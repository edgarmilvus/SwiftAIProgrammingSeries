
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CreateML // Required for MLDataTable and MLLinearRegressor

/// Represents a single historical utility bill record.
/// In a real application, this data would come from a database or user input.
struct UtilityBillData: Identifiable, Codable {
    let id = UUID() // Unique identifier for SwiftUI List iteration
    let month: Int // Month of the year (1-12)
    let avgTemperatureC: Double // Average outdoor temperature in Celsius for the month
    let householdOccupants: Int // Number of people living in the household
    let previousBillAmount: Double // The bill amount from the previous month
    let actualBillAmount: Double // The actual utility bill amount for the current month (target)
}

/// Generates a synthetic dataset of historical utility bill data.
/// This function simulates real-world variations and dependencies between features.
/// - Parameter count: The number of historical records to generate.
/// - Returns: An array of `UtilityBillData` objects.
func generateHistoricalUtilityData(count: Int) -> [UtilityBillData] {
    var data: [UtilityBillData] = []
    var lastBill: Double = 100.0 // Starting point for the previous bill

    for i in 0..<count {
        let month = (i % 12) + 1
        // Simulate temperature variation based on month (e.g., warmer in summer)
        let baseTemp = 10.0 + sin(Double(month - 3) * .pi / 6) * 15.0
        let avgTemperatureC = baseTemp + Double.random(in: -3.0...3.0)

        let householdOccupants = Int.random(in: 1...4)

        // Simulate bill amount based on temperature (higher in extreme temps), occupants, and previous bill
        var currentBill = 50.0 // Base cost
        currentBill += (25.0 - avgTemperatureC).magnitude * 2.0 // Temperature impact
        currentBill += Double(householdOccupants) * 15.0 // Occupant impact
        currentBill += lastBill * Double.random(in: 0.8...1.2) * 0.1 // Previous bill influence

        // Add some random noise
        currentBill += Double.random(in: -10.0...10.0)

        let bill = UtilityBillData(
            month: month,
            avgTemperatureC: avgTemperatureC,
            householdOccupants: householdOccupants,
            previousBillAmount: lastBill,
            actualBillAmount: max(50.0, currentBill) // Ensure bill is not too low
        )
        data.append(bill)
        lastBill = bill.actualBillAmount
    }
    return data
}
