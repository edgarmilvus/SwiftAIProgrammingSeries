
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

// Re-using User struct from Exercise 1 (assumed to be Sendable)
struct User: Identifiable {
    let id: UUID
    let name: String
    let avatarURL: URL?
}

// 1. Create an Attachment enum
enum Attachment: Sendable { // Explicit Sendable conformance for clarity, though often inferred
    case image(url: URL, thumbnailData: Data?) // Data is Sendable
    case video(url: URL, previewImageURL: URL?)
    case file(url: URL, filename: String, fileSize: Int)
    
    // Attachment is automatically Sendable because all its associated values are Sendable:
    // URL (struct), Data (struct), String (struct), Int (struct).
    // Optional<T> is Sendable if T is Sendable (e.g., thumbnailData: Data?)
}

// 3. Modify ChatMessage struct to include an optional attachment property
struct ChatMessage: Identifiable {
    let id: UUID
    let sender: User
    let content: String
    let timestamp: Date
    let attachment: Attachment? // New optional property
    
    // ChatMessage remains automatically Sendable because:
    // - All its original properties (id, sender, content, timestamp) are Sendable.
    // - The new property `attachment: Attachment?` is Sendable because `Attachment` is Sendable,
    //   and Optional<T> is Sendable if T is Sendable.
}

// Example Usage
func demonstrateAttachmentComposition() {
    let user2 = User(id: UUID(), name: "Bob", avatarURL: nil)
    
    let imageData = "some image data".data(using: .utf8) // Simulate Data
    let imageAttachment = Attachment.image(url: URL(string: "https://example.com/photo.jpg")!, thumbnailData: imageData)
    let messageWithImage = ChatMessage(id: UUID(), sender: user2, content: "Check out this photo!", timestamp: Date(), attachment: imageAttachment)
    
    let videoAttachment = Attachment.video(url: URL(string: "https://example.com/video.mp4")!, previewImageURL: URL(string: "https://example.com/video_preview.jpg"))
    let messageWithVideo = ChatMessage(id: UUID(), sender: user2, content: "Watch this video!", timestamp: Date(), attachment: videoAttachment)
    
    let messageWithoutAttachment = ChatMessage(id: UUID(), sender: user2, content: "Just a text message.", timestamp: Date(), attachment: nil)
    
    print("Image message content: \(messageWithImage.content), attachment: \(String(describing: messageWithImage.attachment))")
    print("Video message content: \(messageWithVideo.content), attachment: \(String(describing: messageWithVideo.attachment))")
    print("Text message content: \(messageWithoutAttachment.content), attachment: \(String(describing: messageWithoutAttachment.attachment))")
}

// Call to demonstrate (optional)
// demonstrateAttachmentComposition()
