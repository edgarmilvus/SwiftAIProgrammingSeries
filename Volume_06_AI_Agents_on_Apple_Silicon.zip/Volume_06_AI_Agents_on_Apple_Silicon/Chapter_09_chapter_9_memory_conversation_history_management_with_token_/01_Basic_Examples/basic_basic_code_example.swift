
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation // For basic types like String, Date, UUID
import SwiftUI    // For UI context in an Apple app

// MARK: - 1. Message Data Structure

/// Represents a single message in the conversation, including its content, sender, and timestamp.
/// Conforms to `Identifiable` for easy use in SwiftUI lists and `Equatable` for comparison.
struct Message: Identifiable, Equatable {
    /// A unique identifier for the message, useful for SwiftUI's ForEach.
    let id = UUID()
    /// The actual text content of the message.
    let content: String
    /// The sender of the message (e.g., user or AI).
    let sender: Sender
    /// The timestamp when the message was created, useful for ordering and potential time-based pruning.
    let timestamp: Date

    /// Defines who sent the message.
    enum Sender: String, CaseIterable, Identifiable {
        case user
        case ai

        var id: String { self.rawValue }
    }

    /// A simplified proxy for the number of tokens in the message.
    ///
    /// **Under the Hood Detail:** In a real-world application, this would involve a complex,
    /// LLM-specific tokenizer (e.g., a BPE tokenizer like `tiktoken` for OpenAI models,
    /// or `SentencePiece` for others) that breaks down text into sub-word units and counts them.
    /// For this basic example, we use character count as a simple, illustrative approximation
    /// to keep the focus on the pruning logic itself.
    var tokenCount: Int {
        content.count
    }
}

// MARK: - 2. Conversation Manager

/// Manages the conversation history, ensuring it stays within a defined token budget
/// by pruning older messages when the budget is exceeded.
///
/// Uses `@Observable` (available iOS 17.0+) for seamless integration with SwiftUI,
/// allowing views to automatically react to changes in the conversation history.
/// This makes `ConversationManager` suitable for use as a `@State` or `@Environment` object.
@available(iOS 17.0, macOS 14.0, *) // @Observable is available from iOS 17.0, macOS 14.0
class ConversationManager: ObservableObject { // Using ObservableObject for broader compatibility, @Observable for iOS 17+
    /// The internal storage for all messages in the conversation history.
    /// This array is kept private to enforce controlled access and modification.
    @Published private var messages: [Message] = []

    /// The maximum allowed number of tokens for the entire conversation history.
    /// When the total token count exceeds this budget, older messages are removed.
    let tokenBudget: Int

    /// Initializes a new `ConversationManager` with a specified token budget.
    /// - Parameter tokenBudget: The maximum number of tokens allowed for the conversation history.
    init(tokenBudget: Int) {
        self.tokenBudget = tokenBudget
    }

    /// Adds a new message to the conversation history. After adding, it checks
    /// if the token budget is exceeded and prunes older messages if necessary.
    /// - Parameter newMessage: The `Message` object to be added.
    func addMessage(_ newMessage: Message) {
        messages.append(newMessage)
        print("Added message: '\(newMessage.content)' (\(newMessage.tokenCount) tokens)")
        pruneConversationHistory()
        print("Current history token count: \(currentTokenCount)/\(tokenBudget)")
    }

    /// Provides a read-only copy of the current conversation history.
    /// This prevents external code from directly modifying the `messages` array,
    /// ensuring that pruning logic is always applied correctly.
    var currentHistory: [Message] {
        messages
    }

    /// Calculates the total token count of all messages currently in the history.
    /// This is a computed property that iterates over the `messages` array,
    /// summing up the `tokenCount` of each message.
    private var currentTokenCount: Int {
        messages.reduce(0) { $0 + $1.tokenCount }
    }

    /// Prunes the conversation history by removing the oldest messages until
    /// the `currentTokenCount` is within the `tokenBudget`.
    ///
    /// **How it works:** It continuously removes messages from the beginning of the array
    /// (`messages.removeFirst()`) as long as two conditions are met:
    /// 1. The `currentTokenCount` exceeds the `tokenBudget`.
    /// 2. There is more than one message left in the history (`messages.count > 1`).
    ///
    /// This ensures that at least the most recent message is always retained, even if it alone
    /// exceeds the budget (a scenario that a more advanced system might handle by truncating
    /// the last message itself or rejecting it entirely).
    private func pruneConversationHistory() {
        while currentTokenCount > tokenBudget && messages.count > 1 {
            let removedMessage = messages.removeFirst() // Remove the oldest message
            print("  Pruning: Removed oldest message: '\(removedMessage.content)' (\(removedMessage.tokenCount) tokens)")
        }

        // Edge case: If after pruning, even the single remaining message exceeds the budget,
        // it will still be kept. A more robust system might implement additional logic
        // for this, such as truncating the content of the last message or flagging it.
    }
}

// MARK: - 3. SwiftUI Demonstration View

/// A simple SwiftUI `View` to demonstrate the `ConversationManager` in an app context.
/// This view allows users to send messages and observes the conversation history,
/// automatically updating as messages are added and pruned.
///
/// Uses `@available(iOS 18.0, macOS 15.0, *)` to align with the "latest SDK" context
/// and potential future Swift 6 features, although `@Observable` (or `ObservableObject` used here)
/// is available from iOS 17.0.
@available(iOS 18.0, macOS 15.0, *)
struct ChatView: View {
    /// The text currently being typed by the user in the input field.
    @State private var inputText: String = ""
    /// An instance of `ConversationManager` to handle message history.
    /// Initialized with a small token budget (e.g., 100) for easy demonstration of pruning.
    @StateObject private var conversationManager = ConversationManager(tokenBudget: 100)

    var body: some View {
        VStack {
            // Display area for messages, allowing scrolling for long histories
            ScrollView {
                VStack(alignment: .leading) {
                    ForEach(conversationManager.currentHistory) { message in
                        HStack {
                            if message.sender == .user {
                                Spacer() // Push user messages to the right
                                Text(message.content)
                                    .padding(8)
                                    .background(Color.blue.opacity(0.8))
                                    .cornerRadius(10)
                                    .foregroundColor(.white)
                            } else {
                                // AI messages on the left
                                Text(message.content)
                                    .padding(8)
                                    .background(Color.gray.opacity(0.2))
                                    .cornerRadius(10)
                                    .foregroundColor(.black)
                                Spacer()
                            }
                        }
                        .padding(.vertical, 2) // Small vertical spacing between messages
                    }
                }
                .padding()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.white.opacity(0.1)) // Subtle background for the chat area

            // Input field and send buttons
            HStack {
                TextField("Type a message...", text: $inputText)
                    .textFieldStyle(.roundedBorder) // Modern way to apply text field style
                    .padding(.horizontal)

                Button("Send User") {
                    sendMessage(sender: .user)
                }
                .buttonStyle(.borderedProminent) // Visually distinct primary button

                Button("Send AI") {
                    sendMessage(sender: .ai)
                }
                .buttonStyle(.bordered) // Standard button style
            }
            .padding()
        }
        // Display current token count in the navigation title for easy monitoring
        .navigationTitle("AI Chat (Tokens: \(conversationManager.currentHistory.reduce(0) { $0 + $1.tokenCount }) / \(conversationManager.tokenBudget))")
    }

    /// Handles sending a message, either from the user or simulating an AI response.
    /// - Parameter sender: The `Sender` of the message.
    private func sendMessage(sender: Message.Sender) {
        guard !inputText.isEmpty else { return } // Don't send empty messages
        let message = Message(content: inputText, sender: sender, timestamp: Date())
        conversationManager.addMessage(message) // Add message to manager, triggering pruning if needed
        inputText = "" // Clear the input field after sending
    }
}

// MARK: - App Entry Point (for a simple SwiftUI demo)

/*
// To run this in a full SwiftUI app, your App.swift might look like this:
@main
@available(iOS 18.0, macOS 15.0, *)
struct AI_Agent_App: App {
    var body: some Scene {
        WindowGroup {
            NavigationView { // Or NavigationStack in iOS 16+ for modern navigation
                ChatView()
            }
        }
    }
}
*/

// MARK: - Console Demonstration (Alternative without SwiftUI)

/*
// To run this in a simple console application (e.g., in a Playground or main.swift):
@available(iOS 17.0, macOS 14.0, *)
func demonstrateConversationManagerInConsole() {
    print("--- Console Demonstration of ConversationManager ---")
    let manager = ConversationManager(tokenBudget: 50) // Small budget for quick pruning visibility

    manager.addMessage(Message(content: "Hello, AI!", sender: .user, timestamp: Date()))
    manager.addMessage(Message(content: "Hi there! How can I help you today?", sender: .ai, timestamp: Date()))
    manager.addMessage(Message(content: "Tell me a very long story about a space cat named Astro.", sender: .user, timestamp: Date()))
    manager.addMessage(Message(content: "Astro, the space cat, was born on a cosmic dust cloud, drifting through the Andromeda galaxy.", sender: .ai, timestamp: Date()))
    manager.addMessage(Message(content: "His adventures took him across galaxies, meeting alien species and discovering new stars, always with a purr.", sender: .ai, timestamp: Date()))
    manager.addMessage(Message(content: "He had a special collar that translated all languages, making him a universal diplomat.", sender: .ai, timestamp: Date()))
    manager.addMessage(Message(content: "What exciting new planet did Astro discover next?", sender: .user, timestamp: Date()))
    manager.addMessage(Message(content: "Astro soon stumbled upon Xylos, a planet made entirely of sentient crystals.", sender: .ai, timestamp: Date()))

    print("\n--- Final Conversation History ---")
    for msg in manager.currentHistory {
        print("[\(msg.sender)] \(msg.content) (\(msg.tokenCount) tokens)")
    }
    print("Total tokens in final history: \(manager.currentHistory.reduce(0) { $0 + $1.tokenCount }) / \(manager.tokenBudget)")
}

// Uncomment the line below to run the console demo:
// demonstrateConversationManagerInConsole()
*/
