
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// MARK: - Create ML Model Generation (Run this in an Xcode Playground)
import CreateML
import Foundation

// 1. Prepare your dataset
// In a real scenario, you'd load this from a CSV or JSON file.
// For this example, we'll use an array of dictionaries.
let moderationData: [[String: String]] = [
    ["text": "This is a perfectly fine comment.", "label": "Appropriate"],
    ["text": "I love this app, great features!", "label": "Appropriate"],
    ["text": "What a wonderful day!", "label": "Appropriate"],
    ["text": "Let's discuss this further.", "label": "Appropriate"],
    ["text": "The service was excellent.", "label": "Appropriate"],
    ["text": "You are a complete idiot!", "label": "Flagged"],
    ["text": "This content is offensive and terrible.", "label": "Flagged"],
    ["text": "I hate everything about this.", "label": "Flagged"],
    ["text": "Don't be a jerk.", "label": "Flagged"],
    ["text": "Spam message: buy now!", "label": "Flagged"]
]

// Convert to MLDataTable
let dataTable = try! MLDataTable(array: moderationData)

// Split into training and testing data (optional, but good practice)
let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 0)

// 2. Train the text classifier
let classifier = try! MLTextClassifier(trainingData: trainingData,
                                       textColumn: "text",
                                       labelColumn: "label")

// 3. Evaluate the model (optional)
let evaluationMetrics = classifier.evaluation(on: testingData, textColumn: "text", labelColumn: "label")
print("Validation Accuracy: \(evaluationMetrics.accuracy)")

// 4. Save the model
let modelURL = URL(fileURLWithPath: "/tmp/InappropriateContentClassifier.mlmodel") // Change path as needed
try! classifier.write(to: modelURL)
print("Model saved to: \(modelURL.path)")

// Drag the generated InappropriateContentClassifier.mlmodel from /tmp/ to your Xcode project.
