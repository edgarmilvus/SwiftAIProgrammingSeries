
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

// MARK: - Document Data Extractor Agent

/// An agent that uses an MLX-powered LLM to extract structured data from documents,
/// employing an agentic loop for self-correction and refinement.
@available(iOS 18.0, macOS 14.0, *)
class DocumentDataExtractorAgent {
    private let llmEngine: MLXLLMInferenceEngine
    private let maxIterations: Int

    /// Initializes the document data extractor agent.
    /// - Parameters:
    ///   - llmEngine: An instance of `MLXLLMInferenceEngine` to perform LLM inference.
    ///   - maxIterations: The maximum number of times the agent will attempt to extract and refine data.
    init(llmEngine: MLXLLMInferenceEngine, maxIterations: Int = 3) {
        self.llmEngine = llmEngine
        self.maxIterations = maxIterations
    }

    /// Extracts structured data from the given document text using an iterative agentic loop.
    ///
    /// **The Agentic Loop Explained:**
    /// 1. **Initial Prompt:** The LLM is given the document text and asked to extract specific fields in JSON format.
    /// 2. **Inference:** The `MLXLLMInferenceEngine` generates a response.
    /// 3. **Parsing:** The agent attempts to parse the LLM's raw text output into a `DocumentData` structure.
    /// 4. **Validation (Critic):** The `validateExtraction` method acts as a critic, checking if the parsed data is complete and valid.
    /// 5. **Feedback & Refinement:**
    ///    - If valid, the process succeeds.
    ///    - If invalid, the critic generates specific feedback (e.g., "missing totalAmount", "invoiceDate format invalid").
    ///    - This feedback is appended to the original prompt, instructing the LLM to correct its previous attempt.
    /// 6. **Iteration:** The loop repeats with the refined prompt until valid data is extracted or `maxIterations` is reached.
    ///
    /// This iterative process allows the agent to self-correct, mimicking a human's ability to review and refine work.
    ///
    /// - Parameter documentText: The raw text content of the document.
    /// - Returns: A `DocumentData` object containing the extracted structured information.
    /// - Throws: `DocumentExtractionError` if extraction fails after `maxIterations`.
    func extractData(from documentText: String) async throws -> DocumentData {
        var currentPrompt = """
        You are an expert document data extractor. Extract the 'vendor', 'totalAmount', and 'invoiceDate'
        from the following document text. Respond ONLY with a JSON object.

        Document: \"\"\"
        \(documentText)
        \"\"\"

        JSON:
        """

        for iteration in 1...maxIterations {
            print("\n--- Agent Iteration \(iteration)/\(maxIterations) ---")
            print("Prompting LLM with:\n\(currentPrompt.prefix(200))...")

            let llmOutput: String
            do {
                llmOutput = try await llmEngine.generate(prompt: currentPrompt)
                print("LLM Raw Output:\n\(llmOutput)")
            } catch {
                throw DocumentExtractionError.llmInferenceFailed("LLM generation failed: \(error.localizedDescription)")
            }

            guard let jsonData = llmOutput.data(using: .utf8) else {
                currentPrompt += "\n\nFeedback: Your previous response was not valid JSON. Please ensure your response is a well-formed JSON object."
                continue // Try again
            }

            do {
                // Attempt to decode the JSON output into our DocumentData structure
                let decoder = JSONDecoder()
                let extractedData = try decoder.decode(DocumentData.self, from: jsonData)

                // Validate the extracted data using our critic
                let (isValid, feedback) = validateExtraction(data: extractedData)

                if isValid {
                    print("✅ Data extraction successful after \(iteration) iterations.")
                    return extractedData
                } else if let feedbackMessage = feedback {
                    print("❌ Validation failed. Feedback: \(feedbackMessage)")
                    // Append feedback to the prompt for the next iteration
                    currentPrompt += "\n\nFeedback: \(feedbackMessage)\n\nRevised JSON:"
                } else {
                    // Fallback if feedback is nil but not valid
                    currentPrompt += "\n\nFeedback: The extracted data was invalid. Please re-evaluate and provide a correct JSON object."
                }
            } catch {
                print("❌ Failed to parse or decode LLM output: \(error.localizedDescription)")
                // Provide specific feedback if parsing failed
                currentPrompt += "\n\nFeedback: Your previous JSON output was malformed or did not match the expected structure (vendor: String, totalAmount: Double, invoiceDate: String). Please correct the JSON format."
            }
        }

        throw DocumentExtractionError.agentMaxIterationsReached
    }

    /// Acts as the "critic" for the agent, validating the extracted document data.
    /// - Parameter data: The `DocumentData` object to validate.
    /// - Returns: A tuple indicating `(isValid: Bool, feedback: String?)`.
    private func validateExtraction(data: DocumentData) -> (isValid: Bool, feedback: String?) {
        var feedbackMessages: [String] = []

        if data.vendor.isEmpty || data.vendor == "Unknown" || data.vendor == "N/A" {
            feedbackMessages.append("The 'vendor' field is missing or generic. Please identify the correct vendor.")
        }

        if data.totalAmount <= 0.0 {
            feedbackMessages.append("The 'totalAmount' must be a valid positive number. Current value: \(data.totalAmount).")
        }

        // Simple date format validation (e.g., YYYY-MM-DD)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        if dateFormatter.date(from: data.invoiceDate) == nil {
            feedbackMessages.append("The 'invoiceDate' format is invalid. Please use 'YYYY-MM-DD'. Current value: '\(data.invoiceDate)'.")
        }

        if feedbackMessages.isEmpty {
            return (true, nil)
        } else {
            return (false, feedbackMessages.joined(separator: " "))
        }
    }
}
