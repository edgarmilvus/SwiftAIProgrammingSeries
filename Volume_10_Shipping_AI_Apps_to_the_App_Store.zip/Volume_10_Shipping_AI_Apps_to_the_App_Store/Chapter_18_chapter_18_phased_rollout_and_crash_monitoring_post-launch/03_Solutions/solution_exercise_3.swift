
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

/// 1. Metric Data Structure
struct AIMetric: Sendable {
    let latency: Duration
    let tokenCount: Int
    let modelID: String
    let timestamp: Date
}

/// 2. Optimized Summary Struct
struct TelemetrySummary: Sendable {
    let averageLatency: Duration
    let p95Latency: Duration
    let totalTokens: Int
    let count: Int
}

/// 3. The Telemetry Actor (High-speed Buffer)
actor TelemetryActor {
    private var metricsBuffer: [AIMetric] = []
    private let maxBufferSize = 1000

    func record(_ metric: AIMetric) {
        metricsBuffer.append(metric)
        // Maintain circular buffer to prevent memory bloat
        if metricsBuffer.count > maxBufferSize {
            metricsBuffer.removeFirst()
        }
    }

    /// 4. Asynchronous Aggregation using TaskGroups
    func generateReport() async -> TelemetrySummary {
        guard !metricsBuffer.isEmpty else {
            return TelemetrySummary(averageLatency: .zero, p95Latency: .zero, totalTokens: 0, count: 0)
        }

        let currentMetrics = metricsBuffer
        
        // Use a TaskGroup to perform heavy math concurrently
        return await withTaskGroup(of: AggregationResult.self) { group in
            // Task 1: Calculate Token Totals
            group.addTask {
                let total = currentMetrics.reduce(0) { $0 + $1.tokenCount }
                return .tokens(total)
            }

            // Task 2: Calculate Latency Stats
            group.addTask {
                let latencies = currentMetrics.map { $0.latency }.sorted()
                let sum = latencies.reduce(.zero, +)
                let avg = sum / Double(latencies.count)
                
                // P95 Calculation
                let p95Index = Int(Double(latencies.count) * 0.95)
                let p95 = latencies[min(p95Index, latencies.count - 1)]
                
                return .latency(avg, p95)
            }

            var totalTokens = 0
            var avgLat: Duration = .zero
            var p95Lat: Duration = .zero

            for await result in group {
                switch result {
                case .tokens(let t): totalTokens = t
                case .latency(let avg, let p95):
                    avgLat = avg
                    p95Lat = p95
                }
            }

            return TelemetrySummary(
                averageLatency: avgLat,
                p95Latency: p95Lat,
                totalTokens: totalTokens,
                count: currentMetrics.count
            )
        }
    }

    private enum AggregationResult {
        case tokens(Int)
        case latency(Duration, Duration)
    }
}

/// 5. The Middleware (Interceptor Pattern)
protocol AIProvider: Sendable {
    func process(prompt: String) async throws -> String
}

struct TelemetryMiddleware: AIProvider {
    let innerProvider: any AIProvider
    let telemetryActor: TelemetryActor
    let modelID: String

    func process(prompt: String) async throws -> String {
        let clock = ContinuousClock()
        let startTime = clock.now
        
        do {
            let result = try await innerProvider.process(prompt: prompt)
            let duration = startTime.duration(to: clock.now)
            
            // Non-blocking: We don't 'await' the recording in a way that stalls the user
            Task {
                await telemetryActor.record(AIMetric(
                    latency: duration,
                    tokenCount: prompt.count / 4, // Mock token estimation
                    modelID: modelID,
                    timestamp: Date()
                ))
            }
            
            return result
        } catch {
            throw error
        }
    }
}
