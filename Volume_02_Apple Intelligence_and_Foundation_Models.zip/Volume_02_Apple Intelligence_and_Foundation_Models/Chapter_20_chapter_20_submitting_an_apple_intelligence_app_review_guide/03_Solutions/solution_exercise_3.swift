
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import SwiftUI
import TextGeneration

// Define a simple Message structure for conversation history
struct Message: Identifiable, Equatable {
    let id = UUID()
    let sender: String
    let content: String
    let isUser: Bool // Added to distinguish user messages from others
}

@available(iOS 18.0, *)
struct ChatView: View {
    // Example conversation history
    @State private var conversationHistory: [Message] = [
        Message(sender: "Alice", content: "Hey, are you free for coffee this afternoon?", isUser: false),
        Message(sender: "Bob", content: "I'm a bit swamped with work, maybe tomorrow?", isUser: true),
        Message(sender: "Alice", content: "No worries! How about lunch on Wednesday instead?", isUser: false),
        Message(sender: "Bob", content: "Wednesday sounds good. What time works for you?", isUser: true),
        Message(sender: "Alice", content: "Around 1 PM? There's a new cafe downtown.", isUser: false)
    ]
    @State private var messageInput: String = ""
    @State private var smartReplies: [String] = []
    @State private var showingSmartReplies = false
    @State private var isLoadingReplies = false
    @FocusState private var isInputFocused: Bool
    @State private var isTextGenerationAvailable = TextGenerationService.shared.isAvailable

    var body: some View {
        VStack(spacing: 0) {
            // Display conversation history
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(conversationHistory) { message in
                        HStack {
                            if message.isUser { Spacer() }
                            Text("\(message.content)")
                                .padding(8)
                                .background(message.isUser ? Color.blue.opacity(0.8) : Color.gray.opacity(0.2))
                                .foregroundColor(message.isUser ? .white : .primary)
                                .cornerRadius(10)
                            if !message.isUser { Spacer() }
                        }
                    }
                }
                .padding()
            }
            .background(Color.clear) // To ensure scroll view content padding is visible

            if showingSmartReplies && !smartReplies.isEmpty {
                VStack(alignment: .leading, spacing: 5) {
                    HStack {
                        Text("AI Suggestions:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Spacer()
                        Button("Dismiss") {
                            showingSmartReplies = false
                        }
                        .font(.caption)
                        .buttonStyle(.plain)
                        .foregroundColor(.secondary)
                    }
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(smartReplies, id: \.self) { reply in
                                Button(reply) {
                                    messageInput = reply
                                    showingSmartReplies = false // Hide suggestions after selection
                                    isInputFocused = true // Keep input focused
                                }
                                .buttonStyle(.bordered)
                                .font(.subheadline)
                                .lineLimit(1)
                            }
                        }
                    }
                }
                .padding([.horizontal, .top])
                .background(Color.clear)
                .transition(.opacity.combined(with: .move(edge: .bottom))) // Smooth transition
            } else if isLoadingReplies {
                ProgressView("Generating suggestions...")
                    .padding()
                    .transition(.opacity)
            }

            HStack {
                TextField("Message", text: $messageInput)
                    .textFieldStyle(.roundedBorder)
                    .focused($isInputFocused)
                    .onChange(of: isInputFocused) { oldValue, newValue in
                        if newValue { // Input field became focused
                            // Only generate if no text has been entered yet
                            if messageInput.isEmpty {
                                Task {
                                    await generateSmartReplies()
                                }
                            }
                        } else { // Input field lost focus
                            showingSmartReplies = false
                        }
                    }
                    .onChange(of: messageInput) { oldValue, newValue in
                        // Dismiss suggestions if user starts typing
                        if !newValue.isEmpty && newValue != oldValue {
                            showingSmartReplies = false
                        }
                    }

                Button("Send") {
                    if !messageInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        conversationHistory.append(Message(sender: "You", content: messageInput, isUser: true))
                        messageInput = ""
                        showingSmartReplies = false
                        // After sending, if input is still focused, regenerate suggestions
                        if isInputFocused {
                            Task {
                                await generateSmartReplies()
                            }
                        }
                    }
                }
                .disabled(messageInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding()
            .background(Color.clear) // Ensure padding is visible
        }
        .animation(.easeInOut(duration: 0.2), value: showingSmartReplies) // Animate changes to smart replies
        .animation(.easeInOut(duration: 0.2), value: isLoadingReplies)
        .onAppear {
            // Observe availability changes
            NotificationCenter.default.addObserver(forName: TextGenerationService.availabilityDidChangeNotification, object: nil, queue: .main) { _ in
                isTextGenerationAvailable = TextGenerationService.shared.isAvailable
            }
        }
        .onDisappear {
            // Clean up observer
            NotificationCenter.default.removeObserver(self, name: TextGenerationService.availabilityDidChangeNotification, object: nil)
        }
    }

    private func generateSmartReplies() async {
        guard isTextGenerationAvailable else {
            print("Text Generation Service is not available.")
            return
        }

        // Only generate if input is focused and empty, and not already loading
        guard isInputFocused, messageInput.isEmpty, !isLoadingReplies else { return }

        isLoadingReplies = true
        smartReplies = [] // Clear previous replies

        // Construct a prompt from the conversation history
        // Take the last 5 messages for context
        let relevantHistory = conversationHistory.suffix(5)
        let conversationText = relevantHistory.map { "\($0.sender): \($0.content)" }.joined(separator: "\n")

        // Prompt engineering for structured output and multiple suggestions
        let prompt = """
        Based on the following conversation, suggest 3-5 short, concise, and relevant replies for the last message.
        Respond with a comma-separated list of replies. Each reply should be brief.

        Conversation:
        \(conversationText)

        Replies:
        """

        let request = TextGenerationRequest(prompt: prompt)
        request.options.maxTokens = 100 // Limit response length for brevity
        request.options.temperature = 0.7 // Adjust for a bit of creativity in suggestions
        request.options.topP = 0.9 // For diverse but relevant suggestions

        do {
            let result = try await TextGenerationService.shared.generate(request)
            if let generatedText = result.text, !generatedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                // Parse the comma-separated string into an array of replies
                let parsedReplies = generatedText.split(separator: ",").map {
                    $0.trimmingCharacters(in: .whitespacesAndNewlines)
                }.filter { !$0.isEmpty } // Remove any empty strings resulting from parsing

                if !parsedReplies.isEmpty {
                    smartReplies = parsedReplies
                    showingSmartReplies = true
                } else {
                    print("No valid smart replies parsed.")
                    showingSmartReplies = false
                }
            } else {
                print("No smart replies generated.")
                showingSmartReplies = false
            }
        } catch {
            print("Error generating smart replies: \(error.localizedDescription)")
            // Optionally present an alert to the user about the failure
            showingSmartReplies = false
        }
        isLoadingReplies = false
    }
}

// Example usage in a parent view:
@available(iOS 18.0, *)
struct ChatView_Previews: PreviewProvider {
    static var previews: some View {
        ChatView()
    }
}
