
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// A protocol defining the behavior of a text chunking engine.
protocol TextChunker: Sendable {
    func chunk(text: String, maxChunkSize: Int, overlap: Int) async -> [String]
}

@available(iOS 18.0, macOS 15.0, *)
struct WordBoundaryChunker: TextChunker {
    
    func chunk(text: String, maxChunkSize: Int, overlap: Int) async -> [String] {
        guard !text.isEmpty else { return [] }
        // Prevent infinite loops or invalid logic
        let effectiveMax = max(maxChunkSize, 1)
        let effectiveOverlap = min(overlap, effectiveMax - 1)
        
        var chunks: [String] = []
        var currentIndex = text.startIndex
        
        while currentIndex < text.endIndex {
            // 1. Determine the end bound for this chunk
            let remainingRange = currentIndex..<text.endIndex
            let targetEndIndex = text.index(currentIndex, offsetBy: effectiveMax, limitedBy: text.endIndex) ?? text.endIndex
            
            var actualEndIndex = targetEndIndex
            
            // 2. If we aren't at the end of the string, try to find a word boundary (space/newline)
            // to avoid cutting a word in half.
            if actualEndIndex < text.endIndex {
                if let wordBoundary = findLastBoundary(in: text, upTo: actualEndIndex, startingFrom: currentIndex) {
                    actualEndIndex = wordBoundary
                }
            }
            
            // 3. Create the chunk
            let chunk = String(text[currentIndex..<actualEndIndex]).trimmingCharacters(in: .whitespacesAndNewlines)
            if !chunk.isEmpty {
                chunks.append(chunk)
            }
            
            // 4. Calculate next start index using overlap
            // We look back from the actualEndIndex by 'effectiveOverlap' characters
            // and find the nearest word boundary to ensure the overlap is also semantic.
            let overlapStartSearch = text.index(actualEndIndex, offsetBy: -effectiveOverlap, limitedBy: currentIndex) ?? currentIndex
            
            if let overlapBoundary = findLastBoundary(in: text, upTo: actualEndIndex, startingFrom: overlapStartSearch) {
                currentIndex = overlapBoundary
            } else {
                // Fallback: if no boundary found in overlap range, move to actualEndIndex
                currentIndex = actualEndIndex
            }
            
            // Safety break: if we aren't progressing, force move forward
            if currentIndex <= text.index(currentIndex, offsetBy: -1, limitedBy: text.endIndex) == false && actualEndIndex == currentIndex {
                currentIndex = actualEndIndex
            }
            
            // Prevent infinite loop if overlap keeps us at the same index
            if chunks.count > 1000 { break } // Safety cap for exercise
        }
        
        return chunks
    }
    
    /// Helper to find the nearest whitespace or newline index
    private func findLastBoundary(in text: String, upTo limit: String.Index, startingFrom start: String.Index) -> String.Index? {
        var searchIndex = limit
        while searchIndex > start {
            let char = text[searchIndex]
            if char.isWhitespace {
                return searchIndex
            }
            if let prev = text.index(searchIndex, offsetBy: -1, limitedBy: text.startIndex) {
                searchIndex = prev
            } else {
                break
            }
        }
        return nil
    }
}
