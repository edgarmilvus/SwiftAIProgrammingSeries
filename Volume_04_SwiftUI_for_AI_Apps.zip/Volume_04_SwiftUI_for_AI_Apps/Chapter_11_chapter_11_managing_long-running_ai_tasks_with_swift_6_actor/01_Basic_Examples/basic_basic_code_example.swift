
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation // For basic types like String, Data, etc.
import SwiftUI    // For UI components and @MainActor
import Combine    // For ObservableObject and Published, though a simple @State would also work.

// Ensure the code compiles and runs on recent SDKs.
// Actors were introduced in Swift 5.5, available on iOS 15.0+.
@available(iOS 15.0, macOS 12.0, *)
enum OCRResult {
    case success(String)
    case failure(Error)
    case processing
    case idle
}

/// 1. Define the AI Model's Output and Input
/// We'll simulate a complex OCR result.
struct DocumentOCRResult: Identifiable {
    let id = UUID()
    let documentName: String
    let extractedText: String
    let processingTime: TimeInterval
}

/// A simple error type for our simulated OCR process.
enum OCRServiceError: Error, LocalizedError {
    case processingFailed(String)
    case invalidInput

    var errorDescription: String? {
        switch self {
        case .processingFailed(let reason):
            return "OCR processing failed: \(reason)"
        case .invalidInput:
            return "Invalid input for OCR."
        }
    }
}

/// 2. Define the DocumentProcessorActor
/// This actor encapsulates the AI model (simulated here) and its processing logic.
/// By making it an actor, we ensure that the `processDocument` method
/// can only be executed by one task at a time, preventing data races
/// if multiple parts of the app tried to OCR documents simultaneously.
actor DocumentProcessorActor {
    // In a real app, this might be an MLModel instance,
    // a Core ML model, or a connection to a remote AI service.
    private var isModelLoaded: Bool = false
    private var processingQueue: [UUID: String] = [:] // Simulate a queue for requests

    /// Initializes the actor and simulates loading an AI model.
    init() {
        print("DocumentProcessorActor: Initializing and loading AI model...")
        // Simulate a delay for model loading
        Task {
            await Task.sleep(nanoseconds: 1_000_000_000) // 1 second
            self.isModelLoaded = true
            print("DocumentProcessorActor: AI model loaded successfully.")
        }
    }

    /// /// Simulates a long-running OCR task.
    /// - Parameters:
    ///   - documentID: A unique identifier for the document.
    ///   - imageData: The raw image data to be processed.
    /// - Returns: A `DocumentOCRResult` containing the extracted text and processing details.
    /// - Throws: `OCRServiceError` if processing fails.
    func processDocument(documentID: UUID, imageData: Data) async throws -> DocumentOCRResult {
        // Actor isolation ensures that only one task can execute this method at a time.
        // This protects `isModelLoaded` and `processingQueue` from concurrent access.

        guard isModelLoaded else {
            print("DocumentProcessorActor: Model not yet loaded. Waiting...")
            // A more robust solution might queue the request or wait for loading.
            // For this example, we'll just simulate a wait.
            await Task.sleep(nanoseconds: 2_000_000_000) // Wait another 2 seconds
            guard isModelLoaded else {
                throw OCRServiceError.processingFailed("AI model failed to load.")
            }
        }

        print("DocumentProcessorActor: Starting OCR for document \(documentID)...")
        let startTime = Date()

        // Simulate complex AI processing.
        // In a real app, this would involve calling a Core ML model's prediction method
        // or making a network request to an AI API.
        await Task.sleep(nanoseconds: UInt64.random(in: 3_000_000_000...7_000_000_000)) // 3 to 7 seconds

        // Simulate a potential failure
        if Bool.random() && documentID.uuidString.contains("F") { // Just a random condition for failure
            print("DocumentProcessorActor: OCR failed for document \(documentID) due to simulated error.")
            throw OCRServiceError.processingFailed("Simulated OCR engine malfunction.")
        }

        let extractedText = "This is the simulated OCR result for document \(documentID). " +
                            "The image data size was \(imageData.count) bytes. " +
                            "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
        let processingTime = Date().timeIntervalSince(startTime)

        print("DocumentProcessorActor: Finished OCR for document \(documentID) in \(String(format: "%.2f", processingTime))s.")

        return DocumentOCRResult(documentName: "Document \(documentID.uuidString.prefix(4))",
                                 extractedText: extractedText,
                                 processingTime: processingTime)
    }
    
    /// Cleans up resources, if necessary.
    deinit {
        print("DocumentProcessorActor: Deinitialized.")
    }
}

/// 3. Define a ViewModel to interact with the actor and manage UI state.
/// We use `@MainActor` to ensure all state updates happen on the main thread,
/// which is crucial for SwiftUI views.
@MainActor
@available(iOS 15.0, macOS 12.0, *)
class DocumentScannerViewModel: ObservableObject {
    @Published var ocrResults: [DocumentOCRResult] = []
    @Published var currentOCRStatus: OCRResult = .idle
    @Published var errorMessage: String?

    // The actor instance. It's a reference type, so we hold onto it.
    private let processorActor = DocumentProcessorActor()

    /// Initiates an OCR process for a new document.
    /// - Parameter documentID: The ID of the document to process.
    /// - Parameter imageData: The simulated image data.
    func scanAndProcessDocument(documentID: UUID, imageData: Data) {
        errorMessage = nil
        currentOCRStatus = .processing
        print("ViewModel: Initiating scan for document \(documentID)...")

        // We launch a new Task to perform the asynchronous work.
        // The work inside the Task will run on a cooperative thread pool,
        // offloading from the main actor.
        Task {
            do {
                // `await` is required to call an actor's async method.
                // This suspends the current task until the actor's method completes.
                // Because `processorActor` is an actor, this call is safely isolated.
                let result = try await processorActor.processDocument(documentID: documentID, imageData: imageData)

                // Once the actor's work is done, we are back in the `Task`'s context.
                // Since `self` (DocumentScannerViewModel) is `@MainActor`,
                // all modifications to `@Published` properties here are automatically
                // dispatched to the main thread, ensuring UI safety.
                self.ocrResults.append(result)
                self.currentOCRStatus = .success(result.extractedText)
                print("ViewModel: Successfully processed document \(documentID).")
            } catch {
                self.errorMessage = error.localizedDescription
                self.currentOCRStatus = .failure(error)
                print("ViewModel: Failed to process document \(documentID): \(error.localizedDescription)")
            }
        }
    }
}

/// 4. Create a SwiftUI View to interact with the ViewModel and display results.
@available(iOS 15.0, macOS 12.0, *)
struct DocumentScannerView: View {
    // The ViewModel is an ObservableObject, so we use @StateObject to manage its lifecycle.
    @StateObject private var viewModel = DocumentScannerViewModel()

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("AI Document Scanner")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                // Button to simulate scanning a new document.
                Button("Scan New Document (Simulated)") {
                    let newDocumentID = UUID()
                    let simulatedImageData = Data(repeating: UInt8.random(in: 0...255), count: 1024 * 1024 * Int.random(in: 1...5)) // 1-5 MB
                    viewModel.scanAndProcessDocument(documentID: newDocumentID, imageData: simulatedImageData)
                }
                .buttonStyle(.borderedProminent)
                .padding()

                // Display current processing status.
                Group {
                    switch viewModel.currentOCRStatus {
                    case .idle:
                        Text("Ready to scan.")
                            .foregroundColor(.secondary)
                    case .processing:
                        ProgressView("Processing document...")
                            .progressViewStyle(.circular)
                            .padding(.vertical)
                    case .success(let text):
                        Text("Last OCR Success!")
                            .foregroundColor(.green)
                            .fontWeight(.medium)
                        Text(text.prefix(100) + "...")
                            .font(.caption)
                            .lineLimit(2)
                    case .failure(let error):
                        Text("OCR Failed: \(error.localizedDescription)")
                            .foregroundColor(.red)
                            .fontWeight(.medium)
                    }
                }
                .animation(.easeInOut, value: viewModel.currentOCRStatus)

                // Display error messages.
                if let errorMessage = viewModel.errorMessage {
                    Text("Error: \(errorMessage)")
                        .foregroundColor(.red)
                        .padding()
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(8)
                }

                // List of all processed documents.
                List {
                    Section("Processed Documents") {
                        if viewModel.ocrResults.isEmpty {
                            Text("No documents processed yet.")
                                .foregroundColor(.secondary)
                        } else {
                            ForEach(viewModel.ocrResults.reversed()) { result in
                                VStack(alignment: .leading) {
                                    Text(result.documentName)
                                        .font(.headline)
                                    Text("Extracted: \(result.extractedText.prefix(50))...")
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                    Text("Time: \(String(format: "%.2f", result.processingTime))s")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
            }
            .navigationTitle("") // Hide default navigation title
            .navigationBarHidden(true) // Hide navigation bar for a cleaner look
        }
    }
}

// MARK: - App Entry Point (for Xcode Previews or actual app)
@main
@available(iOS 15.0, macOS 12.0, *)
struct AIAppBookExampleApp: App {
    var body: some Scene {
        WindowGroup {
            DocumentScannerView()
        }
    }
}
