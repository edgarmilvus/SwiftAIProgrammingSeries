
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// @available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct ToolParameter: Codable, Sendable, Identifiable {
    let id = UUID() // For SwiftUI List iteration if needed
    let name: String
    let value: String // Assuming string values for simplicity, could be Codable for complex types
}

// @available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct ToolCall: Codable, Sendable {
    let toolName: String
    let parameters: [String: String] // Dictionary for dynamic parameters

    // Example of a specific tool's parameters
    struct SearchWebParameters: Codable, Sendable {
        let query: String
    }

    // A utility to decode specific tool parameters if needed
    func decodeParameters<T: Codable & Sendable>(as type: T.Type) throws -> T {
        let data = try JSONSerialization.data(withJSONObject: parameters)
        return try JSONDecoder().decode(type, from: data)
    }
}
