
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import NaturalLanguage // Provides NLModel for text classification
import Foundation    // For URL, Bundle, and basic error handling

/// A class responsible for loading and performing text classification using a pre-trained NLModel.
/// This model is typically trained using Apple's Create ML framework.
@available(iOS 15.0, macOS 12.0, *) // NLModel itself is available from iOS 12.0, macOS 10.14,
                                    // but we use a modern baseline for the example context.
class SupportTicketClassifier {
    /// The underlying Natural Language model used for predictions.
    private var model: NLModel?

    /// Initializes the classifier by attempting to load a Core ML model from the specified URL.
    /// The model at the URL is expected to be a text classification model.
    ///
    /// - Parameter modelURL: The file URL to the compiled Core ML model (e.g., `MyClassifier.mlmodel`).
    /// - Returns: An initialized `SupportTicketClassifier` instance, or `nil` if the model
    ///            could not be loaded.
    init?(modelURL: URL) {
        do {
            // Step 1: Load the pre-trained NLModel
            // NLModel acts as a convenient wrapper around MLModel specifically for
            // natural language tasks. It handles the specific input/output formats
            // expected by text classification models.
            self.model = try NLModel(contentsOf: modelURL)
            print("✅ Successfully loaded NLModel from \(modelURL.lastPathComponent)")
        } catch {
            // It's crucial to handle errors during model loading, as the app
            // cannot function without the model. Common errors include:
            // - Model file not found at the URL.
            // - Model file is corrupted or not a valid Core ML model.
            // - Model type mismatch (e.g., trying to load an image classifier as an NLModel).
            print("❌ Failed to load NLModel from \(modelURL.lastPathComponent): \(error.localizedDescription)")
            return nil // Indicate initialization failure
        }
    }

    /// Predicts the category label for a given text input using the loaded model.
    ///
    /// - Parameter text: The input string to be classified.
    /// - Returns: The predicted category label as a `String` (e.g., "Billing", "Technical Support"),
    ///            or `nil` if the model is not loaded or an error occurs during prediction.
    func classify(text: String) -> String? {
        // Ensure the model is loaded before attempting to make a prediction.
        guard let model = self.model else {
            print("Error: NLModel is not loaded. Cannot perform classification.")
            return nil
        }

        // Step 2: Perform prediction using the loaded model
        // NLModel's `predictedLabel(for:)` method takes a String and returns
        // the most likely label predicted by the model.
        let predictedLabel = model.predictedLabel(for: text)
        return predictedLabel
    }
}

// MARK: - Example Usage in an App Context

/// This asynchronous function demonstrates how to use the `SupportTicketClassifier`
/// within a typical iOS/macOS application setup.
@available(iOS 15.0, macOS 12.0, *)
@MainActor // Indicates that this function (and potentially its callers) should run on the main actor.
           // This is important for UI updates and typically for initial app setup.
func runTextClassificationExample() async {
    print("--- Starting Text Classification Example ---")

    // Step 0: Obtain the URL to your pre-trained Core ML model.
    // In a real application, you would drag your '.mlmodel' file (generated by Create ML)
    // into your Xcode project. Xcode automatically compiles it into a '.mlmodelc'
    // directory and bundles it with your application.
    //
    // For this example, we assume a model named "SupportTicketClassifier.mlmodel" exists
    // in your app's main bundle.
    guard let modelURL = Bundle.main.url(forResource: "SupportTicketClassifier", withExtension: "mlmodel") else {
        print("❌ Error: 'SupportTicketClassifier.mlmodel' not found in the app bundle.")
        print("   To run this example, you need to:")
        print("   1. Train a text classification model using Apple's Create ML.")
        print("   2. Save the resulting '.mlmodel' file (e.g., named 'SupportTicketClassifier.mlmodel').")
        print("   3. Drag this '.mlmodel' file into your Xcode project's navigator.")
        print("   4. Ensure it's included in your target's 'Build Phases -> Copy Bundle Resources'.")
        return
    }

    // Step 1: Initialize the classifier.
    // This involves loading the model from disk, which can be an I/O intensive operation.
    // It's generally best to do this once, perhaps at app launch or when the feature is first needed.
    guard let classifier = SupportTicketClassifier(modelURL: modelURL) else {
        print("❌ Failed to initialize SupportTicketClassifier. Aborting example.")
        return
    }

    // Step 2: Define sample texts to classify.
    // These represent new, unseen user messages that the model needs to categorize.
    let userMessages = [
        "My bill is incorrect, I was charged twice for last month.", // Expected: Billing
        "The app crashes every time I try to open the settings.",    // Expected: Technical Support
        "It would be great if you could add dark mode to the app.",  // Expected: Feature Request
        "Just wanted to say hello, great app!",                      // Expected: General Inquiry
        "I can't log in, my password isn't working.",                // Expected: Technical Support
        "Where can I find my invoice from October?",                 // Expected: Billing
        "The new update is fantastic!",                              // Expected: General Inquiry
        "I need help with a refund for a recent purchase."           // Expected: Billing
    ]

    // Step 3: Classify each message and display the results.
    print("\n--- Classifying Sample Messages ---")
    for message in userMessages {
        if let category = classifier.classify(text: message) {
            print("Message: \"\(message)\"\n  ➡️ Predicted Category: \(category)\n")
        } else {
            print("Message: \"\(message)\"\n  ⚠️ Prediction failed.\n")
        }
    }

    print("--- Text Classification Example Finished ---")
}

// To run this example in an Xcode Playground or within an application:
// You would typically call this function from an appropriate lifecycle method
// (e.g., `application(_:didFinishLaunchingWithOptions:)` or `onAppear` for a SwiftUI view).
//
// Example call (requires a model to be present):
// Task {
//     await runTextClassificationExample()
// }
