
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import RealityKit
import Foundation

struct LifespanComponent: Component, Codable, Sendable {
    var lastSeenTimestamp: Date
    let initialOpacity: Float
    let decayRate: Float // Percentage of opacity lost per second
}

@available(visionOS 1.0, *)
class TemporalDecaySystem: System {
    private static let query = EntityQuery(where: .has(LifespanComponent.self))

    required init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        let now = Date()
        var entitiesToRemove: [Entity] = []

        context.scene.performQuery(Self.query).forEach { entity in
            guard var lifespan = entity.components[LifespanComponent.self] else { return }
            
            // 1. Update Logic: If recently seen, reset opacity
            let timeSinceLastSeen = now.timeIntervalSince(lifespan.lastSeenTimestamp)
            
            // 2. Decay Logic: Calculate current opacity via LERP
            // Opacity = Initial * (1 - (age * decayRate))
            let age = Float(timeSinceLastSeen)
            let newOpacity = max(0, lifespan.initialOpacity - (age * lifespan.decayRate))
            
            // 3. Apply Visuals
            if var model = entity.components[ModelComponent.self] {
                // Note: In a real app, we'd update the material's opacity
                // This assumes a material that supports opacity/transparency
                model.materials = model.materials.map { mat in
                    var pbr = mat as? PhysicallyBasedMaterial ?? PhysicallyBasedMaterial()
                    pbr.baseColor.tint = .white.withAlphaComponent(CGFloat(newOpacity))
                    return pbr
                }
                entity.components[ModelComponent.self] = model
            }

            // 4. Cleanup: Mark for removal if invisible
            if newOpacity <= 0 {
                entitiesToRemove.append(entity)
            }
        }

        // Batch removal to avoid mutating the query iterator mid-loop
        for entity in entitiesToRemove {
            entity.removeFromParent()
        }
    }
}
