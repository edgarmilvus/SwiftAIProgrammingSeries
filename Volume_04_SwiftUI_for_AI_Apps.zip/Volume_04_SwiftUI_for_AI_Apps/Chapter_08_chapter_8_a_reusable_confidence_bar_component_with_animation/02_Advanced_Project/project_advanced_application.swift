
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// MARK: - Package.swift (Swift Package Manager - SPM)
// For this specific advanced application component, no external third-party Swift Packages are strictly required
// beyond the standard Apple frameworks (SwiftUI, Foundation, etc.) which are implicitly available.
// If we were integrating with a real Core ML model, the 'CoreML' framework would be used,
// but it's a system framework, not an SPM dependency.

/*
// If this component were part of a larger package, its Package.swift might look like this:
// This section is for illustrative purposes to show how SPM dependencies would be declared.
// For the current example, all dependencies are built-in Apple frameworks.

import PackageDescription

let package = Package(
    name: "AIConfidenceKit",
    platforms: [
        .iOS(.v18), // Targeting iOS 18 for Swift 6 features like @Observable
        .macOS(.v15),
        .watchOS(.v11),
        .tvOS(.v18)
    ],
    products: [
        .library(
            name: "AIConfidenceKit",
            targets: ["AIConfidenceKit"]),
    ],
    dependencies: [
        // Example: If we needed a third-party charting library for more complex visualizations
        // .package(url: "https://github.com/example/Charts.git", from: "1.0.0"),
        // Or a networking library for remote AI inference
        // .package(url: "https://github.com/example/Networking.git", from: "2.0.0"),
    ],
    targets: [
        .target(
            name: "AIConfidenceKit",
            dependencies: [
                // If using external packages, list them here:
                // .product(name: "Charts", package: "Charts"),
            ]),
        .testTarget(
            name: "AIConfidenceKitTests",
            dependencies: ["AIConfidenceKit"]),
    ]
)
*/

// MARK: - Advanced Application: AI-Powered Document Classification with Animated Confidence Bars

// This advanced application demonstrates how to integrate the reusable confidence bar component
// into a real-world AI application context: an intelligent document scanner.
// The scanner uses a simulated on-device AI model to classify scanned documents
// (e.g., "Invoice", "Receipt", "Contract"). The application dynamically displays
// the top predicted classifications along with their confidence levels using animated bars.
// This highlights robust error handling, Swift 6 concurrency, and production-quality UI/UX patterns.

import SwiftUI
import Foundation // For UUID, Error, etc.

// Ensure compatibility with iOS 18.0 and later, leveraging new Swift 6 features like @Observable.
@available(iOS 18.0, *)
struct DocumentClassificationResult: Identifiable, Hashable {
    let id = UUID()
    let label: String
    let confidence: Double // 0.0 to 1.0
}

/// A reusable SwiftUI view component that displays a confidence bar with an animated fill.
///
/// This component is designed to visually represent a numerical confidence score (0.0 to 1.0)
/// associated with a given label. The bar animates smoothly when its `confidence` value changes,
/// providing clear visual feedback in AI-driven applications.
@available(iOS 18.0, *)
struct ConfidenceBarView: View {
    let label: String
    let confidence: Double // Expected range: 0.0 to 1.0

    // Internal state to drive the animation.
    // The actual width of the filled part of the bar.
    @State private var currentFillWidth: CGFloat = 0.0

    /// Initializes a `ConfidenceBarView` with a label and a confidence score.
    /// - Parameters:
    ///   - label: The text label describing what the confidence score pertains to (e.g., "Invoice").
    ///   - confidence: A `Double` value between 0.0 and 1.0 representing the confidence level.
    init(label: String, confidence: Double) {
        self.label = label
        // Clamp confidence to ensure it stays within 0.0 and 1.0
        self.confidence = max(0.0, min(1.0, confidence))
    }

    var body: some View {
        HStack {
            Text(label)
                .font(.caption)
                .frame(width: 80, alignment: .leading) // Fixed width for labels
                .accessibilityLabel("Classification: \(label)")

            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    // Background of the bar
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.gray.opacity(0.3))
                        .frame(height: 10)
                        .accessibilityHidden(true) // The fill will provide the main info

                    // Animated fill based on confidence
                    RoundedRectangle(cornerRadius: 5)
                        .fill(fillColor(for: confidence))
                        .frame(width: currentFillWidth, height: 10)
                        .animation(.easeInOut(duration: 0.6), value: currentFillWidth) // Smooth animation for width changes
                        .accessibilityValue("Confidence: \(Int(confidence * 100)) percent")
                }
                .onAppear {
                    // Set initial width on appear, triggering animation if confidence is not 0
                    currentFillWidth = geometry.size.width * confidence
                }
                .onChange(of: confidence) { newConfidence in
                    // Animate width change whenever confidence updates
                    currentFillWidth = geometry.size.width * newConfidence
                }
            }
            .frame(height: 10) // Fixed height for the bar itself
            .padding(.horizontal, 4)

            Text("\(Int(confidence * 100))%")
                .font(.caption2)
                .frame(width: 40, alignment: .trailing)
                .accessibilityHidden(true) // Redundant with accessibilityValue on the bar
        }
        .padding(.vertical, 2)
    }

    /// Determines the color of the confidence bar based on the confidence level.
    /// - Parameter confidence: The confidence score (0.0 to 1.0).
    /// - Returns: A `Color` representing the confidence level.
    private func fillColor(for confidence: Double) -> Color {
        if confidence > 0.85 {
            return .green // High confidence
        } else if confidence > 0.6 {
            return .orange // Medium confidence
        } else {
            return .red // Low confidence
        }
    }
}

/// Custom error types for the document scanner.
@available(iOS 18.0, *)
enum DocumentScannerError: Error, LocalizedError {
    case modelPredictionFailed(reason: String)
    case invalidModelOutput
    case noConfidentPredictions

    var errorDescription: String? {
        switch self {
        case .modelPredictionFailed(let reason):
            return "AI model prediction failed: \(reason)"
        case .invalidModelOutput:
            return "The AI model returned an invalid output format."
        case .noConfidentPredictions:
            return "The AI could not confidently classify the document based on the current thresholds."
        }
    }
}

/// A view model responsible for managing document scanning, AI classification,
/// and publishing the top confidence results to the UI.
///
/// This `@Observable` class leverages Swift 6's new observation framework
/// to automatically notify SwiftUI views of changes to its published properties.
@available(iOS 18.0, *)
@Observable
final class DocumentScannerViewModel {
    /// The list of top document classifications with their confidence scores.
    var topClassifications: [DocumentClassificationResult] = []
    /// An optional error message to display to the user.
    var errorMessage: String?
    /// Indicates if a scan operation is currently in progress.
    var isScanning: Bool = false

    // Configuration for the number of top predictions to display.
    private let numberOfTopPredictions = 3
    // Minimum confidence threshold to consider a prediction valid.
    private let minimumConfidenceThreshold: Double = 0.15

    /// Simulates an AI model inference process and updates the classification results.
    ///
    /// This method mimics an asynchronous operation, such as calling a Core ML model
    /// or a remote AI service. It uses `Task` for Swift concurrency and `await Task.sleep`
    /// to simulate processing time.
    ///
    /// - Parameter documentImage: A placeholder for the actual document image data.
    ///   In a real app, this would be `UIImage` or `CVPixelBuffer`.
    func performAIMLClassification(for documentImage: Data?) async {
        // Ensure UI state updates happen on the main actor immediately.
        await MainActor.run {
            self.isScanning = true
            self.errorMessage = nil
            self.topClassifications = [] // Clear previous results to show loading state
        }

        do {
            // Simulate AI model processing time using a random delay.
            try await Task.sleep(for: .seconds(Double.random(in: 1.0...2.5)))

            // Simulate potential model failure or invalid output with a 5% chance.
            if Bool.random(probability: 0.05) {
                throw DocumentScannerError.modelPredictionFailed(reason: "Internal model error encountered.")
            }

            // Simulate AI model output: a dictionary of classification labels and their confidences.
            let simulatedPredictions = generateSimulatedPredictions()

            // Process the raw model output to filter, sort, and select top predictions.
            try await processNewPrediction(predictions: simulatedPredictions)

        } catch let error as DocumentScannerError {
            // Catch specific DocumentScannerErrors and update UI with localized description.
            await MainActor.run {
                self.errorMessage = error.localizedDescription
                self.topClassifications = [] // Clear any partial results on error
            }
        } catch {
            // Catch any other unexpected errors.
            await MainActor.run {
                self.errorMessage = "An unexpected error occurred during classification: \(error.localizedDescription)"
                self.topClassifications = []
            }
        }

        // Ensure `isScanning` is set to false on the main actor once the process completes or fails.
        await MainActor.run {
            self.isScanning = false
        }
    }

    /// Processes a dictionary of raw AI predictions, sorts them, filters by confidence,
    /// and updates `topClassifications`.
    ///
    /// - Parameter predictions: A dictionary where keys are classification labels (String)
    ///   and values are their confidence scores (Double).
    /// - Throws: `DocumentScannerError.invalidModelOutput` if predictions are malformed,
    ///   or `DocumentScannerError.noConfidentPredictions` if no predictions meet the threshold.
    private func processNewPrediction(predictions: [String: Double]) async throws {
        guard !predictions.isEmpty else {
            throw DocumentScannerError.invalidModelOutput
        }

        let sortedResults = predictions
            .map { (label, confidence) in
                DocumentClassificationResult(label: label, confidence: confidence)
            }
            .filter { $0.confidence >= minimumConfidenceThreshold } // Filter out very low confidence scores
            .sorted { $0.confidence > $1.confidence } // Sort by highest confidence first

        guard !sortedResults.isEmpty else {
            throw DocumentScannerError.noConfidentPredictions // No predictions met the confidence threshold
        }

        // Update UI-bound state on the main actor.
        await MainActor.run {
            self.topClassifications = Array(sortedResults.prefix(numberOfTopPredictions)) // Take only the top N
            self.errorMessage = nil // Clear any previous errors on successful update
        }
    }

    /// Generates a set of simulated AI predictions for demonstration purposes.
    ///
    /// In a real application, this data would come directly from a Core ML model's
    /// output or a server-side AI API response.
    /// - Returns: A dictionary of document labels to confidence scores.
    private func generateSimulatedPredictions() -> [String: Double] {
        let documentTypes = ["Invoice", "Receipt", "Contract", "ID Card", "Passport", "Letter", "Form", "Statement"]
        var predictions: [String: Double] = [:]

        // Simulate a dominant prediction and some lower ones
        let dominantType = documentTypes.randomElement()!
        predictions[dominantType] = Double.random(in: 0.6...0.99)

        // Add 2-4 more random predictions with lower confidences, ensuring they are distinct
        let otherTypes = documentTypes.filter { $0 != dominantType }.shuffled().prefix(Int.random(in: 2...4))
        for type in otherTypes {
            // Ensure other predictions are lower than the dominant one but still potentially above threshold
            predictions[type] = Double.random(in: 0.05...max(0.1, predictions[dominantType]! - 0.1))
        }

        // Occasionally simulate a very uncertain scenario where no single prediction is high.
        if Bool.random(probability: 0.1) { // 10% chance of an uncertain outcome
            return [
                "Unknown Document": Double.random(in: 0.1...0.3),
                "Miscellaneous": Double.random(in: 0.05...0.25),
                "Unclassified": Double.random(in: 0.01...0.15)
            ]
        }

        return predictions
    }
}

// MARK: - Helper Extension for Bool.random(probability:)
extension Bool {
    /// Generates a random boolean value with a specified probability of being true.
    /// - Parameter probability: The likelihood (0.0 to 1.0) that the result will be `true`.
    /// - Returns: `true` with the given probability, `false` otherwise.
    static func random(probability: Double) -> Bool {
        return Double.random(in: 0...1) < probability
    }
}

/// The main SwiftUI view for the AI-powered document classification feature.
///
/// This view orchestrates the display of classification results using `ConfidenceBarView`s,
/// manages the scanning process via `DocumentScannerViewModel`, and provides
/// user interaction elements like a "Scan Document" button.
@available(iOS 18.0, *)
struct DocumentClassificationView: View {
    /// The view model responsible for handling the AI classification logic.
    @State private var viewModel = DocumentScannerViewModel()

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("AI Document Classifier")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.bottom, 10)

                // Conditional UI based on ViewModel state
                if viewModel.isScanning {
                    ProgressView("Analyzing Document...")
                        .progressViewStyle(.circular)
                        .padding()
                        .accessibilityLabel("Document analysis in progress")
                } else if let error = viewModel.errorMessage {
                    VStack {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.largeTitle)
                            .foregroundColor(.red)
                            .padding(.bottom, 5)
                        Text("Error: \(error)")
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color.red.opacity(0.1)))
                    .accessibilityLiveRegion(.assertive) // Announce error immediately for accessibility
                } else if viewModel.topClassifications.isEmpty {
                    VStack {
                        Image(systemName: "doc.text.magnifyingglass")
                            .font(.largeTitle)
                            .foregroundColor(.gray)
                            .padding(.bottom, 5)
                        Text("No classifications yet. Tap 'Scan' to begin.")
                            .foregroundColor(.gray)
                    }
                    .padding()
                } else {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Top Classifications:")
                            .font(.headline)
                            .padding(.leading)

                        // Display ConfidenceBarView for each top classification result
                        ForEach(viewModel.topClassifications) { classification in
                            ConfidenceBarView(label: classification.label, confidence: classification.confidence)
                        }
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 15)
                            .fill(Color.white)
                            .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 2)
                    )
                    .transition(.opacity.animation(.easeInOut(duration: 0.5))) // Smooth transition for results block
                }

                Spacer()

                Button {
                    // Trigger the AI classification process asynchronously within a Task.
                    Task {
                        await viewModel.performAIMLClassification(for: nil) // `nil` for simulated image data
                    }
                } label: {
                    Label("Scan Document", systemImage: "camera.fill")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(viewModel.isScanning ? Color.gray : Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                }
                .disabled(viewModel.isScanning) // Disable button while a scan is in progress
                .padding(.horizontal)
                .padding(.bottom)
            }
            .navigationTitle("DocuScan AI")
            .navigationBarHidden(true) // Hide default navigation bar for custom title
            .background(Color.init(uiColor: .systemGroupedBackground).ignoresSafeArea()) // System background color
            .onAppear {
                // Optionally start an initial scan on app launch for immediate feedback
                // Task {
                //     await viewModel.performAIMLClassification(for: nil)
                // }
            }
        }
    }
}

// MARK: - App Entry Point (for Xcode Previews and actual app)
@available(iOS 18.0, *)
struct DocumentScannerApp: App {
    var body: some Scene {
        WindowGroup {
            DocumentClassificationView()
        }
    }
}

// MARK: - Preview Provider
@available(iOS 18.0, *)
#Preview {
    DocumentClassificationView()
}
