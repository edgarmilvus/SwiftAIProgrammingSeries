
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Vision
import CoreImage // For CIImage input

@available(iOS 18.0, *) // Vision's async APIs are generally available from iOS 15+, but using 18.0 for forward compatibility
class VisionProcessor {
    private let imageRequestHandler = VNImageRequestHandler(ciImage: CIImage(), options: [:]) // Placeholder

    func processImage(ciImage: CIImage) async throws -> [VNObservation] {
        // Update the handler with the new image source
        let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])

        // Define the requests
        let faceDetectionRequest = VNDetectFaceRectanglesRequest()
        let bodyPoseRequest = VNDetectHumanBodyPoseRequest()

        do {
            // Perform the requests asynchronously
            try await handler.perform([faceDetectionRequest, bodyPoseRequest])

            // Collect results from all requests
            var allObservations: [VNObservation] = []
            if let faceObservations = faceDetectionRequest.results {
                allObservations.append(contentsOf: faceObservations)
            }
            if let bodyPoseObservations = bodyPoseRequest.results {
                allObservations.append(contentsOf: bodyPoseObservations)
            }
            return allObservations

        } catch {
            print("Vision request failed with error: \(error)")
            throw error
        }
    }

    // Example usage in an async context
    func analyzeLiveStreamFrame(frameImage: CIImage) {
        Task {
            do {
                let observations = try await processImage(ciImage: frameImage)
                // Process observations on a background thread, then dispatch UI updates to main actor
                await MainActor.run {
                    // Update SwiftUI views or UIKit elements with observations
                    print("Detected \(observations.count) observations.")
                }
            } catch {
                await MainActor.run {
                    print("Error analyzing frame: \(error)")
                }
            }
        }
    }
}
