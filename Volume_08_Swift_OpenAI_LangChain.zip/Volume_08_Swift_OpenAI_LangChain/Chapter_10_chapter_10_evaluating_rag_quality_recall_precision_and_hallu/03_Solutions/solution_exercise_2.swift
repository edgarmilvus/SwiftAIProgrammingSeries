
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct FaithfulnessResult: Codable, Sendable {
    let isFaithful: Bool
    let reasoning: String
    let confidenceScore: Double
}

@available(iOS 18.0, macOS 15.0, *)
actor FaithfulnessService {
    let apiKey: String
    let endpoint: URL

    init(apiKey: String, endpoint: URL) {
        self.apiKey = apiKey
        self.endpoint = endpoint
    }

    func checkFaithfulness(context: String, answer: String) async throws -> FaithfulnessResult {
        // 1. Construct a strict system prompt
        let systemPrompt = """
        You are a professional fact-checker. Your task is to determine if a given 'Answer' is fully supported by the 'Context' provided. 
        An answer is UNFAITHFUL if it contains information not present in the context or contradicts the context.
        You must respond ONLY in valid JSON format with the following keys:
        "isFaithful" (boolean), "reasoning" (string), "confidenceScore" (double 0.0-1.0).
        """
        
        let userPrompt = "Context: \(context)\n\nAnswer: \(answer)"
        
        // 2. Prepare the request payload (OpenAI-compatible format)
        let payload: [String: Any] = [
            "model": "gpt-4o",
            "messages": [
                ["role": "system", "content": systemPrompt],
                ["role": "user", "content": userPrompt]
            ],
            "response_format": ["type": "json_object"]
        ]
        
        let jsonData = try JSONSerialization.data(withJSONObject: payload)
        
        // 3. Perform the network request
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }
        
        // 4. Parse the response
        // Note: The LLM returns a JSON object containing the 'message' object
        let decoder = JSONDecoder()
        let wrapper = try decoder.decode(LLMResponseWrapper.self, from: data)
        
        guard let contentData = wrapper.choices.first?.message.content.data(using: .utf8) else {
            throw DecodingError.dataCorrupted(.init(codingPath: [], debugDescription: "No content in LLM response"))
        }
        
        return try decoder.decode(FaithfulnessResult.self, from: contentData)
    }
}

// Internal helper for parsing the LLM provider's response structure
private struct LLMResponseWrapper: Codable {
    struct Choice: Codable {
        struct Message: Codable {
            let content: String
        }
        let message: Message
    }
    let choices: [Choice]
}
