
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

// MARK: - 3. Document Processor Class

/// A class responsible for processing documents using a local LLM service.
/// It handles text extraction (simulated) and delegates LLM-specific tasks.
@available(iOS 18.0, macOS 15.0, *)
class DocumentProcessor {
    private let llmService: LocalLLMService
    private let defaultLLMModel: String

    /// Initializes the document processor with a concrete LLM service and a default model.
    /// - Parameters:
    ///   - llmService: An instance conforming to `LocalLLMService` (e.g., `MockLLMService`, `LlamaCppLLMService`).
    ///   - defaultLLMModel: The name of the LLM model to use for operations (e.g., "llama3", "mistral").
    init(llmService: LocalLLMService, defaultLLMModel: String = "llama3-8b-instruct") {
        self.llmService = llmService
        self.defaultLLMModel = defaultLLMModel
    }

    /// Simulates text extraction from a document URL.
    /// In a real app, this would use Apple's Vision framework (e.g., `VNRecognizeTextRequest`)
    /// or PDFKit to get text content from an image or PDF file.
    /// - Parameter documentURL: The URL of the document (e.g., a local file path).
    /// - Returns: The extracted plain text content.
    /// - Throws: `DocumentProcessingError.textExtractionFailed` if extraction fails.
    func extractText(from documentURL: URL) async throws -> String {
        // Simulate reading content from a file.
        // In a real app:
        // 1. Use Vision framework for image-based documents:
        //    let request = VNRecognizeTextRequest()
        //    let handler = VNImageRequestHandler(url: documentURL)
        //    try handler.perform([request])
        //    return request.results.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
        // 2. Use PDFKit for PDF documents:
        //    if let pdfDocument = PDFDocument(url: documentURL) {
        //        return pdfDocument.string ?? ""
        //    }
        // For this example, we'll just return a dummy string.
        try await Task.sleep(for: .milliseconds(300)) // Simulate I/O
        guard !Task.isCancelled else { throw DocumentProcessingError.operationCancelled }

        if documentURL.lastPathComponent.contains("sensitive") {
            return """
            This is a highly sensitive document regarding John Doe, born on 1980-05-15,
            residing at 123 Main St, Anytown, CA 90210. His email is john.doe@example.com.
            His Social Security Number is SSN: 123-45-6789.
            The project code is ALPHA-XYZ-789. Client meeting scheduled for 2024-10-26.
            Please ensure all PII is redacted before sharing.
            """
        } else if documentURL.lastPathComponent.contains("report") {
            return """
            Annual Project Report Q3 2024:
            The third quarter saw significant progress in project X, achieving 85% completion
            of phase 2 milestones. Key challenges included resource allocation and unexpected
            supply chain delays, impacting delivery by approximately 10 days.
            Team performance was exemplary, with a 15% increase in productivity compared to Q2.
            Next steps involve finalizing phase 2 and initiating phase 3 planning by end of October.
            """
        } else {
            return "This is a generic document content from \(documentURL.lastPathComponent)."
        }
    }

    /// Summarizes a given document using the local LLM.
    /// - Parameter document: The document to summarize.
    /// - Returns: A `ProcessedDocument` containing the summary.
    /// - Throws: `DocumentProcessingError` if the document is invalid or LLM fails.
    func summarizeDocument(document: Document) async throws -> ProcessedDocument {
        guard !document.rawContent.isEmpty else {
            throw DocumentProcessingError.invalidDocumentContent
        }

        do {
            let summary = try await llmService.summarize(text: document.rawContent, model: defaultLLMModel)
            return ProcessedDocument(
                originalDocumentID: document.id,
                processedContent: summary,
                operationType: "Summary"
            )
        } catch let llmError as DocumentProcessingError {
            throw llmError // Re-throw specific LLM errors
        } catch {
            throw DocumentProcessingError.llmServiceError(reason: "Unknown error during summarization: \(error.localizedDescription)")
        }
    }

    /// Redacts sensitive information from a given document using the local LLM.
    /// - Parameters:
    ///   - document: The document to redact.
    ///   - redactionInstructions: A string providing context or specific patterns for redaction.
    /// - Returns: A `ProcessedDocument` containing the redacted content.
    /// - Throws: `DocumentProcessingError` if the document is invalid or LLM fails.
    func redactDocument(document: Document, redactionInstructions: String) async throws -> ProcessedDocument {
        guard !document.rawContent.isEmpty else {
            throw DocumentProcessingError.invalidDocumentContent
        }

        do {
            let redactedContent = try await llmService.redact(
                text: document.rawContent,
                redactionInstructions: redactionInstructions,
                model: defaultLLMModel
            )
            return ProcessedDocument(
                originalDocumentID: document.id,
                processedContent: redactedContent,
                operationType: "Redaction"
            )
        } catch let llmError as DocumentProcessingError {
            throw llmError
        } catch {
            throw DocumentProcessingError.llmServiceError(reason: "Unknown error during redaction: \(error.localizedDescription)")
        }
    }
}
