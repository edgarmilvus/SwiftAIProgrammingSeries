
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// Protocol defining the requirements for a hybrid scoring mechanism.
protocol HybridScoring: Sendable {
    func calculateScore(keywordScore: Double, semanticScore: Double) async -> Double
}

/// An actor that manages the weighted fusion of two different scoring signals.
/// Using an actor ensures that updates to the 'alpha' parameter are thread-safe.
actor HybridScoringEngine: HybridScoring {
    
    /// The weighting factor (alpha). 
    /// 1.0 = Purely Semantic, 0.0 = Purely Keyword.
    private(set) var alpha: Double
    
    enum ScoringError: Error {
        case invalidAlpha
        case invalidInputScore
    }
    
    init(alpha: Double = 0.5) {
        // Clamp alpha between 0 and 1 during initialization
        self.alpha = max(0.0, min(1.0, alpha))
    }
    
    /// Dynamically updates the search sensitivity.
    /// This is thread-safe because it's an actor method.
    func updateAlpha(_ newAlpha: Double) {
        self.alpha = max(0.0, min(1.0, newAlpha))
    }
    
    /// Calculates the hybrid score using the formula:
    /// Score_hybrid = (alpha * Score_semantic) + ((1 - alpha) * Score_keyword)
    func calculateScore(keywordScore: Double, semanticScore: Double) async -> Double {
        // Input Validation: Ensure scores are within reasonable mathematical bounds
        // Even if BM25 is unbounded, we treat negative values as 0 for this engine.
        let kScore = max(0.0, keywordScore)
        let sScore = max(0.0, semanticScore)
        
        let hybridScore = (alpha * sScore) + ((1.0 - alpha) * kScore)
        return hybridScore
    }
}

// MARK: - Example Usage
@main
struct AtomNotesApp {
    static func main() async {
        let engine = HybridScoringEngine(alpha: 0.7) // Semantic-heavy
        
        let keywordResult = 15.5  // High BM25 score
        let semanticResult = 0.85 // High cosine similarity
        
        let score = await engine.calculateScore(keywordScore: keywordResult, semanticScore: semanticResult)
        print("Initial Hybrid Score (Alpha 0.7): \(score)")
        
        // User adjusts slider to Keyword-heavy
        await engine.updateAlpha(0.1)
        let newScore = await engine.calculateScore(keywordScore: keywordResult, semanticScore: semanticResult)
        print("Updated Hybrid Score (Alpha 0.1): \(newScore)")
    }
}
