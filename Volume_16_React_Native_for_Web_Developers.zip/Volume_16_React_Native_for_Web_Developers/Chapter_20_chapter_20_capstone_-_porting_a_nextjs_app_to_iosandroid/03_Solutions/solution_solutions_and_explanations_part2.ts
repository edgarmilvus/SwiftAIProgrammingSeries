/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// navigation/types.ts
import type { NavigatorScreenParams } from '@react-navigation/native';

// Define parameters for individual screens
export type DashboardParams = { userId?: string };
export type SettingsParams = { screen?: string };

// Define the root parameter list for the entire app
export type RootParamList = {
  '(app)/dashboard': DashboardParams;
  '(app)/settings/profile': SettingsParams;
  // Add other routes as needed
};

// navigation/LinkingConfig.ts
import * as Linking from 'expo-linking';
import { LinkingOptions } from '@react-navigation/native';
import { RootParamList } from './types';

const prefix = Linking.createURL('/');

export const LinkingConfiguration: LinkingOptions<RootParamList> = {
  prefixes: [prefix, 'myapp://'],
  config: {
    screens: {
      '(app)': {
        screens: {
          dashboard: 'dashboard', // Maps myapp://dashboard
          settings: {
            screens: {
              profile: 'settings/profile', // Maps myapp://settings/profile
            },
          },
        },
      },
    },
  },
};

// hooks/useUniversalRouter.ts
import { useNavigation, ParamListBase } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootParamList } from '../navigation/types';

// Helper to parse Next.js style paths (e.g., /dashboard/123)
const parsePath = (path: string) => {
  // Remove leading slash if present
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;
  const parts = cleanPath.split('/');
  
  // Simple mapping logic for the exercise
  if (parts[0] === 'dashboard') {
    return {
      pathname: '(app)/dashboard/[id]',
      params: { id: parts[1] || undefined },
    };
  }
  
  if (parts[0] === 'settings' && parts[1] === 'profile') {
    return {
      pathname: '(app)/settings/profile',
      params: {},
    };
  }

  return { pathname: '(app)/dashboard', params: {} };
};

export function useUniversalRouter() {
  const navigation = useNavigation<NativeStackNavigationProp<RootParamList>>();

  const navigate = (path: string) => {
    const route = parsePath(path);
    // @ts-ignore: Simplified for exercise, in real app verify types strictly
    navigation.navigate(route.pathname, route.params);
  };

  return { navigate };
}
