/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// File: components/UserGreeting.tsx
// A universal React component for displaying a user greeting in a SaaS dashboard.
// This component is designed to work in both Expo (React Native) and Next.js (Web).

import React, { useState, useEffect } from 'react';

// Define the User type for TypeScript type safety.
// This ensures we don't accidentally assign non-string values to the name.
type User = {
  id: string;
  name: string;
  email: string;
};

/**
 * UserGreeting Component
 * 
 * Renders a greeting message for the logged-in user.
 * 
 * Props:
 * - userId: The ID of the user to fetch data for (simulated).
 * 
 * State:
 * - user: The current user object.
 * - error: Any error message from data fetching.
 * 
 * @param {Object} props - Component props.
 * @param {string} props.userId - The user ID.
 */
const UserGreeting: React.FC<{ userId: string }> = ({ userId }) => {
  // State to hold the user data. Initialized to null.
  const [user, setUser] = useState<User | null>(null);
  
  // State to hold any error messages.
  const [error, setError] = useState<string | null>(null);

  // Effect to simulate fetching user data on component mount.
  useEffect(() => {
    // Simulate an asynchronous API call to a SaaS backend.
    const fetchUser = async () => {
      try {
        // In a real app, this would be: await fetch(`/api/users/${userId}`)
        // We simulate a delay to mimic network latency.
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Mock user data response.
        const mockUser: User = {
          id: userId,
          name: "Alex Developer",
          email: "alex@example.com"
        };
        
        // Update state with the fetched user.
        setUser(mockUser);
        setError(null);
      } catch (err) {
        setError("Failed to load user data.");
      }
    };

    fetchUser();
  }, [userId]); // Re-run effect if userId changes.

  // BUG: This is an intentionally incorrect state update.
  // It mutates the existing user object directly, which React may not detect.
  // This is a common pitfall in JavaScript when dealing with objects in state.
  const updateName = () => {
    if (user) {
      // ❌ WRONG: Direct mutation. React's state updates rely on immutability.
      // This will not trigger a re-render in many cases, especially with
      // React's state batching or strict mode.
      user.name = "Alex (Updated)";
      setUser(user); // This sets the same reference, no change detected.
    }
  };

  // Conditional rendering based on state.
  if (error) {
    return <div style={{ color: 'red' }}>Error: {error}</div>; // Web-style inline styles for simplicity.
  }

  if (!user) {
    return <div>Loading user...</div>; // Loading state.
  }

  // Render the greeting. Note: In a real universal app, you'd use a UI library like Tamagui or NativeWind.
  // For this example, we use simple divs/text that work in both contexts.
  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
      <h1>Hello, {user.name}!</h1>
      <p>Email: {user.email}</p>
      
      {/* Button to trigger the buggy update */}
      <button onClick={updateName} style={{ marginTop: '10px', padding: '8px 16px' }}>
        Update Name (Buggy)
      </button>
      
      {/* For React Native, this would be a <Button> or <TouchableOpacity> */}
    </div>
  );
};

export default UserGreeting;
