/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// todoStore.ts
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

// 1. Types
interface Todo {
  id: string;
  text: string;
  completed: boolean;
}

type Filter = 'all' | 'active' | 'completed';

interface TodoState {
  todos: Todo[];
  filter: Filter;
}

interface TodoActions {
  addTodo: (text: string) => void;
  toggleTodo: (id: string) => void;
  deleteTodo: (id: string) => void;
  editTodo: (id: string, newText: string) => void;
  setFilter: (filter: Filter) => void;
  toggleAllCompleted: () => void;
}

// 2. Store Creation
export const useTodoStore = create<TodoState & TodoActions>()(
  persist(
    (set, get) => ({
      todos: [],
      filter: 'all',

      addTodo: (text) =>
        set((state) => ({
          todos: [
            ...state.todos,
            { id: Date.now().toString(), text, completed: false },
          ],
        })),

      toggleTodo: (id) =>
        set((state) => ({
          todos: state.todos.map((todo) =>
            todo.id === id ? { ...todo, completed: !todo.completed } : todo
          ),
        })),

      deleteTodo: (id) =>
        set((state) => ({
          todos: state.todos.filter((todo) => todo.id !== id),
        })),

      editTodo: (id, newText) =>
        set((state) => ({
          todos: state.todos.map((todo) =>
            todo.id === id ? { ...todo, text: newText } : todo
          ),
        })),

      setFilter: (filter) => set({ filter }),

      toggleAllCompleted: () => {
        const { todos } = get();
        const allCompleted = todos.every((todo) => todo.completed);
        
        set({
          todos: todos.map((todo) => ({
            ...todo,
            completed: !allCompleted, // If all are true, set false; otherwise set true
          })),
        });
      },
    }),
    {
      name: '@universal-todos',
      storage: createJSONStorage(() => (typeof window !== 'undefined' ? localStorage : AsyncStorage)),
    }
  )
);

// 3. Selector for Derived State (Memoized)
export const useFilteredTodos = () => {
  const { todos, filter } = useTodoStore();
  
  return todos.filter((todo) => {
    if (filter === 'active') return !todo.completed;
    if (filter === 'completed') return todo.completed;
    return true; // 'all'
  });
};

// --- UI COMPONENTS (Example Implementation) ---

// TodoInput.tsx
import React, { useState } from 'react';
import { View, TextInput, Button } from 'react-native';
import { useTodoStore } from './todoStore';

export const TodoInput = () => {
  const [text, setText] = useState('');
  const addTodo = useTodoStore((state) => state.addTodo);

  const handleAdd = () => {
    if (text.trim()) {
      addTodo(text);
      setText('');
    }
  };

  return (
    <View className="flex-row gap-2 mb-4">
      <TextInput
        value={text}
        onChangeText={setText}
        placeholder="Add a todo..."
        className="flex-1 border border-gray-300 rounded px-3 bg-white"
      />
      <Button title="Add" onPress={handleAdd} />
    </View>
  );
};

// TodoList.tsx
import React from 'react';
import { View, Text, Pressable, ScrollView } from 'react-native';
import { useFilteredTodos, useTodoStore } from './todoStore';

export const TodoList = () => {
  const todos = useFilteredTodos();
  const toggleTodo = useTodoStore((state) => state.toggleTodo);
  const deleteTodo = useTodoStore((state) => state.deleteTodo);

  return (
    <ScrollView className="flex-1">
      {todos.map((todo) => (
        <View
          key={todo.id}
          className="flex-row items-center p-3 mb-2 bg-white rounded-lg shadow-sm border border-gray-100"
        >
          <Pressable
            onPress={() => toggleTodo(todo.id)}
            className={`w-6 h-6 rounded border mr-3 flex items-center justify-center ${
              todo.completed ? 'bg-green-500 border-green-500' : 'border-gray-300'
            }`}
          >
            {todo.completed && <Text className="text-white text-xs">✓</Text>}
          </Pressable>
          
          <Text
            className={`flex-1 text-lg ${todo.completed ? 'line-through text-gray-400' : 'text-gray-800'}`}
          >
            {todo.text}
          </Text>

          <Pressable onPress={() => deleteTodo(todo.id)} className="px-3 py-1 bg-red-100 rounded">
            <Text className="text-red-600 text-xs">Delete</Text>
          </Pressable>
        </View>
      ))}
    </ScrollView>
  );
};

// FilterControls.tsx
import React from 'react';
import { View, Pressable, Text } from 'react-native';
import { useTodoStore } from './todoStore';

export const FilterControls = () => {
  const { filter, setFilter } = useTodoStore();
  const filters: Filter[] = ['all', 'active', 'completed'];

  return (
    <View className="flex-row justify-center gap-2 mb-4">
      {filters.map((f) => (
        <Pressable
          key={f}
          onPress={() => setFilter(f)}
          className={`px-4 py-2 rounded-full border ${
            filter === f
              ? 'bg-blue-500 border-blue-500 text-white'
              : 'bg-white border-gray-300 text-gray-600'
          }`}
        >
          <Text className="capitalize font-medium">{f}</Text>
        </Pressable>
      ))}
    </View>
  );
};

// BulkAction.tsx
import React from 'react';
import { Pressable, Text } from 'react-native';
import { useTodoStore } from './todoStore';

export const BulkAction = () => {
  const { todos, toggleAllCompleted } = useTodoStore();
  
  // Determine button text based on current state
  const allCompleted = todos.length > 0 && todos.every(t => t.completed);
  const buttonText = allCompleted ? 'Mark All Incomplete' : 'Mark All Complete';

  return (
    <Pressable 
      onPress={toggleAllCompleted} 
      disabled={todos.length === 0}
      className="bg-purple-100 py-3 rounded-lg items-center mt-4 active:bg-purple-200 disabled:opacity-50"
    >
      <Text className="text-purple-700 font-bold">{buttonText}</Text>
    </Pressable>
  );
};
