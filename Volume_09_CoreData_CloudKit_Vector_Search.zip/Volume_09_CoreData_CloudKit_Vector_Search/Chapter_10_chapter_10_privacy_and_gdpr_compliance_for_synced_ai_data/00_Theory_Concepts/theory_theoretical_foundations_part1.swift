
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreData
import Observation

/// Represents the strict privacy levels for data within the AI system.
enum PrivacyLevel: Sendable {
    case publicInfo      // Non-sensitive metadata
    case pseudonymized   // Vectors and mathematical representations
    case highlySensitive // Raw text, names, PII
}

/// A Sendable container that ensures PII is never accidentally leaked 
/// during the synchronization process.
struct PrivacySafeEmbedding: Sendable {
    let id: UUID
    let vector: [Float]
    let timestamp: Date
    // Note: No raw text or user names are included here.
}

/// The PrivacyCoordinator acts as the "Gatekeeper" (The SwiftUI View Analogy).
/// It is an Actor, ensuring that all access to sensitive data is isolated
/// and strictly controlled via asynchronous boundaries.
@available(iOS 18.0, *)
actor PrivacyCoordinator {
    
    private var localStore: NSManagedObjectContext
    
    init(context: NSManagedObjectContext) {
        self.localStore = context
    }
    
    /// Processes raw input into a privacy-safe embedding.
    /// This follows the "Data Minimization" principle by stripping PII 
    /// immediately after the vector is generated.
    func processAndSecure(text: String, metadata: [String: String]) async throws -> PrivacySafeEmbedding {
        // 1. Perform On-Device Embedding Generation (Simulated)
        // In a real app, this would call a Core ML model.
        let generatedVector = try await generateVector(for: text)
        
        // 2. Create the Privacy-Safe DTO
        let safeEmbedding = PrivacySafeEmbedding(
            id: UUID(),
            vector: generatedVector,
            timestamp: Date()
        )
        
        // 3. Persist the raw text locally in Core Data (Encrypted)
        try await saveRawTextLocally(text: text, id: safeEmbedding.id)
        
        // 4. Return only the 'pseudonymized' version for CloudKit sync
        return safeEmbedding
    }
    
    private func generateVector(for text: String) async throws -> [Float] {
        // Simulate heavy ML inference
        try await Task.sleep(for: .milliseconds(100))
        return (0..<1536).map { _ in Float.random(in: -1...1) }
    }
    
    private func saveRawTextLocally(text: String, id: UUID) async throws {
        // Implementation of Core Data persistence with local-only encryption
        // This ensures the 'Right to Erasure' is manageable within the local sandbox.
    }
}

/// An Observable model for the UI that respects the Privacy Boundary.
@Observable
@available(iOS 18.0, *)
final class AIContextViewModel {
    var isSyncing: Bool = false
    var lastSyncTimestamp: Date?
    
    // We do NOT store the raw text or the full vector here to prevent 
    // accidental leakage into the View hierarchy.
    private(set) var summaryStatus: String = "Ready"
    
    private let coordinator: PrivacyCoordinator
    
    init(coordinator: PrivacyCoordinator) {
        self.coordinator = coordinator
    }
    
    func handleUserEntry(text: String) async {
        isSyncing = true
        summaryStatus = "Processing..."
        
        do {
            // The UI only interacts with the 'Safe' version of the data.
            let _ = try await coordinator.processAndSecure(text: text, metadata: [:])
            summaryStatus = "Secured and Synced."
            lastSyncTimestamp = Date()
        } catch {
            summaryStatus = "Error: \(error.localizedDescription)"
        }
        
        isSyncing = false
    }
}
