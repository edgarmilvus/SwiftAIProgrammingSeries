
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import NaturalLanguage

@available(iOS 18.0, *)
func demonstrateEmbeddingWithTokenization() async {
    let text = "The quick brown fox jumps over the lazy dog."
    let tagger = NLTagger(tagSchemes: [.tokenType])
    tagger.string = text

    let embedding = NLEmbedding.wordEmbedding(for: .english)

    tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .tokenType, options: []) { tag, tokenRange in
        let word = String(text[tokenRange])
        Task {
            if let vector = await embedding?.vector(for: word) {
                print("Word: '\(word)' -> Vector (first 3): \(vector.prefix(3))...")
            } else {
                print("Word: '\(word)' -> No embedding found.")
            }
        }
        return true
    }
}

@available(iOS 18.0, *)
@main
struct EmbeddingWithTaggerApp {
    static func main() async {
        await demonstrateEmbeddingWithTokenization()
    }
}
