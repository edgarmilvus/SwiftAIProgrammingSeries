
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import RealityKit
import Metal
import CoreML

// 1. Metal Shader Logic (Conceptual Fragment Shader)
/*
#include <metal_stdlib>
using namespace metal;

[[visible]]
void segmentationOcclusionShader(params) {
    float4 color = params.color();
    // Sample the segmentation texture (the mask)
    float maskValue = segmentationTexture.sample(s, params.uv).r;
    
    // If maskValue > 0.5, it means a person is here. 
    // Discard the fragment to create an occlusion hole.
    if (maskValue > 0.5) {
        discard_fragment();
    }
    
    params.set_render_color(color);
}
*/

class SegmentationProcessor {
    private let device: MTLDevice
    private let commandQueue: MTLCommandQueue
    private var segmentationTexture: MTLTexture?

    init() {
        self.device = MTLCreateSystemDefaultDevice()!
        self.commandQueue = device.makeCommandQueue()!
    }

    // 2. Convert CVPixelBuffer (Segmentation Output) to Metal Texture
    func updateOcclusionMask(from pixelBuffer: CVPixelBuffer) {
        let textureDescriptor = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: .r8Unorm, 
            width: CVPixelBufferGetWidth(pixelBuffer), 
            height: CVPixelBufferGetHeight(pixelBuffer), 
            mipmapped: false
        )
        textureDescriptor.usage = [.shaderRead]
        
        guard let newTexture = device.makeTexture(descriptor: textureDescriptor) else { return }
        
        // 3. Efficiently upload pixel data to GPU
        CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
        let bufferAddress = CVPixelBufferGetBaseAddress(pixelBuffer)
        
        let region = MTLRegionMake2D(0, 0, textureDescriptor.width, textureDescriptor.height)
        newTexture.replace(region: region, mipmapLevel: 0, withBytes: bufferAddress!, bytesPerRow: textureDescriptor.width)
        
        CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly)
        
        self.segmentationTexture = newTexture
    }
    
    func getTexture() -> MTLTexture? { segmentationTexture }
}

// 4. RealityKit Integration
extension Entity {
    func applyOcclusionMaterial(texture: MTLTexture) {
        guard let modelEntity = self as? ModelEntity else { return }
        
        do {
            // Create a CustomMaterial that uses our Metal shader
            // The 'segmentationTexture' is passed as a parameter to the shader
            var customMaterial = try CustomMaterial(surfaceShader: /* loaded shader */, lightingModel: .lit)
            customMaterial.custom.texture = .init(texture)
            
            modelEntity.model?.materials = [customMaterial]
        } catch {
            print("Failed to create custom material: \(error)")
        }
    }
}
