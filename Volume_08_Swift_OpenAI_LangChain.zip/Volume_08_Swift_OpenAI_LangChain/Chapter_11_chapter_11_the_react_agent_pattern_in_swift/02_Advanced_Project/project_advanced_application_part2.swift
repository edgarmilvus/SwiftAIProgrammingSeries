
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Observation

/// Represents the various errors that can occur during the ReAct loop.
enum AgentError: Error, LocalizedError {
    case toolExecutionFailed(String)
    case reasoningLoopExceeded
    case llmParsingError(String)
    case connectionLost

    var errorDescription: String? {
        switch self {
        case .toolExecutionFailed(let msg): return "Tool Error: \(msg)"
        case .reasoningLoopExceeded: return "The agent entered an infinite reasoning loop."
        case .llmParsingError(let msg): return "Failed to parse LLM response: \(msg)"
        case .connectionLost: return "Lost connection to the LLM provider."
        }
    }
}

/// The fundamental unit of action in the ReAct pattern.
/// Each tool must provide a description that the LLM uses to decide when to invoke it.
protocol AgentTool: Sendable {
    var name: String { get }
    var description: String { get }
    
    /// Executes the tool logic.
    /// - Parameter input: A JSON-formatted string or raw text provided by the LLM.
    /// - Returns: A string representation of the tool's output for the LLM to 'observe'.
    func execute(input: String) async throws -> String
}

/// A concrete implementation of a Calendar Tool.
/// In a real app, this would interface with EventKit.
struct CalendarTool: AgentTool {
    let name = "get_calendar_events"
    let description = "Retrieves upcoming calendar events for a specific time range. Input should be a time range string."

    func execute(input: String) async throws -> String {
        // Simulating an EventKit lookup
        try await Task.sleep(for: .seconds(1)) 
        return "Found event: 'Project Sync' from 3:00 PM to 4:00 PM."
    }
}

/// A concrete implementation of a Weather Tool.
struct WeatherTool: AgentTool {
    let name = "get_weather"
    let description = "Returns current weather conditions for a location. Input should be a city name."

    func execute(input: String) async throws -> String {
        // Simulating a weather API call
        try await Task.sleep(for: .seconds(0.5))
        return "Current weather in San Francisco: Heavy Rain, 55°F."
    }
}

/// The `ReActAgent` is an Actor to ensure that the agent's internal state 
/// (conversation history and tool registry) is protected from data races 
/// during the asynchronous reasoning loop.
@available(iOS 18.0, macOS 15.0, *)
actor ReActAgent {
    
    /// The internal state of the agent, including the conversation history.
    private var messageHistory: [String] = []
    private let tools: [String: any AgentTool]
    private let maxIterations: Int
    
    /// A stream to broadcast the agent's thought process to the UI.
    private var thoughtContinuation: AsyncStream<String>.Continuation?
    
    /// The stream used by the UI to observe the agent's "Thinking..." process.
    nonisolated let thoughtStream: AsyncStream<String>

    init(tools: [any AgentTool], maxIterations: Int = 5) {
        var toolMap: [String: any AgentTool] = [:]
        for tool in tools {
            toolMap[tool.name] = tool
        }
        self.tools = toolMap
        self.maxIterations = maxIterations
        
        // Initialize the stream for real-time UI updates
        var continuation: AsyncStream<String>.Continuation?
        self.thoughtStream = AsyncStream { continuation = $0 }
        self.thoughtContinuation = continuation
    }

    /// The main entry point for user queries.
    /// - Parameter query: The natural language prompt from the user.
    /// - Returns: The final synthesized answer from the agent.
    func solve(query: String) async throws -> String {
        messageHistory.append("User: \(query)")
        var iteration = 0
        
        while iteration < maxIterations {
            iteration += 1
            
            // 1. REASON: Ask the LLM what to do next based on history.
            let reasoningResponse = try await callLLM(history: messageHistory)
            
            // 2. PARSE: Determine if the LLM wants to ACT or give a FINAL ANSWER.
            // We expect a format like: THOUGHT: <reasoning> | ACTION: <tool_name> | INPUT: <input>
            // Or: FINAL ANSWER: <answer>
            
            if reasoningResponse.contains("FINAL ANSWER:") {
                let answer = reasoningResponse.replacingOccurrences(of: "FINAL ANSWER:", with: "").trimmingCharacters(in: .whitespacesAndNewlines)
                messageHistory.append("Assistant: \(answer)")
                return answer
            }
            
            // 3. ACT: Extract the tool name and input.
            guard let actionInfo = parseAction(from: reasoningResponse) else {
                throw AgentError.llmParsingError("Could not parse Action/Input from: \(reasoningResponse)")
            }
            
            let (toolName, toolInput) = actionInfo
            thoughtContinuation?.yield("Iteration \(iteration): Thinking about using \(toolName)...")
            
            // 4. OBSERVE: Execute the tool and record the result.
            guard let tool = tools[toolName] else {
                let errorMsg = "Tool \(toolName) not found."
                messageHistory.append("Observation: \(errorMsg)")
                continue
            }
            
            do {
                let observation = try await tool.execute(input: toolInput)
                messageHistory.append("Action: \(toolName)(\(toolInput))")
                messageHistory.append("Observation: \(observation)")
                thoughtContinuation?.yield("Observed: \(observation)")
            } catch {
                messageHistory.append("Observation: Error executing tool: \(error.localizedDescription)")
            }
        }
        
        throw AgentError.reasoningLoopExceeded
    }

    /// Simulates the LLM API call. In a real implementation, this would use 
    /// OpenAI's Chat Completions API with a system prompt defining the ReAct format.
    private func callLLM(history: [String]) async throws -> String {
        // This is a mock of the LLM's complex logic. 
        // In reality, this sends the `history` to OpenAI.
        try await Task.sleep(for: .milliseconds(800))
        
        let currentContext = history.joined(separator: "\n")
        
        // Mocking a multi-step reasoning process for the specific query: 
        // "Should I leave for my 3:00 PM meeting now?"
        if currentContext.contains("get_calendar_events") && !currentContext.contains("get_weather") {
            return "THOUGHT: I need to check the user's calendar to see when the meeting is. | ACTION: get_calendar_events | INPUT: today"
        } else if currentContext.contains("get_weather") || currentContext.contains("get_calendar_events") {
            return "THOUGHT: I know the meeting is at 3:00 PM. Now I need to check the weather to see if rain affects travel. | ACTION: get_weather | INPUT: San Francisco"
        } else if currentContext.contains("Heavy Rain") {
            return "FINAL ANSWER: You should leave now. You have a meeting at 3:00 PM, and the current weather is heavy rain, which will likely slow down your commute."
        }
        
        return "FINAL ANSWER: I'm not sure how to help with that yet."
    }

    /// Helper to parse the structured string output from the LLM.
    private func parseAction(from response: String) -> (String, String)? {
        // Simplified parsing logic for demonstration
        // Expected format: THOUGHT: ... | ACTION: tool_name | INPUT: input_text
        let components = response.components(separatedBy: "|")
        guard components.count >= 2 else { return nil }
        
        let actionPart = components.first(where: { $0.contains("ACTION:") })?.replacingOccurrences(of: "ACTION:", with: "").trimmingCharacters(in: .whitespaces)
        let inputPart = components.first(where: { $0.contains("INPUT:") })?.replacingOccurrences(of: "INPUT:", with: "").trimmingCharacters(in: .whitespaces)
        
        if let action = actionPart, let input = inputPart {
            return (action, input)
        }
        return nil
    }
}

// MARK: - UI Integration Layer

@available(iOS 18.0, macOS 15.0, *)
@Observable
class AgentViewModel {
    var userQuery: String = ""
    var response: String = ""
    var thoughtLogs: [String] = []
    var isProcessing: Bool = false
    
    private let agent: ReActAgent
    
    init() {
        // Initialize the agent with our system tools
        self.agent = ReActAgent(tools: [CalendarTool(), WeatherTool()])
        
        // Start observing the agent's thoughts
        Task {
            for await thought in await agent.thoughtStream {
                await MainActor.run {
                    self.thoughtLogs.append(thought)
                }
            }
        }
    }
    
    @MainActor
    func runAgent() async {
        isProcessing = true
        response = ""
        thoughtLogs.append("Starting agent loop...")
        
        do {
            let finalAnswer = try await agent.solve(query: userQuery)
            response = finalAnswer
        } catch {
            response = "Error: \(error.localizedDescription)"
        }
        
        isProcessing = false
    }
}
