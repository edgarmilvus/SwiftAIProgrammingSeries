
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation // For UUID

actor AICacheActor {
    private var cache: [UUID: String] = [:]

    /// Safely retrieves a cached value for a given key.
    /// - Parameter key: The UUID key for the cached content.
    /// - Returns: The cached string value, or `nil` if not found.
    func get(key: UUID) async -> String? {
        print("[\(Thread.current.description)] Getting value for key: \(key.uuidString.prefix(8))...")
        return cache[key]
    }

    /// Safely stores a new value in the cache for a given key.
    /// - Parameters:
    ///   - key: The UUID key for the content.
    ///   - value: The string content to cache.
    func set(key: UUID, value: String) async {
        print("[\(Thread.current.description)] Setting value for key: \(key.uuidString.prefix(8))...")
        cache[key] = value
        print("[\(Thread.current.description)] Cache size after set: \(cache.count)")
    }

    /// Clears the entire cache.
    func clear() async {
        cache.removeAll()
        print("[\(Thread.current.description)] Cache cleared.")
    }
}

// MARK: - Concurrency Demonstration

@main
struct Exercise1 {
    static func main() async {
        let aiCache = AICacheActor()
        let totalTasks = 100
        let sharedKey = UUID() // A key that multiple tasks will try to set/get

        print("--- Starting AICacheActor Concurrency Demonstration ---")

        // Group of tasks to concurrently set and get values
        await withTaskGroup(of: Void.self) { group in
            for i in 1...totalTasks {
                group.addTask {
                    let key = (i % 2 == 0) ? sharedKey : UUID() // Use sharedKey for even tasks, new UUID for odd
                    let value = "AI Result for task \(i)"

                    // Simulate some work before setting
                    try? await Task.sleep(for: .milliseconds(Int.random(in: 10...50)))

                    if i % 3 == 0 { // Every 3rd task tries to get a value
                        if let retrievedValue = await aiCache.get(key: key) {
                            print("[\(Thread.current.description)] Task \(i) retrieved: '\(retrievedValue.prefix(20))...' for key \(key.uuidString.prefix(8))...")
                        } else {
                            print("[\(Thread.current.description)] Task \(i) tried to retrieve, but no value found for key \(key.uuidString.prefix(8))...")
                        }
                    } else { // Other tasks set values
                        await aiCache.set(key: key, value: value)
                        if key == sharedKey {
                            print("[\(Thread.current.description)] Task \(i) set value for SHARED key: '\(value.prefix(20))...'")
                        }
                    }
                }
            }
        }

        // After all tasks are done, try to retrieve the shared key's final value
        print("\n--- All concurrent tasks completed. ---")
        if let finalSharedValue = await aiCache.get(key: sharedKey) {
            print("[\(Thread.current.description)] Final value for shared key \(sharedKey.uuidString.prefix(8))...: '\(finalSharedValue)'")
        } else {
            print("[\(Thread.current.description)] Shared key \(sharedKey.uuidString.prefix(8))... was not found in cache.")
        }
        
        // Verify cache count (should be less than totalTasks if sharedKey was used)
        let finalCacheSize = await aiCache.cache.count
        print("[\(Thread.current.description)] Final cache size: \(finalCacheSize)")
        
        await aiCache.clear()
    }
}
