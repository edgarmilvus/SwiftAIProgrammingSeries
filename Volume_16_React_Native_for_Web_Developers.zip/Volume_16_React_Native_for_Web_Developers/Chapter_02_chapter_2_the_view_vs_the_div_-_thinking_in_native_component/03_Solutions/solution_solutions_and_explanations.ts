/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

// Define the props interface for type safety
interface UserProfileCardProps {
  name: string;
  bio: string;
  avatarSource: any; // Using 'any' for local require() type compatibility
}

/**
 * A reusable User Profile Card component.
 * Translates web semantics (div, span, img) to native components (View, Text, Image).
 */
const UserProfileCard: React.FC<UserProfileCardProps> = ({ name, bio, avatarSource }) => {
  return (
    <View style={styles.card}>
      <Image source={avatarSource} style={styles.avatar} />
      <Text style={styles.name}>{name}</Text>
      <Text style={styles.bio}>{bio}</Text>
    </View>
  );
};

// StyleSheet for styling translation
const styles = StyleSheet.create({
  card: {
    display: 'flex', // 'flex' is the default in RN, but explicit for clarity
    flexDirection: 'column',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    padding: 20,
    borderRadius: 12,
    margin: 16,
    // React Native uses elevation for Android and shadow props for iOS
    // For this exercise, we stick to the closest web equivalent logic (shadow props)
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    // Note: On Android, you would typically add elevation: 4 here
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50, // 'borderRadius: 50%' is not valid; use a number
    marginBottom: 16,
    resizeMode: 'cover', // Equivalent to object-fit: cover
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  bio: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center', // Text alignment works on Text components
  },
});

export default UserProfileCard;
