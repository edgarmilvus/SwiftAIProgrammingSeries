
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

struct ContentAnalysisResult: Sendable { // Implicitly Sendable as it contains only Sendable types
    enum Sentiment: Sendable { case positive, negative, neutral } // Enums are Sendable by default
    let sentiment: Sentiment
    let topics: [String] // Array of Strings is Sendable
}

// Example of passing Sendable data between tasks
func processAIResult(result: ContentAnalysisResult) async {
    // This function can safely receive 'result' from any concurrency context
    // because ContentAnalysisResult is Sendable.
    print("Processing AI result with sentiment: \(result.sentiment)")
}

func performAIWorkAndSendResult() async {
    let aiResult = ContentAnalysisResult(sentiment: .neutral, topics: ["AI", "Concurrency"])
    await processAIResult(result: aiResult) // Safely pass the result
}
