
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import ARKit
import RealityKit
import simd

@MainActor
class DriftCorrectionEngine {
    private var worldTracking: WorldTrackingProvider?
    private var targetAnchors: [UUID: Entity] = [:] // The "Pillars"
    
    // Stores the original transforms relative to the WorldOrigin before correction
    private var baselineTransforms: [UUID: simd_float4x4] = [:]

    func registerTarget(anchorID: UUID, entity: Entity, initialTransform: simd_float4x4) {
        targetAnchors[anchorID] = entity
        baselineTransforms[anchorID] = initialTransform
    }

    func performCorrection(using referenceImageAnchor: ARImageAnchor) {
        // 1. The 'Ideal' transform of the image (where we thought it was)
        // For this example, let's assume we have a stored 'ideal' transform
        let idealImageTransform = simd_float4x4(1) // Simplified for demo
        
        // 2. The 'Observed' transform (where ARKit actually sees it now)
        let observedImageTransform = referenceImageAnchor.transform
        
        // 3. Calculate the Drift Matrix (D)
        // D * Ideal = Observed  =>  D = Observed * Inverse(Ideal)
        let driftMatrix = simd_mul(observedImageTransform, idealImageTransform.inverse)
        
        applyCorrection(driftMatrix: driftMatrix)
    }

    private func applyCorrection(driftMatrix: simd_float4x4) {
        for (id, entity) in targetAnchors {
            guard let originalBase = baselineTransforms[id] else { continue }
            
            // 4. Calculate corrected position: P' = D * P
            // We apply the drift to the original baseline to prevent cumulative error
            let correctedTransform = simd_mul(driftMatrix, originalBase)
            
            // 5. Update the RealityKit entity
            entity.setTransformMatrix(correctedTransform, relativeTo: nil)
        }
    }
}
