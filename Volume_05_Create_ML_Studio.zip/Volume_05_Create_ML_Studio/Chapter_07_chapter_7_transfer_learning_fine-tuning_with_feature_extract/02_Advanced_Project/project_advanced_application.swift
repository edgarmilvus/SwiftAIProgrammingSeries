
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift (Illustrative for external dependencies)
// NOTE: Create ML, Core ML, and Vision are system frameworks and do not require
// explicit SPM declarations in the same way.

/*
import PackageDescription

let package = Package(
    name: "DocumentClassifierApp",
    platforms: [
        .iOS(.v18), // Targeting latest iOS for Swift 6 features and Create ML capabilities
        .macOS(.v15)
    ],
    products: [
        .library(
            name: "DocumentClassifierKit",
            targets: ["DocumentClassifierKit"]),
    ],
    dependencies: [
        // Example: If we needed a robust third-party unzipping library
        // .package(url: "https://github.com/marmelroy/Zip", from: "2.1.0"),
    ],
    targets: [
        .target(
            name: "DocumentClassifierKit",
            dependencies: [
                // .product(name: "Zip", package: "Zip") // If ZipFoundation was used
            ]),
        .testTarget(
            name: "DocumentClassifierKitTests",
            dependencies: ["DocumentClassifierKit"]),
    ]
)
*/
