
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import Vision
import CoreML

/// A ViewModel to integrate the DocumentClassifierService into a SwiftUI application.
@available(iOS 18.0, *)
class DocumentScannerViewModel: ObservableObject {
    @Published var classifiedDocumentType: DocumentType = .unknown
    @Published var errorMessage: String?
    @Published var isLoading: Bool = false
    @Published var currentModelStatus: String = "Initializing..."

    private let classifierService = DocumentClassifierService()

    init() {
        // Observe changes to the service's internal state if needed,
        // or rely on its `loadBestAvailableModel` in init.
        // For this example, we'll just rely on the service's internal init logic.
        Task { @MainActor in
            // A small delay to allow the service's internal init to complete
            // and update its current model status.
            try? await Task.sleep(for: .milliseconds(500))
            self.updateModelStatus()
        }
    }

    /// Processes a UIImage for classification.
    /// - Parameter uiImage: The image to classify.
    func processImage(_ uiImage: UIImage) {
        Task { @MainActor in
            isLoading = true
            errorMessage = nil
            do {
                guard let cgImage = uiImage.cgImage else {
                    throw AppError.invalidInput
                }
                let type = try await classifierService.classifyDocument(image: cgImage)
                self.classifiedDocumentType = type
                self.updateModelStatus() // Update status after successful operation
            } catch {
                self.errorMessage = (error as? AppError)?.localizedDescription ?? "An unexpected error occurred: \(error.localizedDescription)"
                self.classifiedDocumentType = .unknown // Ensure UI reflects failure
                self.updateModelStatus() // Update status even on error
            }
            isLoading = false
        }
    }

    /// Triggers the simulation of downloading a new model version.
    func downloadNewModel() {
        Task { @MainActor in
            isLoading = true
            errorMessage = nil
            do {
                try await classifierService.simulateDownloadV2Model()
                self.errorMessage = "V2 model downloaded and loaded!"
                self.updateModelStatus()
            } catch {
                self.errorMessage = (error as? AppError)?.localizedDescription ?? "Failed to download new model: \(error.localizedDescription)"
            }
            isLoading = false
        }
    }

    /// Triggers the simulation of removing a downloaded model version.
    func removeNewModel() {
        Task { @MainActor in
            isLoading = true
            errorMessage = nil
            do {
                try await classifierService.simulateRemoveV2Model()
                self.errorMessage = "V2 model removed, falling back to V1/fallback."
                self.updateModelStatus()
            } catch {
                self.errorMessage = (error as? AppError)?.localizedDescription ?? "Failed to remove model: \(error.localizedDescription)"
            }
            isLoading = false
        }
    }

    /// Helper to update the UI with the current model status.
    private func updateModelStatus() {
        // This would ideally access a public property on DocumentClassifierService
        // that exposes its currentModelVersion. For this example, we'll hardcode
        // based on assumption or a simplified service interface.
        // A more robust solution would involve the service publishing its state.
        if let _ = classifierService.currentModel { // Access to currentModel is private, this is illustrative
             self.currentModelStatus = "Active Model: \(classifierService.currentModelVersion)"
        } else {
             self.currentModelStatus = "Active Model: Fallback (No ML)"
        }
    }
}
