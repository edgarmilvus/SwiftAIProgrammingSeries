
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import UIKit
import RealityKit
import ARKit
import Vision
import CoreML // Required if using VNCoreMLRequest for custom models

/// A custom ARAnchor subclass to uniquely identify and track detected objects.
/// This allows us to associate Vision detections with ARKit's world tracking.
@available(iOS 18.0, *)
class DetectedObjectAnchor: ARAnchor {
    let objectIdentifier: String
    var boundingBox: CGRect // Store the last known 2D bounding box for updates

    init(transform: simd_float4x4, objectIdentifier: String, boundingBox: CGRect) {
        self.objectIdentifier = objectIdentifier
        self.boundingBox = boundingBox
        super.init(transform: transform)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func isEqual(_ object: Any?) -> Bool {
        guard let otherAnchor = object as? DetectedObjectAnchor else {
            return false
        }
        // Anchors are equal if their objectIdentifier and transform are similar enough
        // For simplicity, we just check identifier here. ARKit handles transform equality.
        return self.objectIdentifier == otherAnchor.objectIdentifier
    }
}

/// Manages an AR experience for detecting and tagging specific real-world objects
/// using Vision and ARKit, displaying persistent information tags with RealityKit.
@available(iOS 18.0, *)
class ObjectTaggingViewController: UIViewController, ARSessionDelegate, ARViewDelegate {

    // MARK: - UI Elements
    var arView: ARView!
    private let processingQueue = DispatchQueue(label: "com.example.objectDetectionQueue", qos: .userInitiated)
    private var isProcessingFrame = false // Guard to prevent multiple concurrent Vision requests

    // MARK: - Vision Setup
    /// The Vision request for our custom Core ML object detection model.
    /// Replace "MyObjectDetector" with the actual name of your .mlmodel file.
    /// This model should be trained to detect the specific objects you want to tag.
    private var objectDetectionRequest: VNCoreMLRequest?

    // MARK: - State Management
    /// A dictionary to keep track of currently active detected object anchors.
    /// Key: objectIdentifier (from Vision result), Value: DetectedObjectAnchor
    private var activeObjectAnchors: [String: DetectedObjectAnchor] = [:]

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupARView()
        setupVision()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        startARSession()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        arView.session.pause()
    }

    // MARK: - Setup Methods

    /// 1. Initializes and configures the ARView for the augmented reality experience.
    /// This includes setting up world tracking and enabling debug options.
    private func setupARView() {
        arView = ARView(frame: view.bounds)
        view.addSubview(arView)
        arView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            arView.topAnchor.constraint(equalTo: view.topAnchor),
            arView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            arView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            arView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        arView.session.delegate = self
        arView.delegate = self // For ARViewDelegate methods like entity updates
        arView.automaticallyConfigureSession = false // We configure it manually
        arView.debugOptions = [.showFeaturePoints, .showWorldOrigin]

        // Enable user interaction for tapping on virtual tags
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        arView.addGestureRecognizer(tapGesture)
    }

    /// 2. Sets up the Vision framework for object detection using a custom Core ML model.
    /// This prepares the `VNCoreMLRequest` that will be used for each frame.
    private func setupVision() {
        guard let modelURL = Bundle.main.url(forResource: "MyObjectDetector", withExtension: "mlmodelc") else {
            fatalError("Failed to find MyObjectDetector.mlmodelc in app bundle. Ensure your Core ML model is compiled and added to the project.")
        }

        do {
            let visionModel = try VNCoreMLModel(for: MLModel(contentsOf: modelURL))
            objectDetectionRequest = VNCoreMLRequest(model: visionModel) { [weak self] request, error in
                self?.handleVisionResults(request: request, error: error)
            }
            objectDetectionRequest?.imageCropAndScaleOption = .scaleFit // Or .centerCrop, .scaleFill
            objectDetectionRequest?.usesCPUOnly = false // Leverage GPU if available
        } catch {
            print("Error setting up Vision model: \(error)")
            fatalError("Vision model setup failed.")
        }
    }

    /// 3. Starts the AR session with world tracking configuration.
    private func startARSession() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal, .vertical] // Optional: for general AR interaction
        arView.session.run(configuration)
    }

    // MARK: - ARSessionDelegate

    /// 4. Processes each AR camera frame for object detection.
    /// This method is called frequently by ARKit on a background thread.
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        guard !isProcessingFrame, let pixelBuffer = frame.capturedImage else { return }

        isProcessingFrame = true
        processingQueue.async { [weak self] in
            self?.performObjectDetection(pixelBuffer: pixelBuffer, orientation: .up)
        }
    }

    /// 5. Handles AR session errors.
    func session(_ session: ARSession, didFailWithError error: Error) {
        print("AR Session failed: \(error.localizedDescription)")
        // Present user feedback, e.g., an alert
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "AR Session Error", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true)
        }
    }

    // MARK: - Vision Processing

    /// Performs the actual object detection using the Vision framework.
    /// This runs on a background queue to avoid blocking the AR experience.
    private func performObjectDetection(pixelBuffer: CVPixelBuffer, orientation: CGImagePropertyOrientation) {
        guard let request = objectDetectionRequest else {
            print("Vision request not initialized.")
            isProcessingFrame = false
            return
        }

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: orientation, options: [:])
        do {
            try handler.perform([request])
        } catch {
            print("Failed to perform Vision request: \(error)")
        }
        // Ensure to reset the guard variable regardless of success or failure
        isProcessingFrame = false
    }

    /// 6. Processes the results from the Vision object detection request.
    /// This method is called after Vision has processed a frame.
    private func handleVisionResults(request: VNRequest, error: Error?) {
        // Ensure updates to ARView/UI happen on the main thread
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }

            if let error = error {
                print("Vision object detection error: \(error.localizedDescription)")
                return
            }

            guard let observations = request.results as? [VNRecognizedObjectObservation] else {
                print("No observations found or wrong type.")
                return
            }

            var newOrUpdatedIdentifiers: Set<String> = []

            for observation in observations {
                // Assuming your Core ML model provides a single top label for simplicity
                guard let topLabel = observation.labels.first else { continue }

                let objectIdentifier = topLabel.identifier
                let confidence = topLabel.confidence
                let boundingBox = observation.boundingBox // Normalized coordinates [0,1]

                // Filter out low confidence detections
                guard confidence > 0.8 else {
                    print("Low confidence detection for \(objectIdentifier): \(confidence)")
                    continue
                }

                // 7. Map 2D Vision bounding box to 3D world coordinates.
                // We'll use the center of the bounding box for hit testing.
                let centerPoint = CGPoint(x: boundingBox.midX, y: boundingBox.midY)
                let transformedPoint = self.arView.transform(normalizedPoint: centerPoint) // Convert to screen coordinates
                
                // Perform a hit test to find a real-world plane or feature point
                let hitTestResults = self.arView.hitTest(transformedPoint, types: [.featurePoint, .estimatedHorizontalPlane, .estimatedVerticalPlane])

                guard let hitResult = hitTestResults.first else {
                    print("No ARKit hit test result for object \(objectIdentifier) at \(boundingBox)")
                    continue
                }

                let newTransform = hitResult.worldTransform

                if let existingAnchor = self.activeObjectAnchors[objectIdentifier] {
                    // Update existing anchor's transform and bounding box
                    existingAnchor.transform = newTransform
                    existingAnchor.boundingBox = boundingBox
                    print("Updated anchor for \(objectIdentifier)")
                } else {
                    // Create a new anchor for a newly detected object
                    let newAnchor = DetectedObjectAnchor(transform: newTransform, objectIdentifier: objectIdentifier, boundingBox: boundingBox)
                    self.arView.session.add(anchor: newAnchor)
                    self.activeObjectAnchors[objectIdentifier] = newAnchor
                    print("Added new anchor for \(objectIdentifier)")
                }
                newOrUpdatedIdentifiers.insert(objectIdentifier)
            }

            // Remove anchors for objects that are no longer detected
            let identifiersToRemove = Set(self.activeObjectAnchors.keys).subtracting(newOrUpdatedIdentifiers)
            for identifier in identifiersToRemove {
                if let anchor = self.activeObjectAnchors[identifier] {
                    self.arView.session.remove(anchor: anchor)
                    self.activeObjectAnchors.removeValue(forKey: identifier)
                    print("Removed anchor for \(identifier)")
                }
            }
        }
    }

    // MARK: - ARViewDelegate (RealityKit Integration)

    /// 8. Attaches RealityKit entities (virtual tags) to new or updated AR anchors.
    /// This method is called by ARView when an ARAnchor is added or updated.
    func arView(_ arView: ARView, didAdd anchor: ARAnchor) {
        guard let detectedAnchor = anchor as? DetectedObjectAnchor else { return }

        // Create a virtual tag entity
        let tagEntity = createTagEntity(for: detectedAnchor.objectIdentifier)
        tagEntity.name = detectedAnchor.objectIdentifier // Assign name for easy lookup
        
        // Add a CollisionComponent for tap interaction
        tagEntity.components.set(CollisionComponent(shapes: [.generateBox(size: tagEntity.visualBounds(relativeTo: nil).extents)]))
        
        // Add a InputTargetComponent to make it tappable
        tagEntity.components.set(InputTargetComponent())

        // Create an AnchorEntity and add our tag entity to it
        let anchorEntity = AnchorEntity(anchor: detectedAnchor)
        anchorEntity.addChild(tagEntity)
        arView.scene.addAnchor(anchorEntity)

        print("Attached virtual tag for \(detectedAnchor.objectIdentifier)")
    }

    /// 9. Creates a RealityKit entity representing the virtual information tag.
    /// This can be customized to show text, icons, or more complex UI.
    private func createTagEntity(for objectIdentifier: String) -> ModelEntity {
        let textMesh = MeshResource.generateText(
            objectIdentifier,
            extrusionDepth: 0.005,
            font: .systemFont(ofSize: 0.05, weight: .bold),
            containerFrame: .zero,
            alignment: .center,
            lineBreakMode: .byWordWrapping
        )
        let material = SimpleMaterial(color: .blue, isMetallic: false)
        let textEntity = ModelEntity(mesh: textMesh, material: material)

        // Position the text slightly above the detected object
        textEntity.position = [0, 0.1, 0] // 10cm above the anchor point
        textEntity.scale = [1, 1, 1] // Ensure scale is appropriate

        // Add a background plane for better visibility
        let planeMesh = MeshResource.generatePlane(width: 0.2, height: 0.08)
        let planeMaterial = SimpleMaterial(color: .white.withAlphaComponent(0.8), isMetallic: false)
        let planeEntity = ModelEntity(mesh: planeMesh, material: planeMaterial)
        planeEntity.position = [0, 0.08, -0.006] // Behind the text
        
        let groupEntity = ModelEntity()
        groupEntity.addChild(planeEntity)
        groupEntity.addChild(textEntity)
        
        // Add a simple pointer or line to the object
        let lineMesh = MeshResource.generateCylinder(height: 0.1, radius: 0.002)
        let lineMaterial = SimpleMaterial(color: .green, isMetallic: false)
        let lineEntity = ModelEntity(mesh: lineMesh, material: lineMaterial)
        lineEntity.position = [0, 0.05, 0] // Connects tag to anchor point
        groupEntity.addChild(lineEntity)

        return groupEntity
    }
    
    // MARK: - User Interaction

    /// 10. Handles user taps on virtual tags.
    @objc private func handleTap(_ sender: UITapGestureRecognizer) {
        let tapLocation = sender.location(in: arView)
        
        // Perform a raycast to detect if a RealityKit entity was tapped
        if let tappedEntity = arView.entity(at: tapLocation) {
            // Traverse up the hierarchy to find the root entity associated with our tag
            var currentEntity: Entity? = tappedEntity
            while currentEntity != nil && currentEntity?.name == nil {
                currentEntity = currentEntity?.parent
            }
            
            if let tagRootEntity = currentEntity, let objectIdentifier = tagRootEntity.name {
                print("Tapped on tag for object: \(objectIdentifier)")
                // In a real app, you would fetch and display detailed info
                let alert = UIAlertController(title: "Object Details", message: "Information for: \(objectIdentifier)\n(Simulated data)", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                present(alert, animated: true)
            }
        }
    }
}
