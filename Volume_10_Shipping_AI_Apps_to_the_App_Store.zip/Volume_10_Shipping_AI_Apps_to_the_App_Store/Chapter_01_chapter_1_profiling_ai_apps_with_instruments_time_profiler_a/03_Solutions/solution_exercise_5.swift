
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import CoreML

@available(iOS 18.0, *)
class LLMInferenceEngine {
    // In a real LLM, this would be a complex structure managing GPU buffers.
    // Here, we simulate the KV Cache (Key-Value Cache) using an array of buffers.
    private var kvCacheBuffers: [UnsafeMutableRawPointer] = []
    
    // Constraint: Limit the context window to prevent unbounded memory growth.
    private let maxContextWindow = 15 
    private let bufferSize = 1024 * 1024 // 1MB per token simulation

    func runInference(prompt: String) async {
        print("Starting inference for: \(prompt)")
        
        for i in 0..<100 {
            if Task.isCancelled { break }
            
            // 1. Simulate allocating memory for a new token's KV Cache
            let newBuffer = UnsafeMutableRawPointer.allocate(
                byteCount: bufferSize, 
                alignment: 64
            )
            kvCacheBuffers.append(newBuffer)
            
            // 2. Implement "Sliding Window" Attention:
            // If our context window exceeds the limit, we deallocate the oldest buffer.
            // This keeps the "Resident Memory" stable and prevents a crash.
            if kvCacheBuffers.count > maxContextWindow {
                let oldestBuffer = kvCacheBuffers.removeFirst()
                oldestBuffer.deallocate()
                print("Context window exceeded. Evicted oldest token cache.")
            }
            
            // Simulate the time taken to generate a token
            try? await Task.sleep(for: .milliseconds(50))
        }
        
        // 3. Final Cleanup
        cleanup()
    }
    
    private func cleanup() {
        kvCacheBuffers.forEach { $0.deallocate() }
        kvCacheBuffers.removeAll()
    }
    
    deinit {
        cleanup()
    }
}
