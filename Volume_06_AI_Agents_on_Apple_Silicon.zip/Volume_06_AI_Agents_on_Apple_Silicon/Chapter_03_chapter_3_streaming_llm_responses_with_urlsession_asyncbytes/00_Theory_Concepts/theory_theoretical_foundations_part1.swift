
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation // URLSession, URL, Data, String

@available(iOS 17.0, macOS 14.0, watchOS 10.0, tvOS 17.0, *)
func streamLLMResponse(from url: URL) async throws {
    var accumulatedResponse = ""
    
    // The core mechanism: URLSession.shared.bytes(for:) returns an AsyncBytes sequence.
    let (bytes, response) = try await URLSession.shared.bytes(for: URLRequest(url: url))
    
    guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
        throw URLError(.badServerResponse)
    }
    
    print("Starting LLM response stream...")
    
    // Iterate over the raw byte chunks as they arrive.
    for try await byte in bytes {
        // In a real LLM scenario, 'byte' would be part of an SSE event.
        // We'd accumulate bytes, parse SSE events, then parse JSON within.
        
        // For demonstration, let's assume raw UTF-8 chunks for simplicity.
        // In practice, this would involve more sophisticated parsing.
        if let chunk = String(data: Data([byte]), encoding: .utf8) {
            accumulatedResponse += chunk
            // Ideally, here you'd process and potentially display partial chunks
            // to the user, rather than just accumulating.
            print("Received chunk: \(chunk)")
            // Example: update a UI element on the main actor
            // await MainActor.run { self.viewModel.currentResponse = accumulatedResponse }
        }
    }
    
    print("LLM response stream finished. Total response: \(accumulatedResponse)")
}

// Example usage (in an async context):
/*
@available(iOS 17.0, macOS 14.0, watchOS 10.0, tvOS 17.0, *)
func initiateStream() async {
    guard let llmStreamURL = URL(string: "https://api.example.com/stream-llm") else { return }
    do {
        try await streamLLMResponse(from: llmStreamURL)
    } catch {
        print("Error streaming LLM response: \(error)")
    }
}
*/
