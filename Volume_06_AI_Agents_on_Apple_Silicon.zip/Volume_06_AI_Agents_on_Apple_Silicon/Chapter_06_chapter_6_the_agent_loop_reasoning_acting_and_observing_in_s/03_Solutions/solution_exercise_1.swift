
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

// MARK: - 1. Define Tools

/// Simulates a web search.
func searchWeb(query: String) -> String {
    "Searching the web for: \"\(query)\""
}

/// Simulates creating a reminder.
func createReminder(title: String, dueDate: Date?) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateStyle = .medium
    dateFormatter.timeStyle = .short
    let dateString = dueDate.map { " due on \(dateFormatter.string(from: $0))" } ?? ""
    return "Creating reminder: \"\(title)\"\(dateString)"
}

// MARK: - LLM Abstraction and Tool Definitions

/// Protocol for LLM inference, allowing for mocking.
protocol LLMInference {
    @available(iOS 18.0, macOS 15.0, *)
    func infer(prompt: String) async throws -> String
}

/// A mock LLM implementation for demonstration purposes.
/// In a real app, this would integrate with Ollama, llama.cpp, or a cloud LLM.
class MockLLM: LLMInference {
    @available(iOS 18.0, macOS 15.0, *)
    func infer(prompt: String) async throws -> String {
        // Simulate LLM thinking time
        try await Task.sleep(for: .milliseconds(100))

        // Simple keyword-based response for demonstration
        if prompt.contains("searchWeb") && prompt.contains("weather in London") {
            return """
            {
                "toolName": "searchWeb",
                "arguments": {
                    "query": "weather in London"
                }
            }
            """
        } else if prompt.contains("createReminder") && prompt.contains("buy groceries tomorrow") {
            // Simulate tomorrow's date
            let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: Date())!
            let dateFormatter = ISO8601DateFormatter()
            return """
            {
                "toolName": "createReminder",
                "arguments": {
                    "title": "buy groceries",
                    "dueDate": "\(dateFormatter.string(from: tomorrow))"
                }
            }
            """
        } else if prompt.contains("searchWeb") && prompt.contains("Swift concurrency") {
            return """
            {
                "toolName": "searchWeb",
                "arguments": {
                    "query": "Swift concurrency"
                }
            }
            """
        } else if prompt.contains("createReminder") && prompt.contains("call mom next Friday") {
            // Simulate next Friday's date
            var components = Calendar.current.dateComponents([.yearForWeekOfYear, .weekOfYear], from: Date())
            components.weekday = 6 // Friday
            let nextFriday = Calendar.current.date(from: components)!
            let dateFormatter = ISO8601DateFormatter()
            return """
            {
                "toolName": "createReminder",
                "arguments": {
                    "title": "call mom",
                    "dueDate": "\(dateFormatter.string(from: nextFriday))"
                }
            }
            """
        } else {
            return """
            {
                "toolName": "none",
                "arguments": {}
            }
            """
        }
    }
}

/// Represents a tool the agent can invoke.
struct Tool {
    let name: String
    let description: String
    let action: ([String: Any]) async throws -> String // Closure to execute the tool

    // Helper for creating tools with specific argument types
    static func make<A: Decodable>(name: String, description: String, _ handler: @escaping (A) async throws -> String) -> Tool {
        Tool(name: name, description: description) { argsDict in
            let data = try JSONSerialization.data(withJSONObject: argsDict, options: [])
            let typedArgs = try JSONDecoder().decode(A.self, from: data)
            return try await handler(typedArgs)
        }
    }
}

// MARK: - Agent Implementation

/// Decodable structure for LLM's tool output.
struct LLMToolCall: Decodable {
    let toolName: String
    let arguments: [String: JSONValue] // Use JSONValue to handle mixed types
}

/// Helper enum to parse arguments from LLM response, allowing for flexible types.
enum JSONValue: Decodable {
    case string(String)
    case int(Int)
    case double(Double)
    case bool(Bool)
    case dictionary([String: JSONValue])
    case array([JSONValue])
    case null

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let string = try? container.decode(String.self) {
            self = .string(string)
        } else if let int = try? container.decode(Int.self) {
            self = .int(int)
        } else if let double = try? container.decode(Double.self) {
            self = .double(double)
        } else if let bool = try? container.decode(Bool.self) {
            self = .bool(bool)
        } else if let dict = try? container.decode([String: JSONValue].self) {
            self = .dictionary(dict)
        } else if let array = try? container.decode([JSONValue].self) {
            self = .array(array)
        } else if container.decodeNil() {
            self = .null
        } else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Cannot decode JSONValue")
        }
    }

    // Convert to a more standard Swift type for tool invocation
    var toAny: Any {
        switch self {
        case .string(let s): return s
        case .int(let i): return i
        case .double(let d): return d
        case .bool(let b): return b
        case .dictionary(let dict): return dict.mapValues { $0.toAny }
        case .array(let arr): return arr.map { $0.toAny }
        case .null: return NSNull()
        }
    }
}

/// Defines argument structures for our specific tools.
struct SearchWebArgs: Codable {
    let query: String
}

struct CreateReminderArgs: Codable {
    let title: String
    let dueDate: Date? // ISO8601DateFormatter handles this by default with Codable
}

@available(iOS 18.0, macOS 15.0, *)
class ToolDispatcherAgent {
    private let llm: LLMInference
    private let tools: [String: Tool]
    private let jsonDecoder: JSONDecoder

    init(llm: LLMInference) {
        self.llm = llm
        
        let dateFormatter = ISO8601DateFormatter()
        self.jsonDecoder = JSONDecoder()
        self.jsonDecoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let dateString = try container.decode(String.self)
            if let date = dateFormatter.date(from: dateString) {
                return date
            }
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Cannot decode date string \(dateString)")
        }

        // Initialize and register tools
        let searchWebTool = Tool.make(
            name: "searchWeb",
            description: "Searches the web for a given query. Use this for general information, weather, definitions, etc."
        ) { (args: SearchWebArgs) in
            await Task { searchWeb(query: args.query) }.value
        }

        let createReminderTool = Tool.make(
            name: "createReminder",
            description: "Creates a new reminder with a title and an optional due date. Use this when the user wants to be reminded of something."
        ) { (args: CreateReminderArgs) in
            await Task { createReminder(title: args.title, dueDate: args.dueDate) }.value
        }

        self.tools = [
            searchWebTool.name: searchWebTool,
            createReminderTool.name: createReminderTool
        ]
    }

    private func generatePrompt(for query: String) -> String {
        let toolDescriptions = tools.values.map { tool in
            "Tool Name: \(tool.name)\nDescription: \(tool.description)"
        }.joined(separator: "\n---\n")

        return """
        You are an AI assistant that can dispatch tools based on user queries.
        Here are the tools you have available:
        \(toolDescriptions)

        Based on the user's query, decide which tool to call and extract the necessary arguments.
        If no tool is suitable, respond with {"toolName": "none", "arguments": {}}.
        If a tool is chosen, respond with a JSON object in the format:
        {
            "toolName": "name_of_the_tool",
            "arguments": {
                "arg1": "value1",
                "arg2": "value2",
                // ...
            }
        }
        Ensure date arguments are in ISO 8601 format (e.g., "YYYY-MM-DDTHH:MM:SSZ").

        User Query: "\(query)"
        JSON Response:
        """
    }

    func run(query: String) async throws -> String {
        print("Agent processing query: \"\(query)\"")
        // Reasoning
        let prompt = generatePrompt(for: query)
        let llmResponse = try await llm.infer(prompt: prompt)
        print("LLM Response:\n\(llmResponse)")

        // Acting
        guard let data = llmResponse.data(using: .utf8) else {
            throw AgentError.invalidLLMResponse("Could not encode LLM response to data.")
        }

        let toolCall: LLMToolCall
        do {
            toolCall = try jsonDecoder.decode(LLMToolCall.self, from: data)
        } catch {
            print("Failed to decode LLM tool call JSON: \(error.localizedDescription)")
            throw AgentError.invalidLLMResponse("Malformed JSON from LLM: \(error.localizedDescription)")
        }

        if toolCall.toolName == "none" {
            return "I couldn't find a suitable tool for your request."
        }

        guard let tool = tools[toolCall.toolName] else {
            throw AgentError.toolNotFound("Tool '\(toolCall.toolName)' not found.")
        }

        let argumentsAsAny = toolCall.arguments.mapValues { $0.toAny } as! [String: Any] // Force cast after conversion

        do {
            let toolOutput = try await tool.action(argumentsAsAny)
            // Observing (simplified)
            print("Tool '\(toolCall.toolName)' executed. Output: \(toolOutput)")
            return toolOutput
        } catch {
            print("Error executing tool '\(toolCall.toolName)': \(error.localizedDescription)")
            throw AgentError.toolExecutionFailed("Failed to execute tool '\(toolCall.toolName)': \(error.localizedDescription)")
        }
    }
}

// MARK: - Error Handling

enum AgentError: LocalizedError {
    case invalidLLMResponse(String)
    case toolNotFound(String)
    case toolExecutionFailed(String)

    var errorDescription: String? {
        switch self {
        case .invalidLLMResponse(let message): return "Invalid LLM Response: \(message)"
        case .toolNotFound(let message): return "Tool Not Found: \(message)"
        case .toolExecutionFailed(let message): return "Tool Execution Failed: \(message)"
        }
    }
}

// MARK: - Example Usage

@available(iOS 18.0, macOS 15.0, *)
func runSimpleToolDispatcherExample() async {
    let llm = MockLLM()
    let agent = ToolDispatcherAgent(llm: llm)

    let queries = [
        "What is the weather like in London?",
        "Remind me to buy groceries tomorrow.",
        "Find me information about Swift concurrency.",
        "Set a reminder to call mom next Friday.",
        "Tell me a joke." // Should result in 'no tool'
    ]

    for query in queries {
        print("\n--- User Input: \(query) ---")
        do {
            let result = try await agent.run(query: query)
            print("Agent's Final Response: \(result)")
        } catch {
            print("Agent encountered an error: \(error.localizedDescription)")
        }
        print("--------------------------")
    }
}

// To run the example in a playground or an app:
// if #available(iOS 18.0, macOS 15.0, *) {
//     Task {
//         await runSimpleToolDispatcherExample()
//     }
// } else {
//     print("Requires iOS 18.0 / macOS 15.0 or later for async/await functionality.")
// }
