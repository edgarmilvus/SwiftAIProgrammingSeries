
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift
// This file describes the package and its dependencies.

import PackageDescription

let package = Package(
    name: "AICodeReviewer",
    platforms: [
        .macOS(.v14), // Targeting macOS 14 for modern Swift and SwiftUI features
        .iOS(.v17)    // Including iOS 17 for potential cross-platform future
    ],
    products: [
        .executable(name: "AICodeReviewer", targets: ["AICodeReviewer"])
    ],
    dependencies: [
        // Hypothetical Swift bindings for llama.cpp.
        // In a real scenario, this would point to a specific Git repository
        // or a local path containing the LLamaKit Swift package.
        // For example: .package(url: "https://github.com/your-org/LLamaKit.git", from: "1.0.0")
        .package(url: "https://example.com/LLamaKit.git", .upToNextMajor(from: "1.0.0")),
        
        // Another dependency for handling network operations, if models are downloaded
        // For example, using a lightweight networking library or URLSession directly.
        // .package(url: "https://github.com/Alamofire/Alamofire.git", .upToNextMajor(from: "5.0.0"))
    ],
    targets: [
        .executableTarget(
            name: "AICodeReviewer",
            dependencies: ["LLamaKit"], // Our app depends on LLamaKit
            resources: [
                // If model files were bundled directly, they would be listed here.
                // However, for advanced distribution, we often download them.
                // .process("Resources/model.gguf")
            ]
        )
    ]
)
