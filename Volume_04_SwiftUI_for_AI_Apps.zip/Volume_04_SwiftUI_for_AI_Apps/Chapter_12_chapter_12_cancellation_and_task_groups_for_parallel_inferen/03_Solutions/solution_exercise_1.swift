
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import UIKit // Using UIKit for UIImage, even in a non-UI context for demonstration

// MARK: - Simulated AI Model and Data

/// Represents a placeholder for an image.
let sampleImage = UIImage(systemName: "photo")!

/// An error type for AI operations.
enum AIProcessingError: Error, LocalizedError {
    case inferenceFailed
    case invalidImage
    
    var errorDescription: String? {
        switch self {
        case .inferenceFailed: return "AI inference failed unexpectedly."
        case .invalidImage: return "The provided image is invalid for processing."
        }
    }
}

/// Simulates a long-running AI inference to extract features from an image.
/// This function is cooperatively cancellable.
func extractImageFeatures(image: UIImage) async throws -> [String] {
    print("AI: Starting feature extraction for image...")
    
    // Simulate image validation
    guard image.size.width > 0 && image.size.height > 0 else {
        throw AIProcessingError.invalidImage
    }

    // Simulate a long-running AI inference process
    for i in 1...3 {
        try await Task.sleep(for: .seconds(1)) // Simulate work
        try Task.checkCancellation() // Check for cancellation
        print("AI: Processing step \(i)/3...")
    }
    
    // Final check before returning results
    try Task.checkCancellation()
    
    print("AI: Feature extraction complete.")
    return ["feature_object_detection", "feature_scene_understanding", "feature_color_palette"]
}

// MARK: - Task Management and UI Simulation

/// A class to manage the image processing task, simulating a UI controller.
class ImageProcessor {
    private var currentExtractionTask: Task<[String], Error>?
    
    func startFeatureExtraction() {
        // If a previous task is running, cancel it before starting a new one
        if let existingTask = currentExtractionTask {
            print("UI: Cancelling previous extraction task before starting new one.")
            existingTask.cancel()
        }
        
        print("UI: 'Start Feature Extraction' tapped. Initiating new task...")
        currentExtractionTask = Task {
            do {
                let features = try await extractImageFeatures(image: sampleImage)
                print("UI: ✅ Extraction successful! Features: \(features)")
            } catch is CancellationError {
                print("UI: 🛑 Extraction cancelled by user.")
            } catch {
                print("UI: ❌ Extraction failed with error: \(error.localizedDescription)")
            }
            // Clear the task reference once it's finished (or cancelled/failed)
            self.currentExtractionTask = nil
        }
    }
    
    func cancelExtraction() {
        guard let task = currentExtractionTask else {
            print("UI: No active extraction task to cancel.")
            return
        }
        print("UI: 'Cancel Extraction' tapped. Cancelling task...")
        task.cancel()
    }
    
    // For demonstration, ensure the task is cleaned up on deinit
    deinit {
        currentExtractionTask?.cancel()
    }
}

// MARK: - Demonstration

func demonstrateCancellableImageFeatureExtraction() async {
    let processor = ImageProcessor()
    
    print("--- Scenario 1: Successful Extraction ---")
    processor.startFeatureExtraction()
    await Task.sleep(for: .seconds(4)) // Wait for completion
    print("\n")
    
    print("--- Scenario 2: User Cancels Mid-Process ---")
    processor.startFeatureExtraction()
    await Task.sleep(for: .seconds(1.5)) // Allow some work to happen
    processor.cancelExtraction()
    await Task.sleep(for: .seconds(1)) // Give time for cancellation to propagate
    print("\n")
    
    print("--- Scenario 3: Cancel when no task is active ---")
    processor.cancelExtraction()
    print("\n")
    
    print("--- Scenario 4: Starting a new task cancels the old one ---")
    processor.startFeatureExtraction()
    await Task.sleep(for: .seconds(1))
    processor.startFeatureExtraction() // This should cancel the first one and start a new one
    await Task.sleep(for: .seconds(4)) // Wait for the second task to complete
    print("\n")
}

// Run the demonstration
await demonstrateCancellableImageFeatureExtraction()
