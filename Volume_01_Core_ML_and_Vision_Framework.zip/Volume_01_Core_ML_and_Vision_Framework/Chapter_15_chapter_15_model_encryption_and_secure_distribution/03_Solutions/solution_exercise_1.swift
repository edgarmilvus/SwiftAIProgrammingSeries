
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CoreML
import Foundation
import CryptoKit

// MARK: - Global Helpers (for all exercises)

enum ModelEncryptionError: Error, LocalizedError {
    case keychainError(status: OSStatus)
    case encryptionFailed
    case decryptionFailed
    case invalidDataFormat
    case modelNotFound
    case modelCompilationFailed
    case signatureVerificationFailed
    case authenticationFailed(Error?)
    case secureEnclaveKeyGenerationFailed(Error)
    case keyWrappingFailed
    case keyUnwrappingFailed
    case networkError(Error)
    case badServerResponse(statusCode: Int, description: String?)
    case invalidKeyData
    case fileSystemError(Error)

    var errorDescription: String? {
        switch self {
        case .keychainError(let status): return "Keychain operation failed with status: \(status)"
        case .encryptionFailed: return "Encryption failed."
        case .decryptionFailed: return "Decryption failed."
        case .invalidDataFormat: return "Invalid data format."
        case .modelNotFound: return "Core ML model not found."
        case .modelCompilationFailed: return "Core ML model compilation failed."
        case .signatureVerificationFailed: return "Model integrity check failed: Invalid signature."
        case .authenticationFailed(let error): return "Authentication failed: \(error?.localizedDescription ?? "Unknown error")."
        case .secureEnclaveKeyGenerationFailed(let error): return "Secure Enclave key generation failed: \(error.localizedDescription)."
        case .keyWrappingFailed: return "Key wrapping failed."
        case .keyUnwrappingFailed: return "Key unwrapping failed."
        case .networkError(let error): return "Network request failed: \(error.localizedDescription)."
        case .badServerResponse(let statusCode, let desc): return "Bad server response (\(statusCode)): \(desc ?? "No description")."
        case .invalidKeyData: return "Invalid key data received from server."
        case .fileSystemError(let error): return "File system operation failed: \(error.localizedDescription)."
        }
    }
}

// Helper to create a dummy .mlmodelc directory for testing.
// NOTE: This creates a directory structure that *looks* like .mlmodelc but is not a functional Core ML model.
// MLModel(contentsOf:) will likely fail to load this dummy structure, but it serves to demonstrate
// the file system operations, zipping/unzipping, and encryption/decryption of its contents.
func createDummyMLModelc(in directory: URL, modelName: String = "MyDummyModel") throws -> URL {
    let dummyModelcURL = directory.appendingPathComponent("\(modelName).mlmodelc")
    let fileManager = FileManager.default

    if fileManager.fileExists(atPath: dummyModelcURL.path) {
        try fileManager.removeItem(at: dummyModelcURL)
    }
    try fileManager.createDirectory(at: dummyModelcURL, withIntermediateDirectories: true, attributes: nil)

    // Add some dummy files to simulate a .mlmodelc structure
    try "model_spec_data_123".data(using: .utf8)?.write(to: dummyModelcURL.appendingPathComponent("model.mlmodel"))
    try "weights_data_456".data(using: .utf8)?.write(to: dummyModelcURL.appendingPathComponent("weights"))
    try "metadata_json_789".data(using: .utf8)?.write(to: dummyModelcURL.appendingPathComponent("metadata.json"))

    print("✅ Created dummy .mlmodelc directory at: \(dummyModelcURL.path)")
    return dummyModelcURL
}

// MARK: - Zipping/Unzipping Helpers (simplified for demonstration)

// This function simulates zipping a .mlmodelc directory into a single Data blob.
// In a real app, you would use a library like 'Zip' or the 'Compression' framework to properly archive the directory structure.
// For this exercise, we just concatenate file contents. This is a simplification.
func zipMLModelcToData(at mlmodelcURL: URL) throws -> Data {
    var combinedData = Data()
    let fileManager = FileManager.default
    guard let enumerator = fileManager.enumerator(at: mlmodelcURL, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles, .skipsPackageDescendants]) else {
        throw ModelEncryptionError.fileSystemError(NSError(domain: "ZipHelper", code: 0, userInfo: [NSLocalizedDescriptionKey: "Could not create file enumerator for \(mlmodelcURL.lastPathComponent)"]))
    }

    // For a realistic zip, you'd store relative paths and lengths.
    // Here, we just concatenate file contents. The actual content doesn't matter for encryption/decryption,
    // only its Data representation for size and integrity.
    for case let fileURL as URL in enumerator {
        if fileURL.isFileURL {
            let fileData = try Data(contentsOf: fileURL)
            combinedData.append(fileData)
        }
    }
    print("✅ Zipped (simulated) \(mlmodelcURL.lastPathComponent) into \(combinedData.count) bytes.")
    return combinedData
}

// This function simulates unzipping Data back into a .mlmodelc directory structure.
// In a real app, you would use a library like 'Zip' to properly extract the archive.
// For this exercise, we simply write the entire decrypted data into a single dummy file
// within the new .mlmodelc directory.
func unzipDataToMLModelc(data: Data, to tempDirectoryURL: URL, originalModelcName: String) throws -> URL {
    let modelcURL = tempDirectoryURL.appendingPathComponent(originalModelcName)
    let fileManager = FileManager.default

    if fileManager.fileExists(atPath: modelcURL.path) {
        try fileManager.removeItem(at: modelcURL)
    }
    try fileManager.createDirectory(at: modelcURL, withIntermediateDirectories: true, attributes: nil)

    // Write the entire decrypted data as a single file within the "unzipped" directory.
    // This is a simplification. A real unzip would reconstruct the original directory structure.
    let dummyModelContentFile = modelcURL.appendingPathComponent("model_content_placeholder.bin")
    try data.write(to: dummyModelContentFile)

    print("✅ Unzipped (simulated) data into \(modelcURL.lastPathComponent) with \(data.count) bytes in placeholder file.")
    return modelcURL
}

// Helper to remove temporary directories
func cleanUpTempDirectory(at url: URL) {
    if FileManager.default.fileExists(atPath: url.path) {
        try? FileManager.default.removeItem(at: url)
        print("🗑️ Cleaned up temporary directory: \(url.lastPathComponent)")
    }
}

// MARK: - Core Encryption/Decryption Functions

// Encrypts Data using AES-256 GCM. Returns ciphertext, authentication tag, and nonce.
func encryptModelData(_ data: Data, using key: SymmetricKey) throws -> (ciphertext: Data, tag: Data, nonce: Data) {
    let nonce = AES.GCM.Nonce()
    let sealedBox = try AES.GCM.seal(data, using: key, nonce: nonce)
    return (sealedBox.ciphertext, sealedBox.tag, nonce.combined)
}

// Decrypts Data using AES-256 GCM. Requires ciphertext, tag, nonce, and the same key.
func decryptModelData(_ ciphertext: Data, tag: Data, nonce: Data, using key: SymmetricKey) throws -> Data {
    let gcmNonce = try AES.GCM.Nonce(data: nonce)
    let sealedBox = try AES.GCM.SealedBox(nonce: gcmNonce, ciphertext: ciphertext, tag: tag)
    return try AES.GCM.open(sealedBox, using: key)
}

// MARK: - Exercise 1 Execution

func exercise1Solution() async {
    print("--- Exercise 1: On-Device Model Encryption and Decryption with AES-256 ---")

    let fileManager = FileManager.default
    let tempDirectory = fileManager.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    let encryptedModelFileName = "encryptedModel.zip.enc"
    let hardcodedKey = SymmetricKey(size: .bits256) // Insecure for production, for testing only

    do {
        try fileManager.createDirectory(at: tempDirectory, withIntermediateDirectories: true, attributes: nil)

        // 1. Obtain a Core ML Model (create a dummy one for demonstration)
        let originalModelcURL = try createDummyMLModelc(in: tempDirectory, modelName: "MySampleModel")
        let originalModelcName = originalModelcURL.lastPathComponent

        // 2. Prepare for Encryption: Archive the .mlmodelc directory into a single Data blob
        let modelDataToEncrypt = try zipMLModelcToData(at: originalModelcURL)

        // 3. Implement Encryption
        print("Encrypting model data...")
        let (ciphertext, tag, nonce) = try encryptModelData(modelDataToEncrypt, using: hardcodedKey)
        print("✅ Model data encrypted. Ciphertext size: \(ciphertext.count) bytes.")

        // Combine nonce, tag, and ciphertext for storage. A simple header format: NonceLength(1B) + TagLength(1B) + Nonce + Tag + Ciphertext
        // More robust: use fixed sizes or a more complex header. For GCM, nonce is 12 bytes, tag is 16 bytes.
        let combinedEncryptedData = nonce + tag + ciphertext
        let encryptedModelFileURL = tempDirectory.appendingPathComponent(encryptedModelFileName)

        // 4. Store Encrypted Model
        try combinedEncryptedData.write(to: encryptedModelFileURL)
        print("✅ Encrypted model saved to: \(encryptedModelFileURL.lastPathComponent)")

        // --- Simulate App Restart / Later Retrieval ---
        print("\nSimulating app restart and model retrieval...")

        // Load encrypted data from disk
        let loadedEncryptedData = try Data(contentsOf: encryptedModelFileURL)

        // Extract nonce, tag, and ciphertext
        guard loadedEncryptedData.count >= AES.GCM.Nonce.defaultSize + AES.GCM.tagByteCount else {
            throw ModelEncryptionError.invalidDataFormat
        }
        let loadedNonce = loadedEncryptedData.prefix(AES.GCM.Nonce.defaultSize)
        let loadedTag = loadedEncryptedData.dropFirst(AES.GCM.Nonce.defaultSize).prefix(AES.GCM.tagByteCount)
        let loadedCiphertext = loadedEncryptedData.dropFirst(AES.GCM.Nonce.defaultSize + AES.GCM.tagByteCount)

        // 5. Implement Decryption and Decompression
        print("Decrypting model data...")
        let decryptedModelData = try decryptModelData(loadedCiphertext, tag: loadedTag, nonce: loadedNonce, using: hardcodedKey)
        print("✅ Model data decrypted. Decrypted size: \(decryptedModelData.count) bytes.")

        // Verify decrypted data matches original (simplified check)
        guard decryptedModelData == modelDataToEncrypt else {
            throw ModelEncryptionError.decryptionFailed
        }
        print("✅ Decrypted data matches original data.")

        // Decompress (unzip) the decrypted Data back into a temporary .mlmodelc directory
        let decompressedModelcURL = try unzipDataToMLModelc(data: decryptedModelData, to: tempDirectory, originalModelcName: originalModelcName)

        // 6. Load and Verify
        print("Attempting to load Core ML model from: \(decompressedModelcURL.lastPathComponent)...")
        let configuration = MLModelConfiguration()
        do {
            // NOTE: This will likely fail for the dummy .mlmodelc created by createDummyMLModelc
            // because it's not a truly compilable or runnable Core ML model.
            // However, the intent to load is demonstrated.
            let mlModel = try MLModel(contentsOf: decompressedModelcURL, configuration: configuration)
            print("✅ Core ML model loaded successfully (dummy model).")

            // Perform a dummy prediction (this part would only work with a real, runnable model)
            // For a dummy model, we can't actually predict.
            // print("Performing a dummy prediction...")
            // let input = try MLDictionaryFeatureProvider(dictionary: ["input": MLFeatureValue(double: 10.0)])
            // let output = try mlModel.prediction(from: input)
            // print("Dummy prediction output: \(output.featureValue(for: "output")?.doubleValue ?? -1)")
            // print("✅ Dummy prediction successful.")

        } catch {
            print("⚠️ Failed to load Core ML model from dummy .mlmodelc. This is expected for a non-functional dummy model. Error: \(error.localizedDescription)")
            print("The encryption, decryption, and file handling steps were successful.")
        }

    } catch {
        print("❌ Exercise 1 failed with error: \(error.localizedDescription)")
    } finally {
        cleanUpTempDirectory(at: tempDirectory)
    }
    print("--- End of Exercise 1 ---")
}

// Call the solution function to run
// await exercise1Solution() // Uncomment to run in an async context
