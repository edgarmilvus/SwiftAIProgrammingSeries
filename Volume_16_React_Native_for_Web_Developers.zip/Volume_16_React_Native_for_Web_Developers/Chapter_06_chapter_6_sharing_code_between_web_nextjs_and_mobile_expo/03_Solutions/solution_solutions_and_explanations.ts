/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

# 1. Initialize Turborepo (run in the desired root directory)
npx create-turbo@latest

# 2. Move existing Next.js app (assuming it's in a sibling folder named 'my-next-app')
# Note: In a real scenario, you would copy or move the folder contents.
# Here we simulate the structure creation.
mkdir -p apps/web
# (Copy existing Next.js files into apps/web)

# 3. Initialize Expo inside apps/mobile
cd apps/mobile
npx create-expo-app . --template blank-typescript
cd ../..

# 4. Create Shared ESLint Config
# packages/eslint-config/package.json
{
  "name": "@repo/eslint-config",
  "version": "0.0.0",
  "main": "index.js",
  "dependencies": {
    "eslint-config-next": "latest",
    "eslint-config-prettier": "^9.0.0",
    "eslint-plugin-react": "^7.33.0",
    "eslint": "^8.0.0"
  }
}

# packages/eslint-config/index.js
module.exports = {
  extends: ["next", "prettier", "plugin:react/recommended"],
  rules: {
    "react/react-in-jsx-scope": "off",
  },
};

# 5. Create Shared TypeScript Config
# packages/typescript-config/package.json
{
  "name": "@repo/typescript-config",
  "version": "0.0.0",
  "main": "tsconfig.json",
  "devDependencies": {
    "typescript": "^5.0.0"
  }
}

# packages/typescript-config/base.json
{
  "compilerOptions": {
    "target": "ES2017",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [
      { "name": "next" }
    ]
  }
}

# packages/typescript-config/react-native.json
{
  "extends": "./base.json",
  "compilerOptions": {
    "jsx": "react-native",
    "module": "commonjs",
    "target": "esnext"
  }
}

# 6. Configure Apps to Extend Shared Configs
# apps/web/tsconfig.json
{
  "extends": "@repo/typescript-config/base.json",
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}

# apps/mobile/tsconfig.json
{
  "extends": "@repo/typescript-config/react-native.json",
  "compilerOptions": {
    "strict": true
  },
  "extends": "expo/tsconfig.base"
}

# 7. Verify Linting (Run from root)
# Add script to root package.json
# "lint": "turbo run lint"

# Interactive Challenge: Modify turbo.json
# turbo.json
{
  "$schema": "https://turbo.build/schema.json",
  "globalDependencies": ["**/.env.*local"],
  "pipeline": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": [".next/**", "dist/**"]
    },
    "lint": {},
    "dev": {
      "cache": false,
      "persistent": true
    },
    "build:shared": {
      "dependsOn": ["^build"],
      "inputs": ["packages/**"],
      "outputs": ["dist/**"]
    }
  }
}

# Command to execute only the new pipeline task
turbo run build:shared --filter=@repo/*
