
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import MetricKit
import OSLog
import Combine

// MARK: - Dependencies

/// In a real-world scenario, you might use a specialized telemetry library.
/// Here we define the requirement for a Swift Package Manager dependency.
/*
// Package.swift snippet
dependencies: [
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0"),
    .package(url: "https://github.com/apple/swift-log", from: "1.5.0")
]
*/

// MARK: - Models

/// Represents the specific performance metrics of an AI inference task.
/// Conforms to `Sendable` to safely pass across actor boundaries in Swift 6.
struct AIInferenceMetrics: Sendable, Codable {
    let modelIdentifier: String
    let inferenceLatencyMS: Double
    let tokensPerSecond: Double
    let memoryDeltaMB: Double
    let timestamp: Date
}

/// An enriched telemetry payload that combines system-level MetricKit data
/// with application-specific AI performance data.
struct EnrichedTelemetryPayload: Sendable, Codable {
    let systemMetrics: MXMetricPayloadData
    let aiMetrics: [AIInferenceMetrics]
    let thermalState: ProcessInfo.ThermalState
    let deviceModel: String
}

/// A container for the raw data extracted from MXMetricPayload to ensure 
/// the payload remains Sendable and easily serializable.
struct MXMetricPayloadData: Sendable, Codable {
    let cpuUsage: Double
    let memoryUsageMB: Double
    let diskWriteBytes: Int64
    let fatalErrorCount: Int
}

// MARK: - The Observability Actor

/// `AuraObservabilityManager` is the central authority for telemetry.
/// It is implemented as an `actor` to ensure thread-safe access to the
/// accumulated AI metrics and to prevent data races during MetricKit callbacks.
@available(iOS 18.0, *)
actor AuraObservabilityManager: NSObject, MXMetricManagerSubscriber {
    
    private let logger = Logger(subsystem: "com.aura.ai.observability", category: "Telemetry")
    private var pendingAIInferenceMetrics: [AIInferenceMetrics] = []
    private var metricManager: MXMetricManager?
    
    /// The shared instance for the application.
    static let shared = AuraObservabilityManager()
    
    private override init() {
        super.init()
        self.metricManager = MXMetricManager()
    }
    
    /// Starts the MetricKit subscription.
    /// - Throws: An error if the subscription fails.
    func startMonitoring() throws {
        logger.info("Initializing MetricKit monitoring...")
        try metricManager?.startMonitoring(with: self)
    }
    
    /// Records a new AI inference event.
    /// This is called by the Inference Engine after a model run completes.
    /// - Parameter metrics: The performance data from the specific run.
    func recordInference(metrics: AIInferenceMetrics) {
        pendingAIInferenceMetrics.append(metrics)
        logger.debug("Recorded AI Metrics: \(metrics.modelIdentifier) - \(metrics.inferenceLatencyMS)ms")
        
        // In a real-world app, you might trigger an immediate alert if latency 
        // exceeds a threshold (e.g., > 5000ms).
        if metrics.inferenceLatencyMS > 5000 {
            logger.warning("CRITICAL: High Latency Detected in AI Inference!")
        }
    }
    
    // MARK: - MXMetricManagerSubscriber Implementation
    
    /// This delegate method is called by the OS when a new MetricKit payload is available.
    /// Note: This is called on a background thread by the system.
    nonisolated func didReceive(_ payloads: [MXMetricPayload]) {
        // We use a Task to bridge from the nonisolated delegate method 
        // into our actor's isolated context.
        Task {
            await self.processPayloads(payloads)
        }
    }
    
    /// Processes the incoming MetricKit payloads and correlates them with AI metrics.
    /// - Parameter payloads: The array of payloads provided by the system.
    private func processPayloads(_ payloads: [MXMetricPayload]) {
        for payload in payloads {
            logger.info("Received new MetricKit payload. Processing...")
            
            // 1. Extract System Metrics
            let systemData = extractSystemData(from: payload)
            
            // 2. Correlate with AI Metrics
            // We take all AI metrics recorded since the last payload was processed.
            let correlatedAIStats = self.pendingAIInferenceMetrics
            
            // 3. Construct Enriched Payload
            let enriched = EnrichedTelemetryPayload(
                systemMetrics: systemData,
                aiMetrics: correlatedAIStats,
                thermalState: ProcessInfo.processInfo.thermalState,
                deviceModel: UIDevice.current.model
            )
            
            // 4. Dispatch to Backend
            self.uploadTelemetry(enriched)
            
            // 5. Reset the buffer
            self.pendingAIInferenceMetrics.removeAll()
        }
    }
    
    /// Extracts relevant data from the complex MXMetricPayload object.
    private func extractSystemData(from payload: MXMetricPayload) -> MXMetricPayloadData {
        // In production, you would iterate through payload.app, payload.cpu, etc.
        // For brevity, we simulate the extraction of core metrics.
        let cpu = payload.cpuMetrics?.cumulativeCPUUsage ?? 0.0
        let memory = payload.memoryMetrics?.peakMemoryUsage ?? 0.0
        let disk = payload.diskMetrics?.writeBytes ?? 0
        let errors = payload.fatalErrorCount
        
        return MXMetricPayloadData(
            cpuUsage: cpu,
            memoryUsageMB: Double(memory) / 1_048_576.0, // Convert bytes to MB
            diskWriteBytes: disk,
            fatalErrorCount: errors
        )
    }
    
    /// Simulates uploading the enriched data to a remote telemetry server.
    private func uploadTelemetry(_ payload: EnrichedTelemetryPayload) {
        Task.detached(priority: .background) {
            do {
                let encoder = JSONEncoder()
                encoder.dateEncodingStrategy = .iso8601
                let data = try encoder.encode(payload)
                
                // Simulate Network Request
                try await Task.sleep(for: .seconds(1)) 
                print("Successfully uploaded \(data.count) bytes of enriched telemetry.")
                
                // In a real app: 
                // var request = URLRequest(url: telemetryEndpoint)
                // request.httpMethod = "POST"
                // request.httpBody = data
                // try await URLSession.shared.upload(for: request, from: data)
                
            } catch {
                self.logger.error("Failed to upload telemetry: \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - AI Inference Engine Simulation

/// A mock engine representing a Core ML-based Voice Assistant.
final class AuraInferenceEngine: Sendable {
    
    /// Simulates running an LLM inference task.
    func runInference(prompt: String) async throws -> String {
        let startTime = CFAbsoluteTimeGetCurrent()
        let initialMemory = reportMemory()
        
        // Simulate heavy computational work (ANE/GPU usage)
        try await Task.sleep(for: .milliseconds(800))
        
        let duration = (CFAbsoluteTimeGetCurrent() - startTime) * 1000
        let finalMemory = reportMemory()
        let memoryDelta = (finalMemory - initialMemory) / 1_048_576.0
        
        let result = "Processed: \(prompt)"
        
        // Record the metrics in the observability manager
        let metrics = AIInferenceMetrics(
            modelIdentifier: "aura-llama-3-8b-on-device",
            inferenceLatencyMS: duration,
            tokensPerSecond: 12.5, // Mock value
            memoryDeltaMB: memoryDelta,
            timestamp: Date()
        )
        
        await AuraObservabilityManager.shared.recordInference(metrics: metrics)
        
        return result
    }
    
    /// Helper to get current resident memory size in bytes.
    private func reportMemory() -> Double {
        var taskInfo = mach_task_basic_info()
        var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size) / 4
        let kerr: kern_return_t = withUnsafeMutablePointer(to: &taskInfo) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
            }
        }
        return kerr == KERN_SUCCESS ? Double(taskInfo.resident_size) : 0
    }
}
