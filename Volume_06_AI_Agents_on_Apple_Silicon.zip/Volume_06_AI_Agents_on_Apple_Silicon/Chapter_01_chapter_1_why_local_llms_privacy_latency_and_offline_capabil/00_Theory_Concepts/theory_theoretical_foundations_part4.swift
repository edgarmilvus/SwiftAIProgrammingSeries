
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation

// Explicitly conforming to Sendable (though for simple structs with Sendable members, it's often implicit)
struct Prompt: Sendable {
    let text: String
    let temperature: Float
    let maxTokens: Int
    // No mutable state, all members are Sendable, so Prompt is Sendable.
}

struct LLMResponse: Sendable {
    let generatedText: String
    let tokensUsed: Int
    let duration: TimeInterval
    // No mutable state, all members are Sendable, so LLMResponse is Sendable.
}

// Example of a potentially non-Sendable type that needs care
// class InferenceContextState { // A class is not implicitly Sendable
//     var internalBuffer: [Float] = []
//     // ... if this were passed between tasks, it could cause data races.
// }

// To make a class Sendable, it must be final and its mutable state must be protected
// (e.g., by being part of an actor's isolated state or using locks).
// Or, simply use value types (structs/enums) or actors for shared mutable state.
