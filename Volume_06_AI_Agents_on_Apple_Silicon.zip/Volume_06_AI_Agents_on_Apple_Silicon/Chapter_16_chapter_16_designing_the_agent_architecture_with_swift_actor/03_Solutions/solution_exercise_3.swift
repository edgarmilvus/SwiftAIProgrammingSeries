
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// Swift 6
@available(iOS 18.0, macOS 15.0, *)
// Re-using LLMClientActor and LLMService from Exercise 1
// actor LLMClientActor { ... }
// struct LLMService { ... }

// MARK: - Worker Actors (Tools)

actor SummarizerActor {
    private let llmClient: LLMClientActor

    init(llmClient: LLMClientActor) {
        self.llmClient = llmClient
    }

    func summarize(text: String) async throws -> String {
        print("SummarizerActor: Summarizing text...")
        let prompt = "Summarize the following text concisely: \n\"\(text)\""
        let summary = try await llmClient.sendPrompt(text: prompt)
        // Basic post-processing to make simulated response more specific
        return summary.replacingOccurrences(of: "You asked: '\(prompt)'. This is a generic LLM response.", with: "Summary of the email: \(text.prefix(50))...")
    }
}

actor DraftGeneratorActor {
    private let llmClient: LLMClientActor

    init(llmClient: LLMClientActor) {
        self.llmClient = llmClient
    }

    func generateDraft(originalEmail: String, intent: String) async throws -> String {
        print("DraftGeneratorActor: Generating draft...")
        let prompt = "Draft a polite reply to the following email based on the intent: '\(intent)'.\nOriginal email: \n\"\(originalEmail)\""
        let draft = try await llmClient.sendPrompt(text: prompt)
        // Basic post-processing
        return draft.replacingOccurrences(of: "You asked: '\(prompt)'. This is a generic LLM response.", with: "Draft reply based on intent '\(intent)':")
    }
}

actor SentimentAnalyzerActor {
    private let llmClient: LLMClientActor

    init(llmClient: LLMClientActor) {
        self.llmClient = llmClient
    }

    func analyzeSentiment(text: String) async throws -> String {
        print("SentimentAnalyzerActor: Analyzing sentiment...")
        let prompt = "Analyze the sentiment of the following text. Respond with 'Positive', 'Negative', or 'Neutral' only: \n\"\(text)\""
        let sentiment = try await llmClient.sendPrompt(text: prompt)
        // Simulate a more specific sentiment response parsing
        if sentiment.lowercased().contains("positive") { return "Positive" }
        if sentiment.lowercased().contains("negative") { return "Negative" }
        return "Neutral"
    }
}

// MARK: - Orchestrator Actor

actor EmailAssistantActor {
    private let summarizer: SummarizerActor
    private let draftGenerator: DraftGeneratorActor
    private let sentimentAnalyzer: SentimentAnalyzerActor

    init(llmClient: LLMClientActor) {
        // Each worker actor gets its own LLMClientActor instance,
        // or they could share one if the LLMClientActor itself
        // is designed to handle multiple concurrent requests.
        // For simplicity and clear dependency, each gets one here.
        // (Note: LLMClientActor is thread-safe, so sharing one instance would also be fine).
        self.summarizer = SummarizerActor(llmClient: llmClient)
        self.draftGenerator = DraftGeneratorActor(llmClient: llmClient)
        self.sentimentAnalyzer = SentimentAnalyzerActor(llmClient: llmClient)
    }

    enum AssistantAction {
        case summarize
        case draftReply(intent: String)
        case analyzeSentiment
        case unknown
    }

    /// Determines the action based on user intent.
    private func determineAction(userIntent: String) -> AssistantAction {
        let lowercasedIntent = userIntent.lowercased()
        if lowercasedIntent.contains("summarize") {
            return .summarize
        } else if lowercasedIntent.contains("reply") || lowercasedIntent.contains("draft") {
            return .draftReply(intent: userIntent)
        } else if lowercasedIntent.contains("sentiment") || lowercasedIntent.contains("feel") {
            return .analyzeSentiment
        }
        return .unknown
    }

    /// Handles an email based on a user's explicit intent.
    func handleEmail(emailContent: String, userIntent: String) async throws -> String {
        let action = determineAction(userIntent: userIntent)
        print("EmailAssistantActor: Determined action: \(action)")

        switch action {
        case .summarize:
            return try await summarizer.summarize(text: emailContent)
        case .draftReply(let intent):
            return try await draftGenerator.generateDraft(originalEmail: emailContent, intent: intent)
        case .analyzeSentiment:
            return try await sentimentAnalyzer.analyzeSentiment(text: emailContent)
        case .unknown:
            return "I'm sorry, I don't understand that request. Please try 'summarize', 'draft a reply', or 'analyze sentiment'."
        }
    }
}

// MARK: - Example Usage (e.g., in a Mail.app extension/feature)

@available(iOS 18.0, macOS 15.0, *)
class MailAssistantViewModel: ObservableObject {
    @Published var emailBody: String = "Hi Team,\n\nThe project deadline for Q3 has been moved up to next Friday. Please ensure all outstanding tasks are completed by then. Let me know if you foresee any issues.\n\nThanks,\nManager"
    @Published var userIntent: String = "summarize this email"
    @Published var assistantResponse: String = "Enter email and intent to get started."

    private let emailAssistant: EmailAssistantActor

    init() {
        let llmService = LLMService() // Re-using LLMService
        let llmClient = LLMClientActor(llmService: llmService) // Re-using LLMClientActor
        self.emailAssistant = EmailAssistantActor(llmClient: llmClient)
    }

    func processEmail() {
        Task {
            do {
                let response = try await emailAssistant.handleEmail(emailContent: emailBody, userIntent: userIntent)
                await MainActor.run {
                    self.assistantResponse = response
                }
            } catch {
                await MainActor.run {
                    self.assistantResponse = "Error: \(error.localizedDescription)"
                }
            }
        }
    }
}
