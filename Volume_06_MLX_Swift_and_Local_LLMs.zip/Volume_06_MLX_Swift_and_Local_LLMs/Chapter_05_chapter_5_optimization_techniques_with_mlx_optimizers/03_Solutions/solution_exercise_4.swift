
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

// Package.swift snippet for MLX Swift dependency
// dependencies: [
//     .package(url: "https://github.com/ml-explore/mlx-swift.git", from: "0.0.1")
// ]

import MLX
import MLXNN // For MLXNN.Module, MLXNN.Linear

@available(iOS 18.0, macOS 15.0, *)
func exercise4_actorCriticAgent() {
    let stateDim = 4 // e.g., position (x,y), velocity (vx,vy)
    let numActions = 2 // e.g., move left, move right

    // 1. Define the Environment (Simplified Simulation)
    class SimpleGameEnvironment {
        let stateDim: Int
        let numActions: Int
        var currentState: MLXArray // Current state of the environment
        var episodeStep: Int // Current step within an episode

        init(stateDim: Int, numActions: Int) {
            self.stateDim = stateDim
            self.numActions = numActions
            // Initialize state to zeros, will be randomized on reset
            self.currentState = MLXArray.zeros([stateDim], dtype: .float32)
            self.episodeStep = 0
        }

        // Resets the environment to a new random initial state
        func reset() -> MLXArray {
            currentState = MLXArray.random([stateDim], min: -1.0, max: 1.0, stream: .current, dtype: .float32)
            episodeStep = 0
            return currentState
        }

        // Takes an action and returns the next state, reward, and if the episode is done
        func step(action: Int) -> (MLXArray, Float, Bool) {
            episodeStep += 1
            var reward: Float = 0.0
            var isDone: Bool = false

            // Simple simulation logic: agent tries to bring state values closer to zero
            // Reward is higher if the state is closer to zero
            let distanceToTarget = sum(currentState.square()).item(Float.self)!
            reward = 1.0 - distanceToTarget // Max reward 1.0 when state is all zeros

            // Randomly update state based on action
            let actionEffect = MLXArray.random([stateDim], min: -0.1, max: 0.1, stream: .current, dtype: .float32)
            if action == 0 { // Action 0: try to decrease state values
                currentState = currentState - actionEffect
            } else { // Action 1: try to increase state values
                currentState = currentState + actionEffect
            }

            // Episode ends after a fixed number of steps or if target is reached
            if episodeStep >= 10 || distanceToTarget < 0.1 {
                isDone = true
            }

            return (currentState, reward, isDone)
        }
    }

    // 2. Define the Actor Network (Policy Network)
    class ActorNetwork: MLXNN.Module {
        let fc1, fc2: MLXNN.Linear
        init(stateDim: Int, numActions: Int) {
            self.fc1 = MLXNN.Linear(inputFeatures: stateDim, outputFeatures: 64)
            self.fc2 = MLXNN.Linear(inputFeatures: 64, outputFeatures: numActions)
            super.init()
        }
        func callAsFunction(_ state: MLXArray) -> MLXArray {
            let x = relu(fc1(state))
            // Softmax converts logits to a probability distribution over actions
            return softmax(fc2(x), axis: -1)
        }
    }

    // 3. Define the Critic Network (Value Network)
    class CriticNetwork: MLXNN.Module {
        let fc1, fc2: MLXNN.Linear
        init(stateDim: Int) {
            self.fc1 = MLXNN.Linear(inputFeatures: stateDim, outputFeatures: 64)
            self.fc2 = MLXNN.Linear(inputFeatures: 64, outputFeatures: 1) // Outputs a single scalar value
            super.init()
        }
        func callAsFunction(_ state: MLXArray) -> MLXArray {
            let x = relu(fc1(state))
            // No activation on the final layer for value prediction (continuous output)
            return fc2(x)
        }
    }

    // 4. Implement the Training Loop (Simplified A2C-like)
    let env = SimpleGameEnvironment(stateDim: stateDim, numActions: numActions)
    let actor = ActorNetwork(stateDim: stateDim, numActions: numActions)
    let critic = CriticNetwork(stateDim: stateDim)

    let actorLearningRate: Float = 0.001
    let criticLearningRate: Float = 0.005
    let gamma: Float = 0.99 // Discount factor for future rewards

    // Initialize separate optimizers for Actor and Critic
    let actorOptimizer = MLXOptimizers.Adam(learningRate: actorLearningRate)
    let criticOptimizer = MLXOptimizers.RMSprop(learningRate: criticLearningRate)

    let numEpisodes = 500
    var totalRewards: [Float] = []

    print("Starting Actor-Critic training...")

    for episode in 0..<numEpisodes {
        var state = env.reset()
        var episodeReward: Float = 0.0
        var isDone = false
        var logProbActions: [MLXArray] = [] // Log probabilities of chosen actions
        var values: [MLXArray] = []         // State value estimates from Critic
        var rewards: [Float] = []           // Rewards collected in the episode

        // Collect an episode's worth of experience
        while !isDone {
            // Actor predicts action probabilities
            let actionProbs = actor(state)
            // Sample an action (for simplicity, argmax is used here, but categorical sampling is more common in RL)
            let action = actionProbs.argmax(axis: -1).item(Int.self)!
            
            // Store log probability of the chosen action for Actor loss
            logProbActions.append(log(actionProbs.take(action, axis: -1)))
            
            // Critic estimates the value of the current state
            values.append(critic(state))

            // Take a step in the environment
            let (nextState, reward, done) = env.step(action: action)
            rewards.append(reward)
            episodeReward += reward
            isDone = done
            state = nextState
        }

        // Convert collected data into MLXArrays for batch processing
        let valuesTensor = MLXArray.stack(values)
        let logProbActionsTensor = MLXArray.stack(logProbActions)
        
        // Calculate discounted returns (G_t = R_t + gamma * R_{t+1} + ...)
        var returns: [MLXArray] = Array(repeating: MLXArray(0.0), count: rewards.count)
        var G: Float = 0.0
        for i in (0..<rewards.count).reversed() {
            G = rewards[i] + gamma * G
            returns[i] = MLXArray(G, dtype: .float32)
        }
        let returnsTensor = MLXArray.stack(returns)

        // --- Critic Update ---
        // Critic Loss: Mean Squared Error between predicted values and actual discounted returns
        let (criticLoss, criticGradients) = valueAndGradient(model: critic) { criticModel in
            return (valuesTensor - returnsTensor).square().mean()
        }
        criticOptimizer.update(model: critic, gradients: criticGradients)

        // --- Actor Update ---
        // Advantage: How much better the action was than expected (returns - baseline value)
        // .detached() is crucial: prevents gradients from flowing from actor loss back into the critic
        let advantage = returnsTensor - valuesTensor.detached() 
        // Actor Loss: Minimize negative log probability of action multiplied by advantage
        // (Equivalent to maximizing log_prob * advantage)
        let (actorLoss, actorGradients) = valueAndGradient(model: actor) { actorModel in
            return -(logProbActionsTensor * advantage).mean()
        }
        actorOptimizer.update(model: actor, gradients: actorGradients)

        totalRewards.append(episodeReward)

        if episode % 50 == 0 {
            let avgReward = totalRewards.suffix(50).reduce(0, +) / Float(min(50, totalRewards.count))
            print("Episode \(episode), Avg Reward (last 50): \(avgReward), Actor Loss: \(actorLoss.item(Float.self)!), Critic Loss: \(criticLoss.item(Float.self)!)")
        }
    }
    print("\nActor-Critic training complete.")
}
