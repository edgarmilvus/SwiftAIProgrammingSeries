
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import SwiftUI
import TextGeneration

@available(iOS 18.0, *)
struct DocumentView: View {
    let documentContent: String // The full text of the document
    @State private var suggestedTags: [String] = []
    @State private var isLoadingTags = false
    @State private var selectedTags: Set<String> = [] // User-selected tags for this document
    @State private var isTextGenerationAvailable = TextGenerationService.shared.isAvailable
    @State private var showingErrorAlert = false
    @State private var errorMessage: String = ""

    var body: some View {
        VStack {
            ScrollView {
                Text(documentContent)
                    .font(.body)
                    .padding()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity) // Make scroll view take available space

            if isLoadingTags {
                ProgressView("Analyzing document for tags...")
                    .padding()
                    .transition(.opacity)
            } else if !suggestedTags.isEmpty {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("AI-Suggested Tags:")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Spacer()
                        Button("Dismiss Suggestions") {
                            suggestedTags = [] // Clear suggestions
                        }
                        .font(.caption)
                        .buttonStyle(.plain)
                        .foregroundColor(.secondary)
                    }
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(suggestedTags, id: \.self) { tag in
                                Button(action: {
                                    if selectedTags.contains(tag) {
                                        selectedTags.remove(tag)
                                    } else {
                                        selectedTags.insert(tag)
                                    }
                                }) {
                                    Text(tag)
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 5)
                                        .background(selectedTags.contains(tag) ? Color.accentColor : Color.gray.opacity(0.2))
                                        .foregroundColor(selectedTags.contains(tag) ? .white : .primary)
                                        .cornerRadius(15)
                                }
                            }
                        }
                    }
                }
                .padding([.horizontal, .bottom])
                .transition(.opacity.combined(with: .move(edge: .bottom))) // Smooth transition
            }
            // Display currently selected tags (for demonstration)
            Text("User Selected Tags: \(selectedTags.sorted().joined(separator: ", "))")
                .font(.footnote)
                .foregroundColor(.secondary)
                .padding(.bottom)
        }
        .navigationTitle("Document Details")
        .navigationBarTitleDisplayMode(.inline)
        .animation(.easeInOut(duration: 0.2), value: isLoadingTags)
        .animation(.easeInOut(duration: 0.2), value: suggestedTags)
        .onAppear {
            // Observe availability changes
            NotificationCenter.default.addObserver(forName: TextGenerationService.availabilityDidChangeNotification, object: nil, queue: .main) { _ in
                isTextGenerationAvailable = TextGenerationService.shared.isAvailable
            }
            // Trigger tag generation when document view appears
            Task {
                await generateTags()
            }
        }
        .onDisappear {
            // Clean up observer
            NotificationCenter.default.removeObserver(self, name: TextGenerationService.availabilityDidChangeNotification, object: nil)
        }
        .alert("Error", isPresented: $showingErrorAlert) {
            Button("OK") { }
        } message: {
            Text(errorMessage)
        }
    }

    private func generateTags() async {
        guard isTextGenerationAvailable else {
            errorMessage = "Text Generation Service is not available on this device."
            showingErrorAlert = true
            return
        }
        // Only generate if not already loading
        guard !isLoadingTags else { return }

        isLoadingTags = true
        suggestedTags = []

        // Truncate document content if too long for prompt efficiency
        // A common practice is to take a prefix and a suffix to capture main ideas
        let maxPromptLength = 4000 // Example limit, adjust as needed for model context window
        let contentForPrompt: String
        if documentContent.count > maxPromptLength {
            let prefixLength = maxPromptLength / 2
            let suffixLength = maxPromptLength - prefixLength
            let prefix = documentContent.prefix(prefixLength)
            let suffix = documentContent.suffix(suffixLength)
            contentForPrompt = "\(prefix)\n...\n\(suffix)" // Indicate truncation
        } else {
            contentForPrompt = documentContent
        }

        // Prompt engineering for structured output and specific categories/tags
        let prompt = """
        Analyze the following document content and suggest 3-5 relevant tags or a primary category.
        Respond with a comma-separated list of tags/categories.
        Consider categories like: "Finance", "Technology", "Personal", "Legal", "Education", "Health", "Travel", "Business", "Marketing", "Research".

        Document Content:
        \(contentForPrompt)

        Suggested Tags/Category:
        """

        let request = TextGenerationRequest(prompt: prompt)
        request.options.maxTokens = 50 // Limit the output length for tags
        request.options.temperature = 0.5 // Keep it focused and less creative
        request.options.topP = 0.8 // Allow some diversity but keep it on topic

        do {
            let result = try await TextGenerationService.shared.generate(request)
            if let generatedText = result.text, !generatedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                let parsedTags = generatedText.split(separator: ",").map {
                    $0.trimmingCharacters(in: .whitespacesAndNewlines)
                }.filter { !$0.isEmpty }

                if !parsedTags.isEmpty {
                    suggestedTags = parsedTags
                } else {
                    errorMessage = "No relevant tags could be generated."
                    showingErrorAlert = true
                }
            } else {
                errorMessage = "No tags generated."
                showingErrorAlert = true
            }
        } catch {
            errorMessage = "Error generating tags: \(error.localizedDescription)"
            showingErrorAlert = true
            print("Error generating tags: \(error.localizedDescription)")
        }
        isLoadingTags = false
    }
}

// Example usage in a parent view:
@available(iOS 18.0, *)
struct DocumentView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            DocumentView(documentContent: """
                This report details the quarterly financial performance of Tech Innovations Inc. for the fiscal year 2024. Key highlights include a 15% increase in revenue driven by strong sales in our AI software division and a successful launch of the new cloud computing platform. Operating expenses saw a slight increase due to investments in research and development for quantum computing initiatives. Net profit reached an all-time high, exceeding analyst expectations. The board approved a new share buyback program.
                """)
        }
        .previewDisplayName("Financial Report")

        NavigationView {
            DocumentView(documentContent: """
                A personal reflection on the transformative power of mindfulness practices. This diary entry explores the benefits of daily meditation, improved focus, and reduced stress levels experienced over the past six months. It discusses techniques for cultivating presence and gratitude in everyday life, and how these practices have positively impacted personal relationships and overall well-being.
                """)
        }
        .previewDisplayName("Personal Reflection")
    }
}
