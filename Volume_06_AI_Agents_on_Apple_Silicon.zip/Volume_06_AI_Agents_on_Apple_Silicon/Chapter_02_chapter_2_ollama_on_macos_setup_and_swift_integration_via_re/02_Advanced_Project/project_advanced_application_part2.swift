
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

// swift-tools-version:6.0
import PackageDescription

let package = Package(
    name: "OllamaContractAnalyzer",
    platforms: [
        .macOS(.v12), // Requires macOS 12+ for async/await
        // .iOS(.v15), // Or iOS 15+ if building for mobile
    ],
    products: [
        .executable(name: "ContractAnalyzerApp", targets: ["ContractAnalyzerApp"]),
    ],
    dependencies: [
        // Example: If you needed more advanced async stream operators
        // .package(url: "https://github.com/apple/swift-async-algorithms", from: "1.0.0"),
        // Example: If you preferred a dedicated HTTP client library
        // .package(url: "https://github.com/Alamofire/Alamofire", from: "5.8.1")
    ],
    targets: [
        .executableTarget(
            name: "ContractAnalyzerApp",
            dependencies: [
                // .product(name: "AsyncAlgorithms", package: "swift-async-algorithms"), // If using AsyncAlgorithms
                // .product(name: "Alamofire", package: "Alamofire"), // If using Alamofire
            ],
            path: "Sources/ContractAnalyzerApp" // Assuming your main.swift is here
        ),
    ]
)
