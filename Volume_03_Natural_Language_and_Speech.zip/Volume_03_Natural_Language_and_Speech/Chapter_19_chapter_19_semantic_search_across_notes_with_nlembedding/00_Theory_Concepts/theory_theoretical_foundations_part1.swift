
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift snippet for NaturalLanguage dependency (if not already included)
// .package(name: "NaturalLanguage", path: "path/to/NaturalLanguage.xcframework"),

import NaturalLanguage // Requires iOS 14.0+ for NLEmbedding

@available(iOS 18.0, *) // NLEmbedding has been available since iOS 14, but async/await usage might imply newer OS versions for convenience.
func generateEmbedding(for text: String) async throws -> [Float] {
    // Check if the document model is supported on the current device.
    // NLEmbedding.document is available since iOS 14.0
    guard NLEmbedding.document.isAvailable else {
        throw EmbeddingError.modelNotAvailable
    }

    let embeddingGenerator = NLEmbedding.document
    // The maximum length of text that can be processed by the embedding model.
    // Texts longer than this will be truncated.
    let maxLength = NLEmbedding.maximumEmbeddingLength

    // Truncate text if it exceeds the maximum supported length
    let processedText = String(text.prefix(maxLength))

    // Asynchronously generate the embedding for the given text.
    let embedding = try await embeddingGenerator.embedding(for: processedText)
    return embedding
}

enum EmbeddingError: Error {
    case modelNotAvailable
    case embeddingGenerationFailed
}
