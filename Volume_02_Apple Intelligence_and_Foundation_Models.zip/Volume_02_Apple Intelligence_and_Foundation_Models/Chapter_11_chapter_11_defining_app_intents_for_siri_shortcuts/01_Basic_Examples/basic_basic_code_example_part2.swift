
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation

/// A mock data store for managing reminders.
/// In a real app, this would interact with a persistent data layer.
class ReminderStore {
    // A simple in-memory array to hold our reminders.
    // Making it static ensures a single source of truth for all intents.
    static var shared = ReminderStore() // Singleton instance

    private var reminders: [Reminder] = [
        Reminder(title: "Buy groceries", isCompleted: false),
        Reminder(title: "Call mom", isCompleted: false),
        Reminder(title: "Finish App Intents chapter", isCompleted: false),
        Reminder(title: "Walk the dog", isCompleted: true) // Example of a completed one
    ]

    private init() {} // Private initializer for singleton

    /// Adds a new reminder to the store.
    func addReminder(_ reminder: Reminder) {
        reminders.append(reminder)
    }

    /// Retrieves all reminders.
    func getAllReminders() -> [Reminder] {
        return reminders.sorted { $0.creationDate > $1.creationDate }
    }

    /// Finds a reminder by its ID.
    func findReminder(by id: UUID) -> Reminder? {
        return reminders.first { $0.id == id }
    }

    /// Updates an existing reminder.
    /// - Returns: The updated reminder if found, otherwise nil.
    func updateReminder(_ updatedReminder: Reminder) -> Reminder? {
        if let index = reminders.firstIndex(where: { $0.id == updatedReminder.id }) {
            reminders[index] = updatedReminder
            return reminders[index]
        }
        return nil
    }

    /// Deletes a reminder by its ID.
    /// - Returns: True if the reminder was deleted, false otherwise.
    func deleteReminder(by id: UUID) -> Bool {
        let initialCount = reminders.count
        reminders.removeAll { $0.id == id }
        return reminders.count < initialCount
    }
}
