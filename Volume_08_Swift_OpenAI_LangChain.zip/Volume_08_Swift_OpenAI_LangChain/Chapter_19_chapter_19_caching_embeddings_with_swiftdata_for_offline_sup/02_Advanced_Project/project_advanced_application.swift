
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import SwiftData
import Accelerate
import Observation

// MARK: - Package Dependencies
/*
 To use this in a real project, your Package.swift would include:
 .package(url: "https://github.com/openai/openai-swift", from: "1.0.0")
 .package(url: "https://github.com/langchain-ai/langchain-swift", from: "0.1.0")
*/

// MARK: - Error Definitions

/// Errors specific to the semantic caching and embedding lifecycle.
enum SemanticError: Error, LocalizedError {
    case embeddingGenerationFailed(String)
    case databaseContextError(String)
    case vectorDimensionMismatch(expected: Int, actual: Int)
    case unauthorized
    
    var errorDescription: String? {
        switch self {
        case .embeddingGenerationFailed(let msg): return "Failed to generate embedding: \(msg)"
        case .databaseContextError(let msg): return "SwiftData Error: \(msg)"
        case .vectorDimensionMismatch(let e, let a): return "Dimension mismatch: Expected \(e), got \(a)"
        case .unauthorized: return "API Key is missing or invalid."
        }
    }
}

// MARK: - Data Model

/// Represents a piece of text and its corresponding high-dimensional vector.
/// We use `@Model` to enable SwiftData persistence.
@available(iOS 18.0, *)
@Model
final class EmbeddingRecord {
    /// The unique identifier for the text content (e.g., a hash of the text).
    @Attribute(.unique) var textHash: String
    
    /// The raw text content.
    var content: String
    
    /// The embedding vector stored as an array of Floats.
    /// SwiftData handles the serialization of [Float] automatically.
    var vector: [Float]
    
    /// Metadata for cache invalidation (e.g., when the model version changes).
    var modelIdentifier: String
    
    /// Timestamp of when this embedding was generated.
    var createdAt: Date

    init(textHash: String, content: String, vector: [Float], modelIdentifier: String) {
        self.textHash = textHash
        self.content = content
        self.vector = vector
        self.modelIdentifier = modelIdentifier
        self.createdAt = Date()
    }
}

// MARK: - Vector Math Engine

/// A utility providing high-performance linear algebra operations.
/// Uses Apple's Accelerate framework to leverage the CPU's SIMD instructions.
enum VectorMath {
    /// Calculates the Cosine Similarity between two vectors.
    /// Formula: (A · B) / (||A|| * ||B||)
    /// - Returns: A value between -1.0 and 1.0 (1.0 being identical).
    static func cosineSimilarity(_ v1: [Float], _ v2: [Float]) -> Float {
        guard v1.count == v2.count else { return 0.0 }
        
        var dotProduct: Float = 0.0
        vDSP_dotpr(v1, 1, v2, 1, &dotProduct, vDSP_Length(v1.count))
        
        var v1Magnitude: Float = 0.0
        vDSP_svesq(v1, 1, &v1Magnitude, vDSP_Length(v1.count))
        v1Magnitude = sqrt(v1Magnitude)
        
        var v2Magnitude: Float = 0.0
        vDSP_svesq(v2, 1, &v2Magnitude, vDSP_Length(v2.count))
        v2Magnitude = sqrt(v2Magnitude)
        
        let denominator = v1Magnitude * v2Magnitude
        return denominator == 0 ? 0 : dotProduct / denominator
    }
}

// MARK: - Semantic Cache Manager

/// The central orchestrator for managing embeddings and performing local semantic search.
/// Implemented as an `actor` to ensure thread-safety when accessing SwiftData 
/// and performing heavy mathematical computations.
@available(iOS 18.0, *)
actor SemanticCacheManager {
    
    private let modelContainer: ModelContainer
    private let modelIdentifier: String = "text-embedding-3-small"
    private let vectorDimension: Int = 1536
    
    /// Initializes the manager with a SwiftData container.
    /// - Parameter container: The ModelContainer used for persistence.
    init(container: ModelContainer) {
        self.modelContainer = container
    }
    
    /// Performs a semantic search: checks cache, fetches new embeddings if needed, and ranks results.
    /// - Parameters:
    ///   - query: The user's natural language query.
    ///   - limit: The maximum number of results to return.
    /// - Returns: An array of tuples containing the content and its similarity score.
    func semanticSearch(for query: String, limit: Int = 5) async throws -> [(content: String, score: Float)] {
        // 1. Generate embedding for the query
        let queryVector = try await getOrCreateEmbedding(for: query)
        
        // 2. Fetch all records from SwiftData
        // Note: In a massive production app, you would use a more sophisticated 
        // vector indexing approach, but for local mobile apps, scanning the 
        // local store is extremely efficient.
        let context = ModelContext(modelContainer)
        let descriptor = FetchDescriptor<EmbeddingRecord>()
        let allRecords = try context.fetch(descriptor)
        
        // 3. Calculate similarity using Accelerate
        let results = allRecords.map { record -> (content: String, score: Float) in
            let similarity = VectorMath.cosineSimilarity(queryVector, record.vector)
            return (record.content, similarity)
        }
        
        // 4. Sort and return top K
        return results
            .sorted { $0.score > $1.score }
            .prefix(limit)
            .map { $0 }
    }
    
    /// Retrieves an existing embedding from SwiftData or fetches a new one from the API.
    /// - Parameter text: The text to embed.
    /// - Returns: The [Float] vector representation.
    private func getOrCreateEmbedding(for text: String) async throws -> [Float] {
        let hash = text.sha256Hash() // Assume a helper exists for hashing
        let context = ModelContext(modelContainer)
        
        // Check if we already have this in our local cache
        let predicate = #Predicate<EmbeddingRecord> { $0.textHash == hash }
        var descriptor = FetchDescriptor<EmbeddingRecord>(predicate: predicate)
        descriptor.fetchLimit = 1
        
        if let cachedRecord = try context.fetch(descriptor).first {
            print("DEBUG: Cache Hit for hash \(hash)")
            return cachedRecord.vector
        }
        
        print("DEBUG: Cache Miss. Fetching from OpenAI...")
        // Simulate API Call
        let newVector = try await mockOpenAIEmbeddingCall(for: text)
        
        // Persist the new embedding for future offline use
        let newRecord = EmbeddingRecord(
            textHash: hash,
            content: text,
            vector: newVector,
            modelIdentifier: modelIdentifier
        )
        context.insert(newRecord)
        try context.save()
        
        return newVector
    }
    
    /// A simulated network call to an embedding provider.
    private func mockOpenAIEmbeddingCall(for text: String) async throws -> [Float] {
        // In a real app, use URLSession to call OpenAI's /v1/embeddings endpoint
        try await Task.sleep(for: .seconds(1.5)) 
        
        // Returning a dummy vector of the correct dimension
        return (0..<vectorDimension).map { _ in Float.random(in: -1...1) }
    }
}

// MARK: - Helpers

extension String {
    /// A simplified hash for demonstration purposes. 
    /// In production, use CryptoKit to generate a real SHA256.
    func sha256Hash() -> String {
        return String(self.hashValue)
    }
}

// MARK: - Usage Example (View Model Context)

@available(iOS 18.0, *)
@Observable
class SearchViewModel {
    var query: String = ""
    var results: [(content: String, score: Float)] = []
    var isSearching: Bool = false
    var errorMessage: String?
    
    private let cacheManager: SemanticCacheManager
    
    init(cacheManager: SemanticCacheManager) {
        self.cacheManager = cacheManager
    }
    
    @MainActor
    func performSearch() async {
        guard !query.isEmpty else { return }
        
        isSearching = true
        errorMessage = nil
        
        do {
            results = try await cacheManager.semanticSearch(for: query)
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isSearching = false
    }
}
