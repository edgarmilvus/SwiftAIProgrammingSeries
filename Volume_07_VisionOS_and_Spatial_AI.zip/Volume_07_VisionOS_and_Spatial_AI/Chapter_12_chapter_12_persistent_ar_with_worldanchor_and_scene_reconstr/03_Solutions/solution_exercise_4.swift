
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import ARKit
import RealityKit
import SwiftUI

@MainActor
class IntelligentAgentManager: ObservableObject {
    let session = ARKitSession()
    let sceneReconstruction = SceneReconstructionProvider()
    
    // The "Pet" Entity
    var pet: ModelEntity?

    func setupPet(in content: RealityViewContent) {
        let mesh = MeshResource.generateSphere(radius: 0.1)
        let material = SimpleMaterial(color: .red, isMetallic: true)
        let entity = ModelEntity(mesh: mesh, materials: [material])
        
        // 1. Enable Physics and Collision for the pet
        entity.physicsBody = PhysicsBodyComponent(massProperties: .default, material: .default, mode: .dynamic)
        entity.collision = CollisionComponent(shapes: [.generateSphere(radius: 0.1)])
        
        self.pet = entity
        content.add(entity)
    }

    func startEnvironmentIntelligence(in content: RealityViewContent) async {
        do {
            try await session.run([sceneReconstruction])
            
            for await anchor in sceneReconstruction.anchors {
                await updateEnvironment(anchor: anchor, in: content)
            }
        } catch {
            print("Intelligence setup failed: \(error)")
        }
    }

    private func updateEnvironment(anchor: MeshAnchor, in content: RealityViewContent) async {
        guard let meshResource = try? MeshResource.generate(from: anchor.geometry) else { return }
        
        // 2. Create the Mesh Entity for Occlusion and Collision
        let meshEntity = ModelEntity()
        
        // 3. Apply OcclusionMaterial: This makes the mesh "invisible" but blocks things behind it
        meshEntity.model = ModelComponent(mesh: meshResource, materials: [OcclusionMaterial()])
        
        // 4. Apply Collision: This allows the pet to "bump" into the real world
        // We use .generateStaticMesh for high-fidelity collision with the room
        meshEntity.collision = CollisionComponent(shapes: [.generateStaticMesh(from: meshResource)])
        
        meshEntity.transform = Transform(matrix: anchor.originFromAnchorTransform)
        
        // Add/Update the mesh in the scene
        // (In practice, use a dictionary to manage these to prevent duplicate entities)
        content.add(meshEntity)
    }
}
