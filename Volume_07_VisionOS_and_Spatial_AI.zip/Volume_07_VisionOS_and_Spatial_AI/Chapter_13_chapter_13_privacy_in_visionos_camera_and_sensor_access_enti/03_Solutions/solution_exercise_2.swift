
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import ARKit
import Observation

/// Represents the various stages of spatial permission lifecycle.
enum SpatialPermissionState: String, Sendable {
    case undetermined
    case checking
    case authorized
    case partialAuthorization // e.g., Scene works, but Hands do not
    case denied
    case restricted
}

@MainActor
@Observable
class SpatialSessionController {
    private(set) var state: SpatialPermissionState = .undetermined
    private var session = ARKitSession()
    
    // Providers
    private let sceneProvider = SceneReconstructionProvider()
    private let handProvider = HandTrackingProvider()
    
    /// Orchestrates the request for all necessary spatial permissions.
    func requestSpatialAccess() async {
        state = .checking
        
        // We use a TaskGroup to attempt to start both providers concurrently.
        // This is more efficient than awaiting them sequentially.
        await withTaskGroup(of: Result<Void, Error>.self) { group in
            
            // Task 1: Scene Reconstruction
            group.addTask {
                do {
                    try await self.session.run([self.sceneProvider])
                    return .success(())
                } catch {
                    return .failure(error)
                }
            }
            
            // Task 2: Hand Tracking
            group.addTask {
                do {
                    try await self.session.run([self.handProvider])
                    return .success(())
                } catch {
                    return .failure(error)
                }
            }
            
            var sceneSuccess = false
            var handSuccess = false
            
            for await result in group {
                switch result {
                case .success:
                    // We don't know which one succeeded immediately, 
                    // so we track successes via the specific provider logic.
                    // For this exercise, let's assume we track individual success.
                    break 
                case .failure(let error):
                    handleError(error)
                }
            }
            
            // In a real implementation, we would check the individual success 
            // of the providers to determine the state.
            determineFinalState()
        }
    }
    
    private func handleError(_ error: Error) {
        if let arkitError = error as? ARKitError, arkitError == .missingEntitlement {
            // This is a privacy denial
            print("Privacy denial detected: \(error.localizedDescription)")
        }
    }
    
    private func determineFinalState() {
        // Logic to evaluate if we are in .authorized or .partialAuthorization
        // For demonstration:
        // If sceneProvider.isSupported && handProvider.isSupported -> .authorized
        // If sceneProvider.isSupported && !handProvider.isSupported -> .partialAuthorization
        // Else -> .denied
        
        // Mocking the logic for the sake of the exercise:
        let sceneIsRunning = true // Assume successful
        let handIsRunning = false // Assume denied
        
        if sceneIsRunning && handIsRunning {
            state = .authorized
        } else if sceneIsRunning && !handIsRunning {
            state = .partialAuthorization
        } else {
            state = .denied
        }
    }
}
