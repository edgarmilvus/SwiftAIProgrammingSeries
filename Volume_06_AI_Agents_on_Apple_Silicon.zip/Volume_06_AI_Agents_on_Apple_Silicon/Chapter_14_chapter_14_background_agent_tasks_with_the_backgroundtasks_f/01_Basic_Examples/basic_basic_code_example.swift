
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import UIKit
import BackgroundTasks // Required for BackgroundTasks framework
import Foundation // For Date, etc.

// MARK: - PhotoAnalyzerAgent: Encapsulates Background Task Logic

/// A singleton class responsible for registering, scheduling, and handling background photo analysis tasks.
/// This agent simulates analyzing new photos with a local AI model.
@available(iOS 13.0, *) // BackgroundTasks framework is available from iOS 13.0
class PhotoAnalyzerAgent {

    // MARK: - Constants

    /// The unique identifier for our background photo processing task.
    /// This MUST match an entry in your app's Info.plist under `BGTaskSchedulerPermittedIdentifiers`.
    static let photoProcessingTaskIdentifier = "com.example.smartphotoorganizer.photoprocessing"

    // MARK: - Singleton Instance

    /// The shared singleton instance of the PhotoAnalyzerAgent.
    static let shared = PhotoAnalyzerAgent()

    // Private initializer to enforce singleton pattern.
    private init() {
        print("PhotoAnalyzerAgent initialized.")
    }

    // MARK: - Task Registration

    /// Registers all background tasks with the system.
    /// This should be called early in the app's lifecycle, typically in `application(_:didFinishLaunchingWithOptions:)`.
    func registerTasks() {
        // Register the photo processing background task.
        // The handler block will be executed by the system when the task is launched.
        BGTaskScheduler.shared.register(forTaskWithIdentifier: PhotoAnalyzerAgent.photoProcessingTaskIdentifier, using: nil) { task in
            // Downcast the generic BGTask to BGProcessingTask as we registered it as such.
            guard let processingTask = task as? BGProcessingTask else {
                print("Error: Task received is not a BGProcessingTask.")
                task.setTaskCompleted(success: false)
                return
            }
            print("Received background processing task: \(processingTask.identifier)")
            // Call our dedicated handler for this task.
            self.handlePhotoAnalysisTask(task: processingTask)
        } completion: { success, error in
            if success {
                print("Successfully registered background task handler.")
            } else if let error = error {
                print("Failed to register background task handler: \(error.localizedDescription)")
            }
        }
    }

    // MARK: - Task Scheduling

    /// Schedules a background photo analysis task to run in the future.
    /// This should be called whenever the app enters the background or when data changes.
    func schedulePhotoAnalysisTask() {
        // Create a new background processing task request.
        let request = BGProcessingTaskRequest(identifier: PhotoAnalyzerAgent.photoProcessingTaskIdentifier)

        // Set the earliest date and time the task can run.
        // For demonstration, we'll try to run it soon. In a real app, this might be hours later.
        request.earliestBeginDate = Date(timeIntervalSinceNow: 15 * 60) // Try to run in 15 minutes.

        // Configure task requirements.
        // For local AI inference, network connectivity might not be required.
        request.requiresNetworkConnectivity = false
        // If the AI model is very resource-intensive, requiring external power is a good idea
        // to prevent battery drain. For a basic example, we'll set it to false.
        request.requiresExternalPower = false

        do {
            // Submit the task request to the system.
            try BGTaskScheduler.shared.submit(request)
            print("Successfully scheduled background photo analysis task.")
            print("Task identifier: \(request.identifier)")
            print("Earliest begin date: \(request.earliestBeginDate ?? Date())")
        } catch {
            print("Could not schedule background photo analysis task: \(error.localizedDescription)")
        }
    }

    // MARK: - Task Handling Logic

    /// The main handler for the background photo analysis task.
    /// This is where the actual AI work would take place.
    /// - Parameter task: The `BGProcessingTask` instance provided by the system.
    private func handlePhotoAnalysisTask(task: BGProcessingTask) {
        print("Starting photo analysis in background...")

        // Create an OperationQueue or a TaskGroup for concurrent work if needed.
        // For simplicity, we'll use a single async Task.
        let operationQueue = OperationQueue()
        operationQueue.maxConcurrentOperationCount = 1 // Limit concurrency for this example

        // Define the work to be done in the background.
        // This is where your AI model inference logic would go.
        let photoAnalysisOperation = BlockOperation { [weak self] in
            guard let self = self else { return }
            Task {
                await self.performAIPhotoAnalysis()
                // Once the analysis is complete, mark the task as finished.
                // It's crucial to call setTaskCompleted, otherwise, the system will terminate
                // your app for not completing the task, and future tasks may not be scheduled.
                task.setTaskCompleted(success: true)
                print("Photo analysis task completed successfully.")
            }
        }

        // Set an expiration handler. If the system decides to revoke the task's time budget
        // (e.g., due to low battery, user starting a game), this handler will be called.
        // You MUST stop all work and call setTaskCompleted(success: false) here.
        task.expirationHandler = {
            operationQueue.cancelAllOperations() // Stop any ongoing work.
            task.setTaskCompleted(success: false)
            print("Background photo analysis task expired. Work was interrupted.")
        }

        // Add the operation to the queue to start the work.
        operationQueue.addOperation(photoAnalysisOperation)
    }

    /// Simulates the asynchronous process of performing AI-driven photo analysis.
    /// In a real app, this would involve:
    /// 1. Fetching new photos from the Photo Library (e.g., using `PHPhotoLibrary`).
    /// 2. Loading a local AI model (e.g., `MLModel`, `CoreML`, `llama.cpp` bindings).
    /// 3. Running inference on the photos.
    /// 4. Storing the results (tags, descriptions) locally (e.g., Core Data, Realm).
    private func performAIPhotoAnalysis() async {
        print("Simulating AI photo analysis...")
        // Simulate fetching new photos (e.g., 5 photos)
        let newPhotosCount = Int.random(in: 1...10)
        print("Found \(newPhotosCount) new photos to analyze.")

        for i in 1...newPhotosCount {
            // Simulate processing each photo with an AI model.
            // This could be loading an image, converting it to a tensor,
            // passing it to your local VLM, and getting results.
            print("  - Analyzing photo \(i)...")
            try? await Task.sleep(for: .seconds(Double.random(in: 0.5...2.0))) // Simulate AI inference time
            print("  - Photo \(i) analyzed. Tags: [\"Nature\", \"Landscape\"]") // Simulate output
        }

        print("AI photo analysis simulation finished.")
    }
}

// MARK: - AppDelegate (or SceneDelegate in SwiftUI) Integration

/// The AppDelegate class, responsible for handling application lifecycle events.
@main
@available(iOS 13.0, *)
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    /// Called when the application finishes launching.
    /// This is the ideal place to register background tasks.
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        print("App launched.")
        // Register all background tasks immediately at launch.
        PhotoAnalyzerAgent.shared.registerTasks()

        // For testing purposes, let's schedule a task immediately after launch.
        // In a real app, you might schedule it only when specific conditions are met,
        // or when the app goes to the background.
        PhotoAnalyzerAgent.shared.schedulePhotoAnalysisTask()

        return true
    }

    /// Called when the application enters the background.
    /// This is a good place to schedule background tasks to ensure they run even if the app is terminated later.
    func applicationDidEnterBackground(_ application: UIApplication) {
        print("App entered background.")
        // Schedule the photo analysis task when the app goes to the background.
        // This ensures that even if the app is killed by the system, the task has been requested.
        PhotoAnalyzerAgent.shared.schedulePhotoAnalysisTask()
    }

    /// Called when the application is about to terminate.
    func applicationWillTerminate(_ application: UIApplication) {
        print("App will terminate.")
        // Any cleanup or final scheduling can happen here, but background tasks
        // should ideally be scheduled in `applicationDidEnterBackground`.
    }

    // MARK: - For Testing/Debugging

    /// You can use this function to manually trigger a task for debugging purposes.
    /// This is NOT part of the standard background task flow but useful for development.
    /// To test this, you'd typically set a breakpoint in `handlePhotoAnalysisTask` and then
    /// use Xcode's Debug -> Simulate Background Tasks -> `com.example.smartphotoorganizer.photoprocessing`
    /// menu option.
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String, completionHandler: @escaping () -> Void) {
        // This method is for handling background URL sessions, not general background tasks.
        // It's included here just to show the full AppDelegate signature, but not directly
        // used by BGTaskScheduler.
        print("Handling events for background URL session: \(identifier)")
        completionHandler()
    }
}

// MARK: - Main App Entry Point (for SwiftUI, typically in App struct)

/*
// If you are using SwiftUI, your App struct would look something like this:
import SwiftUI
import BackgroundTasks

@main
@available(iOS 13.0, *)
struct SmartPhotoOrganizerApp: App {

    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
*/
