
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import MLX

@available(iOS 18.0, macOS 15.0, *)
func performSensorDataProcessing() {
    // 1. Create MLXArray Instances
    let numberOfReadings = 1000
    let sensorReadingsA = MLXArray.randomUniform(low: 20.0, high: 30.0, shape: [numberOfReadings])
    let sensorReadingsB = MLXArray.randomUniform(low: 0.0, high: 5.0, shape: [numberOfReadings])

    print("Sensor Readings A (first 5): \(sensorReadingsA[0..<5].description)")
    print("Sensor Readings B (first 5): \(sensorReadingsB[0..<5].description)")

    // 2. Element-wise Operations
    let combinedReadings = sensorReadingsA + sensorReadingsB
    let scaledReadings = combinedReadings * MLXArray(0.5)

    print("Combined Readings (first 5): \(combinedReadings[0..<5].description)")
    print("Scaled Readings (first 5): \(scaledReadings[0..<5].description)")

    // 3. Aggregation
    let meanValue = scaledReadings.mean()

    // .item() forces computation and returns the scalar Swift value
    print("Mean of Scaled Readings: \(meanValue.item())")

    // 4. Reflection on Unified Memory
    // MLXArray leverages Apple's Unified Memory architecture by allocating tensor data
    // in a memory region that is directly accessible by both the CPU and the GPU (or Neural Engine).
    //
    // Why this is beneficial:
    // - No Data Copies: Traditional architectures require explicit data transfers between
    //   CPU (host) memory and GPU (device) memory, which is a significant bottleneck.
    //   Unified Memory eliminates these costly copies, reducing latency and improving throughput.
    // - Simplified Programming: Developers don't need to manage separate memory pools or
    //   synchronization primitives for data movement, leading to simpler and less error-prone code.
    // - Power Efficiency: Avoiding redundant data movement conserves energy, which is crucial
    //   for mobile and battery-powered devices.
    // - Performance: For operations like these sensor data manipulations, where data is
    //   frequently accessed and processed by both CPU and GPU (e.g., initial data loading on CPU,
    //   tensor ops on GPU, then final aggregation/display on CPU), Unified Memory ensures
    //   maximum efficiency and responsiveness.
}

// To run this, you would call:
// performSensorDataProcessing()
