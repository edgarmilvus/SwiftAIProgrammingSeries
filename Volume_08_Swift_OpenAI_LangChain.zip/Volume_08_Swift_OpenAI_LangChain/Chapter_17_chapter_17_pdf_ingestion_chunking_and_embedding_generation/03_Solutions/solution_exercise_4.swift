
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

// MARK: - Data Models

struct DocumentChunk: Sendable {
    let id: UUID = UUID()
    let content: String
    let metadata: [String: String]
    var embedding: [Float]?
}

enum IngestionError: Error {
    case fileReadError(URL)
    case embeddingAPIError(String)
    case rateLimitExceeded
    case parsingError
}

enum IngestionState: Sendable {
    case idle
    case processing(progress: Double)
    case completed
    case failed(String)
}

// MARK: - Mock OpenAI Client

actor OpenAIClient {
    func generateEmbeddings(for chunks: [DocumentChunk]) async throws -> [[Float]] {
        // Simulate network latency
        try await Task.sleep(for: .seconds(1))
        
        // Simulate a random Rate Limit error (10% chance)
        if Int.random(in: 1...10) == 1 {
            throw IngestionError.rateLimitExceeded
        }
        
        // Return dummy vectors
        return chunks.map { _ in (0..<1536).map { _ in Float.random(in: -1...1) } }
    }
}

// MARK: - Ingestion Pipeline

actor IngestionPipeline {
    private let openai = OpenAIClient()
    private(set) var state: IngestionState = .idle
    
    /// Processes a collection of URLs and reports progress via an AsyncStream
    func processDocuments(urls: [URL]) -> AsyncStream<IngestionState> {
        AsyncStream { continuation in
            Task {
                do {
                    try await performIngestion(urls: urls, continuation: continuation)
                    continuation.yield(.completed)
                    continuation.finish()
                } catch {
                    continuation.yield(.failed(error.localizedDescription))
                    continuation.finish()
                }
            }
        }
    }
    
    private func performIngestion(urls: [URL], continuation: AsyncStream<IngestionState>.Continuation) async throws {
        var allChunks: [DocumentChunk] = []
        let totalFiles = urls.count
        
        // 1. Concurrency Limiter: Use a TaskGroup to process up to 3 files at a time
        try await withThrowingTaskGroup(of: [DocumentChunk].self) { group in
            var fileIndex = 0
            
            // Fill initial buffer
            while fileIndex < min(3, totalFiles) {
                let url = urls[fileIndex]
                group.addTask { try await self.extractChunks(from: url) }
                fileIndex += 1
            }
            
            // As tasks finish, add new ones (Producer-Consumer pattern)
            for try await fileChunks in group {
                allChunks.append(contentsOf: fileChunks)
                
                // Update Progress
                let progress = Double(fileIndex) / Double(totalFiles) // Simplified progress
                continuation.yield(.processing(progress: progress))
                
                if fileIndex < totalFiles {
                    let nextUrl = urls[fileIndex]
                    group.addTask { try await self.extractChunks(from: nextUrl) }
                    fileIndex += 1
                }
            }
        }
        
        // 2. Batching and Embedding with Retry Logic
        try await embedInBatches(chunks: allChunks)
    }
    
    private func extractChunks(from url: URL) async throws -> [DocumentChunk] {
        // In a real app, call PDFTextExtractor and RecursiveCharacterSplitter here
        // We simulate metadata enrichment
        let dummyText = "Legal content from \(url.lastPathComponent)"
        return [
            DocumentChunk(
                content: dummyText,
                metadata: [
                    "source": url.lastPathComponent,
                    "timestamp": ISO8601DateFormatter().string(from: Date())
                ]
            )
        ]
    }
    
    private func embedInBatches(chunks: [DocumentChunk]) async throws {
        let batchSize = 10
        let batches = chunks.chunked(into: batchSize)
        
        for batch in batches {
            try await retryWithExponentialBackoff(retries: 3) {
                let vectors = try await openai.generateEmbeddings(for: batch)
                // In a real app, you'd save these to a Vector DB here
                print("Successfully embedded batch of \(vectors.count)")
            }
        }
    }
    
    private func retryWithExponentialBackoff(retries: Int, operation: () async throws -> Void) async throws {
        for attempt in 0...retries {
            do {
                try await operation()
                return
            } catch IngestionError.rateLimitExceeded where attempt < retries {
                let delay = UInt64(pow(2.0, Double(attempt))) * 1_000_000_000
                try await Task.sleep(nanoseconds: delay)
            } catch {
                throw error
            }
        }
    }
}

// Helper for batching
extension Array {
    func chunked(into size: Int) -> [[Element]] {
        stride(from: 0, to: count, by: size).map {
            Array(self[$0 ..< Swift.min($0 + size, count)])
        }
    }
}
