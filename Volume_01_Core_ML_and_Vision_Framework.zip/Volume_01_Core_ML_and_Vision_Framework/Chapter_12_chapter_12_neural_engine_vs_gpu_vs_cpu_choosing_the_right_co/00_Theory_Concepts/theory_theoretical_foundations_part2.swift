
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor MLModelManager {
    private let model: MLModel
    private let modelConfiguration: MLModelConfiguration

    init(modelURL: URL, computeUnits: MLComputeUnits) async throws {
        // Reference to a previous chapter concept: Model compilation and loading
        // In "Chapter 3: Model Compilation and Preparation" or "Chapter 5: Loading and Running Models",
        // we discussed how `.mlmodel` files are compiled into `.mlmodelc` bundles.
        // This compilation step is crucial because it allows Core ML to pre-analyze the model's structure
        // and optimize it for specific hardware, informing the runtime's compute unit selection.
        // The configuration provided here is used during the loading process.
        self.modelConfiguration = {
            let config = MLModelConfiguration()
            config.computeUnits = computeUnits
            return config
        }()
        self.model = try MLModel(contentsOf: modelURL, configuration: self.modelConfiguration)
        print("MLModelManager initialized with compute units: \(computeUnits)")
    }

    /// Performs a prediction using the managed model.
    func predict(input: MLFeatureProvider) async throws -> MLFeatureProvider {
        return try await model.prediction(from: input)
    }

    /// Allows changing compute units at runtime (if supported by Core ML and model)
    /// Note: Re-initializing MLModel is often required for compute unit changes.
    func updateComputeUnits(to newUnits: MLComputeUnits) async throws {
        guard newUnits != modelConfiguration.computeUnits else { return }
        print("Attempting to update compute units to: \(newUnits)")
        
        // This is a simplified example. In reality, changing compute units
        // often requires re-loading or re-initializing the MLModel.
        // Core ML's MLModel object is largely immutable regarding its underlying compute path
        // after initialization. This method illustrates the *intent* of an actor managing
        // such a change, potentially by replacing its internal `model` instance.
        // For practical purposes, you might load a *new* MLModel with the updated configuration.
        let newConfig = MLModelConfiguration()
        newConfig.computeUnits = newUnits
        // Assuming `modelURL` is accessible or passed to the actor
        // self.model = try MLModel(contentsOf: self.modelURL, configuration: newConfig)
        // self.modelConfiguration = newConfig
        print("Compute units updated (conceptual): \(newUnits)")
    }
}

// Analogy: Actor isolation vs. @MainActor UI updates
// Just as `@MainActor` ensures all UI updates happen safely on the main thread,
// preventing race conditions on UI state, an `MLModelManager` actor ensures
// that all interactions with the `MLModel` instance (like prediction calls or
// configuration changes) are serialized and thread-safe. This prevents
// multiple concurrent tasks from corrupting the model's internal state
// or conflicting over compute unit resources if not managed by Core ML.
