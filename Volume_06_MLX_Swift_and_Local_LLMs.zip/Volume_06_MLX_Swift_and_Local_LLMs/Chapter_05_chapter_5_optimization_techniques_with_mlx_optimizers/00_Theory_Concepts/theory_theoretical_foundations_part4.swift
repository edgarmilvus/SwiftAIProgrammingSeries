
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    // import MLX, MLXNN // Assume these are imported in the project

    @available(iOS 18.0, *) // @Observable requires iOS 17+, but for MLX Swift, assume 18+ for consistency
    @Observable
    class TrainingMonitor {
        var currentEpoch: Int = 0
        var currentLoss: Float = 0.0
        var isTraining: Bool = false
        var model: SimpleLinearModel // The model itself could be part of the Observable state

        init(model: SimpleLinearModel) {
            self.model = model
        }

        func startTraining(x_data: MLXArray, y_data: MLXArray, epochs: Int, optimizer: Adam) async {
            isTraining = true
            for epoch in 0..<epochs {
                currentEpoch = epoch
                let (loss, gradients) = valueAndGradient(mseLoss)(model, x_data, y_data)
                optimizer.update(model: model, gradients: gradients)
                MLXArray.eval(model.parameters(), optimizer.parameters())
                currentLoss = loss.item()
                print("Monitor - Epoch \(epoch), Loss: \(currentLoss)")
                await Task.yield()
            }
            isTraining = false
        }
    }

    // Example SwiftUI View (conceptual)
    /*
    @available(iOS 18.0, *)
    struct TrainingView: View {
        @State var monitor: TrainingMonitor
        @State var optimizer: Adam // Or pass it in

        init(model: SimpleLinearModel) {
            _monitor = State(initialValue: TrainingMonitor(model: model))
            _optimizer = State(initialValue: Adam(learningRate: 0.01))
        }

        var body: some View {
            VStack {
                Text("Epoch: \(monitor.currentEpoch)")
                Text("Loss: \(monitor.currentLoss, specifier: "%.4f")")
                if monitor.isTraining {
                    ProgressView()
                } else {
                    Button("Start Training") {
                        Task {
                            await monitor.startTraining(x_data: x_data, y_data: y_data, epochs: 10, optimizer: optimizer)
                        }
                    }
                }
            }
        }
    }
    */
    