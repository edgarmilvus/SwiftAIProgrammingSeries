/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// next.config.js (Configuration for Bundle Analysis)
const withBundleAnalyzer = require('@next/bundle-analyzer')({
  enabled: process.env.ANALYZE === 'true',
});

module.exports = withBundleAnalyzer({
  // Your existing Next.js config
});

// components/AdminPanel.tsx
'use client';

// Simulate a heavy library import
import React from 'react';

export default function AdminPanel() {
  return (
    <div style={{ border: '2px solid red', padding: '1rem' }}>
      <h2>Admin Panel (Heavy Component)</h2>
      <p>This component is only loaded when visiting the /admin route.</p>
    </div>
  );
}

// app/admin/page.tsx (App Router Example)
'use client';

import dynamic from 'next/dynamic';

// 1. Dynamically import the heavy admin component
// We use next/dynamic with SSR disabled if this is strictly client-side logic,
// or leave SSR enabled if the component supports it.
const AdminPanel = dynamic(() => import('../../components/AdminPanel'), {
  loading: () => <p>Loading Admin Panel...</p>,
  ssr: false, 
});

export default function AdminPage() {
  return (
    <div>
      <h1>Administration</h1>
      {/* 2. Render the dynamic component */}
      <AdminPanel />
    </div>
  );
}
