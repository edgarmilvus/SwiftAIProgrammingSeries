
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

/// Represents the current progress or state of the upscaling operation.
enum UpscaleProgress {
    case started
    case uploading(Double) // Progress percentage
    case processing(String) // A message about the current processing step
    case retrying(attempt: Int, after: TimeInterval) // Indicates a retry attempt
    case completed(Data) // The final upscaled image data
}

/// A service responsible for orchestrating the AI image upscaling process,
/// including retry logic, cancellation, and progress reporting.
@available(iOS 18.0, *)
class ImageUpscaler {
    private let client: AIInferenceClient
    private let logger = Logger(label: "com.example.AIPoweredPhotoEditor.ImageUpscaler")

    /// Initializes the ImageUpscaler with a specific AIInferenceClient.
    init(client: AIInferenceClient) {
        self.client = client
    }

    /// Upscales an image using the AI inference client, with retry logic and cancellation support.
    /// - Parameters:
    ///   - imageData: The original image data to upscale.
    ///   - maxRetries: The maximum number of retry attempts for transient errors.
    ///   - initialBackoffDelay: The initial delay before the first retry. This delay will increase exponentially.
    /// - Returns: An `AsyncThrowingStream` that emits `UpscaleProgress` updates and eventually the
    ///            upscaled image data upon completion, or throws an `AIInferenceError`.
    func upscaleImage(
        imageData: Data,
        maxRetries: Int = 3,
        initialBackoffDelay: TimeInterval = 1.0
    ) -> AsyncThrowingStream<UpscaleProgress, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                var currentAttempt = 0
                var currentDelay = initialBackoffDelay

                // Emit initial state
                continuation.yield(.started)
                continuation.yield(.uploading(0.1)) // Simulate initial upload progress

                while currentAttempt <= maxRetries {
                    // Check for cancellation before each attempt or significant operation.
                    // This is crucial for responsive user cancellation.
                    try Task.checkCancellation()

                    logger.info("Attempt \(currentAttempt + 1) of \(maxRetries + 1) to upscale image.")
                    continuation.yield(.processing("Attempting inference (attempt \(currentAttempt + 1))."))

                    do {
                        // Simulate further upload progress before the main inference call
                        continuation.yield(.uploading(0.5 + Double(currentAttempt) * 0.1))

                        let upscaledData = try await client.performInference(imageData: imageData)
                        continuation.yield(.completed(upscaledData))
                        continuation.finish() // Operation completed successfully
                        return // Exit the task
                    } catch let error as AIInferenceError {
                        logger.error("Inference failed on attempt \(currentAttempt + 1): \(error.localizedDescription)")

                        // Handle cancellation explicitly
                        if error == .cancelled {
                            logger.info("Upscale operation was cancelled.")
                            continuation.finish(throwing: error)
                            return
                        }

                        // Check if the error is retryable
                        if error.isRetryable && currentAttempt < maxRetries {
                            // It's a retryable error and we still have attempts left.
                            currentAttempt += 1
                            logger.warning("Retrying in \(currentDelay.formatted())s due to retryable error: \(error.localizedDescription)")
                            continuation.yield(.retrying(attempt: currentAttempt, after: currentDelay))

                            // Exponential backoff: increase delay for the next retry
                            try await Task.sleep(for: .seconds(currentDelay))
                            currentDelay *= 2.0 // Double the delay for the next attempt
                        } else {
                            // Non-retryable error, or max retries reached.
                            logger.error("Inference failed permanently after \(currentAttempt + 1) attempts: \(error.localizedDescription)")
                            continuation.finish(throwing: error)
                            return
                        }
                    } catch {
                        // Catch any other unexpected errors
                        logger.critical("An unexpected error occurred during upscaling: \(error.localizedDescription)")
                        continuation.finish(throwing: AIInferenceError.unknown(error.localizedDescription))
                        return
                    }
                }
                // If we exit the loop, it means maxRetries was reached and the last attempt failed.
                continuation.finish(throwing: AIInferenceError.inferenceFailed("Max retries reached without success."))
            }
        }
    }
}
