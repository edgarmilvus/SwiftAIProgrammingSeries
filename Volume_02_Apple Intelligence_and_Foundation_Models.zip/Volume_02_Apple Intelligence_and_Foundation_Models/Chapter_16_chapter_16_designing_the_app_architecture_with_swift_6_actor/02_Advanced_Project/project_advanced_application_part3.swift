
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

    @available(iOS 18.0, *)
    actor AIService {
        private let processingDelay: UInt64 = 2_000_000_000 // 2 seconds in nanoseconds

        /// Simulates summarizing a document using an on-device LLM.
        /// - Parameter text: The raw text content of the document.
        /// - Returns: A summarized string.
        /// - Throws: `DocumentProcessingError` if the AI service fails.
        func summarize(text: String) async throws -> String {
            guard !text.isEmpty else {
                throw DocumentProcessingError.emptyDocument
            }

            // Simulate network/on-device processing delay
            try await Task.sleep(nanoseconds: processingDelay)

            // Simulate potential AI processing failures
            if Bool.random() && text.contains("error trigger") { // 10% chance of failure if text contains "error trigger"
                throw DocumentProcessingError.aiProcessingFailed(reason: "Simulated LLM inference error.")
            }

            // Simple mock summarization for demonstration
            let words = text.split(separator: " ")
            if words.count > 20 {
                return words.prefix(15).joined(separator: " ") + "... (AI Summary)"
            } else {
                return text + " (AI Summary)"
            }
        }

        /// Simulates extracting keywords from a document using an on-device LLM.
        /// - Parameter text: The raw text content of the document.
        /// - Returns: An array of extracted keywords.
        /// - Throws: `DocumentProcessingError` if the AI service fails.
        func extractKeywords(text: String) async throws -> [String] {
            guard !text.isEmpty else {
                throw DocumentProcessingError.emptyDocument
            }

            // Simulate network/on-device processing delay
            try await Task.sleep(nanoseconds: processingDelay / 2) // Shorter delay for keywords

            // Simulate potential AI processing failures
            if Bool.random() && text.contains("keyword error") { // 10% chance of failure if text contains "keyword error"
                throw DocumentProcessingError.aiProcessingFailed(reason: "Simulated keyword extraction failure.")
            }

            // Simple mock keyword extraction
            let commonWords = ["the", "a", "an", "is", "are", "and", "or", "to", "in", "for", "with"]
            let words = text.lowercased()
                            .components(separatedBy: CharacterSet.alphanumerics.inverted)
                            .filter { !$0.isEmpty && !commonWords.contains($0) }
            
            let uniqueWords = Array(Set(words)).sorted()
            return uniqueWords.prefix(5).map { $0.capitalized } // Return top 5 unique words
        }
    }
    