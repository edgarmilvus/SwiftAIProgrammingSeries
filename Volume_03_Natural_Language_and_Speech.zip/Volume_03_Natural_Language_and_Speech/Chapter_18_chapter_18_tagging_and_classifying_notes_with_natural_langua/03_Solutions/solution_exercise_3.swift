
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import NaturalLanguage
import CoreML // NLModel relies on CoreML

// 1. Define your training data structure
typealias TrainingData = [(String, String)] // (noteContent, categoryLabel)

func createTrainingData() -> TrainingData {
    var data: TrainingData = []

    // Add "Bug Report" examples
    data.append(("App crashes when I try to open the settings menu.", "Bug Report"))
    data.append(("The login button is unresponsive on iOS 17.", "Bug Report"))
    data.append(("Data loss occurred after syncing with iCloud.", "Bug Report"))
    data.append(("UI freezes randomly when scrolling through tasks.", "Bug Report"))
    data.append(("Incorrect calculation in the expense report module.", "Bug Report"))
    data.append(("Error 404 when trying to access user profile.", "Bug Report"))
    data.append(("The application quits unexpectedly during startup.", "Bug Report"))
    data.append(("Text input field doesn't accept special characters.", "Bug Report"))
    data.append(("Image upload fails with a generic error message.", "Bug Report"))
    data.append(("Notifications are not delivered consistently.", "Bug Report"))
    data.append(("The search bar disappears after typing.", "Bug Report"))
    data.append(("Cannot submit form, invalid input error.", "Bug Report"))
    data.append(("Calendar sync is not working with Google.", "Bug Report"))
    data.append(("High CPU usage when idle.", "Bug Report"))
    data.append(("Incorrect sorting order in the task list.", "Bug Report"))


    // Add "Feature Request" examples
    data.append(("Please add dark mode support for macOS.", "Feature Request"))
    data.append(("I'd like to see a 'share to social media' option.", "Feature Request"))
    data.append(("Can we have customizable themes for the interface?", "Feature Request"))
    data.append(("Allow users to export data as CSV or PDF.", "Feature Request"))
    data.append(("Integrate with Apple Calendar for event syncing.", "Feature Request"))
    data.append(("Add a search bar to filter tasks by due date.", "Feature Request"))
    data.append(("Support for rich text formatting in notes is needed.", "Feature Request"))
    data.append(("Implement a 'read receipts' feature for messages.", "Feature Request"))
    data.append(("Provide an undo/redo option for text edits.", "Feature Request"))
    data.append(("It would be great to have multi-user collaboration on documents.", "Feature Request"))
    data.append(("Ability to attach files to tasks.", "Feature Request"))
    data.append(("Support for voice input in notes.", "Feature Request"))
    data.append(("Customizable keyboard shortcuts would be useful.", "Feature Request"))
    data.append(("Add a 'snooze' option for notifications.", "Feature Request"))
    data.append(("Offline mode for editing tasks.", "Feature Request"))


    // Add "General Task" examples
    data.append(("Update documentation for API endpoints.", "General Task"))
    data.append(("Refactor the user authentication module.", "General Task"))
    data.append(("Write unit tests for the new payment gateway.", "General Task"))
    data.append(("Prepare presentation slides for the weekly sprint review.", "General Task"))
    data.append(("Review pull requests from the junior developers.", "General Task"))
    data.append(("Deploy the latest build to the staging environment.", "General Task"))
    data.append(("Research new UI/UX trends for the next release.", "General Task"))
    data.append(("Set up continuous integration pipeline.", "General Task"))
    data.append(("Onboard new team member to the project.", "General Task"))
    data.append(("Schedule a meeting with the design team.", "General Task"))
    data.append(("Clean up old database entries.", "General Task"))
    data.append(("Create marketing materials for new feature.", "General Task"))
    data.append(("Investigate performance bottlenecks.", "General Task"))
    data.append(("Configure server monitoring tools.", "General Task"))
    data.append(("Plan sprint backlog for next iteration.", "General Task"))


    return data
}

// Function to train and save the model
func trainAndSaveCustomClassifier(trainingData: TrainingData, modelURL: URL) throws {
    // NLModel.Trainer's `train` method for [(String, String)] is asynchronous.
    // To conform to the `throws` signature, we use a DispatchSemaphore to wait for completion.
    // In a real application, this would ideally be an `async throws` function.
    let semaphore = DispatchSemaphore(value: 0)
    var trainingError: Error?
    var trainedModel: NLModel?

    let trainer = NLModel.Trainer(trainingData: trainingData, language: .english) // Assuming English notes
    
    trainer.train(completionHandler: { model, error in
        if let error = error {
            trainingError = error
        } else if let model = model {
            trainedModel = model
        }
        semaphore.signal() // Signal that training is complete (or failed)
    })

    // Wait for the training to complete
    _ = semaphore.wait(timeout: .distantFuture)

    if let error = trainingError {
        throw error
    }
    guard let model = trainedModel else {
        throw NSError(domain: "NLModelTrainer", code: 0, userInfo: [NSLocalizedDescriptionKey: "Model training failed without specific error."])
    }

    // Save the trained model to the specified URL
    try model.write(to: modelURL)
}

// Function to load the model and classify a note
func classifyNoteWithCustomModel(noteText: String, modelURL: URL) throws -> String {
    // Load the custom NLModel from the URL
    let model = try NLModel(contentsOf: modelURL)

    // Predict the label for the given noteText
    guard let predictedLabel = model.predictedLabel(for: noteText) else {
        throw NSError(domain: "NLModelClassifier", code: 0, userInfo: [NSLocalizedDescriptionKey: "Could not predict label for the note."])
    }

    return predictedLabel
}

// Example Usage (for testing your implementation)
/*
let tempModelURL = FileManager.default.temporaryDirectory.appendingPathComponent("TaskMasterClassifier.mlmodel")
let trainingData = createTrainingData()

do {
    print("Starting model training...")
    try trainAndSaveCustomClassifier(trainingData: trainingData, modelURL: tempModelURL)
    print("Model trained and saved successfully at \(tempModelURL.lastPathComponent)")

    let testNote1 = "The app crashes every time I open the camera."
    let prediction1 = try classifyNoteWithCustomModel(noteText: testNote1, modelURL: tempModelURL)
    print("Note: '\(testNote1)' -> Category: \(prediction1)") // Expected: Bug Report

    let testNote2 = "It would be nice to have an option to export all tasks to a spreadsheet."
    let prediction2 = try classifyNoteWithCustomModel(noteText: testNote2, modelURL: tempModelURL)
    print("Note: '\(testNote2)' -> Category: \(prediction2)") // Expected: Feature Request

    let testNote3 = "Finish the documentation for the new API."
    let prediction3 = try classifyNoteWithCustomModel(noteText: testNote3, modelURL: tempModelURL)
    print("Note: '\(testNote3)' -> Category: \(prediction3)") // Expected: General Task

    let testNote4 = "The UI is completely frozen after the last update, I can't do anything."
    let prediction4 = try classifyNoteWithCustomModel(noteText: testNote4, modelURL: tempModelURL)
    print("Note: '\(testNote4)' -> Category: \(prediction4)") // Expected: Bug Report

    let testNote5 = "I wish there was a way to share tasks with external collaborators."
    let prediction5 = try classifyNoteWithCustomModel(noteText: testNote5, modelURL: tempModelURL)
    print("Note: '\(testNote5)' -> Category: \(prediction5)") // Expected: Feature Request

    // Clean up the temporary model file
    try FileManager.default.removeItem(at: tempModelURL)
    print("Cleaned up temporary model file.")

} catch {
    print("Error during model training or classification: \(error)")
}
*/
