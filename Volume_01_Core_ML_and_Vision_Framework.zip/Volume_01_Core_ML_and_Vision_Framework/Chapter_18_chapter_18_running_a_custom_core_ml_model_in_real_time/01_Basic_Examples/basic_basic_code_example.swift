
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import CoreML
import Vision
import UIKit // For UIImage and CGImage

// MARK: - 1. Define the Model's Output Structure (Simulated for clarity)
// In a real scenario, the generated MyImageClassifier class would define its outputs.
// This struct represents a simplified version of what a classification observation might contain.
struct ImageClassificationResult {
    let identifier: String
    let confidence: Float
}

// MARK: - 2. Image Classification Service
/// A service class responsible for loading and running a custom Core ML image classification model.
/// It uses the Vision framework for efficient image processing and model inference.
@available(iOS 18.0, *)
final class ImageClassifierService {

    // MARK: - Properties
    /// The Core ML model wrapped by Vision. It's recommended to retain this instance
    /// for the lifetime of the service to avoid repeated loading overhead.
    private var visionCoreMLModel: VNCoreMLModel?

    /// The Vision request that uses our Core ML model.
    private var classificationRequest: VNCoreMLRequest?

    // MARK: - Initialization
    /// Initializes the service by loading the Core ML model.
    /// - Throws: An error if the Core ML model cannot be loaded or initialized.
    init() throws {
        try setupModel()
    }

    // MARK: - Model Setup
    /// Loads the custom Core ML model and sets up the Vision request.
    /// This method should ideally be called once during the service's lifecycle.
    private func setupModel() throws {
        // 1. Load the compiled Core ML model.
        // Xcode automatically generates a class (e.g., MyImageClassifier) from your .mlmodel file.
        // We create an instance of this generated class.
        // For demonstration, we'll assume a model configuration.
        let modelConfiguration = MLModelConfiguration()
        modelConfiguration.computeUnits = .all // Use all available compute units (CPU, GPU, Neural Engine)

        // IMPORTANT: Replace 'MyImageClassifier' with the actual name of your generated model class.
        // If your model is named 'FruitClassifier.mlmodel', the class will be 'FruitClassifier'.
        guard let coreMLModel = try? MyImageClassifier(configuration: modelConfiguration).model else {
            // In a real app, you'd provide a more specific error or fallback.
            throw ImageClassifierError.modelLoadingFailed
        }

        // 2. Wrap the Core ML model in a VNCoreMLModel.
        // VNCoreMLModel bridges Core ML with Vision, handling necessary image preprocessing.
        self.visionCoreMLModel = try VNCoreMLModel(for: coreMLModel)

        // 3. Create a VNCoreMLRequest.
        // This request specifies which Vision task to perform with the Core ML model.
        // The completion handler will be called when the classification is done.
        self.classificationRequest = VNCoreMLRequest(model: visionCoreMLModel!) { [weak self] request, error in
            // Handle the classification results or errors.
            self?.handleClassificationResults(request: request, error: error)
        }

        // Optional: Configure the request for better performance or specific behavior.
        // For image classification, `imageCropAndScaleOption` is often crucial.
        // .centerCrop: Crops the image to the model's expected aspect ratio and then scales it.
        // .scaleFit: Scales the image to fit without cropping, potentially adding padding.
        // .scaleFill: Scales the image to fill the entire input, potentially distorting aspect ratio.
        self.classificationRequest?.imageCropAndScaleOption = .centerCrop
    }

    // MARK: - Classification Execution
    /// Performs image classification on the given `CGImage`.
    /// - Parameters:
    ///   - image: The `CGImage` to classify.
    ///   - orientation: The orientation of the image, crucial for correct Vision processing.
    /// - Returns: An array of `ImageClassificationResult` if classification is successful.
    /// - Throws: An error if the classification request fails or if the model isn't set up.
    @MainActor // Ensure this method can safely update UI or be called from UI contexts.
    func classifyImage(_ image: CGImage, orientation: CGImagePropertyOrientation = .up) async throws -> [ImageClassificationResult] {
        guard let classificationRequest = classificationRequest else {
            throw ImageClassifierError.modelNotReady
        }

        // 1. Create a VNImageRequestHandler.
        // This handler manages the execution of Vision requests on a specific image.
        let handler = VNImageRequestHandler(cgImage: image, orientation: orientation)

        // 2. Perform the request.
        // This is where the Vision framework processes the image and runs the Core ML model.
        // The actual inference happens on a background thread managed by Vision.
        return try await withCheckedThrowingContinuation { continuation in
            classificationRequest.completionHandler = { request, error in
                if let error = error {
                    continuation.resume(throwing: ImageClassifierError.classificationFailed(error))
                    return
                }
                // Handle results on the main actor, as the completion handler might be on a background thread.
                self.handleClassificationResults(request: request, error: nil) { results in
                    continuation.resume(returning: results)
                }
            }

            do {
                try handler.perform([classificationRequest])
            } catch {
                continuation.resume(throwing: ImageClassifierError.requestFailed(error))
            }
        }
    }

    // MARK: - Result Handling
    /// Processes the results from the `VNCoreMLRequest`.
    /// - Parameters:
    ///   - request: The completed `VNCoreMLRequest`.
    ///   - error: An optional error if the request failed.
    ///   - completion: A closure to return the processed results.
    private func handleClassificationResults(request: VNRequest, error: Error?, completion: (([ImageClassificationResult]) -> Void)? = nil) {
        // Ensure UI updates happen on the main thread.
        // The Vision completion handler might be called on a background queue.
        Task { @MainActor in
            if let error = error {
                print("Error classifying image: \(error.localizedDescription)")
                completion?([])
                return
            }

            // 1. Cast the results to VNClassificationObservation.
            // For classification models, Vision returns VNClassificationObservation objects.
            guard let observations = request.results as? [VNClassificationObservation] else {
                print("No classification observations found.")
                completion?([])
                return
            }

            // 2. Process and sort the observations by confidence.
            let topResults = observations.sorted(by: { $0.confidence > $1.confidence }).prefix(5) // Get top 5 results

            let classificationResults = topResults.map { observation in
                ImageClassificationResult(
                    identifier: observation.identifier,
                    confidence: observation.confidence
                )
            }

            // 3. Print or use the results.
            print("Classification Results:")
            for result in classificationResults {
                print("- \(result.identifier) (Confidence: \(String(format: "%.2f", result.confidence * 100))%)")
            }
            completion?(classificationResults)
        }
    }

    // MARK: - Error Handling Enum
    enum ImageClassifierError: LocalizedError {
        case modelLoadingFailed
        case modelNotReady
        case classificationFailed(Error)
        case requestFailed(Error)

        var errorDescription: String? {
            switch self {
            case .modelLoadingFailed:
                return "Failed to load the Core ML model. Ensure 'MyImageClassifier.mlmodel' is in the project bundle."
            case .modelNotReady:
                return "Image classifier model is not ready or initialized."
            case .classificationFailed(let error):
                return "Image classification failed: \(error.localizedDescription)"
            case .requestFailed(let error):
                return "Vision request failed: \(error.localizedDescription)"
            }
        }
    }
}


// MARK: - 3. Simulate the Generated MyImageClassifier Model (for compilation without actual .mlmodel)
// In a real project, Xcode generates this class automatically from your .mlmodel file.
// We're including a minimal version here so the example code compiles.
// You would NOT write this class yourself; it's generated.
class MyImageClassifierInput: MLFeatureProvider {
    var featureNames: Set<String> {
        return ["image"] // Assuming your model expects an input named "image"
    }

    private let image: CVPixelBuffer

    init(image: CVPixelBuffer) {
        self.image = image
    }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "image" {
            return MLFeatureValue(pixelBuffer: image)
        }
        return nil
    }
}

class MyImageClassifierOutput: MLFeatureProvider {
    var featureNames: Set<String> {
        return ["classLabel", "classLabelProbs"] // Typical outputs for classification
    }

    let classLabel: String
    let classLabelProbs: [String: Double]

    init(classLabel: String, classLabelProbs: [String: Double]) {
        self.classLabel = classLabel
        self.classLabelProbs = classLabelProbs
    }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "classLabel" {
            return MLFeatureValue(string: classLabel)
        }
        if featureName == "classLabelProbs" {
            return MLFeatureValue(dictionary: classLabelProbs as [AnyHashable : NSNumber])
        }
        return nil
    }
}

class MyImageClassifier {
    let model: MLModel

    /// - Parameter configuration: the Configuration for the MLModel
    init(configuration: MLModelConfiguration = MLModelConfiguration()) throws {
        // This is where Xcode would generate code to load your compiled model.
        // For this example, we'll simulate a dummy MLModel.
        // In a real scenario, it would be:
        // guard let modelURL = Bundle(for: MyImageClassifier.self).url(forResource: "MyImageClassifier", withExtension: "mlmodelc") else {
        //     fatalError("Failed to find MyImageClassifier.mlmodelc in bundle.")
        // }
        // self.model = try MLModel(contentsOf: modelURL, configuration: configuration)

        // Dummy MLModel for compilation purposes. This won't actually classify.
        // It merely provides an MLModel instance that VNCoreMLModel can wrap.
        // A real .mlmodelc needs to be present in your project for actual inference.
        let dummyModelDescription = MLModelDescription()
        let inputDescription = MLFeatureDescription()
        inputDescription.isOptional = false
        inputDescription.type = .image
        dummyModelDescription.inputFeatureDefs["image"] = inputDescription

        let outputDescription = MLFeatureDescription()
        outputDescription.isOptional = false
        outputDescription.type = .string
        dummyModelDescription.outputFeatureDefs["classLabel"] = outputDescription

        let dummySpecification = MLModel_Specification()
        dummySpecification.hasDescription_p = true
        dummySpecification.description_p = dummyModelDescription.proto

        let mlModel = try MLModel(mlModel: dummySpecification, configuration: configuration)
        self.model = mlModel
    }

    func prediction(input: MyImageClassifierInput) throws -> MyImageClassifierOutput {
        // This method would be generated by Xcode.
        // For our dummy model, we return a mock output.
        return MyImageClassifierOutput(classLabel: "dummy_label", classLabelProbs: ["dummy_label": 1.0])
    }
}


// MARK: - 4. Example Usage in a UIViewController (Simulated Camera Capture)
/// A simulated UIViewController that uses the ImageClassifierService to classify a captured image.
@available(iOS 18.0, *)
final class CameraViewController: UIViewController {

    private var classifierService: ImageClassifierService!
    private let imageView = UIImageView()
    private let resultLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Initialize the service. This might throw if the model is not found.
        do {
            classifierService = try ImageClassifierService()
        } catch {
            print("Failed to initialize ImageClassifierService: \(error.localizedDescription)")
            resultLabel.text = "Error: \(error.localizedDescription)"
            return
        }

        // Simulate an image capture after a short delay or user interaction.
        // In a real app, this would be triggered by a camera delegate callback.
        Task {
            // Ensure UI updates are on the main actor.
            await MainActor.run {
                self.resultLabel.text = "Simulating image capture..."
            }
            try? await Task.sleep(for: .seconds(2)) // Simulate delay

            await classifySampleImage()
        }
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)

        resultLabel.numberOfLines = 0
        resultLabel.textAlignment = .center
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(resultLabel)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5),

            resultLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            resultLabel.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    /// Simulates capturing an image and then classifying it.
    private func classifySampleImage() async {
        // Load a sample image from the asset catalog.
        // In a real app, this would be an image from the camera.
        guard let sampleImage = UIImage(named: "sampleImage") else {
            await MainActor.run {
                self.resultLabel.text = "Error: 'sampleImage' not found in assets. Please add one."
            }
            print("Error: 'sampleImage' not found in assets.")
            return
        }

        await MainActor.run {
            self.imageView.image = sampleImage
            self.resultLabel.text = "Classifying image..."
        }

        guard let cgImage = sampleImage.cgImage else {
            await MainActor.run {
                self.resultLabel.text = "Error: Could not convert UIImage to CGImage."
            }
            print("Error: Could not convert UIImage to CGImage.")
            return
        }

        do {
            // Perform classification. The Vision framework handles threading internally.
            let results = try await classifierService.classifyImage(cgImage, orientation: .up)

            // Update UI on the main actor with the results.
            await MainActor.run {
                if results.isEmpty {
                    self.resultLabel.text = "No classification results."
                } else {
                    let topResult = results[0]
                    self.resultLabel.text = "Top Result: \(topResult.identifier) (\(String(format: "%.2f", topResult.confidence * 100))%)"
                    print("Classification successful!")
                }
            }
        } catch {
            await MainActor.run {
                self.resultLabel.text = "Classification failed: \(error.localizedDescription)"
            }
            print("Classification failed with error: \(error.localizedDescription)")
        }
    }
}

// NOTE: To run this example, you need to:
// 1. Add a .mlmodel file to your Xcode project (e.g., named 'MyImageClassifier.mlmodel').
//    Xcode will automatically generate the 'MyImageClassifier' Swift class.
// 2. Add an image named "sampleImage" to your project's Asset Catalog.
//    This image will be used for simulation.
