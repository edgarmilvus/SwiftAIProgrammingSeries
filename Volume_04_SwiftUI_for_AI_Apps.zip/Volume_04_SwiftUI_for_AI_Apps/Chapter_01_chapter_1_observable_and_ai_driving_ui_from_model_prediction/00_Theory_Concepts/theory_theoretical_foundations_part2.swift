
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor AIModelActor {
    private var model: SomeComplexAIModel // Assume this holds mutable state or is heavy to initialize
    private var internalCache: [String: String] = [:] // Example of actor-isolated mutable state

    init() {
        // Initialize the heavy AI model, potentially asynchronously
        self.model = SomeComplexAIModel()
        print("AIModelActor initialized.")
    }

    func performInference(input: String) async throws -> String {
        // All access to 'model' and 'internalCache' is actor-isolated and safe
        if let cachedResult = internalCache[input] {
            print("Returning cached result for: \(input)")
            return cachedResult
        }

        print("Performing new inference for: \(input)")
        let result = try await model.process(input: input) // 'model.process' could be another async function
        internalCache[input] = result
        return result
    }

    // Example of a private, actor-isolated AI model class
    private class SomeComplexAIModel {
        func process(input: String) async throws -> String {
            // Simulate heavy AI processing
            try await Task.sleep(for: .seconds(1.5))
            return "Processed: \(input.uppercased())"
        }
    }
}

// Usage in an Observable ViewModel
@available(iOS 18.0, *)
@Observable
class AIViewModel {
    private let aiModelActor = AIModelActor()
    var predictionResult: String = "No prediction yet."
    var isLoading: Bool = false

    @MainActor // Ensure this method runs on the main actor for UI updates
    func makePrediction(input: String) async {
        isLoading = true
        do {
            let result = try await aiModelActor.performInference(input: input)
            predictionResult = result // UI updates automatically via @Observable
        } catch {
            predictionResult = "Error: \(error.localizedDescription)"
        }
        isLoading = false
    }
}
