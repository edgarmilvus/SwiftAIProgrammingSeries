
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

// MARK: - 1. RefactoringSuggestion Structure

/// Represents a suggested code refactoring.
struct RefactoringSuggestion: Codable, Identifiable {
    let id: UUID = UUID() // For SwiftUI List identification, etc.
    let type: String // e.g., "Extract Method", "Introduce Guard Let"
    let description: String // Natural language explanation
    let originalCodeRange: RangeData? // Optional, for precise replacement
    let suggestedCode: String // The full or partial modified code
    let confidence: Double // Score from 0.0 to 1.0

    // Helper for Codable Range<String.Index>
    struct RangeData: Codable {
        let lowerBound: Int // Character offset
        let upperBound: Int

        init?<S: StringProtocol>(range: Range<S.Index>, in string: S) {
            guard let lower = range.lowerBound.utf16Offset(in: string),
                  let upper = range.upperBound.utf16Offset(in: string) else { return nil }
            self.lowerBound = lower
            self.upperBound = upper
        }

        func toRange(in string: String) -> Range<String.Index>? {
            guard let lower = string.utf16Index(atOffset: lowerBound),
                  let upper = string.utf16Index(atOffset: upperBound) else { return nil }
            return lower..<upper
        }
    }
}

// MARK: - LLM Abstraction and Tool

/// Protocol for LLM inference (reused from Exercise 1).
protocol LLMInference {
    @available(iOS 18.0, macOS 15.0, *)
    func infer(prompt: String) async throws -> String
}

/// A mock LLM for code refactoring.
class MockRefactoringLLM: LLMInference {
    @available(iOS 18.0, macOS 15.0, *)
    func infer(prompt: String) async throws -> String {
        try await Task.sleep(for: .milliseconds(500)) // Simulate longer LLM processing

        // Simple keyword-based simulation for the given example code
        if prompt.contains("NetworkManager") && prompt.contains("fetchData") {
            return """
            [
                {
                    "type": "Introduce Guard Let",
                    "description": "Introduce a guard let for URL initialization to handle bad URLs early.",
                    "originalCodeRange": { "lowerBound": 140, "upperBound": 223 },
                    "suggestedCode": "        guard let url = URL(string: urlString) else {\\n            completion(.failure(URLError(.badURL)))\\n            return\\n        }",
                    "confidence": 0.95
                },
                {
                    "type": "Extract Method",
                    "description": "Extract data task completion logic into a separate method for better readability and testability.",
                    "originalCodeRange": null,
                    "suggestedCode": "    private func handleFetchDataCompletion(data: Data?, response: URLResponse?, error: Error?, completion: @escaping (Result<Data, Error>) -> Void) {\\n        if let error = error {\\n            completion(.failure(error))\\n            return\\n        }\\n\\n        guard let httpResponse = response as? HTTPURLResponse,\\n              (200...299).contains(httpResponse.statusCode) else {\\n            completion(.failure(URLError(.badServerResponse)))\\n            return\\n        }\\n\\n        guard let data = data else {\\n            completion(.failure(URLError(.zeroByteResource)))\\n            return\\n        }\\n        completion(.success(data))\\n    }",
                    "confidence": 0.88
                },
                {
                    "type": "Introduce Guard Let",
                    "description": "Introduce a guard let for HTTP response status code check.",
                    "originalCodeRange": { "lowerBound": 460, "upperBound": 612 },
                    "suggestedCode": "            guard let httpResponse = response as? HTTPURLResponse,\\n                  (200...299).contains(httpResponse.statusCode) else {\\n                completion(.failure(URLError(.badServerResponse)))\\n                return\\n            }",
                    "confidence": 0.92
                }
            ]
            """
        }
        return "[]" // No suggestions
    }
}

// MARK: - 2. AnalyzeCodeTool

/// The tool responsible for using the LLM to analyze Swift code for refactorings.
@available(iOS 18.0, macOS 15.0, *)
struct AnalyzeCodeTool {
    private let llm: LLMInference
    private let jsonDecoder = JSONDecoder()

    init(llm: LLMInference) {
        self.llm = llm
    }

    func analyze(codeSnippet: String) async throws -> [RefactoringSuggestion] {
        let prompt = """
        You are an AI assistant specialized in Swift code refactoring.
        Analyze the following Swift code snippet and identify potential refactorings.
        For each refactoring, provide a 'RefactoringSuggestion' in JSON format.
        Output an array of these JSON objects.
        
        A RefactoringSuggestion should have the following structure:
        {
            "type": "String", // e.g., "Extract Method", "Introduce Guard Let", "Rename Variable"
            "description": "String", // Natural language explanation of the suggestion
            "originalCodeRange": { // Optional: character offsets for the code to be replaced/modified
                "lowerBound": Int,
                "upperBound": Int
            },
            "suggestedCode": "String", // The full or partial modified code
            "confidence": Double // A score from 0.0 to 1.0
        }
        
        Swift Code Snippet:
        