
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.swift
// Description: Basic Code Example
// ==========================================

    // Correct: Reusing the tagger instance
    class EfficientKeywordExtractor {
        @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
        private let tagger: NLTagger
        private let stopWords: Set<String> = [/* ... your stop words ... */] // Re-use stop words

        @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
        init() {
            // Initialize once when the extractor is created
            tagger = NLTagger(tagSchemes: [.lexicalClass, .lemma])
        }

        @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
        func extractKeywords(from text: String, maxKeywords: Int = 5) -> [(keyword: String, frequency: Int)] {
            tagger.string = text // Only change the string for new text
            var keywordFrequencies: [String: Int] = [:]

            tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lexicalClass, options: [.omitWhitespace, .omitPunctuation]) { tag, tokenRange in
                guard let tag = tag else { return true }
                let word = String(text[tokenRange]).lowercased()
                if tag == .noun || tag == .verb {
                    let lemmaTag = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .lemma)?.0
                    let keyword = lemmaTag?.rawValue.lowercased() ?? word
                    if !stopWords.contains(keyword) && keyword.count > 2 {
                        keywordFrequencies[keyword, default: 0] += 1
                    }
                }
                return true
            }
            return keywordFrequencies.sorted { $0.value > $1.value }
                                     .prefix(maxKeywords)
                                     .map { (keyword: $0.key, frequency: $0.value) }
        }
    }
    