
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import MLX
import MLXNN

// 1. Define a LinearRegression Module
class LinearRegression: MLXNN.Module {
    let linear: MLXNN.Linear

    init() {
        // Initialize a single linear layer: input size 1 (num_events), output size 1 (engagement_time)
        self.linear = MLXNN.Linear(inputSize: 1, outputSize: 1)
        super.init() // Call the superclass initializer
    }

    // Implement the callAsFunction for the forward pass
    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // Pass the input through the linear layer
        return linear(x)
    }
}

// Main execution block
// 2. Generate Synthetic Data
// Inputs: Number of in-app events triggered the previous day
let x_train_data: [Float] = [1.0, 2.0, 3.0, 4.0, 5.0]
let x_train = MLXArray(x_train_data, type: .float32)

// Targets: Corresponding daily engagement time (with some noise)
let y_train_data: [Float] = [2.1, 3.9, 6.2, 7.8, 10.1]
let y_train = MLXArray(y_train_data, type: .float32)

print("--- Exercise 1: Simple Linear Regression ---")

// 3. Perform a Forward Pass
// Instantiate the model
let model = LinearRegression()

// Take a single input from our synthetic data
let singleInput = x_train[0] // MLXArray([1.0])

// Perform a forward pass
let predictedOutput = model(singleInput)

// Print the predicted output. This is where lazy evaluation triggers computation.
print("Input (num_events): \(singleInput.toFloat())")
print("Predicted engagement time: \(predictedOutput.toFloat())")

// You can also print the initial weights and biases for inspection
print("\nModel's initial weights (linear.weight):")
if let weight = model.parameters()["linear.weight"] {
    print(weight.toFloatArray())
}
print("Model's initial bias (linear.bias):")
if let bias = model.parameters()["linear.bias"] {
    print(bias.toFloatArray())
}

print("\nExplanation of Lazy Evaluation:")
print("When `model(singleInput)` is called, MLX doesn't immediately perform the computation on the GPU/CPU.")
print("Instead, it builds a computational graph representing the operations (matrix multiplication, addition).")
print("The actual numerical computation is deferred until the result is needed,")
print("for example, when `predictedOutput.toFloat()` is called to convert the MLXArray to a Swift scalar for printing.")
print("This allows MLX to optimize the entire graph before execution, leading to better performance.")
