
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import Observation
import SwiftUI

// MARK: - Data Model

@available(iOS 18.0, *)
enum AgentID: String, CaseIterable, Identifiable {
    case planner = "Planner"
    case executor = "Executor"
    case reviewer = "Reviewer" // Added a third agent for more variety
    var id: String { rawValue }

    var color: Color {
        switch self {
        case .planner: return .blue
        case .executor: return .green
        case .reviewer: return .purple
        }
    }
}

@available(iOS 18.0, *)
struct AgentLogEntry: Identifiable, Hashable {
    let id = UUID()
    let agent: AgentID
    let content: String
    let timestamp: Date = Date()

    // Formatted timestamp for display
    var formattedTimestamp: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: timestamp)
    }
}

// MARK: - ViewModel

@available(iOS 18.0, *)
@Observable
class MultiAgentViewModel {
    var logEntries: [AgentLogEntry] = []
    private var collaborationTask: Task<Void, Never>?

    func startCollaborationSimulation() {
        reset() // Clear previous entries
        collaborationTask = Task {
            let plannerMessages = [
                "Analyzing request...",
                "Breaking down into sub-tasks.",
                "Task 1: Retrieve user preferences.",
                "Task 2: Generate initial draft.",
                "Task 3: Review and refine."
            ]
            let executorMessages = [
                "Executing Task 1: Fetching data.",
                "Data retrieved successfully.",
                "Executing Task 2: Generating draft content.",
                "Draft generated. Waiting for review."
            ]
            let reviewerMessages = [
                "Reviewing draft for coherence.",
                "Found minor inconsistencies.",
                "Suggesting revisions for Task 3.",
                "Final review complete. Approved."
            ]

            var plannerIndex = 0
            var executorIndex = 0
            var reviewerIndex = 0

            while plannerIndex < plannerMessages.count ||
                  executorIndex < executorMessages.count ||
                  reviewerIndex < reviewerMessages.count {

                await Task.sleep(nanoseconds: UInt64(Double.random(in: 0.3...0.8) * 1_000_000_000))
                
                await MainActor.run {
                    // Randomly pick an agent to generate a message, if they have messages left
                    let activeAgents: [AgentID] = AgentID.allCases.filter { agent in
                        switch agent {
                        case .planner: return plannerIndex < plannerMessages.count
                        case .executor: return executorIndex < executorMessages.count
                        case .reviewer: return reviewerIndex < reviewerMessages.count
                        }
                    }
                    
                    guard let randomAgent = activeAgents.randomElement() else { return }

                    switch randomAgent {
                    case .planner:
                        logEntries.append(AgentLogEntry(agent: .planner, content: plannerMessages[plannerIndex]))
                        plannerIndex += 1
                    case .executor:
                        logEntries.append(AgentLogEntry(agent: .executor, content: executorMessages[executorIndex]))
                        executorIndex += 1
                    case .reviewer:
                        logEntries.append(AgentLogEntry(agent: .reviewer, content: reviewerMessages[reviewerIndex]))
                        reviewerIndex += 1
                    }
                }
            }
        }
    }

    func reset() {
        collaborationTask?.cancel()
        logEntries = []
    }
}

// MARK: - View

@available(iOS 18.0, *)
struct MultiAgentLogView: View {
    @State private var viewModel = MultiAgentViewModel()

    private var lastEntryId: UUID? {
        viewModel.logEntries.last?.id
    }

    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 5) {
                        ForEach(viewModel.logEntries) { entry in
                            HStack(alignment: .top) {
                                Text("[\(entry.formattedTimestamp)]")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                Text("[\(entry.agent.rawValue)]")
                                    .font(.caption.bold())
                                    .foregroundColor(entry.agent.color)
                                Text(entry.content)
                                    .font(.body)
                                    .foregroundColor(.primary)
                            }
                            .padding(.vertical, 2)
                            .padding(.horizontal)
                            .background(entry.agent.color.opacity(0.1))
                            .cornerRadius(5)
                            .id(entry.id) // Crucial for ScrollViewReader
                        }
                        // Invisible anchor for absolute bottom scrolling
                        Color.clear
                            .frame(height: 1)
                            .id("bottom_anchor")
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)
                }
                .onChange(of: viewModel.logEntries.count) {
                    // Always scroll to the latest entry when new ones are added
                    withAnimation(.easeOut(duration: 0.3)) {
                        proxy.scrollTo(lastEntryId ?? "bottom_anchor", anchor: .bottom)
                    }
                }
            }

            HStack {
                Button("Start Collaboration") {
                    viewModel.startCollaborationSimulation()
                }
                .buttonStyle(.borderedProminent)

                Button("Reset") {
                    viewModel.reset()
                }
                .buttonStyle(.bordered)
            }
            .padding()
        }
        .navigationTitle("Multi-Agent Log")
        .onDisappear {
            viewModel.reset()
        }
    }
}

// MARK: - Preview (for Xcode Canvas)

@available(iOS 18.0, *)
#Preview {
    MultiAgentLogView()
}
