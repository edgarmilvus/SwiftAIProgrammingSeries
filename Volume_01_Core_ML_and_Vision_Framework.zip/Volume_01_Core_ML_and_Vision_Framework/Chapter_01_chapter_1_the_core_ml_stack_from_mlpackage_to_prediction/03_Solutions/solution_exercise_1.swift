
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import CoreML
import Vision // Often used for image processing, but direct CVPixelBuffer conversion is shown here

// MARK: - Helper: UIImage to CVPixelBuffer Conversion
// This extension is crucial for converting UIImages into a format Core ML models expect.
extension UIImage {
    /// Converts a UIImage to a CVPixelBuffer, resizing it to the specified dimensions.
    /// Core ML models typically expect 0-255 pixel values, with any necessary normalization
    /// handled by the model's internal pre-processing steps (e.g., NeuralNetworkImageScaler).
    /// - Parameters:
    ///   - width: The target width for the CVPixelBuffer.
    ///   - height: The target height for the CVPixelBuffer.
    ///   - pixelFormatType: The desired pixel format (e.g., kCVPixelFormatType_32BGRA for 8-bit BGRA).
    /// - Returns: An optional CVPixelBuffer.
    func toCVPixelBuffer(width: Int, height: Int, pixelFormatType: OSType) -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        let attributes: [NSObject: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ]

        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormatType,
                                         attributes as CFDictionary,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess, let finalPixelBuffer = pixelBuffer else {
            print("Failed to create CVPixelBuffer: \(status)")
            return nil
        }

        CVPixelBufferLockBaseAddress(finalPixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(finalPixelBuffer, .readOnly) }

        let pixelData = CVPixelBufferGetBaseAddress(finalPixelBuffer)
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()

        // Use BGRA format for the context, which is common for Core ML image inputs.
        // `noneSkipFirst` for no alpha, `byteOrder32Little` for BGRA.
        guard let context = CGContext(data: pixelData,
                                      width: width,
                                      height: height,
                                      bitsPerComponent: 8,
                                      bytesPerRow: CVPixelBufferGetBytesPerRow(finalPixelBuffer),
                                      space: rgbColorSpace,
                                      bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue) else {
            print("Failed to create CGContext for CVPixelBuffer.")
            return nil
        }

        // Flip the image vertically, as Core Graphics draws from bottom-left
        context.translateBy(x: 0, y: CGFloat(height))
        context.scaleBy(x: 1.0, y: -1.0)

        // Draw the UIImage into the CVPixelBuffer's context
        UIGraphicsPushContext(context)
        self.draw(in: CGRect(x: 0, y: 0, width: width, height: height))
        UIGraphicsPopContext()

        return finalPixelBuffer
    }
}

// MARK: - PlantClassifier (Assumed auto-generated Core ML model interface)
// For demonstration, let's define a simplified mock interface.
// In a real project, Xcode generates this from your .mlpackage.
struct PlantClassifierInput : MLFeatureProvider {
    var image: CVPixelBuffer

    var featureNames: Set<String> {
        return ["image"]
    }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "image" {
            return MLFeatureValue(pixelBuffer: image)
        }
        return nil
    }
}

struct PlantClassifierOutput : MLFeatureProvider {
    var classLabel: String
    var classLabelProbs: [String : Double]

    var featureNames: Set<String> {
        return ["classLabel", "classLabelProbs"]
    }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "classLabel" {
            return MLFeatureValue(string: classLabel)
        }
        if featureName == "classLabelProbs" {
            return MLFeatureValue(dictionary: classLabelProbs as [AnyHashable : NSNumber])
        }
        return nil
    }
}

// Mock MLModel class for demonstration.
// In a real app, this would be the actual auto-generated class from your .mlpackage.
class PlantClassifier {
    // Placeholder for the actual Core ML model instance
    let model: MLModel

    // Initialize with a dummy model or load a real one
    init() throws {
        // In a real app, you would load your model like this:
        // let config = MLModelConfiguration()
        // self.model = try PlantClassifier(configuration: config).model // assuming PlantClassifier is the generated class
        
        // For this exercise, we'll create a dummy MLModel that always returns the same prediction
        // This is NOT how you would load a model in a real app, but allows the example to compile.
        let url = Bundle.main.url(forResource: "PlantClassifier", withExtension: "mlmodelc")! // .mlmodelc for compiled model
        self.model = try MLModel(contentsOf: url) // This will fail if no actual model is present
    }

    func prediction(input: PlantClassifierInput) throws -> PlantClassifierOutput {
        // In a real app, you'd call the underlying MLModel's prediction method:
        // let predictionOutput = try model.prediction(from: input)
        // return PlantClassifierOutput(classLabel: predictionOutput.classLabel, classLabelProbs: predictionOutput.classLabelProbs)

        // For this mock, we return a fixed output
        print("Performing mock prediction...")
        return PlantClassifierOutput(classLabel: "Sunflower", classLabelProbs: ["Sunflower": 0.95, "Rose": 0.03, "Tulip": 0.02])
    }
}


// MARK: - Core ML Workflow Implementation Example
class PlantIdentificationService {
    private var plantClassifier: PlantClassifier?

    init() {
        do {
            // Instantiate your Core ML model
            plantClassifier = try PlantClassifier()
            print("PlantClassifier model loaded successfully.")
        } catch {
            print("Error loading PlantClassifier model: \(error)")
        }
    }

    /// Performs plant classification on a given UIImage.
    /// - Parameter image: The UIImage to classify.
    /// - Parameter completion: A closure to call with the classification result or an error.
    func classifyPlant(image: UIImage, completion: @escaping (Result<(String, Double), Error>) -> Void) {
        guard let classifier = plantClassifier else {
            completion(.failure(PlantClassifierError.modelNotLoaded))
            return
        }

        // 1. Get model's expected input dimensions and pixel format
        // These values should come from your model's generated interface (e.g., PlantClassifierInput.image.size)
        let modelInputWidth = 224
        let modelInputHeight = 224
        let modelPixelFormat = kCVPixelFormatType_32BGRA // Common format for image models

        // 2. Prepare Input: Convert UIImage to CVPixelBuffer
        guard let pixelBuffer = image.toCVPixelBuffer(width: modelInputWidth, height: modelInputHeight, pixelFormatType: modelPixelFormat) else {
            completion(.failure(PlantClassifierError.imageConversionFailed))
            return
        }

        // 3. Perform Prediction
        do {
            let input = PlantClassifierInput(image: pixelBuffer)
            let output = try classifier.prediction(input: input)

            // 4. Output Interpretation
            let predictedLabel = output.classLabel
            let confidence = output.classLabelProbs[predictedLabel] ?? 0.0

            // 5. Display Results (via completion handler)
            DispatchQueue.main.async { // Ensure completion is called on main thread for UI updates
                completion(.success((predictedLabel, confidence)))
            }

        } catch {
            DispatchQueue.main.async {
                completion(.failure(error))
            }
        }
    }

    enum PlantClassifierError: Error, LocalizedError {
        case modelNotLoaded
        case imageConversionFailed
        case predictionFailed(Error)

        var errorDescription: String? {
            switch self {
            case .modelNotLoaded: return "The Core ML model could not be loaded."
            case .imageConversionFailed: return "Failed to convert image to the required pixel buffer format."
            case .predictionFailed(let error): return "Prediction failed: \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - Example Usage (e.g., in a ViewController)
/*
// Assume you have a UIImage, e.g., from a Photo Library picker or asset catalog
let plantImage = UIImage(named: "sunflower_example")! // Replace with your image

let service = PlantIdentificationService()
service.classifyPlant(image: plantImage) { result in
    switch result {
    case .success(let (label, confidence)):
        let confidencePercentage = String(format: "%.2f%%", confidence * 100)
        print("Predicted Plant: \(label) with confidence: \(confidencePercentage)")
        // Update your UI here, e.g., a UILabel
        // self.plantLabel.text = label
        // self.confidenceLabel.text = confidencePercentage
    case .failure(let error):
        print("Classification error: \(error.localizedDescription)")
        // Show an alert or error message to the user
    }
}
*/
