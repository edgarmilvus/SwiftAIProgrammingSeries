
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

@available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, visionOS 1.0, *)
@MainActor
class ImageProgressViewModel: ObservableObject {
    @Published var progressFraction: Double = 0.0
    @Published var phaseText: String = "Idle"
    @Published var isTraining: Bool = false

    private var progressTask: Task<Void, Never>?

    func startTraining() {
        guard !isTraining else { return }
        isTraining = true
        progressFraction = 0.0
        phaseText = "Starting training..."

        let mlProgress = createMockMLProgress(iterations: 75, delay: .milliseconds(150))

        progressTask = Task {
            do {
                for await event in mlProgress {
                    switch event {
                    case .snapshot(let snapshot):
                        await MainActor.run {
                            self.progressFraction = snapshot.fractionCompleted
                            self.phaseText = "Phase: \(snapshot.phase.description)"
                        }
                    case .completed:
                        await MainActor.run {
                            self.progressFraction = 1.0
                            self.phaseText = "Training Completed!"
                            self.isTraining = false
                        }
                    case .failed(let error):
                        await MainActor.run {
                            self.phaseText = "Training Failed: \(error.localizedDescription)"
                            self.isTraining = false
                        }
                    }
                }
            } catch {
                await MainActor.run {
                    self.phaseText = "Error observing progress: \(error.localizedDescription)"
                    self.isTraining = false
                }
            }
        }
    }

    func stopTraining() {
        progressTask?.cancel()
        progressTask = nil
        if isTraining {
            phaseText = "Training stopped."
            isTraining = false
        }
    }
}

@available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, visionOS 1.0, *)
struct ImageProgressView: View {
    @StateObject private var viewModel = ImageProgressViewModel()

    var body: some View {
        VStack(spacing: 20) {
            Text("Image Classifier Training")
                .font(.headline)

            ProgressView(value: viewModel.progressFraction)
                .progressViewStyle(.linear)
                .padding(.horizontal)

            Text(viewModel.phaseText)
                .font(.body)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)

            HStack {
                Button("Start Training") {
                    viewModel.startTraining()
                }
                .disabled(viewModel.isTraining)

                Button("Stop Training") {
                    viewModel.stopTraining()
                }
                .disabled(!viewModel.isTraining)
            }
        }
        .padding()
    }
}
