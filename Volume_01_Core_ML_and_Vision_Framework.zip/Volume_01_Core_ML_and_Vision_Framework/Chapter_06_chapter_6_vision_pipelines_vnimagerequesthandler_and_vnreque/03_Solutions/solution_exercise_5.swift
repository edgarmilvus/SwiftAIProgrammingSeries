
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Vision
import CoreML
import CoreImage
import Foundation
import UIKit // For UIImage conversion in example usage

// IMPORTANT: For this example to run, you need a Core ML model named 'MyCustomClassifier.mlmodel'
// dragged into your Xcode project. Xcode will compile it to 'MyCustomClassifier.mlmodelc'
// and generate a Swift class 'MyCustomClassifier'.
//
// If you don't have one, you can create a simple image classifier using Apple's Create ML.
// For instance, a model that classifies between two types of art, e.g., "Impressionism" and "Abstract".

@available(iOS 18.0, macOS 15.0, *)
func classifyImageWithCustomCoreMLModel(image: CIImage) async throws -> (label: String, confidence: Float)? {
    // 1. Load the custom Core ML model
    // The .mlmodelc is the compiled version of your .mlmodel, located in the app bundle.
    // If you dragged 'MyCustomClassifier.mlmodel' into Xcode, it gets compiled automatically.
    guard let modelURL = Bundle.main.url(forResource: "MyCustomClassifier", withExtension: "mlmodelc") else {
        throw NSError(domain: "CustomCoreMLVision", code: 1, userInfo: [NSLocalizedDescriptionKey: "MyCustomClassifier.mlmodelc not found in bundle. Ensure your .mlmodel is in the project and compiled."])
    }

    let mlModel: MLModel
    do {
        // MLModel.compileModel(at:) is typically used for dynamic model loading.
        // For models bundled with the app, you can often directly use MLModel(contentsOf: modelURL)
        // if the modelURL already points to the compiled .mlmodelc.
        // However, if the modelURL points to the original .mlmodel, compileModel is needed.
        // The most robust way is to use the generated class (e.g., MyCustomClassifier().model)
        // or check if the URL is already compiled.
        // For simplicity and robustness, let's assume 'modelURL' is the compiled .mlmodelc.
        mlModel = try MLModel(contentsOf: modelURL)
    } catch {
        throw NSError(domain: "CustomCoreMLVision", code: 2, userInfo: [NSLocalizedDescriptionKey: "Failed to load MLModel: \(error.localizedDescription)"])
    }

    // 2. Create a VNCoreMLModel from your MLModel
    let vnCoreMLModel = try VNCoreMLModel(for: mlModel)

    // 3. Create a VNCoreMLRequest
    // Using currentRevision for broadest compatibility. Specific revisions (e.g., .revision2)
    // might be needed for models with specific input/output types or features.
    let request = VNCoreMLRequest(model: vnCoreMLModel)
    
    // Configure the request if necessary.
    // This tells Vision how to prepare the input image for the Core ML model.
    // .centerCrop is common for image classification models.
    request.imageCropAndScaleOption = .centerCrop

    // 4. Create VNImageRequestHandler
    let handler = VNImageRequestHandler(ciImage: image, options: [:])

    // 5. Perform the request using async/await with a continuation
    return try await withCheckedThrowingContinuation { continuation in
        request.completionHandler = { vnRequest, error in
            if let error = error {
                continuation.resume(throwing: error)
                return
            }

            // 6. Result Processing: Cast observations to VNClassificationObservation
            // VNCoreMLRequest typically outputs VNClassificationObservation if the Core ML model
            // has an output feature of type MLMultiArray that Vision can interpret as class probabilities.
            guard let observations = vnRequest.results as? [VNClassificationObservation],
                  let topObservation = observations.first else {
                continuation.resume(returning: nil) // No observations or no top observation
                return
            }
            continuation.resume(returning: (label: topObservation.identifier, confidence: topObservation.confidence))
        }

        do {
            try handler.perform([request])
        } catch {
            // Error during the handler.perform call itself
            continuation.resume(throwing: error)
        }
    }
}

// Example Usage:
// func identifyArtStyle() async {
//     // Assuming you have an image in your assets that your custom model can classify.
//     // Replace "mona_lisa" with an appropriate image name for your model.
//     guard let uiImage = UIImage(named: "mona_lisa"),
//           let ciImage = CIImage(image: uiImage) else {
//         print("Error: Image 'mona_lisa' not found or could not be loaded.")
//         return
//     }
//
//     print("Classifying image with custom Core ML model...")
//     do {
//         if let prediction = try await classifyImageWithCustomCoreMLModel(image: ciImage) {
//             print("Detected: \(prediction.label) with confidence \(String(format: "%.2f", prediction.confidence * 100))%")
//         } else {
//             print("No prediction made or model returned no observations.")
//         }
//     } catch {
//         print("Error classifying image with custom model: \(error.localizedDescription)")
//     }
// }
//
// // Call this from an async context, e.g., a Task in viewDidLoad or a button action
// Task {
//     await identifyArtStyle()
// }
