
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

/// ViewModel for the chat interface, managing messages, AI interaction, and UI state.
@MainActor // Ensures all @Published updates happen on the main thread
class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var currentInput: String = ""
    @Published var isLoadingAIResponse: Bool = false
    @Published var errorMessage: String? = nil

    private let aiModel = MockAIModelKit()
    private var streamingTask: Task<Void, Never>? // To manage cancellation of AI streaming

    /// Sends the current user input as a message and requests an AI response.
    func sendMessage() {
        guard !currentInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        errorMessage = nil // Clear any previous errors
        let userMessage = ChatMessage(content: currentInput, isFromUser: true)
        messages.append(userMessage)
        currentInput = "" // Clear input field immediately
        HapticFeedbackManager.shared.impactLight() // Haptic feedback for sending

        requestAIResponse(for: userMessage.content)
    }

    /// Requests an AI response for a given prompt, handling streaming and errors.
    /// - Parameter prompt: The user's prompt to send to the AI.
    private func requestAIResponse(for prompt: String) {
        isLoadingAIResponse = true
        var aiResponseContent = ""
        let aiMessageId = UUID() // Pre-generate ID for the AI message
        messages.append(ChatMessage(id: aiMessageId, content: "", isFromUser: false)) // Add an empty message placeholder

        streamingTask = Task {
            do {
                for try await token in aiModel.streamResponse(for: prompt) {
                    // Check for cancellation before updating UI
                    try Task.checkCancellation()

                    aiResponseContent += token
                    // Find the placeholder and update its content
                    if let index = messages.firstIndex(where: { $0.id == aiMessageId }) {
                        messages[index] = ChatMessage(id: aiMessageId, content: aiResponseContent, isFromUser: false)
                    }
                }
                isLoadingAIResponse = false
                HapticFeedbackManager.shared.notification(.success) // Success haptic
            } catch {
                isLoadingAIResponse = false
                errorMessage = error.localizedDescription
                HapticFeedbackManager.shared.notification(.error) // Error haptic
                // Remove the empty placeholder if an error occurred before any content was streamed
                if aiResponseContent.isEmpty, let index = messages.firstIndex(where: { $0.id == aiMessageId }) {
                    messages.remove(at: index)
                }
                print("AI streaming error: \(error.localizedDescription)")
            }
        }
    }

    /// Cancels any ongoing AI response streaming task.
    func cancelStreaming() {
        streamingTask?.cancel()
        streamingTask = nil
        isLoadingAIResponse = false
        errorMessage = "AI response generation cancelled."
    }
}
