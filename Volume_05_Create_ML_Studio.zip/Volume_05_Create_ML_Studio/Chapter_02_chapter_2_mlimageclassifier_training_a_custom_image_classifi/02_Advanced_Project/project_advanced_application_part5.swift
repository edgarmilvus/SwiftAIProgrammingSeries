
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

import UIKit
import CoreGraphics
import Photos // For PHAsset

/// A protocol for any type that can provide image data for classification.
protocol ImageInput {
    var id: String { get }
    func loadImageData() async -> Data?
}

// MARK: - UIImage and PHAsset Extensions for ImageInput and CVPixelBuffer Conversion

extension UIImage {
    /// Converts a UIImage to a CVPixelBuffer, which is the required input format for Vision requests.
    /// - Returns: An optional `CVPixelBuffer` if the conversion is successful.
    func toCVPixelBuffer() -> CVPixelBuffer? {
        let attrs = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferIOSurfacePropertiesKey: CFDictionaryCreate(nil, nil, nil, 0, nil, nil) as Dictionary?
        ] as CFDictionary
        var pixelBuffer: CVPixelBuffer?
        let width = Int(self.size.width)
        let height = Int(self.size.height)

        // Create a CVPixelBuffer with a BGRA pixel format.
        // VNCoreMLRequest often expects BGRA or ARGB.
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         kCVPixelFormatType_32BGRA, // Ensure correct pixel format
                                         attrs,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess, let pBuffer = pixelBuffer else {
            return nil
        }

        CVPixelBufferLockBaseAddress(pBuffer, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(pBuffer)

        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        guard let context = CGContext(data: pixelData,
                                      width: width,
                                      height: height,
                                      bitsPerComponent: 8,
                                      bytesPerRow: CVPixelBufferGetBytesPerRow(pBuffer),
                                      space: rgbColorSpace,
                                      bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue) else {
            return nil
        }

        context.translateBy(x: 0, y: CGFloat(height))
        context.scaleBy(x: 1.0, y: -1.0)

        UIGraphicsPushContext(context)
        self.draw(in: CGRect(x: 0, y: 0, width: width, height: height))
        UIGraphicsPopContext()
        CVPixelBufferUnlockBaseAddress(pBuffer, CVPixelBufferLockFlags(rawValue: 0))

        return pBuffer
    }

    /// Resizes the image to the specified target size, maintaining aspect ratio by fitting.
    /// - Parameter targetSize: The desired size.
    /// - Returns: A new `UIImage` scaled to the target size.
    func resized(to targetSize: CGSize) -> UIImage? {
        let scale = min(targetSize.width / size.width, targetSize.height / size.height)
        let newSize = CGSize(width: size.width * scale, height: size.height * scale)
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)

        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage
    }
}

// Example conformance for PHAsset (requires Photos framework)
@available(iOS 15.0, *)
extension PHAsset: ImageInput {
    var id: String {
        return self.localIdentifier
    }

    /// Asynchronously loads image data for the PHAsset.
    /// This is a simplified version; in a real app, you'd use PHImageManager
    /// with specific options for performance (e.g., targetSize, contentMode).
    func loadImageData() async -> Data? {
        let manager = PHImageManager.default()
        let options = PHImageRequestOptions()
        options.isSynchronous = true // Simplified for example; prefer async = false with completion handler
        options.deliveryMode = .highQualityFormat
        options.resizeMode = .exact

        return await withCheckedContinuation { continuation in
            manager.requestImageDataAndOrientation(for: self, options: options) { data, _, _, _ in
                continuation.resume(returning: data)
            }
        }
    }
}

// MARK: - Mock Image Input for Demonstration

/// A mock implementation of `ImageInput` for testing without requiring actual photos.
struct MockImageInput: ImageInput {
    let id: String
    let imageName: String // Name of an image asset in the bundle

    func loadImageData() async -> Data? {
        guard let image = UIImage(named: imageName) else {
            print("MockImageInput: Image '\(imageName)' not found in assets.")
            return nil
        }
        return image.jpegData(compressionQuality: 0.9)
    }
}
