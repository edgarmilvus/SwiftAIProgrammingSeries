
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CoreML

// 1. Simulate Raw Sensor Data
struct SensorReading {
    let temperature: Float
    let pressure: Float
    let vibration: Float
}

// Helper to generate some dummy data
func generateDummySensorData(count: Int) -> [SensorReading] {
    var data: [SensorReading] = []
    for i in 0..<count {
        let temp = 20.0 + sin(Float(i) * 0.1) * 5.0 + Float.random(in: -0.5...0.5)
        let pressure = 100.0 + cos(Float(i) * 0.05) * 10.0 + Float.random(in: -1.0...1.0)
        let vibration = 0.5 + sin(Float(i) * 0.2) * 0.3 + Float.random(in: -0.1...0.1)
        data.append(SensorReading(temperature: temp, pressure: pressure, vibration: vibration))
    }
    return data
}

// 2. Implement the windowing function.
func createTimeSeriesSample(window: [SensorReading]) throws -> MLMultiArray {
    guard window.count == 10 else {
        throw NSError(domain: "TimeSeriesError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Window must contain exactly 10 readings."])
    }

    let sequenceLength = 10
    let numFeatures = 3 // temperature, pressure, vibration

    // Initialize an MLMultiArray with shape [1, 10, 3] and .float32 data type.
    let shape: [NSNumber] = [1, NSNumber(value: sequenceLength), NSNumber(value: numFeatures)]
    let sampleMultiArray = try MLMultiArray(shape: shape, dataType: .float32)

    // Loop through the 'window' and assign the sensor values
    // to the correct indices in the MLMultiArray.
    // Remember the order: [batch_index, sequence_index, feature_index].
    for sequenceIndex in 0..<sequenceLength {
        let reading = window[sequenceIndex]
        sampleMultiArray[[0, sequenceIndex, 0]] = NSNumber(value: reading.temperature)
        sampleMultiArray[[0, sequenceIndex, 1]] = NSNumber(value: reading.pressure)
        sampleMultiArray[[0, sequenceIndex, 2]] = NSNumber(value: reading.vibration)
    }

    return sampleMultiArray
}

// 3. Implement the batching function.
func createTimeSeriesBatch(windows: [[SensorReading]]) throws -> MLMultiArray {
    guard !windows.isEmpty else {
        throw NSError(domain: "TimeSeriesError", code: 2, userInfo: [NSLocalizedDescriptionKey: "Input 'windows' cannot be empty."])
    }
    for window in windows {
        guard window.count == 10 else {
            throw NSError(domain: "TimeSeriesError", code: 3, userInfo: [NSLocalizedDescriptionKey: "Each window must contain exactly 10 readings."])
        }
    }

    let batchSize = windows.count
    let sequenceLength = 10
    let numFeatures = 3

    // Initialize an MLMultiArray with shape [batchSize, sequenceLength, numFeatures] and .float32 data type.
    let shape: [NSNumber] = [NSNumber(value: batchSize), NSNumber(value: sequenceLength), NSNumber(value: numFeatures)]
    let batchMultiArray = try MLMultiArray(shape: shape, dataType: .float32)

    // Use nested loops to efficiently populate the MLMultiArray.
    // The direct indexing `multiArray[[d0, d1, d2]]` is often optimized internally.
    for batchIndex in 0..<batchSize {
        let currentWindow = windows[batchIndex]
        for sequenceIndex in 0..<sequenceLength {
            let reading = currentWindow[sequenceIndex]
            batchMultiArray[[batchIndex, sequenceIndex, 0]] = NSNumber(value: reading.temperature)
            batchMultiArray[[batchIndex, sequenceIndex, 1]] = NSNumber(value: reading.pressure)
            batchMultiArray[[batchIndex, sequenceIndex, 2]] = NSNumber(value: reading.vibration)
        }
    }

    return batchMultiArray
}

// Example usage (for testing your implementation):
/*
let allSensorData = generateDummySensorData(count: 50) // 50 readings total

// Test windowing function
do {
    let singleWindow = Array(allSensorData[0..<10])
    let sample = try createTimeSeriesSample(window: singleWindow)
    print("Single sample MLMultiArray shape: \(sample.shape)")
    // print("First value: \(sample[[0, 0, 0]].floatValue)") // Should be temperature of first reading
} catch {
    print("Error creating sample: \(error)")
}

// Test batching function
do {
    let batchOfWindows: [[SensorReading]] = [
        Array(allSensorData[0..<10]),
        Array(allSensorData[10..<20]),
        Array(allSensorData[20..<30]),
        Array(allSensorData[30..<40]),
        Array(allSensorData[40..<50])
    ]
    let batch = try createTimeSeriesBatch(windows: batchOfWindows)
    print("Batch MLMultiArray shape: \(batch.shape)")
    // print("First value of first window: \(batch[[0, 0, 0]].floatValue)")
    // print("First value of second window: \(batch[[1, 0, 0]].floatValue)")
} catch {
    print("Error creating batch: \(error)")
}
*/
