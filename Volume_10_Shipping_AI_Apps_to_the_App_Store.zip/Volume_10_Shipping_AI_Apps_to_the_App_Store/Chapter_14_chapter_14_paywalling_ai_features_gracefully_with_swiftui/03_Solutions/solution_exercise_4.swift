
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI

@available(iOS 18.0, *)
enum PaywallType: Identifiable {
    case featureLocked(String)
    case outOfCredits
    case subscriptionUpgrade
    
    var id: String {
        switch self {
        case .featureLocked(let name): return "feature-\(name)"
        case .outOfCredits: return "credits"
        case .subscriptionUpgrade: return "upgrade"
        }
    }
}

@available(iOS 18.0, *)
@Observable
class PaywallCoordinator {
    var activePaywall: PaywallType?
}

@available(iOS 18.0, *)
struct FeatureGateModifier: ViewModifier {
    @Environment(PaywallCoordinator.self) var coordinator
    let action: () -> Void
    let errorType: PaywallType
    let isAllowed: Bool // Logic to determine if the gate should open
    
    func body(content: Content) -> some View {
        content.onTapGesture {
            if isAllowed {
                action()
            } else {
                // Trigger the specific paywall type
                coordinator.activePaywall = errorType
            }
        }
    }
}

// Helper for cleaner syntax
@available(iOS 18.0, *)
extension View {
    func featureGate<T>(
        _ coordinator: PaywallCoordinator,
        isAllowed: Bool,
        errorType: PaywallType,
        action: @escaping () -> Void
    ) -> some View {
        self.modifier(FeatureGateModifier(coordinator: coordinator, action: action, errorType: errorType, isAllowed: isAllowed))
    }
}

@available(iOS 18.0, *)
struct ContentView: View {
    @State private var coordinator = PaywallCoordinator()
    @State private var hasCredits = false // Mock state
    @State private var isPro = false      // Mock state
    
    var body: some View {
        NavigationStack {
            List {
                Section("AI Tools") {
                    // Case 1: Feature is locked for non-Pro users
                    Button("Cinematic Lighting Filter") {
                        print("Applying filter...")
                    }
                    .featureGate(coordinator, 
                                 isAllowed: isPro, 
                                 errorType: .featureLocked("Cinematic Lighting")) {
                        print("Filter applied!")
                    }
                    
                    // Case 2: Feature is Pro, but user is out of credits
                    Button("Generate High-Res Image") {
                        print("Generating...")
                    }
                    .featureGate(coordinator, 
                                 isAllowed: hasCredits, 
                                 errorType: .outOfCredits) {
                        print("Image generated!")
                    }
                }
                
                Section("Settings") {
                    Toggle("Simulate Pro Status", isOn: $isPro)
                    Toggle("Simulate Credits", isOn: $hasCredits)
                }
            }
            .navigationTitle("Lumina AI")
            // The Item-Based Sheet Pattern
            .sheet(item: $coordinator.activePaywall) { type in
                PaywallView(type: type)
            }
        }
        .environment(coordinator)
    }
}

@available(iOS 18.0, *)
struct PaywallView: View {
    let type: PaywallType
    
    var body: some View {
        VStack(spacing: 25) {
            Image(systemName: icon)
                .font(.system(size: 60))
                .foregroundStyle(gradient)
            
            Text(title)
                .font(.title.bold())
            
            Text(description)
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
            
            Button(action: { /* Purchase Logic */ }) {
                Text(buttonText)
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(.blue, in: RoundedRectangle(cornerRadius: 12))
            }
        }
        .padding(30)
        .presentationDetents([.medium])
    }
    
    // Dynamic Content based on PaywallType
    private var icon: String {
        switch type {
        case .featureLocked: return "lock.fill"
        case .outOfCredits: return "drop.fill"
        case .subscriptionUpgrade: return "star.fill"
        }
    }
    
    private var title: String {
        switch type {
        case .featureLocked(let name): return "\(name) is Pro"
        case .outOfCredits: return "Out of Credits"
        case .subscriptionUpgrade: return "Go Pro"
        }
    }
    
    private var description: String {
        switch type {
        case .featureLocked: return "Unlock cinematic lighting and professional filters with a Pro subscription."
        case .outOfCredits: return "You've used your free daily credits. Top up to keep creating!"
        case .subscriptionUpgrade: return "Get unlimited access to all AI models and features."
        }
    }
    
    private var buttonText: String {
        switch type {
        case .featureLocked, .subscriptionUpgrade: return "Upgrade Now"
        case .outOfCredits: return "Buy Credits"
        }
    }
    
    private var gradient: LinearGradient {
        LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}
