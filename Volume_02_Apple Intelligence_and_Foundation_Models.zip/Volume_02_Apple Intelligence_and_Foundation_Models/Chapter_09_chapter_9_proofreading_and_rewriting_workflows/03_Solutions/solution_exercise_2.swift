
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import NaturalLanguage
import UIKit

// Ensure iOS 18.0 availability for NLWritingTool
@available(iOS 18.0, *)
class RephraseViewController: UIViewController, UITextViewDelegate {

    let textView = UITextView()
    let rephraseButton = UIButton(type: .system)
    private let writingTool = NLWritingTool()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        textView.delegate = self
        // Initial state check
        textViewDidChangeSelection(textView)
    }

    private func setupUI() {
        // MARK: - TextView Setup
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.font = UIFont.preferredFont(forTextStyle: .body)
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 0.5
        textView.layer.cornerRadius = 5
        textView.textContainerInset = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        view.addSubview(textView)

        // MARK: - Rephrase Button Setup
        rephraseButton.translatesAutoresizingMaskIntoConstraints = false
        rephraseButton.setTitle("Rephrase Selected Sentence", for: .normal)
        rephraseButton.addTarget(self, action: #selector(rephraseSelectedSentence), for: .touchUpInside)
        rephraseButton.isEnabled = false // Initially disabled
        view.addSubview(rephraseButton)

        // MARK: - Layout Constraints
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 200),

            rephraseButton.topAnchor.constraint(equalTo: textView.bottomAnchor, constant: 20),
            rephraseButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            rephraseButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    // MARK: - UITextViewDelegate

    func textViewDidChangeSelection(_ textView: UITextView) {
        guard let selectedTextRange = textView.selectedTextRange,
              let selectedText = textView.text(in: selectedTextRange),
              !selectedText.isEmpty else {
            rephraseButton.isEnabled = false
            return
        }

        // Simple heuristic for sentence detection:
        // - Text must not be empty.
        // - Text should end with a sentence-ending punctuation mark (., !, ?)
        // - Text should not contain multiple sentence-ending punctuation marks in the middle.
        let trimmedText = selectedText.trimmingCharacters(in: .whitespacesAndNewlines)
        let hasSentenceEnd = trimmedText.last.map { ".!?".contains($0) } ?? false

        // More robust check: Use `NLLanguageRecognizer` or `NLTokenizer` for sentence segmentation
        // For this exercise, a heuristic is sufficient.
        let tokenizer = NLTokenizer(unit: .sentence)
        tokenizer.string = selectedText
        let sentenceRanges = tokenizer.tokens(for: selectedText.startIndex..<selectedText.endIndex)

        // If the selected text exactly matches one sentence token, it's likely a complete sentence.
        let isCompleteSentence = sentenceRanges.count == 1 &&
                                 String(selectedText[sentenceRanges.first!]) == selectedText

        rephraseButton.isEnabled = isCompleteSentence // Enable if it's a complete sentence
    }

    // MARK: - Rephrase Action

    @objc private func rephraseSelectedSentence() {
        guard let selectedTextRange = textView.selectedTextRange,
              let selectedText = textView.text(in: selectedTextRange),
              !selectedText.isEmpty else { return }

        // Show a loading indicator
        let activityIndicator = UIActivityIndicatorView(style: .medium)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(activityIndicator)
        NSLayoutConstraint.activate([
            activityIndicator.centerXAnchor.constraint(equalTo: rephraseButton.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: rephraseButton.centerYAnchor)
        ])
        activityIndicator.startAnimating()
        rephraseButton.isEnabled = false // Disable button during processing

        Task { @MainActor in
            do {
                let options = NLWritingTool.Options() // No specific options needed for basic rephrase
                let suggestion = try await writingTool.rephrase(selectedText, options: options)

                // Hide loading indicator
                activityIndicator.stopAnimating()
                activityIndicator.removeFromSuperview()
                rephraseButton.isEnabled = true // Re-enable button

                // Present 'suggestion' to the user for review
                presentRephraseSuggestion(original: selectedText, suggestion: suggestion, range: selectedTextRange)

            } catch {
                // Hide loading indicator
                activityIndicator.stopAnimating()
                activityIndicator.removeFromSuperview()
                rephraseButton.isEnabled = true // Re-enable button

                print("Error rephrasing: \(error.localizedDescription)")
                let alert = UIAlertController(title: "Rephrase Error", message: error.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                present(alert, animated: true)
            }
        }
    }

    private func presentRephraseSuggestion(original: String, suggestion: String, range: UITextRange) {
        let alert = UIAlertController(title: "Rephrase Suggestion", message: nil, preferredStyle: .alert)

        // Use attributed string for richer message display
        let attributedMessage = NSMutableAttributedString()
        attributedMessage.append(NSAttributedString(string: "Original:\n", attributes: [.font: UIFont.systemFont(ofSize: 15, weight: .bold)]))
        attributedMessage.append(NSAttributedString(string: "\(original)\n\n", attributes: [.font: UIFont.systemFont(ofSize: 15)]))
        attributedMessage.append(NSAttributedString(string: "Suggestion:\n", attributes: [.font: UIFont.systemFont(ofSize: 15, weight: .bold)]))
        attributedMessage.append(NSAttributedString(string: suggestion, attributes: [.font: UIFont.systemFont(ofSize: 15, weight: .medium)]))

        alert.setValue(attributedMessage, forKey: "attributedMessage")

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Apply Suggestion", style: .default) { [weak self] _ in
            self?.applyRephrasedText(suggestion, to: range)
        })
        present(alert, animated: true)
    }

    private func applyRephrasedText(_ newText: String, to range: UITextRange) {
        // Replace the selected text with the new rephrased text
        textView.replace(range, withText: newText)
        
        // Optionally, move the cursor to the end of the newly inserted text
        if let newStart = textView.position(from: range.start, offset: newText.utf16.count) {
            textView.selectedTextRange = textView.textRange(from: newStart, to: newStart)
        }
    }
}
