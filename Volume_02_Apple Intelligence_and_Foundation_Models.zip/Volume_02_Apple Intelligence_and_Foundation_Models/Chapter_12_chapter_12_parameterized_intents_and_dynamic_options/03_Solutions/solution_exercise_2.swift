
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import AppIntents
import Foundation // For UUID

// MARK: - Contact AppEntity
// Define your Contact struct here, conforming to AppEntity, Codable, and Identifiable.
// It should have properties like 'id', 'name', 'phoneNumber'.
// Implement 'displayRepresentation' for AppEntity conformance.
@available(iOS 18.0, *)
struct Contact: AppEntity, Codable, Identifiable {
    var id: UUID
    var name: String
    var phoneNumber: String

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Contact"

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(title: "\(name)", subtitle: "\(phoneNumber)")
    }
}

// MARK: - ContactProvider
@available(iOS 18.0, *)
struct ContactProvider: DynamicOptionsProvider {
    typealias Result = Contact // Use your Contact AppEntity

    // A fixed, in-memory list of Contact objects
    private let allContacts: [Contact] = [
        Contact(id: UUID(), name: "Alice Smith", phoneNumber: "555-1234"),
        Contact(id: UUID(), name: "Bob Johnson", phoneNumber: "555-5678"),
        Contact(id: UUID(), name: "Charlie Brown", phoneNumber: "555-9012"),
        Contact(id: UUID(), name: "Diana Prince", phoneNumber: "555-3456"),
        Contact(id: UUID(), name: "Eve Adams", phoneNumber: "555-7890")
    ]

    func suggestedOptions() async throws -> [Contact] {
        // Return the full fixed list of contacts as suggestions
        return allContacts
    }

    func defaultOptions() async throws -> [Contact] {
        // Return a subset of suggestedOptions or the full list if applicable
        // For this exercise, return a few prominent contacts
        return Array(allContacts.prefix(3))
    }

    func options(for identifiers: [Contact.ID]) async throws -> [Contact] {
        // Retrieve specific contacts by their IDs from your fixed list.
        return allContacts.filter { identifiers.contains($0.id) }
    }

    func suggestedOptions(for searchTerm: String?) async throws -> [Contact] {
        guard let searchTerm = searchTerm, !searchTerm.isEmpty else {
            return suggestedOptions() // If no search term, return all suggestions
        }
        let lowercasedSearchTerm = searchTerm.lowercased()
        return allContacts.filter {
            $0.name.lowercased().contains(lowercasedSearchTerm)
        }
    }
}

// MARK: - CallContactIntent
@available(iOS 18.0, *)
struct CallContactIntent: AppIntent {
    static var title: LocalizedStringResource = "Call Contact"
    static var description: IntentDescription = "Initiates a call to a selected contact."

    @Parameter(title: "Contact", description: "The contact to call.", optionsProvider: ContactProvider.self)
    var contact: Contact

    func perform() async throws -> some IntentResult {
        // Implement your logic here.
        // Print a message confirming the call to the selected contact.
        print("Initiating call to \(contact.name) at \(contact.phoneNumber).")
        
        // In a real app, you would use CallKit or URL schemes to initiate a call.
        // e.g., if let url = URL(string: "tel://\(contact.phoneNumber.filter("0123456789".contains))") {
        //           await UIApplication.shared.open(url)
        //       }
        
        return .result(
            value: "Calling \(contact.name)",
            view: IntentResultView {
                VStack(alignment: .leading) {
                    Text("Calling...")
                        .font(.headline)
                    Text("\(contact.name)")
                    Text("at \(contact.phoneNumber)")
                }
            }
        )
    }
}
