
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Foundation
// import MLX // For actual MLX integration, uncomment and ensure MLX is imported

// MARK: - 1. LLMService Protocol and Implementation

/// Defines the interface for an LLM service that can stream responses.
protocol LLMService {
    func streamResponse(prompt: String) -> AsyncThrowingStream<String, Error>
}

enum LLMServiceError: Error, LocalizedError {
    case generationFailed
    case cancellationRequested

    var errorDescription: String? {
        switch self {
        case .generationFailed: return "LLM generation failed."
        case .cancellationRequested: return "LLM generation was cancelled."
        }
    }
}

/// A simulated MLX LLM service that streams a predefined response.
/// In a real application, this would interact with an MLX model loaded from disk.
final class MLXLLMService: LLMService {
    // MARK: - MLX Simulation Details
    // In a real MLX integration:
    // 1. You would load a model:
    //    private var model: MLXNN.Module?
    //    private var tokenizer: Tokenizer? // A custom tokenizer for MLXArray<Int32> <-> String
    //
    // 2. Model loading might look like:
    //    func loadModel() async throws {
    //        // Example: Load a pre-trained model like Llama, Mistral, etc.
    //        // This often involves loading weights and a tokenizer from disk.
    //        // For this exercise, we're skipping the actual MLX model setup complexity.
    //        // model = try await MLXModelLoader.loadMyLLM()
    //        // tokenizer = try await MyTokenizerLoader.loadTokenizer()
    //        print("Simulating MLX model loading...")
    //        try await Task.sleep(for: .seconds(2)) // Simulate loading time
    //        print("MLX model loaded (simulated).")
    //    }

    private let simulatedResponse = "Hello there! I am a simulated AI assistant powered by MLX Swift. I can help you with various tasks, from answering questions to generating creative content. How can I assist you today?"
    private let simulatedTokens: [String]

    init() {
        // Simulate tokenization by splitting the response into words
        simulatedTokens = simulatedResponse.components(separatedBy: " ")
    }

    /// Simulates streaming tokens from an LLM.
    /// In a real MLX scenario, this would involve:
    /// - Tokenizing the prompt into `MLXArray<Int32>`.
    /// - Passing it to `model.generate(...)` or an iterative `model.decode(...)` loop.
    /// - Decoding the generated `MLXArray<Int32>` token IDs back to `String` segments.
    /// - Yielding each decoded segment.
    func streamResponse(prompt: String) -> AsyncThrowingStream<String, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                print("MLXLLMService: Starting stream for prompt: '\(prompt)'")
                for (index, token) in simulatedTokens.enumerated() {
                    // Check for cancellation before yielding the next token
                    if Task.isCancelled {
                        print("MLXLLMService: Stream cancelled.")
                        continuation.finish(throwing: LLMServiceError.cancellationRequested)
                        return
                    }

                    // Simulate processing time for each token
                    try await Task.sleep(for: .milliseconds(70))

                    let tokenWithSpace = token + (index == simulatedTokens.count - 1 ? "" : " ")
                    continuation.yield(tokenWithSpace)
                }
                print("MLXLLMService: Stream finished.")
                continuation.finish()
            }
        }
    }
}

// MARK: - 2. ChatViewModel

/// Manages the chat interface state and interaction with the LLM service.
@MainActor // Ensures all published updates and UI-related logic run on the main actor
final class ChatViewModel: ObservableObject {
    @Published var currentResponse: String = ""
    @Published var promptInput: String = ""
    @Published var isLoading: Bool = false // To indicate if a response is being generated

    private let llmService: LLMService
    private var currentGenerationTask: Task<Void, Never>? // Store reference for cancellation

    init(llmService: LLMService = MLXLLMService()) {
        self.llmService = llmService
    }

    /// Sends the current prompt to the LLM service and streams the response.
    func sendMessage() {
        guard !promptInput.isEmpty, !isLoading else { return }

        let currentPrompt = promptInput
        promptInput = "" // Clear input field immediately
        currentResponse = "" // Clear previous response
        isLoading = true

        currentGenerationTask = Task {
            do {
                for try await token in llmService.streamResponse(prompt: currentPrompt) {
                    // Ensure UI updates are on the main actor (handled by @MainActor on class)
                    currentResponse += token
                }
            } catch {
                print("Error streaming response: \(error.localizedDescription)")
                currentResponse = "Error: \(error.localizedDescription)"
            }
            isLoading = false
            currentGenerationTask = nil // Clear task reference
        }
    }
    
    /// Clears the current response and prompt.
    func clearChat() {
        currentResponse = ""
        promptInput = ""
    }
}

// MARK: - 3. ContentView

/// The main SwiftUI view for the chat application.
struct ContentView: View {
    @StateObject private var chatViewModel = ChatViewModel() // StateObject for ViewModel lifecycle

    var body: some View {
        VStack {
            // Chat history display
            ScrollViewReader { scrollViewProxy in
                ScrollView {
                    Text(chatViewModel.currentResponse)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                        .onChange(of: chatViewModel.currentResponse) { _ in
                            // Auto-scroll to bottom when new content is added
                            scrollViewProxy.scrollTo("bottom", anchor: .bottom)
                        }
                    // Invisible view at the bottom to scroll to
                    Rectangle()
                        .fill(Color.clear)
                        .frame(height: 1)
                        .id("bottom")
                }
                .frame(maxHeight: .infinity)
                .padding(.horizontal)
            }

            // Input area
            HStack {
                TextField("Ask me anything...", text: $chatViewModel.promptInput, axis: .vertical)
                    .textFieldStyle(.roundedBorder)
                    .padding(.vertical, 8)
                    .disabled(chatViewModel.isLoading) // Disable input while streaming

                Button {
                    chatViewModel.sendMessage()
                } label: {
                    if chatViewModel.isLoading {
                        ProgressView()
                    } else {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.title)
                    }
                }
                .buttonStyle(.plain)
                .disabled(chatViewModel.promptInput.isEmpty || chatViewModel.isLoading)
            }
            .padding()
            .background(.ultraThinMaterial)
        }
        .navigationTitle("AI Assistant (MLX Swift)")
    }
}

// MARK: - Package.swift snippet for reference
/*
// Package.swift snippet for your executable target
// ...
dependencies: [
    .package(url: "https://github.com/ml-explore/mlx-swift.git", from: "0.12.0") // Use the latest stable version
],
targets: [
    .executableTarget(
        name: "YourStreamingChatApp",
        dependencies: [
            .product(name: "MLX", package: "mlx-swift"),
            .product(name: "MLXNN", package: "mlx-swift")
        ]
    )
]
// ...
*/
