
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN
import Foundation
import Observation // For @Observable

// @available(iOS 18.0, *)
// @available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, *) // @Observable availability
// func exampleObservableUsage() async {
@Observable
final class TrainingMonitor {
    var currentEpoch: Int = 0
    var currentLoss: Float = 0.0
    var isTraining: Bool = false
    var latestOutput: String = "No output yet"

    // Simulate a training process
    func startTraining(model: MySimpleMLP) async {
        isTraining = true
        for epoch in 1...5 {
            currentEpoch = epoch
            // Simulate a forward pass and loss calculation
            let input = MLXArray.rand([1, 10])
            let target = MLXArray.rand([1, 1])
            let prediction = model(input)
            let loss = MLX.mean(MLX.square(prediction - target))
            loss.eval() // Evaluate the loss

            currentLoss = loss.item() as! Float
            print("Epoch \(currentEpoch), Loss: \(currentLoss)")
            try? await Task.sleep(for: .milliseconds(200)) // Simulate work
        }
        latestOutput = "Training complete!"
        isTraining = false
    }
}

// In a SwiftUI view:
/*
struct TrainingView: View {
    @State private var monitor = TrainingMonitor()
    @State private var model = MySimpleMLP() // Ensure model is initialized

    var body: some View {
        VStack {
            Text("Epoch: \(monitor.currentEpoch)")
            Text("Loss: \(monitor.currentLoss, specifier: "%.4f")")
            Text("Status: \(monitor.isTraining ? "Training..." : "Idle")")
            Text("Output: \(monitor.latestOutput)")
            Button("Start Training") {
                Task {
                    await monitor.startTraining(model: model)
                }
            }
            .disabled(monitor.isTraining)
        }
    }
}
*/
// }
