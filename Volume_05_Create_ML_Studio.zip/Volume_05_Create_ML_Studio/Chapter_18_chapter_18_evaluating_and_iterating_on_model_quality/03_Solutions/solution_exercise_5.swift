
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

// Example of async prediction
@available(iOS 15.0, macOS 12.0, watchOS 8.0, tvOS 15.0, *)
extension BirdCallClassifier {
    func classifyBirdCallAsync(features: MLFeatureProvider) async throws -> String {
        guard let model = self.model else {
            throw NSError(domain: "BirdCallClassifier", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model not loaded."])
        }
        let prediction = try await Task.detached { // Perform on a background thread
            try model.prediction(input: features)
        }.value

        guard let predictedLabel = prediction.label else {
            throw NSError(domain: "BirdCallClassifier", code: 2, userInfo: [NSLocalizedDescriptionKey: "No prediction label found."])
        }
        return predictedLabel
    }
}
