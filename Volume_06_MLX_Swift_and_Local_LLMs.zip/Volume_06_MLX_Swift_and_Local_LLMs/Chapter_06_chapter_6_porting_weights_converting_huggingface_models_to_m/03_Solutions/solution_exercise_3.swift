
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import MLX
import MLXNN

@available(iOS 18.0, macOS 15.0, *)
class SimpleImageFeatureExtractor: MLXNN.Module {
    let conv1: MLXNN.Conv2d
    let conv2: MLXNN.Conv2d
    let linear: MLXNN.Linear

    init(inputChannels: Int, hiddenChannels: Int, outputFeatures: Int) {
        self.conv1 = MLXNN.Conv2d(
            inputChannels: inputChannels,
            outputChannels: hiddenChannels,
            kernelSize: 3,
            padding: 1
        )
        self.conv2 = MLXNN.Conv2d(
            inputChannels: hiddenChannels,
            outputChannels: hiddenChannels * 2,
            kernelSize: 3,
            padding: 1
        )
        // Assuming a fixed spatial size after convolutions for the linear layer.
        // Input image 32x32 -> MaxPool1 (16x16) -> MaxPool2 (8x8)
        // So, spatial size is 8x8.
        let finalSpatialSize = 8 * 8
        let finalChannels = hiddenChannels * 2
        self.linear = MLXNN.Linear(inputDimensions: finalChannels * finalSpatialSize, outputDimensions: outputFeatures)
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // input: [batch_size, channels, height, width]
        var x = MLX.relu(conv1(input))
        x = MLX.maxPool2d(x, kernelSize: 2, stride: 2) // Reduces spatial dimensions by 2x

        x = MLX.relu(conv2(x))
        x = MLX.maxPool2d(x, kernelSize: 2, stride: 2) // Reduces spatial dimensions by another 2x

        // Flatten for the linear layer
        let batchSize = x.dim[0]
        let flattened = MLX.flatten(x, start: 1) // [batch_size, total_features_per_image]

        return linear(flattened) // [batch_size, output_features]
    }
}

// MARK: - Weight Conversion and Inference Logic

@available(iOS 18.0, macOS 15.0, *)
func runImageFeatureExtractorExercise() {
    print("\n--- Exercise 2: Image Feature Extraction for Photo Tagging ---")

    // Model Hyperparameters
    let inputChannels = 3 // RGB image
    let hiddenChannels = 32
    let outputFeatures = 128 // Dimension of the feature vector
    let batchSize = 4
    let imageHeight = 32
    let imageWidth = 32

    // 1. Instantiate the MLX Swift model
    let model = SimpleImageFeatureExtractor(
        inputChannels: inputChannels,
        hiddenChannels: hiddenChannels,
        outputFeatures: outputFeatures
    )

    // 2. Simulate HuggingFace-like weights
    // Convolutional weights in PyTorch are typically [out_channels, in_channels, kernel_h, kernel_w]
    // MLXNN.Conv2d expects [kernel_h, kernel_w, in_channels, out_channels]
    var hfWeights: [String: MLXArray] = [:]

    // Conv1
    hfWeights["features.0.weight"] = MLXArray.rand([hiddenChannels, inputChannels, 3, 3], .float32)
    hfWeights["features.0.bias"] = MLXArray.rand([hiddenChannels], .float32)

    // Conv2
    hfWeights["features.3.weight"] = MLXArray.rand([hiddenChannels * 2, hiddenChannels, 3, 3], .float32)
    hfWeights["features.3.bias"] = MLXArray.rand([hiddenChannels * 2], .float32)

    // Linear Classifier (after flattening)
    // Calculate expected input dimensions for the linear layer
    let finalSpatialSize = (imageHeight / 4) * (imageWidth / 4) // (32/2)/2 = 8, so 8*8
    let finalChannels = hiddenChannels * 2
    let linearInputDim = finalChannels * finalSpatialSize
    hfWeights["classifier.6.weight"] = MLXArray.rand([outputFeatures, linearInputDim], .float32)
    hfWeights["classifier.6.bias"] = MLXArray.rand([outputFeatures], .float32)
    
    print("Simulated HuggingFace weights created. Total: \(hfWeights.count) tensors.")

    // 3. Implement Weight Conversion Logic
    // Convolutional weights require permutation: PyTorch (OC, IC, KH, KW) -> MLX (KH, KW, IC, OC)
    // Linear weights require transposition: PyTorch (OUT, IN) -> MLX (IN, OUT)

    model.conv1.weight = hfWeights["features.0.weight"]!.permuted(2, 3, 1, 0) // KH, KW, IC, OC
    model.conv1.bias = hfWeights["features.0.bias"]!

    model.conv2.weight = hfWeights["features.3.weight"]!.permuted(2, 3, 1, 0) // KH, KW, IC, OC
    model.conv2.bias = hfWeights["features.3.bias"]!

    model.linear.weight = hfWeights["classifier.6.weight"]!.transposed() // IN, OUT
    model.linear.bias = hfWeights["classifier.6.bias"]!

    print("Weights successfully converted and loaded into the MLX Swift model.")

    // 4. Perform Feature Extraction
    // Create a dummy input image batch: [batch_size, channels, height, width]
    let dummyImages = MLXArray.rand([batchSize, inputChannels, imageHeight, imageWidth], .float32)
    MLX.eval(dummyImages) // Force computation of dummy input

    print("\nDummy input image shape: \(dummyImages.shape)")

    let featureVectors = model(dummyImages)
    MLX.eval(featureVectors) // Force computation of the output features

    print("\nFeature extraction complete.")
    print("Output feature vectors shape: \(featureVectors.shape)") // Expected: [batch_size, output_features]
    print("Output feature vector (first image): \(featureVectors[0])")
    
    print("--- End Exercise 2 ---")
}

// Call the function to run the exercise
// runImageFeatureExtractorExercise() // Uncomment to run in a playground or main.swift
