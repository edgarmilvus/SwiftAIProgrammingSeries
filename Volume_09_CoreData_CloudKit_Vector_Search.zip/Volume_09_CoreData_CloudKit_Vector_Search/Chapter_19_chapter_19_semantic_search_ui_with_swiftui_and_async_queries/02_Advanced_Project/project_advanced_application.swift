
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import Observation
import Combine

// MARK: - Dependencies (Package.swift equivalent)
/*
 [package]
 name = "SemanticSearchEngine"
 version = "1.0.0"
 dependencies = [
     .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0"),
     // Hypothetical vector math library
     .package(url: "https://github.com/apple/swift-numerics", from: "1.0.0")
 ]
*/

// MARK: - Models

/// Represents a piece of content that can be searched semantically.
/// Conforms to `Sendable` to ensure safety across actor boundaries.
struct JournalEntry: Identifiable, Sendable, Hashable {
    let id: UUID
    let timestamp: Date
    let content: String
    let embedding: [Float] // The high-dimensional vector representation
}

/// Errors specific to the semantic search pipeline.
enum SearchError: LocalizedError, Sendable {
    case embeddingFailed(String)
    case vectorStoreUnavailable
    case timeout
    case insufficientContext

    var errorDescription: String? {
        switch self {
        case .embeddingFailed(let msg): return "Failed to process text: \(msg)"
        case .vectorStoreUnavailable: return "The database is currently unreachable."
        case .timeout: return "The search took too long."
        case .insufficientContext: return "Please enter a more descriptive query."
        }
    }
}

// MARK: - Service Layer

/// An actor responsible for the heavy lifting of semantic search.
/// Using an `actor` ensures that vector similarity calculations and 
/// embedding generation do not block the Main Actor (UI thread).
@available(iOS 18.0, *)
actor SemanticSearchService {
    
    /// A simulated vector store. In a real app, this would interface 
    /// with CoreData or a specialized Vector Database.
    private var mockDatabase: [JournalEntry] = []

    init() {
        // Pre-populating with mock data for demonstration
        self.mockDatabase = [
            JournalEntry(id: UUID(), timestamp: Date(), content: "The sunset in Santorini was breathtaking.", embedding: [0.1, 0.8, -0.3]),
            JournalEntry(id: UUID(), timestamp: Date(), content: "I felt very productive working on my Swift code today.", embedding: [-0.5, 0.2, 0.9]),
            JournalEntry(id: UUID(), timestamp: Date(), content: "Had a delicious pasta dinner in Rome.", embedding: [0.2, -0.1, 0.4]),
            JournalEntry(id: UUID(), timestamp: Date(), content: "The mountains in Switzerland were covered in snow.", embedding: [0.8, -0.5, -0.2])
        ]
    }

    /// Performs a semantic search by converting the query to a vector and 
    /// calculating cosine similarity against the database.
    /// - Parameter query: The natural language string from the user.
    /// - Returns: An array of `JournalEntry` sorted by relevance.
    func performSearch(query: String) async throws -> [JournalEntry] {
        // 1. Simulate network/ML latency for embedding generation
        try await Task.sleep(for: .milliseconds(600))
        
        guard !query.isEmpty else { return [] }
        
        // 2. In a real app, call a local MLModel (CoreML) or an API (OpenAI/Anthropic)
        // to get the embedding for the query string.
        let queryEmbedding = try await generateEmbedding(for: query)
        
        // 3. Perform Vector Similarity Search (Cosine Similarity)
        // We sort the database based on how "close" the vectors are.
        let results = mockDatabase.map { entry in
            (entry, cosineSimilarity(queryEmbedding, entry.embedding))
        }
        .sorted { $0.1 > $1.1 } // Highest similarity first
        .map { $0.0 }
        
        return results
    }

    /// Simulates the conversion of text to a vector.
    private func generateEmbedding(for text: String) async throws -> [Float] {
        // Real-world: Use NaturalLanguage framework or a CoreML model.
        // For this demo, we return a pseudo-random vector based on text length.
        return text.count % 3 == 0 ? [0.1, 0.8, -0.3] : [0.8, -0.5, -0.2]
    }

    /// Calculates the cosine similarity between two vectors.
    /// Formula: (A · B) / (||A|| * ||B||)
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return 0 }
        let dotProduct = zip(a, b).map(*).reduce(0, +)
        let magnitudeA = sqrt(a.map { $0 * $0 }.reduce(0, +))
        let magnitudeB = sqrt(b.map { $0 * $0 }.reduce(0, +))
        return dotProduct / (magnitudeA * magnitudeB)
    }
}

// MARK: - ViewModel Layer

/// The ViewModel manages the UI state and orchestrates the search lifecycle.
/// Using `@Observable` (iOS 17+) provides efficient UI updates.
@available(iOS 18.0, *)
@Observable
final class SearchViewModel {
    
    // MARK: Published State
    var searchQuery: String = ""
    var results: [JournalEntry] = []
    var isLoading: Bool = false
    var errorMessage: String? = nil
    
    // MARK: Private Properties
    private let searchService = SemanticSearchService()
    private var searchTask: Task<Void, Never>?
    
    /// Initiates a debounced search process.
    /// Debouncing is critical to avoid firing an embedding request on every single keystroke.
    func debouncedSearch() {
        // Cancel the previous task if the user is still typing
        searchTask?.cancel()
        
        guard !searchQuery.trimmingCharacters(in: .whitespaces).isEmpty else {
            results = []
            isLoading = false
            return
        }
        
        searchTask = Task {
            do {
                // 1. Wait for user to stop typing (Debounce)
                try await Task.sleep(for: .milliseconds(500))
                
                // 2. Check for cancellation before starting heavy work
                try Task.checkCancellation()
                
                await MainActor.run {
                    self.isLoading = true
                    self.errorMessage = nil
                }
                
                // 3. Perform the semantic search via the actor
                let fetchedResults = try await searchService.performSearch(query: searchQuery)
                
                // 4. Update UI on the Main Actor
                try Task.checkCancellation()
                await MainActor.run {
                    self.results = fetchedResults
                    self.isLoading = false
                }
                
            } catch is CancellationError {
                // Task was cancelled, do nothing
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
    
    func cancelSearch() {
        searchTask?.cancel()
        isLoading = false
    }
}

// MARK: - View Layer

@available(iOS 18.0, *)
struct SemanticSearchView: View {
    
    @State private var viewModel = SearchViewModel()
    
    var body: some View {
        NavigationStack {
            Group {
                if viewModel.isLoading {
                    loadingView
                } else if let error = viewModel.errorMessage {
                    errorView(error)
                } else if viewModel.searchQuery.isEmpty {
                    emptyStateView
                } else if viewModel.results.isEmpty {
                    noResultsView
                } else {
                    resultsList
                }
            }
            .navigationTitle("Semantic Search")
            .searchable(text: $viewModel.searchQuery, prompt: "Ask your journal anything...")
            // The .onChange modifier triggers the debounced search logic
            .onChange(of: viewModel.searchQuery) {
                viewModel.debouncedSearch()
            }
        }
    }
    
    // MARK: - Subviews
    
    private var resultsList: some View {
        List(viewModel.results) { entry in
            VStack(alignment: .leading, spacing: 8) {
                Text(entry.content)
                    .font(.body)
                Text(entry.timestamp, style: .date)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 4)
        }
        .listStyle(.plain)
    }
    
    private var loadingView: some View {
        VStack(spacing: 20) {
            ProgressView()
                .controlSize(.large)
            Text("Analyzing meaning...")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
    }
    
    private var emptyStateView: some View {
        ContentUnavailableView(
            "Search Your Memories",
            systemImage: "magnifyingglass",
            description: Text("Type a question like 'How was my trip?' to find relevant entries.")
        )
    }
    
    private var noResultsView: some View {
        ContentUnavailableView(
            "No Matches Found",
            systemImage: "exclamationmark.bubble",
            description: Text("We couldn't find anything matching that intent. Try different wording.")
        )
    }
    
    private func errorView(_ message: String) -> some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.triangle")
                .font(.largeTitle)
                .foregroundStyle(.red)
            Text(message)
                .multilineTextAlignment(.center)
            Button("Try Again") {
                viewModel.debouncedSearch()
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}

// MARK: - Preview
#Preview {
    SemanticSearchView()
}
