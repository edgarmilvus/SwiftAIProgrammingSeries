
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import AppIntents

// 1. The Agentic Models
struct TaskSuggestion: Sendable {
    let id: UUID
    let title: String
    let contextDescription: String
}

// 2. The Agentic Interface (AppIntents)
@available(iOS 18.0, *)
struct CreateProactiveTaskIntent: AppIntent {
    static var title: LocalizedStringResource = "Confirm Proactive Task"
    
    @Parameter(title: "Task Title")
    var title: String
    
    func perform() async throws -> some IntentResult {
        // Logic to actually save the task to the database
        print("✅ Task '\(title)' has been officially added to FocusFlow.")
        return .result()
    }
}

// 3. The Contextual Intelligence Layer
actor AgentCoordinator {
    private var recentSuggestions: [UUID: TaskSuggestion] = [:]
    
    // Simulated Intelligence Engine
    func analyzeContext(activityDescription: String) async -> TaskSuggestion? {
        // In reality, this would call an LLM to interpret the activity
        // "User is reading Project_Specs.pdf" -> "Review specs"
        if activityDescription.contains("Project_Specs.pdf") {
            let suggestion = TaskSuggestion(
                id: UUID(),
                title: "Review Project Specifications",
                contextDescription: "Detected while reading Project_Specs.pdf"
            )
            recentSuggestions[suggestion.id] = suggestion
            return suggestion
        }
        return nil
    }
    
    func getSuggestion(for id: UUID) -> TaskSuggestion? {
        return recentSuggestions[id]
    }
}

// 4. The Proactive Service (The "Listener")
class FocusFlowAgentService {
    private let coordinator = AgentCoordinator()
    
    // Simulated system-wide context listener
    func onSystemContextChanged(newActivity: String) {
        Task {
            print("🔍 Observing Context: \(newActivity)")
            if let suggestion = await coordinator.analyzeContext(activityDescription: newActivity) {
                await presentUserInTheLoop(suggestion)
            }
        }
    }
    
    // 5. User-in-the-Loop Implementation
    @MainActor
    private func presentUserInTheLoop(_ suggestion: TaskSuggestion) async {
        // In a real app, this would be a Widget, a Notification, or a Banner
        print("\n🔔 PROACTIVE SUGGESTION")
        print("Context: \(suggestion.contextDescription)")
        print("Suggestion: \(suggestion.title)")
        print("Action: [Confirm] or [Dismiss]\n")
        
        // Simulate User Interaction
        let userConfirmed = true 
        
        if userConfirmed {
            // Trigger the AppIntent via the system
            let intent = CreateProactiveTaskIntent()
            intent.title = suggestion.title
            try? await intent.perform()
        }
    }
}

// Usage
let service = FocusFlowAgentService()
service.onSystemContextChanged(newActivity: "User opened Project_Specs.pdf in Safari")
