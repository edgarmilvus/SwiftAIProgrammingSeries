
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

@available(iOS 18.0, macOS 14.0, *)
import MLX
import MLXNN // For MLXNN.Module

// Your implementation goes here
/// A custom Dense (fully connected) layer for neural networks.
/// It performs a linear transformation: output = input @ weight.T + bias.
class Dense: MLXNN.Module {
    let inputFeatures: Int
    let outputFeatures: Int

    // Learnable parameters
    var weight: MLXArray
    var bias: MLXArray

    // 1. Module Definition & 2. Initialization
    /// Initializes a new Dense layer.
    /// - Parameters:
    ///   - inputFeatures: The number of input features (size of the input vector).
    ///   - outputFeatures: The number of output features (size of the output vector).
    init(inputFeatures: Int, outputFeatures: Int) {
        self.inputFeatures = inputFeatures
        self.outputFeatures = outputFeatures

        // Initialize weight matrix:
        // Shape [outputFeatures, inputFeatures] is common in MLX/PyTorch for weights.
        // Using `randomNormal` for typical neural network weight initialization.
        // `requiresGrad = true` is essential for MLX to track gradients for these parameters.
        self.weight = MLXArray.randomNormal(
            shape: [outputFeatures, inputFeatures],
            requiresGrad: true
        )

        // Initialize bias vector:
        // Shape [outputFeatures]
        // Initialized with zeros, `requiresGrad = true`.
        self.bias = MLXArray.zeros(
            shape: [outputFeatures],
            requiresGrad: true
        )

        super.init() // Call the superclass initializer
    }

    // 3. Forward Pass
    /// Performs the forward pass of the Dense layer.
    /// output = input @ weight.T + bias
    /// - Parameter input: The input MLXArray, typically of shape [batch_size, inputFeatures].
    /// - Returns: The output MLXArray, typically of shape [batch_size, outputFeatures].
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Ensure input is float for consistent type operations
        let floatInput = input.astype(Float.self)

        // Matrix multiplication: input (batch_size, input_features) @ weight.T (input_features, output_features)
        // The result will be (batch_size, output_features)
        let linearOutput = floatInput @ weight.T

        // Add bias (broadcasting will automatically apply bias to each sample in the batch)
        let output = linearOutput + bias
        return output
    }
}

// Example usage:
let inputFeatures = 10
let outputFeatures = 5
let batchSize = 3

// 1. Instantiate the Dense layer
let denseLayer = Dense(inputFeatures: inputFeatures, outputFeatures: outputFeatures)

// 2. Create sample input (e.g., a batch of 3 samples, each with 10 features)
// Values between -1.0 and 1.0 are common for normalized inputs.
let sampleInput = MLXArray.randomUniform(low: -1.0, high: 1.0, shape: [batchSize, inputFeatures])

print("Input shape:", sampleInput.shape)
print("Weight shape:", denseLayer.weight.shape)
print("Bias shape:", denseLayer.bias.shape)

// 3. Perform forward pass
let output = denseLayer.callAsFunction(sampleInput)

print("Output shape:", output.shape)
// print("Sample output (first item in batch):\n", output[0].eval()) // Uncomment to see actual values

// Show how module tracks parameters
// The `parameters()` method, inherited from MLXNN.Module,
// automatically collects all MLXArray properties with `requiresGrad = true`.
print("\nLayer parameters:", denseLayer.parameters().keys)
print("Weight requires grad:", denseLayer.weight.requiresGrad)
print("Bias requires grad:", denseLayer.bias.requiresGrad)
