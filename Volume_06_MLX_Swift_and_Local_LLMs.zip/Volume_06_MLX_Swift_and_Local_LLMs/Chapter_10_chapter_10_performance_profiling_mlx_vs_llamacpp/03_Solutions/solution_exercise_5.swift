
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import MLX
import MLXNN

// MARK: - 2. Define a Simple Custom Inference Model
/// `GestureClassifier` is a small convolutional neural network for gesture recognition.
/// It processes image data through convolutional, activation, pooling, and linear layers.
class GestureClassifier: MLXNN.Module {
    let conv1: MLXNN.Conv2d
    let relu: MLXNN.ReLU
    let adaptivePool: MLXNN.AdaptiveAvgPool2d
    let linear: MLXNN.Linear

    /// Initializes the gesture classifier model.
    /// - Parameters:
    ///   - inputChannels: Number of input channels (e.g., 3 for RGB images).
    ///   - numClasses: Number of output classes (e.g., 5 gestures).
    init(inputChannels: Int, numClasses: Int) {
        // Convolutional layer to extract features.
        // inputChannels -> 16 output channels, 3x3 kernel, 1 pixel padding to maintain size.
        self.conv1 = MLXNN.Conv2d(inputChannels: inputChannels, outputChannels: 16, kernelSize: 3, padding: 1)
        self.relu = MLXNN.ReLU()
        // Adaptive average pooling to reduce spatial dimensions to 1x1,
        // preparing features for the linear classification layer.
        self.adaptivePool = MLXNN.AdaptiveAvgPool2d(outputSize: [1, 1])
        // Final linear layer for classification. Input size is 16 (from conv output) * 1 * 1.
        self.linear = MLXNN.Linear(inputSize: 16, outputSize: numClasses)
        super.init()
    }

    /// Performs the forward pass of the gesture classifier.
    /// - Parameter input: Input MLXArray representing image data (expected shape: [batch, channels, height, width]).
    /// - Returns: Output MLXArray with class probabilities/logits.
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        var x = conv1(input) // Apply convolution
        x = relu(x)          // Apply ReLU activation
        x = adaptivePool(x)  // Apply adaptive pooling
        // Flatten the output from [batch, channels, 1, 1] to [batch, channels]
        x = MLX.flatten(x, start: 1) // Flattens from dimension 1 onwards
        return linear(x)     // Apply final linear classification layer
    }
}

func runExercise5() {
    print("--- Exercise 5: Real-time Inference Pipeline with Unified Memory Considerations ---")

    let batchSize = 1 // Simulating real-time, single-frame inference
    let height = 128
    let width = 128
    let channels = 3 // RGB image
    let numClasses = 5 // e.g., 5 different gesture categories

    // MARK: - 1. Simulate Image Preprocessing
    // Create dummy raw camera frames (Float values, 0-255 range)
    // Initial shape: [batchSize, height, width, channels]
    let rawFrames = MLXArray.randomUniform(low: 0.0, high: 255.0, shape: [batchSize, height, width, channels])

    /// Performs image preprocessing steps.
    /// - Parameter frames: Raw input image frames.
    /// - Returns: Preprocessed frames ready for the model.
    func preprocess(frames: MLXArray) -> MLXArray {
        // Normalize pixel values to the 0-1 range
        var processed = frames / 255.0
        // Transpose the dimensions to [batch, channels, height, width],
        // as MLXNN.Conv2d typically expects this channel-first format.
        processed = MLX.transpose(processed, axes: [0, 3, 1, 2])
        return processed
    }

    // Instantiate the GestureClassifier model
    let classifier = GestureClassifier(inputChannels: channels, numClasses: numClasses)

    // MARK: - 3. Construct and Profile the End-to-End Inference Pipeline
    /// Performs the complete inference pipeline: preprocessing + model forward pass.
    /// - Parameter frames: Raw input frames.
    /// - Returns: Model predictions.
    func performInference(frames: MLXArray) -> MLXArray {
        let preprocessedFrames = preprocess(frames: frames)
        let predictions = classifier(preprocessedFrames)
        return predictions
    }

    print("\nPerforming end-to-end inference for a single frame...")
    let inferenceStartTime = CFAbsoluteTimeGetCurrent()

    let finalOutput = performInference(frames: rawFrames)
    // MLX.eval() is critical here to measure the actual computational latency
    // of the entire pipeline, including preprocessing and model inference.
    MLX.eval(finalOutput)

    let inferenceEndTime = CFAbsoluteTimeGetCurrent()
    print("End-to-end inference latency: \(inferenceEndTime - inferenceStartTime) seconds")
    print("Final output shape (after preprocessing and model): \(finalOutput.shape)")


    // MARK: - 4. Discuss Unified Memory and Zero-Copy Benefits
    print("\n// Discussion on Unified Memory and Zero-Copy Benefits for Real-time Inference:")
    print("// For real-time applications like on-device gesture recognition, low latency is critical. Apple's Unified Memory, as exposed by MLX, provides a profound advantage by eliminating memory copy overheads. Here's why:")
    print("// 1. **No Host-Device Copies:** When `rawFrames` are created (or captured from the camera and converted to `MLXArray`), they reside in a memory region accessible by both the CPU and the GPU (Neural Engine). As these frames pass through `preprocess` and then the `GestureClassifier` (which likely uses the GPU), there is no need to copy the image data or intermediate feature maps back and forth between distinct CPU and GPU memory banks. This 'zero-copy' mechanism saves precious milliseconds per frame.")
    print("// 2. **Reduced Latency:** Each memory copy operation adds latency. By avoiding these copies, the entire pipeline – from input buffering, through preprocessing, to model inference – becomes significantly faster, enabling higher frame rates and more responsive user experiences.")
    print("// 3. **Simplified Memory Management:** Developers don't need to manually manage `CVPixelBuffer` to `MTLTexture` conversions and explicit `blit` commands, simplifying the code and reducing the chance of memory-related bugs. MLX abstracts this complexity, allowing developers to focus on the model logic.")
    print("// 4. **Efficient Resource Utilization:** Unified Memory allows dynamic allocation of memory between CPU and GPU needs, ensuring that memory is used efficiently without needing to pre-allocate fixed-size pools for each processor. This is especially beneficial for variable-sized inputs or dynamic model architectures.")
    print("// In essence, Unified Memory ensures that the data is always where it needs to be, immediately available to whichever processor requires it, making MLX a powerful tool for building high-performance, real-time on-device AI features.")
}

runExercise5()
