
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import CoreData

class DataCoordinator {
    let container: NSPersistentContainer
    
    init(container: NSPersistentContainer) {
        self.container = container
    }
    
    /// Performs a semantic search and retrieves the local sensitive content.
    func performSemanticSearch(queryVector: [Float]) async throws -> [String] {
        let context = container.viewContext
        
        return try await context.perform {
            // 1. Simulate finding the best match in the SemanticVector entity
            // In a real app, this would involve a vector similarity math operation
            let request: NSFetchRequest<SemanticVector> = SemanticVector.fetchRequest()
            let vectors = try context.fetch(request)
            
            // Mocking a match
            guard let matchedVector = vectors.first else { return [] }
            
            // 2. Use the relationship to find the local-only content
            // The relationship is defined in the model: SemanticVector.content -> SensitiveContent
            guard let sensitiveContent = matchedVector.content else {
                print("⚠️ Orphaned Vector Found: Vector exists in Cloud, but local PII is missing.")
                return []
            }
            
            return [sensitiveContent.rawText]
        }
    }
}

// MARK: - Schema Implementation (Conceptual Model Definition)

/* 
 NOTE: The following represents the logical structure of the Core Data entities.
 In a real implementation, these are defined in the .xcdatamodeld file.
*/

// ENTITY: SensitiveContent
// - rawText: String
// - id: UUID
// - Relationship: contentToVector (One-to-One, Destination: SemanticVector, Inverse: content)
// CONFIGURATION: This entity is assigned to a 'LocalOnly' Configuration.
// The NSPersistentStoreDescription for 'LocalOnly' does NOT have cloudKitContainerOptions.

// ENTITY: SemanticVector
// - embedding: Data (The [Float] array)
// - contextualTag: String (e.g., "Note_123")
// - Relationship: vectorToContent (One-to-One, Destination: SensitiveContent, Inverse: contentToVector)
// CONFIGURATION: This entity is assigned to a 'CloudSynced' Configuration.
// The NSPersistentStoreDescription for 'CloudSynced' HAS cloudKitContainerOptions.
*/

@objc(SensitiveContent)
public class SensitiveContent: NSManagedObject {
    @NSManaged public var rawText: String
    @NSManaged public var id: UUID
    @NSManaged public var contentToVector: SemanticVector?
}

@objc(SemanticVector)
public class SemanticVector: NSManagedObject {
    @NSManaged public var embedding: Data
    @NSManaged public var contextualTag: String
    @NSManaged public var content: SensitiveContent?
    
    static func fetchRequest() -> NSFetchRequest<SemanticVector> {
        return NSFetchRequest<SemanticVector>(entityName: "SemanticVector")
    }
}
