
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import AppIntents
import Foundation
import SwiftUI // Required for potentially displaying a custom view in IntentResult

@available(iOS 18.0, macOS 15.0, *)
struct SummarizeTextIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize Text"
    static var description: IntentDescription = IntentDescription("Summarizes a block of text using Apple Intelligence (simulated).", category: .productivity, searchKeywords: ["summarize", "text", "AI", "intelligence"])

    @Parameter(title: "Text to Summarize", description: "The text content that needs to be summarized.")
    var textToSummarize: String

    init() {}
    init(textToSummarize: String) {
        self.textToSummarize = textToSummarize
    }

    func perform() async throws -> some IntentResult {
        // MARK: - Simulate Apple Intelligence Summarization
        // In a real application, this would involve calling Apple's on-device LLM APIs
        // or a custom foundation model via the Apple Intelligence framework.
        let simulatedSummary: String
        if textToSummarize.isEmpty {
            simulatedSummary = "No text was provided to summarize."
        } else if textToSummarize.count > 150 { // Summarize if text is long
            let endIndex = textToSummarize.index(textToSummarize.startIndex, offsetBy: 120)
            simulatedSummary = String(textToSummarize[..<endIndex]) + "... (Simulated AI Summary)"
        } else { // For short texts, provide a simple 'summary'
            simulatedSummary = "This is a concise (simulated) summary of your input: \"\(textToSummarize.prefix(80))\""
            if textToSummarize.count > 80 {
                simulatedSummary += "..."
            }
        }

        // Return the summary as a result.
        // The dialog provides spoken feedback, and the optional trailing closure
        // can provide a custom SwiftUI View for richer display in the Shortcuts app.
        return .result(dialog: "Here's the summary: \(simulatedSummary)") {
            // Optional: Provide a custom view for rich display in Shortcuts if needed.
            // This SwiftUI Text view would be rendered directly within the Shortcuts app interface.
            Text(simulatedSummary)
                .font(.body)
                .padding()
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct SmartReaderAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: SummarizeTextIntent(), // Provide a default intent instance
            phrases: [
                "Summarize \(.parameter(\.$textToSummarize)) in \(.applicationName)",
                "Get summary of \(.parameter(\.$textToSummarize)) in \(.applicationName)",
                "Siri, summarize this article in \(.applicationName)"
            ],
            shortTitle: "Summarize Text",
            systemImageName: "text.book.closed.fill"
        )
    }
}
