
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI

// MARK: - Ollama API Response Structures

/// Represents a single streaming chunk from Ollama's /api/generate endpoint.
struct OllamaStreamingResponse: Decodable {
    let model: String?
    let createdAt: String?
    let response: String? // The actual token generated
    let done: Bool
    let totalDuration: Int?
    let loadDuration: Int?
    let promptEvalCount: Int?
    let promptEvalDuration: Int?
    let evalCount: Int?
    let evalDuration: Int?
}

// MARK: - Main SwiftUI Application

@main
struct IdeaGeneratorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

// MARK: - ContentView

struct ContentView: View {
    @State private var prompt: String = "Generate 5 ideas for a new mobile game"
    @State private var generatedIdeas: String = "Ideas will appear here..."
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?

    // Ollama server details
    private let ollamaHost = "localhost"
    private let ollamaPort = 11434
    private let ollamaModel = "phi-3:mini"

    var body: some View {
        VStack(spacing: 15) {
            Text("Ollama Idea Generator")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 10)

            TextField("Enter your prompt here (e.g., 'Generate 5 ideas for a new mobile game')", text: $prompt)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
                .disabled(isLoading)

            Button(action: generateIdeas) {
                Label("Generate Ideas", systemImage: "lightbulb.fill")
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(isLoading || prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

            if isLoading {
                ProgressView("Generating...")
                    .padding()
            }

            if let errorMessage = errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .padding()
            }

            ScrollView {
                Text(generatedIdeas)
                    .textSelection(.enabled) // Allows copying the generated text
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
            }
            .frame(minHeight: 200, maxHeight: .infinity)
            .padding(.horizontal)
        }
        .padding()
        .frame(minWidth: 500, minHeight: 400)
    }

    /// Sends the user's prompt to Ollama and streams the response.
    private func generateIdeas() {
        isLoading = true
        errorMessage = nil
        generatedIdeas = "" // Clear previous ideas

        Task {
            do {
                // Construct the URL for Ollama's generate API
                guard let url = URL(string: "http://\(ollamaHost):\(ollamaPort)/api/generate") else {
                    throw URLError(.badURL)
                }

                // Prepare the request body
                let requestBody: [String: Any] = [
                    "model": ollamaModel,
                    "prompt": prompt,
                    "stream": true // Crucial for streaming responses
                ]
                let jsonData = try JSONSerialization.data(withJSONObject: requestBody)

                // Create the URLRequest
                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.httpBody = jsonData

                // Use URLSession's async/await for streaming bytes
                let (asyncBytes, response) = try await URLSession.shared.bytes(for: request)

                // Check for HTTP errors
                guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                    let statusCode = (response as? HTTPURLResponse)?.statusCode ?? -1
                    let responseData = String(data: try await Data(asyncBytes), encoding: .utf8) ?? "No data"
                    throw URLError(.badServerResponse, userInfo: [
                        NSLocalizedDescriptionKey: "Server returned status \(statusCode). Response: \(responseData)"
                    ])
                }

                // Process the streaming response
                for try await line in asyncBytes.lines {
                    // Each line is a JSON object from Ollama
                    guard let data = line.data(using: .utf8) else { continue }
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase // Ollama uses snake_case for some keys

                    let streamingResponse = try decoder.decode(OllamaStreamingResponse.self, from: data)

                    // Update UI on the main actor
                    await MainActor.run {
                        if let responseText = streamingResponse.response, !responseText.isEmpty {
                            generatedIdeas += responseText
                        }
                        // The 'done' field indicates the end of the stream
                        if streamingResponse.done {
                            isLoading = false
                        }
                    }
                }
            } catch {
                // Handle various errors
                await MainActor.run {
                    isLoading = false
                    if let urlError = error as? URLError {
                        errorMessage = "Network error: \(urlError.localizedDescription). Is Ollama running and `phi-3:mini` downloaded? Check `http://localhost:11434`."
                    } else if let decodingError = error as? DecodingError {
                        errorMessage = "Data decoding error: \(decodingError.localizedDescription)"
                    } else {
                        errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                    }
                    print("Error: \(error)") // Log the full error for debugging
                }
            }
        }
    }
}
