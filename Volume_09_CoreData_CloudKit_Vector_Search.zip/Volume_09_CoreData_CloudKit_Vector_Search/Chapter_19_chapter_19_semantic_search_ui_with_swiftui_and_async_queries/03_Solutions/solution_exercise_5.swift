
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

@available(iOS 18.0, *)
struct KeywordResult: Sendable {
    let id: UUID
    let title: String
    let keywordScore: Double // Unnormalized (e.g., 0.0 to 10.0)
}

@available(iOS 18.0, *)
struct SemanticResult: Sendable {
    let id: UUID
    let title: String
    let semanticScore: Double // Normalized (0.0 to 1.0)
}

@available(iOS 18.0, *)
struct HybridResult: Identifiable, Sendable {
    let id: UUID
    let title: String
    let combinedScore: Double
}

@available(iOS 18.0, *)
struct HybridRankingEngine {
    
    func rank(
        keywordResults: [KeywordResult],
        semanticResults: [SemanticResult],
        keywordWeight: Double,
        semanticWeight: Double
    ) -> [HybridResult] {
        
        // 1. Normalize Keyword Scores
        // We find the max to scale everything to 0.0 - 1.0
        let maxKeywordScore = keywordResults.map(\.keywordScore).max() ?? 1.0
        let safeMax = maxKeywordScore == 0 ? 1.0 : maxKeywordScore
        
        // 2. Use a dictionary for deduplication and score accumulation
        // Key: UUID, Value: (Title, NormalizedKeywordScore, SemanticScore)
        var registry: [UUID: (title: String, kScore: Double, sScore: Double)] = [:]
        
        // Process Keywords
        for res in keywordResults {
            let normK = res.keywordScore / safeMax
            registry[res.id] = (res.title, normK, 0.0)
        }
        
        // Process Semantic (and merge)
        for res in semanticResults {
            if var existing = registry[res.id] {
                // Item exists in both: update semantic score
                existing.sScore = res.semanticScore
                registry[res.id] = existing
            } else {
                // Item only in semantic
                registry[res.id] = (res.title, 0.0, res.semanticScore)
            }
        }
        
        // 3. Calculate final weighted scores and convert to HybridResult
        let finalResults = registry.map { (id, data) -> HybridResult in
            let combined = (data.kScore * keywordWeight) + (data.sScore * semanticWeight)
            return HybridResult(id: id, title: data.title, combinedScore: combined)
        }
        
        // 4. Sort by score descending
        return finalResults.sorted { $0.combinedScore > $1.combinedScore }
    }
}

#Preview {
    let engine = HybridRankingEngine()
    let kResults = [
        KeywordResult(id: UUID(uuidString: "00000000-0000-0000-0000-000000000001")!, title: "Exact Match", keywordScore: 10.0),
        KeywordResult(id: UUID(uuidString: "00000000-0000-0000-0000-000000000002")!, title: "Keyword Only", keywordScore: 5.0)
    ]
    let sResults = [
        SemanticResult(id: UUID(uuidString: "00000000-0000-0000-0000-000000000001")!, title: "Exact Match", semanticScore: 0.9),
        SemanticResult(id: UUID(uuidString: "00000000-0000-0000-0000-000000000003")!, title: "Semantic Only", semanticScore: 0.8)
    ]
    
    let final = engine.rank(keywordResults: kResults, semanticResults: sResults, keywordWeight: 0.5, semanticWeight: 0.5)
    
    return List(final) { item in
        Text("\(item.title): \(String(format: "%.2f", item.combinedScore))")
    }
}
