
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// MARK: - Swift Package Manager Dependencies (Conceptual)
// For system frameworks like CoreML, Vision, Photos, and UIKit, no explicit
// Package.swift declaration is needed as they are directly imported.
// If this project were to use external Swift packages, a Package.swift
// file would look conceptually like this:

/*
// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "IntelligentPhotoAlbum",
    platforms: [
        .iOS(.v17) // Minimum deployment target for modern APIs
    ],
    products: [
        .library(
            name: "PhotoClassifier",
            targets: ["PhotoClassifier"]),
    ],
    dependencies: [
        // Example of an external dependency, if we were using one
        // .package(url: "https://github.com/some/utility-library.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "PhotoClassifier",
            dependencies: [
                // If using external packages, list them here:
                // .product(name: "UtilityLibrary", package: "utility-library"),
            ]),
        .testTarget(
            name: "PhotoClassifierTests",
            dependencies: ["PhotoClassifier"]),
    ]
)
*/

// MARK: - Imports
import CoreML
import Vision
import UIKit
import Photos // For fetching images from the photo library

// MARK: - Custom Error Types
/// Defines specific errors that can occur during the photo classification process.
enum PhotoClassificationError: Error, LocalizedError, CustomStringConvertible {
    case modelLoadingFailed(Error)
    case imageProcessingFailed(Error)
    case noObservationsFound
    case invalidImageData
    case photoLibraryAccessDenied
    case assetConversionFailed(String)

    var description: String {
        switch self {
        case .modelLoadingFailed(let error):
            return "Failed to load Core ML model: \(error.localizedDescription)"
        case .imageProcessingFailed(let error):
            return "Failed to process image with Vision: \(error.localizedDescription)"
        case .noObservationsFound:
            return "No classification observations were found for the image."
        case .invalidImageData:
            return "Invalid image data provided for classification."
        case .photoLibraryAccessDenied:
            return "Access to the photo library was denied. Please grant permission in settings."
        case .assetConversionFailed(let assetID):
            return "Failed to convert PHAsset (ID: \(assetID)) to UIImage."
        }
    }

    var errorDescription: String? {
        return self.description
    }
}

// MARK: - Classification Result Structure
/// Represents the result of classifying a single image, including its identifier and top classifications.
struct ClassifiedImage {
    let assetIdentifier: String // Unique identifier for the PHAsset
    let topClassifications: [(identifier: String, confidence: Float)]
    let error: PhotoClassificationError? // Optional error if classification failed for this image
}

// MARK: - PhotoClassifier Class
/// A robust class responsible for classifying images using a Core ML model via Vision framework.
/// It supports classifying individual images and batches of images from the Photos library.
@available(iOS 17.0, *) // Targeting iOS 17+ for modern concurrency features
class PhotoClassifier {

    /// The Core ML model used for image classification.
    private let coreMLModel: VNCoreMLModel

    /// Initializes the PhotoClassifier with a specific Core ML model.
    /// - Parameter model: An instance of `MLModel` (e.g., `MobileNetV2().model`).
    /// - Throws: `PhotoClassificationError.modelLoadingFailed` if the `VNCoreMLModel` cannot be created.
    init(model: MLModel) throws {
        do {
            self.coreMLModel = try VNCoreMLModel(for: model)
        } catch {
            throw PhotoClassificationError.modelLoadingFailed(error)
        }
    }

    /// Classifies a single `UIImage` asynchronously.
    /// - Parameter image: The `UIImage` to classify.
    /// - Parameter topK: The number of top classifications to return.
    /// - Returns: An array of tuples, each containing an identifier (tag) and its confidence score.
    /// - Throws: `PhotoClassificationError` if classification fails.
    func classifyImage(_ image: UIImage, topK: Int = 3) async throws -> [(identifier: String, confidence: Float)] {
        guard let cgImage = image.cgImage else {
            throw PhotoClassificationError.invalidImageData
        }

        // 1. Create a VNClassifyImageRequest
        // This request uses the pre-loaded Core ML model to perform image classification.
        let request = VNCoreMLRequest(model: coreMLModel) { request, error in
            // This completion handler is typically used in non-async contexts.
            // For async/await, we'll wrap the request execution.
        }

        request.imageCropAndScaleOption = .centerCrop // Standard practice for many classification models
        request.usesCPUOnly = false // Allow GPU usage for faster processing if available

        // 2. Perform the Vision request on a background queue
        // VNImageRequestHandler handles the actual execution of the Vision requests.
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        do {
            try handler.perform([request])
        } catch {
            throw PhotoClassificationError.imageProcessingFailed(error)
        }

        // 3. Process the results
        guard let observations = request.results as? [VNClassificationObservation], !observations.isEmpty else {
            throw PhotoClassificationError.noObservationsFound
        }

        // Sort observations by confidence and take the top K
        let topClassifications = observations
            .sorted { $0.confidence > $1.confidence }
            .prefix(topK)
            .map { (identifier: $0.identifier, confidence: $0.confidence) }

        return topClassifications
    }

    /// Asynchronously classifies a batch of `PHAsset` objects from the photo library.
    /// This method demonstrates robust error handling for individual assets and utilizes
    /// Swift 6 concurrency for efficient parallel processing.
    /// - Parameter assets: An array of `PHAsset` objects to classify.
    /// - Parameter topK: The number of top classifications to return for each image.
    /// - Returns: An array of `ClassifiedImage` results, including potential errors for individual assets.
    func classifyPhotos(assets: [PHAsset], topK: Int = 3) async -> [ClassifiedImage] {
        var classifiedResults: [ClassifiedImage] = []

        // Check photo library access upfront
        let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)
        guard status == .authorized || status == .limited else {
            // If access is denied, return an error for all assets or handle globally.
            // For this example, we'll return an error for each asset.
            return assets.map {
                ClassifiedImage(assetIdentifier: $0.localIdentifier, topClassifications: [], error: .photoLibraryAccessDenied)
            }
        }

        // Use a TaskGroup for concurrent processing of multiple assets.
        // This allows individual asset classification tasks to run in parallel
        // and collect their results.
        await withTaskGroup(of: ClassifiedImage.self) { group in
            for asset in assets {
                group.addTask { [weak self] in
                    guard let self = self else {
                        return ClassifiedImage(assetIdentifier: asset.localIdentifier, topClassifications: [], error: .modelLoadingFailed(NSError(domain: "PhotoClassifier", code: 0, userInfo: [NSLocalizedDescriptionKey: "Classifier deallocated"])))
                    }

                    do {
                        // 1. Request UIImage from PHAsset
                        // PHImageManager is used to fetch image data from PHAsset.
                        // This can be a long-running operation, so it's awaited.
                        guard let uiImage = await self.fetchUIImage(for: asset) else {
                            throw PhotoClassificationError.assetConversionFailed(asset.localIdentifier)
                        }

                        // 2. Classify the fetched UIImage
                        let classifications = try await self.classifyImage(uiImage, topK: topK)
                        return ClassifiedImage(assetIdentifier: asset.localIdentifier, topClassifications: classifications, error: nil)
                    } catch let error as PhotoClassificationError {
                        // Catch specific classification errors
                        return ClassifiedImage(assetIdentifier: asset.localIdentifier, topClassifications: [], error: error)
                    } catch {
                        // Catch any other unexpected errors
                        return ClassifiedImage(assetIdentifier: asset.localIdentifier, topClassifications: [], error: .imageProcessingFailed(error))
                    }
                }
            }

            // Collect results as they complete
            for await result in group {
                classifiedResults.append(result)
            }
        }

        return classifiedResults
    }

    /// Fetches a `UIImage` from a `PHAsset` asynchronously.
    /// - Parameter asset: The `PHAsset` to fetch the image from.
    /// - Returns: The `UIImage` if successful, otherwise `nil`.
    private func fetchUIImage(for asset: PHAsset) async -> UIImage? {
        return await withCheckedContinuation { continuation in
            let manager = PHImageManager.default()
            let requestOptions = PHImageRequestOptions()
            requestOptions.isSynchronous = false // Allow asynchronous fetching
            requestOptions.deliveryMode = .highQualityFormat // Request high-quality image
            requestOptions.resizeMode = .fast // Optimize for speed

            // Request image with a target size suitable for classification (e.g., 299x299 for InceptionV3, 224x224 for MobileNetV2)
            // We'll use a larger size and let Vision handle the final scaling/cropping.
            let targetSize = CGSize(width: 1024, height: 1024)

            manager.requestImage(for: asset, targetSize: targetSize, contentMode: .aspectFit, options: requestOptions) { image, info in
                // info dictionary can contain error details, isDegraded, etc.
                if let image = image, !(info?[PHImageResultIsDegradedKey] as? Bool ?? false) {
                    continuation.resume(returning: image)
                } else {
                    // Handle cases where image is nil or degraded (e.g., iCloud-only asset not downloaded)
                    continuation.resume(returning: nil)
                }
            }
        }
    }
}

// MARK: - Example Usage (within a ViewController or App entry point)
/// This extension demonstrates how to integrate the PhotoClassifier into an app lifecycle.
@available(iOS 17.0, *)
extension UIViewController {

    /// Simulates loading a Core ML model (e.g., MobileNetV2) for classification.
    /// In a real app, this model would be bundled with the app or downloaded.
    private func loadClassificationModel() throws -> MLModel {
        // Assume MobileNetV2.mlmodel is part of the app bundle.
        // You would typically generate this class using Xcode's Core ML Model Editor.
        guard let modelURL = Bundle.main.url(forResource: "MobileNetV2", withExtension: "mlmodelc") else {
            // For demonstration, we'll create a dummy MLModel if not found.
            // In a real app, this would be a fatal error or properly handled model download.
            print("WARNING: MobileNetV2.mlmodelc not found in bundle. Using a dummy model for demonstration.")
            // A real Core ML model requires a .mlmodelc compiled model.
            // Creating a dummy MLModel is complex and not practical here.
            // For a runnable example, ensure you've added a Core ML model to your project.
            // For now, we'll throw an error and assume the model exists in a real scenario.
            throw PhotoClassificationError.modelLoadingFailed(NSError(domain: "App", code: 1, userInfo: [NSLocalizedDescriptionKey: "MobileNetV2.mlmodelc not found. Please add a Core ML model to your project."]))
        }

        let compiledModelURL = try MLModel.compileModel(at: modelURL)
        let model = try MLModel(contentsOf: compiledModelURL)
        return model
    }

    /// Initiates the photo classification process for selected assets.
    /// This method would be called from a UI action (e.g., a button tap).
    func startPhotoTaggingProcess(selectedAssets: [PHAsset]) {
        Task {
            do {
                // 1. Initialize the classifier
                let mlModel = try loadClassificationModel() // Load your specific Core ML model
                let classifier = try PhotoClassifier(model: mlModel)

                // 2. Request photo library access if not already granted
                let status = await PHPhotoLibrary.requestAuthorization(for: .readWrite)
                guard status == .authorized || status == .limited else {
                    print("Photo library access denied.")
                    // Display an alert to the user
                    return
                }

                // 3. Classify the selected photos
                print("Starting classification for \(selectedAssets.count) assets...")
                let results = await classifier.classifyPhotos(assets: selectedAssets)

                // 4. Process and display results
                print("\n--- Classification Results ---")
                for result in results {
                    if let error = result.error {
                        print("Asset ID: \(result.assetIdentifier) - Error: \(error.localizedDescription)")
                    } else {
                        let tags = result.topClassifications.map { "\($0.identifier) (\(String(format: "%.2f", $0.confidence * 100))%)" }.joined(separator: ", ")
                        print("Asset ID: \(result.assetIdentifier) - Tags: \(tags)")
                        // In a real app, you would save these tags to a database
                        // or directly update the PHAsset metadata (requires PHAssetChangeRequest).
                    }
                }
                print("--- Classification Complete ---")

            } catch let error as PhotoClassificationError {
                print("Global Classification Error: \(error.localizedDescription)")
                // Display an alert for global errors
            } catch {
                print("An unexpected error occurred: \(error.localizedDescription)")
            }
        }
    }
}
