
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CoreML
import Foundation

// Helper for semantic version comparison (from Exercise 3)
extension String {
    func isSemanticVersionGreaterThan(_ otherVersion: String) -> Bool {
        let components = self.split(separator: ".").compactMap { Int($0) }
        let otherComponents = otherVersion.split(separator: ".").compactMap { Int($0) }

        for i in 0..<min(components.count, otherComponents.count) {
            if components[i] > otherComponents[i] {
                return true
            }
            if components[i] < otherComponents[i] {
                return false
            }
        }
        return components.count > otherComponents.count
    }
    
    func isSemanticVersionEqual(_ otherVersion: String) -> Bool {
        return self == otherVersion
    }
}

@available(iOS 18.0, *)
enum ModelUpdateError: Error, LocalizedError {
    case downloadFailed(URL?)
    case invalidModelFile(URL)
    case versionMismatch(expected: String?, actual: String)
    case activationFailed(String)
    case noActiveModelAvailable
    case noFallbackModelAvailable

    var errorDescription: String? {
        switch self {
        case .downloadFailed(let url):
            return "Failed to download model from \(url?.lastPathComponent ?? "unknown URL")."
        case .invalidModelFile(let url):
            return "Downloaded file at \(url.lastPathComponent) is not a valid Core ML model."
        case .versionMismatch(let expected, let actual):
            return "Model version mismatch. Expected \(expected ?? "any newer"), got \(actual)."
        case .activationFailed(let details):
            return "Failed to activate new model: \(details)"
        case .noActiveModelAvailable:
            return "No active model is available. Please ensure a default model is bundled or downloaded."
        case .noFallbackModelAvailable:
            return "No fallback model is available. Cannot rollback."
        }
    }
}

@available(iOS 18.0, *)
class ARModelUpdater {
    private let userDefaults = UserDefaults.standard
    private let activeModelPathKey = "activeARModelPath"
    private let fallbackModelPathKey = "fallbackARModelPath"

    private var currentActiveModel: MLModel? // In-memory instance of the active model
    private var currentActiveModelURL: URL? // Path to the active model on disk

    init() {
        // Ensure a default model is established on first launch
        if userDefaults.string(forKey: activeModelPathKey) == nil {
            if let bundledModelURL = Bundle.main.url(forResource: "ARObjectRecognizer_v1_0", withExtension: "mlmodelc") {
                // Copy bundled model to app's data directory to simulate it being "downloaded"
                // and allow for persistence logic to treat it like other downloaded models.
                let targetURL = FileManager.default.temporaryDirectory.appendingPathComponent(bundledModelURL.lastPathComponent)
                do {
                    if FileManager.default.fileExists(atPath: targetURL.path) {
                        try FileManager.default.removeItem(at: targetURL)
                    }
                    try FileManager.default.copyItem(at: bundledModelURL, to: targetURL)
                    userDefaults.set(targetURL.path, forKey: activeModelPathKey)
                    print("Initialized active model from bundled: \(targetURL.lastPathComponent)")
                } catch {
                    print("Error copying bundled model to temp directory: \(error.localizedDescription)")
                }
            } else {
                print("Warning: Initial bundled model 'ARObjectRecognizer_v1_0.mlmodelc' not found.")
            }
        }
        // Attempt to load the stored active model on init
        _ = try? getActiveModel()
    }

    /// Simulates downloading a new model and attempts to activate it.
    /// - Parameters:
    ///   - simulatedDownloadURL: A URL to a model file (e.g., another bundled model for simulation).
    ///   - expectedVersion: The minimum or exact version expected for the new model. If nil, any newer version is accepted.
    /// - Throws: `ModelUpdateError` if the download, validation, or activation fails.
    func downloadAndActivateModel(from simulatedDownloadURL: URL, expectedVersion: String? = nil) async throws {
        print("\n--- Attempting to download and activate new model from: \(simulatedDownloadURL.lastPathComponent) ---")

        let tempDownloadPath = FileManager.default.temporaryDirectory.appendingPathComponent("DownloadedModel_\(UUID().uuidString).mlmodelc")

        do {
            // Simulate download by copying the file
            if FileManager.default.fileExists(atPath: tempDownloadPath.path) {
                try FileManager.default.removeItem(at: tempDownloadPath)
            }
            try FileManager.default.copyItem(at: simulatedDownloadURL, to: tempDownloadPath)
            print("Simulated download successful to: \(tempDownloadPath.lastPathComponent)")

            // 1. Validate the downloaded model
            let newModel: MLModel
            var newModelVersion: String?
            do {
                let configuration = MLModelConfiguration()
                newModel = try MLModel(contentsOf: tempDownloadPath, configuration: configuration)
                newModelVersion = newModel.modelDescription.metadata.versionString
                print("New model loaded successfully for validation. Version: \(newModelVersion ?? "N/A")")
            } catch let error as CoreMLError {
                try? FileManager.default.removeItem(at: tempDownloadPath) // Clean up
                throw ModelUpdateError.invalidModelFile(tempDownloadPath)
            } catch {
                try? FileManager.default.removeItem(at: tempDownloadPath) // Clean up
                throw ModelUpdateError.invalidModelFile(tempDownloadPath)
            }

            // 2. Version check
            if let expectedVer = expectedVersion,
               let actualVer = newModelVersion {
                if !actualVer.isSemanticVersionGreaterThan(expectedVer) && !actualVer.isSemanticVersionEqual(expectedVer) {
                    try? FileManager.default.removeItem(at: tempDownloadPath) // Clean up
                    throw ModelUpdateError.versionMismatch(expected: expectedVer, actual: actualVer)
                }
            } else if let activeModel = currentActiveModel, let activeVersion = activeModel.modelDescription.metadata.versionString,
                      let newVer = newModelVersion {
                // If no expectedVersion, ensure it's strictly newer than current active
                if !newVer.isSemanticVersionGreaterThan(activeVersion) {
                    print("New model version (\(newVer)) is not strictly greater than current active (\(activeVersion)). Skipping.")
                    try? FileManager.default.removeItem(at: tempDownloadPath)
                    throw ModelUpdateError.versionMismatch(expected: "strictly newer than \(activeVersion)", actual: newVer)
                }
            } else if newModelVersion == nil {
                try? FileManager.default.removeItem(at: tempDownloadPath)
                throw ModelUpdateError.invalidModelFile(tempDownloadPath) // Model must have a version
            }
            
            // Get current active model details for rollback
            let previousActiveModelPath = userDefaults.string(forKey: activeModelPathKey)
            
            // 3. Activation: Update active and fallback paths
            userDefaults.set(tempDownloadPath.path, forKey: activeModelPathKey)
            if let prevPath = previousActiveModelPath {
                userDefaults.set(prevPath, forKey: fallbackModelPathKey)
                print("Previous active model (\(URL(fileURLWithPath: prevPath).lastPathComponent)) set as fallback.")
            } else {
                userDefaults.removeObject(forKey: fallbackModelPathKey) // No previous fallback if this is the first model
            }
            
            self.currentActiveModel = newModel // Set the new model in memory
            self.currentActiveModelURL = tempDownloadPath
            print("New model \(newModelVersion ?? "N/A") activated successfully.")

        } catch let error as ModelUpdateError {
            print("Model update failed with specific error: \(error.localizedDescription)")
            throw error // Re-throw specific update errors
        } catch {
            print("Model update failed with unexpected error: \(error.localizedDescription)")
            throw ModelUpdateError.downloadFailed(simulatedDownloadURL) // General download failure
        }
    }

    /// Retrieves the currently active MLModel instance, loading it if necessary.
    /// - Returns: The active MLModel.
    /// - Throws: `ModelUpdateError.noActiveModelAvailable` if no model can be loaded.
    func getActiveModel() throws -> MLModel {
        // If the in-memory model is still the active one, return it
        if let activeModel = currentActiveModel, let activeURL = currentActiveModelURL,
           userDefaults.string(forKey: activeModelPathKey) == activeURL.path {
            return activeModel
        }

        guard let activePath = userDefaults.string(forKey: activeModelPathKey) else {
            print("No active model path found in UserDefaults. Attempting rollback.")
            // If active path is lost, try to rollback to a known good state
            do {
                try rollbackToFallbackModel()
                return try getActiveModel() // Recurse after successful rollback
            } catch {
                print("Rollback failed after active model path loss: \(error.localizedDescription)")
                throw ModelUpdateError.noActiveModelAvailable
            }
        }
        let activeURL = URL(fileURLWithPath: activePath)

        do {
            let configuration = MLModelConfiguration()
            let model = try MLModel(contentsOf: activeURL, configuration: configuration)
            self.currentActiveModel = model
            self.currentActiveModelURL = activeURL
            print("Active model loaded from path: \(activeURL.lastPathComponent) (Version: \(model.modelDescription.metadata.versionString ?? "N/A"))")
            return model
        } catch let error as CoreMLError {
            print("Core ML Error loading active model from \(activeURL.lastPathComponent): \(error.localizedDescription)")
            // If the active model fails to load, attempt rollback
            do {
                try rollbackToFallbackModel()
                return try getActiveModel() // Recurse after successful rollback
            } catch {
                print("Rollback failed after active model loading error: \(error.localizedDescription)")
                throw ModelUpdateError.noActiveModelAvailable // If fallback also fails, we're in trouble
            }
        } catch {
            print("Unexpected error loading active model from \(activeURL.lastPathComponent): \(error.localizedDescription)")
            do {
                try rollbackToFallbackModel()
                return try getActiveModel() // Recurse after successful rollback
            } catch {
                print("Rollback failed after unexpected active model loading error: \(error.localizedDescription)")
                throw ModelUpdateError.noActiveModelAvailable
            }
        }
    }

    /// Attempts to revert to the last known working model.
    /// - Throws: `ModelUpdateError.noFallbackModelAvailable` if no fallback can be loaded.
    func rollbackToFallbackModel() throws {
        print("\n--- Initiating model rollback ---")
        guard let fallbackPath = userDefaults.string(forKey: fallbackModelPathKey) else {
            print("No fallback model path available. Cannot rollback.")
            throw ModelUpdateError.noFallbackModelAvailable
        }

        let fallbackURL = URL(fileURLWithPath: fallbackPath)
        do {
            let configuration = MLModelConfiguration()
            let model = try MLModel(contentsOf: fallbackURL, configuration: configuration)
            self.currentActiveModel = model
            self.currentActiveModelURL = fallbackURL
            userDefaults.set(fallbackPath, forKey: activeModelPathKey) // Make fallback the new active
            userDefaults.removeObject(forKey: fallbackModelPathKey) // Clear fallback after rollback
            print("Successfully rolled back to model: \(fallbackURL.lastPathComponent) (Version: \(model.modelDescription.metadata.versionString ?? "N/A"))")
        } catch let error as CoreMLError {
            print("Core ML Error loading fallback model from \(fallbackURL.lastPathComponent): \(error.localizedDescription)")
            throw ModelUpdateError.noActiveModelAvailable // If fallback also fails, we're in trouble
        } catch {
            print("Unexpected error loading fallback model from \(fallbackURL.lastPathComponent): \(error.localizedDescription)")
            throw ModelUpdateError.noActiveModelAvailable
        }
    }

    /// Simulates a prediction failure with the currently active model.
    /// In a real app, this would be based on actual Vision/Core ML prediction errors or performance metrics.
    /// - Returns: `true` if a failure is simulated, `false` otherwise.
    func simulatePredictionFailure() -> Bool {
        // For demonstration, let's say models with "v2_0" are currently buggy
        if let currentVersion = currentActiveModel?.modelDescription.metadata.versionString,
           currentVersion == "2.0.0" { // Example: v2.0 is buggy
            print("Simulating prediction failure for current active model (Version: \(currentVersion)).")
            return true
        }
        return false
    }
}

// Example Usage (in an AppDelegate or ViewController)
/*
@available(iOS 18.0, *)
class AppCoordinator {
    let modelUpdater = ARModelUpdater()

    func startApp() {
        // Initial load of the active model
        do {
            let model = try modelUpdater.getActiveModel()
            print("App started with active model: \(model.modelDescription.metadata.versionString ?? "N/A")")
        } catch {
            print("Failed to get initial active model: \(error.localizedDescription)")
            // Handle critical startup failure, e.g., disable AR features
        }

        // Simulate an OTA update later
        Task {
            // Assume ARObjectRecognizer_v1_1.mlmodelc is another bundled model for simulation
            // You need to add ARObjectRecognizer_v1_0.mlmodel, ARObjectRecognizer_v1_1.mlmodel,
            // and ARObjectRecognizer_v2_0.mlmodel to your Xcode project for this to work.
            // These can be dummy models exported from Xcode.

            if let newModelURL_v1_1 = Bundle.main.url(forResource: "ARObjectRecognizer_v1_1", withExtension: "mlmodelc") {
                do {
                    print("\n--- Attempting to update to v1.1 ---")
                    try await modelUpdater.downloadAndActivateModel(from: newModelURL_v1_1, expectedVersion: "1.1.0")
                    let activeModel = try modelUpdater.getActiveModel()
                    print("Successfully updated to model version: \(activeModel.modelDescription.metadata.versionString ?? "N/A")")

                    // Simulate a buggy model update (e.g., if v2.0 was actually broken)
                    if let buggyModelURL_v2_0 = Bundle.main.url(forResource: "ARObjectRecognizer_v2_0", withExtension: "mlmodelc") {
                        do {
                            print("\n--- Attempting to update to v2.0 (buggy) ---")
                            try await modelUpdater.downloadAndActivateModel(from: buggyModelURL_v2_0, expectedVersion: "2.0.0")
                            print("Updated to potentially buggy v2.0 model.")

                            // Simulate a prediction failure with the new model
                            if modelUpdater.simulatePredictionFailure() {
                                print("Detected prediction failure with current model. Initiating rollback.")
                                try modelUpdater.rollbackToFallbackModel()
                                let rolledBackModel = try modelUpdater.getActiveModel()
                                print("Rollback successful. Now using model version: \(rolledBackModel.modelDescription.metadata.versionString ?? "N/A")")
                            }
                        } catch {
                            print("Failed to update to v2.0 or encountered an error: \(error.localizedDescription)")
                            // The app should still be running with the previous model (v1.1 in this case)
                            do {
                                let currentModel = try modelUpdater.getActiveModel()
                                print("App continues with existing model: \(currentModel.modelDescription.metadata.versionString ?? "N/A")")
                            } catch {
                                print("Critical: Could not even load existing model after update failure: \(error.localizedDescription)")
                            }
                        }
                    }

                } catch {
                    print("Model update failed: \(error.localizedDescription)")
                    // The app should still be running with the previous model (v1.0 in this case)
                    do {
                        let currentModel = try modelUpdater.getActiveModel()
                        print("App continues with existing model: \(currentModel.modelDescription.metadata.versionString ?? "N/A")")
                    } catch {
                        print("Critical: Could not even load existing model after update failure: \(error.localizedDescription)")
                    }
                }
            } else {
                print("ARObjectRecognizer_v1_1.mlmodelc not found in bundle for simulation.")
            }
            
            // Test case: Simulate a non-existent model download
            print("\n--- Test: Simulate download of non-existent model ---")
            let nonExistentURL = URL(fileURLWithPath: "/path/to/nonexistent_model.mlmodelc")
            do {
                try await modelUpdater.downloadAndActivateModel(from: nonExistentURL, expectedVersion: "3.0.0")
            } catch {
                print("Successfully caught error for non-existent model: \(error.localizedDescription)")
            }
        }
    }
}
*/
