
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import XCTest

final class TokenStreamer {
    func streamTokens() -> AsyncStream<String> {
        AsyncStream { continuation in
            Task {
                let tokens = ["Hello", " ", "world", "!"]
                for token in tokens {
                    // Simulate network/inference latency
                    try? await Task.sleep(nanoseconds: 100_000_000) 
                    continuation.yield(token)
                }
                continuation.finish()
            }
        }
    }
}

final class CodeWhisperTests: XCTestCase {
    
    func test_tokenStream_emitsCorrectSequence() async throws {
        let streamer = TokenStreamer()
        var receivedTokens: [String] = []
        
        // We use a TaskGroup to implement a timeout mechanism
        // This prevents the test from hanging indefinitely if the stream never finishes
        try await withThrowingTaskGroup(of: Void.self) { group in
            
            // Task 1: Consume the stream
            group.addTask {
                for await token in streamer.streamTokens() {
                    receivedTokens.append(token)
                }
            }
            
            // Task 2: Timeout watchdog
            group.addTask {
                try await Task.sleep(nanoseconds: 2_000_000_000) // 2 second timeout
                throw NSError(domain: "TestTimeout", code: -1)
            }
            
            // Wait for the first task to finish (the stream completion)
            // If the watchdog finishes first, it throws and fails the test
            try await group.next()
            group.cancelAll()
        }
        
        // Assertions
        let fullSentence = receivedTokens.joined()
        XCTAssertEqual(fullSentence, "Hello world!")
        XCTAssertEqual(receivedTokens, ["Hello", " ", "world", "!"])
    }
    
    func test_stream_handlesCancellation() async {
        let streamer = TokenStreamer()
        let expectation = expectation(description: "Stream should cancel")
        
        let task = Task {
            var count = 0
            for await _ in streamer.streamTokens() {
                count += 1
            }
            expectation.fulfill()
        }
        
        // Cancel the task mid-stream
        try? await Task.sleep(nanoseconds: 250_000_000)
        task.cancel()
        
        await fulfillment(of: [expectation], timeout: 1.0)
        task.cancel() 
    }
}
