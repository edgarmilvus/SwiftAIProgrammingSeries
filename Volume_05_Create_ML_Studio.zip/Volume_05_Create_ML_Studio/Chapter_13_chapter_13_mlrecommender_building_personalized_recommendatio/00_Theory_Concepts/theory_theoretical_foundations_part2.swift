
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import Observation // For @Observable

    @available(iOS 17.0, *)
    @Observable
    class RecommendationStore {
        var recommendations: [String] = []
        var isLoading: Bool = false
        var errorMessage: String?
        private let engine: RecommendationEngine

        init(engine: RecommendationEngine) {
            self.engine = engine
        }

        func fetchRecommendations(for user: String, count: Int) async {
            isLoading = true
            errorMessage = nil
            do {
                let results = try await engine.getRecommendations(for: user, count: count)
                recommendations = results
            } catch {
                errorMessage = "Failed to get recommendations: \(error.localizedDescription)"
                print("Error fetching recommendations: \(error)")
            }
            isLoading = false
        }

        func startTraining() async {
            isLoading = true
            errorMessage = nil
            do {
                try await engine.trainModel()
            } catch {
                errorMessage = "Failed to train model: \(error.localizedDescription)"
                print("Error training model: \(error)")
            }
            isLoading = false
        }
    }

    @available(iOS 17.0, *)
    struct RecommendationView: View {
        @State private var store: RecommendationStore
        @State private var currentUser: String = "UserA"

        init(engine: RecommendationEngine) {
            _store = State(initialValue: RecommendationStore(engine: engine))
        }

        var body: some View {
            VStack {
                TextField("Current User", text: $currentUser)
                    .textFieldStyle(.roundedBorder)
                    .padding()

                Button("Train Model") {
                    Task { await store.startTraining() }
                }
                .disabled(store.isLoading)
                .padding()

                Button("Get Recommendations") {
                    Task { await store.fetchRecommendations(for: currentUser, count: 5) }
                }
                .disabled(store.isLoading)
                .padding()

                if store.isLoading {
                    ProgressView("Loading...")
                } else if let error = store.errorMessage {
                    Text("Error: \(error)")
                        .foregroundColor(.red)
                } else {
                    List(store.recommendations, id: \.self) { item in
                        Text(item)
                    }
                }
            }
            .navigationTitle("MLRecommender Demo")
        }
    }
    