
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import CoreML
import Foundation

// MARK: - Semantic Version Comparison Utility

@available(iOS 18.0, macOS 15.0, *)
extension String {
    /// Compares two semantic version strings (e.g., "1.0.0", "1.1.0-alpha").
    /// Returns true if the receiver is greater than the other version.
    func isNewerVersion(than otherVersion: String) -> Bool {
        let components1 = self.split(separator: "-").first?.split(separator: ".").map { Int($0) ?? 0 } ?? []
        let components2 = otherVersion.split(separator: "-").first?.split(separator: ".").map { Int($0) ?? 0 } ?? []

        // Compare major, minor, patch
        for i in 0..<max(components1.count, components2.count) {
            let v1 = i < components1.count ? components1[i] : 0
            let v2 = i < components2.count ? components2[i] : 0
            if v1 > v2 { return true }
            if v1 < v2 { return false }
        }

        // If numeric parts are equal, compare pre-release identifiers
        let prerelease1 = self.split(separator: "-").dropFirst().first?.lowercased()
        let prerelease2 = otherVersion.split(separator: "-").dropFirst().first?.lowercased()

        switch (prerelease1, prerelease2) {
        case (.some(let p1), .some(let p2)):
            return p1 > p2 // "beta" > "alpha"
        case (.some(_), nil):
            return false // A version with prerelease is older than one without
        case (nil, .some(_)):
            return true // A version without prerelease is newer than one with
        case (nil, nil):
            return false // Versions are identical
        }
    }
}

// MARK: - Model Manager

@available(iOS 18.0, macOS 15.0, *)
class DynamicModelManager: ObservableObject {
    @Published var activeModel: MLModel?
    @Published var activeModelVersion: String = "Not Loaded"
    @Published var statusMessage: String = "App started."

    // Function to load model metadata without loading the full model
    func getModelMetadata(at url: URL) async throws -> [MLModelMetadataKey: Any] {
        let options = MLModelLoadingOptions()
        // In a real scenario, you might use options.loadIfSigned(by:) for security
        
        // Perform synchronous metadata loading on a background thread
        return try await Task.detached {
            let model = try MLModel(contentsOf: url, configuration: MLModelConfiguration(), options: options)
            return model.modelDescription.metadata
        }.value
    }

    // Function to load a full MLModel
    func loadModel(from url: URL) async throws -> MLModel {
        // Perform synchronous model loading on a background thread
        return try await Task.detached {
            return try MLModel(contentsOf: url, configuration: MLModelConfiguration())
        }.value
    }

    // Main function to check for updates and switch models
    func checkForModelUpdates(newModelURL: URL) async {
        DispatchQueue.main.async { self.statusMessage = "Checking for updates..." }
        do {
            // 1. Get current model's version
            let currentVersion = activeModelVersion

            // 2. Get metadata of the "downloaded" model
            let newModelMetadata = try await getModelMetadata(at: newModelURL)
            guard let newVersion = newModelMetadata[MLModelMetadataKey.versionString] as? String else {
                throw NSError(domain: "ModelUpdateError", code: 1, userInfo: [NSLocalizedDescriptionKey: "New model metadata missing version string."])
            }

            // 3. Compare versions
            if newVersion.isNewerVersion(than: currentVersion) {
                DispatchQueue.main.async { self.statusMessage = "Newer model (v\(newVersion)) found! Loading..." }

                // 4. Dynamically load the new model
                let newlyLoadedModel = try await loadModel(from: newModelURL)

                DispatchQueue.main.async {
                    self.activeModel = newlyLoadedModel
                    self.activeModelVersion = newVersion
                    self.statusMessage = "Successfully updated to model version \(newVersion)."
                    print("Model updated to version \(newVersion)")
                }
            } else {
                DispatchQueue.main.async { self.statusMessage = "Current model (v\(currentVersion)) is already the latest version." }
                print("No update needed. Current: \(currentVersion), New: \(newVersion)")
            }

        } catch {
            DispatchQueue.main.async {
                self.statusMessage = "Error checking/loading update: \(error.localizedDescription)"
                print("Error: \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - SwiftUI View

@available(iOS 18.0, macOS 15.0, *)
struct Exercise3View: View {
    @StateObject private var modelManager = DynamicModelManager()
    @State private var showUpdateAlert = false
    @State private var updateAlertMessage = ""

    // Simulate "downloaded" model by copying v2 from bundle to a temp directory
    private func simulateModelDownload() async throws -> URL {
        guard let v2URL = Bundle.main.url(forResource: "ObjectDetector_v2", withExtension: "mlpackage") else {
            throw NSError(domain: "SimulatedDownloadError", code: 404, userInfo: [NSLocalizedDescriptionKey: "ObjectDetector_v2.mlpackage not found in bundle."])
        }

        let tempDir = FileManager.default.temporaryDirectory
        let destinationURL = tempDir.appendingPathComponent("ObjectDetector_v2_downloaded.mlpackage")

        // Remove existing if any
        if FileManager.default.fileExists(atPath: destinationURL.path) {
            try FileManager.default.removeItem(at: destinationURL)
        }

        try FileManager.default.copyItem(at: v2URL, to: destinationURL)
        print("Simulated download: ObjectDetector_v2 copied to \(destinationURL.path)")
        return destinationURL
    }

    var body: some View {
        VStack(spacing: 20) {
            Text("AR Object Detector")
                .font(.largeTitle)
                .fontWeight(.bold)

            Spacer()

            Text("Active Model Version:")
                .font(.headline)
            Text(modelManager.activeModelVersion)
                .font(.title)
                .foregroundColor(.accentColor)
                .padding()
                .background(Capsule().fill(Color.gray.opacity(0.1)))

            Text(modelManager.statusMessage)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            Spacer()

            Button("Check for Model Updates") {
                Task {
                    do {
                        let downloadedModelURL = try await simulateModelDownload()
                        await modelManager.checkForModelUpdates(newModelURL: downloadedModelURL)
                    } catch {
                        updateAlertMessage = "Failed to simulate model download: \(error.localizedDescription)"
                        showUpdateAlert = true
                    }
                }
            }
            .buttonStyle(.borderedProminent)
            .padding()

            Text("Note: 'ObjectDetector_v1.mlpackage' (v1.0.0) and 'ObjectDetector_v2.mlpackage' (v1.1.0) are expected in the app bundle for this demo.")
                .font(.footnote)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        .padding()
        .onAppear {
            // Load initial model (v1) from bundle
            Task {
                do {
                    guard let v1URL = Bundle.main.url(forResource: "ObjectDetector_v1", withExtension: "mlpackage") else {
                        throw NSError(domain: "InitialLoadError", code: 404, userInfo: [NSLocalizedDescriptionKey: "ObjectDetector_v1.mlpackage not found in bundle."])
                    }
                    let initialModel = try await modelManager.loadModel(from: v1URL)
                    guard let version = initialModel.modelDescription.metadata[MLModelMetadataKey.versionString] as? String else {
                        throw NSError(domain: "InitialLoadError", code: 2, userInfo: [NSLocalizedDescriptionKey: "Initial model metadata missing version string."])
                    }
                    DispatchQueue.main.async {
                        modelManager.activeModel = initialModel
                        modelManager.activeModelVersion = version
                        modelManager.statusMessage = "Initial model v\(version) loaded."
                    }
                } catch {
                    DispatchQueue.main.async {
                        modelManager.statusMessage = "Failed to load initial model: \(error.localizedDescription)"
                    }
                }
            }
        }
        .alert("Update Error", isPresented: $showUpdateAlert) {
            Button("OK") { }
        } message: {
            Text(updateAlertMessage)
        }
    }
}

// MARK: - App Entry Point (for demonstration in an Xcode project)
/*
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            Exercise3View()
        }
    }
}
*/
