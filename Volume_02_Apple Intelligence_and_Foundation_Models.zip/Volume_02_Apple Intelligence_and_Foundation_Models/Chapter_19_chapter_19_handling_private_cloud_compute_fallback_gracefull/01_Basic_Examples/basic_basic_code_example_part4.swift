
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.swift
// Description: Basic Code Example
// ==========================================

/// SwiftUI View for the Document Scanner app interface.
@available(iOS 18.0, macOS 15.0, *)
struct DocumentScannerView: View {
    @StateObject private var viewModel = DocumentScannerViewModel()

    var body: some View {
        NavigationView {
            Form {
                Section("Document Text") {
                    TextEditor(text: $viewModel.scannedText)
                        .frame(minHeight: 100)
                        .border(Color.gray.opacity(0.3), width: 1)
                        .padding(.vertical, 5)
                }

                Section("AI Compute Policy") {
                    Picker("Policy", selection: $viewModel.selectedPolicy) {
                        ForEach(AIComputePolicy.allCases) { policy in
                            Text(policy.rawValue).tag(policy)
                        }
                    }
                    .pickerStyle(.menu) // Or .segmented for fewer options
                }

                Section("Actions") {
                    Button("Summarize Document") {
                        viewModel.summarizeDocument()
                    }
                    .disabled(viewModel.processingState != .idle && viewModel.processingState != .finished && viewModel.processingState != .error)
                }

                Section("Processing Status") {
                    switch viewModel.processingState {
                    case .idle:
                        Text("Ready to summarize.")
                    case .processing(let policy):
                        HStack {
                            ProgressView()
                            Text("Processing with \(policy.rawValue)...")
                        }
                    case .finished:
                        Text("Processing complete.")
                    case .error:
                        Text("Error during processing.")
                            .foregroundColor(.red)
                    }
                }

                if let errorMessage = viewModel.errorMessage {
                    Section("Error") {
                        Text(errorMessage)
                            .foregroundColor(.red)
                    }
                }

                if let summary = viewModel.resultSummary {
                    Section("Summary Result") {
                        Text(summary)
                            .font(.body)
                        if let source = viewModel.computeSource {
                            Text("Computed by: \(source.rawValue)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("AI Document Scanner")
        }
    }
}

// MARK: - App Entry Point (for Xcode Previews and actual app)
@available(iOS 18.0, macOS 15.0, *)
struct DocumentScannerApp: App {
    var body: some Scene {
        WindowGroup {
            DocumentScannerView()
        }
    }
}

// To enable SwiftUI previews in Xcode
@available(iOS 18.0, macOS 15.0, *)
#Preview {
    DocumentScannerView()
}
