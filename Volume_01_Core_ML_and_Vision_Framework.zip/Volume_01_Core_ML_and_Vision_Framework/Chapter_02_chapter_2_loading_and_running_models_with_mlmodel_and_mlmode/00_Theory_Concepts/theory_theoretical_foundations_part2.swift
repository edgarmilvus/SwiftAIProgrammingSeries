
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Foundation

// Assume MyModel is the generated Swift class from your .mlmodel file
// and it has an initializer that takes MLModelConfiguration.
@available(iOS 13.0, *)
func runInference(inputProvider: MLFeatureProvider) async throws -> MLFeatureProvider {
    // 1. Configure the model execution
    let config = MLModelConfiguration()
    config.computeUnits = .all // Utilize all available compute units (CPU, GPU, Neural Engine)
    config.allowLowPrecisionAccumulationOnGPU = true // Potentially faster on GPU

    // 2. Load the model with the configuration
    // This initializer is often used for generic MLModel loading,
    // or when you need to override the default configuration for a generated model class.
    // For generated model classes, you'd typically instantiate like `MyModel(configuration: config)`.
    guard let modelURL = Bundle.main.url(forResource: "MyModel", withExtension: "mlmodelc") else {
        fatalError("Failed to find model bundle.")
    }
    let genericModel = try MLModel(contentsOf: modelURL, configuration: config)

    // 3. Perform prediction asynchronously
    let prediction = try await genericModel.prediction(from: inputProvider)
    return prediction
}
