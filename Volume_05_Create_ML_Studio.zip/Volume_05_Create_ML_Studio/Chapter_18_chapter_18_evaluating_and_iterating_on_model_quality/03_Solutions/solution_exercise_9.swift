
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_9.swift
// Description: Solution for Exercise 9
// ==========================================

// This exercise is conceptual, focusing on data analysis, preparation strategies,
// and evaluation metrics within the Create ML context. No direct Swift code is
// required for the data balancing or training steps themselves, as these are
// typically handled in Create ML Studio or via pre-processing scripts.
//
// However, once a balanced model is trained, it would be used in a Swift app
// similarly to other Core ML models, often by providing MLFeatureProvider data.

import CoreML
import Foundation

// Example of how to use a trained MLTabularClassifier in Swift
@available(iOS 13.0, macOS 10.15, watchOS 6.0, tvOS 13.0, *) // Or appropriate version
class ChurnPredictor {
    private var model: CustomerChurnPredictor? // Replace with your actual model name

    init() {
        // Load the compiled Core ML model
        // CustomerChurnPredictor is the generated class from your .mlmodel
        do {
            let configuration = MLModelConfiguration()
            self.model = try CustomerChurnPredictor(configuration: configuration)
            print("CustomerChurnPredictor model loaded successfully.")
        } catch {
            print("Error loading CustomerChurnPredictor model: \(error.localizedDescription)")
        }
    }

    // This method takes a dictionary representing customer attributes.
    // The keys should match the feature names used during Create ML training.
    func predictChurn(customerAttributes: [String: Any]) -> String? {
        guard let model = self.model else {
            print("Model not loaded.")
            return nil
        }
        do {
            // Create an MLFeatureProvider from the dictionary
            let inputFeatures = try MLDictionaryFeatureProvider(dictionary: customerAttributes)

            let prediction = try model.prediction(input: inputFeatures) // Assuming 'input' is the input feature name

            // The output feature name might be 'churnLabel', 'prediction', 'customerStatus', etc.
            if let predictedStatus = prediction.churnLabel { // Assuming 'churnLabel' is the output feature
                print("Predicted customer status: \(predictedStatus)")
                return predictedStatus
            }
        } catch {
            print("Prediction error: \(error.localizedDescription)")
        }
        return nil
    }

    // Example of how to create an MLDictionaryFeatureProvider for demonstration
    struct MLDictionaryFeatureProvider: MLFeatureProvider {
        let dictionary: [String: Any]
        let featureNames: Set<String>

        init(dictionary: [String: Any]) throws {
            self.dictionary = dictionary
            self.featureNames = Set(dictionary.keys)
        }

        func featureValue(for featureName: String) -> MLFeatureValue? {
            guard let value = dictionary[featureName] else { return nil }

            // Core ML expects specific types. You might need type casting based on your features.
            if let stringValue = value as? String {
                return MLFeatureValue(string: stringValue)
            } else if let intValue = value as? Int {
                return MLFeatureValue(int: intValue)
            } else if let doubleValue = value as? Double {
                return MLFeatureValue(double: doubleValue)
            } else if let boolValue = value as? Bool {
                return MLFeatureValue(bool: boolValue)
            }
            // Add other type conversions as needed (e.g., for MLMultiArray if you have complex features)
            return nil
        }
    }
}

/*
// Example Usage (conceptual, as no real customer data is provided)
if #available(iOS 13.0, macOS 10.15, watchOS 6.0, tvOS 13.0, *) {
    let predictor = ChurnPredictor()
    let customerData: [String: Any] = [
        "subscription_duration": 12.0,
        "last_interaction_days": 30.0,
        "support_tickets": 2,
        "avg_monthly_spend": 55.75,
        "plan_type": "Premium"
    ]
    // let predictedChurn = predictor.predictChurn(customerAttributes: customerData)
}
*/
