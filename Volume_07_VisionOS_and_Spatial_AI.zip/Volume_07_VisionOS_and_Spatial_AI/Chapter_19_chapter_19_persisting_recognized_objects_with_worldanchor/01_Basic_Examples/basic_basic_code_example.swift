
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import ARKit
import RealityKit
import Observation

// MARK: - Models

/// Represents a digital note pinned to a physical location.
struct SpatialNote: Identifiable, Codable {
    let id: UUID
    let text: String
    let transform: simd_float4x4 // The position and orientation in the world
}

// MARK: - Spatial Manager

/// An actor responsible for managing the ARKit session and the persistence of anchors.
/// Using an actor ensures that the heavy lifting of world tracking and anchor 
/// management is thread-safe and isolated from the UI.
@available(visionOS 1.0, *)
actor SpatialPersistenceManager {
    
    /// The session used to track the world and manage anchors.
    private let session = ARKitSession()
    
    /// The provider that gives us access to the world-tracking data.
    private let worldTracking = WorldTrackingProvider()
    
    /// A collection of currently recognized and persisted anchors.
    private(set) var activeAnchors: [UUID: WorldAnchor] = [:]
    
    init() {
        // Initialization of the session is handled via async startup.
    }
    
    /// Starts the ARKit session and begins tracking the world.
    /// - Throws: An error if the session cannot be started (e.g., camera permissions).
    func startSession() async throws {
        try await session.run([worldTracking])
    }
    
    /// Creates a new WorldAnchor at a specific transform.
    /// - Parameter transform: The 4x4 matrix representing the physical location.
    /// - Returns: A newly created WorldAnchor.
    func createAnchor(at transform: simd_float4x4) async throws -> WorldAnchor {
        // We request the system to create an anchor that is tied to the 
        // physical environment's feature points.
        let anchor = try await worldTracking.createAnchor(at: transform)
        activeAnchors[anchor.id] = anchor
        return anchor
    }
    
    /// Retrieves the current world tracking status.
    func getTrackingStatus() -> ARKitSession.Status {
        // In a real app, you would monitor the session state via an AsyncSequence.
        return .running // Simplified for this example
    }
}

// MARK: - View Model

/// The ViewModel bridges the SpatialPersistenceManager (Actor) and the SwiftUI View (MainActor).
@Observable
@MainActor
class SpatialMemoryViewModel {
    
    /// The manager that handles the background spatial logic.
    private let manager = SpatialPersistenceManager()
    
    /// The RealityKit view that renders the 3D content.
    var arView: RealityKit.ARView?
    
    /// Tracks whether the session is currently active.
    var isSessionRunning = false
    
    /// A list of notes to display in the UI.
    var notes: [SpatialNote] = []
    
    /// Starts the spatial session.
    func setupSession() {
        Task {
            do {
                try await manager.startSession()
                isSessionRunning = true
                print("Spatial Session Started Successfully")
            } catch {
                print("Failed to start session: \(error)")
                isSessionRunning = false
            }
        }
    }
    
    /// Handles the user interaction to place a note.
    /// - Parameter location: The 3D coordinate tapped by the user.
    func placeNote(at location: simd_float4x4, text: String) {
        Task {
            do {
                // 1. Create the persistent WorldAnchor via the actor.
                let anchor = try await manager.createAnchor(at: location)
                
                // 2. Create the RealityKit visual representation.
                let anchorEntity = AnchorEntity(world: anchor.transform)
                
                // 3. Create a simple 3D text/box to represent the note.
                let mesh = MeshResource.generateBox(size: 0.1)
                let material = SimpleMaterial(color: .systemBlue, isMetallic: true)
                let modelEntity = ModelEntity(mesh: mesh, materials: [material])
                
                // 4. Attach the visual to the anchor entity.
                anchorEntity.addChild(modelEntity)
                
                // 5. Add the anchor entity to the ARView's scene.
                arView?.scene.addAnchor(anchorEntity)
                
                // 6. Update our local state.
                let newNote = SpatialNote(id: anchor.id, text: text, transform: location)
                notes.append(newNote)
                
            } catch {
                print("Error placing anchor: \(error)")
            }
        }
    }
}

// MARK: - UI Layer

struct SpatialMemoryView: View {
    @State private var viewModel = SpatialMemoryViewModel()
    @State private var noteTextField = "New Memory"
    
    var body: some View {
        ZStack(alignment: .bottom) {
            // The AR View Container
            ARViewContainer(viewModel: viewModel)
                .edgesIgnoringSafeArea(.all)
            
            // UI Overlay
            VStack {
                if !viewModel.isSessionRunning {
                    Button("Start Spatial Session") {
                        viewModel.setupSession()
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                }
                
                HStack {
                    TextField("Enter note...", text: $noteTextField)
                        .textFieldStyle(.roundedBorder)
                        .padding()
                    
                    Button("Pin Note") {
                        // In a real app, we would use a raycast to find the 3D position.
                        // For this example, we simulate a hit at the center of the view.
                        let simulatedTransform = simd_float4x4(diagonal: [1, 1, 1, 1])
                        viewModel.placeNote(at: simulatedTransform, text: noteTextField)
                    }
                    .buttonStyle(.bordered)
                }
                .background(.ultraThinMaterial)
                .cornerRadius(15)
                .padding()
            }
        }
    }
}

/// A bridge between SwiftUI and RealityKit.
struct ARViewContainer: UIViewRepresentable {
    let viewModel: SpatialMemoryViewModel
    
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        
        // Assign the view to the view model so we can manipulate the scene.
        DispatchQueue.main.async {
            viewModel.arView = arView
        }
        
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
}
