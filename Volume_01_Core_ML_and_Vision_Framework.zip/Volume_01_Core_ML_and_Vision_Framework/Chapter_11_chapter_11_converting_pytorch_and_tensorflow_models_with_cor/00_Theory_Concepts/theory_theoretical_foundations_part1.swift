
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Vision
import Foundation // For URL

@available(iOS 18.0, macOS 15.0, *)
class ModelLoader {
    private var model: MLModel?

    // Simulate a complex model loading process
    func loadModel(named modelName: String) async throws -> MLModel {
        if let existingModel = model {
            return existingModel
        }

        // Reference to a concept from a previous chapter:
        // We assume 'MyImageClassifier.mlmodel' was created using coremltools
        // and is included in the app bundle.
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            throw ModelError.notFound
        }

        // MLModel loading can be asynchronous and resource-intensive
        let configuration = MLModelConfiguration()
        configuration.computeUnits = .all // Utilize Neural Engine, GPU, CPU
        
        // This is where async/await shines for potentially long-running operations
        let loadedModel = try await MLModel.load(contentsOf: modelURL, configuration: configuration)
        self.model = loadedModel
        return loadedModel
    }

    // Example of asynchronous inference
    func performInference(image: MLFeatureProvider) async throws -> MLFeatureProvider {
        guard let model = self.model else {
            throw ModelError.notLoaded
        }
        
        // Perform prediction asynchronously
        let prediction = try await model.prediction(from: image)
        return prediction
    }
}

@available(iOS 18.0, macOS 15.0, *)
enum ModelError: Error {
    case notFound
    case notLoaded
    case inferenceFailed
}

// Usage Example:
@available(iOS 18.0, macOS 15.0, *)
func applicationStartup() async {
    let loader = ModelLoader()
    do {
        print("Starting model load...")
        let myModel = try await loader.loadModel(named: "MyImageClassifier")
        print("Model loaded: \(myModel.modelDescription.metadata[MLModelMetadataKey.authorKey] ?? "Unknown Author")")
        // Now you can use myModel for inference
    } catch {
        print("Failed to load model: \(error.localizedDescription)")
    }
}
