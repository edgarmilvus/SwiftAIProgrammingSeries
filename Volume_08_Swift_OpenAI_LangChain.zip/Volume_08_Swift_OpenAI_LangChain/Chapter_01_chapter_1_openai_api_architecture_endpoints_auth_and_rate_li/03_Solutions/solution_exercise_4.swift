
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

struct ContextConfiguration: Sendable {
    let maxTokens: Int
    let systemPrompt: ChatMessage
    let summaryThreshold: Int // Threshold at which we trigger summarization
}

final class ContextManager: @unchecked Sendable {
    private let config: ContextConfiguration
    private var history: [ChatMessage] = []
    
    init(config: ContextConfiguration) {
        self.config = config
        self.history.append(config.systemPrompt)
    }
    
    /// Heuristic: 1 token ≈ 4 characters
    private func tokenCount(for text: String) -> Int {
        return text.count / 4
    }
    
    private func calculateTotalTokens(for messages: [ChatMessage]) -> Int {
        messages.reduce(0) { $0 + tokenCount(for: $1.content) }
    }
    
    /// Prepares the message array for the API call, ensuring it fits the context window.
    func prepareMessages(currentInput: String, history: [ChatMessage]) async -> [ChatMessage] {
        var workingHistory = history
        let inputMessage = ChatMessage(role: .user, content: currentInput)
        workingHistory.append(inputMessage)
        
        // 1. Check if we are over the limit
        var totalTokens = calculateTotalTokens(for: workingHistory)
        
        if totalTokens > config.maxTokens {
            // 2. Check if we should summarize instead of just truncating
            if workingHistory.count > 10 {
                workingHistory = await summarizeOldContext(workingHistory)
            } else {
                // 3. Fallback: Sliding Window Truncation
                workingHistory = applySlidingWindow(workingHistory)
            }
        }
        
        return workingHistory
    }
    
    private func applySlidingWindow(_ messages: [ChatMessage]) -> [ChatMessage] {
        var result = [messages[0]] // Always keep System Prompt
        
        // Keep the most recent messages until we hit the limit
        // We iterate backwards from the end (excluding the system prompt)
        for i in (1..<messages.count).reversed() {
            let potentialMessages = [messages[0]] + messages[i..<messages.count]
            if calculateTotalTokens(for: potentialMessages) <= config.maxTokens {
                return potentialMessages
            }
        }
        return result
    }
    
    private func summarizeOldContext(_ messages: [ChatMessage]) async -> [ChatMessage] {
        print("Simulating summarization of old context...")
        // In a real app, you would call a cheaper model here.
        // For this exercise, we simulate by taking the first 10 messages and 
        // replacing them with a single summary message.
        let systemPrompt = messages[0]
        let recentMessages = Array(messages.suffix(5)) // Keep the last 5
        
        let summaryMessage = ChatMessage(role: .system, content: "[Summary of previous conversation omitted for brevity]")
        
        return [systemPrompt, summaryMessage] + recentMessages
    }
}
