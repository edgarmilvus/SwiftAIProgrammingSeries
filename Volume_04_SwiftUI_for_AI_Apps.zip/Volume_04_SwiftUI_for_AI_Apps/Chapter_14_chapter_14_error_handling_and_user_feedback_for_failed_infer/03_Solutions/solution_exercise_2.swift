
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import SwiftUI

// SummarizationError.swift
enum SummarizationError: LocalizedError, Identifiable {
    case networkError(Error)
    case apiError(statusCode: Int, message: String?)
    case rateLimitExceeded(retryAfterSeconds: Int?)
    case unknown(Error?)

    var id: String {
        switch self {
        case .networkError(let error): return "network-\(error.localizedDescription.hashValue)"
        case .apiError(let statusCode, _): return "api-\(statusCode)"
        case .rateLimitExceeded: return "rateLimit"
        case .unknown(let error): return "unknown-\(error?.localizedDescription.hashValue ?? "no-error")"
        }
    }

    var errorDescription: String? {
        switch self {
        case .networkError(let error):
            // Provide specific message for common network issues
            if let urlError = error as? URLError {
                switch urlError.code {
                case .notConnectedToInternet:
                    return "No internet connection. Please check your network settings."
                case .timedOut:
                    return "The network request timed out. Please try again."
                default:
                    return "Network connection failed: \(error.localizedDescription)"
                }
            }
            return "Network connection failed. Please check your internet connection. (\(error.localizedDescription))"
        case .apiError(let statusCode, let message):
            return "API error (\(statusCode)): \(message ?? "An unexpected server error occurred.")"
        case .rateLimitExceeded(let seconds):
            if let s = seconds {
                return "You've sent too many requests. Please try again in \(s) seconds."
            } else {
                return "You've sent too many requests. Please try again later."
            }
        case .unknown(let error):
            return "An unknown error occurred: \(error?.localizedDescription ?? "No details available.")."
        }
    }

    // Helper to determine if an error is retryable
    var isRetryable: Bool {
        switch self {
        case .networkError, .rateLimitExceeded:
            return true
        case .apiError(let statusCode, _):
            // Common transient HTTP errors
            return statusCode == 503 || statusCode == 504 || statusCode == 408 // Service Unavailable, Gateway Timeout, Request Timeout
        case .unknown:
            return false // Unknown errors are generally not considered retryable without more context
        }
    }
    
    // Helper to extract retryAfterSeconds
    var retryAfterSeconds: Int? {
        if case .rateLimitExceeded(let seconds) = self {
            return seconds
        }
        return nil
    }
}

// TextSummarizationService.swift
@available(iOS 18.0, *)
class TextSummarizationService {
    let maxRetries: Int = 3 // Max retries allowed by the service/policy

    func summarizeText(_ text: String, currentAttempt: Int) async throws -> String {
        // Simulate network delay
        try await Task.sleep(for: .seconds(2))

        // Simulate various error conditions
        let randomFailure = Int.random(in: 0...100)

        // Simulate transient errors (network, rate limit) that are retryable
        if randomFailure < 20 && currentAttempt < maxRetries { // 20% chance of transient network error
            throw SummarizationError.networkError(URLError(.notConnectedToInternet))
        } else if randomFailure < 30 && currentAttempt < maxRetries { // 10% chance of rate limit
            throw SummarizationError.rateLimitExceeded(retryAfterSeconds: 5)
        } else if randomFailure < 35 { // 5% chance of non-retryable API error (Bad Request)
            throw SummarizationError.apiError(statusCode: 400, message: "Invalid input text provided.")
        } else if randomFailure < 40 { // 5% chance of another non-retryable API error (Internal Server Error)
            throw SummarizationError.apiError(statusCode: 500, message: "Internal server error.")
        } else {
            // Success
            return "Summary of: \"\(text.prefix(50))...\" - This is a concise summary generated by the AI."
        }
    }
}

// SummarizationView.swift
@available(iOS 18.0, *)
struct SummarizationView: View {
    @State private var inputText: String = ""
    @State private var summarizationState: SummarizationState = .idle
    @State private var currentRetryAttempt: Int = 0
    @State private var currentSummarizationTask: Task<Void, Never>?

    private let service = TextSummarizationService()

    enum SummarizationState {
        case idle
        case loading
        case success(String)
        case error(SummarizationError)
    }

    var body: some View {
        VStack(spacing: 20) {
            TextEditor(text: $inputText)
                .frame(height: 150)
                .border(Color.gray, width: 1)
                .padding(.horizontal)
                .overlay(
                    Group {
                        if inputText.isEmpty {
                            Text("Enter text to summarize...")
                                .foregroundColor(.gray)
                                .padding(.leading, 5)
                                .allowsHitTesting(false)
                        }
                    }, alignment: .topLeading
                )

            Button("Summarize") {
                summarize()
            }
            .buttonStyle(.borderedProminent)
            .disabled(inputText.isEmpty || summarizationState == .loading)

            switch summarizationState {
            case .idle:
                Spacer()
            case .loading:
                ProgressView("Summarizing...")
                if currentRetryAttempt > 0 {
                    Text("Attempt \(currentRetryAttempt + 1) of \(service.maxRetries + 1)...") // +1 for initial attempt
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            case .success(let summary):
                ScrollView {
                    Text(summary)
                        .padding()
                        .background(Color.green.opacity(0.1))
                        .cornerRadius(8)
                }
            case .error(let error):
                VStack {
                    Text("Error: \(error.localizedDescription)")
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                        .padding()

                    // Only show retry if the error is retryable and we haven't exhausted retries
                    if error.isRetryable && currentRetryAttempt < service.maxRetries {
                        Button("Retry (\(currentRetryAttempt + 1)/\(service.maxRetries))") {
                            summarize(isRetry: true)
                        }
                        .buttonStyle(.bordered)
                        .tint(.orange)
                    } else if currentRetryAttempt >= service.maxRetries {
                        Text("Maximum retries reached. Please try again later.")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }

                    Button("Clear") {
                        resetState()
                    }
                    .buttonStyle(.bordered)
                }
                .padding()
                .background(Color.red.opacity(0.1))
                .cornerRadius(8)
            }
            Spacer()
        }
        .padding()
        .navigationTitle("AI Summarizer")
        .onDisappear {
            currentSummarizationTask?.cancel() // Cancel task if view disappears
        }
    }

    @MainActor
    private func summarize(isRetry: Bool = false) {
        currentSummarizationTask?.cancel() // Cancel any ongoing task before starting a new one

        if !isRetry {
            currentRetryAttempt = 0
        } else {
            currentRetryAttempt += 1
        }

        summarizationState = .loading

        currentSummarizationTask = Task {
            do {
                // Introduce a delay before retrying for rate limits or general backoff
                if isRetry {
                    let delaySeconds = (summarizationState as? SummarizationState == .error(.rateLimitExceeded(let s)))?.retryAfterSeconds ?? (1 + Double(currentRetryAttempt) * 0.5)
                    try await Task.sleep(for: .seconds(delaySeconds))
                }
                
                let summary = try await service.summarizeText(inputText, currentAttempt: currentRetryAttempt)
                summarizationState = .success(summary)
                currentRetryAttempt = 0 // Reset on success
            } catch let summarizationError as SummarizationError {
                // Only increment attempt if it's a retryable error that failed
                summarizationState = .error(summarizationError)
            } catch {
                summarizationState = .error(.unknown(error))
            }
            // If the task was cancelled, we don't want to update the state from the catch block
            if Task.isCancelled {
                resetState() // Or set to a 'cancelled' state
            }
        }
    }
    
    @MainActor
    private func resetState() {
        currentSummarizationTask?.cancel()
        inputText = ""
        summarizationState = .idle
        currentRetryAttempt = 0
    }
}

// App Entry Point (for preview/testing)
@available(iOS 18.0, *)
struct SummarizationView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView { // Wrap in NavigationView for better presentation
            SummarizationView()
        }
    }
}
