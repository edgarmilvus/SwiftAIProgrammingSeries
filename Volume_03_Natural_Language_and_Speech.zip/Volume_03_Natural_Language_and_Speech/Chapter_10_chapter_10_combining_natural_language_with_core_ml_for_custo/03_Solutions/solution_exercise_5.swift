
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

// MARK: - Create ML Model Generation (Run this in an Xcode Playground)
import CreateML
import Foundation

// 1. Prepare your dataset (simulated JSON data)
// In a real scenario, this would be a larger, more diverse dataset.
let emailData: [[String: String]] = [
    // Work
    ["text": "Meeting at 10 AM to discuss Q3 report. Please review the attached agenda.", "category": "Work"],
    ["text": "Project update: Phase 2 completed. Next steps outlined in confluence.", "category": "Work"],
    ["text": "Your expense report for last month has been approved.", "category": "Work"],
    ["text": "Reminder: Team stand-up call in 15 minutes.", "category": "Work"],
    ["text": "Please provide your feedback on the new design mockups by Friday.", "category": "Work"],
    // Personal
    ["text": "Hey, how are you? Let's catch up this weekend.", "category": "Personal"],
    ["text": "Don't forget mom's birthday next week!", "category": "Personal"],
    ["text": "Just got back from vacation, photos attached.", "category": "Personal"],
    ["text": "Are you free for dinner on Thursday?", "category": "Personal"],
    ["text": "Received your package, thanks a lot!", "category": "Personal"],
    // Promotions
    ["text": "Flash Sale! Get 50% off all items for a limited time.", "category": "Promotions"],
    ["text": "New arrivals just dropped! Shop now and save.", "category": "Promotions"],
    ["text": "Your weekly newsletter from FashionCo. Exclusive deals inside.", "category": "Promotions"],
    ["text": "Limited offer: Free shipping on orders over $50.", "category": "Promotions"],
    ["text": "Unlock your discount code today!", "category": "Promotions"],
    // Social
    ["text": "John Doe liked your photo on Instagram.", "category": "Social"],
    ["text": "You have 3 new friend requests on Facebook.", "category": "Social"],
    ["text": "Someone mentioned you in a tweet.", "category": "Social"],
    ["text": "New activity in your LinkedIn network.", "category": "Social"],
    ["text": "Your YouTube subscription has a new video.", "category": "Social"],
    // Spam
    ["text": "URGENT: Your account has been compromised. Click here to verify.", "category": "Spam"],
    ["text": "Win a free iPhone! Enter your credit card details now.", "category": "Spam"],
    ["text": "Congratulations, you've won a lottery you didn't enter!", "category": "Spam"],
    ["text": "Enlarge your assets naturally with this one simple trick.", "category": "Spam"],
    ["text": "Claim your inheritance from a distant relative in Nigeria.", "category": "Spam"]
]

// Convert to MLDataTable
let dataTable = try! MLDataTable(array: emailData)

// Split into training and testing data
let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 123)

// 2. Train the text classifier
let classifier = try! MLTextClassifier(trainingData: trainingData,
                                       textColumn: "text",
                                       labelColumn: "category")

// 3. Evaluate the model (optional)
let evaluationMetrics = classifier.evaluation(on: testingData, textColumn: "text", labelColumn: "category")
print("Validation Accuracy: \(evaluationMetrics.accuracy)")

// 4. Save the model
let modelURL = URL(fileURLWithPath: "/tmp/EmailCategorizer.mlmodel") // Change path as needed
try! classifier.write(to: modelURL)
print("Model saved to: \(modelURL.path)")

// Drag the generated EmailCategorizer.mlmodel from /tmp/ to your Xcode project.
