
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

import MLX

// MLXArray is implicitly Sendable due to its internal design
// Its underlying data is in Unified Memory and operations are managed safely.
func processMLXArrayConcurrently(array: MLXArray) async -> MLXArray {
    // This function can be called from any Task or Actor
    // without worrying about data races on 'array'.
    let result = array * 2 + 1
    return result.eval() // Ensure computation is done
}

@available(iOS 18.0, macOS 15.0, *)
func demonstrateSendable() async {
    let initialArray = MLXArray.random(shape: [10, 10])

    // Pass MLXArray to a new Task
    let task1 = Task {
        let processed = await processMLXArrayConcurrently(array: initialArray)
        print("Task 1 processed array shape: \(processed.shape)")
    }

    // Pass MLXArray to another Task
    let task2 = Task {
        let processed = await processMLXArrayConcurrently(array: initialArray)
        print("Task 2 processed array shape: \(processed.shape)")
    }

    _ = await [task1.value, task2.value]
}
