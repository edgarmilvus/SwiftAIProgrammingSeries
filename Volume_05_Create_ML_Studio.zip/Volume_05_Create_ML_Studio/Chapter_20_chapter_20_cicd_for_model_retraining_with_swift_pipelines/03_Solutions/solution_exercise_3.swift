
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// BirdCallModelDeployer.swift

import Foundation
import CreateML
import CoreML // For MLModel, if needed for direct inspection (not strictly used here, but good to include)

@available(macOS 15.0, *)
@main
struct BirdCallModelDeployer {
    static let minOverallAccuracy: Double = 0.90 // 90% overall accuracy
    static let minPerClassF1Score: Double = 0.70 // 70% F1-score for any individual species

    static func main() async {
        // MARK: - Configuration
        // Assuming data is relative to the script's execution path.
        // Create these directories and populate them with audio files (e.g., .wav)
        // in subfolders named by bird species.
        // Example: Data/BirdCalls/Training/Robin/robin_1.wav
        let scriptDirectory = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
        let dataPath = scriptDirectory.appendingPathComponent("Data/BirdCalls")
        let trainingDataPath = dataPath.appendingPathComponent("Training")
        let validationDataPath = dataPath.appendingPathComponent("Validation")
        let testDataPath = dataPath.appendingPathComponent("Test") // Dedicated test set for final validation
        let outputDirectory = scriptDirectory.appendingPathComponent("Output")

        let fileManager = FileManager.default

        // MARK: - Setup Directories
        do {
            if !fileManager.fileExists(atPath: outputDirectory.path) {
                print("Creating output directory: \(outputDirectory.path)")
                try fileManager.createDirectory(at: outputDirectory, withIntermediateDirectories: true, attributes: nil)
            }
        } catch {
            print("Error setting up directories: \(error.localizedDescription)")
            return
        }

        do {
            // MARK: - Load Data
            print("Loading training data from: \(trainingDataPath.path)")
            let trainingData = try MLSoundClassifier.DataSource.labeledDirectories(at: trainingDataPath)
            print("Successfully loaded training data.")

            print("Loading validation data from: \(validationDataPath.path)")
            let validationData = try MLSoundClassifier.DataSource.labeledDirectories(at: validationDataPath)
            print("Successfully loaded validation data.")
            
            print("Loading test data from: \(testDataPath.path)")
            let testData = try MLSoundClassifier.DataSource.labeledDirectories(at: testDataPath)
            print("Successfully loaded test data.")


            // MARK: - Train Model
            print("Starting MLSoundClassifier training...")
            let classifier = try await MLSoundClassifier(trainingData: trainingData, validationData: validationData)
            print("Model training complete.")

            // MARK: - Advanced Model Validation
            print("\n--- Advanced Model Validation ---")
            let testMetrics = classifier.evaluation(on: testData)
            
            var validationReport: [String: Any] = [
                "overallAccuracy": testMetrics.accuracy,
                "passedOverallAccuracy": testMetrics.accuracy >= minOverallAccuracy,
                "perClassMetrics": [String: Any]() // Will be populated below
            ]

            var allPerClassF1ScoresMeetThreshold = true
            for (label, metrics) in testMetrics.perClassMetrics {
                let f1Score = metrics.f1Score
                let passedF1 = f1Score >= minPerClassF1Score
                
                // Safely update nested dictionary
                var classMetrics: [String: Any] = [
                    "precision": metrics.precision,
                    "recall": metrics.recall,
                    "f1Score": f1Score,
                    "passedF1Threshold": passedF1
                ]
                // Ensure perClassMetrics exists before inserting
                if var existingPerClassMetrics = validationReport["perClassMetrics"] as? [String: Any] {
                    existingPerClassMetrics[label] = classMetrics
                    validationReport["perClassMetrics"] = existingPerClassMetrics
                } else {
                    validationReport["perClassMetrics"] = [label: classMetrics]
                }
                
                if !passedF1 {
                    allPerClassF1ScoresMeetThreshold = false
                }
            }

            let modelPassedValidation = (testMetrics.accuracy >= minOverallAccuracy) && allPerClassF1ScoresMeetThreshold

            // Generate and save validation report
            let jsonReportData = try JSONSerialization.data(withJSONObject: validationReport, options: .prettyPrinted)
            let validationReportURL = outputDirectory.appendingPathComponent("validation_report.json")
            try jsonReportData.write(to: validationReportURL)
            print("Validation Report saved to: \(validationReportURL.path)")
            print(String(data: jsonReportData, encoding: .utf8)!)

            if modelPassedValidation {
                print("\nModel passed all validation checks. Proceeding to package.")

                // MARK: - Package as Swift Package
                let currentVersion = try getCurrentPackageVersion(in: outputDirectory)
                let nextVersion = incrementVersion(currentVersion)
                let modelFileName = "BirdCallClassifier.mlmodel"
                let packageName = "BirdCallModels"
                let packageDirectory = outputDirectory.appendingPathComponent(packageName)

                // 1. Create Swift Package Directory Structure
                let sourcesDirectory = packageDirectory.appendingPathComponent("Sources/\(packageName)")
                let resourcesDirectory = sourcesDirectory.appendingPathComponent("Resources") // For models
                try fileManager.createDirectory(at: resourcesDirectory, withIntermediateDirectories: true, attributes: nil)

                // 2. Save MLModel inside the package's resources
                let modelOutputURL = resourcesDirectory.appendingPathComponent(modelFileName)
                try classifier.write(to: modelOutputURL)
                print("Model saved to Swift Package resources: \(modelOutputURL.path)")

                // 3. Generate Package.swift file programmatically
                let packageSwiftContent = """
                // swift-tools-version:6.0
                import PackageDescription

                let package = Package(
                    name: "\(packageName)",
                    platforms: [.iOS(.v18), .macOS(.v15), .tvOS(.v18), .watchOS(.v11)], // Adjust as needed
                    products: [
                        .library(
                            name: "\(packageName)",
                            targets: ["\(packageName)"]),
                    ],
                    targets: [
                        .target(
                            name: "\(packageName)",
                            resources: [.process("Resources")] // This bundles the model
                        ),
                    ]
                )
                """
                let packageSwiftURL = packageDirectory.appendingPathComponent("Package.swift")
                try packageSwiftContent.write(to: packageSwiftURL, atomically: true, encoding: .utf8)
                print("Generated Package.swift at: \(packageSwiftURL.path)")

                // MARK: - Prepare for Deployment (Create .zip archive)
                let zipFileName = "\(packageName)_v\(nextVersion).zip"
                let zipOutputURL = outputDirectory.appendingPathComponent(zipFileName)

                // Use Foundation.Process to run 'zip' command
                let process = Process()
                process.executableURL = URL(fileURLWithPath: "/usr/bin/zip") // Path to the zip utility
                process.arguments = ["-r", zipOutputURL.path, packageName] // -r for recursive, packageName is the directory to zip
                process.currentDirectoryURL = outputDirectory // Execute zip from output directory to correctly include packageName
                
                print("Creating zip archive: \(zipOutputURL.path)")
                try process.run()
                process.waitUntilExit()

                if process.terminationStatus == 0 {
                    print("Swift Package zipped successfully to: \(zipOutputURL.path)")
                    
                    // MARK: - Output Manifest
                    let finalManifest: [String: Any] = [
                        "modelVersion": nextVersion,
                        "packageName": packageName,
                        "zipArchivePath": zipOutputURL.path,
                        "validationStatus": "PASSED",
                        "validationReport": validationReport // Include the full report
                    ]
                    let finalManifestData = try JSONSerialization.data(withJSONObject: finalManifest, options: .prettyPrinted)
                    print("\n--- Deployment Manifest ---")
                    print(String(data: finalManifestData, encoding: .utf8)!)
                    print("---------------------------\n")

                } else {
                    print("Error zipping Swift Package. Exit code: \(process.terminationStatus)")
                    // If zipping fails, consider this a pipeline failure
                    let finalManifest: [String: Any] = [
                        "modelVersion": nextVersion,
                        "packageName": packageName,
                        "zipArchivePath": "N/A",
                        "validationStatus": "FAILED_ZIP",
                        "validationReport": validationReport
                    ]
                    let finalManifestData = try JSONSerialization.data(withJSONObject: finalManifest, options: .prettyPrinted)
                    print("\n--- Deployment Manifest (Failed Zip) ---")
                    print(String(data: finalManifestData, encoding: .utf8)!)
                    print("----------------------------------------\n")
                }

            } else {
                print("Model failed validation. Deployment aborted.")
                let finalManifest: [String: Any] = [
                    "validationStatus": "FAILED",
                    "validationReport": validationReport
                ]
                let finalManifestData = try JSONSerialization.data(withJSONObject: finalManifest, options: .prettyPrinted)
                print("\n--- Deployment Manifest (Failed Validation) ---")
                print(String(data: finalManifestData, encoding: .utf8)!)
                print("-----------------------------------------------\n")
            }

        } catch {
            print("An error occurred during pipeline execution: \(error.localizedDescription)")
            // Output a generic failure manifest if a critical error occurs
            let finalManifest: [String: Any] = [
                "validationStatus": "CRITICAL_ERROR",
                "errorMessage": error.localizedDescription
            ]
            if let finalManifestData = try? JSONSerialization.data(withJSONObject: finalManifest, options: .prettyPrinted) {
                 print("\n--- Deployment Manifest (Critical Error) ---")
                 print(String(data: finalManifestData, encoding: .utf8)!)
                 print("------------------------------------------\n")
            }
        }
    }
    
    // MARK: - Helper Functions for Versioning (Simplified)
    /// Scans the output directory for existing zipped packages and determines the latest semantic version.
    static func getCurrentPackageVersion(in directory: URL) throws -> String {
        let fileManager = FileManager.default
        let contents = try fileManager.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)
        
        var latestVersion = Version(major: 1, minor: 0, patch: 0) // Default starting version
        
        for url in contents {
            if url.pathExtension == "zip" && url.lastPathComponent.hasPrefix("BirdCallModels_v") {
                let fileName = url.lastPathComponent
                let versionPart = fileName.replacingOccurrences(of: "BirdCallModels_v", with: "").replacingOccurrences(of: ".zip", with: "")
                if let version = Version(versionPart) {
                    if version > latestVersion {
                        latestVersion = version
                    }
                }
            }
        }
        return latestVersion.description
    }

    /// Increments the patch version of a semantic version string.
    static func incrementVersion(_ version: String) -> String {
        if var currentVersion = Version(version) {
            currentVersion.patch += 1
            return currentVersion.description
        }
        return "1.0.1" // Fallback
    }
}

// MARK: - Simple Semantic Versioning Struct
/// A basic struct to represent and compare semantic versions (Major.Minor.Patch).
struct Version: CustomStringConvertible, Comparable {
    var major: Int
    var minor: Int
    var patch: Int

    init(major: Int, minor: Int, patch: Int) {
        self.major = major
        self.minor = minor
        self.patch = patch
    }

    init?(_ versionString: String) {
        let components = versionString.split(separator: ".").compactMap { Int($0) }
        guard components.count == 3 else { return nil }
        self.major = components[0]
        self.minor = components[1]
        self.patch = components[2]
    }

    var description: String {
        return "\(major).\(minor).\(patch)"
    }

    static func < (lhs: Version, rhs: Version) -> Bool {
        if lhs.major != rhs.major { return lhs.major < rhs.major }
        if lhs.minor != rhs.minor { return lhs.minor < rhs.minor }
        return lhs.patch < rhs.patch
    }
}
