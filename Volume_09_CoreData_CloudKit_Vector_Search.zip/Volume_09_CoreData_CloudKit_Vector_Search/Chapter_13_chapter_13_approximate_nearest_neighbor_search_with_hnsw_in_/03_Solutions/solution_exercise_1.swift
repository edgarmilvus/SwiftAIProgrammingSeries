
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import Accelerate

/// A protocol defining a metric for calculating distance between two high-dimensional vectors.
protocol DistanceMetric: Sendable {
    func distance(_ a: [Float], _ b: [Float]) -> Float
}

/// Error handling for dimension mismatches.
enum DistanceError: Error {
    case dimensionMismatch
}

/// Optimized Euclidean Distance (L2 Norm) using Accelerate.
struct EuclideanDistance: DistanceMetric {
    func distance(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return .infinity }
        var distanceSquared: Float = 0
        // Use vDSP to calculate the sum of squared differences: sum((a[i] - b[i])^2)
        vDSP_distancesq(a, 1, b, 1, &distanceSquared, vDSP_Length(a.count))
        return sqrt(distanceSquared)
    }
}

/// Optimized Cosine Distance (1 - Cosine Similarity) using Accelerate.
struct CosineDistance: DistanceMetric {
    func distance(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return .infinity }
        
        var dotProduct: Float = 0
        // Calculate dot product: sum(a[i] * b[i])
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        
        var normA: Float = 0
        var normB: Float = 0
        // Calculate magnitudes: sqrt(sum(a[i]^2))
        vDSP_svesq(a, 1, &normA, vDSP_Length(a.count))
        vDSP_svesq(b, 1, &normB, vDSP_Length(b.count))
        
        let similarity = dotProduct / (sqrt(normA) * sqrt(normB))
        // Return distance (1 - similarity) so that smaller values mean "closer"
        return 1.0 - similarity
    }
}

/// Optimized Manhattan Distance (L1 Norm) using Accelerate.
struct ManhattanDistance: DistanceMetric {
    func distance(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return .infinity }
        
        // Step 1: Calculate absolute differences: |a[i] - b[i]|
        var differences = [Float](repeating: 0, count: a.count)
        vDSP_vsub(a, 1, b, 1, &differences, 1, vDSP_Length(a.count))
        
        var sumAbs: Float = 0
        // Step 2: Sum the absolute values
        vDSP_sveabs(differences, 1, &sumAbs, vDSP_Length(a.count))
        
        return sumAbs
    }
}

// MARK: - Usage Example
@available(iOS 18.0, *)
func demonstrateMetrics() {
    let vecA: [Float] = [1.0, 2.0, 3.0]
    let vecB: [Float] = [4.0, 5.0, 6.0]
    
    let metrics: [DistanceMetric] = [EuclideanDistance(), CosineDistance(), ManhattanDistance()]
    
    for metric in metrics {
        print("\(type(of: metric)) result: \(metric.distance(vecA, vecB))")
    }
}
