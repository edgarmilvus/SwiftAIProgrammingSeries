
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

// LLMModelConfiguration.swift
/// Represents a configuration for a specific Large Language Model.
/// Each model has a unique identifier and a display name for UI purposes.
enum LLMModelConfiguration: String, CaseIterable, Identifiable, Codable {
    case llama3_8b_instruct = "llama3-8b-instruct"
    case phi3_mini_4k_instruct = "phi3-mini-4k-instruct"
    case mistral_7b_instruct = "mistral-7b-instruct"

    var id: String { self.rawValue }

    /// The user-friendly name of the model.
    var displayName: String {
        switch self {
        case .llama3_8b_instruct: return "Llama 3 8B Instruct"
        case .phi3_mini_4k_instruct: return "Phi-3 Mini 4K Instruct"
        case .mistral_7b_instruct: return "Mistral 7B Instruct"
        }
    }

    /// The expected file path or identifier for loading the model.
    /// In a real app, this might be a URL, a path in the app bundle, or a reference to a downloaded file.
    var modelPath: String {
        switch self {
        case .llama3_8b_instruct: return "models/llama-3-8b-instruct.gguf"
        case .phi3_mini_4k_instruct: return "models/phi-3-mini-4k-instruct.gguf"
        case .mistral_7b_instruct: return "models/mistral-7b-instruct-v0.2.gguf"
        }
    }

    /// Provides a brief description of the model, useful for user selection.
    var description: String {
        switch self {
        case .llama3_8b_instruct: return "A powerful 8 billion parameter model, good for complex tasks."
        case .phi3_mini_4k_instruct: return "A small, fast 3.8 billion parameter model, ideal for quick responses."
        case .mistral_7b_instruct: return "A balanced 7 billion parameter model, known for good performance."
        }
    }
}
