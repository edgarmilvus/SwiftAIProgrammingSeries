
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Foundation

// Assume MyModel is a Core ML model generated from a .mlmodel file
// and has an input that expects an MLMultiArray.

@available(iOS 15.0, *)
actor MLModelPredictor {
    private let model: MyModel

    init() throws {
        self.model = try MyModel(configuration: MLModelConfiguration())
    }

    // An asynchronous method to perform inference
    func performPrediction(inputMultiArray: MLMultiArray) async throws -> MLMultiArray {
        // Wrap the MLMultiArray in an MLFeatureProvider
        let inputFeatures = MyModelInput(myMultiArrayInput: inputMultiArray) // Assuming MyModelInput has a multi-array property

        // Perform prediction on a background queue managed by the Swift Concurrency runtime
        let prediction = try await model.prediction(input: inputFeatures)

        // Assuming the model output is also an MLMultiArray
        guard let outputMultiArray = prediction.featureValue(for: "myMultiArrayOutput")?.multiArrayValue else {
            throw PredictionError.invalidOutput
        }
        return outputMultiArray
    }
}

enum PredictionError: Error {
    case invalidOutput
    case modelLoadingFailed
}

@available(iOS 15.0, *)
func exampleUsage() async {
    do {
        let predictor = try MLModelPredictor()

        // Create a dummy MLMultiArray for input
        let inputShape = [1, 100] // Example: batch size 1, 100 features
        let inputMultiArray = try MLMultiArray(shape: inputShape as [NSNumber], dataType: .float32)
        for i in 0..<inputMultiArray.count {
            inputMultiArray[i] = NSNumber(value: Float.random(in: 0...1))
        }

        print("Starting prediction...")
        let output = try await predictor.performPrediction(inputMultiArray: inputMultiArray)
        print("Prediction complete. Output shape: \(output.shape)")

        // Further processing of the output multi-array
    } catch {
        print("Prediction failed: \(error)")
    }
}

// Call exampleUsage from an async context, e.g., in a Task
@available(iOS 15.0, *)
func runExample() {
    Task {
        await exampleUsage()
    }
}
// runExample() // Call this from your app's entry point
