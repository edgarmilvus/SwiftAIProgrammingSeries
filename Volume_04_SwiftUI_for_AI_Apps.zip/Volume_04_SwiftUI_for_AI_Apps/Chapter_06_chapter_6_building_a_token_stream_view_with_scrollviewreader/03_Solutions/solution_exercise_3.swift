
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import Observation
import SwiftUI

// MARK: - Data Model

@available(iOS 18.0, *)
struct SummaryPoint: Identifiable, Hashable {
    let id = UUID()
    let mainText: String
    let detailText: String?
    var isExpanded: Bool = false
}

// MARK: - ViewModel

@available(iOS 18.0, *)
@Observable
class SummaryViewModel {
    var summaryPoints: [SummaryPoint] = []
    private var streamingTask: Task<Void, Never>?

    var isAnyPointExpanded: Bool {
        summaryPoints.contains(where: { $0.isExpanded })
    }

    func startStreamingSummary() {
        reset() // Clear previous points
        streamingTask = Task {
            let rawSummaries = [
                ("AI Models are becoming increasingly powerful.", "Large Language Models (LLMs) like GPT-4 and Llama 3 are capable of understanding and generating human-like text, revolutionizing various industries."),
                ("Real-time token streaming enhances user experience.", "By delivering AI outputs incrementally, applications feel more responsive and engaging, reducing perceived latency."),
                ("SwiftUI provides robust tools for reactive UIs.", "Features like @State, @Observable, and ScrollViewReader are essential for building dynamic interfaces that respond to asynchronous data streams."),
                ("Optimizing performance is key for long streams.", "For very large outputs, strategies like virtualization or limiting the number of displayed items can prevent UI lag and maintain responsiveness.")
            ]

            for (main, detail) in rawSummaries {
                await Task.sleep(nanoseconds: UInt64(1 * 1_000_000_000)) // Simulate delay
                await MainActor.run {
                    self.summaryPoints.append(SummaryPoint(mainText: main, detailText: detail))
                }
            }
        }
    }

    func toggleExpansion(for point: SummaryPoint) {
        if let index = summaryPoints.firstIndex(where: { $0.id == point.id }) {
            summaryPoints[index].isExpanded.toggle()
        }
    }

    func reset() {
        streamingTask?.cancel()
        summaryPoints = []
    }
}

// MARK: - PreferenceKeys for Scroll Position Detection (reused from Exercise 2)

struct SummaryContentHeightPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

struct SummaryScrollViewHeightPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

// MARK: - View

@available(iOS 18.0, *)
struct InteractiveSummaryView: View {
    @State private var viewModel = SummaryViewModel()

    @State private var isAutoScrollingEnabled: Bool = true
    @State private var showScrollToBottomButton: Bool = false

    @State private var scrollViewContentHeight: CGFloat = 0
    @State private var scrollViewHeight: CGFloat = 0
    @State private var currentScrollOffset: CGFloat = 0

    private let atBottomThreshold: CGFloat = 10

    private var isAtBottom: Bool {
        if scrollViewContentHeight <= scrollViewHeight { return true }
        let maxScrollOffset = scrollViewContentHeight - scrollViewHeight
        return currentScrollOffset >= maxScrollOffset - atBottomThreshold
    }

    private var lastSummaryPointId: UUID? {
        viewModel.summaryPoints.last?.id
    }

    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                ScrollView(.vertical, showsIndicators: true) {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(viewModel.summaryPoints) { point in
                            SummaryPointRow(point: point) { tappedPoint in
                                viewModel.toggleExpansion(for: tappedPoint)
                                // If a point is expanded, disable auto-scroll
                                // This is handled by the onChange(of: isAnyPointExpanded)
                            }
                            .id(point.id) // Crucial for ScrollViewReader
                        }
                        Color.clear
                            .frame(height: 1)
                            .id("bottom_anchor")
                            .background(GeometryReader { geo in
                                Color.clear.preference(key: SummaryContentHeightPreferenceKey.self, value: geo.frame(in: .named("scroll")).maxY)
                            })
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                }
                .coordinateSpace(name: "scroll")
                .onPreferenceChange(SummaryContentHeightPreferenceKey.self) {
                    scrollViewContentHeight = $0
                }
                .background(GeometryReader { geo in
                    Color.clear.preference(key: SummaryScrollViewHeightPreferenceKey.self, value: geo.size.height)
                })
                .onPreferenceChange(SummaryScrollViewHeightPreferenceKey.self) {
                    scrollViewHeight = $0
                }
                .onChange(of: viewModel.summaryPoints.count) {
                    // Auto-scroll only if enabled, no points are expanded, and we are at the bottom
                    if isAutoScrollingEnabled && !viewModel.isAnyPointExpanded && isAtBottom {
                        withAnimation(.easeOut(duration: 0.3)) {
                            proxy.scrollTo(lastSummaryPointId ?? "bottom_anchor", anchor: .bottom)
                        }
                    } else if !isAtBottom || viewModel.isAnyPointExpanded {
                        showScrollToBottomButton = true
                    }
                }
                .onChange(of: viewModel.isAnyPointExpanded) {
                    // If any point is expanded, pause auto-scrolling
                    if viewModel.isAnyPointExpanded {
                        isAutoScrollingEnabled = false
                        showScrollToBottomButton = true // Show button if expanded
                    } else {
                        // If all points are collapsed, and we are at the bottom, re-enable auto-scroll
                        if isAtBottom {
                            isAutoScrollingEnabled = true
                            showScrollToBottomButton = false
                        }
                    }
                }
                .onScroll { phase in
                    currentScrollOffset = phase.contentOffset.y
                    
                    if phase.isDecelerating || phase.isDragging {
                        isAutoScrollingEnabled = false
                    }
                    
                    showScrollToBottomButton = !isAutoScrollingEnabled && !isAtBottom
                    
                    if isAtBottom && !viewModel.isAnyPointExpanded {
                        isAutoScrollingEnabled = true
                        showScrollToBottomButton = false
                    }
                }
                .overlay(alignment: .bottomTrailing) {
                    if showScrollToBottomButton {
                        Button {
                            withAnimation(.easeOut(duration: 0.5)) {
                                proxy.scrollTo(lastSummaryPointId ?? "bottom_anchor", anchor: .bottom)
                            }
                            isAutoScrollingEnabled = true
                            showScrollToBottomButton = false
                        } label: {
                            Label("Scroll to Bottom", systemImage: "arrow.down.circle.fill")
                                .font(.headline)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(20)
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 20)
                        .transition(.opacity.animation(.easeInOut))
                    }
                }
            }

            HStack {
                Button("Start Streaming Summary") {
                    viewModel.startStreamingSummary()
                }
                .buttonStyle(.borderedProminent)

                Button("Reset") {
                    viewModel.reset()
                    isAutoScrollingEnabled = true
                    showScrollToBottomButton = false
                }
                .buttonStyle(.bordered)
            }
            .padding()
        }
        .navigationTitle("AI Summary View")
        .onDisappear {
            viewModel.reset()
        }
    }
}

// MARK: - Helper View for Summary Point Row

@available(iOS 18.0, *)
struct SummaryPointRow: View {
    let point: SummaryPoint
    let action: (SummaryPoint) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(point.mainText)
                .font(.headline)
                .foregroundColor(.primary)
                .padding(.vertical, 2)

            if point.isExpanded {
                Text(point.detailText ?? "No details available.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding(.bottom, 5)
                    .transition(.opacity.animation(.easeIn(duration: 0.2)))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(point.isExpanded ? Color.blue.opacity(0.1) : Color.clear)
        .cornerRadius(8)
        .onTapGesture {
            withAnimation(.easeInOut(duration: 0.2)) {
                action(point)
            }
        }
    }
}

// MARK: - Preview (for Xcode Canvas)

@available(iOS 18.0, *)
#Preview {
    InteractiveSummaryView()
}
