
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

/// @available(macOS 14.0, *)
/// Custom error types for operations within the LLMService and CodeReviewAgent.
/// These errors provide specific context for failures, aiding in debugging and user feedback.
enum LLMServiceError: Error, LocalizedError, CustomStringConvertible {
    case modelNotFound(path: String)
    case modelLoadingFailed(reason: String)
    case inferenceFailed(reason: String)
    case invalidModelURL
    case modelDownloadFailed(url: URL, underlyingError: Error)
    case fileSystemError(reason: String, underlyingError: Error?)
    case serviceUnavailable(reason: String)
    case invalidPrompt(reason: String)

    var description: String {
        switch self {
        case .modelNotFound(let path):
            return "LLM Model not found at path: \(path)"
        case .modelLoadingFailed(let reason):
            return "Failed to load LLM model: \(reason)"
        case .inferenceFailed(let reason):
            return "LLM inference failed: \(reason)"
        case .invalidModelURL:
            return "Invalid URL provided for model download."
        case .modelDownloadFailed(let url, let error):
            return "Failed to download model from \(url): \(error.localizedDescription)"
        case .fileSystemError(let reason, let error):
            return "File system error: \(reason) \(error?.localizedDescription ?? "")"
        case .serviceUnavailable(let reason):
            return "LLM Service unavailable: \(reason)"
        case .invalidPrompt(let reason):
            return "Invalid prompt provided: \(reason)"
        }
    }

    var errorDescription: String? {
        return description // LocalizedError protocol conformance
    }
}
