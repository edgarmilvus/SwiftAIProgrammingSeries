
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import MetricKit

/// A centralized actor to manage telemetry data, ensuring thread safety 
/// when receiving asynchronous updates from the system.
@available(iOS 18.0, *)
actor TelemetryManager: NSObject, MXMetricManagerDelegate {
    
    static let shared = TelemetryManager()
    
    // Private initializer to enforce singleton pattern
    private override init() {
        super.init()
    }
    
    /// Starts the MetricKit monitoring process.
    func startMonitoring() {
        MXMetricManager.shared.beginMonitoring(with: self)
        print("Telemetry: Monitoring started.")
    }
    
    /// Implementation of MXMetricManagerDelegate.
    /// Note: This is called by the system on a background thread.
    nonisolated func didReceive(_ payload: MXMetricPayload) {
        // Since this is a non-isolated delegate method, we must 
        // hop into the actor's isolated context to process the data.
        Task {
            await self.processPayload(payload)
        }
    }
    
    /// Processes the payload within the actor's isolated context.
    private func processPayload(_ payload: MXMetricPayload) {
        print("--- New MetricKit Payload Received ---")
        
        // 1. Extract CPU Metrics
        if let cpuMetric = payload.cpuMetric {
            print("Total CPU Time: \(cpuMetric.cumulativeCPUUsage)s")
        }
        
        // 2. Extract Memory Metrics
        if let memoryMetric = payload.cumulativeMetrics.first?.memoryMetric {
            // Note: In a real app, we'd look for peak memory specifically
            print("Peak Memory Usage: \(memoryMetric.peakMemoryUsage) bytes")
        }
        
        // 3. Extract Battery Metrics
        if let batteryMetric = payload.batteryMetric {
            let discharge = batteryMetric.cumulativeDischargeCapacity
            let charge = batteryMetric.cumulativeChargingCapacity
            print("Battery Discharge: \(discharge) mAh | Battery Charge: \(charge) mAh")
        }
        
        print("---------------------------------------")
    }
}

// Usage in App Lifecycle (e.g., @main or AppDelegate)
@main
struct AIApp {
    init() {
        Task {
            await TelemetryManager.shared.startMonitoring()
        }
    }
}
