
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import NaturalLanguage
import Accelerate
import CoreData

// MARK: - Models

/// Represents a single note in the system.
/// In a real app, this would be a Core Data managed object.
struct Note: Identifiable, Sendable {
    let id: UUID
    let content: String
    let embedding: [Float] // The high-dimensional vector representation
    
    /// A convenience for debugging
    var description: String {
        "Note(id: \(id.uuidString.prefix(8)), content: \"\(content.prefix(20))...\")"
    }
}

/// A structure to hold search results along with their calculated hybrid score.
struct SearchResult: Sendable {
    let note: Note
    let score: Double
}

// MARK: - Embedding Service

/// A service responsible for converting text into high-dimensional vectors.
/// Uses Apple's NaturalLanguage framework.
final class EmbeddingService: Sendable {
    
    /// The embedding model used for semantic calculations.
    /// @available(iOS 18.0, *)
    private let embedding = NLEmbedding.sentenceEmbedding(for: .english)

    /// Generates a vector for a given string.
    /// - Parameter text: The input text to embed.
    /// - Returns: An array of Floats representing the vector, or nil if failed.
    func generateEmbedding(for text: String) -> [Float]? {
        guard let embedding = embedding else { return nil }
        // NLEmbedding returns [Double], but for ML/Accelerate, [Float] is standard.
        let vector = embedding.vector(for: text)
        return vector?.map { Float($0) }
    }
    
    /// Calculates the Cosine Similarity between two vectors.
    /// This is the "Under the Hood" math of semantic search.
    /// - Parameters:
    ///   - v1: First vector.
    ///   - v2: Second vector.
    /// - Returns: A similarity score between -1.0 and 1.0.
    func cosineSimilarity(_ v1: [Float], _ v2: [Float]) -> Float {
        guard v1.count == v2.count else { return 0 }
        
        // Using Accelerate framework for high-performance vector math.
        // Cosine Similarity = (A · B) / (||A|| * ||B||)
        
        var dotProduct: Float = 0
        vDSP_dotpr(v1, 1, v2, 1, &dotProduct, vDSP_Length(v1.count))
        
        var v1SumSq: Float = 0
        vDSP_svesq(v1, 1, &v1SumSq, vDSP_Length(v1.count))
        
        var v2SumSq: Float = 0
        vDSP_svesq(v2, 1, &v2SumSq, vDSP_Length(v1.count))
        
        let denominator = sqrt(v1SumSq) * sqrt(v2SumSq)
        return denominator == 0 ? 0 : dotProduct / denominator
    }
}

// MARK: - Hybrid Search Engine

/// The orchestrator that combines Full-Text and Semantic search results.
@available(iOS 18.0, *)
actor HybridSearchEngine {
    
    private let embeddingService = EmbeddingService()
    private let notes: [Note] // In reality, this would be a Core Data FetchRequest
    
    init(notes: [Note]) {
        self.notes = notes
    }
    
    /// Performs a hybrid search.
    /// - Parameter query: The user's search string.
    /// - Returns: A ranked list of SearchResults.
    func search(query: String) async -> [SearchResult] {
        print("🔍 Starting hybrid search for: '\(query)'")
        
        // 1. Run Full-Text Search (Keyword-based)
        // We use TaskGroup to run these in parallel for performance.
        async let ftsResults = performFullTextSearch(query: query)
        
        // 2. Run Semantic Search (Vector-based)
        async let semanticResults = performSemanticSearch(query: query)
        
        // Await both results
        let (fts, semantic) = await (ftsResults, semanticResults)
        
        // 3. Merge results using Reciprocal Rank Fusion (RRF)
        return merge(fts: fts, semantic: semantic)
    }
    
    /// Simulates a Full-Text Search using keyword matching.
    private func performFullTextSearch(query: String) async -> [UUID: Int] {
        // Returns a dictionary of [NoteID: Rank]
        // Rank is the position in the results (1-based)
        var ranks: [UUID: Int] = [:]
        let lowerQuery = query.lowercased()
        
        // Filtering notes where content contains the query string
        let matches = notes.filter { $0.content.lowercased().contains(lowerQuery) }
        
        for (index, note) in matches.enumerated() {
            ranks[note.id] = index + 1
        }
        
        return ranks
    }
    
    /// Performs Semantic Search by comparing query embedding to note embeddings.
    private func performSemanticSearch(query: String) async -> [UUID: Int] {
        guard let queryVector = embeddingService.generateEmbedding(for: query) else {
            return [:]
        }
        
        // Calculate similarity for all notes
        let scoredNotes = notes.map { note -> (UUID, Float) in
            let similarity = embeddingService.cosineSimilarity(queryVector, note.embedding)
            return (note.id, similarity)
        }
        
        // Sort by similarity descending
        let sorted = scoredNotes.sorted { $0.1 > $1.1 }
        
        // Convert to [NoteID: Rank]
        var ranks: [UUID: Int] = [:]
        for (index, element) in sorted.enumerated() {
            ranks[element.0] = index + 1
        }
        
        return ranks
    }
    
    /// Combines two ranked lists using Reciprocal Rank Fusion (RRF).
    /// RRF Formula: Score(d) = Σ (1 / (k + rank(d)))
    /// where k is a constant (usually 60) to mitigate the impact of low-ranked items.
    private func merge(fts: [UUID: Int], semantic: [UUID: Int]) -> [SearchResult] {
        let k: Double = 60.0
        var combinedScores: [UUID: Double] = [:]
        
        // Process FTS ranks
        for (id, rank) in fts {
            combinedScores[id, default: 0] += 1.0 / (k + Double(rank))
        }
        
        // Process Semantic ranks
        for (id, rank) in semantic {
            combinedScores[id, default: 0] += 1.0 / (k + Double(rank))
        }
        
        // Map back to Note objects and sort
        return combinedScores.compactMap { (id, score) in
            guard let note = notes.first(where: { $0.id == id }) else { return nil }
            return SearchResult(note: note, score: score)
        }.sorted { $0.score > $1.score }
    }
}

// MARK: - Execution Example

@main
struct HybridSearchApp {
    static func main() async {
        let embeddingService = EmbeddingService()
        
        // Mock Data: Creating notes with embeddings
        let noteContents = [
            "The feline sat on the mat.", // Semantic target for 'cat'
            "Buy milk and eggs at the grocery store.", // Unrelated
            "AX-772-B is the serial number for the engine.", // FTS target for 'AX-772-B'
            "A small kitten playing with yarn.", // Semantic target for 'feline'
            "The engine requires AX-772-B maintenance." // Both FTS and Semantic target
        ]
        
        let mockNotes: [Note] = noteContents.compactMap { content in
            guard let vector = embeddingService.generateEmbedding(for: content) else { return nil }
            return Note(id: UUID(), content: content, embedding: vector)
        }
        
        let engine = HybridSearchEngine(notes: mockNotes)
        
        // TEST 1: Semantic Query
        print("\n--- TEST 1: Semantic Query ('cat') ---")
        let semanticResults = await engine.search(query: "cat")
        for result in semanticResults {
            print("Score: \(String(format: "%.4f", result.score)) | Content: \(result.note.content)")
        }
        
        // TEST 2: Exact Match Query
        print("\n--- TEST 2: Exact Match Query ('AX-772-B') ---")
        let ftsResults = await engine.search(query: "AX-772-B")
        for result in ftsResults {
            print("Score: \(String(format: "%.4f", result.score)) | Content: \(result.note.content)")
        }
    }
}
