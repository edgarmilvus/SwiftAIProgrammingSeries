
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import Speech
    import AVFoundation

    @available(iOS 18.0, *)
    actor SpeechRecognitionService {
        private var speechRecognizer: SFSpeechRecognizer?
        private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
        private var recognitionTask: SFSpeechRecognitionTask?
        private var audioEngine: AVAudioEngine?

        // Internal state, safely isolated
        private var _currentTranscription: String = ""
        private var _isRecognizing: Bool = false

        var currentTranscription: String { _currentTranscription }
        var isRecognizing: Bool { _isRecognizing }

        init() {
            // Initialize with a locale, e.g., Locale(identifier: "en-US")
            self.speechRecognizer = SFSpeechRecognizer()
        }

        func startRecognition() async throws {
            guard speechRecognizer?.isAvailable ?? false else {
                throw SpeechError.recognizerUnavailable
            }
            guard SFSpeechRecognizer.authorizationStatus() == .authorized else {
                throw SpeechError.notAuthorized
            }

            _isRecognizing = true
            _currentTranscription = ""

            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = recognitionRequest else {
                throw SpeechError.recognitionRequestFailed
            }
            recognitionRequest.shouldReportPartialResults = true

            audioEngine = AVAudioEngine()
            let inputNode = audioEngine!.inputNode
            let recordingFormat = inputNode.outputFormat(forBus: 0)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
                recognitionRequest.append(buffer)
            }

            audioEngine?.prepare()
            try audioEngine?.start()

            // The recognition task itself is also managed within the actor's isolated state
            recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
                Task {
                    guard let self = self else { return }
                    if let result = result {
                        await self.updateTranscription(result.bestTranscription.formattedString)
                        if result.isFinal {
                            await self.stopRecognition()
                        }
                    } else if let error = error {
                        print("Recognition error: \(error.localizedDescription)")
                        await self.stopRecognition() // Stop on error
                    }
                }
            }
        }

        func stopRecognition() async {
            audioEngine?.stop()
            audioEngine?.inputNode.removeTap(onBus: 0)
            recognitionRequest?.endAudio()
            recognitionTask?.cancel()

            _isRecognizing = false
            recognitionRequest = nil
            recognitionTask = nil
            audioEngine = nil
        }

        private func updateTranscription(_ text: String) {
            _currentTranscription = text
            // In a real app, you might notify observers here or have a way to publish this state
        }

        enum SpeechError: Error {
            case recognizerUnavailable
            case notAuthorized
            case recognitionRequestFailed
        }
    }
    