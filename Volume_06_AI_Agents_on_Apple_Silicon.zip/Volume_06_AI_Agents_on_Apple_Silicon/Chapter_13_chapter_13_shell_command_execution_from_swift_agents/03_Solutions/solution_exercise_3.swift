
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

enum OllamaPullProgress {
    case started
    case status(String) // e.g., "pulling manifest"
    case progress(model: String, percentage: Double, details: String) // e.g., "downloading 10%", "verifying checksum"
    case completed(model: String)
    case cancelled
    case failed(error: Error)
}

enum OllamaPullError: Error, LocalizedError {
    case commandNotFound(path: String)
    case invalidModelName(name: String)
    case executionFailed(status: Int, stderr: String)
    case cancellationFailed
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .commandNotFound(let path):
            return "Ollama command not found at '\(path)'. Is Ollama installed and in your PATH?"
        case .invalidModelName(let name):
            return "Invalid model name provided: '\(name)'."
        case .executionFailed(let status, let stderr):
            return "Ollama pull failed with exit status \(status).\nError: \(stderr)"
        case .cancellationFailed:
            return "Failed to terminate Ollama pull process."
        case .unknown(let error):
            return "An unknown error occurred: \(error.localizedDescription)"
        }
    }
}

class OllamaPullAgent {
    private var process: Process?
    private var outputTask: Task<Void, Never>?
    private let ollamaExecutablePath: URL

    init(ollamaExecutablePath: URL? = nil) {
        // Attempt to find Ollama in common locations or rely on PATH
        let defaultOllamaPath = "/usr/local/bin/ollama"
        if let customPath = ollamaExecutablePath {
            self.ollamaExecutablePath = customPath
        } else if FileManager.default.fileExists(atPath: defaultOllamaPath) {
            self.ollamaExecutablePath = URL(fileURLWithPath: defaultOllamaPath)
        } else {
            self.ollamaExecutablePath = URL(fileURLWithPath: "ollama") // Process will search PATH
        }
    }

    /// Pulls an Ollama model with real-time progress updates.
    /// - Parameters:
    ///   - modelName: The name of the model to pull (e.g., "llama2", "mistral").
    /// - Returns: An AsyncStream of OllamaPullProgress updates.
    func pullModel(modelName: String) -> AsyncStream<OllamaPullProgress> {
        return AsyncStream { continuation in
            // Ensure any previous pull process is terminated
            self.cancelPull()

            let process = Process()
            let stdoutPipe = Pipe()
            let stderrPipe = Pipe()

            process.standardOutput = stdoutPipe
            process.standardError = stderrPipe
            process.executableURL = ollamaExecutablePath
            process.arguments = ["pull", modelName]
            
            self.process = process // Keep a reference for cancellation

            continuation.yield(.started)

            // Task to handle process execution and output processing
            self.outputTask = Task {
                do {
                    try process.run()
                } catch {
                    if let posixError = error as? POSIXError, posixError.code == .ENOENT {
                        continuation.yield(.failed(error: OllamaPullError.commandNotFound(path: ollamaExecutablePath.path)))
                    } else {
                        continuation.yield(.failed(error: OllamaPullError.unknown(error)))
                    }
                    continuation.finish()
                    self.process = nil
                    return
                }

                // Setup real-time output reading for stdout
                var currentLine = ""
                stdoutPipe.fileHandleForReading.readabilityHandler = { fileHandle in
                    if Task.isCancelled {
                        // If the Task was cancelled, stop reading and terminate process
                        self.cancelPull()
                        continuation.yield(.cancelled)
                        continuation.finish()
                        return
                    }

                    let data = fileHandle.availableData
                    guard !data.isEmpty else { return }

                    if let output = String(data: data, encoding: .utf8) {
                        currentLine += output
                        // Process line by line
                        let lines = currentLine.split(separator: "\n", omittingEmptySubsequences: false)
                        currentLine = String(lines.last ?? "") // Keep incomplete last line

                        for i in 0..<(lines.count - (currentLine.isEmpty ? 0 : 1)) {
                            let line = String(lines[i]).trimmingCharacters(in: .whitespacesAndNewlines)
                            // Parse progress updates
                            if line.contains("pulling manifest") || line.contains("verifying checksum") || line.contains("success") {
                                continuation.yield(.status(line))
                            } else if let progress = self.parseProgressLine(line: line, modelName: modelName) {
                                continuation.yield(progress)
                            } else if !line.isEmpty {
                                // Yield other non-progress lines as status updates
                                continuation.yield(.status(line))
                            }
                        }
                    }
                }

                // Wait for the process to exit
                process.waitUntilExit()

                // Clean up readability handler
                stdoutPipe.fileHandleForReading.readabilityHandler = nil

                // Read any remaining stderr data if termination was not clean
                let stderrData = stderrPipe.fileHandleForReading.readDataToEndOfFile()
                let stderr = String(data: stderrData, encoding: .utf8) ?? ""

                if process.terminationStatus == 0 {
                    continuation.yield(.completed(model: modelName))
                } else {
                    continuation.yield(.failed(error: OllamaPullError.executionFailed(status: Int(process.terminationStatus), stderr: stderr)))
                }
                continuation.finish()
                self.process = nil
            }
            
            // Handle cancellation of the AsyncStream itself
            continuation.onTermination = { @Sendable _ in
                self.cancelPull()
            }
        }
    }
    
    /// Parses a line from ollama pull output to extract progress information.
    private func parseProgressLine(line: String, modelName: String) -> OllamaPullProgress? {
        // Example lines:
        // "downloading 10%... (1/1)"
        // "downloading 10.1 GB / 10.1 GB @ 2.5 MB/s [==================================================]  100%"
        // "pulling manifest" (handled as status)

        if line.contains("downloading") || line.contains("extracting") {
            // Regex to capture percentage (e.g., "10%", "10.1 GB / 10.1 GB ... 100%")
            let regex = #"(?:downloading|extracting)\s+((?:\d+\.?\d*(?:\s?[KMGT]?B)?\s*\/\s*\d+\.?\d*(?:\s?[KMGT]?B)?\s*@\s*\d+\.?\d*\s?[KMGT]?B\/s\s*)?\[.*?\]\s*)?(\d+\.?\d*)%"#
            if let match = line.range(of: regex, options: .regularExpression) {
                let nsRange = NSRange(match, in: line)
                if let percentRange = Range(nsRange(2, in: line)!) {
                    let percentageString = String(line[percentRange])
                    if let percentage = Double(percentageString) {
                        let details = String(line[Range(nsRange(1, in: line)!) ?? match])
                            .trimmingCharacters(in: .whitespacesAndNewlines)
                            .replacingOccurrences(of: "[", with: "")
                            .replacingOccurrences(of: "]", with: "")
                            .replacingOccurrences(of: "%", with: "")
                            .trimmingCharacters(in: .whitespacesAndNewlines)
                        return .progress(model: modelName, percentage: percentage, details: details)
                    }
                }
            }
            // Fallback for simpler percentage like "downloading 10%"
            if let range = line.range(of: #"(\d+\.?\d*)%"#, options: .regularExpression) {
                let percentageString = String(line[range].dropLast()) // Remove '%'
                if let percentage = Double(percentageString) {
                    return .progress(model: modelName, percentage: percentage, details: line)
                }
            }
        }
        return nil
    }

    /// Terminates the ongoing Ollama pull process if any.
    func cancelPull() {
        if let currentProcess = process {
            currentProcess.terminate() // Sends SIGTERM
            // Also cancel the associated Task
            outputTask?.cancel()
            outputTask = nil
            process = nil
        }
    }
}

// Example Usage:
/*
Task {
    let agent = OllamaPullAgent()
    let modelToPull = "llama2" // Or "mistral", "gemma", etc.

    print("Starting pull for model: \(modelToPull)")

    // Simulate user cancellation after a few seconds
    let cancellationTask = Task {
        try? await Task.sleep(for: .seconds(10))
        if !Task.isCancelled {
            print("\nSimulating user cancellation...")
            agent.cancelPull()
        }
    }

    do {
        for await progress in agent.pullModel(modelName: modelToPull) {
            switch progress {
            case .started:
                print("Pull started.")
            case .status(let message):
                print("Status: \(message)")
            case .progress(let model, let percentage, let details):
                print(String(format: "Pulling \(model): %.2f%% - %@", percentage, details))
            case .completed(let model):
                print("Pull of \(model) completed successfully.")
                cancellationTask.cancel() // Stop cancellation task if completed
            case .cancelled:
                print("Pull operation cancelled by user.")
                cancellationTask.cancel()
            case .failed(let error):
                if let pullError = error as? OllamaPullError {
                    print("Pull failed: \(pullError.localizedDescription)")
                } else {
                    print("Pull failed with unexpected error: \(error.localizedDescription)")
                }
                cancellationTask.cancel()
            }
        }
    } catch {
        print("An error occurred outside the AsyncStream: \(error.localizedDescription)")
    }
}
*/
