
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

// This solution provides a combined approach for iOS (UIKit) and macOS (AppKit)
// The core bookmark logic is platform-agnostic.

import Foundation
import UniformTypeIdentifiers
#if canImport(UIKit)
import UIKit
#elseif canImport(AppKit)
import AppKit
#endif

// MARK: - Bookmark Management & Image Listing Logic (Platform-Agnostic)

class PhotoFolderManager {
    static let shared = PhotoFolderManager()
    private let userDefaultsKey = "photoFolderBookmark"

    private var currentAccessedFolderURL: URL? {
        didSet {
            // Ensure stopAccessing is called if the URL changes or is set to nil
            if oldValue != currentAccessedFolderURL {
                oldValue?.stopAccessingSecurityScopedResource()
            }
        }
    }

    // Call this when the app is about to terminate or when access is no longer needed
    func stopAccessingCurrentFolder() {
        currentAccessedFolderURL?.stopAccessingSecurityScopedResource()
        currentAccessedFolderURL = nil
    }

    // Saves a bookmark for the given folder URL to UserDefaults
    func saveFolderBookmark(for url: URL) throws {
        // Ensure we can access the folder initially to create the bookmark
        guard url.startAccessingSecurityScopedResource() else {
            print("Failed to start accessing security-scoped resource for saving folder bookmark.")
            throw BookmarkError.accessDenied
        }
        defer { url.stopAccessingSecurityScopedResource() }

        let bookmarkData = try url.bookmarkData(options: .withSecurityScopedResource,
                                                includingResourceValuesForKeys: nil,
                                                relativeTo: nil)
        UserDefaults.standard.set(bookmarkData, forKey: userDefaultsKey)
        print("Folder bookmark saved for: \(url.lastPathComponent)")
    }

    // Resolves the stored folder bookmark and returns the URL, handling stale bookmarks
    func resolveFolderBookmark() -> URL? {
        guard let bookmarkData = UserDefaults.standard.data(forKey: userDefaultsKey) else {
            print("No folder bookmark data found.")
            return nil
        }

        var isStale = false
        do {
            let url = try URL(resolvingBookmarkData: bookmarkData,
                              options: .withSecurityScopedResource,
                              relativeTo: nil,
                              bookmarkDataIsStale: &isStale)

            if isStale {
                print("Folder bookmark is stale, attempting to refresh...")
                let newBookmarkData = try url.bookmarkData(options: .withSecurityScopedResource,
                                                           includingResourceValuesForKeys: nil,
                                                           relativeTo: nil)
                UserDefaults.standard.set(newBookmarkData, forKey: userDefaultsKey)
                print("Folder bookmark refreshed successfully.")
            }

            // Attempt to gain access to the resource
            guard url.startAccessingSecurityScopedResource() else {
                print("Failed to start accessing security-scoped resource after resolving folder bookmark.")
                return nil
            }
            currentAccessedFolderURL = url
            print("Successfully resolved and accessed folder: \(url.lastPathComponent)")
            return url

        } catch {
            print("Error resolving or refreshing folder bookmark: \(error.localizedDescription)")
            clearFolderBookmark() // Clear invalid bookmark
            return nil
        }
    }

    // Removes the stored folder bookmark from UserDefaults
    func clearFolderBookmark() {
        stopAccessingCurrentFolder()
        UserDefaults.standard.removeObject(forKey: userDefaultsKey)
        print("Folder bookmark cleared from UserDefaults.")
    }

    // Enumerates image files within the currently accessed folder
    func listImageFiles() async throws -> [URL] {
        guard let folderURL = currentAccessedFolderURL else {
            throw ListingError.noFolderSelected
        }

        let imageExtensions: Set<String> = ["jpg", "jpeg", "png", "gif", "heic", "tiff", "webp"]
        var imageURLs: [URL] = []

        do {
            let fileURLs = try FileManager.default.contentsOfDirectory(at: folderURL,
                                                                       includingPropertiesForKeys: [.isRegularFileKey],
                                                                       options: .skipsHiddenFiles)
            for url in fileURLs {
                if imageExtensions.contains(url.pathExtension.lowercased()) {
                    imageURLs.append(url)
                }
            }
            return imageURLs.sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
        } catch {
            print("Error enumerating directory contents: \(error.localizedDescription)")
            throw ListingError.enumerationFailed(error)
        }
    }

    enum BookmarkError: Error, LocalizedError {
        case accessDenied
        case bookmarkCreationFailed(Error)

        var errorDescription: String? {
            switch self {
            case .accessDenied: return "Access to the selected resource was denied."
            case .bookmarkCreationFailed(let error): return "Failed to create bookmark: \(error.localizedDescription)"
            }
        }
    }

    enum ListingError: Error, LocalizedError {
        case noFolderSelected
        case enumerationFailed(Error)

        var errorDescription: String? {
            switch self {
            case .noFolderSelected: return "No photo folder has been selected."
            case .enumerationFailed(let error): return "Failed to list images in folder: \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - UI Implementation (Conditional for iOS/macOS)

#if canImport(UIKit) // iOS Implementation

class ViewController: UIViewController, UIDocumentPickerDelegate, UITableViewDataSource, UITableViewDelegate {

    let statusLabel = UILabel()
    let selectFolderButton = UIButton(type: .system)
    let clearFolderButton = UIButton(type: .system)
    let tableView = UITableView()

    var imageFileNames: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadAndListImages()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        PhotoFolderManager.shared.stopAccessingCurrentFolder()
    }

    func setupUI() {
        view.backgroundColor = .systemBackground

        statusLabel.text = "No folder selected."
        statusLabel.textAlignment = .center
        statusLabel.numberOfLines = 0
        statusLabel.translatesAutoresizingMaskIntoConstraints = false

        selectFolderButton.setTitle("Select Photo Folder", for: .normal)
        selectFolderButton.addTarget(self, action: #selector(selectFolderTapped), for: .touchUpInside)
        selectFolderButton.translatesAutoresizingMaskIntoConstraints = false

        clearFolderButton.setTitle("Clear Folder", for: .normal)
        clearFolderButton.addTarget(self, action: #selector(clearFolderTapped), for: .touchUpInside)
        clearFolderButton.translatesAutoresizingMaskIntoConstraints = false

        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "ImageCell")
        tableView.translatesAutoresizingMaskIntoMaskIntoConstraints = false

        let buttonStack = UIStackView(arrangedSubviews: [selectFolderButton, clearFolderButton])
        buttonStack.axis = .horizontal
        buttonStack.spacing = 10
        buttonStack.distribution = .fillEqually
        buttonStack.translatesAutoresizingMaskIntoConstraints = false

        let mainStack = UIStackView(arrangedSubviews: [statusLabel, buttonStack, tableView])
        mainStack.axis = .vertical
        mainStack.spacing = 10
        mainStack.distribution = .fill
        mainStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mainStack)

        NSLayoutConstraint.activate([
            mainStack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            mainStack.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            mainStack.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            mainStack.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            tableView.heightAnchor.constraint(greaterThanOrEqualToConstant: 100) // Ensure table view has some height
        ])
    }

    @objc func selectFolderTapped() {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.folder], asCopy: false)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        present(documentPicker, animated: true, completion: nil)
    }

    @objc func clearFolderTapped() {
        PhotoFolderManager.shared.clearFolderBookmark()
        statusLabel.text = "Folder access cleared."
        imageFileNames.removeAll()
        tableView.reloadData()
    }

    func loadAndListImages() {
        Task {
            if PhotoFolderManager.shared.resolveFolderBookmark() != nil {
                do {
                    let urls = try await PhotoFolderManager.shared.listImageFiles()
                    await MainActor.run {
                        self.imageFileNames = urls.map { $0.lastPathComponent }
                        self.tableView.reloadData()
                        self.statusLabel.text = "Loaded \(self.imageFileNames.count) images from: \(PhotoFolderManager.shared.currentAccessedFolderURL?.lastPathComponent ?? "N/A")"
                    }
                } catch {
                    await MainActor.run {
                        self.statusLabel.text = "Error listing images: \(error.localizedDescription)"
                        self.imageFileNames.removeAll()
                        self.tableView.reloadData()
                    }
                }
            } else {
                await MainActor.run {
                    self.statusLabel.text = "No photo folder selected or accessible."
                    self.imageFileNames.removeAll()
                    self.tableView.reloadData()
                }
            }
        }
    }

    // MARK: - UIDocumentPickerDelegate

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }

        Task {
            do {
                try PhotoFolderManager.shared.saveFolderBookmark(for: url)
                await MainActor.run {
                    self.loadAndListImages()
                }
            } catch {
                await MainActor.run {
                    self.statusLabel.text = "Error saving folder bookmark: \(error.localizedDescription)"
                }
            }
        }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("Document picker cancelled.")
    }

    // MARK: - UITableViewDataSource

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return imageFileNames.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ImageCell", for: indexPath)
        cell.textLabel?.text = imageFileNames[indexPath.row]
        return cell
    }
}

#elseif canImport(AppKit) // macOS Implementation

class ViewController: NSViewController, NSTableViewDataSource, NSTableViewDelegate {

    let statusLabel = NSTextField(labelWithString: "No folder selected.")
    let selectFolderButton = NSButton(title: "Select Photo Folder", target: nil, action: nil)
    let clearFolderButton = NSButton(title: "Clear Folder", target: nil, action: nil)
    let tableView = NSTableView()
    let tableScrollView = NSScrollView()

    var imageFileNames: [String] = []

    override func loadView() {
        self.view = NSView()
        self.view.wantsLayer = true
        self.view.layer?.backgroundColor = NSColor.windowBackgroundColor.cgColor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadAndListImages()
    }

    override func viewWillDisappear() {
        super.viewWillDisappear()
        PhotoFolderManager.shared.stopAccessingCurrentFolder()
    }

    func setupUI() {
        statusLabel.alignment = .center
        statusLabel.maximumNumberOfLines = 0
        statusLabel.translatesAutoresizingMaskIntoConstraints = false

        selectFolderButton.target = self
        selectFolderButton.action = #selector(selectFolderTapped)
        selectFolderButton.translatesAutoresizingMaskIntoConstraints = false

        clearFolderButton.target = self
        clearFolderButton.action = #selector(clearFolderTapped)
        clearFolderButton.translatesAutoresizingMaskIntoConstraints = false

        let buttonStack = NSStackView(views: [selectFolderButton, clearFolderButton])
        buttonStack.orientation = .horizontal
        buttonStack.spacing = 10
        buttonStack.distribution = .fillEqually
        buttonStack.translatesAutoresizingMaskIntoConstraints = false

        tableScrollView.documentView = tableView
        tableScrollView.hasVerticalScroller = true
        tableScrollView.translatesAutoresizingMaskIntoConstraints = false

        tableView.addTableColumn(NSTableColumn(identifier: NSUserInterfaceItemIdentifier("ImageName")))
        tableView.headerView = nil // Hide header for simplicity
        tableView.dataSource = self
        tableView.delegate = self
        tableView.columnAutoresizingStyle = .uniformColumnAutoresizingStyle
        tableView.tableColumns.first?.width = tableScrollView.bounds.width // Fill width

        let mainStack = NSStackView(views: [statusLabel, buttonStack, tableScrollView])
        mainStack.orientation = .vertical
        mainStack.spacing = 10
        mainStack.distribution = .fill
        mainStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mainStack)

        NSLayoutConstraint.activate([
            mainStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            mainStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            mainStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            mainStack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20),
            tableScrollView.heightAnchor.constraint(greaterThanOrEqualToConstant: 100)
        ])
    }

    @objc func selectFolderTapped() {
        let openPanel = NSOpenPanel()
        openPanel.canChooseFiles = false
        openPanel.canChooseDirectories = true
        openPanel.allowsMultipleSelection = false
        openPanel.prompt = "Select Photo Folder"

        openPanel.begin { [weak self] response in
            guard response == .OK, let url = openPanel.url else {
                print("Open panel cancelled or no URL selected.")
                return
            }

            Task {
                do {
                    try PhotoFolderManager.shared.saveFolderBookmark(for: url)
                    await MainActor.run {
                        self?.loadAndListImages()
                    }
                } catch {
                    await MainActor.run {
                        self?.statusLabel.stringValue = "Error saving folder bookmark: \(error.localizedDescription)"
                    }
                }
            }
        }
    }

    @objc func clearFolderTapped() {
        PhotoFolderManager.shared.clearFolderBookmark()
        statusLabel.stringValue = "Folder access cleared."
        imageFileNames.removeAll()
        tableView.reloadData()
    }

    func loadAndListImages() {
        Task {
            if PhotoFolderManager.shared.resolveFolderBookmark() != nil {
                do {
                    let urls = try await PhotoFolderManager.shared.listImageFiles()
                    await MainActor.run {
                        self.imageFileNames = urls.map { $0.lastPathComponent }
                        self.tableView.reloadData()
                        self.statusLabel.stringValue = "Loaded \(self.imageFileNames.count) images from: \(PhotoFolderManager.shared.currentAccessedFolderURL?.lastPathComponent ?? "N/A")"
                    }
                } catch {
                    await MainActor.run {
                        self.statusLabel.stringValue = "Error listing images: \(error.localizedDescription)"
                        self.imageFileNames.removeAll()
                        self.tableView.reloadData()
                    }
                }
            } else {
                await MainActor.run {
                    self.statusLabel.stringValue = "No photo folder selected or accessible."
                    self.imageFileNames.removeAll()
                    self.tableView.reloadData()
                }
            }
        }
    }

    // MARK: - NSTableViewDataSource

    func numberOfRows(in tableView: NSTableView) -> Int {
        return imageFileNames.count
    }

    // MARK: - NSTableViewDelegate

    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        var cellView = tableView.makeView(withIdentifier: NSUserInterfaceItemIdentifier("ImageCell"), owner: self) as? NSTableCellView
        if cellView == nil {
            cellView = NSTableCellView(frame: NSRect(x: 0, y: 0, width: tableView.bounds.width, height: 20))
            cellView?.identifier = NSUserInterfaceItemIdentifier("ImageCell")
            cellView?.textField = NSTextField(frame: NSRect(x: 0, y: 0, width: tableView.bounds.width, height: 20))
            cellView?.textField?.isEditable = false
            cellView?.textField?.isBordered = false
            cellView?.textField?.backgroundColor = .clear
            cellView?.addSubview(cellView!.textField!)
        }
        cellView?.textField?.stringValue = imageFileNames[row]
        return cellView
    }
}

// Example AppDelegate for macOS to set up the window and initial view controller
@main
class AppDelegate: NSObject, NSApplicationDelegate {

    var window: NSWindow!

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 600, height: 400),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.center()
        window.setFrameAutosaveName("PhotoViewerWindow")
        window.contentViewController = ViewController()
        window.makeKeyAndOrderFront(nil)
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        PhotoFolderManager.shared.stopAccessingCurrentFolder()
    }

    func applicationSupportsSecureRestorableState(_ app: NSApplication) -> Bool {
        return true
    }
}
#endif
