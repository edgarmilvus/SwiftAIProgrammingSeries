
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import MLX
import Foundation

@available(iOS 18.0, macOS 15.0, *)
class LoRALinear: MLXNN.Module {
    let inputSize: Int
    let outputSize: Int
    let rank: Int
    
    // LoRA matrices A and B
    var A: MLXArray
    var B: MLXArray
    
    init(inputSize: Int, outputSize: Int, rank: Int) {
        self.inputSize = inputSize
        self.outputSize = outputSize
        self.rank = rank
        
        // Initialize LoRA matrices with small values
        // A: (input_size, rank)
        // B: (rank, output_size)
        // LoRA weights are typically full-precision (e.g., float16 or float32)
        // even when the base model is quantized.
        self.A = MLXArray.randomNormal(shape: [inputSize, rank], type: .float16) * 0.01
        self.B = MLXArray.randomNormal(shape: [rank, outputSize], type: .float16) * 0.01
        
        super.init()
        self.name = "LoRALinear"
        
        // Register A and B as trainable parameters within this module
        self.parameters["A"] = A
        self.parameters["B"] = B
    }
    
    // The forward pass for the LoRA adapter
    func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Compute (input @ A @ B)
        // This represents the low-rank update to the base linear layer's output
        return input.matmul(A).matmul(B)
    }
}

@available(iOS 18.0, macOS 15.0, *)
class QuantizedBaseLLMLayer: MLXNN.Module {
    // This simulates a single linear layer from a pre-quantized LLM
    // In a real scenario, `baseLinear`'s weights would be loaded as `int4` or `int8` MLXArrays,
    // and MLX's internal operations would handle the de-quantization for computation.
    
    let baseLinear: MLXNN.Linear // Represents a layer from the quantized base model
    let loraAdapter: LoRALinear?
    
    init(inputSize: Int, outputSize: Int, loraRank: Int? = nil) {
        self.baseLinear = MLXNN.Linear(inputSize: inputSize, outputSize: outputSize, bias: true)
        
        // Simulate loading quantized weights for baseLinear
        // In reality, baseLinear.weights would be loaded from a quantized MLX model file.
        // For this exercise, we'll just initialize it normally, but conceptually it's a frozen, quantized layer.
        self.baseLinear.weights = MLXArray.randomNormal(shape: [outputSize, inputSize], type: .float16) // Conceptual quantized weights
        
        if let rank = loraRank {
            self.loraAdapter = LoRALinear(inputSize: inputSize, outputSize: outputSize, rank: rank)
        } else {
            self.loraAdapter = nil
        }
        
        super.init()
        self.name = "QuantizedBaseLLMLayer"
        
        // Add baseLinear parameters to the module's parameters.
        // For LoRA, these parameters are typically *frozen* during fine-tuning.
        // We add them here to include them in the overall model structure, but they won't be trained.
        self.parameters["baseLinear"] = baseLinear.parameters()
        
        // Add LoRA adapter parameters if present. These are the *only* trainable parameters.
        if let lora = loraAdapter {
            self.parameters["loraAdapter"] = lora.parameters()
        }
    }
    
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // 1. Forward pass through the base (quantized) linear layer
        // MLX's internal mechanisms would handle de-quantization for computation if weights are int4/int8.
        // The output of this layer will be float16.
        let baseOutput = baseLinear(input)
        
        // 2. Apply LoRA adapter if available
        if let lora = loraAdapter {
            let loraOutput = lora(input) // LoRA computes its update
            // Add LoRA output (float16) to base output (float16)
            return baseOutput + loraOutput
        } else {
            return baseOutput
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
func runLoRAQuantizedFineTuning() {
    print("Starting LoRA Adapter for Quantized Base Model Fine-Tuning Simulation...")

    let inputDim = 256
    let outputDim = 256
    let loraRank = 4 // Low rank for LoRA matrices
    
    // 1. Define a LoRA-enabled layer for a conceptual quantized base model
    let modelLayer = QuantizedBaseLLMLayer(inputSize: inputDim, outputSize: outputDim, loraRank: loraRank)
    
    // Identify trainable parameters (only LoRA's A and B)
    // We need to filter the modelLayer's parameters to only include those from the loraAdapter.
    let loraTrainableParameters = modelLayer.parameters.filter { $0.key.starts(with: "loraAdapter") }.values.map { $0 }
    
    guard !loraTrainableParameters.isEmpty else {
        print("Error: LoRA adapter not initialized or no trainable parameters found.")
        return
    }
    
    // 2. Create a dummy "Swift code" dataset
    let batchSize = 4
    let sequenceLength = 10
    
    // Input: e.g., embeddings of Swift code tokens
    let dummyInputs = MLXArray.randomUniform(low: 0, high: 1, shape: [batchSize, sequenceLength, inputDim], type: .float16)
    // Target: e.g., next token prediction embeddings
    let dummyTargets = MLXArray.randomUniform(low: 0, high: 1, shape: [batchSize, sequenceLength, outputDim], type: .float16)

    // Define optimizer
    let learningRate: Float = 0.001
    let optimizer = MLXOptimizers.Adam(learningRate: learningRate)
    
    // Define a simple loss function (Mean Squared Error for regression)
    func lossFunction(_ model: MLXNN.Module, _ inputs: MLXArray, _ targets: MLXArray) -> MLXArray {
        let predictions = model(inputs)
        return MLX.mean(MLX.square(predictions - targets))
    }
    
    print("\n--- Simulated Training Loop (LoRA only) ---")
    let numTrainingSteps = 5
    
    for step in 0..<numTrainingSteps {
        // Use valueAndGradient to compute loss and gradients for ONLY the LoRA parameters.
        // The `parameters` argument to `valueAndGradient` specifies which parameters are trainable.
        let (loss, grads) = MLX.valueAndGradient(of: lossFunction, with: modelLayer, parameters: loraTrainableParameters, arguments: dummyInputs, dummyTargets)
        
        // Update only the LoRA parameters using the optimizer
        // The `update` method modifies the MLXArray instances passed in `parameters` in place.
        var updatedLoRAParams = loraTrainableParameters // Create a mutable copy
        optimizer.update(parameters: &updatedLoRAParams, gradients: grads.values.map { $0 })
        
        // Crucially, update the modelLayer's internal parameters with the new values.
        // Since `optimizer.update` modifies the MLXArray instances, we need to ensure
        // the `modelLayer`'s `loraAdapter` (and its `parameters` dictionary) points to these updated arrays.
        if let lora = modelLayer.loraAdapter {
            // Assuming the order of loraTrainableParameters is consistent (A then B)
            lora.A = updatedLoRAParams[0]
            lora.B = updatedLoRAParams[1]
            // Also update the module's parameters dictionary to reflect these changes
            modelLayer.parameters["loraAdapter.A"] = lora.A
            modelLayer.parameters["loraAdapter.B"] = lora.B
        }

        MLX.eval(loss, updatedLoRAParams) // Evaluate the loss and updated parameters
        MLX.synchronize() // Ensure all computations are done
        
        print("Step \(step + 1): Loss = \(loss.item(Float.self))")
    }
    
    print("\n--- Inference with Trained LoRA Adapter ---")
    // Use a new input for inference
    let inferenceInput = MLXArray.randomUniform(low: 0, high: 1, shape: [1, sequenceLength, inputDim], type: .float16)
    
    let startTime = Date()
    let inferenceOutput = modelLayer(inferenceInput)
    MLX.eval(inferenceOutput)
    MLX.synchronize()
    let inferenceDuration = Date().timeIntervalSince(startTime)
    
    print("Inference completed in \(String(format: "%.4f", inferenceDuration)) seconds.")
    print("Output shape: \(inferenceOutput.shape)")
    
    print("\n--- Discussion: LoRA Integration with Quantized Base ---")
    print("This exercise demonstrates how to apply LoRA to a conceptually quantized base model.")
    print("The key insight is that the LoRA adapter's parameters (A and B) are typically small,")
    print("full-precision (e.g., `float16`) matrices. During inference, the base model's forward pass")
    print("occurs (which internally handles de-quantization for computation if its weights are `int4`/`int8`).")
    print("The output of the base layer is then in `float16`. The LoRA adapter then computes its low-rank update")
    print("using `float16` arithmetic, and this update is *added* to the base model's `float16` output.")
    print("This avoids the need to fully de-quantize and re-quantize the entire large base model during fine-tuning or inference,")
    print("preserving memory efficiency while allowing specialized adaptation.")
    print("MLX's `MLXArray` handles mixed-precision operations gracefully, performing necessary")
    print("type promotions during computation, making this integration seamless.")
}
