
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import MLX

// Re-using TokenizerProtocol from Exercise 1
protocol TokenizerProtocol: Sendable {
    func tokenize(text: String) -> [Int]
    func detokenize(ids: [Int]) -> String
    var eosTokenID: Int { get }
}

// Re-using MockTokenizer from Exercise 1
class MockTokenizer: TokenizerProtocol {
    let vocab: [String: Int]
    let reverseVocab: [Int: String]
    let eosTokenID: Int

    init(vocab: [String: Int], eosTokenID: Int) {
        self.vocab = vocab
        self.reverseVocab = vocab.reduce(into: [:]) { $0[$1.value] = $1.key }
        self.eosTokenID = eosTokenID
    }

    func tokenize(text: String) -> [Int] {
        return text.split(separator: " ", omittingEmptySubsequences: true).compactMap { vocab[String($0)] }
    }

    func detokenize(ids: [Int]) -> String {
        return ids.compactMap { reverseVocab[$0] }.joined(separator: " ")
    }
}

// MARK: - Mock MLX Models for Ensemble

@available(iOS 18.0, macOS 14.0, *)
class EntityRecognizerModel: MLXNN.Module {
    // In a real scenario, this would have parameters and a forward pass
    // For this mock, we just simulate streaming.
    override init() { super.init() }

    func generate(input: MLXArray) async throws -> AsyncThrowingStream<String, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                // Simulate processing based on input (simplified)
                let inputString = MockTokenizer(vocab: ["apple":1, "tim":2, "cook":3, "new":4, "product":5, "company":6, "ceo":7, "<|eos|>":1000], eosTokenID: 1000).detokenize(ids: input.data.map { $0.item(Int.self)! })
                
                if inputString.lowercased().contains("apple") {
                    try await Task.sleep(for: .milliseconds(100))
                    continuation.yield("Apple (Company)")
                    try await Task.sleep(for: .milliseconds(200))
                    continuation.yield("iPhone (Product)")
                }
                if inputString.lowercased().contains("tim cook") {
                    try await Task.sleep(for: .milliseconds(150))
                    continuation.yield("Tim Cook (Person)")
                }
                continuation.finish()
            }
        }
    }
}

@available(iOS 18.0, macOS 14.0, *)
class SentimentAnalyzerModel: MLXNN.Module {
    enum Sentiment: String, CustomStringConvertible, Sendable {
        case positive, negative, neutral
        var description: String { self.rawValue }
    }
    override init() { super.init() }

    func generate(input: MLXArray) async throws -> AsyncThrowingStream<Sentiment, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                let inputString = MockTokenizer(vocab: ["apple":1, "tim":2, "cook":3, "new":4, "product":5, "company":6, "ceo":7, "<|eos|>":1000, "great":8, "bad":9, "exciting":10], eosTokenID: 1000).detokenize(ids: input.data.map { $0.item(Int.self)! })

                try await Task.sleep(for: .milliseconds(50))
                continuation.yield(.neutral) // Initial sentiment
                
                if inputString.lowercased().contains("great") || inputString.lowercased().contains("exciting") {
                    try await Task.sleep(for: .milliseconds(300))
                    continuation.yield(.positive)
                } else if inputString.lowercased().contains("bad") {
                    try await Task.sleep(for: .milliseconds(300))
                    continuation.yield(.negative)
                }
                continuation.finish()
            }
        }
    }
}

@available(iOS 18.0, macOS 14.0, *)
class SummarizerModel: MLXNN.Module {
    override init() { super.init() }

    func generate(input: MLXArray) async throws -> AsyncThrowingStream<String, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                let inputString = MockTokenizer(vocab: ["apple":1, "tim":2, "cook":3, "new":4, "product":5, "company":6, "ceo":7, "<|eos|>":1000, "great":8, "bad":9, "exciting":10, "report":11], eosTokenID: 1000).detokenize(ids: input.data.map { $0.item(Int.self)! })

                try await Task.sleep(for: .milliseconds(20))
                continuation.yield("Summary: ")
                
                if inputString.lowercased().contains("apple") && inputString.lowercased().contains("new product") {
                    try await Task.sleep(for: .milliseconds(150))
                    continuation.yield("Apple is launching ")
                    try await Task.sleep(for: .milliseconds(100))
                    continuation.yield("a new product. ")
                } else if inputString.lowercased().contains("tim cook") {
                    try await Task.sleep(for: .milliseconds(150))
                    continuation.yield("Tim Cook discusses ")
                    try await Task.sleep(for: .milliseconds(100))
                    continuation.yield("company strategy. ")
                } else {
                    try await Task.sleep(for: .milliseconds(100))
                    continuation.yield("Content analysis. ")
                }
                continuation.finish()
            }
        }
    }
}

// MARK: - Fact-Checking Orchestrator

@available(iOS 18.0, macOS 14.0, *)
struct FactCheckEvent: Sendable {
    var entity: String?
    var sentiment: SentimentAnalyzerModel.Sentiment?
    var summaryPart: String?
}

@available(iOS 18.0, macOS 14.0, *)
class FactCheckingOrchestrator {
    let entityRecognizer = EntityRecognizerModel()
    let sentimentAnalyzer = SentimentAnalyzerModel()
    let summarizer = SummarizerModel()
    
    // Assume tokenizer is loaded externally
    private let tokenizer: any TokenizerProtocol

    init(tokenizer: any TokenizerProtocol) {
        self.tokenizer = tokenizer
    }

    func processContent(text: String) async throws -> AsyncThrowingStream<FactCheckEvent, Error> {
        let inputTokens = tokenizer.tokenize(text: text)
        let mlxInput = MLXArray(inputTokens)

        return AsyncThrowingStream { continuation in
            Task { // Use a single Task to manage the streams and continuation
                var currentEvent = FactCheckEvent()
                var entityFinished = false
                var sentimentFinished = false
                var summaryFinished = false

                // Use a TaskGroup to concurrently consume from all streams
                await withTaskGroup(of: Void.self) { group in
                    group.addTask {
                        do {
                            for try await entity in try await self.entityRecognizer.generate(input: mlxInput) {
                                await MainActor.run {
                                    currentEvent.entity = entity
                                    continuation.yield(currentEvent)
                                }
                            }
                            entityFinished = true
                        } catch {
                            continuation.finish(throwing: error)
                        }
                    }

                    group.addTask {
                        do {
                            for try await sentiment in try await self.sentimentAnalyzer.generate(input: mlxInput) {
                                await MainActor.run {
                                    currentEvent.sentiment = sentiment
                                    continuation.yield(currentEvent)
                                }
                            }
                            sentimentFinished = true
                        } catch {
                            continuation.finish(throwing: error)
                        }
                    }

                    group.addTask {
                        do {
                            for try await summaryPart in try await self.summarizer.generate(input: mlxInput) {
                                await MainActor.run {
                                    currentEvent.summaryPart = (currentEvent.summaryPart ?? "") + summaryPart
                                    continuation.yield(currentEvent)
                                }
                            }
                            summaryFinished = true
                        } catch {
                            continuation.finish(throwing: error)
                        }
                    }
                    
                    // Wait for all tasks in the group to complete
                    await group.waitForAll()
                }
                
                // Ensure the continuation finishes after all streams are exhausted
                continuation.finish()
            }
        }
    }
}

// MARK: - Conceptual Usage

@available(iOS 18.0, macOS 14.0, *)
@MainActor
func runMultiModelEnsembleExample() {
    let mockVocab: [String: Int] = [
        "Apple": 1, "is": 2, "launching": 3, "a": 4, "new": 5, "great": 6, "product": 7, ".": 8, "Tim": 9, "Cook": 10, "spoke": 11, "about": 12, "it": 13, "today": 14, "at": 15, "the": 16, "conference": 17, "exciting": 18,
        "<|eos|>": 1000
    ]
    let tokenizer = MockTokenizer(vocab: mockVocab, eosTokenID: 1000)
    let orchestrator = FactCheckingOrchestrator(tokenizer: tokenizer)
    
    Task {
        print("\n--- Processing Content with Multi-Model Ensemble ---")
        let content = "Apple is launching a new great product. Tim Cook spoke about it today at the exciting conference."
        print("Input: \"\(content)\"\n")
        
        do {
            let eventStream = try await orchestrator.processContent(text: content)
            var lastEvent = FactCheckEvent()
            
            for try await event in eventStream {
                // Only print if there's a change or new information
                if event.entity != lastEvent.entity || event.sentiment != lastEvent.sentiment || event.summaryPart != lastEvent.summaryPart {
                    print("FactCheckEvent: Entity='\(event.entity ?? "N/A")', Sentiment='\(event.sentiment?.description ?? "N/A")', Summary='\(event.summaryPart ?? "N/A")'")
                    lastEvent = event
                }
            }
            print("\n--- Fact-Checking Complete ---")
        } catch {
            print("Error during fact-checking: \(error.localizedDescription)")
        }
    }
}

// Call this to run the conceptual example
// runMultiModelEnsembleExample()
