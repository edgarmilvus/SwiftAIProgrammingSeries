
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import AVFoundation
import SoundAnalysis
import Observation

/// Represents a detected sound event.
struct SoundEvent: Sendable {
    let label: String
    let confidence: Float
}

/// An actor to safely manage the audio engine and analysis state in a concurrent environment.
actor SoundClassifierEngine {
    private let audioEngine = AVAudioEngine()
    private var analyzer: SNAudioStreamAnalyzer?
    private var classificationRequest: SNClassifySoundRequest?
    
    // A stream to broadcast results to the UI
    private var continuation: AsyncStream<SoundEvent>.Continuation?
    lazy var eventStream: AsyncStream<SoundEvent> = {
        AsyncStream { continuation in
            self.continuation = continuation
        }
    }()

    func startAnalyzing() throws {
        let inputNode = audioEngine.inputNode
        let inputFormat = inputNode.inputFormat(forBus: 0)
        
        // 1. Initialize the Analyzer
        analyzer = SNAudioStreamAnalyzer(format: inputFormat)
        
        // 2. Create the Request (using system-provided classification)
        classificationRequest = SNClassifySoundRequest()
        
        // 3. Install the Tap
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: inputFormat) { [weak self] buffer, _ in
            Task { [weak self] in
                await self?.processBuffer(buffer)
            }
        }
        
        try audioEngine.start()
        
        // 4. Start the Analysis Stream
        guard let analyzer = analyzer, let request = classificationRequest else { return }
        
        Task {
            let listener = SNResultsListener(analyzing: request, on: analyzer)
            for try await result in listener.results(for: request) {
                // Extract the top classification
                if let topClassification = result.classifications.first(where: { $0.confidence > 0.8 }) {
                    let event = SoundEvent(label: topClassification.identifier, 
                                         confidence: topClassification.confidence)
                    self.continuation?.yield(event)
                }
            }
        }
    }

    private func processBuffer(_ buffer: AVAudioPCMBuffer) async {
        guard let analyzer = analyzer else { return }
        do {
            try await analyzer.analyze(buffer, presenting: classificationRequest!)
        } catch {
            print("Analysis error: \(error)")
        }
    }
    
    func stop() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        continuation?.finish()
    }
}

@MainActor
@Observable
class SentinelViewModel {
    var lastDetectedSound: String = "Listening..."
    private let engine = SoundClassifierEngine()
    
    func start() {
        Task {
            do {
                try await engine.startAnalyzing()
                // Consume the async stream
                for await event in await engine.eventStream {
                    self.lastDetectedSound = "\(event.label) (\(Int(event.confidence * 100))%)"
                }
            } catch {
                self.lastDetectedSound = "Error: \(error.localizedDescription)"
            }
        }
    }
}
