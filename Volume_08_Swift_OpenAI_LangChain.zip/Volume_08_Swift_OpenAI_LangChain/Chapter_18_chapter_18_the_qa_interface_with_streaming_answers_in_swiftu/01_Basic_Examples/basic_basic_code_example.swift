
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Observation

// MARK: - Models

/// Represents a single message in the chat history.
/// We conform to `Identifiable` so SwiftUI can efficiently manage the list.
/// We conform to `Sendable` to ensure it can be safely passed across concurrency domains.
struct ChatMessage: Identifiable, Sendable, Hashable {
    let id: UUID
    let content: String
    let isUser: Bool
    
    init(id: UUID = UUID(), content: String, isUser: Bool) {
        self.id = id
        self.content = content
        self.isUser = isUser
    }
}

// MARK: - Service Layer

/// A service responsible for simulating the streaming of text from an LLM.
/// In a production app, this would wrap a URLSession task handling Server-Sent Events (SSE).
@available(iOS 18.0, *)
final class ChatStreamingService: Sendable {
    
    /// Simulates a streaming response from an AI.
    /// - Parameter prompt: The user's input.
    /// - Returns: An `AsyncStream` that yields strings (tokens) one by one.
    func streamResponse(for prompt: String) -> AsyncStream<String> {
        AsyncStream { continuation in
            // We wrap the simulation in a Task to avoid blocking the caller.
            Task {
                let mockResponse = "This is a simulated streaming response. I am appearing token by token to demonstrate how Swift 6 handles asynchronous data streams in SwiftUI."
                let words = mockResponse.components(separatedBy: " ")
                
                for word in words {
                    // Simulate network latency/processing time for each token.
                    try? await Task.sleep(for: .milliseconds(150))
                    
                    // Yield the next "token" to the stream.
                    continuation.yield(word + " ")
                }
                
                // Signal that the stream is complete.
                continuation.finish()
            }
        }
    }
}

// MARK: - ViewModel

/// The orchestrator for the Chat UI.
/// Uses the modern `@Observable` macro for efficient, fine-grained UI updates.
@available(iOS 18.0, *)
@MainActor
@Observable
final class ChatViewModel {
    /// The collection of messages displayed in the UI.
    /// Marked as `@MainActor` implicitly via the class attribute to ensure UI safety.
    var messages: [ChatMessage] = []
    
    /// Tracks whether the AI is currently "typing" (streaming).
    var isStreaming: Bool = false
    
    /// The input text from the user.
    var inputText: String = ""
    
    private let streamingService = ChatStreamingService()
    
    /// Sends the user's message and initiates the streaming process.
    func sendMessage() async {
        let userText = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !userText.isEmpty else { return }
        
        // 1. Append the user's message to the list.
        let userMessage = ChatMessage(content: userText, isUser: true)
        messages.append(userMessage)
        inputText = "" // Clear input immediately for better UX.
        
        // 2. Prepare a placeholder for the AI's response.
        let aiMessageID = UUID()
        let placeholderMessage = ChatMessage(id: aiMessageID, content: "", isUser: false)
        messages.append(placeholderMessage)
        
        isStreaming = true
        
        // 3. Consume the stream.
        var accumulatedContent = ""
        
        // We iterate over the AsyncStream. Each iteration yields a new token.
        for await token in streamingService.streamResponse(for: userText) {
            accumulatedContent += token
            
            // 4. Update the specific AI message in the array.
            // Because the ViewModel is @MainActor, this update is thread-safe for the UI.
            if let index = messages.firstIndex(where: { $0.id == aiMessageID }) {
                messages[index] = ChatMessage(id: aiMessageID, content: accumulatedContent, isUser: false)
            }
        }
        
        isStreaming = false
    }
}

// MARK: - View Layer

@available(iOS 18.0, *)
struct ChatInterfaceView: View {
    @State private var viewModel = ChatViewModel()
    
    // Used to programmatically scroll to the bottom as text streams in.
    @Namespace private var chatNamespace
    
    var body: some View {
        NavigationStack {
            VStack {
                // The Message List
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            ForEach(viewModel.messages) { message in
                                MessageBubble(message: message)
                                    .id(message.id) // Required for ScrollViewProxy to find the view.
                            }
                        }
                        .padding()
                    }
                    // Automatically scroll to the latest message whenever the list changes.
                    .onChange(of: viewModel.messages) { _, _ in
                        if let lastMessage = viewModel.messages.last {
                            withAnimation(.easeOut(duration: 0.2)) {
                                proxy.scrollTo(lastMessage.id, anchor: .bottom)
                            }
                        }
                    }
                }
                
                // Input Area
                Divider()
                HStack(spacing: 12) {
                    TextField("Ask anything...", text: $viewModel.inputText)
                        .textFieldStyle(.roundedBorder)
                        .disabled(viewModel.isStreaming)
                    
                    Button {
                        Task {
                            await viewModel.sendMessage()
                        }
                    } label: {
                        if viewModel.isStreaming {
                            ProgressView()
                                .tint(.blue)
                        } else {
                            Image(systemName: "paperplane.fill")
                                .foregroundColor(.blue)
                        }
                    }
                    .disabled(viewModel.isStreaming || viewModel.inputText.isEmpty)
                }
                .padding()
            }
            .navigationTitle("AI Assistant")
        }
    }
}

/// A subview representing a single chat bubble.
struct MessageBubble: View {
    let message: ChatMessage
    
    var body: some View {
        HStack {
            if message.isUser { Spacer() }
            
            Text(message.content)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(message.isUser ? Color.blue : Color.gray.opacity(0.2))
                .foregroundColor(message.isUser ? .white : .primary)
                .clipShape(RoundedRectangle(cornerRadius: 18))
                // Use fixed size or minHeight to prevent "jumping" during stream.
                .frame(minWidth: 50, alignment: .leading)
            
            if !message.isUser { Spacer() }
        }
        .transition(.opacity.combined(with: .move(edge: .bottom)))
    }
}

// MARK: - Preview

#Preview {
    ChatInterfaceView()
}
