
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import Accelerate

@available(iOS 18.0, *)
struct SemanticChunk: Sendable {
    let id: UUID
    let embedding: [Float]
    let timestamp: Date
}

@available(iOS 18.0, *)
actor HybridScorer {
    let alpha: Float // Weight for similarity (0.0 - 1.0)
    let lambda: Float // Decay constant for recency
    
    init(alpha: Float = 0.7, lambda: Float = 0.1) {
        self.alpha = alpha
        self.lambda = lambda
    }
    
    @available(iOS 18.0, *)
    func rank(
        query: [Float],
        candidates: [SemanticChunk]
    ) async -> [(chunk: SemanticChunk, score: Float)] {
        let now = Date()
        
        // Use a TaskGroup if candidates were massive, but for standard batches, 
        // a mapped approach is more efficient to avoid task overhead.
        let scored = candidates.map { chunk -> (chunk: SemanticChunk, score: Float) in
            // 1. Calculate Cosine Similarity
            let simScore = cosineSimilarity(query, chunk.embedding)
            
            // 2. Calculate Recency Score (Exponential Decay)
            // deltaT in days
            let deltaT = Float(now.timeIntervalSince(chunk.timestamp) / 86400.0)
            let recencyScore = expf(-lambda * deltaT)
            
            // 3. Feature Fusion
            let finalScore = (alpha * simScore) + ((1.0 - alpha) * recencyScore)
            
            return (chunk, finalScore)
        }
        
        return scored.sorted { $0.score > $1.score }
    }
    
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count, !a.isEmpty else { return 0.0 }
        var dotProduct: Float = 0
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        var normA: Float = 0
        vDSP_svesq(a, 1, &normA, vDSP_Length(a.count))
        var normB: Float = 0
        vDSP_svesq(b, 1, &normB, vDSP_Length(b.count))
        let magnitude = sqrt(normA) * sqrt(normB)
        return magnitude > 0 ? dotProduct / magnitude : 0.0
    }
}
