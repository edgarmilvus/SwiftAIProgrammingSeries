
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import ARKit
import simd

enum ClapState {
    case neutral, approaching, impact, receding
}

actor GestureProcessor {
    // A circular buffer of wrist positions
    private var positionBuffer: [(left: simd_float3, right: simd_float3)] = []
    private let maxBufferSize = 30
    private var currentState: ClapState = .neutral

    func processFrame(left: simd_float3, right: simd_float3) -> Bool {
        // 1. Update Circular Buffer
        positionBuffer.append((left, right))
        if positionBuffer.count > maxBufferSize { positionBuffer.removeFirst() }
        
        guard positionBuffer.count >= 5 else { return false }

        // 2. Calculate current distance and velocity
        let currentDist = simd_distance(left, right)
        let prevDist = simd_distance(positionBuffer[positionBuffer.count - 2].left, 
                                     positionBuffer[positionBuffer.count - 2].right)
        let velocity = currentDist - prevDist

        // 3. State Machine Logic
        switch currentState {
        case .neutral:
            if velocity < -0.02 { // Hands moving together quickly
                currentState = .approaching
            }
            
        case .approaching:
            if currentDist < 0.05 { // Hands met (threshold 5cm)
                currentState = .impact
                return true // CLAP DETECTED!
            }
            
        case .impact:
            if velocity > 0.02 { // Hands moving apart
                currentState = .receding
            } else {
                currentState = .approaching // Reset if they stalled
            }
            
        case .receding:
            if velocity < -0.01 {
                currentState = .approaching
            } else {
                currentState = .neutral
            }
        }
        
        return false
    }
}

// Implementation in a VisionOS View Model
@MainActor
class SpatialInterfaceManager: ObservableObject {
    private let processor = GestureProcessor()
    
    func update(anchor: ARBodyAnchor) {
        Task {
            // Extracting positions (simplified)
            guard let leftT = anchor.skeleton.modelTransform(for: .leftWrist),
                  let rightT = anchor.skeleton.modelTransform(for: .rightWrist) else { return }
            
            let leftPos = simd_make_float3(anchor.transform * leftT.columns.3)
            let rightPos = simd_make_float3(anchor.transform * rightT.columns.3)
            
            // Run detection on a background actor to keep UI at 90/120 FPS
            let didClap = await processor.processFrame(left: leftPos, right: rightPos)
            
            if didClap {
                triggerClapEffect()
            }
        }
    }
    
    private func triggerClapEffect() {
        // Trigger RealityKit Particle Emitter or Spatial Audio
        print("✨ Magic Clap Triggered! ✨")
    }
}
