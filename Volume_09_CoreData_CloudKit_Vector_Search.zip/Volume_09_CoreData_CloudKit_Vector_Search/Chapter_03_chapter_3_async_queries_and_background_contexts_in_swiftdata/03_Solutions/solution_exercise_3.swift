
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import SwiftData

@Model
final class MediaItem {
    var title: String
    var fileHash: String
    
    init(title: String, fileHash: String) {
        self.title = title
        self.fileHash = fileHash
    }
}

actor MediaDataHandler: ModelActor {
    let modelContainer: ModelContainer
    let modelExecutor: any ModelExecutor
    
    init(container: ModelContainer) {
        self.modelContainer = container
        let context = ModelContext(container)
        self.modelExecutor = DefaultSerialModelExecutor(modelContext: context)
    }
    
    /// Performs complex cleanup by identifying and deleting duplicate file hashes.
    func performCleanup() throws -> Int {
        let descriptor = FetchDescriptor<MediaItem>()
        let allItems = try modelContext.fetch(descriptor)
        
        var seenHashes: [String: PersistentIdentifier] = [:]
        var deletedCount = 0
        
        for item in allItems {
            if let existingID = seenHashes[item.fileHash] {
                // Duplicate found!
                // We must fetch the actual model to delete it
                if let duplicateItem = try? modelContext.model(for: item.persistentModelID) as? MediaItem {
                    modelContext.delete(duplicateItem)
                    deletedCount += 1
                }
            } else {
                seenHashes[item.fileHash] = item.persistentModelID
            }
        }
        
        try modelContext.save()
        print("Cleanup complete. Deleted \(deletedCount) duplicates.")
        return deletedCount
    }
    
    /// Returns IDs to the UI to avoid passing non-Sendable models.
    func getMediaIDsForUI() throws -> [PersistentIdentifier] {
        let descriptor = FetchDescriptor<MediaItem>()
        let items = try modelContext.fetch(descriptor)
        return items.map { $0.persistentModelID }
    }
}
