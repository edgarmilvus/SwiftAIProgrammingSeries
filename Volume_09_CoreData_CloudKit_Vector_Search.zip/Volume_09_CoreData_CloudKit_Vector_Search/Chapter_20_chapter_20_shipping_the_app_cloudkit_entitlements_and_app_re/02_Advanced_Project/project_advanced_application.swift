
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CloudKit
import OSLog
import Combine

/// Represents the various states of the CloudKit synchronization engine.
/// Used to drive UI indicators (e.g., "Syncing...", "Offline", "Error").
enum SyncStatus: Equatable {
    case idle
    case syncing
    case error(SyncError)
    case accountUnavailable
    case quotaExceeded
}

/// Custom error types for granular error handling and user feedback.
enum SyncError: LocalizedError, Equatable {
    case cloudKitError(CKError.Code)
    case subscriptionFailed
    case networkIssue
    case unknown

    var errorDescription: String? {
        switch self {
        case .cloudKitError(let code): return "CloudKit Error: \(code.description)"
        case .subscriptionFailed: return "Failed to subscribe to remote changes."
        case .networkIssue: return "Network unavailable. Please check your connection."
        case .unknown: return "An unexpected error occurred."
        }
    }
}

/// A production-ready coordinator responsible for managing the lifecycle of CloudKit synchronization.
/// This actor ensures that all sync operations are thread-safe and isolated from the Main Actor.
///
/// @available(iOS 18.0, *)
actor CloudKitSyncCoordinator {
    
    // MARK: - Properties
    
    private let container: CKContainer
    private let privateDatabase: CKDatabase
    private let logger = Logger(subsystem: "com.app.sync", category: "CloudKitCoordinator")
    
    /// The current status of the synchronization engine, observable by the UI.
    @Published private(set) var status: SyncStatus = .idle
    
    /// The zone ID used for all private database operations. 
    /// Using a custom zone is a best practice for supporting `CKRecordZoneSubscription`.
    private let customZoneID: CKRecordZone.ID

    // MARK: - Initialization

    /// Initializes the coordinator with a specific container identifier.
    /// - Parameter containerIdentifier: The unique ID of the CloudKit container.
    init(containerIdentifier: String) {
        self.container = CKContainer(identifier: containerIdentifier)
        self.privateDatabase = container.privateCloudDatabase
        self.customZoneID = CKRecordZone.ID(zoneName: "UserDataZone", ownerName: CKCurrentUserDefaultName)
    }

    // MARK: - Public API

    /// Performs the initial setup of the CloudKit environment.
    /// This includes creating the custom zone and setting up remote subscriptions.
    /// - Throws: `SyncError` if the setup fails.
    func prepareEnvironment() async throws {
        status = .syncing
        logger.info("Starting CloudKit environment preparation...")

        do {
            try await setupCustomZone()
            try await setupRemoteSubscriptions()
            status = .idle
            logger.info("CloudKit environment ready.")
        } catch {
            handleError(error)
            throw error
        }
    }

    /// Manually triggers a fetch of all changes since the last known server change token.
    /// This is typically called after a silent push notification is received.
    func fetchChanges() async {
        status = .syncing
        logger.debug("Fetching remote changes...")
        
        // In a real app, you would fetch the last stored 'CKServerChangeToken' from CoreData.
        // For this demonstration, we simulate the fetch logic.
        do {
            // Simulate network latency
            try await Task.sleep(for: .seconds(1))
            
            // Logic for CKFetchRecordZoneChangesOperation would go here.
            // This is where the heavy lifting of delta-syncing happens.
            
            status = .idle
            logger.info("Fetch completed successfully.")
        } catch {
            handleError(error)
        }
    }

    // MARK: - Private Logic

    /// Ensures the custom CKRecordZone exists in the user's private database.
    /// Custom zones are required for atomic transactions and delta-syncing.
    private func setupCustomZone() async throws {
        let zone = CKRecordZone(zoneID: customZoneID)
        let operation = CKModifyRecordZonesOperation(recordZonesToSave: [zone], recordZoneIDsToDelete: nil)
        
        // We wrap the operation in a CheckedContinuation to bridge the legacy callback API 
        // to modern Swift 6 async/await.
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            operation.modifyRecordZonesResultBlock = { result in
                switch result {
                case .success:
                    continuation.resume()
                case .failure(let error):
                    continuation.resume(throwing: error)
                }
            }
            privateDatabase.add(operation)
        }
    }

    /// Registers a subscription so the server sends a push notification when data changes.
    /// This is critical for the "Multi-Device Sync" experience.
    private func setupRemoteSubscriptions() async throws {
        // Check if subscription already exists to avoid redundant errors
        let subscriptionID = "user-data-changes"
        
        let subscription = CKRecordZoneSubscription(zoneID: customZoneID, subscriptionID: subscriptionID)
        
        // Configure the notification info to be a "silent push"
        let notificationInfo = CKSubscription.NotificationInfo()
        notificationInfo.shouldSendContentAvailable = true // This makes it a silent push
        subscription.notificationInfo = notificationInfo

        let operation = CKModifySubscriptionsOperation(subscriptionsToSave: [subscription], subscriptionIDsToDelete: nil)
        
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            operation.modifySubscriptionsResultBlock = { result in
                switch result {
                case .success:
                    continuation.resume()
                case .failure(let error):
                    // If the error is 'duplicate subscription', we can safely ignore it.
                    if let ckError = error as? CKError, ckError.code == .duplicateSubscription {
                        continuation.resume()
                    } else {
                        continuation.resume(throwing: error)
                    }
                }
            }
            privateDatabase.add(operation)
        }
    }

    /// Centralized error handling logic to map CloudKit errors to user-friendly states.
    /// This is where "Production Intelligence" lives.
    private func handleError(_ error: Error) {
        guard let ckError = error as? CKError else {
            logger.error("Non-CloudKit error encountered: \(error.localizedDescription)")
            status = .error(.unknown)
            return
        }

        logger.error("CloudKit error encountered: \(ckError.localizedDescription) (Code: \(ckError.code.rawValue))")

        switch ckError.code {
        case .notAuthenticated:
            // User is not logged into iCloud.
            status = .accountUnavailable
        case .quotaExceeded:
            // User's iCloud storage is full.
            status = .quotaExceeded
        case .networkUnavailable, .networkFailure:
            // Standard connectivity issues.
            status = .error(.networkIssue)
        case .managedAccountRestricted:
            // Parental controls or MDM restrictions.
            status = .error(.cloudKitError(.managedAccountRestricted))
        default:
            status = .error(.cloudKitError(ckError.code))
        }
    }
}

// MARK: - UI Integration Example

import SwiftUI

/// A SwiftUI view that demonstrates how to observe the sync coordinator.
@available(iOS 18.0, *)
struct SyncStatusView: View {
    @State private var status: SyncStatus = .idle
    // In a real app, this would be injected via Environment or an ObservableObject.
    let syncCoordinator = CloudKitSyncCoordinator(containerIdentifier: "iCloud.com.example.AdvancedSyncApp")

    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: iconName)
                .font(.system(size: 40))
                .foregroundColor(statusColor)
            
            Text(statusMessage)
                .font(.headline)
            
            if case .error = status {
                Button("Retry Sync") {
                    Task {
                        try? await syncCoordinator.prepareEnvironment()
                    }
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .task {
            // Initial setup on view appearance
            try? await syncCoordinator.prepareEnvironment()
        }
    }

    private var iconName: String {
        switch status {
        case .idle: return "checkmark.icloud"
        case .syncing: return "arrow.triangle.2.circlepath"
        case .error: return "exclamationmark.icloud"
        case .accountUnavailable: return "person.crop.circle.badge.exclamationmark"
        case .quotaExceeded: return "cloud.badge.exclamationmark"
        }
    }

    private var statusColor: Color {
        switch status {
        case .idle: return .green
        case .syncing: return .blue
        case .error: return .red
        case .accountUnavailable: return .orange
        case .quotaExceeded: return .red
        }
    }

    private var statusMessage: String {
        switch status {
        case .idle: return "All data synced."
        case .syncing: return "Synchronizing with iCloud..."
        case .error(let error): return error.localizedDescription
        case .accountUnavailable: return "Please sign in to iCloud."
        case .quotaExceeded: return "iCloud storage is full."
        }
    }
}
