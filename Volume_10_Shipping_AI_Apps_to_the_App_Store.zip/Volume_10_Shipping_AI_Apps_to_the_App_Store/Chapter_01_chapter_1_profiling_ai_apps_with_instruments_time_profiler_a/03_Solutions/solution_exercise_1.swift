
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Vision
import CoreML

@available(iOS 18.0, *)
@MainActor // Ensure the ViewModel updates UI on the Main Actor
class ScannerViewModel: ObservableObject {
    @Published var isProcessing = false
    @Published var recognizedText = ""

    func performScan(on image: UIImage) {
        isProcessing = true
        
        // We spawn a new Task to enter an asynchronous context.
        // This allows the 'performScan' function to return immediately,
        // freeing the Main Thread to keep the UI responsive (and the spinner animating).
        Task {
            let result = await runOCROffloaded(image: image)
            
            // Since this Task was created on a @MainActor class, 
            // the following updates safely happen on the Main Actor.
            self.recognizedText = result
            self.isProcessing = false
        }
    }

    // 'nonisolated' is crucial here. It tells the Swift compiler that this 
    // method does not belong to the MainActor, allowing it to run on 
    // the shared concurrent thread pool instead of blocking the UI thread.
    nonisolated private func runOCROffloaded(image: UIImage) async -> String {
        // Simulate heavy Core ML inference latency
        // Using Task.sleep instead of Thread.sleep to avoid blocking a thread entirely
        try? await Task.sleep(for: .seconds(1.5)) 
        return "Extracted Text: Hello World"
    }
}

struct ScannerView: View {
    @StateObject private var viewModel = ScannerViewModel()
    
    var body: some View {
        VStack(spacing: 20) {
            if viewModel.isProcessing {
                ProgressView("Analyzing Document...")
                    .scaleEffect(1.5)
            }
            
            Text(viewModel.recognizedText)
                .font(.headline)
            
            Button("Scan Document") {
                viewModel.performScan(on: UIImage())
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}
