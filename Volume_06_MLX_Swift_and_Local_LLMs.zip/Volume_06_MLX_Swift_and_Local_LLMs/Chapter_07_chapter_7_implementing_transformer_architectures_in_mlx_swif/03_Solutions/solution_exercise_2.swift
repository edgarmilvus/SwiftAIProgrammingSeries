
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import MLX
import MLXNN // For MLXNN.Module

@available(iOS 18.0, macOS 15.0, *)
class SinusoidalPositionalEncoding: MLXNN.Module {
    let positionalEncoding: MLXArray // Pre-computed PE matrix

    init(maxSequenceLength: Int, modelDimension: Int) {
        // Create positions: [0, 1, ..., maxSequenceLength - 1] as a float array.
        let positions = mlx.core.arange(0, maxSequenceLength, dtype: MLXArray.DType.float32) // Shape: [maxSequenceLength]

        // Create dimensions for the `div_term`.
        // `indices` represents `2i` in the formula: [0, 2, 4, ..., modelDimension - 2]
        let indices = mlx.core.arange(0, modelDimension, step: 2, dtype: MLXArray.DType.float32) // Shape: [modelDimension / 2]

        // Calculate the `div_term` part: 10000^(2i / modelDimension)
        let divTerm = mlx.core.power(MLXArray(10000.0), indices / MLXArray(Float(modelDimension))) // Shape: [modelDimension / 2]

        // Expand dimensions for broadcasting.
        // `positionsExpanded` becomes [maxSequenceLength, 1]
        // `divTermExpanded` becomes [1, modelDimension / 2]
        // This allows element-wise division to produce a [maxSequenceLength, modelDimension / 2] tensor.
        let positionsExpanded = positions.expandedDimensions(axes: [1])
        let divTermExpanded = divTerm.expandedDimensions(axes: [0])

        // Calculate the argument for sin/cos: pos / (10000^(2i / modelDimension))
        let arg = positionsExpanded / divTermExpanded // Shape: [maxSequenceLength, modelDimension / 2]

        // Initialize the full PE matrix with zeros.
        var pe = MLXArray.zeros([maxSequenceLength, modelDimension], dtype: MLXArray.DType.float32)

        // Assign sin values to even indices and cos values to odd indices.
        // MLX Swift's slicing allows assignment to specific parts of an array.
        // `pe[row_slice, col_slice, step: col_step]`
        pe[0 ..< maxSequenceLength, 0 ..< modelDimension, step: 2] = mlx.core.sin(arg)
        pe[0 ..< maxSequenceLength, 1 ..< modelDimension, step: 2] = mlx.core.cos(arg)

        // Store the pre-computed positional encoding.
        self.positionalEncoding = pe
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // x: [batchSize, currentSequenceLength, modelDimension]
        let currentSequenceLength = x.shape[1]

        // Slice the pre-computed PE matrix to match the current sequence length of the input.
        // This results in a [currentSequenceLength, modelDimension] tensor.
        let currentPE = positionalEncoding[0 ..< currentSequenceLength]

        // Add the positional encoding to the input embeddings.
        // MLXArray automatically handles broadcasting `currentPE` (which is [S, D])
        // to `x`'s batch dimension (which is [B, S, D]).
        // This means `currentPE` is effectively duplicated across the batch dimension.
        return x + currentPE
    }
}
