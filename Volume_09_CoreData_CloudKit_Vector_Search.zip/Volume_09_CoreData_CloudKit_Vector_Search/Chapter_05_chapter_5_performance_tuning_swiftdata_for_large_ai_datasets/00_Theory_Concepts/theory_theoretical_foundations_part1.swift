
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import SwiftData
import Observation

/// Represents a semantic chunk of data with its associated embedding.
/// We use @available to ensure we are using the latest concurrency and observation features.
@available(iOS 18.0, *)
@Model
final class SemanticMemory {
    @Attribute(.unique) var id: UUID
    var text: String
    var timestamp: Date
    
    /// The high-dimensional vector. 
    /// Note: In a real-world scenario, we must be mindful of the size of this array.
    var embedding: [Float]
    
    init(text: String, embedding: [Float]) {
        self.id = UUID()
        self.text = text
        self.timestamp = Date()
        self.embedding = embedding
    }
}

/// The AIModelActor is our "Station Chef."
/// It isolates all heavy-duty vector operations and SwiftData mutations 
/// to a background executor, preventing Main Thread stalls.
@available(iOS 18.0, *)
actor AIModelActor: ModelActor {
    let modelContainer: ModelContainer
    let modelExecutor: any ModelExecutor

    /// The specialized context for this actor.
    let context: ModelContext

    init(container: ModelContainer) {
        self.modelContainer = container
        // We create a new context specifically for this actor's executor.
        let context = ModelContext(container)
        self.modelExecutor = DefaultSerialModelExecutor(modelContext: context)
        self.context = context
    }

    /// Performs high-intensity embedding ingestion.
    /// This is a 'Sendable' operation because it takes a raw [Float] 
    /// and a String, which are value types.
    func ingest(text: String, embedding: [Float]) async throws {
        let newMemory = SemanticMemory(text: text, embedding: embedding)
        context.insert(newMemory)
        
        // Batch saving is critical for performance.
        // We don't save on every single insertion in a loop; 
        // we save at the end of a logical batch.
        try context.save()
    }

    /// Performs a semantic search by calculating cosine similarity.
    /// This demonstrates the 'Hybrid Retrieval' concept:
    /// 1. Filter via Predicate (SQLite)
    /// 2. Score via Math (CPU/Accelerate)
    func semanticSearch(queryEmbedding: [Float], limit: Int) async throws -> [UUID] {
        // Step 1: Fetch potential candidates (Metadata filtering)
        // In a real app, you might filter by date or category here.
        let descriptor = FetchDescriptor<SemanticMemory>()
        let candidates = try context.fetch(descriptor)

        // Step 2: Mathematical Scoring (The heavy lifting)
        // We do this on the actor, NOT the main thread.
        let scoredResults = candidates.map { memory in
            let similarity = cosineSimilarity(queryEmbedding, memory.embedding)
            return (memory.id, similarity)
        }

        // Step 3: Sort and return only the IDs to maintain Sendability
        return scoredResults
            .sorted { $0.1 > $1.1 }
            .prefix(limit)
            .map { $0.0 }
    }

    /// Private helper for vector math.
    /// In production, this would use the Accelerate framework for SIMD optimization.
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return 0 }
        let dotProduct = zip(a, b).map(*).reduce(0, +)
        let magnitudeA = sqrt(a.map { $0 * $0 }.reduce(0, +))
        let magnitudeB = sqrt(b.map { $0 * $0 }.reduce(0, +))
        return dotProduct / (magnitudeA * magnitudeB)
    }
}
