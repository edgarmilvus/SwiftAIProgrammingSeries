
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Vision
import UIKit // For UIImage

@available(iOS 18.0, *)
actor ImageClassifier {
    private let imageRequestHandler: VNImageRequestHandler

    init(image: UIImage) throws {
        guard let cgImage = image.cgImage else {
            throw ImageClassifierError.invalidImage
        }
        self.imageRequestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
    }

    // A simple error enum for demonstration
    enum ImageClassifierError: Error {
        case invalidImage
        case classificationFailed(Error)
        case noResults
    }

    func classifyImage() async throws -> [VNClassificationObservation] {
        let request = VNClassifyImageRequest()

        // Use a TaskGroup or directly await if a modern async API is available.
        // For older APIs, wrap the completion handler in a continuation.
        try await withCheckedThrowingContinuation { continuation in
            do {
                try imageRequestHandler.perform([request])
                if let observations = request.results as? [VNClassificationObservation] {
                    continuation.resume(returning: observations)
                } else {
                    continuation.resume(throwing: ImageClassifierError.noResults)
                }
            } catch {
                continuation.resume(throwing: ImageClassifierError.classificationFailed(error))
            }
        }
    }
}

@available(iOS 18.0, *)
func processImageAsync(image: UIImage) async {
    do {
        let classifier = try ImageClassifier(image: image)
        let classifications = try await classifier.classifyImage()

        print("Image Classifications:")
        for observation in classifications.prefix(5) { // Show top 5
            print("  \(observation.identifier) (Confidence: \(observation.confidence * 100.0)%)")
        }
    } catch {
        print("Error classifying image: \(error.localizedDescription)")
    }
}
