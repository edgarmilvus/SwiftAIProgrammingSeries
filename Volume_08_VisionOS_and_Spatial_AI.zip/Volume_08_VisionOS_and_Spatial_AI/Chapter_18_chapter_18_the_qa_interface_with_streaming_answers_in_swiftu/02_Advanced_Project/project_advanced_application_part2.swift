
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import Observation
import Foundation

// MARK: - Models

/// Represents the various states a single message can inhabit during its lifecycle.
enum MessageStatus: Sendable, Equatable {
    case sending
    case thinking // The model is processing (e.g., RAG retrieval or reasoning)
    case streaming(progress: Double) // Currently receiving tokens
    case completed
    case error(String)
}

/// A thread-safe, Sendable model representing a single interaction in the chat.
struct ChatMessage: Identifiable, Sendable {
    let id: UUID
    let role: MessageRole
    var content: String
    var status: MessageStatus
    
    enum MessageRole: String, Sendable {
        case user
        case assistant
    }
    
    init(id: UUID = UUID(), role: MessageRole, content: String = "", status: MessageStatus = .completed) {
        self.id = id
        self.role = role
        self.content = content
        self.status = status
    }
}

/// Custom errors for the streaming pipeline.
enum StreamingError: Error, LocalizedError {
    case invalidURL
    case networkError(Error)
    case decodingError
    case serverError(String)
    
    var errorDescription: String? {
        switch self {
        case .invalidURL: return "The API endpoint is invalid."
        case .networkError(let error): return "Network error: \(error.localizedDescription)"
        case .decodingError: return "Failed to parse the response from the AI."
        case .serverError(let msg): return "Server error: \(msg)"
        }
    }
}

// MARK: - Service Layer (The Engine)

/// An Actor responsible for managing the network connection and parsing the SSE stream.
/// Using an actor ensures that the internal state of the stream is protected from data races.
actor StreamingService {
    private let apiKey: String
    private let endpoint = URL(string: "https://api.openai.com/v1/chat/completions")!
    
    init(apiKey: String) {
        self.apiKey = apiKey
    }
    
    /// Streams content from the LLM using Server-Sent Events (SSE).
    /// - Parameter prompt: The user's input string.
    /// - Returns: An AsyncStream of strings representing the incoming tokens.
    func streamResponse(for prompt: String) -> AsyncThrowingStream<String, Error> {
        AsyncThrowingStream { continuation in
            Task {
                do {
                    var request = URLRequest(url: endpoint)
                    request.httpMethod = "POST"
                    request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    
                    let payload: [String: Any] = [
                        "model": "gpt-4o",
                        "messages": [["role": "user", "content": prompt]],
                        "stream": true
                    ]
                    request.httpBody = try JSONSerialization.data(withJSONObject: payload)
                    
                    let (bytes, response) = try await URLSession.shared.bytes(for: request)
                    
                    guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                        continuation.finish(throwing: StreamingError.serverError("Invalid HTTP status"))
                        return
                    }
                    
                    // Iterate over the lines of the byte stream
                    for try await line in bytes.lines {
                        // SSE format: "data: { ... }"
                        if line.hasPrefix("data: ") {
                            let dataString = line.dropFirst(6).trimmingCharacters(in: .whitespaces)
                            
                            // Check for the end of the stream
                            if dataString == "[DONE]" {
                                continuation.finish()
                                return
                            }
                            
                            // Parse the JSON chunk
                            if let data = dataString.data(using: .utf8),
                                let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                                let choices = json["choices"] as? [[String: Any]],
                                let delta = choices.first?["delta"] as? [String: Any],
                                let content = delta["content"] as? String {
                                
                                continuation.yield(content)
                            }
                        }
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
        }
    }
}

// MARK: - ViewModel Layer

/// The ViewModel manages the UI state and orchestrates the interaction between the Service and the View.
@Observable
@MainActor
final class ChatViewModel {
    /// The list of messages displayed in the UI.
    var messages: [ChatMessage] = []
    /// Tracks if the assistant is currently generating a response.
    var isProcessing: Bool = false
    /// The current input text from the user.
    var inputText: String = ""
    
    private let service: StreamingService
    
    init(service: StreamingService) {
        self.service = service
    }
    
    /// Sends a new message and begins the streaming process.
    func sendMessage() async {
        let userPrompt = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !userPrompt.isEmpty else { return }
        
        // 1. Add User Message
        let userMsg = ChatMessage(role: .user, content: userPrompt)
        messages.append(userMsg)
        inputText = ""
        isProcessing = true
        
        // 2. Prepare Assistant Message Placeholder
        let assistantMsgId = UUID()
        let assistantMsg = ChatMessage(id: assistantMsgId, role: .assistant, content: "", status: .thinking)
        messages.append(assistantMsg)
        
        // 3. Start Streaming
        do {
            let stream = await service.streamResponse(for: userPrompt)
            
            // Update status to streaming
            updateMessageStatus(id: assistantMsgId, status: .streaming(progress: 0.0))
            
            var accumulatedContent = ""
            
            for try await token in stream {
                accumulatedContent += token
                // Update the message content in the array
                if let index = messages.firstIndex(where: { $0.id == assistantMsgId }) {
                    messages[index].content = accumulatedContent
                    messages[index].status = .streaming(progress: 1.0) // In a real app, calculate actual progress
                }
            }
            
            // 4. Mark as completed
            updateMessageStatus(id: assistantMsgId, status: .completed)
            
        } catch {
            // 5. Handle Errors
            updateMessageStatus(id: assistantMsgId, status: .error(error.localizedDescription))
        }
        
        isProcessing = false
    }
    
    /// Helper to update the status of a specific message safely on the MainActor.
    private func updateMessageStatus(id: UUID, status: MessageStatus) {
        if let index = messages.firstIndex(where: { $0.id == id }) {
            messages[index].status = status
        }
    }
}

// MARK: - View Layer

/// The primary SwiftUI view for the Q&A interface.
struct ChatInterfaceView: View {
    @State private var viewModel: ChatViewModel
    @Namespace private var chatNamespace
    
    init(apiKey: String) {
        let service = StreamingService(apiKey: apiKey)
        _viewModel = State(initialValue: ChatViewModel(service: service))
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            headerView
            
            // Chat Messages List
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 16) {
                        ForEach(viewModel.messages) { message in
                            MessageBubble(message: message)
                                .id(message.id)
                                .transition(.asymmetric(insertion: .opacity.combined(with: .move(edge: .bottom)), removal: .opacity))
                        }
                    }
                    .padding()
                }
                .onChange(of: viewModel.messages.last?.content) { _, _ in
                    // Auto-scroll to bottom when new content arrives
                    if let lastId = viewModel.messages.last?.id {
                        withAnimation(.easeOut(duration: 0.2)) {
                            proxy.scrollTo(lastId, anchor: .bottom)
                        }
                    }
                }
            }
            
            // Input Area
            inputArea
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .ignoresSafeArea(edges: .bottom)
    }
    
    private var headerView: some View {
        HStack {
            Text("Research Assistant")
                .font(.headline)
            Spacer()
            if viewModel.isProcessing {
                ProgressView()
                    .controlSize(.small)
            }
        }
        .padding()
        .background(.ultraThinMaterial)
    }
    
    private var inputArea: some View {
        VStack(spacing: 0) {
            Divider()
            HStack(alignment: .bottom) {
                TextField("Ask a complex question...", text: $viewModel.inputText, axis: .vertical)
                    .padding(12)
                    .background(Color(uiColor: .secondarySystemBackground))
                    .cornerRadius(20)
                    .lineLimit(1...5)
                
                Button {
                    Task { await viewModel.sendMessage() }
                } label: {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.system(size: 32))
                        .symbolRenderingMode(.hierarchical)
                }
                .disabled(viewModel.inputText.isEmpty || viewModel.isProcessing)
                .padding(.bottom, 4)
            }
            .padding()
            .background(.background)
        }
    }
}

/// A component representing a single message bubble.
struct MessageBubble: View {
    let message: ChatMessage
    
    var body: some View {
        HStack {
            if message.role == .user { Spacer() }
            
            VStack(alignment: message.role == .user ? .trailing : .leading, spacing: 4) {
                contentView
                    .padding(12)
                    .background(message.role == .user ? Color.blue : Color(uiColor: .tertiarySystemBackground))
                    .foregroundColor(message.role == .user ? .white : .primary)
                    .cornerRadius(16)
                
                statusView
            }
            
            if message.role == .assistant { Spacer() }
        }
    }
    
    @ViewBuilder
    private var contentView: some View {
        if message.content.isEmpty && message.status == .thinking {
            Text("Thinking...")
                .italic()
                .font(.subheadline)
        } else {
            Text(message.content)
                .font(.body)
        }
    }
    
    @ViewBuilder
    private var statusView: some View {
        switch message.status {
        case .streaming:
            Text("Typing...")
                .font(.caption2)
                .foregroundColor(.secondary)
        case .error(let error):
            Text(error)
                .font(.caption2)
                .foregroundColor(.red)
        default:
            EmptyView()
        }
    }
}

#Preview {
    ChatInterfaceView(apiKey: "your_api_key_here")
}
