/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { useMemo } from 'react';
import { ViewStyle } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Dimensions } from 'react-native';

// Type definition for the external device config object
type DeviceConfig = {
  hasNotch: boolean;
  density: number;
};

/**
 * Type guard for DeviceConfig.
 * Enables type narrowing: if this returns true, TypeScript knows obj is DeviceConfig.
 */
export function isDeviceConfig(obj: unknown): obj is DeviceConfig {
  return (
    typeof obj === 'object' &&
    obj !== null &&
    'hasNotch' in obj && typeof (obj as any).hasNotch === 'boolean' &&
    'density' in obj && typeof (obj as any).density === 'number'
  );
}

/**
 * AI PROMPT STRATEGY (Commentary):
 * "Create a React Native hook named 'useSafeAreaLayout' using TypeScript.
 * It should import 'useSafeAreaInsets' from 'react-native-safe-area-context'.
 * Return an object with three style properties:
 * 1. containerStyle: Applies paddingTop and paddingBottom based on insets.
 * 2. centeredContentStyle: Calculates maxHeight as screen height minus top and bottom insets.
 * 3. scrollContainerStyle: Applies paddingBottom based on insets.
 * Ensure all styles are strictly typed as ViewStyle."
 */

export const useSafeAreaLayout = () => {
  const insets = useSafeAreaInsets();
  const { height: screenHeight } = Dimensions.get('window');

  // Conceptual: Simulate fetching config from an async source
  const deviceConfig: unknown = { hasNotch: true, density: 2.0 }; 

  // Calculate dynamic margin based on density if config is valid
  let extraMargin = 0;
  if (isDeviceConfig(deviceConfig)) {
    // Type narrowing allows safe access to .density
    if (deviceConfig.density > 2.0) extraMargin = 4; 
  }

  const containerStyle: ViewStyle = useMemo(() => ({
    paddingTop: insets.top,
    paddingBottom: insets.bottom,
  }), [insets.top, insets.bottom]);

  const centeredContentStyle: ViewStyle = useMemo(() => ({
    // Max height is screen height minus safe areas and any extra margins
    maxHeight: screenHeight - insets.top - insets.bottom - extraMargin,
    justifyContent: 'center',
  }), [screenHeight, insets.top, insets.bottom, extraMargin]);

  const scrollContainerStyle: ViewStyle = useMemo(() => ({
    paddingBottom: insets.bottom,
  }), [insets.bottom]);

  return {
    containerStyle,
    centeredContentStyle,
    scrollContainerStyle,
  };
};
