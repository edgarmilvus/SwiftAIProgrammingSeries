
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Observation // For @Observable

@available(iOS 18.0, *)
@Observable class AIOutputViewModel {
    var currentPrediction: TextClassifierOutput?
    var isLoading: Bool = false
    var errorMessage: String?

    private let predictor: MyTextModel
    private let manager: PredictionManager // Our actor for state management

    init(predictor: MyTextModel, manager: PredictionManager) {
        self.predictor = predictor
        self.manager = manager
    }

    @MainActor // Ensure UI updates happen on the main actor
    func performPrediction(for input: String) async {
        isLoading = true
        errorMessage = nil
        do {
            let output = try await predictor.predict(input: input)
            await manager.updateLatestPrediction(output: output) // Update actor state
            currentPrediction = await manager.getLatestPrediction() // Retrieve latest from actor
        } catch {
            errorMessage = error.localizedDescription
            currentPrediction = nil
        }
        isLoading = false
    }

    // A computed property to easily access confidence for a specific class
    var positiveConfidence: Double {
        currentPrediction?.confidenceScores["positive"] ?? 0.0
    }

    // A computed property for a full distribution array, useful for charts
    var distributionData: [(String, Double)] {
        currentPrediction?.confidenceScores.sorted { $0.1 > $1.1 } ?? []
    }
}

@available(iOS 18.0, *)
struct ConfidenceView: View {
    @State private var textInput: String = ""
    @State private var viewModel: AIOutputViewModel // ViewModel is @Observable

    init(predictor: MyTextModel, manager: PredictionManager) {
        _viewModel = State(initialValue: AIOutputViewModel(predictor: predictor, manager: manager))
    }

    var body: some View {
        VStack {
            TextField("Enter text", text: $textInput)
                .textFieldStyle(.roundedBorder)
                .padding()

            Button("Predict") {
                Task {
                    await viewModel.performPrediction(for: textInput)
                }
            }
            .disabled(viewModel.isLoading)

            if viewModel.isLoading {
                ProgressView()
            } else if let prediction = viewModel.currentPrediction {
                Text("Prediction: \(prediction.prediction)")
                    .font(.headline)
                    .padding(.top)

                // Animate the confidence score
                // SwiftUI automatically observes changes to `positiveConfidence`
                // and animates the Text or Gauge accordingly.
                Text("Positive Confidence: \(prediction.confidenceScores["positive"] ?? 0.0, format: .percent)")
                    .font(.subheadline)
                    .animation(.easeInOut(duration: 0.5), value: viewModel.positiveConfidence) // Explicit animation

                // Example for a Gauge (new in iOS 16)
                Gauge(value: viewModel.positiveConfidence) {
                    Text("Positive")
                } currentValueLabel: {
                    Text(viewModel.positiveConfidence, format: .percent)
                }
                .gaugeStyle(.linearCapacity)
                .tint(.green)
                .padding()
                .animation(.easeInOut(duration: 0.5), value: viewModel.positiveConfidence) // Animate Gauge value

                // Visualize the full distribution (e.g., a simple bar chart)
                VStack(alignment: .leading) {
                    Text("Probability Distribution:")
                        .font(.caption)
                    ForEach(viewModel.distributionData, id: \.0) { (label, score) in
                        HStack {
                            Text(label)
                                .frame(width: 80, alignment: .leading)
                            ProgressView(value: score)
                                .progressViewStyle(.linear)
                                .tint(score > 0.8 ? .blue : .gray)
                                .animation(.easeInOut(duration: 0.3), value: score) // Animate individual bar
                        }
                    }
                }
                .padding()

            } else if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
            }
        }
    }
}

// Package.swift for demonstrating dependencies
/*
// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "AIAppCore",
    platforms: [.iOS(.v18), .macOS(.v15)], // Or appropriate versions for @Observable, async/await
    products: [
        .library(
            name: "AIAppCore",
            targets: ["AIAppCore"]),
    ],
    dependencies: [
        // No explicit dependencies for these core Swift features
    ],
    targets: [
        .target(
            name: "AIAppCore",
            dependencies: []),
        .testTarget(
            name: "AIAppCoreTests",
            dependencies: ["AIAppCore"]),
    ]
)
*/
