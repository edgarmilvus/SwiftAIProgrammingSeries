
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import CoreData

@available(iOS 18.0, *)
public final class Tenant: NSManagedObject, Sendable {
    @NSManaged public var id: UUID
    @NSManaged public var name: String
    @NSManaged public var workspaces: NSSet? // Relationship to Workspaces
}

@available(iOS 18.0, *)
public final class Workspace: NSManagedObject, Sendable {
    @NSManaged public var id: UUID
    @NSManaged public var tenant: Tenant?
    @NSManaged public var name: String
    @NSManaged public var semanticChunks: NSSet? // Relationship to SemanticChunks
}

@available(iOS 18.0, *)
public final class SemanticChunk: NSManagedObject, Sendable, Codable {
    @NSManaged public var id: UUID
    @NSManaged public var embedding: Data // Stored as binary for vector data
    @NSManaged public var rawText: String
    @NSManaged public var createdAt: Date
    @NSManaged public var category: String
    @NSManaged public var workspace: Workspace?

    // Codable implementation for transferring chunks across network/threads
    enum CodingKeys: String, CodingKey {
        case id, embedding, rawText, createdAt, category
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(embedding, forKey: .embedding)
        try container.encode(rawText, forKey: .rawText)
        try container.encode(createdAt, forKey: .createdAt)
        try container.encode(category, forKey: .category)
    }
    
    // Note: Decodable would be implemented similarly for ingestion
}

// MARK: - Schema Configuration Helper
@available(iOS 18.0, *)
struct SchemaValidator {
    /// Demonstrates how the relationship should be configured in the .xcdatamodeld
    func validateCascadeRules() {
        print("Requirement: Workspace -> SemanticChunk relationship must have 'Delete Rule: Cascade'")
        print("Requirement: Tenant -> Workspace relationship must have 'Delete Rule: Cascade'")
    }
}
