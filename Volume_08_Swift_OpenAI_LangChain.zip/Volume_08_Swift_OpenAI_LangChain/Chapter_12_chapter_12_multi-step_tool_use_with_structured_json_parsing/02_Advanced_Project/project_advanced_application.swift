
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Observation

// MARK: - Dependencies (Package.swift equivalent)
/*
 dependencies: [
    .package(url: "https://github.com/openai/openai-swift", from: "1.0.0"),
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
 ]
*/

/// Represents the status of a tool execution within the agentic loop.
enum ToolExecutionResult: Sendable {
    case success(json: String)
    case failure(error: String)
}

/// A protocol defining the requirements for a tool that an LLM can invoke.
/// Using `Sendable` ensures compatibility with Swift 6 concurrency.
protocol AgentTool: Sendable {
    /// The unique identifier for the tool, matching the LLM's tool name.
    var name: String { get }
    
    /// A detailed description of what the tool does, used to prime the LLM.
    var toolDescription: String { get }
    
    /// The JSON schema defining the expected arguments.
    var argumentSchema: [String: AnySendable] { get }
    
    /// The asynchronous execution logic.
    func execute(arguments: [String: AnySendable]) async throws -> ToolExecutionResult
}

/// A type-erased wrapper to allow heterogeneous dictionaries in tool schemas.
struct AnySendable: Sendable {
    let value: Sendable
    init(_ value: Sendable) { self.value = value }
}

// MARK: - Domain Models

/// Represents the structured output of a weather check.
struct WeatherReport: Codable, Sendable {
    let temperature: Double
    let condition: String
    let isClear: Bool
}

/// Represents the structured output of a calendar check.
struct CalendarEvent: Codable, Sendable {
    let title: String
    let startTime: Date
    let endTime: Date
}

// MARK: - Concrete Tool Implementations

/// A tool for fetching weather data.
/// In a real app, this would call a REST API like OpenWeatherMap.
final class WeatherTool: AgentTool, @unchecked Sendable {
    let name = "get_weather"
    let toolDescription = "Fetches the weather for a specific location and date. Returns temperature and clarity."
    let argumentSchema: [String: AnySendable] = [
        "location": AnySendable("The city name"),
        "date": AnySendable("ISO8601 date string")
    ]

    func execute(arguments: [String: AnySendable]) async throws -> ToolExecutionResult {
        // Simulate network latency
        try await Task.sleep(for: .seconds(1))
        
        // In production, parse arguments and call API
        // For demonstration, we return a hardcoded successful JSON
        let report = WeatherReport(temperature: 22.5, condition: "Sunny", isClear: true)
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        let data = try encoder.encode(report)
        
        return .success(json: String(data: data, encoding: .utf8) ?? "{}")
    }
}

/// A tool for checking user availability.
final class CalendarTool: AgentTool, @unchecked Sendable {
    let name = "check_calendar"
    let toolDescription = "Checks for existing appointments in the user's calendar for a given date."
    let argumentSchema: [String: AnySendable] = [
        "date": AnySendable("ISO8601 date string")
    ]

    func execute(arguments: [String: AnySendable]) async throws -> ToolExecutionResult {
        try await Task.sleep(for: .seconds(1))
        
        // Simulate finding one meeting
        let event = CalendarEvent(title: "Project Sync", startTime: Date(), endTime: Date().addingTimeInterval(3600))
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode([event])
        
        return .success(json: String(data: data, encoding: .utf8) ?? "[]")
    }
}

// MARK: - The Agent Engine

/// The `TravelAgent` manages the multi-step reasoning loop.
/// It is an `actor` to protect the `messages` history from concurrent access.
@available(iOS 18.0, macOS 15.0, *)
actor TravelAgent {
    
    private var messages: [[String: Sendable]] = []
    private let tools: [String: any AgentTool]
    private let modelName: String = "gpt-4o"
    
    /// Initializes the agent with a set of available tools.
    /// - Parameter availableTools: A collection of tools the agent can use.
    init(availableTools: [any AgentTool]) {
        var toolMap: [String: any AgentTool] = [:]
        for tool in availableTools {
            toolMap[tool.name] = tool
        }
        self.tools = toolMap
        
        // Initialize system prompt
        self.messages = [[
            "role": "system",
            "content": "You are a sophisticated travel assistant. Use tools to gather information before making recommendations. If a tool returns an error, explain it to the user or try an alternative approach."
        ]]
    }
    
    /// The primary entry point for the user.
    /// This method initiates the ReAct loop.
    func process(query: String) async throws -> String {
        // 1. Add user query to history
        messages.append(["role": "user", "content": query])
        
        // 2. Enter the reasoning loop
        return try await runReasoningLoop()
    }
    
    /// The core loop that implements the 'Reasoning + Acting' pattern.
    private func runReasoningLoop() async throws -> String {
        // Limit loop iterations to prevent infinite recursion/token drain
        let maxIterations = 5
        
        for _ in 0..<maxIterations {
            // A. Call the LLM with current context
            let response = try await callLLM()
            
            // B. Check if the LLM wants to use a tool
            if let toolCalls = response.toolCalls, !toolCalls.isEmpty {
                // Add the assistant's tool call message to history
                messages.append(response.asMessage())
                
                // C. Execute all requested tools
                for toolCall in toolCalls {
                    let result = await executeTool(toolCall)
                    
                    // D. Append the tool's observation to history
                    messages.append([
                        "role": "tool",
                        "tool_call_id": toolCall.id,
                        "content": result
                    ])
                }
                // Continue loop to let LLM "observe" results
                continue
            } else {
                // No more tools requested; return the final text content
                return response.content ?? "I'm sorry, I couldn't process that."
            }
        }
        
        throw AgentError.maxIterationsReached
    }
    
    /// Maps the LLM's tool call request to a concrete Swift tool execution.
    private func executeTool(_ toolCall: LLMToolCall) async -> String {
        guard let tool = tools[toolCall.function.name] else {
            return "Error: Tool \(toolCall.function.name) not found."
        }
        
        do {
            // In a real implementation, we would parse toolCall.function.arguments (JSON string)
            // into the [String: AnySendable] dictionary required by the tool.
            let arguments = try parseArguments(toolCall.function.arguments)
            let result = try await tool.execute(arguments: arguments)
            
            switch result {
            case .success(let json):
                return json
            case .failure(let error):
                return "Error executing \(tool.name): \(error)"
            }
        } catch {
            return "Error parsing arguments for \(tool.name): \(error.localizedDescription)"
        }
    }
    
    /// Mock function representing the network call to OpenAI.
    /// In a production app, this uses URLSession and decodes the OpenAI response.
    private func callLLM() async throws -> LLMResponse {
        // This is where the actual OpenAI API integration happens.
        // We simulate a multi-step response for the sake of this demonstration.
        // Step 1: LLM decides to call weather.
        // Step 2: LLM decides to call calendar.
        // Step 3: LLM provides final answer.
        
        // For the purpose of this code block, we'll simulate the logic.
        // In a real implementation, this would be a network request.
        return try await simulateLLMBehavior()
    }
    
    private func parseArguments(_ jsonString: String) throws -> [String: AnySendable] {
        // Real implementation would use JSONDecoder
        return [:] 
    }
    
    enum AgentError: Error {
        case maxIterationsReached
        case apiError(String)
    }
}

// MARK: - OpenAI Simulation Models

/// Internal representation of the LLM's response.
struct LLMResponse: Sendable {
    let content: String?
    let toolCalls: [LLMToolCall]?
    
    func asMessage() -> [String: Sendable] {
        var msg: [String: Sendable] = ["role": "assistant"]
        if let content = content { msg["content"] = content }
        if let toolCalls = toolCalls { msg["tool_calls"] = toolCalls }
        return msg
    }
}

struct LLMToolCall: Sendable {
    let id: String
    let function: LLMFunction
}

struct LLMFunction: Sendable {
    let name: String
    let arguments: String
}

// MARK: - Simulation Logic (For Demonstration)

extension TravelAgent {
    /// Simulates the stateful progression of an LLM through multiple turns.
    private func simulateLLMBehavior() async throws -> LLMResponse {
        // This simulates the "Brain" of the agent.
        // In reality, this is purely the result of the OpenAI API.
        
        // We use a static counter or check the 'messages' to decide what to return.
        let turnCount = messages.count
        
        if turnCount == 2 { // First turn: User asked question
            return LLMResponse(
                content: nil,
                toolCalls: [LLMToolCall(id: "call_1", function: LLMFunction(name: "get_weather", arguments: "{\"location\": \"Tokyo\"}"))]
            )
        } else if turnCount == 4 { // Second turn: Weather result returned
            return LLMResponse(
                content: nil,
                toolCalls: [LLMToolCall(id: "call_2", function: LLMFunction(name: "check_calendar", arguments: "{\"date\": \"2025-05-20\"}"))]
            )
        } else if turnCount == 6 { // Third turn: Calendar result returned
            return LLMResponse(
                content: "Based on the clear weather in Tokyo and your free schedule, I recommend visiting the Shibuya Crossing in the morning!",
                toolCalls: nil
            )
        }
        
        return LLMResponse(content: "I'm not sure how to help.", toolCalls: nil)
    }
}

// MARK: - Application Entry Point

@main
struct AgentApp {
    static func main() async {
        print("🚀 Initializing Advanced Multi-Step Agent...")
        
        let weather = WeatherTool()
        let calendar = CalendarTool()
        
        let agent = TravelAgent(availableTools: [weather, calendar])
        
        do {
            let query = "Plan a trip to Tokyo for next Tuesday. Check the weather and my calendar."
            print("👤 User: \(query)")
            
            let response = try await agent.process(query: query)
            
            print("\n🤖 Agent: \(response)")
        } catch {
            print("❌ Error: \(error)")
        }
    }
}
