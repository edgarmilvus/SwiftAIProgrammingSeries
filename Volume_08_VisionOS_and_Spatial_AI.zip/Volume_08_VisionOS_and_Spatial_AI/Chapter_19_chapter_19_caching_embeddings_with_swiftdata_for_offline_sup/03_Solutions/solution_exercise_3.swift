
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import SwiftData

struct SearchResult {
    let chunk: TextChunk
    let score: Float
}

actor VectorSearchEngine {
    private let container: ModelContainer

    init(container: ModelContainer) {
        self.container = container
    }

    func findNearestNeighbors(to queryVector: [Float], limit: Int) async throws -> [TextChunk] {
        let context = ModelContext(container)
        
        // 1. Fetch all relevant chunks
        let descriptor = FetchDescriptor<TextChunk>()
        let allChunks = try context.fetch(descriptor)
        
        // 2. Calculate Similarity and 3. Rank
        let scoredResults = allChunks.compactMap { chunk -> SearchResult? in
            let similarity = cosineSimilarity(queryVector, chunk.embedding)
            return SearchResult(chunk: chunk, score: similarity)
        }
        .sorted { $0.score > $1.score } // Descending order
        .prefix(limit)
        
        return scoredResults.map { $0.chunk }
    }

    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count, a.count > 0 else { return 0 }
        
        let dotProduct = zip(a, b).map(*).reduce(0, +)
        let magnitudeA = sqrt(a.map { $0 * $0 }.reduce(0, +))
        let magnitudeB = sqrt(b.map { $0 * $0 }.reduce(0, +))
        
        guard magnitudeA > 0 && magnitudeB > 0 else { return 0 }
        return dotProduct / (magnitudeA * magnitudeB)
    }
}

// Extension for performance-oriented math
extension Array where Element == Float {
    func dotProduct(_ other: [Float]) -> Float {
        precondition(self.count == other.count)
        return zip(self, other).map(*).reduce(0, +)
    }
}
