
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import BackgroundTasks
import UIKit // For AppDelegate context

// MARK: - Helper Logger (for all exercises)
struct Logger {
    static func log(_ message: String, category: String = "BackgroundTasks", isError: Bool = false) {
        let timestamp = DateFormatter.localizedString(from: Date(), dateStyle: .medium, timeStyle: .medium)
        let level = isError ? "ERROR" : "INFO"
        print("[\(timestamp)] [\(category)] [\(level)] \(message)")
    }
}

// MARK: - Mock API Service (for Exercise 1 & 2)
struct MockAPI {
    static let shared = MockAPI()

    enum APIError: Error {
        case invalidURL
        case networkError(Error)
        case decodingError(Error)
        case serverError(statusCode: Int)
        case cancelled
    }

    // Simulate fetching a knowledge base dataset
    func fetchKnowledgeBase() async throws -> [KnowledgeItem] {
        Logger.log("Simulating fetching knowledge base...", category: "MockAPI")
        try await Task.sleep(nanoseconds: 1_500_000_000) // Simulate network delay
        if Task.isCancelled { throw APIError.cancelled }

        let jsonString = """
        [
            {"id": "doc1", "content": "Swift is a powerful and intuitive programming language."},
            {"id": "doc2", "content": "BackgroundTasks framework enables apps to perform work in the background."},
            {"id": "doc3", "content": "Core ML allows integrating machine learning models into your apps."}
        ]
        """
        guard let data = jsonString.data(using: .utf8) else {
            let error = NSError(domain: "MockAPI", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to encode JSON string"])
            Logger.log("Failed to encode knowledge base JSON string: \(error.localizedDescription)", category: "MockAPI", isError: true)
            throw APIError.decodingError(error)
        }

        do {
            let items = try JSONDecoder().decode([KnowledgeItem].self, from: data)
            Logger.log("Knowledge base fetched successfully with \(items.count) items.", category: "MockAPI")
            return items
        } catch {
            Logger.log("Failed to decode knowledge base: \(error.localizedDescription)", category: "MockAPI", isError: true)
            throw APIError.decodingError(error)
        }
    }
    // Other mock API methods would go here for subsequent exercises
    // ...
}

// MARK: - Models for Exercise 2
struct KnowledgeItem: Codable, Hashable {
    let id: String
    let content: String
}

// MARK: - AppDelegate / SceneDelegate context
class AppDelegate: UIResponder, UIApplicationDelegate {

    // MARK: - Background Task Identifiers
    static let knowledgeSyncTaskIdentifier = "com.example.app.syncKnowledge"
    // Other task identifiers for subsequent exercises would go here
    // ...

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        Logger.log("App finished launching.", category: "AppDelegate")
        registerBackgroundTasks() // Register all background tasks
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        Logger.log("App entered background. Scheduling tasks...", category: "AppDelegate")
        scheduleKnowledgeSync() // Schedule the knowledge sync task
        // Other task scheduling for subsequent exercises would go here
        // ...
    }

    // MARK: - Task Registration
    private func registerBackgroundTasks() {
        Logger.log("Registering background tasks...", category: "BGTaskScheduler")

        // Exercise 2: Processing Task (Knowledge Sync)
        BGTaskScheduler.shared.register(forIdentifier: AppDelegate.knowledgeSyncTaskIdentifier, using: nil) { task in
            Logger.log("Received BGProcessingTask: \(task.identifier)", category: "BGTaskScheduler")
            self.handleKnowledgeSync(task: task as! BGProcessingTask)
        }
        // Other task registrations for subsequent exercises would go here
        // ...
    }

    // MARK: - Task Scheduling
    private func scheduleKnowledgeSync() {
        let request = BGProcessingTaskRequest(identifier: AppDelegate.knowledgeSyncTaskIdentifier)
        request.requiresNetworkAccess = true
        request.requiresExternalPower = false // Lightweight sync
        request.earliestBeginDate = Date(timeIntervalSinceNow: 30 * 60) // Try every 30 minutes

        do {
            try BGTaskScheduler.shared.submit(request)
            Logger.log("Scheduled BGProcessingTask for \(AppDelegate.knowledgeSyncTaskIdentifier)", category: "BGTaskScheduler")
        } catch {
            Logger.log("Could not schedule knowledge sync task: \(error.localizedDescription)", category: "BGTaskScheduler", isError: true)
        }
    }

    // MARK: - Task Handlers

    // Exercise 2: Local Knowledge Base Pre-Synchronization Handler
    private func handleKnowledgeSync(task: BGProcessingTask) {
        Logger.log("Starting knowledge base synchronization task...", category: "KnowledgeSync")

        // Create a new Task to perform asynchronous work.
        let backgroundTask = Task {
            do {
                // Set the expiration handler immediately.
                task.expirationHandler = {
                    Logger.log("Knowledge sync task expired. Cancelling...", category: "KnowledgeSync", isError: true)
                    backgroundTask.cancel() // Cancel the async Task
                    task.setTaskCompleted(success: false)
                }

                // Simulate fetching knowledge base data
                let knowledgeItems = try await MockAPI.shared.fetchKnowledgeBase()

                // Simulate storing data locally (e.g., in UserDefaults)
                let encoder = JSONEncoder()
                if let encoded = try? encoder.encode(knowledgeItems) {
                    UserDefaults.standard.set(encoded, forKey: "localKnowledgeBase")
                    Logger.log("Successfully stored \(knowledgeItems.count) knowledge items locally.", category: "KnowledgeSync")
                } else {
                    Logger.log("Failed to encode and store knowledge items.", category: "KnowledgeSync", isError: true)
                    throw MockAPI.APIError.decodingError(NSError(domain: "KnowledgeSync", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to encode for UserDefaults"]))
                }

                Logger.log("Knowledge base synchronization completed successfully.", category: "KnowledgeSync")
                task.setTaskCompleted(success: true)

            } catch {
                if let apiError = error as? MockAPI.APIError, apiError == .cancelled {
                    Logger.log("Knowledge sync task was cancelled.", category: "KnowledgeSync", isError: true)
                } else {
                    Logger.log("Knowledge sync failed: \(error.localizedDescription)", category: "KnowledgeSync", isError: true)
                }
                task.setTaskCompleted(success: false)
            }
        }
    }
    // Other task handlers for subsequent exercises would go here
    // ...
}

/*
// --- Info.plist Configuration ---
// Add the following key-value pair to your app's Info.plist file:
//
// <key>BGTaskSchedulerPermittedIdentifiers</key>
// <array>
//     <string>com.example.app.syncKnowledge</string>
//     <!-- Add other identifiers here -->
// </array>
*/
