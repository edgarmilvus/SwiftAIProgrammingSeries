
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import ARKit
import RealityKit

@available(visionOS 1.0, *)
enum IntentLevel {
    case scanning
    case investigating
    case targeting
}

struct GazePoint: Sendable {
    let position: SIMD3<Float>
    let timestamp: TimeInterval
}

@available(visionOS 1.0, *)
@MainActor
class IntentEngine: ObservableObject {
    @Published var currentIntent: IntentLevel = .scanning
    @Published var smoothedGazePosition: SIMD3<Float> = .zero
    
    private var gazeHistory: [GazePoint] = []
    private let windowSize = 15 // Increased window for smoother filtering
    private let velocityThreshold: Float = 0.05 // Angular velocity threshold
    private let fixationThreshold: TimeInterval = 0.3 // 300ms for intent
    
    private var lastFixationStartTime: TimeInterval = 0
    
    func processNewGaze(rawPosition: SIMD3<Float>, timestamp: TimeInterval) {
        let newPoint = GazePoint(position: rawPosition, timestamp: timestamp)
        gazeHistory.append(newPoint)
        
        // 1. Maintain Window Size
        if gazeHistory.count > windowSize {
            gazeHistory.removeFirst()
        }
        
        // 2. Moving Average Filter (Smoothing)
        let averagePosition = calculateMovingAverage()
        self.smoothedGazePosition = averagePosition
        
        // 3. Velocity and Intent Calculation
        calculateIntent(newPoint: newPoint)
    }
    
    private func calculateMovingAverage() -> SIMD3<Float> {
        let sum = gazeHistory.reduce(SIMD3<Float>.zero) { $0 + $1.position }
        return sum / Float(gazeHistory.count)
    }
    
    private func calculateIntent(newPoint: GazePoint) {
        guard gazeHistory.count >= 2 else { return }
        
        let prevPoint = gazeHistory[gazeHistory.count - 2]
        let distance = distance(newPoint.position, prevPoint.position)
        let deltaTime = Float(newPoint.timestamp - prevPoint.timestamp)
        
        // Calculate instantaneous velocity
        let velocity = distance / deltaTime
        
        if velocity < velocityThreshold {
            // User is staying relatively still (Fixation)
            if lastFixationStartTime == 0 {
                lastFixationStartTime = newPoint.timestamp
            }
            
            let fixationDuration = newPoint.timestamp - lastFixationStartTime
            
            if fixationDuration > 0.8 {
                currentIntent = .targeting
            } else if fixationDuration > 0.3 {
                currentIntent = .investigating
            }
        } else {
            // Saccade detected (Rapid movement)
            currentIntent = .scanning
            lastFixationStartTime = 0
        }
    }
}

@available(visionOS 1.0, *)
struct IntentVisualizerView: View {
    @StateObject private var engine = IntentEngine()
    
    var body: some View {
        RealityView { content in
            // Scene setup...
        } update: { content in
            // Update Reticle
            // In a real app, we'd find a Reticle Entity and update its position
            // based on engine.smoothedGazePosition and color based on engine.currentIntent
        }
    }
}
