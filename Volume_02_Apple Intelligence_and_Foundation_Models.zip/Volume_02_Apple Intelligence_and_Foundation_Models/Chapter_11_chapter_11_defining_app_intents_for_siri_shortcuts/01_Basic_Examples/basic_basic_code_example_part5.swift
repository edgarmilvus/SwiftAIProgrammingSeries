
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part5.swift
// Description: Basic Code Example
// ==========================================

import AppIntents

/// The main App Intents entry point for your application.
/// This tells Siri and Shortcuts which intents your app provides.
@available(iOS 18.0, *)
struct ReminderAppIntents: AppIntentsExtension {
    // Provide an array of all the intents your app supports.
    static var allAppIntents: [AppIntent.Type] {
        [
            MarkReminderCompleteIntent.self
            // Add other intents here as you create them
        ]
    }
    
    // You can also define AppShortcuts here for specific phrases.
    // For example:
    // static var appShortcuts: [AppShortcut] {
    //     AppShortcut(
    //         intent: MarkReminderCompleteIntent(),
    //         phrases: ["Mark my reminder as complete", "I finished my reminder"]
    //     )
    // }
}
