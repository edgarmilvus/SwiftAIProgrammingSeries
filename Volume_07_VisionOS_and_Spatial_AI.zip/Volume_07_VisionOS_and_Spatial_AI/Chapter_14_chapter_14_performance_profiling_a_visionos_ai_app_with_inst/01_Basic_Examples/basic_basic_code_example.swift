
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import OSLog
import Vision
import CoreML
import RealityKit
import Combine

// MARK: - Performance Instrumentation Constants
/// A dedicated logger for performance profiling. 
/// Using a specific subsystem allows us to filter for our AI app in the Instruments 'os_log' instrument.
extension OSLog {
    static let spatialAI = OSLog(subsystem: "com.example.SpatialAIApp", category: "InferencePipeline")
}

/// A utility to wrap signpost calls, making the code cleaner and more readable.
struct PerformanceTracer {
    static let signpostID = OSSignpostID(log: .spatialAI)
    
    /// Marks the beginning of a heavy operation.
    static func startInterval(_ name: StaticString) {
        os_signpost(.begin, log: .spatialAI, name: name, signpostID: signpostID)
    }
    
    /// Marks the end of a heavy operation.
    static func endInterval(_ name: StaticString) {
        os_signpost(.end, log: .spatialAI, name: name, signpostID: signpostID)
    }
}

// MARK: - Models

/// Represents the result of an AI inference task.
/// Conforms to `Sendable` to safely pass between the Inference Actor and the MainActor.
struct RecognitionResult: Sendable {
    let label: String
    let confidence: Float
    let boundingBox: CGRect
}

// MARK: - AI Inference Engine

/// The `SpatialInferenceEngine` is an `actor`. 
/// This is critical for performance profiling: it ensures that heavy CoreML work 
/// is isolated from the Main Actor, preventing UI stutters in visionOS.
@available(visionOS 1.0, *)
actor SpatialInferenceEngine {
    
    private var model: VNCoreMLModel?
    
    init() {
        // In a real app, you would load your compiled .mlmodel here.
        // For this example, we simulate the initialization.
    }
    
    /// Performs AI inference on a provided image buffer.
    /// - Parameter pixelBuffer: The raw image data from the camera or spatial feed.
    /// - Returns: A `RecognitionResult` if an object is found.
    func performInference(on pixelBuffer: CVPixelBuffer) async throws -> RecognitionResult? {
        // 1. Start the Signpost for the entire inference pipeline.
        // In Instruments, this will appear as a custom interval in the 'Points of Interest' track.
        PerformanceTracer.startInterval("TotalInference")
        
        defer {
            // Ensure the signpost ends even if the function throws an error.
            PerformanceTracer.endInterval("TotalInference")
        }
        
        // 2. Simulate Pre-processing (e.g., resizing, color conversion)
        PerformanceTracer.startInterval("PreProcessing")
        try await Task.sleep(for: .milliseconds(15)) // Simulating work
        PerformanceTracer.endInterval("PreProcessing")
        
        // 3. Simulate CoreML Inference
        PerformanceTracer.startInterval("CoreMLInference")
        // In a real scenario, this is where the VNCoreMLRequest would be executed.
        try await Task.sleep(for: .milliseconds(45)) // Simulating heavy neural net math
        PerformanceTracer.endInterval("CoreMLInference")
        
        // 4. Post-processing (e.g., non-maximum suppression, coordinate mapping)
        PerformanceTracer.startInterval("PostProcessing")
        try await Task.sleep(for: .milliseconds(5)) // Simulating work
        PerformanceTracer.endInterval("PostProcessing")
        
        // Return a dummy result
        return RecognitionResult(
            label: "Spatial Anchor",
            confidence: 0.98,
            boundingBox: CGRect(x: 0.1, y: 0.1, width: 0.5, height: 0.5)
        )
    }
}

// MARK: - Scene Management

/// The `SpatialSceneManager` is responsible for updating the 3D world.
/// It must be marked `@MainActor` because it interacts with RealityKit and UI.
@available(visionOS 1.0, *)
@MainActor
class SpatialSceneManager: ObservableObject {
    
    /// The engine instance, owned by the manager.
    private let inferenceEngine = SpatialInferenceEngine()
    
    /// The RealityKit entity representing the detected object.
    var detectedObjectEntity: Entity?
    
    /// Published property to update the visionOS UI.
    @Published var lastDetectedLabel: String = "Scanning..."
    
    /// The main entry point for a new frame of data.
    /// - Parameter pixelBuffer: The current frame from the visionOS system.
    func processNewFrame(_ pixelBuffer: CVPixelBuffer) {
        // We create a new Task to bridge from the synchronous frame callback 
        // to the asynchronous inference engine.
        Task {
            do {
                // Perform inference on the background actor.
                // This call is 'awaitable', meaning the Main Actor is freed up 
                // to keep the visionOS frame rate at 90Hz/100Hz.
                if let result = try await inferenceEngine.performInference(on: pixelBuffer) {
                    // Once inference is done, we jump back to the Main Actor 
                    // automatically to update the UI and RealityKit.
                    self.updateScene(with: result)
                }
            } catch {
                print("Inference failed: \(error)")
            }
        }
    }
    
    /// Updates the 3D scene. This is a @MainActor method.
    private func updateScene(with result: RecognitionResult) {
        // Update UI
        self.lastDetectedLabel = "\(result.label) (\(Int(result.confidence * 100))%)"
        
        // Update RealityKit (Simulated)
        // In a real app, you would move an Entity to the bounding box position.
        PerformanceTracer.startInterval("RealityKitUpdate")
        print("Updating 3D Entity for: \(result.label)")
        // Simulate the cost of updating a complex 3D hierarchy
        // RealityKit updates can be expensive if the scene graph is deep.
        PerformanceTracer.endInterval("RealityKitUpdate")
    }
}
