
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import FoundationModels

@available(iOS 18.0, *)
actor ConversationAgent {
    private var conversationHistory: [String] = []
    private let textGenerator: TextGenerator // On-device LLM instance

    init() {
        self.textGenerator = TextGenerator()
    }

    /// Appends a user message and generates an AI response.
    func sendMessage(_ message: String) async throws -> String {
        conversationHistory.append("User: \(message)")

        let context = conversationHistory.joined(separator: "\n")
        let prompt = "Based on the following conversation, provide a concise response:\n\(context)\nAI:"

        // AI inference is an async operation
        let result = try await textGenerator.generate(prompt: prompt)
        let aiResponse = result.text

        conversationHistory.append("AI: \(aiResponse)")
        return aiResponse
    }

    /// Retrieves the current conversation history.
    func getHistory() -> [String] {
        return conversationHistory // Safe to read as it's within the actor's isolation
    }

    /// Clears the conversation history.
    func clearHistory() {
        conversationHistory.removeAll()
    }
}

// Usage example:
@available(iOS 18.0, *)
func simulateConversation() async {
    let agent = ConversationAgent()

    // Interactions with the actor are always 'await'ed
    let response1 = try? await agent.sendMessage("Hello, what can you do?")
    print("AI: \(response1 ?? "Error")")

    let response2 = try? await agent.sendMessage("Can you summarize a document for me?")
    print("AI: \(response2 ?? "Error")")

    let history = await agent.getHistory() // Accessing actor state safely
    print("\nFull Conversation:\n\(history.joined(separator: "\n"))")
}
