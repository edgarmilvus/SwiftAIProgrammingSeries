/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/notifications/stream/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { ReadableStream } from 'stream';

/**
 * @description Configuration for the SSE stream.
 * Defines the content type and CORS headers to allow browser access.
 */
const CONFIG = {
  headers: {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*', // In production, restrict to specific domain
    'Access-Control-Allow-Credentials': 'true',
  },
};

/**
 * @description Simulates an AI Model Provider (e.g., OpenAI) that streams tokens.
 * In a real scenario, this would be an API call to an LLM.
 * @returns A ReadableStream of string tokens.
 */
const mockAIModelStream = (): ReadableStream<string> => {
  return new ReadableStream({
    async start(controller) {
      const tokens = [
        "System", ": ", "Initiating", " analysis", "...\n",
        "Step", " 1", ": ", "Parsing", " user", " intent", ".\n",
        "Step", " 2", ": ", "Retrieving", " context", " from", " database", ".\n",
        "Step", " 3", ": ", "Generating", " response", " structure", ".\n",
        "Final", "izing", " output", "..."
      ];

      // Simulate network latency and token arrival time
      for (const token of tokens) {
        await new Promise(resolve => setTimeout(resolve, 150)); 
        controller.enqueue(token);
      }
      
      controller.close();
    },
  });
};

/**
 * @description Main API Route Handler.
 * Establishes an SSE connection and pipes AI model tokens to the client.
 * 
 * Context: This route is Server-Side Rendered (SSR) via the Edge Runtime.
 * It bypasses browser-side API limitations by handling the connection 
 * directly on the server, managing the Event Loop efficiently for I/O operations.
 */
export async function GET(req: NextRequest) {
  // 1. Initialize the TransformStream to convert string tokens to SSE format
  const encoder = new TextEncoder();
  
  const transformStream = new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, controller) {
      // Convert chunk (Uint8Array) back to string to format it
      const text = new TextDecoder().decode(chunk);
      
      // Format as SSE message: "data: {message}\n\n"
      // This adheres to the SSE protocol standard.
      const formattedData = `data: ${JSON.stringify({ 
        type: 'token', 
        content: text,
        timestamp: Date.now()
      })}\n\n`;
      
      controller.enqueue(encoder.encode(formattedData));
    },
  });

  // 2. Create the pipeline: AI Stream -> Transform -> Response
  const aiStream = mockAIModelStream();
  
  // Pipe the AI stream through the transformer and into the response body
  const stream = aiStream
    .pipeThrough(transformStream)
    .pipeThrough(new TransformStream({
      transform(chunk, controller) {
        // Optional: Additional logging or metrics can happen here
        // without blocking the main thread.
        controller.enqueue(chunk);
      }
    }));

  // 3. Return the Response with SSE headers
  return new Response(stream, CONFIG);
}
