
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Observation
import CryptoKit

/// Represents a single, atomic unit of information extracted from a larger document.
/// This is the fundamental building block of a RAG system.
struct DocumentChunk: Sendable, Identifiable {
    let id: UUID
    /// The actual text content of the chunk.
    let text: String
    /// The mathematical representation (vector) of the text.
    let embedding: [Float]
    /// Metadata to help the LLM understand the context (e.g., page number).
    let metadata: [String: String]
    
    init(text: String, embedding: [Float], metadata: [String: String] = [:]) {
        self.id = UUID()
        self.text = text
        self.embedding = embedding
        self.metadata = metadata
    }
}

/// Errors that can occur during the ingestion process.
enum IngestionError: Error {
    case extractionFailed(String)
    case embeddingGenerationFailed
    case invalidChunkSize
}

/// An Actor responsible for managing the Vector Store. 
/// Using an `actor` ensures that multiple ingestion tasks don't corrupt the 
/// in-memory database when writing vectors simultaneously.
actor VectorStore {
    private var storage: [DocumentChunk] = []
    
    /// Adds a newly created chunk to the store.
    func insert(_ chunk: DocumentChunk) {
        storage.append(chunk)
        print("✅ Stored chunk: \(chunk.id.uuidString.prefix(8))... Total: \(storage.count)")
    }
    
    /// Returns all stored chunks (for demonstration purposes).
    func allChunks() -> [DocumentChunk] {
        return storage
    }
}

/// The core service that orchestrates the transformation of text into searchable vectors.
/// We use `@Observable` to allow SwiftUI views to react to progress updates.
@Observable
@available(iOS 18.0, *)
final class IngestionPipeline {
    
    /// The destination where processed chunks are stored.
    private let vectorStore: VectorStore
    
    /// Tracks the current progress of the ingestion (0.0 to 1.0).
    var progress: Double = 0.0
    /// Indicates if the pipeline is currently working.
    var isProcessing: Bool = false
    
    init(vectorStore: VectorStore) {
        self.vectorStore = vectorStore
    }
    
    /// The primary entry point for the pipeline.
    /// - Parameter rawText: The full string extracted from a document.
    /// - Throws: `IngestionError` if any stage fails.
    func process(rawText: String) async throws {
        // Ensure we are starting from a clean state
        await MainActor.run {
            self.isProcessing = true
            self.progress = 0.0
        }
        
        defer {
            // Ensure we reset the UI state regardless of success or failure
            Task { @MainActor in
                self.isProcessing = false
            }
        }
        
        // 1. Chunking Phase
        // We split the text into manageable pieces.
        let chunks = try chunkText(rawText, chunkSize: 500, overlap: 50)
        
        // 2. Embedding and Storage Phase
        // We use a TaskGroup to process chunks in parallel, maximizing CPU/Network usage.
        try await withThrowingTaskGroup(of: Void.self) { group in
            for (index, text) in chunks.enumerated() {
                group.addTask {
                    // Generate the vector for this specific chunk
                    let vector = try await self.generateEmbedding(for: text)
                    
                    // Create the final object
                    let chunk = DocumentChunk(
                        text: text,
                        embedding: vector,
                        metadata: ["source": "scanned_doc_01"]
                    )
                    
                    // Save to the actor-protected store
                    await self.vectorStore.insert(chunk)
                    
                    // Update progress on the MainActor for the UI
                    let currentProgress = Double(index + 1) / Double(chunks.count)
                    await MainActor.run {
                        self.progress = currentProgress
                    }
                }
            }
            
            // Wait for all tasks in the group to complete
            try await group.waitForAll()
        }
    }
    
    /// Splits text into chunks using a sliding window approach.
    /// - Parameters:
    ///   - text: The full text to split.
    ///   - chunkSize: Maximum number of characters per chunk.
    ///   - overlap: Number of characters to repeat from the previous chunk to maintain context.
    /// - Returns: An array of text segments.
    private func chunkText(_ text: String, chunkSize: Int, overlap: Int) throws -> [String] {
        guard chunkSize > overlap else { throw IngestionError.invalidChunkSize }
        
        var chunks: [String] = []
        var currentIndex = text.startIndex
        
        while currentIndex < text.endIndex {
            let nextIndex = text.index(currentIndex, offsetBy: chunkSize, limitedBy: text.endIndex) ?? text.endIndex
            let chunk = String(text[currentIndex..<nextIndex])
            chunks.append(chunk)
            
            // Move the index forward, but subtract the overlap to ensure continuity
            let step = chunkSize - overlap
            if nextIndex == text.endIndex { break }
            
            // Safety check to prevent infinite loops if step is 0 or negative
            guard let newStart = text.index(currentIndex, offsetBy: step, limitedBy: text.endIndex) else {
                break
            }
            currentIndex = newStart
        }
        
        return chunks
    }
    
    /// Simulates a call to an external Embedding API (like OpenAI).
    /// In a real app, this would involve a URLSession call to `https://api.openai.com/v1/embeddings`.
    private func generateEmbedding(for text: String) async throws -> [Float] {
        // Simulate network latency
        try await Task.sleep(for: .seconds(0.5))
        
        // For demonstration, we generate a deterministic "fake" vector based on the text content.
        // In production, this returns the 1536-dimensional vector from OpenAI.
        let pseudoRandomSeed = text.hashValue
        return (0..<1536).map { i in
            Float(sin(Double(pseudoRandomSeed + i)))
        }
    }
}

// MARK: - Execution Example

@MainActor
func runDemo() async {
    let store = VectorStore()
    let pipeline = IngestionPipeline(vectorStore: store)
    
    let longDocument = """
    The Apple Vision Pro is a spatial computer that blends digital content with the physical world. 
    It uses advanced micro-OLED displays to provide incredibly high resolution. 
    The operating system, visionOS, is designed specifically for eye and hand tracking. 
    Spatial computing allows users to interact with apps in a three-dimensional space.
    """ + String(repeating: " This is additional context for testing the chunking logic. ", count: 20)
    
    print("🚀 Starting Ingestion...")
    
    do {
        try await pipeline.process(rawText: longDocument)
        let finalChunks = await store.allChunks()
        print("🎉 Ingestion Complete! Total chunks stored: \(finalChunks.count)")
    } catch {
        print("❌ Ingestion Failed: \(error)")
    }
}

// Execute the demo
Task {
    await runDemo()
}
