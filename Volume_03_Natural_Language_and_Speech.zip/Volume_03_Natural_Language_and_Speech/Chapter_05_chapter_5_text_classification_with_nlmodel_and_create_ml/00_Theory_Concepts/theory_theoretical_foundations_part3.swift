
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, visionOS 2.0, *)
actor ConcurrentSentimentClassifier {
    private let model: NLModel

    init() throws {
        guard let modelURL = Bundle.main.url(forResource: "SentimentClassifier", withExtension: "mlmodelc") else {
            throw SentimentClassifierError.modelNotFound
        }
        self.model = try NLModel(contentsOf: modelURL)
    }

    enum SentimentClassifierError: Error {
        case modelNotFound
        case predictionFailed(Error)
    }

    /// Classifies the sentiment for a given text, protected by actor isolation.
    func classifySentiment(for text: String) throws -> String {
        // NLModel.predictedLabel is synchronous and thread-safe for multiple reads,
        // but encapsulating it within an actor provides a single point of access
        // and protection if the model itself had mutable state or required setup.
        return model.predictedLabel(for: text) ?? "unknown"
    }

    /// Classifies sentiment for multiple texts concurrently, but the underlying
    /// model access is still serialized by the actor.
    func classifyBatch(texts: [String]) async throws -> [String] {
        var results: [String] = []
        for text in texts {
            results.append(try classifySentiment(for: text)) // Awaits implicitly due to actor isolation
        }
        return results
    }
}
