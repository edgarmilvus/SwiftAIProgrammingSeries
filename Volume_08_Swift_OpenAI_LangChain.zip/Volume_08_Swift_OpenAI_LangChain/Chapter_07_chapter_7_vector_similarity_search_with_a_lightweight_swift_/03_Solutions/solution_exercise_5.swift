
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

struct SearchResult: Sendable {
    let document: Document
    let similarity: Float
    let confidence: Float // Calculated based on the neighborhood
}

extension VectorStore {
    /// Performs a filtered search with a minimum similarity threshold and confidence scoring.
    func filteredSearch(
        query: [Float],
        limit: Int,
        threshold: Float
    ) -> [SearchResult] {
        // 1. Perform the standard search to get candidates
        // We fetch a slightly larger limit to calculate neighborhood density
        let expandedLimit = limit * 3
        let candidates = self.search(queryVector: query, limit: expandedLimit)
        
        // 2. Filter by threshold and calculate similarities
        var scoredResults: [(doc: Document, sim: Float)] = []
        for doc in candidates {
            if let sim = try? VectorMath.cosineSimilarity(between: query, and: doc.embedding),
               sim >= threshold {
                scoredResults.append((doc, sim))
            }
        }
        
        guard !scoredResults.isEmpty else { return [] }
        
        // 3. Calculate Confidence Score
        // Confidence is defined by how "dense" the cluster is around the query.
        // We use the average similarity of the top K results.
        let topKCount = min(scoredResults.count, limit)
        let topK = scoredResults.prefix(topKCount)
        let sumSim = topK.reduce(0.0) { $0 + $1.sim }
        let averageSimilarity = sumSim / Float(topKCount)
        
        // 4. Map to SearchResult
        return topK.map { item in
            SearchResult(
                document: item.doc,
                similarity: item.sim,
                confidence: averageSimilarity // High average = high confidence
            )
        }
    }
}

// MARK: - Testing the Semantic Filter
let store = VectorStore()
let doc1 = Document(id: UUID(), text: "Deeply related topic", embedding: [0.9, 0.9, 0.9])
let doc2 = Document(id: UUID(), text: "Somewhat related", embedding: [0.7, 0.7, 0.7])
let doc3 = Document(id: UUID(), text: "Completely unrelated", embedding: [0.1, 0.1, 0.1])

store.add(doc1)
store.add(doc2)
store.add(doc3)

let query: [Float] = [0.85, 0.85, 0.85]

print("--- Scenario 1: High Threshold (Strict) ---")
let strictResults = store.filteredSearch(query: query, limit: 2, threshold: 0.95)
print("Results found: \(strictResults.count)") // Should be 0

print("\n--- Scenario 2: Low Threshold (Loose) ---")
let looseResults = store.filteredSearch(query: query, limit: 2, threshold: 0.5)
for res in looseResults {
    print("Doc: \(res.document.text) | Sim: \(String(format: "%.2f", res.similarity)) | Conf: \(String(format: "%.2f", res.confidence))")
}
