
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
// In a real project, you would import the LlamaCpp package here:
// import LlamaCpp // Assuming LlamaCpp provides the necessary types for embedding and LLM inference

// MARK: - 1. Core Data Structures and Error Handling

/// Represents a custom error type for the Smart Document Assistant.
/// Provides specific error messages for different failure points in the RAG pipeline.
enum DocumentAssistantError: Error, LocalizedError {
    case embeddingFailed(String)
    case vectorStoreError(String)
    case llmInferenceFailed(String)
    case documentProcessingFailed(String)
    case invalidQuery(String)

    var errorDescription: String? {
        switch self {
        case .embeddingFailed(let reason): return "Embedding generation failed: \(reason)"
        case .vectorStoreError(let reason): return "Vector store operation failed: \(reason)"
        case .llmInferenceFailed(let reason): return "LLM inference failed: \(reason)"
        case .documentProcessingFailed(let reason): return "Document processing failed: \(reason)"
        case .invalidQuery(let reason): return "Invalid query: \(reason)"
        }
    }
}

/// Represents a chunk of text from a document, along with its embedding and metadata.
/// This struct is the fundamental unit stored and retrieved by the RAG system.
struct DocumentChunk: Identifiable, Hashable {
    let id: UUID
    let text: String
    let documentID: String // The ID of the parent document, useful for context
    var embedding: [Float]? // The vector representation of the text chunk
    var pageNumber: Int? // Example metadata: original page number for context

    /// Initializes a new `DocumentChunk`.
    /// - Parameters:
    ///   - id: A unique identifier for the chunk. Defaults to a new UUID.
    ///   - text: The textual content of the chunk.
    ///   - documentID: The ID of the document this chunk belongs to.
    ///   - pageNumber: The page number from which this chunk was extracted (optional).
    ///   - embedding: The pre-calculated embedding vector for the chunk (optional).
    init(id: UUID = UUID(), text: String, documentID: String, pageNumber: Int? = nil, embedding: [Float]? = nil) {
        self.id = id
        self.text = text
        self.documentID = documentID
        self.pageNumber = pageNumber
        self.embedding = embedding
    }
    
    // Conformance to Hashable and Equatable for efficient use in collections.
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: DocumentChunk, rhs: DocumentChunk) -> Bool {
        lhs.id == rhs.id
    }
}

// MARK: - 2. Local Embedding Service

/// Protocol for a service that generates vector embeddings for text.
/// This abstraction allows for different embedding model implementations (e.g., `llama.cpp`, CoreML, etc.).
protocol EmbeddingService {
    /// Generates a vector embedding for the given text asynchronously.
    /// - Parameter text: The input text to embed.
    /// - Returns: An array of floats representing the embedding vector.
    /// - Throws: `DocumentAssistantError.embeddingFailed` if embedding generation fails.
    func embed(text: String) async throws -> [Float]
}

/// A mock implementation of `EmbeddingService` for demonstration purposes.
/// **Under the Hood:** In a real application, this class would leverage `llama.cpp` Swift bindings.
/// It would load a pre-trained embedding model (e.g., `BAAI/bge-small-en-v1.5` or `nomic-ai/nomic-embed-text`)
/// on device, tokenize the input text, and perform inference using Apple Silicon's Neural Engine and GPU.
@available(iOS 18.0, macOS 15.0, *)
class MockLocalEmbeddingService: EmbeddingService {
    private let embeddingDimension: Int // The size of the embedding vector

    /// Initializes the mock embedding service.
    /// - Parameter embeddingDimension: The desired dimension of the mock embeddings.
    ///   Common dimensions for embedding models are 384, 768, or 1024.
    init(embeddingDimension: Int = 384) {
        self.embeddingDimension = embeddingDimension
        print("MockLocalEmbeddingService initialized. Emulating a local embedding model.")
    }

    /// Generates a mock embedding by creating a pseudo-random vector.
    /// **Pedagogical Note:** This simulates the asynchronous nature and potential latency
    /// of real model inference. The generated embeddings are deterministic based on text
    /// hash for consistent demo behavior, but are not semantically meaningful.
    func embed(text: String) async throws -> [Float] {
        try await Task.sleep(for: .milliseconds(50)) // Simulate inference latency
        
        guard !text.isEmpty else {
            throw DocumentAssistantError.embeddingFailed("Cannot embed empty text.")
        }
        
        // Generate a pseudo-random embedding vector for demonstration.
        // In a real scenario, this would be the output of a neural network.
        let seed = text.hashValue
        var random = SystemRandomNumberGenerator()
        random.seed(with: UInt64(seed))
        
        let embedding = (0..<embeddingDimension).map { _ in
            Float.random(in: -1.0...1.0, using: &random)
        }
        return embedding
    }
}

// MARK: - 3. Vector Store

/// Protocol for a generic vector store that can store and retrieve vectors.
/// This abstraction allows for different underlying vector storage implementations.
protocol VectorStore {
    associatedtype MetadataType // Type of metadata associated with each vector
    
    /// Adds a vector and its associated metadata to the store.
    /// - Parameters:
    ///   - vector: The embedding vector to add.
    ///   - metadata: Any metadata associated with the vector (e.g., document chunk ID, text).
    /// - Throws: `DocumentAssistantError.vectorStoreError` if the operation fails.
    func add(vector: [Float], metadata: MetadataType) async throws
    
    /// Searches the store for the `k` most similar vectors to the `queryVector`.
    /// - Parameters:
    ///   - queryVector: The vector representing the query.
    ///   - k: The number of top similar results to retrieve.
    /// - Returns: An array of tuples, each containing the metadata and the similarity score.
    /// - Throws: `DocumentAssistantError.vectorStoreError` if the search fails.
    func search(queryVector: [Float], k: Int) async throws -> [(metadata: MetadataType, similarity: Float)]
    
    /// Clears all vectors and metadata from the store.
    func clear() async throws
}

/// An in-memory implementation of `VectorStore` using a simple array.
/// **Under the Hood:** For production, this `InMemoryVectorStore` would be replaced by more
/// sophisticated solutions. Options include:
/// 1.  **CoreML:** For highly optimized vector operations on Apple Silicon. You could convert
///     your vector search into a CoreML model.
/// 2.  **Custom Indexing:** Implement data structures like HNSW (Hierarchical Navigable Small World),
///     Annoy (Approximate Nearest Neighbors Oh Yeah), or a Faiss-like index directly in Swift or
///     via a C++ bridge. These offer much faster approximate nearest neighbor search for large datasets.
/// 3.  **Persistence:** Integrate with `CoreData` or `Realm` to persist embeddings on disk.
@available(iOS 18.0, macOS 15.0, *)
class InMemoryVectorStore: VectorStore {
    private var store: [(vector: [Float], metadata: DocumentChunk)] = []
    private let lock = NSLock() // Protects `store` from concurrent modifications

    /// Initializes an empty in-memory vector store.
    init() {
        print("InMemoryVectorStore initialized.")
    }

    /// Adds a vector and its corresponding `DocumentChunk` metadata to the store.
    /// **Why `NSLock`?** To ensure thread safety when `add` is called concurrently,
    /// preventing data corruption from race conditions.
    func add(vector: [Float], metadata: DocumentChunk) async throws {
        lock.lock()
        defer { lock.unlock() } // Ensure unlock always happens
        store.append((vector: vector, metadata: metadata))
    }

    /// Searches for the `k` most similar vectors using cosine similarity.
    /// **How it works:** It iterates through all stored vectors, calculates their cosine
    /// similarity to the query vector, sorts them by similarity, and returns the top `k`.
    func search(queryVector: [Float], k: Int) async throws -> [(metadata: DocumentChunk, similarity: Float)] {
        guard !queryVector.isEmpty else {
            throw DocumentAssistantError.vectorStoreError("Query vector cannot be empty.")
        }
        
        try await Task.sleep(for: .milliseconds(20)) // Simulate search latency
        
        lock.lock()
        defer { lock.unlock() }
        
        guard !store.isEmpty else { return [] }

        let similarities = store.map { storedItem -> (metadata: DocumentChunk, similarity: Float) in
            let similarity = cosineSimilarity(queryVector, storedItem.vector)
            return (metadata: storedItem.metadata, similarity: similarity)
        }
        
        // Sort by similarity in descending order and take the top k results.
        return similarities
            .sorted { $0.similarity > $1.similarity }
            .prefix(k)
            .map { $0 }
    }
    
    /// Clears all stored vectors and metadata.
    func clear() async throws {
        lock.lock()
        defer { lock.unlock() }
        store.removeAll()
        print("Vector store cleared.")
    }

    /// Computes the cosine similarity between two vectors.
    /// **Why Cosine Similarity?** It's a common metric for text similarity,
    /// measuring the angle between two vectors. A higher value (closer to 1)
    /// indicates greater similarity in direction, regardless of magnitude.
    private func cosineSimilarity(_ v1: [Float], _ v2: [Float]) -> Float {
        guard v1.count == v2.count, !v1.isEmpty else { return 0.0 }
        
        var dotProduct: Float = 0.0
        var magnitude1: Float = 0.0
        var magnitude2: Float = 0.0
        
        for i in 0..<v1.count {
            dotProduct += v1[i] * v2[i]
            magnitude1 += v1[i] * v1[i]
            magnitude2 += v2[i] * v2[i]
        }
        
        let denom = sqrt(magnitude1) * sqrt(magnitude2)
        guard denom != 0 else { return 0.0 } // Avoid division by zero
        
        return dotProduct / denom
    }
}

// MARK: - 4. Local LLM Service

/// Protocol for a service that interacts with a local Large Language Model.
/// This abstracts the LLM provider, allowing for different local LLM backends.
protocol LLMService {
    /// Generates a response from the LLM based on the given prompt.
    /// - Parameter prompt: The input prompt for the LLM.
    /// - Returns: The generated text response.
    /// - Throws: `DocumentAssistantError.llmInferenceFailed` if generation fails.
    func generate(prompt: String) async throws -> String
}

/// A mock implementation of `LLMService`.
/// **Under the Hood:** In a real application, this would interface with a local LLM.
/// Options include:
/// 1.  **Ollama API:** Sending HTTP requests to a locally running Ollama server, which
///     manages various LLM models and leverages `llama.cpp` for inference.
/// 2.  **Direct `llama.cpp` Bindings:** Directly loading and running a GGUF model
///     (e.g., LLaMA, Mixtral, Gemma) using the `llama.cpp` Swift bindings.
@available(iOS 18.0, macOS 15.0, *)
class MockLocalLLMService: LLMService {
    /// Initializes the mock LLM service.
    init() {
        print("MockLocalLLMService initialized. Emulating a local LLM (e.g., via Ollama).")
    }

    /// Generates a mock response based on keywords in the prompt.
    /// **Pedagogical Note:** This simulates the asynchronous nature and higher latency
    /// of real LLM inference compared to embedding generation.
    func generate(prompt: String) async throws -> String {
        try await Task.sleep(for: .milliseconds(200)) // Simulate LLM inference latency
        
        guard !prompt.isEmpty else {
            throw DocumentAssistantError.llmInferenceFailed("Cannot generate with empty prompt.")
        }
        
        // Simple keyword-based mock responses.
        if prompt.contains("Apple Silicon") {
            return "Apple Silicon refers to a series of ARM-based system on a chip (SoC) designs developed by Apple Inc. for their Mac computers and other devices. It's known for its high performance and power efficiency, enabling local AI tasks like LLM inference."
        } else if prompt.contains("RAG") {
            return "Retrieval-Augmented Generation (RAG) is an AI framework that enhances the output of large language models (LLMs) by retrieving relevant information from an external knowledge base before generating a response. This helps LLMs provide more accurate and up-to-date answers, reducing hallucinations."
        } else if prompt.contains("local LLMs") {
            return "Running local LLMs on Apple Silicon means you can perform sophisticated AI tasks directly on your Mac or iPhone without sending data to the cloud. This offers enhanced privacy, lower latency, and can be more cost-effective for certain applications."
        } else {
            return "As a local AI assistant, I can tell you that based on the provided context, the answer is: The information you're asking about is highly relevant to the context provided. Please provide more specific details or documents for a precise answer."
        }
    }
}

// MARK: - 5. Smart Document Assistant Service (RAG Orchestrator)

/// The main service orchestrating the RAG pipeline for local documents.
/// This class ties together the embedding, vector store, and LLM services to provide
/// a complete document Q&A experience.
@available(iOS 18.0, macOS 15.0, *)
class SmartDocumentAssistantService {
    private let embeddingService: any EmbeddingService
    private let vectorStore: InMemoryVectorStore // Using concrete type for simplicity, could be protocol
    private let llmService: any LLMService
    
    /// Initializes the `SmartDocumentAssistantService` with its required dependencies.
    /// - Parameters:
    ///   - embeddingService: An instance of a service to generate embeddings.
    ///   - vectorStore: An instance of a vector store for efficient similarity search.
    ///   - llmService: An instance of a service to interact with a local LLM.
    init(embeddingService: any EmbeddingService, vectorStore: InMemoryVectorStore, llmService: any LLMService) {
        self.embeddingService = embeddingService
        self.vectorStore = vectorStore
        self.llmService = llmService
        print("SmartDocumentAssistantService initialized.")
    }

    /// Ingests a document by chunking its text, generating embeddings for each chunk,
    /// and storing them in the vector store.
    /// **How it works:**
    /// 1.  **Chunking:** The document text is split into smaller, manageable chunks.
    ///     (Advanced: Real-world chunking involves strategies like fixed-size, semantic,
    ///     or recursive chunking to preserve context and optimize retrieval).
    /// 2.  **Parallel Embedding:** Embeddings for all chunks are generated concurrently
    ///     using `TaskGroup` to maximize utilization of Apple Silicon's parallel processing capabilities.
    /// 3.  **Vector Storage:** Each chunk's embedding and metadata are added to the vector store.
    /// - Parameters:
    ///   - documentID: A unique identifier for the document.
    ///   - documentText: The full text content of the document.
    /// - Throws: `DocumentAssistantError` if any step of the ingestion fails.
    func ingestDocument(documentID: String, documentText: String) async throws {
        print("Ingesting document: \(documentID)...")
        
        // 1. Simulate document chunking. In a real app, this would use `PDFKit` or similar.
        // For simplicity, we split by double newline.
        let chunks = documentText.split(separator: "\n\n").map { String($0) }
        
        guard !chunks.isEmpty else {
            throw DocumentAssistantError.documentProcessingFailed("Document yielded no chunks.")
        }
        
        var documentChunks: [DocumentChunk] = []
        
        // 2. Generate embeddings for each chunk concurrently using `TaskGroup`.
        // This is a key production pattern for performance on multi-core Apple Silicon.
        try await withThrowingTaskGroup(of: DocumentChunk.self) { group in
            for (index, chunkText) in chunks.enumerated() {
                group.addTask {
                    let embedding = try await self.embeddingService.embed(text: chunkText)
                    return DocumentChunk(text: chunkText, documentID: documentID, pageNumber: index + 1, embedding: embedding)
                }
            }
            
            // Collect results as they complete
            for try await chunk in group {
                documentChunks.append(chunk)
            }
        }
        
        // 3. Store chunks and their embeddings in the vector store.
        for var chunk in documentChunks {
            guard let embedding = chunk.embedding else {
                throw DocumentAssistantError.embeddingFailed("Chunk \(chunk.id) missing embedding after generation.")
            }
            try await vectorStore.add(vector: embedding, metadata: chunk)
        }
        print("Document \(documentID) ingested with \(documentChunks.count) chunks.")
    }

    /// Answers a natural language query by performing the RAG workflow.
    /// **How it works:**
    /// 1.  **Query Embedding:** The user's question is converted into a vector embedding.
    /// 2.  **Context Retrieval:** The vector store is queried to find the most semantically
    ///     similar document chunks.
    /// 3.  **Prompt Construction:** A specialized prompt (RAG prompt) is created,
    ///     combining the original query with the retrieved document context.
    /// 4.  **LLM Generation:** The local LLM uses this enriched prompt to generate an answer,
    ///     grounded in the provided facts.
    /// - Parameters:
    ///   - query: The user's question.
    ///   - topK: The number of relevant document chunks to retrieve for context.
    /// - Returns: The LLM-generated answer based on retrieved context.
    /// - Throws: `DocumentAssistantError` if any step of the RAG process fails.
    func answerQuestion(query: String, topK: Int = 3) async throws -> String {
        guard !query.isEmpty else {
            throw DocumentAssistantError.invalidQuery("Query cannot be empty.")
        }
        print("\nAnswering query: '\(query)'")

        // 1. Embed the user's query.
        let queryEmbedding = try await embeddingService.embed(text: query)
        print("Query embedded.")

        // 2. Retrieve relevant document chunks from the vector store.
        let retrievedChunks = try await vectorStore.search(queryVector: queryEmbedding, k: topK)
        
        guard !retrievedChunks.isEmpty else {
            print("No relevant chunks found for the query in the local knowledge base.")
            // Fallback: Ask LLM without context or provide a default answer
            return try await llmService.generate(prompt: "Answer the question: \(query) based on general knowledge, as no relevant local documents were found.")
        }
        
        // Concatenate the text of the most relevant chunks to form the context.
        let context = retrievedChunks.map { $0.metadata.text }.joined(separator: "\n\n")
        print("Retrieved \(retrievedChunks.count) relevant chunks. Context length: \(context.count) characters.")
        
        // 3. Construct the RAG prompt for the LLM.
        // This prompt instructs the LLM to use the provided context.
        let ragPrompt = """
        You are an AI assistant for local documents. Use the following retrieved context to answer the question.
        If the answer is not available in the context, state that you don't have enough information from the documents.
        
        Context:
        \(context)
        
        Question: \(query)
        
        Answer:
        """
        
        // 4. Generate the answer using the local LLM.
        let answer = try await llmService.generate(prompt: ragPrompt)
        print("LLM generated answer.")
        return answer
    }
    
    /// Clears all ingested documents from the vector store.
    /// Useful for managing storage or when documents are removed from the app.
    func clearAllDocuments() async throws {
        try await vectorStore.clear()
        print("All documents cleared from the assistant.")
    }
}

// MARK: - 6. Example Usage in an Apple App Context

/// Entry point for demonstrating the Smart Document Assistant in an app-like scenario.
/// This function simulates the interaction flow of a user with the document assistant.
@available(iOS 18.0, macOS 15.0, *)
func runSmartDocumentAssistantDemo() async {
    print("--- Starting Smart Document Assistant Demo ---")

    // Initialize the mock services. In a real app, these would be concrete
    // implementations interacting with llama.cpp/Ollama.
    let embeddingService = MockLocalEmbeddingService()
    let vectorStore = InMemoryVectorStore()
    let llmService = MockLocalLLMService()
    
    // Instantiate the main RAG orchestrator.
    let assistant = SmartDocumentAssistantService(
        embeddingService: embeddingService,
        vectorStore: vectorStore,
        llmService: llmService
    )
    
    // Simulate document content (e.g., extracted from PDFs).
    // These texts provide the knowledge base for the RAG system.
    let doc1Text = """
    Chapter 1: Introduction to Apple Silicon and Neural Engines
    Apple Silicon chips, such as the M1, M2, and M3 series, integrate powerful neural engines designed for accelerating machine learning tasks. These dedicated hardware blocks are crucial for efficient on-device AI inference, including running large language models (LLMs) and generating embeddings locally. The unified memory architecture further enhances performance by allowing the CPU, GPU, and Neural Engine to access the same data pool without copying, leading to significant speedups for AI workloads.

    Chapter 2: Local LLMs with Ollama and llama.cpp
    Ollama provides a convenient way to run open-source large language models locally on macOS and Linux. It leverages `llama.cpp` under the hood for optimized inference on Apple Silicon, taking advantage of the Neural Engine and GPU. Developers can use Ollama's API to interact with various models, making it straightforward to integrate local LLMs into applications. `llama.cpp` itself is a C/C++ port of Facebook's LLaMA model, optimized for various hardware, including Apple's processors, offering impressive performance for local inference.

    Chapter 3: Retrieval-Augmented Generation (RAG)
    Retrieval-Augmented Generation (RAG) is a technique that improves the factual accuracy and relevance of LLM outputs. It works by retrieving relevant information from a knowledge base (like a vector store of documents) and feeding it as context to the LLM alongside the user's query. This minimizes 'hallucinations' and allows LLMs to answer questions about specific, up-to-date, or proprietary information not present in their training data, making them more reliable.
    """
    
    let doc2Text = """
    Performance Benchmarks on Apple Silicon for AI
    Recent benchmarks show that Apple Silicon chips excel in on-device AI inference due to their high memory bandwidth and efficient Neural Engine. For tasks like embedding generation and LLM inference, the performance can rival or even exceed cloud-based solutions for certain model sizes, especially considering latency and privacy. Optimizations in `llama.cpp` specifically target these architectural advantages, enabling fast and power-efficient execution of demanding AI models directly on user devices.
    """

    do {
        // 1. Ingest documents into the RAG system.
        print("\n--- Ingesting Documents ---")
        try await assistant.ingestDocument(documentID: "tech_overview_doc", documentText: doc1Text)
        try await assistant.ingestDocument(documentID: "performance_report", documentText: doc2Text)

        // 2. Answer questions based on the ingested documents.
        print("\n--- Answering Questions ---")
        
        let question1 = "What are the benefits of Apple Silicon for local AI?"
        let answer1 = try await assistant.answerQuestion(query: question1)
        print("Q: \(question1)")
        print("A: \(answer1)\n")
        
        print("--------------------------------------------------\n")

        let question2 = "How does RAG improve LLM performance?"
        let answer2 = try await assistant.answerQuestion(query: question2)
        print("Q: \(question2)")
        print("A: \(answer2)\n")
        
        print("--------------------------------------------------\n")

        let question3 = "What is llama.cpp used for in the context of local LLMs?"
        let answer3 = try await assistant.answerQuestion(query: question3)
        print("Q: \(question3)")
        print("A: \(answer3)\n")
        
        print("--------------------------------------------------\n")

        let question4 = "Tell me about the history of Apple Inc." // Query outside current document context
        let answer4 = try await assistant.answerQuestion(query: question4)
        print("Q: \(question4)")
        print("A: \(answer4)\n") // Should get a general answer or "not enough info" from mock LLM.

        // 3. Clear documents (e.g., when a user removes a document from the app).
        print("\n--- Clearing Documents ---")
        try await assistant.clearAllDocuments()
        
        // 4. Try answering a question after clearing the knowledge base.
        print("\n--- Answering After Clear ---")
        let question5 = "What are Apple Silicon chips?"
        let answer5 = try await assistant.answerQuestion(query: question5)
        print("Q: \(question5)")
        print("A: \(answer5)\n") // Should now get a general answer as no context is found.
        
    } catch {
        print("An error occurred during the demo: \(error.localizedDescription)")
    }

    print("\n--- Smart Document Assistant Demo Finished ---")
}

// To run this demo in an Xcode Playground or a Swift project:
// Task {
//     await runSmartDocumentAssistantDemo()
// }

// MARK: - VISUALIZATIONS

/// The following Graphviz DOT diagram illustrates the architecture and data flow
/// within the Smart Document Assistant's RAG system.
///
/// 

::: {style="text-align: center"}
![Architecture and data flow within the Smart Document Assistant's RAG system.](images/b6_c10_s3_diag1.png){width=80% caption="Architecture and data flow within the Smart Document Assistant's RAG system."}
:::


