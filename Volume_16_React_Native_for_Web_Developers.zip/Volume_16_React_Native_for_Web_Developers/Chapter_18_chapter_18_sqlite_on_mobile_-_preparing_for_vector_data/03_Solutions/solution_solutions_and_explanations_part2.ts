/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// database.ts
import { VectorRecord } from './types';
import * as SQLite from 'expo-sqlite';

export async function insertVectorRecord(
  db: SQLite.SQLiteDatabase,
  record: VectorRecord
): Promise<void> {
  // Serialize the embedding array to a JSON string
  const embeddingString = JSON.stringify(record.embedding);
  
  const query = `
    INSERT INTO document_vectors (embedding, document_id, chunk_text, page_number, created_at)
    VALUES (?, ?, ?, ?, ?)
  `;

  await new Promise<void>((resolve, reject) => {
    db.transaction((tx) => {
      tx.executeSql(
        query,
        [
          embeddingString,
          record.document_id,
          record.chunk_text,
          record.page_number,
          record.created_at || new Date().toISOString(),
        ],
        () => resolve(),
        (_, error) => {
          reject(error);
          return true;
        }
      );
    });
  });
}

export async function getVectorById(
  db: SQLite.SQLiteDatabase,
  id: number
): Promise<VectorRecord | null> {
  const query = `SELECT * FROM document_vectors WHERE id = ?`;

  return new Promise((resolve, reject) => {
    db.transaction((tx) => {
      tx.executeSql(
        query,
        [id],
        (_, { rows }) => {
          if (rows.length === 0) {
            resolve(null);
          } else {
            const item = rows.item(0);
            // Deserialize the embedding string back into a number array
            const record: VectorRecord = {
              ...item,
              embedding: JSON.parse(item.embedding),
            };
            resolve(record);
          }
        },
        (_, error) => {
          reject(error);
          return true;
        }
      );
    });
  });
}
