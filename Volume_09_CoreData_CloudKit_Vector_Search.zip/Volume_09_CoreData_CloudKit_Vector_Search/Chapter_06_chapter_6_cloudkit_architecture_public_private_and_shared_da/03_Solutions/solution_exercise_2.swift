
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CloudKit

@available(iOS 18.0, *)
actor WorkspaceManager {
    private let privateDB: CKDatabase
    
    init(container: CKContainer) {
        self.privateDB = container.privateCloudDatabase
    }
    
    func createWorkspace(named name: String) async throws -> CKRecordZone.ID {
        let zone = CKRecordZone(zoneID: CKRecordZone.ID(zoneName: name, ownerName: CKCurrentUserDefaultName))
        try await privateDB.save(zone)
        return zone.zoneID
    }
    
    func addTask(taskName: String, to workspaceID: CKRecordZone.ID) async throws {
        let record = CKRecord(recordType: "Task", recordID: CKRecord.ID(recordName: UUID().uuidString, zoneID: workspaceID))
        record["name"] = taskName as CKRecordValue
        
        try await privateDB.save(record)
    }
    
    func deleteWorkspace(workspaceID: CKRecordZone.ID) async throws {
        // Deleting the zone automatically deletes all records within it.
        try await privateDB.deleteRecordZone(withID: workspaceID)
    }
    
    // Demonstration of Concurrency via TaskGroup
    func simulateBulkTaskAddition(workspaces: [CKRecordZone.ID]) async throws {
        try await withThrowingTaskGroup(of: Void.self) { group in
            for zoneID in workspaces {
                group.addTask {
                    // Simulate adding 3 tasks per workspace concurrently
                    for i in 1...3 {
                        try await self.addTask(taskName: "Task \(i)", to: zoneID)
                    }
                }
            }
            try await group.waitForAll()
        }
    }
}
