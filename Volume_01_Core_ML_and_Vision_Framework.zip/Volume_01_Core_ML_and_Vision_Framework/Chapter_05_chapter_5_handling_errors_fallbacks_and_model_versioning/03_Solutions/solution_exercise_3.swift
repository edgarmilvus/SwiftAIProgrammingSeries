
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CoreML
import Foundation

// Helper for semantic version comparison (simplified)
extension String {
    // This simplified comparison works for versions like "1.0.0", "1.1.0", "2.0.0"
    // For full semantic versioning (pre-release, build metadata), a more robust library
    // or custom implementation would be needed.
    func isSemanticVersionGreaterThan(_ otherVersion: String) -> Bool {
        let components = self.split(separator: ".").compactMap { Int($0) }
        let otherComponents = otherVersion.split(separator: ".").compactMap { Int($0) }

        for i in 0..<min(components.count, otherComponents.count) {
            if components[i] > otherComponents[i] {
                return true
            }
            if components[i] < otherComponents[i] {
                return false
            }
        }
        // If versions are like "1.0" and "1.0.0", the longer one (more specific) is considered greater
        return components.count > otherComponents.count
    }
    
    func isSemanticVersionEqual(_ otherVersion: String) -> Bool {
        return self == otherVersion
    }
}

@available(iOS 18.0, *)
enum ModelLoadingError: Error, LocalizedError {
    case noModelFound
    case noCompatibleModelFound(minimumVersion: String)
    case generalLoadingFailure(String)
    case invalidModelMetadata(URL)

    var errorDescription: String? {
        switch self {
        case .noModelFound:
            return "No style transfer models were found in the app bundle."
        case .noCompatibleModelFound(let minVersion):
            return "No style transfer model found that meets the minimum version requirement of \(minVersion)."
        case .generalLoadingFailure(let details):
            return "Failed to load any suitable style transfer model: \(details)"
        case .invalidModelMetadata(let url):
            return "Model \(url.lastPathComponent) has invalid or missing version metadata."
        }
    }
}

@available(iOS 18.0, *)
class StyleTransferModelLoader {
    // Simulate available model assets in the bundle
    // In a real app, these would be actual URLs to .mlmodelc files.
    // Ensure these files exist in your Xcode project and are included in the target bundle.
    private let availableModelFileNames: [String] = [
        "StyleTransfer_v1_0", // Assume metadata version "1.0.0"
        "StyleTransfer_v1_1", // Assume metadata version "1.1.0"
        "StyleTransfer_v2_0"  // Assume metadata version "2.0.0"
    ]

    /// Loads the best available style transfer model that meets the minimum version requirement.
    /// - Parameter minimumVersion: The minimum semantic version string required (e.g., "1.1.0").
    /// - Returns: The loaded MLModel instance.
    /// - Throws: `ModelLoadingError` if no suitable model can be loaded.
    func loadBestModel(minimumVersion: String? = nil) async throws -> MLModel { // Added async for modern context
        var bestModel: MLModel? = nil
        var bestVersionString: String = "0.0.0" // Initialize with a very low version

        // First, collect all potential model URLs
        let modelURLs = availableModelFileNames.compactMap { name in
            Bundle.main.url(forResource: name, withExtension: "mlmodelc")
        }

        guard !modelURLs.isEmpty else {
            throw ModelLoadingError.noModelFound
        }

        print("Searching for best model with minimum version: \(minimumVersion ?? "None")")

        for modelURL in modelURLs.sorted(by: { $0.lastPathComponent > $1.lastPathComponent }) { // Sort to prioritize higher versions in file names
            do {
                let configuration = MLModelConfiguration()
                // You might configure compute units based on device capabilities
                // configuration.computeUnits = .all

                // MLModel(contentsOf:) is synchronous, so no 'await' needed here for the call itself
                let tempModel = try MLModel(contentsOf: modelURL, configuration: configuration)
                
                guard let currentModelVersion = tempModel.modelDescription.metadata.versionString else {
                    print("Warning: Model \(modelURL.lastPathComponent) has no version string metadata. Skipping.")
                    continue // Skip models without version metadata
                }
                
                print("Found model \(modelURL.lastPathComponent) with version: \(currentModelVersion)")

                // Check if it meets the minimum version requirement
                if let minVer = minimumVersion {
                    if !currentModelVersion.isSemanticVersionGreaterThan(minVer) && !currentModelVersion.isSemanticVersionEqual(minVer) {
                        print("  Skipping \(modelURL.lastPathComponent) (version \(currentModelVersion) is below minimum \(minVer))")
                        continue // Skip models that don't meet the minimum
                    }
                }

                // Check if this is a better version than the current best
                if currentModelVersion.isSemanticVersionGreaterThan(bestVersionString) {
                    bestModel = tempModel
                    bestVersionString = currentModelVersion
                    print("  -> This is the new best candidate: \(modelURL.lastPathComponent) (Version: \(bestVersionString))")
                }
            } catch let error as CoreMLError {
                print("Error loading model \(modelURL.lastPathComponent) due to Core ML issue: \(error.localizedDescription)")
                // Continue to try other models even if one fails to load
            } catch {
                print("Unexpected error loading model \(modelURL.lastPathComponent): \(error.localizedDescription)")
                // Continue to try other models
            }
        }

        if let finalBestModel = bestModel {
            print("Successfully loaded best model: \(finalBestModel.modelDescription.metadata.versionString ?? "unknown version") from \(finalBestModel.modelDescription.url.lastPathComponent)")
            return finalBestModel
        } else if let minVer = minimumVersion {
            throw ModelLoadingError.noCompatibleModelFound(minimumVersion: minVer)
        } else {
            throw ModelLoadingError.generalLoadingFailure("No suitable model could be loaded after checking all candidates.")
        }
    }
}

// Example Usage (e.g., in an AppDelegate or ViewController)
/*
@available(iOS 18.0, *)
func demonstrateModelSelection() async {
    let modelLoader = StyleTransferModelLoader()

    print("\n--- Scenario 1: Load best available model (no minimum version) ---")
    do {
        let model = try await modelLoader.loadBestModel()
        print("Loaded model: \(model.modelDescription.metadata.versionString ?? "N/A")")
    } catch {
        print("Failed to load best model: \(error.localizedDescription)")
    }

    print("\n--- Scenario 2: Load model with minimum version 1.1.0 ---")
    do {
        let model = try await modelLoader.loadBestModel(minimumVersion: "1.1.0")
        print("Loaded model: \(model.modelDescription.metadata.versionString ?? "N/A")")
    } catch {
        print("Failed to load model with minimum 1.1.0: \(error.localizedDescription)")
    }

    print("\n--- Scenario 3: Load model with minimum version 2.0.0 ---")
    do {
        let model = try await modelLoader.loadBestModel(minimumVersion: "2.0.0")
        print("Loaded model: \(model.modelDescription.metadata.versionString ?? "N/A")")
    } catch {
        print("Failed to load model with minimum 2.0.0: \(error.localizedDescription)")
    }

    print("\n--- Scenario 4: Load model with minimum version 2.1.0 (should fail) ---")
    do {
        let model = try await modelLoader.loadBestModel(minimumVersion: "2.1.0")
        print("Loaded model: \(model.modelDescription.metadata.versionString ?? "N/A")")
    } catch {
        print("Failed to load model with minimum 2.1.0: \(error.localizedDescription)")
    }
    
    // To test model loading failure:
    // 1. Create a dummy .mlmodel (e.g., from Xcode)
    // 2. Add it to your project, name it "StyleTransfer_v9_9.mlmodel"
    // 3. Corrupt the .mlmodelc file in the bundle (e.g., by opening it as text and deleting content)
    //    or add a non-existent file name to availableModelFileNames.
    // 4. Run the app to see CoreMLError being caught for that specific model.
}

// Call demonstrateModelSelection() from an async context, e.g., in a Task in AppDelegate
// @main
// @available(iOS 18.0, *)
// class AppDelegate: UIResponder, UIApplicationDelegate {
//     func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
//         Task {
//             await demonstrateModelSelection()
//         }
//         return true
//     }
// }
*/
