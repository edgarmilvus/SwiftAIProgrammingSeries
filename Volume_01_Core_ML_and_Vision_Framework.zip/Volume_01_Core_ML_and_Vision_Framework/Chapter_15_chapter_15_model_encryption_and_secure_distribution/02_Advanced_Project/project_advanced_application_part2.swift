
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreML
import CryptoKit
import Security // For Keychain services, though CryptoKit often abstracts it

// MARK: - 1. Define Model Configuration Structure

/// Represents a sensitive configuration for a Core ML feature,
/// which needs to be securely distributed and decrypted.
/// This could control parameters like confidence thresholds, custom layer weights,
/// or feature activation settings for a premium AI filter.
struct SecureModelConfiguration: Codable, Equatable {
    let version: Int
    let featureName: String
    let confidenceThreshold: Double
    let customWeights: [Double] // Example: weights for a custom post-processing layer
    let isActive: Bool
}

// MARK: - 2. Custom Error Handling

/// Custom error types for secure model configuration management.
enum SecureModelConfigError: Error, LocalizedError {
    case keychainError(status: OSStatus)
    case keyNotFoundInKeychain
    case networkError(Error)
    case invalidServerResponse
    case decryptionFailed(Error)
    case dataCorruption
    case fileSystemError(Error)
    case invalidConfigurationData
    case modelLoadingFailed(Error)
    case missingDecryptionComponents // For IV/Tag/Ciphertext extraction
    
    var errorDescription: String? {
        switch self {
        case .keychainError(let status):
            return "Keychain operation failed with status: \(status)"
        case .keyNotFoundInKeychain:
            return "Decryption key not found in Keychain."
        case .networkError(let error):
            return "Network request failed: \(error.localizedDescription)"
        case .invalidServerResponse:
            return "Server returned an invalid response."
        case .decryptionFailed(let error):
            return "Failed to decrypt configuration data: \(error.localizedDescription)"
        case .dataCorruption:
            return "Decrypted data appears corrupted or malformed."
        case .fileSystemError(let error):
            return "File system operation failed: \(error.localizedDescription)"
        case .invalidConfigurationData:
            return "Decrypted data could not be parsed as SecureModelConfiguration."
        case .modelLoadingFailed(let error):
            return "Failed to load Core ML model: \(error.localizedDescription)"
        case .missingDecryptionComponents:
            return "Encrypted data is missing IV, ciphertext, or authentication tag."
        }
    }
}

// MARK: - 3. Secure AI Feature Manager Class

/// `@available(iOS 18.0, *)` annotation for potential future API usage,
/// but `CryptoKit` and `async/await` are widely available on recent iOS versions.
/// This class manages the secure fetching, decryption, and application of
/// Core ML model configurations for a premium photo editing app.
@available(iOS 15.0, *) // Targeting iOS 15 for full async/await support
@available(macOS 12.0, *)
@available(tvOS 15.0, *)
@available(watchOS 8.0, *)
final class SecureAIConfigurationManager {
    
    // MARK: - Properties
    
    /// Unique identifier for storing the decryption key in the Keychain.
    private let keychainKeyIdentifier: String
    /// URL for fetching the encrypted model configuration.
    private let encryptedConfigURL: URL
    /// URL for fetching the symmetric decryption key.
    private let decryptionKeyURL: URL
    
    /// The currently loaded and decrypted secure configuration.
    private(set) var currentConfiguration: SecureModelConfiguration?
    
    // MARK: - Initialization
    
    /// Initializes the manager with necessary URLs and Keychain identifier.
    /// - Parameters:
    ///   - encryptedConfigURL: The URL to download the encrypted configuration.
    ///   - decryptionKeyURL: The URL to securely fetch the symmetric decryption key.
    ///   - keychainKeyIdentifier: A unique string to identify the key in the Keychain.
    init(encryptedConfigURL: URL, decryptionKeyURL: URL, keychainKeyIdentifier: String) {
        self.encryptedConfigURL = encryptedConfigURL
        self.decryptionKeyURL = decryptionKeyURL
        self.keychainKeyIdentifier = keychainKeyIdentifier
    }
    
    // MARK: - 4. Decryption Key Management (Keychain)
    
    /// Stores a `SymmetricKey` securely in the Keychain.
    /// - Parameter key: The `SymmetricKey` to store.
    /// - Throws: `SecureModelConfigError.keychainError` if the operation fails.
    private func storeKeyInKeychain(_ key: SymmetricKey) async throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: keychainKeyIdentifier,
            kSecValueData as String: key.withUnsafeBytes { Data($0) },
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly // Strong accessibility
        ]
        
        // Delete any existing key first to ensure we're storing the latest
        SecItemDelete(query as CFDictionary)
        
        let status = SecItemAdd(query as CFDictionary, nil)
        guard status == errSecSuccess else {
            throw SecureModelConfigError.keychainError(status: status)
        }
        print("✅ Key successfully stored in Keychain.")
    }
    
    /// Retrieves a `SymmetricKey` from the Keychain.
    /// - Returns: The retrieved `SymmetricKey`.
    /// - Throws: `SecureModelConfigError.keyNotFoundInKeychain` or `SecureModelConfigError.keychainError`.
    private func retrieveKeyFromKeychain() async throws -> SymmetricKey {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: keychainKeyIdentifier,
            kSecReturnData as String: kCFBooleanTrue!,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        
        guard status == errSecSuccess else {
            if status == errSecItemNotFound {
                throw SecureModelConfigError.keyNotFoundInKeychain
            }
            throw SecureModelConfigError.keychainError(status: status)
        }
        
        guard let data = item as? Data else {
            throw SecureModelConfigError.keyNotFoundInKeychain // Should not happen if status is success
        }
        
        print("✅ Key successfully retrieved from Keychain.")
        return SymmetricKey(data: data)
    }
    
    /// Fetches the symmetric decryption key from a secure server endpoint.
    /// In a real app, this would be authenticated (e.g., with a user token).
    /// - Returns: The `SymmetricKey` fetched from the server.
    /// - Throws: `SecureModelConfigError` if network or data issues occur.
    private func fetchDecryptionKeyFromServer() async throws -> SymmetricKey {
        print("🚀 Fetching decryption key from server: \(decryptionKeyURL.absoluteString)")
        do {
            let (data, response) = try await URLSession.shared.data(from: decryptionKeyURL)
            
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                throw SecureModelConfigError.invalidServerResponse
            }
            
            // Assume the server sends the raw key bytes directly.
            // In a real scenario, this key might be wrapped with a public key or derived.
            guard data.count == 32 else { // AES-256 key is 32 bytes
                throw SecureModelConfigError.invalidServerResponse // Or specific key size error
            }
            
            let key = SymmetricKey(data: data)
            print("✅ Decryption key fetched from server.")
            return key
            
        } catch {
            throw SecureModelConfigError.networkError(error)
        }
    }
    
    // MARK: - 5. Secure Configuration Download
    
    /// Downloads the encrypted model configuration from the specified URL.
    /// - Returns: The raw `Data` of the encrypted configuration.
    /// - Throws: `SecureModelConfigError` if network or server issues occur.
    private func downloadEncryptedConfiguration() async throws -> Data {
        print("🚀 Downloading encrypted configuration from: \(encryptedConfigURL.absoluteString)")
        do {
            let (data, response) = try await URLSession.shared.data(from: encryptedConfigURL)
            
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                throw SecureModelConfigError.invalidServerResponse
            }
            
            print("✅ Encrypted configuration downloaded successfully.")
            return data
            
        } catch {
            throw SecureModelConfigError.networkError(error)
        }
    }
    
    // MARK: - 6. Configuration Decryption
    
    /// Decrypts the raw encrypted data using the provided symmetric key.
    /// Assumes the encrypted data is structured as: `IV || Ciphertext || Authentication Tag`.
    /// - Parameters:
    ///   - encryptedData: The raw `Data` containing IV, ciphertext, and tag.
    ///   - key: The `SymmetricKey` used for decryption.
    /// - Returns: The decrypted plaintext `Data`.
    /// - Throws: `SecureModelConfigError` if decryption fails or data is malformed.
    private func decryptConfiguration(encryptedData: Data, with key: SymmetricKey) throws -> Data {
        print("🔑 Attempting to decrypt configuration data...")
        do {
            // Reconstruct `SealedBox` from the raw data.
            // We assume a specific structure: IV (12 bytes) + Ciphertext + Authentication Tag (16 bytes)
            guard encryptedData.count >= AES.GCM.nonceSize + AES.GCM.tagSize else {
                throw SecureModelConfigError.missingDecryptionComponents
            }
            
            let ivData = encryptedData.prefix(AES.GCM.nonceSize)
            let tagData = encryptedData.suffix(AES.GCM.tagSize)
            let ciphertextData = encryptedData.dropFirst(AES.GCM.nonceSize).dropLast(AES.GCM.tagSize)
            
            let nonce = try AES.GCM.Nonce(data: ivData)
            let sealedBox = try AES.GCM.SealedBox(
                nonce: nonce,
                ciphertext: ciphertextData,
                tag: tagData
            )
            
            let decryptedData = try AES.GCM.open(sealedBox, using: key)
            print("✅ Configuration data decrypted successfully.")
            return decryptedData
        } catch {
            throw SecureModelConfigError.decryptionFailed(error)
        }
    }
    
    // MARK: - 7. Configuration Application
    
    /// Parses the decrypted data into a `SecureModelConfiguration` object.
    /// - Parameter decryptedData: The plaintext `Data` (expected to be JSON).
    /// - Returns: The parsed `SecureModelConfiguration`.
    /// - Throws: `SecureModelConfigError.invalidConfigurationData` if parsing fails.
    private func parseConfiguration(decryptedData: Data) throws -> SecureModelConfiguration {
        print("⚙️ Parsing decrypted configuration data...")
        do {
            let configuration = try JSONDecoder().decode(SecureModelConfiguration.self, from: decryptedData)
            print("✅ Configuration parsed successfully (Version: \(configuration.version), Feature: \(configuration.featureName)).")
            return configuration
        } catch {
            throw SecureModelConfigError.invalidConfigurationData
        }
    }
    
    /// Simulates applying the secure configuration to a Core ML model.
    /// In a real app, this would involve setting properties on an `MLModel` instance
    /// or its `MLFeatureProvider` inputs, or adjusting Vision request parameters.
    /// - Parameter config: The `SecureModelConfiguration` to apply.
    private func applyConfigurationToCoreMLModel(config: SecureModelConfiguration) {
        print("✨ Applying configuration to Core ML model (simulated)...")
        // Example: Imagine a Core ML model that takes a 'threshold' as an input.
        // let modelInput = MyModelInput(image: someImage, threshold: config.confidenceThreshold)
        // Or, if using a custom Vision request:
        // let request = VNCustomVisionRequest(model: myModel) { request, error in ... }
        // request.setValue(config.confidenceThreshold, forParameterKey: "confidenceThreshold")
        
        print("   - Set confidence threshold to: \(config.confidenceThreshold)")
        print("   - Adjusted custom weights (first 3): \(config.customWeights.prefix(3))...")
        print("   - Feature is active: \(config.isActive)")
        
        // Store the configuration for later access
        self.currentConfiguration = config
        print("✅ Configuration applied and stored.")
    }
    
    // MARK: - Public API: Update and Load Configuration
    
    /// Orchestrates the entire process: fetches key, downloads encrypted config,
    /// decrypts, parses, and applies it.
    /// This method handles initial setup and subsequent updates.
    /// - Parameter forceRefreshKey: If `true`, forces fetching a new key from the server
    ///                              and overwriting the one in Keychain.
    /// - Throws: `SecureModelConfigError` if any step in the process fails.
    func updateAndApplySecureConfiguration(forceRefreshKey: Bool = false) async throws {
        print("\n--- Starting Secure Configuration Update Process ---")
        
        var decryptionKey: SymmetricKey
        
        // Try to retrieve key from Keychain first
        if !forceRefreshKey {
            do {
                decryptionKey = try await retrieveKeyFromKeychain()
                print("Using key from Keychain.")
            } catch SecureModelConfigError.keyNotFoundInKeychain {
                print("Key not found in Keychain. Fetching from server.")
                decryptionKey = try await fetchDecryptionKeyFromServer()
                try await storeKeyInKeychain(decryptionKey)
            } catch {
                print("Error retrieving key from Keychain: \(error.localizedDescription). Attempting to fetch from server.")
                decryptionKey = try await fetchDecryptionKeyFromServer()
                try await storeKeyInKeychain(decryptionKey)
            }
        } else {
            print("Forcing key refresh from server.")
            decryptionKey = try await fetchDecryptionKeyFromServer()
            try await storeKeyInKeychain(decryptionKey)
        }
        
        // Download encrypted configuration
        let encryptedConfigData = try await downloadEncryptedConfiguration()
        
        // Decrypt configuration
        let decryptedConfigData = try decryptConfiguration(encryptedConfigData, with: decryptionKey)
        
        // Parse and apply configuration
        let config = try parseConfiguration(decryptedConfigData)
        applyConfigurationToCoreMLModel(config: config)
        
        print("--- Secure Configuration Update Process Completed Successfully ---\n")
    }
    
    /// Simulates loading a dummy Core ML model. This is just for context,
    /// as the primary focus is on the secure configuration.
    /// - Returns: An `MLModel` instance.
    /// - Throws: `SecureModelConfigError.modelLoadingFailed` if the model cannot be loaded.
    func loadDummyCoreMLModel() throws -> MLModel {
        // In a real app, this would load a bundled or securely downloaded .mlmodelc
        // For demonstration, we'll simulate a successful load.
        print("Loading dummy Core ML model (simulated)...")
        
        // A real Core ML model would be loaded from its .mlmodelc URL:
        // guard let modelURL = Bundle.main.url(forResource: "MyImageClassifier", withExtension: "mlmodelc") else {
        //     throw SecureModelConfigError.modelLoadingFailed(NSError(domain: "App", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model not found"]))
        // }
        // let model = try MLModel(contentsOf: modelURL)
        
        // Placeholder for a successfully loaded model
        class DummyMLModel: MLModel {
            override var modelDescription: MLModelDescription {
                let inputDescription = MLFeatureDescription(name: "image", type: .image)
                let outputDescription = MLFeatureDescription(name: "label", type: .string)
                return MLModelDescription(inputFeatureDescriptions: [inputDescription], outputFeatureDescriptions: [outputDescription])
            }
            
            override func prediction(from input: MLFeatureProvider, options: MLPredictionOptions) throws -> MLFeatureProvider {
                // Simulate a prediction
                let outputFeatures: [String: MLFeatureValue] = ["label": .string("dummy_prediction")]
                return MLDictionaryFeatureProvider(dictionary: outputFeatures)
            }
        }
        
        print("✅ Dummy Core ML model loaded successfully.")
        return DummyMLModel() // Return a dummy model instance
    }
}

// MARK: - Simulation Environment

/// A utility to simulate network responses for encrypted data and keys.
/// This `MockServer` conceptualizes the server-side operations:
/// generating a symmetric key and encrypting the configuration using AES-GCM.
class MockServer {
    static let shared = MockServer()
    
    // AES-256 key size is 32 bytes
    private let symmetricKey = SymmetricKey(size: .bits256)
    
    /// Simulates the server-side encryption of a configuration.
    /// This function would run on the server to prepare the data.
    /// - Parameter config: The `SecureModelConfiguration` to encrypt.
    /// - Returns: The combined `IV || Ciphertext || Authentication Tag` data.
    func encryptConfigurationOnServer(config: SecureModelConfiguration) throws -> Data {
        let configData = try JSONEncoder().encode(config)
        
        let nonce = AES.GCM.Nonce() // Generate a random IV (nonce)
        let sealedBox = try AES.GCM.seal(configData, using: symmetricKey, nonce: nonce)
        
        // Combine IV, ciphertext, and tag for client-side reconstruction
        var encryptedPayload = Data()
        encryptedPayload.append(nonce.withUnsafeBytes { Data($0) }) // 12 bytes
        encryptedPayload.append(sealedBox.ciphertext)
        encryptedPayload.append(sealedBox.tag) // 16 bytes
        
        print("Server: Configuration encrypted. Payload size: \(encryptedPayload.count) bytes.")
        return encryptedPayload
    }
    
    /// Simulates providing the symmetric key to the client.
    /// In a real scenario, this would be secured, e.g., via public-key encryption or an authenticated session.
    func getSymmetricKeyForClient() -> Data {
        return symmetricKey.withUnsafeBytes { Data($0) }
    }
}

// MARK: - Mocking URLSession for testing network calls

/// A custom `URLProtocol` to intercept and mock `URLSession` requests for testing.
/// This allows us to simulate network responses without actually making network calls,
/// which is crucial for testing secure distribution logic.
class MockURLProtocol: URLProtocol {
    static var mockResponses: [URL: Data] = [:]
    
    override class func canInit(with request: URLRequest) -> Bool {
        return mockResponses.keys.contains(where: { $0 == request.url })
    }
    
    override class func canonicalRequest(for request: URLRequest) -> URLRequest {
        return request
    }
    
    override func startLoading() {
        if let url = request.url, let data = MockURLProtocol.mockResponses[url] {
            let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: nil, headerFields: nil)!
            self.client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            self.client?.urlProtocol(self, didLoad: data)
            self.client?.urlProtocolDidFinishLoading(self)
        } else {
            let error = NSError(domain: NSURLErrorDomain, code: NSURLErrorResourceUnavailable, userInfo: [NSLocalizedDescriptionKey: "Mock response not found for \(request.url?.absoluteString ?? "unknown URL")"])
            self.client?.urlProtocol(self, didFailWithError: error)
        }
    }
    
    override func stopLoading() {
        // Required override
    }
}

// MARK: - Application Entry Point (Example Usage)

/// This `main` struct serves as the entry point for demonstrating the `SecureAIConfigurationManager`.
/// It simulates various scenarios like initial configuration load, updates, and forced key refreshes.
@main
@available(iOS 15.0, *) // Targeting iOS 15 for full async/await support
struct SecureAIApp {
    static func main() async throws {
        print("--- Starting Secure AI Configuration Demo ---")
        
        // 1. Setup Mock Server and Data
        let mockServer = MockServer.shared
        
        let initialConfig = SecureModelConfiguration(
            version: 1,
            featureName: "Advanced Portrait Mode",
            confidenceThreshold: 0.85,
            customWeights: [0.1, 0.2, 0.15, 0.3],
            isActive: true
        )
        
        let updatedConfig = SecureModelConfiguration(
            version: 2,
            featureName: "Advanced Portrait Mode",
            confidenceThreshold: 0.92, // Higher threshold for better quality
            customWeights: [0.12, 0.25, 0.18, 0.35], // Updated weights
            isActive: true
        )
        
        // Simulate server-side encryption for both initial and updated configurations
        let encryptedInitialConfigData: Data
        let encryptedUpdatedConfigData: Data
        do {
            encryptedInitialConfigData = try mockServer.encryptConfigurationOnServer(config: initialConfig)
            encryptedUpdatedConfigData = try mockServer.encryptConfigurationOnServer(config: updatedConfig)
        } catch {
            print("Fatal Error: Mock server encryption failed: \(error.localizedDescription)")
            return
        }
        
        // Simulate network endpoints for the configuration and the decryption key
        let configURL = URL(string: "https://api.example.com/premium_ai_config")!
        let keyURL = URL(string: "https://api.example.com/ai_config_key")!
        let keychainID = "com.yourapp.secureAIConfigKey"
        
        // Register our custom URLProtocol to intercept and mock network requests
        URLProtocol.registerClass(MockURLProtocol.self)
        // Configure mock responses: initially, the server provides the initial config
        MockURLProtocol.mockResponses[configURL] = encryptedInitialConfigData
        MockURLProtocol.mockResponses[keyURL] = mockServer.getSymmetricKeyForClient()
        
        // Initialize the SecureAIConfigurationManager
        let manager = SecureAIConfigurationManager(
            encryptedConfigURL: configURL,
            decryptionKeyURL: keyURL,
            keychainKeyIdentifier: keychainID
        )
        
        // 2. First Run: Simulate initial configuration load
        // The manager will attempt to retrieve the key from Keychain (it won't be there yet),
        // then fetch it from the mock server, store it, download, decrypt, and apply the config.
        print("\n--- DEMO PHASE 1: Initial Configuration Load ---")
        do {
            try await manager.updateAndApplySecureConfiguration()
            if let config = manager.currentConfiguration {
                print("Current active configuration: Version \(config.version), Threshold \(config.confidenceThreshold)")
            }
            
            // Load a dummy Core ML model to show context of where config would be applied
            _ = try manager.loadDummyCoreMLModel()
            
        } catch {
            print("❌ Initial configuration update failed: \(error.localizedDescription)")
        }
        
        // 3. Second Run: Simulate a configuration update
        // The key should now be in the Keychain, so it will be retrieved from there.
        // The mock server is updated to provide the `updatedConfig`.
        print("\n--- DEMO PHASE 2: Configuration Update (Key from Keychain) ---")
        MockURLProtocol.mockResponses[configURL] = encryptedUpdatedConfigData // Server now provides updated config
        
        do {
            try await manager.updateAndApplySecureConfiguration()
            if let config = manager.currentConfiguration {
                print("Current active configuration: Version \(config.version), Threshold \(config.confidenceThreshold)")
            }
        } catch {
            print("❌ Configuration update failed: \(error.localizedDescription)")
        }
        
        // 4. Third Run: Simulate a forced key refresh
        // This simulates a scenario where the server issues a new key (e.g., subscription renewal).
        // A new `MockServer` instance is created to generate a *different* symmetric key.
        print("\n--- DEMO PHASE 3: Forced Key Refresh and Configuration Update ---")
        let newMockServer = MockServer() // A new server instance implies a new, different key
        MockURLProtocol.mockResponses[keyURL] = newMockServer.getSymmetricKeyForClient() // New key from new server
        // The config must also be re-encrypted with the *new* key
        MockURLProtocol.mockResponses[configURL] = try! newMockServer.encryptConfigurationOnServer(config: updatedConfig)
        
        do {
            try await manager.updateAndApplySecureConfiguration(forceRefreshKey: true)
            if let config = manager.currentConfiguration {
                print("Current active configuration: Version \(config.version), Threshold \(config.confidenceThreshold)")
            }
        } catch {
            print("❌ Forced key refresh and update failed: \(error.localizedDescription)")
        }
        
        // Clean up mock URL protocol
        URLProtocol.unregisterClass(MockURLProtocol.self)
        
        print("\n--- Secure AI Configuration Demo Finished ---")
    }
}
