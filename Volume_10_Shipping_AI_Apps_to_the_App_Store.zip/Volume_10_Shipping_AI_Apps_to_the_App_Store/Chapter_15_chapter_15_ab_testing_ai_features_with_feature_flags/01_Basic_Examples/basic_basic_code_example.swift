
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Foundation

// MARK: - Domain Models

/// Defines the available variants for our AI feature A/B test.
/// Conforming to `Sendable` is crucial for passing this across actor boundaries in Swift 6.
enum AIModelVariant: String, Sendable, CaseIterable {
    case standard
    case enhanced
}

/// An error type specifically for our AI orchestration logic.
enum AIError: Error, LocalizedError {
    case modelFailure
    case flagServiceUnavailable
    
    var errorDescription: String? {
        switch self {
        case .modelFailure: return "The AI model failed to generate a response."
        case .flagServiceUnavailable: return "Could not retrieve feature flags."
        }
    }
}

// MARK: - Protocols

/// The blueprint for any AI model implementation.
/// By using a protocol, the ViewModel doesn't care *which* model it's using,
/// only that the model can respond to a prompt.
protocol AIModel: Sendable {
    var modelName: String { get }
    func generateResponse(for prompt: String) async throws -> String
}

// MARK: - Feature Flag Service

/// An actor-based service responsible for managing feature flags.
/// Using an `actor` ensures that if we were to update these flags from a 
/// background network task (e.g., Firebase Remote Config), there would be no data races.
actor FeatureFlagService {
    /// In a real-world app, this would be populated by a remote configuration service.
    private var activeVariants: [String: AIModelVariant] = [:]
    
    /// Initializes the service with some mock data.
    init() {
        // Simulating a remote config fetch where 'enhanced' is enabled for a test group.
        activeVariants["voice_assistant_model"] = .enhanced
    }
    
    /// Retrieves the assigned variant for a specific feature key.
    /// - Parameter key: The unique identifier for the feature.
    /// - Returns: The assigned `AIModelVariant`.
    func variant(for key: String) -> AIModelVariant {
        return activeVariants[key] ?? .standard
    }
}

// MARK: - AI Model Implementations

/// A lightweight, fast AI model implementation.
/// Suitable for simple tasks or when battery life is a priority.
struct StandardAIModel: AIModel {
    let modelName = "Swift-Nano-v1"
    
    func generateResponse(for prompt: String) async throws -> String {
        // Simulate network/compute latency
        try await Task.sleep(for: .seconds(1))
        return "Standard Response: I heard you say '\(prompt)'. How can I help further?"
    }
}

/// A heavy, high-reasoning AI model implementation.
/// Provides much better quality but at the cost of latency and compute.
struct EnhancedAIModel: AIModel {
    let modelName = "Swift-Ultra-Reasoning-v2"
    
    func generateResponse(for prompt: String) async throws -> String {
        // Simulate much higher latency for complex reasoning
        try await Task.sleep(for: .seconds(3))
        return "Enhanced Response: After analyzing your request regarding '\(prompt)', I recommend..."
    }
}

// MARK: - ViewModel

/// The orchestrator of the UI and AI logic.
/// Marked with `@MainActor` to ensure all UI updates happen on the main thread.
@MainActor
class VoiceAssistantViewModel: ObservableObject {
    @Published var responseText: String = "Waiting for input..."
    @Published var isProcessing: Bool = false
    @Published var activeModelName: String = "None"
    @Published var errorMessage: String?
    
    private let flagService: FeatureFlagService
    
    /// Dependency Injection: We pass the service in to make testing easier.
    init(flagService: FeatureFlagService) {
        self.flagService = flagService
    }
    
    /// The core logic for processing a user request.
    /// This demonstrates the A/B testing flow:
    /// 1. Check the flag.
    /// 2. Resolve the dependency (the model).
    /// 3. Execute the task.
    func processUserPrompt(_ prompt: String) async {
        isProcessing = true
        errorMessage = nil
        
        // 1. Fetch the variant from the actor (requires 'await')
        let variant = await flagService.variant(for: "voice_assistant_model")
        
        // 2. Resolve which model to use based on the variant
        // This is the "Switch" that makes A/B testing possible.
        let model: any AIModel = {
            switch variant {
            case .standard:
                return StandardAIModel()
            case .enhanced:
                return EnhancedAIModel()
            }
        }()
        
        activeModelName = model.modelName
        
        do {
            // 3. Execute the AI generation
            let result = try await model.generateResponse(for: prompt)
            self.responseText = result
        } catch {
            self.errorMessage = error.localizedDescription
            self.responseText = "Error occurred."
        }
        
        isProcessing = false
    }
}

// MARK: - View Layer

@available(iOS 18.0, *)
struct VoiceAssistantView: View {
    @StateObject private var viewModel: VoiceAssistantViewModel
    @State private var userInput: String = ""
    
    init(flagService: FeatureFlagService) {
        // Initialize StateObject with the injected service
        _viewModel = StateObject(wrappedValue: VoiceAssistantViewModel(flagService: flagService))
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                // Status Indicator
                HStack {
                    Circle()
                        .fill(viewModel.isProcessing ? Color.orange : Color.green)
                        .frame(width: 10, height: 10)
                    Text("Model: \(viewModel.activeModelName)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                
                // Response Area
                ScrollView {
                    Text(viewModel.responseText)
                        .font(.title3)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(maxHeight: .infinity)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(12)
                
                if let error = viewModel.errorMessage {
                    Text(error)
                        .font(.caption)
                        .foregroundStyle(.red)
                }
                
                // Input Area
                HStack {
                    TextField("Type a prompt...", text: $userInput)
                        .textFieldStyle(.roundedBorder)
                        .disabled(viewModel.isProcessing)
                    
                    Button {
                        let prompt = userInput
                        userInput = ""
                        Task {
                            await viewModel.processUserPrompt(prompt)
                        }
                    } label: {
                        if viewModel.isProcessing {
                            ProgressView()
                        } else {
                            Image(systemName: "paperplane.fill")
                        }
                    }
                    .disabled(viewModel.isProcessing || userInput.isEmpty)
                }
            }
            .padding()
            .navigationTitle("AI Assistant")
        }
    }
}

// MARK: - App Entry Point (Mock)

@main
struct AIAvancedApp: App {
    let flagService = FeatureFlagService()
    
    var body: some Scene {
        WindowGroup {
            VoiceAssistantView(flagService: flagService)
        }
    }
}
