
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

// MARK: - 1. Structured Data Definition & Mock Data

struct SaleRecord: Codable, Identifiable {
    let id: UUID
    let productName: String
    let amount: Double
    let region: String
    let date: Date
    
    init(productName: String, amount: Double, region: String, date: Date) {
        self.id = UUID()
        self.productName = productName
        self.amount = amount
        self.region = region
        self.date = date
    }
}

// Mock local sales data
let mockSalesData: [SaleRecord] = [
    SaleRecord(productName: "Product A", amount: 120.0, region: "New York", date: Date.from(year: 2023, month: 10, day: 15)!),
    SaleRecord(productName: "Product B", amount: 250.0, region: "Los Angeles", date: Date.from(year: 2023, month: 10, day: 20)!),
    SaleRecord(productName: "Product A", amount: 150.0, region: "New York", date: Date.from(year: 2023, month: 11, day: 5)!),
    SaleRecord(productName: "Product C", amount: 75.0, region: "Chicago", date: Date.from(year: 2023, month: 11, day: 10)!),
    SaleRecord(productName: "Product A", amount: 200.0, region: "New York", date: Date.from(year: 2023, month: 11, day: 25)!),
    SaleRecord(productName: "Product B", amount: 300.0, region: "Los Angeles", date: Date.from(year: 2023, month: 12, day: 1)!),
    SaleRecord(productName: "Product C", amount: 90.0, region: "Chicago", date: Date.from(year: 2023, month: 12, day: 10)!),
    SaleRecord(productName: "Product A", amount: 180.0, region: "New York", date: Date.from(year: 2024, month: 1, day: 1)!),
    SaleRecord(productName: "Product B", amount: 280.0, region: "Los Angeles", date: Date.from(year: 2024, month: 1, day: 5)!),
    SaleRecord(productName: "Product D", amount: 50.0, region: "Miami", date: Date.from(year: 2024, month: 1, day: 15)!),
]

// Helper for creating dates from components
extension Date {
    static func from(year: Int, month: Int, day: Int) -> Date? {
        var components = DateComponents()
        components.year = year
        components.month = month
        components.day = day
        return Calendar.current.date(from: components)
    }
}

// MARK: - 2. Tool Definition (Swift Function)

enum SalesQueryError: Error, CustomStringConvertible {
    case invalidAggregationType(type: String)
    case noMatchingData
    case invalidDateRange
    
    var description: String {
        switch self {
        case .invalidAggregationType(let type): return "Invalid aggregation type: '\(type)'. Expected 'total_sales', 'average_amount', or 'count_orders'."
        case .noMatchingData: return "No sales data found matching the specified criteria."
        case .invalidDateRange: return "Invalid date range: start date must be before or equal to end date."
        }
    }
}

func querySalesData(
    productName: String?,
    region: String?,
    startDate: Date?,
    endDate: Date?,
    aggregation: String?
) throws -> [String: Any] {
    
    var filteredRecords = mockSalesData
    
    // 1. Filter by product name
    if let productName = productName {
        filteredRecords = filteredRecords.filter { $0.productName.caseInsensitiveCompare(productName) == .orderedSame }
    }
    
    // 2. Filter by region
    if let region = region {
        filteredRecords = filteredRecords.filter { $0.region.caseInsensitiveCompare(region) == .orderedSame }
    }
    
    // 3. Filter by date range
    if let startDate = startDate, let endDate = endDate {
        guard startDate <= endDate else {
            throw SalesQueryError.invalidDateRange
        }
        filteredRecords = filteredRecords.filter { record in
            record.date >= startDate && record.date <= endDate
        }
    } else if let startDate = startDate { // Only start date provided, filter from start date onwards
        filteredRecords = filteredRecords.filter { $0.date >= startDate }
    } else if let endDate = endDate { // Only end date provided, filter up to end date
        filteredRecords = filteredRecords.filter { $0.date <= endDate }
    }
    
    guard !filteredRecords.isEmpty else {
        throw SalesQueryError.noMatchingData
    }
    
    // 4. Apply aggregation
    let aggregationType = aggregation?.lowercased() ?? "count_orders" // Default aggregation
    
    var result: [String: Any] = [:]
    
    switch aggregationType {
    case "total_sales":
        let total = filteredRecords.reduce(0.0) { $0 + $1.amount }
        result["total_sales"] = total
    case "average_amount":
        let total = filteredRecords.reduce(0.0) { $0 + $1.amount }
        let average = total / Double(filteredRecords.count)
        result["average_amount"] = average
    case "count_orders":
        result["count_orders"] = filteredRecords.count
    default:
        throw SalesQueryError.invalidAggregationType(type: aggregationType)
    }
    
    return result
}

// MARK: - 3. Tool Description (JSON Schema - Manual Representation)

let salesQueryToolSchema: [String: Any] = [
    "type": "function",
    "function": [
        "name": "querySalesData",
        "description": "Queries local sales data with optional filters and performs aggregation. Returns a dictionary with the aggregated result.",
        "parameters": [
            "type": "object",
            "properties": [
                "productName": ["type": "string", "description": "Optional: Filter by product name (e.g., 'Product A')"],
                "region": ["type": "string", "description": "Optional: Filter by sales region (e.g., 'New York')"],
                "startDate": ["type": "string", "format": "date", "description": "Optional: Filter sales from this date (ISO 8601 format, e.g., '2023-10-01')"],
                "endDate": ["type": "string", "format": "date", "description": "Optional: Filter sales up to this date (ISO 8601 format, e.g., '2023-10-31')"],
                "aggregation": ["type": "string", "enum": ["total_sales", "average_amount", "count_orders"], "description": "Optional: Type of aggregation to perform. Defaults to 'count_orders'."]
            ],
            "required": [] // All parameters are optional, but LLM should infer based on prompt
        ]
    ]
]

// MARK: - 4. LLM Integration (Mocking LLM Output)

// Structs to decode the LLM's expected JSON tool call output
struct SalesQueryArguments: Codable {
    let productName: String?
    let region: String?
    let startDate: String? // Will be parsed to Date
    let endDate: String?   // Will be parsed to Date
    let aggregation: String?
}

struct SalesToolCall: Codable {
    let toolName: String
    let arguments: SalesQueryArguments
}

// Date formatter for ISO 8601 strings
let iso8601Formatter: ISO8601DateFormatter = {
    let formatter = ISO8601DateFormatter()
    formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    return formatter
}()

// Simulate LLM's response
func simulateLLMSalesToolCall(for prompt: String) -> SalesToolCall? {
    if prompt.contains("sales") || prompt.contains("orders") || prompt.contains("revenue") {
        if prompt.contains("total sales for Product A last month") {
            // Assuming "last month" for January 2024 is December 2023
            return SalesToolCall(toolName: "querySalesData", arguments: SalesQueryArguments(
                productName: "Product A", region: nil, startDate: "2023-12-01T00:00:00Z", endDate: "2023-12-31T23:59:59Z", aggregation: "total_sales"))
        } else if prompt.contains("average order value for customers in New York") {
            return SalesToolCall(toolName: "querySalesData", arguments: SalesQueryArguments(
                productName: nil, region: "New York", startDate: nil, endDate: nil, aggregation: "average_amount"))
        } else if prompt.contains("how many orders for Product B in Los Angeles this year") {
            // Assuming "this year" is 2024
            return SalesToolCall(toolName: "querySalesData", arguments: SalesQueryArguments(
                productName: "Product B", region: "Los Angeles", startDate: "2024-01-01T00:00:00Z", endDate: "2024-12-31T23:59:59Z", aggregation: "count_orders"))
        } else if prompt.contains("all sales data for Product D") {
            return SalesToolCall(toolName: "querySalesData", arguments: SalesQueryArguments(
                productName: "Product D", region: nil, startDate: nil, endDate: nil, aggregation: "total_sales"))
        } else if prompt.contains("sales in Q4 2023") {
            return SalesToolCall(toolName: "querySalesData", arguments: SalesQueryArguments(
                productName: nil, region: nil, startDate: "2023-10-01T00:00:00Z", endDate: "2023-12-31T23:59:59Z", aggregation: "total_sales"))
        } else if prompt.contains("total sales for Product Z") { // No matching data
            return SalesToolCall(toolName: "querySalesData", arguments: SalesQueryArguments(
                productName: "Product Z", region: nil, startDate: nil, endDate: nil, aggregation: "total_sales"))
        } else if prompt.contains("invalid aggregation type") { // Invalid aggregation
            return SalesToolCall(toolName: "querySalesData", arguments: SalesQueryArguments(
                productName: nil, region: nil, startDate: nil, endDate: nil, aggregation: "invalid_sum"))
        }
    }
    return nil
}

// MARK: - 5. Tool Execution

func executeSalesToolCall(toolCall: SalesToolCall) -> String {
    
    // Parse date strings to Date objects
    var startDate: Date?
    if let dateString = toolCall.arguments.startDate {
        startDate = iso8601Formatter.date(from: dateString)
    }
    var endDate: Date?
    if let dateString = toolCall.arguments.endDate {
        endDate = iso8601Formatter.date(from: dateString)
    }
    
    do {
        let result = try querySalesData(
            productName: toolCall.arguments.productName,
            region: toolCall.arguments.region,
            startDate: startDate,
            endDate: endDate,
            aggregation: toolCall.arguments.aggregation
        )
        
        // Format the result for LLM feedback
        let resultString = result.map { (key, value) in
            if let doubleValue = value as? Double {
                return "\(key): \(String(format: "%.2f", doubleValue))"
            } else {
                return "\(key): \(value)"
            }
        }.joined(separator: ", ")
        
        return "Tool 'querySalesData' executed successfully. Raw data: [\(resultString)]"
        
    } catch let error as SalesQueryError {
        return "Error executing tool 'querySalesData': \(error.description)"
    } catch {
        return "An unexpected error occurred: \(error.localizedDescription)"
    }
}

// MARK: - 6. Result Interpretation by LLM (Mock)

func summarizeResultForUser(rawResult: String, originalPrompt: String) -> String {
    // In a real scenario, this would be another LLM call:
    // LLM_API.send(messages: [user_prompt, tool_output_message(rawResult)], prompt: "Summarize this data for the user in natural language.")
    
    // For this mock, we'll simulate a simple summary.
    if rawResult.contains("Error") || rawResult.contains("No sales data") {
        return "I encountered an issue when trying to get the data: \(rawResult). Please try a different query."
    } else if rawResult.contains("total_sales") {
        if let range = rawResult.range(of: "total_sales: ") {
            let startIndex = rawResult.index(range.upperBound, offsetBy: 0)
            let endIndex = rawResult.firstIndex(of: ",") ?? rawResult.endIndex
            let totalSales = rawResult[startIndex..<endIndex].trimmingCharacters(in: .whitespaces)
            return "The total sales for your query are approximately \(totalSales)."
        }
    } else if rawResult.contains("average_amount") {
        if let range = rawResult.range(of: "average_amount: ") {
            let startIndex = rawResult.index(range.upperBound, offsetBy: 0)
            let endIndex = rawResult.firstIndex(of: ",") ?? rawResult.endIndex
            let averageAmount = rawResult[startIndex..<endIndex].trimmingCharacters(in: .whitespaces)
            return "The average amount for your query is about \(averageAmount)."
        }
    } else if rawResult.contains("count_orders") {
        if let range = rawResult.range(of: "count_orders: ") {
            let startIndex = rawResult.index(range.upperBound, offsetBy: 0)
            let endIndex = rawResult.firstIndex(of: ",") ?? rawResult.endIndex
            let countOrders = rawResult[startIndex..<endIndex].trimmingCharacters(in: .whitespaces)
            return "There were \(countOrders) orders matching your criteria."
        }
    }
    return "I found some data, but I'm having trouble summarizing it: \(rawResult)"
}


// MARK: - Main Interaction Flow (Simulation)

func processUserSalesPrompt(prompt: String) {
    print("User: \(prompt)")
    
    if let toolCall = simulateLLMSalesToolCall(for: prompt) {
        print("LLM suggests tool call: \(toolCall.toolName) with arguments: \(toolCall.arguments)")
        let rawExecutionResult = executeSalesToolCall(toolCall: toolCall)
        print("Raw Tool Execution Result: \(rawExecutionResult)")
        
        let summarizedResponse = summarizeResultForUser(rawResult: rawExecutionResult, originalPrompt: prompt)
        print("AI Assistant: \(summarizedResponse)")
    } else {
        print("AI Assistant: I can't find a suitable sales data tool for that request.")
    }
    print("---")
}

// Test cases
processUserSalesPrompt(prompt: "What were the total sales for 'Product A' last month?")
processUserSalesPrompt(prompt: "Show me the average order value for customers in 'New York'.")
processUserSalesPrompt(prompt: "How many orders for Product B in Los Angeles this year?")
processUserSalesPrompt(prompt: "What were the sales in Q4 2023?")
processUserSalesPrompt(prompt: "Total sales for Product D.") // Should find data
processUserSalesPrompt(prompt: "Total sales for Product Z.") // No matching data
processUserSalesPrompt(prompt: "Show me sales with invalid aggregation type.") // Invalid aggregation type
processUserSalesPrompt(prompt: "Tell me a story.") // No sales tool
