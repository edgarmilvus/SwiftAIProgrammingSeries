
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

// MARK: - 1. Tool Argument Definitions

/// @available annotation for macOS 15.0 to align with latest Swift features.
@available(macOS 15.0, *)
enum SmartHomeTools {
    /// Arguments for setting a light's color.
    struct SetLightColorArgs: Codable {
        let room: String
        let color: String // e.g., "red", "blue", "white"
    }

    /// Arguments for setting a light's brightness.
    struct SetLightBrightnessArgs: Codable {
        let room: String
        let brightness: Int // 0-100
    }

    /// Arguments for getting the current temperature in a room.
    struct GetRoomTemperatureArgs: Codable {
        let room: String
    }

    /// Arguments for setting the thermostat temperature.
    struct SetThermostatTemperatureArgs: Codable {
        let room: String
        let temperature: Double
    }

    /// Arguments for playing music in a room.
    struct PlayMusicArgs: Codable {
        let room: String
        let songTitle: String? // Optional song title
        let artist: String?    // Optional artist
        let genre: String?     // Optional genre
    }
}
