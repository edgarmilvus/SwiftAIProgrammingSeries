
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor EmbeddingService {
    // In a real scenario, this would wrap a Core ML model or llama.cpp embedding model
    private var model: SomeLocalEmbeddingModel // e.g., SentenceTransformer via Core ML

    init(model: SomeLocalEmbeddingModel) {
        self.model = model
    }

    func generateEmbedding(for text: String) async throws -> [Float] {
        // Simulate an asynchronous embedding generation
        print("Generating embedding for: \(text.prefix(20))... on actor thread")
        try await Task.sleep(for: .milliseconds(100))
        // Actual model inference would happen here
        let embedding = (0..<768).map { _ in Float.random(in: -1...1) } // Placeholder
        return embedding
    }
}

@available(iOS 18.0, *)
actor LocalVectorStore {
    private var vectors: [[Float]] = []
    private var texts: [String] = []
    private var metadatas: [[String: String]] = []
    // In a real scenario, this would be an optimized in-memory or on-disk vector index (e.g., HNSW)

    func addEmbedding(_ embedding: [Float], text: String, metadata: [String: String]) {
        vectors.append(embedding)
        texts.append(text)
        metadatas.append(metadata)
        print("Added embedding. Total: \(vectors.count)")
    }

    func search(_ queryEmbedding: [Float], topK: Int) async -> [(text: String, metadata: [String: String], score: Float)] {
        print("Searching vector store with \(vectors.count) items...")
        try? await Task.sleep(for: .milliseconds(50)) // Simulate search time

        // Simplified similarity search (e.g., dot product or cosine similarity)
        // In reality, this would use an optimized ANN library.
        let results = vectors.enumerated().map { (index, vector) in
            let score = calculateCosineSimilarity(queryEmbedding, vector)
            return (text: texts[index], metadata: metadatas[index], score: score)
        }
        return results.sorted { $0.score > $1.score }.prefix(topK).map { $0 }
    }

    private func calculateCosineSimilarity(_ vec1: [Float], _ vec2: [Float]) -> Float {
        guard !vec1.isEmpty && !vec2.isEmpty else { return 0.0 }
        let dotProduct = zip(vec1, vec2).map(*).reduce(0, +)
        let magnitude1 = sqrt(vec1.map { $0 * $0 }.reduce(0, +))
        let magnitude2 = sqrt(vec2.map { $0 * $0 }.reduce(0, +))
        guard magnitude1 != 0 && magnitude2 != 0 else { return 0.0 }
        return dotProduct / (magnitude1 * magnitude2)
    }
}
