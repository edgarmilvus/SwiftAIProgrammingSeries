
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import StoreKit
import Observation

// MARK: - Domain Models & Errors

/// Represents the specific reasons why an AI feature might be inaccessible.
/// Using a specialized error type allows the UI to react contextually.
enum AIFeatureError: LocalizedError {
    case insufficientCredits(required: Int, available: Int)
    case modelTierLocked(requiredTier: ModelTier)
    case rateLimitExceeded(retryAfter: TimeInterval)
    case hardwareConstraint(reason: String)

    var errorDescription: String? {
        switch self {
        case .insufficientCredits(let req, let avail):
            return "You need \(req) credits for this high-res generation, but you only have \(avail)."
        case .modelTierLocked(let tier):
            return "The \(tier.rawValue) model is available to Pro subscribers."
        case .rateLimitExceeded(let retry):
            return "Too many requests. Please wait \(Int(retry)) seconds."
        case .hardwareConstraint(let reason):
            return "Generation failed: \(reason)"
        }
    }
}

/// Defines the complexity levels of AI models.
enum ModelTier: String, CaseIterable, Sendable {
    case standard = "Standard"
    case cinematic = "Cinematic"
    case ultraRealism = "Ultra-Realism"
}

// MARK: - Monetization & Credit Management

/// An Actor to manage user credits, ensuring thread-safety when multiple
/// concurrent AI tasks attempt to deduct credits simultaneously.
@available(iOS 18.0, *)
actor CreditManager {
    private(set) var availableCredits: Int
    private let maxCredits: Int
    
    init(initialCredits: Int, maxCredits: Int) {
        self.availableCredits = initialCredits
        self.maxCredits = maxCredits
    }
    
    /// Attempts to deduct credits for a specific AI task.
    /// - Parameter amount: The cost of the operation.
    /// - Throws: `AIFeatureError.insufficientCredits` if the user cannot afford the task.
    func consume(amount: Int) throws {
        guard availableCredits >= amount else {
            throw AIFeatureError.insufficientCredits(required: amount, available: availableCredits)
        }
        availableCredits -= amount
    }
    
    /// Resets or adds credits upon successful StoreKit transaction.
    func replenish(amount: Int) {
        availableCredits = min(maxCredits, availableCredits + amount)
    }
}

/// Manages the connection between the app and Apple's StoreKit 2.
@available(iOS 18.0, *)
@Observable
final class SubscriptionManager {
    private(set) var isProSubscriber: Bool = false
    private var updateTask: Task<Void, Never>?
    
    init() {
        Task {
            await updateSubscriptionStatus()
            startListeningForTransactions()
        }
    }
    
    /// Checks the current transaction history to verify subscription status.
    func updateSubscriptionStatus() async {
        // In a real app, you would check for specific Product IDs
        for await result in Transaction.currentEntitlements {
            guard case .verified(let transaction) = result else { continue }
            if transaction.revocationDate == nil {
                self.isProSubscriber = true
                return
            }
        }
        self.isProSubscriber = false
    }
    
    /// Listens for real-time transaction updates (e.g., renewals, cancellations).
    private func startListeningForTransactions() {
        updateTask = Task.detached {
            for await result in Transaction.updates {
                guard case .verified(let transaction) = result else { continue }
                await self.updateSubscriptionStatus()
                // Notify the system of successful purchase
                NotificationCenter.default.post(name: .subscriptionDidUpdate, object: nil)
            }
        }
    }
    
    deinit {
        updateTask?.cancel()
    }
}

extension Notification.Name {
    static let subscriptionDidUpdate = Notification.Name("subscriptionDidUpdate")
}

// MARK: - AI Service Layer

/// The core engine that simulates AI generation.
@available(iOS 18.0, *)
final class AIGenerationService: Sendable {
    private let creditManager: CreditManager
    
    init(creditManager: CreditManager) {
        self.creditManager = creditManager
    }
    
    /// Simulates an asynchronous AI generation process.
    /// - Parameters:
    ///   - prompt: The text describing the image.
    ///   - tier: The complexity of the model requested.
    /// - Returns: A simulated image name.
    /// - Throws: `AIFeatureError` if credits are low or tier is locked.
    func generateImage(prompt: String, tier: ModelTier, isPro: Bool) async throws -> String {
        // 1. Validate Tier Access
        if tier == .ultraRealism && !isPro {
            throw AIFeatureError.modelTierLocked(requiredTier: .ultraRealism)
        }
        
        // 2. Determine Cost
        let cost = tier == .standard ? 1 : (tier == .cinematic ? 3 : 10)
        
        // 3. Attempt Credit Consumption (Atomic)
        // This is the "Feature Gate" in action.
        try await creditManager.consume(amount: cost)
        
        // 4. Simulate Network/GPU Latency
        try await Task.sleep(for: .seconds(2))
        
        // 5. Return Result
        return "Generated_Image_\(UUID().uuidString.prefix(8)).png"
    }
}

// MARK: - View Models

@available(iOS 18.0, *)
@Observable
final class GenerationViewModel {
    var prompt: String = ""
    var isGenerating: Bool = false
    var lastGeneratedImage: String?
    var errorMessage: String?
    var showPaywall: Bool = false
    
    // Contextual error storage to tell the paywall *why* it's showing
    var activeError: AIFeatureError?
    
    private let aiService: AIGenerationService
    private let subscriptionManager: SubscriptionManager
    private let creditManager: CreditManager
    
    init(aiService: AIGenerationService, 
         subscriptionManager: SubscriptionManager, 
         creditManager: CreditManager) {
        self.aiService = aiService
        self.subscriptionManager = subscriptionManager
        self.creditManager = creditManager
    }
    
    @MainActor
    func performGeneration(tier: ModelTier) async {
        isGenerating = true
        errorMessage = nil
        activeError = nil
        
        do {
            let result = try await aiService.generateImage(
                prompt: prompt,
                tier: tier,
                isPro: subscriptionManager.isProSubscriber
            )
            lastGeneratedImage = result
        } catch let error as AIFeatureError {
            handleAIError(error)
        } catch {
            errorMessage = "An unexpected error occurred."
        }
        
        isGenerating = false
    }
    
    @MainActor
    private func handleAIError(_ error: AIFeatureError) {
        self.activeError = error
        
        switch error {
        case .insufficientCredits, .modelTierLocked:
            // Trigger the contextual paywall
            self.showPaywall = true
        case .rateLimitExceeded, .hardwareConstraint:
            // Trigger a simple error toast instead of a paywall
            self.errorMessage = error.localizedDescription
        }
    }
    
    @MainActor
    func replenishCredits() async {
        // Simulate a successful purchase
        await creditManager.replenish(amount: 50)
        showPaywall = false
    }
}

// MARK: - UI Components

@available(iOS 18.0, *)
struct PaywallView: View {
    let error: AIFeatureError
    let onPurchase: () -> Void
    let onDismiss: () -> Void
    
    var body: some View {
        VStack(spacing: 24) {
            Image(systemName: "sparkles")
                .font(.system(size: 60))
                .foregroundStyle(.purple.gradient)
            
            Text("Unlock Full Potential")
                .font(.title.bold())
            
            Text(error.localizedDescription)
                .font(.body)
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
            
            VStack(spacing: 12) {
                Button(action: onPurchase) {
                    Text("Upgrade to Pro")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(.blue)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                
                Button(action: onDismiss) {
                    Text("Maybe Later")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 40)
        }
        .padding(30)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 28))
        .shadow(radius: 20)
        .padding()
    }
}

@available(iOS 18.0, *)
struct MainAppView: View {
    // In a real app, these would be injected via Environment or a DI container
    @State private var subscriptionManager = SubscriptionManager()
    @State private var creditManager = CreditManager(initialCredits: 5, maxCredits: 100)
    @State private var viewModel: GenerationViewModel!
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
                
                VStack(spacing: 20) {
                    // Header Info
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Lumina AI")
                                .font(.title2.bold())
                            Text("Creative Assistant")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        // Credit Display
                        Text("Credits: \(currentCredits)")
                            .font(.caption.monospaced())
                            .padding(8)
                            .background(.white)
                            .clipShape(Capsule())
                            .shadow(radius: 1)
                    }
                    .padding(.horizontal)
                    
                    // Prompt Input
                    TextField("Describe your imagination...", text: $viewModel.prompt, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .lineLimit(3...5)
                        .padding(.horizontal)
                    
                    // Model Selection
                    Picker("Model Tier", selection: .constant(ModelTier.cinematic)) {
                        ForEach(ModelTier.allCases, id: \.self) { tier in
                            Text(tier.rawValue).tag(tier)
                        }
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal)
                    
                    // Generation Button
                    Button(action: {
                        Task { await viewModel.performGeneration(tier: .cinematic) }
                    }) {
                        Group {
                            if viewModel.isGenerating {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Text("Generate Cinematic Image")
                                    .fontWeight(.semibold)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(viewModel.isGenerating ? Color.gray : Color.purple)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .disabled(viewModel.isGenerating || viewModel.prompt.isEmpty)
                    .padding(.horizontal)
                    
                    // Result Area
                    Spacer()
                    
                    if let image = viewModel.lastGeneratedImage {
                        VStack {
                            Text("Latest Creation:")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            RoundedRectangle(cornerRadius: 12)
                                .fill(.white)
                                .overlay(Text(image).font(.caption2))
                                .frame(height: 200)
                                .shadow(radius: 5)
                        }
                        .padding()
                    } else {
                        ContentUnavailableView("No Image Generated", 
                            systemImage: "photo.on.rectangle", 
                            description: Text("Enter a prompt to begin your journey."))
                    }
                    
                    Spacer()
                }
                
                // Contextual Paywall Overlay
                if viewModel.showPaywall, let error = viewModel.activeError {
                    Color.black.opacity(0.4)
                        .ignoresSafeArea()
                        .onTapGesture { /* Prevent dismissal by tapping background */ }
                    
                    PaywallView(error: error, onPurchase: {
                        Task { await viewModel.replenishCredits() }
                    }, onDismiss: {
                        viewModel.showPaywall = false
                    })
                    .transition(.scale.combined(with: .opacity))
                }
                
                // Error Toast
                if let errorMsg = viewModel.errorMessage {
                    VStack {
                        Text(errorMsg)
                            .font(.subheadline)
                            .padding()
                            .background(.black.opacity(0.8))
                            .foregroundStyle(.white)
                            .cornerRadius(10)
                            .padding(.top, 50)
                        Spacer()
                    }
                    .transition(.move(edge: .top))
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                // Dependency Injection Simulation
                let service = AIGenerationService(creditManager: creditManager)
                viewModel = GenerationViewModel(
                    aiService: service,
                    subscriptionManager: subscriptionManager,
                    creditManager: creditManager
                )
            }
            .animation(.spring(), value: viewModel.showPaywall)
            .animation(.easeInOut, value: viewModel.errorMessage != nil)
        }
    }
    
    // Helper to read from actor in View
    private var currentCredits: Int {
        // In a real app, this would be an @Observable property 
        // updated by the CreditManager actor via a stream or notification.
        // For this demo, we'll assume a simplified state update.
        0 // Placeholder for brevity in the view logic
    }
}
