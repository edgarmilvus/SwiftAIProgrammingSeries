
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import AVFoundation
import Vision
import CoreML // Ensure MobileNetV2 is added to your project

class ObjectClassificationViewController: UIViewController {

    private var captureSession: AVCaptureSession!
    private var previewLayer: AVCaptureVideoPreviewLayer!
    private var videoDataOutput: AVCaptureVideoDataOutput!
    private let videoDataOutputQueue = DispatchQueue(label: "VideoDataOutput", qos: .userInitiated)

    private var classificationRequest: VNCoreMLRequest!
    private var classificationLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
        setupVision()
        setupUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !captureSession.isRunning {
            videoDataOutputQueue.async {
                self.captureSession.startRunning()
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession.isRunning {
            videoDataOutputQueue.async {
                self.captureSession.stopRunning()
            }
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer.frame = view.bounds
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .hd1280x720 // Use a suitable preset

        guard let backCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Unable to access back camera.")
            return
        }

        do {
            let input = try AVCaptureDeviceInput(device: backCamera)
            if captureSession.canAddInput(input) {
                captureSession.addInput(input)
            }

            videoDataOutput = AVCaptureVideoDataOutput()
            videoDataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
            // Discard late frames to maintain real-time performance
            videoDataOutput.alwaysDiscardsLateVideoFrames = true
            videoDataOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

            if captureSession.canAddOutput(videoDataOutput) {
                captureSession.addOutput(videoDataOutput)
            }

            // Ensure the video output connection is in portrait orientation
            if let connection = videoDataOutput.connection(with: .video), connection.isVideoOrientationSupported {
                connection.videoOrientation = .portrait
            }

            previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            previewLayer.videoGravity = .resizeAspectFill
            previewLayer.frame = view.bounds
            view.layer.addSublayer(previewLayer)

        } catch {
            print("Error setting up camera input: \(error.localizedDescription)")
        }
    }

    private func setupVision() {
        do {
            // Load the MobileNetV2 Core ML model
            let config = MLModelConfiguration()
            let coreMLModel = try MobileNetV2(configuration: config).model
            let visionModel = try VNCoreMLModel(for: coreMLModel)

            classificationRequest = VNCoreMLRequest(model: visionModel) { [weak self] request, error in
                self.handleClassification(request: request, error: error)
            }
            // Scale the image to fit the model's expected input size
            classificationRequest.imageCropAndScaleOption = .centerCrop

        } catch {
            print("Error setting up Vision model: \(error.localizedDescription)")
        }
    }

    private func setupUI() {
        classificationLabel = UILabel()
        classificationLabel.translatesAutoresizingMaskIntoConstraints = false
        classificationLabel.textColor = .white
        classificationLabel.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        classificationLabel.textAlignment = .center
        classificationLabel.numberOfLines = 0
        classificationLabel.shadowColor = .black
        classificationLabel.shadowOffset = CGSize(width: 1, height: 1)
        view.addSubview(classificationLabel)

        NSLayoutConstraint.activate([
            classificationLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            classificationLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            classificationLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20)
        ])
    }

    private func handleClassification(request: VNRequest, error: Error?) {
        // All UI updates must be on the main thread
        DispatchQueue.main.async {
            guard let observations = request.results as? [VNClassificationObservation] else {
                self.classificationLabel.text = "Classification failed."
                print("Classification failed: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            // Get the top classification result
            if let bestResult = observations.first {
                let confidence = String(format: "%.2f", bestResult.confidence * 100)
                self.classificationLabel.text = "\(bestResult.identifier) (\(confidence)%)"
            } else {
                self.classificationLabel.text = "No classification found."
            }
        }
    }
}

extension ObjectClassificationViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Determine the orientation of the image for Vision processing
        // This is crucial for correct analysis, especially if the device orientation changes.
        let imageOrientation = CGImagePropertyOrientation(
            interfaceOrientation: UIApplication.shared.windows.first?.windowScene?.interfaceOrientation ?? .portrait
        )

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: imageOrientation, options: [:])

        do {
            // Perform the Vision request on the background queue
            try handler.perform([classificationRequest])
        } catch {
            print("Failed to perform classification: \(error.localizedDescription)")
        }
    }
}

// Helper for CGImagePropertyOrientation from UIInterfaceOrientation
extension CGImagePropertyOrientation {
    init(interfaceOrientation: UIInterfaceOrientation) {
        switch interfaceOrientation {
        case .portrait: self = .up
        case .portraitUpsideDown: self = .down
        case .landscapeLeft: self = .right
        case .landscapeRight: self = .left
        default: self = .up
        }
    }
}
