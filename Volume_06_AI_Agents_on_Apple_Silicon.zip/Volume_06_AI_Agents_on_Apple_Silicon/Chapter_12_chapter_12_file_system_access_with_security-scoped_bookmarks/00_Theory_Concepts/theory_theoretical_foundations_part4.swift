
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

// Example: Passing bookmark data safely
@available(macOS 11.0, iOS 18.0, *)
func processModelChunk(bookmarkData: Data, chunkIndex: Int) async throws {
    // Data is Sendable, so it can be passed directly.
    let fileAccess = FileAccessManager()
    let modelData = try await fileAccess.readData(from: bookmarkData)
    // Process a specific chunk from modelData
    print("Processing chunk \(chunkIndex) from \(modelData.count) bytes.")
}

// In a calling context:
@available(macOS 11.0, iOS 18.0, *)
func distributeModelProcessing(mainModelBookmark: Data) async {
    await withTaskGroup(of: Void.self) { group in
        for i in 0..<4 { // Simulate processing 4 chunks concurrently
            group.addTask {
                do {
                    // Each task receives its own copy of the Sendable Data
                    try await processModelChunk(bookmarkData: mainModelBookmark, chunkIndex: i)
                } catch {
                    print("Error processing chunk \(i): \(error.localizedDescription)")
                }
            }
        }
    }
}
