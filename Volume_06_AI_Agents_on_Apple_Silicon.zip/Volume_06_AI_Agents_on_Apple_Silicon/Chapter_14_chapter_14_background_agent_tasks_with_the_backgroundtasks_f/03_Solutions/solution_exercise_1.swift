
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import BackgroundTasks
import UIKit // For AppDelegate context

// MARK: - Helper Logger (for all exercises)
struct Logger {
    static func log(_ message: String, category: String = "BackgroundTasks", isError: Bool = false) {
        let timestamp = DateFormatter.localizedString(from: Date(), dateStyle: .medium, timeStyle: .medium)
        let level = isError ? "ERROR" : "INFO"
        print("[\(timestamp)] [\(category)] [\(level)] \(message)")
    }
}

// MARK: - Mock API Service (for Exercise 1 & 2)
struct MockAPI {
    static let shared = MockAPI()

    enum APIError: Error {
        case invalidURL
        case networkError(Error)
        case decodingError(Error)
        case serverError(statusCode: Int)
        case cancelled
    }

    // Simulate fetching a small JSON config
    func fetchConfiguration() async throws -> AppConfiguration {
        Logger.log("Simulating fetching configuration...", category: "MockAPI")
        try await Task.sleep(nanoseconds: 1_000_000_000) // Simulate network delay
        if Task.isCancelled { throw APIError.cancelled }

        let jsonString = """
        {
            "version": "1.2.3",
            "featureFlags": {
                "newPromptEngine": true,
                "experimentalUI": false
            },
            "modelPreference": "fast"
        }
        """
        guard let data = jsonString.data(using: .utf8) else {
            let error = NSError(domain: "MockAPI", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to encode JSON string"])
            Logger.log("Failed to encode configuration JSON string: \(error.localizedDescription)", category: "MockAPI", isError: true)
            throw APIError.decodingError(error)
        }

        do {
            let config = try JSONDecoder().decode(AppConfiguration.self, from: data)
            Logger.log("Configuration fetched successfully: \(config.version)", category: "MockAPI")
            return config
        } catch {
            Logger.log("Failed to decode configuration: \(error.localizedDescription)", category: "MockAPI", isError: true)
            throw APIError.decodingError(error)
        }
    }

    // Other mock API methods would go here for subsequent exercises
    // ...
}

// MARK: - Models for Exercise 1
struct AppConfiguration: Codable {
    let version: String
    let featureFlags: [String: Bool]
    let modelPreference: String
}

// MARK: - AppDelegate / SceneDelegate context
class AppDelegate: UIResponder, UIApplicationDelegate {

    // MARK: - Background Task Identifiers
    static let appRefreshTaskIdentifier = "com.example.app.refreshConfig"
    // Other task identifiers for subsequent exercises would go here
    // ...

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        Logger.log("App finished launching.", category: "AppDelegate")
        registerBackgroundTasks() // Register all background tasks
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        Logger.log("App entered background. Scheduling tasks...", category: "AppDelegate")
        scheduleAppRefresh() // Schedule the app refresh task
        // Other task scheduling for subsequent exercises would go here
        // ...
    }

    // MARK: - Task Registration
    private func registerBackgroundTasks() {
        Logger.log("Registering background tasks...", category: "BGTaskScheduler")

        // Exercise 1: App Refresh Task
        BGTaskScheduler.shared.register(forIdentifier: AppDelegate.appRefreshTaskIdentifier, using: nil) { task in
            Logger.log("Received BGAppRefreshTask: \(task.identifier)", category: "BGTaskScheduler")
            self.handleAppRefresh(task: task as! BGAppRefreshTask)
        }
        // Other task registrations for subsequent exercises would go here
        // ...
    }

    // MARK: - Task Scheduling
    private func scheduleAppRefresh() {
        let request = BGAppRefreshTaskRequest(identifier: AppDelegate.appRefreshTaskIdentifier)
        // Fetch config at least 15 minutes from now, but system decides optimal time.
        request.earliestBeginDate = Date(timeIntervalSinceNow: 15 * 60)

        do {
            try BGTaskScheduler.shared.submit(request)
            Logger.log("Scheduled BGAppRefreshTask for \(AppDelegate.appRefreshTaskIdentifier)", category: "BGTaskScheduler")
        } catch {
            Logger.log("Could not schedule app refresh task: \(error.localizedDescription)", category: "BGTaskScheduler", isError: true)
        }
    }

    // MARK: - Task Handlers

    // Exercise 1: AI Agent Configuration Refresh Handler
    private func handleAppRefresh(task: BGAppRefreshTask) {
        Logger.log("Starting configuration refresh task...", category: "ConfigRefresh")

        // Create a new Task to perform asynchronous work.
        // The task.expirationHandler must be set immediately.
        let backgroundTask = Task {
            do {
                // Set the expiration handler immediately.
                // If the task expires, cancel the ongoing work.
                task.expirationHandler = {
                    Logger.log("Configuration refresh task expired. Cancelling...", category: "ConfigRefresh", isError: true)
                    backgroundTask.cancel() // Cancel the async Task
                    task.setTaskCompleted(success: false)
                }

                // Simulate fetching configuration
                let config = try await MockAPI.shared.fetchConfiguration()
                Logger.log("Fetched configuration version: \(config.version)", category: "ConfigRefresh")

                // Simulate storing the new configuration locally (e.g., in UserDefaults)
                // For simplicity, we just log here.
                Logger.log("Configuration refresh completed successfully.", category: "ConfigRefresh")
                task.setTaskCompleted(success: true)

            } catch {
                if let apiError = error as? MockAPI.APIError, apiError == .cancelled {
                    Logger.log("Configuration refresh task was cancelled.", category: "ConfigRefresh", isError: true)
                } else {
                    Logger.log("Configuration refresh failed: \(error.localizedDescription)", category: "ConfigRefresh", isError: true)
                }
                task.setTaskCompleted(success: false)
            }
        }
        // Retain the Task if needed for external cancellation, though expirationHandler handles it here.
        // In a real app, you might store `backgroundTask` in a property to cancel it from elsewhere.
    }

    // Other task handlers for subsequent exercises would go here
    // ...
}

/*
// --- Info.plist Configuration ---
// Add the following key-value pair to your app's Info.plist file:
//
// <key>BGTaskSchedulerPermittedIdentifiers</key>
// <array>
//     <string>com.example.app.refreshConfig</string>
// </array>
*/
