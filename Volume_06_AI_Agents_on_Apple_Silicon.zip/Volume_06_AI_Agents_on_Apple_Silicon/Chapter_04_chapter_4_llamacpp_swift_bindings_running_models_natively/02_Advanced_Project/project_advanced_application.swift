
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "AdvancedSummarizerApp",
    platforms: [
        .macOS(.v14), // Targeting macOS for a document summarizer, but could be iOS(.v18)
        .iOS(.v18) // Or iOS 18 for a universal app
    ],
    products: [
        .executable(
            name: "AdvancedSummarizerApp",
            targets: ["AdvancedSummarizerApp"]),
        .library( // Define a library for the core summarizer service
            name: "DocumentSummarizerService",
            targets: ["DocumentSummarizerService"])
    ],
    dependencies: [
        // This path should point to your llama.cpp.swift package.
        // For a real project, it would typically be a GitHub URL:
        // .package(url: "https://github.com/ggerganov/llama.cpp.swift", from: "0.1.0"),
        .package(path: "../llama.cpp.swift") // Assuming it's a sibling directory for local dev
    ],
    targets: [
        .target(
            name: "DocumentSummarizerService",
            dependencies: [
                .product(name: "llama_cpp", package: "llama.cpp.swift")
            ],
            swiftSettings: [
                // Enable upcoming Swift 6 features for stricter concurrency and better performance
                .enableUpcomingFeature("BareSlashRegexLiterals"),
                .enableUpcomingFeature("ExistentialAny"),
                .enableUpcomingFeature("ConciseMagicFile"),
                .enableUpcomingFeature("ForwardTrailingClosures"),
                .enableUpcomingFeature("ImplicitOpenExistentials"),
                .enableUpcomingFeature("StrictConcurrency"),
                .unsafeFlags(["-cross-module-optimization"], .when(configuration: .release))
            ]
        ),
        .executableTarget(
            name: "AdvancedSummarizerApp",
            dependencies: ["DocumentSummarizerService"]),
        .testTarget(
            name: "DocumentSummarizerServiceTests",
            dependencies: ["DocumentSummarizerService"]),
    ]
)
