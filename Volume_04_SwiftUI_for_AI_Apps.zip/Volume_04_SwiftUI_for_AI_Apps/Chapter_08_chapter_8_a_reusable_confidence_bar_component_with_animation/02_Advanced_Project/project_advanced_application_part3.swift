
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

/// A reusable SwiftUI view component that displays a confidence bar with an animated fill.
/// ... (full code above)
struct ConfidenceBarView: View {
    // ... properties and init ...
    var body: some View {
        HStack {
            Text(label) // Displays the classification label
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 5).fill(Color.gray.opacity(0.3)) // Background bar
                    RoundedRectangle(cornerRadius: 5)
                        .fill(fillColor(for: confidence))
                        .frame(width: currentFillWidth, height: 10)
                        .animation(.easeInOut(duration: 0.6), value: currentFillWidth) // Smooth animation
                }
                .onAppear { currentFillWidth = geometry.size.width * confidence } // Initial state
                .onChange(of: confidence) { newConfidence in
                    currentFillWidth = geometry.size.width * newConfidence // Trigger animation on change
                }
            }
            Text("\(Int(confidence * 100))%") // Displays percentage value
        }
    }
    private func fillColor(for confidence: Double) -> Color { /* ... color logic ... */ }
}
