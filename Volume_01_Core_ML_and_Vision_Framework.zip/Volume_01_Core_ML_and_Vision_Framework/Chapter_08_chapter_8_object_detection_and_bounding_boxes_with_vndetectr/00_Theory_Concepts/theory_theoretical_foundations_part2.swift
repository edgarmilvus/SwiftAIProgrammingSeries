
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor CameraFrameProcessor {
    // VNImageRequestHandler is not Sendable itself, so encapsulating it within an actor
    // ensures that access to it is serialized and thread-safe.
    private var currentHandler: VNImageRequestHandler?

    // Method to process a CVPixelBuffer frame
    func processFrame(_ pixelBuffer: CVPixelBuffer) async throws -> [VNRectangleObservation] {
        // Initialize or update the handler for the new frame within the actor's isolated context.
        // This ensures that only one frame is being processed by this handler at a time.
        self.currentHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer)

        let request = VNDetectRectanglesRequest()
        request.minimumAspectRatio = 0.5
        request.maximumAspectRatio = 2.0

        // Perform the request. This call is synchronous within the actor's isolated executor.
        // The 'await' on the calling side will handle the suspension.
        guard let handler = self.currentHandler else {
            throw VisionProcessingError.handlerNotInitialized
        }
        try handler.perform([request])

        guard let observations = request.results as? [VNRectangleObservation] else {
            return []
        }
        return observations
    }
}

@available(iOS 18.0, *)
enum VisionProcessingError: Error {
    case handlerNotInitialized
}

// Example usage from a view model
@available(iOS 18.0, *)
@Observable
class LiveDetectionViewModel {
    private let processor = CameraFrameProcessor()
    var latestRectangles: [VNRectangleObservation] = []
    var isProcessing: Bool = false

    func handleNewCameraFrame(pixelBuffer: CVPixelBuffer) {
        Task {
            isProcessing = true
            do {
                // Call the actor's method. The await here ensures the UI remains responsive.
                let observations = try await processor.processFrame(pixelBuffer)
                await MainActor.run { // Ensure UI updates on the main actor
                    self.latestRectangles = observations
                    self.isProcessing = false
                }
            } catch {
                print("Error processing frame: \(error)")
                await MainActor.run {
                    self.isProcessing = false
                }
            }
        }
    }
}
