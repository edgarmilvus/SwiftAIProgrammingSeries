
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Observation
import Foundation

// MARK: - Models

/// Represents the type of feedback provided by the user.
/// Using an enum ensures type safety when categorizing feedback for model training.
enum FeedbackRating: String, Codable, Sendable {
    case positive = "👍"
    case negative = "👎"
    case neutral = "😐"
}

/// The fundamental data unit of the feedback loop.
/// This struct captures the entire context of an AI interaction.
/// It conforms to `Sendable` to safely pass between the MainActor and our Feedback Actor.
struct FeedbackEntry: Codable, Identifiable, Sendable {
    let id: UUID
    let timestamp: Date
    let prompt: String
    let aiResponse: String
    let rating: FeedbackRating
    let userCorrection: String? // Optional: Captures if the user manually edited the text
    
    init(id: UUID = UUID(), prompt: String, aiResponse: String, rating: FeedbackRating, userCorrection: String? = nil) {
        self.id = id
        self.timestamp = Date()
        self.prompt = prompt
        self.aiResponse = aiResponse
        self.rating = rating
        self.userCorrection = userCorrection
    }
}

// MARK: - Logic Layer

/// `FeedbackManager` is an `actor`, which is critical for AI apps.
/// AI feedback can be generated from various background tasks (image processing, text generation).
/// Using an actor prevents data races when multiple feedback events arrive simultaneously.
actor FeedbackManager {
    /// A simulated local cache of feedback before it is uploaded to the cloud.
    private var pendingFeedback: [FeedbackEntry] = []
    
    /// In a real-world app, this would be a database connection (e.g., SwiftData or SQLite).
    private let storageURL: URL = {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0].appendingPathComponent("feedback_log.json")
    }()

    /// Submits a new feedback entry to the system.
    /// - Parameter entry: The `FeedbackEntry` captured from the UI.
    /// - Throws: Errors related to file I/O or network issues.
    func submitFeedback(_ entry: FeedbackEntry) async throws {
        // 1. Append to the in-memory buffer
        pendingFeedback.append(entry)
        
        // 2. Persist to local storage immediately to prevent data loss if the app crashes
        try await saveToDisk()
        
        // 3. Attempt to sync with the cloud if we have a batch
        if pendingFeedback.count >= 3 {
            try await uploadBatch()
        }
    }

    /// Persists the current buffer to the device's file system.
    private func saveToDisk() async throws {
        let data = try JSONEncoder().encode(pendingFeedback)
        try data.write(to: storageURL, options: .atomic)
        print("DEBUG: Feedback saved to disk at \(storageURL.lastPathComponent)")
    }

    /// Simulates an API call to a telemetry server for model fine-tuning.
    private func uploadBatch() async throws {
        print("DEBUG: Uploading \(pendingFeedback.count) entries to telemetry server...")
        
        // Simulate network latency
        try await Task.sleep(for: .seconds(2))
        
        // In a real app, you would use URLSession here.
        // After successful upload, clear the local buffer.
        pendingFeedback.removeAll()
        print("DEBUG: Batch upload successful. Buffer cleared.")
    }
}

// MARK: - View Model

/// The `RecipeViewModel` manages the state of the AI interaction.
/// It uses the `@Observable` macro (iOS 17+) for efficient UI updates.
@Observable
@MainActor
class RecipeViewModel {
    var currentPrompt: String = ""
    var aiGeneratedRecipe: String = ""
    var isProcessing: Bool = false
    var feedbackStatus: String = ""
    
    /// The manager responsible for handling the feedback lifecycle.
    /// We use a private property to encapsulate the actor.
    private let feedbackManager = FeedbackManager()

    /// Simulates an AI model generating a recipe.
    func generateRecipe() async {
        guard !currentPrompt.isEmpty else { return }
        
        isProcessing = true
        feedbackStatus = "AI is thinking..."
        
        // Simulate LLM latency
        try? await Task.sleep(for: .seconds(1.5))
        
        aiGeneratedRecipe = "Ingredients: 2 Eggs, 1 Cup Flour\nInstructions: Mix and fry in a pan."
        isProcessing = false
        feedbackStatus = "Recipe generated!"
    }

    /// Captures user feedback and hands it off to the background actor.
    /// - Parameter rating: The rating selected by the user.
    func submitUserFeedback(rating: FeedbackRating) {
        let entry = FeedbackEntry(
            prompt: currentPrompt,
            aiResponse: aiGeneratedRecipe,
            rating: rating
        )
        
        feedbackStatus = "Saving feedback..."
        
        // We create a new Task to bridge from the @MainActor (UI) to the FeedbackManager (Actor).
        Task {
            do {
                try await feedbackManager.submitFeedback(entry)
                feedbackStatus = "Thank you for your feedback!"
            } catch {
                feedbackStatus = "Failed to save feedback."
                print("ERROR: \(error)")
            }
        }
    }
}

// MARK: - UI Layer

@available(iOS 18.0, *)
struct RecipeFeedbackView: View {
    @State private var viewModel = RecipeViewModel()

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                // Input Section
                TextField("Enter ingredients (e.g., Eggs, Flour)", text: $viewModel.currentPrompt)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                Button(action: {
                    Task { await viewModel.generateRecipe() }
                }) {
                    if viewModel.isProcessing {
                        ProgressView()
                    } else {
                        Text("Generate Recipe")
                            .bold()
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(viewModel.isProcessing)

                Divider()

                // Output Section
                ScrollView {
                    Text(viewModel.aiGeneratedRecipe)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.secondary.opacity(0.1))
                        .cornerRadius(10)
                }
                .frame(maxHeight: .infinity)
                .padding(.horizontal)

                // Feedback Section
                if !viewModel.aiGeneratedRecipe.isEmpty {
                    VStack(spacing: 10) {
                        Text("Was this recipe helpful?")
                            .font(.headline)
                        
                        HStack(spacing: 30) {
                            FeedbackButton(rating: .negative) {
                                viewModel.submitUserFeedback(rating: .negative)
                            }
                            FeedbackButton(rating: .neutral) {
                                viewModel.submitUserFeedback(rating: .neutral)
                            }
                            FeedbackButton(rating: .positive) {
                                viewModel.submitUserFeedback(rating: .positive)
                            }
                        }
                    }
                    .padding()
                    .background(Color.blue.opacity(0.05))
                    .cornerRadius(15)
                }

                Text(viewModel.feedbackStatus)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .navigationTitle("AI Chef")
            .padding()
        }
    }
}

/// A reusable button for feedback selection.
struct FeedbackButton: View {
    let rating: FeedbackRating
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(rating.rawValue)
                .font(.largeTitle)
                .padding()
                .background(Color.white)
                .clipShape(Circle())
                .shadow(radius: 2)
        }
    }
}
