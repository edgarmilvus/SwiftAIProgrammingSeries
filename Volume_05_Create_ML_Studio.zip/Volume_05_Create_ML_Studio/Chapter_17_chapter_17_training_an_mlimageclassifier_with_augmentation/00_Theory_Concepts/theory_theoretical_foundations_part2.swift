
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import Foundation
    import CreateML

    @available(iOS 18.0, macOS 15.0, *)
    actor TrainingManager {
        private var activeTrainingSessions: [UUID: TrainingSessionStatus] = [:]

        struct TrainingSessionStatus: Identifiable, Sendable {
            let id: UUID
            let modelName: String
            var progress: Double
            var message: String
            var isActive: Bool
            var error: String?
            var trainedModelURL: URL?

            // Ensure structs passed between actors/tasks are Sendable
            // All properties here are Sendable by default (UUID, String, Double, Bool, URL?)
        }

        func startNewTraining(
            name: String,
            trainingDataURL: URL,
            validationDataURL: URL? = nil,
            parameters: MLImageClassifier.ModelParameters
        ) async throws -> UUID {
            let sessionId = UUID()
            activeTrainingSessions[sessionId] = TrainingSessionStatus(
                id: sessionId,
                modelName: name,
                progress: 0.0,
                message: "Starting...",
                isActive: true
            )

            // Spawn a detached task for the actual training, allowing the actor to respond to other calls.
            // The task will interact with the actor to update its status.
            Task.detached { [weak self] in
                guard let self else { return }
                let trainer = ImageClassifierTrainer() // Re-use the trainer from previous example
                let outputModelURL = FileManager.default.temporaryDirectory.appending(path: "\(name)-\(sessionId).mlmodel")

                do {
                    let classifier = try await trainer.trainModel(
                        from: trainingDataURL,
                        validationDataURL: validationDataURL,
                        parameters: parameters,
                        progressHandler: { currentProgress in
                            Task { await self.updateProgress(for: sessionId, progress: currentProgress.fractionCompleted) }
                        }
                    )
                    try await trainer.exportModel(classifier, to: outputModelURL)
                    await self.markTrainingCompleted(for: sessionId, modelURL: outputModelURL)
                } catch {
                    await self.markTrainingFailed(for: sessionId, error: error.localizedDescription)
                }
            }
            return sessionId
        }

        // Actor-isolated methods to safely update state
        private func updateProgress(for id: UUID, progress: Double) {
            activeTrainingSessions[id]?.progress = progress
            activeTrainingSessions[id]?.message = "Training: \(Int(progress * 100))%"
        }

        private func markTrainingCompleted(for id: UUID, modelURL: URL) {
            activeTrainingSessions[id]?.progress = 1.0
            activeTrainingSessions[id]?.message = "Completed!"
            activeTrainingSessions[id]?.isActive = false
            activeTrainingSessions[id]?.trainedModelURL = modelURL
        }

        private func markTrainingFailed(for id: UUID, error: String) {
            activeTrainingSessions[id]?.message = "Failed!"
            activeTrainingSessions[id]?.isActive = false
            activeTrainingSessions[id]?.error = error
        }

        func getSessionStatus(for id: UUID) -> TrainingSessionStatus? {
            return activeTrainingSessions[id]
        }

        func getAllSessionStatuses() -> [TrainingSessionStatus] {
            return Array(activeTrainingSessions.values)
        }
    }
    