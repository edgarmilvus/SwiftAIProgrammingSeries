
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import Speech
import AVFoundation

class VADTranscriptionViewController: UIViewController, SFSpeechRecognizerDelegate {

    // MARK: - UI Elements
    private let textView: UITextView = {
        let tv = UITextView()
        tv.font = .systemFont(ofSize: 18)
        tv.isEditable = false
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8.0
        tv.translatesAutoresizingMaskIntoConstraints = false
        return tv
    }()

    private let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Listening for Speech..."
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - Speech Recognition Properties
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    // MARK: - VAD Properties
    private var speechDetectedBuffers: [AVAudioPCMBuffer] = []
    private let speechDetectionThreshold: Float = 0.01 // RMS threshold for speech detection
    private let silenceThreshold: Float = 0.005 // RMS threshold for silence detection
    private let speechMinDuration: TimeInterval = 0.2 // Minimum duration of speech to start recognition (seconds)
    private let silenceMaxDuration: TimeInterval = 1.5 // Maximum duration of silence before ending recognition (seconds)

    private var speechTimer: Timer? // To track continuous speech
    private var silenceTimer: Timer? // To track continuous silence

    private var currentVADState: VADState = .listening {
        didSet {
            DispatchQueue.main.async {
                self.statusLabel.text = self.currentVADState.description
                if self.currentVADState == .listening {
                    self.textView.text = "" // Clear text when returning to listening
                }
            }
        }
    }

    enum VADState: CustomStringConvertible {
        case listening
        case speechDetected
        case processingSpeech
        case silenceDetected

        var description: String {
            switch self {
            case .listening: return "Listening for Speech..."
            case .speechDetected: return "Speech Detected, Starting Recognition..."
            case .processingSpeech: return "Processing Speech..."
            case .silenceDetected: return "Silence Detected, Ending Recognition..."
            }
        }
    }

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        requestPermissions()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopVADAndRecognition()
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground

        view.addSubview(statusLabel)
        view.addSubview(textView)

        NSLayoutConstraint.activate([
            statusLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 30),

            textView.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    // MARK: - Permissions
    private func requestPermissions() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            DispatchQueue.main.async {
                if authStatus == .authorized {
                    self.requestMicrophonePermission()
                } else {
                    self.statusLabel.text = "Speech recognition denied."
                }
            }
        }
    }

    private func requestMicrophonePermission() {
        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
            DispatchQueue.main.async {
                if granted {
                    self?.setupAudioEngineForVAD()
                } else {
                    self?.statusLabel.text = "Microphone access denied."
                }
            }
        }
    }

    // MARK: - Audio Engine Setup for VAD
    private func setupAudioEngineForVAD() {
        // Ensure speech recognizer is available
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            statusLabel.text = "Speech recognizer not available."
            return
        }
        speechRecognizer.delegate = self // To monitor availability

        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            statusLabel.text = "Audio Session Error: \(error.localizedDescription)"
            return
        }

        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { [weak self] buffer, _ in
            self?.processAudioBufferForVAD(buffer: buffer)
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
            currentVADState = .listening
        } catch {
            statusLabel.text = "Audio Engine Start Error: \(error.localizedDescription)"
        }
    }

    private func stopVADAndRecognition() {
        speechTimer?.invalidate()
        speechTimer = nil
        silenceTimer?.invalidate()
        silenceTimer = nil

        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionRequest = nil
        recognitionTask?.cancel()
        recognitionTask = nil
        speechDetectedBuffers.removeAll()

        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
        }

        DispatchQueue.main.async {
            self.currentVADState = .listening // Reset state
        }
    }

    // MARK: - VAD Logic
    private func processAudioBufferForVAD(buffer: AVAudioPCMBuffer) {
        let rms = calculateRMS(buffer: buffer)

        switch currentVADState {
        case .listening:
            if rms > speechDetectionThreshold {
                // Potential speech detected, start accumulating buffers
                speechDetectedBuffers.append(buffer)
                currentVADState = .speechDetected
                // Start a timer to confirm sustained speech
                speechTimer?.invalidate()
                speechTimer = Timer.scheduledTimer(withTimeInterval: speechMinDuration, repeats: false) { [weak self] _ in
                    guard let self = self else { return }
                    if self.currentVADState == .speechDetected { // Still in speechDetected state after min duration
                        self.startRecognitionFromBufferAccumulation()
                    }
                }
            }
        case .speechDetected:
            // Continue accumulating buffers
            speechDetectedBuffers.append(buffer)
            if rms < speechDetectionThreshold {
                // If silence occurs before min duration, reset
                speechTimer?.invalidate()
                speechTimer = nil
                speechDetectedBuffers.removeAll()
                currentVADState = .listening
            }
            // If speech continues, the timer will fire and transition to processingSpeech

        case .processingSpeech:
            recognitionRequest?.append(buffer)

            if rms < silenceThreshold {
                // Potential silence, start silence timer if not already running
                if silenceTimer == nil {
                    silenceTimer = Timer.scheduledTimer(withTimeInterval: silenceMaxDuration, repeats: false) { [weak self] _ in
                        guard let self = self else { return }
                        // If still silent after max duration, end recognition
                        if self.currentVADState == .processingSpeech { // Ensure we haven't already transitioned
                            self.currentVADState = .silenceDetected
                            self.endRecognition()
                        }
                    }
                }
            } else {
                // Speech detected again, reset silence timer
                silenceTimer?.invalidate()
                silenceTimer = nil
            }

        case .silenceDetected:
            // Should not append buffers here, waiting for recognition to end
            break
        }
    }

    private func startRecognitionFromBufferAccumulation() {
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            DispatchQueue.main.async { self.statusLabel.text = "Recognizer unavailable." }
            currentVADState = .listening
            speechDetectedBuffers.removeAll()
            return
        }

        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        recognitionRequest?.shouldReportPartialResults = true

        // Append all accumulated buffers first
        for buffer in speechDetectedBuffers {
            recognitionRequest?.append(buffer)
        }
        speechDetectedBuffers.removeAll() // Clear accumulated buffers

        currentVADState = .processingSpeech

        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest!) { [weak self] result, error in
            guard let self = self else { return }

            var isFinal = false
            if let result = result {
                DispatchQueue.main.async { self.textView.text = result.bestTranscription.formattedString }
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                // If recognition ends due to error or final result, ensure VAD state is reset
                self.endRecognition()
                if let error = error {
                    DispatchQueue.main.async { self.statusLabel.text = "Recognition error: \(error.localizedDescription)" }
                }
            }
        }
    }

    private func endRecognition() {
        speechTimer?.invalidate()
        speechTimer = nil
        silenceTimer?.invalidate()
        silenceTimer = nil

        recognitionRequest?.endAudio()
        recognitionRequest = nil
        recognitionTask?.cancel()
        recognitionTask = nil

        // After recognition ends, transition back to listening
        currentVADState = .listening
    }

    // MARK: - Audio Analysis Helper
    private func calculateRMS(buffer: AVAudioPCMBuffer) -> Float {
        guard let floatChannelData = buffer.floatChannelData else { return 0.0 }
        let frameLength = Int(buffer.frameLength)
        let channelCount = Int(buffer.format.channelCount)
        var sumOfSquares: Float = 0.0

        for channel in 0..<channelCount {
            let channelData = floatChannelData[channel]
            for i in 0..<frameLength {
                let sample = channelData[i]
                sumOfSquares += sample * sample
            }
        }

        if frameLength * channelCount > 0 {
            return sqrt(sumOfSquares / Float(frameLength * channelCount))
        } else {
            return 0.0
        }
    }

    // MARK: - SFSpeechRecognizerDelegate
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        DispatchQueue.main.async {
            if !available && self.currentVADState != .listening {
                self.stopVADAndRecognition() // Stop if recognizer becomes unavailable mid-recognition
                self.statusLabel.text = "Speech recognizer became unavailable."
            } else if available && self.currentVADState == .listening {
                self.statusLabel.text = "Listening for Speech..."
            }
        }
    }
}
