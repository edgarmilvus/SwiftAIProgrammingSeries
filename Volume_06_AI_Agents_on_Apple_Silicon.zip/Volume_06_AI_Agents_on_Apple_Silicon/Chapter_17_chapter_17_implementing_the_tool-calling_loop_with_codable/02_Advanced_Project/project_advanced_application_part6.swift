
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

// MARK: - 5. LLM Agent

@available(macOS 15.0, *)
actor LLMAgent {
    private let toolExecutor: ToolExecutor
    private let jsonDecoder = JSONDecoder()
    private let ollama: OllamaKit // For actual LLM interaction

    /// Initializes the LLMAgent with a ToolExecutor and OllamaKit instance.
    /// - Parameter toolExecutor: The executor responsible for running smart home actions.
    /// - Parameter ollama: An instance of OllamaKit for LLM communication.
    init(toolExecutor: ToolExecutor, ollama: OllamaKit) {
        self.toolExecutor = toolExecutor
        self.ollama = ollama
    }

    /// The main tool-calling loop. It sends a user query to the LLM,
    /// processes tool calls, executes them, and potentially sends results back to the LLM.
    /// - Parameter userQuery: The natural language query from the user.
    /// - Returns: A final response string from the agent.
    func processUserQuery(_ userQuery: String) async throws -> String {
        print("\nUser: \(userQuery)")
        var conversationHistory: [ChatMessages] = [
            .init(role: .user, content: userQuery)
        ]

        // Define the tools available to the LLM in a structured format (JSON schema).
        // This is crucial for the LLM to understand how to call the tools.
        let toolDefinitions = """
        [
            {
                "type": "function",
                "function": {
                    "name": "SetLightColorTool",
                    "description": "Sets the color of a smart light in a specified room.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "room": { "type": "string", "description": "The room where the light is located (e.g., 'living_room', 'bedroom')." },
                            "color": { "type": "string", "description": "The desired color for the light (e.g., 'red', 'blue', 'white')." }
                        },
                        "required": ["room", "color"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "SetLightBrightnessTool",
                    "description": "Sets the brightness of a smart light in a specified room.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "room": { "type": "string", "description": "The room where the light is located." },
                            "brightness": { "type": "integer", "description": "The desired brightness level (0-100)." }
                        },
                        "required": ["room", "brightness"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "GetRoomTemperatureTool",
                    "description": "Retrieves the current temperature in a specified room.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "room": { "type": "string", "description": "The room to get the temperature from." }
                        },
                        "required": ["room"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "SetThermostatTemperatureTool",
                    "description": "Sets the target temperature for the thermostat in a specified room.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "room": { "type": "string", "description": "The room where the thermostat is located." },
                            "temperature": { "type": "number", "description": "The desired temperature in Celsius." }
                        },
                        "required": ["room", "temperature"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "PlayMusicTool",
                    "description": "Plays music in a specified room. Can optionally specify song title, artist, or genre.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "room": { "type": "string", "description": "The room to play music in." },
                            "songTitle": { "type": "string", "description": "The title of the song to play (optional)." },
                            "artist": { "type": "string", "description": "The artist of the song (optional)." },
                            "genre": { "type": "string", "description": "The genre of music to play (optional)." }
                        },
                        "required": ["room"]
                    }
                }
            }
        ]
        """

        var loopCount = 0
        let maxLoopIterations = 5 // Prevent infinite loops

        while loopCount < maxLoopIterations {
            loopCount += 1
            print("--- LLM Interaction Loop \(loopCount) ---")

            do {
                // 1. Send conversation history and tool definitions to the LLM.
                // The LLM will either respond with text or suggest tool calls.
                let response = try await ollama.chat(
                    model: "llama3", // Replace with your desired local LLM model
                    messages: conversationHistory,
                    options: .init(temperature: 0.1),
                    format: .json, // Request JSON format for tool calls
                    tools: toolDefinitions // Pass the tool definitions
                )
                
                // Collect the full response content
                var fullResponseContent = ""
                for try await chunk in response {
                    if let content = chunk.message?.content {
                        fullResponseContent += content
                    }
                }
                
                // Add the LLM's full response to the conversation history
                conversationHistory.append(.init(role: .assistant, content: fullResponseContent))
                print("LLM Raw Response: \(fullResponseContent)")

                // 2. Attempt to parse the LLM's response for tool calls.
                // The LLM is expected to return a JSON object with "tool_calls" if it wants to use a tool.
                guard let data = fullResponseContent.data(using: .utf8) else {
                    // If it's not valid JSON, it might be a direct text response.
                    // For this example, we'll assume direct text if parsing fails.
                    return fullResponseContent.trimmingCharacters(in: .whitespacesAndNewlines)
                }

                let toolCallsContainer = try jsonDecoder.decode(SmartHomeTools.ToolCallsContainer.self, from: data)

                guard !toolCallsContainer.tool_calls.isEmpty else {
                    // LLM responded with valid JSON but no tool calls,
                    // or it was a text-only response that was successfully parsed as JSON but empty.
                    // This implies the LLM decided no tools were needed.
                    return fullResponseContent.trimmingCharacters(in: .whitespacesAndNewlines)
                }

                print("LLM suggested \(toolCallsContainer.tool_calls.count) tool calls.")

                // 3. Execute each suggested tool call.
                var toolOutputs: [ToolOutput] = []
                for toolCall in toolCallsContainer.tool_calls {
                    do {
                        let output = try await toolExecutor.executeTool(functionCall: toolCall.function)
                        toolOutputs.append(.init(toolCallId: toolCall.id, content: output))
                        print("Tool '\(toolCall.function.name)' output: \(output)")
                    } catch {
                        let errorMessage = "Error executing tool '\(toolCall.function.name)': \(error.localizedDescription)"
                        toolOutputs.append(.init(toolCallId: toolCall.id, content: errorMessage))
                        print("Tool '\(toolCall.function.name)' ERROR: \(errorMessage)")
                    }
                }

                // 4. Append tool outputs to the conversation history and loop.
                // This allows the LLM to use the results for further reasoning or to generate a final response.
                conversationHistory.append(.init(role: .tool, toolCallId: nil, content: nil, toolCalls: nil, toolOutputs: toolOutputs))
                print("Tool outputs added to conversation history. Looping for LLM's final response...")

            } catch let decodingError as DecodingError {
                // If the LLM response is not a valid tool call JSON, it might be a direct text response.
                // We'll treat it as a final text response if it's not a tool call.
                // This is a common pattern: try parsing tool calls, if it fails, assume it's a direct text response.
                print("LLM response was not a tool call JSON (or malformed). Assuming direct text response. Error: \(decodingError.localizedDescription)")
                
                // For a robust system, we would re-query the LLM with a specific instruction
                // to generate a text response if previous parsing failed, or simply return the raw text.
                // For this example, we'll just return the last raw text received.
                if let lastMessage = conversationHistory.last(where: { $0.role == .assistant })?.content {
                    return lastMessage.trimmingCharacters(in: .whitespacesAndNewlines)
                } else {
                    throw SmartHomeError.llmResponseParsingFailed(decodingError)
                }
            } catch {
                throw SmartHomeError.llmCommunicationFailed(error)
            }
        }
        
        // If we reach here, max loops exceeded without a final text response.
        return "The agent reached its maximum processing iterations without a definitive answer or action."
    }
}
