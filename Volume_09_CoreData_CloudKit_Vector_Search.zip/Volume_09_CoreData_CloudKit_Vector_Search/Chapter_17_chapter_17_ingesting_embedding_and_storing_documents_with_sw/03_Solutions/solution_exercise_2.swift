
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import SwiftData
import NaturalLanguage

@Model
final class ResearchDocument {
    @Attribute(.unique) var id: UUID
    var title: String
    var author: String
    @Attribute(.externalStorage) var content: String
    var timestamp: Date
    
    // The mathematical fingerprint of the document.
    // Dimensionality depends on the NLEmbedding model used.
    var embedding: [Float]?
    
    init(title: String, author: String, content: String, timestamp: Date = .now) {
        self.id = UUID()
        self.title = title
        self.author = author
        self.content = content
        self.timestamp = timestamp
    }
}

final class EmbeddingService {
    private let embeddingModel = NLEmbedding.wordEmbedding(for: .english)
    
    /// Generates a single document-level vector by averaging word embeddings.
    func generateEmbedding(for text: String) -> [Float]? {
        guard let embeddingModel = embeddingModel else { return nil }
        
        let words = text.lowercased()
            .components(separatedBy: .punctuationCharacters).joined()
            .components(separatedBy: .whitespacesAndNewlines)
            .filter { !$0.isEmpty }
        
        var wordVectors: [[Float]] = []
        
        for word in words {
            if let vector = embeddingModel.vector(for: word) {
                wordVectors.append(vector)
            }
        }
        
        guard !wordVectors.isEmpty else { return nil }
        
        // Strategy: Mean Pooling (Averaging the vectors)
        let dimension = wordVectors[0].count
        var averagedVector = [Float](repeating: 0, count: dimension)
        
        for vector in wordVectors {
            for i in 0..<dimension {
                averagedVector[i] += vector[i]
            }
        }
        
        for i in 0..<dimension {
            averagedVector[i] /= Float(wordVectors.count)
        }
        
        return averagedVector
    }
}

@MainActor
class DocumentIngestor {
    private let context: ModelContext
    private let embeddingService: EmbeddingService
    
    init(context: ModelContext, embeddingService: EmbeddingService) {
        self.context = context
        self.embeddingService = embeddingService
    }
    
    func ingest(title: String, author: String, content: String) async throws {
        // 1. Generate embedding first
        guard let vector = embeddingService.generateEmbedding(for: content) else {
            throw NSError(domain: "EmbeddingError", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to generate embedding"])
        }
        
        // 2. Create model with embedding
        let newDocument = ResearchDocument(title: title, author: author, content: content)
        newDocument.embedding = vector
        
        // 3. Persist
        context.insert(newDocument)
        try context.save()
    }
}
