
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Accelerate
import CoreML

// MARK: - Dependencies

/// In a real-world project, your Package.swift would include dependencies for 
/// specialized vector database drivers or advanced CoreML management.
/*
// Package.swift snippet
let package = Package(
    name: "SemanticSearchEngine",
    platforms: [.iOS(.v18), .macOS(.v15)],
    dependencies: [
        // Example: A hypothetical high-performance vector storage wrapper
        // .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
    ],
    targets: [
        .target(name: "SemanticSearchEngine", dependencies: [])
    ]
)
*/

// MARK: - Error Handling

/// Represents errors that can occur during vector operations.
enum VectorError: Error, LocalizedError {
    case dimensionMismatch(expected: Int, actual: Int)
    case emptyDatabase
    case computationFailed(String)
    case embeddingGenerationFailed

    var errorDescription: String? {
        switch self {
        case .dimensionMismatch(let e, let a):
            return "Vector dimension mismatch: Expected \(e), but got \(a)."
        case .emptyDatabase:
            return "The semantic memory is currently empty."
        case .computationFailed(let reason):
            return "Mathematical computation failed: \(reason)"
        case .embeddingGenerationFailed:
            return "Failed to generate embedding from input text."
        }
    }
}

// MARK: - Models

/// A Sendable representation of a piece of semantic information.
/// This would typically be backed by a CoreData entity in a production app.
struct SemanticMemoryItem: Sendable, Identifiable {
    let id: UUID
    let text: String
    let metadata: [String: String]
    /// The high-dimensional vector representing the text's meaning.
    let embedding: [Float]
    
    /// The dimensionality of the embedding (e.g., 384, 768, or 1536).
    static let dimension: Int = 384 
}

/// The result of a similarity search.
struct SimilarityResult: Sendable, Comparable {
    let item: SemanticMemoryItem
    let score: Float

    static func < (lhs: SimilarityResult, rhs: SimilarityResult) -> Bool {
        // We want highest similarity first, so we invert the comparison for sorting.
        lhs.score > rhs.score
    }
}

// MARK: - The Engine

/// `SemanticMemoryEngine` is an actor that manages a collection of vector embeddings.
/// Using an `actor` ensures that multiple concurrent tasks (e.g., background indexing 
/// and foreground searching) do not cause data races on the underlying storage.
@available(iOS 18.0, macOS 15.0, *)
actor SemanticMemoryEngine {
    
    /// The internal storage for our semantic items.
    private var memoryStore: [SemanticMemoryItem] = []
    
    /// The expected dimensionality for all vectors in this engine.
    private let expectedDimension: Int
    
    init(dimension: Int = SemanticMemoryItem.dimension) {
        self.expectedDimension = dimension
    }
    
    // MARK: - Public API

    /// Adds a new item to the semantic memory.
    /// - Parameter item: The item containing text and its pre-computed embedding.
    /// - Throws: `VectorError.dimensionMismatch` if the vector size is incorrect.
    func ingest(item: SemanticMemoryItem) throws {
        guard item.embedding.count == expectedDimension else {
            throw VectorError.dimensionMismatch(
                expected: expectedDimension, 
                actual: item.embedding.count
            )
        }
        memoryStore.append(item)
    }

    /// Performs a semantic search across the entire memory store.
    /// - Parameter queryEmbedding: The vector representation of the user's query.
    /// - Returns: An array of `SimilarityResult` sorted by descending similarity.
    /// - Throws: `VectorError` if dimensions mismatch or database is empty.
    func search(queryEmbedding: [Float], limit: Int = 5) throws -> [SimilarityResult] {
        guard !memoryStore.isEmpty else { throw VectorError.emptyDatabase }
        guard queryEmbedding.count == expectedDimension else {
            throw VectorError.dimensionMismatch(expected: expectedDimension, actual: queryEmbedding.count)
        }

        // Perform the search using high-performance vector math.
        // We use a TaskGroup to parallelize the computation if the store is large.
        let results = try performParallelCosineSearch(query: queryEmbedding, limit: limit)
        return results
    }

    /// Clears all items from the engine.
    func purge() {
        memoryStore.removeAll()
    }

    // MARK: - Private Mathematical Implementation

    /// Uses the Accelerate framework to perform cosine similarity.
    /// This is the "Under the Hood" part where we leverage SIMD instructions.
    private func performParallelCosineSearch(query: [Float], limit: Int) throws -> [SimilarityResult] {
        // In a real-world production app with 100,000+ vectors, we would use 
        // an Approximate Nearest Neighbor (ANN) algorithm like HNSW.
        // For this implementation, we demonstrate the high-performance exact search.
        
        var similarityResults: [SimilarityResult] = []
        
        // Pre-calculate query magnitude once to optimize the loop.
        // Magnitude = sqrt(sum(q_i^2))
        let queryMagnitude = calculateMagnitude(query)
        
        for item in memoryStore {
            let dotProduct = calculateDotProduct(query, item.embedding)
            let itemMagnitude = calculateMagnitude(item.embedding)
            
            // Cosine Similarity formula: (A . B) / (|A| * |B|)
            // We add a tiny epsilon to prevent division by zero.
            let denominator = (queryMagnitude * itemMagnitude) + Float.leastNormalMagnitude
            let similarity = dotProduct / denominator
            
            similarityResults.append(SimilarityResult(item: item, score: similarity))
        }
        
        // Sort by score descending and return the top N.
        return Array(similarityResults.sorted().prefix(limit))
    }

    /// Calculates the dot product using Accelerate's vDSP (Digital Signal Processing) functions.
    /// This is significantly faster than a standard `for` loop because it uses SIMD.
    private func calculateDotProduct(_ a: [Float], _ b: [Float]) -> Float {
        var result: Float = 0
        // vDSP_dotpr performs the dot product of two vectors in a single instruction stream.
        vDSP_dotpr(a, 1, b, 1, &result, vDSP_Length(a.count))
        return result
    }

    /// Calculates the Euclidean norm (magnitude) of a vector using Accelerate.
    private func calculateMagnitude(_ vector: [Float]) -> Float {
        var magnitude: Float = 0
        // vDSP_svesq calculates the sum of squares of the elements.
        vDSP_svesq(vector, 1, &magnitude, vDSP_Length(vector.count))
        return sqrt(magnitude)
    }
}

// MARK: - Real-World Application Example

/// A mock service representing an AI model (like a local CoreML transformer).
struct EmbeddingService {
    /// Simulates generating an embedding for a given string.
    func generateEmbedding(for text: String) async throws -> [Float] {
        // In reality, this would call a CoreML model.
        // We simulate a 384-dimensional vector with random values.
        try await Task.sleep(for: .milliseconds(100)) 
        return (0..<384).map { _ in Float.random(in: -1...1) }
    }
}

/// The ViewModel that coordinates the UI and the Semantic Engine.
@MainActor
class SemanticSearchViewModel: ObservableObject {
    @Published var searchResults: [SimilarityResult] = []
    @Published var isSearching: Bool = false
    @Published var errorMessage: String?

    private let engine = SemanticMemoryEngine()
    private let embeddingService = EmbeddingService()

    /// Adds a new note to the semantic memory.
    func addNote(text: String) async {
        do {
            let embedding = try await embeddingService.generateEmbedding(for: text)
            let item = SemanticMemoryItem(
                id: UUID(),
                text: text,
                metadata: ["timestamp": "\(Date().timeIntervalSince1970)"],
                embedding: embedding
            )
            try await engine.ingest(item: item)
        } catch {
            self.errorMessage = error.localizedDescription
        }
    }

    /// Searches for notes semantically.
    func performSearch(query: String) async {
        isSearching = true
        errorMessage = nil
        
        do {
            let queryEmbedding = try await embeddingService.generateEmbedding(for: query)
            let results = try await engine.search(queryEmbedding: queryEmbedding)
            self.searchResults = results
        } catch {
            self.errorMessage = error.localizedDescription
        }
        
        isSearching = false
    }
}
