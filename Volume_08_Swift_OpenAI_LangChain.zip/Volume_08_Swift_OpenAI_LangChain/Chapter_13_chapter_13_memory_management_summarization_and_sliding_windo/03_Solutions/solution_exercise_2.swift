
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// Protocol defining the requirement for tokenizing text.
/// Marked Sendable so it can be used within actors.
protocol Tokenizing: Sendable {
    func countTokens(for text: String) async -> Int
}

/// A mock implementation of a tokenizer for testing purposes.
struct MockTokenizer: Tokenizing {
    func countTokens(for text: String) async -> Int {
        // Simulate network/computational latency
        try? await Task.sleep(for: .milliseconds(10))
        // Heuristic: 1 token is roughly 4 characters
        return max(1, text.count / 4)
    }
}

/// An actor that manages the token budget of the conversation.
actor TokenBudgetManager {
    private(set) var currentTokenCount: Int = 0
    let maxTokenLimit: Int
    private let tokenizer: any Tokenizing
    
    init(maxTokenLimit: Int, tokenizer: any Tokenizing) {
        self.maxTokenLimit = maxTokenLimit
        self.tokenizer = tokenizer
    }
    
    /// Processes a new message, updating the running total.
    /// Returns `true` if the budget is still within limits, `false` if exceeded.
    func processNewMessage(_ message: ChatMessage) async -> Bool {
        let newTokens = await tokenizer.countTokens(for: message.content)
        currentTokenCount += newTokens
        
        return currentTokenCount <= maxTokenLimit
    }
    
    /// Resets the budget (useful when starting a new session).
    func reset() {
        currentTokenCount = 0
    }
}

// --- Implementation Test ---
@main
struct BudgetTest {
    static func main() async {
        let tokenizer = MockTokenizer()
        let budgetManager = TokenBudgetManager(maxTokenLimit: 100, tokenizer: tokenizer)
        
        let messages = [
            ChatMessage(role: .user, content: "Hi"),
            ChatMessage(role: .assistant, content: "Hello! How can I help?"),
            ChatMessage(role: .user, content: "Can you tell me a very long story about a brave knight and a dragon?"),
            ChatMessage(role: .assistant, content: "Once upon a time, in a land far away, there lived a dragon who loved coding in Swift...")
        ]
        
        for msg in messages {
            let withinBudget = await budgetManager.processNewMessage(msg)
            let count = await budgetManager.currentTokenCount
            print("Processed: [\(msg.role.rawValue)] | Total Tokens: \(count) | Within Budget: \(withinBudget)")
            
            if !withinBudget {
                print("⚠️ WARNING: Token budget exceeded! Triggering context pruning...")
                break
            }
        }
    }
}
