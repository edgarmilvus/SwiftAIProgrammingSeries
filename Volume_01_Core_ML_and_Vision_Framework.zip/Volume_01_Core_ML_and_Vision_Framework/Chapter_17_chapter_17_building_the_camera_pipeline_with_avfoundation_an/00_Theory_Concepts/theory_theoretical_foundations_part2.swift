
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

// Example of an actor managing camera and Vision processing
@available(iOS 17.0, *)
actor VisionProcessor: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    private let session = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let videoQueue = DispatchQueue(label: "com.example.videoQueue")
    private var visionRequests: [VNRequest] = []

    // @Published or @Observable property would be exposed from an ObservableObject/class
    // This actor manages the internal state safely.
    var latestObservations: [VNRecognizedObjectObservation] = []

    func setupCamera() async throws {
        // ... configure session, add input ...

        videoOutput.setSampleBufferDelegate(self, queue: videoQueue)
        session.addOutput(videoOutput)

        // Setup Vision requests
        guard let model = try? VNCoreMLModel(for: MyCoreMLModel().model) else {
            fatalError("Failed to load Core ML model")
        }
        visionRequests = [VNCoreMLRequest(model: model) { [weak self] request, error in
            guard let self = self, let observations = request.results as? [VNRecognizedObjectObservation] else { return }
            Task { // Hop back to actor's isolation for state update
                await self.updateObservations(observations)
            }
        }]

        session.startRunning()
    }

    nonisolated func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up) // Handle orientation
        do {
            try imageRequestHandler.perform(visionRequests)
        } catch {
            print("Vision request failed: \(error)")
        }
    }

    private func updateObservations(_ observations: [VNRecognizedObjectObservation]) {
        self.latestObservations = observations // Safely update actor's isolated state
    }
}
