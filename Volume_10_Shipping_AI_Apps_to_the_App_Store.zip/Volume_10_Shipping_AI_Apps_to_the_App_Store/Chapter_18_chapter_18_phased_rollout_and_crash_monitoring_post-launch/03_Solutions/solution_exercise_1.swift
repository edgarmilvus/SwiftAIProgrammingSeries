
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import OSLog

/// 1. Domain-Specific Error Enum
enum AIError: Error, LocalizedError, Sendable {
    case modelTimeout
    case contextWindowExceeded(currentTokens: Int, limit: Int)
    case apiRateLimitReached(retryAfter: TimeInterval?)
    case malformedResponse
    case modelCorruption

    var errorDescription: String? {
        switch self {
        case .modelTimeout: return "The AI model failed to respond in time."
        case .contextWindowExceeded(let current, let limit): 
            return "Context window exceeded. Used \(current), Limit \(limit)."
        case .apiRateLimitReached(let retry): 
            return "Rate limit reached. Retry after \(retry ?? 0)s."
        case .malformedResponse: return "The model returned an invalid response format."
        case .modelCorruption: return "Critical: CoreML model weights appear corrupted."
        }
    }
}

/// 2. The Interceptor Protocol
protocol TelemetryInterceptor: Sendable {
    func intercept(_ error: Error, context: [String: Any])
}

/// 3. Implementation with OSLog
/// Marked as final and Sendable to comply with Swift 6 concurrency requirements.
final class AIErrorLogger: TelemetryInterceptor, @unchecked Sendable {
    private let logger = Logger(subsystem: "com.linguistai.engine", category: "AI-Inference")
    
    // In a real app, we might add a rate-limiter here to prevent log flooding.
    func intercept(_ error: Error, context: [String: Any]) {
        let modelVersion = context["modelVersion"] as? String ?? "unknown"
        let temperature = context["temperature"] as? Double ?? 0.0
        
        // Sanitize context: Ensure no PII (Personal Identifiable Information) is logged
        // We only log metadata, never the 'user_input' or 'translated_text'
        let metadata = "Model: \(modelVersion), Temp: \(temperature)"

        if let aiError = error as? AIError {
            switch aiError {
            case .modelCorruption:
                // .fault is used for critical system failures that require immediate attention
                logger.fault("CRITICAL: \(aiError.localizedDescription). Metadata: \(metadata)")
            case .apiRateLimitReached, .modelTimeout:
                // .error is used for recoverable but significant issues
                logger.error("API/Timeout Error: \(aiError.localizedDescription). Metadata: \(metadata)")
            case .contextWindowExceeded, .malformedResponse:
                // .debug or .info for standard operational errors
                logger.info("Operational Error: \(aiError.localizedDescription). Metadata: \(metadata)")
            }
        } else {
            logger.error("Unknown Error: \(error.localizedDescription). Metadata: \(metadata)")
        }
    }
}

// MARK: - Usage Example
struct TranslationEngine {
    let interceptor: TelemetryInterceptor
    
    func performTranslation(text: String) async {
        // Simulating a failure
        let error = AIError.contextWindowExceeded(currentTokens: 1200, limit: 1000)
        let context: [String: Any] = [
            "modelVersion": "v2.1-transformer",
            "temperature": 0.7,
            "connection": "5G"
        ]
        
        interceptor.intercept(error, context: context)
    }
}
