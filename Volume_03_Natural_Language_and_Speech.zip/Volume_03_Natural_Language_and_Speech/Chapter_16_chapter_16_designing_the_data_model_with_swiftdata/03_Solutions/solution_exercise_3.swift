
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, visionOS 2.0, *)
import SwiftData
import Foundation // For Date and Data

// MARK: - Version 1 Models

// VoiceMemo Model (V1)
@Model
class VoiceMemoV1 {
    var title: String
    var audioData: Data
    var dateRecorded: Date
    @Relationship(inverse: \TranscriptionV1.voiceMemo) var transcription: TranscriptionV1 // One-to-one

    init(title: String, audioData: Data, dateRecorded: Date, transcription: TranscriptionV1) {
        self.title = title
        self.audioData = audioData
        self.dateRecorded = dateRecorded
        self.transcription = transcription
    }
}

// Transcription Model (V1)
@Model
class TranscriptionV1 {
    var rawText: String
    var languageCode: String
    @Relationship(inverse: \VoiceMemoV1.transcription) var voiceMemo: VoiceMemoV1 // One-to-one inverse
    @Relationship(inverse: \SpeakerV1.transcriptions) var speakers: [SpeakerV1] // Many-to-many

    init(rawText: String, languageCode: String, voiceMemo: VoiceMemoV1, speakers: [SpeakerV1] = []) {
        self.rawText = rawText
        self.languageCode = languageCode
        self.voiceMemo = voiceMemo
        self.speakers = speakers
    }
}

// Speaker Model (V1)
@Model
class SpeakerV1 {
    var name: String
    @Attribute(.unique) var speakerIdentifier: String // Ensure unique speaker IDs
    @Relationship(inverse: \TranscriptionV1.speakers) var transcriptions: [TranscriptionV1] // Many-to-many inverse

    init(name: String, speakerIdentifier: String, transcriptions: [TranscriptionV1] = []) {
        self.name = name
        self.speakerIdentifier = speakerIdentifier
        self.transcriptions = transcriptions
    }
}

// MARK: - Version 2 Models

// VoiceMemo Model (V2) - Updated with summary
@Model
class VoiceMemoV2 {
    var title: String
    var audioData: Data
    var dateRecorded: Date
    var summary: String? // New optional attribute in V2
    @Relationship(inverse: \TranscriptionV2.voiceMemo) var transcription: TranscriptionV2

    init(title: String, audioData: Data, dateRecorded: Date, summary: String? = nil, transcription: TranscriptionV2) {
        self.title = title
        self.audioData = audioData
        self.dateRecorded = dateRecorded
        self.summary = summary
        self.transcription = transcription
    }
}

// Transcription Model (V2) - Updated with derived property
@Model
class TranscriptionV2 {
    var rawText: String
    var languageCode: String
    @Relationship(inverse: \VoiceMemoV2.transcription) var voiceMemo: VoiceMemoV2
    @Relationship(inverse: \SpeakerV2.transcriptions) var speakers: [SpeakerV2]

    // Derived property: Not persisted in the database
    var isMultiSpeaker: Bool {
        speakers.count > 1
    }

    init(rawText: String, languageCode: String, voiceMemo: VoiceMemoV2, speakers: [SpeakerV2] = []) {
        self.rawText = rawText
        self.languageCode = languageCode
        self.voiceMemo = voiceMemo
        self.speakers = speakers
    }
}

// Speaker Model (V2) - No changes, but needs to be part of the V2 schema
@Model
class SpeakerV2 {
    var name: String
    @Attribute(.unique) var speakerIdentifier: String
    @Relationship(inverse: \TranscriptionV2.transcriptions) var transcriptions: [TranscriptionV2]

    init(name: String, speakerIdentifier: String, transcriptions: [TranscriptionV2] = []) {
        self.name = name
        self.speakerIdentifier = speakerIdentifier
        self.transcriptions = transcriptions
    }
}


// MARK: - Schema & Migration Plan

// Define Schema versions
enum AppSchemaV1: VersionedSchema {
    static var versionIdentifier: Schema.Version = .init(1, 0, 0)
    static var models: [any PersistentModel.Type] {
        [VoiceMemoV1.self, TranscriptionV1.self, SpeakerV1.self]
    }
}

enum AppSchemaV2: VersionedSchema {
    static var versionIdentifier: Schema.Version = .init(2, 0, 0)
    static var models: [any PersistentModel.Type] {
        [VoiceMemoV2.self, TranscriptionV2.self, SpeakerV2.self]
    }
}

// Define the migration plan
enum AppSchemaMigrationPlan: SchemaMigrationPlan {
    static var schemas: [any VersionedSchema.Type] {
        [AppSchemaV1.self, AppSchemaV2.self]
    }

    static var stages: [MigrationStage] {
        .resize(from: AppSchemaV1.self, to: AppSchemaV2.self) {
            // Migration for adding 'summary' to VoiceMemo
            // This stage will automatically map existing properties from V1 to V2
            // and initialize new optional properties (like `summary`) to `nil`.
            // No explicit transformation is needed for adding an optional property.
            // If `summary` was non-optional, a custom `MigrationStage.custom` would be
            // required to provide a default value.
        }
        // Example of a custom migration stage if complex logic was needed:
        // .custom(from: AppSchemaV1.self, to: AppSchemaV2.self) { context in
        //     // This block runs after the automatic mapping for each object
        //     // You could fetch V1 VoiceMemos, create V2 VoiceMemos, and set summary based on some logic
        //     // For adding an optional property that defaults to nil, the .resize stage is sufficient.
        // }
    }
}
