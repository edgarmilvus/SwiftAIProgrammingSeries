
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Accelerate // For high-performance vector math

// MARK: - Package Dependencies
/*
 To use this in a real project, your Package.swift would include:
 dependencies: [
     .package(url: "https://github.com/openai/openai-swift", from: "1.0.0")
 ],
 targets: [
     .target(name: "ResearchEngine", dependencies: ["OpenAISwift"])
 ]
*/

/// Errors specific to the Vector Search Engine.
enum VectorError: Error, LocalizedError {
    case dimensionMismatch(expected: Int, actual: Int)
    case emptyStore
    case embeddingFailed(String)
    case computationError

    var errorDescription: String? {
        switch self {
        case .dimensionMismatch(let e, let a): return "Dimension mismatch: Expected \(e), got \(a)."
        case .emptyStore: return "The vector store contains no data."
        case .embeddingFailed(let msg): return "Embedding generation failed: \(msg)"
        case .computationError: return "A mathematical error occurred during similarity calculation."
        }
    }
}

/// A representation of a high-dimensional vector.
/// Conforms to Sendable to allow safe transfer across Actor boundaries in Swift 6.
struct SemanticVector: Sendable, Codable {
    let id: UUID
    let values: [Float]
    let metadata: [String: String]
    let dimension: Int

    init(id: UUID = UUID(), values: [Float], metadata: [String: String] = [:]) {
        self.id = id
        self.values = values
        self.metadata = metadata
        self.dimension = values.count
    }
}

/// The result of a similarity search.
struct SearchResult: Sendable, Identifiable {
    let id: UUID
    let score: Float
    let metadata: [String: String]
}

/// A thread-safe, actor-based storage for semantic vectors.
/// This component manages the lifecycle of embeddings and performs similarity searches.
@available(iOS 18.0, macOS 15.0, *)
actor LocalVectorStore {
    
    /// The internal storage for vectors.
    private var storage: [SemanticVector] = []
    
    /// The required dimension for all vectors in this store (e.g., 1536 for OpenAI text-embedding-3-small).
    private let requiredDimension: Int
    
    init(requiredDimension: Int) {
        self.requiredDimension = requiredDimension
    }
    
    /// Adds a new vector to the store.
    /// - Parameter vector: The semantic vector to index.
    /// - Throws: `VectorError.dimensionMismatch` if the vector size is incorrect.
    func insert(_ vector: SemanticVector) throws {
        guard vector.dimension == requiredDimension else {
            throw VectorError.dimensionMismatch(expected: requiredDimension, actual: vector.dimension)
        }
        storage.append(vector)
    }
    
    /// Performs a k-Nearest Neighbors (k-NN) search using Cosine Similarity.
    /// - Parameters:
    ///   - query: The vector to search for.
    ///   - k: The number of top results to return.
    /// - Returns: An array of `SearchResult` sorted by highest similarity.
    /// - Throws: `VectorError.emptyStore` or `VectorError.dimensionMismatch`.
    func search(query: SemanticVector, k: Int) throws -> [SearchResult] {
        guard !storage.isEmpty else { throw VectorError.emptyStore }
        guard query.dimension == requiredDimension else {
            throw VectorError.dimensionMismatch(expected: requiredDimension, actual: query.dimension)
        }
        
        // Perform similarity calculation
        // In a production environment with >10,000 vectors, we would use 
        // an HNSW index or a specialized library like Faiss.
        // Here, we implement a high-performance linear scan using Swift's concurrency.
        
        let results = storage.map { storedVector -> SearchResult in
            let similarity = cosineSimilarity(query.values, storedVector.values)
            return SearchResult(
                id: storedVector.id,
                score: similarity,
                metadata: storedVector.metadata
            )
        }
        
        // Sort by score descending and take top k
        return Array(results.sorted(by: { $0.score > $1.score }).prefix(k))
    }
    
    /// Calculates the cosine similarity between two vectors.
    /// Uses the formula: (A · B) / (||A|| * ||B||)
    /// - Parameters:
    ///   - a: First vector array.
    ///   - b: Second vector array.
    /// - Returns: A float representing the similarity (typically 0.0 to 1.0).
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        // Optimization: Using Accelerate framework's dot product for high performance.
        // vDSP_dotpr is significantly faster than a manual loop for large dimensions.
        var dotProduct: Float = 0
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        
        var normA: Float = 0
        var normB: Float = 0
        vDSP_svesq(a, 1, &normA, vDSP_Length(a.count))
        vDSP_svesq(b, 1, &normB, vDSP_Length(b.count))
        
        let denominator = sqrt(normA) * sqrt(normB)
        
        // Prevent division by zero
        guard denominator > 0 else { return 0 }
        
        return dotProduct / denominator
    }
    
    /// Returns the current count of indexed items.
    func count() -> Int {
        return storage.count
    }
}

/// A high-level manager that orchestrates the interaction between the UI, 
/// an LLM Embedding service, and the LocalVectorStore.
@available(iOS 18.0, macOS 15.0, *)
final class SemanticSearchManager: Sendable {
    
    private let vectorStore: LocalVectorStore
    private let dimension: Int
    
    init(dimension: Int) {
        self.dimension = dimension
        self.vectorStore = LocalVectorStore(requiredDimension: dimension)
    }
    
    /// Simulates an external API call to get an embedding.
    /// In a real app, this calls OpenAI or a local CoreML model.
    func generateEmbedding(for text: String) async throws -> SemanticVector {
        // Simulate network latency
        try await Task.sleep(for: .seconds(0.5))
        
        // Mocking a vector of the correct dimension with random values
        // In production, this is the output of your LLM embedding model.
        let mockValues = (0..<dimension).map { _ in Float.random(in: -1...1) }
        return SemanticVector(values: mockValues, metadata: ["text": text])
    }
    
    /// The primary entry point for the UI to perform a semantic search.
    func performSearch(queryText: String, limit: Int = 3) async throws -> [SearchResult] {
        // 1. Convert text to vector
        let queryVector = try await generateEmbedding(for: queryText)
        
        // 2. Query the actor-isolated store
        return try await vectorStore.search(query: queryVector, k: limit)
    }
    
    /// Adds a document to the knowledge base.
    func ingest(text: String, source: String) async throws {
        let vector = try await generateEmbedding(for: text)
        let vectorWithMetadata = SemanticVector(
            values: vector.values,
            metadata: ["text": text, "source": source]
        )
        try await vectorStore.insert(vectorWithMetadata)
    }
}

// MARK: - Example Usage (Simulation)

@main
struct AppRunner {
    static func main() async {
        print("🚀 Starting Semantic Research Engine...")
        
        // OpenAI text-embedding-3-small uses 1536 dimensions
        let manager = SemanticSearchManager(dimension: 1536)
        
        do {
            print("📝 Ingesting documents...")
            try await manager.ingest(text: "The capital of France is Paris.", source: "Geography Book")
            try await manager.ingest(text: "Swift 6 introduces strict concurrency by default.", source: "Apple Docs")
            try await manager.ingest(text: "The Eiffel Tower is a famous landmark in Paris.", source: "Travel Guide")
            
            print("🔍 Searching for: 'Tell me about French cities'")
            let results = try await manager.performSearch(queryText: "Tell me about French cities")
            
            print("\n--- Search Results ---")
            for (index, result) in results.enumerated() {
                let text = result.metadata["text"] ?? "Unknown"
                let source = result.metadata["source"] ?? "Unknown"
                print("\(index + 1). [Score: \(String(format: "%.4f", result.score))] \(text) (Source: \(source))")
            }
            
        } catch {
            print("❌ Error: \(error.localizedDescription)")
        }
    }
}
