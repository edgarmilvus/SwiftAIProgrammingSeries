
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Vision
import Foundation

@available(iOS 18.0, macOS 15.0, *)
actor InferenceActor {
    private var mlModel: MLModel
    
    // Initializer is synchronous, assumes model is already loaded
    init(model: MLModel) {
        self.mlModel = model
    }

    // A Sendable type for inference results
    struct InferenceResult: Sendable {
        let identifier: String
        let confidence: Double
    }

    // Perform inference within the actor's isolated context
    func classifyImage(input: MLFeatureProvider) async throws -> [InferenceResult] {
        // Core ML inference itself is thread-safe for the MLModel instance,
        // but managing the *input* and *output* flow, especially if
        // intermediate state needs to be maintained, benefits from an actor.
        let output = try await mlModel.prediction(from: input)
        
        // Example: Extracting classification results
        guard let classProbabilities = output.featureValue(for: "classLabelProbs")?.dictionaryValue as? [String: Double] else {
            throw InferenceError.invalidOutput
        }
        
        let sortedResults = classProbabilities.sorted { $0.value > $1.value }
        return sortedResults.prefix(5).map { InferenceResult(identifier: $0.key, confidence: $0.value) }
    }
}

@available(iOS 18.0, macOS 15.0, *)
enum InferenceError: Error {
    case invalidOutput
}

// Analogy: Actor isolation is similar to how @MainActor ensures all UI updates
// happen on the main thread. Here, the InferenceActor ensures all interactions
// with its internal mlModel instance and any related mutable state are serialized,
// preventing race conditions if multiple parts of your app try to trigger inference.

// Usage Example:
@available(iOS 18.0, macOS 15.0, *)
func performConcurrentInference(model: MLModel, images: [MLFeatureProvider]) async {
    let inferenceService = InferenceActor(model: model)
    
    await withTaskGroup(of: [InferenceActor.InferenceResult]?.self) { group in
        for (index, image) in images.enumerated() {
            group.addTask {
                do {
                    print("Starting inference for image \(index)...")
                    let results = try await inferenceService.classifyImage(input: image)
                    print("Results for image \(index): \(results)")
                    return results
                } catch {
                    print("Error for image \(index): \(error)")
                    return nil
                }
            }
        }
        
        // Collect all results (optional)
        for await result in group {
            // Process individual results as they complete
        }
    }
}

// Package.swift snippet for Core ML (if not using System Frameworks)
/*
// This is generally not needed for CoreML as it's a system framework.
// However, if you were to wrap it or use a custom Swift Package for ML utilities:
// Package.swift
import PackageDescription

let package = Package(
    name: "MyMLApp",
    platforms: [
        .iOS(.v18),
        .macOS(.v15)
    ],
    products: [
        .library(
            name: "MyMLApp",
            targets: ["MyMLApp"]),
    ],
    dependencies: [
        // No direct CoreML dependency needed here as it's a system framework
    ],
    targets: [
        .target(
            name: "MyMLApp",
            dependencies: []),
        .testTarget(
            name: "MyMLAppTests",
            dependencies: ["MyMLApp"]),
    ]
)
*/
