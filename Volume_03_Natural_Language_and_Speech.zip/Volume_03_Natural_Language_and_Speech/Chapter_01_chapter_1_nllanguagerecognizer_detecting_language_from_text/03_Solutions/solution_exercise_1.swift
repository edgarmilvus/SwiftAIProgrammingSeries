
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import NaturalLanguage // Import the NaturalLanguage framework
import Combine // Needed for @StateObject in a simple app structure

// Main app entry point (for a complete SwiftUI app)
@main
struct LanguageDetectorApp: App {
    var body: some Scene {
        WindowGroup {
            RealtimeLanguageDetectorView()
        }
    }
}

struct RealtimeLanguageDetectorView: View {
    @State private var inputText: String = ""
    @State private var detectedLanguage: String = "Start typing..."

    var body: some View {
        VStack {
            Text("Real-time Language Detector")
                .font(.largeTitle)
                .padding()

            TextEditor(text: $inputText)
                .frame(height: 150)
                .border(Color.gray, width: 1)
                .padding()
                .onChange(of: inputText) { newText in
                    // Trigger language detection whenever inputText changes
                    detectLanguage(for: newText)
                }

            Text("Detected Language: \(detectedLanguage)")
                .font(.title2)
                .padding()

            Spacer()
        }
    }

    private func detectLanguage(for text: String) {
        // If the text is empty or very short, provide an initial prompt
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && text.count > 3 else { // Require at least 4 characters for better accuracy
            detectedLanguage = "Start typing..."
            return
        }

        // Use NLLanguageRecognizer to determine the dominant language
        let language = NLLanguageRecognizer.dominantLanguage(for: text)

        // Convert NLLanguage to a user-friendly string
        if language == .undetermined {
            detectedLanguage = "Undetermined"
        } else {
            // Use Locale to get the display name for the language
            let locale = Locale(identifier: language.rawValue)
            if let displayName = locale.localizedString(forLanguageCode: language.rawValue) {
                detectedLanguage = displayName.capitalized
            } else {
                detectedLanguage = "Unknown (\(language.rawValue))"
            }
        }
    }
}

// MARK: - Preview Provider (for Xcode Canvas)
#Preview {
    RealtimeLanguageDetectorView()
}
