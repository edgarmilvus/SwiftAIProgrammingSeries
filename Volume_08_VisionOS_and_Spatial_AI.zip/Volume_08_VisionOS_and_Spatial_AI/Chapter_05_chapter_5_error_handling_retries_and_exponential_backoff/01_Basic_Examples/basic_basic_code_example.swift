
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Observation

// MARK: - Error Definitions

/// Represents the specific errors we might encounter when interacting with an AI service.
/// We conform to `LocalizedError` to provide user-friendly messages.
enum AIError: Error, LocalizedError {
    case networkFailure
    case rateLimitExceeded // HTTP 429
    case serverError       // HTTP 500
    case invalidResponse
    case maxRetriesReached

    var errorDescription: String? {
        switch self {
        case .networkFailure:
            return "The connection was lost. Please check your internet."
        case .rateLimitExceeded:
            return "We're receiving too many requests. Please wait a moment."
        case .serverError:
            return "The AI server is having trouble. We're retrying..."
        case .invalidResponse:
            return "Received an unexpected response from the AI."
        case .maxRetriesReached:
            return "I'm having trouble connecting after several attempts. Please try again later."
        }
    }
    
    /// Determines if the error is "transient" (worth retrying) or "permanent" (don't retry).
    var isRetryable: Bool {
        switch self {
        case .networkFailure, .rateLimitExceeded, .serverError:
            return true
        case .invalidResponse, .maxRetriesReached:
            return false
        }
    }
}

// MARK: - Retry Logic Engine

/// A utility actor designed to handle retry logic safely across concurrent tasks.
/// Using an `actor` ensures that any state related to retry tracking is thread-safe.
actor RetryHandler {
    
    /// Performs an asynchronous operation with exponential backoff and jitter.
    /// - Parameters:
    ///   - maxAttempts: The maximum number of times to try the operation.
    ///   - baseDelay: The starting delay in seconds.
    ///   - operation: The asynchronous block to execute.
    /// - Returns: The successful result of the operation.
    /// - Throws: The last error encountered if all attempts fail.
    func withRetry<T>(
        maxAttempts: Int,
        baseDelay: Double,
        operation: @escaping @Sendable () async throws -> T
    ) async throws -> T {
        var currentAttempt = 1
        
        while true {
            do {
                // Attempt the actual work
                return try await operation()
            } catch let error as AIError {
                // Check if we should stop retrying
                guard error.isRetryable, currentAttempt < maxAttempts else {
                    throw error
                }
                
                // Calculate Exponential Backoff: delay = base * 2^(attempt-1)
                let exponentialFactor = pow(2.0, Double(currentAttempt - 1))
                let delaySeconds = baseDelay * exponentialFactor
                
                // Add Jitter: Randomize the delay by +/- 20% to prevent "Thundering Herd"
                let jitter = Double.random(in: 0.8...1.2)
                let finalDelay = delaySeconds * jitter
                
                print("⚠️ Attempt \(currentAttempt) failed: \(error.localizedDescription). Retrying in \(String(format: "%.2f", finalDelay))s...")
                
                // Wait before the next attempt
                // We use ContinuousClock for high-precision timing in Swift 6
                try await Task.sleep(for: .seconds(finalDelay))
                
                currentAttempt += 1
            } catch {
                // If it's an unknown error type, don't retry for safety
                throw error
            }
        }
    }
}

// MARK: - AI Service Layer

/// A mock service simulating an interaction with an OpenAI-like API.
struct AIService {
    /// Simulates an API call that randomly fails to demonstrate retry logic.
    /// - Parameter prompt: The user's input.
    /// - Returns: A string response from the AI.
    func generateResponse(for prompt: String) async throws -> String {
        // Simulate network latency
        try await Task.sleep(for: .milliseconds(500))
        
        // Simulate random failures for demonstration purposes
        let randomValue = Int.random(in: 1...10)
        
        if randomValue <= 3 {
            // 30% chance of a rate limit error
            throw AIError.rateLimitExceeded
        } else if randomValue <= 5 {
            // 20% chance of a network failure
            throw AIError.networkFailure
        } else if randomValue == 6 {
            // 10% chance of a server error
            throw AIError.serverError
        }
        
        // 40% chance of success
        return "AI Response to: '\(prompt)'"
    }
}

// MARK: - View Model (UI Layer)

/// The ViewModel manages the state for the Chat UI.
/// Marked with `@MainActor` to ensure all UI updates happen on the main thread.
@Observable
@MainActor
class ChatViewModel {
    var messages: [String] = []
    var isProcessing: Bool = false
    var errorMessage: String?
    
    private let aiService = AIService()
    private let retryHandler = RetryHandler()
    
    /// Sends a user prompt and handles the lifecycle of the request, including retries.
    func sendPrompt(_ prompt: String) async {
        isProcessing = true
        errorMessage = nil
        messages.append("You: \(prompt)")
        
        do {
            // We wrap the service call inside the retry handler
            let response = try await retryHandler.withRetry(
                maxAttempts: 4,
                baseDelay: 1.0
            ) {
                try await self.aiService.generateResponse(for: prompt)
            }
            
            messages.append("AI: \(response)")
        } catch {
            // If all retries fail, we catch the error here and show it to the user
            self.errorMessage = error.localizedDescription
            messages.append("System: Error occurred.")
        }
        
        isProcessing = false
    }
}

// MARK: - Execution Example (Mocking the App Lifecycle)

@available(iOS 18.0, *)
func runDemo() async {
    let viewModel = ChatViewModel()
    
    print("🚀 Starting AI Chat Demo...")
    await viewModel.sendPrompt("Hello, how are you?")
    
    print("\n--- Final State ---")
    print("Messages: \(viewModel.messages)")
    if let error = viewModel.errorMessage {
        print("Error displayed to user: \(error)")
    }
}

// To run this in a Swift Playground or Command Line Tool:
// Task { await runDemo() }
