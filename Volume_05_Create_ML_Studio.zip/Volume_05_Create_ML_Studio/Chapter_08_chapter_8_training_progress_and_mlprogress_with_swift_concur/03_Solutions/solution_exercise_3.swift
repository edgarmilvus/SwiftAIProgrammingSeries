
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// MARK: - Data Model for Charting
struct MetricDataPoint: Identifiable, Sendable {
    let id = UUID()
    let iteration: Int
    let trainingLoss: Double?
    let validationLoss: Double?
    let trainingAccuracy: Double?
    let validationAccuracy: Double?
}

// MARK: - View Model for a Single Training Session's Metrics
@available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, visionOS 1.0, *)
@MainActor // Ensure all updates to this object happen on the MainActor
class TrainingSessionMetrics: ObservableObject, Identifiable {
    let id: UUID
    @Published var dataPoints: [MetricDataPoint] = []
    @Published var status: String = "Starting..."
    @Published var isCompleted: Bool = false
    @Published var hasFailed: Bool = false

    init(id: UUID) {
        self.id = id
    }

    func processSnapshot(_ snapshot: MLProgress.Snapshot) {
        let newPoint = MetricDataPoint(
            iteration: snapshot.currentIteration,
            trainingLoss: snapshot.metrics[.loss]?.doubleValue,
            validationLoss: snapshot.validationMetrics?[.loss]?.doubleValue,
            trainingAccuracy: snapshot.metrics[.accuracy]?.doubleValue,
            validationAccuracy: snapshot.validationMetrics?[.accuracy]?.doubleValue
        )
        dataPoints.append(newPoint)
        status = "Iteration: \(snapshot.currentIteration), Phase: \(snapshot.phase.description)"
    }

    func markCompleted() {
        status = "Completed!"
        isCompleted = true
    }

    func markFailed(error: Error) {
        status = "Failed: \(error.localizedDescription)"
        hasFailed = true
    }
}

// MARK: - Overall Training Manager for Multiple Sessions
@available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, visionOS 1.0, *)
@MainActor
class TrainingManager: ObservableObject {
    @Published var activeSessions: [TrainingSessionMetrics] = []
    private var sessionTasks: [UUID: Task<Void, Never>] = [:]

    func startNewTrainingSession() {
        let newSessionId = UUID()
        let newSessionMetrics = TrainingSessionMetrics(id: newSessionId)
        activeSessions.append(newSessionMetrics)

        let mlProgress = createMockMLProgress(iterations: 120, delay: .milliseconds(100), failAtIndex: newSessionId.uuidString.first?.wholeNumberValue == 7 ? 60 : nil)

        let sessionTask = Task {
            do {
                for await event in mlProgress {
                    // Check for Task cancellation to stop observing
                    if Task.isCancelled {
                        await newSessionMetrics.markFailed(error: MLProgress.Error.cancelled)
                        return
                    }

                    switch event {
                    case .snapshot(let snapshot):
                        await newSessionMetrics.processSnapshot(snapshot)
                    case .completed:
                        await newSessionMetrics.markCompleted()
                    case .failed(let error):
                        await newSessionMetrics.markFailed(error: error)
                    }
                }
            } catch {
                await newSessionMetrics.markFailed(error: error)
            }
            // Clean up the task reference when it finishes
            await MainActor.run {
                self.sessionTasks.removeValue(forKey: newSessionId)
            }
        }
        sessionTasks[newSessionId] = sessionTask
    }

    func cancelSession(id: UUID) {
        sessionTasks[id]?.cancel()
        // The task itself will handle marking the session as failed/cancelled
    }
}

// MARK: - SwiftUI View for Charting
@available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, visionOS 1.0, *)
struct MetricChartView: View {
    @ObservedObject var sessionMetrics: TrainingSessionMetrics

    var body: some View {
        VStack(alignment: .leading) {
            Text("Session \(sessionMetrics.id.uuidString.prefix(4)) - \(sessionMetrics.status)")
                .font(.subheadline)
                .foregroundColor(sessionMetrics.hasFailed ? .red : (sessionMetrics.isCompleted ? .green : .primary))

            Chart(sessionMetrics.dataPoints) { point in
                if let loss = point.trainingLoss {
                    LineMark(
                        x: .value("Iteration", point.iteration),
                        y: .value("Training Loss", loss)
                    )
                    .foregroundStyle(by: .value("Metric", "Training Loss"))
                }
                if let valLoss = point.validationLoss {
                    LineMark(
                        x: .value("Iteration", point.iteration),
                        y: .value("Validation Loss", valLoss)
                    )
                    .foregroundStyle(by: .value("Metric", "Validation Loss"))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [3, 3])) // Dashed line for validation
                }
                if let accuracy = point.trainingAccuracy {
                    LineMark(
                        x: .value("Iteration", point.iteration),
                        y: .value("Training Accuracy", accuracy)
                    )
                    .foregroundStyle(by: .value("Metric", "Training Accuracy"))
                }
                if let valAccuracy = point.validationAccuracy {
                    LineMark(
                        x: .value("Iteration", point.iteration),
                        y: .value("Validation Accuracy", valAccuracy)
                    )
                    .foregroundStyle(by: .value("Metric", "Validation Accuracy"))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [3, 3]))
                }
            }
            .chartYScale(domain: 0...1) // Assuming metrics like loss/accuracy are often in this range
            .chartXAxisLabel("Iteration")
            .chartYAxisLabel("Value")
            .frame(height: 200)
        }
        .padding(.vertical, 5)
        .border(Color.gray.opacity(0.3), width: 1)
        .cornerRadius(5)
    }
}

@available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, visionOS 1.0, *)
struct ConcurrentTrainingView: View {
    @StateObject private var trainingManager = TrainingManager()

    var body: some View {
        VStack {
            Text("Concurrent Model Training")
                .font(.largeTitle)
                .padding(.bottom)

            Button("Start New Training Session") {
                trainingManager.startNewTrainingSession()
            }
            .padding(.bottom)

            ScrollView {
                LazyVStack(spacing: 20) {
                    ForEach(trainingManager.activeSessions) { session in
                        HStack {
                            MetricChartView(sessionMetrics: session)
                            Button("Cancel") {
                                trainingManager.cancelSession(id: session.id)
                            }
                            .disabled(session.isCompleted || session.hasFailed)
                        }
                    }
                }
            }
        }
        .padding()
    }
}
