
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import CoreML
import Foundation

// MARK: - Placeholder for our custom Core ML Model
// In a real app, you would drag your 'MySecureClassifier.mlmodel' file into your Xcode project.
// Xcode automatically compiles it into 'MySecureClassifier.mlmodelc' and adds it to your app bundle.
// For demonstration, we assume this model exists and has been configured for encryption/signing
// during its export/compilation phase via Xcode's build settings or `coremlcompiler` tool.

/// A simple structure to represent the output of our image classifier.
struct ClassificationResult {
    let label: String
    let confidence: Double
}

/// Manages the loading and basic interaction with our secure Core ML model.
@MainActor // Ensure UI updates and model interactions happen on the main actor.
class SecureModelLoader: ObservableObject {
    @Published var modelLoadingStatus: String = "Not loaded"
    @Published var loadedModel: MLModel?
    @Published var classificationResult: ClassificationResult?

    /// Asynchronously loads the Core ML model from the app bundle.
    /// - Parameter modelName: The base name of the Core ML model (without .mlmodelc extension).
    /// - Throws: An error if the model cannot be found or loaded.
    func loadSecureImageClassifierModel(modelName: String = "MySecureClassifier") async {
        modelLoadingStatus = "Attempting to load model '\(modelName)'..."

        // 1. Locate the compiled Core ML model in the app bundle.
        // The .mlmodelc extension is crucial as it refers to the compiled model directory.
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            modelLoadingStatus = "Error: Model '\(modelName).mlmodelc' not found in app bundle."
            print("Error: Model '\(modelName).mlmodelc' not found.")
            return
        }

        do {
            // 2. Configure the MLModel.
            // MLModelConfiguration allows specifying compute units (CPU, GPU, Neural Engine).
            // For sensitive models, you might prefer Neural Engine for performance,
            // but CPU might be a fallback or chosen for specific privacy reasons.
            let configuration = MLModelConfiguration()
            configuration.computeUnits = .all // Utilize all available compute units (CPU, GPU, Neural Engine)

            // 3. Load the model.
            // If the model was encrypted and signed, Core ML and the OS will transparently
            // decrypt and verify it here using app entitlements.
            // If decryption/verification fails, this initializer will throw an error.
            let model = try MLModel(contentsOf: modelURL, configuration: configuration)
            self.loadedModel = model
            modelLoadingStatus = "Model '\(modelName)' loaded successfully!"
            print("Model '\(modelName)' loaded. Description: \(model.modelDescription.metadata.shortDescription ?? "No description")")

            // 4. (Optional) Simulate a prediction to show the model is functional.
            // For a real image classifier, you'd pass an MLFeatureProvider (e.g., an image buffer).
            // Here, we just print a placeholder message.
            // To make a real prediction, you'd typically need a specific input type, e.g., CVPixelBuffer.
            // For simplicity, we'll just acknowledge it's loaded.
            // let input = try MLDictionaryFeatureProvider(dictionary: ["image": someCVPixelBuffer])
            // let prediction = try model.prediction(from: input)
            // self.classificationResult = ClassificationResult(label: prediction.featureValue(for: "label")?.stringValue ?? "Unknown", confidence: 0.99)

        } catch {
            self.loadedModel = nil
            modelLoadingStatus = "Error loading model '\(modelName)': \(error.localizedDescription)"
            print("Failed to load model '\(modelName)': \(error)")
        }
    }
}

/// The main SwiftUI view for our Secure Content Analyzer app.
struct SecureClassifierView: View {
    @StateObject private var modelLoader = SecureModelLoader()

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Secure Content Analyzer")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Spacer()

                VStack(alignment: .leading, spacing: 10) {
                    Text("Model Status:")
                        .font(.headline)
                    Text(modelLoader.modelLoadingStatus)
                        .font(.subheadline)
                        .foregroundColor(modelLoader.loadedModel != nil ? .green : .red)
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)

                if let model = modelLoader.loadedModel {
                    Text("Model loaded: \(model.modelDescription.metadata.shortDescription ?? "No description")")
                        .font(.caption)
                        .padding(.horizontal)
                }

                if let result = modelLoader.classificationResult {
                    Text("Last Classification: \(result.label) (\(result.confidence * 100, specifier: "%.2f")%)")
                        .font(.body)
                        .padding()
                        .background(Color.blue.opacity(0.2))
                        .cornerRadius(8)
                }

                Button("Load Secure Classifier Model") {
                    Task {
                        await modelLoader.loadSecureImageClassifierModel()
                    }
                }
                .buttonStyle(.borderedProminent)
                .padding(.top, 20)

                Spacer()
            }
            .padding()
            .navigationTitle("") // Hide default navigation title
            .navigationBarHidden(true) // Hide navigation bar for cleaner look
            .onAppear {
                // Optionally load the model automatically when the view appears
                // Task {
                //     await modelLoader.loadSecureImageClassifierModel()
                // }
            }
        }
    }
}

// MARK: - Preview Provider (for Xcode Canvas)
struct SecureClassifierView_Previews: PreviewProvider {
    static var previews: some View {
        SecureClassifierView()
    }
}

