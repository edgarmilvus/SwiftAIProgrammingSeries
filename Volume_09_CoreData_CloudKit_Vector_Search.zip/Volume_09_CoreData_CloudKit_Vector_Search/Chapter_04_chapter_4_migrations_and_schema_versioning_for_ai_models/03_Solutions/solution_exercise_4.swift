
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CoreData
import Foundation

// 1. Entities (Conceptual Schema)
// ResearchNote: (id, title) -> Relationship: vectorStores (1:N)
// VectorStore: (vectorData: Data, modelIdentifier: String, createdAt: Date)

actor MigrationCoordinator {
    private let container: NSPersistentContainer
    private let newModelID = "v2-1536-dim"
    
    init(container: NSPersistentContainer) {
        self.container = container
    }
    
    func performBackgroundMigration() async {
        let context = container.newBackgroundContext()
        context.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        
        // 1. Identify notes missing the new model
        let fetchRequest: NSFetchRequest<NSManagedObject> = NSFetchRequest(entityName: "ResearchNote")
        
        do {
            let notes = try context.fetch(fetchRequest)
            
            // 2. Batch processing using TaskGroup
            await withTaskGroup(of: Void.self) { group in
                for note in notes {
                    // Check if note already has this model version
                    let hasVersion = note.value(forKey: "vectorStores") as? Set<NSManagedObject>
                        .map { $0.contains { $0.value(forKey: "modelIdentifier") as? String == newModelID } } ?? false
                    
                    if !hasVersion {
                        group.addTask {
                            await self.migrateSingleNote(note: note, in: context)
                        }
                    }
                }
            }
            print("✅ Background Migration Complete.")
        } catch {
            print("❌ Migration Error: \(error)")
        }
    }
    
    private func migrateSingleNote(note: NSManagedObject, in context: NSManagedObjectContext) async {
        let content = note.value(forKey: "content") as? String ?? ""
        let newVector = await EmbeddingService.shared.generateEmbedding(for: content)
        let vectorData = newVector.withUnsafeBytes { Data($0) }
        
        // 3. Perform write on the private context
        await context.perform {
            let vectorStore = NSEntityDescription.insertNewObject(forEntityName: "VectorStore", into: context)
            vectorStore.setValue(vectorData, forKey: "vectorData")
            vectorStore.setValue(self.newModelID, forKey: "modelIdentifier")
            vectorStore.setValue(Date(), forKey: "createdAt")
            
            // Link to note
            let stores = note.mutableSetValue(forKey: "vectorStores")
            stores.add(vectorStore)
            
            try? context.save()
        }
    }
}

// 4. Search Service
struct SearchService {
    func search(query: String, modelID: String, context: NSManagedObjectContext) {
        let fetchRequest: NSFetchRequest<NSManagedObject> = NSFetchRequest(entityName: "VectorStore")
        fetchRequest.predicate = NSPredicate(format: "modelIdentifier == %@", modelID)
        
        // Perform similarity search logic here...
        print("Searching using model: \(modelID)")
    }
}
