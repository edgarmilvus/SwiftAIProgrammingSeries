
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import ARKit
import Observation

/// Represents the various states of spatial sensor availability.
/// This enum is used to drive the UI and ensure the user is informed of the app's status.
enum SpatialPermissionStatus: Equatable {
    case notDetermined
    case authorized
    case denied
    case restricted
}

/// A manager responsible for handling the lifecycle of spatial permissions.
/// Using `@MainActor` ensures that all updates to the `@Observable` state 
/// happen on the main thread, which is critical for SwiftUI stability.
@Observable
@MainActor
final class SpatialPermissionManager {
    
    /// The current status of the spatial tracking permission.
    /// This is observed by the SwiftUI view to update the interface.
    var status: SpatialPermissionStatus = .notDetermined
    
    /// A descriptive error message to show the user if a request fails.
    var errorMessage: String?
    
    /// Initializes the manager and performs an initial check of the permission status.
    init() {
        // In a real-world scenario, we would check the current ARKit/RealityKit 
        // authorization status here.
        checkCurrentStatus()
    }
    
    /// Performs a synchronous check of the current permission status.
    /// Note: In visionOS, many permission checks are handled via the system 
    /// through ARKit or the WorldTrackingProvider.
    private func checkCurrentStatus() {
        // For the purpose of this example, we simulate the check.
        // In production, you would use: ARKitSession.shared.trackingStatus
        self.status = .notDetermined
    }
    
    /// Requests permission from the user to access spatial tracking data.
    /// This is an asynchronous function that interacts with the system-level 
    /// permission dialog.
    ///
    /// - Throws: An error if the permission request is interrupted or fails.
    func requestSpatialAccess() async throws {
        // 1. Clear previous errors
        self.errorMessage = nil
        
        // 2. Simulate the asynchronous delay of a system permission dialog.
        // In a real app, this would be: try await session.run([.worldTracking])
        try await Task.sleep(for: .seconds(1.5))
        
        // 3. Simulate a successful permission grant.
        // In a real app, we would evaluate the result of the ARKit session.
        let success = true 
        
        if success {
            self.status = .authorized
        } else {
            self.status = .denied
            self.errorMessage = "Permission was denied by the user."
        }
    }
    
    /// Resets the manager state, useful for testing or handling 'Reset' flows.
    func reset() {
        self.status = .notDetermined
        self.errorMessage = nil
    }
}

/// The primary view for our Spatial Vision Assistant.
/// This view demonstrates how to reactively update the UI based on the 
/// permission status managed by the `SpatialPermissionManager`.
struct SpatialAssistantView: View {
    
    /// The source of truth for permissions, owned by the view's lifecycle.
    @State private var permissionManager = SpatialPermissionManager()
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 30) {
                // Status Indicator Icon
                statusIcon
                    .font(.system(size: 80))
                    .foregroundStyle(statusColor)
                
                // Informational Text
                VStack(spacing: 10) {
                    Text("Spatial Assistant")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    
                    statusDescription
                        .font(.title3)
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                }
                
                // Action Button
                if permissionManager.status != .authorized {
                    Button(action: {
                        // We wrap the async call in a Task to bridge 
                        // the synchronous button action to the async function.
                        Task {
                            do {
                                try await permissionManager.requestSpatialAccess()
                            } catch {
                                permissionManager.errorMessage = "An unexpected error occurred."
                            }
                        }
                    }) {
                        Text(permissionManager.status == .notDetermined ? "Enable Spatial Tracking" : "Try Again")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .padding(.horizontal, 50)
                } else {
                    // The "Success" state: Show the actual Spatial AI interface
                    SpatialAIInterfaceView()
                        .transition(.opacity.combined(with: .scale))
                }
                
                // Error Display
                if let error = permissionManager.errorMessage {
                    Text(error)
                        .font(.caption)
                        .foregroundStyle(.red)
                        .transition(.move(edge: .bottom))
                }
            }
            .padding()
            .navigationTitle("Setup")
            .animation(.spring(duration: 0.4), value: permissionManager.status)
        }
    }
    
    // MARK: - Helper Views
    
    @ViewBuilder
    private var statusIcon: some View {
        switch permissionManager.status {
        case .notDetermined:
            Image(systemName: "eye.slash.fill")
        case .authorized:
            Image(systemName: "eye.fill")
        case .denied, .restricted:
            Image(systemName: "exclamationmark.triangle.fill")
        }
    }
    
    private var statusColor: Color {
        switch permissionManager.status {
        case .notDetermined: return .gray
        case .authorized: return .green
        case .denied, .restricted: return .red
        }
    }
    
    private var statusDescription: some View {
        switch permissionManager.status {
        case .notDetermined:
            return "To provide intelligent spatial insights, we need permission to access your environment."
        case .authorized:
            return "Spatial tracking is active. The assistant is ready."
        case .denied, .restricted:
            return "Spatial tracking is disabled. Please enable it in Settings to use this feature."
        }
    }
}

/// A placeholder view representing the core functionality of the app 
/// once permissions are granted.
struct SpatialAIInterfaceView: View {
    var body: some View {
        VStack {
            Text("AI Engine Active")
                .font(.headline)
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(10)
            
            Text("Scanning environment...")
                .font(.subheadline)
                .italic()
        }
    }
}

// MARK: - App Entry Point

@main
struct SpatialAssistantApp: App {
    var body: some Scene {
        WindowGroup {
            SpatialAssistantView()
        }
    }
}
