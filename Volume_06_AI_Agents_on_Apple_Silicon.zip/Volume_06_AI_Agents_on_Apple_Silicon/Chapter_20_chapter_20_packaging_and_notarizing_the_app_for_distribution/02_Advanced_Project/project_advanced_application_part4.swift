
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

/// @available(macOS 14.0, *)
/// An agent that orchestrates AI-powered code review and refactoring suggestions.
/// It utilizes the `LLMService` to interact with the local LLM.
///
/// This class demonstrates:
/// - High-level application logic built upon a low-level AI service.
/// - Prompt engineering for specific AI tasks.
/// - State management for a user-facing feature.
/// - Integration with Swift 6 concurrency for long-running operations.
actor CodeReviewAgent {
    private let llmService: LLMService

    /// Initializes the CodeReviewAgent with an LLMService instance.
    /// - Parameter llmService: The LLMService to use for model interaction.
    init(llmService: LLMService) {
        self.llmService = llmService
    }

    /// Generates a structured prompt for the LLM to perform a code review.
    /// - Parameters:
    ///   - code: The Swift code snippet to be reviewed.
    ///   - context: Optional additional context for the review (e.g., "This is part of a networking layer.").
    /// - Returns: A formatted string prompt suitable for the LLM.
    private func createReviewPrompt(code: String, context: String?) -> String {
        var prompt = """
        You are an expert Swift developer and a helpful AI assistant.
        Your task is to review the provided Swift code snippet, identify potential issues,
        suggest refactorings for improved readability, performance, or best practices,
        and provide a concise summary of your findings.
        If possible, provide refactored code examples.
        Focus on Swift 6 best practices, concurrency, error handling, and memory management.

        Code to review:
        