
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

/// Represents the safety status of a piece of AI-generated content.
enum SafetyStatus: Sendable, Equatable {
    case pending
    case safe
    case unsafe(reason: String)
}

/// A thread-safe container for content that is undergoing moderation.
/// Conforms to Sendable to ensure it can be passed between actors.
struct ContentPacket: Sendable {
    let id: UUID
    let text: String
    let timestamp: Date
}

/// The ModerationActor is the 'Internal Reviewer'.
/// It isolates the safety logic from the rest of the application.
@available(iOS 18.0, *)
actor ModerationEngine {
    private var blockedKeywords: Set<String> = ["badword1", "badword2"] // Simplified for example
    
    /// Performs a multi-stage moderation check.
    /// This is a non-deterministic process modeled as an async function.
    func validate(_ packet: ContentPacket) async -> SafetyStatus {
        // Stage 1: Fast Keyword Scan (Simulated)
        try? await Task.sleep(for: .milliseconds(100)) 
        
        for word in blockedKeywords {
            if packet.text.lowercased().contains(word) {
                return .unsafe(reason: "Prohibited language detected.")
            }
        }
        
        // Stage 2: Semantic Analysis (Simulated heavy Core ML task)
        // In a real app, this would call a Core ML model.
        try? await Task.sleep(for: .milliseconds(500))
        
        if packet.text.contains("jailbreak") {
            return .unsafe(reason: "Prompt injection attempt detected.")
        }
        
        return .safe
    }
}

/// The ViewModel uses @Observable to reactively update the UI
/// based on the results of the ModerationEngine.
@available(iOS 18.0, *)
@Observable
class ChatViewModel {
    var currentMessage: String = ""
    var safetyStatus: SafetyStatus = .safe
    var messages: [String] = []
    
    private let engine = ModerationEngine()
    
    /// Processes a user prompt through the moderation pipeline.
    func sendMessage(_ input: String) async {
        // 1. Immediate UI update for user feedback
        currentMessage = input
        
        // 2. Create a Sendable packet
        let packet = ContentPacket(id: UUID(), text: input, timestamp: Date())
        
        // 3. Perform moderation via the Actor
        // The UI remains responsive because this is awaited.
        safetyStatus = .pending
        let result = await engine.validate(packet)
        
        // 4. Handle the result
        switch result {
        case .safe:
            // In a real app, this is where you'd call the LLM
            let aiResponse = "This is a safe response to: \(input)"
            let responsePacket = ContentPacket(id: UUID(), text: aiResponse, timestamp: Date())
            
            // Validate the AI response before showing it!
            let responseResult = await engine.validate(responsePacket)
            if case .safe = responseResult {
                messages.append(aiResponse)
                safetyStatus = .safe
            } else {
                messages.append("[Content Blocked]")
                safetyStatus = .unsafe(reason: "AI generated inappropriate content.")
            }
            
        case .unsafe(let reason):
            safetyStatus = .unsafe(reason: reason)
            messages.append("[Message blocked: \(reason)]")
        case .pending:
            break
        }
    }
}
