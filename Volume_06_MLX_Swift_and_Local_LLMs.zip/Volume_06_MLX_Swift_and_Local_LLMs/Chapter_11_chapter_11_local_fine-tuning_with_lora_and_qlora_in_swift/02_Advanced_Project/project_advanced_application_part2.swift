
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import MLX
import MLXNN

/// Represents a LoRA (Low-Rank Adaptation) adapter for a linear layer.
/// This module contains the trainable A and B matrices that inject
/// low-rank updates into the base model's linear transformations.
final class LoRALinearAdapter: MLXNN.Module {
    let inputDimensions: Int
    let outputDimensions: Int
    let rank: Int
    let alpha: Double

    /// The 'A' matrix of the LoRA adapter.
    /// Initialized with a small random value (e.g., Kaiming uniform)
    /// to ensure the initial update is negligible.
    @MLXNN.Parameter var loraA: MLXArray
    /// The 'B' matrix of the LoRA adapter.
    /// Initialized to zeros, so the initial LoRA output is zero.
    @MLXNN.Parameter var loraB: MLXArray

    /// Initializes a new LoRA adapter.
    /// - Parameters:
    ///   - inputDimensions: The input feature dimension of the base linear layer.
    ///   - outputDimensions: The output feature dimension of the base linear layer.
    ///   - rank: The low rank `r` for the LoRA matrices (e.g., 4, 8, 16).
    ///   - alpha: Scaling factor for the LoRA output. Typically `rank * 2`.
    ///   - key: The `MLXRandom.Key` for parameter initialization.
    init(inputDimensions: Int, outputDimensions: Int, rank: Int, alpha: Double, key: MLXRandom.Key) {
        self.inputDimensions = inputDimensions
        self.outputDimensions = outputDimensions
        self.rank = rank
        self.alpha = alpha

        // Initialize loraA using Kaiming uniform for small initial values.
        // This helps prevent large initial perturbations to the base model.
        let kaimingUniformFactor = sqrt(1.0 / Double(inputDimensions))
        self.loraA = MLXArray.randomUniform(
            low: -kaimingUniformFactor,
            high: kaimingUniformFactor,
            [inputDimensions, rank],
            key: key
        )

        // Initialize loraB to zeros. This ensures that the LoRA path
        // initially adds nothing to the base model's output.
        self.loraB = MLXArray.zeros([rank, outputDimensions])

        super.init()
    }

    /// Performs the forward pass for the LoRA adapter.
    /// - Parameter input: The input tensor from the base linear layer.
    /// - Returns: The low-rank update tensor `(input @ loraA @ loraB) * (alpha / rank)`.
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Compute the low-rank update: (input @ loraA @ loraB)
        // The result is scaled by (alpha / rank) as per LoRA paper.
        return (input.matmul(loraA).matmul(loraB)) * (alpha / Double(rank))
    }
}
