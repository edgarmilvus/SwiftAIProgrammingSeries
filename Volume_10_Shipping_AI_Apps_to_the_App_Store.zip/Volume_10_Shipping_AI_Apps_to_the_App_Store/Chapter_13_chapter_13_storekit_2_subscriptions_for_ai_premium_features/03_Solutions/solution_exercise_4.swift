
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import StoreKit
import Foundation

struct UserAccount: Sendable {
    var subscriptionStatus: SubscriptionStatus = .free
    var creditBalance: Int = 0
}

@available(iOS 18.0, *)
actor MonetizationEngine {
    private(set) var userAccount = UserAccount()
    private var processedTransactionIDs = Set<UInt64>() // Replay protection
    
    // Mock backend synchronization
    private func syncCreditsWithServer(newBalance: Int) async throws {
        // Simulate network latency
        try await Task.sleep(for: .seconds(1))
        print("Backend synced: \(newBalance) credits.")
    }

    func processTransaction(_ transaction: Transaction) async throws {
        // 1. Transaction Replay Protection (Hard Mode)
        guard !processedTransactionIDs.contains(transaction.id) else {
            print("Duplicate transaction detected: \(transaction.id)")
            return
        }

        // 2. Cryptographic Verification
        guard case .verified(let verifiedTransaction) = transaction else {
            throw NSError(domain: "SecurityError", code: 401)
        }

        // 3. Route by Product Type
        if verifiedTransaction.productType == .autoRenewable {
            // Handle Subscription
            userAccount.subscriptionStatus = .pro
            print("Subscription activated.")
        } else if verifiedTransaction.productType == .consumable {
            // Handle Consumable Credits
            try await handleCreditPurchase(verifiedTransaction)
        }

        // 4. Finalize
        processedTransactionIDs.insert(transaction.id)
        await verifiedTransaction.finish()
    }

    private func handleCreditPurchase(_ transaction: Transaction) async throws {
        // Logic: Determine how many credits to add (hardcoded for demo)
        let creditsToAdd = 100 
        let newBalance = userAccount.creditBalance + creditsToAdd
        
        // 5. ATOMIC UPDATE PATTERN:
        // Update local state -> Sync to Server -> ONLY THEN finish transaction.
        // This prevents "lost money" if the app crashes during the network call.
        try await syncCreditsWithServer(newBalance: newBalance)
        
        self.userAccount.creditBalance = newBalance
        print("Credits added. New balance: \(newBalance)")
    }
    
    func consumeCredits(amount: Int) throws {
        guard userAccount.creditBalance >= amount else {
            throw NSError(domain: "InsufficientCredits", code: 403)
        }
        userAccount.creditBalance -= amount
    }
}
