
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import SwiftData

@Model
final class Summary {
    var text: String
    var sourceDocumentID: UUID
    var confidenceScore: Float
    
    init(text: String, sourceDocumentID: UUID, confidenceScore: Float) {
        self.text = text
        self.sourceDocumentID = sourceDocumentID
        self.confidenceScore = confidenceScore
    }
}

actor IngestionService {
    private let modelContainer: ModelContainer
    
    init(container: ModelContainer) {
        self.modelContainer = container
    }
    
    /// Ingests summaries in optimized chunks to balance speed and safety.
    func ingest(summaries: [Summary]) async throws {
        // Create a new context specifically for this background work
        let context = ModelContext(modelContainer)
        
        // 1. Disable autosave to prevent frequent, expensive disk I/O
        context.autosaveEnabled = false
        
        let chunkSize = 100
        let totalSummaries = summaries.count
        
        for i in stride(from: 0, to: totalSummaries, by: chunkSize) {
            let end = min(i + chunkSize, totalSummaries)
            let chunk = summaries[i..<end]
            
            // 2. Process the chunk
            for summary in chunk {
                // We must create a new instance in this context 
                // or pass data to be instantiated here.
                let newSummary = Summary(
                    text: summary.text,
                    sourceDocumentID: summary.sourceDocumentID,
                    confidenceScore: summary.confidenceScore
                )
                context.insert(newSummary)
            }
            
            // 3. Perform an atomic save for the chunk
            // This commits 100 rows in a single SQLite transaction.
            try context.save()
            
            // Yield to allow other tasks to run if this is a massive import
            await Task.yield()
            
            print("Progress: \(end)/\(totalSummaries) ingested.")
        }
    }
}

// Usage Example
// Task {
//    let service = IngestionService(container: sharedContainer)
//    try await service.ingest(summaries: largeArrayOfSummaries)
// }
