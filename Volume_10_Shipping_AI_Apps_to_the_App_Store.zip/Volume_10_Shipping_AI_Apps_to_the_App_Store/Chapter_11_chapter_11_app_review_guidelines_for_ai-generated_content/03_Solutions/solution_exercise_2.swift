
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

@available(iOS 18.0, *)
struct AIProvenance: Sendable {
    enum Source: String, Sendable {
        case llm = "Large Language Model"
        case diffusion = "Diffusion Model"
        case hybrid = "Hybrid AI"
    }
    
    let source: Source
    let confidenceScore: Double
}

// 1. Define the Environment Key
@available(iOS 18.0, *)
struct AIProvenanceKey: EnvironmentKey {
    static let defaultValue: AIProvenance? = nil
}

@available(iOS 18.0, *)
extension EnvironmentValues {
    var aiProvenance: AIProvenance? {
        get { self[AIProvenanceKey.self] }
        set { self[AIProvenanceKey.self] = newValue }
    }
}

// 2. The ViewModifier
@available(iOS 18.0, *)
struct AIProvenanceLabel: ViewModifier {
    @Environment(\.aiProvenance) var provenance
    @State private var showPopover = false
    
    func body(content: Content) -> some View {
        content
            .overlay(alignment: .topTrailing) {
                if let provenance = provenance {
                    Button {
                        showPopover.toggle()
                    } label: {
                        Image(systemName: "sparkles")
                            .foregroundStyle(.blue)
                            .padding(4)
                            .accessibilityLabel("AI Generated Content Info")
                    }
                    .popover(isPresented: $showPopover) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("AI Provenance")
                                .font(.headline)
                            Text("Source: \(provenance.source.rawValue)")
                            Text("Confidence: \(Int(provenance.confidenceScore * 100))%")
                        }
                        .padding()
                        .presentationCompactAdaptation(.popover)
                    }
                }
            }
    }
}

// 3. Convenience Extension
@available(iOS 18.0, *)
extension View {
    func aiProvenanceLabel() -> some View {
        self.modifier(AIProvenanceLabel())
    }
}

// 4. Usage Demonstration
@available(iOS 18.0, *)
struct JournalView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("My Daily Journal")
                    .font(.largeTitle)
                
                // This section is NOT AI-generated
                Text("Today I went for a walk in the park. The weather was lovely.")
                    .padding()
                
                Divider()
                
                // This section IS AI-generated via Environment injection
                VStack(alignment: .leading) {
                    Text("AI-Rewritten Version:")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    
                    Text("The sun cast a golden hue over the verdant landscape as I strolled through the tranquil park.")
                        .aiProvenanceLabel() // Inherits from environment
                        .padding()
                        .background(Color.secondary.opacity(0.1))
                        .cornerRadius(8)
                }
                .environment(\.aiProvenance, AIProvenance(source: .llm, confidenceScore: 0.98))
            }
            .padding()
        }
    }
}
