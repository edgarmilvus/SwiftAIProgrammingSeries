
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet (not strictly necessary for built-in frameworks, but good practice for context)
// This section indicates the frameworks implicitly linked by an Xcode project.
/*
import PackageDescription

let package = Package(
    name: "MultilingualDocumentScanner",
    platforms: [
        .iOS(.v15), // Vision and NaturalLanguage APIs are stable on iOS 15+
        .macOS(.v12),
        .tvOS(.v15),
        .watchOS(.v8)
    ],
    products: [
        .library(
            name: "MultilingualDocumentScanner",
            targets: ["MultilingualDocumentScanner"]),
    ],
    targets: [
        .target(
            name: "MultilingualDocumentScanner",
            dependencies: []), // Vision and NaturalLanguage are system frameworks
    ]
)
*/

import Foundation
import Vision // For Optical Character Recognition (OCR)
import NaturalLanguage // For Language Detection
import UIKit // For UIImage (or AppKit for NSImage on macOS)

// MARK: - Custom Errors

/// Defines custom errors specific to the document scanning and language detection process.
enum DocumentScannerError: Error, LocalizedError {
    case imageProcessingFailed(String)
    case textRecognitionFailed(String)
    case noTextDetected
    case languageDetectionFailed(String)
    case invalidInputImage

    var errorDescription: String? {
        switch self {
        case .imageProcessingFailed(let details):
            return "Failed to process the image: \(details)"
        case .textRecognitionFailed(let details):
            return "Failed to recognize text in the image: \(details)"
        case .noTextDetected:
            return "No text could be detected in the image."
        case .languageDetectionFailed(let details):
            return "Failed to detect language: \(details)"
        case .invalidInputImage:
            return "The provided image input is invalid or nil."
        }
    }
}

// MARK: - Result Structure

/// Represents the comprehensive result of a document scan and language detection.
struct ScannedDocumentResult {
    /// The full text extracted from the document.
    let fullText: String
    /// The dominant language detected in the text.
    let detectedLanguage: NLLanguage?
    /// The confidence score for the detected language (0.0 to 1.0).
    let languageConfidence: Double?
}

// MARK: - Document Scanner Service

/// A service responsible for scanning documents, recognizing text, and detecting its language.
/// This class encapsulates the complex asynchronous workflow involving Vision and Natural Language frameworks.
@available(iOS 15.0, macOS 12.0, tvOS 15.0, watchOS 8.0, *)
final class MultilingualDocumentScanner {

    /// Initializes a new instance of the MultilingualDocumentScanner.
    init() {}

    /// Scans an image for text, then detects the dominant language of the recognized text.
    ///
    /// This method performs the following steps asynchronously:
    /// 1. Converts the input `UIImage` to a `CGImage`.
    /// 2. Initiates a `VNRecognizeTextRequest` using the Vision framework to perform OCR.
    /// 3. Extracts all recognized text observations and concatenates them into a single string.
    /// 4. Uses `NLLanguageRecognizer` from the Natural Language framework to determine the primary language.
    /// 5. Returns a `ScannedDocumentResult` containing the text, detected language, and its confidence.
    ///
    /// - Parameter image: The `UIImage` of the document to be scanned.
    /// - Returns: A `ScannedDocumentResult` containing the extracted text and detected language information.
    /// - Throws: `DocumentScannerError` if any step of the process fails (e.g., OCR failure, no text, language detection issues).
    func scanAndDetectLanguage(for image: UIImage) async throws -> ScannedDocumentResult {
        guard let cgImage = image.cgImage else {
            throw DocumentScannerError.invalidInputImage
        }

        // 1. Perform Text Recognition (OCR) using Vision framework
        let recognizedText = try await recognizeText(from: cgImage)

        guard !recognizedText.isEmpty else {
            throw DocumentScannerError.noTextDetected
        }

        // 2. Detect Language using NaturalLanguage framework
        let (language, confidence) = detectLanguage(for: recognizedText)

        // 3. Aggregate and return results
        return ScannedDocumentResult(
            fullText: recognizedText,
            detectedLanguage: language,
            languageConfidence: confidence
        )
    }

    /// Performs Optical Character Recognition (OCR) on a given `CGImage` using the Vision framework.
    ///
    /// - Parameter cgImage: The `CGImage` to recognize text from.
    /// - Returns: A `String` containing all recognized text concatenated.
    /// - Throws: `DocumentScannerError` if text recognition fails or no text is found.
    private func recognizeText(from cgImage: CGImage) async throws -> String {
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNRecognizeTextRequest { request, error in
                if let error = error {
                    continuation.resume(throwing: DocumentScannerError.textRecognitionFailed(error.localizedDescription))
                    return
                }

                guard let observations = request.results as? [VNRecognizeTextObservation] else {
                    continuation.resume(throwing: DocumentScannerError.textRecognitionFailed("No text observations found."))
                    return
                }

                let recognizedStrings = observations.compactMap { observation in
                    // Get the top candidate for each text block
                    observation.topCandidates(1).first?.string
                }

                let fullText = recognizedStrings.joined(separator: "\n")
                continuation.resume(returning: fullText)
            }

            // Configure the request for better accuracy and language hints if known
            request.recognitionLevel = .accurate // Prioritize accuracy over speed
            // request.recognitionLanguages = ["en-US", "fr-FR", "es-ES"] // Optional: Hint known languages for better OCR

            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: DocumentScannerError.imageProcessingFailed(error.localizedDescription))
            }
        }
    }

    /// Detects the dominant language of a given text string using `NLLanguageRecognizer`.
    ///
    /// - Parameter text: The text string for which to detect the language.
    /// - Returns: A tuple containing the detected `NLLanguage` (if any) and its `Double` confidence score.
    private func detectLanguage(for text: String) -> (NLLanguage?, Double?) {
        let recognizer = NLLanguageRecognizer()
        recognizer.processString(text)

        // Get the dominant language with its confidence score
        if let (language, confidence) = recognizer.dominantLanguage {
            return (language, confidence)
        } else {
            // If no dominant language can be determined, return nil
            return (nil, nil)
        }
    }
}

// MARK: - Example Usage (within a ViewController or App entry point)

// This would typically be in a UI context, e.g., after picking an image from the photo library.
@available(iOS 15.0, *)
func demonstrateMultilingualDocumentScanner() async {
    print("--- Starting Multilingual Document Scanner Demo ---")

    // Simulate an image (in a real app, this would come from UIImagePicker or camera)
    // For demonstration, let's create a simple image with text.
    // In a real app, you'd load a UIImage from assets or a live camera feed.
    // For simplicity, we'll use a placeholder and assume it has text.
    // If running in a Playground, you might use:
    // let image = UIImage(named: "sample_document_english_french")!

    // Create a dummy image for demonstration purposes.
    // In a real app, you'd load this from your assets or camera.
    let dummyImage = UIGraphicsImageRenderer(size: CGSize(width: 400, height: 200)).image { context in
        UIColor.white.setFill()
        context.fill(CGRect(x: 0, y: 0, width: 400, height: 200))

        let text = """
        Hello, world!
        Ceci est un test.
        ¡Hola mundo!
        """
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 24),
            .foregroundColor: UIColor.black,
            .paragraphStyle: paragraphStyle
        ]
        text.draw(in: CGRect(x: 20, y: 50, width: 360, height: 100), withAttributes: attributes)
    }

    let scanner = MultilingualDocumentScanner()

    do {
        let result = try await scanner.scanAndDetectLanguage(for: dummyImage)
        print("\n--- Scan Result ---")
        print("Full Extracted Text:\n\(result.fullText)")
        if let lang = result.detectedLanguage, let confidence = result.languageConfidence {
            print("Detected Dominant Language: \(lang.rawValue) (Confidence: \(String(format: "%.2f", confidence * 100))%)")
        } else {
            print("Could not confidently detect a dominant language.")
        }
    } catch {
        print("\n--- Scan Error ---")
        if let scannerError = error as? DocumentScannerError {
            print("Error: \(scannerError.localizedDescription)")
        } else {
            print("An unexpected error occurred: \(error.localizedDescription)")
        }
    }

    // Demonstrate with an empty image to show error handling
    print("\n--- Demonstrating Error: No Text Detected ---")
    let emptyImage = UIGraphicsImageRenderer(size: CGSize(width: 400, height: 200)).image { context in
        UIColor.white.setFill()
        context.fill(CGRect(x: 0, y: 0, width: 400, height: 200))
        // No text drawn
    }

    do {
        _ = try await scanner.scanAndDetectLanguage(for: emptyImage)
    } catch {
        if let scannerError = error as? DocumentScannerError, case .noTextDetected = scannerError {
            print("Successfully caught 'No Text Detected' error: \(scannerError.localizedDescription)")
        } else {
            print("An unexpected error occurred during empty image scan: \(error.localizedDescription)")
        }
    }

    print("\n--- Multilingual Document Scanner Demo Finished ---")
}

// To run this in a Playground or an async context:
// Task {
//     await demonstrateMultilingualDocumentScanner()
// }
