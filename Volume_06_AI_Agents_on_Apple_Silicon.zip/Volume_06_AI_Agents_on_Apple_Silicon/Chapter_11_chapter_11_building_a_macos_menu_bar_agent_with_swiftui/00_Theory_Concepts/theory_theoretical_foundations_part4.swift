
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

@available(macOS 14.0, *)
struct InferenceParameters: Sendable { // Structs are Sendable by default if their members are Sendable
    let temperature: Double
    let topK: Int
    let maxTokens: Int
    let modelIdentifier: String
}

@available(macOS 14.0, *)
struct ConversationTurn: Sendable, Identifiable { // Example of a Sendable struct
    let id = UUID()
    let speaker: String
    let text: String
    let timestamp: Date
}

// An actor method returning a Sendable type
extension LLMAgent {
    func getCurrentConversation() async -> [ConversationTurn] {
        // Assuming ConversationTurn is Sendable, it can be returned safely.
        // This is a simplified example; actual implementation would map history to ConversationTurn.
        return conversationHistory.map {
            ConversationTurn(speaker: $0.hasPrefix("User:") ? "User" : "AI",
                             text: $0,
                             timestamp: Date())
        }
    }
}
