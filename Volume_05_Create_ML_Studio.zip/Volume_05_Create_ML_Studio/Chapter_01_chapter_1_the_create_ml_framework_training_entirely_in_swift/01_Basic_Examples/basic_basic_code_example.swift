
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import CreateML
import Foundation

// Ensure this code is run on a platform that supports Create ML.
// Create ML is available on macOS for training, and the resulting models
// can be used on iOS/macOS/watchOS/tvOS.
// For simplicity, this example assumes a macOS environment for training,
// but the principles apply to any Swift environment where Create ML is available.

/// A utility class responsible for managing and training a custom plant image classifier.
@available(macOS 10.15, *) // Create ML is available from macOS 10.15
class PlantClassifierTrainer {

    // MARK: - Data Setup (Conceptual)
    // In a real app, these URLs would point to actual directories containing your images.
    // For this example, we'll use placeholder URLs and assume the data structure.
    //
    // Data Structure for Create ML Image Classifier:
    //
    // - TrainingData/
    //   - Rose/
    //     - rose_01.jpg
    //     - rose_02.jpg
    //   - Tulip/
    //     - tulip_01.jpg
    //     - tulip_02.jpg
    //   - Orchid/
    //     - orchid_01.jpg
    //     - orchid_02.jpg
    //
    // - ValidationData/
    //   - Rose/
    //     - rose_val_01.jpg
    //   - Tulip/
    //     - tulip_val_01.jpg
    //   - Orchid/
    //     - orchid_val_01.jpg
    //
    /// The URL pointing to the directory containing the training image data.
    /// Each sub-directory within this URL represents a distinct class label.
    private var trainingDataURL: URL {
        // In a real app, this might be fetched from a user-selected folder
        // or a bundled resource. For demonstration, we use a mock path.
        // You would replace "/path/to/your/TrainingData" with the actual path.
        // For local testing, ensure this directory exists and contains labeled subdirectories.
        URL(fileURLWithPath: "/tmp/PlantClassifierData/TrainingData")
    }

    /// The URL pointing to the directory containing the validation image data.
    /// This data is used to evaluate the model's performance on unseen data.
    private var validationDataURL: URL {
        // Replace "/path/to/your/ValidationData" with the actual path.
        URL(fileURLWithPath: "/tmp/PlantClassifierData/ValidationData")
    }

    /// The URL where the trained `.mlmodel` file will be saved.
    private var outputModelURL: URL {
        // The model will be saved to the user's Documents directory or a temporary directory.
        // For this example, we'll save it to a temporary location.
        URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("PlantClassifier.mlmodel")
    }

    // MARK: - Training Process

    /// Initiates the training process for the plant image classifier.
    /// - Throws: An error if data loading or training fails.
    /// - Returns: The URL of the saved `.mlmodel` file.
    func trainPlantClassifier() async throws -> URL {
        print("Starting plant classifier training...")

        // 1. Load Training Data
        // Create ML expects image classification data organized into subdirectories,
        // where each subdirectory name is the label for the images within it.
        print("Loading training data from: \(trainingDataURL.path)")
        let trainingData = try MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)
        print("Successfully loaded \(trainingData.count) training images.")

        // 2. Load Validation Data
        // Validation data is crucial for evaluating the model's performance
        // on data it hasn't seen during training, helping to detect overfitting.
        print("Loading validation data from: \(validationDataURL.path)")
        let validationData = try MLImageClassifier.DataSource.labeledDirectories(at: validationDataURL)
        print("Successfully loaded \(validationData.count) validation images.")

        // 3. Initialize and Train the Model
        // This is the core step where Create ML builds and trains the image classifier.
        // The training process involves feature extraction and then training a classifier
        // (often a transfer learning approach on a pre-trained neural network like ResNet).
        print("Initializing and training MLImageClassifier...")
        let classifier = try MLImageClassifier(trainingData: trainingData)
        print("MLImageClassifier training complete.")

        // 4. Evaluate the Model
        // After training, it's important to evaluate how well the model performs.
        // The evaluation provides metrics like accuracy, precision, and recall.
        print("Evaluating the trained model on validation data...")
        let evaluationMetrics = classifier.evaluation(on: validationData)
        print("Model Evaluation Results:")
        print("  Validation Accuracy: \(String(format: "%.2f%%", evaluationMetrics.accuracyError * 100)) (error rate)")
        print("  Validation Precision: \(evaluationMetrics.precisionRecall.precision)")
        print("  Validation Recall: \(evaluationMetrics.precisionRecall.recall)")
        // Create ML's accuracyError is 1 - accuracy. So, (1 - accuracyError) is the accuracy.
        print("  Calculated Accuracy: \(String(format: "%.2f%%", (1 - evaluationMetrics.accuracyError) * 100))")


        // 5. Save the Trained Model
        // The trained model is saved as an .mlmodel file, which can then be
        // integrated into your Xcode project and used for predictions.
        print("Saving the trained model to: \(outputModelURL.path)")
        try classifier.write(to: outputModelURL)
        print("Model successfully saved!")

        return outputModelURL
    }
}

// MARK: - Example Usage

// This is how you would trigger the training process, for instance,
// from a button tap in your app's UI or a command-line tool.
@main
@available(macOS 10.15, *)
struct PlantIdentifierApp {
    static func main() async {
        let trainer = PlantClassifierTrainer()

        // IMPORTANT: For this example to run, you *must* create the following directory structure
        // and place some dummy images inside.
        //
        // Example setup for /tmp/PlantClassifierData:
        //
        // /tmp/PlantClassifierData/
        // ├── TrainingData/
        // │   ├── Rose/
        // │   │   ├── rose1.jpg
        // │   │   └── rose2.jpg
        // │   ├── Tulip/
        // │   │   ├── tulip1.jpg
        // │   │   └── tulip2.jpg
        // │   └── Orchid/
        // │       ├── orchid1.jpg
        // │       └── orchid2.jpg
        // └── ValidationData/
        //     ├── Rose/
        //     │   └── rose_val1.jpg
        //     ├── Tulip/
        //     │   └── tulip_val1.jpg
        //     └── Orchid/
        //         └── orchid_val1.jpg
        //
        // You can use any small JPG/PNG images for testing.
        // If these directories are empty or don't exist, the `labeledDirectories` call will throw an error.

        do {
            let modelPath = try await trainer.trainPlantClassifier()
            print("\nTraining complete! Model saved at: \(modelPath.path)")

            // You can now load and use this model in your app for predictions.
            // Example of loading the model (requires the generated model file):
            // let compiledModelURL = try await MLModel.compileModel(at: modelPath)
            // let loadedModel = try MLModel(contentsOf: compiledModelURL)
            // print("Model loaded for prediction: \(loadedModel.modelDescription.classLabels ?? ["No Labels"])")

        } catch {
            print("\nError during training: \(error.localizedDescription)")
            if let mlError = error as? MLCoreError {
                print("MLCore Error Code: \(mlError.errorCode)")
                print("MLCore Error Domain: \(mlError.errorDomain)")
            }
            print("Please ensure your training and validation data directories exist and contain images organized into labeled subdirectories.")
        }
    }
}
