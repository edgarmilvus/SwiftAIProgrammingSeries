
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import ARKit
import RealityKit
import SwiftUI
import Observation

enum PinState {
    case relocalizing
    case active
    case lost
}

@Observable
class SpatialPinManager {
    static let shared = SpatialPinManager()
    
    var currentPins: [UUID: PinConfiguration] = [:]
    var globalState: PinState = .relocalizing
    
    private var arKitSession: ARKitSession?
    private var worldTracking: WorldTrackingProvider?

    func startSession() async throws {
        arKitSession = ARKitSession()
        worldTracking = WorldTrackingProvider()
        try await arKitSession?.run([worldTracking!])
        
        // Monitor session state
        Task {
            for await update in worldTracking!.anchorUpdates {
                await handleAnchorUpdate(update)
            }
        }
    }

    @MainActor
    private func handleAnchorUpdate(_ update: ARKitAnchor) {
        // If we see anchors that match our stored IDs, we transition from relocalizing to active
        if currentPins.keys.contains(update.identifier) {
            self.globalState = .active
        }
    }

    func pinUI(at transform: simd_float4x4, type: String) async throws {
        guard let worldTracking = worldTracking else { return }
        
        let anchor = try await worldTracking.createAnchor(at: transform)
        let config = PinConfiguration(type: type, offset: [0, 0.5, 0]) // Offset above surface
        currentPins[anchor.identifier] = config
        
        await attachComplexUI(to: anchor, config: config)
    }

    @MainActor
    private func attachComplexUI(to anchor: ARKitAnchor, config: PinConfiguration) {
        // In visionOS 2.0, this would use ViewAttachmentEntity
        // Here we simulate a complex hierarchy
        let rootEntity = Entity()
        let panel = ModelEntity(mesh: .generatePlane(width: 0.3, height: 0.2), materials: [SimpleMaterial(color: .darkGray, isMetallic: false)])
        
        rootEntity.addChild(panel)
        let anchorEntity = AnchorEntity(worldAnchor: anchor)
        anchorEntity.addChild(rootEntity)
        
        // Apply the offset from the configuration
        rootEntity.position = config.offset
        
        // Add to scene (Implementation detail)
    }
    
    func rePin(existingID: UUID, newTransform: simd_float4x4) async throws {
        // 1. Remove old anchor
        // 2. Create new anchor
        // 3. Update currentPins dictionary
    }
}

struct PinConfiguration: Codable {
    let type: String
    let offset: SIMD3<Float>
}
