
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

// Package.swift
// This file is illustrative; the provided code does not require custom SPM dependencies.
// It uses built-in Apple frameworks like Foundation and CryptoKit.

// swift-tools-version: 5.10
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "LocalAIAppModels",
    platforms: [
        .macOS(.v14), // Minimum macOS version for @available(macOS 14.0, ...)
        .iOS(.v18)    // Minimum iOS version for @available(iOS 18.0, ...)
    ],
    products: [
        // Products define the executables and libraries a package produces, making them visible to other packages.
        .library(
            name: "LocalAIAppModels",
            targets: ["LocalAIAppModels"]),
    ],
    dependencies: [
        // Example: If we needed a specific external crypto library not provided by CryptoKit
        // .package(url: "https://github.com/apple/swift-crypto.git", from: "2.0.0"),
        // Example: If we used a third-party networking library
        // .package(url: "https://github.com/Alamofire/Alamofire.git", .upToNextMajor(from: "5.8.1"))
    ],
    targets: [
        // Targets are the basic building blocks of a package, defining a module or a test suite.
        // Targets can depend on other targets in this package, and on products in packages this package depends on.
        .target(
            name: "LocalAIAppModels",
            dependencies: [
                // If external dependencies were added above, they would be listed here.
                // .product(name: "Crypto", package: "swift-crypto"),
                // .product(name: "Alamofire", package: "Alamofire")
            ]),
        .testTarget(
            name: "LocalAIAppModelsTests",
            dependencies: ["LocalAIAppModels"]),
    ]
)
