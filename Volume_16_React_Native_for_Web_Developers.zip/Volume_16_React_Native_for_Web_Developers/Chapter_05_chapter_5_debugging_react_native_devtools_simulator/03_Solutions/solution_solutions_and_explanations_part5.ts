/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Terminal Commands (Diagnostic & Reset)
// ------------------------------------------
// To reset Metro cache and force a clean rebuild/reconnection without killing the process:
// This clears the bundler's cached state which often resolves desynchronization.
npx expo start -c

// If the above fails, manually kill the Metro process and restart:
// (Find PID: lsof -i :8081)
// (Kill: kill -9 <PID>)

// 2. The "Nuclear Option" (Android Debug Bridge - adb)
// ----------------------------------------------------
// If the Android Emulator is hanging, the port forwarding (8081 -> device) might be stale.
// Check current forwarding:
adb forward --list

// Remove the specific forwarding rule (if it exists):
adb forward --remove tcp:8081

// Re-establish the forwarding to allow the browser/Metro to talk to the emulator:
adb reverse tcp:8081 tcp:8081
// Note: 'adb reverse' is usually preferred for Expo, mapping device port to host.

// 3. Code Fix: Heartbeat Mechanism
// ---------------------------------
import { useEffect } from 'react';
import { logUniversal } from '../utils/UniversalLogger';

export const useBridgeHeartbeat = () => {
  useEffect(() => {
    // Only run in development
    if (process.env.NODE_ENV !== 'development') return;

    const intervalId = setInterval(() => {
      const startTime = Date.now();
      
      // A dummy synchronous heavy task or a microtask to check JS thread responsiveness
      // If the JS thread is blocked by the bridge waiting, this might not fire immediately.
      Promise.resolve().then(() => {
        const latency = Date.now() - startTime;
        
        if (latency > 1000) { // Threshold of 1 second
          logUniversal('CRITICAL', {
            event: 'Bridge Hang Detected',
            latency: `${latency}ms`,
            advice: 'JS thread is unresponsive. Check Metro connection or Hermes Inspector.'
          });
        }
      });

    }, 5000); // Check every 5 seconds

    return () => clearInterval(intervalId);
  }, []);
};

// Usage: Call this hook in your root App.tsx or a debug component.
