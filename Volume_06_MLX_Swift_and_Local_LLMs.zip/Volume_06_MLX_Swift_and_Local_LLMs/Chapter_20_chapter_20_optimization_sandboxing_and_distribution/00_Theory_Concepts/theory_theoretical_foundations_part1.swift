
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Example: A simple loss function
func myLossFunction(x: MLXArray, y: MLXArray) -> MLXArray {
    let prediction = x * 2.0 // Simple model: predict 2x
    return MLX.mean(MLX.square(prediction - y)) // Mean Squared Error
}

// Get a function that computes both the loss and its gradient
let lossAndGradient = MLX.valueAndGradient(myLossFunction)

// Example inputs
let inputX = MLXArray(0.5)
let targetY = MLXArray(1.2)

// Compute loss and gradient
let (loss, grad) = lossAndGradient(inputX, targetY)

// Force evaluation to get concrete values
print("Loss: \(loss.eval().item(Float.self))") // Output: Loss: 0.04
print("Gradient: \(grad.eval().item(Float.self))") // Output: Gradient: -0.8
