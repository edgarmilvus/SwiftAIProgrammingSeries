
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Observation // For @Observable

@available(iOS 18.0, *)
@Observable
class VoiceCommandViewModel {
    var currentTranscription: String = "Listening..."
    var recognizedCommand: String?
    var isListening: Bool = false
    var errorMessage: String?

    private let speechRecognizerManager = SpeechRecognizerManager()
    private let nlProcessorActor: NLProcessorActor // Initialized with a custom NLModel
    private var recognitionTask: Task<Void, Never>?

    init(intentModel: NLModel) {
        self.nlProcessorActor = NLProcessorActor(intentModel: intentModel)
    }

    func startVoiceCommandSession() {
        guard !isListening else { return }
        isListening = true
        currentTranscription = "Listening..."
        recognizedCommand = nil
        errorMessage = nil

        recognitionTask = Task {
            do {
                for await transcription in try await speechRecognizerManager.startRecognition() {
                    await MainActor.run {
                        self.currentTranscription = transcription
                    }
                    // Process transcription with NLP actor
                    let (intent, entities) = await nlProcessorActor.processCommand(transcription)
                    if let intent {
                        await MainActor.run {
                            self.recognizedCommand = "Intent: \(intent), Entities: \(entities)"
                        }
                        // Trigger command execution
                        // await CommandExecutorActor.execute(intent: intent, entities: entities)
                    }
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "Recognition error: \(error.localizedDescription)"
                    self.isListening = false
                }
            }
        }
    }

    func stopVoiceCommandSession() {
        isListening = false
        recognitionTask?.cancel()
        recognitionTask = nil
        // Ensure speechRecognizerManager also stops
        Task { await speechRecognizerManager.stopRecognition() }
    }
}

// In a SwiftUI View:
/*
@available(iOS 18.0, *)
struct VoiceCommandView: View {
    @State private var viewModel: VoiceCommandViewModel

    init(intentModel: NLModel) {
        _viewModel = State(initialValue: VoiceCommandViewModel(intentModel: intentModel))
    }

    var body: some View {
        VStack {
            Text(viewModel.currentTranscription)
                .font(.title2)
                .padding()

            if let command = viewModel.recognizedCommand {
                Text("Command: \(command)")
                    .font(.headline)
                    .foregroundColor(.green)
            }

            if let error = viewModel.errorMessage {
                Text(error)
                    .foregroundColor(.red)
            }

            Button(viewModel.isListening ? "Stop Listening" : "Start Listening") {
                if viewModel.isListening {
                    viewModel.stopVoiceCommandSession()
                } else {
                    viewModel.startVoiceCommandSession()
                }
            }
            .buttonStyle(.borderedProminent)
            .padding()
        }
    }
}
*/
