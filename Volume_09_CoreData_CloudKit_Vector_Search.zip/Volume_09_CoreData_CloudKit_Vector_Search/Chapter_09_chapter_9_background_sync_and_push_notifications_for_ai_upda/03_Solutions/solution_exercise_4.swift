
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CloudKit
import CoreML
import OSLog

/// The central orchestrator for proactive intelligence.
/// Uses an actor to ensure only one pipeline runs at a time.
actor BackgroundIntelligenceOrchestrator {
    private let logger = Logger(subsystem: "com.lumina.notes", category: "Orchestrator")
    private let database = CKContainer.default().privateCloudDatabase
    private let zoneID = CKRecordZone.ID(zoneName: "NotesZone", ownerName: CKCurrentUserDefaultName)
    
    private var isProcessing = false
    
    // In a real app, this would be a shared singleton managed by the App lifecycle
    static let shared = BackgroundIntelligenceOrchestrator()

    /// Entry point triggered by AppDelegate's didReceiveRemoteNotification
    func processIncomingNote(recordID: CKRecord.ID) async {
        guard !isProcessing else {
            logger.info("Pipeline already running. Skipping trigger.")
            return
        }
        
        isProcessing = true
        defer { isProcessing = false }
        
        do {
            // Step B: Fetch specific record
            let record = try await fetchRecord(recordID: recordID)
            
            // Step C: Persist to Core Data
            // We save with 'isPendingIndexing = true' to handle potential failures in Step D/E
            try await saveToCoreData(record: record)
            
            // Step D: Inference (CPU/GPU Intensive)
            let embedding = try await generateEmbedding(for: record["content"] as? String ?? "")
            
            // Step E: Indexing
            try await updateVectorIndex(id: record.recordID.recordName, vector: embedding)
            
            // Final Step: Clear the pending flag
            try await markAsIndexed(recordID: record.recordID.recordName)
            
            logger.info("Proactive Intelligence: Successfully processed note \(record.recordID.recordName)")
            
        } catch {
            logger.error("Pipeline failed: \(error.localizedDescription)")
            // The 'isPendingIndexing' flag in Core Data ensures a BGProcessingTask 
            // can clean this up later.
        }
    }

    // MARK: - Pipeline Steps

    private func fetchRecord(recordID: CKRecord.ID) async throws -> CKRecord {
        try await database.record(for: recordID)
    }

    private func saveToCoreData(record: CKRecord) async throws {
        // Logic to save to Core Data with 'isPendingIndexing = true'
        print("Step C: Saved to Core Data (Pending Indexing)")
    }

    private func generateEmbedding(for text: String) async throws -> [Float] {
        // In a real app, load the CoreML model here.
        // To manage model lifecycle, use a static property or a dedicated actor.
        return try await Task.detached(priority: .userInitiated) {
            // Simulate CoreML Inference
            print("Step D: Running CoreML Inference...")
            try await Task.sleep(for: .seconds(1)) 
            return [0.1, 0.2, 0.3, 0.4] // Mock vector
        }.value
    }

    private func updateVectorIndex(id: String, vector: [Float]) async throws {
        print("Step E: Vector Index Updated for \(id)")
    }
    
    private func markAsIndexed(recordID: String) async throws {
        print("Final: Flag cleared for \(recordID)")
    }
}

// MARK: - Integration Example

extension AppDelegate {
    // This connects the Exercise 1 trigger to the Exercise 4 Orchestrator
    func handleSilentPush(recordID: CKRecord.ID) {
        Task {
            await BackgroundIntelligenceOrchestrator.shared.processIncomingNote(recordID: recordID)
        }
    }
}
