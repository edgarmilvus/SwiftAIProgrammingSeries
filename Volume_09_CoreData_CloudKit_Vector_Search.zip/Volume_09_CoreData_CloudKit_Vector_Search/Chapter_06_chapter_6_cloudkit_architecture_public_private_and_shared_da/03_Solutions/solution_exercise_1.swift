
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CloudKit

@available(iOS 18.0, *)
protocol CloudKitRecordConvertible {
    func toCKRecord() -> CKRecord
    init?(from ckRecord: CKRecord)
}

@available(iOS 18.0, *)
enum CloudKitError: Error {
    case notAuthenticated
    case recordConversionFailed
    case unknown(Error)
}

@available(iOS 18.0, *)
enum DatabaseScope {
    case `private`
    case `public`
}

@available(iOS 18.0, *)
actor CloudKitManager {
    private let container: CKContainer
    
    init(containerIdentifier: String) {
        self.container = CKContainer(identifier: containerIdentifier)
    }
    
    private func database(for scope: DatabaseScope) -> CKDatabase {
        switch scope {
        case .private: return container.privateCloudDatabase
        case .public: return container.publicCloudDatabase
        }
    }
    
    func save<T: CloudKitRecordConvertible>(_ record: T, in scope: DatabaseScope) async throws {
        let db = database(for: scope)
        let ckRecord = record.toCKRecord()
        
        do {
            try await db.save(ckRecord)
        } catch let error as CKError {
            if error.code == .notAuthenticated {
                throw CloudKitError.notAuthenticated
            }
            throw CloudKitError.unknown(error)
        } catch {
            throw CloudKitError.unknown(error)
        }
    }
    
    func fetchRecords<T: CloudKitRecordConvertible>(ofType type: T.Type, in scope: DatabaseScope) async throws -> [T] {
        let db = database(for: scope)
        // Note: In a real app, you'd pass a CKQuery or Predicate. 
        // Here we use a generic query for demonstration.
        let query = CKQuery(recordType: String(describing: type), predicate: NSPredicate(value: true))
        
        do {
            let (results, _) = try await db.records(matching: query)
            
            return try results.compactMap { (_, result) in
                switch result {
                case .success(let record):
                    guard let converted = T(from: record) else {
                        throw CloudKitError.recordConversionFailed
                    }
                    return converted
                case .failure(let error):
                    throw error
                }
            }
        } catch let error as CKError {
            if error.code == .notAuthenticated {
                throw CloudKitError.notAuthenticated
            }
            throw CloudKitError.unknown(error)
        } catch {
            throw CloudKitError.unknown(error)
        }
    }
}
