
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
/// An error type for LLM interactions.
enum LLMServiceError: Error, LocalizedError {
    case inferenceFailed(String)
    case noOutputReceived
    
    var errorDescription: String? {
        switch self {
        case .inferenceFailed(let message): return "LLM inference failed: \(message)"
        case .noOutputReceived: return "LLM returned no output."
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
/// A mock service to simulate interaction with a local LLM.
/// In a real app, this would use OllamaKit or llama.cpp to send prompts and get responses.
class MockLLMService {
    /// Simulates sending a transcript to the LLM and receiving JSON output.
    /// - Parameter transcript: The meeting transcript to process.
    /// - Returns: A `String` containing the LLM's JSON response.
    /// - Throws: `LLMServiceError` if the mock inference fails.
    func getStructuredSummary(for transcript: String) async throws -> String {
        // Simulate network/inference delay
        try await Task.sleep(for: .milliseconds(500))
        
        // Simulate different LLM outputs based on transcript content or a random factor
        if transcript.contains("error simulation") {
            // Simulate an LLM returning non-JSON or malformed JSON
            return "This is not JSON. The LLM got confused and returned plain text."
        } else if transcript.contains("malformed date") {
            // Simulate a common LLM issue: date format variations or missing keys.
            // Here, 'dueDate' is in a non-standard format, and 'assignedTo' is 'assignee'.
            return """
            {
              "meetingTitle": "Q4 Planning Session",
              "summary": "Reviewed Q3 performance and outlined Q4 objectives.",
              "actionItems": [
                {
                  "description": "Finalize Q4 budget",
                  "assignee": "Charlie",
                  "dueDate": "Oct 25, 2024" 
                },
                {
                  "description": "Schedule team offsite",
                  "assignedTo": "Diana",
                  "dueDate": "2024-11-01"
                }
              ],
              "decisions": [
                {
                  "topic": "Increase marketing spend by 15%",
                  "decisionMaker": "CEO",
                  "dateMade": "2024-09-30"
                }
              ],
              "followUpRequired": true
            }
            """
        } else if transcript.contains("missing key title") {
            // Simulate a missing 'meetingTitle' key, but with 'title' instead.
            return """
            {
              "title": "Weekly Standup",
              "summary": "Discussed ongoing tasks and blockers.",
              "actionItems": [
                {
                  "description": "Update project board",
                  "assignedTo": "Eve",
                  "dueDate": "2024-10-02"
                }
              ],
              "decisions": [],
              "followUpRequired": false
            }
            """
        } else {
            // Simulate a perfectly valid LLM output
            return """
            {
              "meetingTitle": "Q3 Product Strategy Review",
              "summary": "Reviewed Q3 performance and set priorities for Q4 product development. Key focus areas identified include feature X and Y.",
              "actionItems": [
                {
                  "description": "Draft Q4 marketing plan for feature X",
                  "assignedTo": "Alice",
                  "dueDate": "2024-10-15"
                },
                {
                  "description": "Research competitor Y features",
                  "assignedTo": "Bob",
                  "dueDate": "2024-10-10"
                }
              ],
              "decisions": [
                {
                  "topic": "Prioritize feature Y development for Q4",
                  "decisionMaker": "CTO",
                  "dateMade": "2024-09-28"
                },
                {
                  "topic": "Allocate additional budget for marketing",
                  "decisionMaker": "CFO",
                  "dateMade": "2024-09-28"
                }
              ],
              "followUpRequired": true
            }
            """
        }
    }
}
