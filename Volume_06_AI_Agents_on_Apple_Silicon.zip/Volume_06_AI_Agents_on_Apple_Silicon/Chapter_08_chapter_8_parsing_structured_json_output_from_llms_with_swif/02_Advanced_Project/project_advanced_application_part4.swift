
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
/// An error type specific to the meeting summary processing.
enum MeetingProcessorError: Error, LocalizedError {
    case invalidJSON(String)
    case decodingFailed(Error)
    case llmError(LLMServiceError)
    
    var errorDescription: String? {
        switch self {
        case .invalidJSON(let message): return "LLM output was not valid JSON: \(message)"
        case .decodingFailed(let error): return "Failed to decode meeting summary: \(error.localizedDescription)"
        case .llmError(let llmError): return llmError.localizedDescription
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
/// Processes meeting transcripts to extract structured summaries using an LLM and robust JSON parsing.
class MeetingAssistantProcessor {
    private let llmService: MockLLMService
    private let jsonDecoder: JSONDecoder

    /// Initializes the processor with a mock LLM service and configures the JSONDecoder.
    init(llmService: MockLLMService) {
        self.llmService = llmService
        self.jsonDecoder = JSONDecoder()
        
        // --- Advanced JSONDecoder Configuration for Robustness ---
        
        // 1. Key Decoding Strategy:
        //    .convertFromSnakeCase: Converts snake_case JSON keys to camelCase Swift properties.
        //    Our current JSON uses camelCase, but this is a good default for LLMs that might output snake_case.
        jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase
        
        // 2. Date Decoding Strategy:
        //    This is crucial for handling varied date formats from LLMs.
        //    LLMs might output ISO 8601, 'YYYY-MM-DD', 'Month Day, Year', etc.
        //    We define a custom strategy that tries multiple common formats.
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX") // Ensures consistent parsing
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0) // UTC for consistency

        jsonDecoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let dateString = try container.decode(String.self)

            // Try ISO 8601 first (e.g., "2024-10-15T10:00:00Z")
            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
            if let date = dateFormatter.date(from: dateString) {
                return date
            }
            
            // Try "YYYY-MM-DD" (common for just dates)
            dateFormatter.dateFormat = "yyyy-MM-dd"
            if let date = dateFormatter.date(from: dateString) {
                return date
            }

            // Try "MMM dd, yyyy" (e.g., "Oct 25, 2024")
            dateFormatter.dateFormat = "MMM dd, yyyy"
            if let date = dateFormatter.date(from: dateString) {
                return date
            }
            
            // Try "MM/dd/yyyy"
            dateFormatter.dateFormat = "MM/dd/yyyy"
            if let date = dateFormatter.date(from: dateString) {
                return date
            }

            // If none of the above formats match, throw an error.
            throw DecodingError.dataCorruptedError(in: container,
                                                   debugDescription: "Cannot decode date string \(dateString) to Date.")
        }
    }

    /// Processes a raw meeting transcript to generate a structured `MeetingSummary`.
    /// - Parameter transcript: The raw text transcript of the meeting.
    /// - Returns: A `MeetingSummary` object if parsing is successful.
    /// - Throws: `MeetingProcessorError` if LLM interaction fails, JSON is invalid, or decoding fails.
    func processMeetingTranscript(transcript: String) async throws -> MeetingSummary {
        print("Processing transcript for summary...")
        
        let llmOutput: String
        do {
            // 1. Interact with the LLM to get raw JSON output.
            // This is where OllamaKit or llama.cpp.swift would be used in a real app.
            llmOutput = try await llmService.getStructuredSummary(for: transcript)
            print("LLM Raw Output:\n\(llmOutput)\n")
        } catch let llmError as LLMServiceError {
            throw MeetingProcessorError.llmError(llmError)
        } catch {
            throw MeetingProcessorError.llmError(.inferenceFailed("Unknown error from LLM service: \(error.localizedDescription)"))
        }

        // 2. Convert the LLM's string output to Data for JSONDecoder.
        guard let jsonData = llmOutput.data(using: .utf8) else {
            throw MeetingProcessorError.invalidJSON("Could not convert LLM output string to Data.")
        }

        // 3. Attempt to decode the JSON data into our Codable `MeetingSummary` model.
        // The `do-catch` block handles potential `DecodingError`s.
        do {
            let summary = try jsonDecoder.decode(MeetingSummary.self, from: jsonData)
            print("Successfully decoded Meeting Summary.")
            return summary
        } catch let decodingError as DecodingError {
            // Provide specific details for decoding errors.
            print("Decoding failed: \(decodingError)")
            throw MeetingProcessorError.decodingFailed(decodingError)
        } catch {
            // Catch any other unexpected errors during decoding.
            print("An unexpected error occurred during JSON decoding: \(error)")
            throw MeetingProcessorError.decodingFailed(error)
        }
    }
}
