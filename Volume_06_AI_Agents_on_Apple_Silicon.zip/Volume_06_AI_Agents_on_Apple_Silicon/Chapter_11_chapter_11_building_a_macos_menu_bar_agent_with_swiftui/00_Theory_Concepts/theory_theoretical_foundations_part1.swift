
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(macOS 14.0, *)
actor LLMInferenceEngine {
    // Represents the underlying llama.cpp or Ollama client
    private var modelPath: String?
    private var isModelLoaded: Bool = false

    func loadModel(at path: String) async throws {
        // Simulate a long-running model loading process
        print("Loading model from \(path)...")
        try await Task.sleep(for: .seconds(5)) // Simulate I/O and computation
        self.modelPath = path
        self.isModelLoaded = true
        print("Model loaded.")
    }

    func generateResponse(prompt: String) async throws -> String {
        guard isModelLoaded else {
            throw LLMError.modelNotLoaded
        }
        print("Generating response for: '\(prompt)'")
        // Simulate inference
        try await Task.sleep(for: .seconds(3)) // Simulate computation
        return "AI response to '\(prompt)'"
    }

    func streamResponse(prompt: String) async throws -> AsyncStream<String> {
        guard isModelLoaded else {
            throw LLMError.modelNotLoaded
        }
        print("Starting streaming for: '\(prompt)'")
        return AsyncStream { continuation in
            Task {
                let words = "Streaming AI response for \(prompt) example."
                    .components(separatedBy: " ")
                for word in words {
                    try await Task.sleep(for: .milliseconds(200)) // Simulate token generation
                    continuation.yield(word + " ")
                }
                continuation.finish()
                print("Streaming finished.")
            }
        }
    }
}

enum LLMError: Error {
    case modelNotLoaded
    case inferenceFailed(String)
}

// Example usage in a SwiftUI view model (simplified)
@available(macOS 14.0, *)
class ChatViewModel: ObservableObject { // Or better, use @Observable directly on the model
    @Published var currentResponse: String = ""
    @Published var isLoading: Bool = false
    private let engine = LLMInferenceEngine() // Actor instance

    func sendPrompt(_ prompt: String) async {
        await MainActor.run {
            isLoading = true
            currentResponse = ""
        }
        do {
            // Load model if not already loaded (simplified)
            if await !engine.isModelLoaded {
                try await engine.loadModel(at: "/path/to/my/llm.gguf")
            }

            // Stream response
            for await token in try await engine.streamResponse(prompt: prompt) {
                await MainActor.run {
                    self.currentResponse += token
                }
            }
        } catch {
            await MainActor.run {
                self.currentResponse = "Error: \(error.localizedDescription)"
            }
        }
        await MainActor.run {
            isLoading = false
        }
    }
}
