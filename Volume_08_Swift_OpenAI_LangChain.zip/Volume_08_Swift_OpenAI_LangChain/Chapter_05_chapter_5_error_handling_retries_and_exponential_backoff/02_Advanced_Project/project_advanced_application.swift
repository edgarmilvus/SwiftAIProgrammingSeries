
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation

// MARK: - Package Dependencies
/*
 // Package.swift equivalent
 dependencies: [
    .package(url: "https://github.com/openai/openai-swift", from: "1.0.0")
 ]
*/

/// Represents the specific categories of errors encountered when interacting with LLM APIs.
/// Categorization is crucial to decide whether to retry or fail immediately.
enum LLMError: Error, Sendable {
    case transient(reason: String, retryAfter: TimeInterval?) // 429, 500, 503
    case permanent(reason: String)                             // 400, 401, 404
    case contextExceeded(reason: String)                       // Token limit reached
    case circuitBreakerOpen                                    // Failing fast
    case networkFailure(Error)
}

/// Defines the strategy for retrying failed requests.
struct RetryPolicy: Sendable {
    let maxAttempts: Int
    let baseDelay: TimeInterval
    let maxDelay: TimeInterval
    
    static let `default` = RetryPolicy(
        maxAttempts: 5,
        baseDelay: 1.0,
        maxDelay: 30.0
    )
}

/// The CircuitBreaker actor manages the state of the connection to the LLM provider.
/// Using an `actor` ensures that state transitions (Closed -> Open) are atomic
/// across multiple concurrent LLM requests.
@available(iOS 18.0, *)
actor CircuitBreaker {
    enum State: Sendable {
        case closed
        case open(expiry: Date)
        case halfOpen
    }
    
    private var state: State = .closed
    private var failureCount: Int = 0
    private let threshold: Int
    private let resetTimeout: TimeInterval
    
    init(threshold: Int = 3, resetTimeout: TimeInterval = 60) {
        self.threshold = threshold
        self.resetTimeout = resetTimeout
    }
    
    /// Determines if a request is allowed to proceed.
    func canProceed() -> Bool {
        switch state {
        case .closed:
            return true
        case .open(let expiry):
            if Date() > expiry {
                state = .halfOpen
                return true
            }
            return false
        case .halfOpen:
            // In half-open, we only allow one probe. 
            // For simplicity, we treat it as "true" but the first failure will re-open.
            return true
        }
    }
    
    /// Reports a success, resetting the failure count and closing the circuit.
    func reportSuccess() {
        state = .closed
        failureCount = 0
    }
    
    /// Reports a failure, potentially tripping the circuit.
    func reportFailure() {
        failureCount += 1
        if failureCount >= threshold {
            state = .open(expiry: Date().addingTimeInterval(resetTimeout))
        }
    }
}

/// The ResilienceEngine orchestrates retries, backoff, and the circuit breaker.
@available(iOS 18.0, *)
actor ResilienceEngine {
    private let circuitBreaker = CircuitBreaker()
    private let policy: RetryPolicy
    
    init(policy: RetryPolicy = .default) {
        self.policy = policy
    }
    
    /// Executes a throwing asynchronous block with built-in resilience patterns.
    /// - Parameter action: The LLM API call to perform.
    /// - Returns: The result of the action.
    func execute<T: Sendable>(
        action: @escaping @Sendable () async throws -> T
    ) async throws -> T {
        
        // 1. Check Circuit Breaker
        guard await circuitBreaker.canProceed() else {
            throw LLMError.circuitBreakerOpen
        }
        
        var currentAttempt = 0
        
        while currentAttempt < policy.maxAttempts {
            do {
                let result = try await action()
                
                // Success! Reset the circuit.
                await circuitBreaker.reportSuccess()
                return result
                
            } catch let error as LLMError {
                currentAttempt += 1
                
                switch error {
                case .transient(let reason, let retryAfter):
                    print("⚠️ Transient error: \(reason). Attempt \(currentAttempt)/\(policy.maxAttempts)")
                    
                    if currentAttempt >= policy.maxAttempts {
                        await circuitBreaker.reportFailure()
                        throw error
                    }
                    
                    try await performBackoff(attempt: currentAttempt, suggestedDelay: retryAfter)
                    
                case .permanent, .contextExceeded:
                    // Do not retry permanent errors or context errors.
                    // They require user intervention or prompt modification.
                    throw error
                    
                case .circuitBreakerOpen, .networkFailure:
                    await circuitBreaker.reportFailure()
                    throw error
                }
            } catch {
                // Handle unexpected non-LLMError types
                await circuitBreaker.reportFailure()
                throw LLMError.networkFailure(error)
            }
        }
        
        throw LLMError.permanent(reason: "Max retry attempts reached")
    }
    
    /// Implements Jittered Exponential Backoff.
    private func performBackoff(attempt: Int, suggestedDelay: TimeInterval?) async throws {
        // If the API explicitly tells us when to retry (e.g., Retry-After header), use it.
        let baseDelay = suggestedDelay ?? policy.baseDelay
        
        // Exponential formula: base * 2^(attempt-1)
        let exponentialDelay = baseDelay * pow(2.0, Double(attempt - 1))
        let cappedDelay = min(exponentialDelay, policy.maxDelay)
        
        // Full Jitter: random value between 0 and the capped exponential delay.
        // This is the most effective way to prevent the Thundering Herd.
        let jitteredDelay = Double.random(in: 0...cappedDelay)
        
        print("⏳ Backing off for \(String(format: "%.2f", jitteredDelay)) seconds...")
        
        // Use Swift Concurrency's Task.sleep, which is cancellation-aware.
        try await Task.sleep(nanoseconds: UInt64(jitteredDelay * 1_000_000_000))
    }
}

// MARK: - Real-World Application Example

/// A mock service simulating an OpenAI API client.
struct OpenAIClient {
    static func fetchChatCompletion(prompt: String) async throws -> String {
        // Simulate network/API behavior
        let random = Int.random(in: 1...10)
        
        switch random {
        case 1...2: // 20% chance of rate limiting
            throw LLMError.transient(reason: "Rate limit exceeded (429)", retryAfter: 2.0)
        case 3:     // 10% chance of server error
            throw LLMError.transient(reason: "Internal Server Error (500)", retryAfter: nil)
        case 4:     // 10% chance of permanent error
            throw LLMError.permanent(reason: "Invalid API Key (401)")
        default:    // 60% success
            return "EchoMind Response: The weather in Cupertino is sunny."
        }
    }
}

/// The main ViewModel for our AI Voice Assistant.
@available(iOS 18.0, *)
@MainActor
class VoiceAssistantViewModel: ObservableObject {
    @Published var responseText: String = ""
    @Published var isProcessing: Bool = false
    @Published var errorMessage: String?
    
    private let resilienceEngine = ResilienceEngine()
    
    func askQuestion(_ prompt: String) async {
        isProcessing = true
        errorMessage = nil
        
        do {
            // We wrap the unstable API call inside the resilience engine.
            let result = try await resilienceEngine.execute {
                try await OpenAIClient.fetchChatCompletion(prompt: prompt)
            }
            self.responseText = result
        } catch LLMError.circuitBreakerOpen {
            self.errorMessage = "Service is temporarily unavailable. Please try again in a minute."
        } catch LLMError.permanent(let reason) {
            self.errorMessage = "Critical Error: \(reason)"
        } catch {
            self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
        }
        
        isProcessing = false
    }
}
