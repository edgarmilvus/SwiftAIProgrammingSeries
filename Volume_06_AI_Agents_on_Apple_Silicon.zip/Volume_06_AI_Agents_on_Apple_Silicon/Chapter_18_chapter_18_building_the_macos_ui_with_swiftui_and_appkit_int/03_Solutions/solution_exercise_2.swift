
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import AppKit

// MARK: - 1. Design SwiftUI Preferences View

struct AppPreferencesView: View {
    @AppStorage("enableDarkMode") var enableDarkMode: Bool = false
    @AppStorage("volumeLevel") var volumeLevel: Double = 0.75
    @AppStorage("defaultAIModel") var defaultAIModel: String = "GPT-4o"

    let aiModels = ["GPT-4o", "Claude 3.5 Sonnet", "Llama 3", "Gemini 1.5 Pro"]

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Application Preferences")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.bottom, 5)

            Toggle("Enable Dark Mode", isOn: $enableDarkMode)
                .toggleStyle(.switch)

            HStack {
                Text("Volume Level:")
                Slider(value: $volumeLevel, in: 0...1, step: 0.05) {
                    Text(String(format: "%.0f%%", volumeLevel * 100))
                } minimumValueLabel: {
                    Text("0%")
                } maximumValueLabel: {
                    Text("100%")
                }
            }

            Picker("Default AI Model:", selection: $defaultAIModel) {
                ForEach(aiModels, id: \.self) { model in
                    Text(model).tag(model)
                }
            }
            .pickerStyle(.menu) // Ensure it's a menu picker for macOS

            Divider()

            Text("Settings are saved automatically.")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(minWidth: 300, idealWidth: 350, maxWidth: 400) // Constrain popover size
    }
}

// MARK: - 2 & 3. AppKit Trigger and Popover Logic

struct Exercise2View: View {
    @State private var popover: NSPopover?
    // Using a GeometryReader to get the button's frame for anchoring the AppKit popover
    @State private var buttonRect: CGRect = .zero

    var body: some View {
        VStack {
            Text("Main Application Window")
                .font(.largeTitle)
                .padding()

            Button("Show Preferences Popover") {
                showPreferencesPopover()
            }
            .background(
                // Invisible view to capture the button's frame
                GeometryReader { proxy in
                    Color.clear
                        .onAppear {
                            // Capture the global frame of the button
                            buttonRect = proxy.frame(in: .global)
                        }
                        .onChange(of: proxy.frame(in: .global)) { newRect in
                            // Update if the button's position changes (e.g., window resize)
                            buttonRect = newRect
                        }
                }
            )
            .buttonStyle(.borderedProminent)
            .padding()
        }
        .frame(minWidth: 400, minHeight: 300)
    }

    private func showPreferencesPopover() {
        // Ensure only one popover instance is managed
        if popover == nil {
            let newPopover = NSPopover()
            newPopover.behavior = .transient // Dismisses when clicking outside
            newPopover.contentViewController = NSHostingController(rootView: AppPreferencesView())
            self.popover = newPopover // Keep a strong reference
        }

        // Check if the popover is already shown; if so, dismiss it first
        if popover?.isShown == true {
            popover?.performClose(nil)
            return
        }

        // Present the popover
        if let currentWindow = NSApp.keyWindow, let contentView = currentWindow.contentView {
            // Convert the global SwiftUI frame to the window's coordinate system
            // This is crucial because NSPopover expects an NSRect relative to an NSView
            let windowRect = currentWindow.convertFromScreen(NSRect(buttonRect))
            
            // Show the popover relative to the button's position in the window's content view
            popover?.show(relativeTo: windowRect, of: contentView, preferredEdge: .maxY)
        }
    }
}

// To run this in a preview or an actual app:
// @main
// struct AppKitSwiftUIApp: App {
//     var body: some Scene {
//         WindowGroup {
//             Exercise2View()
//         }
//     }
// }
