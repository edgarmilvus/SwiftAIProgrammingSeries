
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import SwiftUI

// StreamError.swift
enum StreamError: LocalizedError, Identifiable {
    case networkInterruption
    case backendProcessingError(details: String)
    case sessionTimeout
    case unknown(Error?)

    var id: String {
        switch self {
        case .networkInterruption: return "networkInterruption"
        case .backendProcessingError(let details): return "backendProcessingError-\(details.hashValue)"
        case .sessionTimeout: return "sessionTimeout"
        case .unknown(let error): return "unknown-\(error?.localizedDescription.hashValue ?? "no-error")"
        }
    }

    var errorDescription: String? {
        switch self {
        case .networkInterruption:
            return "The network connection was interrupted during the AI response. Please check your internet."
        case .backendProcessingError(let details):
            return "The AI backend encountered an error while generating the response: \(details)"
        case .sessionTimeout:
            return "The AI session timed out. It took too long to generate a response."
        case .unknown(let error):
            return "An unknown error occurred during streaming: \(error?.localizedDescription ?? "No details available.")."
        }
    }
}

// AIResponseStreamer.swift
@available(iOS 18.0, *)
class AIResponseStreamer {
    private let predefinedResponses: [String] = [
        "Hello there! How can I assist you today?",
        "The quick brown fox jumps over the lazy dog, demonstrating agility.",
        "Artificial intelligence is transforming industries globally, enabling new possibilities.",
        "SwiftUI makes building declarative user interfaces across Apple platforms incredibly efficient.",
        "Error handling is a critical aspect of robust software development, especially in distributed systems."
    ]

    func streamResponse(for prompt: String) async throws -> AsyncThrowingStream<String, Error> {
        return AsyncThrowingStream { continuation in
            let responseText = predefinedResponses.randomElement() ?? "Default response when no specific prompt logic."
            let words = responseText.split(separator: " ").map(String.init)
            
            let errorTriggerIndex = Int.random(in: 5...min(words.count - 1, 15)) // Trigger error after 5-15 words
            let shouldError = Bool.random() // Randomly decide if an error will occur

            // Use a separate Task for the stream's production to allow the continuation to be captured
            Task {
                for (index, word) in words.enumerated() {
                    // Check for cancellation before yielding or performing work
                    if Task.isCancelled {
                        continuation.finish(throwing: CancellationError())
                        return
                    }

                    if shouldError && index == errorTriggerIndex {
                        let errorType = Int.random(in: 0...2)
                        switch errorType {
                        case 0:
                            continuation.finish(throwing: StreamError.networkInterruption)
                        case 1:
                            continuation.finish(throwing: StreamError.backendProcessingError(details: "Model inference failed internally."))
                        case 2:
                            continuation.finish(throwing: StreamError.sessionTimeout)
                        default:
                            continuation.finish(throwing: StreamError.unknown(nil))
                        }
                        return
                    }

                    continuation.yield(word + " ")
                    try? await Task.sleep(for: .milliseconds(150)) // Simulate streaming delay
                }
                continuation.finish() // Stream completed successfully
            }
        }
    }
}

// ChatView.swift
@available(iOS 18.0, *)
struct ChatView: View {
    @State private var currentResponse: String = ""
    @State private var streamError: StreamError?
    @State private var isStreaming: Bool = false
    @State private var currentStreamingTask: Task<Void, Never>? // Holds the task that consumes the stream

    private let streamer = AIResponseStreamer()

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("AI Assistant Response:")
                .font(.headline)

            ScrollView {
                Text(currentResponse)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(10)
            }
            .frame(height: 200)
            .border(Color.gray.opacity(0.3), width: 1)

            if isStreaming {
                ProgressView()
                    .padding(.vertical)
            }

            if let error = streamError {
                Text("Error: \(error.localizedDescription)")
                    .foregroundColor(.red)
                    .font(.subheadline)
                    .padding(.vertical, 5)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(Color.red.opacity(0.1))
                    .cornerRadius(5)
            }

            HStack {
                Button(action: startNewSession) {
                    Label("Start New Session", systemImage: "arrow.clockwise.circle.fill")
                }
                .buttonStyle(.borderedProminent)
                .disabled(isStreaming)

                if isStreaming {
                    Button(action: cancelStreaming) {
                        Label("Stop Streaming", systemImage: "stop.circle.fill")
                    }
                    .buttonStyle(.bordered)
                    .tint(.red)
                }
            }
        }
        .padding()
        .navigationTitle("AI Chat Stream")
        .onDisappear {
            // Ensure the streaming task is cancelled if the view is dismissed
            currentStreamingTask?.cancel()
        }
    }

    @MainActor
    private func startNewSession() {
        currentStreamingTask?.cancel() // Cancel any previous streaming task
        currentResponse = ""
        streamError = nil
        isStreaming = true

        currentStreamingTask = Task {
            do {
                let stream = try await streamer.streamResponse(for: "Tell me about SwiftUI.")
                // The `for await in` loop itself is a throwing operation
                for try await token in stream {
                    // Check for cancellation within the loop for immediate response
                    if Task.isCancelled {
                        print("Streaming task was cancelled while processing tokens.")
                        break // Exit the loop if cancelled
                    }
                    currentResponse += token
                }
                // If loop completes without throwing, stream finished successfully
                isStreaming = false
            } catch let error as StreamError {
                // Caught a custom StreamError from the AsyncThrowingStream
                streamError = error
                isStreaming = false
            } catch is CancellationError {
                // The Task itself was cancelled (e.g., by user tapping "Stop" or view disappearing)
                print("Streaming cancelled by user or system.")
                streamError = nil // Clear any previous error if user cancelled
                isStreaming = false
            } catch {
                // Catch any other unexpected errors
                streamError = .unknown(error)
                isStreaming = false
            }
        }
    }

    @MainActor
    private func cancelStreaming() {
        currentStreamingTask?.cancel() // Request cancellation of the task
        // The `Task.isCancelled` check in the `for await in` loop and `AIResponseStreamer` will handle the rest.
        // UI state will be updated once the task acknowledges cancellation and exits.
    }
}

// App Entry Point (for preview/testing)
@available(iOS 18.0, *)
struct ChatView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ChatView()
        }
    }
}
