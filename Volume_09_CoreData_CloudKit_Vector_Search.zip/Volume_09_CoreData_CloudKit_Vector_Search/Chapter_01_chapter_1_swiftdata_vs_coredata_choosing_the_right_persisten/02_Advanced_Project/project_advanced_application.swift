
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import SwiftData
import CoreData
import Combine

// MARK: - Package Dependencies
/*
 [Package.swift]
 dependencies: [
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0"),
    // Hypothetical Vector Library for Semantic Search
    .package(url: "https://github.com/example/VectorEmbeddings", from: "1.0.0")
 ]
*/

// MARK: - Error Definitions

/// Errors specific to the orchestration of dual-stack persistence.
enum PersistenceError: Error, LocalizedError {
    case migrationFailed(reason: String)
    case batchIngestionFailed(Error)
    case contextMismatch
    case dataCorruption(UUID)

    var errorDescription: String? {
        switch self {
        case .migrationFailed(let reason): return "Migration failed: \(reason)"
        case .batchIngestionFailed(let error): return "Batch ingestion failed: \(error.localizedDescription)"
        case .contextMismatch: return "Attempted to access data across incompatible contexts."
        case .dataCorruption(let id): return "Data corruption detected in fragment: \(id.uuidString)"
        }
    }
}

// MARK: - Models

/// The Modern Model used by the SwiftUI layer via SwiftData.
/// Optimized for rapid UI updates and ease of use.
@available(iOS 18.0, *)
@Model
final class ModernMemoryFragment {
    @Attribute(.unique) var id: UUID
    var timestamp: Date
    var textContent: String
    var semanticVector: [Float] // Simplified vector representation
    var importanceScore: Double
    
    init(id: UUID = UUID(), timestamp: Date = .now, textContent: String, semanticVector: [Float], importanceScore: Double) {
        self.id = id
        self.timestamp = timestamp
        self.textContent = textContent
        self.semanticVector = semanticVector
        self.importanceScore = importanceScore
    }
}

// MARK: - Orchestration Actor

/// The `PersistenceOrchestrator` is a Swift 6 Actor that manages the bridge
/// between the high-performance Core Data stack and the reactive SwiftData stack.
/// Using an actor ensures that heavy background migrations and batch inserts
/// do not block the Main Actor or cause data races.
@available(iOS 18.0, *)
actor PersistenceOrchestrator {
    
    private let coreDataStack: CoreDataStack
    private let modelContainer: ModelContainer
    private let mainContext: ModelContext
    
    /// Initializes the orchestrator with both persistence engines.
    /// - Parameters:
    ///   - coreDataStack: The legacy/high-performance stack.
    ///   - modelContainer: The modern SwiftData container.
    init(coreDataStack: CoreDataStack, modelContainer: ModelContainer) {
        self.coreDataStack = coreDataStack
        self.modelContainer = modelContainer
        // We capture the main context to perform sync operations back to the UI
        self.mainContext = ModelContext(modelContainer)
    }
    
    /// Performs a high-speed batch ingestion of semantic data.
    /// This bypasses the SwiftData overhead by using Core Data's `NSBatchInsertRequest`.
    /// - Parameter rawData: An array of dictionaries containing fragment data.
    func ingestLargeScaleData(rawData: [[String: Any]]) async throws {
        print("🚀 Starting high-speed batch ingestion of \(rawData.count) fragments...")
        
        // Perform work on a private background context provided by the Core Data stack
        try await coreDataStack.performBackgroundTask { context in
            let batchInsert = NSBatchInsertRequest(entityName: "LegacyFragment", objects: rawData)
            batchInsert.resultType = .statusOnly
            
            let result = try context.execute(batchInsert) as? NSBatchInsertResult
            guard let status = result?.result as? Bool, status else {
                throw PersistenceError.batchIngestionFailed(
                    NSError(domain: "BatchInsertError", code: -1, userInfo: nil)
                )
            }
            print("✅ Batch insertion successful.")
        }
        
        // After heavy ingestion, we trigger a "Sync-to-SwiftData" process
        try await synchronizeLegacyToModern()
    }
    
    /// Synchronizes data from the Core Data store to the SwiftData store.
    /// In a production environment, this would involve a delta-check to avoid duplicates.
    private func synchronizeLegacyToModern() async throws {
        print("🔄 Synchronizing Core Data fragments to SwiftData...")
        
        // 1. Fetch all legacy fragments from Core Data
        let legacyFragments = try await coreDataStack.fetchAllLegacyFragments()
        
        // 2. Map and Upsert into SwiftData
        // We use the mainContext here to ensure the UI sees the changes immediately.
        for legacy in legacyFragments {
            let id = legacy.id // Assuming ID is mapped
            
            // Check if it already exists in SwiftData to prevent duplicates
            let predicate = #Predicate<ModernMemoryFragment> { $0.id == id }
            let descriptor = FetchDescriptor<ModernMemoryFragment>(predicate: predicate)
            
            let existing = try mainContext.fetch(descriptor)
            
            if existing.isEmpty {
                let newFragment = ModernMemoryFragment(
                    id: id,
                    timestamp: legacy.timestamp,
                    textContent: legacy.textContent,
                    semanticVector: legacy.vector,
                    importanceScore: legacy.score
                )
                mainContext.insert(newFragment)
            }
        }
        
        // 3. Commit changes to the SwiftData store
        try mainContext.save()
        print("✨ Synchronization complete. UI updated.")
    }
}

// MARK: - Core Data Infrastructure (The "Heavy Lifter")

/// A specialized wrapper for Core Data to handle background processing.
/// This is kept separate from SwiftData to maintain strict separation of concerns.
final class CoreDataStack: Sendable {
    let persistentContainer: NSPersistentContainer
    
    init() {
        persistentContainer = NSPersistentContainer(name: "MemoryEngineLegacy")
        // In a real app, we would load the persistent store here.
        // For this example, we assume the model is configured.
        persistentContainer.loadPersistentStores { _, error in
            if let error = error {
                fatalError("Core Data failed to load: \(error)")
            }
        }
    }
    
    /// Executes a block of code on a private background context.
    /// - Parameters:
    ///   - block: A closure that receives a background context.
    func performBackgroundTask(_ block: @escaping @Sendable (NSManagedObjectContext) throws -> Void) async throws {
        let context = persistentContainer.newBackgroundContext()
        // Ensure the context is configured for high-performance background work
        context.undoManager = nil 
        
        try await context.perform {
            try block(context)
        }
    }
    
    /// Fetches data from the legacy store.
    /// Returns a Sendable-friendly representation of the data.
    func fetchAllLegacyFragments() async throws -> [LegacyDataDTO] {
        let context = persistentContainer.viewContext
        return try await context.perform {
            let request = NSFetchRequest<NSManagedObject>(entityName: "LegacyFragment")
            let results = try context.fetch(request)
            
            return results.map { obj in
                LegacyDataDTO(
                    id: obj.value(forKey: "id") as? UUID ?? UUID(),
                    timestamp: obj.value(forKey: "timestamp") as? Date ?? .now,
                    textContent: obj.value(forKey: "textContent") as? String ?? "",
                    vector: obj.value(forKey: "vector") as? [Float] ?? [],
                    score: obj.value(forKey: "score") as? Double ?? 0.0
                )
            }
        }
    }
}

/// A Data Transfer Object (DTO) to move data safely from Core Data (non-Sendable)
/// to the Swift 6 Actor-based Orchestrator.
struct LegacyDataDTO: Sendable {
    let id: UUID
    let timestamp: Date
    let textContent: String
    let vector: [Float]
    let score: Double
}

// MARK: - Mock Legacy Managed Object
// In a real project, this is generated by the .xcdatamodeld file.
@objc(LegacyFragment)
final class LegacyFragment: NSManagedObject {
    @NSManaged var id: UUID
    @NSManaged var timestamp: Date
    @NSManaged var textContent: String
    @NSManaged var vector: [Float]
    @NSManaged var score: Double
}
