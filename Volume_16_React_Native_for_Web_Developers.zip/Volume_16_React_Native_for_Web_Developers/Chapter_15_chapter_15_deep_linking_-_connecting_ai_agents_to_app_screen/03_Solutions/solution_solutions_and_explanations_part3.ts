/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// DeepLinkTester.tsx
import React, { useState } from 'react';
import { View, TextInput, Button, Text, Linking, Alert } from 'react-native';
import * as LinkingAPI from 'expo-linking';

const DeepLinkTester = () => {
  const [url, setUrl] = useState('myapp://article/123');
  const [status, setStatus] = useState('');

  const handleTestLink = async () => {
    setStatus('Checking...');
    
    // 1. Check if the app can handle the URL (custom scheme)
    const supported = await LinkingAPI.canOpenURL(url);
    
    if (supported) {
      setStatus('App can handle this link. Opening...');
      // 2. Open the URL (will switch to the app)
      await LinkingAPI.openURL(url);
    } else {
      setStatus('App not installed, opening web fallback...');
      // 3. Fallback logic (e.g., open a web version or store)
      const webUrl = url.replace('myapp://', 'https://myapp.com/');
      await Linking.openURL(webUrl);
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput 
        value={url} 
        onChangeText={setUrl} 
        style={{ borderWidth: 1, padding: 10, marginBottom: 10 }} 
      />
      <Button title="Test Link" onPress={handleTestLink} />
      <Text style={{ marginTop: 10, color: 'blue' }}>{status}</Text>
    </View>
  );
};

export default DeepLinkTester;

/*
 * EXPO CONFIG (app.json) FOR UNIVERSAL LINKS:
 * To enable Universal Links on iOS (opening myapp.com links directly in the app),
 * you must configure the 'associatedDomains' entitlement.
 *
 * "ios": {
 *   "associatedDomains": ["applinks:myapp.com"]
 * }
 *
 * This requires an Apple App Site Association (AASA) file hosted at
 * https://myapp.com/.well-known/apple-app-site-association.
 */
