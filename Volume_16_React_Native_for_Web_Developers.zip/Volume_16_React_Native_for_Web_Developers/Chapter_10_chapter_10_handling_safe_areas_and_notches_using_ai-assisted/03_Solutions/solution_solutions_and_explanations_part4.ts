/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';

export const UniversalTabBar = ({ state, descriptors, navigation }: BottomTabBarProps) => {
  const insets = useSafeAreaInsets();
  
  // Calculate the FAB's vertical position.
  // It sits above the tab bar. Assuming a tab bar height of ~60px (arbitrary for this example).
  const tabBarHeight = 60; 
  const fabBottom = insets.bottom + tabBarHeight - 20; // -20 centers the FAB relative to the bar edge

  return (
    <View style={{ position: 'relative' }}> {/* Wrapper for FAB absolute positioning context */}
      
      {/* Main Tab Bar Container */}
      <View
        style={{
          flexDirection: 'row',
          backgroundColor: 'rgba(255, 255, 255, 0.9)', // Semi-transparent
          borderTopWidth: 1,
          borderTopColor: '#e0e0e0',
          height: tabBarHeight + insets.bottom, // Total height includes safe area
          paddingBottom: insets.bottom, // Pushes content up into the safe area
          shadowColor: '#000',
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 5, // Android shadow
        }}
      >
        {state.routes.map((route, index) => {
          const isFocused = state.index === index;
          const { options } = descriptors[route.key];

          const onPress = () => {
            const event = navigation.emit({
              type: 'tabPress',
              target: route.key,
              canPreventDefault: true,
            });

            if (!isFocused && !event.defaultPrevented) {
              navigation.navigate(route.name);
            }
          };

          return (
            <TouchableOpacity
              key={route.key}
              accessibilityRole="button"
              accessibilityState={isFocused ? { selected: true } : {}}
              onPress={onPress}
              style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
            >
              <Text style={{ color: isFocused ? '#007AFF' : '#8e8e93', fontSize: 12 }}>
                {options.title || route.name}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Floating Action Button (FAB) */}
      <TouchableOpacity
        style={{
          position: 'absolute',
          right: 20,
          bottom: fabBottom, // Calculated dynamic bottom
          width: 56,
          height: 56,
          borderRadius: 28,
          backgroundColor: '#007AFF',
          justifyContent: 'center',
          alignItems: 'center',
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.3,
          shadowRadius: 4,
          elevation: 6,
        }}
        onPress={() => alert('FAB Pressed')}
      >
        <Text style={{ color: 'white', fontSize: 24, fontWeight: 'bold' }}>+</Text>
      </TouchableOpacity>
    </View>
  );
};

/*
 * UNDER THE HOOD: Padding vs. Margin
 * 
 * Q: What is the difference between using paddingBottom on the tab bar container vs. 
 *    using marginBottom on the screen content?
 * A: 
 * 1. paddingBottom on Tab Bar: This is the most reliable approach. By adding paddingBottom 
 *    equal to the safe area inset directly to the tab bar, we ensure the tab bar itself 
 *    occupies the safe area. The content above the tab bar (the main screen) typically 
 *    uses flex: 1 to fill the remaining space. This guarantees that the tab bar is always 
 *    visible and interactive, and no content is hidden behind the system UI.
 * 
 * 2. marginBottom on Screen Content: Adding a margin to the screen content effectively 
 *    creates a "dead zone" at the bottom of the scrollable area. While this prevents 
 *    content from being hidden behind the tab bar, it can feel unnatural in ScrollView 
 *    interactions. The user might scroll content down into this margin area, leaving 
 *    empty space. Furthermore, calculating this margin requires knowing the exact height 
 *    of the tab bar, which might change dynamically.
 * 
 * Conclusion: Using paddingBottom on the tab bar container is the standard and recommended 
 * pattern in React Navigation, as it keeps the tab bar fixed and allows content to flow 
 * naturally up to the edge of the safe area.
 */
