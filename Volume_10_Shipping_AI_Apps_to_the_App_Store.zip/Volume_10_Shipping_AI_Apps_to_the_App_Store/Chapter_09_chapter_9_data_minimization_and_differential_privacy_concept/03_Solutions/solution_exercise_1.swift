
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import NaturalLanguage

/// Custom errors for the sanitization process
enum SanitizationError: Error {
    case nlpEngineFailure
    case invalidInput
}

/// An actor that ensures thread-safe sanitization of sensitive text.
/// Using an actor prevents data races when multiple threads attempt to sanitize text simultaneously.
actor PIISanitizer {
    
    private let redactionPlaceholder = "<REDACTED_ENTITY>"
    
    /// Sanitizes the input text by replacing identified PII with placeholders.
    /// - Parameter text: The raw user input.
    /// - Returns: A sanitized version of the string.
    /// - Throws: `SanitizationError` if processing fails.
    func sanitize(_ text: String) async throws -> String {
        guard !text.isEmpty else {
            throw SanitizationError.invalidInput
        }
        
        // Initialize the NLTagger with the nameType scheme
        let tagger = NLTagger(tagSchemes: [.nameType])
        tagger.string = text
        
        // We will collect the ranges of sensitive entities first.
        // To avoid index invalidation during string mutation, we collect and then process in reverse.
        var rangesToRedact: [Range<String.Index>] = []
        
        let options: NLTagger.Options = [.omitWhitespace, .joinNames]
        let tagsToRedact: [NLTag] = [.name, .placeName, .organization]
        
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .nameType, options: options) { tag, tokenRange in
            if let tag = tag, tagsToRedact.contains(tag) {
                rangesToRedact.append(tokenRange)
            }
            return true
        }
        
        // If no tags were found, return original text immediately to save allocations
        if rangesToRedact.isEmpty {
            return text
        }
        
        // Sort ranges in descending order to replace from the end of the string to the beginning.
        // This prevents the indices of earlier ranges from becoming invalid as the string length changes.
        let sortedRanges = rangesToRedact.sorted { $0.lowerBound > $1.lowerBound }
        
        var sanitizedText = text
        for range in sortedRanges {
            sanitizedText.replaceSubrange(range, with: redactionPlaceholder)
        }
        
        return sanitizedText
    }
}

// MARK: - Example Usage
@main
struct SanitizerApp {
    static func main() async {
        let sanitizer = PIISanitizer()
        let rawInput = "Hello, my name is John Doe and I live in New York near the Apple headquarters."
        
        do {
            let cleanText = try await sanitizer.sanitize(rawInput)
            print("Original: \(rawInput)")
            print("Sanitized: \(cleanText)")
        } catch {
            print("Error: \(error)")
        }
    }
}
