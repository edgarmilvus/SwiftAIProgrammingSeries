
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import AppTrackingTransparency

enum PrivacyFlowState: Equatable {
    case idle
    case showingEducation
    case requestingSystem
    case completed
}

@Observable
@MainActor
class PrivacyFlowManager {
    var currentState: PrivacyFlowState = .idle
    var hasUserConsentedToEducation: Bool = false // Persist this in real app
    
    func startFlow() {
        if !hasUserConsentedToEducation {
            currentState = .showingEducation
        } else {
            currentState = .requestingSystem
        }
    }
    
    func handleEducationDecision(accepted: Bool) {
        if accepted {
            hasUserConsentedToEducation = true
            currentState = .requestingSystem
        } else {
            // Respect choice: Do NOT show system prompt
            hasUserConsentedToEducation = true 
            currentState = .completed
        }
    }
}

struct LuminaPrivacyOverlay: View {
    @Bindable var manager: PrivacyFlowManager
    
    var body: some View {
        ZStack {
            if manager.currentState == .showingEducation {
                Color.black.opacity(0.4).ignoresSafeArea()
                
                VStack(spacing: 20) {
                    Text("Enhance Your Insights")
                        .font(.headline)
                    Text("See how your sleep patterns in other apps affect your AI-generated mood insights by enabling cross-app correlation.")
                        .multilineTextAlignment(.center)
                    
                    Button("Enhance My Insights") {
                        manager.handleEducationDecision(accepted: true)
                    }
                    .buttonStyle(.borderedProminent)
                    
                    Button("Keep it Private") {
                        manager.handleEducationDecision(accepted: false)
                    }
                    .buttonStyle(.bordered)
                }
                .padding()
                .background(RoundedRectangle(cornerRadius: 16).fill(Color(.systemBackground)))
                .padding(40)
            }
        }
        .onChange(of: manager.currentState) { _, newState in
            if newState == .requestingSystem {
                triggerSystemPrompt()
            }
        }
    }
    
    private func triggerSystemPrompt() {
        Task {
            let status = await ATTrackingManager.requestTrackingAuthorization()
            // Handle status...
            manager.currentState = .completed
        }
    }
}

// SDK Wrapper (The Gatekeeper)
struct WellnessAnalyticsWrapper {
    static func initialize(isAuthorized: Bool) {
        if isAuthorized {
            print("Initializing WellnessAnalytics with IDFA...")
        } else {
            print("Initializing WellnessAnalytics in Privacy Mode (No IDFA).")
        }
    }
}
