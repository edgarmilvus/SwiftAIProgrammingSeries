
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Foundation

// MARK: - 1. The Model
/// Represents a single message in the chat history.
/// Conforms to `Sendable` to ensure it can be safely passed between 
/// the LLMService (Actor) and the ChatViewModel (MainActor).
struct ChatMessage: Identifiable, Codable, Sendable, Equatable {
    let id: UUID
    let role: MessageRole
    var content: String
    let timestamp: Date

    enum MessageRole: String, Codable, Sendable {
        case user
        case assistant
    }

    init(id: UUID = UUID(), role: MessageRole, content: String, timestamp: Date = .now) {
        self.id = id
        self.role = role
        self.content = content
        self.timestamp = timestamp
    }
}

// MARK: - 2. The Service (The Actor)
/// `LLMService` is an `actor`, which means it provides automatic synchronization.
/// This is critical because multiple asynchronous tasks might try to append 
/// to the `conversationHistory` simultaneously.
@available(iOS 18.0, *)
actor LLMService {
    /// Internal state protected by the actor.
    /// Only methods within this actor can modify this array, preventing data races.
    private var conversationHistory: [ChatMessage] = []
    
    /// Simulates a network call to an LLM (e.g., OpenAI).
    /// - Parameter userPrompt: The text entered by the user.
    /// - Returns: An `AsyncStream` that yields tokens as they are "received" from the API.
    func streamResponse(for userPrompt: String) -> AsyncStream<String> {
        // 1. Add user message to local history
        let userMsg = ChatMessage(role: .user, content: userPrompt)
        conversationHistory.append(userMsg)
        
        // 2. Create an empty assistant message to be updated via streaming
        let assistantMsg = ChatMessage(role: .assistant, content: "")
        conversationHistory.append(assistantMsg)
        
        return AsyncStream { continuation in
            Task {
                // Simulate network latency for the initial request
                try? await Task.sleep(for: .seconds(1))
                
                let simulatedResponse = "This is a simulated AI response generated via an actor-based service architecture in Swift 6."
                let words = simulatedResponse.components(separatedBy: " ")
                
                for word in words {
                    // Simulate token-by-token streaming
                    try? await Task.sleep(for: .milliseconds(300))
                    continuation.yield(word + " ")
                    
                    // Update the internal history so the actor stays in sync
                    // We find the last message (the assistant one) and update it.
                    if let index = conversationHistory.indices.last {
                        conversationHistory[index].content += word + " "
                    }
                }
                
                continuation.finish()
            }
        }
    }
    
    /// Returns the current history. Since this is an actor, 
    /// the caller must `await` this property.
    func getHistory() -> [ChatMessage] {
        return conversationHistory
    }
}

// MARK: - 3. The ViewModel (The Coordinator)
/// `ChatViewModel` is marked with `@MainActor` because it drives the UI.
/// All updates to `@Published` properties must happen on the main thread.
@available(iOS 18.0, *)
@MainActor
class ChatViewModel: ObservableObject {
    /// The source of truth for the View.
    @Published private(set) var messages: [ChatMessage] = []
    @Published var isProcessing: Bool = false
    @Published var inputText: String = ""
    
    /// The dependency: The Service.
    private let llmService: LLMService
    
    init(service: LLMService) {
        self.llmService = service
    }
    
    /// Orchestrates the flow: UI -> ViewModel -> Service -> UI.
    func sendMessage() {
        let prompt = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !prompt.isEmpty else { return }
        
        // Update local UI state immediately
        let userMsg = ChatMessage(role: .user, content: prompt)
        messages.append(userMsg)
        inputText = ""
        isProcessing = true
        
        // Create a placeholder for the assistant's response
        let assistantMsg = ChatMessage(role: .assistant, content: "")
        messages.append(assistantMsg)
        
        // Start the asynchronous streaming task
        Task {
            // We call the actor. This is an 'await' because we are crossing 
            // the isolation boundary from @MainActor to the LLMService actor.
            let stream = await llmService.streamResponse(for: prompt)
            
            var accumulatedContent = ""
            
            // Iterate over the stream of tokens
            for await token in stream {
                accumulatedContent += token
                
                // Update the UI. Because this Task was started from a @MainActor 
                // context, this update is safe.
                if let index = messages.indices.last(where: { messages[index].role == .assistant }) {
                    messages[index].content = accumulatedContent
                }
            }
            
            isProcessing = false
        }
    }
}

// MARK: - 4. The View (The Interface)
@available(iOS 18.0, *)
struct ChatView: View {
    @StateObject private var viewModel: ChatViewModel
    
    init(service: LLMService) {
        // Initialize the StateObject with the provided service
        _viewModel = StateObject(wrappedValue: ChatViewModel(service: service))
    }
    
    var body: some View {
        NavigationStack {
            VStack {
                // Message List
                ScrollViewReader { proxy in
                    List(viewModel.messages) { message in
                        MessageBubble(message: message)
                            .id(message.id)
                            .listRowSeparator(.hidden)
                    }
                    .onChange(of: viewModel.messages.count) { _, _ in
                        // Auto-scroll to bottom when new messages arrive
                        if let lastId = viewModel.messages.last?.id {
                            withAnimation { proxy.scrollTo(lastId) }
                        }
                    }
                }
                
                // Input Area
                HStack {
                    TextField("Ask anything...", text: $viewModel.inputText)
                        .textFieldStyle(.roundedBorder)
                        .disabled(viewModel.isProcessing)
                    
                    Button {
                        viewModel.sendMessage()
                    } label: {
                        if viewModel.isProcessing {
                            ProgressView()
                        } else {
                            Image(systemName: "paperplane.fill")
                        }
                    }
                    .disabled(viewModel.isProcessing || viewModel.inputText.isEmpty)
                }
                .padding()
            }
            .navigationTitle("AI Assistant")
        }
    }
}

/// A simple subview for rendering message bubbles.
struct MessageBubble: View {
    let message: ChatMessage
    
    var body: some View {
        HStack {
            if message.role == .user { Spacer() }
            
            Text(message.content)
                .padding(12)
                .background(message.role == .user ? Color.blue : Color.gray.opacity(0.2))
                .foregroundColor(message.role == .user ? .white : .primary)
                .cornerRadius(16)
            
            if message.role == .assistant { Spacer() }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Preview
#Preview {
    ChatView(service: LLMService())
}
