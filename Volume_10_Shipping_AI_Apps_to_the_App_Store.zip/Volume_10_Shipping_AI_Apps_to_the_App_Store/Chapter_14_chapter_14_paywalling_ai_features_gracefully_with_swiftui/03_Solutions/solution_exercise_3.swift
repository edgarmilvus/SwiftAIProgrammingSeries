
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

enum AIAction {
    case basicText
    case highReasoning
}

enum SubscriptionError: Error, LocalizedError {
    case insufficientCredits
    case noActiveSubscription
    
    var errorDescription: String? {
        switch self {
        case .insufficientCredits: return "You've run out of High-Reasoning credits."
        case .noActiveSubscription: return "This feature requires a Pro subscription."
        }
    }
}

@available(iOS 18.0, *)
actor SubscriptionManager {
    // Actor isolation protects this state from data races
    private var credits: Int = 3
    private var isSubscribed: Bool = false
    
    func validateAccess(for action: AIAction) async throws {
        // Simulate a slight network check delay
        try await Task.sleep(for: .milliseconds(100))
        
        switch action {
        case .basicText:
            // Basic text is always allowed
            return
            
        case .highReasoning:
            // 1. Check if user has a subscription OR credits
            guard isSubscribed || credits > 0 else {
                throw SubscriptionError.insufficientCredits
            }
            
            // 2. Deduct a credit if not a subscriber
            if !isSubscribed {
                print("Deducting credit. Remaining: \(credits - 1)")
                credits -= 1
            }
            
            // 3. Success
            return
        }
    }
    
    // Method to simulate a subscription purchase
    func setSubscriptionStatus(_ status: Bool) {
        isSubscribed = status
    }
}

@available(iOS 18.0, *)
class AIService {
    let subscriptionManager: SubscriptionManager
    
    init(manager: SubscriptionManager) {
        self.subscriptionManager = manager
    }
    
    func generateResponse(prompt: String, type: AIAction) async throws -> String {
        // 1. The Guard Pattern: Validate BEFORE doing work
        try await subscriptionManager.validateAccess(for: type)
        
        // 2. Simulate heavy AI inference
        try await Task.sleep(for: .seconds(1.5))
        
        return "AI Response to: \(prompt)"
    }
}

// Test Harness
@available(iOS 18.0, *)
@MainActor
struct SubscriptionTestView: View {
    let service = AIService(manager: SubscriptionManager())
    @State private var response: String = "Waiting..."
    @State private var errorMessage: String?

    var body: some View {
        VStack(spacing: 20) {
            Text(response).padding()
            
            Button("Run High-Reasoning Task") {
                Task {
                    do {
                        response = "Processing..."
                        let result = try await service.generateResponse(prompt: "Hello AI", type: .highReasoning)
                        response = result
                    } catch {
                        response = "Error"
                        errorMessage = error.localizedDescription
                    }
                }
            }
        }
        .alert(errorMessage ?? "", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        }
    }
}
