/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * File: components/SaaSDashboard.tsx
 * Context: Advanced Application Script for Chapter 10.
 * Description: A Next.js/React Native for Web component demonstrating dynamic
 * safe area handling, generic layout components, and simulated async preference fetching.
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  SafeAreaView,
  useWindowDimensions,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

// --- 1. Type Definitions & Generics ---

/**
 * Generic type for layout variants.
 * Using Generics here allows us to extend the configuration later without breaking type safety.
 * @template T - The specific variant string literal type.
 */
type LayoutVariant = 'header' | 'footer' | 'content' | 'modal';

/**
 * Props for the SafeAreaBox component.
 * Includes a generic constraint to ensure 'variant' is a valid LayoutVariant.
 */
interface SafeAreaBoxProps<T extends LayoutVariant> {
  variant: T;
  children: React.ReactNode;
  className?: string;
  // Simulating AI-assisted configuration injection
  config?: {
    enforceSafeTop?: boolean;
    enforceSafeBottom?: boolean;
  };
}

// --- 2. The Core Layout Primitive (AI-Assisted) ---

/**
 * A robust, generic layout component that automatically adjusts padding
 * based on device safe areas (notches, navigation bars).
 *
 * Why: This abstracts the complexity of calculating insets manually.
 * How: It uses the `useSafeAreaInsets` hook to get current safe area values.
 * Under the Hood: It merges NativeWind classes with dynamic inline styles for precise control.
 */
const SafeAreaBox = <T extends LayoutVariant>({
  variant,
  children,
  className = '',
  config = { enforceSafeTop: true, enforceSafeBottom: true },
}: SafeAreaBoxProps<T>) => {
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();

  // --- Type Narrowing & Logic ---
  // While `insets` are always numbers, we can add logic here to handle edge cases
  // (e.g., specific web browser address bars that might not be captured by the context provider).
  const topInset = config.enforceSafeTop ? insets.top : 0;
  const bottomInset = config.enforceSafeBottom ? insets.bottom : 0;

  // Dynamic styling based on the variant
  const getVariantStyles = () => {
    switch (variant) {
      case 'header':
        return {
          paddingTop: topInset,
          backgroundColor: '#ffffff',
          borderBottomWidth: 1,
          borderBottomColor: '#e5e7eb',
        };
      case 'footer':
        return {
          paddingBottom: bottomInset,
          backgroundColor: '#ffffff',
          borderTopWidth: 1,
          borderTopColor: '#e5e7eb',
        };
      case 'content':
        return {
          paddingTop: 0,
          paddingBottom: bottomInset, // Ensure content isn't cut off by bottom safe area
        };
      case 'modal':
        return {
          paddingTop: topInset + 20,
          paddingBottom: bottomInset + 20,
        };
      default:
        return {};
    }
  };

  return (
    <View
      style={[
        getVariantStyles(),
        // We apply specific width constraints for web to mimic mobile viewport behavior if needed
        { maxWidth: 600, alignSelf: 'center', width: '100%' },
      ]}
      className={`px-4 ${className}`}
    >
      {children}
    </View>
  );
};

// --- 3. Asynchronous Tool Handling Simulation ---

/**
 * Simulates an asynchronous call to a SaaS backend to fetch user preferences.
 * In a real LangGraph/Node.js context, this would be an awaited tool call.
 */
const fetchUserPreferences = async (): Promise<{
  theme: 'light' | 'dark';
  layoutMode: 'comfortable' | 'compact';
}> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        theme: 'light',
        layoutMode: 'comfortable',
      });
    }, 800); // Simulate network latency
  });
};

// --- 4. The Main SaaS Dashboard Component ---

export const SaaSDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [preferences, setPreferences] = useState<{ theme: string; layoutMode: string } | null>(null);
  const insets = useSafeAreaInsets();

  // Asynchronous Tool Handling: Fetching data on mount
  useEffect(() => {
    const loadPreferences = async () => {
      try {
        const data = await fetchUserPreferences();
        setPreferences(data);
      } catch (error) {
        console.error("Failed to load preferences", error);
      } finally {
        setLoading(false);
      }
    };

    loadPreferences();
  }, []);

  if (loading) {
    return (
      <View style={[styles.centered, { paddingTop: insets.top }]}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={{ marginTop: 10 }}>Loading Dashboard...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Global Safe Area Provider is assumed to wrap this in _app.tsx */}
      
      {/* Header: Safe Area Aware */}
      <SafeAreaBox variant="header">
        <View className="flex-row justify-between items-center py-4">
          <Text className="text-xl font-bold text-gray-900">SaaS Analytics</Text>
          <View className="w-8 h-8 rounded-full bg-blue-500" />
        </View>
      </SafeAreaBox>

      {/* Main Content: Scrollable with Bottom Safe Area Padding */}
      <ScrollView 
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <SafeAreaBox variant="content">
          <Text className="text-2xl font-bold mb-2">Welcome back</Text>
          <Text className="text-gray-600 mb-6">
            Layout Mode: {preferences?.layoutMode.toUpperCase()}
          </Text>

          {/* Dashboard Cards */}
          <View className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 mb-4">
            <Text className="text-sm text-gray-500">Revenue</Text>
            <Text className="text-2xl font-bold text-green-600">$42,050</Text>
          </View>

          <View className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 mb-4">
            <Text className="text-sm text-gray-500">Active Users</Text>
            <Text className="text-2xl font-bold text-blue-600">1,240</Text>
          </View>

          {/* Simulating AI-generated content block */}
          <View className="bg-indigo-50 p-4 rounded-xl border border-indigo-100">
            <Text className="text-indigo-800 font-semibold mb-2">AI Insight</Text>
            <Text className="text-indigo-600 text-sm">
              "Your safe area insets are currently: Top {Math.round(insets.top)}px, Bottom {Math.round(insets.bottom)}px. 
              The layout is optimized for this device."
            </Text>
          </View>
          
          {/* Spacer to ensure scrollability above bottom nav */}
          <View style={{ height: 80 }} />
        </SafeAreaBox>
      </ScrollView>

      {/* Bottom Navigation: Safe Area Aware */}
      <SafeAreaBox variant="footer" className="absolute bottom-0 left-0 right-0">
        <View className="flex-row justify-around items-center py-3">
          <Text className="text-blue-600 font-bold">Home</Text>
          <Text className="text-gray-400">Reports</Text>
          <Text className="text-gray-400">Settings</Text>
        </View>
      </SafeAreaBox>
    </SafeAreaView>
  );
};

// --- 5. Styles (NativeWind alternative for raw React Native) ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb', // Light gray background
  },
  scrollContent: {
    paddingBottom: 100, // Extra padding for bottom navigation overlap
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
