/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/SmartLink.tsx
import React from 'react';
import { Platform, Linking, Pressable, TextStyle, ViewStyle } from 'react-native';
import { Link, usePathname } from 'expo-router';

type SmartLinkProps = {
  href: string;
  children: React.ReactNode;
  style?: TextStyle | ViewStyle;
  activeStyle?: ViewStyle;
} & React.ComponentProps<typeof Pressable>;

export function SmartLink({ href, children, style, activeStyle, ...pressableProps }: SmartLinkProps) {
  const pathname = usePathname();
  const isExternal = href.startsWith('http');
  const isActive = pathname === href;

  // Web Implementation
  if (Platform.OS === 'web') {
    // If external, use standard anchor tag
    if (isExternal) {
      return (
        <a 
          href={href} 
          target="_blank" 
          rel="noopener noreferrer"
          style={{ textDecoration: 'none', color: 'inherit', ...(style as any) }}
        >
          {children}
        </a>
      );
    }

    // If internal, use Expo Router Link (Next.js compatible)
    return (
      <Link 
        href={href} 
        asChild
        style={{ textDecoration: 'none', color: 'inherit', ...(style as any), ...(isActive ? activeStyle : {}) }}
      >
        <Pressable {...pressableProps}>
          {children}
        </Pressable>
      </Link>
    );
  }

  // Native Implementation
  const handlePress = () => {
    if (isExternal) {
      Linking.openURL(href);
    } 
    // Internal navigation is handled by the Link component
  };

  return (
    <Link 
      href={href} 
      asChild 
      onPress={isExternal ? handlePress : undefined}
    >
      <Pressable 
        {...pressableProps} 
        style={({ pressed }) => [
          style,
          isActive && activeStyle,
          pressed && { opacity: 0.7 }
        ]}
      >
        {children}
      </Pressable>
    </Link>
  );
}
