
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import NaturalLanguage // Crucial: Import the NaturalLanguage framework

/// A simple struct to simulate a chat message for our example.
/// In a real app, this might come from a database or network request.
struct ChatMessage {
    let id: UUID
    let sender: String
    let text: String
    let timestamp: Date
}

/// A service responsible for detecting the language of chat messages.
/// Encapsulates the NLLanguageRecognizer logic for reuse.
class ChatLanguageDetector {

    /// Detects the dominant language of a given chat message's text.
    ///
    /// - Parameter message: The `ChatMessage` object containing the text to analyze.
    /// - Returns: An `NLLanguage` enum value representing the dominant language,
    ///            or `nil` if no language could be confidently determined by the recognizer
    ///            (e.g., for very short, ambiguous, or non-linguistic text).
    func detectLanguage(for message: ChatMessage) -> NLLanguage? {
        // 1. Create an instance of NLLanguageRecognizer.
        // This object is lightweight and can be created per detection or reused.
        // For simple, single-string detections, creating a new instance is fine.
        let recognizer = NLLanguageRecognizer()

        // 2. Provide the text to the recognizer for analysis.
        // The recognizer processes the input string to extract linguistic features
        // that help in identifying the language. This step is crucial.
        recognizer.processString(message.text)

        // 3. Retrieve the dominant language.
        // This property returns the language that the recognizer most confidently identified.
        // NLLanguage is an enum that provides standardized ISO 639-1 codes (e.g., .english, .spanish).
        // It returns an optional `NLLanguage` because the recognizer might not always
        // be able to determine a language (e.g., if the text is too short, contains only numbers, etc.).
        let dominantLanguage = recognizer.dominantLanguage

        return dominantLanguage
    }

    /// A convenience method to detect the dominant language directly from a `String`.
    /// This bypasses the `ChatMessage` struct for quick testing.
    ///
    /// - Parameter text: The string content to analyze.
    /// - Returns: An `NLLanguage` enum value, or `nil`.
    func detectLanguage(for text: String) -> NLLanguage? {
        let recognizer = NLLanguageRecognizer()
        recognizer.processString(text)
        return recognizer.dominantLanguage
    }
}

// MARK: - Example Usage

/// Main entry point for demonstrating NLLanguageRecognizer.
/// This function simulates the application logic.
func runLanguageDetectionExample() {
    print("--- NLLanguageRecognizer Basic Example ---")

    // Initialize our language detection service.
    let detector = ChatLanguageDetector()

    // --- Scenario 1: Detecting language for a clear English message ---
    let englishMessage = ChatMessage(
        id: UUID(),
        sender: "Alice",
        text: "Hello, how are you doing today? I hope you're having a great time.",
        timestamp: Date()
    )
    print("\nAnalyzing message: \"\(englishMessage.text)\"")
    if let detectedLanguage = detector.detectLanguage(for: englishMessage) {
        // NLLanguage.rawValue gives the ISO 639-1 standard code (e.g., "en", "es").
        print("Detected Language: \(detectedLanguage.rawValue) (ISO 639-1 code)")
        // You can also get a localized name for the language:
        print("Localized Name: \(detectedLanguage.localizedString(for: detectedLanguage))")
    } else {
        print("Could not confidently detect language for the English message.")
    }

    // --- Scenario 2: Detecting language for a clear Spanish message ---
    let spanishMessage = ChatMessage(
        id: UUID(),
        sender: "Bob",
        text: "¿Hola, cómo estás hoy? Espero que tengas un buen día.",
        timestamp: Date()
    )
    print("\nAnalyzing message: \"\(spanishMessage.text)\"")
    if let detectedLanguage = detector.detectLanguage(for: spanishMessage) {
        print("Detected Language: \(detectedLanguage.rawValue) (ISO 639-1 code)")
        print("Localized Name: \(detectedLanguage.localizedString(for: detectedLanguage))")
    } else {
        print("Could not confidently detect language for the Spanish message.")
    }

    // --- Scenario 3: Detecting language for a mixed or ambiguous message ---
    // The recognizer will try to find the *dominant* language.
    let ambiguousMessage = ChatMessage(
        id: UUID(),
        sender: "Charlie",
        text: "Swift is cool! C'est magnifique. I love programming.",
        timestamp: Date()
    )
    print("\nAnalyzing message: \"\(ambiguousMessage.text)\"")
    if let detectedLanguage = detector.detectLanguage(for: ambiguousMessage) {
        print("Detected Language: \(detectedLanguage.rawValue) (ISO 639-1 code)")
        print("Localized Name: \(detectedLanguage.localizedString(for: detectedLanguage))")
    } else {
        print("Could not confidently detect language for the ambiguous message.")
    }

    // --- Scenario 4: Detecting language for very short or non-linguistic text ---
    // NLLanguageRecognizer might not be able to make a confident prediction.
    let shortText = ChatMessage(
        id: UUID(),
        sender: "Dave",
        text: "abc",
        timestamp: Date()
    )
    print("\nAnalyzing message: \"\(shortText.text)\"")
    if let detectedLanguage = detector.detectLanguage(for: shortText) {
        print("Detected Language: \(detectedLanguage.rawValue) (ISO 639-1 code)")
    } else {
        print("Could not confidently detect language for the short text.")
    }

    let numericText = ChatMessage(
        id: UUID(),
        sender: "Eve",
        text: "12345",
        timestamp: Date()
    )
    print("\nAnalyzing message: \"\(numericText.text)\"")
    if let detectedLanguage = detector.detectLanguage(for: numericText) {
        print("Detected Language: \(detectedLanguage.rawValue) (ISO 639-1 code)")
    } else {
        print("Could not confidently detect language for the numeric text.")
    }

    let emojiText = ChatMessage(
        id: UUID(),
        sender: "Frank",
        text: "👋🌍✨",
        timestamp: Date()
    )
    print("\nAnalyzing message: \"\(emojiText.text)\"")
    if let detectedLanguage = detector.detectLanguage(for: emojiText) {
        print("Detected Language: \(detectedLanguage.rawValue) (ISO 639-1 code)")
    } else {
        print("Could not confidently detect language for the emoji text.")
    }
}

// Call the main function to execute the example.
runLanguageDetectionExample()
