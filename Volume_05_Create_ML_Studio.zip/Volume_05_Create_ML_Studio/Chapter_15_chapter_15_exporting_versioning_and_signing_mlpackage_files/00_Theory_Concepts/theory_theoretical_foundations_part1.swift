
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreML
import CreateML

// Assume 'trainedModel' is an MLModel instance obtained from a Create ML training session.
// @available(macOS 12.0, iOS 15.0, tvOS 15.0, watchOS 8.0, *) // Create ML is macOS only for training
@available(macOS 12.0, *)
actor ModelExporter {
    enum ExportError: Error {
        case directoryCreationFailed
        case modelSavingFailed(Error)
    }

    /// Exports an MLModel to a specified URL asynchronously.
    /// - Parameters:
    ///   - model: The MLModel instance to export.
    ///   - destinationURL: The URL where the .mlpackage should be saved.
    ///   - metadata: Optional metadata to include in the exported model.
    /// - Returns: The URL of the exported .mlpackage.
    func exportModel(
        _ model: MLModel,
        to destinationURL: URL,
        metadata: MLModelMetadata? = nil
    ) async throws -> URL {
        let fileManager = FileManager.default
        let modelFileName = (model.modelDescription.metadata[MLModelMetadataKey.modelName] as? String ?? "UntitledModel") + ".mlpackage"
        let finalURL = destinationURL.appendingPathComponent(modelFileName)

        // Ensure the destination directory exists
        if !fileManager.fileExists(atPath: destinationURL.path) {
            do {
                try fileManager.createDirectory(at: destinationURL, withIntermediateDirectories: true, attributes: nil)
            } catch {
                throw ExportError.directoryCreationFailed
            }
        }

        do {
            // MLModel.write(to:metadata:) is an asynchronous operation.
            // In a real-world scenario, CreateML often provides an asynchronous export method.
            // For demonstration, we wrap a potentially synchronous save or simulate async.
            // Actual Create ML `MLModel.write(to:metadata:)` is synchronous, but a larger system
            // managing multiple exports would benefit from async/await and actors.
            try await Task.detached { // Simulate a potentially long-running operation
                try model.write(to: finalURL, metadata: metadata)
            }.value
            
            print("Model successfully exported to: \(finalURL.path)")
            return finalURL
        } catch {
            throw ExportError.modelSavingFailed(error)
        }
    }
}

// Example usage (in an async context, e.g., a Task or an @main func)
/*
@available(macOS 12.0, *)
func performExport(trainedModel: MLModel) async {
    let exporter = ModelExporter()
    let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    let exportDirectory = documentsURL.appendingPathComponent("ExportedModels")

    do {
        let exportedURL = try await exporter.exportModel(trainedModel, to: exportDirectory)
        print("Export complete: \(exportedURL)")
    } catch {
        print("Export failed: \(error)")
    }
}
*/
