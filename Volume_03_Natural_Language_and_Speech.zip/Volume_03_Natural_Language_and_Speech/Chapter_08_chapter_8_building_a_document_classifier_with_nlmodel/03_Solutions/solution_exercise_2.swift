
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import NaturalLanguage
import CreateML
import Foundation

// MARK: - 1. Dataset Acquisition & Preprocessing

// Helper function to generate synthetic spam/ham data
func generateEmailSubjectTrainingData() -> [(text: String, label: String)] {
    var data: [(text: String, label: String)] = []

    // Ham (Not Spam) examples
    let hamSubjects = [
        "Meeting reminder for Monday",
        "Project update: Q4 results",
        "Regarding your recent inquiry",
        "Action required: Review document",
        "Lunch plans for tomorrow?",
        "Your order #12345 has shipped",
        "Weekly team sync agenda",
        "Follow up on our discussion",
        "Important: System maintenance tonight",
        "Invitation: Company picnic",
        "Your flight details confirmed",
        "New photos from the weekend",
        "Request for feedback on the new design",
        "Invoice from Acme Corp.",
        "Happy birthday from the team!",
        "Quick question about the report",
        "Reminder: Doctor's appointment",
        "Your subscription renewal",
        "Updates to our privacy policy",
        "Meeting minutes from last week",
        "Welcome to our newsletter!",
        "Job application status update",
        "Conference schedule released",
        "Please confirm your availability",
        "Important announcement from HR",
        "Your account statement is ready",
        "New features in our app",
        "Invitation to connect on LinkedIn",
        "Your password reset request",
        "Regarding your recent purchase"
    ]

    // Spam examples
    let spamSubjects = [
        "FREE MONEY NOW!!! Claim your prize!",
        "Urgent: Your account has been compromised",
        "Click here to win a million dollars!",
        "Enlarge your member naturally",
        "Congratulations, you've been selected!",
        "Limited time offer: Huge discount!",
        "Verify your banking information immediately",
        "Your package is delayed - track here",
        "Exclusive offer just for you!",
        "Nigerian prince needs your help",
        "Lose weight fast with this one trick",
        "Unsubscribe here to stop receiving emails",
        "Viagra for sale, discreet shipping",
        "Your lottery winnings are waiting!",
        "Get rich quick scheme",
        "Act now before it's too late!",
        "Warning: Your computer is infected!",
        "Claim your free gift card!",
        "Debt relief solutions",
        "Student loan forgiveness program",
        "Work from home and earn thousands",
        "Secret to youthful skin",
        "Your credit score needs attention",
        "Unexpected inheritance funds",
        "Cheap pharmaceuticals online",
        "Government grants you never knew existed",
        "Investment opportunity: High returns",
        "Your prize notification",
        "Click to update your security info",
        "Hidden camera footage exposed"
    ]

    // Add multiple variations for each to reach 200-300 examples
    for _ in 0..<5 { // Repeat each subject 5-6 times to get ~300 examples
        for subject in hamSubjects {
            data.append((subject.lowercased().trimmingCharacters(in: .whitespacesAndNewlines), "Not Spam"))
        }
        for subject in spamSubjects {
            data.append((subject.lowercased().trimmingCharacters(in: .whitespacesAndNewlines), "Spam"))
        }
    }
    
    // Add some more variations manually
    data.append(("urgent action required - account suspended", "Spam"))
    data.append(("your amazon order is pending", "Spam"))
    data.append(("re: project meeting tomorrow", "Not Spam"))
    data.append(("new policy update for employees", "Not Spam"))
    data.append(("claim your free iphone now", "Spam"))
    data.append(("weekly report for sales performance", "Not Spam"))
    data.append(("investment opportunity with guaranteed returns", "Spam"))
    data.append(("quick question about the proposal", "Not Spam"))
    data.append(("your bank account needs verification", "Spam"))
    data.append(("invoice for january services", "Not Spam"))

    return data.shuffled()
}

// MARK: - 2. Model Training

func trainAndSaveSpamClassifier() throws -> URL {
    let trainingData = generateEmailSubjectTrainingData()
    
    // Convert to MLDataTable
    let dataTable = try MLDataTable(array: trainingData.map { ["text": $0.text, "label": $0.label] })

    // Split data for training and testing
    let (trainingTable, testingTable) = dataTable.randomSplit(by: 0.8, seed: 42)

    // Train the classifier
    let classifier = try MLTextClassifier(trainingData: trainingTable,
                                          textColumn: "text",
                                          labelColumn: "label")

    // Evaluate the model
    let evaluation = classifier.evaluation(on: testingTable, textColumn: "text", labelColumn: "label")
    print("Spam Classifier Training Accuracy: \(evaluation.accuracy)")
    print("Spam Classifier Evaluation Metrics: \(evaluation.metrics)") // Provides precision, recall, F1

    // Save the model
    let fileManager = FileManager.default
    let documentsURL = try fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    let modelURL = documentsURL.appendingPathComponent("SpamClassifier.mlmodel")

    try classifier.write(to: modelURL)
    print("Spam Classifier model saved to: \(modelURL.path)")
    return modelURL
}

// MARK: - 3. Integration and Classification

class EmailSpamClassifier {
    private var model: NLModel?

    init(modelURL: URL) {
        do {
            self.model = try NLModel(contentsOf: modelURL)
            print("Email spam classifier model loaded successfully.")
        } catch {
            print("Error loading NLModel: \(error.localizedDescription)")
            self.model = nil
        }
    }

    func classifyEmailSubject(subject: String) -> String {
        guard let model = model else {
            print("Model not loaded. Cannot classify.")
            return "Unknown"
        }
        // Preprocess the input subject line just like the training data
        let preprocessedSubject = subject.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        return model.predictedLabel(for: preprocessedSubject) ?? "Unknown"
    }
    
    func classifyEmailSubjectWithConfidence(subject: String) -> (label: String, confidence: Double) {
        guard let model = model else {
            print("Model not loaded. Cannot classify.")
            return ("Unknown", 0.0)
        }
        let preprocessedSubject = subject.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        let (label, probabilities) = model.predictedLabel(for: preprocessedSubject, probabilities: ())
        if let label = label, let confidence = probabilities[label] {
            return (label, confidence)
        }
        return ("Unknown", 0.0)
    }
}

// MARK: - Main Execution

func runSpamDetectionDemo() {
    var modelURL: URL?
    do {
        modelURL = try trainAndSaveSpamClassifier()
    } catch {
        print("Failed to train or save spam classifier model: \(error.localizedDescription)")
        return
    }

    guard let loadedModelURL = modelURL else {
        print("Spam classifier model URL not available.")
        return
    }

    let spamClassifier = EmailSpamClassifier(modelURL: loadedModelURL)

    print("\n--- Testing Spam Detection ---")
    let testSubjects = [
        "Your account has been suspended, click to verify.", // Spam
        "Meeting agenda for next week's sync.", // Not Spam
        "Congratulations! You've won a free holiday!", // Spam
        "Quick question about the new feature.", // Not Spam
        "Urgent: Your payment is overdue.", // Spam
        "Review request: Pull Request #123.", // Not Spam
        "Get rich fast with our exclusive investment plan.", // Spam
        "Regarding the project deadline.", // Not Spam
        "Claim your prize now!!!", // Spam
        "Order confirmation for your recent purchase." // Not Spam
    ]

    for subject in testSubjects {
        let (prediction, confidence) = spamClassifier.classifyEmailSubjectWithConfidence(subject: subject)
        let confidenceString = String(format: "%.2f", confidence)
        print("Subject: '\(subject)' -> Prediction: \(prediction) (Confidence: \(confidenceString))")
    }
}

// Call the demo function
runSpamDetectionDemo()
