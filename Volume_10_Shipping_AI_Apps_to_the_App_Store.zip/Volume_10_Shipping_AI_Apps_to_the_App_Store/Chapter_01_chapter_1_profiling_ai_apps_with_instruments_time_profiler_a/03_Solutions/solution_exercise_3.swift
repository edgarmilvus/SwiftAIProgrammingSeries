
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import OSLog
import CoreML
import Accelerate // Essential for high-performance math

@available(iOS 18.0, *)
class SemanticSearchEngine {
    private let logger = Logger(subsystem: "com.lumina.search", category: "Inference")
    private let signposter = OSSignposter(subsystem: "com.lumina.search", category: "Inference")
    
    // Track the current search task to allow cancellation
    private var activeSearchTask: Task<Void, Never>?

    /// The entry point for the UI. Implements debouncing and cancellation.
    func handleQueryChange(query: String, imageEmbeddings: [[Float]], onResult: @escaping ([Int]) -> Void) {
        // 1. Cancellation: If the user types another character, kill the previous search.
        // This prevents the ANE from being overwhelmed by outdated requests.
        activeSearchTask?.cancel()
        
        activeSearchTask = Task {
            // 2. Debouncing: Wait 300ms. If the user is still typing, this task is cancelled.
            try? await Task.sleep(for: .milliseconds(300))
            if Task.isCancelled { return }

            let results = await performSearch(query: query, imageEmbeddings: imageEmbeddings)
            
            if !Task.isCancelled {
                onResult(results)
            }
        }
    }

    private func performSearch(query: String, imageEmbeddings: [[Float]]) async -> [Int] {
        let state = signposter.beginInterval("SearchCycle")
        defer { signposter.endInterval("SearchCycle", state) }
        
        let queryEmbedding = await generateEmbedding(for: query)
        
        var matches: [Int] = []
        
        // 3. Vector Acceleration: Using Accelerate/vDSP instead of a manual loop.
        // This moves the math from the CPU general-purpose registers to SIMD units.
        for (index, imgEmbedding) in imageEmbeddings.enumerated() {
            if Task.isCancelled { break }
            
            // vDSP.dot is highly optimized for Apple Silicon
            let similarity = vDSP.dot(queryEmbedding, imgEmbedding)
            
            if similarity > 0.8 {
                matches.append(index)
            }
        }
        return matches
    }

    private func generateEmbedding(for text: String) async -> [Float] {
        let state = signposter.beginInterval("TextEmbedding")
        defer { signposter.endInterval("TextEmbedding", state) }
        
        // Simulate heavy NLP model inference
        try? await Task.sleep(for: .milliseconds(200))
        return (0..<512).map { _ in Float.random(in: -1...1) }
    }
}
