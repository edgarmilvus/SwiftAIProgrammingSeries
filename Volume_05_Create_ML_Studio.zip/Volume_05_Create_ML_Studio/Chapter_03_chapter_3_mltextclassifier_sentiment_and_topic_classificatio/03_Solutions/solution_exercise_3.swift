
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import CoreML

// MARK: - App Structure (for a runnable SwiftUI app)
@main
struct EmailAssistantApp: App {
    var body: some Scene {
        WindowGroup {
            EmailAssistantView()
                .frame(minWidth: 500, minHeight: 600) // Set initial window size for macOS
        }
    }
}

// MARK: - EmailAssistantView
@available(iOS 18.0, macOS 15.0, *) // Adjust minimum OS versions as needed
struct EmailAssistantView: View {
    @State private var emailSubject: String = ""
    @State private var emailBody: String = ""
    @State private var urgencyResult: String = "N/A"
    @State private var sentimentResult: String = "N/A"
    @State private var suggestedReply: String = ""

    // Load the Urgency Classifier model
    let urgencyClassifier: EmailUrgencyClassifier = {
        do {
            let config = MLModelConfiguration()
            return try EmailUrgencyClassifier(configuration: config)
        } catch {
            fatalError("Failed to load EmailUrgencyClassifier: \(error.localizedDescription)")
        }
    }()

    // Load the Sentiment Classifier model
    let sentimentClassifier: EmailSentimentClassifier = {
        do {
            let config = MLModelConfiguration()
            return try EmailSentimentClassifier(configuration: config)
        } catch {
            fatalError("Failed to load EmailSentimentClassifier: \(error.localizedDescription)")
        }
    }()

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Intelligent Inbox Assistant")
                .font(.title)
                .padding(.bottom)

            TextField("Subject", text: $emailSubject)
                .textFieldStyle(.roundedBorder)
                .accessibilityLabel("Email Subject Input")

            TextEditor(text: $emailBody)
                .frame(height: 200)
                .border(Color.gray, width: 1)
                .accessibilityLabel("Email Body Input")

            Button("Analyze Email") {
                analyzeEmail()
            }
            .buttonStyle(.borderedProminent)
            .accessibilityLabel("Analyze Email Button")

            Divider()

            HStack {
                Text("Urgency:")
                    .bold()
                Text(urgencyResult)
                    .accessibilityLabel("Predicted Urgency")
                    .accessibilityValue(urgencyResult)
            }
            HStack {
                Text("Sentiment:")
                    .bold()
                Text(sentimentResult)
                    .accessibilityLabel("Predicted Sentiment")
                    .accessibilityValue(sentimentResult)
            }

            Text("Suggested Reply:")
                .bold()
                .padding(.top, 5)
            Text(suggestedReply)
                .italic()
                .padding(.top, 5)
                .foregroundColor(.secondary)
                .accessibilityLabel("Suggested Quick Reply")
                .accessibilityValue(suggestedReply)

            Spacer()
        }
        .padding()
        .navigationTitle("Email Assistant") // For potential navigation contexts
    }

    /// Analyzes the email for both urgency and sentiment using two separate models.
    func analyzeEmail() {
        // Combine subject and body for a more comprehensive analysis
        let combinedText = "\(emailSubject) \(emailBody)"
        guard !combinedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            urgencyResult = "N/A"
            sentimentResult = "N/A"
            suggestedReply = "Please enter email content."
            return
        }

        do {
            // Predict urgency
            let urgencyPrediction = try urgencyClassifier.prediction(from: combinedText)
            urgencyResult = urgencyPrediction.label

            // Predict sentiment
            let sentimentPrediction = try sentimentClassifier.prediction(from: combinedText)
            sentimentResult = sentimentPrediction.label

            // Suggest a reply based on combined predictions
            suggestReply(urgency: urgencyResult, sentiment: sentimentResult)

        } catch {
            urgencyResult = "Error"
            sentimentResult = "Error"
            suggestedReply = "Error analyzing email: \(error.localizedDescription)"
            print("Email analysis error: \(error)")
        }
    }

    /// Generates a quick reply suggestion based on the predicted urgency and sentiment.
    func suggestReply(urgency: String, sentiment: String) {
        switch (urgency, sentiment) {
        case ("Urgent", "Negative"):
            suggestedReply = "I apologize for the inconvenience. Let me look into this immediately."
        case ("Urgent", "Positive"):
            suggestedReply = "Great news! I'll get on this right away."
        case ("Normal", "Negative"):
            suggestedReply = "Thank you for letting me know. I'll address this as soon as possible."
        case ("Normal", "Positive"):
            suggestedReply = "Thanks for the update! Glad to hear it."
        case ("Normal", "Neutral"):
            suggestedReply = "Understood. I'll review this."
        default:
            // Fallback for unexpected combinations or initial state
            suggestedReply = "How can I help?"
        }
    }
}
