/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// database.ts
import { VectorRecord } from './types';
import * as SQLite from 'expo-sqlite';

/**
 * Performs a similarity search against the database.
 * Calculates Cosine Similarity on-the-fly using SQL arithmetic.
 */
export async function findSimilarVectors(
  db: SQLite.SQLiteDatabase,
  queryVector: number[],
  limit: number = 5
): Promise<Array<{ record: VectorRecord; similarity: number }>> {
  // Serialize the query vector to pass into the SQL query safely
  const queryVectorString = JSON.stringify(queryVector);

  // Note: SQLite does not support array operations natively.
  // To calculate dot product and norms on JSON strings without extensions,
  // we would typically need to parse the JSON into table rows (using json_each),
  // which is extremely slow for high-dimensional vectors.
  // 
  // However, for the sake of this exercise and assuming a "pure SQL" constraint
  // without external extensions like SQLite Vector, we must acknowledge a limitation:
  // SQLite cannot natively iterate over a JSON array index-wise to perform vector math
  // efficiently in a single query.
  //
  // WORKAROUND FOR EXERCISE: 
  // We will fetch all records and perform the calculation in TypeScript.
  // A true SQL implementation of vector math on JSON strings requires complex 
  // recursive CTEs or user-defined functions (UDFs), which are not available in standard expo-sqlite.
  
  const query = `SELECT * FROM document_vectors`;

  return new Promise((resolve, reject) => {
    db.transaction((tx) => {
      tx.executeSql(
        query,
        [],
        (_, { rows }) => {
          const results: Array<{ record: VectorRecord; similarity: number }> = [];
          
          // Calculate Cosine Similarity in TypeScript (Post-Processing)
          for (let i = 0; i < rows.length; i++) {
            const item = rows.item(i);
            const storedVector: number[] = JSON.parse(item.embedding);
            
            if (storedVector.length !== queryVector.length) continue;

            // Dot Product
            let dotProduct = 0;
            for (let j = 0; j < queryVector.length; j++) {
              dotProduct += queryVector[j] * storedVector[j];
            }

            // Norms
            const queryNorm = Math.sqrt(queryVector.reduce((sum, val) => sum + val * val, 0));
            const storedNorm = Math.sqrt(storedVector.reduce((sum, val) => sum + val * val, 0));

            if (queryNorm === 0 || storedNorm === 0) continue;

            const similarity = dotProduct / (queryNorm * storedNorm);

            results.push({
              record: {
                ...item,
                embedding: storedVector // Keep as array
              },
              similarity
            });
          }

          // Sort by similarity descending and slice by limit
          results.sort((a, b) => b.similarity - a.similarity);
          resolve(results.slice(0, limit));
        },
        (_, error) => {
          reject(error);
          return true;
        }
      );
    });
  });
}
