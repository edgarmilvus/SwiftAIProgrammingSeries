
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

actor LLMRetryHandler {
    /// Executes a throwing task with a limited number of retry attempts.
    /// - Parameters:
    ///   - attempts: The number of times to retry after the initial failure.
    ///   - task: The asynchronous, throwing work to perform.
    /// - Returns: The result of the successful task.
    func execute<T>(
        attempts: Int,
        task: @escaping @Sendable () async throws -> T
    ) async throws -> T {
        var currentAttempt = 0
        
        while true {
            do {
                // Attempt the actual work
                return try await task()
            } catch let error as LLMError {
                // Check if we should retry
                if error.isRetryable && currentAttempt < attempts {
                    currentAttempt += 1
                    
                    // Respect task cancellation during the wait period
                    try Task.checkCancellation()
                    
                    // Fixed delay as per Exercise 2 requirements
                    try await Task.sleep(for: .seconds(1))
                    continue 
                } else {
                    // Not retryable or out of attempts
                    throw error
                }
            } catch {
                // If it's not an LLMError, we don't know how to handle it; throw immediately
                throw error
            }
        }
    }
}
