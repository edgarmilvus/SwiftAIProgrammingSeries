
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CreateML
import Foundation

// MARK: - Exercise 1: Predicting Coffee Shop Wait Times

// Function to generate synthetic data for coffee shop wait times
func generateCoffeeShopData() -> [[String: MLDataValue]] {
    var data: [[String: MLDataValue]] = []
    let numSamples = 100 // Generate 100 samples for demonstration

    for _ in 0..<numSamples {
        let ordersInQueue = Int.random(in: 0...20)
        let baristasOnDuty = Int.random(in: 1...4)
        let isPeakHour = Bool.random()
        let orderComplexityScore = Int.random(in: 1...5)

        // Simulate wait time:
        // Base wait time increases with orders, complexity, peak hour.
        // Decreases with more baristas.
        var waitTime = Double(ordersInQueue) * 1.5
        waitTime += Double(orderComplexityScore) * 2.0
        if isPeakHour {
            waitTime += 5.0 // Add extra wait time during peak hours
        }
        waitTime -= Double(baristasOnDuty) * 1.0 // Baristas reduce wait time

        // Add some random noise to make it more realistic
        waitTime += Double.random(in: -2.0...2.0)
        waitTime = max(0.5, waitTime) // Ensure wait time is at least 0.5 minutes

        data.append([
            "ordersInQueue": .int(ordersInQueue),
            "baristasOnDuty": .int(baristasOnDuty),
            "isPeakHour": .int(isPeakHour ? 1 : 0), // Convert Bool to Int (0 or 1)
            "orderComplexityScore": .int(orderComplexityScore),
            "waitTimeMinutes": .double(waitTime)
        ])
    }
    return data
}

// Main function to run Exercise 1
func runExercise1() {
    print("--- Exercise 1: Predicting Coffee Shop Wait Times ---")

    // 1. Data Loading: Generate synthetic data
    let rawData = generateCoffeeShopData()
    guard let dataTable = try? MLDataTable(array: rawData) else {
        print("Error: Could not create MLDataTable from raw data.")
        return
    }
    print("Generated \(dataTable.rows.count) samples.")
    // print(dataTable.description) // Uncomment to see the raw data table

    // 2. Feature and Label Definition
    let featureColumns = ["ordersInQueue", "baristasOnDuty", "isPeakHour", "orderComplexityScore"]
    let targetColumn = "waitTimeMinutes"

    // Split data into training and testing sets
    let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 0)
    print("Training data size: \(trainingData.rows.count)")
    print("Testing data size: \(testingData.rows.count)")

    // 3. Model Training
    do {
        let regressor = try MLLinearRegressor(trainingData: trainingData,
                                              targetColumn: targetColumn,
                                              featureColumns: featureColumns)
        print("Model training complete.")

        // 4. Model Evaluation
        let evaluationMetrics = regressor.evaluation(on: testingData, targetColumn: targetColumn)
        let rmse = evaluationMetrics.rootMeanSquaredError
        let mae = evaluationMetrics.meanAbsoluteError

        print("Model Evaluation:")
        print("  Root Mean Squared Error (RMSE): \(String(format: "%.2f", rmse)) minutes")
        print("  Mean Absolute Error (MAE): \(String(format: "%.2f", mae)) minutes")

        // 5. Prediction Example
        print("\nDemonstrating a prediction:")
        let newOrderFeatures: [String: MLDataValue] = [
            "ordersInQueue": .int(7),
            "baristasOnDuty": .int(2),
            "isPeakHour": .int(1), // Peak hour
            "orderComplexityScore": .int(4)
        ]
        
        // Create a new MLDataTable for prediction
        guard let predictionInput = try? MLDataTable(array: [newOrderFeatures]) else {
            print("Error: Could not create prediction input MLDataTable.")
            return
        }

        let predictions = try regressor.predictions(from: predictionInput)
        if let predictedWaitTime = predictions[targetColumn]?.first?.doubleValue {
            print("  Input Features: Orders=7, Baristas=2, Peak=True, Complexity=4")
            print("  Predicted Wait Time: \(String(format: "%.2f", predictedWaitTime)) minutes")
        } else {
            print("  Could not retrieve prediction.")
        }
        
        // Example of saving the model (optional, for real-world deployment)
        // let modelURL = URL(fileURLWithPath: "/tmp/CoffeeWaitTimeRegressor.mlmodel")
        // try regressor.write(to: modelURL)
        // print("\nModel saved to: \(modelURL.path)")

    } catch {
        print("Error during model training or evaluation: \(error.localizedDescription)")
    }
    print("--------------------------------------------------\n")
}

// Call the function to run the exercise
runExercise1()
