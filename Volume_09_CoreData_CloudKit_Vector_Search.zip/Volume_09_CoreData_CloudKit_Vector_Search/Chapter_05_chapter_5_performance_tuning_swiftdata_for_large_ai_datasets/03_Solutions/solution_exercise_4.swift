
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import SwiftData

@Model
final class ResearchNote {
    var content: String
    var timestamp: Date
    var embedding: [Float]?
    
    init(content: String, timestamp: Date = .now) {
        self.content = content
        self.timestamp = timestamp
    }
}

struct SearchResult: Sendable {
    let note: ResearchNote
    let similarity: Float
}

final class HybridSearchService {
    private let modelContainer: ModelContainer
    
    init(container: ModelContainer) {
        self.modelContainer = container
    }
    
    func search(queryVector: [Float], keyword: String) async throws -> [ResearchNote] {
        let context = ModelContext(modelContainer)
        
        // --- STAGE 1: The Broad Stroke (Database Pruning) ---
        // We use a predicate to narrow down the search to recent notes 
        // or notes containing the keyword. This avoids loading 100k vectors.
        let oneYearAgo = Calendar.current.date(byAdding: .year, value: -1, to: .now)!
        
        let predicate = #Predicate<ResearchNote> { note in
            (note.content.contains(keyword) || keyword.isEmpty) &&
            note.timestamp > oneYearAgo
        }
        
        var descriptor = FetchDescriptor<ResearchNote>(predicate: predicate)
        // We only fetch the embedding and the ID to keep the fetch lightweight
        // (Note: SwiftData handles property-level faulting automatically)
        
        let candidates = try context.fetch(descriptor)
        
        // --- STAGE 2: The Precision Strike (Mathematical Ranking) ---
        // Now we perform the heavy math only on the filtered subset.
        let scoredResults = candidates.compactMap { note -> SearchResult? in
            guard let noteEmbedding = note.embedding else { return nil }
            
            let similarity = cosineSimilarity(queryVector, noteEmbedding)
            return SearchResult(note: note, similarity: similarity)
        }
        
        // Sort by highest similarity and return the top 5
        let topNotes = scoredResults
            .sorted { $0.similarity > $1.similarity }
            .prefix(5)
            .map { $0.note }
        
        return Array(topNotes)
    }
    
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return 0 }
        let dotProduct = zip(a, b).map(*).reduce(0, +)
        let magnitudeA = sqrt(a.map { $0 * $0 }.reduce(0, +))
        let magnitudeB = sqrt(b.map { $0 * $0 }.reduce(0, +))
        return dotProduct / (magnitudeA * magnitudeB)
    }
}
