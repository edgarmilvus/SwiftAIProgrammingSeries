
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

// Example: Vision processing within the AVCaptureSession delegate
import Vision
import CoreML

@available(iOS 18.0, *)
extension CameraProcessor {
    // Assume `myCoreMLModel` is loaded from a previous chapter's instructions
    // e.g., let myCoreMLModel = try! MyCustomModel(configuration: MLModelConfiguration()).model
    
    // Placeholder for a loaded Core ML model
    private lazy var visionCoreMLModel: VNCoreMLModel? = {
        do {
            // Replace `MyCustomModel` with your actual generated Core ML model class
            let model = try MyCustomModel(configuration: MLModelConfiguration()).model
            return try VNCoreMLModel(for: model)
        } catch {
            print("Error loading Core ML model for Vision: \(error)")
            return nil
        }
    }()

    private lazy var coreMLRequest: VNCoreMLRequest? = {
        guard let visionModel = visionCoreMLModel else { return nil }
        let request = VNCoreMLRequest(model: visionModel) { request, error in
            if let error = error {
                print("Vision Core ML Request error: \(error)")
                return
            }
            guard let observations = request.results as? [VNClassificationObservation] else { return }
            // Process observations (e.g., display top classification)
            if let topResult = observations.first {
                print("Detected: \(topResult.identifier) with confidence \(topResult.confidence)")
                // Update UI or state via an @Observable object
            }
        }
        request.imageCropAndScaleOption = .centerCrop // Or .scaleFill, .scaleFit
        return request
    }()

    func processPixelBufferWithVision(_ pixelBuffer: CVPixelBuffer) {
        guard let request = coreMLRequest else { return }
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        do {
            try handler.perform([request])
        } catch {
            print("Failed to perform Vision request: \(error)")
        }
    }

    // Modified captureOutput to integrate Vision
    override func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        processPixelBufferWithVision(pixelBuffer)
    }
}
