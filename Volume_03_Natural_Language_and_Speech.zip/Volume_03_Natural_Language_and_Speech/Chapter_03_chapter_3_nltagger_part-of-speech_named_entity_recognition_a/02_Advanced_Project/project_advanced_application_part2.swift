
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

/// Represents a single identified entity with its type and original text.
struct ExtractedEntity: Identifiable, Hashable {
    let id = UUID()
    let type: NLToken.TokenType // Or NLTagger.Tag for specific entity types
    let value: String
    let originalRange: Range<String.Index>
}

/// Represents a recognized named entity (Person, Organization, Location, Date).
struct NamedEntity: Identifiable, Hashable {
    let id = UUID()
    let type: NLToken.TokenType
    let name: String
    let originalRange: Range<String.Index>
    var dateValue: Date? // For date entities
}

/// Encapsulates all analyzed data from a document.
struct AnalyzedDocument {
    let originalText: String
    let recognizedLanguage: NLLanguage
    var namedEntities: [NamedEntity] = []
    var importantTerms: [String: Int] = [:] // For lemmatized significant terms and their counts
    var suggestedActions: [String] = [] // Actions derived from extracted data
}
