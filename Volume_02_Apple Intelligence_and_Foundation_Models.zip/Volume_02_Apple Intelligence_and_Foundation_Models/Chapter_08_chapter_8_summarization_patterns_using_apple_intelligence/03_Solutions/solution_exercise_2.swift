
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import NaturalLanguage // Contains TextSummarizer

@available(iOS 18.0, macOS 15.0, *)
func summarizeDailyNotes(notes: [String]) async throws -> String {
    guard !notes.isEmpty else {
        return "No notes provided for summarization."
    }

    // 1. Combine notes into a single string, using a clear separator.
    // A double newline often helps the summarizer understand distinct paragraphs.
    let combinedNotes = notes.joined(separator: "\n\n")

    // 2. Instantiate TextSummarizer.
    let summarizer = TextSummarizer()

    // 3. Call summarize() and return the result.
    let summary = try await summarizer.summarize(combinedNotes)
    return summary
}

// Example usage demonstrating an async context:
@available(iOS 18.0, macOS 15.0, *)
struct DailyNotesSummarizerExample: View {
    let dailyNotes = [
        "Met with John for project X update. Discussed blockers and next steps.",
        "Drafted initial design for new feature 'Smart Search'. Focused on user experience.",
        "Reviewed Q3 financial report. Noted slight revenue dip but strong growth in service sector.",
        "Prepared agenda for tomorrow's team standup. Key items: Project X, Smart Search, Q4 planning.",
        "Responded to client email regarding contract terms. Awaiting their feedback."
    ]
    @State private var dailySummary: String = "Tap 'Summarize' to get daily notes summary."
    @State private var isLoading: Bool = false
    @State private var showingErrorAlert: Bool = false
    @State private var errorMessage: String = ""

    var body: some View {
        VStack(alignment: .leading) {
            Text("Your Daily Notes:")
                .font(.headline)
            ScrollView {
                Text(dailyNotes.joined(separator: "\n- "))
                    .padding(.bottom)
            }
            .frame(height: 150)
            .border(Color.gray, width: 0.5)
            .padding(.horizontal)

            Button {
                Task {
                    isLoading = true
                    errorMessage = ""
                    showingErrorAlert = false
                    do {
                        dailySummary = try await summarizeDailyNotes(notes: dailyNotes)
                    } catch {
                        errorMessage = "Error summarizing notes: \(error.localizedDescription)"
                        showingErrorAlert = true
                        dailySummary = "Failed to generate summary."
                        print("Error summarizing daily notes: \(error)")
                    }
                    isLoading = false
                }
            } label: {
                if isLoading {
                    ProgressView()
                } else {
                    Text("Summarize All Notes")
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(isLoading)
            .padding()

            Text("Daily Summary:")
                .font(.headline)
            ScrollView {
                Text(dailySummary)
                    .padding(.top, 5)
            }
            .frame(minHeight: 100)
            .border(Color.gray, width: 0.5)
            .padding(.horizontal)
        }
        .navigationTitle("Daily Notes Summarizer")
        .padding()
        .alert("Error", isPresented: $showingErrorAlert) {
            Button("OK") { }
        } message: {
            Text(errorMessage)
        }
    }
}

// To run this example in a SwiftUI App:
/*
@main
@available(iOS 18.0, macOS 15.0, *)
struct NotesApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                DailyNotesSummarizerExample()
            }
        }
    }
}
*/
