
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation

// MARK: - DocumentProcessor Actor Definition

/// `DocumentProcessor` is an actor responsible for safely managing and processing scanned document texts.
/// It ensures that all operations on its internal state (like `processedDocuments`) are mutually exclusive,
/// preventing data races in a concurrent environment.
actor DocumentProcessor {
    /// Private mutable state to store the text of documents that have been processed.
    /// This array is protected by the actor's isolation.
    private var processedDocuments: [String] = []
    
    /// A simple counter to simulate document IDs or processing order.
    private var documentCount: Int = 0

    /// Simulates the processing of a single document.
    /// In a real app, this might involve OCR, initial parsing, or preparing data for AI models.
    ///
    /// - Parameter rawText: The raw text extracted from a scanned document.
    /// - Returns: A unique identifier for the processed document.
    ///
    /// This method is `async` because real-world processing often involves
    /// I/O or computationally intensive tasks that should not block the calling thread.
    /// The `await` keyword is implicitly handled when calling this method on the actor,
    /// ensuring exclusive access to `processedDocuments`.
    func processDocument(rawText: String) async -> String {
        // Simulate some asynchronous work, like OCR or initial text analysis.
        // In a real scenario, this might take hundreds of milliseconds or seconds.
        try? await Task.sleep(for: .milliseconds(500)) 
        
        documentCount += 1
        let processedText = "Document \(documentCount) (Processed): \(rawText.prefix(50))..."
        
        // This modification to `processedDocuments` is safe because it's inside an actor method.
        // The actor ensures only one task can modify `processedDocuments` at a time.
        self.processedDocuments.append(processedText)
        
        print("✅ DocumentProcessor: Processed document \(documentCount). Total processed: \(self.processedDocuments.count)")
        return processedText
    }

    /// Retrieves a copy of the currently processed documents.
    ///
    /// - Returns: An array of strings, each representing a processed document.
    ///
    /// Accessing `processedDocuments` through this method is also safe and isolated by the actor.
    func getProcessedDocuments() async -> [String] {
        return self.processedDocuments
    }
}

// MARK: - Example Usage in an iOS/macOS App Context

/// This class represents a typical view controller or view model that interacts with the `DocumentProcessor`.
/// It demonstrates how UI-related tasks can trigger background processing via the actor.
class DocumentScannerApp {
    // Instantiate our actor. Actors are reference types.
    private let documentProcessor = DocumentProcessor()

    /// Simulates a user scanning multiple documents concurrently.
    /// In a real app, these could be triggered by UI buttons or background tasks.
    ///
    /// We use `@MainActor` to indicate that this method (and typically UI-related logic)
    /// should run on the main thread.
    @MainActor
    func simulateScanningSession() async {
        print("🚀 Starting document scanning session...")

        // Define some sample raw document texts
        let rawDocuments = [
            "The quick brown fox jumps over the lazy dog. This is document one.",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. This is document two.",
            "Swift concurrency with actors makes concurrent programming much safer. This is document three.",
            "Apple Intelligence will revolutionize how we interact with our devices. This is document four."
        ]

        // Create a group of tasks to process documents concurrently.
        // Each task will call the actor's `processDocument` method.
        await withTaskGroup(of: String.self) { group in
            for (index, text) in rawDocuments.enumerated() {
                group.addTask {
                    print("➡️ UI Task: Submitting document \(index + 1) for processing...")
                    // Calling an actor method like `documentProcessor.processDocument` is an `await` point.
                    // The Swift runtime ensures that `processDocument` has exclusive access to the actor's state.
                    let processed = await self.documentProcessor.processDocument(rawText: text)
                    print("⬅️ UI Task: Received result for document \(index + 1): \(processed.prefix(20))...")
                    return processed
                }
            }

            // Collect results as they complete (optional, but good for demonstration)
            for await result in group {
                // In a real app, you might update UI here, e.g., show a checkmark next to the scanned document.
                print("✨ UI Task: Document processed and collected: \(result.prefix(20))...")
            }
        }

        // After all documents are submitted (and potentially processed),
        // we can safely retrieve the final list from the actor.
        let finalProcessedDocuments = await documentProcessor.getProcessedDocuments()
        print("\n📝 Final list of all processed documents:")
        for doc in finalProcessedDocuments {
            print("- \(doc)")
        }
        
        print("\n🎉 Scanning session complete.")
    }
}

// MARK: - Execution

// To run this example, typically you'd do so from your `main` function or an entry point.
// Since `simulateScanningSession` is `async`, we need an `async` context to call it.
Task {
    let app = DocumentScannerApp()
    await app.simulateScanningSession()
}
