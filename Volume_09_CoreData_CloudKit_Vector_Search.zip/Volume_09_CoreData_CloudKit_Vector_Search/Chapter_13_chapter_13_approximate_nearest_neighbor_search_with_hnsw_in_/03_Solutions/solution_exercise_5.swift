
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

/// Represents a node in the HNSW graph.
struct HNSWNode: Sendable {
    let id: Int
    let vector: [Float]
    var neighbors: [Int]
    var isDeleted: Bool = false
}

/// An actor-based HNSW graph that supports safe deletions and background compaction.
actor LivingHNSWGraph {
    private var nodes: [Int: HNSWNode] = [:]
    private var isCompacting: Bool = false

    /// Adds a node to the graph.
    func insert(id: Int, vector: [Float], neighbors: [Int]) {
        nodes[id] = HNSWNode(id: id, vector: vector, neighbors: neighbors)
    }

    /// Performs a logical deletion using a tombstone.
    func delete(id: Int) {
        nodes[id]?.isDeleted = true
        print("Node \(id) marked as tombstone.")
    }

    /// Searches the graph, skipping tombstoned nodes.
    func search(queryVector: [Float], limit: Int) -> [Int] {
        // In a real HNSW, this would be a complex traversal.
        // Here, we simulate the traversal logic including the tombstone check.
        var results: [Int] = []
        
        // Simulated traversal order
        let traversalOrder = nodes.keys.sorted()
        
        for nodeId in traversalOrder {
            guard let node = nodes[nodeId], !node.isDeleted else {
                continue // SKIP tombstoned nodes
            }
            
            results.append(nodeId)
            if results.count >= limit { break }
        }
        return results
    }

    /// Performs structural cleanup by removing tombstoned nodes and re-linking neighbors.
    func compact() async {
        guard !isCompacting else { return }
        isCompacting = true
        
        // Run compaction on a detached task with lower priority
        await Task.detached(priority: .background) {
            await self.performCleanup()
        }.value
        
        isCompacting = false
    }

    private func performCleanup() {
        // This is a simplified version of the RCU (Read-Copy-Update) pattern.
        // In a real graph, you would rebuild the adjacency lists of neighbors.
        print("Starting background compaction...")
        
        // 1. Identify dead nodes
        let deadNodes = nodes.filter { $0.value.isDeleted }.map { $0.key }
        
        for deadId in deadNodes {
            // 2. In a real implementation, we would:
            //    a. Find all neighbors of deadId.
            //    b. For each neighbor, remove deadId from their neighbor list.
            //    c. Optionally, link the neighbor's neighbors to each other.
            
            // 3. Physical removal
            nodes.removeValue(forKey: deadId)
            print("Physically removed node \(deadId)")
        }
        print("Compaction complete.")
    }
}

// MARK: - Usage Example
@available(iOS 18.0, *)
func demonstrateLivingGraph() async {
    let graph = LivingHNSWGraph()
    
    // 1. Setup nodes
    await graph.insert(id: 1, vector: [0.1], neighbors: [2])
    await graph.insert(id: 2, vector: [0.2], neighbors: [1])
    await graph.insert(id: 3, vector: [0.3], neighbors: [1])
    
    // 2. Delete a node (Logical)
    await graph.delete(id: 2)
    
    // 3. Search (Should skip node 2)
    let results = await graph.search(queryVector: [0.1], limit: 10)
    print("Search results (skipping deleted): \(results)")
    
    // 4. Compact (Physical)
    await graph.compact()
    
    // 5. Search again (Node 2 is physically gone)
    let finalResults = await graph.search(queryVector: [0.1], limit: 10)
    print("Final search results: \(finalResults)")
}
