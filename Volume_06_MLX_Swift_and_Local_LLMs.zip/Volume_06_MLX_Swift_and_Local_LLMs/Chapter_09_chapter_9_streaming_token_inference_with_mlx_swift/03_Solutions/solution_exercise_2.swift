
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import MLX

// Re-using TokenizerProtocol from Exercise 1
protocol TokenizerProtocol: Sendable {
    func tokenize(text: String) -> [Int]
    func detokenize(ids: [Int]) -> String
    var eosTokenID: Int { get }
}

// Re-using MockTokenizer from Exercise 1
class MockTokenizer: TokenizerProtocol {
    let vocab: [String: Int]
    let reverseVocab: [Int: String]
    let eosTokenID: Int

    init(vocab: [String: Int], eosTokenID: Int) {
        self.vocab = vocab
        self.reverseVocab = vocab.reduce(into: [:]) { $0[$1.value] = $1.key }
        self.eosTokenID = eosTokenID
    }

    func tokenize(text: String) -> [Int] {
        // Simple word-based tokenization for mock
        return text.split(separator: " ", omittingEmptySubsequences: true).compactMap { vocab[String($0)] }
    }

    func detokenize(ids: [Int]) -> String {
        // Simple space-joined detokenization for mock
        return ids.compactMap { reverseVocab[$0] }.joined(separator: " ")
    }
}

// MARK: - Detokenization and Stop Phrase Logic

enum DetokenizationError: Error, LocalizedError {
    case invalidTokenID
    case tokenizerFailed
    
    var errorDescription: String? {
        switch self {
        case .invalidTokenID: return "Received an invalid token ID."
        case .tokenizerFailed: return "Tokenizer operation failed."
        }
    }
}

@available(iOS 18.0, macOS 14.0, *)
class StreamingDetokenizer {
    private let tokenizer: any TokenizerProtocol
    private let stopPhrases: [String]
    private var currentOutputBuffer: String = "" // The full string generated so far
    private var pendingTokensBuffer: [Int] = []  // Tokens not yet confidently yielded

    init(tokenizer: any TokenizerProtocol, stopPhrases: [String]) {
        self.tokenizer = tokenizer
        self.stopPhrases = stopPhrases.sorted(by: { $0.count > $1.count }) // Check longer phrases first
    }

    /// Processes a stream of MLXArray token IDs into a stream of processed strings,
    /// handling buffered detokenization and stop phrase detection.
    func process(tokenIDStream: AsyncThrowingStream<MLXArray, Error>) -> AsyncThrowingStream<String, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                do {
                    for try await tokenIDArray in tokenIDStream {
                        guard let tokenID = tokenIDArray.item(Int.self) else {
                            continuation.finish(throwing: DetokenizationError.invalidTokenID)
                            return
                        }

                        if tokenID == tokenizer.eosTokenID {
                            // Yield any remaining buffered text before stopping
                            let remainingText = try yieldBufferedText()
                            if !remainingText.isEmpty {
                                continuation.yield(remainingText)
                            }
                            continuation.finish()
                            return
                        }

                        pendingTokensBuffer.append(tokenID)

                        // Attempt to detokenize the buffered tokens + current output
                        // This is a common strategy: detokenize the *entire* sequence
                        // and compare with what was last yielded.
                        let fullDetokenized = tokenizer.detokenize(ids: pendingTokensBuffer)
                        
                        // Heuristic for yielding: If the new detokenized chunk ends with a space,
                        // newline, or punctuation, or if it gets "long enough" (e.g., a word),
                        // we can confidently yield the stable part.
                        let newStableText = extractStableText(from: fullDetokenized, previousOutput: currentOutputBuffer)
                        
                        if !newStableText.isEmpty {
                            currentOutputBuffer += newStableText
                            continuation.yield(newStableText)
                            
                            // Remove yielded tokens from buffer (this is tricky with subword tokenizers)
                            // For simplicity with a word-based tokenizer, we can clear if we've output a word.
                            // A more robust solution would re-tokenize `currentOutputBuffer` to find how many
                            // `pendingTokensBuffer` were consumed.
                            // For this mock, we'll assume `extractStableText` implies consumption.
                            // A more robust approach might be to not clear `pendingTokensBuffer` but
                            // rather use it to reconstruct the *full* string for stop phrase checks.
                            // Let's adjust: keep `pendingTokensBuffer` for full detokenization,
                            // but only yield `newStableText`.
                        }

                        // Check for stop phrases in the cumulative output string
                        if let stopPhrase = stopPhrases.first(where: { currentOutputBuffer.hasSuffix($0) }) {
                            // Yield any remaining part before the stop phrase
                            let finalOutput = currentOutputBuffer.dropLast(stopPhrase.count)
                            let remainingTextToYield = String(finalOutput.dropFirst(currentOutputBuffer.count - newStableText.count)) // Crude
                            if !remainingTextToYield.isEmpty {
                                continuation.yield(remainingTextToYield)
                            }
                            print("Stop phrase detected: '\(stopPhrase)'")
                            continuation.finish()
                            return
                        }
                    }
                    // After the loop, yield any remaining buffered tokens
                    let remainingText = try yieldBufferedText()
                    if !remainingText.isEmpty {
                        continuation.yield(remainingText)
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
        }
    }
    
    /// Extracts a stable, complete chunk of text from the fully detokenized string
    /// by comparing it with what has already been output.
    private func extractStableText(from fullDetokenized: String, previousOutput: String) -> String {
        guard fullDetokenized.count > previousOutput.count else { return "" }
        let newPart = String(fullDetokenized.dropFirst(previousOutput.count))
        
        // Simple heuristic: yield if a space, newline, or common punctuation is found
        // This is still simplified for a mock word-based tokenizer.
        // For subword tokenizers, a more complex algorithm (e.g., byte-pair encoding specific)
        // is needed to avoid yielding partial UTF-8 characters.
        if newPart.contains(" ") || newPart.contains("\n") || newPart.contains(".") || newPart.contains("!") || newPart.contains("?") || newPart.contains(",") {
            // Find the last stable point (e.g., end of a word or punctuation)
            if let lastSpace = newPart.lastIndex(of: " ") {
                let stableChunk = String(newPart[...lastSpace])
                // Update pendingTokensBuffer by removing tokens corresponding to stableChunk
                // This is the tricky part. For mock, we'll just return the chunk.
                return stableChunk
            } else if let lastPunctuation = newPart.lastIndex(where: { ".!?,:;".contains($0) }) {
                 let stableChunk = String(newPart[...lastPunctuation])
                 return stableChunk
            }
        }
        
        // If the buffer is getting too long without a natural break,
        // or if it's the end of the stream, yield it.
        // For this exercise, we prioritize natural breaks.
        return "" // Don't yield yet
    }

    /// Yields any remaining buffered text and clears the buffer.
    private func yieldBufferedText() throws -> String {
        guard !pendingTokensBuffer.isEmpty else { return "" }
        let finalDetokenized = tokenizer.detokenize(ids: pendingTokensBuffer)
        let newText = String(finalDetokenized.dropFirst(currentOutputBuffer.count))
        currentOutputBuffer += newText
        pendingTokensBuffer.removeAll()
        return newText
    }
}

// MARK: - Example Usage (combining with Exercise 1's model mock)

class MockMLXModelWithStreaming: MLXModelProtocol {
    let name: String = "Mock-Llama-7B"
    let eosTokenID: Int

    init(eosTokenID: Int) {
        self.eosTokenID = eosTokenID
    }

    func generate(
        promptTokens: MLXArray,
        maxTokens: Int,
        temperature: Float,
        tokenizer: TokenizerProtocol
    ) async throws -> AsyncThrowingStream<MLXArray, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                let mockResponses: [String: [String]] = [
                    "hello": ["Hello", "there", "!", "How", "can", "I", "assist", "you", "?"],
                    "tell me a joke": ["Why", "don't", "scientists", "trust", "atoms", "?", "Because", "they", "make", "up", "everything", "!", "\nUser:"], // Add stop phrase
                    "what is mlx": ["MLX", "is", "an", "array", "framework", "for", "Apple", "silicon", "."],
                    "long sentence": ["This", "is", "a", "very", "long", "sentence", "that", "will", "test", "the", "buffered", "detokenization", "logic", "."],
                    "another prompt": ["This", "is", "the", "AI", "response", ".\nAI END"] // Custom stop phrase
                ]

                guard let promptString = tokenizer.detokenize(ids: promptTokens.data.map { $0.item(Int.self)! }).lowercased() else {
                    continuation.finish(throwing: DetokenizationError.tokenizerFailed)
                    return
                }
                
                let responseWords = mockResponses.first { promptString.contains($0.key) }?.value ?? ["I'm", "not", "sure", "how", "to", "respond", "to", "that", "."]
                
                for word in responseWords {
                    try await Task.sleep(for: .milliseconds(50))
                    let tokenIDsForWord = tokenizer.tokenize(text: word)
                    for id in tokenIDsForWord {
                        continuation.yield(MLXArray(scalar: id))
                    }
                }
                
                try await Task.sleep(for: .milliseconds(50))
                continuation.yield(MLXArray(scalar: self.eosTokenID))
                
                continuation.finish()
            }
        }
    }
}

@available(iOS 18.0, macOS 14.0, *)
@Observable
class EnhancedChatViewModel {
    private var model: (any MLXModelProtocol)?
    private var tokenizer: (any TokenizerProtocol)?
    private var streamingDetokenizer: StreamingDetokenizer?
    
    var chatHistory: String = ""
    var currentInput: String = ""
    var isLoading: Bool = false
    var errorMessage: String?
    
    private let customStopPhrases = ["\nUser:", "\nAI END", "<|im_end|>"]
    
    init() {
        let mockVocab: [String: Int] = [
            "hello": 1, "there": 2, "!": 3, "How": 4, "can": 5, "I": 6, "assist": 7, "you": 8, "?": 9,
            "Why": 10, "don't": 11, "scientists": 12, "trust": 13, "atoms": 14, "Because": 15, "they": 16, "make": 17, "up": 18, "everything": 19,
            "MLX": 20, "is": 21, "an": 22, "array": 23, "framework": 24, "for": 25, "Apple": 26, "silicon": 27, ".": 28,
            "I'm": 29, "not": 30, "sure": 31, "how": 32, "to": 33, "respond": 34, "that": 35,
            "This": 36, "a": 37, "very": 38, "long": 39, "sentence": 40, "will": 41, "test": 42, "the": 43, "buffered": 44, "detokenization": 45, "logic": 46,
            "another": 47, "prompt": 48, "response": 49,
            "<|eos|>": 1000,
            "\nUser:": 1001, // Mock token for stop phrase
            "\nAI END": 1002 // Mock token for another stop phrase
        ]
        let eosTokenID = mockVocab["<|eos|>"]!
        self.tokenizer = MockTokenizer(vocab: mockVocab, eosTokenID: eosTokenID)
        self.model = MockMLXModelWithStreaming(eosTokenID: eosTokenID)
        self.streamingDetokenizer = StreamingDetokenizer(tokenizer: self.tokenizer!, stopPhrases: customStopPhrases)
    }

    func loadModelAndTokenizer() async {
        isLoading = true
        errorMessage = nil
        do {
            try await Task.sleep(for: .seconds(1)) // Simulate loading
            guard self.model != nil && self.tokenizer != nil else {
                throw ChatError.modelLoadingFailed("Failed to initialize mock model/tokenizer.")
            }
            print("Model and tokenizer loaded successfully.")
        } catch {
            errorMessage = error.localizedDescription
            print("Error loading model/tokenizer: \(error.localizedDescription)")
        }
        isLoading = false
    }
    
    @MainActor
    func sendMessage() async {
        guard !currentInput.isEmpty else { return }
        guard let model = self.model, let tokenizer = self.tokenizer, let streamingDetokenizer = self.streamingDetokenizer else {
            errorMessage = "Model, tokenizer, or detokenizer not loaded."
            return
        }

        let userPrompt = currentInput
        chatHistory += "You: \(userPrompt)\n"
        currentInput = ""
        
        chatHistory += "AI: "
        
        do {
            let promptTokens = tokenizer.tokenize(text: userPrompt)
            let mlxPrompt = MLXArray(promptTokens)
            
            let rawTokenStream = try await model.generate(
                promptTokens: mlxPrompt,
                maxTokens: 200,
                temperature: 0.7,
                tokenizer: tokenizer
            )
            
            let processedTextStream = streamingDetokenizer.process(tokenIDStream: rawTokenStream)
            
            for try await chunk in processedTextStream {
                chatHistory += chunk
                print("Streamed (processed): \(chunk)")
            }
            
            // The streamingDetokenizer handles the newline and stop phrases
            // If a stop phrase was found and removed, the chatHistory might not end with it.
            // Add a newline if not already present.
            if !chatHistory.hasSuffix("\n") {
                chatHistory += "\n"
            }
            print("AI response finished.")

        } catch {
            errorMessage = "Inference error: \(error.localizedDescription)"
            chatHistory += "Error: \(error.localizedDescription)\n"
            print("Error during inference: \(error.localizedDescription)")
        }
    }
}

// MARK: - Conceptual Usage

@available(iOS 18.0, macOS 14.0, *)
@MainActor
func runEnhancedChatExample() {
    let viewModel = EnhancedChatViewModel()
    
    Task {
        await viewModel.loadModelAndTokenizer()
    }

    Task {
        try await Task.sleep(for: .seconds(2))
        print("\n--- Simulating User Input (Enhanced) ---")
        
        viewModel.currentInput = "Long sentence"
        await viewModel.sendMessage()
        
        try await Task.sleep(for: .seconds(5))
        
        viewModel.currentInput = "Tell me a joke" // Contains "\nUser:" stop phrase
        await viewModel.sendMessage()
        
        try await Task.sleep(for: .seconds(8))

        viewModel.currentInput = "Another prompt" // Contains "\nAI END" stop phrase
        await viewModel.sendMessage()

        try await Task.sleep(for: .seconds(8))
        
        print("\n--- Final Enhanced Chat History ---")
        print(viewModel.chatHistory)
        if let error = viewModel.errorMessage {
            print("Error: \(error)")
        }
    }
}

// Call this to run the conceptual example
// runEnhancedChatExample()
