
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import UIKit
import Vision
import CoreImage
import CoreImage.CIFilterBuiltins // For easier access to filters

/// @available(iOS 18.0, *) ensures this code is only used on platforms supporting
/// modern Swift concurrency features and potentially newer Vision/Core Image APIs.
/// This approach ensures forward compatibility and leverages the latest SDK capabilities.
@available(iOS 18.0, *)
enum WhiteboardScannerError: Error, LocalizedError {
    case invalidInputImage
    case visionRequestFailed(Error)
    case noRectanglesDetected
    case failedToCreateCIImage
    case failedToApplyPerspectiveCorrection
    case failedToRenderOutputImage
    case invalidRectangleObservationPoints

    var errorDescription: String? {
        switch self {
        case .invalidInputImage:
            return "The input image was invalid or could not be processed."
        case .visionRequestFailed(let error):
            return "Vision rectangle detection failed: \(error.localizedDescription)"
        case .noRectanglesDetected:
            return "No prominent rectangles (whiteboards) were detected in the image."
        case .failedToCreateCIImage:
            return "Failed to create a Core Image from the input image."
        case .failedToApplyPerspectiveCorrection:
            return "Failed to apply perspective correction using Core Image."
        case .failedToRenderOutputImage:
            return "Failed to render the corrected Core Image to a UIImage."
        case .invalidRectangleObservationPoints:
            return "Detected rectangle observation had invalid corner points for correction."
        }
    }
}

/// `WhiteboardScanner` is a utility class responsible for detecting and correcting
/// the perspective of whiteboards or documents within an image.
/// It uses `VNDetectRectanglesRequest` for detection and `CIPerspectiveCorrection`
/// from Core Image for transformation.
@available(iOS 18.0, *)
class WhiteboardScanner {

    // MARK: - Properties

    /// A Core Image context for rendering. Initialized lazily for performance.
    /// Using a single `CIContext` for multiple operations can be more efficient.
    private lazy var ciContext: CIContext = {
        // Options can be configured for performance (e.g., .useSoftwareRenderer, .priorityRequestLow)
        // For most cases, the default options are sufficient.
        return CIContext(options: nil)
    }()

    // MARK: - Public API

    /// Scans an input `UIImage` to detect a prominent rectangle (e.g., a whiteboard or document),
    /// corrects its perspective, and returns the rectified image.
    ///
    /// - Parameter image: The `UIImage` to be scanned.
    /// - Returns: A `UIImage` representing the perspective-corrected whiteboard content.
    /// - Throws: `WhiteboardScannerError` if detection or correction fails at any stage.
    public func scanWhiteboard(from image: UIImage) async throws -> UIImage {
        // 1. Input Validation and CGImage Conversion
        guard let cgImage = image.cgImage else {
            throw WhiteboardScannerError.invalidInputImage
        }

        // 2. Vision Request Setup
        let request = VNDetectRectanglesRequest()
        // Configure the request for optimal whiteboard detection:
        // - minimumAspectRatio and maximumAspectRatio help filter out non-rectangular shapes or highly distorted ones.
        //   A whiteboard is typically close to a 4:3 or 16:9 aspect ratio.
        request.minimumAspectRatio = 0.5 // Allow for portrait (1:2) or landscape (2:1)
        request.maximumAspectRatio = 2.0
        request.quadratureTolerance = 10.0 // How much deviation from perfect 90-degree corners is allowed.
        request.minimumSize = 0.3 // Minimum size of the detected rectangle as a fraction of the image's smaller dimension.
        request.maximumObservations = 5 // Limit the number of observations to process.

        // 3. Asynchronous Request Execution
        // Use a Task to perform the Vision request asynchronously.
        let observations: [VNRectangleObservation] = try await withCheckedThrowingContinuation { continuation in
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            do {
                try handler.perform([request])
                // Vision requests return results in the 'results' property of the request object.
                if let results = request.results as? [VNRectangleObservation] {
                    continuation.resume(returning: results)
                } else {
                    continuation.resume(returning: [])
                }
            } catch {
                continuation.resume(throwing: WhiteboardScannerError.visionRequestFailed(error))
            }
        }

        // 4. Result Filtering & Selection
        guard let bestObservation = observations.sorted(by: { $0.confidence > $1.confidence }).first else {
            throw WhiteboardScannerError.noRectanglesDetected
        }
        
        // Ensure all corner points are valid before proceeding
        guard let topLeft = bestObservation.topLeft,
              let topRight = bestObservation.topRight,
              let bottomRight = bestObservation.bottomRight,
              let bottomLeft = bestObservation.bottomLeft else {
            throw WhiteboardScannerError.invalidRectangleObservationPoints
        }

        // 5. Coordinate Conversion
        // Vision coordinates are normalized (0.0 to 1.0) with origin at bottom-left.
        // Core Image expects pixel coordinates with origin at bottom-left.
        let imageSize = image.size
        let imageRect = CGRect(origin: .zero, size: imageSize)

        // Helper to convert Vision normalized point to Core Image pixel point (bottom-left origin)
        func convertVisionPointToCIPoint(_ visionPoint: CGPoint) -> CGPoint {
            // Vision's Y-axis is inverted relative to UIKit's Y-axis (top-left origin).
            // Core Image (CIImage) also uses bottom-left origin, so we need to flip Y.
            return VNImagePointForNormalizedPoint(visionPoint, Int(imageSize.width), Int(imageSize.height))
        }

        let ciTopLeft = convertVisionPointToCIPoint(topLeft)
        let ciTopRight = convertVisionPointToCIPoint(topRight)
        let ciBottomRight = convertVisionPointToCIPoint(bottomRight)
        let ciBottomLeft = convertVisionPointToCIPoint(bottomLeft)

        // 6. Perspective Correction with Core Image
        guard let ciImage = CIImage(cgImage: cgImage) else {
            throw WhiteboardScannerError.failedToCreateCIImage
        }

        let perspectiveCorrectionFilter = CIFilter.perspectiveCorrection()
        perspectiveCorrectionFilter.inputImage = ciImage
        perspectiveCorrectionFilter.topLeft = CIVector(cgPoint: ciTopLeft)
        perspectiveCorrectionFilter.topRight = CIVector(cgPoint: ciTopRight)
        perspectiveCorrectionFilter.bottomRight = CIVector(cgPoint: ciBottomRight)
        perspectiveCorrectionFilter.bottomLeft = CIVector(cgPoint: ciBottomLeft)

        guard let outputCIImage = perspectiveCorrectionFilter.outputImage else {
            throw WhiteboardScannerError.failedToApplyPerspectiveCorrection
        }

        // 7. Output Generation
        // Determine the output extent (bounding box) of the corrected image.
        // The perspective correction filter often changes the image's extent.
        let outputExtent = outputCIImage.extent

        guard let outputCGImage = ciContext.createCGImage(outputCIImage, from: outputExtent) else {
            throw WhiteboardScannerError.failedToRenderOutputImage
        }

        // UIImage's initializer handles orientation correctly when created from CGImage.
        return UIImage(cgImage: outputCGImage)
    }
}

// MARK: - Example Usage (for demonstration)

// This section shows how you might integrate the WhiteboardScanner into an app.
// In a real app, this would be part of a ViewController or SwiftUI View.
@available(iOS 18.0, *)
class ExampleAppIntegration {
    let scanner = WhiteboardScanner()

    /// Simulates processing an image, perhaps from a photo library or camera.
    /// - Parameter inputImage: The image to process.
    func processImageForWhiteboard(inputImage: UIImage) {
        Task {
            do {
                print("Starting whiteboard scan...")
                let correctedImage = try await scanner.scanWhiteboard(from: inputImage)
                print("Whiteboard scan successful! Corrected image size: \(correctedImage.size)")
                // In a real app, you would now display `correctedImage` in an `UIImageView`
                // or pass it to another processing step (e.g., OCR).
                // Example:
                // DispatchQueue.main.async {
                //    self.imageView.image = correctedImage
                // }
            } catch {
                if let scannerError = error as? WhiteboardScannerError {
                    print("Whiteboard scan failed: \(scannerError.localizedDescription)")
                } else {
                    print("An unexpected error occurred: \(error.localizedDescription)")
                }
                // Handle error in UI, e.g., show an alert
            }
        }
    }

    /// Placeholder for a UIImage (e.g., from asset catalog or camera).
    /// In a real app, you'd load a specific image.
    func getSampleImage() -> UIImage? {
        // For demonstration, let's assume we have an image named "whiteboard_sample"
        // in the asset catalog. Replace with actual image loading in your app.
        // If running in a Playground, you might use UIImage(named: "image.jpg", in: Bundle.main, compatibleWith: nil)
        // or load from a URL.
        return UIImage(systemName: "doc.text.image")? // A placeholder system icon
            .withTintColor(.systemBlue, renderingMode: .alwaysOriginal)
            .withConfiguration(UIImage.SymbolConfiguration(pointSize: 100, weight: .regular))
            .sd_resizedImage(with: CGSize(width: 800, height: 600)) // Assuming some image data
    }
}

// MARK: - UIImage Extension for a quick mock image (if not running in a real app context)
// This is purely for making the example runnable without an actual image asset.
// In a real app, you would load a proper image.
@available(iOS 18.0, *)
extension UIImage {
    // A simple way to create a mock image for demonstration purposes
    func sd_resizedImage(with newSize: CGSize) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        self.draw(in: CGRect(origin: .zero, size: newSize))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage
    }
}
