
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import Foundation

// Ensure the Python server from the problem description is running on port 8080
// with the path '/ai/code-stream'

// MARK: - Decodable Models (re-using from Exercise 2, or simplified)
struct AICodeChunk: Decodable {
    let id: String?
    let object: String?
    let choices: [Choice]?

    struct Choice: Decodable {
        let index: Int
        let delta: Delta
    }

    struct Delta: Decodable {
        let content: String?
    }
}

// MARK: - SwiftUI View
struct AICodeAssistantView: View {
    @State private var prompt: String = ""
    @State private var suggestedCode: String = ""
    @State private var errorMessage: String?
    @State private var isLoading: Bool = false

    // State for debouncing UI updates
    @State private var bufferedCodeUpdates: String = ""
    private let debounceInterval: Duration = .milliseconds(100) // Update UI every 100ms

    // Task for the streaming operation, allowing cancellation
    @State private var streamingTask: Task<Void, Never>?

    private let streamURL = URL(string: "http://localhost:8080/ai/code-stream")!

    var body: some View {
        VStack(alignment: .leading) {
            Text("AI Code Assistant")
                .font(.largeTitle)
                .padding(.bottom, 5)

            TextField("Enter your code prompt...", text: $prompt)
                .textFieldStyle(.roundedBorder)
                .padding(.bottom, 10)
                .onChange(of: prompt) { oldValue, newValue in
                    // Cancel previous streaming task if prompt changes
                    streamingTask?.cancel()
                    // Optionally, trigger new stream on change after a debounce
                    // For this exercise, we'll use a button for explicit trigger.
                }

            TextEditor(text: $suggestedCode)
                .font(.body)
                .frame(minHeight: 200, maxHeight: .infinity)
                .border(Color.secondary, width: 1)
                .cornerRadius(5)
                .padding(.bottom, 10)
                .scrollContentBackground(.hidden) // Make TextEditor background transparent

            HStack {
                Button("Get Suggestion") {
                    startStreaming()
                }
                .buttonStyle(.borderedProminent)
                .disabled(isLoading || prompt.isEmpty)

                Button("Cancel") {
                    streamingTask?.cancel()
                    isLoading = false
                    errorMessage = "Streaming cancelled by user."
                }
                .buttonStyle(.bordered)
                .disabled(!isLoading)
            }
            .padding(.bottom, 10)

            if let errorMessage = errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
            }
            Spacer()
        }
        .padding()
    }

    private func startStreaming() {
        // Cancel any existing task before starting a new one
        streamingTask?.cancel()
        suggestedCode = ""
        bufferedCodeUpdates = ""
        errorMessage = nil
        isLoading = true

        streamingTask = Task {
            await fetchAndStreamCode()
        }
    }

    @MainActor
    private func fetchAndStreamCode() async {
        do {
            let (bytes, response) = try await URLSession.shared.bytes(for: URLRequest(url: streamURL))

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                errorMessage = "Server responded with an unexpected status code."
                isLoading = false
                return
            }

            // Task for debouncing UI updates
            let uiUpdateTask = Task {
                while !Task.isCancelled {
                    try? await Task.sleep(for: debounceInterval)
                    // Ensure updates are on MainActor
                    await MainActor.run {
                        if !bufferedCodeUpdates.isEmpty {
                            suggestedCode.append(bufferedCodeUpdates)
                            bufferedCodeUpdates = ""
                        }
                    }
                }
            }

            for await line in bytes.lines {
                // Check for cancellation at each iteration
                try Task.checkCancellation()

                guard !line.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { continue }

                if let data = line.data(using: .utf8) {
                    do {
                        let chunk = try JSONDecoder().decode(AICodeChunk.self, from: data)
                        if let content = chunk.choices?.first?.delta.content {
                            // Append to buffer, not directly to UI
                            bufferedCodeUpdates.append(content)
                        }
                    } catch let decodingError as DecodingError {
                        print("JSON Decoding Error: \(decodingError)")
                        // Log but don't stop the stream for individual malformed chunks
                    }
                }
            }
            
            // After stream finishes, ensure any remaining buffered content is displayed
            await MainActor.run {
                if !bufferedCodeUpdates.isEmpty {
                    suggestedCode.append(bufferedCodeUpdates)
                    bufferedCodeUpdates = ""
                }
            }
            isLoading = false
            print("Code stream finished successfully.")
            uiUpdateTask.cancel() // Cancel the UI update task when streaming finishes

        } catch is CancellationError {
            print("Streaming task cancelled.")
            errorMessage = "Streaming cancelled."
            isLoading = false
        } catch URLError.notConnectedToInternet {
            errorMessage = "No internet connection."
            isLoading = false
        } catch URLError.cannotConnectToHost {
            errorMessage = "Could not connect to the server. Is the Python server running on \(streamURL.absoluteString)?"
            isLoading = false
        } catch {
            errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
            isLoading = false
        }
    }
}
