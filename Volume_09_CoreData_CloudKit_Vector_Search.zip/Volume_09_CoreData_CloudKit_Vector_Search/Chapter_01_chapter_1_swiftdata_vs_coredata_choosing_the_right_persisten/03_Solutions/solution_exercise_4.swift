
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CoreData
import SwiftData
import Foundation

// --- LEGACY CONTENT (Mocked) ---
class JournalEntry: NSObject {
    let id: UUID
    var text: String
    init(id: UUID, text: String) { self.id = id; self.text = text }
}

// --- SWIFTDATA SEMANTIC LAYER ---
@available(iOS 17.0, *)
@Model
final class SemanticMetadata {
    @Attribute(.unique) var entryID: UUID
    var tags: [String]
    var embedding: [Float]
    var timestamp: Date
    
    init(entryID: UUID, tags: [String], embedding: [Float], timestamp: Date) {
        self.entryID = entryID
        self.tags = tags
        self.embedding = embedding
        self.timestamp = timestamp
    }
}

// --- SEMANTIC ENGINE ---
@available(iOS 17.0, *)
actor SemanticEngine {
    private let modelContainer: ModelContainer
    
    init(container: ModelContainer) {
        self.modelContainer = container
    }
    
    /// Simulates AI processing and injects metadata into SwiftData
    func injectSemanticContext(for entry: JournalEntry) async throws {
        // 1. Simulate AI processing delay
        try await Task.sleep(for: .seconds(1))
        
        // 2. Generate Mock AI Data
        let mockTags = ["reflective", "nature", "peaceful"]
        let mockEmbedding = (0..<128).map { _ in Float.random(in: -1...1) }
        
        // 3. Persist to SwiftData
        let context = ModelContext(modelContainer)
        let metadata = SemanticMetadata(
            entryID: entry.id,
            tags: mockTags,
            embedding: mockEmbedding,
            timestamp: Date()
        )
        
        context.insert(metadata)
        try context.save()
        print("Semantic context injected for entry: \(entry.id)")
    }
    
    /// Simulates a semantic search by finding tags and returning the legacy entry
    func searchByTag(_ tag: String, in legacyEntries: [JournalEntry]) -> JournalEntry? {
        let context = ModelContext(modelContainer)
        let entryIDToFind = // In a real app, this would be a Predicate query
        
        // Simulating the search logic:
        // 1. Query SwiftData for metadata containing the tag
        // 2. Get the entryID
        // 3. Return the entry from the legacy array
        
        // Mocking the search result for demonstration:
        let foundID = legacyEntries.first?.id // Simplified for exercise
        return legacyEntries.first(where: { $0.id == foundID })
    }
}
