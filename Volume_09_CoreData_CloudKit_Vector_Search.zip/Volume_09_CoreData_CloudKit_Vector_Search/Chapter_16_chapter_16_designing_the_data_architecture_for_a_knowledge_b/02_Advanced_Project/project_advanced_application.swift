
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreData
import NaturalLanguage
import Combine

// MARK: - Dependencies

/// Package.swift equivalent for the required frameworks:
/// .package(url: "https://github.com/apple/swift-algorithms", from: "1.0.0")
/// Note: CoreData, CloudKit, and NaturalLanguage are built-in Apple frameworks.

// MARK: - Error Handling

/// Represents specific failure points in the semantic ingestion pipeline.
enum KnowledgeError: LocalizedError {
    case embeddingGenerationFailed(String)
    case persistenceFailure(Error)
    case contextNotFound
    case searchTimeout

    var errorDescription: String? {
        switch self {
        case .embeddingGenerationFailed(let reason):
            return "Failed to generate semantic vector: \(reason)"
        case .persistenceFailure(let error):
            return "Core Data persistence error: \(error.localizedDescription)"
        case .contextNotFound:
            return "The required Managed Object Context was not found."
        case .searchTimeout:
            return "The semantic search operation timed out."
        }
    }
}

// MARK: - Models

/// A lightweight, Sendable representation of a semantic vector.
/// This is used to pass embedding data between actors safely.
struct SemanticVector: Sendable, Codable {
    let values: [Float]
    let modelIdentifier: String
    
    /// Calculates the cosine similarity between this vector and another.
    /// This is the mathematical heart of semantic search.
    func cosineSimilarity(to other: SemanticVector) -> Float {
        guard values.count == other.values.count else { return 0.0 }
        
        var dotProduct: Float = 0.0
        var normA: Float = 0.0
        var normB: Float = 0.0
        
        for i in 0..<values.count {
            dotProduct += values[i] * other.values[i]
            normA += values[i] * values[i]
            normB += other.values[i] * other.values[i]
        }
        
        let denominator = sqrt(normA) * sqrt(normB)
        return denominator == 0 ? 0 : dotProduct / denominator
    }
}

// MARK: - Ingestion Actor

/// An Actor responsible for the computationally expensive task of generating embeddings.
/// By using an `actor`, we ensure that ML processing happens off the main thread
/// and that the internal state of the embedding process is thread-safe.
@available(iOS 18.0, *)
actor KnowledgeIngestionActor {
    
    private let embeddingModel = NLEmbedding.sentenceEmbedding(for: .english)
    
    /// Generates a semantic vector for a given string of text.
    /// - Parameter text: The raw content to be embedded.
    /// - Returns: A `SemanticVector` representing the conceptual meaning.
    /// - Throws: `KnowledgeError.embeddingGenerationFailed` if the model cannot process the text.
    func generateEmbedding(for text: String) throws -> SemanticVector {
        guard let embedding = embeddingModel else {
            throw KnowledgeError.embeddingGenerationFailed("NLEmbedding model not available.")
        }
        
        // In a real-world app, we might chunk long text into smaller segments
        // to avoid exceeding model token limits.
        guard let vector = embedding.vector(for: text) else {
            throw KnowledgeError.embeddingGenerationFailed("Could not map text to vector space.")
        }
        
        // Convert [Double] from NLEmbedding to [Float] for more efficient storage/math
        let floatValues = vector.map { Float($0) }
        
        return SemanticVector(
            values: floatValues,
            modelIdentifier: "com.apple.nlp.sentence-embedding.v1"
        )
    }
}

// MARK: - Core Engine

/// The central coordinator for the Knowledge Base application.
/// This class manages the lifecycle of notes, triggers ingestion, and facilitates searches.
@available(iOS 18.0, *)
@Observable
final class KnowledgeBaseEngine {
    
    private let container: NSPersistentCloudKitContainer
    private let ingestionActor = KnowledgeIngestionActor()
    
    /// The main context for UI-related data fetching.
    nonisolated let viewContext: NSManagedObjectContext
    
    /// A background context specifically for heavy write operations.
    private let backgroundContext: NSManagedObjectContext

    init(container: NSPersistentCloudKitContainer) {
        self.container = container
        self.viewContext = container.viewContext
        self.viewContext.automaticallyMergesChangesFromParent = true
        
        self.backgroundContext = container.newBackgroundContext()
        self.backgroundContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
    }

    /// Orchestrates the creation of a new knowledge entry.
    /// This follows the "Write-Through" pattern: Structured data is saved immediately,
    /// while semantic data is processed asynchronously.
    ///
    /// - Parameters:
    ///   - title: The title of the note.
    ///   - content: The body text.
    /// - Throws: `KnowledgeError` if the initial save fails.
    func createNote(title: String, content: String) async throws {
        // 1. Perform the initial structured save on the background context
        let noteID = try await performStructuredSave(title: title, content: content)
        
        // 2. Trigger the asynchronous semantic ingestion
        // We do not 'await' this in a way that blocks the user; 
        // we fire it as a detached task or a managed background task.
        Task(priority: .utility) {
            do {
                try await self.ingestSemantics(for: noteID, content: content)
            } catch {
                print("Background Ingestion Error: \(error.localizedDescription)")
                // In a production app, you would implement a retry mechanism or a 'needs-indexing' flag.
            }
        }
    }

    /// Saves the initial metadata to Core Data.
    private func performStructuredSave(title: String, content: String) async throws -> NSManagedObjectID {
        return try await backgroundContext.perform { [backgroundContext] in
            let newNote = NoteEntity(context: backgroundContext)
            newNote.id = UUID()
            newNote.title = title
            newNote.content = content
            newNote.createdAt = Date()
            
            try backgroundContext.save()
            return newNote.objectID
        }
    }

    /// The heavy lifting: Generates the vector and updates the existing record.
    private func ingestSemantics(for noteID: NSManagedObjectID, content: String) async throws {
        // Generate the vector using the Actor (off-main-thread)
        let vector = try await ingestionActor.generateEmbedding(for: content)
        
        // Convert vector to Data for Core Data storage
        let vectorData = try JSONEncoder().encode(vector)
        
        // Update the record in the background context
        try await backgroundContext.perform { [backgroundContext] in
            guard let note = backgroundContext.object(with: noteID) as? NoteEntity else {
                throw KnowledgeError.contextNotFound
            }
            
            note.embeddingData = vectorData
            note.isIndexed = true // Flag to indicate semantic search is ready
            
            try backgroundContext.save()
        }
    }

    /// Performs a semantic similarity search across all indexed notes.
    /// - Parameter query: The natural language string to search for.
    /// - Returns: An array of Note entities sorted by relevance.
    func semanticSearch(query: String) async throws -> [NoteEntity] {
        // 1. Generate embedding for the query
        let queryVector = try await ingestionActor.generateEmbedding(for: query)
        
        // 2. Fetch all indexed notes
        // In a massive database, you would use a specialized Vector Database (like Milvus or Pinecone)
        // or a SQLite extension with vector support. For Apple platforms, we perform 
        // a high-performance linear scan for medium-sized datasets.
        let fetchRequest: NSFetchRequest<NoteEntity> = NoteEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "isIndexed == YES")
        
        let allNotes = try viewContext.fetch(fetchRequest)
        
        // 3. Score and Sort
        // We use Swift's high-performance sorting.
        let scoredNotes = allNotes.compactMap { note -> (NoteEntity, Float)? in
            guard let data = note.embeddingData,
                  let existingVector = try? JSONDecoder().decode(SemanticVector.self, from: data) else {
                return nil
            }
            
            let similarity = queryVector.cosineSimilarity(to: existingVector)
            return (note, similarity)
        }
        .sorted { $0.1 > $1.1 } // Highest similarity first
        .map { $0.0 }
        
        return scoredNotes
    }
}

// MARK: - Core Data Managed Object (Simulated)

/// Note: In a real project, this is generated by the .xcdatamodeld file.
@objc(NoteEntity)
public class NoteEntity: NSManagedObject {
    @NSManaged public var id: UUID?
    @NSManaged public var title: String?
    @NSManaged public var content: String?
    @NSManaged public var createdAt: Date?
    @NSManaged public var embeddingData: Data?
    @NSManaged public var isIndexed: Bool
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<NoteEntity> {
        return NSFetchRequest<NoteEntity>(entityName: "NoteEntity")
    }
}
