
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import Foundation

// @available(iOS 18.0, *) // Or macOS 15.0, watchOS 11.0, tvOS 18.0
// func exampleMLXArrayCreation() {
let scalar = MLXArray(10.0) // A 0-dimensional tensor (scalar)
print("Scalar: \(scalar), Shape: \(scalar.shape)") // Output: Scalar: array(10.0, ), Shape: []

let vector = MLXArray([1.0, 2.0, 3.0]) // A 1-dimensional tensor (vector)
print("Vector: \(vector), Shape: \(vector.shape)") // Output: Vector: array([1., 2., 3.], ), Shape: [3]

let matrix = MLXArray([[1.0, 2.0], [3.0, 4.0]]) // A 2-dimensional tensor (matrix)
print("Matrix: \(matrix), Shape: \(matrix.shape)") // Output: Matrix: array([[1., 2.], [3., 4.]], ), Shape: [2, 2]

let largeArray = MLXArray.rand([2, 3, 4]) // Random 3D tensor
print("Large Array Shape: \(largeArray.shape)") // Output: Large Array Shape: [2, 3, 4]

// MLXArray directly leverages Unified Memory.
// The data for `largeArray` is allocated once and accessible by both CPU and GPU.
// No explicit copies are needed when performing operations that might switch device context.
// }
