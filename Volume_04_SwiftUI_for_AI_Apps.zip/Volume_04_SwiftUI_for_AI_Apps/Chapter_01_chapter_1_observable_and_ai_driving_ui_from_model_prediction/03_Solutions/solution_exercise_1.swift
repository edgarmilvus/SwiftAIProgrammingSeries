
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI

// MARK: - 1. Define AI Status
@available(iOS 18.0, *)
enum AIStatus: String, CaseIterable, Identifiable {
    case idle = "Idle"
    case thinking = "Thinking..."
    case typing = "Typing a response..."

    var id: String { self.rawValue }
    
    var displayColor: Color {
        switch self {
        case .idle: return .gray
        case .thinking: return .orange
        case .typing: return .blue
        }
    }
}

// MARK: - 2. Create an Observable AI Manager
@available(iOS 18.0, *)
@Observable
class AIAssistantManager {
    var status: AIStatus = .idle

    /// Cycles the AI status to the next logical state.
    func cycleStatus() {
        let allStatuses = AIStatus.allCases
        if let currentIndex = allStatuses.firstIndex(of: status) {
            let nextIndex = (currentIndex + 1) % allStatuses.count
            status = allStatuses[nextIndex]
        }
    }
}

// MARK: - 3. Build the SwiftUI View
@available(iOS 18.0, *)
struct AIAssistantStatusView: View {
    // Instantiate AIAssistantManager using @State for ownership
    @State private var assistantManager = AIAssistantManager()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("AI Assistant Status")
                .font(.largeTitle)
                .bold()
                .padding(.bottom, 10)
            
            // Display the status property
            Text(assistantManager.status.rawValue)
                .font(.title)
                .foregroundColor(assistantManager.status.displayColor)
                .animation(.easeInOut, value: assistantManager.status) // Smooth transition
            
            // Button to cycle through statuses
            Button("Cycle AI Status") {
                assistantManager.cycleStatus()
            }
            .padding()
            .background(Color.accentColor)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.white.opacity(0.05).ignoresSafeArea())
    }
}

// MARK: - Preview Provider (for demonstration, not part of the solution requirement)
/*
@available(iOS 18.0, *)
#Preview {
    AIAssistantStatusView()
}
*/
