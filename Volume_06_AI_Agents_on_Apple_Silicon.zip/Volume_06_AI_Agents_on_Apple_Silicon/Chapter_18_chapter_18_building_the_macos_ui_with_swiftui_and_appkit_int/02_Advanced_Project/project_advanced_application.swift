
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// MARK: - Swift Package Manager Dependencies
// This Package.swift snippet defines the dependencies for our project.
// In a real-world scenario for local LLMs, 'llama.cpp' Swift bindings
// would typically be integrated either as a direct C++ dependency
// wrapped with a Swift package, or via a pre-built XCFramework.
// For this example, we'll simulate a 'LLamaKit' package.

// swift-tools-version:6.0
import PackageDescription

let package = Package(
    name: "IntelligentDocumentAssistant",
    platforms: [
        .macOS(.v14) // Requires macOS 14.0 for @Observable and modern SwiftUI features
    ],
    products: [
        .library(
            name: "IntelligentDocumentAssistant",
            targets: ["IntelligentDocumentAssistant"]),
    ],
    dependencies: [
        // Hypothetical dependency for local LLM inference.
        // In a real project, this might be a wrapper around llama.cpp,
        // or a custom framework for specific Apple Silicon optimizations.
        .package(url: "https://github.com/example/LLamaKit.git", from: "1.0.0"),
        // Other potential dependencies like a Markdown parser, etc.
    ],
    targets: [
        .target(
            name: "IntelligentDocumentAssistant",
            dependencies: [
                .product(name: "LLamaKit", package: "LLamaKit")
            ]),
        .testTarget(
            name: "IntelligentDocumentAssistantTests",
            dependencies: ["IntelligentDocumentAssistant"]),
    ]
)

// MARK: - Application Component Code

import SwiftUI
import AppKit // Required for NSViewRepresentable and AppKit specific types like NSOpenPanel
import Foundation // For URL, Data, String operations
import UniformTypeIdentifiers // For UTType

/// @available annotation for macOS 14.0, as `@Observable` and some SwiftUI features
/// used here are available from this version.
@available(macOS 14.0, *)
enum DocumentAssistantError: Error, LocalizedError {
    case fileReadError(URL, Error)
    case unsupportedFileType(URL)
    case llmInferenceFailed(String)
    case noDocumentLoaded

    var errorDescription: String? {
        switch self {
        case .fileReadError(let url, let error):
            return "Failed to read file at \(url.lastPathComponent): \(error.localizedDescription)"
        case .unsupportedFileType(let url):
            return "Unsupported file type for \(url.lastPathComponent). Please select a text file."
        case .llmInferenceFailed(let message):
            return "AI analysis failed: \(message)"
        case .noDocumentLoaded:
            return "No document is currently loaded for analysis."
        }
    }
}

/// A simplified service to simulate local LLM inference.
/// In a real application, this would interact with a llama.cpp Swift binding
/// or a custom inference pipeline.
@available(macOS 14.0, *)
actor LLMInferenceService {
    /// Simulates loading an LLM model.
    /// - Returns: A boolean indicating success.
    func loadModel() async throws -> Bool {
        // In a real scenario, this would load the model weights into memory
        // and initialize the llama.cpp context. This can be time-consuming.
        try await Task.sleep(for: .seconds(0.5)) // Simulate loading time
        print("LLM Model loaded successfully (simulated).")
        return true
    }

    /// Simulates performing an AI analysis on the given text.
    /// This method runs on a background actor, off the main thread.
    /// - Parameter text: The document content to analyze.
    /// - Returns: A string representing the AI's analysis.
    /// - Throws: `DocumentAssistantError.llmInferenceFailed` if analysis fails.
    func analyzeDocument(text: String) async throws -> String {
        guard text.count > 10 else {
            throw DocumentAssistantError.llmInferenceFailed("Document too short for meaningful analysis.")
        }
        
        // Simulate a complex LLM inference operation.
        // This would involve tokenization, running the model, and decoding.
        try await Task.sleep(for: .seconds(3)) // Simulate inference time

        let words = text.split(separator: " ").prefix(20).joined(separator: " ")
        let summary = "AI Summary (simulated): This document primarily discusses topics related to '\(words)...'. Key entities identified include 'Apple Silicon', 'SwiftUI', and 'AppKit Integration'. The overall sentiment appears to be positive towards modern development practices."
        
        if Bool.random() { // Simulate occasional failure
            return summary
        } else {
            throw DocumentAssistantError.llmInferenceFailed("Internal model error during processing.")
        }
    }
}

/// A SwiftUI `NSViewRepresentable` to wrap an `NSTextView`.
/// This allows us to use the powerful text rendering capabilities of AppKit's `NSTextView`
/// within a SwiftUI view hierarchy.
@available(macOS 14.0, *)
struct DocumentTextView: NSViewRepresentable {
    @Binding var text: String
    var isEditable: Bool = false
    var font: NSFont = .systemFont(ofSize: 14)

    /// Creates the `NSTextView` instance. This is called once by SwiftUI.
    func makeNSView(context: Context) -> NSScrollView {
        let scrollView = NSTextView.scrollableTextView()
        let textView = scrollView.documentView as! NSTextView
        
        textView.isEditable = isEditable
        textView.isSelectable = true
        textView.usesAdaptiveColorMappingForSmartInsertions = true // Modern macOS text features
        textView.textContainerInset = NSSize(width: 10, height: 10) // Padding
        textView.font = font
        textView.string = text
        
        // Optionally, add a delegate for advanced interactions (e.g., text changes)
        // textView.delegate = context.coordinator

        return scrollView
    }

    /// Updates the `NSTextView` when the `text` binding changes.
    func updateNSView(_ nsView: NSScrollView, context: Context) {
        // Ensure we update the text view if the bound text changes.
        // We cast back to NSTextView from the scroll view's documentView.
        if let textView = nsView.documentView as? NSTextView {
            if textView.string != text { // Prevent unnecessary updates and cursor jumps
                textView.string = text
            }
            textView.font = font // Allow font to be updated
            textView.isEditable = isEditable
        }
    }

    /// Creates a Coordinator for handling delegates (if needed).
    /// For this simple display, a coordinator isn't strictly necessary,
    /// but it's good practice to include the `makeCoordinator` method.
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, NSTextViewDelegate {
        var parent: DocumentTextView

        init(_ parent: DocumentTextView) {
            self.parent = parent
        }

        // Example delegate method:
        // func textDidChange(_ notification: Notification) {
        //     if let textView = notification.object as? NSTextView {
        //         parent.text = textView.string // Update SwiftUI binding on text change
        //     }
        // }
    }
}

/// The observable model for our document assistant, holding all relevant state.
/// Using `@Observable` for efficient and modern state management.
@available(macOS 14.0, *)
@Observable
class DocumentModel {
    var documentContent: String = "Load a text document to see its content here."
    var documentTitle: String = "No Document Loaded"
    var aiAnalysisResult: String = "AI analysis will appear here after processing a document."
    var isLoadingDocument: Bool = false
    var isAnalyzingDocument: Bool = false
    var errorMessage: String?
    
    private let llmService = LLMInferenceService()

    init() {
        // Pre-load the LLM model on app launch, or first use.
        Task {
            do {
                _ = try await llmService.loadModel()
            } catch {
                await MainActor.run {
                    self.errorMessage = DocumentAssistantError.llmInferenceFailed("Failed to load LLM model: \(error.localizedDescription)").localizedDescription
                }
            }
        }
    }

    /// Opens an `NSOpenPanel` to allow the user to select a text file.
    /// This method is marked `@MainActor` because it interacts with UI (the file panel).
    @MainActor
    func openDocument() async {
        let openPanel = NSOpenPanel()
        openPanel.allowedContentTypes = [.plainText, .rtf, .utf8PlainText, .sourceCode]
        openPanel.allowsMultipleSelection = false
        openPanel.canChooseDirectories = false
        openPanel.canChooseFiles = true

        let response = openPanel.runModal()
        if response == .OK, let url = openPanel.url {
            await loadDocument(from: url)
        }
    }

    /// Loads the content of a document from the given URL.
    /// This operation is asynchronous and handles potential file reading errors.
    /// - Parameter url: The URL of the document to load.
    @MainActor // UI updates and state changes need to be on the MainActor
    func loadDocument(from url: URL) async {
        isLoadingDocument = true
        errorMessage = nil // Clear previous errors
        documentTitle = url.lastPathComponent // Update title immediately

        do {
            guard url.conformsToTextType() else {
                throw DocumentAssistantError.unsupportedFileType(url)
            }
            let content = try String(contentsOf: url, encoding: .utf8)
            documentContent = content
            aiAnalysisResult = "Document loaded. Click 'Analyze with AI' to get insights."
        } catch {
            documentContent = "Failed to load document."
            aiAnalysisResult = "AI analysis not available due to document loading error."
            errorMessage = DocumentAssistantError.fileReadError(url, error).localizedDescription
            print("Error loading document: \(error.localizedDescription)")
        }
        isLoadingDocument = false
    }

    /// Triggers the AI analysis on the currently loaded document.
    /// This operation runs on a background task to keep the UI responsive.
    @MainActor // For updating observable state
    func analyzeDocumentContent() async {
        guard !documentContent.isEmpty, documentContent != "Load a text document to see its content here." else {
            errorMessage = DocumentAssistantError.noDocumentLoaded.localizedDescription
            return
        }

        isAnalyzingDocument = true
        errorMessage = nil // Clear previous errors
        aiAnalysisResult = "Analyzing document with local LLM..."

        do {
            let analysis = try await llmService.analyzeDocument(text: documentContent)
            aiAnalysisResult = analysis
        } catch {
            aiAnalysisResult = "AI analysis failed."
            errorMessage = (error as? DocumentAssistantError)?.localizedDescription ?? error.localizedDescription
            print("Error analyzing document: \(error.localizedDescription)")
        }
        isAnalyzingDocument = false
    }
}

// Helper extension for UTType conformance check
@available(macOS 14.0, *)
extension URL {
    func conformsToTextType() -> Bool {
        guard let typeIdentifier = try? resourceValues(forKeys: [.contentTypeKey]).contentType else { return false }
        return typeIdentifier.conforms(to: .plainText) ||
               typeIdentifier.conforms(to: .rtf) ||
               typeIdentifier.conforms(to: .utf8PlainText) ||
               typeIdentifier.conforms(to: .sourceCode) // Covers various code files
    }
}


/// The main SwiftUI view for the Intelligent Document Assistant application.
@available(macOS 14.0, *)
struct ContentView: View {
    @State private var documentModel = DocumentModel() // State object for the observable model

    var body: some View {
        NavigationSplitView { // Use NavigationSplitView for a robust macOS layout
            sidebarContent
        } detail: {
            detailContent
        }
        .navigationTitle(documentModel.documentTitle)
        .frame(minWidth: 800, minHeight: 600)
        .alert("Error", isPresented: .constant(documentModel.errorMessage != nil)) {
            Button("OK") { documentModel.errorMessage = nil }
        } message: {
            Text(documentModel.errorMessage ?? "An unknown error occurred.")
        }
    }

    /// Sidebar content for document actions.
    private var sidebarContent: some View {
        VStack(alignment: .leading) {
            Text("Document Actions")
                .font(.headline)
                .padding(.bottom, 5)

            Button("Open Document...") {
                Task { await documentModel.openDocument() }
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(documentModel.isLoadingDocument)

            Divider()
                .padding(.vertical)

            Text("AI Analysis")
                .font(.headline)
                .padding(.bottom, 5)

            Button("Analyze with AI") {
                Task { await documentModel.analyzeDocumentContent() }
            }
            .buttonStyle(.bordered)
            .controlSize(.large)
            .disabled(documentModel.isLoadingDocument || documentModel.isAnalyzingDocument || documentModel.documentContent.isEmpty)

            if documentModel.isAnalyzingDocument {
                ProgressView()
                    .progressViewStyle(.circular)
                    .scaleEffect(0.8)
                    .padding(.top, 5)
            }

            Spacer()
        }
        .padding()
        .frame(minWidth: 200)
    }

    /// Detail content showing the document and AI analysis.
    private var detailContent: some View {
        HSplitView { // Use HSplitView to divide document view and analysis view
            VStack {
                Text("Document Content")
                    .font(.title2)
                    .padding(.bottom, 5)
                
                // Our NSViewRepresentable wrapping NSTextView
                DocumentTextView(text: $documentModel.documentContent, isEditable: false)
                    .frame(minWidth: 300, minHeight: 200)
                    .border(Color.gray.opacity(0.2), width: 1)
                    .cornerRadius(5)
            }
            .padding()

            VStack {
                Text("AI Analysis")
                    .font(.title2)
                    .padding(.bottom, 5)
                
                ScrollView {
                    Text(documentModel.aiAnalysisResult)
                        .font(.body)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(minWidth: 250, minHeight: 200)
                .border(Color.blue.opacity(0.2), width: 1)
                .cornerRadius(5)
            }
            .padding()
        }
    }
}

/// The main entry point for the macOS application.
@available(macOS 14.0, *)
@main
struct IntelligentDocumentAssistantApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .commands {
            // Custom commands can be added here, e.g., for File menu actions
            CommandGroup(replacing: .newItem) {
                Button("Open Document...") {
                    Task { await DocumentModel().openDocument() } // Trigger via a new instance or a shared model
                }
                .keyboardShortcut("o")
            }
        }
    }
}
