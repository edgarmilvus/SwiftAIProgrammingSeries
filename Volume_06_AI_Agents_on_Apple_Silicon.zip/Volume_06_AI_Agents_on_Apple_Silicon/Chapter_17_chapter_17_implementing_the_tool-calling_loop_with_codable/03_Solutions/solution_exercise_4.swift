
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

// MARK: - Exercise 4: Dynamic Tool Manifest Generation & LLM Integration Simulation

// The common Tool, ToolCall, AnyCodable, ToolError, ToolRegistry, LLMFunctionParameter,
// and LLMToolDefinition structs/classes are defined at the top of the file
// and are reused here.

// The CalculatorTool and TimeZoneConverterTool from Exercises 1 and 2 are also reused.

func runExercise4() async {
    print("\n--- Running Exercise 4: Dynamic Tool Manifest Generation & LLM Integration Simulation ---")

    // 1. Instantiate ToolRegistry and add tools
    let registry = ToolRegistry()
    registry.registerTool(CalculatorTool())
    registry.registerTool(TimeZoneConverterTool())
    // Note: SmartHome tools could also be added here, but for simplicity, we'll stick to Ex1 & Ex2 tools.

    // 2. Generate LLM Tool Manifest
    do {
        let llmManifest = try registry.generateLLMToolManifest()
        print("\nGenerated LLM Tool Manifest (JSON to send to LLM):")
        print(llmManifest)
    } catch {
        print("Error generating LLM manifest: \(error.localizedDescription)")
    }

    // 3. Simulate LLM response and process it
    let mockLLMResponses: [(String, String)] = [
        ("LLM wants to add numbers", """
        {
            "toolName": "calculator_tool",
            "arguments": "{\\"operand1\\": 25.0, \\"operand2\\": 15.0, \\"operation\\": \\"add\\"}"
        }
        """),
        ("LLM wants to know time in Tokyo", """
        {
            "toolName": "time_zone_converter_tool",
            "arguments": "{\\"city\\": \\"Tokyo\\"}"
        }
        """),
        ("LLM wants to multiply, but with malformed arguments", """
        {
            "toolName": "calculator_tool",
            "arguments": "{\\"operand1\\": 25, \\"operand2\\": \\"ten\\", \\"operation\\": \\"multiply\\"}"
        }
        """),
        ("LLM calls a non-existent tool", """
        {
            "toolName": "weather_tool",
            "arguments": "{\\"city\\": \\"London\\"}"
        }
        """)
    ]

    for (description, toolCallJSON) in mockLLMResponses {
        print("\n=== Simulating LLM response for: \(description) ===")
        do {
            let result = try await processLLMResponse(toolCallJSON: toolCallJSON, registry: registry)
            print("Agent's Final Response: \(result)")
        } catch {
            print("Agent Encountered Error: \(error.localizedDescription)")
        }
    }
}

// Main execution block to run all exercises
@main
struct ToolCallingApp {
    static func main() async {
        await runExercise1()
        await runExercise2()
        await runExercise3()
        await runExercise4()
    }
}
