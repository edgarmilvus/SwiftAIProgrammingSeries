
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part7.swift
// Description: Advanced Application
// ==========================================

/// Main application entry point to demonstrate the agent's functionality.
/// This simulates the UI layer interacting with the AgentCoordinator.
@available(iOS 18.0, macOS 15.0, *)
@main
struct SmartDocumentAgentApp {
    static func main() async {
        print("--- Smart Document Agent Application Starting ---")

        // 1. Initialize the LLM Service (e.g., a real llama.cpp binding or Ollama client)
        let llmService = MockLLMService()

        // 2. Initialize the worker actors
        let documentProcessor = DocumentProcessingActor()
        let llmInferrer = LLMInferenceActor(llmService: llmService)

        // 3. Initialize the Agent Coordinator
        let coordinator = AgentCoordinatorActor(
            documentProcessor: documentProcessor,
            llmInferrer: llmInferrer
        )

        // Simulate multiple user requests concurrently
        let documents = [
            "This is a legal document outlining terms and conditions for a software license agreement. It covers intellectual property, warranty disclaimers, and dispute resolution mechanisms. The agreement is between TechCorp Inc. and various end-users.",
            "A research paper on the advancements in quantum computing. It discusses qubit stability, error correction codes, and potential applications in cryptography and materials science. Key figures include Dr. Alice Smith and Professor Bob Johnson.",
            "Meeting minutes from the Q3 product strategy review. Attendees included CEO, CTO, Head of Marketing. Decisions made: prioritize Project X, deprioritize Project Y, and launch marketing campaign for Product Z next month.",
            "A short personal note about planning a weekend trip to the mountains. Need to pack hiking gear, check weather forecast, and book a cabin. Expected activities include trail hiking and stargazing.",
            "Another legal document, this time a patent application for a novel AI-driven recommendation engine. Details include algorithm design, data processing pipelines, and user interaction models. Inventor: Dr. Carol White."
        ]

        let tasks: [AnalysisTask] = [
            .summarize(length: 50),
            .answerQuestion(question: "Who are the key figures mentioned?"),
            .categorize(categories: ["Legal", "Technology", "Business", "Personal"]),
            .custom(promptSuffix: "What is the main subject of this document?"),
            .summarize(length: 75)
        ]

        // Use a TaskGroup to run multiple analysis requests concurrently, simulating parallel user interactions.
        await withTaskGroup(of: Void.self) { group in
            for i in 0..<documents.count {
                let rawDoc = documents[i]
                let task = tasks[i % tasks.count] // Cycle through tasks

                group.addTask {
                    print("\n--- Initiating Request \(i+1) ---")
                    do {
                        let response = try await coordinator.handleDocumentAnalysisRequest(rawDocumentData: rawDoc, task: task)
                        print("\n✅ Request \(i+1) Succeeded for \(response.requestID.uuidString.prefix(8))...:")
                        print("   Model: \(response.modelName)")
                        print("   Generated Text: \(response.generatedText.prefix(200))...")
                        print("   Completion Time: \(String(format: "%.2f", response.completionTime))s")
                    } catch let agentError as AgentError {
                        print("\n❌ Request \(i+1) Failed with AgentError for '\(rawDoc.prefix(20))...': \(agentError.localizedDescription)")
                    } catch {
                        print("\n❌ Request \(i+1) Failed with unexpected error for '\(rawDoc.prefix(20))...': \(error.localizedDescription)")
                    }
                    print("--- Request \(i+1) Finished ---")
                }
            }
        }
        print("\n--- All Document Agent Tasks Completed ---")
    }
}
