
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI

// MARK: - UserChatBubbleView
struct UserChatBubbleView: View {
    let message: String

    var body: some View {
        HStack {
            Spacer() // Pushes the bubble to the trailing edge
            Text(message)
                .padding(10)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(15)
                .frame(maxWidth: 280, alignment: .trailing) // Constrain width
        }
    }
}

// MARK: - AIChatBubbleView
struct AIChatBubbleView: View {
    let message: String

    var body: some View {
        HStack {
            Text(message)
                .padding(10)
                .background(Color.gray.opacity(0.2)) // A subtle gray for AI
                .foregroundColor(.primary)
                .cornerRadius(15)
                .frame(maxWidth: 280, alignment: .leading) // Constrain width
            Spacer() // Pushes the bubble to the leading edge
        }
    }
}

// MARK: - ContentView for demonstration
struct ContentView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                AIChatBubbleView(message: "Hello! How can I assist you today?")
                UserChatBubbleView(message: "I need help understanding SwiftUI layout.")
                AIChatBubbleView(message: "SwiftUI uses a declarative approach. Key components are VStack, HStack, and ZStack for arranging views.")
                UserChatBubbleView(message: "That makes sense. What about modifiers like padding and background?")
                AIChatBubbleView(message: "Modifiers like `.padding()` add space around a view, and `.background()` changes its visual appearance, often with shapes or colors.")
                UserChatBubbleView(message: "Thanks! This is very helpful.")
            }
            .padding()
        }
        .navigationTitle("AI Chat") // For better context in a navigation stack
    }
}

// MARK: - Preview Provider
#Preview {
    ContentView()
}
