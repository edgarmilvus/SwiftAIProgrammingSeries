
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
import MLX
import MLXNN
import Foundation // For URL, FileManager, Date

// Define placeholder LLM modules
// In a real scenario, these would be different MLXNN.Module subclasses
// or instances of a generic LLM with different loaded weights.
class CodeGenLLM: MLXNN.Module {
    let linear: MLXNN.Linear
    init() { self.linear = MLXNN.Linear(inputFeatures: 1024, outputFeatures: 1024); super.init() }
    override func callAsFunction(_ input: MLXArray) -> MLXArray { return linear(input) }
}
class StoryWeaverLLM: MLXNN.Module {
    let linear: MLXNN.Linear
    init() { self.linear = MLXNN.Linear(inputFeatures: 1024, outputFeatures: 1024); super.init() }
    override func callAsFunction(_ input: MLXArray) -> MLXArray { return linear(input) }
}
class DataSageLLM: MLXNN.Module {
    let linear: MLXNN.Linear
    init() { self.linear = MLXNN.Linear(inputFeatures: 1024, outputFeatures: 1024); super.init() }
    override func callAsFunction(_ input: MLXArray) -> MLXArray { return linear(input) }
}

// Helper to estimate model memory (sum of nbytes of all parameters)
@available(iOS 18.0, macOS 15.0, *)
func estimateModelMemory(model: MLXNN.Module) -> Int {
    return model.parameters().values.reduce(0) { $0 + $1.nbytes }
}

// Helper to create dummy .safetensors files for testing
@available(iOS 18.0, macOS 15.0, *)
func createDummyModelFiles() throws {
    let models: [String: MLXNN.Module] = [
        "CodeGen": CodeGenLLM(),
        "StoryWeaver": StoryWeaverLLM(),
        "DataSage": DataSageLLM()
    ]

    for (name, model) in models {
        let path = "\(name.lowercased())_model.safetensors"
        print("Creating dummy model file: \(path)")
        try MLX.safesave(model.parameters(), path: path)
    }
}

enum ModelSwitchingError: Error, CustomStringConvertible {
    case modelNotFound(String)
    case modelInstantiationFailed(String)
    case pathInvalid(String)

    var description: String {
        switch self {
        case .modelNotFound(let name): return "Model '\(name)' not found in known types."
        case .modelInstantiationFailed(let name): return "Failed to instantiate model '\(name)'."
        case .pathInvalid(let path): return "Invalid model path: '\(path)'."
        }
    }
}

class ModelSwitchingManager {
    static let shared = ModelSwitchingManager() // Singleton pattern
    
    // Using a DispatchQueue for thread-safety, as a singleton could be accessed from multiple threads
    private let accessQueue = DispatchQueue(label: "com.cognito.modelmanager.access", attributes: .concurrent)

    private var loadedModels: [String: (model: MLXNN.Module, lastUsed: Date, memoryFootprint: Int)] = [:]
    private var _currentMemoryUsage: Int = 0 // Backing property for currentMemoryUsage
    var currentMemoryUsage: Int {
        accessQueue.sync { _currentMemoryUsage }
    }
    
    let memoryBudget: Int // In bytes, e.g., 2 GB = 2 * 1024 * 1024 * 1024

    private init(memoryBudgetGB: Double = 0.2) { // Using a smaller budget for easier testing (200MB)
        self.memoryBudget = Int(memoryBudgetGB * 1024 * 1024 * 1024)
        print("ModelSwitchingManager initialized with memory budget: \(Double(memoryBudget) / (1024 * 1024)) MB")
    }

    // Factory method to instantiate specific MLXNN.Module subclasses
    private func instantiateModel(named modelName: String) -> MLXNN.Module? {
        switch modelName {
        case "CodeGen": return CodeGenLLM()
        case "StoryWeaver": return StoryWeaverLLM()
        case "DataSage": return DataSageLLM()
        default: return nil
        }
    }

    // Implement this function
    func loadModel(named modelName: String, modelPath: String) throws -> MLXNN.Module {
        return try accessQueue.sync(flags: .barrier) { // Use barrier for write access
            // 1. Check if model is already loaded
            if let entry = loadedModels[modelName] {
                // Update last used for LRU
                loadedModels[modelName]?.lastUsed = Date()
                print("Model '\(modelName)' already loaded. Returning cached instance.")
                return entry.model
            }

            // 2. Load model parameters from path using MLX.load
            guard FileManager.default.fileExists(atPath: modelPath) else {
                throw ModelSwitchingError.pathInvalid(modelPath)
            }
            print("Loading parameters for '\(modelName)' from disk...")
            let loadedParams = try MLX.load(safetensors: modelPath)

            // 3. Instantiate the correct MLXNN.Module subclass and load parameters
            guard let newModel = instantiateModel(named: modelName) else {
                throw ModelSwitchingError.modelInstantiationFailed(modelName)
            }
            newModel.load(parameters: loadedParams)
            
            // 4. Estimate the new model's memory footprint.
            let newModelFootprint = estimateModelMemory(model: newModel)
            print("Estimated footprint for new model '\(modelName)': \(Double(newModelFootprint) / (1024 * 1024)) MB")

            // 5. If loading exceeds budget, apply LRU eviction.
            evictModelsIfNeeded(spaceNeeded: newModelFootprint)

            // Double check if space is available after eviction (should be, unless model is too big for budget)
            if _currentMemoryUsage + newModelFootprint > memoryBudget {
                print("Warning: Model '\(modelName)' ( \(Double(newModelFootprint) / (1024 * 1024)) MB) is too large for the remaining budget even after eviction. Loading anyway, but budget exceeded.")
            }

            // 6. Add the new model to `loadedModels` and update `currentMemoryUsage`.
            loadedModels[modelName] = (model: newModel, lastUsed: Date(), memoryFootprint: newModelFootprint)
            _currentMemoryUsage += newModelFootprint
            print("Model '\(modelName)' loaded. Current total memory usage: \(Double(_currentMemoryUsage) / (1024 * 1024)) MB")
            return newModel
        }
    }

    // Implement this function
    func unloadModel(named modelName: String) {
        accessQueue.sync(flags: .barrier) { // Use barrier for write access
            if let removedEntry = loadedModels.removeValue(forKey: modelName) {
                _currentMemoryUsage -= removedEntry.memoryFootprint
                print("Model '\(modelName)' unloaded. Current total memory usage: \(Double(_currentMemoryUsage) / (1024 * 1024)) MB")
                // ARC will deallocate removedEntry.model (and its MLXArrays) here
            } else {
                print("Model '\(modelName)' not found in cache, nothing to unload.")
            }
        }
    }

    // Helper to get a model, updating its lastUsed timestamp
    func getModel(named modelName: String) -> MLXNN.Module? {
        accessQueue.sync { // Use sync for read access
            if var entry = loadedModels[modelName] {
                // Update last used for LRU (requires write access)
                accessQueue.sync(flags: .barrier) {
                    entry.lastUsed = Date()
                    loadedModels[modelName] = entry
                }
                print("Model '\(modelName)' accessed. Last used timestamp updated.")
                return entry.model
            }
            print("Model '\(modelName)' not found in cache.")
            return nil
        }
    }

    // Implement eviction logic (e.g., LRU)
    private func evictModelsIfNeeded(spaceNeeded: Int) {
        // This method is called from within a barrier, so it has exclusive write access.
        while _currentMemoryUsage + spaceNeeded > memoryBudget && !loadedModels.isEmpty {
            // Find the least recently used model
            guard let lruEntry = loadedModels.min(by: { $0.value.lastUsed < $1.value.lastUsed }) else {
                break // No models to evict
            }
            let modelToEvictName = lruEntry.key
            print("Memory budget exceeded. Evicting LRU model: '\(modelToEvictName)'")
            
            // Unload the model (this will update _currentMemoryUsage)
            // Call the internal removal logic directly to avoid recursive barrier
            if let removedEntry = loadedModels.removeValue(forKey: modelToEvictName) {
                _currentMemoryUsage -= removedEntry.memoryFootprint
                print("Evicted '\(modelToEvictName)'. Current total memory usage: \(Double(_currentMemoryUsage) / (1024 * 1024)) MB")
            }
        }
    }
}

// Example usage structure:
@available(iOS 18.0, macOS 15.0, *)
func exercise4Example() {
    print("--- Exercise 4: Adaptive Model Switching for a 'Smart Assistant' ---")

    // Create dummy model files first
    do {
        try createDummyModelFiles()
    } catch {
        print("Error creating dummy model files: \(error)")
        return
    }

    let manager = ModelSwitchingManager.shared
    let dummyInput = MLXArray.randomUniform(low: 0, high: 1, shape: [1, 1024]) // For inference calls

    // Simulate loading models
    do {
        let codeGenModel = try manager.loadModel(named: "CodeGen", modelPath: "codegen_model.safetensors")
        _ = codeGenModel(dummyInput) // Use the model
        Thread.sleep(forTimeInterval: 0.1) // Simulate some time passing

        let storyWeaverModel = try manager.loadModel(named: "StoryWeaver", modelPath: "storyweaver_model.safetensors")
        _ = storyWeaverModel(dummyInput) // Use the model
        Thread.sleep(forTimeInterval: 0.1)

        // Request CodeGen again - should be fast and update its 'lastUsed' timestamp
        print("\nRequesting CodeGen model again...")
        let retrievedCodeGen = manager.getModel(named: "CodeGen")
        if let model = retrievedCodeGen {
            _ = model(dummyInput)
            print("CodeGen model retrieved from cache.")
        }

        // Load a third model, potentially triggering eviction (StoryWeaver should be LRU)
        print("\nAttempting to load DataSage model (might trigger eviction)...")
        let dataSageModel = try manager.loadModel(named: "DataSage", modelPath: "datasage_model.safetensors")
        _ = dataSageModel(dummyInput) // Use the model

        print("\nCurrent loaded models and their last used times:")
        manager.accessQueue.sync {
            let sortedModels = manager.loadedModels.sorted { $0.value.lastUsed < $1.value.lastUsed }
            for (name, entry) in sortedModels {
                print("- \(name): Last Used \(entry.lastUsed.formatted(date: .omitted, time: .standard)), Mem: \(Double(entry.memoryFootprint) / (1024 * 1024)) MB")
            }
        }
        
        // Explicitly unload a model
        print("\nExplicitly unloading CodeGen model...")
        manager.unloadModel(named: "CodeGen")
        
        // Try to get unloaded model
        print("\nAttempting to get unloaded CodeGen model...")
        _ = manager.getModel(named: "CodeGen") // Should return nil

    } catch {
        print("Error in ModelSwitchingManager example: \(error.localizedDescription)")
    }
    print("--- End Exercise 4 ---")
}

// Call the example function to run the exercise
// exercise4Example() // Uncomment to run
