
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import CoreML
import Foundation
import Security // For SecCertificate, SecKey, SecKeyVerifySignature
import CryptoKit // For SHA256 hashing

// MARK: - Custom Signature Verification Logic

@available(iOS 18.0, macOS 15.0, *)
enum ModelSecurityError: Error, LocalizedError {
    case certificateNotFoundInBundle(String)
    case certificateDataInvalid
    case publicKeyExtractionFailed
    case modelPackageInvalid(String)
    case signatureFileNotFound(String)
    case signatureFileCorrupt(String)
    case modelHashMismatch
    case signatureVerificationFailed
    case modelNotSigned

    var errorDescription: String? {
        switch self {
        case .certificateNotFoundInBundle(let name): return "Trusted certificate '\(name)' not found in app bundle."
        case .certificateDataInvalid: return "Trusted certificate data is invalid."
        case .publicKeyExtractionFailed: return "Failed to extract public key from trusted certificate."
        case .modelPackageInvalid(let path): return "Model package at '\(path)' is invalid or cannot be opened."
        case .signatureFileNotFound(let path): return "Signature file not found within model package at '\(path)'."
        case .signatureFileCorrupt(let path): return "Signature file at '\(path)' is corrupt or malformed."
        case .modelHashMismatch: return "Calculated model hash does not match hash in signature file. Model integrity compromised."
        case .signatureVerificationFailed: return "Digital signature verification failed. Model not signed by trusted authority."
        case .modelNotSigned: return "Model package does not contain a signature, or signature is incomplete."
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct ModelSignature {
    let modelHash: Data // SHA256 hash of model.mlmodelc
    let signature: Data // Digital signature of modelHash
}

@available(iOS 18.0, macOS 15.0, *)
class SecureModelManager: ObservableObject {
    @Published var activeModel: MLModel?
    @Published var statusMessage: String = "Ready for model loading."
    @Published var activeModelName: String = "N/A"

    private var trustedCertificate: SecCertificate?

    init() {
        // Load trusted certificate on initialization
        Task {
            await loadTrustedCertificate()
        }
    }

    // MARK: - Certificate Loading

    func loadTrustedCertificate(named certName: String = "certificate", withExtension ext: String = "cer") async {
        DispatchQueue.main.async { self.statusMessage = "Loading trusted certificate..." }
        do {
            guard let certURL = Bundle.main.url(forResource: certName, withExtension: ext),
                  let certData = try? Data(contentsOf: certURL) else {
                throw ModelSecurityError.certificateNotFoundInBundle(certName)
            }
            guard let cert = SecCertificateCreateWithData(nil, certData as CFData) else {
                throw ModelSecurityError.certificateDataInvalid
            }
            DispatchQueue.main.async {
                self.trustedCertificate = cert
                self.statusMessage = "Trusted certificate loaded successfully."
            }
        } catch {
            DispatchQueue.main.async {
                self.statusMessage = "Error loading trusted certificate: \(error.localizedDescription)"
                self.trustedCertificate = nil
            }
        }
    }

    // MARK: - Custom Signature Verification

    /// Verifies the custom digital signature of an .mlpackage.
    /// Assumes the signature is stored in `Contents/Resources/_Signature.json`
    /// containing `modelHash` (base64 of SHA256 of model.mlmodelc) and `signature` (base64 of signed hash).
    func verifyModelSignature(at modelURL: URL) async throws {
        guard let trustedCert = self.trustedCertificate else {
            throw ModelSecurityError.certificateNotFoundInBundle("Trusted certificate not loaded.")
        }

        // Perform file I/O and crypto operations on a background thread
        try await Task.detached {
            // 1. Extract public key from trusted certificate
            guard let publicKey = SecCertificateCopyPublicKey(trustedCert) else {
                throw ModelSecurityError.publicKeyExtractionFailed
            }

            // 2. Open .mlpackage bundle and locate model.mlmodelc and _Signature.json
            guard let packageBundle = Bundle(url: modelURL) else {
                throw ModelSecurityError.modelPackageInvalid(modelURL.path)
            }

            guard let modelCURL = packageBundle.url(forResource: "model", withExtension: "mlmodelc", subdirectory: "Contents"),
                  let signatureFileURL = packageBundle.url(forResource: "_Signature", withExtension: "json", subdirectory: "Contents/Resources") else {
                throw ModelSecurityError.modelNotSigned // Or more specific error
            }

            // 3. Calculate SHA256 hash of model.mlmodelc
            let modelCData = try Data(contentsOf: modelCURL)
            let calculatedModelHash = SHA256.hash(data: modelCData)
            let calculatedModelHashData = Data(calculatedModelHash)

            // 4. Read and parse _Signature.json
            let signatureData = try Data(contentsOf: signatureFileURL)
            guard let json = try JSONSerialization.jsonObject(with: signatureData, options: []) as? [String: String],
                  let base64ModelHash = json["modelHash"],
                  let base64Signature = json["signature"],
                  let signedModelHash = Data(base64Encoded: base64ModelHash),
                  let digitalSignature = Data(base64Encoded: base64Signature) else {
                throw ModelSecurityError.signatureFileCorrupt(signatureFileURL.path)
            }

            // 5. Verify the modelHash from the file matches the calculated hash
            guard calculatedModelHashData == signedModelHash else {
                throw ModelSecurityError.modelHashMismatch
            }

            // 6. Verify the digital signature using the public key
            // Use kSecKeyAlgorithmRSASignatureMessageX931SHA256 for a common RSA-SHA256 scheme
            var error: Unmanaged<CFError>?
            let isValidSignature = SecKeyVerifySignature(
                publicKey,
                .rsaSignatureMessageX931SHA256, // Or other appropriate algorithm
                signedModelHash as CFData,      // The original data that was signed (the hash)
                digitalSignature as CFData,     // The actual signature
                &error
            )

            if let verificationError = error?.takeRetainedValue() {
                print("Signature verification error: \(verificationError)")
            }

            guard isValidSignature else {
                throw ModelSecurityError.signatureVerificationFailed
            }
        }.value // Await the detached task
    }

    // MARK: - Conditional Model Loading

    func loadSecureModel(modelName: String) async {
        DispatchQueue.main.async {
            self.statusMessage = "Attempting to load '\(modelName).mlpackage'..."
            self.activeModel = nil
            self.activeModelName = "N/A"
        }

        do {
            guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlpackage") else {
                throw ModelSecurityError.modelPackageInvalid("Model '\(modelName)' not found in bundle.")
            }

            // First, perform custom signature verification
            DispatchQueue.main.async { self.statusMessage = "Verifying custom signature for '\(modelName)'..." }
            try await verifyModelSignature(at: modelURL)
            DispatchQueue.main.async { self.statusMessage = "Custom signature verification PASSED for '\(modelName)'." }

            // If verification passes, proceed to load the MLModel
            let loadedModel = try await Task.detached {
                return try MLModel(contentsOf: modelURL, configuration: MLModelConfiguration())
            }.value

            DispatchQueue.main.async {
                self.activeModel = loadedModel
                self.activeModelName = modelName
                self.statusMessage = "Successfully loaded and verified model: \(modelName)."
                print("Model '\(modelName)' loaded and verified.")
            }

        } catch {
            DispatchQueue.main.async {
                self.activeModel = nil
                self.activeModelName = "N/A"
                self.statusMessage = "Failed to load model: \(error.localizedDescription)"
                print("Failed to load model '\(modelName)': \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - SwiftUI View

@available(iOS 18.0, macOS 15.0, *)
struct Exercise4View: View {
    @StateObject private var modelManager = SecureModelManager()

    var body: some View {
        VStack(spacing: 20) {
            Text("Secure Medical Imaging App")
                .font(.largeTitle)
                .fontWeight(.bold)

            Spacer()

            Text("Active Model:")
                .font(.headline)
            Text(modelManager.activeModelName)
                .font(.title)
                .foregroundColor(modelManager.activeModel != nil ? .accentColor : .red)
                .padding()
                .background(Capsule().fill(Color.gray.opacity(0.1)))

            Text(modelManager.statusMessage)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            Spacer()

            VStack(spacing: 10) {
                Button("Load Signed Model (MedicalImageClassifier)") {
                    Task {
                        await modelManager.loadSecureModel(modelName: "MedicalImageClassifier")
                    }
                }
                .buttonStyle(.borderedProminent)

                Button("Load Unsigned Model (UnsignedMedicalImageClassifier)") {
                    Task {
                        await modelManager.loadSecureModel(modelName: "UnsignedMedicalImageClassifier")
                    }
                }
                .buttonStyle(.bordered)
                .tint(.red)
            }
            .padding()

            Text("Note: This demo simulates custom signing. 'MedicalImageClassifier.mlpackage' is assumed to be 'signed' with a '_Signature.json' file, and 'UnsignedMedicalImageClassifier.mlpackage' is assumed to be 'unsigned' or malformed to demonstrate failure.")
                .font(.footnote)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        .padding()
    }
}

// MARK: - External Preparation (Conceptual Guidance for the Instructor)
/*
   To prepare the models and certificate for this exercise:

   1.  **Generate a Self-Signed Certificate and Private Key:**
       Run these commands in your terminal. This creates `private.key` and `certificate.crt` (PEM format).
       Then converts `certificate.crt` to `certificate.cer` (DER format) for embedding in the app.

       