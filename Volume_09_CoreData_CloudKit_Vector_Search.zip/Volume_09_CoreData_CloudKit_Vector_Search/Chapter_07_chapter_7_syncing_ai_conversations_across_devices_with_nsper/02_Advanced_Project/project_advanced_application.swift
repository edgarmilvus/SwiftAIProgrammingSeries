
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreData
import Combine
import CloudKit

// MARK: - Dependencies

/// Package.swift equivalent dependencies:
/// - CoreData (Built-in)
/// - CloudKit (Built-in)
/// - Apple's Swift 6 Concurrency Runtime

// MARK: - Models & Errors

/// Custom errors for the synchronization lifecycle.
enum SyncError: Error {
    case containerInitializationFailed
    case mergeConflictDetected(entityID: NSManagedObjectID)
    case vectorDataIncomplete(messageID: UUID)
    case cloudKitPermissionDenied
}

/// Represents the role of a message in the AI conversation.
enum MessageRole: String, Codable {
    case user
    case assistant
    case system
}

// MARK: - Persistence Controller

/// A thread-safe, actor-isolated controller responsible for managing the 
/// NSPersistentCloudKitContainer and handling complex merge logic.
@available(iOS 18.0, *)
final class CognitivePersistenceController: NSObject {
    static let shared = CognitivePersistenceController()

    let container: NSPersistentCloudKitContainer
    private var cancellables = Set<AnyCancellable>()

    /// The background context used for heavy-duty AI processing and sync handling.
    /// This context is isolated to prevent UI hangs during large vector imports.
    let backgroundContext: NSManagedObjectContext

    private override init() {
        // Initialize the container with the model named 'AIConversationModel'
        container = NSPersistentCloudKitContainer(name: "AIConversationModel")

        // 1. Configure CloudKit Options
        guard let description = container.persistentStoreDescriptions.first else {
            fatalError("Failed to retrieve persistent store description.")
        }

        // Enable remote change notifications to react to CloudKit syncs
        description.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)
        
        // Enable history tracking for advanced conflict resolution
        description.setOption(true as NSNumber, forKey: NSPersistentHistoryTrackingKey)

        // 2. Setup Container
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }

        // 3. Configure Merge Policy
        // We use a custom merge policy to handle the 'Text vs Vector' dependency.
        container.viewContext.automaticallyMergesChangesFromParent = true
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        
        self.backgroundContext = container.newBackgroundContext()
        self.backgroundContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        self.backgroundContext.undoManager = nil

        super.init()

        self.setupRemoteChangeObservation()
    }

    /// Observes remote changes coming from CloudKit and triggers local re-indexing.
    private func setupRemoteChangeObservation() {
        NotificationCenter.default.publisher(for: .NSPersistentStoreRemoteChange)
            .sink { [weak self] _ in
                self?.handleRemoteChange()
            }
            .store(in: &cancellables)
    }

    private func handleRemoteChange() {
        // In a real-world app, we would use NSPersistentHistoryChangeRequest
        // to fetch exactly what changed and update the Vector Index.
        print("🚀 Remote change detected. Re-indexing local vector store...")
        Task {
            await CognitiveSyncActor.shared.reindexLocalEmbeddings()
        }
    }
}

// MARK: - Sync Actor

/// An actor that manages the high-frequency updates of AI conversations.
/// Using an actor ensures that even if multiple background tasks (AI generation, 
/// user input, CloudKit sync) attempt to modify the same conversation, 
/// the operations are serialized and thread-safe.
@available(iOS 18.0, *)
actor CognitiveSyncActor {
    static let shared = CognitiveSyncActor()
    
    private let persistence = CognitivePersistenceController.shared

    private init() {}

    /// Adds a new message and its associated vector embedding atomically.
    /// - Parameters:
    ///   - text: The raw string content of the message.
    ///   - role: The sender role.
    ///   - conversationID: The ID of the parent conversation.
    ///   - embedding: The high-dimensional vector generated by the AI model.
    /// - Throws: `SyncError` if the write fails.
    func processIncomingMessage(
        text: String,
        role: MessageRole,
        conversationID: UUID,
        embedding: [Float]
    ) async throws {
        let context = persistence.backgroundContext
        
        // Perform the write on the background context
        try await context.perform {
            // 1. Create the Message entity
            let newMessage = MessageEntity(context: context)
            newMessage.id = UUID()
            newMessage.text = text
            newMessage.role = role.rawValue
            newMessage.timestamp = Date()
            newMessage.conversationID = conversationID

            // 2. Create/Update the Embedding entity
            // We link the embedding to the message to ensure they sync as a pair.
            let embeddingEntity = MessageEmbeddingEntity(context: context)
            embeddingEntity.id = UUID()
            embeddingEntity.vectorData = embedding as NSObject // Assuming Transformable
            embeddingEntity.message = newMessage
            embeddingEntity.lastUpdated = Date()

            // 3. Save the context to trigger CloudKit sync
            if context.hasChanges {
                try context.save()
            }
        }
    }

    /// Re-indexes the local vector store. This is critical when remote changes 
    /// arrive that contain new text but might be missing embeddings.
    func reindexLocalEmbeddings() async {
        let context = persistence.backgroundContext
        
        await context.perform {
            // Logic: Find messages that have text but no associated embedding entity.
            // This handles the "Partial Sync" problem where text arrives before the vector.
            let request: NSFetchRequest<MessageEntity> = MessageEntity.fetchRequest()
            request.predicate = NSPredicate(format: "embedding == nil")
            
            do {
                let incompleteMessages = try context.fetch(request)
                for message in incompleteMessages {
                    print("⚠️ Found incomplete message: \(message.id?.uuidString ?? "Unknown"). Triggering on-device embedding generation.")
                    // In a real app: Trigger local LLM/CoreML to generate embedding
                    // and then call processIncomingMessage again.
                }
            } catch {
                print("❌ Failed to fetch incomplete messages: \(error)")
            }
        }
    }
}

// MARK: - CoreData Managed Object Extensions (Mocked for implementation)

/// Note: In a real project, these are generated by the .xcdatamodeld file.
@objc(MessageEntity)
public class MessageEntity: NSManagedObject {
    @NSManaged public var id: UUID?
    @NSManaged public var text: String?
    @NSManaged public var role: String?
    @NSManaged public var timestamp: Date?
    @NSManaged public var conversationID: UUID?
    @NSManaged public var embedding: MessageEmbeddingEntity?
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<MessageEntity> {
        return NSFetchRequest<MessageEntity>(entityName: "MessageEntity")
    }
}

@objc(MessageEmbeddingEntity)
public class MessageEmbeddingEntity: NSManagedObject {
    @NSManaged public var id: UUID?
    @NSManaged public var vectorData: NSObject? // Transformable Float array
    @NSManaged public var lastUpdated: Date?
    @NSManaged public var message: MessageEntity?
}
