
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import CoreML
import AppKit // Required for NSOpenPanel (for optional challenge)

// MARK: - App Structure (for a runnable SwiftUI app)
@main
struct BlogPostCategorizerApp: App {
    var body: some Scene {
        WindowGroup {
            TopicCategorizerView()
                .frame(minWidth: 600, minHeight: 500) // Set initial window size
        }
        .windowResizability(.contentSize) // Allow window to resize based on content
    }
}

// MARK: - TopicCategorizerView
@available(macOS 15.0, *) // macOS 15.0 or later for SwiftUI TextEditor, or adjust for older versions if needed
struct TopicCategorizerView: View {
    @State private var postText: String = ""
    @State private var topicResult: String = "Paste your blog post here or load from file."

    // Instantiate your ML model. Ensure BlogPostTopicClassifier.mlmodel
    // is correctly added to your Xcode project and target.
    let topicClassifier: BlogPostTopicClassifier = {
        do {
            let config = MLModelConfiguration()
            return try BlogPostTopicClassifier(configuration: config)
        } catch {
            fatalError("Failed to load BlogPostTopicClassifier: \(error.localizedDescription)")
        }
    }()

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Blog Post Topic Categorizer")
                .font(.largeTitle)
                .padding(.bottom, 10)

            HStack {
                Text("Post Content:")
                    .font(.headline)
                Spacer()
                Button("Load from File...") {
                    loadFile()
                }
                .buttonStyle(.bordered)
            }

            TextEditor(text: $postText)
                .frame(minWidth: 400, minHeight: 300)
                .border(Color.gray, width: 1)
                .padding(.bottom)
                .accessibilityLabel("Blog Post Input Text Editor")
                .accessibilityHint("Paste your blog post content here.")

            Button("Categorize Post") {
                categorizePost()
            }
            .buttonStyle(.borderedProminent)
            .padding(.bottom)
            .accessibilityLabel("Categorize Post Button")

            Divider()

            Text("Predicted Topic:")
                .font(.headline)
            Text(topicResult)
                .font(.title2)
                .foregroundColor(.accentColor)
                .padding(.top, 5)
                .accessibilityLabel("Predicted Topic Result")
                .accessibilityValue(topicResult)

            Spacer()
        }
        .padding()
        .navigationTitle("Blog Post Categorizer") // For potential navigation contexts
    }

    /// Performs topic categorization on the user-entered text.
    func categorizePost() {
        guard !postText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            topicResult = "Please enter some text."
            return
        }
        do {
            let prediction = try topicClassifier.prediction(from: postText)
            topicResult = "Predicted Topic: \(prediction.label)"
        } catch {
            topicResult = "Error categorizing post: \(error.localizedDescription)"
            print("Prediction error: \(error)")
        }
    }

    /// Presents an `NSOpenPanel` to allow the user to select and load a text file.
    func loadFile() {
        let panel = NSOpenPanel()
        panel.allowedFileTypes = ["txt", "rtf", "md"] // Common text file types
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.canChooseFiles = true

        if panel.runModal() == .OK, let url = panel.url {
            do {
                postText = try String(contentsOf: url, encoding: .utf8)
                topicResult = "Text loaded. Press 'Categorize Post'."
            } catch {
                topicResult = "Error loading file: \(error.localizedDescription)"
                print("File loading error: \(error)")
            }
        }
    }
}
