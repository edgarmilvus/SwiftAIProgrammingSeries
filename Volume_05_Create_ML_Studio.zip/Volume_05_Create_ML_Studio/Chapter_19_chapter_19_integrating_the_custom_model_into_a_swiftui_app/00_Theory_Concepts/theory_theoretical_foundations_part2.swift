
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import CoreML
    import Vision // Often used with Core ML for image processing

    @available(iOS 18.0, *)
    actor ModelManager {
        private let model: MyImageClassifier // Your generated Core ML model class
        private var currentPredictionTask: Task<String, Error>? // To manage ongoing tasks

        init() throws {
            // Load the compiled model (.mlmodelc) from the app bundle
            guard let modelURL = Bundle.main.url(forResource: "MyImageClassifier", withExtension: "mlmodelc") else {
                fatalError("Failed to find model in bundle.")
            }
            self.model = try MyImageClassifier(contentsOf: modelURL)
        }

        func predict(imageBuffer: CVPixelBuffer) async throws -> String {
            // Ensure only one prediction runs at a time for this model instance
            // or cancel previous if a new one comes in.
            // This is an example of actor-isolated state management.
            currentPredictionTask?.cancel() // Cancel previous task if any

            currentPredictionTask = Task {
                let input = MyImageClassifierInput(image: imageBuffer)
                let output = try await model.prediction(input: input)
                return output.label
            }

            return try await currentPredictionTask!.value
        }
    }
    