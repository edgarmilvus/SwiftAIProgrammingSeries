
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import RealityKit

@available(visionOS 1.0, *)
struct SpatialArchitectProView: View {
    @State private var isSimplifying = false

    var body: some View {
        VStack {
            RealityView { content in
                // Simulate a massive mesh by adding a very large sphere
                let massiveMesh = ModelEntity(mesh: .generateSphere(radius: 0.5), materials: [SimpleMaterial(color: .gray, isMetallic: false)])
                content.add(massiveMesh)
            }
            
            Button(isSimplifying ? "Simplifying..." : "Simplify Mesh") {
                runMockAISimplification()
            }
            .disabled(isSimplifying)
            .buttonStyle(.borderedProminent)
        }
    }

    func runMockAISimplification() {
        isSimplifying = true
        
        // --- THE FLAWED IMPLEMENTATION ---
        // 1. We use a background Task to simulate intent.
        Task.detached(priority: .medium) {
            print("Starting AI Mesh Simplification...")
            
            // 2. Simulate heavy computation (The "AI" part)
            // This loop is heavy and consumes CPU.
            var dummyData = [Float]()
            for i in 0..<5_000_000 {
                dummyData.append(sin(Float(i)) * cos(Float(i)))
            }
            
            // 3. THE CRITICAL ERROR: Blocking the Main Thread
            // The developer tries to "update the UI" or "sync the mesh" 
            // by calling DispatchQueue.main.sync from a background thread.
            // This causes the Main Thread to wait for the background thread,
            // or vice versa, leading to a massive stall/freeze.
            DispatchQueue.main.sync {
                print("Syncing mesh back to main thread...")
                // Simulate the freeze duration
                Thread.sleep(forTimeInterval: 0.5) 
            }
            
            await MainActor.run {
                isSimplifying = false
                print("Simplification Complete.")
            }
        }
    }
}
