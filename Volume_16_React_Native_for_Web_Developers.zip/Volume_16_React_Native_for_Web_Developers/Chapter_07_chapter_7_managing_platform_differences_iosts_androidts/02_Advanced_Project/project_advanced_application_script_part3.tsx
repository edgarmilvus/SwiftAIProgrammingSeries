/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.tsx
// Description: Advanced Application Script
// ==========================================

// File: components/AnalyticsCard.web.tsx
import React from 'react';
import { AnalyticsCardProps } from './AnalyticsCard.types';

/**
 * Web Implementation (Next.js)
 * Uses standard HTML elements and CSS for styling.
 * Handles hover states via CSS classes.
 */
export const AnalyticsCard: React.FC<AnalyticsCardProps> = ({ data, onPress }) => {
  const handleClick = () => {
    if (onPress) onPress(data.id);
  };

  return (
    <div 
      className="bg-gray-800 rounded-xl p-4 my-2 transition-all duration-300 hover:bg-gray-700 hover:shadow-lg cursor-pointer flex flex-row items-center justify-between"
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') handleClick();
      }}
    >
      <div className="flex-1">
        <span className="text-gray-400 text-sm font-semibold block">{data.label}</span>
        <span className="text-white text-2xl font-bold">{data.value.toLocaleString()}</span>
      </div>
      <div 
        className={`w-3 h-3 rounded-full ${data.trend === 'up' ? 'bg-emerald-500' : 'bg-red-500'}`} 
      />
    </div>
  );
};
