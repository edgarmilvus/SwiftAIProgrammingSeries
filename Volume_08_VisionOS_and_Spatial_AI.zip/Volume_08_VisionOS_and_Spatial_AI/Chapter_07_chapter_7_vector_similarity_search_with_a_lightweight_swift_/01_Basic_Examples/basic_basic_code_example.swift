
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Accelerate // Essential for high-performance vector math on Apple platforms

/// Represents a high-dimensional vector used for semantic representation.
/// Conforming to `Sendable` ensures it can be safely passed across concurrency boundaries in Swift 6.
struct Embedding: Sendable, Equatable {
    /// The raw numerical values representing the semantic meaning.
    /// In a real-world app, this might have 768, 1536, or more dimensions.
    let values: [Double]
    
    /// The dimensionality of the vector.
    var dimension: Int {
        values.count
    }
    
    init(values: [Double]) {
        self.values = values
    }
}

/// A domain model representing a photo in our Smart Gallery.
struct Photo: Identifiable, Sendable {
    let id: UUID
    let filename: String
    /// The semantic embedding of the photo's content.
    let embedding: Embedding
}

/// An error type for vector operations.
enum VectorError: Error {
    case dimensionMismatch
    case emptyVector
}

/// A high-performance engine responsible for performing similarity searches.
/// We use an `actor` to ensure that the underlying photo store is thread-safe,
/// preventing data races when adding photos while a search is in progress.
actor SemanticSearchEngine {
    
    /// The local "Vector Store" containing our photo embeddings.
    private var photoStore: [Photo] = []
    
    /// Adds a new photo to the searchable index.
    /// - Parameter photo: The photo object containing the embedding.
    func index(photo: Photo) {
        photoStore.append(photo)
    }
    
    /// Performs a similarity search to find the most relevant photos.
    /// - Parameter queryEmbedding: The embedding representing the user's search intent.
    /// - Returns: An array of photos sorted by similarity (highest to lowest).
    /// - Throws: `VectorError.dimensionMismatch` if the query doesn't match the stored dimensions.
    func search(queryEmbedding: Embedding, limit: Int = 5) async throws -> [Photo] {
        // 1. Validate dimensions to prevent mathematical errors.
        guard let firstPhoto = photoStore.first, 
              firstPhoto.embedding.dimension == queryEmbedding.dimension else {
            // If store is empty, return empty. If mismatch, throw error.
            if photoStore.isEmpty { return [] }
            throw VectorError.dimensionMismatch
        }
        
        // 2. Calculate similarity for every photo in the store.
        // We use a map to create (Photo, Score) pairs.
        let scoredPhotos = photoStore.compactMap { photo -> (Photo, Double)? in
            let score = cosineSimilarity(queryEmbedding, photo.embedding)
            return (photo, score)
        }
        
        // 3. Sort by score in descending order (highest similarity first).
        let sortedPhotos = scoredPhotos
            .sorted { $0.1 > $1.1 }
            .map { $0.0 }
        
        // 4. Return the top N results.
        return Array(sortedPhotos.prefix(limit))
    }
    
    /// Calculates the Cosine Similarity between two vectors.
    /// Formula: (A · B) / (||A|| * ||B||)
    ///
    /// Cosine similarity measures the cosine of the angle between two vectors.
    /// - A value of 1.0 means the vectors are identical in direction.
    /// - A value of 0.0 means they are orthogonal (unrelated).
    /// - A value of -1.0 means they are diametrically opposed.
    private func cosineSimilarity(_ a: Embedding, _ b: Embedding) -> Double {
        let vecA = a.values
        let vecB = b.values
        
        // Optimization: Use Accelerate framework's vDSP for high-performance math.
        // This is significantly faster than a standard 'for' loop for large vectors.
        
        // Calculate Dot Product (A · B)
        var dotProduct: Double = 0
        vDSP_dotprD(vecA, 1, vecB, 1, &dotProduct, vDSP_Length(vecA.count))
        
        // Calculate Magnitude of A (||A||)
        var magnitudeA: Double = 0
        vDSP_svesqD(vecA, 1, &magnitudeA, vDSP_Length(vecA.count))
        magnitudeA = sqrt(magnitudeA)
        
        // Calculate Magnitude of B (||B||)
        var magnitudeB: Double = 0
        vDSP_svesqD(vecB, 1, &magnitudeB, vDSP_Length(vecB.count))
        magnitudeB = sqrt(magnitudeB)
        
        // Avoid division by zero
        guard magnitudeA > 0 && magnitudeB > 0 else { return 0.0 }
        
        return dotProduct / (magnitudeA * magnitudeB)
    }
}

// MARK: - Real-World Usage Example

@available(iOS 18.0, macOS 15.0, *)
@MainActor
class PhotoSearchViewModel: ObservableObject {
    @Published var searchResults: [Photo] = []
    @Published var isSearching = false
    @Published var errorMessage: String?
    
    private let engine = SemanticSearchEngine()
    
    /// Simulates the initialization of the app with some data.
    func setupMockData() async {
        // Mocking embeddings: In a real app, these come from OpenAI or a local CLIP model.
        // Let's assume a 3-dimensional space for simplicity in this demo.
        let sunsetPhoto = Photo(
            id: UUID(),
            filename: "sunset_beach.jpg",
            embedding: Embedding(values: [0.9, 0.1, 0.0]) // High value in dim 0
        )
        
        let mountainPhoto = Photo(
            id: UUID(),
            filename: "snowy_peaks.jpg",
            embedding: Embedding(values: [0.1, 0.8, 0.1]) // High value in dim 1
        )
        
        let oceanPhoto = Photo(
            id: UUID(),
            filename: "blue_ocean.jpg",
            embedding: Embedding(values: [0.8, 0.2, 0.1]) // Similar to sunset
        )
        
        await engine.index(photo: sunsetPhoto)
        await engine.index(photo: mountainPhoto)
        await engine.index(photo: oceanPhoto)
    }
    
    /// Simulates a user typing a search query.
    func performSearch(query: String) async {
        isSearching = true
        errorMessage = nil
        
        // In a real app, you would send 'query' to an LLM/Embedding API to get a vector.
        // Here, we simulate a user searching for something "ocean-like".
        let simulatedQueryVector = Embedding(values: [0.85, 0.15, 0.05])
        
        do {
            let results = try await engine.search(queryEmbedding: simulatedQueryVector)
            self.searchResults = results
        } catch {
            self.errorMessage = "Search failed: \(error.localizedDescription)"
        }
        
        isSearching = false
    }
}
