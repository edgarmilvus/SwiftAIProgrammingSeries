
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
import AppleIntelligence

actor SummarizationCache {
    private var cachedSummaries: [String: String] = [:] // Mutable state

    // Simulate the actual summarization API call
    private func performSummarization(for text: String) async throws -> String {
        // In a real app, this would call Apple Intelligence's API
        try await Task.sleep(for: .seconds(1))
        return "Summary of: \(text.prefix(50))..."
    }

    func getOrComputeSummary(for text: String) async throws -> String {
        // Access to cachedSummaries is isolated by the actor
        if let cached = cachedSummaries[text] {
            print("Returning cached summary.")
            return cached
        }

        print("Computing new summary...")
        let newSummary = try await performSummarization(for: text)
        self.cachedSummaries[text] = newSummary // Mutating state safely
        return newSummary
    }

    func clearCache() {
        cachedSummaries.removeAll() // Mutating state safely
    }
}

// Example usage
@available(iOS 18.0, *)
func demonstrateActorIsolation() {
    let cache = SummarizationCache()

    Task {
        let text1 = "The quick brown fox jumps over the lazy dog."
        let summary1 = try await cache.getOrComputeSummary(for: text1)
        print("Task 1 Summary: \(summary1)")

        let summary1Again = try await cache.getOrComputeSummary(for: text1)
        print("Task 1 Summary (cached): \(summary1Again)")
    }

    Task {
        let text2 = "Apple Intelligence brings powerful AI to your device."
        let summary2 = try await cache.getOrComputeSummary(for: text2)
        print("Task 2 Summary: \(summary2)")
    }
}
