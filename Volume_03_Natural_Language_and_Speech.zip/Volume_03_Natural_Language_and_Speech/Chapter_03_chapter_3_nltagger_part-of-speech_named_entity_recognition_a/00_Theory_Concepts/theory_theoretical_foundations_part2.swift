
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import NaturalLanguage
import Observation // For @Observable

@available(iOS 18.0, *)
@Observable
class NLAnalysisViewModel {
    var inputText: String = "The quick brown fox jumps over the lazy dog."
    var posTags: [String] = []
    var namedEntities: [String] = []
    var lemmas: [String] = []
    var isLoading: Bool = false
    var errorMessage: String?

    private let textProcessor = TextProcessor() // Our actor

    @MainActor
    func performAnalysis() async {
        isLoading = true
        errorMessage = nil
        posTags = []
        namedEntities = []
        lemmas = []

        do {
            let schemes: [NLTagScheme] = [.lexicalClass, .nameType, .lemma]
            let analysisResult = try await textProcessor.analyzeText(inputText, schemes: schemes)
            
            if let tags = analysisResult["PoS Tags"] {
                posTags = tags
            }
            if let entities = analysisResult["Named Entities"] {
                namedEntities = entities
            }
            if let lms = analysisResult["Lemmas"] {
                lemmas = lms
            }
        } catch {
            errorMessage = "Failed to analyze text: \(error.localizedDescription)"
        }
        isLoading = false
    }
}
