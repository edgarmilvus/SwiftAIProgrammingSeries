
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

/// A protocol for interacting with an LLM service.
/// This allows us to swap out different LLM providers (e.g., llama.cpp, Ollama, remote API)
/// without changing the actor logic.
protocol LLMServiceProtocol: Sendable {
    func performInference(request: LLMRequest) async throws -> LLMResponse
    var modelName: String { get }
}

/// A mock implementation of `LLMServiceProtocol` for demonstration purposes.
/// Simulates network delays and potential inference failures.
actor MockLLMService: LLMServiceProtocol {
    let modelName: String = "Mock-Llama-7B-v2"
    private var inferenceCount: Int = 0

    /// Simulates performing an LLM inference request.
    /// - Parameter request: The `LLMRequest` containing the prompt and context.
    /// - Returns: An `LLMResponse` with generated text.
    /// - Throws: `AgentError.llmInferenceFailed` for simulated errors.
    func performInference(request: LLMRequest) async throws -> LLMResponse {
        inferenceCount += 1
        print("[\(Date().formatted(date: .omitted, time: .standard))] MockLLMService: Performing inference #\(inferenceCount) for \(request.documentID.uuidString.prefix(8))...")

        // Simulate network/computation delay
        try await Task.sleep(for: .seconds(Double.random(in: 1.0...3.0)))

        // Simulate occasional failures
        if Bool.random() && inferenceCount % 5 == 0 { // 20% chance of failure every 5th request
            print("[\(Date().formatted(date: .omitted, time: .standard))] MockLLMService: Simulated failure for request \(request.documentID.uuidString.prefix(8))...")
            throw AgentError.llmInferenceFailed(reason: "Simulated inference error due to resource contention.")
        }

        let generatedText: String
        if request.prompt.contains("Summarize") {
            generatedText = "This document discusses advanced Swift concurrency with actors for AI agent design, covering error handling and resource management on Apple Silicon."
        } else if request.prompt.contains("answer the question") {
            let question = request.prompt.split(separator: "'")[1]
            generatedText = "The answer to '\(question)' is a complex topic involving Swift's actor model and its application in AI."
        } else if request.prompt.contains("Categorize") {
             generatedText = ["Technology", "AI/ML", "Software Development"].randomElement()!
        } else {
            generatedText = "Mock LLM response for: '\(request.prompt.prefix(50))...'"
        }

        return LLMResponse(
            requestID: request.documentID,
            generatedText: generatedText,
            modelName: self.modelName,
            completionTime: Double.random(in: 1.5...3.5),
            tokensUsed: Int.random(in: 200...800)
        )
    }
}
