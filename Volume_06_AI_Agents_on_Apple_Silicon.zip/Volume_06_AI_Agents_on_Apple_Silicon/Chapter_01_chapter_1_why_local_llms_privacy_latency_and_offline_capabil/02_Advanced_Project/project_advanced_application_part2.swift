
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

// MARK: - 1. Error Handling and Data Models

/// Custom errors specific to our document processing operations.
enum DocumentProcessingError: Error, LocalizedError {
    case textExtractionFailed(reason: String)
    case llmServiceError(reason: String)
    case invalidDocumentContent
    case operationCancelled

    var errorDescription: String? {
        switch self {
        case .textExtractionFailed(let reason):
            return "Failed to extract text from document: \(reason)"
        case .llmServiceError(let reason):
            return "Local LLM service error: \(reason)"
        case .invalidDocumentContent:
            return "Document content is empty or invalid."
        case .operationCancelled:
            return "Document processing operation was cancelled."
        }
    }
}

/// Represents an input document with its identifier and raw text content.
struct Document: Identifiable, Hashable {
    let id: UUID
    let title: String
    let rawContent: String // The extracted text from the document.
    let creationDate: Date

    init(id: UUID = UUID(), title: String, rawContent: String, creationDate: Date = Date()) {
        self.id = id
        self.title = title
        self.rawContent = rawContent
        self.creationDate = creationDate
    }
}

/// Represents a document after it has been processed by the LLM.
struct ProcessedDocument: Identifiable, Hashable {
    let id: UUID
    let originalDocumentID: UUID
    let processedContent: String // The summarized or redacted text.
    let operationType: String // e.g., "Summary", "Redaction", "Analysis"
    let processingDate: Date

    init(id: UUID = UUID(), originalDocumentID: UUID, processedContent: String, operationType: String, processingDate: Date = Date()) {
        self.id = id
        self.originalDocumentID = originalDocumentID
        self.processedContent = processedContent
        self.operationType = operationType
        self.processingDate = processingDate
    }
}
