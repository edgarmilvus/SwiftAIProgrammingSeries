
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CoreData
import Foundation

/// A custom merge policy for AuraPersona to handle semantic conflicts.
/// Adheres to Swift 6 Sendable requirements for safe background execution.
final class PersonaMergePolicy: NSMergePolicy, @unchecked Sendable {
    
    init() {
        // Default to a base policy, though we will override the resolution logic.
        super.init(mergeType: .mergeByPropertyObjectTrumpMergePolicyType)
    }
    
    override func resolve(optimisticLockingConflicts list: [NSMergeConflict]) throws {
        for conflict in list {
            guard let object = conflict.sourceObject as? AuraPersona else {
                try super.resolve(optimisticLockingConflicts: [conflict])
                continue
            }
            
            let localValues = object.changedValues()
            let storeValues = conflict.objectSnapshot ?? [:]
            
            // 1. Handle 'name' conflict: Local changes take precedence.
            // If name was changed locally, we keep it. 
            // Edge Case: If both changed, we use lexicographical order for determinism.
            if let localName = localValues["name"] as? String,
               let storeName = storeValues["name"] as? String {
                if localName != storeName {
                    // Deterministic tie-breaker: pick the "larger" string to avoid sync loops
                    let winner = localName > storeName ? localName : storeName
                    object.setValue(winner, forKey: "name")
                }
            }
            
            // 2. Handle 'personalityTrait' conflict: Timestamp-based reconciliation.
            let localTimestamp = object.lastModified ?? Date.distantPast
            let storeTimestamp = storeValues["lastModified"] as? Date ?? Date.distantPast
            
            if let localTrait = localValues["personalityTrait"] as? String,
               let storeTrait = storeValues["personalityTrait"] as? String {
                
                if localTrait != storeTrait {
                    if storeTimestamp > localTimestamp {
                        // Server version is newer, adopt server trait
                        object.setValue(storeTrait, forKey: "personalityTrait")
                    } else {
                        // Local version is newer or equal, keep local trait
                        // (Already set in the object, but we ensure logic is explicit)
                    }
                }
            }
            
            // 3. Ensure lastModified is synchronized to the most recent of the two
            object.lastModified = max(localTimestamp, storeTimestamp)
        }
        
        // Finalize the resolution for the processed conflicts
        try super.resolve(optimisticLockingConflicts: list)
    }
}

// MARK: - Mock Entity for Context
@objc(AuraPersona)
public class AuraPersona: NSManagedObject {
    @NSManaged public var name: String?
    @NSManaged public var personalityTrait: String?
    @NSManaged public var lastModified: Date?
}
