
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import AVFoundation
import Vision

class FaceDetectionViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {

    private var captureSession: AVCaptureSession!
    private var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    private var overlayLayer: CALayer! // Layer to hold all detection overlays

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
        setupVisionOverlay()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        videoPreviewLayer?.frame = view.bounds
        overlayLayer?.frame = view.bounds
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !captureSession.isRunning {
            DispatchQueue.global(qos: .userInitiated).async {
                self.captureSession.startRunning()
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession.isRunning {
            captureSession.stopRunning()
        }
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .hd1280x720

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
            print("Failed to get the camera device.")
            return
        }

        do {
            let videoInput = try AVCaptureDeviceInput(device: videoDevice)
            if captureSession.canAddInput(videoInput) {
                captureSession.addInput(videoInput)
            } else {
                print("Could not add video input to the session")
                return
            }
        } catch {
            print("Could not create video device input: \(error)")
            return
        }

        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        videoOutput.alwaysDiscardsLateVideoFrames = true
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        } else {
            print("Could not add video output to the session")
            return
        }

        // Set up video orientation for the output
        if let connection = videoOutput.connection(with: .video), connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait
            connection.isPortraitUpsideDown = false // Or true, depending on desired front camera behavior
        }

        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        videoPreviewLayer.videoGravity = .resizeAspectFill
        videoPreviewLayer.frame = view.bounds
        view.layer.addSublayer(videoPreviewLayer)

        // For front camera, mirror the preview layer
        if videoDevice.position == .front {
            videoPreviewLayer.setAffineTransform(CGAffineTransform(scaleX: -1, y: 1))
        }
    }

    private func setupVisionOverlay() {
        overlayLayer = CALayer()
        overlayLayer.frame = view.bounds
        overlayLayer.sublayerTransform = videoPreviewLayer.sublayerTransform // Inherit transform for correct mirroring
        videoPreviewLayer.addSublayer(overlayLayer)
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        let faceDetectionRequest = VNDetectFaceRectanglesRequest { [weak self] request, error in
            guard let self = self else { return }
            if let error = error {
                print("Face detection error: \(error.localizedDescription)")
                return
            }
            self.drawFaceOverlays(for: request.results as? [VNFaceObservation])
        }

        // Set up request to process the image in the correct orientation
        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up)
        
        do {
            try imageRequestHandler.perform([faceDetectionRequest])
        } catch {
            print("Failed to perform Vision request: \(error)")
        }
    }

    private func drawFaceOverlays(for observations: [VNFaceObservation]?) {
        DispatchQueue.main.async {
            self.overlayLayer.sublayers?.forEach { $0.removeFromSuperlayer() } // Clear previous overlays

            guard let observations = observations else { return }

            for observation in observations {
                // Convert Vision bounding box to AVCaptureVideoPreviewLayer coordinates
                let boundingBox = observation.boundingBox
                let convertedRect = self.videoPreviewLayer.rectForMetadataOutputRectOfInterest(boundingBox)

                // Bounding Box Layer
                let shapeLayer = CAShapeLayer()
                shapeLayer.frame = convertedRect
                shapeLayer.borderColor = UIColor.green.cgColor
                shapeLayer.borderWidth = 2.0
                shapeLayer.cornerRadius = 5.0
                self.overlayLayer.addSublayer(shapeLayer)

                // Confidence Text Layer
                let confidenceText = String(format: "Confidence: %.2f", observation.confidence)
                let textLayer = CATextLayer()
                textLayer.string = confidenceText
                textLayer.foregroundColor = UIColor.white.cgColor
                textLayer.backgroundColor = UIColor.black.withAlphaComponent(0.5).cgColor
                textLayer.fontSize = 12
                textLayer.alignmentMode = .center
                textLayer.contentsScale = UIScreen.main.scale // Important for high-res text

                // Position text layer above the bounding box
                let textHeight: CGFloat = 20
                textLayer.frame = CGRect(x: convertedRect.origin.x,
                                         y: convertedRect.origin.y - textHeight - 5,
                                         width: convertedRect.size.width,
                                         height: textHeight)
                self.overlayLayer.addSublayer(textLayer)
            }
        }
    }
}
