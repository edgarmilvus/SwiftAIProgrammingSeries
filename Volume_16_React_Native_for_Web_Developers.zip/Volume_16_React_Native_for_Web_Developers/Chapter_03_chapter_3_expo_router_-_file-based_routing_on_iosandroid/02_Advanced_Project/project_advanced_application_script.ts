/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ==============================================================================
 * FILE: app/layout.tsx
 * PURPOSE: Root Layout (Universal Shell). Acts as the primary container for
 *          all routes, similar to a root navigator in Expo Router.
 *          This is a Server Component by default.
 * ==============================================================================
 */
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Providers } from './providers'; // Client Context wrapper

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'SaaS Universal Dashboard',
  description: 'A multi-tenant application using file-based routing',
};

export default function RootLayout({
  children,
  modal, // Parallel Route slot for intercepting modals
}: {
  children: React.ReactNode;
  modal: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>
          {/* Global Navigation Header */}
          <nav className="border-b p-4">
            <h1 className="font-bold text-lg">SaaS Platform</h1>
          </nav>
          
          {/* Main Content Area */}
          <main className="p-4">
            {children}
          </main>

          {/* 
            Modal Slot: If a route matches the `@modal` convention, 
            it renders here. Otherwise, it remains empty.
            This enables "intercepting routes" (e.g., clicking a project 
            from the list opens a modal, but navigating directly to the 
            URL renders a full page).
          */}
          {modal}
        </Providers>
      </body>
    </html>
  );
}
