
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

// Example of how valueAndGradient would be used conceptually
import MLX
import MLXNN

@available(iOS 18.0, *)
class MyModel: MLXNN.Module {
    // ... (model definition as above) ...
    func callAsFunction(_ input: MLXArray) -> MLXArray {
        // ... forward pass ...
        return input // Placeholder
    }
}

@available(iOS 18.0, *)
func lossFunction(model: MyModel, input: MLXArray, target: MLXArray) -> MLXArray {
    let prediction = model(input)
    // Example: Mean Squared Error loss
    return MLX.mean(MLX.square(prediction - target))
}

@available(iOS 18.0, *)
func theoreticalTrainingStep() {
    let model = MyModel(inputFeatures: 10, hiddenFeatures: 20, outputFeatures: 1)
    let input = MLXArray.randomUniform([1, 10]) // Batch size 1, 10 features
    let target = MLXArray.randomUniform([1, 1])

    // Define the function that we want to differentiate
    // We bind the input and target, so the differentiated function only takes the model's parameters
    let lossFn = { (model: MyModel) in
        lossFunction(model: model, input: input, target: target)
    }

    // Compute the loss and its gradient with respect to the model's parameters
    let (loss, gradients) = valueAndGradient(lossFn)(model)

    print("Loss: \(loss.item())")
    // 'gradients' is an MLXArray representing the gradient of the loss
    // with respect to the model's parameters.
    // You would then use an optimizer (e.g., SGD, Adam) to update model.parameters.
}
