
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
class DocumentAnalysisService {
    private let documentClassifier: DocumentClassifier
    private let dataDetector: NSDataDetector

    /// Initializes the service, loading the Core ML model and setting up data detectors.
    /// - Throws: `DocumentAnalysisError.modelNotFound` if the Core ML model cannot be loaded.
    init() throws {
        self.documentClassifier = try DocumentClassifier()
        do {
            // NSDataDetector can detect dates, addresses, links, phone numbers, and transit information.
            // We're interested in dates and amounts (amounts are often detected as numbers by NLTagger or custom regex).
            // For amounts, we'll primarily rely on NLTagger's numbers and then filter.
            self.dataDetector = try NSDataDetector(types: NSTextCheckingResult.CheckingType.date.rawValue)
        } catch {
            throw DocumentAnalysisError.dataDetectorError(error)
        }
    }

    /// Processes a document image, extracting text, classifying its type, and detecting key entities.
    /// This is an asynchronous operation suitable for Swift 6 concurrency.
    /// - Parameter image: The `CGImage` of the document to process.
    /// - Returns: A `DocumentAnalysisResult` containing the classified type, extracted text, and detected entities.
    /// - Throws: `DocumentAnalysisError` if any step in the process fails.
    func analyzeDocument(image: CGImage) async throws -> DocumentAnalysisResult {
        // 1. Text Extraction with Vision Framework
        /// This step uses Vision to recognize text from the image. It's an asynchronous operation.
        let extractedText = try await recognizeText(from: image)
        guard !extractedText.isEmpty else {
            throw DocumentAnalysisError.noTextFound
        }

        // 2. Document Classification with Core ML
        /// The extracted text is fed into our custom Core ML model to predict the document type.
        let (predictedLabel, confidence) = try documentClassifier.prediction(text: extractedText)
        let documentType = DocumentType(rawValue: predictedLabel) ?? .unknown

        // 3. Entity Extraction using Foundation's NSDataDetector and NaturalLanguage's NLTagger
        /// We use NSDataDetector for robust date detection and NLTagger for general number/currency detection.
        let detectedDates = detectDates(in: extractedText)
        let detectedAmounts = detectAmounts(in: extractedText)

        return DocumentAnalysisResult(
            documentType: documentType,
            extractedText: extractedText,
            detectedDates: detectedDates,
            detectedAmounts: detectedAmounts,
            confidence: confidence
        )
    }

    /// Asynchronously recognizes text from a `CGImage` using Vision framework.
    /// - Parameter image: The `CGImage` to process.
    /// - Returns: A `String` containing all recognized text, or an empty string if none.
    /// - Throws: `DocumentAnalysisError.textRecognitionFailed` if the Vision request fails.
    private func recognizeText(from image: CGImage) async throws -> String {
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNRecognizeTextRequest { request, error in
                if let error = error {
                    continuation.resume(throwing: DocumentAnalysisError.textRecognitionFailed(error))
                    return
                }

                guard let observations = request.results as? [VNRecognizedTextObservation] else {
                    continuation.resume(returning: "")
                    return
                }

                let recognizedText = observations.compactMap { observation in
                    // Get the top candidate for each text block.
                    observation.topCandidates(1).first?.string
                }.joined(separator: "\n") // Join lines with a newline character.

                continuation.resume(returning: recognizedText)
            }

            // Configure the request for accurate recognition.
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = true // Improves accuracy by correcting common errors.
            request.recognitionLanguages = ["en-US"] // Specify languages for better performance.

            let handler = VNImageRequestHandler(cgImage: image, options: [:])
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: DocumentAnalysisError.textRecognitionFailed(error))
            }
        }
    }

    /// Detects dates within the given text using `NSDataDetector`.
    /// - Parameter text: The text to search for dates.
    /// - Returns: An array of `Date` objects found in the text.
    private func detectDates(in text: String) -> [Date] {
        let matches = dataDetector.matches(in: text, options: [], range: NSRange(location: 0, length: text.utf16.count))
        return matches.compactMap { $0.date }
    }

    /// Detects potential monetary amounts within the given text.
    /// This uses `NLTagger` to find numbers and then attempts to parse them as Decimals.
    /// A more robust solution might involve regex for currency patterns.
    /// - Parameter text: The text to search for amounts.
    /// - Returns: An array of `Decimal` objects found in the text.
    private func detectAmounts(in text: String) -> [Decimal] {
        var amounts: [Decimal] = []
        let tagger = NLTagger(tagSchemes: [.lexicalClass])
        tagger.string = text

        // Iterate through tokens and identify numbers.
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lexicalClass, options: []) { tag, tokenRange in
            if let tag = tag, tag == .number {
                let numberString = String(text[tokenRange]).replacingOccurrences(of: ",", with: "") // Remove comma for parsing
                if let decimal = Decimal(string: numberString) {
                    // Simple heuristic: amounts are usually positive and often have decimal places.
                    // This is a basic example; real-world would need more sophisticated regex or context.
                    if decimal >= 0 { // Consider only positive amounts for typical documents
                        amounts.append(decimal)
                    }
                }
            }
            return true
        }
        return amounts
    }
}
