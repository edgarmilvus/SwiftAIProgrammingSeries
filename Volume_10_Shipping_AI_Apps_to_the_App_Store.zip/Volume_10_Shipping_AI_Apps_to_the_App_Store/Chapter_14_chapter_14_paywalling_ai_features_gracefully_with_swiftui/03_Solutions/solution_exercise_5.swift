
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import StoreKit

@available(iOS 18.0, *)
enum ProGateError: Error {
    case subscriptionRequired
}

@available(iOS 18.0, *)
@MainActor
class StoreManager: ObservableObject {
    @Published var isSubscribed: Bool = false
    
    // 1. Use StoreKit 2 to check for active subscriptions
    func updateSubscriptionStatus() async {
        var subscribed = false
        // Iterate through current entitlements
        for await result in Transaction.currentEntitlements {
            if case .verified(let transaction) = result {
                // Check if the transaction is for our specific product ID
                // In a real app, use: if transaction.productID == "pro_sub"
                if transaction.revocationDate == nil {
                    subscribed = true
                }
            }
        }
        self.isSubscribed = subscribed
    }
    
    func purchasePro() async -> Bool {
        // Mocking a successful purchase for this exercise
        try? await Task.sleep(for: .seconds(1))
        self.isSubscribed = true
        return true
    }
}

@available(iOS 18.0, *)
class ImageProcessingEngine {
    func applyGenerativeFill() async throws {
        // Simulate heavy AI work
        try await Task.sleep(for: .seconds(3))
        print("Generative Fill Applied!")
    }
}

@available(iOS 18.0, *)
struct LuminaEditorView: View {
    @StateObject private var storeManager = StoreManager()
    private let engine = ImageProcessingEngine()
    
    @State private var isProcessing = false
    @State private var showPaywall = false
    
    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: "photo.artframe")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 200, height: 200)
                .foregroundStyle(.gray.opacity(0.3))
            
            if isProcessing {
                VStack {
                    ProgressView()
                        .scaleEffect(1.5)
                    Text("Applying AI Magic...")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            } else {
                Button(action: {
                    Task {
                        await attemptGenerativeFill()
                    }
                }) {
                    Label("Apply Generative Fill", systemImage: "wand.and.stars")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(.blue, in: RoundedRectangle(cornerRadius: 15))
                        .foregroundStyle(.white)
                }
                .padding(.horizontal)
            }
        }
        .task {
            // Initial check when view appears
            await storeManager.updateSubscriptionStatus()
        }
        .sheet(isPresented: $showPaywall) {
            PremiumPaywallView(storeManager: storeManager) {
                // 5. Immediate Gratification: Re-trigger the action on success
                Task {
                    await attemptGenerativeFill()
                }
            }
        }
    }
    
    // 3. Orchestration Logic
    private func attemptGenerativeFill() async {
        // 1. Non-blocking check
        if storeManager.isSubscribed {
            isProcessing = true
            do {
                try await engine.applyGenerativeFill()
                isProcessing = false
            } catch {
                isProcessing = false
            }
        } else {
            // 2. Trigger paywall if not subscribed
            showPaywall = true
        }
    }
}

@available(iOS 18.0, *)
struct PremiumPaywallView: View {
    @ObservedObject var storeManager: StoreManager
    var onPurchaseSuccess: () -> Void
    
    var body: some View {
        VStack(spacing: 25) {
            Text("Generative Fill")
                .font(.largeTitle.bold())
            
            Image(systemName: "sparkles")
                .font(.system(size: 80))
                .foregroundStyle(
                    LinearGradient(colors: [.yellow, .orange], startPoint: .top, endPoint: .bottom)
                )
            
            VStack(spacing: 10) {
                Text("Unlock Pro Magic")
                    .font(.title2.bold())
                Text("Generative Fill uses heavy compute to expand your photos seamlessly. This feature is available for Pro members only.")
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal)
            
            Spacer()
            
            Button(action: {
                Task {
                    let success = await storeManager.purchasePro()
                    if success {
                        onPurchaseSuccess()
                    }
                }
            }) {
                Text("Get Pro Access")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(.black, in: RoundedRectangle(cornerRadius: 12))
            }
            .padding(.horizontal)
        }
        .padding(.top, 50)
    }
}
