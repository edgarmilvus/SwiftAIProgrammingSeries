
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

// ... (AudioInputManager from above)
@available(iOS 18.0, *)
class AudioInputManager: ObservableObject { // Or @Observable in Swift 6 directly
    // ...
    @Published var waveformPoints: [Float] = [] // In Swift 6, this would typically be @Observable
                                                // and the class would conform to Observable.
                                                // For broader compatibility, @ObservableObject with @Published is shown.
    // ...
}

@available(iOS 18.0, *)
struct WaveformView: View {
    @ObservedObject var audioManager: AudioInputManager // Or @Bindable for @Observable types

    var body: some View {
        Canvas { context, size in
            guard !audioManager.waveformPoints.isEmpty else { return }

            let horizontalScale = size.width / CGFloat(audioManager.waveformPoints.count / 2) // Assuming peak/trough pairs
            let verticalScale = size.height / 2 // Center the waveform

            var path = Path()
            path.move(to: CGPoint(x: 0, y: verticalScale))

            for i in stride(from: 0, to: audioManager.waveformPoints.count, by: 2) {
                let x = CGFloat(i / 2) * horizontalScale
                let peak = CGFloat(audioManager.waveformPoints[i])
                let trough = CGFloat(audioManager.waveformPoints[i+1])

                // Scale amplitude values to UI coordinates
                let yPeak = verticalScale - (peak * verticalScale)
                let yTrough = verticalScale - (trough * verticalScale)

                // Draw vertical line from trough to peak
                path.addLines([
                    CGPoint(x: x, y: yTrough),
                    CGPoint(x: x, y: yPeak)
                ])
            }

            context.stroke(path, with: .color(.blue), lineWidth: 1)
        }
        .frame(height: 200)
        .background(Color.black)
    }
}
