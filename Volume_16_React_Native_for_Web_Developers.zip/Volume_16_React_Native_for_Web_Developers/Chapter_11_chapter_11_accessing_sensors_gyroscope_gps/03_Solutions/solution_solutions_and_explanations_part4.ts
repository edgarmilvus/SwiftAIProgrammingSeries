/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { Accelerometer } from 'expo-sensors';

interface MotionToggleProps {
  label: string;
  onToggle: (isOn: boolean) => void;
}

export default function MotionToggle({ label, onToggle }: MotionToggleProps) {
  const [isOn, setIsOn] = useState(false);
  const [isCoolingDown, setIsCoolingDown] = useState(false);
  
  // Refs to manage state inside listeners without re-rendering
  const isCoolingDownRef = useRef(false);
  const isOnRef = useRef(false);

  useEffect(() => {
    // Threshold for shake detection (approx 2.5 G-force)
    // Note: 1G is roughly 9.81 m/s^2. Expo Accelerometer returns values in G's (approx -1 to 1).
    // However, "shake" usually implies rapid changes. 
    // Magnitude formula: sqrt(x^2 + y^2 + z^2). 
    // A resting phone is ~1.0. A vigorous shake can spike > 2.0 or rapid delta changes.
    const THRESHOLD = 2.2; 

    const subscription = Accelerometer.addListener(accelerometerData => {
      const { x, y, z } = accelerometerData;
      
      // Calculate magnitude of acceleration
      const magnitude = Math.sqrt(x * x + y * y + z * z);

      // Check conditions: Threshold breached AND not cooling down
      if (magnitude > THRESHOLD && !isCoolingDownRef.current) {
        // Trigger Toggle
        const newState = !isOnRef.current;
        setIsOn(newState);
        isOnRef.current = newState;
        
        // Call parent callback
        if (onToggle) {
          onToggle(newState);
        }

        // Start Cooldown (Debouncing)
        isCoolingDownRef.current = true;
        setIsCoolingDown(true);

        // Reset cooldown after 1000ms
        setTimeout(() => {
          isCoolingDownRef.current = false;
          setIsCoolingDown(false);
        }, 1000);
      }
    });

    Accelerometer.setUpdateInterval(100);

    return () => subscription.remove();
  }, [onToggle]); // Re-run if onToggle callback changes

  return (
    <TouchableOpacity 
      style={[styles.container, { 
        backgroundColor: isCoolingDown ? '#555' : (isOn ? 'green' : 'red'),
        opacity: isCoolingDown ? 0.7 : 1
      }]}
      activeOpacity={0.8}
      // Optional: Allow manual toggle via touch as well
      onPress={() => {
        if (!isCoolingDown) {
          const newState = !isOn;
          setIsOn(newState);
          isOnRef.current = newState;
          if (onToggle) onToggle(newState);
        }
      }}
    >
      <Text style={styles.text}>{label}: {isOn ? 'ON' : 'OFF'}</Text>
      <Text style={styles.subtext}>
        {isCoolingDown ? 'Cooling down...' : (isOn ? 'Shake to turn OFF' : 'Shake to turn ON')}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    width: 220,
    height: 110,
    margin: 10,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  text: { color: 'white', fontSize: 18, fontWeight: 'bold' },
  subtext: { color: 'white', fontSize: 12, marginTop: 5, textAlign: 'center' },
});
