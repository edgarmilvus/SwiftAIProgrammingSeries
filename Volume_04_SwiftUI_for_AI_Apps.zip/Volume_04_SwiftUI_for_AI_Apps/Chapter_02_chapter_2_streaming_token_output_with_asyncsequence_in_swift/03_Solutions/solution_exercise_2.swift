
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import Foundation

// MARK: - Mock AsyncSequence for Chat Responses

struct MockChatResponseStream: AsyncSequence {
    typealias Element = String
    private let responseText: String
    private let delay: TimeInterval

    init(responseText: String, delay: TimeInterval = 0.05) {
        self.responseText = responseText
        self.delay = delay
    }

    func makeAsyncIterator() -> Iterator {
        // Simple tokenization: split by spaces and keep punctuation attached to words.
        // For more advanced tokenization, a regex could be used.
        let tokens = responseText.split(whereSeparator: \.isWhitespace).map(String.init)
        return Iterator(tokens: tokens, delay: delay)
    }

    struct Iterator: AsyncIteratorProtocol {
        private var tokens: [String]
        private let delay: TimeInterval

        init(tokens: [String], delay: TimeInterval) {
            self.tokens = tokens
            self.delay = delay
        }

        mutating func next() async throws -> String? {
            guard !tokens.isEmpty else { return nil }

            // Simulate delay
            try await Task.sleep(for: .seconds(delay))

            // Check for cancellation before emitting
            try Task.checkCancellation()

            return tokens.removeFirst()
        }
    }
}

// MARK: - SwiftUI View

struct ChatView: View {
    @State private var userInput: String = ""
    @State private var aiResponse: String = ""
    @State private var currentStreamTask: Task<Void, Never>?

    private let mockAIResponse = "Hello! I am an AI assistant ready to help you with your questions. How can I assist you today?"

    var body: some View {
        VStack(spacing: 15) {
            ScrollView {
                Text(aiResponse)
                    .font(.body)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(10)
                    .animation(.easeOut(duration: 0.05), value: aiResponse) // Smooth updates
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.gray.opacity(0.05))
            .cornerRadius(10)

            HStack {
                TextField("Ask me anything...", text: $userInput)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal, 5)

                Button("Send") {
                    sendChatMessage()
                }
                .buttonStyle(.borderedProminent)
                .disabled(currentStreamTask != nil) // Disable send button while streaming
            }
            .padding(.horizontal)
        }
        .padding(.vertical)
        .navigationTitle("AI Chat")
        .onDisappear {
            currentStreamTask?.cancel()
        }
    }

    private func sendChatMessage() {
        // Clear previous AI response and cancel any active stream
        currentStreamTask?.cancel()
        aiResponse = ""
        userInput = "" // Clear user input after sending

        // Start a new streaming task
        currentStreamTask = Task {
            let stream = MockChatResponseStream(responseText: mockAIResponse, delay: 0.05)
            do {
                for await token in stream {
                    // Update UI on the main actor
                    await MainActor.run {
                        // Append token, adding a space if it's not the first token
                        self.aiResponse += (self.aiResponse.isEmpty || token.first?.isPunctuation == true ? "" : " ") + token
                    }
                }
                await MainActor.run {
                    self.currentStreamTask = nil // Stream completed
                }
            } catch {
                if Task.isCancelled {
                    print("Chat stream cancelled.")
                } else {
                    print("Chat stream error: \(error.localizedDescription)")
                    await MainActor.run {
                        self.aiResponse = "Error: \(error.localizedDescription)"
                    }
                }
                await MainActor.run {
                    self.currentStreamTask = nil // Stream ended due to error or cancellation
                }
            }
        }
    }
}
