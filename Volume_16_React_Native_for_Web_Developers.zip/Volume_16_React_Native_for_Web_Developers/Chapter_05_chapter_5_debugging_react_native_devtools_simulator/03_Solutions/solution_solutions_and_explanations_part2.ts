/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Graphviz DOT Syntax for Exercise 2

// 1. Expo (Hermes) Debugging Lifecycle
digraph ExpoDebug {
  rankdir=LR;
  node [shape=box, style=filled, color=lightblue];
  
  DeveloperMachine [label="Developer Machine\n(Terminal / VS Code)"];
  MetroBundler [label="Metro Bundler\n(Port 8081)"];
  Simulator [label="iOS/Android Simulator\n(Hermes VM)"];
  ChromeDevTools [label="Chrome DevTools\n(react-native-devtools)"];

  DeveloperMachine -> MetroBundler [label="1. npx expo start"];
  MetroBundler -> Simulator [label="2. Bundle JS\n(HMR)"];
  DeveloperMachine -> Simulator [label="3. Press 'j' (Hermes Inspector)"];
  Simulator -> ChromeDevTools [label="4. WebSocket Connection\n(debugger.attach())"];
  ChromeDevTools -> Simulator [label="5. Debugger Commands\n(Pause, Step, Inspect)"];
}

// 2. Next.js Server Action Debugging Lifecycle
digraph NextDebug {
  rankdir=LR;
  node [shape=box, style=filled, color=lightgreen];
  
  DeveloperMachine [label="Developer Machine\n(VS Code)"];
  NextServer [label="Next.js Server\n(Node.js)"];
  VSCodeDebugger [label="VS Code Debugger"];
  BrowserClient [label="Browser Client\n(Frontend)"];

  BrowserClient -> NextServer [label="1. HTTP Request\n(Form Action / fetch)"];
  DeveloperMachine -> NextServer [label="2. Start Server\n(Inspector Port 9229)"];
  VSCodeDebugger -> NextServer [label="3. Attach on Port 9229"];
  NextServer -> VSCodeDebugger [label="4. Breakpoints / Call Stack"];
  NextServer -> BrowserClient [label="5. Return JSON Response"];
}
