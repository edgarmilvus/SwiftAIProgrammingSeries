
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import Foundation // For UUID, Data, etc.

// Ensure compatibility with iOS 18 for @Observable
@available(iOS 18.0, *)
struct SmartContractAnalyzerApp: App {
    var body: some Scene {
        WindowGroup {
            WorkflowCoordinatorView()
        }
    }
}

// MARK: - 1. Data Models

/// Represents a document being processed.
struct Document: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let content: String // Simplified: actual content would be URL to PDF, etc.
}

/// Represents an entity extracted by AI from the document.
struct ExtractedEntity: Identifiable, Hashable {
    let id = UUID()
    var type: String // e.g., "Party", "Date", "Amount", "Clause"
    var value: String
    var confidence: Double // AI confidence score (0.0 - 1.0)
    var requiresRefinement: Bool { confidence < 0.7 } // Threshold for refinement
}

/// Represents a specific clause analyzed by AI.
struct AnalyzedClause: Identifiable, Hashable {
    let id = UUID()
    let text: String
    let riskScore: Double // AI-assigned risk score
    let recommendations: [String]
}

// MARK: - 2. Workflow Steps Enum

/// Defines the distinct steps/views in our navigation path.
/// Conforms to `Hashable` for use with `NavigationPath`.
enum WorkflowStep: Hashable, Identifiable {
    case uploadDocument
    case entityReview
    case entityRefinement(entityID: UUID) // Dynamic step for a specific entity
    case clauseAnalysis
    case summaryExport

    var id: String {
        switch self {
        case .uploadDocument: return "uploadDocument"
        case .entityReview: return "entityReview"
        case .entityRefinement(let entityID): return "entityRefinement-\(entityID)"
        case .clauseAnalysis: return "clauseAnalysis"
        case .summaryExport: return "summaryExport"
        }
    }
}

// MARK: - 3. AIService (Simulated)

/// A simulated AI service for document processing.
/// In a real application, this would interact with CoreML models or cloud AI APIs.
@available(iOS 18.0, *)
class AIService {

    enum AIError: Error, LocalizedError {
        case processingFailed(reason: String)
        case modelUnavailable
        case timeout

        var errorDescription: String? {
            switch self {
            case .processingFailed(let reason): return "AI processing failed: \(reason)"
            case .modelUnavailable: return "AI model is currently unavailable."
            case .timeout: return "AI processing timed out. Please try again."
            }
        }
    }

    /// Simulates OCR and entity recognition.
    /// - Parameter document: The document to process.
    /// - Returns: An array of extracted entities.
    func performOCREntityRecognition(document: Document) async throws -> [ExtractedEntity] {
        print("AI Service: Starting OCR and Entity Recognition for '\(document.name)'...")
        try await Task.sleep(for: .seconds(2)) // Simulate network/processing delay

        // Simulate potential error
        if Bool.random() && document.name.contains("Error") {
            throw AIError.processingFailed(reason: "Document corrupted or unreadable.")
        }

        // Simulate entity extraction with varying confidence
        let entities = [
            ExtractedEntity(type: "Party", value: "Acme Corp.", confidence: 0.95),
            ExtractedEntity(type: "Party", value: "Globex Inc.", confidence: 0.8),
            ExtractedEntity(type: "Date", value: "January 1, 2024", confidence: 0.98),
            ExtractedEntity(type: "Amount", value: "$1,000,000", confidence: 0.6), // Low confidence
            ExtractedEntity(type: "Clause", value: "Indemnification clause...", confidence: 0.75),
            ExtractedEntity(type: "Term", value: "3 years", confidence: 0.55) // Low confidence
        ]
        print("AI Service: OCR and Entity Recognition complete.")
        return entities
    }

    /// Simulates clause-level risk analysis.
    /// - Parameter entities: The confirmed entities from the previous step.
    /// - Returns: An array of analyzed clauses.
    func analyzeClauses(entities: [ExtractedEntity]) async throws -> [AnalyzedClause] {
        print("AI Service: Starting Clause Analysis...")
        try await Task.sleep(for: .seconds(3)) // Simulate longer processing delay

        // Simulate potential error
        if Bool.random() && entities.contains(where: { $0.value.contains("Critical Error") }) {
            throw AIError.processingFailed(reason: "Critical clause analysis failure.")
        }

        let clauses = entities.filter { $0.type == "Clause" }.map { entity in
            // Simulate risk score based on content
            let risk = entity.value.contains("Indemnification") ? 0.8 : 0.2
            let recommendations = risk > 0.7 ? ["Review indemnification terms", "Consult legal counsel"] : []
            return AnalyzedClause(text: entity.value, riskScore: risk, recommendations: recommendations)
        }
        print("AI Service: Clause Analysis complete.")
        return clauses
    }
}

// MARK: - 4. DocumentWorkflowViewModel

/// Manages the state and navigation for the entire document processing workflow.
/// Conforms to `Observable` for SwiftUI's reactive updates (iOS 17+).
@available(iOS 18.0, *)
@Observable
class DocumentWorkflowViewModel {
    var navigationPath = NavigationPath()
    var currentDocument: Document?
    var extractedEntities: [ExtractedEntity] = []
    var analyzedClauses: [AnalyzedClause] = []
    var isLoading: Bool = false
    var errorMessage: String?
    var currentStep: WorkflowStep = .uploadDocument // Track current logical step for UI hints

    private let aiService = AIService()

    /// Starts the document processing workflow.
    /// - Parameter document: The document to begin processing.
    func startProcessing(document: Document) {
        self.currentDocument = document
        self.extractedEntities = []
        self.analyzedClauses = []
        self.errorMessage = nil
        self.navigationPath = NavigationPath() // Reset path for a new workflow
        self.navigationPath.append(WorkflowStep.entityReview) // Move to entity review immediately
        self.currentStep = .entityReview

        Task {
            await processDocument()
        }
    }

    /// Processes the document using AI for OCR and entity recognition.
    private func processDocument() async {
        guard let document = currentDocument else { return }

        isLoading = true
        errorMessage = nil
        do {
            let entities = try await aiService.performOCREntityRecognition(document: document)
            DispatchQueue.main.async {
                self.extractedEntities = entities
                self.isLoading = false
                self.checkForRefinementNeeds()
            }
        } catch {
            DispatchQueue.main.async {
                self.errorMessage = error.localizedDescription
                self.isLoading = false
            }
        }
    }

    /// Checks if any extracted entities require refinement and navigates accordingly.
    private func checkForRefinementNeeds() {
        if let entityToRefine = extractedEntities.first(where: { $0.requiresRefinement }) {
            print("Navigation: Entity '\(entityToRefine.value)' needs refinement. Pushing EntityRefinement view.")
            navigationPath.append(WorkflowStep.entityRefinement(entityID: entityToRefine.id))
        } else {
            print("Navigation: All entities confirmed. Moving to Clause Analysis.")
            navigationPath.append(WorkflowStep.clauseAnalysis)
            currentStep = .clauseAnalysis
            Task {
                await analyzeClauses()
            }
        }
    }

    /// Updates an entity after user refinement.
    /// - Parameters:
    ///   - entityID: The ID of the entity to update.
    ///   - newValue: The new value for the entity.
    func refineEntity(entityID: UUID, newValue: String) {
        if let index = extractedEntities.firstIndex(where: { $0.id == entityID }) {
            extractedEntities[index].value = newValue
            extractedEntities[index].confidence = 1.0 // Assume user correction makes it 100% confident
            print("Entity \(entityID) refined to: \(newValue).")
        }
        // Pop the refinement view and re-check for other entities needing refinement
        navigationPath.removeLast()
        checkForRefinementNeeds()
    }

    /// Performs AI analysis on the clauses.
    private func analyzeClauses() async {
        isLoading = true
        errorMessage = nil
        do {
            let clauses = try await aiService.analyzeClauses(entities: extractedEntities)
            DispatchQueue.main.async {
                self.analyzedClauses = clauses
                self.isLoading = false
                self.navigationPath.append(WorkflowStep.summaryExport)
                self.currentStep = .summaryExport
            }
        } catch {
            DispatchQueue.main.async {
                self.errorMessage = error.localizedDescription
                self.isLoading = false
            }
        }
    }

    /// Resets the workflow to the initial state.
    func resetWorkflow() {
        currentDocument = nil
        extractedEntities = []
        analyzedClauses = []
        errorMessage = nil
        navigationPath = NavigationPath()
        currentStep = .uploadDocument
    }
}

// MARK: - 5. Views

/// Initial view for uploading a document.
@available(iOS 18.0, *)
struct DocumentUploadView: View {
    @Environment(DocumentWorkflowViewModel.self) private var viewModel

    @State private var documentName: String = ""
    @State private var documentContent: String = "This is a sample contract document with Acme Corp. and Globex Inc. on January 1, 2024, for $1,000,000. It includes an indemnification clause and a term of 3 years. This document has an Error in its name to test error handling."

    var body: some View {
        VStack(spacing: 20) {
            Text("Upload Contract Document")
                .font(.title)
                .bold()

            TextField("Document Name", text: $documentName)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)

            TextEditor(text: $documentContent)
                .frame(height: 150)
                .border(Color.gray.opacity(0.3), width: 1)
                .padding(.horizontal)

            Button("Start AI Analysis") {
                let document = Document(name: documentName.isEmpty ? "Sample Contract" : documentName, content: documentContent)
                viewModel.startProcessing(document: document)
            }
            .buttonStyle(.borderedProminent)
            .disabled(viewModel.isLoading)

            if viewModel.isLoading {
                ProgressView("Analyzing document...")
            }
            if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .padding()
        .navigationTitle("Upload Document")
        .onChange(of: viewModel.currentStep) { oldStep, newStep in
            // Example of reacting to step changes if needed for UI elements outside NavigationStack
            print("Current workflow step changed to: \(newStep)")
        }
    }
}

/// View for reviewing extracted entities and initiating refinement.
@available(iOS 18.0, *)
struct EntityReviewView: View {
    @Environment(DocumentWorkflowViewModel.self) private var viewModel

    var body: some View {
        VStack {
            Text("Review Extracted Entities")
                .font(.title2)
                .bold()
                .padding(.bottom, 5)

            if viewModel.isLoading {
                ProgressView("Extracting entities...")
            } else if viewModel.extractedEntities.isEmpty && viewModel.currentDocument != nil {
                Text("No entities extracted yet or processing failed.")
                    .foregroundColor(.gray)
            } else {
                List {
                    ForEach(viewModel.extractedEntities) { entity in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(entity.type)
                                    .font(.headline)
                                Text(entity.value)
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            if entity.requiresRefinement {
                                Label("Needs Review", systemImage: "exclamationmark.triangle.fill")
                                    .font(.caption)
                                    .foregroundColor(.orange)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            Spacer()

            if !viewModel.extractedEntities.isEmpty && !viewModel.isLoading {
                Button("Confirm Entities & Continue") {
                    // This button acts as a fallback to trigger next step if no entities need refinement
                    // The checkForRefinementNeeds in ViewModel handles automatic navigation
                    viewModel.checkForRefinementNeeds()
                }
                .buttonStyle(.borderedProminent)
                .disabled(viewModel.extractedEntities.contains(where: { $0.requiresRefinement }))
            }
            if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .padding()
        .navigationTitle("Entity Review")
        .onAppear {
            // If we navigate back here, ensure we re-check for refinement
            if !viewModel.extractedEntities.isEmpty && !viewModel.isLoading {
                viewModel.checkForRefinementNeeds()
            }
        }
    }
}

/// View for manually refining a specific entity.
@available(iOS 18.0, *)
struct EntityDetailView: View {
    @Environment(DocumentWorkflowViewModel.self) private var viewModel
    let entityID: UUID

    @State private var editedValue: String = ""

    var entity: ExtractedEntity? {
        viewModel.extractedEntities.first(where: { $0.id == entityID })
    }

    var body: some View {
        VStack(spacing: 20) {
            if let entity = entity {
                Text("Refine \(entity.type)")
                    .font(.title2)
                    .bold()

                Text("Original Value: \(entity.value)")
                    .foregroundColor(.secondary)

                TextField("Corrected Value", text: $editedValue)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                    .onAppear {
                        editedValue = entity.value // Pre-fill with current value
                    }

                Button("Save Correction") {
                    viewModel.refineEntity(entityID: entity.id, newValue: editedValue)
                }
                .buttonStyle(.borderedProminent)
                .disabled(editedValue.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

            } else {
                Text("Entity not found.")
                    .foregroundColor(.red)
            }
        }
        .padding()
        .navigationTitle("Refine Entity")
    }
}

/// View displaying the results of clause analysis.
@available(iOS 18.0, *)
struct ClauseAnalysisView: View {
    @Environment(DocumentWorkflowViewModel.self) private var viewModel

    var body: some View {
        VStack {
            Text("AI Clause Analysis")
                .font(.title2)
                .bold()
                .padding(.bottom, 5)

            if viewModel.isLoading {
                ProgressView("Analyzing clauses...")
            } else if viewModel.analyzedClauses.isEmpty {
                Text("No clauses analyzed yet or processing failed.")
                    .foregroundColor(.gray)
            } else {
                List {
                    ForEach(viewModel.analyzedClauses) { clause in
                        VStack(alignment: .leading) {
                            Text(clause.text)
                                .font(.headline)
                            HStack {
                                Text("Risk Score: \(clause.riskScore, format: .percent)")
                                    .foregroundColor(clause.riskScore > 0.7 ? .red : .green)
                                Spacer()
                                if !clause.recommendations.isEmpty {
                                    Label("Recommendations", systemImage: "lightbulb.fill")
                                        .font(.caption)
                                        .foregroundColor(.blue)
                                }
                            }
                            if !clause.recommendations.isEmpty {
                                ForEach(clause.recommendations, id: \.self) { rec in
                                    Text("• \(rec)").font(.caption).foregroundColor(.secondary)
                                }
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            Spacer()
            if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .padding()
        .navigationTitle("Clause Analysis")
    }
}

/// Final summary and export view.
@available(iOS 18.0, *)
struct SummaryExportView: View {
    @Environment(DocumentWorkflowViewModel.self) private var viewModel

    var body: some View {
        VStack(spacing: 20) {
            Text("Analysis Complete!")
                .font(.title)
                .bold()

            Text("Document: \(viewModel.currentDocument?.name ?? "N/A")")
                .font(.headline)

            Text("Total Entities Extracted: \(viewModel.extractedEntities.count)")
            Text("Total Clauses Analyzed: \(viewModel.analyzedClauses.count)")

            Button("Export Report") {
                print("Exporting analysis report...")
                // Simulate export
            }
            .buttonStyle(.borderedProminent)

            Button("Start New Workflow") {
                viewModel.resetWorkflow()
            }
            .buttonStyle(.bordered)
            .tint(.secondary)
        }
        .padding()
        .navigationTitle("Summary & Export")
    }
}

// MARK: - 6. WorkflowCoordinatorView (Root Navigation Host)

/// The root view that hosts the NavigationStack and manages the workflow's environment object.
@available(iOS 18.0, *)
struct WorkflowCoordinatorView: View {
    @State private var viewModel = DocumentWorkflowViewModel()

    var body: some View {
        NavigationStack(path: $viewModel.navigationPath) {
            // The initial view when the app starts or workflow is reset
            DocumentUploadView()
                .navigationDestination(for: WorkflowStep.self) { step in
                    switch step {
                    case .uploadDocument:
                        DocumentUploadView()
                    case .entityReview:
                        EntityReviewView()
                    case .entityRefinement(let entityID):
                        EntityDetailView(entityID: entityID)
                    case .clauseAnalysis:
                        ClauseAnalysisView()
                    case .summaryExport:
                        SummaryExportView()
                    }
                }
        }
        .environment(viewModel) // Make the ViewModel available to all child views
    }
}
