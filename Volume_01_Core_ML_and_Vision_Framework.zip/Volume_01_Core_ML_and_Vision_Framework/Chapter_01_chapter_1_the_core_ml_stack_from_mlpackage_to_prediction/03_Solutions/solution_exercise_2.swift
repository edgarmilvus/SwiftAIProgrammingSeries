
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import AVFoundation
import CoreML
import Vision // Used for CVPixelBuffer and image processing, often for Core ML models too
import CoreGraphics // For drawing bounding boxes

// MARK: - Helper: CVPixelBuffer to UIImage Conversion (for visualization)
// Useful for debugging or displaying processed frames
extension CVPixelBuffer {
    func toUIImage() -> UIImage? {
        let ciImage = CIImage(cvPixelBuffer: self)
        let context = CIContext()
        guard let cgImage = context.createCGImage(ciImage, from: ciImage.extent) else { return nil }
        return UIImage(cgImage: cgImage)
    }
}

// MARK: - Object Detection Data Structures
struct Detection {
    var boundingBox: CGRect // Normalized 0-1 coordinates
    var confidence: Float
    var classLabel: String
    var classIndex: Int
}

// MARK: - Helper: Non-Maximum Suppression (NMS)
// A common algorithm to filter out overlapping bounding boxes.
class NMS {
    static func apply(detections: [Detection], iouThreshold: Float, scoreThreshold: Float) -> [Detection] {
        guard !detections.isEmpty else { return [] }

        // Sort detections by confidence in descending order
        let sortedDetections = detections.sorted { $0.confidence > $1.confidence }
        var selectedDetections: [Detection] = []
        var suppressedIndices: Set<Int> = []

        for (i, detection) in sortedDetections.enumerated() {
            if suppressedIndices.contains(i) { continue }
            if detection.confidence < scoreThreshold { continue }

            selectedDetections.append(detection)
            suppressedIndices.insert(i)

            for (j, otherDetection) in sortedDetections.enumerated() {
                if suppressedIndices.contains(j) { continue }
                if detection.classIndex != otherDetection.classIndex { continue } // NMS per class

                let iou = NMS.iou(box1: detection.boundingBox, box2: otherDetection.boundingBox)
                if iou > iouThreshold {
                    suppressedIndices.insert(j)
                }
            }
        }
        return selectedDetections
    }

    // Intersection over Union (IoU) calculation
    private static func iou(box1: CGRect, box2: CGRect) -> Float {
        let intersection = box1.intersection(box2)
        let intersectionArea = intersection.width * intersection.height

        let box1Area = box1.width * box1.height
        let box2Area = box2.width * box2.height

        let unionArea = box1Area + box2Area - intersectionArea

        if unionArea == 0 { return 0 }
        return Float(intersectionArea / unionArea)
    }
}

// MARK: - ObjectDetector (Assumed auto-generated Core ML model interface)
// For demonstration, let's define a simplified mock interface.
// In a real project, Xcode generates this from your .mlpackage.
// Assume a model with a single image input and two MLMultiArray outputs:
// - `boxes`: (num_detections, 4) -> [x, y, width, height] (normalized 0-1)
// - `scores`: (num_detections, num_classes) -> class probabilities
// - `labels`: (num_detections) -> class index
struct ObjectDetectorInput: MLFeatureProvider {
    var image: CVPixelBuffer

    var featureNames: Set<String> { return ["image"] }
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "image" { return MLFeatureValue(pixelBuffer: image) }
        return nil
    }
}

struct ObjectDetectorOutput: MLFeatureProvider {
    var boxes: MLMultiArray // (num_detections, 4)
    var scores: MLMultiArray // (num_detections, num_classes)
    var labels: MLMultiArray // (num_detections)

    var featureNames: Set<String> { return ["boxes", "scores", "labels"] }
    func featureValue(for featureName: String) -> MLFeatureValue? {
        switch featureName {
        case "boxes": return MLFeatureValue(multiArray: boxes)
        case "scores": return MLFeatureValue(multiArray: scores)
        case "labels": return MLFeatureValue(multiArray: labels)
        default: return nil
        }
    }
}

// Mock MLModel class for demonstration.
// In a real app, this would be the actual auto-generated class from your .mlpackage.
class ObjectDetector {
    let model: MLModel
    let classLabels: [String] = ["apple", "banana", "milk", "bread"] // Example labels
    let modelInputWidth = 416
    let modelInputHeight = 416

    init() throws {
        // In a real app, you would load your model like this:
        // let config = MLModelConfiguration()
        // self.model = try ObjectDetector(configuration: config).model // assuming ObjectDetector is the generated class

        // For this exercise, we'll create a dummy MLModel that always returns the same prediction
        // This will fail if no actual model is present.
        let url = Bundle.main.url(forResource: "ObjectDetector", withExtension: "mlmodelc")!
        self.model = try MLModel(contentsOf: url)
    }

    func prediction(input: ObjectDetectorInput) throws -> ObjectDetectorOutput {
        // In a real app, you'd call the underlying MLModel's prediction method:
        // let predictionOutput = try model.prediction(from: input)
        // return ObjectDetectorOutput(boxes: predictionOutput.boxes, scores: predictionOutput.scores, labels: predictionOutput.labels)

        // For this mock, we return a fixed output simulating a single detection
        print("Performing mock object detection prediction...")
        let numDetections = 1
        let numClasses = classLabels.count

        let boxes = try MLMultiArray(shape: [NSNumber(value: numDetections), 4], dataType: .float32)
        let scores = try MLMultiArray(shape: [NSNumber(value: numDetections), NSNumber(value: numClasses)], dataType: .float32)
        let labels = try MLMultiArray(shape: [NSNumber(value: numDetections)], dataType: .int32)

        // Simulate detecting an apple
        boxes[0] = 0.2 // x
        boxes[1] = 0.3 // y
        boxes[2] = 0.4 // width
        boxes[3] = 0.5 // height

        scores[0 * numClasses + 0] = 0.9 // apple confidence
        scores[0 * numClasses + 1] = 0.05 // banana
        scores[0 * numClasses + 2] = 0.03 // milk
        scores[0 * numClasses + 3] = 0.02 // bread

        labels[0] = 0 // class index for apple

        return ObjectDetectorOutput(boxes: boxes, scores: scores, labels: labels)
    }
}


// MARK: - Real-time Object Detection Manager
class RealtimeObjectDetectorManager: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    private let videoOutputQueue = DispatchQueue(label: "videoOutputQueue", qos: .userInitiated)
    private var captureSession: AVCaptureSession?
    private var previewLayer: AVCaptureVideoPreviewLayer?
    private var objectDetector: ObjectDetector?

    // UI elements for drawing overlays
    private var detectionOverlayLayers: [CALayer] = []
    private var rootLayer: CALayer? // The layer where previewLayer and overlays are added

    // MARK: - Initialization & Setup
    init(previewView: UIView) {
        super.init()
        self.rootLayer = previewView.layer
        setupCamera(in: previewView)
        loadModel()
    }

    private func loadModel() {
        do {
            objectDetector = try ObjectDetector()
            print("ObjectDetector model loaded successfully.")
        } catch {
            print("Error loading ObjectDetector model: \(error)")
        }
    }

    private func setupCamera(in previewView: UIView) {
        captureSession = AVCaptureSession()
        captureSession?.sessionPreset = .hd1280x720 // Or .vga640x480 for lower resolution, faster processing

        guard let backCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("No back camera found.")
            return
        }

        do {
            let input = try AVCaptureDeviceInput(device: backCamera)
            if captureSession?.canAddInput(input) == true {
                captureSession?.addInput(input)
            }

            let videoOutput = AVCaptureVideoDataOutput()
            videoOutput.setSampleBufferDelegate(self, queue: videoOutputQueue)
            videoOutput.alwaysDiscardsLateVideoFrames = true // Crucial for real-time performance
            videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA] // BGRA format for Core ML

            if captureSession?.canAddOutput(videoOutput) == true {
                captureSession?.addOutput(videoOutput)
            }

            // Ensure video orientation is correct
            if let connection = videoOutput.connection(with: .video), connection.isSupportedVideoOrientation {
                connection.videoOrientation = .portrait
            }

            previewLayer = AVCaptureVideoPreviewLayer(session: captureSession!)
            previewLayer?.videoGravity = .resizeAspectFill
            previewLayer?.frame = previewView.bounds
            rootLayer?.addSublayer(previewLayer!)

            // Start the session on a background queue
            videoOutputQueue.async {
                self.captureSession?.startRunning()
            }

        } catch {
            print("Error setting up camera: \(error)")
        }
    }

    func start() {
        videoOutputQueue.async {
            self.captureSession?.startRunning()
        }
    }

    func stop() {
        videoOutputQueue.async {
            self.captureSession?.stopRunning()
        }
        clearOverlays()
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        guard let detector = objectDetector else { return }

        // Perform prediction on a background thread to avoid blocking the video queue
        // For real-time, we want to keep this as fast as possible.
        // Core ML prediction is often synchronous and optimized for the GPU/Neural Engine.
        // Dispatching to another queue might add overhead. It's a trade-off.
        // For this example, we'll run it directly to minimize latency, but careful profiling is needed.
        
        // Resize CVPixelBuffer for model input
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        let resizedImage = ciImage.transformed(by: CGAffineTransform(scaleX: CGFloat(detector.modelInputWidth) / ciImage.extent.width,
                                                                     y: CGFloat(detector.modelInputHeight) / ciImage.extent.height))
        
        let context = CIContext()
        var resizedPixelBuffer: CVPixelBuffer?
        CVPixelBufferCreate(kCFAllocatorDefault, detector.modelInputWidth, detector.modelInputHeight, kCVPixelFormatType_32BGRA, nil, &resizedPixelBuffer)
        
        guard let finalResizedPixelBuffer = resizedPixelBuffer else { return }
        context.render(resizedImage, to: finalResizedPixelBuffer)

        do {
            let input = ObjectDetectorInput(image: finalResizedPixelBuffer)
            let output = try detector.prediction(input: input)

            // Parse MLMultiArray outputs
            let detections = parseDetections(output: output, classLabels: detector.classLabels)
            let filteredDetections = NMS.apply(detections: detections, iouThreshold: 0.45, scoreThreshold: 0.5)

            // Update UI on the main thread
            DispatchQueue.main.async {
                self.drawDetections(filteredDetections, on: self.previewLayer)
            }

        } catch {
            print("Prediction error: \(error)")
        }
    }

    private func parseDetections(output: ObjectDetectorOutput, classLabels: [String]) -> [Detection] {
        var detections: [Detection] = []
        let numDetections = output.labels.count

        for i in 0..<numDetections {
            let x = output.boxes[[i, 0] as [NSNumber]].floatValue
            let y = output.boxes[[i, 1] as [NSNumber]].floatValue
            let width = output.boxes[[i, 2] as [NSNumber]].floatValue
            let height = output.boxes[[i, 3] as [NSNumber]].floatValue

            let classIndex = output.labels[i].intValue
            let confidence = output.scores[[i, classIndex] as [NSNumber]].floatValue

            if confidence > 0.1 { // Minimal confidence threshold before NMS
                let rect = CGRect(x: CGFloat(x), y: CGFloat(y), width: CGFloat(width), height: CGFloat(height))
                let label = classLabels[classIndex]
                detections.append(Detection(boundingBox: rect, confidence: confidence, classLabel: label, classIndex: classIndex))
            }
        }
        return detections
    }

    // MARK: - Visualization
    private func drawDetections(_ detections: [Detection], on previewLayer: AVCaptureVideoPreviewLayer?) {
        guard let previewLayer = previewLayer else { return }

        // Clear previous overlays
        clearOverlays()

        // Draw new overlays
        for detection in detections {
            let normalizedRect = detection.boundingBox
            // Convert normalized coordinates (0-1) to layer coordinates
            let convertedRect = previewLayer.layerRectConverted(fromMetadataOutputRect: normalizedRect)

            let shapeLayer = CALayer()
            shapeLayer.frame = convertedRect
            shapeLayer.borderColor = UIColor.red.cgColor
            shapeLayer.borderWidth = 2.0
            shapeLayer.cornerRadius = 3.0

            let textLayer = CATextLayer()
            textLayer.string = "\(detection.classLabel) (\(String(format: "%.2f", detection.confidence * 100))%)"
            textLayer.fontSize = 12
            textLayer.foregroundColor = UIColor.white.cgColor
            textLayer.backgroundColor = UIColor.red.cgColor
            textLayer.alignmentMode = .center
            textLayer.frame = CGRect(x: 0, y: -20, width: convertedRect.width, height: 20) // Position above box

            shapeLayer.addSublayer(textLayer)
            previewLayer.addSublayer(shapeLayer)
            detectionOverlayLayers.append(shapeLayer)
        }
    }

    private func clearOverlays() {
        for layer in detectionOverlayLayers {
            layer.removeFromSuperlayer()
        }
        detectionOverlayLayers.removeAll()
    }
}

// MARK: - Example Usage (e.g., in a ViewController)
/*
class ViewController: UIViewController {
    @IBOutlet weak var cameraPreviewView: UIView!
    var detectorManager: RealtimeObjectDetectorManager!

    override func viewDidLoad() {
        super.viewDidLoad()
        detectorManager = RealtimeObjectDetectorManager(previewView: cameraPreviewView)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        detectorManager.start()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        detectorManager.stop()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Ensure preview layer and overlays resize with view changes
        detectorManager.previewLayer?.frame = cameraPreviewView.bounds
        // Re-draw detections if needed, or simply let the next frame update them
    }
}
*/
