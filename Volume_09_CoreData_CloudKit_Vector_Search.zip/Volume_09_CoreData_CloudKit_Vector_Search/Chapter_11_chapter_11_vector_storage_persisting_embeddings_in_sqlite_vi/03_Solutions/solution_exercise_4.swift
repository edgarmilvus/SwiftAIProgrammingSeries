
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import GRDB

struct MemoryStreamEngine {
    let dbWriter: any DatabaseWriter
    let lambda: Double = 0.001 // Decay constant
    
    func queryMemories(promptEmbedding: [Float], focusOnRecency: Bool) async throws -> [Note] {
        let now = Date()
        
        // 1. Pre-filter using SQL to avoid loading the entire DB into memory
        // We only fetch notes from the last 2 years to keep the math manageable.
        let twoYearsAgo = Calendar.current.date(byAdding: .year, value: -2, to: now)!
        
        let candidates = try await dbWriter.read { db in
            try Note.filter(Note.Columns.createdAt >= twoYearsAgo)
                .fetchAll(db)
        }
        
        // 2. Apply Complex Ranking Logic using a TaskGroup for parallel processing
        return try await withThrowingTaskGroup(of: (Note, Float).self) { group in
            for note in candidates {
                group.addTask {
                    // S_semantic (Cosine Similarity)
                    let similarity = calculateCosine(promptEmbedding, note.vectorEmbedding ?? [])
                    
                    // S_temporal (Exponential Decay: e^-λt)
                    let timeInterval = now.timeIntervalSince(note.createdAt)
                    let temporalDecay = exp(-self.lambda * timeInterval)
                    
                    // Combine scores
                    var finalScore = similarity * Float(temporalDecay)
                    
                    // If recency is prioritized, boost the temporal component
                    if focusOnRecency {
                        finalScore *= Float(temporalDecay)
                    }
                    
                    return (note, finalScore)
                }
            }
            
            var results: [(Note, Float)] = []
            for try await result in group {
                results.append(result)
            }
            
            return results
                .sorted { $0.1 > $1.1 }
                .map { $0.0 }
        }
    }
    
    private func calculateCosine(_ a: [Float], _ b: [Float]) -> Float {
        // Implementation from Exercise 2...
        return 0.0 
    }
}
