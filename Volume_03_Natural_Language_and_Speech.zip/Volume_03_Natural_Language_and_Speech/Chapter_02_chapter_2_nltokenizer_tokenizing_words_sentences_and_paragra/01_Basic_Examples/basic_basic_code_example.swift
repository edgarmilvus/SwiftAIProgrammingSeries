
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import NaturalLanguage // Essential for NLTokenizer
import Foundation     // For String and Range operations

/// A utility function to perform basic text analysis using NLTokenizer.
/// It tokenizes the input text into words, sentences, and paragraphs,
/// then prints them along with their counts.
///
/// - Parameter text: The input string to be analyzed.
@available(iOS 12.0, macOS 10.14, watchOS 5.0, tvOS 12.0, *)
func performBasicTextAnalysis(on text: String) {
    print("--- Original Text ---")
    print(text)
    print("\n---------------------\n")

    // 1. Initialize NLTokenizer for each desired unit type.
    //    While a single tokenizer can be reconfigured, creating separate instances
    //    for different unit types enhances clarity for this beginner example.
    let wordTokenizer = NLTokenizer(unit: .word)
    let sentenceTokenizer = NLTokenizer(unit: .sentence)
    let paragraphTokenizer = NLTokenizer(unit: .paragraph)

    // Set the string property for each tokenizer.
    // This tells the tokenizer which text it should operate on.
    wordTokenizer.string = text
    sentenceTokenizer.string = text
    paragraphTokenizer.string = text

    // MARK: - Tokenize by Words
    print("### Word Tokens:")
    var wordTokens: [String] = []
    // `enumerateTokens(in:using:)` iterates over the tokens within a specified range.
    // The closure provides the range of the token in the original string and the token type.
    wordTokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
        // Extract the actual token string using the provided range.
        let token = String(text[tokenRange])
        wordTokens.append(token)
        print(" - '\(token)'")
        return true // Return `true` to continue enumeration, `false` to stop.
    }
    print("Total Words: \(wordTokens.count)\n")

    // MARK: - Tokenize by Sentences
    print("### Sentence Tokens:")
    var sentenceTokens: [String] = []
    sentenceTokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
        let token = String(text[tokenRange])
        sentenceTokens.append(token)
        print(" - '\(token)'")
        return true
    }
    print("Total Sentences: \(sentenceTokens.count)\n")

    // MARK: - Tokenize by Paragraphs
    print("### Paragraph Tokens:")
    var paragraphTokens: [String] = []
    paragraphTokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
        let token = String(text[tokenRange])
        paragraphTokens.append(token)
        print(" - '\(token)'")
        return true
    }
    print("Total Paragraphs: \(paragraphTokens.count)\n")

    // MARK: - Analysis Summary
    print("--- Analysis Summary for 'NoteSense' ---")
    print("Original Text Length: \(text.count) characters")
    print("Word Count: \(wordTokens.count)")
    print("Sentence Count: \(sentenceTokens.count)")
    print("Paragraph Count: \(paragraphTokens.count)")
    print("----------------------------------------\n")
}

// MARK: - Application Entry Point
/// This is the main entry point for our "NoteSense" Text Analyzer simulation.
/// It defines various sample texts and calls the analysis function for each.
@main
@available(iOS 12.0, macOS 10.14, watchOS 5.0, tvOS 12.0, *)
struct BasicTokenizerApp {
    static func main() {
        let sampleText = """
        Hello, world! This is a simple example of text tokenization.
        Natural Language framework is powerful. It helps us understand human language.

        How does it work? NLTokenizer breaks text into meaningful units.
        These units can be words, sentences, or even paragraphs.
        It's quite useful for text analysis and processing tasks.
        """

        performBasicTextAnalysis(on: sampleText)

        let anotherText = "SwiftUI is great.  It simplifies UI development.  Isn't it amazing?"
        print("\n--- Analyzing another piece of text ---\n")
        performBasicTextAnalysis(on: anotherText)

        let shortText = "One word."
        print("\n--- Analyzing a short text ---\n")
        performBasicTextAnalysis(on: shortText)

        let emptyText = ""
        print("\n--- Analyzing an empty text ---\n")
        performBasicTextAnalysis(on: emptyText)

        let punctuationText = "Hello... World!!! How are you?"
        print("\n--- Analyzing text with unusual punctuation ---\n")
        performBasicTextAnalysis(on: punctuationText)
    }
}
