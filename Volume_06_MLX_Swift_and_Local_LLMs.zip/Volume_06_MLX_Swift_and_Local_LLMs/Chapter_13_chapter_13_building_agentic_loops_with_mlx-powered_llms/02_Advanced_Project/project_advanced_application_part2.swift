
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import MLX
import MLXNN // For MLXNN.Module inheritance

/// Represents the structured data extracted from a document.
struct DocumentData: Codable, Equatable {
    let vendor: String
    let totalAmount: Double
    let invoiceDate: String // Keeping as String for LLM simplicity, could be Date

    // A simple initializer for convenience
    init(vendor: String, totalAmount: Double, invoiceDate: String) {
        self.vendor = vendor
        self.totalAmount = totalAmount
        self.invoiceDate = invoiceDate
    }

    // Custom initializer from a dictionary (useful for LLM output parsing)
    init?(dictionary: [String: Any]) {
        guard let vendor = dictionary["vendor"] as? String,
              let totalAmount = dictionary["totalAmount"] as? Double,
              let invoiceDate = dictionary["invoiceDate"] as? String else {
            return nil
        }
        self.vendor = vendor
        self.totalAmount = totalAmount
        self.invoiceDate = invoiceDate
    }
}

/// Custom errors for the document extraction agent.
enum DocumentExtractionError: Error, LocalizedError {
    case llmInferenceFailed(String)
    case parsingFailed(String)
    case validationFailed(String)
    case agentMaxIterationsReached
    case modelLoadingFailed(String)

    var errorDescription: String? {
        switch self {
        case .llmInferenceFailed(let msg): return "LLM inference failed: \(msg)"
        case .parsingFailed(let msg): return "Failed to parse LLM output: \(msg)"
        case .validationFailed(let msg): return "Extracted data failed validation: \(msg)"
        case .agentMaxIterationsReached: return "Agent reached maximum iterations without successful extraction."
        case .modelLoadingFailed(let msg): return "Failed to load MLX model: \(msg)"
        }
    }
}
