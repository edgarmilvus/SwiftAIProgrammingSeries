
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import ARKit
import Vision
import SwiftUI

enum AIState: Sendable {
    case idle
    case listening
}

// 3. The GestureAnalyzer Actor (Swift 6 Thread Safety)
actor GestureAnalyzer {
    private(set) var currentState: AIState = .idle
    
    // Thresholds for normalized distance
    private let okGestureDistanceThreshold: Float = 0.05 
    
    func processHandUpdate(thumbTip: SIMD3<Float>, indexTip: SIMD3<Float>, palmSize: Float) -> AIState {
        // Calculate normalized Euclidean distance
        let distance = simd_distance(thumbTip, indexTip)
        let normalizedDistance = distance / palmSize
        
        // "OK" gesture: Thumb and Index are close, others are extended.
        // For simplicity, we focus on the normalized distance.
        if normalizedDistance < okGestureDistanceThreshold {
            if currentState == .idle {
                currentState = .listening
            }
        } else {
            if currentState == .listening {
                currentState = .idle
            }
        }
        return currentState
    }
}

// 4. Integration View Model
@MainActor
class IntentViewModel: ObservableObject {
    @Published var aiStatus: AIState = .idle
    private let analyzer = GestureAnalyzer()
    
    func updateHandPose(handAnchor: HandAnchor) async {
        // Extract relevant joints
        let thumbTip = handAnchor.handSkeleton.joint(.thumbTip).anchorPose.position
        let indexTip = handAnchor.handSkeleton.joint(.indexFingerTip).anchorPose.position
        
        // Calculate Palm Size (Normalization Factor)
        // Using distance between Index MCP and Pinky MCP as a proxy for hand scale
        let indexMCP = handAnchor.handSkeleton.joint(.indexFingerMCP).anchorPose.position
        let pinkyMCP = handAnchor.handSkeleton.joint(.pinkyFingerMCP).anchorPose.position
        let palmSize = simd_distance(indexMCP, pinkyMCP)
        
        // Offload heavy math/logic to the Actor
        let newState = await analyzer.processHandUpdate(
            thumbTip: thumbTip,
            indexTip: indexTip,
            palmSize: palmSize
        )
        
        // Update UI on Main Actor
        if newState != self.aiStatus {
            self.aiStatus = newState
        }
    }
}
