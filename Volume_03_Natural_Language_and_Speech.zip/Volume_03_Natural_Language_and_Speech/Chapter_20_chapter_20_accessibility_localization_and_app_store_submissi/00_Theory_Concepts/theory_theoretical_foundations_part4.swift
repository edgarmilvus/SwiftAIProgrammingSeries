
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import Observation // Required for @Observable

    @available(iOS 18.0, *)
    @Observable
    class SpeechViewModel {
        var isRecording: Bool = false
        var liveTranscription: String = "Start speaking..."
        var currentSentiment: String = "Neutral"
        var errorMessage: String?

        private let aiManager = AIManager() // Assuming AIManager is refactored to use async/await directly

        func toggleRecording() async {
            if isRecording {
                aiManager.stopSpeechRecognition()
                isRecording = false
                liveTranscription = "Recognition stopped."
            } else {
                do {
                    liveTranscription = "Listening..."
                    isRecording = true
                    try await aiManager.startSpeechRecognition()
                    // This part is tricky: AIManager's recognitionTask closure updates self.transcribedText
                    // We need a way for SpeechViewModel to observe AIManager's updates or
                    // AIManager should directly update SpeechViewModel.
                    // For simplicity, let's assume AIManager can publish its results.
                    // A more robust solution might involve Combine or an async stream.
                    // For now, let's just show how @Observable works on its own properties.
                } catch {
                    errorMessage = "Error: \(error.localizedDescription)"
                    isRecording = false
                }
            }
        }

        // Example method to simulate updates from AIManager
        func updateFromAIManager(text: String, sentiment: String) {
            liveTranscription = text
            currentSentiment = sentiment
        }
    }

    @available(iOS 18.0, *)
    struct SpeechView: View {
        @State private var viewModel = SpeechViewModel()

        var body: some View {
            VStack {
                Text(viewModel.liveTranscription)
                    .font(.title2)
                    .padding()
                Text("Sentiment: \(viewModel.currentSentiment)")
                    .font(.headline)
                    .padding(.bottom)

                Button(action: {
                    Task { // Use a Task to call async function from Button
                        await viewModel.toggleRecording()
                    }
                }) {
                    Text(viewModel.isRecording ? "Stop Recording" : "Start Recording")
                        .font(.title)
                        .padding()
                        .background(viewModel.isRecording ? Color.red : Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()

                if let error = viewModel.errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                        .padding()
                }
            }
        }
    }
    