
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// This Swift code defines a simple macOS command-line tool.
// For a GUI app, the structure would involve SwiftUI or AppKit,
// but the underlying notarization steps are identical.

import Foundation

@main
struct NotarizedAIUtility {
    static func main() async {
        print("Notarized AI Utility: Starting up...")

        // Simulate loading a small GGUF model bundled with the app.
        // In a real application, you'd use llama.cpp Swift bindings here.
        // For this example, we assume 'tinyllama.gguf' is in the app's Resources.
        if let modelURL = Bundle.main.url(forResource: "tinyllama", withExtension: "gguf") {
            print("Attempting to load simulated model from: \(modelURL.path)")
            // Simulate an asynchronous model loading and inference task.
            await Task.sleep(for: .seconds(1)) // Non-blocking sleep
            print("Model loaded successfully.")
            print("Inference result for 'What is Swift?': Swift is Apple's powerful programming language.")
        } else {
            print("Error: 'tinyllama.gguf' not found in app bundle. Please add it to your project resources.")
        }

        print("Notarized AI Utility: Exiting.")
    }
}

/*
--- Conceptual Steps for Xcode Configuration and Notarization ---

1.  **Xcode Project Setup:**
    *   Create a new macOS project (e.g., "Command Line Tool" or "App").
    *   Add a dummy file named `tinyllama.gguf` to your project (e.g., an empty text file renamed). Ensure it's included in the target's "Copy Bundle Resources" build phase.
    *   In your project's settings, navigate to the target's "Signing & Capabilities" tab.
    *   Enable "Automatically manage signing".
    *   Select your "Developer ID Application" team. If you don't have a Developer ID certificate, you'll need to create one via your Apple Developer account (Certificates, Identifiers & Profiles). Xcode will then provision it.
    *   Ensure a valid "Developer ID Application" signing certificate is selected.

2.  **Archiving the Application:**
    *   In Xcode, select "Product > Archive" from the menu bar.
    *   Xcode will build your application and then open the Organizer window, displaying your new archive.

3.  **Distributing for Notarization:**
    *   In the Organizer window, select your newly created archive.
    *   Click the "Distribute App" button.
    *   Choose "Developer ID" as the distribution method.
    *   Select "Notarize" in the subsequent options. This instructs Xcode to upload your signed app to Apple's Notarization service.
    *   Follow the prompts, ensuring you provide your Apple ID and an app-specific password if requested.
    *   Click "Export" (or "Upload" depending on the Xcode version) to initiate the process. Xcode will then package your app (typically into a `.pkg` installer or `.dmg` disk image) and upload it.

4.  **Monitoring Notarization:**
    *   Xcode will display the notarization status in the Organizer window.
    *   You will also receive an email from Apple (to your developer account email) confirming the notarization status (success or failure) once the process is complete. This can take anywhere from a few minutes to an hour.
    *   (Optional command-line check): `xcrun altool --notarization-history --username "your_apple_id" --password "your_app_specific_password"`

5.  **Verification:**
    *   Once notarization is successful, locate the exported `.pkg` or `.dmg` file.
    *   Copy this package to a different macOS machine (preferably a clean VM or a machine that hasn't previously run your app).
    *   Install the application using the package.
    *   Launch the installed application. A properly notarized app will display a standard Gatekeeper prompt confirming the developer (e.g., "Developer 'Your Name (Team ID)' downloaded this app from the Internet. Are you sure you want to open it?"), but *not* a warning about an unverified developer or blocking the app entirely. This indicates successful notarization.
*/
