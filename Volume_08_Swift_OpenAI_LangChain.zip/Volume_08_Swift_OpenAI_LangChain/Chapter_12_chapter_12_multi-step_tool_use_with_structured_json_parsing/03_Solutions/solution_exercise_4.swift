
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import Observation

/// Represents the current state of the Agent's execution.
enum AgentStatus: Equatable {
    case idle
    case processing
    case waitingForConfirmation(toolCallID: String, actionDescription: String)
}

@Observable
final class HomeGuardAgent {
    var status: AgentStatus = .idle
    var lastResponse: String = ""
    
    private var pendingAction: (id: String, toolName: String)?
    private var history: [ChatMessage] = []
    
    // Mock tools
    private func executeTool(name: String) async -> String {
        switch name {
        case "setLockStatus": return "SUCCESS: Door is now locked."
        case "setLightStatus": return "SUCCESS: Lights turned off."
        default: return "SUCCESS"
        }
    }

    /// The main entry point for user commands.
    func handleUserIntent(_ intent: String) async {
        status = .processing
        lastResponse = "Analyzing request..."
        
        // Simulate LLM deciding to lock the door
        // In a real app, this comes from the LLM
        let simulatedToolCallID = "call_lock_123"
        let simulatedToolName = "setLockStatus"
        
        if simulatedToolName == "setLockStatus" {
            // HITL Logic: Intercept high-security tools
            pendingAction = (simulatedToolCallID, simulatedToolName)
            status = .waitingForConfirmation(
                toolCallID: simulatedToolCallID, 
                actionDescription: "Lock the front door?"
            )
            lastResponse = "I need to lock the door to secure the house. Should I proceed?"
        } else {
            let result = await executeTool(name: simulatedToolName)
            lastResponse = "Done! \(result)"
            status = .idle
        }
    }

    /// Called by the UI when the user interacts with the confirmation dialog.
    func confirmAction() async {
        guard let pending = pendingAction else { return }
        
        print("✅ User confirmed: \(pending.toolName)")
        let result = await executeTool(name: pending.toolName)
        
        lastResponse = "Action completed: \(result)"
        pendingAction = nil
        status = .idle
        
        // In a real app, you would now send 'result' back to the LLM 
        // to let it finish its reasoning loop.
    }

    func cancelAction() async {
        guard let pending = pendingAction else { return }
        
        print("❌ User denied: \(pending.toolName)")
        lastResponse = "I've cancelled the request to \(pending.toolName). Is there anything else?"
        
        pendingAction = nil
        status = .idle
        
        // In a real app, you would send "User denied this action" back to the LLM.
    }
}

// --- SwiftUI-like View Simulation ---
@main
struct HomeGuardApp {
    static func main() async {
        let agent = HomeGuardAgent()

        print("--- Scenario: User says 'I'm leaving' ---")
        await agent.handleUserIntent("I'm leaving.")
        
        print("Current Status: \(agent.status)")
        print("Agent Message: \(agent.lastResponse)")

        // Simulate User tapping "Confirm" in a UI Alert
        print("\n--- User taps 'Confirm' ---")
        await agent.confirmAction()
        
        print("Current Status: \(agent.status)")
        print("Agent Message: \(agent.lastResponse)")
    }
}
