
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import Swiftgger
import Darwin // For mach_task_self and task_info

// MARK: - Data Structures for Results

struct ModelPerformanceResult: Identifiable {
    let id = UUID()
    let modelName: String
    var loadingTime: TimeInterval?
    var inferenceTime: TimeInterval?
    var tokensGenerated: Int?
    var tps: Double?
    var peakMemoryUsageMB: Double? // Approximate peak resident memory
    var output: String?
    var errorMessage: String?
    var isLoading: Bool = false
}

// MARK: - Main SwiftUI Application

@main
struct QuantizationAnalyzerApp: App {
    var body: some Scene {
        WindowGroup {
            QuantizationAnalyzerView()
        }
    }
}

// MARK: - QuantizationAnalyzerView

struct QuantizationAnalyzerView: View {
    @State private var prompt: String = "Write a short, creative poem about the future of AI on Apple Silicon, focusing on local inference and privacy."
    @State private var results: [String: ModelPerformanceResult] = [:] // Key: quantization name
    @State private var isAnalyzing: Bool = false

    // Model file names for comparison
    private let baseModelName = "mistral-7b-instruct-v0.2"
    private let q4Quantization = "Q4_K_M"
    private let q8Quantization = "Q8_0"

    var body: some View {
        VStack(spacing: 20) {
            Text("Quantization Impact Analyzer")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 10)

            // Prompt Input
            TextEditor(text: $prompt)
                .font(.body)
                .frame(minHeight: 100, maxHeight: 200)
                .border(Color.gray.opacity(0.3), width: 1)
                .cornerRadius(5)
                .padding(.horizontal)
                .overlay(
                    Group {
                        if prompt.isEmpty {
                            Text("Enter your prompt here...")
                                .foregroundColor(.gray)
                                .padding(.horizontal, 20)
                                .padding(.vertical, 8)
                        }
                    }, alignment: .topLeading
                )

            // Analyze Button
            Button(action: startAnalysis) {
                Label("Start Analysis", systemImage: "speedometer")
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(isAnalyzing || prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

            if isAnalyzing {
                ProgressView("Analyzing...")
                    .padding()
            }

            // Results Display
            ScrollView {
                VStack(spacing: 25) {
                    ForEach([q4Quantization, q8Quantization], id: \.self) { quantization in
                        if let result = results[quantization] {
                            AnalysisResultView(result: result)
                        } else {
                            VStack(alignment: .leading) {
                                Text("\(baseModelName).\(quantization) (No data)")
                                    .font(.headline)
                                    .foregroundColor(.gray)
                                Divider()
                            }
                            .padding(.bottom, 10)
                        }
                    }
                }
                .padding(.horizontal)
            }
        }
        .padding()
        .frame(minWidth: 800, minHeight: 700)
        .onAppear(perform: setupInitialResults)
    }

    private func setupInitialResults() {
        results[q4Quantization] = ModelPerformanceResult(modelName: "\(baseModelName).\(q4Quantization).gguf")
        results[q8Quantization] = ModelPerformanceResult(modelName: "\(baseModelName).\(q8Quantization).gguf")
    }

    /// Initiates the comparative analysis for both quantization levels.
    private func startAnalysis() {
        isAnalyzing = true
        // Reset previous results and set loading state
        results[q4Quantization]?.isLoading = true
        results[q8Quantization]?.isLoading = true
        results[q4Quantization]?.errorMessage = nil
        results[q8Quantization]?.errorMessage = nil
        results[q4Quantization]?.output = nil
        results[q8Quantization]?.output = nil
        results[q4Quantization]?.inferenceTime = nil
        results[q8Quantization]?.inferenceTime = nil
        results[q4Quantization]?.tokensGenerated = nil
        results[q8Quantization]?.tokensGenerated = nil
        results[q4Quantization]?.tps = nil
        results[q8Quantization]?.tps = nil
        results[q4Quantization]?.peakMemoryUsageMB = nil
        results[q8Quantization]?.peakMemoryUsageMB = nil


        Task {
            // Run analysis for Q4_K_M
            await analyzeModel(quantization: q4Quantization)
            // Run analysis for Q8_0
            await analyzeModel(quantization: q8Quantization)

            await MainActor.run {
                isAnalyzing = false
            }
        }
    }

    /// Performs model loading, inference, and measures performance for a given quantization.
    private func analyzeModel(quantization: String) async {
        let fullModelFileName = "\(baseModelName).\(quantization).gguf"
        let currentDirectory = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
        let modelPath = currentDirectory.appendingPathComponent(fullModelFileName)

        await MainActor.run {
            results[quantization]?.isLoading = true
            results[quantization]?.output = "Loading and generating..."
        }

        guard FileManager.default.fileExists(atPath: modelPath.path) else {
            await MainActor.run {
                results[quantization]?.errorMessage = "Model file not found at \(modelPath.path). Please download '\(fullModelFileName)' and place it in the same directory as the executable."
                results[quantization]?.isLoading = false
                results[quantization]?.output = "Error: Model not found."
            }
            return
        }

        var currentResult = ModelPerformanceResult(modelName: fullModelFileName, isLoading: true)

        do {
            // 1. Measure Model Loading Time
            let loadStartTime = Date()
            let llm = try LLM(modelPath: modelPath.path)
            currentResult.loadingTime = Date().timeIntervalSince(loadStartTime)

            // 2. Measure Peak Memory Usage (Approximation)
            // This captures the *current* resident memory after loading, not true peak during inference.
            // A more accurate peak measurement would require external profiling tools or OS-level sampling.
            var info = mach_task_basic_info()
            var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size) / 4
            let kernReturn = task_info(mach_task_self(), mach_flavor_t(MACH_TASK_BASIC_INFO), &info.tuple, &count)
            if kernReturn == KERN_SUCCESS {
                currentResult.peakMemoryUsageMB = Double(info.resident_size) / (1024.0 * 1024.0)
            } else {
                print("Warning: Could not get memory info for \(fullModelFileName). Error: \(kernReturn)")
            }

            let parameters = LLM.Parameters(
                temperature: 0.7,
                topK: 40,
                topP: 0.9,
                repeatPenalty: 1.1
            )

            // 3. Measure Inference Time and Tokens Generated
            let inferenceStartTime = Date()
            var generatedText = ""
            var tokenCount = 0

            for await token in llm.sample(prompt: prompt, parameters: parameters) {
                generatedText += token
                tokenCount += 1
                // Update UI incrementally
                await MainActor.run {
                    results[quantization]?.output = generatedText
                }
            }

            currentResult.inferenceTime = Date().timeIntervalSince(inferenceStartTime)
            currentResult.tokensGenerated = tokenCount
            if let infTime = currentResult.inferenceTime, infTime > 0 {
                currentResult.tps = Double(tokenCount) / infTime
            }

            currentResult.output = generatedText

        } catch {
            currentResult.errorMessage = "Error: \(error.localizedDescription)"
            currentResult.output = "Error during generation."
            print("Error for \(fullModelFileName): \(error)")
        }

        // Update final results on the main actor
        await MainActor.run {
            currentResult.isLoading = false
            results[quantization] = currentResult
        }
    }
}

// MARK: - AnalysisResultView Helper

struct AnalysisResultView: View {
    let result: ModelPerformanceResult

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(result.modelName)
                    .font(.headline)
                if result.isLoading {
                    ProgressView()
                        .controlSize(.small)
                }
                Spacer()
            }

            if let errorMessage = result.errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .font(.caption)
            } else {
                Group {
                    if let loadingTime = result.loadingTime {
                        Text("Loading Time: \(String(format: "%.2f", loadingTime))s")
                    }
                    if let inferenceTime = result.inferenceTime {
                        Text("Inference Time: \(String(format: "%.2f", inferenceTime))s")
                    }
                    if let tokensGenerated = result.tokensGenerated {
                        Text("Tokens Generated: \(tokensGenerated)")
                    }
                    if let tps = result.tps {
                        Text("Tokens/Second: \(String(format: "%.2f", tps))")
                    }
                    if let memory = result.peakMemoryUsageMB {
                        Text("Memory (Resident): \(String(format: "%.2f", memory)) MB")
                    }
                }
                .font(.subheadline)
                .foregroundColor(.secondary)

                Text("Output:")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .padding(.top, 5)

                Text(result.output ?? "Generating...")
                    .textSelection(.enabled)
                    .font(.body)
                    .padding(8)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.green.opacity(0.05))
                    .cornerRadius(5)
            }
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}
