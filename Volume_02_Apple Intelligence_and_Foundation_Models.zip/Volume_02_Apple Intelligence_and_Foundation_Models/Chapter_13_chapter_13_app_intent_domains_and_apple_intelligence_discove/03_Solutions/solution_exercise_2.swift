
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import AppIntents
import Foundation

// 1. Define TaskStatus Enum
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
enum TaskStatus: String, AppEnum, CaseIterable, Identifiable {
    case todo = "To Do"
    case inProgress = "In Progress"
    case done = "Done"
    case blocked = "Blocked"

    // Required for AppEnum: How the enum type is displayed
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Task Status"
    
    // Required for AppEnum: How each case is displayed
    static var caseDisplayRepresentations: [Self: String] = [
        .todo: "To Do",
        .inProgress: "In Progress",
        .done: "Done",
        .blocked: "Blocked"
    ]

    // Required for Identifiable, useful for SwiftUI lists, etc.
    var id: String { rawValue }
}

// Define an AppIntentDomain for TaskMaster (if not already defined)
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct TaskMasterDomain: AppIntentDomain {
    static var identifier: String = "taskMaster"
    static var displayName: LocalizedStringResource = "TaskMaster"
    static var description: LocalizedStringResource = "Intents for managing tasks in the TaskMaster app."
}

// 2. Create UpdateTaskStatusIntent
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct UpdateTaskStatusIntent: AppIntent {
    static var title: LocalizedStringResource = "Update Task Status"
    static var description: LocalizedStringResource = "Updates the status of a specific task."
    static var openAppWhenRun: Bool = false // May not need to open the app for a status update
    static var domain: AppIntentDomain.Type? = TaskMasterDomain.self

    @Parameter(title: "Task ID", description: "The unique identifier of the task to update.", requestValueDialog: "Which task ID should be updated?")
    var taskID: UUID // Using UUID to simulate a real-world task identifier

    @Parameter(title: "New Status", description: "The new status for the task.", requestValueDialog: "What's the new status for the task?")
    var newStatus: TaskStatus // Using our custom AppEnum

    // 3. Implement confirm() for user confirmation
    func confirm() async throws -> some IntentResult {
        // Use IntentDialog.confirmation() to prompt the user
        return .result(
            dialog: IntentDialog.confirmation(
                "Are you sure you want to change task \(taskID.uuidString.prefix(8))'s status to \(newStatus.rawValue)?"
            )
        )
    }

    // 4. Implement perform()
    func perform() async throws -> some IntentResult {
        // This method is only called if the user confirms (if confirm() returns a confirmation dialog).
        // In a real app, you would fetch the task by ID and update its status in your data store.
        print("Attempting to update task \(taskID.uuidString.prefix(8)) to status: \(newStatus.rawValue)")

        // Simulate a successful update
        print("✅ TaskMaster: Task \(taskID.uuidString.prefix(8)) status updated to: \(newStatus.rawValue)")
        return .result(
            dialog: "Task \(taskID.uuidString.prefix(8)) status has been updated to \(newStatus.rawValue)."
        )
    }
}

// 5. Make Discoverable
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct TaskMasterShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            // Provide default values for parameters when defining the shortcut
            // These are used for display in the Shortcuts app, not for actual execution.
            intent: UpdateTaskStatusIntent(taskID: UUID(), newStatus: .done),
            phrases: [
                "Change status of task \(.parameter(\.$taskID)) to \(.parameter(\.$newStatus))",
                "Mark task \(.parameter(\.$taskID)) as \(.parameter(\.$newStatus))"
            ],
            shortTitle: "Update Task",
            systemImageName: "checklist.checked"
        )
    }
}
