
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

/// Represents a single unit of processed text.
/// Conforms to `Sendable` to ensure it can be safely passed from 
/// background worker tasks to the main actor.
struct DocumentChunk: Sendable, Identifiable {
    let id: UUID
    let text: String
    let metadata: [String: String]
    let embedding: [Float]? // The vector representation
}

/// The status of the ingestion process, used for UI updates.
enum IngestionStatus: Sendable {
    case idle
    case processing(progress: Double)
    case completed
    case failed(Error)
}

/// The IngestionEngine is an `actor` to protect its internal state 
/// (processedCount, error state) from data races during parallel execution.
actor IngestionEngine {
    private var processedCount: Int = 0
    private var totalChunks: Int = 0
    
    /// This method demonstrates Structured Concurrency using `withTaskGroup`.
    /// It allows us to process multiple chunks in parallel.
    func ingest(documents: [URL], progressHandler: @Sendable @escaping (Double) -> Void) async throws {
        // 1. Extraction Phase
        let allChunks = try await extractChunks(from: documents)
        self.totalChunks = allChunks.count
        
        // 2. Transformation & Loading Phase (Parallelized)
        try await withThrowingTaskGroup(of: DocumentChunk.self) { group in
            for chunk in allChunks {
                group.addTask {
                    // This runs in parallel across available threads
                    return try await self.embedChunk(chunk)
                }
            }
            
            for try await completedChunk in group {
                // 3. Loading Phase: Store in Vector DB
                try await self.saveToVectorStore(completedChunk)
                
                // Update internal state safely within the actor
                self.processedCount += 1
                let progress = Double(self.processedCount) / Double(self.totalChunks)
                
                // Notify the UI via the Sendable closure
                progressHandler(progress)
            }
        }
    }
    
    private func extractChunks(from urls: [URL]) async throws -> [DocumentChunk] {
        // Implementation of file reading and text splitting logic
        return [] 
    }
    
    private func embedChunk(_ chunk: DocumentChunk) async throws -> DocumentChunk {
        // Call to OpenAI API or local Core ML model
        // This is a high-latency network or compute call
        return chunk 
    }
    
    private func saveToVectorStore(_ chunk: DocumentChunk) async throws {
        // Logic to insert into a local SQLite-based vector store or remote DB
    }
}

/// The ViewModel acts as the bridge between the Background Actor 
/// and the SwiftUI View, ensuring all UI updates happen on the @MainActor.
@Observable
@MainActor
class IngestionViewModel {
    var status: IngestionStatus = .idle
    var progress: Double = 0.0
    
    private let engine = IngestionEngine()
    
    func startIngestion(files: [URL]) async {
        status = .processing(progress: 0.0)
        
        do {
            try await engine.ingest(documents: files) { [weak self] newProgress in
                // We must jump back to the MainActor to update @Observable properties
                Task { @MainActor in
                    self?.progress = newProgress
                }
            }
            status = .completed
        } catch {
            status = .failed(error)
        }
    }
}
