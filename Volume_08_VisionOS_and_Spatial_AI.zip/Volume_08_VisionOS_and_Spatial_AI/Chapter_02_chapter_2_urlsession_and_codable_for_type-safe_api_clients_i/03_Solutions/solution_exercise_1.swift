
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

@available(iOS 18.0, *)
import Foundation

// MARK: - Models

struct ChatRequest: Encodable {
    let model: String
    let messages: [MessageRequest]
}

struct MessageRequest: Encodable {
    let role: String
    let content: String
}

struct ChatCompletionResponse: Codable, Sendable {
    let id: String
    let object: String
    let created: Int
    let model: String
    let choices: [Choice]
    let usage: Usage
}

struct Choice: Codable, Sendable {
    let index: Int
    let message: MessageResponse
    let finishReason: String? // Automatically mapped from finish_reason
}

struct MessageResponse: Codable, Sendable {
    let role: String
    let content: String
}

struct Usage: Codable, Sendable {
    let promptTokens: Int    // Automatically mapped from prompt_tokens
    let completionTokens: Int // Automatically mapped from completion_tokens
    let totalTokens: Int      // Automatically mapped from total_tokens
}

// MARK: - Client

struct ChatCompletionClient {
    let endpoint = URL(string: "https://api.example.com/v1/chat/completions")!
    let apiKey = "your_api_key_here"

    func fetchCompletion(prompt: String) async throws -> ChatCompletionResponse {
        // 1. Construct Request Body
        let requestBody = ChatRequest(
            model: "gpt-4",
            messages: [MessageRequest(role: "user", content: prompt)]
        )
        
        // 2. Construct URLRequest
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(requestBody)

        // 3. Perform Request
        let (data, _) = try await URLSession.shared.data(for: request)

        // 4. Decode with Snake Case Strategy
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        
        return try decoder.decode(ChatCompletionResponse.self, from: data)
    }
}
