
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
/// Represents a single action item extracted from the meeting.
struct ActionItem: Codable, Identifiable {
    let id = UUID() // For SwiftUI list iteration, not part of JSON
    let description: String
    let assignedTo: String
    let dueDate: Date? // Optional, as LLM might sometimes miss it or use varied formats
    
    // Custom CodingKeys to handle potential variations in LLM output field names.
    // This allows us to map multiple JSON keys to a single Swift property.
    enum CodingKeys: String, CodingKey {
        case description
        case assignedTo = "assignedTo" // Explicitly map 'assignedTo'
        case assignee = "assignee"     // Allow 'assignee' as an alternative
        case dueDate
    }

    // Custom initializer for decoding, allowing flexible key mapping.
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.description = try container.decode(String.self, forKey: .description)
        
        // Attempt to decode 'assignedTo', if not found, try 'assignee'.
        if let assignedTo = try container.decodeIfPresent(String.self, forKey: .assignedTo) {
            self.assignedTo = assignedTo
        } else if let assignee = try container.decodeIfPresent(String.self, forKey: .assignee) {
            self.assignedTo = assignee
        } else {
            // If neither is present, it's a decoding error for this field.
            throw DecodingError.keyNotFound(CodingKeys.assignedTo,
                                            DecodingError.Context(codingPath: decoder.codingPath,
                                                                  debugDescription: "Neither 'assignedTo' nor 'assignee' found."))
        }
        
        // dueDate is optional and uses the decoder's dateDecodingStrategy.
        self.dueDate = try container.decodeIfPresent(Date.self, forKey: .dueDate)
    }
}

@available(iOS 18.0, macOS 15.0, *)
/// Represents a key decision made during the meeting.
struct Decision: Codable, Identifiable {
    let id = UUID()
    let topic: String
    let decisionMaker: String
    let dateMade: Date?
}

@available(iOS 18.0, macOS 15.0, *)
/// The top-level structure for the meeting summary.
struct MeetingSummary: Codable, Identifiable {
    let id = UUID()
    let meetingTitle: String
    let summary: String
    let actionItems: [ActionItem]
    let decisions: [Decision]
    let followUpRequired: Bool
    
    // Custom CodingKeys for the top-level structure if needed,
    // for example, if 'meetingTitle' might also be 'title'.
    enum CodingKeys: String, CodingKey {
        case meetingTitle
        case title // Alternative key for meetingTitle
        case summary
        case actionItems
        case decisions
        case followUpRequired
    }
    
    // Custom initializer to handle flexible key mapping for meetingTitle.
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Attempt to decode 'meetingTitle', if not found, try 'title'.
        if let meetingTitle = try container.decodeIfPresent(String.self, forKey: .meetingTitle) {
            self.meetingTitle = meetingTitle
        } else if let title = try container.decodeIfPresent(String.self, forKey: .title) {
            self.meetingTitle = title
        } else {
            throw DecodingError.keyNotFound(CodingKeys.meetingTitle,
                                            DecodingError.Context(codingPath: decoder.codingPath,
                                                                  debugDescription: "Neither 'meetingTitle' nor 'title' found."))
        }
        
        self.summary = try container.decode(String.self, forKey: .summary)
        self.actionItems = try container.decode([ActionItem].self, forKey: .actionItems)
        self.decisions = try container.decode([Decision].self, forKey: .decisions)
        self.followUpRequired = try container.decode(Bool.self, forKey: .followUpRequired)
    }
}
