
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part7.swift
// Description: Advanced Application
// ==========================================

    // MARK: - Inference Function

    /// Performs inference using the trained AdaptiveContrastModule.
    /// - Parameters:
    ///   - model: The trained AdaptiveContrastModule instance.
    ///   - inputData: An MLXArray representing a new low-contrast image patch.
    /// - Returns: An MLXArray with the enhanced contrast.
    /// - Throws: MLXEnhancementError if input shape is invalid or inference fails.
    @available(iOS 18.0, macOS 15.0, *)
    func performInference(model: AdaptiveContrastModule, inputData: MLXArray) throws -> MLXArray {
        print("\nPerforming inference with trained model...")

        // Set the model to evaluation mode.
        // In our simple model, this doesn't change behavior, but it's crucial for models
        // with layers like BatchNorm or Dropout.
        model.eval()

        // Validate input shape (example: expecting a 2D array [batch, patch_size])
        // For a single image patch, batch size would be 1.
        if inputData.ndim != 2 || inputData.shape.last! != 16 { // Assuming patchSize 16 for consistency
             throw MLXEnhancementError.invalidInputShape(expected: [1, 16], actual: inputData.shape)
        }

        do {
            let enhancedOutput = model(inputData)
            print("Inference successful. Output shape: \(enhancedOutput.shape)")
            return enhancedOutput
        } catch {
            throw MLXEnhancementError.inferenceFailed("MLX computation error during inference: \(error.localizedDescription)")
        }
    }
    