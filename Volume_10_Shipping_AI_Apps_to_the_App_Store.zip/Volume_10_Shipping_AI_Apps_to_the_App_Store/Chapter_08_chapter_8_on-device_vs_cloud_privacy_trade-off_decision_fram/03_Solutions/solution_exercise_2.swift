
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// Defines the privacy-centric behavior of the application.
enum PrivacyMode: Sendable {
    case strict    // Only Local
    case balanced  // Cloud if safe, else Local
    case open      // Cloud preferred
}

/// Errors that can occur during AI generation.
enum AIError: Error, Sendable {
    case networkError
    case privacyRestrictionError
    case localInferenceFailed
}

/// A unified interface for any AI intelligence source.
protocol AIProvider: Sendable {
    func generateResponse(for prompt: String) async throws -> String
}

/// A local provider simulating Core ML inference.
struct LocalProvider: AIProvider {
    func generateResponse(for prompt: String) async throws -> String {
        // Simulate Core ML latency
        try await Task.sleep(for: .seconds(0.5))
        return "[Local Model]: I understand you said: '\(prompt)'"
    }
}

/// A cloud provider simulating a remote API call.
struct CloudProvider: AIProvider {
    func generateResponse(for prompt: String) async throws -> String {
        // Simulate network latency
        try await Task.sleep(for: .seconds(1.5))
        
        // Simulate a random network failure for testing fallback
        if Bool.random() && false { // Set to true to test fallback
            throw AIError.networkError
        }
        
        return "[Cloud LLM]: Sophisticated response to: '\(prompt)'"
    }
}

/// An actor that manages the selection and execution of AI providers.
actor AIDispatcher {
    private let local: LocalProvider
    private let cloud: CloudProvider
    private let privacyMode: PrivacyMode

    init(local: LocalProvider, cloud: CloudProvider, privacyMode: PrivacyMode) {
        self.local = local
        self.cloud = cloud
        self.privacyMode = privacyMode
    }

    func dispatch(prompt: String) async throws -> String {
        switch privacyMode {
        case .strict:
            return try await local.generateResponse(for: prompt)
            
        case .open:
            do {
                return try await cloud.generateResponse(for: prompt)
            } catch {
                print("Cloud failed, falling back to local...")
                return try await local.generateResponse(for: prompt)
            }
            
        case .balanced:
            // In a real app, we would call the PrivacyAuditEngine here.
            // For this exercise, we assume 'balanced' attempts cloud first.
            do {
                return try await cloud.generateResponse(for: prompt)
            } catch {
                return try await local.generateResponse(for: prompt)
            }
        }
    }
}

// MARK: - Execution Example
@main
struct DispatcherApp {
    static func main() async {
        let dispatcher = AIDispatcher(
            local: LocalProvider(),
            cloud: CloudProvider(),
            privacyMode: .balanced
        )

        print("--- Dispatching Request (Balanced Mode) ---")
        do {
            let response = try await dispatcher.dispatch(prompt: "What is the meaning of life?")
            print("Result: \(response)")
        } catch {
            print("Final Error: \(error)")
        }
    }
}
