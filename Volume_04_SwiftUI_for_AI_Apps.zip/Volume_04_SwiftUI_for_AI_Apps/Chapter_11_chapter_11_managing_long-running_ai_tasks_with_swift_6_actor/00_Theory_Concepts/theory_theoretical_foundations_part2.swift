
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

// Example of a Sendable AI input struct
struct ImageInput: Sendable {
    let pixelData: Data
    let width: Int
    let height: Int
    // Potentially other immutable metadata
}

// Example of a Sendable AI output struct
struct InferenceResult: Sendable, Identifiable {
    let id = UUID()
    let predictedLabel: String
    let confidence: Float
    let boundingBox: CGRect? // CGRect is a Sendable value type
}

@available(iOS 18.0, *)
extension AIManagementActor {
    func processImage(input: ImageInput) async throws -> InferenceResult {
        guard let model = loadedModel else {
            throw AIError.modelNotLoaded
        }
        // Simulate processing the Sendable input
        try await Task.sleep(for: .seconds(4))
        let result = InferenceResult(predictedLabel: "Cat", confidence: 0.98, boundingBox: CGRect(x: 10, y: 10, width: 50, height: 50))
        await MainActor.run {
            self.latestPrediction = "Image processed: \(result.predictedLabel)"
        }
        return result
    }
}
