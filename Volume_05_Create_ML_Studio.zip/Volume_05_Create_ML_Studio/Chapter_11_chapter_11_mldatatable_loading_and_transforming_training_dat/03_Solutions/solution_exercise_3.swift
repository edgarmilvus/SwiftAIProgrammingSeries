
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CreateML
import Foundation

@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
func preprocessDeviceTelemetry() throws {
    print("--- Preprocessing Device Telemetry Data ---")

    // 1. Data Source: Define Codable struct and sample data.
    struct DeviceTelemetry: Codable {
        let deviceID: String
        let timestamp: Date
        let batteryPercentage: Double?
        let deviceType: String
        let operatingHours: Double
        let firmwareVersion: String
    }

    let rawTelemetryData: [DeviceTelemetry] = [
        DeviceTelemetry(deviceID: "D001", timestamp: Date().addingTimeInterval(-86400 * 10), batteryPercentage: 92.5, deviceType: "Smart Bulb", operatingHours: 1200.5, firmwareVersion: "1.0.1"),
        DeviceTelemetry(deviceID: "D002", timestamp: Date().addingTimeInterval(-86400 * 3), batteryPercentage: nil, deviceType: "Thermostat", operatingHours: 500.2, firmwareVersion: "2.1.0"),
        DeviceTelemetry(deviceID: "D003", timestamp: Date().addingTimeInterval(-86400 * 25), batteryPercentage: 45.0, deviceType: "Door Sensor", operatingHours: 300.0, firmwareVersion: "1.5.0"),
        DeviceTelemetry(deviceID: "D004", timestamp: Date().addingTimeInterval(-86400 * 1), batteryPercentage: 88.0, deviceType: "Smart Bulb", operatingHours: 100.1, firmwareVersion: "1.0.1"),
        DeviceTelemetry(deviceID: "D005", timestamp: Date().addingTimeInterval(-86400 * 7), batteryPercentage: 70.0, deviceType: "Thermostat", operatingHours: 750.8, firmwareVersion: "2.1.0"),
        DeviceTelemetry(deviceID: "D006", timestamp: Date().addingTimeInterval(-86400 * 18), batteryPercentage: nil, deviceType: "Smart Bulb", operatingHours: 900.0, firmwareVersion: "1.0.1")
    ]

    // 2. Load Data: Convert the rawTelemetryData array into an MLDataTable.
    var dataTable = try MLDataTable(array: rawTelemetryData)
    print("Initial Data Table Row Count: \(dataTable.rowCount)")
    print("Initial Columns: \(dataTable.columnNames.joined(separator: ", "))\n")

    // Get current date for calculations
    let currentDate = Date()
    let calendar = Calendar.current

    // 3. Feature Engineering:
    //    a. daysSinceLastTelemetry
    try dataTable.addColumn(named: "daysSinceLastTelemetry", type: Double.self) { (row: MLDataRow) -> Double in
        let timestamp = row["timestamp"] as! Date
        let components = calendar.dateComponents([.day], from: timestamp, to: currentDate)
        return Double(components.day ?? 0)
    }
    print("Added 'daysSinceLastTelemetry' column.")

    //    b. batteryHealthCategory
    try dataTable.addColumn(named: "batteryHealthCategory", type: String.self) { (row: MLDataRow) -> String in
        if let battery = row["batteryPercentage"] as? Double {
            if battery >= 80.0 {
                return "Good"
            } else if battery >= 50.0 {
                return "Moderate"
            } else {
                return "Poor"
            }
        }
        return "Poor" // Treat nil as poor
    }
    print("Added 'batteryHealthCategory' column.")

    //    c. isSmartBulb
    try dataTable.addColumn(named: "isSmartBulb", type: Bool.self) { (row: MLDataRow) -> Bool in
        let deviceType = row["deviceType"] as! String
        return deviceType == "Smart Bulb"
    }
    print("Added 'isSmartBulb' column.\n")

    // 4. Data Cleaning - Missing Value Imputation (Mean Imputation for batteryPercentage):
    // Calculate the mean of non-nil battery percentages
    let batteryColumn: MLDataColumn<Double?> = dataTable["batteryPercentage"]
    let nonNilBatteries = batteryColumn.compactMap { $0 }
    let meanBattery = nonNilBatteries.isEmpty ? 0.0 : (nonNilBatteries.reduce(0.0, +) / Double(nonNilBatteries.count))
    print("Calculated mean battery percentage (for imputation): \(String(format: "%.2f", meanBattery))")

    // Add a new column with imputed values
    try dataTable.addColumn(named: "batteryPercentage_imputed", type: Double.self) { (row: MLDataRow) -> Double in
        if let battery = row["batteryPercentage"] as? Double {
            return battery
        } else {
            return meanBattery
        }
    }
    print("Imputed missing 'batteryPercentage' values with the mean.")

    // 5. Column Management:
    //    Remove original 'batteryPercentage' and other unwanted columns
    try dataTable.removeColumn(named: "batteryPercentage")
    try dataTable.removeColumn(named: "deviceID")
    try dataTable.removeColumn(named: "firmwareVersion")
    try dataTable.removeColumn(named: "timestamp") // Remove original timestamp as we derived daysSinceLastTelemetry
    print("Removed 'batteryPercentage', 'deviceID', 'firmwareVersion', 'timestamp' columns.")

    //    Rename 'batteryPercentage_imputed' to 'batteryPercentage'
    try dataTable.renameColumn(named: "batteryPercentage_imputed", to: "batteryPercentage")
    //    Rename 'operatingHours' to 'totalOperatingHours_hours'
    try dataTable.renameColumn(named: "operatingHours", to: "totalOperatingHours_hours")
    print("Renamed 'batteryPercentage_imputed' to 'batteryPercentage' and 'operatingHours' to 'totalOperatingHours_hours'.\n")

    // 6. Data Splitting:
    //    Shuffle the data
    let shuffledTable = dataTable.shuffled()
    print("Data table shuffled.")

    //    Split into 80% training and 20% validation
    let (trainingTable, validationTable) = shuffledTable.randomSplit(by: 0.8, seed: 42)
    print("Data split into \(trainingTable.rowCount) training rows and \(validationTable.rowCount) validation rows.\n")

    // 7. Verification:
    print("--- Training Data Table Details ---")
    print("Column Names: \(trainingTable.columnNames.joined(separator: ", "))")
    print("Column Types:")
    for columnName in trainingTable.columnNames {
        print("  - \(columnName): \(trainingTable[columnName].dataType)")
    }
    print("\nTraining Data (First 5 Rows):")
    print(trainingTable.head(5))

    print("\nValidation Data (First 5 Rows):")
    print(validationTable.head(5))
}

// Call the function to execute the exercise
/*
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
do {
    try preprocessDeviceTelemetry()
} catch {
    print("Error during device telemetry preprocessing: \(error.localizedDescription)")
}
*/
