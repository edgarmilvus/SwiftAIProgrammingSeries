/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/api/stream-example/route.ts

import { NextRequest } from 'next/server';

/**
 * Handles GET requests to stream a simulated AI response.
 * 
 * This route uses the Edge Runtime for optimal streaming performance.
 * It simulates an LLM generating tokens by yielding strings from an async generator.
 */
export async function GET(req: NextRequest) {
  // 1. Define the ReadableStream
  const stream = new ReadableStream({
    async start(controller) {
      // 2. Simulate an Async Generator (Model Output)
      // In a real app, this would be a loop reading from OpenAI's stream.
      const simulatedModelOutput = async function* () {
        const tokens = ["Hello", " ", "World", "!", " ", "This", " ", "is", " ", "a", " ", "streaming", " ", "response."];
        for (const token of tokens) {
          // Simulate network/processing delay
          await new Promise((resolve) => setTimeout(resolve, 100));
          yield token;
        }
      };

      // 3. Iterate and Stream Tokens
      for await (const chunk of simulatedModelOutput()) {
        // Encode the string chunk into a Uint8Array buffer
        const encoded = new TextEncoder().encode(chunk);
        controller.enqueue(encoded);
      }

      // 4. Close the stream
      controller.close();
    },
  });

  // 5. Return the Response
  return new Response(stream, {
    headers: {
      // Standard SSE content type
      'Content-Type': 'text/event-stream',
      // Disable caching for dynamic streams
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}
