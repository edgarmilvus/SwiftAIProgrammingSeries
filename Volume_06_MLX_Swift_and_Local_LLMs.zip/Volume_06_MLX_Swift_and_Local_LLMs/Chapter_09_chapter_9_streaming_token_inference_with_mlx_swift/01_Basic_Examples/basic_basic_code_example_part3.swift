
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.swift
// Description: Basic Code Example
// ==========================================

/// A simple character-level prediction model using MLXNN.
/// It takes an input token ID, embeds it, and then uses a linear layer
/// to predict the logits for the next token.
class SimpleTokenPredictor: MLXNN.Module {
    let embedding: MLXNN.Embedding
    let linear: MLXNN.Linear

    /// Initializes the model with vocabulary size and embedding dimension.
    /// - Parameters:
    ///   - vocabSize: The total number of unique tokens in the vocabulary.
    ///   - embedDim: The dimension of the embedding vectors.
    init(vocabSize: Int, embedDim: Int) {
        // Embedding layer: maps token IDs to dense vectors.
        // `vocabSize` is the number of possible input tokens.
        // `embedDim` is the size of the vector representation for each token.
        self.embedding = MLXNN.Embedding(
            outputDimensions: embedDim,
            vocabularySize: vocabSize
        )
        
        // Linear layer: transforms the embedding vector into logits
        // for the next token prediction.
        // Input dimension is `embedDim`, output dimension is `vocabSize`
        // (representing the probability distribution over the next token).
        self.linear = MLXNN.Linear(
            inputDimensions: embedDim,
            outputDimensions: vocabSize
        )
        super.init() // Call the superclass initializer
    }

    /// The forward pass of the model.
    /// - Parameter x: An `MLXArray` representing the input token IDs.
    ///                Expected shape: `[batch_size, sequence_length]`
    /// - Returns: An `MLXArray` of logits for the next token.
    ///            Expected shape: `[batch_size, sequence_length, vocabSize]`
    ///            (for multi-token input) or `[batch_size, vocabSize]` (for single token input)
    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // 1. Embed the input token IDs.
        //    Input: [batch_size, sequence_length] -> Output: [batch_size, sequence_length, embedDim]
        let embedded = embedding(x)
        
        // 2. Apply the linear layer.
        //    This projects the embedded vector to the vocabulary size,
        //    giving us logits for each possible next token.
        //    Output: [batch_size, sequence_length, vocabSize]
        let logits = linear(embedded)
        
        return logits
    }
}
