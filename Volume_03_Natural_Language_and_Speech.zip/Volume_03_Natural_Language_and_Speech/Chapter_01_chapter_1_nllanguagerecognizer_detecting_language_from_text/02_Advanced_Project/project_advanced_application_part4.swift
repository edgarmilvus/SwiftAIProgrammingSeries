
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

import SwiftUI

// Assume ChatMessage and RecognizedChatMessage structs, and ChatLanguageError enum are defined above.
// Assume LanguageDetectionService class is defined above.

@available(iOS 18.0, *)
struct ChatView: View {
    @State private var messages: [ChatMessage] = []
    @State private var recognizedMessages: [RecognizedChatMessage] = []
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?

    private let languageDetectionService = LanguageDetectionService()

    var body: some View {
        NavigationView {
            VStack {
                if isLoading {
                    ProgressView("Analyzing messages...")
                } else if let errorMessage = errorMessage {
                    Text("Error: \(errorMessage)")
                        .foregroundColor(.red)
                } else if recognizedMessages.isEmpty && !messages.isEmpty {
                    Text("No messages analyzed yet. Tap 'Analyze'.")
                        .foregroundColor(.gray)
                } else if recognizedMessages.isEmpty {
                    Text("No messages to analyze.")
                        .foregroundColor(.gray)
                } else {
                    List(recognizedMessages) { msg in
                        VStack(alignment: .leading) {
                            HStack {
                                Text(msg.sender)
                                    .font(.headline)
                                Spacer()
                                Text(msg.timestamp, style: .time)
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }
                            Text(msg.text)
                                .font(.body)
                            if let lang = msg.recognizedLanguage {
                                Text("Language: \(lang.rawValue.uppercased())")
                                    .font(.caption)
                                    .foregroundColor(.blue)
                            } else {
                                Text("Language: Undetermined")
                                    .font(.caption)
                                    .foregroundColor(.orange)
                            }
                            if let confidence = msg.confidenceScore {
                                Text("Confidence: \(String(format: "%.2f", confidence * 100))%")
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }

                Spacer()

                Button("Load & Analyze Sample Messages") {
                    Task {
                        await loadAndAnalyzeMessages()
                    }
                }
                .buttonStyle(.borderedProminent)
                .padding()
            }
            .navigationTitle("Chat Language Analyzer")
        }
    }

    /// Loads sample messages and then triggers their language analysis.
    private func loadAndAnalyzeMessages() async {
        isLoading = true
        errorMessage = nil
        messages = generateSampleMessages()
        recognizedMessages = [] // Clear previous results

        do {
            // Simulate a network delay or complex processing before analysis
            try await Task.sleep(for: .seconds(0.5))
            
            let detected = await languageDetectionService.processMessages(messages)
            recognizedMessages = detected
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    /// Generates a set of diverse sample chat messages for demonstration.
    private func generateSampleMessages() -> [ChatMessage] {
        [
            ChatMessage(sender: "Alice", text: "Hello, how are you doing today?"), // English
            ChatMessage(sender: "Bob", text: "Bonjour, comment ça va ?"), // French
            ChatMessage(sender: "Charlie", text: "Ich bin gut, danke! Und du?"), // German
            ChatMessage(sender: "Alice", text: "I'm doing great, thanks for asking!"), // English
            ChatMessage(sender: "David", text: "Estoy muy bien, gracias por preguntar."), // Spanish
            ChatMessage(sender: "Bob", text: "C'est une belle journée, n'est-ce pas ?"), // French
            ChatMessage(sender: "Eve", text: "こんにちは、元気ですか？"), // Japanese
            ChatMessage(sender: "Frank", text: "This is a short text."), // English
            ChatMessage(sender: "Grace", text: "A"), // Ambiguous/Short
            ChatMessage(sender: "Heidi", text: " "), // Empty-like
            ChatMessage(sender: "Ivan", text: "What's up?"), // English
            ChatMessage(sender: "Julia", text: "Это очень интересно!"), // Russian
            ChatMessage(sender: "Karl", text: "Wie geht's?"), // German
            ChatMessage(sender: "Liam", text: "I like Swift programming."), // English
            ChatMessage(sender: "Mia", text: "Grazie mille!"), // Italian
            ChatMessage(sender: "Noah", text: "Muito obrigado!"), // Portuguese
        ]
    }
}

// Example App entry point
@main
@available(iOS 18.0, *)
struct ChatLanguageApp: App {
    var body: some Scene {
        WindowGroup {
            ChatView()
        }
    }
}
