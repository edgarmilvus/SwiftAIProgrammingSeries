
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CoreHaptics
import ARKit

enum ObstacleType: Sendable {
    case hard, soft, moving
}

struct Obstacle: Sendable {
    let type: ObstacleType
    let distance: Float
    let position: SIMD3<Float>
}

@available(visionOS 1.0, *)
actor ObstacleProcessor {
    private let baseBPM: Float = 60.0
    private let maxDistance: Float = 5.0
    private let sensitivity: Float = 15.0

    /// Calculates the BPM based on proximity using the formula:
    /// BPM = BaseBPM + (MaxDistance - CurrentDistance) * Sensitivity
    func calculateHeartbeatBPM(for distance: Float) -> Float {
        let clampedDistance = max(0, min(maxDistance, distance))
        return baseBPM + (maxDistance - clampedDistance) * sensitivity
    }

    func process(obstacles: [Obstacle]) async -> [Obstacle] {
        // In a real implementation, this would involve 
        // running Vision models on ARKit frames.
        return obstacles.filter { $0.distance < maxDistance }
    }
}

@MainActor
class HapticAudioEngine {
    private var hapticEngine: CHHapticEngine?
    private let processor = ObstacleProcessor()
    
    init() {
        setupHaptics()
    }
    
    private func setupHaptics() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        do {
            hapticEngine = try CHHapticEngine()
            try hapticEngine?.start()
        } catch {
            print("Haptic Engine Error: \(error)")
        }
    }
    
    func update(with obstacles: [Obstacle]) async {
        guard let closest = obstacles.min(by: { $0.distance < $1.distance }) else { return }
        
        // 1. Handle Haptics (Texture-based)
        triggerHapticFeedback(for: closest.type)
        
        // 2. Handle Audio Heartbeat (Tempo-based)
        let bpm = await processor.calculateHeartbeatBPM(for: closest.distance)
        print("Audio Heartbeat Tempo: \(bpm) BPM")
    }
    
    private func triggerHapticFeedback(for type: ObstacleType) {
        guard let engine = hapticEngine else { return }
        
        do {
            let intensity: Float
            let sharpness: Float
            
            switch type {
            case .hard:
                intensity = 1.0   // Sharp, strong transient
                sharpness = 1.0
            case .soft:
                intensity = 0.4   // Low-frequency rumble
                sharpness = 0.1
            case .moving:
                intensity = 0.7
                sharpness = 0.5
            }
            
            let event = CHHapticEvent(eventType: .hapticTransient, parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: intensity),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: sharpness)
            ], relativeTime: 0)
            
            let pattern = try CHHapticPattern(events: [event], parameters: [])
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: 0)
        } catch {
            print("Failed to play haptic: \(error)")
        }
    }
}

// MARK: - Simulation
@MainActor
func runSpatialCaneSimulation() async {
    let engine = HapticAudioEngine()
    
    // Simulate a user walking toward a wall
    for distance in stride(from: 5.0, through: 0.5, by: -0.5) {
        let obstacle = Obstacle(type: .hard, distance: Float(distance), position: [0, 0, -Float(distance)])
        await engine.update(with: [obstacle])
        try? await Task.sleep(for: .milliseconds(500))
    }
}
