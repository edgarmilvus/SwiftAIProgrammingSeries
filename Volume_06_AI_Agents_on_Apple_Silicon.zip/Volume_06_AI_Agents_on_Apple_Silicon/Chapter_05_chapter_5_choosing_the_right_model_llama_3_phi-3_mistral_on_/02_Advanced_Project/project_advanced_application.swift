
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift
// This file defines the dependencies for our LocalBrain AI Assistant.

import PackageDescription

let package = Package(
    name: "LocalBrainAI",
    platforms: [
        .iOS(.v18), // Targeting iOS 18 and later for modern concurrency features
        .macOS(.v15) // Targeting macOS 15 and later
    ],
    products: [
        .library(
            name: "LocalBrainAI",
            targets: ["LocalBrainAI"]),
    ],
    dependencies: [
        // Hypothetical dependency for llama.cpp Swift bindings.
        // In a real scenario, this would link to a C++ library or a pre-compiled framework.
        .package(url: "https://github.com/your-org/llama-cpp-swift.git", from: "1.0.0"),
        // We might also include other utility packages, e.g., for logging or metrics.
        // .package(url: "https://github.com/apple/swift-log.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "LocalBrainAI",
            dependencies: [
                .product(name: "LlamaCpp", package: "llama-cpp-swift") // Assuming the product name is LlamaCpp
            ]),
        .testTarget(
            name: "LocalBrainAITests",
            dependencies: ["LocalBrainAI"]),
    ]
)
