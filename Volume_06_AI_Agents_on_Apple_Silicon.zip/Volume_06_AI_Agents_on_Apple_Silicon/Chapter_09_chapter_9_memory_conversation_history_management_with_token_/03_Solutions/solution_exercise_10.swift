
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_10.swift
// Description: Solution for Exercise 10
// ==========================================

import Foundation

// Reuse ChatMessage, Tokenizer protocol/MockTokenizer, calculateTokenCount, truncateConversation from Exercise 1

// 1. Make ChatMessage Codable
extension ChatMessage: Codable {}

class PersistentConversationStore {
    private let fileURL: URL
    private let tokenizer: Tokenizer
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    init(filename: String, tokenizer: Tokenizer) {
        self.tokenizer = tokenizer
        // Determine a suitable directory, e.g., Documents directory
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        self.fileURL = documentsDirectory.appendingPathComponent(filename)
        
        encoder.outputFormatting = .prettyPrinted // For human-readable JSON files
        encoder.dateEncodingStrategy = .iso8601 // Standard date format for Codable
        decoder.dateDecodingStrategy = .iso8601
    }

    // Saves the full conversation to disk
    func saveConversation(_ messages: [ChatMessage]) throws {
        let data = try encoder.encode(messages)
        try data.write(to: fileURL, options: [.atomicWrite])
    }

    // Loads the conversation from disk and applies a token budget
    func loadConversation(tokenBudget: Int) throws -> [ChatMessage] {
        guard FileManager.default.fileExists(atPath: fileURL.path) else {
            return [] // No conversation saved yet, return empty
        }
        let data = try Data(contentsOf: fileURL)
        let fullHistory = try decoder.decode([ChatMessage].self, from: data)
        
        // Crucially: Apply token budget to the loaded history before returning
        return truncateConversation(messages: fullHistory, tokenBudget: tokenBudget, using: tokenizer)
    }
    
    // Loads and returns the entire conversation history without budgeting
    func getAllMessages() throws -> [ChatMessage] {
        guard FileManager.default.fileExists(atPath: fileURL.path) else {
            return []
        }
        let data = try Data(contentsOf: fileURL)
        return try decoder.decode([ChatMessage].self, from: data)
    }

    // Deletes the saved conversation file from disk
    func deleteConversation() throws {
        if FileManager.default.fileExists(atPath: fileURL.path) {
            try FileManager.default.removeItem(at: fileURL)
        }
    }
}
