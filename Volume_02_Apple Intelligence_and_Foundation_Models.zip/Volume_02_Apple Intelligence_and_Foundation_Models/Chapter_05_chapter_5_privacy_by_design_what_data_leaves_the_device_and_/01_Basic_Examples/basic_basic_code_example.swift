
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import SwiftUI // For a minimal UI context
import OSLog   // For logging, crucial for debugging privacy-related flows

// Ensure these APIs are only used on iOS 18+ or macOS 15+
@available(iOS 18.0, macOS 15.0, *)
/// A simple structure to represent a user's note.
struct Note: Identifiable {
    let id = UUID()
    var title: String
    var content: String
}

@available(iOS 18.0, macOS 15.0, *)
/// A service responsible for performing on-device summarization of notes.
/// This service leverages Apple's TextSummarizationService, ensuring privacy
/// by processing all data locally on the device.
class NoteSummarizationService: ObservableObject {
    @Published var currentSummary: String?
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let logger = Logger(subsystem: "com.example.SmartNotes", category: "Summarization")

    /// Summarizes the content of a given note using Apple's on-device LLM.
    /// - Parameter note: The note object containing the content to summarize.
    /// - Returns: An optional string containing the summary.
    func summarizeNote(_ note: Note) async {
        await MainActor.run {
            isLoading = true
            errorMessage = nil
            currentSummary = nil
        }

        logger.info("Attempting to summarize note titled: '\(note.title)'")

        do {
            // 1. Initialize TextSummarizationService
            // This service is a lightweight proxy to the system's on-device LLM.
            // No network connection is initiated upon creation.
            let summarizationService = TextSummarizationService()

            // 2. Perform on-device summarization
            // The content of the note is passed directly to the local LLM.
            // This operation is performed entirely on the device, typically utilizing
            // the Neural Engine for efficient processing.
            logger.debug("Sending \(note.content.count) characters for on-device summarization.")
            let summary = try await summarizationService.summarize(note.content)

            await MainActor.run {
                self.currentSummary = summary.text
                self.isLoading = false
                self.logger.info("Successfully summarized note. Summary length: \(summary.text.count) characters.")
            }
        } catch {
            await MainActor.run {
                self.errorMessage = "Failed to summarize note: \(error.localizedDescription)"
                self.isLoading = false
                self.logger.error("Error during summarization: \(error.localizedDescription)")
            }
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
/// A basic SwiftUI view to demonstrate the NoteSummarizationService.
struct NoteDetailView: View {
    @StateObject private var summarizationService = NoteSummarizationService()
    let note: Note

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text(note.title)
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Text(note.content)
                    .font(.body)
                    .lineLimit(nil) // Allow multiple lines

                Divider()

                Button {
                    Task {
                        await summarizationService.summarizeNote(note)
                    }
                } label: {
                    HStack {
                        if summarizationService.isLoading {
                            ProgressView()
                        }
                        Text(summarizationService.isLoading ? "Summarizing..." : "Summarize Note (On-Device)")
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(summarizationService.isLoading)

                if let summary = summarizationService.currentSummary {
                    VStack(alignment: .leading) {
                        Text("Summary:")
                            .font(.headline)
                        Text(summary)
                            .padding()
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(8)
                    }
                }

                if let error = summarizationService.errorMessage {
                    Text("Error: \(error)")
                        .foregroundColor(.red)
                }
            }
            .padding()
        }
        .navigationTitle("Note Details")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - App Entry Point (for demonstration purposes)

@available(iOS 18.0, macOS 15.0, *)
struct SmartNotesApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                NoteDetailView(note: sampleNote)
            }
        }
    }

    private var sampleNote: Note {
        Note(
            title: "The History of Artificial Intelligence",
            content: """
            Artificial Intelligence (AI) is a rapidly evolving field that has captured the imagination of scientists, engineers, and the public alike. Its roots can be traced back to ancient myths and philosophical inquiries into the nature of thought and creation. However, the modern concept of AI truly began to take shape in the mid-20th century.

            The term "Artificial Intelligence" was coined by John McCarthy in 1956 at the Dartmouth Workshop, which is widely considered the birth of AI as a field. Early pioneers like Alan Turing laid theoretical groundwork with his concept of the Turing Test, a benchmark for machine intelligence. Researchers like Allen Newell, Herbert A. Simon, and Marvin Minsky made significant contributions in symbolic AI, focusing on problem-solving and logical reasoning.

            The 1960s and 70s saw the development of expert systems, which aimed to mimic the decision-making ability of human experts in specific domains. These systems, though powerful in their niche, often struggled with common sense reasoning and scalability, leading to the "AI winter" of the 1980s.

            The late 20th and early 21st centuries witnessed a resurgence of AI, driven by advancements in computational power, the availability of large datasets, and new algorithmic approaches, particularly in machine learning. Subfields like neural networks and deep learning, inspired by the structure of the human brain, have achieved remarkable successes in areas such as image recognition, natural language processing, and game playing.

            Today, AI is integrated into countless aspects of our daily lives, from personalized recommendations and voice assistants to medical diagnostics and autonomous vehicles. Ethical considerations, bias in algorithms, and the future impact on employment are increasingly important topics of discussion as AI continues to advance. The journey of AI is far from over, promising further transformative changes in the years to come.
            """
        )
    }
}
