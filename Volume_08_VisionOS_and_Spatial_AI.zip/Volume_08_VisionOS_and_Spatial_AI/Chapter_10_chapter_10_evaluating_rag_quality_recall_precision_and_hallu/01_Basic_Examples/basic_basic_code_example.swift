
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import OSLog

/// Represents the result of a single RAG evaluation pass.
/// This struct is `Sendable` to allow it to be passed safely across concurrency domains.
struct RAGEvaluationReport: Sendable {
    let precision: Double
    let recall: Double
    let faithfulness: Double // 1.0 is perfect, 0.0 is total hallucination
    let timestamp: Date
}

/// A collection of errors that can occur during the evaluation process.
enum EvaluationError: Error {
    case insufficientData
    case calculationError(String)
}

/// The core engine responsible for calculating RAG metrics.
/// We use an `actor` here because evaluation logic often involves heavy 
/// computational tasks or large datasets that should be isolated from the UI.
@available(iOS 18.0, *)
actor RAGEvaluator {
    private let logger = Logger(subsystem: "com.ai.docassistant", category: "Evaluation")

    /// Evaluates the quality of a RAG cycle.
    /// - Parameters:
    ///   - retrievedDocIDs: The IDs of the documents the retriever found.
    ///   - groundTruthDocIDs: The IDs of the documents that *should* have been found.
    ///   - generatedClaims: A set of factual claims extracted from the LLM's response.
    ///   - supportedClaims: A set of claims that are actually present in the retrieved context.
    /// - Returns: A `RAGEvaluationReport` containing the calculated metrics.
    func evaluate(
        retrievedDocIDs: Set<String>,
        groundTruthDocIDs: Set<String>,
        generatedClaims: Set<String>,
        supportedClaims: Set<String>
    ) async throws -> RAGEvaluationReport {
        
        logger.info("Starting RAG evaluation cycle...")

        // 1. Calculate Precision
        // Precision = (Retrieved ∩ GroundTruth) / Total Retrieved
        let truePositives = retrievedDocIDs.intersection(groundTruthDocIDs).count
        let precision = retrievedDocIDs.isEmpty ? 0.0 : Double(truePositives) / Double(retrievedDocIDs.count)

        // 2. Calculate Recall
        // Recall = (Retrieved ∩ GroundTruth) / Total GroundTruth
        let recall = groundTruthDocIDs.isEmpty ? 0.0 : Double(truePositives) / Double(groundTruthDocIDs.count)

        // 3. Calculate Faithfulness (Anti-Hallucination)
        // Faithfulness = Supported Claims / Total Generated Claims
        let faithfulness = generatedClaims.isEmpty ? 1.0 : Double(supportedClaims.count) / Double(generatedClaims.count)

        // Log the results for debugging
        logger.debug("""
            Evaluation Complete:
            - Precision: \(precision)
            - Recall: \(recall)
            - Faithfulness: \(faithfulness)
            """)

        return RAGEvaluationReport(
            precision: precision,
            recall: recall,
            faithfulness: faithfulness,
            timestamp: Date()
        )
    }
}

/// A ViewModel that manages the UI state for our Document Assistant.
/// We use `@MainActor` to ensure all UI updates happen on the main thread.
@MainActor
class DocumentAssistantViewModel: ObservableObject {
    @Published var lastReport: RAGEvaluationReport?
    @Published var isEvaluating = false
    @Published var errorMessage: String?

    private let evaluator = RAGEvaluator()

    /// Simulates a user asking a question and the system evaluating the response.
    func runEvaluationSimulation() async {
        isEvaluating = true
        errorMessage = nil
        
        // Simulate network/processing delay
        try? await Task.sleep(for: .seconds(1.5))

        do {
            // SCENARIO:
            // The user asked about "Termination Clauses".
            // The retriever found 3 docs, but only 2 were actually relevant. (Precision issue)
            // There were 4 relevant docs in the DB, but we only found 2. (Recall issue)
            // The LLM made 3 claims, but only 2 were supported by the text. (Hallucination issue)
            
            let report = try await evaluator.evaluate(
                retrievedDocIDs: ["doc_1", "doc_2", "doc_99"], // doc_99 is noise
                groundTruthDocIDs: ["doc_1", "doc_2", "doc_3", "doc_4"],
                generatedClaims: ["Claim A", "Claim B", "Claim C"],
                supportedClaims: ["Claim A", "Claim B"]
            )
            
            self.lastReport = report
        } catch {
            self.errorMessage = error.localizedDescription
        }

        isEvaluating = false
    }
}

// MARK: - Execution Example (Simulation)

@available(iOS 18.0, *)
@MainActor
func runDemo() async {
    let viewModel = DocumentAssistantViewModel()
    print("🚀 Starting Document Assistant Evaluation Demo...")
    
    await viewModel.runEvaluationSimulation()
    
    if let report = viewModel.lastReport {
        print("✅ Evaluation Success!")
        print("📊 Precision: \(report.precision * 100)%")
        print("📊 Recall: \(report.recall * 100)%")
        print("📊 Faithfulness: \(report.faithfulness * 100)%")
        
        if report.faithfulness < 1.0 {
            print("⚠️ WARNING: Hallucination detected in generated response.")
        }
    } else {
        print("❌ Evaluation failed.")
    }
}
