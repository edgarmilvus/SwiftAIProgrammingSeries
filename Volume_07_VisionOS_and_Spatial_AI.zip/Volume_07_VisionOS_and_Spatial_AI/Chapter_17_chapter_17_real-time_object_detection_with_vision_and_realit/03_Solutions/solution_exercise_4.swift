
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import ARKit
import RealityKit

class IndustrialARManager: NSObject, ARSessionDelegate {
    var arView: ARView!
    private var detectionToAnchorMap: [UUID: ARAnchor] = [:]
    
    func processVisionDetection(id: UUID, screenPoint: CGPoint) {
        // 1. Raycast to find a real-world surface
        let results = arView.raycast(from: screenPoint, allowing: .estimatedPlane, alignment: .any)
        
        guard let result = results.first else { return }
        
        // 2. Create a persistent ARAnchor
        // This tells ARKit to track this specific point in the world map
        let anchor = ARAnchor(name: "InstructionAnchor_\(id.uuidString)", 
                             transform: result.worldTransform)
        
        arView.session.add(anchor: anchor)
        detectionToAnchorMap[id] = anchor
    }
    
    // MARK: - ARSessionDelegate
    
    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
        for anchor in anchors {
            if anchor.name?.contains("InstructionAnchor") == true {
                spawnInstructionEntity(for: anchor)
            }
        }
    }
    
    private func spawnInstructionEntity(for anchor: ARAnchor) {
        let instructionEntity = ModelEntity(mesh: .generateBox(size: 0.1), 
                                            materials: [SimpleMaterial(color: .yellow, isMetallic: true)])
        
        // 3. Bind Entity to Anchor
        let anchorEntity = AnchorEntity(anchor: anchor)
        anchorEntity.addChild(instructionEntity)
        arView.scene.addAnchor(anchorEntity)
    }
}
