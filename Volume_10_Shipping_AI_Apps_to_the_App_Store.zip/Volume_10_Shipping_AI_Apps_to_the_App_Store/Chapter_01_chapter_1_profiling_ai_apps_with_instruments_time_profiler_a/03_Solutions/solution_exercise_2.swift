
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import CoreML

/// An Actor to safely manage model loading and caching across concurrent tasks.
@available(iOS 18.0, *)
actor ModelCache {
    private var cache: [String: MLModel] = [:]

    func getModel(named modelName: String) async throws -> MLModel {
        // 1. Check if the model is already in memory
        if let cachedModel = cache[modelName] {
            return cachedModel
        }

        print("Loading \(modelName) from disk...")
        let config = MLModelConfiguration()
        config.computeUnits = .all 

        // 2. Simulate loading from bundle
        // In a real app, ensure the URL is valid
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            throw NSError(domain: "ModelNotFound", code: 404)
        }

        // 3. Perform the heavy I/O and compilation
        let newModel = try await MLModel(contentsOf: modelURL, configuration: config)
        
        // 4. "Pre-warming" Step:
        // To prevent the first inference from stuttering, we perform a "dummy" inference.
        // This forces the ANE/GPU to compile the necessary kernels immediately.
        // try await newModel.prediction(input: dummyInput) 
        
        cache[modelName] = newModel
        return newModel
    }
}

@available(iOS 18.0, *)
class ModelManager {
    private let cache = ModelCache()
    private var currentModel: MLModel?

    func switchToModel(named modelName: String) async throws {
        print("Switching to \(modelName)...")
        
        // The heavy lifting is now encapsulated in the Actor.
        // Multiple calls to switchToModel will be serialized by the Actor,
        // preventing redundant loading of the same model.
        let model = try await cache.getModel(named: modelName)
        
        self.currentModel = model
        print("Model \(modelName) is ready and warm.")
    }
}
