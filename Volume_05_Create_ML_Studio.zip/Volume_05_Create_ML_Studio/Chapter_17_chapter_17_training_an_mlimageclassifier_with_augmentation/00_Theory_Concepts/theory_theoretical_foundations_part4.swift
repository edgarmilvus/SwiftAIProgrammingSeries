
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

    // From the TrainingManager actor example:
    struct TrainingSessionStatus: Identifiable, Sendable { // Explicitly Sendable
        let id: UUID
        let modelName: String
        var progress: Double
        var message: String
        var isActive: Bool
        var error: String?
        var trainedModelURL: URL?
        // All properties are value types or Sendable, so this struct is implicitly Sendable.
        // Explicitly adding 'Sendable' makes intent clear and helps static analysis.
    }

    // From the TrainingViewModel example:
    class TrainingProgress: Identifiable, Sendable { // Class can also be Sendable if its internal state is managed safely
        // ... properties ...
        // For a class, Sendable means all stored properties are Sendable, AND
        // it doesn't have mutable state that can be accessed without synchronization
        // from different tasks. In this case, we're careful to update it on the MainActor.
    }
    