/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Button,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Platform,
} from 'react-native';
import {
  QueryClient,
  QueryClientProvider,
  useQuery,
  onlineManager,
  focusManager,
} from '@tanstack/react-query';
import { NetInfo } from '@react-native-community/netinfo';

// ==========================================
// 1. SETUP: Mock Data & API Simulation
// ==========================================

/**
 * Simulates a database model for a SaaS Task Manager.
 */
type Task = {
  id: string;
  title: string;
  status: 'pending' | 'completed';
};

/**
 * Mock API function.
 * In a real app, this would be `fetch('https://api.saas.com/tasks')`.
 */
const fetchTasks = async (): Promise<Task[]> => {
  // Simulate network latency (1 second delay)
  await new Promise((resolve) => setTimeout(resolve, 1000));

  // Simulate random failure to test error states
  if (Math.random() > 0.9) {
    throw new Error('Simulated API Failure');
  }

  return [
    { id: '1', title: 'Review Q3 Financials', status: 'completed' },
    { id: '2', title: 'Update Privacy Policy', status: 'pending' },
    { id: '3', title: 'Deploy v2.0 to Production', status: 'pending' },
  ];
};

// ==========================================
// 2. CONFIGURATION: Network & Focus Managers
// ==========================================

/**
 * Integrates React Native's NetInfo with TanStack Query's onlineManager.
 * This tells Query when the device is online/offline.
 * Why? By default, TanStack Query assumes a browser environment.
 */
onlineManager.setEventListener((setOnline) => {
  return NetInfo.addEventListener((state) => {
    setOnline(!!state.isConnected);
  });
});

/**
 * Integrates React Native's AppState (foreground/background) with focusManager.
 * This tells Query when the app is in focus (active) or background.
 * Why? Mobile apps should not refetch data while in the background to save battery/data.
 */
const onAppStateChange = (status: string) => {
  // 'active' means the app is in the foreground
  if (Platform.OS !== 'web') {
    focusManager.setFocused(status === 'active');
  }
};

// In a real app, we'd hook this up to AppState from 'react-native'
// For this example, we simulate the focus change manually via a button.

// ==========================================
// 3. COMPONENT: The Task List (UI Layer)
// ==========================================

const TaskListComponent = () => {
  // useQuery hook is the heart of TanStack Query
  const { data, isLoading, isError, refetch, isFetching } = useQuery({
    queryKey: ['tasks'], // Unique key to identify this cache entry
    queryFn: fetchTasks, // The function to fetch data
    staleTime: 5000, // Data is fresh for 5 seconds (no background refetch)
    retry: 1, // Retry failed requests once
  });

  // Manual trigger for refetch (simulates pulling to refresh or app focus)
  const handleRefresh = () => {
    refetch();
  };

  // Simulate a manual "Focus" event trigger (refetching when user returns to screen)
  const triggerFocusSim = () => {
    focusManager.setFocused(true);
    Alert.alert('Simulated Focus', 'App is now in focus. Refetching if stale...');
  };

  if (isLoading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Syncing with Cloud...</Text>
      </View>
    );
  }

  if (isError) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>Failed to load tasks.</Text>
        <Button title="Retry" onPress={handleRefresh} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>SaaS Task Dashboard</Text>
        {/* Visual indicator for background fetching */}
        {isFetching && <Text style={styles.syncingText}>Updating...</Text>}
      </View>

      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>{item.title}</Text>
            <View style={[
              styles.badge,
              item.status === 'completed' ? styles.badgeSuccess : styles.badgePending
            ]}>
              <Text style={styles.badgeText}>{item.status.toUpperCase()}</Text>
            </View>
          </View>
        )}
      />

      <View style={styles.controls}>
        <Button title="Refresh Data" onPress={handleRefresh} />
        <View style={{ marginVertical: 5 }} />
        <Button title="Simulate App Focus" onPress={triggerFocusSim} color="gray" />
      </View>
    </View>
  );
};

// ==========================================
// 4. WRAPPER: Provider Setup
// ==========================================

/**
 * The QueryClientProvider makes the client available to all components.
 * This is required to use useQuery.
 */
export const TaskApp = () => {
  const [queryClient] = React.useState(() => new QueryClient());

  return (
    <QueryClientProvider client={queryClient}>
      <TaskListComponent />
    </QueryClientProvider>
  );
};

// ==========================================
// 5. STYLING: Basic Mobile Layout
// ==========================================

const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  container: {
    flex: 1,
    paddingTop: 60,
    backgroundColor: '#f5f5f5',
  },
  header: {
    paddingHorizontal: 20,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  syncingText: {
    fontSize: 12,
    color: '#888',
    fontStyle: 'italic',
  },
  loadingText: {
    marginTop: 10,
    color: '#555',
  },
  errorText: {
    color: 'red',
    fontSize: 16,
    marginBottom: 10,
  },
  card: {
    backgroundColor: 'white',
    padding: 15,
    marginHorizontal: 20,
    marginVertical: 6,
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  cardTitle: {
    fontSize: 16,
    color: '#333',
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  badgeSuccess: {
    backgroundColor: '#e6f4ea',
  },
  badgePending: {
    backgroundColor: '#fef7e0',
  },
  badgeText: {
    fontSize: 10,
    fontWeight: 'bold',
  },
  controls: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    backgroundColor: 'white',
  },
});
