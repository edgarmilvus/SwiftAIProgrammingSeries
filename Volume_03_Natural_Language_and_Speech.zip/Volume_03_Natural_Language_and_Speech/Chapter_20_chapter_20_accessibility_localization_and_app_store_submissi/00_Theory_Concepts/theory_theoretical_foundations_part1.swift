
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    import Foundation
    import Speech
    import NaturalLanguage

    @available(iOS 18.0, *)
    class AIManager: ObservableObject {
        @Published var transcribedText: String = ""
        @Published var sentiment: String = "Neutral"
        private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
        private var recognitionTask: SFSpeechRecognitionTask?
        private let audioEngine = AVAudioEngine()

        func startSpeechRecognition() async throws {
            guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
                throw AIErrors.recognitionUnavailable
            }

            // Request authorization if not already granted
            let authStatus = await SFSpeechRecognizer.requestAuthorization()
            guard authStatus == .authorized else {
                throw AIErrors.notAuthorized
            }

            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = recognitionRequest else {
                throw AIErrors.requestCreationFailed
            }
            recognitionRequest.shouldReportPartialResults = true

            // Start the audio engine
            let inputNode = audioEngine.inputNode
            let recordingFormat = inputNode.outputFormat(forBus: 0)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
                recognitionRequest.append(buffer)
            }
            audioEngine.prepare()
            try audioEngine.start()

            // Await the recognition task
            recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
                guard let self = self else { return }
                if let result = result {
                    Task { @MainActor in // Update UI on the main actor
                        self.transcribedText = result.bestTranscription.formattedString
                        // Perform sentiment analysis on the transcribed text
                        self.sentiment = await self.analyzeSentiment(text: result.bestTranscription.formattedString)
                    }
                } else if let error = error {
                    print("Speech recognition error: \(error.localizedDescription)")
                    self.stopSpeechRecognition()
                }
            }
        }

        func stopSpeechRecognition() {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
            recognitionRequest?.endAudio()
            recognitionTask?.cancel()
            recognitionRequest = nil
            recognitionTask = nil
        }

        func analyzeSentiment(text: String) async -> String {
            guard !text.isEmpty else { return "Neutral" }
            let tagger = NLTagger(tagSchemes: [.sentimentScore])
            tagger.string = text
            let (sentimentScore, _) = tagger.tag(at: text.startIndex, unit: .paragraph, scheme: .sentimentScore)
            if let score = sentimentScore?.rawValue, let floatScore = Float(score) {
                if floatScore > 0.3 { return "Positive" }
                if floatScore < -0.3 { return "Negative" }
            }
            return "Neutral"
        }
    }

    enum AIErrors: Error {
        case recognitionUnavailable
        case notAuthorized
        case requestCreationFailed
    }
    