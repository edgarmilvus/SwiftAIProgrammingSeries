
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import RealityKit
import ARKit
import Combine

/// A specialized error type for Spatial Decorator operations.
enum SpatialError: Error {
    case lidarUnavailable
    case sessionFailed(String)
    case anchorPlacementFailed
}

/// The `SpatialManager` acts as the central brain for the AR experience.
/// It conforms to `ARSessionDelegate` to respond to environmental changes.
/// We use `@MainActor` because this class will drive UI updates and 
/// interact directly with the RealityKit `ARView`.
@MainActor
@Observable
class SpatialManager: NSObject {
    /// The active ARView used for rendering.
    var arView: ARView?
    
    /// Tracks whether the session is currently tracking the environment effectively.
    var isTracking: Bool = false
    
    /// A collection of placed virtual objects, managed via their ARAnchors.
    private var placedAnchors: [UUID: AnchorEntity] = [:]

    /// Initializes the manager and prepares the ARSession.
    /// - Parameter arView: The RealityKit view to be managed.
    override init() {
        super.init()
    }

    /// Configures the ARSession with Scene Reconstruction and World Tracking.
    /// This must be called once the ARView is ready.
    @available(iOS 18.0, *)
    func setupSession(for view: ARView) {
        self.arView = view
        
        // 1. Create a World Tracking Configuration
        let configuration = ARWorldTrackingConfiguration()
        
        // 2. Enable Scene Reconstruction (Requires LiDAR)
        // This creates a mesh of the environment for physics and occlusion.
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) {
            configuration.sceneReconstruction = .mesh
            print("✅ LiDAR Scene Reconstruction enabled.")
        } else {
            print("⚠️ LiDAR not detected. Occlusion and physics will be limited.")
        }
        
        // 3. Enable Plane Detection
        // While mesh provides geometry, plane detection helps with semantic understanding.
        configuration.planeDetection = [.horizontal, .vertical]
        
        // 4. Set the session delegate to receive updates
        view.session.delegate = self
        
        // 5. Run the session
        view.session.run(configuration)
    }

    /// Attempts to place a virtual object at a specific world transform.
    /// - Parameter transform: The 4x4 matrix representing the physical location.
    /// - Returns: A boolean indicating if the placement was successful.
    func placeVirtualObject(at transform: simd_float4x4) {
        guard let arView = arView else { return }

        // 1. Create an ARAnchor. 
        // This is the critical step for persistence. We don't just place an Entity;
        // we ask ARKit to track a specific point in the physical world.
        let anchor = ARAnchor(name: "VirtualObjectAnchor", transform: transform)
        
        // 2. Add the anchor to the ARSession.
        arView.session.add(anchor: anchor)
        
        // Note: The actual Entity creation happens in the `session(_:didAdd:)` delegate method
        // to ensure the Entity is perfectly synchronized with the ARAnchor.
    }
}

// MARK: - ARSessionDelegate Implementation

extension SpatialManager: ARSessionDelegate {
    
    /// Called when ARKit adds a new anchor to the session.
    /// This is where we bridge the gap between ARKit (math/tracking) 
    /// and RealityKit (visuals/entities).
    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
        guard let arView = arView else { return }

        for anchor in anchors {
            // We only care about the anchors we created manually via 'placeVirtualObject'
            if anchor.name == "VirtualObjectAnchor" {
                
                // 1. Create a RealityKit AnchorEntity tied to the ARKit Anchor.
                // This ensures that if ARKit moves the anchor to correct drift,
                // the RealityKit Entity follows it automatically.
                let anchorEntity = AnchorEntity(anchor: anchor)
                
                // 2. Create the visual content (a simple sphere for this example).
                let mesh = MeshResource.generateSphere(radius: 0.05)
                let material = SimpleMaterial(color: .systemBlue, isMetallic: true)
                let modelEntity = ModelEntity(mesh: mesh, materials: [material])
                
                // 3. Add physics to the object so it interacts with the reconstructed mesh.
                modelEntity.collision = CollisionComponent(shapes: [.generateSphere(radius: 0.05)])
                modelEntity.physicsBody = PhysicsBodyComponent(massProperties: .default, 
                                                              mode: .dynamic)
                
                // 4. Attach the model to the anchor entity.
                anchorEntity.addChild(modelEntity)
                
                // 5. Add the anchor entity to the scene.
                arView.scene.addAnchor(anchorEntity)
                
                // Store reference for management.
                placedAnchors[anchor.identifier] = anchorEntity
                
                print("✨ Successfully anchored object at: \(anchor.transform.columns.3)")
            }
        }
    }

    /// Called when the session updates its tracking state.
    func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
        switch camera.trackingState {
        case .normal:
            isTracking = true
        case .limited(.initializing), .limited(.relocalizing):
            isTracking = false
        case .limited(.excessiveMotion), .limited(.insufficientFeatures):
            isTracking = false
        case .notAvailable:
            isTracking = false
        @unknown default:
            isTracking = false
        }
    }
}

// MARK: - SwiftUI Interface

struct SpatialDecoratorView: View {
    @State private var manager = SpatialManager()
    
    var body: some View {
        ZStack {
            // The AR View Container
            ARViewContainer(manager: manager)
                .edgesIgnoringSafeArea(.all)
            
            // UI Overlay
            VStack {
                HStack {
                    StatusIndicator(isTracking: manager.isTracking)
                    Spacer()
                }
                .padding()
                
                Spacer()
                
                Text("Tap a surface to place a persistent object")
                    .font(.caption)
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(10)
                    .padding(.bottom, 30)
            }
        }
        .onAppear {
            // Initialization of the AR session
            // In a real app, we'd wait for the view to be fully mounted.
        }
    }
}

/// A SwiftUI wrapper for the RealityKit ARView.
struct ARViewContainer: UIViewRepresentable {
    let manager: SpatialManager

    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        
        // Setup the manager with the newly created view.
        // We use Task to jump into the MainActor context safely.
        Task { @MainActor in
            manager.setupSession(for: arView)
        }
        
        // Add a tap gesture to trigger placement.
        let tapGesture = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap(_:)))
        arView.addGestureRecognizer(tapGesture)
        
        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(manager: manager)
    }

    /// The Coordinator handles the bridge between UIKit gestures and our Swift 6 Manager.
    class Coordinator: NSObject {
        var manager: SpatialManager

        init(manager: SpatialManager) {
            self.manager = manager
        }

        @objc func handleTap(_ recognizer: UITapGestureRecognizer) {
            guard let arView = manager.arView else { return }
            
            let location = recognizer.location(in: arView)
            
            // Perform a raycast against the reconstructed mesh/planes.
            // .estimatedPlane is used for a more responsive feel, 
            // but .existingPlaneGeometry is more precise.
            let results = arView.raycast(from: location, allowing: .estimatedPlane, alignment: .any)
            
            if let firstResult = results.first {
                // Use the transform from the raycast to place our anchor.
                manager.placeVirtualObject(at: firstResult.worldTransform)
            }
        }
    }
}

struct StatusIndicator: View {
    let isTracking: Bool
    
    var body: some View {
        HStack {
            Circle()
                .fill(isTracking ? Color.green : Color.red)
                .frame(width: 10, height: 10)
            Text(isTracking ? "Tracking Active" : "Tracking Limited")
                .font(.system(size: 12, weight: .bold))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(.ultraThinMaterial)
        .clipShape(Capsule())
    }
}
