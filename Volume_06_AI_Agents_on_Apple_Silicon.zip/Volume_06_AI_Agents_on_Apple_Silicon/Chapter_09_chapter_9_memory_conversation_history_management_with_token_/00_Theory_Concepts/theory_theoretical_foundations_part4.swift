
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI

@available(iOS 17.0, *) // @Observable requires iOS 17+
@Observable
class ChatViewModel {
    private let agent: ChatAgent
    private let memory: AgentMemory // Keep a reference to the actor
    private let tokenizerService: TokenizerService

    var messages: [ConversationEntry] = []
    var currentInput: String = ""
    var isLoading: Bool = false
    var errorMessage: String?

    init() {
        self.tokenizerService = TokenizerService()
        self.memory = AgentMemory(tokenizer: tokenizerService)
        self.agent = ChatAgent(memory: memory, llmService: MockLLMService()) // Mock LLM for example
        
        // Initial load of history (if any)
        Task { await updateMessagesFromMemory() }
    }

    func sendCurrentMessage() async {
        guard !currentInput.isEmpty else { return }
        let messageToSend = currentInput
        currentInput = ""
        isLoading = true
        errorMessage = nil

        do {
            // Send message and get response
            let response = try await agent.sendMessage(messageToSend, tokenBudget: 4000)
            print("LLM Response: \(response)")
            // Update UI with new messages
            await updateMessagesFromMemory()
        } catch {
            errorMessage = "Error: \(error.localizedDescription)"
            print("Error sending message: \(error)")
        }
        isLoading = false
    }

    // Helper to fetch and update UI messages from the actor
    private func updateMessagesFromMemory() async {
        // Fetch the full history from the actor for display
        // (pruning for display might be different than for LLM input)
        self.messages = await memory.fullHistory()
    }
}

// A simple mock LLM service for demonstration
@available(iOS 18.0, *)
class MockLLMService: LLMService {
    func generateResponse(prompt: String) async throws -> String {
        try await Task.sleep(for: .seconds(1)) // Simulate network/compute delay
        return "This is a mock response to: '\(prompt.prefix(50))...'"
    }
}

// Protocol for LLM service to allow mocking
@available(iOS 18.0, *)
protocol LLMService {
    func generateResponse(prompt: String) async throws -> String
}
