
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import MetricKit

protocol TelemetrySanitizer {
    func sanitize(_ data: [String: Any]) -> [String: Any]
}

struct PrivacyFilter: TelemetrySanitizer {
    private let sensitiveKeys = ["device_name", "user_id", "location_string", "email"]

    func sanitize(_ data: [String: Any]) -> [String: Any] {
        var sanitized = data
        for key in sensitiveKeys {
            sanitized.removeValue(forKey: key)
        }
        return sanitized
    }
}

struct SanitizedReport: Sendable {
    let identifier: String
    let metadata: [String: String]
    let tags: [String]
}

actor DiagnosticPipeline {
    private let sanitizer: TelemetrySanitizer
    
    init(sanitizer: TelemetrySanitizer) {
        self.sanitizer = sanitizer
    }

    func processDiagnosticPayload(_ payload: MXDiagnosticPayload, currentMode: String) async {
        // 1. Extract raw data
        let rawData: [String: Any] = [
            "crash_id": payload.crashIdentifier,
            "device_name": "iPhone 15 Pro", // Simulated sensitive data
            "user_id": "user_12345",        // Simulated sensitive data
            "memory_at_crash": "4GB"
        ]
        
        // 2. Sanitize
        let cleanData = sanitizer.sanitize(rawData)
        
        // 3. Create Report
        let report = SanitizedReport(
            identifier: payload.crashIdentifier,
            metadata: cleanData.compactMapValues { "\($0)" },
            tags: currentMode == "ultraHD" ? ["high_intensity_failure"] : ["standard_failure"]
        )
        
        // 4. Upload
        await uploadWithRetry(report)
    }

    private func uploadWithRetry(_ report: SanitizedReport, attempt: Int = 0) async {
        let maxAttempts = 3
        
        do {
            print("📤 Attempting to upload report \(report.identifier) (Attempt \(attempt + 1))...")
            try await simulateNetworkUpload(report)
            print("✅ Upload successful.")
        } catch {
            if attempt < maxAttempts {
                // Exponential Backoff: 2, 4, 8 seconds...
                let delay = UInt64(pow(2.0, Double(attempt + 1))) * 1_000_000_000
                print("⚠️ Upload failed. Retrying in \(delay / 1_000_000_000)s...")
                try? await Task.sleep(nanoseconds: delay)
                await uploadWithRetry(report, attempt: attempt + 1)
            } else {
                print("❌ Max upload attempts reached. Dropping report.")
            }
        }
    }

    private func simulateNetworkUpload(_ report: SanitizedReport) async throws {
        // Simulate a 50% chance of network failure
        if Bool.random() { throw NSError(domain: "NetworkError", code: -1) }
        try await Task.sleep(for: .seconds(1))
    }
}
