
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CoreData
import Combine

@available(iOS 18.0, *)
@MainActor
class SyncMonitor: ObservableObject {
    private let container: NSPersistentCloudKitContainer
    private var lastToken: NSPersistentHistoryToken?
    private var cancellables = Set<AnyCancellable>()
    
    @Published var lastSyncDate: Date?
    @Published var hasNewChanges: Bool = false

    init(container: NSPersistentCloudKitContainer) {
        self.container = container
        setupNotificationHandling()
    }

    private func setupNotificationHandling() {
        // Observe the specific notification sent when CloudKit pushes changes
        NotificationCenter.default.publisher(for: .NSPersistentStoreRemoteChange)
            .sink { [weak self] _ in
                Task {
                    await self?.processRemoteChanges()
                }
            }
            .store(in: &cancellables)
    }

    private func processRemoteChanges() async {
        let context = container.newBackgroundContext()
        // Ensure the context is aware of the changes
        context.automaticallyMergesChangesFromParent = true
        
        await context.perform { [weak self] in
            guard let self = self else { return }
            
            // 1. Create a request to fetch history since our last known token
            let fetchRequest = NSPersistentHistoryChangeRequest.fetchHistory(after: self.lastToken)
            
            do {
                let result = try context.execute(fetchRequest) as? NSPersistentHistoryResult
                guard let historyResult = result?.result as? [NSPersistentHistoryTransaction] else { return }
                
                if !historyResult.isEmpty {
                    // 2. Update the token to the latest transaction
                    self.lastToken = historyResult.last?.token
                    
                    // 3. Trigger UI update on MainActor
                    Task { @MainActor in
                        self.lastSyncDate = Date()
                        self.hasNewChanges = true
                        print("Successfully processed \(historyResult.count) remote transactions.")
                    }
                }
            } catch {
                print("Failed to fetch persistent history: \(error)")
            }
        }
    }
}
