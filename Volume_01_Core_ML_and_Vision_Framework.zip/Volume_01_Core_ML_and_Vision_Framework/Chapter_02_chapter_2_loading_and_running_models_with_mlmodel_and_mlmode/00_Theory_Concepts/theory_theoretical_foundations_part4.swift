
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Foundation
import UIKit

// Assume 'myImage' is a UIImage and 'MyModel' is your generated model class.
@available(iOS 13.0, *)
func performImageClassification(image: UIImage) async throws -> String {
    // This function will be called from a Task or an async context.
    // It should not block the main thread.

    // 1. Prepare input asynchronously (if needed, e.g., complex image pre-processing)
    guard let inputProvider = prepareImageInput(image: image) else {
        throw NSError(domain: "ImageProcessingError", code: 0, userInfo: nil)
    }

    // 2. Configure model
    let config = MLModelConfiguration()
    config.computeUnits = .all

    // 3. Load model (can be done once and reused, but shown here for context)
    let model = try MyModel(configuration: config) // Assuming MyModel is the generated class

    // 4. Perform prediction using await
    // This line will suspend until the prediction is complete,
    // allowing other tasks to run.
    let output = try await model.prediction(input: inputProvider)

    // 5. Interpret output
    guard let classLabel = output.featureValue(for: "classLabel")?.stringValue else {
        throw NSError(domain: "ModelOutputError", code: 1, userInfo: nil)
    }
    return classLabel
}

// Example usage from a SwiftUI View or ViewController
@available(iOS 13.0, *)
class MyViewController: UIViewController {
    var imageView: UIImageView!
    var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Setup UI...
        Task {
            do {
                if let image = imageView.image {
                    let prediction = try await performImageClassification(image: image)
                    DispatchQueue.main.async { // Ensure UI update on main thread
                        self.resultLabel.text = "Prediction: \(prediction)"
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.resultLabel.text = "Error: \(error.localizedDescription)"
                }
            }
        }
    }
}
