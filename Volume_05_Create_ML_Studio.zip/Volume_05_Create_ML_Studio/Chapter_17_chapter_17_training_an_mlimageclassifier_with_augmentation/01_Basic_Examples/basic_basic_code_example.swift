
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CreateML
import AppKit // Required for NSImage, even if not directly used for training data loading in CreateML, it's good practice for image manipulation if needed.

// MARK: - PlantClassifierTrainer Class

/// A utility class to demonstrate training an MLImageClassifier for plant identification.
/// This class encapsulates the logic for preparing data, training the model,
/// and saving the resulting Core ML model.
@available(macOS 10.15, iOS 13.0, *) // CreateML is available from these versions.
class PlantClassifierTrainer {

    /// The base URL where the training data is located.
    /// This directory should contain subdirectories, each named after a plant species (e.g., "FiddleLeafFig", "Monstera").
    let trainingDataURL: URL

    /// The URL where the trained Core ML model will be saved.
    let outputModelURL: URL

    /// Initializes the trainer with the paths for training data and model output.
    /// - Parameters:
    ///   - trainingDataPath: The file system path to the training data root directory.
    ///   - outputModelPath: The file system path where the .mlmodel will be saved.
    init(trainingDataPath: String, outputModelPath: String) {
        self.trainingDataURL = URL(fileURLWithPath: trainingDataPath)
        self.outputModelURL = URL(fileURLWithPath: outputModelPath)
    }

    /// Prepares dummy training data by creating necessary directories and placeholder files.
    /// In a real scenario, these directories would contain actual image files.
    /// - Throws: An error if directory creation fails.
    func prepareDummyTrainingData() throws {
        let fileManager = FileManager.default
        let classes = ["FiddleLeafFig", "MonsteraDeliciosa", "Pothos"]

        print("Preparing dummy training data at: \(trainingDataURL.path)")

        // Ensure the base training data directory exists
        if !fileManager.fileExists(atPath: trainingDataURL.path) {
            try fileManager.createDirectory(at: trainingDataURL, withIntermediateDirectories: true, attributes: nil)
        }

        // Create subdirectories for each class and add dummy files
        for className in classes {
            let classURL = trainingDataURL.appendingPathComponent(className, isDirectory: true)
            if !fileManager.fileExists(atPath: classURL.path) {
                try fileManager.createDirectory(at: classURL, withIntermediateDirectories: true, attributes: nil)
            }
            // Create a few dummy files (e.g., text files instead of images for simplicity)
            for i in 1...5 {
                let dummyFileURL = classURL.appendingPathComponent("image_\(i).txt")
                let dummyContent = "This is a dummy image for \(className) - \(i)"
                try dummyContent.write(to: dummyFileURL, atomically: true, encoding: .utf8)
            }
        }
        print("Dummy training data prepared. (Note: Real training requires actual image files.)")
    }

    /// Trains an MLImageClassifier model using the provided training data and saves it.
    /// - Throws: An error if training or saving fails.
    func trainAndSaveModel() async throws {
        print("Starting model training...")

        // 1. Load Training Data
        // MLImageClassifier.DataSource expects a directory where subdirectories are class labels.
        let trainingData = try MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)
        print("Training data loaded from: \(trainingDataURL.path)")
        print("Detected classes: \(trainingData.classes.joined(separator: ", "))")

        // 2. Define Model Parameters with Augmentation
        // This is where we specify various augmentation techniques.
        // Create ML handles the application of these augmentations during training.
        let parameters = MLImageClassifier.ModelParameters(
            featureExtractor: .scenePrint(revision: 2), // Using a pre-trained feature extractor
            augmentation: .init(
                rotation: .init(minimumAngle: -10, maximumAngle: 10), // Rotate images by -10 to +10 degrees
                flip: .init(horizontal: true, vertical: false),     // Randomly flip images horizontally
                crop: .init(minimumSize: 0.8, maximumSize: 1.0),    // Randomly crop images between 80-100% of original size
                brightness: .init(minimum: 0.8, maximum: 1.2),      // Adjust brightness between 80-120%
                exposure: .init(minimum: -0.1, maximum: 0.1),       // Adjust exposure slightly
                contrast: .init(minimum: 0.8, maximum: 1.2),        // Adjust contrast between 80-120%
                saturation: .init(minimum: 0.8, maximum: 1.2),      // Adjust saturation between 80-120%
                noise: .init(maximumAmount: 0.05)                   // Add a small amount of random noise
            ),
            validationData: nil, // For a basic example, we'll skip explicit validation data.
                                // In a real app, you'd provide a separate dataset here.
            maxIterations: 50,   // Number of training epochs. Adjust based on dataset size and complexity.
            sessionParameters: nil // Optional parameters for the training session
        )
        print("Model parameters defined with augmentation settings.")

        // 3. Train the MLImageClassifier
        // The training process is asynchronous and can take significant time.
        let classifier = try await MLImageClassifier(trainingData: trainingData, parameters: parameters)
        print("Model training completed successfully!")

        // 4. Evaluate the Model (Optional but Recommended)
        // This provides metrics like accuracy on the training data.
        let evaluation = classifier.evaluation(on: trainingData)
        print("Training Accuracy: \(String(format: "%.2f%%", evaluation.classificationMetrics.accuracy * 100))")

        // 5. Save the Trained Model
        // The model is saved as a .mlmodel file, ready for integration into an app.
        try classifier.write(to: outputModelURL)
        print("Model saved to: \(outputModelURL.path)")
    }

    /// Demonstrates how to load a trained model and make a prediction.
    /// This function assumes a model has already been trained and saved.
    /// - Parameters:
    ///   - imageURL: The URL of the image to classify.
    /// - Throws: An error if the model cannot be loaded or prediction fails.
    /// - Returns: The prediction result, if successful.
    func predict(on imageURL: URL) throws -> MLImageClassifier.Prediction? {
        print("Loading model from: \(outputModelURL.path)")
        let model = try MLModel(contentsOf: outputModelURL)
        guard let imageClassifier = try? VNCoreMLModel(for: model) else {
            fatalError("Could not create VNCoreMLModel from trained model.")
        }
        
        // This part would typically be in an iOS/macOS app using Vision framework.
        // For demonstration, we'll simulate a prediction.
        print("Simulating prediction for \(imageURL.lastPathComponent)...")
        // In a real app, you'd use VNImageRequestHandler and VNCoreMLRequest
        // to process the image and get actual classifications.
        // For this basic example, we'll return a dummy prediction.
        
        // Example of how you would load an image for prediction in a real app:
        // guard let image = NSImage(contentsOf: imageURL) else {
        //     print("Could not load image at \(imageURL.path)")
        //     return nil
        // }
        // let prediction = try classifier.prediction(from: image)
        // print("Prediction: \(prediction.label) with confidence \(prediction.confidence)")
        
        // Since we don't have actual images in the dummy data,
        // we'll just return a placeholder prediction.
        return MLImageClassifier.Prediction(label: "SimulatedPlantClass", confidence: 0.95)
    }
}

// MARK: - Main Execution Block

// Define paths for training data and the output model.
// These paths should be adjusted to your local file system.
// For a Swift Playground or command-line tool, these paths are typically relative
// or point to a temporary directory.
let currentDirectory = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
let trainingDataPath = currentDirectory.appendingPathComponent("PlantTrainingData").path
let outputModelPath = currentDirectory.appendingPathComponent("PlantClassifier.mlmodel").path

let trainer = PlantClassifierTrainer(trainingDataPath: trainingDataPath, outputModelPath: outputModelPath)

// Use a Task to run the async training function
Task {
    do {
        // 1. Prepare dummy data (in a real scenario, you'd have actual images)
        try trainer.prepareDummyTrainingData()

        // 2. Train and save the model
        try await trainer.trainAndSaveModel()

        // 3. Demonstrate prediction (requires a saved model and an actual image)
        // For this dummy example, we'll just call the predict function
        // and note its limitations without real image files.
        let dummyImageURL = URL(fileURLWithPath: "/path/to/your/actual/plant_to_identify.jpg") // Placeholder
        let prediction = try trainer.predict(on: dummyImageURL)
        if let prediction = prediction {
            print("Simulated prediction result: \(prediction.label) (Confidence: \(String(format: "%.2f%%", prediction.confidence * 100)))")
        } else {
            print("Prediction failed or returned no result.")
        }

    } catch {
        print("An error occurred: \(error.localizedDescription)")
        // More detailed error handling might be needed based on the error type
        if let mlError = error as? MLCoreMLModelError {
            print("Create ML Error Code: \(mlError.errorCode)")
        }
    }
}

// Keep the program alive long enough for the async task to complete in a script/playground
// This is often not needed in a full app lifecycle.
// RunLoop.current.run() // Not strictly necessary for a simple Task in modern Swift, but good for older contexts.
