
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

/// A thread-safe pool of pre-allocated raw memory to prevent heap fragmentation.
final class TensorBufferPool: @unchecked Sendable {
    private let totalSize: Int
    private let basePointer: UnsafeMutableRawPointer
    private let lock = NSLock()
    
    private struct MemorySegment {
        let offset: Int
        let size: Int
        var isFree: Bool
    }
    
    private var segments: [MemorySegment]

    init(capacityBytes: Int) {
        self.totalSize = capacityBytes
        // 1. Pre-allocate a large contiguous block
        self.basePointer = UnsafeMutableRawPointer.allocate(
            byteCount: capacityBytes, 
            alignment: 64 // 2. Ensure 64-byte alignment for SIMD/Metal
        )
        
        // Initially, one single large free segment
        self.segments = [MemorySegment(offset: 0, size: capacityBytes, isFree: true)]
    }

    deinit {
        basePointer.deallocate()
    }

    /// Checks out a segment of memory.
    func checkout(size: Int) -> UnsafeMutableRawPointer? {
        lock.lock()
        defer { lock.unlock() }

        // Find first fit
        for (index, segment) in segments.enumerated() {
            if segment.isFree && segment.size >= size {
                // Split segment if there's significant leftover
                let leftover = segment.size - size
                let newSegment = MemorySegment(offset: segment.offset + size, size: leftover, isFree: true)
                
                segments[index].size = size
                segments[index].isFree = false
                
                if leftover > 64 { // Only split if leftover is worth a new segment
                    segments.insert(newSegment, at: index + 1)
                }
                
                return basePointer.advanced(by: segment.offset)
            }
        }
        return nil // Pool exhausted
    }

    /// Returns a segment to the pool.
    func release(pointer: UnsafeMutableRawPointer) {
        lock.lock()
        defer { lock.unlock() }

        let offset = pointer - basePointer
        
        if let index = segments.firstIndex(where: { $0.offset == offset }) {
            segments[index].isFree = true
            coalesce()
        }
    }

    /// Merges adjacent free segments to prevent internal fragmentation.
    private func coalesce() {
        var i = 0
        while i < segments.count - 1 {
            if segments[i].isFree && segments[i+1].isFree {
                let combinedSize = segments[i].size + segments[i+1].size
                let combinedOffset = segments[i].offset
                segments[i] = MemorySegment(offset: combinedOffset, size: combinedSize, isFree: true)
                segments.remove(at: i + 1)
            } else {
                i += 1
            }
        }
    }
}
