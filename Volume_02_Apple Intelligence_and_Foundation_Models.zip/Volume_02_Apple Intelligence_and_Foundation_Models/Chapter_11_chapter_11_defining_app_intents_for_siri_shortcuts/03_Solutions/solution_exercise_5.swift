
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import AppIntents
import Foundation

// MARK: - Playback Errors

enum PlaybackError: Error, CustomLocalizedStringResourceConvertible {
    case playlistNotFound
    case playbackFailed // Added for completeness

    var localizedStringResource: LocalizedStringResource {
        switch self {
        case .playlistNotFound:
            return "The specified playlist could not be found."
        case .playbackFailed:
            return "Failed to start playback. Please try again."
        }
    }
}

// MARK: - Mock User Playlists (for simulation)
// In a real app, this would be fetched from a user's data store.
fileprivate let userPlaylists: [String] = ["My Favorites", "Workout Mix", "Chill Vibes", "Focus Music", "Morning Jams"]

// MARK: - Play Playlist Intent

@available(iOS 18.0, *)
struct PlayPlaylistIntent: AppIntent {
    static var intentDisplayName: LocalizedStringResource = "Play Playlist"
    static var description: LocalizedStringResource = "Starts playing a specific music playlist from your library."

    @Parameter(title: "Playlist Name", description: "The name of the playlist to play.")
    var playlistName: String

    // Dynamic options for the playlistName parameter
    static func providesOptions(for playlistName: Parameter<String>) async throws -> [String] {
        // Filter suggestions based on the current input value, if any
        if let currentValue = playlistName.value, !currentValue.isEmpty {
            return userPlaylists.filter { $0.localizedCaseInsensitiveContains(currentValue) }
        }
        // If no input, provide all available playlists
        return userPlaylists
    }

    static var parameterSummary: some ParameterSummary {
        Summary("Play \((\.$playlistName))")
    }

    func perform() async throws -> some IntentResult {
        // Check if the playlist exists in our simulated library
        guard userPlaylists.contains(playlistName) else {
            throw PlaybackError.playlistNotFound
        }

        // Simulate playing the playlist
        print("Now playing playlist: \(playlistName)")

        // In a real app, this would interact with your music playback engine.
        return .result(
            dialog: "Now playing '\(playlistName)'."
        )
    }
}

// MARK: - App Shortcuts Provider

@available(iOS 18.0, *)
struct MyMusicAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: PlayPlaylistIntent(),
            phrases: [
                "Play my \(\.$playlistName) playlist",
                "Start \(\.$playlistName)",
                "Play some music"
            ],
            shortTitle: "Play Music",
            systemImageName: "play.circle.fill"
        )
    }
}
