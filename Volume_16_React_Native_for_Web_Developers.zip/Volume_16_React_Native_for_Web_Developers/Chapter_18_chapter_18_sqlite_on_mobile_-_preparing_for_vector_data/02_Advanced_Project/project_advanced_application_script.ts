/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/search.ts
// Next.js API Route for Semantic Search using SQLite Vector Storage

import type { NextApiRequest, NextApiResponse } from 'next';
import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

// ---------------------------------------------------------------------------
// 1. Type Definitions & Strict Type Discipline
// ---------------------------------------------------------------------------

/**
 * Enforces strict typing for the database schema.
 * Represents a row in our `documents` table.
 */
interface DocumentRow {
  id: number;
  content: string;
  category: string;
  // SQLite stores arrays as JSON strings or BLOBs. 
  // Here we treat it as a JSON string for simplicity in this demo.
  embedding_json: string; 
}

/**
 * Represents the parsed embedding vector.
 */
type Vector = number[];

/**
 * Request Payload for the API endpoint.
 */
interface SearchRequest extends NextApiRequest {
  body: {
    queryEmbedding: number[]; // The vector representation of the user's search query
    limit?: number;
    category?: string;
  };
}

/**
 * Response Payload for the API endpoint.
 */
interface SearchResult {
  id: number;
  content: string;
  category: string;
  similarity: number; // The calculated Cosine Similarity score
}

// ---------------------------------------------------------------------------
// 2. Database Initialization & Schema Setup
// ---------------------------------------------------------------------------

/**
 * Initializes the SQLite database connection.
 * In a real Expo/Next.js universal app, this path would be dynamic based on the platform.
 * For this Next.js server-side script, we use a local file.
 */
const dbPath = path.resolve(process.cwd(), 'data/vectors.db');

// Ensure directory exists
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const db = new Database(dbPath);

/**
 * Sets up the database schema.
 * 
 * OPTIMIZATION NOTE:
 * While SQLite doesn't have a native 'VECTOR' type (like Postgres pgvector),
 * we store embeddings as JSON strings. For high-performance retrieval in a 
 * production mobile app (Expo), we would use `expo-sqlite` with a BLOB or 
 * a dedicated C-extension for vector math.
 * 
 * Here, we create a table to store the vector data alongside metadata.
 */
const initDb = () => {
  // Enable WAL mode for better concurrency (readers don't block writers)
  db.pragma('journal_mode = WAL');

  const stmt = db.prepare(`
    CREATE TABLE IF NOT EXISTS documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      content TEXT NOT NULL,
      category TEXT,
      embedding_json TEXT NOT NULL
    )
  `);
  stmt.run();
};

// ---------------------------------------------------------------------------
// 3. Vector Math & Similarity Logic
// ---------------------------------------------------------------------------

/**
 * Calculates the Cosine Similarity between two vectors.
 * Formula: (A . B) / (||A|| * ||B||)
 * 
 * Why Cosine Similarity?
 * It measures the cosine of the angle between two vectors. 
 * It is useful because it is independent of vector magnitude (length),
 * focusing purely on orientation. This is ideal for text embeddings 
 * where the length of the document doesn't matter, only the semantic direction.
 * 
 * @param vecA - The query vector
 * @param vecB - The stored document vector
 * @returns number - Value between -1 (opposite) and 1 (identical). Usually 0 to 1 for embeddings.
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) {
    throw new Error('Vector dimensions must match for similarity calculation.');
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// ---------------------------------------------------------------------------
// 4. Core Logic: Vector Storage & Retrieval
// ---------------------------------------------------------------------------

/**
 * Inserts a new document with its embedding into SQLite.
 * 
 * @param content - The raw text
 * @param category - Metadata tag
 * @param embedding - The vector array
 */
function storeDocument(content: string, category: string, embedding: number[]) {
  const stmt = db.prepare(
    'INSERT INTO documents (content, category, embedding_json) VALUES (?, ?, ?)'
  );
  
  // Storing the vector as a JSON string.
  // In a true mobile context (Expo), we might use a BLOB for performance.
  const embeddingJson = JSON.stringify(embedding);
  stmt.run(content, category, embeddingJson);
}

/**
 * Performs a semantic search against the database.
 * 
 * STRATEGY: "Flat" Indexing (Exact Search)
 * Since SQLite lacks native vector indexing (like HNSW), we perform a 
 * sequential scan. This is O(N) complexity.
 * 
 * OPTIMIZATION: 
 * 1. Filter by metadata (category) first to reduce the search space.
 * 2. Calculate similarity only on the filtered subset.
 * 3. Limit results early.
 * 
 * For production-scale mobile apps with >10k vectors, we would implement 
 * an Approximate Nearest Neighbor (ANN) index (like HNSW) using a dedicated 
 * library or move the vector data to a specialized store like Pinecone.
 * 
 * @param queryEmbedding - The vector representing the user's search
 * @param limit - Max results to return
 * @param category - Optional filter
 */
function searchDocuments(
  queryEmbedding: number[],
  limit: number = 5,
  category?: string
): SearchResult[] {
  
  // 1. Construct the SQL query with optional filtering
  let sql = 'SELECT id, content, category, embedding_json FROM documents';
  const params: any[] = [];

  if (category) {
    sql += ' WHERE category = ?';
    params.push(category);
  }

  // 2. Execute the query to fetch candidate rows
  const rows = db.prepare(sql).all(...params) as DocumentRow[];

  // 3. Map rows to include similarity scores (Vector Processing Layer)
  const results: SearchResult[] = rows.map((row) => {
    // Parse the stored JSON vector back into an array
    const storedEmbedding: number[] = JSON.parse(row.embedding_json);
    
    // Calculate Cosine Similarity
    const similarity = cosineSimilarity(queryEmbedding, storedEmbedding);

    return {
      id: row.id,
      content: row.content,
      category: row.category,
      similarity: similarity,
    };
  });

  // 4. Sort by similarity (descending) and apply limit
  // Note: In a massive dataset, we might use a heap queue here to avoid sorting everything.
  return results
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, limit);
}

// ---------------------------------------------------------------------------
// 5. Next.js API Route Handler
// ---------------------------------------------------------------------------

export default function handler(req: SearchRequest, res: NextApiResponse) {
  // Initialize DB on first request (in production, do this on app start)
  initDb();

  if (req.method === 'POST') {
    try {
      const { queryEmbedding, limit, category } = req.body;

      if (!queryEmbedding || !Array.isArray(queryEmbedding)) {
        return res.status(400).json({ error: 'Invalid embedding vector provided.' });
      }

      // Execute the vector search
      const results = searchDocuments(queryEmbedding, limit, category);

      return res.status(200).json({
        success: true,
        count: results.length,
        data: results,
      });
    } catch (error) {
      console.error('Search error:', error);
      return res.status(500).json({ error: 'Internal server error during vector search.' });
    }
  } 
  
  else if (req.method === 'GET') {
    // Optional: Endpoint to seed dummy data for testing
    // In a real app, this would be a separate admin script.
    try {
        // Mock Embeddings (3 dimensions for brevity, real ones are 384+)
        // "AI is transforming web development"
        const emb1 = [0.1, 0.8, 0.2]; 
        // "Web development with Next.js and React"
        const emb2 = [0.9, 0.2, 0.1]; 
        // "Cooking recipes for dinner"
        const emb3 = [0.0, 0.1, 0.9]; 

        // Clear existing data
        db.prepare('DELETE FROM documents').run();
        
        // Seed
        storeDocument('AI is transforming web development', 'tech', emb1);
        storeDocument('Web development with Next.js and React', 'tech', emb2);
        storeDocument('Cooking recipes for dinner', 'lifestyle', emb3);

        return res.status(200).json({ message: 'Database seeded with mock vector data.' });
    } catch (e) {
        return res.status(500).json({ error: 'Failed to seed database' });
    }
  }

  res.setHeader('Allow', ['POST', 'GET']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}
