
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 18.0, *)
    actor ToolRegistryActor {
        private var tools: [String: (arguments: [String: String]) async throws -> String] = [:]
        private var toolSchemas: [String: String] = [:] // JSON schema descriptions

        func registerTool(name: String, schema: String, handler: @escaping ([String: String]) async throws -> String) {
            tools[name] = handler
            toolSchemas[name] = schema
        }

        func executeTool(_ name: String, arguments: [String: String]) async throws -> String {
            guard let handler = tools[name] else {
                throw ToolError.notFound(name: name)
            }
            return try await handler(arguments)
        }
        
        func getToolDefinitions() async -> String {
            // Combine all toolSchemas into a single string/JSON for injection
            // This is a simplified representation. Real-world would use structured JSON.
            return toolSchemas.map { "Tool: \($0.key), Schema: \($0.value)" }.joined(separator: "\n")
        }

        enum ToolError: Error {
            case notFound(name: String)
            case executionFailed(name: String, details: String)
        }
    }
    