
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import CreateML
import Foundation

@available(iOS 18.0, *)
class ModelTrainer {
    // A placeholder for a dataset provider
    func loadTrainingData() async throws -> MLDataTable {
        // Simulate a network request or heavy disk I/O
        try await Task.sleep(for: .seconds(2))
        // In a real scenario, load your data here.
        // For example: MLDataTable(contentsOf: URL(fileURLWithPath: "data.csv"))
        let data = try MLDataTable(dictionary: [
            "feature1": MLDataColumn([1.0, 2.0, 3.0, 4.0, 5.0]),
            "feature2": MLDataColumn([10.0, 20.0, 30.0, 40.0, 50.0]),
            "target": MLDataColumn([12.0, 23.0, 34.0, 45.0, 56.0])
        ])
        return data
    }

    func trainRegressor() async throws -> MLLinearRegressor {
        print("Starting regressor training...")
        let data = try await loadTrainingData()
        let regressor = try await MLLinearRegressor(trainingData: data,
                                                    featureColumns: ["feature1", "feature2"],
                                                    targetColumn: "target")
        print("Regressor training complete.")
        return regressor
    }

    func trainClassifier() async throws -> MLDecisionTreeClassifier {
        print("Starting classifier training...")
        // Simulate loading classification data
        try await Task.sleep(for: .seconds(2))
        let classificationData = try MLDataTable(dictionary: [
            "petalLength": MLDataColumn([1.4, 1.3, 1.5, 4.9, 5.2, 6.0]),
            "petalWidth": MLDataColumn([0.2, 0.2, 0.2, 1.5, 1.5, 1.8]),
            "species": MLDataColumn(["setosa", "setosa", "setosa", "versicolor", "versicolor", "virginica"])
        ])
        let classifier = try await MLDecisionTreeClassifier(trainingData: classificationData,
                                                            featureColumns: ["petalLength", "petalWidth"],
                                                            targetColumn: "species")
        print("Classifier training complete.")
        return classifier
    }

    func performInference(model: MLLinearRegressor, inputFeatures: [String: Double]) async throws -> Double {
        // Prepare input for Core ML model
        let input = try MLDictionaryFeatureProvider(dictionary: inputFeatures)
        let prediction = try await model.prediction(from: input)
        return prediction.doubleValue(for: "target") // Assuming 'target' is the output feature name
    }
}

// Example usage in an async context
@available(iOS 18.0, *)
func demonstrateTrainingAndInference() async {
    let trainer = ModelTrainer()
    do {
        let regressor = try await trainer.trainRegressor()
        let prediction = try await trainer.performInference(model: regressor, inputFeatures: ["feature1": 6.0, "feature2": 60.0])
        print("Predicted value for regressor: \(prediction)")

        let classifier = try await trainer.trainClassifier()
        // For classification, inference involves similar steps, providing features and getting a category.
        // The specific prediction method depends on the generated MLModel's interface.
        print("Classifier trained: \(classifier.description)")

    } catch {
        print("An error occurred: \(error)")
    }
}
