
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import SwiftData // Hypothetical for persistence, not fully implemented here but good for context
// import LlamaKit // Hypothetical LlamaKit for llama.cpp Swift bindings

// MARK: - 1. Custom Errors for Robust Handling

/// Custom error types for the RAG assistant, providing specific failure reasons.
enum RAGAssistantError: Error, LocalizedError {
    case fileNotFound(URL)
    case fileReadFailed(URL, Error)
    case embeddingGenerationFailed(String, Error?)
    case vectorStoreEmpty
    case llmInferenceFailed(String, Error?)
    case contextWindowExceeded(maxTokens: Int, actualTokens: Int)
    case invalidDocumentContent

    var errorDescription: String? {
        switch self {
        case .fileNotFound(let url):
            return "File not found at path: \(url.lastPathComponent)"
        case .fileReadFailed(let url, let error):
            return "Failed to read file \(url.lastPathComponent): \(error.localizedDescription)"
        case .embeddingGenerationFailed(let text, let error):
            return "Failed to generate embedding for text '\(text.prefix(50))...': \(error?.localizedDescription ?? "Unknown error")"
        case .vectorStoreEmpty:
            return "The knowledge base is empty. Please add documents first."
        case .llmInferenceFailed(let prompt, let error):
            return "LLM inference failed for prompt '\(prompt.prefix(50))...': \(error?.localizedDescription ?? "Unknown error")"
        case .contextWindowExceeded(let max, let actual):
            return "Context window exceeded. Max: \(max) tokens, Actual: \(actual) tokens."
        case .invalidDocumentContent:
            return "Document content is empty or invalid."
        }
    }
}

// MARK: - 2. Data Models for Documents and Chunks

/// Represents a source document ingested into the knowledge base.
struct Document: Identifiable, Hashable {
    let id: UUID
    let url: URL
    let content: String
    let metadata: [String: String] // e.g., "title", "author", "date"

    init(url: URL, content: String, metadata: [String: String] = [:]) {
        self.id = UUID()
        self.url = url
        self.content = content
        self.metadata = metadata
    }
}

/// Represents a small, semantically coherent chunk of a document, along with its embedding.
struct DocumentChunk: Identifiable, Hashable {
    let id: UUID
    let documentId: UUID // Reference to the parent document
    let text: String
    let embedding: [Float] // Vector representation of the text
    let sourceURL: URL // Original source of the chunk

    init(documentId: UUID, text: String, embedding: [Float], sourceURL: URL) {
        self.id = UUID()
        self.documentId = documentId
        self.text = text
        self.embedding = embedding
        self.sourceURL = sourceURL
    }

    /// A simplified method to calculate cosine similarity between two embeddings.
    /// In a real app, this would be optimized (e.g., using Accelerate framework or a dedicated vector DB).
    func cosineSimilarity(with otherEmbedding: [Float]) -> Float {
        guard !embedding.isEmpty && !otherEmbedding.isEmpty && embedding.count == otherEmbedding.count else {
            return 0.0
        }
        let dotProduct = zip(embedding, otherEmbedding).map(*).reduce(0, +)
        let magnitudeA = sqrt(embedding.map { $0 * $0 }.reduce(0, +))
        let magnitudeB = sqrt(otherEmbedding.map { $0 * $0 }.reduce(0, +))

        guard magnitudeA != 0 && magnitudeB != 0 else { return 0.0 }
        return dotProduct / (magnitudeA * magnitudeB)
    }
}

// MARK: - 3. Embedding Service (Actor)

/// An actor responsible for generating vector embeddings for text.
/// In a real application, this would interface with `llama.cpp` bindings (e.g., via `LlamaKit`)
/// or an Ollama server's embedding endpoint.
actor EmbeddingService {
    /// Simulates generating an embedding for a given text.
    /// - Parameter text: The text to embed.
    /// - Returns: A vector of Float representing the embedding.
    /// - Throws: `RAGAssistantError.embeddingGenerationFailed` if the process fails.
    @available(macOS 14.0, iOS 17.0, *)
    func generateEmbedding(for text: String) async throws -> [Float] {
        guard !text.isEmpty else {
            throw RAGAssistantError.embeddingGenerationFailed("Empty text provided", nil)
        }
        // Simulate network/compute latency and a hypothetical LlamaKit call
        try await Task.sleep(for: .milliseconds(100 + Int.random(in: 0...50)))

        // In a real scenario, this would call LlamaKit's embedding method:
        // let embedding = try LlamaKit.shared.embed(text: text, model: "nomic-embed-text")
        // For demonstration, return a dummy embedding.
        let seed = text.hashValue
        var rng = SystemRandomNumberGenerator()
        rng.seed = UInt64(seed) // Deterministic "random" for testing
        let dummyEmbedding = (0..<768).map { _ in Float.random(in: -1.0...1.0, using: &rng) } // Common embedding size

        guard !dummyEmbedding.isEmpty else {
            throw RAGAssistantError.embeddingGenerationFailed(text, nil)
        }
        return dummyEmbedding
    }
}

// MARK: - 4. Local Vector Store

/// A simplified in-memory vector store for document chunks.
/// In a production app, this would be backed by a persistent vector database
/// (e.g., Faiss, Annoy, or a dedicated SwiftData/CoreData model with a custom vector index).
final class VectorStore {
    private var chunks: [DocumentChunk] = []
    private let lock = OSAllocatedUnfairLock() // For protecting `chunks` in a non-actor class

    /// Adds a new chunk to the store.
    func addChunk(_ chunk: DocumentChunk) {
        lock.lock()
        defer { lock.unlock() }
        chunks.append(chunk)
    }

    /// Adds multiple chunks to the store.
    func addChunks(_ newChunks: [DocumentChunk]) {
        lock.lock()
        defer { lock.unlock() }
        chunks.append(contentsOf: newChunks)
    }

    /// Clears all chunks from the store.
    func clear() {
        lock.lock()
        defer { lock.unlock() }
        chunks.removeAll()
    }

    /// Returns the current count of chunks.
    var count: Int {
        lock.lock()
        defer { lock.unlock() }
        return chunks.count
    }

    /// Performs a similarity search for the top `k` chunks closest to the query embedding.
    /// - Parameters:
    ///   - queryEmbedding: The embedding of the user's query.
    ///   - k: The number of top similar chunks to retrieve.
    /// - Returns: An array of `DocumentChunk`s, sorted by similarity in descending order.
    func search(queryEmbedding: [Float], k: Int) -> [DocumentChunk] {
        lock.lock()
        defer { lock.unlock() }

        guard !chunks.isEmpty else { return [] }

        return chunks
            .map { chunk in
                (chunk: chunk, similarity: chunk.cosineSimilarity(with: queryEmbedding))
            }
            .sorted { $0.similarity > $1.similarity }
            .prefix(k)
            .map { $0.chunk }
    }
}

// MARK: - 5. Knowledge Base Manager (Actor)

/// An actor responsible for managing the ingestion, chunking, and storage of documents.
actor KnowledgeBaseManager {
    private let embeddingService: EmbeddingService
    private let vectorStore: VectorStore
    private var documents: [UUID: Document] = [:] // Store original documents for reference

    init(embeddingService: EmbeddingService, vectorStore: VectorStore) {
        self.embeddingService = embeddingService
        self.vectorStore = vectorStore
    }

    /// Ingests a new document by reading its content, chunking it,
    /// generating embeddings for each chunk, and adding them to the vector store.
    /// - Parameter url: The file URL of the document to ingest.
    /// - Throws: `RAGAssistantError` if file reading or embedding fails.
    @available(macOS 14.0, iOS 17.0, *)
    func ingestDocument(from url: URL) async throws {
        print("Ingesting document: \(url.lastPathComponent)")
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw RAGAssistantError.fileNotFound(url)
        }

        let content: String
        do {
            content = try String(contentsOf: url, encoding: .utf8)
        } catch {
            throw RAGAssistantError.fileReadFailed(url, error)
        }

        guard !content.isEmpty else {
            throw RAGAssistantError.invalidDocumentContent
        }

        let document = Document(url: url, content: content, metadata: ["filename": url.lastPathComponent])
        documents[document.id] = document

        // Simple chunking strategy: split by paragraphs or a fixed character count.
        // Advanced strategies might use semantic chunking or recursive splitting.
        let paragraphs = content.components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        let chunksToProcess = paragraphs.isEmpty ? [content] : paragraphs // Fallback if no newlines

        var documentChunks: [DocumentChunk] = []
        for chunkText in chunksToProcess {
            if chunkText.count < 50 { continue } // Skip very small chunks

            do {
                let embedding = try await embeddingService.generateEmbedding(for: chunkText)
                let chunk = DocumentChunk(documentId: document.id, text: chunkText, embedding: embedding, sourceURL: url)
                documentChunks.append(chunk)
            } catch {
                print("Warning: Failed to embed chunk from \(url.lastPathComponent): \(error.localizedDescription)")
                // Continue with other chunks, but log the error.
            }
        }
        vectorStore.addChunks(documentChunks)
        print("Successfully ingested \(documentChunks.count) chunks from \(url.lastPathComponent). Total chunks: \(vectorStore.count)")
    }

    /// Clears all ingested documents and their chunks from the knowledge base.
    func clearKnowledgeBase() {
        documents.removeAll()
        vectorStore.clear()
        print("Knowledge base cleared.")
    }

    /// Returns the total number of chunks currently in the knowledge base.
    func getChunkCount() -> Int {
        vectorStore.count
    }
}

// MARK: - 6. LLM Service (Actor)

/// An actor responsible for interacting with the local Large Language Model.
/// This would typically interface with `llama.cpp` bindings (e.g., via `LlamaKit`)
/// or a local Ollama server's API.
actor LLMService {
    let modelName: String
    let maxContextTokens: Int = 4096 // Typical context window for many local models

    init(modelName: String) {
        self.modelName = modelName
    }

    /// Simulates generating a response from the LLM based on a given prompt.
    /// - Parameter prompt: The engineered prompt including context and query.
    /// - Returns: The LLM's generated text response.
    /// - Throws: `RAGAssistantError.llmInferenceFailed` if inference fails.
    @available(macOS 14.0, iOS 17.0, *)
    func generateResponse(prompt: String) async throws -> String {
        // Simulate network/compute latency for LLM inference
        try await Task.sleep(for: .milliseconds(500 + Int.random(in: 0...200)))

        // In a real scenario, this would call LlamaKit's inference method:
        // let response = try LlamaKit.shared.generate(prompt: prompt, model: modelName)
        // For demonstration, return a dummy response.
        if prompt.contains("Apple Silicon") {
            return "Based on the provided context, Apple Silicon (like M1, M2, M3 chips) offers significant performance and power efficiency benefits, especially for AI workloads due to its unified memory architecture and neural engine. This allows for efficient local execution of LLMs."
        } else if prompt.contains("RAG") {
            return "Retrieval Augmented Generation (RAG) is a technique that enhances LLM responses by retrieving relevant information from a knowledge base and using it to ground the generation, preventing hallucinations and providing up-to-date information."
        } else if prompt.contains("Swift 6 concurrency") {
            return "Swift 6 concurrency features like async/await and Actors are crucial for building responsive and robust AI applications on Apple platforms, enabling efficient handling of asynchronous operations like embedding generation and LLM inference."
        } else {
            return "I am a local AI assistant. Based on the context you provided, I can tell you that: \(prompt.prefix(100))... [This is a simulated response from model: \(modelName)]"
        }
    }

    /// A very simple token count estimation. For production, use a proper tokenizer.
    func estimateTokenCount(for text: String) -> Int {
        // A rough estimate: 1 word ~ 1.3 tokens for English.
        // A more accurate solution would use a tokenizer specific to the LLM.
        text.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }.count + text.count / 5 // Add some buffer
    }
}

// MARK: - 7. RAG Assistant (Actor) - The Orchestrator

/// The main actor orchestrating the RAG process.
/// It takes a user query, retrieves relevant context, constructs a prompt,
/// and sends it to the LLM for generation.
@available(macOS 14.0, iOS 17.0, *)
actor RAGAssistant {
    private let embeddingService: EmbeddingService
    private let knowledgeBaseManager: KnowledgeBaseManager
    private let llmService: LLMService
    private let maxContextChunks: Int // Max chunks to retrieve for context
    private let maxPromptTokens: Int // Max tokens allowed for the entire prompt (context + query + instructions)

    /// Initializes the RAGAssistant.
    /// - Parameters:
    ///   - embeddingService: The service for generating embeddings.
    ///   - knowledgeBaseManager: The manager for the local document knowledge base.
    ///   - llmService: The service for interacting with the LLM.
    ///   - maxContextChunks: Maximum number of relevant chunks to retrieve.
    ///   - maxPromptTokens: Maximum total tokens for the LLM prompt, including retrieved context.
    init(embeddingService: EmbeddingService, knowledgeBaseManager: KnowledgeBaseManager, llmService: LLMService, maxContextChunks: Int = 5, maxPromptTokens: Int = 3000) {
        self.embeddingService = embeddingService
        self.knowledgeBaseManager = knowledgeBaseManager
        self.llmService = llmService
        self.maxContextChunks = maxContextChunks
        self.maxPromptTokens = maxPromptTokens
    }

    /// Processes a user query using the RAG pipeline.
    /// 1. Embeds the user query.
    /// 2. Searches the knowledge base for relevant chunks.
    /// 3. Constructs a prompt with the retrieved context.
    /// 4. Sends the prompt to the LLM for response generation.
    /// - Parameter query: The user's natural language query.
    /// - Returns: The generated response from the LLM.
    /// - Throws: `RAGAssistantError` if any step in the pipeline fails.
    func processQuery(_ query: String) async throws -> String {
        print("\n--- Processing Query: \"\(query)\" ---")

        // 1. User Query & Embedding
        // Generate an embedding for the user's query.
        let queryEmbedding = try await embeddingService.generateEmbedding(for: query)
        print("Query embedded.")

        guard await knowledgeBaseManager.getChunkCount() > 0 else {
            throw RAGAssistantError.vectorStoreEmpty
        }

        // 2. Vector Search
        // Retrieve the most relevant document chunks from the knowledge base.
        let relevantChunks = await knowledgeBaseManager.vectorStore.search(queryEmbedding: queryEmbedding, k: maxContextChunks)
        guard !relevantChunks.isEmpty else {
            print("No relevant chunks found for query.")
            return try await llmService.generateResponse(prompt: "Answer the following question: \(query)")
        }
        print("Retrieved \(relevantChunks.count) relevant chunks.")

        // 3. Context Construction
        // Assemble the retrieved chunks into a context string, managing the context window.
        var contextString = ""
        var currentTokenCount = llmService.estimateTokenCount(for: query) + llmService.estimateTokenCount(for: "Answer the following question based on the provided context:")

        for chunk in relevantChunks {
            let chunkTextWithSource = "Source: \(chunk.sourceURL.lastPathComponent)\n\(chunk.text)\n\n"
            let chunkTokenCount = llmService.estimateTokenCount(for: chunkTextWithSource)

            if currentTokenCount + chunkTokenCount < maxPromptTokens {
                contextString += chunkTextWithSource
                currentTokenCount += chunkTokenCount
            } else {
                print("Warning: Context window limit reached. Skipping further chunks.")
                break
            }
        }

        guard !contextString.isEmpty else {
            print("No context could be fit into the prompt. Proceeding with query only.")
            return try await llmService.generateResponse(prompt: "Answer the following question: \(query)")
        }

        // 4. Prompt Engineering
        // Combine the context and query into a structured prompt for the LLM.
        let prompt = """
        You are a helpful AI assistant. Answer the following question based *only* on the provided context.
        If the answer cannot be found in the context, state that you don't have enough information.

        Context:
        \(contextString)

        Question: \(query)

        Answer:
        """
        print("Prompt engineered. Total estimated tokens: \(currentTokenCount)")

        // Final check for prompt length before sending to LLM
        if llmService.estimateTokenCount(for: prompt) > maxPromptTokens {
            throw RAGAssistantError.contextWindowExceeded(maxTokens: maxPromptTokens, actualTokens: llmService.estimateTokenCount(for: prompt))
        }

        // 5. LLM Inference
        // Send the complete prompt to the LLM service for generation.
        let response = try await llmService.generateResponse(prompt: prompt)
        print("LLM response generated.")

        // 6. Response Delivery
        return response
    }
}

// MARK: - Example Usage in an App Context (macOS)

/// The main application entry point or a view model in a SwiftUI app.
@main
@available(macOS 14.0, iOS 17.0, *)
struct LocalKnowledgeBaseApp {
    static func main() async {
        print("Starting Local Knowledge Base Assistant...")

        // Initialize services
        let embeddingService = EmbeddingService()
        let vectorStore = VectorStore()
        let knowledgeBaseManager = KnowledgeBaseManager(embeddingService: embeddingService, vectorStore: vectorStore)
        let llmService = LLMService(modelName: "llama2:7b") // Using a hypothetical llama.cpp model name
        let ragAssistant = RAGAssistant(embeddingService: embeddingService, knowledgeBaseManager: knowledgeBaseManager, llmService: llmService)

        // --- Simulate Document Ingestion ---
        print("\n--- Ingesting Documents ---")
        let fileManager = FileManager.default
        let documentsDirectory = fileManager.temporaryDirectory.appendingPathComponent("RAGDocs", isDirectory: true)

        do {
            try fileManager.createDirectory(at: documentsDirectory, withIntermediateDirectories: true, attributes: nil)

            // Create some dummy documents
            let doc1Content = """
            Chapter 19: Context Management and RAG over Local Files
            This chapter delves into advanced techniques for managing context in AI agents, particularly focusing on Retrieval Augmented Generation (RAG) when working with local files on Apple Silicon.
            We explore how to efficiently load, chunk, embed, and retrieve information from documents stored directly on a Mac or iOS device.
            The use of llama.cpp Swift bindings is critical for achieving high performance and low latency inference with local LLMs.
            Swift 6 concurrency, including async/await and Actors, is fundamental for building responsive AI applications.
            """
            let doc1URL = documentsDirectory.appendingPathComponent("IntroToRAG.txt")
            try doc1Content.write(to: doc1URL, atomically: true, encoding: .utf8)
            try await knowledgeBaseManager.ingestDocument(from: doc1URL)

            let doc2Content = """
            Apple Silicon Architecture for AI
            Apple Silicon chips (M1, M2, M3 series) provide a unified memory architecture, which is highly beneficial for machine learning and AI workloads.
            The integrated Neural Engine accelerates on-device inference tasks significantly.
            This architecture, combined with frameworks like Core ML and the ability to run local LLMs via llama.cpp, makes Apple devices powerful platforms for AI development.
            Optimizing memory access and leveraging the GPU/Neural Engine are key for custom inference pipelines.
            """
            let doc2URL = documentsDirectory.appendingPathComponent("AppleSiliconAI.txt")
            try doc2Content.write(to: doc2URL, atomically: true, encoding: .utf8)
            try await knowledgeBaseManager.ingestDocument(from: doc2URL)

            let doc3Content = """
            Swift Concurrency Best Practices
            Building robust and performant applications requires careful use of Swift's concurrency model.
            Actors are essential for isolating mutable state and preventing data races in concurrent environments.
            Async/await simplifies asynchronous code, making it more readable and maintainable.
            Error handling with do-catch blocks and custom error types ensures graceful degradation and informative feedback to the user.
            """
            let doc3URL = documentsDirectory.appendingPathComponent("SwiftConcurrency.txt")
            try doc3Content.write(to: doc3URL, atomically: true, encoding: .utf8)
            try await knowledgeBaseManager.ingestDocument(from: doc3URL)

            print("Total chunks in knowledge base: \(await knowledgeBaseManager.getChunkCount())")

            // --- Simulate User Queries ---
            print("\n--- Simulating User Queries ---")

            let queries = [
                "What are the benefits of Apple Silicon for AI?",
                "How does Swift 6 concurrency help in AI apps?",
                "What is RAG and why is it important for local files?",
                "Tell me about context management in AI agents.",
                "What is the capital of France?" // Out of context query
            ]

            for query in queries {
                do {
                    let response = try await ragAssistant.processQuery(query)
                    print("Assistant: \(response)")
                } catch {
                    print("Error processing query '\(query)': \(error.localizedDescription)")
                }
            }

        } catch {
            print("An error occurred during setup or ingestion: \(error.localizedDescription)")
        }

        // Clean up temporary documents
        do {
            try fileManager.removeItem(at: documentsDirectory)
            print("\nCleaned up temporary documents.")
        } catch {
            print("Error cleaning up temporary documents: \(error.localizedDescription)")
        }

        print("Local Knowledge Base Assistant finished.")
    }
}
