
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

enum ModelTier: Sendable {
    case lowCost      // e.g., gpt-4o-mini
    case highIntelligence // e.g., gpt-4o
}

/// Tracks telemetry data safely across concurrent tasks.
actor TelemetryManager {
    private(set) var totalSavings: Double = 0.0
    private let premiumCostPerToken = 0.01
    private let cheapCostPerToken = 0.0005

    func logSavings(for tokens: Int, tier: ModelTier) {
        if tier == .lowCost {
            let saved = Double(tokens) * (premiumCostPerToken - cheapCostPerToken)
            totalSavings += saved
        }
    }
}

actor ModelOrchestrator {
    private let telemetry = TelemetryManager()
    
    // Stream to notify UI of routing decisions
    private var statusContinuation: AsyncStream<String>.Continuation?
    lazy var statusStream: AsyncStream<String> = {
        AsyncStream { continuation in
            self.statusContinuation = continuation
        }
    }()

    func route(query: String) async -> ModelTier {
        statusContinuation?.yield("Analyzing complexity...")
        
        // Heuristic 1: Keyword detection
        let premiumKeywords = ["architecture", "refactor", "optimize", "algorithm"]
        let containsPremiumKeyword = premiumKeywords.contains { query.lowercased().contains($0) }
        
        // Heuristic 2: Complexity Score (Punctuation density & length)
        let punctuationCount = query.filter { "!?.()[]{}".contains($0) }.count
        let complexityScore = Double(punctuationCount) / Double(max(1, query.count))
        
        // Decision Logic
        if containsPremiumKeyword || complexityScore > 0.1 || query.count > 500 {
            statusContinuation?.yield("Routing to High Intelligence Model...")
            return .highIntelligence
        } else {
            statusContinuation?.yield("Routing to Low Cost Model...")
            return .lowCost
        }
    }

    func execute(query: String) async throws -> String {
        let tier = await route(query: query)
        
        // Simulate API Call
        try await Task.sleep(for: .seconds(1)) 
        let simulatedTokenCount = query.count / 4
        
        // Log telemetry
        await telemetry.logSavings(for: simulatedTokenCount, tier: tier)
        
        let modelName = tier == .highIntelligence ? "gpt-4o" : "gpt-4o-mini"
        return "[Response from \(modelName)]: This is a simulated response to: \(query)"
    }
    
    func getSavings() async -> Double {
        await telemetry.totalSavings
    }
}

// MARK: - Implementation Example
@MainActor
func runOrchestratorDemo() async {
    let orchestrator = ModelOrchestrator()
    
    // Observe the status stream in a separate task
    Task {
        for await status in await orchestrator.statusStream {
            print("UI Update: \(status)")
        }
    }
    
    let queries = [
        "What is a constant?",
        "Please refactor this complex architecture for better scalability."
    ]
    
    for query in queries {
        print("\nUser Query: \(query)")
        do {
            let response = try await orchestrator.execute(query: query)
            print("Result: \(response)")
        } catch {
            print("Error: \(error)")
        }
    }
    
    let savings = await orchestrator.getSavings()
    print("\nTotal Cost Saved: $\(String(format: "%.4f", savings))")
}
