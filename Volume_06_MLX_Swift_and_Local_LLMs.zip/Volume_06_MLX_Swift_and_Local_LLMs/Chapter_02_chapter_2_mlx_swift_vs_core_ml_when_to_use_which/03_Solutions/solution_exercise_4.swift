
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import MLX

@available(iOS 18.0, macOS 15.0, *)
class LoRALinear: MLXNN.Module {
    let loraA: MLXNN.Linear
    let loraB: MLXNN.Linear

    // 1. Design LoRALinear Module
    // 2. Initialize LoRA Layers
    init(inputDim: Int, outputDim: Int, rank: Int) {
        // loraA maps inputDim to the smaller rank dimension
        self.loraA = MLXNN.Linear(inputFeatures: inputDim, outputFeatures: rank)
        // loraB maps the rank dimension back to the outputDim
        self.loraB = MLXNN.Linear(inputFeatures: rank, outputFeatures: outputDim)

        super.init() // Call super.init() after all properties are initialized

        // Crucial for LoRA: Initialize loraB's weights to zero.
        // This ensures that at initialization, the LoRA adapter adds zero to the base model's output.
        // The bias for loraB is typically also initialized to zero or omitted in standard LoRA.
        self.loraB.weight = MLXArray.zeros(loraB.weight.shape)
        if let bias = self.loraB.bias {
            self.loraB.bias = MLXArray.zeros(bias.shape)
        }
    }

    // 3. Implement Forward Pass
    override func callAsFunction(_ inputs: MLXArray) -> MLXArray {
        // The LoRA forward pass: input -> loraA -> loraB
        // This represents the delta_W part of a LoRA-adapted linear layer: (input @ W_A) @ W_B
        return (inputs @ loraA) @ loraB
    }
}

@available(iOS 18.0, macOS 15.0, *)
func demonstrateLoRAConcept() {
    let inputDim = 768 // Example hidden dimension of a transformer
    let outputDim = 768
    let rank = 8      // Low rank for LoRA (e.g., 4, 8, 16, 32)

    let loRALayer = LoRALinear(inputDim: inputDim, outputDim: outputDim, rank: rank)
    // Sample input: batch size 1, input features = inputDim
    let sampleInput = MLXArray.randomUniform(low: -1, high: 1, shape: [1, inputDim])

    // Perform a forward pass
    let output = loRALayer(sampleInput)
    print("LoRA Layer Output Shape: \(output.shape)") // Expected: [1, 768]

    // 4. Conceptual Gradient Step for Fine-tuning
    // To fine-tune *only* the `loraA` and `loraB` parameters (and their biases)
    // while keeping a hypothetical "base model" (e.g., a large MLXNN.Linear layer
    // that this LoRALinear conceptually adapts) frozen, you would structure your
    // training loop and loss function as follows:
    //
    // 1. Define a `lossFunction` that takes the `LoRALinear` module's parameters
    //    (or the module itself) and your input/target data.
    //    Example (conceptual):
    //    func totalLoss(loraModule: LoRALinear, input: MLXArray, target: MLXArray) -> MLXArray {
    //        // Hypothetical base model output (frozen, not part of gradient calculation)
    //        // let baseOutput = baseLinearLayer(input)
    //
    //        // LoRA adapter output
    //        let loraOutput = loraModule(input)
    //
    //        // The full adapted output would be `baseOutput + loraOutput`
    //        // For this exercise, we just use loraOutput for simplicity.
    //        let prediction = loraOutput // Or baseOutput + loraOutput
    //
    //        // Calculate a loss based on prediction and target
    //        return MLXNN.losses.mseLoss(predictions: prediction, targets: target)
    //    }
    //
    // 2. Use `valueAndGradient` on this `totalLoss` function.
    //    `valueAndGradient` automatically tracks gradients for all `MLXArray` parameters
    //    that are part of the computation graph *and* are passed as arguments to the
    //    function being differentiated.
    //
    //    let (lossValue, gradients) = valueAndGradient(totalLoss)(loraLayer, inputData, targetData)
    //
    // How MLX's autograd system facilitates this:
    // - When `valueAndGradient` is applied, MLX builds a computation graph. It traverses
    //   this graph, identifying all operations and their dependencies.
    // - Crucially, `MLXNN.Module`'s `MLXArray` properties (like `loraA.weight`, `loraB.weight`, etc.)
    //   are marked as trainable. When these are used in the forward pass and passed to
    //   `valueAndGradient`, MLX knows to compute gradients with respect to them.
    // - If the "base model" parameters (e.g., a `MLXNN.Linear` layer's weights) are not
    //   properties of the `loraModule` passed to `valueAndGradient`, or if they are explicitly
    //   marked as non-trainable (e.g., if they were loaded from a pre-trained model and
    //   never added to the optimizer's parameter list), MLX will simply treat them as constants
    //   during the backward pass, and no gradients will be computed for them.
    // - This allows for efficient fine-tuning where only a small number of LoRA parameters
    //   are updated, significantly reducing memory and computational overhead compared to
    //   fine-tuning the entire base model.
    //
    // After obtaining `gradients`, you would typically apply an optimizer (e.g., Adam)
    // to update `loraLayer.parameters()` using these gradients.
}

// To run this, you would call:
// demonstrateLoRAConcept()
