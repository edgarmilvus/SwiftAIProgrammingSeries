
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreML // Used for interacting with the generated .mlmodel
import Vision // Often used for image processing with CoreML, especially for image classifiers

/// Represents a photo with its identifier, URL, and classification labels.
struct Photo: Identifiable, Codable {
    let id: UUID
    let url: URL // Local URL to the photo asset
    var predictedLabel: String?
    var userCorrectedLabel: String?
    let timestamp: Date

    init(url: URL, predictedLabel: String? = nil, userCorrectedLabel: String? = nil) {
        self.id = UUID()
        self.url = url
        self.predictedLabel = predictedLabel
        self.userCorrectedLabel = userCorrectedLabel
        self.timestamp = Date()
    }

    /// Determines the effective label for the photo, prioritizing user correction.
    var effectiveLabel: String? {
        return userCorrectedLabel ?? predictedLabel
    }
}

/// Represents a single feedback entry from the user.
/// This data will be collected for future model retraining.
struct FeedbackEntry: Identifiable, Codable {
    let id: UUID
    let photoID: UUID
    let originalPredictedLabel: String
    let userProvidedCorrectLabel: String
    let feedbackTimestamp: Date

    init(photo: Photo, userCorrectedLabel: String) throws {
        guard let originalPrediction = photo.predictedLabel else {
            throw FeedbackError.missingOriginalPrediction
        }
        self.id = UUID()
        self.photoID = photo.id
        self.originalPredictedLabel = originalPrediction
        self.userProvidedCorrectLabel = userCorrectedLabel
        self.feedbackTimestamp = Date()
    }
}

/// Custom errors for the feedback system.
enum FeedbackError: Error, LocalizedError {
    case missingOriginalPrediction
    case feedbackPersistenceFailed(Error)
    case feedbackRetrievalFailed(Error)
    case invalidModelInput
    case predictionFailed(Error)

    var errorDescription: String? {
        switch self {
        case .missingOriginalPrediction:
            return "The original model prediction was missing when attempting to create feedback."
        case .feedbackPersistenceFailed(let error):
            return "Failed to persist feedback: \(error.localizedDescription)"
        case .feedbackRetrievalFailed(let error):
            return "Failed to retrieve feedback: \(error.localizedDescription)"
        case .invalidModelInput:
            return "Invalid input provided to the Core ML model."
        case .predictionFailed(let error):
            return "Model prediction failed: \(error.localizedDescription)"
        }
    }
}

/// A class responsible for classifying images using a Core ML model.
/// This simulates loading a Create ML-generated model.
@available(iOS 18.0, *) // Using modern concurrency features
class PhotoClassifier {
    private let model: MLModel

    /// Initializes the classifier with a compiled Core ML model URL.
    /// In a real app, this would typically load `MyImageClassifier.mlmodelc`
    /// from the app bundle.
    ///
    /// - Parameter modelURL: The URL to the compiled Core ML model (.mlmodelc).
    init(modelURL: URL) throws {
        self.model = try MLModel(contentsOf: modelURL)
        print("PhotoClassifier initialized with model: \(modelURL.lastPathComponent)")
    }

    /// Predicts the category of an image.
    ///
    /// - Parameter imageURL: The URL of the image to classify.
    /// - Returns: The predicted category label as a String.
    /// - Throws: `FeedbackError.predictionFailed` if classification fails.
    func classifyImage(at imageURL: URL) async throws -> String {
        // In a real app, you'd load the image, preprocess it for the model
        // (e.g., resize, convert to CVPixelBuffer), and then create an MLFeatureProvider.

        // --- Simulate image loading and feature creation ---
        // For Create ML image classifiers, the input is typically an `MLFeatureValue`
        // representing a `CVPixelBuffer`.
        // Here, we'll simulate a generic input and output for demonstration.
        // Replace this with actual Vision/CoreML image processing for a real app.

        let inputName = model.modelDescription.inputDescriptionsByName.first?.key ?? "image"
        let outputName = model.modelDescription.outputDescriptionsByName.first?.key ?? "label"

        // Simulate a simple feature provider for demonstration.
        // In a real image classifier, you'd use VNCoreMLModel and VNCoreMLRequest
        // for robust image input handling.
        let inputFeatures: [String: MLFeatureValue] = [
            inputName: MLFeatureValue(string: imageURL.lastPathComponent) // Placeholder
        ]
        
        let provider = try MLDictionaryFeatureProvider(dictionary: inputFeatures)

        do {
            let prediction = try model.prediction(from: provider)
            guard let predictedLabel = prediction.featureValue(for: outputName)?.stringValue else {
                throw FeedbackError.predictionFailed(NSError(domain: "PhotoClassifier", code: 0, userInfo: [NSLocalizedDescriptionKey: "Model output 'label' not found or not a string."]))
            }
            return predictedLabel
        } catch {
            throw FeedbackError.predictionFailed(error)
        }
    }
}

/// Manages the collection and persistence of user feedback.
@available(iOS 18.0, *)
class FeedbackManager {
    private var feedbackEntries: [FeedbackEntry] = []
    private let feedbackFileName = "user_feedback.json"
    private let fileURL: URL

    init() {
        // Determine a suitable location for storing feedback, e.g., Application Support directory.
        if let appSupportURL = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first {
            self.fileURL = appSupportURL.appendingPathComponent(feedbackFileName)
            // Ensure the directory exists
            try? FileManager.default.createDirectory(at: appSupportURL, withIntermediateDirectories: true, attributes: nil)
        } else {
            // Fallback to temporary directory or handle error appropriately
            self.fileURL = FileManager.default.temporaryDirectory.appendingPathComponent(feedbackFileName)
            print("Warning: Could not find Application Support directory, using temporary directory for feedback.")
        }
        
        // Load existing feedback asynchronously
        Task { await loadFeedback() }
    }

    /// Adds a new feedback entry and attempts to persist it.
    ///
    /// - Parameters:
    ///   - photo: The photo object that was corrected.
    ///   - userCorrectedLabel: The label provided by the user.
    func recordFeedback(for photo: Photo, userCorrectedLabel: String) async throws {
        let newEntry = try FeedbackEntry(photo: photo, userCorrectedLabel: userCorrectedLabel)
        feedbackEntries.append(newEntry)
        print("Recorded feedback: Photo ID \(newEntry.photoID), original '\(newEntry.originalPredictedLabel)', corrected to '\(newEntry.userProvidedCorrectLabel)'")
        try await saveFeedback()
    }

    /// Persists the current feedback entries to a JSON file.
    private func saveFeedback() async throws {
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            let data = try encoder.encode(feedbackEntries)
            try data.write(to: fileURL, options: [.atomicWrite])
            print("Feedback saved to \(fileURL.lastPathComponent). Total entries: \(feedbackEntries.count)")
        } catch {
            throw FeedbackError.feedbackPersistenceFailed(error)
        }
    }

    /// Loads feedback entries from the JSON file.
    private func loadFeedback() async {
        guard FileManager.default.fileExists(atPath: fileURL.path) else {
            print("No existing feedback file found at \(fileURL.lastPathComponent).")
            return
        }

        do {
            let data = try Data(contentsOf: fileURL)
            let decoder = JSONDecoder()
            feedbackEntries = try decoder.decode([FeedbackEntry].self, from: data)
            print("Loaded \(feedbackEntries.count) feedback entries from \(fileURL.lastPathComponent).")
        } catch {
            print("Error loading feedback: \(error.localizedDescription)")
            // It might be a corrupt file, consider backing it up or starting fresh
        }
    }

    /// Retrieves all recorded feedback entries.
    /// - Returns: An array of `FeedbackEntry`.
    func getAllFeedback() -> [FeedbackEntry] {
        return feedbackEntries
    }

    /// Clears all stored feedback (e.g., after successful retraining and redeployment).
    func clearAllFeedback() async throws {
        feedbackEntries.removeAll()
        do {
            if FileManager.default.fileExists(atPath: fileURL.path) {
                try FileManager.default.removeItem(at: fileURL)
                print("All feedback cleared and file removed.")
            }
        } catch {
            throw FeedbackError.feedbackPersistenceFailed(error)
        }
    }
}


// MARK: - App Simulation

/// Simulates the main application flow.
@available(iOS 18.0, *)
func simulateAppWorkflow() async {
    print("--- Starting Smart Photo Organizer Simulation ---")

    // 1. Prepare a dummy .mlmodelc URL for demonstration.
    // In a real app, this would be the compiled model from your app bundle.
    // For local testing, you might compile a dummy model or point to a known path.
    // For this example, we'll simulate a valid URL, but the actual model loading
    // will be a placeholder since we don't have a real .mlmodelc.
    guard let dummyModelURL = URL(string: "file:///path/to/MyImageClassifier.mlmodelc") else {
        fatalError("Invalid dummy model URL.")
    }

    let classifier: PhotoClassifier
    do {
        // Attempt to initialize the classifier. In a real app, ensure MyImageClassifier.mlmodelc
        // is present in your app bundle and loaded correctly.
        // For this simulation, the actual model content doesn't matter as we mock prediction.
        classifier = try PhotoClassifier(modelURL: dummyModelURL)
    } catch {
        print("Failed to initialize PhotoClassifier: \(error.localizedDescription)")
        return
    }

    let feedbackManager = FeedbackManager()

    // 2. Simulate some photos and their initial classification.
    var photos: [Photo] = [
        Photo(url: URL(fileURLWithPath: "/photos/IMG_001.heic")),
        Photo(url: URL(fileURLWithPath: "/photos/IMG_002.heic")),
        Photo(url: URL(fileURLWithPath: "/photos/IMG_003.heic")),
        Photo(url: URL(fileURLWithPath: "/photos/IMG_004.heic")),
        Photo(url: URL(fileURLWithPath: "/photos/IMG_005.heic"))
    ]

    print("\n--- Initial Photo Classification ---")
    for i in 0..<photos.count {
        do {
            // Simulate prediction logic
            let simulatedPrediction: String
            switch i {
            case 0: simulatedPrediction = "Landscape"
            case 1: simulatedPrediction = "Pet"
            case 2: simulatedPrediction = "Food"
            case 3: simulatedPrediction = "Landscape" // This will be misclassified
            case 4: simulatedPrediction = "Portrait"
            default: simulatedPrediction = "Unknown"
            }
            
            // In a real app:
            // let prediction = try await classifier.classifyImage(at: photos[i].url)
            // photos[i].predictedLabel = prediction
            photos[i].predictedLabel = simulatedPrediction
            print("Photo \(photos[i].url.lastPathComponent) classified as: \(photos[i].predictedLabel ?? "N/A")")

        } catch {
            print("Error classifying photo \(photos[i].url.lastPathComponent): \(error.localizedDescription)")
        }
    }

    // 3. Simulate user correcting a misclassification.
    print("\n--- Simulating User Feedback ---")
    if var misclassifiedPhoto = photos.first(where: { $0.url.lastPathComponent == "IMG_004.heic" }) {
        print("User finds photo \(misclassifiedPhoto.url.lastPathComponent) (predicted '\(misclassifiedPhoto.predictedLabel ?? "")') is actually a 'Portrait'.")
        let userCorrection = "Portrait"
        misclassifiedPhoto.userCorrectedLabel = userCorrection

        do {
            try await feedbackManager.recordFeedback(for: misclassifiedPhoto, userCorrectedLabel: userCorrection)
            // Update the photo in our local array with the corrected label
            if let index = photos.firstIndex(where: { $0.id == misclassifiedPhoto.id }) {
                photos[index] = misclassifiedPhoto
            }
        } catch {
            print("Error recording feedback: \(error.localizedDescription)")
        }
    }
    
    // Simulate another correction
    if var anotherMisclassifiedPhoto = photos.first(where: { $0.url.lastPathComponent == "IMG_002.heic" }) {
        print("User finds photo \(anotherMisclassifiedPhoto.url.lastPathComponent) (predicted '\(anotherMisclassifiedPhoto.predictedLabel ?? "")') is actually a 'Wildlife'.")
        let userCorrection = "Wildlife"
        anotherMisclassifiedPhoto.userCorrectedLabel = userCorrection

        do {
            try await feedbackManager.recordFeedback(for: anotherMisclassifiedPhoto, userCorrectedLabel: userCorrection)
            if let index = photos.firstIndex(where: { $0.id == anotherMisclassifiedPhoto.id }) {
                photos[index] = anotherMisclassifiedPhoto
            }
        } catch {
            print("Error recording feedback: \(error.localizedDescription)")
        }
    }


    // 4. Later, retrieve all collected feedback.
    print("\n--- Reviewing Collected Feedback ---")
    let allFeedback = feedbackManager.getAllFeedback()
    if allFeedback.isEmpty {
        print("No feedback collected yet.")
    } else {
        print("Total feedback entries: \(allFeedback.count)")
        for entry in allFeedback {
            print("- Photo ID: \(entry.photoID), Original: '\(entry.originalPredictedLabel)', Corrected: '\(entry.userProvidedCorrectLabel)'")
        }
    }

    // 5. Simulate a scenario where feedback is sent to a backend for retraining.
    // In a real app, this would involve uploading the photo (or its identifier)
    // along with the feedback to a server.
    print("\n--- Preparing Feedback for Retraining ---")
    if !allFeedback.isEmpty {
        print("Feedback data is ready for export to a retraining pipeline.")
        print("This would typically involve uploading the original images (or references) ")
        print("along with their new, correct labels to a cloud service or local storage for batch processing.")
        
        // After successful export/retraining, you might clear the local feedback.
        // try await feedbackManager.clearAllFeedback()
    }

    print("\n--- Simulation Complete ---")
}

// To run the simulation in a Swift Playground or an app's entry point:
// Ensure you are targeting iOS 18.0 or later for @available(iOS 18.0, *)
// Task {
//     await simulateAppWorkflow()
// }
