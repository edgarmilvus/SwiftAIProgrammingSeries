
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

enum ModelStatus: Sendable {
    case idle
    case loading(Task<Void, Error>)
    case ready
    case failed(String)
}

actor ModelOrchestrator {
    private var modelStates: [String: ModelStatus] = [:]
    private var loadingQueue: [String] = []
    private var isProcessingQueue = false

    /// Loads a model with specific priority and serialization.
    func loadModel(id: String, priority: TaskPriority = .medium) async throws {
        // 1. Check if already loading or ready
        if case .ready = modelStates[id] { return }
        
        // 2. Add to queue and start processing if not already
        loadingQueue.append(id)
        try await processQueue(priority: priority)
    }

    private func processQueue(priority: TaskPriority) async throws {
        guard !isProcessingQueue else { return }
        isProcessingQueue = true
        
        while !loadingQueue.isEmpty {
            let nextModelId = loadingQueue.removeFirst()
            
            // 3. Memory-Aware Throttling (Simulation)
            // In a real app, call MemoryMonitor.getResidentSetSize() here
            if await checkSystemPressure() == .critical {
                modelStates[nextModelId] = .failed("System under extreme pressure")
                continue
            }

            // 4. Create the loading task
            let loadTask = Task(priority: priority) {
                try await self.performActualLoad(id: nextModelId)
            }
            
            modelStates[nextModelId] = .loading(loadTask)
            
            do {
                try await loadTask.value
                modelStates[nextModelId] = .ready
            } catch is CancellationError {
                modelStates[nextModelId] = .failed("Cancelled")
                throw CancellationError()
            } catch {
                modelStates[nextModelId] = .failed(error.localizedDescription)
            }
        }
        
        isProcessingQueue = false
    }

    private func performActualLoad(id: String) async throws {
        // Simulate heavy I/O and allocation
        for i in 1...10 {
            try Task.checkCancellation() // 5. Frequent cancellation checks
            
            // Simulate incremental allocation
            try await Task.sleep(for: .seconds(0.5))
            print("Loading \(id): \(i*10)% complete...")
        }
    }

    private func checkSystemPressure() async -> MemoryPressure {
        // Placeholder for actual MemoryMonitor integration
        return .normal
    }

    // Nonisolated allows UI to check status without actor hopping
    nonisolated func getStatus(for id: String) -> ModelStatus {
        // In a real implementation, this would require a way to 
        // read the state safely, perhaps via a separate thread-safe storage.
        // For this exercise, we assume the UI queries via an async method.
        return .idle 
    }
    
    enum MemoryPressure { case normal, warning, critical }
}
