/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// themeStore.ts
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface ThemeState {
  theme: 'light' | 'dark';
  isLoading: boolean;
  toggleTheme: () => void;
  setTheme: (theme: 'light' | 'dark') => void;
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      theme: 'light', // Default
      isLoading: true, // Start loading to wait for hydration
      toggleTheme: () =>
        set((state) => ({
          theme: state.theme === 'light' ? 'dark' : 'light',
        })),
      setTheme: (theme) => set({ theme }),
    }),
    {
      name: '@app-theme',
      storage: createJSONStorage(() => (typeof window !== 'undefined' ? localStorage : AsyncStorage)),
      // Hook into the hydration process to update loading state
      onRehydrateStorage: () => (state) => {
        if (state) {
          state.isLoading = false;
        } else {
          // Handle edge case where state might be undefined
           // Force a reset or default if needed, but here we just stop loading
           const store = useThemeStore.getState();
           store.setTheme('light');
           store.isLoading = false;
        }
      },
    }
  )
);

// ThemeToggle.tsx
import React from 'react';
import { Text, Pressable, View } from 'react-native';
import { useThemeStore } from './themeStore';

export const ThemeToggle = () => {
  // Select specific state slices
  const { theme, isLoading, toggleTheme } = useThemeStore();

  if (isLoading) {
    return (
      <View className="p-4 border rounded-lg bg-gray-100">
        <Text>Loading Theme...</Text>
      </View>
    );
  }

  // Dynamic Styling Logic
  const containerClasses = `border p-4 rounded-lg transition-colors duration-300 ${
    theme === 'dark'
      ? 'bg-gray-900 text-white border-gray-700'
      : 'bg-white text-black border-gray-200'
  }`;

  return (
    <Pressable onPress={toggleTheme} className={containerClasses}>
      <Text className="font-bold text-center">
        Current Theme: {theme.toUpperCase()}
      </Text>
      <Text className="text-center mt-2 text-sm opacity-70">
        Press to toggle
      </Text>
    </Pressable>
  );
};
