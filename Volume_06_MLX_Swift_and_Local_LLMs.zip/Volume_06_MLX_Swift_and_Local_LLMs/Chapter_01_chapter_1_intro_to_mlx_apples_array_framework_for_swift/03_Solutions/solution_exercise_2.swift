
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

@available(iOS 18.0, macOS 14.0, *)
import MLX

/// Analyzes 1D heart rate data to calculate the average and maximum heart rate.
///
/// - Parameter data: A 1D MLXArray containing Float values of heart rate readings (BPM).
/// - Returns: A tuple containing two MLXArray scalars: `average` heart rate and `max` heart rate.
func analyzeHeartRateData(_ data: MLXArray) -> (average: MLXArray, max: MLXArray) {
    // Ensure data is Float, though MLXArray(Array<Float>) will typically already be Float.
    let floatData = data.astype(Float.self)

    // Calculate the mean (average) of the heart rate data.
    // mean() is a reduction operation that returns a scalar MLXArray.
    let averageHR = floatData.mean()

    // Calculate the maximum value in the heart rate data.
    // max() is another reduction operation returning a scalar MLXArray.
    let maxHR = floatData.max()

    return (average: averageHR, max: maxHR)
}

// Example usage:
let heartRateReadings: [Float] = [72.5, 75.1, 68.9, 82.3, 70.0, 78.6, 65.2, 90.1]
let dataArray = MLXArray(heartRateReadings)

print("Heart Rate Readings:", dataArray.eval())

let (averageHR, maxHR) = analyzeHeartRateData(dataArray)

// Force evaluation and print the results
print("Average Heart Rate:", averageHR.eval())
print("Maximum Heart Rate:", maxHR.eval())

// Example with a different dataset
let moreReadings: [Float] = [60.0, 62.0, 58.0, 95.0, 70.0]
let moreDataArray = MLXArray(moreReadings)
let (avgMore, maxMore) = analyzeHeartRateData(moreDataArray)
print("\nMore Readings Average:", avgMore.eval())
print("More Readings Maximum:", maxMore.eval())
