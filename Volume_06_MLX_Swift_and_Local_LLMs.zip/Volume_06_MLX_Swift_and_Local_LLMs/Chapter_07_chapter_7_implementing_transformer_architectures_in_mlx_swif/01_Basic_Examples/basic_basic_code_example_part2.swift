
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import MLX
import MLXNN // Essential for neural network modules like Module and Linear

// MARK: - 1. Define the Custom MLXNN.Module

/// A `SimpleFeatureExtractor` module that performs a linear transformation
/// followed by a ReLU activation. This serves as a basic building block,
/// often found as a feed-forward layer within a larger Transformer architecture.
///
/// It processes an input `MLXArray` and transforms its feature dimension.
@available(iOS 18.0, macOS 15.0, *) // Requires latest iOS/macOS SDK for compilation
class SimpleFeatureExtractor: MLXNN.Module {
    /// The linear layer responsible for the affine transformation (matrix multiplication + bias).
    let linear: MLXNN.Linear

    /// Initializes the feature extractor.
    /// - Parameters:
    ///   - inputDim: The number of input features (e.g., embedding dimension).
    ///   - outputDim: The number of output features after transformation.
    init(inputDim: Int, outputDim: Int) {
        // Instantiate the linear layer. MLXNN.Linear manages its own weights and biases.
        self.linear = MLXNN.Linear(inputSize: inputDim, outputSize: outputDim)
        super.init() // Call the superclass initializer for MLXNN.Module
    }

    /// Performs the forward pass of the module.
    /// This method defines how input data is processed through the layer.
    /// - Parameter input: An `MLXArray` representing the input features.
    ///                    Expected shape: `(batch_size, sequence_length, inputDim)`
    /// - Returns: An `MLXArray` representing the transformed features.
    ///            Output shape: `(batch_size, sequence_length, outputDim)`
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Apply the linear transformation.
        // MLX's Linear layer automatically handles input tensors with arbitrary leading dimensions
        // (like batch_size and sequence_length here), applying the transformation to the last dimension.
        let linearOutput = linear(input)
        
        // Apply the Rectified Linear Unit (ReLU) activation function.
        // ReLU introduces non-linearity, which is critical for neural networks
        // to learn and model complex, non-linear relationships in data.
        let activatedOutput = MLX.relu(linearOutput)
        
        return activatedOutput
    }
}

// MARK: - 2. Define a Simple Loss Function

/// `calculateLoss` computes the Mean Squared Error (MSE) between the model's predictions
/// and a given target. This function is designed to be used with MLX's `valueAndGradient`
/// to obtain both the loss value and its gradients with respect to the model's parameters.
///
/// - Parameters:
///   - model: The `SimpleFeatureExtractor` instance whose predictions are being evaluated.
///   - input: The input `MLXArray` fed to the model.
///   - target: The `MLXArray` representing the desired output or ground truth.
/// - Returns: A scalar `MLXArray` representing the computed MSE loss.
@available(iOS 18.0, macOS 15.0, *)
func calculateLoss(model: SimpleFeatureExtractor, input: MLXArray, target: MLXArray) -> MLXArray {
    // Perform the forward pass to get the model's predictions.
    let predictions = model(input)
    
    // Calculate the element-wise squared difference between predictions and targets.
    let squaredError = MLX.square(predictions - target)
    
    // Compute the mean of all squared errors to get a single scalar loss value.
    // This aggregates the error across all elements in the batch and sequence.
    let loss = MLX.mean(squaredError)
    
    return loss
}

// MARK: - 3. Main Execution Context for the Example

@available(iOS 18.0, macOS 15.0, *)
@main
struct MLXTransformerExample {
    static func main() async {
        print("🚀 Starting MLX Swift Basic Feature Extractor Example...")

        // --- MLX Device Configuration and Core Concepts ---
        // MLX Swift automatically uses the GPU on Apple Silicon devices if available.
        // You can explicitly set the default device for computations:
        // MLX.set_default_device(.gpu) // Explicitly use GPU
        // MLX.set_default_device(.cpu) // Explicitly use CPU
        print("⚙️ MLX is using the default device: \(MLX.defaultDevice())")
        print("✨ Unified Memory: MLXArray leverages Apple Silicon's Unified Memory,")
        print("   enabling zero-copy data sharing between CPU and GPU, boosting performance.")
        print("⏳ Lazy Evaluation: MLX operations build a computation graph. Actual computation")
        print("   only occurs when a value is explicitly requested (e.g., .item(), .description, .eval()).")


        // --- Model and Data Parameters ---
        let inputDimension = 128   // Represents the dimensionality of each token's embedding (e.g., from a word embedding model)
        let outputDimension = 64    // The desired dimensionality of the extracted features
        let batchSize = 4           // Number of input phrases/sequences to process simultaneously
        let sequenceLength = 10     // Maximum number of tokens in each phrase

        // --- 4. Instantiate the Model ---
        // Create an instance of our custom feature extractor.
        let model = SimpleFeatureExtractor(inputDim: inputDimension, outputDim: outputDimension)
        print("\n✅ Model created. It has \(model.parameters().count) trainable parameters.")
        
        // --- 5. Prepare Dummy Data (Simulating Chat App Input) ---
        // We generate random uniform data to simulate input. In a real "Smart Chat" app,
        // this `inputData` would come from token embeddings of user messages.
        // Shape: (batch_size, sequence_length, embedding_dimension)
        let inputData = MLXArray.randomUniform(
            low: -1, high: 1,
            shape: [batchSize, sequenceLength, inputDimension]
        )
        print("➡️ Input Data Shape: \(inputData.shape) (Batch Size, Sequence Length, Input Dimension)")

        // Dummy target data for supervised learning. In a real scenario, this would be
        // ground truth labels or desired feature representations for training.
        // Shape: (batch_size, sequence_length, target_feature_dimension)
        let targetData = MLXArray.randomUniform(
            low: -0.5, high: 0.5,
            shape: [batchSize, sequenceLength, outputDimension]
        )
        print("🎯 Target Data Shape: \(targetData.shape) (Batch Size, Sequence Length, Output Dimension)")

        // --- 6. Perform a Forward Pass (Inference Example) ---
        print("\n--- Performing a single forward pass (inference) ---")
        let outputFeatures = model(inputData)
        
        // Due to lazy evaluation, `outputFeatures` is currently just a node in the computation graph.
        // The actual computation has not yet occurred on the hardware.
        print("Output Features (lazy MLXArray representation): \(outputFeatures)")

        // To force the computation and get the actual shape/value, MLX needs to evaluate the graph.
        // Accessing `.shape` or `.item()` implicitly triggers evaluation for that path.
        print("Output Features (computed shape): \(outputFeatures.shape)")
        // Uncomment the line below to see an actual computed value from the output features.
        // Note: `.item()` forces computation of the specific element requested.
        // print("First element of output features: \(outputFeatures[0, 0, 0].item())") 

        // --- 7. Compute Loss and Gradients (Training Example) ---
        print("\n--- Computing Loss and Gradients for Training ---")

        // MLX's `valueAndGradient` is a powerful functional transformation for automatic differentiation.
        // It takes a function (our `calculateLoss`) and returns a *new* function.
        // When this new function is called, it computes both the original function's value (the loss)
        // and the gradients of that value with respect to the specified `parameters`.
        let lossAndGradientFn = MLX.valueAndGradient(
            calculateLoss,
            parameters: model.parameters() // We want gradients for all trainable parameters in our model
        )

        // Execute the `lossAndGradientFn`. This is the point where the entire computation graph
        // (from inputData through the model to loss calculation) is built and then executed.
        // MLX efficiently calculates the loss and all required gradients during this single pass.
        let (loss, gradients) = lossAndGradientFn(model, inputData, targetData)

        // The `loss` MLXArray now holds the computed scalar loss value.
        print("📉 Computed Loss: \(loss.item())")

        // `gradients` is a dictionary where keys are parameter names (e.g., "linear.weight", "linear.bias")
        // and values are `MLXArray`s containing the corresponding gradients.
        print("📈 Number of computed gradients: \(gradients.count)")
        if let firstGrad = gradients.first {
            print("Example gradient for parameter '\(firstGrad.key)': Shape \(firstGrad.value.shape)")
            // Uncomment the line below to see an actual computed gradient value.
            // print("Value of example gradient for '\(firstGrad.key)': \(firstGrad.value[0,0].item())")
        }

        // In a full training loop, an optimizer (e.g., `MLXOptimizers.Adam`) would then use
        // these `gradients` to update the `model.parameters()` to minimize the `loss`.
        // For this basic example, we stop after demonstrating gradient computation.
        print("\n🎉 MLX Swift Basic Feature Extractor example completed successfully.")
    }
}

// MARK: - Common Pitfalls

### Common Pitfalls

When developing with MLX Swift on Apple platforms, especially for beginners or those transitioning from other machine learning frameworks, several common pitfalls can arise. Understanding these can save significant debugging time.

1.  **Forgetting `@MainActor` for UI Updates from Async Contexts:**
    *   **Issue:** Machine learning computations, particularly training loops or complex inference tasks, are almost always performed asynchronously on background threads or within Swift `Task`s to prevent blocking the main thread and freezing the user interface. If you attempt to update UI elements (e.g., `UILabel.text`, `NSImageView.image`) directly from these background contexts without explicitly dispatching back to the main actor, your app will crash with runtime errors (e.g., "UI API called on non-main thread").
    *   **Solution:** Always ensure UI updates are performed on the main actor. For properties or methods that directly interact with UIKit/AppKit, mark them with `@MainActor`. For ad-hoc updates from a background `Task`, wrap the UI-related code in an `await MainActor.run { ... }` block.
        