
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CoreData

/// Represents a result from either the permanent or ephemeral store.
struct SearchResult: Sendable {
    let text: String
    let isEphemeral: Bool
}

actor EphemeralMemoryManager {
    private let ephemeralContainer: NSPersistentContainer
    private(set) var isSessionActive: Bool = false

    init(ephemeralContainer: NSPersistentContainer) {
        self.ephemeralContainer = ephemeralContainer
    }

    func startSession() {
        isSessionActive = true
        print("Session Started: Ephemeral Mode Active.")
    }

    func saveEphemeralNote(text: String) async throws {
        guard isSessionActive else { throw NSError(domain: "SessionInactive", code: 0) }
        
        let context = ephemeralContainer.newBackgroundContext()
        try await context.perform {
            let note = NSManagedObject(entity: NSEntityDescription.entity(forEntityName: "EphemeralNote", in: context)!, insertInto: context)
            note.setValue(text, forKey: "text")
            note.setValue(Date(), forKey: "timestamp")
            try context.save()
        }
    }

    func endSessionAndPurge() async throws {
        isSessionActive = false
        let description = ephemeralContainer.persistentStoreDescriptions.first
        
        // Hard wipe: Delete the actual SQLite file to prevent forensic recovery
        if let url = description?.url {
            try FileManager.default.removeItem(at: url)
            // Re-initialize the store
            try ephemeralContainer.setupPersistentStores()
        }
        print("💥 Ephemeral Store Wiped and Re-initialized.")
    }
}

struct UnifiedSearchService {
    let permanentContainer: NSPersistentContainer
    let ephemeralManager: EphemeralMemoryManager

    func search(query: String) async throws -> [SearchResult] {
        // Use TaskGroup to search both stores concurrently
        return try await withThrowingTaskGroup(of: [SearchResult].self) { group in
            
            // Task 1: Search Permanent Store
            group.addTask {
                let context = permanentContainer.viewContext
                // (Simulated fetch)
                return [SearchResult(text: "Permanent Note Found", isEphemeral: false)]
            }
            
            // Task 2: Search Ephemeral Store (Only if session is active)
            group.addTask {
                let isActive = await ephemeralManager.isSessionActive
                guard isActive else { return [] }
                
                // (Simulated fetch from ephemeralContainer)
                return [SearchResult(text: "Ephemeral Session Note", isEphemeral: true)]
            }
            
            var allResults: [SearchResult] = []
            for try await results in group {
                allResults.append(contentsOf: results)
            }
            
            return allResults.sorted { $0.text < $1.text }
        }
    }
}

// MARK: - Setup Logic (Conceptual)
/*
 let permanentDesc = NSPersistentStoreDescription(url: permanentURL)
 permanentDesc.cloudKitContainerOptions = NSPersistentCloudKitContainerOptions(containerIdentifier: "com.zenith.journal")

 let ephemeralDesc = NSPersistentStoreDescription(url: ephemeralURL)
 ephemeralDesc.cloudKitContainerOptions = nil // CRITICAL: No CloudKit
 ephemeralDesc.setOption(FileProtectionType.completeUnlessOpen as NSObject, 
                         forKey: NSPersistentStoreFileProtectionKey) // Security Hardening
*/
