
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

enum ModerationResult: Equatable {
    case safe
    case flagged(reason: String)
    case blocked(severity: Int)
}

enum ModerationError: Error {
    case networkFailure
    case taskCancelled
}

actor ModerationEngine {
    private var currentModerationTask: Task<ModerationResult, Error>?
    
    // Tier 1: Local Heuristics (Regex)
    private func checkLocal(text: String) -> Bool {
        let prohibitedPatterns = ["bomb", "attack", "kill"]
        return prohibitedPatterns.contains { text.lowercased().contains($0) }
    }
    
    // Tier 2: Local Semantic Analysis (Simulated NLP)
    private func checkSemantic(text: String) async throws -> Bool {
        // Simulate on-device NLP latency
        try await Task.sleep(for: .milliseconds(200))
        try Task.checkCancellation()
        
        // Mock logic: if text is very long, flag it as "potentially overwhelming"
        return text.count > 500 
    }
    
    // Tier 3: Cloud Semantic Moderation (Simulated API)
    private func checkCloud(text: String) async throws -> ModerationResult {
        // Simulate network latency
        try await Task.sleep(for: .seconds(1))
        try Task.checkCancellation()
        
        if text.contains("malicious") {
            return .blocked(severity: 10)
        } else if text.contains("suspicious") {
            return .flagged(reason: "Unusual intent detected")
        }
        
        return .safe
    }

    /// The orchestrator: Manages the lifecycle and debounces input
    func moderate(text: String) async throws -> ModerationResult {
        // 1. Cancel any existing moderation task (Debouncing/Race Condition Prevention)
        currentModerationTask?.cancel()
        
        // 2. Create a new task for the current input
        let newTask = Task<ModerationResult, Error> {
            // Tier 1: Immediate Local Check
            if checkLocal(text: text) {
                return .blocked(severity: 10)
            }
            
            // Tier 2: Semantic Check
            let isSemanticViolation = try await checkSemantic(text: text)
            if isSemanticViolation {
                return .flagged(reason: "Semantic complexity too high")
            }
            
            // Tier 3: Cloud Check
            return try await checkCloud(text: text)
        }
        
        currentModerationTask = newTask
        
        // 3. Await the result, but handle cancellation gracefully
        do {
            return try await newTask.value
        } catch is CancellationError {
            // If the task was cancelled because the user kept typing, 
            // we don't want to throw an error to the UI, just ignore it.
            throw ModerationError.taskCancelled
        } catch {
            throw error
        }
    }
}

// MARK: - Usage Example
@MainActor
class WritingViewModel: ObservableObject {
    private let engine = ModerationEngine()
    @Published var status: String = "Waiting..."
    
    func userDidType(text: String) {
        Task {
            do {
                let result = try await engine.moderate(text: text)
                self.status = "Result: \(result)"
            } catch ModerationError.taskCancelled {
                // Silently ignore cancellation during debouncing
            } catch {
                self.status = "Error: \(error.localizedDescription)"
            }
        }
    }
}
