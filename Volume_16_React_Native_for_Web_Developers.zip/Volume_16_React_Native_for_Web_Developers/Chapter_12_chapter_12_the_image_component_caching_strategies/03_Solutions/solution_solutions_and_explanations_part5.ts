/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/Gallery.tsx
import React, { useState, useEffect, useRef } from 'react';
import { FlatList, View, Image, Text, StyleSheet, ActivityIndicator, Alert } from 'react-native';

// Mock Data Generator
const generateImages = (count: number, startIndex: number) => {
    return Array.from({ length: count }).map((_, i) => ({
        id: `${startIndex + i}`,
        uri: `https://picsum.photos/400/400?random=${startIndex + i}`,
    }));
};

export const Gallery = () => {
    const [data, setData] = useState<any[]>(generateImages(10, 0));
    const [loading, setLoading] = useState(false);
    
    // Ref to track currently rendered items count
    const renderedCountRef = useRef(0);

    // 4. Memory Warning (Simulated)
    // This effect monitors the number of items currently visible in the viewport (or slightly more due to buffering)
    // If it exceeds our threshold (20), we log a warning.
    useEffect(() => {
        if (renderedCountRef.current > 20) {
            console.warn(
                `MEMORY WARNING: Rendered item count (${renderedCountRef.current}) exceeds threshold (20). ` +
                `Consider reducing 'maxToRenderPerBatch' or implementing more aggressive unmounting.`
            );
            // In a production app, you might trigger a garbage collection call or force a layout recalculation here.
        }
    }, [data]); // Re-run when data changes to check the batch size

    // 3. Infinite Scroll Simulation
    const loadMore = () => {
        if (loading) return;
        setLoading(true);
        
        // Simulate network delay
        setTimeout(() => {
            const newImages = generateImages(10, data.length);
            setData(prev => [...prev, ...newImages]);
            setLoading(false);
        }, 1000);
    };

    // Render Item
    const renderItem = ({ item }: { item: any }) => (
        <View style={styles.itemContainer}>
            <Image source={{ uri: item.uri }} style={styles.image} />
            <Text style={styles.idText}>ID: {item.id}</Text>
        </View>
    );

    // Key Extractor
    const keyExtractor = (item: any) => item.id;

    // Viewability Config (Optional but good for performance)
    const onViewableItemsChanged = useRef(({ viewableItems }: any) => {
        // Update the ref with the count of currently viewable items
        // Note: FlatList renders a buffer beyond the view, but viewableItems is strictly what's on screen.
        // However, for memory warnings, we often care about what is mounted.
        // We will simulate the warning based on the 'windowSize' prop logic below.
        renderedCountRef.current = viewableItems.length;
    }).current;

    return (
        <View style={styles.container}>
            <FlatList
                data={data}
                renderItem={renderItem}
                keyExtractor={keyExtractor}
                
                // 2. Window Size Configuration
                // windowSize={3} means it keeps 3 screens worth of content mounted (1 screen forward, 1 screen backward).
                // This is the primary mechanism for memory management in lists.
                windowSize={3} 
                
                // 1. Virtualization: maxToRenderPerBatch
                // This controls how many items are rendered per frame. Lower = less UI thread blocking.
                maxToRenderPerBatch={5}
                
                // 3. Infinite Scroll Handlers
                onEndReached={loadMore}
                onEndReachedThreshold={0.5}
                
                // 4. Viewability Tracking
                viewabilityConfig={{ itemVisiblePercentThreshold: 50 }}
                onViewableItemsChanged={onViewableItemsChanged}
                
                // Loading Indicator
                ListFooterComponent={() => (
                    loading ? <ActivityIndicator size="large" style={styles.loader} /> : null
                )}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#fff' },
    itemContainer: { 
        height: 250, 
        marginVertical: 8, 
        marginHorizontal: 16, 
        backgroundColor: '#eee', 
        borderRadius: 8, 
        overflow: 'hidden' 
    },
    image: { width: '100%', height: '100%' },
    idText: { 
        position: 'absolute', 
        bottom: 10, 
        left: 10, 
        backgroundColor: 'rgba(0,0,0,0.5)', 
        color: 'white', 
        padding: 4, 
        borderRadius: 4 
    },
    loader: { paddingVertical: 20 }
});
