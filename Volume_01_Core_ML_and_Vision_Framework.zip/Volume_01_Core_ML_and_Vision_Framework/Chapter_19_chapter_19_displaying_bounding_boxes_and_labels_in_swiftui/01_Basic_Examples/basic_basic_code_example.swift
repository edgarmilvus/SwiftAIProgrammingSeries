
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import CoreGraphics // For CGRect

// MARK: - 1. Data Model for Detected Objects

/// Represents a single detected object with its label and bounding box.
/// The `boundingBox` is expected to be in normalized coordinates (0.0 to 1.0),
/// where (0,0) is the top-left and (1,1) is the bottom-right of the original image.
struct DetectedObject: Identifiable {
    let id = UUID()
    let label: String
    let boundingBox: CGRect // Normalized CGRect (0.0 to 1.0)
    let confidence: Float? // Optional confidence score
}

// MARK: - 2. SwiftUI View for Drawing Overlays

/// A SwiftUI view responsible for drawing bounding boxes and labels on top of an image.
struct BoundingBoxOverlayView: View {
    let detectedObjects: [DetectedObject]
    let imageSize: CGSize // The *original* size of the image in pixels
    let displayedImageRect: CGRect // The actual rectangle where the image is displayed within the view

    var body: some View {
        // Use a GeometryReader to get the available space for drawing.
        // This is crucial for correctly scaling the bounding boxes.
        GeometryReader { geometry in
            ZStack(alignment: .topLeading) {
                // Iterate through each detected object and draw its bounding box and label
                ForEach(detectedObjects) { object in
                    // Convert normalized bounding box to SwiftUI view coordinates
                    let scaledRect = convertNormalizedRectToViewRect(
                        normalizedRect: object.boundingBox,
                        imageSize: imageSize,
                        displayedImageRect: displayedImageRect,
                        viewSize: geometry.size
                    )

                    // Draw the bounding box rectangle
                    Rectangle()
                        .stroke(Color.red, lineWidth: 2)
                        .frame(width: scaledRect.width, height: scaledRect.height)
                        .offset(x: scaledRect.minX, y: scaledRect.minY)

                    // Draw the label text
                    Text(object.label)
                        .font(.caption)
                        .foregroundColor(.white)
                        .padding(4)
                        .background(Color.red)
                        .cornerRadius(5)
                        .offset(x: scaledRect.minX, y: scaledRect.minY - 20) // Position above the box
                }
            }
        }
    }

    /// Converts a normalized CGRect (0.0 to 1.0) from an ML model
    /// to a CGRect suitable for drawing within a SwiftUI view.
    ///
    /// - Parameters:
    ///   - normalizedRect: The bounding box in normalized coordinates (0.0 to 1.0).
    ///   - imageSize: The original pixel dimensions of the image the ML model processed.
    ///   - displayedImageRect: The actual `CGRect` where the image is rendered *within* the SwiftUI view.
    ///                         This accounts for scaling (e.g., `scaledToFit`) and aspect ratio.
    ///   - viewSize: The size of the `GeometryReader` (i.e., the available drawing area).
    /// - Returns: A `CGRect` in the SwiftUI view's coordinate system.
    private func convertNormalizedRectToViewRect(
        normalizedRect: CGRect,
        imageSize: CGSize,
        displayedImageRect: CGRect,
        viewSize: CGSize
    ) -> CGRect {
        // Step 1: Invert Y-axis for Vision/Core ML conventions if necessary.
        // Vision's origin (0,0) is bottom-left, SwiftUI's is top-left.
        // For Core ML bounding boxes directly, (0,0) is often top-left.
        // Assuming normalizedRect.minY is from the top for this example.
        // If Vision framework is used, you might need:
        // let visionRect = CGRect(x: normalizedRect.minX,
        //                         y: 1.0 - normalizedRect.minY - normalizedRect.height,
        //                         width: normalizedRect.width,
        //                         height: normalizedRect.height)
        // For simplicity here, we assume normalizedRect.minY is already from the top.
        let rectFromTop = normalizedRect

        // Step 2: Scale the normalized rectangle to the original image's pixel dimensions.
        let pixelRect = CGRect(
            x: rectFromTop.minX * imageSize.width,
            y: rectFromTop.minY * imageSize.height,
            width: rectFromTop.width * imageSize.width,
            height: rectFromTop.height * imageSize.height
        )

        // Step 3: Calculate the scaling factor applied to the image when displayed.
        // This is the ratio of the displayed image's width/height to its original width/height.
        let scaleX = displayedImageRect.width / imageSize.width
        let scaleY = displayedImageRect.height / imageSize.height

        // Step 4: Apply the scaling factor and offset based on the displayed image's position.
        let finalRect = CGRect(
            x: displayedImageRect.minX + pixelRect.minX * scaleX,
            y: displayedImageRect.minY + pixelRect.minY * scaleY,
            width: pixelRect.width * scaleX,
            height: pixelRect.height * scaleY
        )

        return finalRect
    }
}

// MARK: - 3. Main Content View

/// The main view that displays the image and overlays the detected objects.
struct ContentView: View {
    // Sample image name (ensure "sample_image" is in your Assets.xcassets)
    let imageName = "sample_image"
    let originalImageSize = CGSize(width: 800, height: 600) // Original pixel dimensions of "sample_image"

    // Sample detected objects (normalized coordinates)
    let detectedObjects: [DetectedObject] = [
        DetectedObject(label: "Cat", boundingBox: CGRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4)),
        DetectedObject(label: "Dog", boundingBox: CGRect(x: 0.5, y: 0.6, width: 0.25, height: 0.3)),
        DetectedObject(label: "Ball", boundingBox: CGRect(x: 0.7, y: 0.1, width: 0.1, height: 0.1))
    ]

    @State private var displayedImageRect: CGRect = .zero // To store the actual frame of the displayed image

    var body: some View {
        VStack {
            Text("Image Annotation Viewer")
                .font(.title)
                .padding()

            // ZStack to layer the image and the bounding box overlay
            ZStack {
                // Background to visualize the `GeometryReader` space
                Color.clear

                // The base image. Use `GeometryReader` to determine its actual displayed size.
                Image(imageName)
                    .resizable()
                    .scaledToFit() // Important: This determines how the image scales
                    .background(
                        // Use another GeometryReader to capture the frame of the *scaled* image
                        GeometryReader { proxy in
                            Color.clear.onAppear {
                                // Store the frame of the image relative to its parent ZStack
                                displayedImageRect = proxy.frame(in: .local)
                            }
                            .onChange(of: proxy.size) { newSize in
                                // Update if the size changes (e.g., device rotation)
                                displayedImageRect = proxy.frame(in: .local)
                            }
                        }
                    )

                // Overlay the bounding boxes and labels
                // Only show if displayedImageRect has been determined
                if displayedImageRect != .zero {
                    BoundingBoxOverlayView(
                        detectedObjects: detectedObjects,
                        imageSize: originalImageSize,
                        displayedImageRect: displayedImageRect
                    )
                }
            }
            .padding()
            Spacer()
        }
    }
}

// MARK: - Preview Provider

#Preview {
    ContentView()
}
