
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import Speech
import AVFoundation

@available(iOS 18.0, *)
class NotesSecureDictationViewController: UIViewController, SFSpeechRecognizerDelegate {

    // MARK: - UI Elements
    private let secureModeBanner: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.systemGreen.withAlphaComponent(0.2)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true // Hidden by default
        return view
    }()

    private let secureModeLabel: UILabel = {
        let label = UILabel()
        label.text = "🔒 Secure Dictation Mode (On-Device)"
        label.font = .systemFont(ofSize: 15, weight: .semibold)
        label.textColor = .systemGreen
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let secureModeInfoLabel: UILabel = {
        let label = UILabel()
        label.text = "Your voice data stays on your device. May have slightly different accuracy or language support."
        label.font = .systemFont(ofSize: 13)
        label.textColor = .systemGreen
        label.textAlignment = .center
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let secureDictationToggle: UISwitch = {
        let sw = UISwitch()
        sw.translatesAutoresizingMaskIntoConstraints = false
        return sw
    }()

    private let toggleLabel: UILabel = {
        let label = UILabel()
        label.text = "Secure Dictation"
        label.font = .systemFont(ofSize: 17)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let textView: UITextView = {
        let tv = UITextView()
        tv.font = .systemFont(ofSize: 18)
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8.0
        tv.translatesAutoresizingMaskIntoConstraints = false
        return tv
    }()

    private let dictationButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Dictation", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 20, weight: .bold)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Ready"
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - Speech Recognition Properties
    private var currentSpeechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    private var isDictating: Bool = false
    private var currentLocale: Locale = Locale.current

    private var isSecureDictationModeActive: Bool = false {
        didSet {
            updateSecureModeUI()
            // If mode changes while actively dictating, restart recognition
            if oldValue != isSecureDictationModeActive && isDictating {
                stopDictation()
                startDictation() // Restart with new mode
            }
        }
    }

    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        requestSpeechAuthorization()
        updateSecureModeUI() // Initial UI setup
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        stopDictation() // Clean up resources
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Secure Notes Dictation"

        view.addSubview(secureModeBanner)
        secureModeBanner.addSubview(secureModeLabel)
        secureModeBanner.addSubview(secureModeInfoLabel)
        
        let toggleStack = UIStackView(arrangedSubviews: [toggleLabel, secureDictationToggle])
        toggleStack.axis = .horizontal
        toggleStack.alignment = .center
        toggleStack.spacing = 10
        toggleStack.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(toggleStack)
        view.addSubview(textView)
        view.addSubview(dictationButton)
        view.addSubview(statusLabel)

        secureDictationToggle.addTarget(self, action: #selector(secureDictationToggleChanged), for: .valueChanged)
        dictationButton.addTarget(self, action: #selector(dictationButtonTapped), for: .touchUpInside)

        NSLayoutConstraint.activate([
            secureModeBanner.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            secureModeBanner.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            secureModeBanner.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            secureModeLabel.topAnchor.constraint(equalTo: secureModeBanner.topAnchor, constant: 10),
            secureModeLabel.leadingAnchor.constraint(equalTo: secureModeBanner.leadingAnchor, constant: 10),
            secureModeLabel.trailingAnchor.constraint(equalTo: secureModeBanner.trailingAnchor, constant: -10),
            
            secureModeInfoLabel.topAnchor.constraint(equalTo: secureModeLabel.bottomAnchor, constant: 5),
            secureModeInfoLabel.leadingAnchor.constraint(equalTo: secureModeBanner.leadingAnchor, constant: 10),
            secureModeInfoLabel.trailingAnchor.constraint(equalTo: secureModeBanner.trailingAnchor, constant: -10),
            secureModeInfoLabel.bottomAnchor.constraint(equalTo: secureModeBanner.bottomAnchor, constant: -10),

            toggleStack.topAnchor.constraint(equalTo: secureModeBanner.bottomAnchor, constant: 20),
            toggleStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            toggleStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            textView.topAnchor.constraint(equalTo: toggleStack.bottomAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 250),

            dictationButton.topAnchor.constraint(equalTo: textView.bottomAnchor, constant: 30),
            dictationButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            dictationButton.widthAnchor.constraint(equalToConstant: 200),
            dictationButton.heightAnchor.constraint(equalToConstant: 50),
            
            statusLabel.topAnchor.constraint(equalTo: dictationButton.bottomAnchor, constant: 20),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 30)
        ])
    }
    
    // MARK: - Authorization
    private func requestSpeechAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation { [weak self] in
                guard let self = self else { return }
                switch authStatus {
                case .authorized:
                    self.dictationButton.isEnabled = true
                    self.statusLabel.text = "Ready to dictate."
                case .denied, .restricted, .notDetermined:
                    self.dictationButton.isEnabled = false
                    self.secureDictationToggle.isEnabled = false
                    self.statusLabel.text = "Speech Authorization Required"
                @unknown default:
                    self.dictationButton.isEnabled = false
                    self.secureDictationToggle.isEnabled = false
                    self.statusLabel.text = "Unknown Authorization Status"
                }
            }
        }
    }

    // MARK: - Actions
    @objc private func secureDictationToggleChanged(_ sender: UISwitch) {
        let desiredState = sender.isOn
        
        if desiredState && !SFSpeechRecognizer.onDeviceSupportedLocales.contains(currentLocale) {
            // Cannot activate secure mode if on-device is not supported for this locale
            let alert = UIAlertController(title: "On-Device Dictation Not Available",
                                          message: "Your current language (\(currentLocale.localizedString(forIdentifier: currentLocale.identifier) ?? currentLocale.identifier)) does not support on-device dictation. Please switch to a supported language or use standard dictation.",
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                sender.isOn = false // Revert toggle state
            })
            present(alert, animated: true)
            return
        }
        isSecureDictationModeActive = desiredState
    }

    @objc private func dictationButtonTapped() {
        if isDictating {
            stopDictation()
            dictationButton.setTitle("Start Dictation", for: .normal)
            statusLabel.text = "Ready."
        } else {
            startDictation()
            dictationButton.setTitle("Stop Dictation", for: .normal)
            statusLabel.text = "Listening..."
        }
    }

    private func startDictation() {
        // Stop any existing task first
        stopDictation()

        currentSpeechRecognizer = SFSpeechRecognizer(locale: currentLocale, onDevice: isSecureDictationModeActive)
        currentSpeechRecognizer?.delegate = self

        guard let recognizer = currentSpeechRecognizer else {
            print("Failed to create speech recognizer.")
            statusLabel.text = "Error: Recognizer creation failed."
            return
        }
        
        // Ensure recognizer is available
        guard recognizer.isAvailable else {
            print("Speech recognizer is not available.")
            statusLabel.text = "Error: Recognizer unavailable."
            return
        }

        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

            let inputNode = audioEngine.inputNode
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = recognitionRequest else { fatalError("Unable to create SFSpeechAudioBufferRecognitionRequest") }
            recognitionRequest.shouldReportPartialResults = true

            recognitionTask = recognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
                guard let self = self else { return }
                OperationQueue.main.addOperation { // All UI updates on main thread
                    if let result = result {
                        self.textView.text = result.bestTranscription.formattedString
                    }
                    if error != nil || (result?.isFinal ?? false) {
                        self.stopDictation() // Stop on error or final result
                        self.dictationButton.setTitle("Start Dictation", for: .normal)
                        if let error = error {
                            print("Dictation error: \(error.localizedDescription)")
                            self.statusLabel.text = "Error: \(error.localizedDescription)"
                        } else {
                            self.statusLabel.text = "Dictation complete."
                        }
                    }
                }
            }

            let recordingFormat = inputNode.outputFormat(forBus: 0)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer: AVAudioPCMBuffer, when: AVAudioTime) in
                self.recognitionRequest?.append(buffer)
            }

            audioEngine.prepare()
            try audioEngine.start()
            isDictating = true
        } catch {
            print("Error starting dictation: \(error.localizedDescription)")
            stopDictation()
            dictationButton.setTitle("Start Dictation", for: .normal)
            statusLabel.text = "Error starting dictation: \(error.localizedDescription)"
        }
    }

    private func stopDictation() {
        guard isDictating else { return }
        
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest = nil
        currentSpeechRecognizer = nil
        isDictating = false
    }

    private func updateSecureModeUI() {
        secureDictationToggle.isOn = isSecureDictationModeActive
        secureModeBanner.isHidden = !isSecureDictationModeActive
        if isSecureDictationModeActive {
            secureModeInfoLabel.text = "Your voice data stays on your device. May have slightly different accuracy or language support."
        } else {
            secureModeInfoLabel.text = "" // Clear info when not active
        }
    }

    // MARK: - SFSpeechRecognizerDelegate
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        OperationQueue.main.addOperation { [weak self] in
            guard let self = self else { return }
            if available {
                self.dictationButton.isEnabled = true
                self.secureDictationToggle.isEnabled = true
                self.statusLabel.text = "Ready."
            } else {
                self.dictationButton.isEnabled = false
                self.secureDictationToggle.isEnabled = false
                self.statusLabel.text = "Recognizer Unavailable."
                self.stopDictation()
            }
        }
    }
}
