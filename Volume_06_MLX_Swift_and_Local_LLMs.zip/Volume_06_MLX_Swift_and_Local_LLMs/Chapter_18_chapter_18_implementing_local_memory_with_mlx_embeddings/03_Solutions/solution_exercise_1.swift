
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import MLX
import MLXNN // For MLXNN.Module
import Foundation // For UUID, Date

// MARK: - Utility for Embedding Model Abstraction
// This class simulates loading an embedding model.
// In a real application, you would load a pre-trained model like 'bge-small-en-v1.5'
// using MLX's model loading utilities (e.g., from a .safetensors file)
// and instantiate a custom MLXNN.Module that implements its architecture.
// For these exercises, we abstract that complexity to focus on embedding usage.
@available(iOS 18.0, macOS 15.0, *)
class EmbeddingModelLoader {
    // A simplified MLXNN.Module that acts as a placeholder for a real embedding model.
    // Its `callAsFunction` will return a random MLXArray of the specified dimension,
    // simulating the output of an actual embedding model.
    //
    // MODIFICATION FOR EXERCISES:
    // This version is adjusted to infer the batch size from the input MLXArray's
    // first dimension, allowing it to simulate batch processing more realistically.
    class DummyEmbeddingModel: MLXNN.Module {
        let embeddingDimension: Int
        
        init(embeddingDimension: Int) {
            self.embeddingDimension = embeddingDimension
            super.init() // Initialize MLXNN.Module
        }
        
        override func callAsFunction(_ inputs: MLXArray) -> MLXArray {
            // In a real model, `inputs` would be token IDs, and this would be a
            // complex transformer forward pass producing contextual embeddings.
            // Here, we just return a random MLXArray to simulate an embedding vector.
            //
            // We infer the batch size from the input's first dimension.
            // If the input is 1D (e.g., [sequence_length]), we assume a batch size of 1.
            let batchSize = inputs.shape.first ?? 1
            let outputShape = [batchSize, embeddingDimension]
            
            // Generate random uniform embeddings.
            let embedding = MLXArray.randomUniform(low: -1, high: 1, outputShape, dtype: .float32)
            
            // MLX uses lazy evaluation. The actual computation (random generation here)
            // won't happen until the `embedding` MLXArray is explicitly evaluated
            // (e.g., printed, converted to Swift Array, or used in a subsequent operation
            // that forces computation).
            return embedding
        }
    }
    
    // Loads and returns an instance of our dummy embedding model.
    static func loadSentenceTransformerModel(name: String = "bge-small-en-v1.5", embeddingDimension: Int = 384) throws -> MLXNN.Module {
        print("Simulating loading of embedding model '\(name)' with output dimension \(embeddingDimension).")
        // The actual model loading (e.g., from a .safetensors file, tokenization setup)
        // would occur here. For these exercises, we use our dummy.
        return DummyEmbeddingModel(embeddingDimension: embeddingDimension)
    }
}

// MARK: - Utility for Cosine Similarity Calculation
// Cosine similarity is a common metric for comparing the semantic similarity of embeddings.
// It measures the cosine of the angle between two vectors.
@available(iOS 18.0, macOS 15.0, *)
extension MLXArray {
    /// Calculates the cosine similarity between two MLXArrays.
    ///
    /// - Parameters:
    ///   - a: The first MLXArray (e.g., query embedding). Expected shape: `[D]` or `[1, D]`.
    ///   - b: The second MLXArray (e.g., document embeddings). Expected shape: `[D]` or `[N, D]`.
    /// - Returns: An MLXArray containing the similarity score(s).
    ///            If `a` is `[1, D]` and `b` is `[N, D]`, returns `[1, N]`.
    ///            If `a` is `[D]` and `b` is `[D]`, returns `[1]`.
    static func cosineSimilarity(a: MLXArray, b: MLXArray) -> MLXArray {
        // Ensure inputs are at least 2D for consistent normalization and matmul.
        // If a vector is 1D (e.g., `[D]`), reshape it to `[1, D]`.
        let a_reshaped = a.shape.count == 1 ? a.reshaped([1, a.shape[0]]) : a
        let b_reshaped = b.shape.count == 1 ? b.reshaped([1, b.shape[0]]) : b
        
        // Normalize vectors to unit length.
        // MLX.linalg.norm calculates the L2 norm.
        // `axis: -1` means normalize along the last dimension (the embedding dimension).
        // `keepdims: true` ensures the output shape allows for broadcasting (e.g., `[N, 1]`).
        let normA = MLX.linalg.norm(a_reshaped, axis: -1, keepdims: true)
        let normB = MLX.linalg.norm(b_reshaped, axis: -1, keepdims: true)
        
        // Add a small epsilon to avoid division by zero for zero vectors.
        let normalizedA = a_reshaped / (normA + 1e-8)
        let normalizedB = b_reshaped / (normB + 1e-8)
        
        // Calculate dot product.
        // For query `[1, D]` and corpus `[N, D]`, we want `[1, D] @ [D, N]`,
        // which gives `[1, N]` similarity scores.
        return MLX.matmul(normalizedA, normalizedB.transposed())
    }
}

// MARK: - Placeholder for text tokenization
// In a real application, you'd use a tokenizer (e.g., BPE, WordPiece)
// to convert text into numerical token IDs, which are then fed to the model.
// For these exercises, we'll just create a dummy MLXArray as input.
@available(iOS 18.0, macOS 15.0, *)
extension String {
    /// Simulates tokenization and converts a string into a dummy MLXArray input
    /// suitable for our `DummyEmbeddingModel`.
    func toDummyMLXInput() -> MLXArray {
        // The actual content of this MLXArray doesn't matter for DummyEmbeddingModel,
        // only its shape. We assume a sequence length of 1 for simplicity.
        return MLXArray.ones([1, 1], dtype: .int32)
    }
    
    /// Simulates tokenization and converts an array of strings into a dummy MLXArray input
    /// suitable for our `DummyEmbeddingModel` for batch processing.
    static func toDummyMLXInput(batch: [String]) -> MLXArray {
        // The actual content of this MLXArray doesn't matter for DummyEmbeddingModel,
        // only its shape. We assume a sequence length of 1 for simplicity.
        return MLXArray.ones([batch.count, 1], dtype: .int32)
    }
}

