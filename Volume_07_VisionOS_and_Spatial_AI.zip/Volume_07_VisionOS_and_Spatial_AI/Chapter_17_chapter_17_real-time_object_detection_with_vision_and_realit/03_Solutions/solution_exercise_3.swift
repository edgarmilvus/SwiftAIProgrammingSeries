
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import RealityKit
import Vision
import CoreML

struct NutritionalData {
    let name: String
    let calories: Int
    let protein: String
}

class NutriScanService {
    // Simulated database
    private let database: [String: NutritionalData] = [
        "Apple": NutritionalData(name: "Granny Smith", calories: 95, protein: "0.5g"),
        "Protein Bar": NutritionalData(name: "PowerBar", calories: 250, protein: "20g")
    ]
    
    func lookup(_ label: String) -> NutritionalData? {
        return database[label]
    }
}

class NutritionHaloEntity: Entity {
    required init() { super.init() }
    
    init(data: NutritionalData) {
        super.init()
        
        // 1. The 3D Glowing Ring (ModelEntity)
        let mesh = MeshResource.generateTorus(ringRadius: 0.1, thickness: 0.01)
        let material = UnlitMaterial(color: .cyan)
        let ring = ModelEntity(mesh: mesh, materials: [material])
        self.addChild(ring)
        
        // 2. The Text Overlay (ViewAttachment)
        // In visionOS, this would be a ViewAttachmentEntity
        // Here we simulate the logic of attaching data
        print("Displaying: \(data.name) - \(data.calories) kcal")
    }
}

actor NutriScanEngine {
    let service = NutriScanService()
    
    func analyze(observation: VNClassificationObservation) -> (String, NutritionalData?) {
        let topLabel = observation.identifier
        let data = service.lookup(topLabel)
        return (topLabel, data)
    }
}

// Main Loop Integration Logic
@MainActor
func handleDetection(observation: VNClassificationObservation, position: SIMD3<Float>) {
    Task {
        let engine = NutriScanEngine()
        let (label, data) = await engine.analyze(observation: observation)
        
        if let nutritionalData = data {
            let halo = NutritionHaloEntity(data: nutritionalicalData)
            let anchor = AnchorEntity(world: position)
            anchor.addChild(halo)
            // Add to scene...
        }
    }
}
