
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AppKit // Required for NSPasteboard

/// Custom errors specific to the Code Explainer Agent.
enum CodeExplainerAgentError: Error, LocalizedError {
    case noCodeInClipboard
    case ollamaClientError(OllamaClientError)
    case unknownError(Error)

    var errorDescription: String? {
        switch self {
        case .noCodeInClipboard: return "No code snippet found in the clipboard. Please copy some code."
        case .ollamaClientError(let clientError): return clientError.localizedDescription
        case .unknownError(let error): return "An unexpected error occurred: \(error.localizedDescription)"
        }
    }
}

/// The core logic for the Code Explainer Menu Bar Agent.
/// It orchestrates fetching code, sending it to Ollama, and managing the explanation state.
@MainActor // Ensures all state changes and UI interactions happen on the main thread.
class CodeExplainerAgent: ObservableObject {
    @Published var explanationText: String = "Copy some code and click 'Explain'!"
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var selectedModel: String = "llama2" // Default LLM model

    private let ollamaService: OllamaService
    private let pasteboard: NSPasteboard

    /// Initializes the Code Explainer Agent.
    /// - Parameters:
    ///   - ollamaService: An instance conforming to `OllamaService` (e.g., `OllamaAPIClient`).
    ///   - pasteboard: The `NSPasteboard` instance to use for clipboard operations. Defaults to `.general`.
    init(ollamaService: OllamaService, pasteboard: NSPasteboard = .general) {
        self.ollamaService = ollamaService
        self.pasteboard = pasteboard
    }

    /// Fetches the current content of the clipboard.
    /// - Returns: The string content of the clipboard, or `nil` if no string is found.
    private func getCodeFromClipboard() -> String? {
        pasteboard.string(forType: .string)
    }

    /// Explains a code snippet using the configured Ollama LLM.
    /// This method fetches code from the clipboard, sends it to Ollama, and updates the UI state.
    func explainCodeFromClipboard() async {
        isLoading = true
        errorMessage = nil
        explanationText = "Thinking..."

        do {
            guard let codeSnippet = getCodeFromClipboard(), !codeSnippet.isEmpty else {
                throw CodeExplainerAgentError.noCodeInClipboard
            }

            let fullPrompt = """
            Explain the following Swift code snippet in detail, focusing on its purpose, how it works,
            and any important Swift concurrency or Apple framework patterns it demonstrates.
            Keep the explanation concise but comprehensive.

            