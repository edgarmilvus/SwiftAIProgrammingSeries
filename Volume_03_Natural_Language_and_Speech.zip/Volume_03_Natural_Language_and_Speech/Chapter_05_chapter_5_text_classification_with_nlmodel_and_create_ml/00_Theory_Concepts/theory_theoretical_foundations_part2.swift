
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, visionOS 2.0, *)
class AppViewModel: ObservableObject { // Using ObservableObject for broader compatibility
    private let classifier: SentimentClassifier // Assume SentimentClassifier from above
    @Published var inputText: String = ""
    @Published var predictedSentiment: String = "Neutral"
    @Published var isLoading: Bool = false

    init() {
        do {
            self.classifier = try SentimentClassifier()
        } catch {
            fatalError("Failed to load sentiment classifier: \(error)")
        }
    }

    @MainActor // Ensure UI updates happen on the main actor
    func analyzeSentiment() {
        guard !inputText.isEmpty else {
            predictedSentiment = "Neutral"; return
        }
        isLoading = true

        Task { // Start a new concurrent task
            do {
                // The actual inference happens in a background context (via Task.detached in classifier)
                // The await here ensures the UI update only happens after inference is complete.
                let result = try await classifier.classifySentiment(for: inputText)
                await MainActor.run { // Explicitly jump back to MainActor for UI update
                    self.predictedSentiment = result
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.predictedSentiment = "Error: \(error.localizedDescription)"
                    self.isLoading = false
                }
            }
        }
    }
}
