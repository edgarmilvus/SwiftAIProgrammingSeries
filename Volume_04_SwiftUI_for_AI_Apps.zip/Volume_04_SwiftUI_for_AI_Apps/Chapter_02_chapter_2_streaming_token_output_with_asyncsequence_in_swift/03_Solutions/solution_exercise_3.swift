
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import Foundation

// MARK: - Custom Error for Markdown Stream

enum MarkdownStreamError: Error, LocalizedError {
    case generationFailed(String)

    var errorDescription: String? {
        switch self {
        case .generationFailed(let message):
            return "Markdown generation failed: \(message)"
        }
    }
}

// MARK: - Markdown-Aware AsyncSequence

struct MarkdownTokenStream: AsyncSequence {
    typealias Element = String
    private let markdownText: String
    private let simulateError: Bool
    private let errorAfterTokens: Int

    init(markdownText: String, simulateError: Bool = false, errorAfterTokens: Int = 5) {
        self.markdownText = markdownText
        self.simulateError = simulateError
        self.errorAfterTokens = errorAfterTokens
    }

    func makeAsyncIterator() -> Iterator {
        // A more advanced tokenization for Markdown might involve a lexer.
        // For this exercise, we'll split by spaces and common Markdown symbols.
        let pattern = #"(?:\*\*|\*|#|-|\n|\s|\w+|[^\s\w])+"# // Matches words, spaces, markdown symbols, non-word chars
        let regex = try! NSRegularExpression(pattern: pattern, options: [])
        let range = NSRange(markdownText.startIndex..<markdownText.endIndex, in: markdownText)
        let matches = regex.matches(in: markdownText, options: [], range: range)

        let tokens = matches.compactMap { match in
            Range(match.range, in: markdownText).map { String(markdownText[$0]) }
        }

        return Iterator(tokens: tokens, simulateError: simulateError, errorAfterTokens: errorAfterTokens)
    }

    struct Iterator: AsyncIteratorProtocol {
        private var tokens: [String]
        private let simulateError: Bool
        private let errorAfterTokens: Int
        private var tokensEmitted: Int = 0

        init(tokens: [String], simulateError: Bool, errorAfterTokens: Int) {
            self.tokens = tokens
            self.simulateError = simulateError
            self.errorAfterTokens = errorAfterTokens
        }

        mutating func next() async throws -> String? {
            guard !tokens.isEmpty else { return nil }

            // Simulate error after a certain number of tokens
            if simulateError && tokensEmitted >= errorAfterTokens {
                throw MarkdownStreamError.generationFailed("AI service encountered an unexpected issue.")
            }

            // Varying delays for realism
            let delay = TimeInterval.random(in: 0.05...0.2)
            try await Task.sleep(for: .seconds(delay))

            try Task.checkCancellation()

            tokensEmitted += 1
            return tokens.removeFirst()
        }
    }
}

// MARK: - SwiftUI View

struct MarkdownStreamView: View {
    @State private var userPrompt: String = ""
    @State private var streamedMarkdown: String = ""
    @State private var attributedContent: AttributedString = AttributedString("")
    @State private var errorMessage: String?
    @State private var currentStreamTask: Task<Void, Error>?

    // Example Markdown response including various elements
    private let mockMarkdownResponse = """
    # Project Update: Q3 Review
    
    This is a **critical** review of our progress. We've achieved *significant* milestones, but also faced some challenges.
    
    ## Key Highlights
    - **Feature A:** Launched ahead of schedule.
    - *Feature B:* User adoption exceeding expectations.
    
    ### Next Steps
    1. Prioritize **bug fixes**.
    2. Plan for `Q4` initiatives.
    
    > "Innovation distinguishes between a leader and a follower." - Steve Jobs
    
    Let's aim for a **strong** finish this quarter!
    """

    var body: some View {
        VStack(spacing: 15) {
            TextField("Enter your prompt...", text: $userPrompt)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)

            Button("Start Markdown Stream") {
                startStreamingMarkdown()
            }
            .buttonStyle(.borderedProminent)
            .disabled(currentStreamTask != nil)

            ScrollView {
                Text(attributedContent) // Displays the rendered Markdown
                    .font(.body) // Apply a base font for non-markdown text
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.green.opacity(0.1))
                    .cornerRadius(10)
                    .animation(.easeOut(duration: 0.1), value: attributedContent) // Animate changes
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.gray.opacity(0.05))
            .cornerRadius(10)

            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.horizontal)
            }
        }
        .padding(.vertical)
        .navigationTitle("Smart Markdown Assistant")
        .onDisappear {
            currentStreamTask?.cancel()
        }
    }

    private func startStreamingMarkdown() {
        currentStreamTask?.cancel()
        streamedMarkdown = ""
        attributedContent = AttributedString("")
        errorMessage = nil
        userPrompt = "" // Clear prompt for a new stream

        currentStreamTask = Task {
            // Simulate error randomly for demonstration
            let shouldSimulateError = Bool.random()
            let stream = MarkdownTokenStream(
                markdownText: mockMarkdownResponse,
                simulateError: shouldSimulateError,
                errorAfterTokens: Int.random(in: 5...15)
            )

            do {
                for await token in stream {
                    // Append token and immediately try to parse as Markdown
                    await MainActor.run {
                        self.streamedMarkdown += token
                        // AttributedString(markdown:) is robust and handles partial markdown gracefully.
                        // If parsing fails for some reason, it falls back to plain text.
                        self.attributedContent = (try? AttributedString(markdown: self.streamedMarkdown)) ?? AttributedString(self.streamedMarkdown)
                    }
                    // Yield to allow UI to update and prevent blocking
                    await Task.yield()
                }
                await MainActor.run {
                    self.currentStreamTask = nil // Stream completed successfully
                }
            } catch {
                if Task.isCancelled {
                    print("Markdown stream cancelled.")
                } else {
                    await MainActor.run {
                        self.errorMessage = error.localizedDescription
                    }
                }
                await MainActor.run {
                    self.currentStreamTask = nil // Stream ended due to error or cancellation
                }
            }
        }
    }
}
