/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';
import { View, StyleSheet, Text, Dimensions } from 'react-native';
import { Accelerometer } from 'expo-sensors';

const { width, height } = Dimensions.get('window');
const BALL_SIZE = 20;
const TARGET_SIZE = 100;
// Target is centered
const TARGET_X = (width - 40) / 2 - TARGET_SIZE / 2;
const TARGET_Y = (height / 2) / 2 - TARGET_SIZE / 2;

export default function SteadyHandGame() {
  const [ballPos, setBallPos] = useState({ x: (width - 40) / 2, y: (height / 2) / 2 });
  const [timer, setTimer] = useState(0);
  const [gameStatus, setGameStatus] = useState<'playing' | 'won'>('playing');
  
  // Refs for game loop to avoid stale closures in setInterval
  const ballPosRef = useRef(ballPos);
  const timerRef = useRef(0);
  const isInsideRef = useRef(false);

  useEffect(() => {
    // 1. Setup Accelerometer
    const subscription = Accelerometer.addListener(accelerometerData => {
      const { x, y } = accelerometerData;
      
      // 2. Movement Logic: Invert axes (tilt left moves ball right)
      // Apply sensitivity multiplier (e.g., 10)
      const sensitivity = 10;
      
      // Calculate new position based on current position + tilt
      // We keep the ball within the game area bounds
      let newX = ballPosRef.current.x - (x * sensitivity);
      let newY = ballPosRef.current.y + (y * sensitivity);

      // Boundary checks
      newX = Math.max(0, Math.min(newX, (width - 40) - BALL_SIZE));
      newY = Math.max(0, Math.min(newY, (height / 2) - BALL_SIZE));

      const newPos = { x: newX, y: newY };
      
      // Update State and Refs
      setBallPos(newPos);
      ballPosRef.current = newPos;

      // 3. Collision Detection
      // Check if ball is strictly inside the target zone
      const isInside = 
        newX >= TARGET_X && 
        newX <= TARGET_X + TARGET_SIZE - BALL_SIZE &&
        newY >= TARGET_Y && 
        newY <= TARGET_Y + TARGET_SIZE - BALL_SIZE;

      isInsideRef.current = isInside;
    });

    Accelerometer.setUpdateInterval(50); // Fast updates for smooth movement

    // 4. Game Loop (Timer Logic)
    const gameLoop = setInterval(() => {
      if (gameStatus === 'won') return;

      if (isInsideRef.current) {
        // Increment timer
        timerRef.current += 0.05; // 50ms interval
        setTimer(timerRef.current);

        // Win Condition: 3 seconds
        if (timerRef.current >= 3) {
          setGameStatus('won');
        }
      } else {
        // Reset logic
        if (timerRef.current > 0) {
          timerRef.current = 0;
          setTimer(0);
        }
      }
    }, 50);

    return () => {
      subscription.remove();
      clearInterval(gameLoop);
    };
  }, [gameStatus]);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Steady Hand Challenge</Text>
      <Text style={styles.timer}>Time: {timer.toFixed(2)}s / 3.00s</Text>
      
      <View style={styles.gameArea}>
        {/* Target Zone */}
        <View style={styles.targetZone} />
        
        {/* Ball */}
        <View style={[styles.ball, { left: ballPos.x, top: ballPos.y }]} />
      </View>

      {gameStatus === 'won' && <Text style={styles.winText}>You Win!</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f5f5f5' },
  header: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  timer: { fontSize: 18, marginBottom: 10, color: '#333' },
  gameArea: { 
    width: width - 40, 
    height: height / 2, 
    backgroundColor: '#e0e0e0', 
    position: 'relative',
    borderWidth: 2,
    borderColor: '#333',
    overflow: 'hidden'
  },
  targetZone: { 
    position: 'absolute', 
    width: TARGET_SIZE, 
    height: TARGET_SIZE, 
    borderRadius: TARGET_SIZE / 2, 
    backgroundColor: 'rgba(0, 255, 0, 0.3)', 
    left: TARGET_X, 
    top: TARGET_Y,
    borderWidth: 2,
    borderColor: 'rgba(0, 255, 0, 0.5)'
  },
  ball: { 
    position: 'absolute', 
    width: BALL_SIZE, 
    height: BALL_SIZE, 
    borderRadius: BALL_SIZE / 2, 
    backgroundColor: 'red',
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 2,
  },
  winText: { 
    fontSize: 32, 
    color: 'green', 
    marginTop: 20, 
    fontWeight: 'bold',
    animation: 'fadeIn 0.5s'
  }
});
