
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import CoreData
import CloudKit
import Combine

@available(iOS 17.0, macOS 14.0, *)
@Observable
@MainActor
class SyncMonitor {
    enum SyncStatus: Equatable {
        case synced
        case syncing
        case error(String)
    }
    
    var status: SyncStatus = .synced
    private var cancellables = Set<AnyCancellable>()
    
    init(container: NSPersistentCloudKitContainer) {
        // Observe the specific notification for CloudKit events
        NotificationCenter.default.publisher(for: NSPersistentCloudKitContainer.eventChangedNotification)
            .sink { [weak self] notification in
                self?.handleEventNotification(notification)
            }
            .store(in: &cancellables)
    }
    
    private func handleEventNotification(_ notification: Notification) {
        // Extract the event object from the notification userInfo
        guard let event = notification.userInfo?[NSPersistentCloudKitContainer.eventNotificationUserInfoKey] 
                as? NSPersistentCloudKitContainer.Event else { return }
        
        if event.error != nil {
            status = .error(event.error?.localizedDescription ?? "Unknown Sync Error")
            return
        }
        
        // If an event is currently active (importing or exporting)
        // Note: In a real-world scenario, we'd check if the event is 'active'
        // via the container's internal state, but checking the type is the standard approach.
        if event.type == .import || event.type == .export {
            status = .syncing
        } else {
            // If the event finished and there is no error, we are synced
            status = .synced
        }
    }
}

struct SyncStatusView: View {
    var monitor: SyncMonitor
    
    var body: some View {
        HStack(spacing: 8) {
            statusIcon
            Text(statusText)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(8)
        .background(Capsule().fill(Color(.systemGray6)))
    }
    
    @ViewBuilder
    private var statusIcon: some View {
        switch monitor.status {
        case .synced:
            Image(systemName: "checkmark.icloud")
                .foregroundStyle(.green)
        case .syncing:
            Image(systemName: "arrow.triangle.2.circlepath")
                .foregroundStyle(.yellow)
                .symbolEffect(.variableColor.iterative)
        case .error:
            Image(systemName: "exclamationmark.icloud")
                .foregroundStyle(.red)
        }
    }
    
    private var statusText: String {
        switch monitor.status {
        case .synced: return "All Caught Up"
        case .syncing: return "Syncing..."
        case .error: return "Sync Error"
        }
    }
}
