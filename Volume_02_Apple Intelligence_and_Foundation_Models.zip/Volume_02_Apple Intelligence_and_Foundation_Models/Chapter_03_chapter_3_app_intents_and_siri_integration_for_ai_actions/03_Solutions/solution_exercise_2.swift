
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import AppIntents
import Foundation

// Simplified Task model for demonstration
struct Task {
    let id: UUID
    var title: String
    var isHighPriority: Bool
    var isCompleted: Bool = false
}

// Simulate a data store for tasks
class TaskStore {
    static let shared = TaskStore()
    // Using a dictionary for easy lookup by UUID
    private var tasks: [UUID: Task] = [
        UUID(uuidString: "E621E1F8-C36C-495A-93FC-0C247A3E6E5F")!: Task(id: UUID(uuidString: "E621E1F8-C36C-495A-93FC-0C247A3E6E5F")!, title: "Review Chapter 3", isHighPriority: true),
        UUID(uuidString: "A21D1F8C-1234-5678-90AB-CDEF0A1B2C3D")!: Task(id: UUID(uuidString: "A21D1F8C-1234-5678-90AB-CDEF0A1B2C3D")!, title: "Buy Groceries", isHighPriority: false),
        UUID(uuidString: "B3C4D5E6-F7A8-9B0C-1D2E-3F4A5B6C7D8E")!: Task(id: UUID(uuidString: "B3C4D5E6-F7A8-9B0C-1D2E-3F4A5B6C7D8E")!, title: "Already Done Task", isHighPriority: false, isCompleted: true)
    ]

    func getTask(id: UUID) -> Task? {
        return tasks[id]
    }

    func completeTask(id: UUID) {
        tasks[id]?.isCompleted = true
        print("Task '\(tasks[id]?.title ?? "")' completed.")
    }
}

// Extension to make String conform to Error for simple throwing in example
extension String: Error {}

@available(iOS 18.0, macOS 15.0, *)
struct CompleteTaskIntent: AppIntent {
    static var title: LocalizedStringResource = "Complete Task"
    static var description: IntentDescription = "Marks a task as complete, with confirmation for high-priority tasks."

    @Parameter(title: "Task ID", description: "The unique identifier of the task to complete.")
    var taskID: UUID // Using UUID directly as the parameter type

    init() {}
    init(taskID: UUID) {
        self.taskID = taskID
    }

    func perform() async throws -> some IntentResult {
        guard let task = TaskStore.shared.getTask(id: taskID) else {
            // Return a specific dialog for task not found, rather than a generic error.
            return .result(dialog: "Task with ID \(taskID.uuidString) not found.")
        }

        if task.isCompleted {
            return .result(dialog: "Task '\(task.title)' is already completed.")
        }

        if task.isHighPriority {
            // Request user confirmation for high-priority tasks
            let confirmation = try await requestConfirmation(
                confirmationDialog("Are you sure you want to complete the high-priority task '\(task.title)'?")
            )
            if !confirmation {
                // User cancelled the confirmation
                return .result(dialog: "Task '\(task.title)' was not completed.")
            }
        }

        // Simulate actual task completion logic
        TaskStore.shared.completeTask(id: taskID)
        return .result(dialog: "Task '\(task.title)' marked as complete.")
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct TaskMasterAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        // Provide an example intent with a hardcoded ID for initial setup in Shortcuts app.
        // Users can then customize this parameter.
        AppShortcut(
            intent: CompleteTaskIntent(taskID: UUID(uuidString: "E621E1F8-C36C-495A-93FC-0C247A3E6E5F")!), // Example: "Review Chapter 3"
            phrases: [
                "Complete \(.parameter(\.$taskID)) in \(.applicationName)",
                "Mark \(.parameter(\.$taskID)) as done in \(.applicationName)"
            ],
            shortTitle: "Complete Task",
            systemImageName: "checkmark.circle.fill"
        )
    }
}
