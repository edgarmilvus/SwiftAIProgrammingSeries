
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import SwiftData

@available(iOS 18.0, *)
@Model
final class Conversation {
    var id: UUID
    var title: String
    var createdAt: Date
    @Relationship(deleteRule: .cascade, inverse: \Message.conversation)
    var messages: [Message] = []
    var modelConfiguration: ModelConfiguration? // Persist AI model settings

    init(id: UUID = UUID(), title: String, createdAt: Date = Date()) {
        self.id = id
        self.title = title
        self.createdAt = createdAt
    }
}

@available(iOS 18.0, *)
@Model
final class Message {
    var id: UUID
    var role: String // e.g., "user", "assistant", "system"
    var content: String
    var timestamp: Date
    var isStreaming: Bool // Useful for AI responses
    var conversation: Conversation? // Inverse relationship

    init(id: UUID = UUID(), role: String, content: String, timestamp: Date = Date(), isStreaming: Bool = false) {
        self.id = id
        self.role = role
        self.content = content
        self.timestamp = timestamp
        self.isStreaming = isStreaming
    }
}

@available(iOS 18.0, *)
@Model
final class ModelConfiguration {
    var id: UUID
    var name: String // e.g., "GPT-4 Turbo", "Claude 3 Opus"
    var temperature: Double
    var maxTokens: Int
    // Other AI-specific parameters
    var conversation: Conversation? // One-to-one or one-to-many link

    init(id: UUID = UUID(), name: String, temperature: Double, maxTokens: Int) {
        self.id = id
        self.name = name
        self.temperature = temperature
        self.maxTokens = maxTokens
    }
}
