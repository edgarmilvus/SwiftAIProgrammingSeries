
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Example: Conceptual MLProgress structure using @Observable
import Foundation
import Observation // For @Observable

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, *)
@Observable
class MLProgress {
    enum Status {
        case notStarted
        case running
        case paused
        case cancelled
        case completed
        case failed(Error)
    }

    var percentage: Double = 0.0 // 0.0 to 1.0
    var currentIteration: Int = 0
    var totalIterations: Int = 0
    var trainingLoss: Double?
    var validationLoss: Double?
    var accuracy: Double? // For classification tasks
    var status: Status = .notStarted
    var estimatedRemainingTime: TimeInterval?

    // Internal initializer, typically managed by the Create ML framework
    internal init() {}

    // Method to simulate internal updates (framework would do this)
    func update(
        percentage: Double,
        iteration: Int,
        total: Int,
        trainingLoss: Double? = nil,
        validationLoss: Double? = nil,
        accuracy: Double? = nil,
        status: Status? = nil,
        estimatedTime: TimeInterval? = nil
    ) {
        self.percentage = percentage
        self.currentIteration = iteration
        self.totalIterations = total
        self.trainingLoss = trainingLoss
        self.validationLoss = validationLoss
        self.accuracy = accuracy
        if let newStatus = status {
            self.status = newStatus
        }
        self.estimatedRemainingTime = estimatedTime
    }
}
