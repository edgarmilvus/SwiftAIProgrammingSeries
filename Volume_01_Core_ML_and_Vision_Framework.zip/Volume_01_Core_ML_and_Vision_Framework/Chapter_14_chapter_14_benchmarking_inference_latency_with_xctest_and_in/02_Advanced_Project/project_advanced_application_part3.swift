
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

/// @available(iOS 17.0, *)
/// Base class for Core ML object detection models, handling common loading logic.
class CoreMLObjectDetector: ObjectDetectionModel {
    let modelIdentifier: String
    let coreMLModel: MLModel

    /// Initializes the detector with a model name from the app bundle.
    /// - Parameter modelName: The name of the `.mlmodelc` (compiled Core ML model) in the app bundle.
    /// - Parameter identifier: A unique string identifier for this specific model instance.
    /// - Throws: `CoreMLError.modelLoadingFailed` if the model cannot be loaded.
    init(modelName: String, identifier: String) throws {
        self.modelIdentifier = identifier
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            throw CoreMLError.modelLoadingFailed(description: "Failed to find model \(modelName).mlmodelc in bundle.")
        }
        do {
            let config = MLModelConfiguration()
            // Optimize for performance or low power based on model type or device capabilities
            config.computeUnits = .all // Use all available compute units (GPU, Neural Engine, CPU)
            self.coreMLModel = try MLModel(contentsOf: modelURL, configuration: config)
        } catch {
            throw CoreMLError.modelLoadingFailed(description: "Failed to load Core ML model \(modelName): \(error.localizedDescription)")
        }
    }

    /// Performs object detection using Vision and the loaded Core ML model.
    /// - Parameter pixelBuffer: The input image buffer.
    /// - Returns: An array of `VNRecognizedObjectObservation`.
    /// - Throws: `CoreMLError.predictionFailed` if the Vision request fails.
    func predict(pixelBuffer: CVPixelBuffer) async throws -> [VNRecognizedObjectObservation] {
        let visionModel = try VNCoreMLModel(for: coreMLModel)
        let request = VNCoreMLRequest(model: visionModel)
        request.imageCropAndScaleOption = .centerCrop // Common preprocessing option

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        do {
            try handler.perform([request])
            guard let observations = request.results as? [VNRecognizedObjectObservation] else {
                return [] // No observations or wrong type
            }
            return observations
        } catch {
            throw CoreMLError.predictionFailed(description: "Vision request failed: \(error.localizedDescription)")
        }
    }
}

/// @available(iOS 17.0, *)
/// Represents the faster, less accurate object detection model.
class FastObjectDetector: CoreMLObjectDetector {
    convenience init() throws {
        // In a real app, "FastDetector_compiled" would be the name of your .mlmodelc
        try self.init(modelName: "FastDetector_compiled", identifier: "FastDetector")
    }
}

/// @available(iOS 17.0, *)
/// Represents the slower, more accurate object detection model.
class AccurateObjectDetector: CoreMLObjectDetector {
    convenience init() throws {
        // In a real app, "AccurateDetector_compiled" would be the name of your .mlmodelc
        try self.init(modelName: "AccurateDetector_compiled", identifier: "AccurateDetector")
    }
}

/// Custom error types for better error handling.
enum CoreMLError: Error, LocalizedError {
    case modelLoadingFailed(description: String)
    case predictionFailed(description: String)
    case invalidInput(description: String)

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let desc): return "Core ML Model Loading Failed: \(desc)"
        case .predictionFailed(let desc): return "Core ML Prediction Failed: \(desc)"
        case .invalidInput(let desc): return "Invalid Input for Core ML: \(desc)"
        }
    }
}
