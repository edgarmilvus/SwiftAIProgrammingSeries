
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Observation // For @Observable

// Custom struct for Confusion Matrix, made Sendable for actor/async usage
struct ConfusionMatrix: Sendable {
    var truePositives: Int = 0
    var trueNegatives: Int = 0
    var falsePositives: Int = 0
    var falseNegatives: Int = 0

    mutating func update(actual: String, predicted: String) {
        // Simplified for binary classification (e.g., "positive" vs "negative")
        let positiveClass = "positive"
        if actual == positiveClass && predicted == positiveClass {
            truePositives += 1
        } else if actual != positiveClass && predicted != positiveClass {
            trueNegatives += 1
        } else if actual != positiveClass && predicted == positiveClass {
            falsePositives += 1
        } else { // actual == positiveClass && predicted != positiveClass
            falseNegatives += 1
        }
    }
    
    // Example method to reset
    mutating func reset() {
        truePositives = 0
        trueNegatives = 0
        falsePositives = 0
        falseNegatives = 0
    }
}

@available(iOS 18.0, *)
@Observable
class EvaluationViewModel {
    private let evaluator = ModelEvaluator() // The actor instance
    var currentAccuracy: Double = 0.0
    var currentPrecision: Double = 0.0
    var currentRecall: Double = 0.0
    var isEvaluating: Bool = false

    func startEvaluation(model: MLModel, dataProvider: some AsyncSequence<Image, Error>) async {
        isEvaluating = true
        // Reset previous state if necessary
        await evaluator.resetMetrics() // Assuming reset method in actor
        
        do {
            try await evaluator.evaluateDataset(model: model, dataProvider: dataProvider)
            let metrics = await evaluator.calculateMetrics()
            await MainActor.run {
                self.currentAccuracy = metrics.accuracy
                self.currentPrecision = metrics.precision
                self.currentRecall = metrics.recall
                self.isEvaluating = false
            }
        } catch {
            print("Evaluation failed: \(error)")
            await MainActor.run {
                self.isEvaluating = false
            }
        }
    }
    
    // Add a reset method to ModelEvaluator actor
    // This would be inside the ModelEvaluator actor definition
    nonisolated func resetMetrics() async { // nonisolated to allow calling from outside, then await inside
        await self.performReset()
    }

    private func performReset() { // isolated to the actor
        results = []
        confusionMatrix.reset()
    }
}

// Example SwiftUI View
@available(iOS 18.0, *)
struct EvaluationView: View {
    @State private var viewModel = EvaluationViewModel()
    let myModel: MLModel // Assume this is passed in
    let testDataProvider: some AsyncSequence<Image, Error> // Assume this is passed in

    var body: some View {
        VStack {
            Text("Model Evaluation")
                .font(.largeTitle)
            
            if viewModel.isEvaluating {
                ProgressView("Evaluating...")
            } else {
                VStack(alignment: .leading) {
                    Text("Accuracy: \(viewModel.currentAccuracy, format: .percent)")
                    Text("Precision: \(viewModel.currentPrecision, format: .percent)")
                    Text("Recall: \(viewModel.currentRecall, format: .percent)")
                }
                .font(.title2)
                .padding()
                
                Button("Run Evaluation") {
                    Task {
                        await viewModel.startEvaluation(model: myModel, dataProvider: testDataProvider)
                    }
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }
}
