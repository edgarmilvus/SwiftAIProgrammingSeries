
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import Vision
import RealityKit

enum PoseState {
    case neutral, armsRaised
}

actor PoseLogicEngine {
    private var currentState: PoseState = .neutral
    private var confidenceCounter = 0
    private let threshold = 10 // Require 10 consecutive frames

    func analyze(joints: [VNHumanBodyPoseObservation.JointName: CGPoint]) -> PoseState {
        // 1. Geometric Heuristic: Are both wrists above the nose?
        guard let leftWrist = joints[.leftWrist],
              let rightWrist = joints[.rightWrist],
              let nose = joints[.nose] else { return .neutral }

        let isArmsRaised = leftWrist.y > nose.y && rightWrist.y > nose.y
        
        if isArmsRaised {
            confidenceCounter += 1
        } else {
            confidenceCounter = 0
            currentState = .neutral
        }

        // 2. Debounce Logic: Only trigger state change if stable
        if confidenceCounter >= threshold {
            currentState = .armsRaised
        }

        return currentState
    }
}

class FitnessCoachManager: ObservableObject {
    private let engine = PoseLogicEngine()
    var characterEntity: ModelEntity?

    func processPose(observation: VNHHumanBodyPoseObservation) {
        Task {
            // 3. Extract Joints
            let joints = try await observation.recognizedPoints(.all)
                .reduce(into: [VNHumanBodyPoseObservation.JointName: CGPoint]()) { dict, point in
                    // Only include high-confidence points
                    if point.confidence > 0.5 {
                        // Vision coordinates are normalized, we need the point
                        dict[point.name] = CGPoint(x: point.location.x, y: point.location.y)
                    }
                }

            // 4. State Machine Transition
            let newState = await engine.analyze(joints: joints)
            
            await MainActor.run {
                if newState == .armsRaised {
                    self.triggerCelebration()
                }
            }
        }
    }

    @MainActor
    private func triggerCelebration() {
        // 5. RealityKit Animation Trigger
        guard let character = characterEntity else { return }
        if let animation = character.availableAnimations.first {
            character.playAnimation(animation.repeat())
        }
    }
}
