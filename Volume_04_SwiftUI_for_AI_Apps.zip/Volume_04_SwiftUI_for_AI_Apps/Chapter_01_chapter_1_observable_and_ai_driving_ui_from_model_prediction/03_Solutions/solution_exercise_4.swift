
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI

// MARK: - 1. Define Prediction Structure
struct SmartHomePrediction: Identifiable, Equatable {
    let id = UUID() // For SwiftUI list/identifiable purposes
    let actionDescription: String
    let confidence: Double // 0.0 - 1.0
    let suggestedTime: Date
}

// MARK: - 2. Create an Observable Smart Home Predictor
@available(iOS 18.0, *)
@Observable
class SmartHomePredictor {
    var currentSuggestion: SmartHomePrediction?
    var isPredicting: Bool = false
    var lastPredictionAttempt: Date?
    
    private var predictionUpdateTask: Task<Void, Never>?
    private let predictionInterval: Duration = .seconds(15) // Simulate predictions every 15 seconds

    init() {
        // Start periodic prediction updates in a background task
        startPeriodicPredictions()
    }
    
    /// Starts a periodic task to generate new predictions.
    private func startPeriodicPredictions() {
        predictionUpdateTask?.cancel() // Cancel any existing task
        predictionUpdateTask = Task {
            while !Task.isCancelled {
                await generateNewPrediction()
                do {
                    try await Task.sleep(for: predictionInterval)
                } catch is CancellationError {
                    // Task was cancelled, break the loop
                    break
                } catch {
                    print("Error sleeping during periodic prediction: \(error)")
                    // Continue loop in case of other errors
                }
            }
        }
    }

    /// Simulates an AI engine generating a new proactive suggestion.
    @MainActor
    func generateNewPrediction() async {
        guard !isPredicting else { return } // Prevent concurrent predictions
        
        isPredicting = true
        lastPredictionAttempt = Date()
        currentSuggestion = nil // Clear previous suggestion while predicting
        
        do {
            // Simulate fetching data and running an AI model
            try await Task.sleep(for: .seconds(3))
            
            // Simulate different predictions based on "time of day" or random chance
            let hour = Calendar.current.component(.hour, from: Date())
            
            let newSuggestion: SmartHomePrediction?
            let randomChance = Double.random(in: 0...1)
            
            if randomChance < 0.2 { // 20% chance of no suggestion
                newSuggestion = nil
            } else if hour >= 18 && hour < 22 { // Evening (6 PM - 10 PM)
                newSuggestion = SmartHomePrediction(
                    actionDescription: "Dim lights for movie night",
                    confidence: Double.random(in: 0.85...0.98),
                    suggestedTime: Date()
                )
            } else if hour >= 22 || hour < 6 { // Night/Early Morning (10 PM - 6 AM)
                newSuggestion = SmartHomePrediction(
                    actionDescription: "Adjust thermostat for sleep (20°C)",
                    confidence: Double.random(in: 0.7...0.9),
                    suggestedTime: Date()
                )
            } else if hour >= 6 && hour < 9 { // Morning (6 AM - 9 AM)
                newSuggestion = SmartHomePrediction(
                    actionDescription: "Brew coffee and open blinds",
                    confidence: Double.random(in: 0.75...0.92),
                    suggestedTime: Date()
                )
            } else { // Daytime
                newSuggestion = SmartHomePrediction(
                    actionDescription: "Turn on ambient music",
                    confidence: Double.random(in: 0.6...0.8),
                    suggestedTime: Date()
                )
            }
            
            self.currentSuggestion = newSuggestion
            
        } catch is CancellationError {
            // Task was cancelled, do nothing
            print("Prediction generation cancelled.")
        } catch {
            print("Error generating new prediction: \(error)")
            self.currentSuggestion = SmartHomePrediction(
                actionDescription: "Prediction failed.",
                confidence: 0.0,
                suggestedTime: Date()
            )
        }
        
        isPredicting = false
    }
    
    /// Simulates confirming a suggestion.
    func confirmSuggestion() {
        if let suggestion = currentSuggestion {
            print("Confirmed suggestion: \(suggestion.actionDescription)")
            // In a real app, this would trigger a smart home action
            currentSuggestion = nil // Clear suggestion after confirmation
            // Immediately trigger a new prediction to get the next relevant suggestion
            Task { await generateNewPrediction() }
        }
    }
    
    /// Simulates dismissing a suggestion.
    func dismissSuggestion() {
        if let suggestion = currentSuggestion {
            print("Dismissed suggestion: \(suggestion.actionDescription)")
            // In a real app, this might log user preference
            currentSuggestion = nil // Clear suggestion
            // Immediately trigger a new prediction
            Task { await generateNewPrediction() }
        }
    }
    
    // Cleanup prediction task if the view model is deallocated
    deinit {
        predictionUpdateTask?.cancel()
    }
}

// MARK: - 3. Build the SwiftUI View
@available(iOS 18.0, *)
struct ProactiveSuggestionsPanel: View {
    // Instantiate SmartHomePredictor using @State
    @State private var predictor = SmartHomePredictor()
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Proactive Suggestions")
                .font(.title2)
                .bold()
                .foregroundColor(.white)
            
            if predictor.isPredicting {
                ProgressView("Thinking...")
                    .progressViewStyle(.circular)
                    .tint(.white)
                    .padding()
            } else if let suggestion = predictor.currentSuggestion {
                VStack(alignment: .leading, spacing: 8) {
                    Text(suggestion.actionDescription)
                        .font(.headline)
                        .foregroundColor(.white)
                    
                    Gauge(value: suggestion.confidence, in: 0.0...1.0) {
                        Text("Confidence")
                            .foregroundColor(.white.opacity(0.8))
                    } currentLabel: {
                        Text(suggestion.confidence, format: .percent)
                            .foregroundColor(.white)
                    }
                    .gaugeStyle(.linearCapacity)
                    .tint(suggestion.confidence > 0.8 ? .green : .yellow)
                    .padding(.vertical, 5)
                    
                    HStack(spacing: 15) {
                        Button("Confirm") {
                            predictor.confirmSuggestion()
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.green)
                        
                        Button("Dismiss") {
                            predictor.dismissSuggestion()
                        }
                        .buttonStyle(.bordered)
                        .tint(.gray)
                    }
                }
                .padding()
                .background(Color.blue.opacity(0.3)) // Suggestion specific background
                .cornerRadius(10)
            } else {
                Text("No proactive suggestions at the moment.")
                    .foregroundColor(.gray)
                    .padding()
            }
            
            if let lastAttempt = predictor.lastPredictionAttempt {
                Text("Last updated: \(lastAttempt, format: .relative(presentation: .numeric)) ago")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.7))
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 15)
                .fill(LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.6), Color.blue.opacity(0.6)]), startPoint: .topLeading, endPoint: .bottomTrailing))
        )
        .shadow(radius: 5)
        .padding()
    }
}

// MARK: - Preview Provider
/*
@available(iOS 18.0, *)
#Preview {
    ProactiveSuggestionsPanel()
        .preferredColorScheme(.dark)
}
*/
