
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import Vision
import UIKit // For UIImage, though could be NSImage for macOS

// 1. Metadata Output Structure
struct ImageRectangleMetadata: Codable, Sendable {
    let originalImageURL: URL
    let detectedNormalizedRect: CGRect?
    let confidence: Float?
    let topLeft: CGPoint?
    let topRight: CGPoint?
    let bottomRight: CGPoint?
    let bottomLeft: CGPoint?
    let errorMessage: String?

    // Custom CodingKeys for CGRect and CGPoint to encode/decode as dictionaries
    // This makes the JSON more readable and robust across platforms.
    enum CodingKeys: String, CodingKey {
        case originalImageURL
        case detectedNormalizedRect
        case confidence
        case topLeft
        case topRight
        case bottomRight
        case bottomLeft
        case errorMessage
    }

    init(originalImageURL: URL, detectedNormalizedRect: CGRect? = nil, confidence: Float? = nil,
         topLeft: CGPoint? = nil, topRight: CGPoint? = nil, bottomRight: CGPoint? = nil,
         bottomLeft: CGPoint? = nil, errorMessage: String? = nil) {
        self.originalImageURL = originalImageURL
        self.detectedNormalizedRect = detectedNormalizedRect
        self.confidence = confidence
        self.topLeft = topLeft
        self.topRight = topRight
        self.bottomRight = bottomRight
        self.bottomLeft = bottomLeft
        self.errorMessage = errorMessage
    }

    // MARK: - Codable Conformance
    // Custom encoding/decoding for CGRect and CGPoint

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(originalImageURL, forKey: .originalImageURL)
        try container.encode(confidence, forKey: .confidence)
        try container.encode(errorMessage, forKey: .errorMessage)

        if let rect = detectedNormalizedRect {
            let rectDict: [String: CGFloat] = [
                "x": rect.origin.x, "y": rect.origin.y,
                "width": rect.size.width, "height": rect.size.height
            ]
            try container.encode(rectDict, forKey: .detectedNormalizedRect)
        }
        if let point = topLeft { try encodePoint(point, forKey: .topLeft, in: &container) }
        if let point = topRight { try encodePoint(point, forKey: .topRight, in: &container) }
        if let point = bottomRight { try encodePoint(point, forKey: .bottomRight, in: &container) }
        if let point = bottomLeft { try encodePoint(point, forKey: .bottomLeft, in: &container) }
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        originalImageURL = try container.decode(URL.self, forKey: .originalImageURL)
        confidence = try container.decodeIfPresent(Float.self, forKey: .confidence)
        errorMessage = try container.decodeIfPresent(String.self, forKey: .errorMessage)

        if let rectDict = try container.decodeIfPresent([String: CGFloat].self, forKey: .detectedNormalizedRect) {
            detectedNormalizedRect = CGRect(
                x: rectDict["x"] ?? 0, y: rectDict["y"] ?? 0,
                width: rectDict["width"] ?? 0, height: rectDict["height"] ?? 0
            )
        } else {
            detectedNormalizedRect = nil
        }

        topLeft = try decodePoint(forKey: .topLeft, from: container)
        topRight = try decodePoint(forKey: .topRight, from: container)
        bottomRight = try decodePoint(forKey: .bottomRight, from: container)
        bottomLeft = try decodePoint(forKey: .bottomLeft, from: container)
    }

    private func encodePoint(_ point: CGPoint, forKey key: CodingKeys, in container: inout KeyedEncodingContainer<CodingKeys>) throws {
        let pointDict: [String: CGFloat] = ["x": point.x, "y": point.y]
        try container.encode(pointDict, forKey: key)
    }

    private func decodePoint(forKey key: CodingKeys, from container: KeyedDecodingContainer<CodingKeys>) throws -> CGPoint? {
        if let pointDict = try container.decodeIfPresent([String: CGFloat].self, forKey: key) {
            return CGPoint(x: pointDict["x"] ?? 0, y: pointDict["y"] ?? 0)
        }
        return nil
    }
}

actor BatchProcessor {
    private let concurrencyLimit: Int
    private var processedCount: Int = 0
    private var totalImages: Int = 0

    init(concurrencyLimit: Int) {
        self.concurrencyLimit = concurrencyLimit
    }

    func processBatch(imageURLs: [URL], outputJSONURL: URL) async throws -> [ImageRectangleMetadata] {
        self.totalImages = imageURLs.count
        self.processedCount = 0
        print("Starting batch processing for \(totalImages) images with concurrency limit \(concurrencyLimit)...")

        var allMetadata: [ImageRectangleMetadata] = []

        await withTaskGroup(of: ImageRectangleMetadata.self) { group in
            var activeTasks = 0

            for url in imageURLs {
                // Wait if we've hit the concurrency limit
                if activeTasks >= concurrencyLimit {
                    if let result = await group.next() {
                        allMetadata.append(result)
                        await self.incrementProcessedCount() // Update progress
                    }
                    activeTasks -= 1
                }

                // Add a new task
                group.addTask {
                    return await self.processSingleImage(url: url)
                }
                activeTasks += 1
            }

            // Await any remaining tasks
            for await result in group {
                allMetadata.append(result)
                await self.incrementProcessedCount() // Update progress
            }
        }

        print("Batch processing complete.")
        try await saveMetadata(allMetadata, to: outputJSONURL)
        return allMetadata
    }

    private func processSingleImage(url: URL) async -> ImageRectangleMetadata {
        print("Processing image: \(url.lastPathComponent)")
        do {
            guard let imageData = try? Data(contentsOf: url),
                  let uiImage = UIImage(data: imageData),
                  let cgImage = uiImage.cgImage else {
                return ImageRectangleMetadata(originalImageURL: url, errorMessage: "Failed to load image data or convert to CGImage.")
            }

            return try await withCheckedThrowingContinuation { continuation in
                let request = VNDetectRectanglesRequest { request, error in
                    if let error = error {
                        continuation.resume(returning: ImageRectangleMetadata(originalImageURL: url, errorMessage: "Vision request failed: \(error.localizedDescription)"))
                        return
                    }

                    guard let observations = request.results as? [VNRectangleObservation],
                          let bestObservation = observations.max(by: { $0.confidence < $1.confidence }) else {
                        continuation.resume(returning: ImageRectangleMetadata(originalImageURL: url, errorMessage: "No prominent rectangle detected."))
                        return
                    }

                    let metadata = ImageRectangleMetadata(
                        originalImageURL: url,
                        detectedNormalizedRect: bestObservation.boundingBox,
                        confidence: bestObservation.confidence,
                        topLeft: bestObservation.topLeft,
                        topRight: bestObservation.topRight,
                        bottomRight: bestObservation.bottomRight,
                        bottomLeft: bestObservation.bottomLeft
                    )
                    continuation.resume(returning: metadata)
                }

                request.minimumSize = 0.2 // Focus on larger documents
                request.maximumObservations = 1 // Only interested in the primary document

                let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
                do {
                    try handler.perform([request])
                } catch {
                    continuation.resume(returning: ImageRectangleMetadata(originalImageURL: url, errorMessage: "Failed to perform Vision request: \(error.localizedDescription)"))
                }
            }
        } catch {
            return ImageRectangleMetadata(originalImageURL: url, errorMessage: "Unexpected error during image processing: \(error.localizedDescription)")
        }
    }

    private func incrementProcessedCount() {
        processedCount += 1
        print("Progress: Processed \(processedCount) of \(totalImages) images.")
    }

    private func saveMetadata(_ metadata: [ImageRectangleMetadata], to url: URL) async throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted // For human-readable JSON
        let data = try encoder.encode(metadata)
        try data.write(to: url, options: [.atomicWrite])
        print("Metadata saved to: \(url.lastPathComponent)")
    }
}

// MARK: - Example Usage (e.g., in a ViewController or a test function)
func runBatchProcessingExample() async {
    // Simulate some image URLs
    let fileManager = FileManager.default
    let tempDirectory = fileManager.temporaryDirectory.appendingPathComponent("BatchImages")
    try? fileManager.createDirectory(at: tempDirectory, withIntermediateDirectories: true, attributes: nil)

    var simulatedImageURLs: [URL] = []
    for i in 1...10 { // Simulate 10 images
        let dummyImage = UIImage(systemName: "doc.text.fill")?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
        let imageToSave = dummyImage?.sd_resizedImage(with: CGSize(width: 800, height: 600), scaleMode: .fill) // Make it a bit larger
        
        // Create a simple image with a rectangle (a white rectangle on a gray background)
        let rectImage = UIGraphicsImageRenderer(size: CGSize(width: 800, height: 600)).image { context in
            UIColor.lightGray.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 800, height: 600))
            
            UIColor.white.setFill()
            let documentRect = CGRect(x: 100, y: 100, width: 600, height: 400) // A clear rectangle
            context.fill(documentRect)
            
            // Add some text to make it look like a document
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            let attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 30),
                .paragraphStyle: paragraphStyle,
                .foregroundColor: UIColor.black
            ]
            "Document \(i)".draw(in: documentRect.insetBy(dx: 20, dy: 20), withAttributes: attributes)
        }

        if let imageData = rectImage.jpegData(compressionQuality: 0.8) {
            let fileURL = tempDirectory.appendingPathComponent("document_\(i).jpg")
            do {
                try imageData.write(to: fileURL)
                simulatedImageURLs.append(fileURL)
            } catch {
                print("Error saving dummy image \(i): \(error)")
            }
        }
    }
    
    // Output JSON file path
    let outputJSONURL = fileManager.temporaryDirectory.appendingPathComponent("batch_metadata.json")

    let processor = BatchProcessor(concurrencyLimit: 4) // Process 4 images concurrently
    do {
        let results = try await processor.processBatch(imageURLs: simulatedImageURLs, outputJSONURL: outputJSONURL)
        print("\nFinal results count: \(results.count)")
        for result in results {
            if let error = result.errorMessage {
                print("  \(result.originalImageURL.lastPathComponent): Error - \(error)")
            } else {
                print("  \(result.originalImageURL.lastPathComponent): Detected Rect \(String(describing: result.detectedNormalizedRect)), Confidence \(String(describing: result.confidence))")
            }
        }
    } catch {
        print("Batch processing failed: \(error.localizedDescription)")
    }
    
    // Clean up simulated images
    try? fileManager.removeItem(at: tempDirectory)
}

// To run this example, you would call `Task { await runBatchProcessingExample() }`
// from an appropriate place, e.g., in `application(_:didFinishLaunchingWithOptions:)`
// or a button tap in a UI app.
