/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/hooks/useStepCount.android.ts
import { useState, useEffect } from 'react';
import { PermissionsAndroid, Platform } from 'react-native';
// Assuming a library like react-native-google-fit or react-native-sensors
import GoogleFit from 'react-native-google-fit'; 
import { UseStepCountResult } from './useStepCount';

export const useStepCount = (): UseStepCountResult => {
  const [steps, setSteps] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | undefined>();

  useEffect(() => {
    // Check if Google Fit is available
    GoogleFit.isAvailable().then((available) => {
      if (available) {
        const options = {
          startDate: new Date().getTime() - 24 * 60 * 60 * 1000,
          endDate: new Date().getTime(),
        };
        GoogleFit.getDailyStepCountSamples(options)
          .then((samples) => {
            // Process samples to get total steps
            const total = samples.reduce((acc, curr) => acc + curr.steps, 0);
            setSteps(total);
            setIsLoading(false);
          })
          .catch((err) => setError(err.message));
      } else {
        setError('Google Fit not available');
      }
    });
  }, []);

  const requestPermissions = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACTIVITY_RECOGNITION
      );
      if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
        setError('Permission denied');
      }
    } catch (err) {
      setError('Permission request error');
    }
  };

  return { steps, requestPermissions, isLoading, error };
};
