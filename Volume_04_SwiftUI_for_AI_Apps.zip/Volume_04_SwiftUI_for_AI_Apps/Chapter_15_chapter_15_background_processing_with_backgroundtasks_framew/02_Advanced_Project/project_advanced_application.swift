
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift (Hypothetical - for demonstrating Swift Package Manager structure)
// For this specific example, all required frameworks (BackgroundTasks, CoreML, UserNotifications, UIKit)
// are system frameworks, so an explicit Package.swift is not strictly necessary.
// However, if you were integrating a third-party AI library, it would look like this:

/*
import PackageDescription

let package = Package(
    name: "SmartDocumentScanner",
    platforms: [.iOS(.v17)], // Or .v18 if using cutting-edge features
    products: [
        .library(
            name: "SmartDocumentScanner",
            targets: ["SmartDocumentScanner"]),
    ],
    dependencies: [
        // Example: A hypothetical external AI inference library
        // .package(url: "https://github.com/some-ai-vendor/ai-sdk.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "SmartDocumentScanner",
            dependencies: [
                // If using a third-party library:
                // .product(name: "AISDK", package: "ai-sdk"),
            ]),
        .testTarget(
            name: "SmartDocumentScannerTests",
            dependencies: ["SmartDocumentScanner"]),
    ]
)
*/

import Foundation
import BackgroundTasks
import CoreML // For simulating local AI inference
import UserNotifications // For sending completion notifications
import UIKit // For UIApplication, needed for background task scheduling
import SwiftUI // For the example app context

// MARK: - 1. Task Identifiers
// Define unique identifiers for our background tasks. These identifiers MUST be
// declared in your app's Info.plist under the 'Permitted background task scheduler identifiers' array.
// Failure to do so will result in runtime errors when registering or scheduling tasks.
// We use a BGProcessingTask because AI inference can be resource-intensive and take longer.
enum BackgroundTaskIdentifier: String {
    case processAIDocument = "com.ai.documentScanner.processAIDocument"
}

// MARK: - 2. AI Model Simulation
/// A simplified representation of a local AI model for document processing.
/// In a production application, this class would wrap a `Core ML` model, a `TensorFlow Lite` model,
/// or a custom C++ inference engine. It simulates the asynchronous nature and potential
/// long-running execution of real AI inference.
@available(iOS 18.0, *) // Using modern Swift concurrency features
final class DocumentAIModel {
    enum AIError: Error, LocalizedError {
        case inferenceFailed(String)
        case modelLoadFailed(String)
        case documentCorrupted
        
        var errorDescription: String? {
            switch self {
            case .inferenceFailed(let reason): return "AI inference failed: \(reason)"
            case .modelLoadFailed(let reason): return "AI model could not be loaded: \(reason)"
            case .documentCorrupted: return "The document data is corrupted or invalid."
            }
        }
    }
    
    /// Simulates loading the AI model. Model loading can itself be a time-consuming
    /// operation, especially for large models.
    func loadModel() async throws {
        print("[\(Date())] DocumentAIModel: Loading model...")
        // Simulate a delay for model loading to mimic real-world scenarios.
        try await Task.sleep(for: .seconds(0.5))
        // In a real app, this would involve loading an MLModel from a URL:
        // let config = MLModelConfiguration()
        // self.model = try MLModel(contentsOf: modelURL, configuration: config)
        print("[\(Date())] DocumentAIModel: Model loaded successfully.")
    }

    /// Simulates processing a document using the AI model.
    /// This method encapsulates the core AI inference logic.
    /// - Parameter documentData: The raw data of the document (e.g., image, PDF bytes).
    /// - Returns: A `ProcessedDocumentResult` containing AI-extracted information.
    func processDocument(documentData: Data) async throws -> ProcessedDocumentResult {
        guard !documentData.isEmpty else {
            throw AIError.documentCorrupted
        }
        
        print("[\(Date())] DocumentAIModel: Starting AI inference for document (size: \(documentData.count) bytes)...")
        
        // Simulate a complex, long-running AI inference operation.
        // This could involve OCR, entity extraction, summarization, classification, etc.
        let processingTime = Double.random(in: 5.0...15.0) // Simulate 5-15 seconds of work
        try await Task.sleep(for: .seconds(processingTime))
        
        // Simulate potential failure during inference, a common scenario in AI.
        if Bool.random() && processingTime > 10 { // Higher chance of failure for longer tasks
            throw AIError.inferenceFailed("Simulated random inference error after \(String(format: "%.1f", processingTime))s.")
        }
        
        // Simulate output from the AI model. In a real app, this would be structured
        // output from your Core ML model's prediction.
        let extractedText = "This is simulated OCR text from the document. Key phrases: 'Contract Agreement', 'Financial Report 2024'."
        let category = ["Invoice", "Receipt", "Contract", "Report"].randomElement()!
        let confidence = Double.random(in: 0.85...0.99)
        
        print("[\(Date())] DocumentAIModel: AI inference completed in \(String(format: "%.1f", processingTime))s. Category: \(category).")
        
        return ProcessedDocumentResult(
            documentID: UUID().uuidString,
            extractedText: extractedText,
            category: category,
            confidence: confidence,
            processingDate: Date()
        )
    }
}

// MARK: - 3. Document Storage Simulation
/// Represents the structured result of an AI-processed document.
/// It conforms to `Codable` for easy persistence and `Identifiable` for SwiftUI lists.
struct ProcessedDocumentResult: Codable, Identifiable {
    let id: String // Conforms to Identifiable
    let documentID: String // Original document identifier
    let extractedText: String
    let category: String
    let confidence: Double
    let processingDate: Date
}

/// A simple manager to store and retrieve processed document results.
/// In a real application, this would typically use a robust persistence layer like
/// Core Data, Realm, or synchronize with a cloud service. For this example, `UserDefaults`
/// is used for simplicity, but it's not suitable for large or complex data.
final class DocumentResultStore {
    private static let userDefaultsKey = "processedDocumentResults"
    
    /// Saves a processed document result to `UserDefaults`.
    /// - Parameter result: The `ProcessedDocumentResult` to save.
    func save(result: ProcessedDocumentResult) {
        var results = fetchAll()
        results.append(result)
        if let encoded = try? JSONEncoder().encode(results) {
            UserDefaults.standard.set(encoded, forKey: Self.userDefaultsKey)
            print("[\(Date())] DocumentResultStore: Saved result for document ID: \(result.documentID)")
        } else {
            print("[\(Date())] DocumentResultStore: Failed to encode and save result.")
        }
    }
    
    /// Fetches all stored processed document results from `UserDefaults`.
    /// - Returns: An array of `ProcessedDocumentResult`.
    func fetchAll() -> [ProcessedDocumentResult] {
        if let savedResultsData = UserDefaults.standard.data(forKey: Self.userDefaultsKey),
           let decodedResults = try? JSONDecoder().decode([ProcessedDocumentResult].self, from: savedResultsData) {
            return decodedResults
        }
        return []
    }
    
    /// Clears all stored results (useful for testing or app resets).
    func clearAll() {
        UserDefaults.standard.removeObject(forKey: Self.userDefaultsKey)
        print("[\(Date())] DocumentResultStore: All processed document results cleared.")
    }
}

// MARK: - 4. BackgroundTaskScheduler
/// `AppBackgroundTaskScheduler` is a singleton that manages the registration and scheduling
/// of all background tasks for the app. It centralizes the logic for interacting with
/// `BGTaskScheduler.shared`.
@available(iOS 18.0, *)
final class AppBackgroundTaskScheduler {
    static let shared = AppBackgroundTaskScheduler()
    private let aiModel = DocumentAIModel()
    private let resultStore = DocumentResultStore()
    
    private init() {
        // Private initializer for singleton pattern.
        // AI model is instantiated here but loaded lazily within the task.
    }
    
    /// Registers all background tasks with the system.
    /// This method must be called early in the app's lifecycle, typically in
    /// `AppDelegate.didFinishLaunchingWithOptions` or the `App` struct's `init`.
    func registerTasks() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: BackgroundTaskIdentifier.processAIDocument.rawValue, using: nil) { task in
            // When the system launches the app for this task, it calls this closure.
            // We downcast the generic BGTask to our specific BGProcessingTask.
            self.handleAIProcessingTask(task: task as! BGProcessingTask)
        }
        print("[\(Date())] AppBackgroundTaskScheduler: Registered background tasks.")
    }
    
    /// Schedules a background processing task to perform AI inference on a document.
    /// This is typically called from the foreground app when a user action (e.g., scanning)
    /// triggers the need for background AI work.
    /// - Parameter documentData: The raw data of the document to be processed.
    /// - Parameter documentIdentifier: A unique identifier for the document.
    func scheduleAIProcessingTask(documentData: Data, documentIdentifier: String) {
        let request = BGProcessingTaskRequest(identifier: BackgroundTaskIdentifier.processAIDocument.rawValue)
        
        // `earliestBeginDate` suggests when the task can start. The system may delay it.
        // For AI processing, allowing some delay is often acceptable.
        request.earliestBeginDate = Date().addingTimeInterval(5 * 60) // Try to run in 5 minutes
        
        // `requiresNetworkConnectivity` should be set to `true` if your AI model needs
        // to download updates, send telemetry, or sync results to a cloud service.
        // For purely local Core ML inference, it might be `false`.
        request.requiresNetworkConnectivity = true
        
        // `requiresExternalPower` should be `true` for very long or resource-intensive tasks
        // to prevent battery drain. For this example, we'll keep it `false` for broader execution.
        request.requiresExternalPower = false
        
        // Store the document data and identifier for the background task to pick up.
        // IMPORTANT: For large data, save to disk (e.g., app's Caches directory) and pass a file URL
        // or a unique ID in `request.userInfo`. Using `UserDefaults` for raw `Data` is
        // simplified for this demo and not recommended for large payloads.
        UserDefaults.standard.set(documentData, forKey: "documentData_\(documentIdentifier)")
        UserDefaults.standard.set(documentIdentifier, forKey: "documentID_for_processing")
        
        do {
            try BGTaskScheduler.shared.schedule(request)
            print("[\(Date())] AppBackgroundTaskScheduler: Successfully scheduled AI document processing task for ID: \(documentIdentifier)")
        } catch {
            print("[\(Date())] AppBackgroundTaskScheduler: Failed to schedule AI document processing task: \(error.localizedDescription)")
            // Clean up temporary data if scheduling fails to prevent stale data.
            UserDefaults.standard.removeObject(forKey: "documentData_\(documentIdentifier)")
            UserDefaults.standard.removeObject(forKey: "documentID_for_processing")
        }
    }
    
    // MARK: - 5. AI Processing Logic within the task
    /// This method is the actual entry point when the system launches the app in the background
    /// to execute the `BGProcessingTask`. It contains the core logic for AI inference.
    /// - Parameter task: The `BGProcessingTask` instance provided by the system.
    func handleAIProcessingTask(task: BGProcessingTask) {
        print("[\(Date())] AppBackgroundTaskScheduler: Starting background task: \(task.identifier)")
        
        // Use a `Task` to manage the asynchronous operations and ensure proper
        // cancellation and completion handling with modern Swift concurrency.
        Task { [weak self] in
            guard let self = self else { return }
            
            var backgroundTaskExpired = false
            
            // Set an expiration handler for the task. This is CRUCIAL.
            // If the system decides the task has run too long or needs to reclaim resources,
            // it will call this handler. We must stop our work and mark the task as complete.
            task.expirationHandler = {
                print("[\(Date())] AppBackgroundTaskScheduler: Background task \(task.identifier) expired!")
                backgroundTaskExpired = true
                // Notify the user if the task was critical and couldn't complete.
                self.sendLocalNotification(
                    title: "Document Processing Failed",
                    body: "AI processing for your document could not complete in the background due to time limits. Please open the app to retry.",
                    sound: .defaultCritical
                )
                // End the task immediately, indicating failure.
                task.setTaskCompleted(success: false)
            }
            
            // Retrieve the document data and identifier that were stored when the task was scheduled.
            guard let documentIdentifier = UserDefaults.standard.string(forKey: "documentID_for_processing"),
                  let documentData = UserDefaults.standard.data(forKey: "documentData_\(documentIdentifier)") else {
                print("[\(Date())] AppBackgroundTaskScheduler: No document data found for processing. Marking task as failed.")
                self.sendLocalNotification(
                    title: "Document Processing Error",
                    body: "Could not retrieve document data for AI processing.",
                    sound: .default
                )
                task.setTaskCompleted(success: false)
                return
            }
            
            var success = false
            do {
                // 1. Load AI Model: Perform potentially heavy model loading.
                try await self.aiModel.loadModel()
                
                // 2. Perform AI Inference: Execute the core AI logic.
                let result = try await self.aiModel.processDocument(documentData: documentData)
                
                // 3. Save Results: Persist the AI-processed data.
                self.resultStore.save(result: result)
                
                // 4. Send Local Notification: Inform the user of successful completion.
                self.sendLocalNotification(
                    title: "Document Processed!",
                    body: "Your document '\(documentIdentifier.prefix(8))...' has been AI-processed. Category: \(result.category).",
                    sound: .default
                )
                success = true
                
            } catch {
                // 6. Error Handling: Catch any errors during the AI process.
                print("[\(Date())] AppBackgroundTaskScheduler: AI document processing failed: \(error.localizedDescription)")
                self.sendLocalNotification(
                    title: "Document Processing Failed",
                    body: "AI processing for document '\(documentIdentifier.prefix(8))...' failed: \(error.localizedDescription)",
                    sound: .default
                )
                success = false
            }
            
            // 7. Clean Up Temporary Data: Always remove temporary data once processing is done.
            UserDefaults.standard.removeObject(forKey: "documentData_\(documentIdentifier)")
            UserDefaults.standard.removeObject(forKey: "documentID_for_processing")
            
            // Mark the task as complete. This is crucial!
            // We only mark it here if the `expirationHandler` hasn't already done so.
            if !backgroundTaskExpired {
                task.setTaskCompleted(success: success)
                print("[\(Date())] AppBackgroundTaskScheduler: Background task \(task.identifier) completed with success: \(success).")
            }
        }
    }
    
    // MARK: - 6. Error Handling (Integrated throughout) and Notifications
    /// Sends a local user notification to provide feedback on background task status.
    /// - Parameters:
    ///   - title: The title of the notification.
    ///   - body: The body text of the notification.
    ///   - sound: The sound to play with the notification.
    func sendLocalNotification(title: String, body: String, sound: UNNotificationSound) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = sound
        
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil) // nil trigger for immediate notification
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("[\(Date())] AppBackgroundTaskScheduler: Failed to send notification: \(error.localizedDescription)")
            } else {
                print("[\(Date())] AppBackgroundTaskScheduler: Sent notification: '\(title)' - '\(body)'")
            }
        }
    }
}

// MARK: - App Lifecycle Integration (Example in an AppDelegate)
// For SwiftUI 3+ apps, `AppDelegate` functionality is integrated using `@UIApplicationDelegateAdaptor`.

/// Example `AppDelegate` to demonstrate integration points for background tasks.
@available(iOS 18.0, *)
class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Request notification authorization early in the app lifecycle.
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            print("[\(Date())] Notification authorization granted: \(granted), error: \(error?.localizedDescription ?? "nil")")
        }
        
        // Register all background tasks immediately upon app launch.
        AppBackgroundTaskScheduler.shared.registerTasks()
        
        return true
    }
    
    // This method is called when the app is about to enter the background.
    // While background tasks are scheduled by the app, this method is useful
    // for last-minute cleanup or saving state before the app goes dormant.
    func applicationDidEnterBackground(_ application: UIApplication) {
        // For this example, scheduling is triggered by a user action in ContentView.
        // If you had periodic background work, you might schedule it here.
    }
    
    // This method is for handling background URL sessions, not directly for BGTaskScheduler.
    // It's included to show typical AppDelegate methods.
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String, completionHandler: @escaping () -> Void) {
        print("[\(Date())] Handle events for background URL session: \(identifier)")
        completionHandler()
    }
}

// MARK: - Example Usage in a SwiftUI View
// This SwiftUI `ContentView` simulates a "Smart Document Scanner" interface,
// allowing users to trigger the background AI processing. It also displays
// the results of previously processed documents.
@available(iOS 18.0, *)
struct ContentView: View {
    @State private var documentText: String = ""
    @State private var statusMessage: String = "Ready to scan."
    
    // Observe processed documents, updated when the app comes to foreground or refreshes.
    @State private var processedDocuments: [ProcessedDocumentResult] = []
    private let resultStore = DocumentResultStore()
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Smart Document Scanner")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                TextField("Enter document content (simulated)", text: $documentText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                
                Button("Simulate Scan & Process Document") {
                    simulateScanAndScheduleProcessing()
                }
                .buttonStyle(.borderedProminent)
                .padding(.horizontal)
                
                Text(statusMessage)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.top, 5)
                
                Divider()
                
                Text("Processed Documents:")
                    .font(.headline)
                    .padding(.top)
                
                List {
                    ForEach(processedDocuments) { doc in
                        VStack(alignment: .leading) {
                            Text("ID: \(doc.documentID.prefix(8))...")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text("Category: \(doc.category)")
                                .font(.body)
                                .fontWeight(.medium)
                            Text("Confidence: \(String(format: "%.2f", doc.confidence))")
                                .font(.caption)
                            Text("Processed: \(doc.processingDate, formatter: DateFormatter.shortDateTime)")
                                .font(.caption)
                            Text("Text: \(doc.extractedText.prefix(50))...")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                    }
                    .onDelete(perform: deleteDocument)
                }
                // `onAppear` and `refreshable` ensure the UI updates when new background
                // processing results are available or when the user pulls to refresh.
                .onAppear(perform: loadProcessedDocuments)
                .refreshable {
                    loadProcessedDocuments()
                }
            }
            .navigationTitle("")
            .navigationBarHidden(true)
            .onAppear {
                // For demonstration, you might clear old results on app launch
                // resultStore.clearAll()
                loadProcessedDocuments()
            }
        }
    }
    
    /// Simulates a document scan and schedules the AI processing task.
    private func simulateScanAndScheduleProcessing() {
        guard !documentText.isEmpty else {
            statusMessage = "Please enter some document content first."
            return
        }
        
        let currentDocumentID = UUID().uuidString // Generate a fresh ID for each scan
        let documentData = Data(documentText.utf8)
        
        AppBackgroundTaskScheduler.shared.scheduleAIProcessingTask(
            documentData: documentData,
            documentIdentifier: currentDocumentID
        )
        
        statusMessage = "Document '\(currentDocumentID.prefix(8))...' scanned. AI processing scheduled in background."
        documentText = "" // Clear input for next scan
        
        // Refresh the list immediately to show the 'pending' state or just to reflect
        // that a new task has been scheduled (though its result isn't visible yet).
        loadProcessedDocuments()
    }
    
    /// Loads all processed documents from the store to update the UI.
    private func loadProcessedDocuments() {
        processedDocuments = resultStore.fetchAll().sorted(by: { $0.processingDate > $1.processingDate })
        print("[\(Date())] Loaded \(processedDocuments.count) processed documents.")
    }
    
    /// Deletes a processed document from the list and the store.
    private func deleteDocument(at offsets: IndexSet) {
        // This is a simplified deletion. In a real app, you'd need a method
        // to delete by ID from your persistent store.
        let documentsToDelete = offsets.map { processedDocuments[$0] }
        processedDocuments.remove(atOffsets: offsets)
        
        // Re-save the entire list (inefficient but simple for demo purposes with UserDefaults)
        UserDefaults.standard.set(try? JSONEncoder().encode(processedDocuments), forKey: DocumentResultStore.userDefaultsKey)
        
        for doc in documentsToDelete {
            print("[\(Date())] Deleted document: \(doc.documentID)")
        }
    }
}

// Helper for Date Formatting
extension DateFormatter {
    static let shortDateTime: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter
    }()
}

// MARK: - App Entry Point for SwiftUI
@available(iOS 18.0, *)
@main
struct SmartDocumentScannerApp: App {
    // Use @UIApplicationDelegateAdaptor to integrate AppDelegate functionality
    // into the SwiftUI App lifecycle, allowing for background task registration.
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

// MARK: - 

::: {style="text-align: center"}
![The `@UIApplicationDelegateAdaptor` integrates traditional `AppDelegate` functionality, such as background task registration, into a modern SwiftUI App's lifecycle.](images/b4_c15_s3_diag1.png){width=80% caption="The `@UIApplicationDelegateAdaptor` integrates traditional `AppDelegate` functionality, such as background task registration, into a modern SwiftUI App's lifecycle."}
:::


