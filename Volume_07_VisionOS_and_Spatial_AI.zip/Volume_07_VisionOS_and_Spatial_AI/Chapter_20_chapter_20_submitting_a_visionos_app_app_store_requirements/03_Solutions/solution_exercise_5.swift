
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import XCTest

final class AppStoreComplianceTests: XCTestCase {
    
    /// Helper to load a property list from the bundle
    private func loadPlist(named name: String) throws -> [String: Any] {
        guard let url = Bundle.main.url(forResource: name, withExtension: "xcprivacy") ?? 
                        Bundle.main.url(forResource: name, withExtension: "plist") else {
            throw NSError(domain: "ComplianceError", code: 404, userInfo: [NSLocalizedDescriptionKey: "File \(name) not found"])
        }
        let data = try Data(contentsOf: url)
        return try PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] ?? [:]
    }

    /// CRITICAL: Tests for mandatory Privacy Manifest keys
    func testPrivacyManifestCompleteness() throws {
        let manifest = try loadPlist(named: "PrivacyInfo")
        
        // 1. Check for Required Reason APIs
        guard let apiTypes = manifest["NSPrivacyAccessedAPITypes"] as? [[String: Any]] else {
            XCTFail("CRITICAL ERROR: Privacy Manifest is missing 'NSPrivacyAccessedAPITypes'. App Store submission will be rejected.")
            return
        }
        
        // 2. Verify System Boot Time justification
        let hasBootTimeJustification = apiTypes.contains { type in
            guard let name = type["NSPrivacyAccessedAPIType"] as? String,
                  let reasons = type["NSPrivacyAccessedAPITypeReasons"] as? [String] else { return false }
            return name == "System Boot Time" && reasons.contains("NSPrivacyAccessedAPITypeReasonToCalculateSessionDuration")
        }
        
        if !hasBootTimeJustification {
            XCTFail("CRITICAL ERROR: Privacy Manifest is missing the required justification for 'systemBootTime'.")
        }
    }
    
    /// WARNING: Tests for metadata that affects marketing/UX but not rejection
    func testInfoPlistHasSpatialPermissions() throws {
        let infoPlist = try loadPlist(named: "Info")
        
        let cameraDescription = infoPlist["NSCameraUsageDescription"] as? String
        
        if cameraDescription == nil || cameraDescription?.isEmpty == true {
            // We use a warning-style failure here (log instead of hard XCTFail if preferred, 
            // but for this exercise, we use XCTFail to demonstrate the point)
            print("WARNING: NSCameraUsageDescription is missing. User experience will be poor.")
            XCTFail("WARNING: Missing Camera Usage Description.")
        }
    }
    
    /// SIMULATED: Tests for entitlements
    func testEntitlementsForImmersiveSpace() throws {
        // In a real CI/CD, we would inspect the .entitlements file or the compiled Mach-O binary.
        // Here, we simulate the check.
        let simulatedEntitlements = ["com.apple.developer.arkit.scene-reconstruction": true]
        
        let hasSceneReconstruction = simulatedEntitlements["com.apple.developer.arkit.scene-reconstruction"] as? Bool ?? false
        
        if !hasSceneReconstruction {
            XCTFail("CRITICAL ERROR: Missing 'com.apple.developer.arkit.scene-reconstruction' entitlement. Immersive Space will fail to initialize.")
        }
    }
}
