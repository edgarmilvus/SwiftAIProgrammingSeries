
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI

// MARK: - 1. Define Sentiment
@available(iOS 18.0, *)
enum Sentiment: String, CaseIterable, Identifiable {
    case positive = "Positive"
    case neutral = "Neutral"
    case negative = "Negative"
    case unknown = "Unknown"

    var id: String { self.rawValue }

    var displayColor: Color {
        switch self {
        case .positive: return .green
        case .neutral: return .gray
        case .negative: return .red
        case .unknown: return .blue
        }
    }
}

// MARK: - 2. Create an Observable Sentiment Analyzer
@available(iOS 18.0, *)
@Observable
class SentimentAnalyzerViewModel {
    var inputText: String = "" {
        didSet {
            // Only debounce if the text actually changed
            guard inputText != oldValue else { return }
            debounceAnalysis()
        }
    }
    var currentSentiment: Sentiment = .unknown
    var confidence: Double?
    var isAnalyzing: Bool = false
    
    private var debounceTask: Task<Void, Never>?
    private let debounceDelay: Duration = .milliseconds(500) // 0.5 seconds

    /// Manages the debounce logic for sentiment analysis.
    private func debounceAnalysis() {
        // Cancel any previous debounce task to restart the timer
        debounceTask?.cancel()
        
        // Start a new task that will perform analysis after a delay
        debounceTask = Task {
            do {
                isAnalyzing = true // Indicate analysis is starting
                try await Task.sleep(for: debounceDelay)
                
                // Ensure the task hasn't been cancelled before performing analysis
                try Task.checkCancellation()
                
                await _performSentimentAnalysis()
                isAnalyzing = false // Indicate analysis is complete
            } catch is CancellationError {
                // Task was cancelled, do nothing, just reset analysis state
                isAnalyzing = false
            } catch {
                // Handle other potential errors during sleep or analysis
                print("Error during sentiment analysis debounce: \(error)")
                isAnalyzing = false
            }
        }
    }
    
    /// Simulates an AI model call for sentiment analysis.
    @MainActor // Ensure UI updates happen on the main actor
    private func _performSentimentAnalysis() async {
        guard !inputText.isEmpty else {
            currentSentiment = .unknown
            confidence = nil
            return
        }

        let lowercasedText = inputText.lowercased()
        
        // Simulate AI logic based on keywords
        if lowercasedText.contains("happy") || lowercasedText.contains("great") || lowercasedText.contains("love") {
            currentSentiment = .positive
            confidence = Double.random(in: 0.8...0.98)
        } else if lowercasedText.contains("bad") || lowercasedText.contains("sad") || lowercasedText.contains("hate") {
            currentSentiment = .negative
            confidence = Double.random(in: 0.75...0.95)
        } else {
            currentSentiment = .neutral
            confidence = Double.random(in: 0.5...0.7) // Lower confidence for neutral often
        }
        
        // Simulate a brief AI model processing time
        try? await Task.sleep(for: .milliseconds(200))
    }
    
    // Cleanup debounce task if the view model is deallocated
    deinit {
        debounceTask?.cancel()
    }
}

// MARK: - 3. Build the SwiftUI View
@available(iOS 18.0, *)
struct SentimentAnalysisView: View {
    // Instantiate SentimentAnalyzerViewModel using @State
    @State private var viewModel = SentimentAnalyzerViewModel()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Sentiment Analyzer")
                .font(.largeTitle)
                .bold()
                .padding(.bottom, 10)
            
            TextField("Enter your text here...", text: $viewModel.inputText, axis: .vertical)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
                .lineLimit(5, reservesSpace: true) // Allow multiple lines
            
            // Display loading indicator during analysis
            if viewModel.isAnalyzing {
                ProgressView("Analyzing sentiment...")
                    .padding(.vertical)
            } else {
                VStack(spacing: 10) {
                    Text("Sentiment: \(viewModel.currentSentiment.rawValue)")
                        .font(.title2)
                        .bold()
                        .foregroundColor(viewModel.currentSentiment.displayColor)
                        .animation(.easeInOut, value: viewModel.currentSentiment)

                    if let confidence = viewModel.confidence {
                        Gauge(value: confidence, in: 0.0...1.0) {
                            Text("Confidence")
                        } currentLabel: {
                            Text(confidence, format: .percent)
                        }
                        .gaugeStyle(.linearCapacity)
                        .tint(viewModel.currentSentiment.displayColor)
                        .padding(.horizontal)
                        .animation(.easeInOut, value: confidence)
                    } else {
                        Text("Type something to analyze...")
                            .foregroundColor(.gray)
                    }
                }
                .padding(.vertical)
            }
            Spacer()
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.white.opacity(0.05).ignoresSafeArea())
    }
}

// MARK: - Preview Provider
/*
@available(iOS 18.0, *)
#Preview {
    SentimentAnalysisView()
}
*/
