
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import AVFoundation // For audio capture and session management
import SoundAnalysis // For real-time audio analysis with Core ML models
import CoreML      // For loading and configuring Core ML models

// IMPORTANT: For this code to compile and run, you must have a Core ML model
// named 'MyCustomSoundClassifier.mlmodel' added to your Xcode project.
// This model would typically be trained using Create ML from your custom audio data.
// Xcode automatically generates a Swift class (e.g., 'MyCustomSoundClassifier')
// from the .mlmodel file, which we then use to initialize MLSoundClassifier.

/// A service class responsible for detecting custom sound events using MLSoundClassifier
/// and the SoundAnalysis framework. It handles audio input, model loading, and result observation.
@available(iOS 17.0, macOS 14.0, *) // Requires modern SoundAnalysis APIs
class CustomSoundDetector: NSObject, SNResultsObserving {

    // MARK: - Properties

    private let audioEngine = AVAudioEngine()
    private var streamAnalyzer: SNAudioStreamAnalyzer?
    private var classificationRequest: SNClassifySoundRequest?

    /// A closure to be called when a sound classification result is received.
    /// Parameters: (identifier: String, confidence: Double)
    var onClassificationResult: ((String, Double) -> Void)?

    // MARK: - Initialization

    override init() {
        super.init()
        // On iOS, it's crucial to set up the audio session.
        // On macOS, it's often handled implicitly or less strictly for command-line tools,
        // but good practice for GUI apps.
        #if os(iOS)
        setupAudioSession()
        #endif
    }

    // MARK: - Audio Session Setup (iOS Specific)

    #if os(iOS)
    private func setupAudioSession() {
        let audioSession = AVAudioSession.sharedInstance()
        do {
            // Set the audio session category to .record for microphone input.
            // .measurement mode is optimized for low-latency input.
            try audioSession.setCategory(.record, mode: .measurement, options: [])
            // Activate the audio session. This can fail if permissions are not granted.
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            print("❌ Failed to set up audio session: \(error.localizedDescription)")
            // In a real app, you would inform the user and disable functionality.
        }
    }
    #endif

    // MARK: - Core Logic

    /// Starts the audio recording and sound analysis process.
    /// - Throws: An error if the audio engine fails to start, the model cannot be loaded,
    ///   or SoundAnalysis setup encounters an issue.
    func startDetection() throws {
        // 1. Prepare the Audio Engine for Input
        // Get the default input node (e.g., the device's microphone).
        let inputNode = audioEngine.inputNode
        let inputFormat = inputNode.outputFormat(forBus: 0) // Get the format of the input audio.

        // Ensure the input format is valid for SoundAnalysis.
        guard inputFormat.channelCount > 0 else {
            throw CustomSoundDetectorError.audioEngineFailed(
                NSError(domain: "CustomSoundDetector", code: 1, userInfo: [NSLocalizedDescriptionKey: "Audio input node has no channels."])
            )
        }

        // 2. Initialize SoundAnalysis Stream Analyzer
        // This analyzer is the central component for feeding audio buffers to analysis requests.
        // It manages its own threading for efficient processing.
        streamAnalyzer = SNAudioStreamAnalyzer(format: inputFormat)

        // 3. Load the Custom MLSoundClassifier Model
        // This step assumes 'MyCustomSoundClassifier.mlmodel' is compiled into 'MyCustomSoundClassifier.mlmodelc'
        // and included in the app bundle. Xcode handles this automatically when you add the .mlmodel file.
        guard let modelURL = Bundle.main.url(forResource: "MyCustomSoundClassifier", withExtension: "mlmodelc") else {
            throw CustomSoundDetectorError.modelNotFound
        }

        // Core ML models need to be compiled before use. Xcode does this at build time,
        // but for dynamic loading or robustness, you can compile explicitly.
        // If the model is already compiled in the bundle, this step is fast.
        let compiledModelURL = try MLModel.compileModel(at: modelURL)
        let mlModel = try MLModel(contentsOf: compiledModelURL)
        
        // Initialize MLSoundClassifier with the loaded MLModel.
        let soundClassifier = try MLSoundClassifier(mlModel: mlModel)

        // 4. Create a Sound Classification Request
        // This request specifies which Core ML model to use for classification.
        let configuration = MLModelConfiguration()
        // IMPORTANT: Choose the compute units based on your app's needs.
        // .all (default) uses the most performant available (Neural Engine > GPU > CPU).
        // .cpuOnly can be useful for debugging or specific low-power scenarios.
        configuration.computeUnits = .all 
        
        // Create the classification request using the underlying MLModel from our MLSoundClassifier.
        classificationRequest = try SNClassifySoundRequest(mlModel: soundClassifier.model, configuration: configuration)
        
        // Optional: Configure the window duration for analysis.
        // A shorter duration means more frequent, but potentially less accurate, predictions.
        // A longer duration provides more context but slower updates.
        // classificationRequest?.windowDuration = CMTime(seconds: 0.5, preferredTimescale: 1000)

        // 5. Add the Request to the Analyzer and Register as an Observer
        // The analyzer will now process audio and send results for this request to `self`.
        try streamAnalyzer?.add(classificationRequest!, withObserver: self)

        // 6. Install Tap on Input Node to Feed Audio
        // This sets up a callback to receive audio buffers from the microphone.
        // These buffers are then fed into our `streamAnalyzer`.
        inputNode.installTap(onBus: 0, bufferSize: 8192, format: inputFormat) { [weak self] buffer, time in
            // IMPORTANT: This closure is called on a high-priority audio thread.
            // Any heavy processing here can cause audio glitches.
            // Feeding to `SNAudioStreamAnalyzer` is designed to be efficient.
            self?.streamAnalyzer?.analyze(buffer, atAudioFramePosition: time.sampleTime)
        }

        // 7. Start the Audio Engine
        audioEngine.prepare() // Prepares the audio engine for playback/recording.
        try audioEngine.start() // Starts the audio processing graph.
        print("✅ Sound detection started. Listening for custom events...")
    }

    /// Stops the audio recording and sound analysis process, releasing resources.
    func stopDetection() {
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0) // Remove the tap to stop receiving audio.
            print("✅ Audio engine stopped.")
        }
        
        // Remove all requests from the analyzer to stop processing.
        streamAnalyzer?.removeAllRequests()
        streamAnalyzer = nil // Release the analyzer.
        classificationRequest = nil // Release the request.
        print("✅ Sound analysis stopped.")

        #if os(iOS)
        // Deactivate the audio session to free up system resources.
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        } catch {
            print("❌ Failed to deactivate audio session: \(error.localizedDescription)")
        }
        #endif
    }

    // MARK: - SNResultsObserving Protocol Conformance

    /// Called by the SoundAnalysis framework when a classification result is produced.
    /// This method is typically called on a background thread managed by SoundAnalysis.
    /// - Parameters:
    ///   - request: The SNRequest that produced the result.
    ///   - result: The SNResult containing the classification data.
    func request(_ request: SNRequest, didProduce result: SNResult) {
        guard let classificationResult = result as? SNClassificationResult else { return }

        // The classificationResult contains an array of classifications, ordered by confidence.
        // We typically care about the top (most confident) classification.
        guard let topClassification = classificationResult.classifications.first else { return }

        let identifier = topClassification.identifier // The label of the detected sound (e.g., "Clap").
        let confidence = topClassification.confidence // The confidence score (0.0 to 1.0).

        // IMPORTANT: UI updates MUST be dispatched to the main actor.
        // The `request(_:didProduce:)` method is called on a background thread.
        Task { @MainActor in
            self.onClassificationResult?(identifier, confidence)
            // For demonstration, print to console. In a real app, update a UI label.
            print("👂 Detected: \(identifier) with confidence: \(String(format: "%.2f", confidence))")
        }
    }

    /// Called by the SoundAnalysis framework when an error occurs during the processing of a request.
    /// - Parameters:
    ///   - request: The SNRequest that failed.
    ///   - error: The error that occurred.
    func request(_ request: SNRequest, didFailWithError error: Error) {
        print("❌ Sound analysis request failed: \(error.localizedDescription)")
        // In a real app, you would handle this gracefully, perhaps by stopping analysis
        // or attempting to restart.
    }

    /// Called by the SoundAnalysis framework when a request has completed processing all available input.
    /// For continuous analysis (like from a microphone), this might only be called if the request is removed.
    /// - Parameter request: The SNRequest that completed.
    func requestDidComplete(_ request: SNRequest) {
        print("ℹ️ Sound analysis request completed.")
    }
}

// MARK: - Custom Error Type

/// Custom errors specific to the `CustomSoundDetector`.
enum CustomSoundDetectorError: Error, LocalizedError {
    case modelNotFound
    case audioEngineFailed(Error)

    var errorDescription: String? {
        switch self {
        case .modelNotFound:
            return "The custom sound classification model 'MyCustomSoundClassifier.mlmodelc' could not be found in the app bundle. Please ensure it's added to your Xcode project."
        case .audioEngineFailed(let error):
            return "Audio engine operation failed: \(error.localizedDescription)"
        }
    }
}

// MARK: - Usage Example (within a ViewController or App Delegate)

/// A simple coordinator class to demonstrate how CustomSoundDetector would be used
/// within a larger application context (e.g., a ViewController or SwiftUI App struct).
@available(iOS 17.0, macOS 14.0, *)
class AppCoordinator {
    let detector = CustomSoundDetector()

    init() {
        // Set up the result handler. This closure will receive classification updates.
        detector.onClassificationResult = { [weak self] identifier, confidence in
            // This closure is guaranteed to be called on the MainActor due to the
            // `Task { @MainActor in ... }` block inside `request(_:didProduce:)`.
            print("AppCoordinator received classification: \(identifier) (Confidence: \(String(format: "%.2f", confidence)))")
            // In a real app, you would update your UI here, e.g., a label, a progress bar, etc.
            // self?.updateUILabel(text: "Detected: \(identifier) (\(String(format: "%.2f", confidence)))")
        }
    }

    /// Starts the sound monitoring process.
    func startMonitoring() {
        // Request microphone permission first (if not already granted).
        // This is crucial for iOS apps.
        #if os(iOS)
        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
            DispatchQueue.main.async { // Ensure UI updates or further actions are on main thread
                if granted {
                    print("Microphone permission granted.")
                    self?.actuallyStartDetection()
                } else {
                    print("Microphone permission denied. Cannot start sound detection.")
                    // Inform the user and guide them to settings.
                }
            }
        }
        #else // macOS or other platforms
        actuallyStartDetection()
        #endif
    }

    private func actuallyStartDetection() {
        do {
            try detector.startDetection()
            print("Monitoring started successfully by AppCoordinator.")
        } catch {
            print("❌ AppCoordinator failed to start sound detection: \(error.localizedDescription)")
            if let customError = error as? CustomSoundDetectorError {
                print("Custom error detail: \(customError.errorDescription ?? "No description")")
            }
            // Display an alert or error message to the user.
        }
    }

    /// Stops the sound monitoring process.
    func stopMonitoring() {
        detector.stopDetection()
        print("Monitoring stopped by AppCoordinator.")
    }
}

// MARK: - How to Run in a Playground (for quick testing)

/*
// For a Swift Playground, you need to enable indefinite execution to keep the
// audio engine running in the background.
import PlaygroundSupport

@available(iOS 17.0, macOS 14.0, *)
let coordinator = AppCoordinator()

// Start monitoring for sounds.
coordinator.startMonitoring()

// Allow the playground to run indefinitely to capture sounds.
PlaygroundSupport.current.needsIndefiniteExecution = true

// To simulate stopping after a certain duration (e.g., 15 seconds):
DispatchQueue.main.asyncAfter(deadline: .now() + 15) {
    coordinator.stopMonitoring()
    PlaygroundSupport.current.finishExecution() // End playground execution
}
*/

