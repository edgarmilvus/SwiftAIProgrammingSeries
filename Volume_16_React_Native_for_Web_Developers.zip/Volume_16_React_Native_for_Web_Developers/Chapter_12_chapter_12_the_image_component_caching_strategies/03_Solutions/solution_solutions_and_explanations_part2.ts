/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/FeedImage.tsx
import React from 'react';
import { Image } from 'expo-image';
import { View, StyleSheet, Text } from 'react-native';

interface FeedImageProps {
    uri: string;
    index: number; // Used to determine priority
}

export const FeedImage: React.FC<FeedImageProps> = ({ uri, index }) => {
    // 4. Priority Logic: High priority for the first item (above the fold), low for others.
    const priority = index === 0 ? 'high' : 'low';

    return (
        <View style={styles.imageContainer}>
            <Image
                source={{ uri }}
                style={styles.image}
                contentFit="cover"
                
                // 2. Cache Policy
                // 'memory-disk' is preferred over 'memory-only' for feeds because:
                // 1. Memory is volatile and limited; if the user scrolls away and memory is flushed, the image is gone.
                // 2. 'memory-disk' persists images to storage, making re-opening the feed or scrolling back up instant.
                cachePolicy="memory-disk"
                
                // 3. Transition Effect
                // Prevents jarring flashes by fading in the image once ready.
                transition={200} 
                
                // 5. Placeholder
                // Shows a blurred, low-res version of the image (if supported) or a solid color
                placeholder={{ blurhash: 'L6P$~q%MRjof~qofofWB%MofRjRj' }} 
                
                // 4. Priority (Source Property)
                // In expo-image, priority is often passed inside the source object or as a prop depending on version,
                // but standard usage usually implies passing it to the source loader.
                // Here we pass it to the component props (standard in newer versions).
                priority={priority as any} 
            />
            <Text style={styles.badge}>Priority: {priority.toUpperCase()}</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    imageContainer: {
        width: '100%',
        height: 300,
        marginBottom: 20,
        backgroundColor: '#eee',
        position: 'relative',
        borderRadius: 12,
        overflow: 'hidden',
    },
    image: {
        width: '100%',
        height: '100%',
    },
    badge: {
        position: 'absolute',
        top: 10,
        right: 10,
        backgroundColor: 'rgba(0,0,0,0.6)',
        color: 'white',
        paddingVertical: 4,
        paddingHorizontal: 8,
        borderRadius: 4,
        fontSize: 10,
        fontWeight: 'bold',
    }
});
