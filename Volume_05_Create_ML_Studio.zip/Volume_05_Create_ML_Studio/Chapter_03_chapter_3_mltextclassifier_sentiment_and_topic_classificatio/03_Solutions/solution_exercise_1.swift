
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import CoreML // For MLTextClassifier

// MARK: - App Structure (for a runnable SwiftUI app)
@main
struct SentimentAnalyzerApp: App {
    var body: some Scene {
        WindowGroup {
            SentimentAnalyzerView()
        }
    }
}

// MARK: - SentimentAnalyzerView
@available(iOS 18.0, *) // Or the minimum iOS version for your project
struct SentimentAnalyzerView: View {
    @State private var reviewText: String = ""
    @State private var sentimentResult: String = "Enter a review to analyze."

    // Instantiate your ML model. Ensure ReviewSentimentClassifier.mlmodel
    // is correctly added to your Xcode project and target.
    let sentimentClassifier: ReviewSentimentClassifier = {
        do {
            let config = MLModelConfiguration()
            return try ReviewSentimentClassifier(configuration: config)
        } catch {
            // In a real app, you might log this error and disable functionality
            // or show a user-friendly message. fatalError is acceptable for
            // development to quickly catch missing models.
            fatalError("Failed to load ReviewSentimentClassifier: \(error.localizedDescription)")
        }
    }()

    var body: some View {
        NavigationView { // Added NavigationView for better iOS app structure
            VStack {
                TextEditor(text: $reviewText)
                    .frame(height: 150)
                    .border(Color.gray, width: 1)
                    .padding()
                    .accessibilityLabel("Review Input Text Editor")
                    .accessibilityHint("Type or paste your product review here.")

                Button("Analyze Sentiment") {
                    analyzeSentiment()
                }
                .padding()
                .buttonStyle(.borderedProminent) // Modern button style
                .accessibilityLabel("Analyze Sentiment Button")

                Text(sentimentResult)
                    .font(.headline)
                    .padding()
                    .accessibilityLabel("Sentiment Analysis Result")
                    .accessibilityValue(sentimentResult)

                Spacer() // Pushes content to the top
            }
            .navigationTitle("Review Sentiment")
            .navigationBarTitleDisplayMode(.inline) // Compact title
        }
    }

    /// Performs sentiment analysis on the user-entered text using the Core ML model.
    func analyzeSentiment() {
        // Basic input validation
        guard !reviewText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            sentimentResult = "Please enter some text."
            return
        }

        do {
            // Make a prediction using the loaded MLTextClassifier model
            let prediction = try sentimentClassifier.prediction(from: reviewText)
            sentimentResult = "Sentiment: \(prediction.label)"
        } catch {
            // Handle any errors during prediction
            sentimentResult = "Error analyzing sentiment: \(error.localizedDescription)"
            print("Prediction error: \(error)") // Log the detailed error
        }
    }
}
