
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet for Swift Package Manager dependencies
// This illustrates how a standalone framework might declare its dependencies.
// For an app target, CreateML, CoreML, and Vision are system frameworks
// linked directly in Xcode and do not require explicit SwiftPM package declarations.
/*
 import PackageDescription

 let package = Package(
     name: "DocumentClassifierKit",
     platforms: [
         .iOS(.v17), // Specify minimum iOS version supporting Create ML features
         .macOS(.v14) // Specify minimum macOS version
     ],
     products: [
         .library(
             name: "DocumentClassifierKit",
             targets: ["DocumentClassifierKit"]),
     ],
     targets: [
         .target(
             name: "DocumentClassifierKit",
             dependencies: [
                 // CreateML, CoreML, and Vision are system frameworks.
                 // In a typical app, these are linked directly in Xcode.
                 // For a SwiftPM package, they are implicitly available if the platform
                 // supports them, or you might rely on the host app providing them.
                 // No explicit 'package' dependency is needed for system frameworks here.
             ]
         ),
     ]
 )
 */
