
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import AVFoundation

// MARK: - Audio Input Manager

@available(iOS 18.0, *)
class AudioInputManager: ObservableObject {
    private let audioEngine = AVAudioEngine()
    private var inputNode: AVAudioInputNode!
    private var audioFormat: AVAudioFormat!

    @Published var waveformSamples: [Float] = []
    private let displaySampleCount: Int = 200 // Number of aggregated samples to display
    private let aggregationFactor: Int = 10   // Aggregate this many raw samples into one display point

    init() {
        setupAudioSession()
        setupAudioEngine()
    }

    private func setupAudioSession() {
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.playAndRecord, mode: .measurement, options: [.mixWithOthers, .allowBluetoothA2DP, .defaultToSpeaker])
            try audioSession.setActive(true)
        } catch {
            print("Failed to set up audio session: \(error.localizedDescription)")
        }
    }

    private func setupAudioEngine() {
        inputNode = audioEngine.inputNode
        audioFormat = inputNode.outputFormat(forBus: 0)

        // Request microphone permission
        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
            guard granted else {
                print("Microphone permission denied.")
                return
            }
            self?.installAudioTap()
        }
    }

    private func installAudioTap() {
        // Buffer size (1024 frames) is a common choice for real-time processing
        let bufferSize: AVAudioFrameCount = 1024
        inputNode.installTap(onBus: 0, bufferSize: bufferSize, format: audioFormat) { [weak self] buffer, _ in
            self?.processAudioBuffer(buffer)
        }
    }

    private func processAudioBuffer(_ buffer: AVAudioPCMBuffer) {
        guard let channelData = buffer.floatChannelData else { return }
        let samples = channelData[0] // Assuming mono or left channel for visualization
        let frameLength = Int(buffer.frameLength)

        var newAggregatedSamples: [Float] = []
        for i in 0..<frameLength / aggregationFactor {
            var maxAmplitude: Float = 0.0
            for j in 0..<aggregationFactor {
                let sampleIndex = i * aggregationFactor + j
                guard sampleIndex < frameLength else { break }
                let sample = abs(samples[sampleIndex])
                if sample > maxAmplitude {
                    maxAmplitude = sample
                }
            }
            newAggregatedSamples.append(maxAmplitude)
        }

        // Update UI on the main thread
        DispatchQueue.main.async {
            self.waveformSamples.append(contentsOf: newAggregatedSamples)
            // Keep only the most recent samples for the fixed-size display window
            if self.waveformSamples.count > self.displaySampleCount {
                self.waveformSamples.removeFirst(self.waveformSamples.count - self.displaySampleCount)
            }
        }
    }

    func start() {
        do {
            try audioEngine.start()
            print("Audio engine started.")
        } catch {
            print("Error starting audio engine: \(error.localizedDescription)")
        }
    }

    func stop() {
        audioEngine.stop()
        inputNode.removeTap(onBus: 0)
        print("Audio engine stopped and tap removed.")
    }

    deinit {
        stop()
    }
}

// MARK: - SwiftUI Waveform View

@available(iOS 18.0, *)
struct BasicWaveformView: View {
    let samples: [Float]

    var body: some View {
        GeometryReader { geometry in
            Path { path in
                guard !samples.isEmpty else { return }

                let width = geometry.size.width
                let height = geometry.size.height
                let midY = height / 2

                // Calculate vertical scaling factor based on max amplitude
                // Ensures waveform fills vertical space without clipping excessively
                let maxAmplitude: Float = samples.max() ?? 1.0 // Default to 1.0 to avoid division by zero
                let verticalScale = (maxAmplitude > 0.01) ? (height / 2) / maxAmplitude : 0.0 // Prevent extreme scaling for silence

                path.move(to: CGPoint(x: 0, y: midY)) // Start at the middle-left

                for i in 0..<samples.count {
                    let x = CGFloat(i) / CGFloat(samples.count - 1) * width
                    // Scale amplitude and invert Y for drawing (higher amplitude = higher on screen)
                    let y = midY - CGFloat(samples[i]) * verticalScale
                    path.addLine(to: CGPoint(x: x, y: y))
                }
            }
            .stroke(Color.blue, lineWidth: 2) // Default stroke
        }
        .frame(height: 100) // Fixed height for the waveform
        .background(Color.black.opacity(0.8))
        .cornerRadius(8)
    }
}

// MARK: - Main Content View

@available(iOS 18.0, *)
struct ContentView: View {
    @StateObject private var audioManager = AudioInputManager()
    @State private var isRecording = false

    var body: some View {
        VStack {
            Text("Real-Time Waveform")
                .font(.largeTitle)
                .padding()

            BasicWaveformView(samples: audioManager.waveformSamples)
                .padding()

            Button(action: toggleRecording) {
                Label(isRecording ? "Stop Recording" : "Start Recording", systemImage: isRecording ? "stop.fill" : "mic.fill")
                    .font(.title2)
                    .padding()
                    .background(isRecording ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(15)
            }
            .padding()
        }
        .onAppear {
            // Start audio capture automatically, or keep it manual via button
            // audioManager.start()
        }
        .onDisappear {
            audioManager.stop()
        }
    }

    private func toggleRecording() {
        if isRecording {
            audioManager.stop()
        } else {
            audioManager.start()
        }
        isRecording.toggle()
    }
}
