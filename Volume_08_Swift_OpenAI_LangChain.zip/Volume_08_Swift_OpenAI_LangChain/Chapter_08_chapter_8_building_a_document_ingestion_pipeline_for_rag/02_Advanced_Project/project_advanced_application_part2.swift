
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import PDFKit
import Vision
import UniformTypeIdentifiers
import OSLog

/// Represents a single, atomic unit of information ready for vector storage.
/// Conforms to `Sendable` to safely pass across concurrency boundaries.
public struct DocumentChunk: Sendable, Identifiable {
    public let id: UUID
    public let text: String
    public let embedding: [Float]?
    public let metadata: [String: String]
    
    public init(id: UUID = UUID(), text: String, embedding: [Float]? = nil, metadata: [String: String]) {
        self.id = id
        self.text = text
        self.embedding = embedding
        self.metadata = metadata
    }
}

/// Custom errors specific to the ingestion pipeline.
public enum IngestionError: Error, LocalizedError {
    case unsupportedFileType(UTType)
    case extractionFailed(String)
    case embeddingFailed(Error)
    case emptyDocument
    
    public var errorDescription: String? {
        switch self {
        case .unsupportedFileType(let type): return "The file type \(type.description) is not supported."
        case .extractionFailed(let reason): return "Failed to extract text: \(reason)"
        case .embeddingFailed(let error): return "Embedding generation failed: \(error.localizedDescription)"
        case .emptyDocument: return "The document contains no readable text."
        }
    }
}

/// The `DocumentIngestionEngine` is an actor that manages the complex, 
/// multi-stage process of converting files into searchable vector chunks.
/// Being an actor ensures that multiple ingestion requests do not cause 
/// data races when managing internal state or shared resources.
@available(iOS 18.0, macOS 15.0, *)
public actor DocumentIngestionEngine {
    
    private let logger = Logger(subsystem: "com.ai.ingestion", category: "Pipeline")
    
    // Configuration for the chunking strategy
    private let maxChunkSize: Int
    private let chunkOverlap: Int
    
    /// Initializes the engine with specific chunking parameters.
    /// - Parameters:
    ///   - maxChunkSize: The maximum number of characters per chunk.
    ///   - chunkOverlap: The number of characters to overlap between adjacent chunks.
    public init(maxChunkSize: Int = 1000, chunkOverlap: Int = 200) {
        self.maxChunkSize = maxChunkSize
        self.chunkOverlap = chunkOverlap
    }
    
    /// The primary entry point for the ingestion pipeline.
    /// - Parameter url: The local file URL of the document to ingest.
    /// - Returns: An array of `DocumentChunk` objects ready for a vector database.
    public func ingest(fileURL: URL) async throws -> [DocumentChunk] {
        logger.info("Starting ingestion for: \(fileURL.lastPathComponent)")
        
        // 1. Identify File Type
        guard let type = UTType(filenameExtension: fileURL.pathExtension) else {
            throw IngestionError.unsupportedFileType(.data)
        }
        
        // 2. Extract Content (Multi-modal)
        let rawPages = try await extractPages(from: fileURL, type: type)
        
        guard !rawPages.isEmpty else {
            throw IngestionError.emptyDocument
        }
        
        // 3. Process, Chunk, and Enrich
        let chunks = try await processPages(rawPages, sourceName: fileURL.lastPathComponent)
        
        // 4. Generate Embeddings (Batch Processing)
        let embeddedChunks = try await generateEmbeddings(for: chunks)
        
        logger.info("Ingestion complete. Created \(embeddedChunks.count) chunks.")
        return embeddedChunks
    }
    
    // MARK: - Private Pipeline Stages
    
    /// Stage 1 & 2: Extraction. Handles PDFKit and Vision OCR.
    private func extractPages(from url: URL, type: UTType) async throws -> [String] {
        if type == .pdf {
            return try await processPDF(url: url)
        } else if type == .image || type == .jpeg || type == .png {
            return try await processImage(url: url)
        } else {
            throw IngestionError.unsupportedFileType(type)
        }
    }
    
    /// Specialized PDF extraction using PDFKit.
    private func processPDF(url: URL) async throws -> [String] {
        guard let document = PDFDocument(url: url) else {
            throw IngestionError.extractionFailed("Could not open PDF document.")
        }
        
        var pageTexts: [String] = []
        let pageCount = document.pageCount
        
        // Use a TaskGroup to process PDF pages in parallel
        try await withThrowingTaskGroup(of: (Int, String).self) { group in
            for i in 0..<pageCount {
                group.addTask {
                    guard let page = document.page(at: i) else { return (i, "") }
                    
                    // Attempt standard text extraction
                    let text = page.string ?? ""
                    
                    // If text is too short, it might be a scanned page; trigger OCR
                    if text.trimmingCharacters(in: .whitespacesAndNewlines).count < 10 {
                        let ocrText = try await self.performOCR(on: page)
                        return (i, ocrText)
                    }
                    
                    return (i, text)
                }
            }
            
            // Collect results and sort by page index to maintain document order
            var results: [(Int, String)] = []
            for try await result in group {
                results.append(result)
            }
            results.sort { $0.0 < $1.0 }
            pageTexts = results.map { $0.1 }
        }
        
        return pageTexts
    }
    
    /// Stage 2 (Cont.): OCR via Vision Framework for scanned images or PDF pages.
    private func performOCR(on page: PDFPage) async throws -> String {
        // In a real implementation, we would convert the PDFPage to a CGImage
        // and pass it to VNRecognizeTextRequest.
        // For brevity in this example, we simulate the Vision call.
        try await Task.sleep(for: .milliseconds(100)) 
        return "[OCR Extracted Text Placeholder]" 
    }
    
    private func processImage(url: URL) async throws -> [String] {
        // Implementation of Vision-based OCR for single images
        return ["Extracted image text..."]
    }
    
    /// Stage 3 & 4: Normalization and Chunking.
    /// This implements a sliding window algorithm to ensure semantic continuity.
    private func processPages(_ pages: [String], sourceName: String) async throws -> [DocumentChunk] {
        var allChunks: [DocumentChunk] = []
        
        for (index, pageText) in pages.enumerated() {
            let cleanedText = normalize(pageText)
            let pageNumber = index + 1
            
            // Sliding Window Chunking
            var start = 0
            while start < cleanedText.count {
                let end = min(start + maxChunkSize, cleanedText.count)
                let chunkText = String(cleanedText[cleanedText.startIndex..<cleanedText.index(cleanedText.startIndex, offsetBy: end)])
                
                let metadata = [
                    "source": sourceName,
                    "page": "\(pageNumber)",
                    "chunk_index": "\(allChunks.count)"
                ]
                
                allChunks.append(DocumentChunk(text: chunkText, metadata: metadata))
                
                // Move the window forward, but subtract the overlap
                if end == cleanedText.count { break }
                start += (maxChunkSize - chunkOverlap)
            }
        }
        
        return allChunks
    }
    
    /// Cleans text by removing excessive whitespace and normalizing Unicode.
    private func normalize(_ text: String) -> String {
        return text.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
            .joined(separator: " ")
            .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
    }
    
    /// Stage 5: Embedding Generation.
    /// Uses Swift Concurrency to batch process chunks through an LLM API.
    private func generateEmbeddings(for chunks: [DocumentChunk]) async throws -> [DocumentChunk] {
        // In production, we would use a specialized service or OpenAI API.
        // We use a TaskGroup to process chunks in parallel, respecting a concurrency limit.
        
        return try await withThrowingTaskGroup(of: DocumentChunk.self) { group in
            // We limit concurrency to 5 to avoid hitting API rate limits too hard
            let maxConcurrentRequests = 5
            var currentRequests = 0
            var results: [DocumentChunk] = []
            
            // This is a simplified version of a semaphore-controlled task group
            for chunk in chunks {
                group.addTask {
                    let vector = try await self.callEmbeddingAPI(for: chunk.text)
                    return DocumentChunk(
                        id: chunk.id,
                        text: chunk.text,
                        embedding: vector,
                        metadata: chunk.metadata
                    )
                }
            }
            
            for try await completedChunk in group {
                results.append(completedChunk)
            }
            
            // Note: Because TaskGroup results return in completion order, 
            // we must re-sort based on metadata index to maintain document order.
            return results.sorted { 
                Int($0.metadata["chunk_index"] ?? "0")! < Int($1.metadata["chunk_index"] ?? "0")! 
            }
        }
    }
    
    /// Mock function representing a network call to an embedding model (e.g., OpenAI).
    private func callEmbeddingAPI(for text: String) async throws -> [Float] {
        // Simulate network latency
        try await Task.sleep(for: .milliseconds(50))
        // Return a dummy 1536-dimensional vector (standard for OpenAI)
        return (0..<1536).map { _ in Float.random(in: -1...1) }
    }
}

// MARK: - Usage Example

@available(iOS 18.0, macOS 15.0, *)
@MainActor
struct IngestionViewModel: ObservableObject {
    @Published var isProcessing = false
    @Published var progress: Double = 0.0
    @Published var statusMessage = "Ready"
    
    private let engine = DocumentIngestionEngine()
    
    func handleFileSelection(url: URL) {
        Task {
            isProcessing = true
            statusMessage = "Analyzing document..."
            
            do {
                let chunks = try await engine.ingest(fileURL: url)
                statusMessage = "Successfully ingested \(chunks.count) chunks."
                // Here, you would send 'chunks' to your Vector Database (e.g., Pinecone, Milvus, or local SQLite-VSS)
                print("First chunk text: \(chunks.first?.text ?? "None")")
            } catch {
                statusMessage = "Error: \(error.localizedDescription)"
            }
            
            isProcessing = false
        }
    }
}
