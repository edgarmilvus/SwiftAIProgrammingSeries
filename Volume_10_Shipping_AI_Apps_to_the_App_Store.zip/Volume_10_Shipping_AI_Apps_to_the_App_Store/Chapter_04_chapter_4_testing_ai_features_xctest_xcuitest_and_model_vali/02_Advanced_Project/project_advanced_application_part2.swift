
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreML
import Vision
import OSLog

/// Represents the types of documents our AI can recognize.
enum DocumentType: String, Codable, Sendable, CaseIterable {
    case receipt
    case identityCard
    case invoice
    case unknown
}

/// Errors specific to the Intelligence Engine.
enum IntelligenceError: Error, LocalizedError {
    case modelLoadingFailed
    case inferenceFailed(String)
    case invalidInputImage
    
    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed: return "Failed to initialize the CoreML model."
        case .inferenceFailed(let reason): return "Inference error: \(reason)"
        case .invalidInputImage: return "The provided image is invalid or corrupt."
        }
    }
}

/// A result object containing the classification and the confidence score.
struct ClassificationResult: Sendable {
    let type: DocumentType
    let confidence: Float
}

/// The primary service responsible for document classification.
/// Designed with Swift 6 concurrency in mind.
@available(iOS 18.0, *)
final actor DocumentIntelligenceEngine {
    private let logger = Logger(subsystem: "com.ai.app", category: "IntelligenceEngine")
    private var model: VNCoreMLModel?
    
    init(modelConfiguration: MLModelConfiguration = MLModelConfiguration()) throws {
        // In a real app, you would load your specific .mlmodel here.
        // For this demonstration, we assume the model is loaded.
        // let model = try MyDocumentClassifier(configuration: modelConfiguration).model
        // self.model = try VNCoreMLModel(for: model)
    }
    
    /// Classifies an image using the on-device Vision framework.
    /// - Parameter image: The pixel buffer or image to analyze.
    /// - Returns: A `ClassificationResult` containing the type and confidence.
    /// - Throws: `IntelligenceError` if inference fails.
    func classify(image: CGImage) async throws -> ClassificationResult {
        guard let model = model else {
            throw IntelligenceError.modelLoadingFailed
        }
        
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNCoreMLRequest(model: model) { request, error in
                if let error = error {
                    continuation.resume(throwing: IntelligenceError.inferenceFailed(error.localizedDescription))
                    return
                }
                
                guard let results = request.results as? [VNClassificationObservation],
                      let topResult = results.first else {
                    continuation.resume(throwing: IntelligenceError.inferenceFailed("No results found"))
                    return
                }
                
                // Map Vision labels to our internal DocumentType
                let type = DocumentType(rawValue: topResult.identifier) ?? .unknown
                let result = ClassificationResult(type: type, confidence: topResult.confidence)
                continuation.resume(returning: result)
            }
            
            request.imageCropAndScaleOption = .centerCrop
            
            let handler = VNImageRequestHandler(cgImage: image, options: [:])
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: IntelligenceError.inferenceFailed(error.localizedDescription))
            }
        }
    }
}
