
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreData
import NaturalLanguage
import Accelerate

/// Represents a unique identifier for a searchable document.
typealias DocumentID = UUID

/// Errors specific to the Hybrid Search process.
enum SearchError: Error, LocalizedError {
    case providerFailure(String)
    case embeddingGenerationFailed
    case fusionError
    case invalidQuery

    var errorDescription: String? {
        switch self {
        case .providerFailure(let msg): return "Search provider failed: \(msg)"
        case .embeddingGenerationFailed: return "Failed to generate vector embeddings."
        case .fusionError: return "Error during rank fusion calculation."
        case .invalidQuery: return "The search query is empty or invalid."
        }
    }
}

/// A protocol defining the requirements for a search provider.
/// Using `Sendable` to ensure compatibility with Swift 6 concurrency.
protocol SearchProvider: Sendable {
    /// Returns a list of document IDs ranked by relevance.
    func search(query: String) async throws -> [(id: DocumentID, score: Double)]
}

/// A mock implementation of a Lexical (FTS) Search Provider.
/// In production, this would wrap a CoreData `NSFetchRequest` using FTS5.
final class LexicalSearchProvider: SearchProvider, @unchecked Sendable {
    func search(query: String) async throws -> [(id: DocumentID, score: Double)] {
        // Simulate network/disk latency
        try await Task.sleep(for: .milliseconds(50))
        
        // Simulated FTS results: (ID, BM25 Score)
        // In reality, this comes from: SELECT id, score FROM notes_fts WHERE notes_fts MATCH 'query'
        return [
            (DocumentID(), 12.5),
            (DocumentID(), 8.2),
            (DocumentID(), 4.1)
        ]
    }
}

/// A mock implementation of a Semantic (Vector) Search Provider.
/// In production, this would use Apple's `NLEmbedding` and a vector similarity engine.
final class SemanticSearchProvider: SearchProvider, @unchecked Sendable {
    func search(query: String) async throws -> [(id: DocumentID, score: Double)] {
        // Simulate embedding generation and vector similarity search
        try await Task.sleep(for: .milliseconds(120))
        
        // Simulated Vector results: (ID, Cosine Similarity)
        return [
            (DocumentID(), 0.95),
            (DocumentID(), 0.88),
            (DocumentID(), 0.72)
        ]
    }
}

/// The `HybridSearchEngine` is the central orchestrator.
/// It is implemented as an `actor` to protect its internal state and 
/// ensure thread-safe access to search providers in a concurrent environment.
@available(iOS 18.0, *)
actor HybridSearchEngine {
    
    private let lexicalProvider: any SearchProvider
    private let semanticProvider: any SearchProvider
    
    /// The constant 'k' used in Reciprocal Rank Fusion.
    /// A value of 60 is standard in academic literature (e.g., Cormack et al.).
    private let rrfK: Double = 60.0
    
    /// Initializes the engine with specific providers.
    /// - Parameters:
    ///   - lexical: The provider responsible for keyword/FTS search.
    ///   - semantic: The provider responsible for vector/embedding search.
    init(lexical: any SearchProvider, semantic: any SearchProvider) {
        self.lexicalProvider = lexical
        self.semanticProvider = semantic
    }
    
    /// Performs a hybrid search by combining lexical and semantic results.
    /// This function utilizes Swift 6 structured concurrency to run providers in parallel.
    /// - Parameter query: The raw string entered by the user.
    /// - Returns: A list of Document IDs sorted by their fused RRF score.
    func search(query: String) async throws -> [DocumentID] {
        guard !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw SearchError.invalidQuery
        }
        
        // Use a TaskGroup to execute both search types concurrently.
        // This minimizes total latency to the duration of the slowest provider.
        let (lexicalResults, semanticResults) = try await withThrowingTaskGroup(
            of: SearchResultType.self
        ) { group in
            
            group.addTask {
                let results = try await self.lexicalProvider.search(query: query)
                return .lexical(results)
            }
            
            group.addTask {
                let results = try await self.semanticProvider.search(query: query)
                return .semantic(results)
            }
            
            var lex: [(id: DocumentID, score: Double)] = []
            var sem: [(id: DocumentID, score: Double)] = []
            
            while let result = try await group.next() {
                switch result {
                case .lexical(let r): lex = r
                case .semantic(let s): sem = s
                }
            }
            
            return (lex, sem)
        }
        
        return try performRRF(lexical: lexicalResults, semantic: semanticResults)
    }
    
    /// Internal enum to categorize task group results.
    private enum SearchResultType {
        case lexical([(id: DocumentID, score: Double)])
        case semantic([(id: DocumentID, score: Double)])
    }
    
    /// Implements the Reciprocal Rank Fusion algorithm.
    /// This merges two differently scaled result sets into a single ranked list.
    /// - Parameters:
    ///   - lexical: The ranked list from the FTS provider.
    ///   - semantic: The ranked list from the Vector provider.
    /// - Returns: An array of DocumentIDs sorted by fusion score.
    private func performRRF(
        lexical: [(id: DocumentID, score: Double)],
        semantic: [(id: DocumentID, score: Double)]
    ) throws -> [DocumentID] {
        
        /// A dictionary to accumulate RRF scores for each document.
        /// Key: DocumentID, Value: Accumulated RRF Score.
        var fusedScores: [DocumentID: Double] = [:]
        
        // Process Lexical Results
        // rank is 1-based index.
        for (index, result) in lexical.enumerated() {
            let rank = Double(index + 1)
            let rrfScore = 1.0 / (rrfK + rank)
            fusedScores[result.id, default: 0.0] += rrfScore
        }
        
        // Process Semantic Results
        for (index, result) in semantic.enumerated() {
            let rank = Double(index + 1)
            let rrfScore = 1.0 / (rrfK + rank)
            fusedScores[result.id, default: 0.0] += rrfScore
        }
        
        // If no results were found in either, return empty.
        if fusedScores.isEmpty { return [] }
        
        // Sort the dictionary by the accumulated score in descending order.
        let sortedIDs = fusedScores.sorted { $0.value > $1.value }.map { $0.key }
        
        return sortedIDs
    }
}

// MARK: - Example Usage in a View Model

@MainActor
class SearchViewModel: ObservableObject {
    @Published var results: [DocumentID] = []
    @Published var isSearching: Bool = false
    @Published var errorMessage: String?
    
    private let engine: HybridSearchEngine
    private var searchTask: Task<Void, Never>?
    
    init(engine: HybridSearchEngine) {
        self.engine = engine
    }
    
    /// Triggered by the UI as the user types.
    /// Implements debouncing to prevent overwhelming the engine.
    func updateQuery(_ query: String) {
        searchTask?.cancel()
        
        searchTask = Task {
            // Debounce: Wait 300ms before executing search
            try? await Task.sleep(for: .milliseconds(300))
            
            if Task.isCancelled { return }
            
            isSearching = true
            errorMessage = nil
            
            do {
                let foundIDs = try await engine.search(query: query)
                self.results = foundIDs
            } catch {
                self.errorMessage = error.localizedDescription
            }
            
            isSearching = false
        }
    }
}
