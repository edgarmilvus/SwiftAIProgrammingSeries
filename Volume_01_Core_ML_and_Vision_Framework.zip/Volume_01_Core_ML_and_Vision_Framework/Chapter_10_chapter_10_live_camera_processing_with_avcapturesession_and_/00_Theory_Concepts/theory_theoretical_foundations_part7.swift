
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part7.swift
// Description: Theoretical Foundations
// ==========================================

// Assuming CameraProcessingActor from above
@available(iOS 18.0, *)
@Observable
class CameraViewModel {
    var detectedObject: String = "No detection"
    var framesProcessed: Int = 0

    private let processor: CameraProcessingActor

    init(processor: CameraProcessingActor) {
        self.processor = processor
        // Start a task to periodically fetch updates from the actor
        Task { @MainActor in // Ensure UI updates are on main actor
            for await _ in Every(.seconds(0.1)) { // Custom async sequence for polling
                self.detectedObject = await processor.currentDetection ?? "No detection"
                self.framesProcessed = await processor.currentFrameCount
            }
        }
    }
}

// In a SwiftUI View:
@available(iOS 18.0, *)
struct CameraView: View {
    @State private var cameraProcessor = CameraProcessingActor()
    @State private var viewModel: CameraViewModel // Initialized in .onAppear or similar

    var body: some View {
        VStack {
            Text("Detected: \(viewModel.detectedObject)")
            Text("Frames: \(viewModel.framesProcessed)")
            // ... Camera preview layer ...
        }
        .onAppear {
            // Setup AVCaptureSession and its delegate here
            // The delegate will pass frames to cameraProcessor actor
            self.viewModel = CameraViewModel(processor: cameraProcessor)
        }
    }
}
