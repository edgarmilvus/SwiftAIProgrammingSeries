
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import MLX
import MLXNN // For MLXNN.Module, MLXNN.Linear, MLXNN.LayerNorm, MLXNN.Embedding
import MLXOptimizers // For Adam optimizer
import MLXRandom // For mlx.random

@available(iOS 18.0, macOS 15.0, *)
class MaskedMultiHeadSelfAttention: MLXNN.Module {
    let queryProjection: MLXNN.Linear
    let keyProjection: MLXNN.Linear
    let valueProjection: MLXNN.Linear
    let outputProjection: MLXNN.Linear
    let numHeads: Int
    let headDimension: Int

    init(modelDimension: Int, numHeads: Int, keyQueryValueBias: Bool = true) {
        precondition(modelDimension % numHeads == 0, "modelDimension must be divisible by numHeads")
        self.numHeads = numHeads
        self.headDimension = modelDimension / numHeads

        self.queryProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension, bias: keyQueryValueBias)
        self.keyProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension, bias: keyQueryValueBias)
        self.valueProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension, bias: keyQueryValueBias)
        self.outputProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray, mask: MLXArray? = nil) -> MLXArray {
        let batchSize = x.shape[0]
        let sequenceLength = x.shape[1]

        let q = queryProjection(x)
        let k = keyProjection(x)
        let v = valueProjection(x)

        let q_heads = q.reshaped([batchSize, sequenceLength, numHeads, headDimension]).transposed(0, 2, 1, 3)
        let k_heads = k.reshaped([batchSize, sequenceLength, numHeads, headDimension]).transposed(0, 2, 1, 3)
        let v_heads = v.reshaped([batchSize, sequenceLength, numHeads, headDimension]).transposed(0, 2, 1, 3)

        var scores = mlx.core.matmul(q_heads, k_heads.transposed(0, 1, 3, 2))
        scores = scores / MLXArray(Float(headDimension).squareRoot())

        // Apply mask if provided.
        // The mask typically contains large negative values (-infinity) where attention should be prevented.
        // Adding -infinity before softmax effectively zeros out those attention weights.
        if let mask = mask {
            // The mask should be broadcastable to [batchSize, numHeads, sequenceLength, sequenceLength]
            // A causal mask is typically [1, 1, sequenceLength, sequenceLength]
            scores = scores + (mask * MLXArray(Float.greatestFiniteMagnitude) * MLXArray(-1.0))
        }

        let attentionWeights = mlx.core.softmax(scores, axis: -1)
        let outputHeads = mlx.core.matmul(attentionWeights, v_heads)

        let concatenatedOutput = outputHeads.transposed(0, 2, 1, 3).reshaped([batchSize, sequenceLength, numHeads * headDimension])
        let finalOutput = outputProjection(concatenatedOutput)

        return finalOutput
    }
}

@available(iOS 18.0, macOS 15.0, *)
class FeedForward: MLXNN.Module {
    let linear1: MLXNN.Linear
    let linear2: MLXNN.Linear

    init(modelDimension: Int, innerDimension: Int) {
        self.linear1 = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: innerDimension)
        self.linear2 = MLXNN.Linear(inputDimensions: innerDimension, outputDimensions: modelDimension)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // Apply GELU activation, a common choice in Transformers.
        return linear2(mlx.core.gelu(linear1(x)))
    }
}

@available(iOS 18.0, macOS 15.0, *)
class TransformerDecoderBlock: MLXNN.Module {
    let selfAttention: MaskedMultiHeadSelfAttention
    let norm1: MLXNN.LayerNorm
    let feedForward: FeedForward
    let norm2: MLXNN.LayerNorm

    init(modelDimension: Int, numHeads: Int, innerDimension: Int) {
        self.selfAttention = MaskedMultiHeadSelfAttention(modelDimension: modelDimension, numHeads: numHeads)
        self.norm1 = MLXNN.LayerNorm(dimensions: modelDimension)
        self.feedForward = FeedForward(modelDimension: modelDimension, innerDimension: innerDimension)
        self.norm2 = MLXNN.LayerNorm(dimensions: modelDimension)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray, mask: MLXArray? = nil) -> MLXArray {
        // First sub-layer: LayerNorm -> Masked Self-Attention -> Residual Connection
        var output = norm1(x)
        output = output + selfAttention(output, mask: mask) // Skip connection

        // Second sub-layer: LayerNorm -> Feed-Forward -> Residual Connection
        output = norm2(output)
        output = output + feedForward(output) // Skip connection

        return output
    }
}

// --- Training Loop Example ---
@available(iOS 18.0, macOS 15.0, *)
func runAutocompleteTraining() {
    let vocabSize = 10 // e.g., tokens 0-9
    let modelDimension = 64
    let numHeads = 4
    let innerDimension = 128
    let maxSequenceLength = 5 // Max length of input sequence for training
    let learningRate: Float = 1e-3
    let numIterations = 1000
    let batchSize = 32

    // 1. Model Definition
    class AutocompleteModel: MLXNN.Module {
        let embedding: MLXNN.Embedding
        let positionalEncoding: SinusoidalPositionalEncoding
        let decoderBlock: TransformerDecoderBlock
        let outputLinear: MLXNN.Linear // Projects decoder output to vocabulary size

        init(vocabSize: Int, modelDimension: Int, numHeads: Int, innerDimension: Int, maxSequenceLength: Int) {
            self.embedding = MLXNN.Embedding(outputDimensions: modelDimension, inputDimensions: vocabSize)
            self.positionalEncoding = SinusoidalPositionalEncoding(maxSequenceLength: maxSequenceLength, modelDimension: modelDimension)
            self.decoderBlock = TransformerDecoderBlock(modelDimension: modelDimension, numHeads: numHeads, innerDimension: innerDimension)
            self.outputLinear = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: vocabSize)
            super.init()
        }

        override func callAsFunction(_ x: MLXArray, mask: MLXArray? = nil) -> MLXArray {
            // x: [batchSize, currentSequenceLength] (token IDs)
            let embedded = embedding(x) // [batchSize, currentSequenceLength, modelDimension]
            let positioned = positionalEncoding(embedded) // Add positional info
            let decoded = decoderBlock(positioned, mask: mask) // Process through decoder block
            return outputLinear(decoded) // Logits for each token in sequence
        }
    }

    let model = AutocompleteModel(vocabSize: vocabSize, modelDimension: modelDimension, numHeads: numHeads, innerDimension: innerDimension, maxSequenceLength: maxSequenceLength)
    let optimizer = MLXOptimizers.Adam(learningRate: learningRate)

    // 2. Data Generation (Simple Next-Token Prediction)
    // Generates sequences like [1, 2, 3] -> predict [2, 3, 4]
    func generateBatch(batchSize: Int, sequenceLength: Int, vocabSize: Int) -> (MLXArray, MLXArray) {
        var inputs: [MLXArray] = []
        var targets: [MLXArray] = []

        for _ in 0..<batchSize {
            // Ensure sequences don't exceed vocabSize when incrementing
            let startToken = Int.random(in: 0..<(vocabSize - sequenceLength + 1))
            let sequence = mlx.core.arange(Float(startToken), Float(startToken + sequenceLength), dtype: MLXArray.DType.int32)
            let inputSequence = sequence[0 ..< sequenceLength - 1] // e.g., [1, 2, 3]
            let targetSequence = sequence[1 ..< sequenceLength]     // e.g., [2, 3, 4]
            inputs.append(inputSequence)
            targets.append(targetSequence)
        }
        return (mlx.core.stack(inputs), mlx.core.stack(targets))
    }

    // 3. Causal Mask Generation
    func createCausalMask(sequenceLength: Int) -> MLXArray {
        // Create an upper triangular matrix of ones, then invert and scale to -infinity.
        // `triu(ones, k: 1)` creates a mask where values above the main diagonal are 1, rest 0.
        // This effectively masks out future tokens (prevents attention to them).
        // Example for sequenceLength = 4:
        // [[0, 1, 1, 1],
        //  [0, 0, 1, 1],
        //  [0, 0, 0, 1],
        //  [0, 0, 0, 0]]
        let ones = MLXArray.ones([sequenceLength, sequenceLength], dtype: MLXArray.DType.float32)
        let mask = mlx.core.triu(ones, k: 1) // Upper triangle (excluding diagonal) is 1, rest 0
        // Expand dimensions to be broadcastable to [batchSize, numHeads, sequenceLength, sequenceLength]
        return mask.expandedDimensions(axes: [0, 1]) // Shape: [1, 1, sequenceLength, sequenceLength]
    }

    // The input sequence length for the decoder block will be `maxSequenceLength - 1`
    // because we are predicting the next token, so the last input token doesn't have a target.
    let causalMask = createCausalMask(sequenceLength: maxSequenceLength - 1)

    // 4. Loss and Gradient Function
    func lossAndGradient(model: AutocompleteModel, inputs: MLXArray, targets: MLXArray, mask: MLXArray) -> (MLXArray, MLX.Core.mlx_array_from_map) {
        // Define the loss calculation closure for `mlx.core.grad`
        let lossFn = { (model: AutocompleteModel, inputs: MLXArray, targets: MLXArray, mask: MLXArray) -> MLXArray in
            let logits = model(inputs, mask: mask) // [batchSize, sequenceLength-1, vocabSize]
            // Flatten logits and targets for cross_entropy, which expects [N, C] and [N]
            let flatLogits = logits.reshaped([-1, vocabSize])
            let flatTargets = targets.flattened()
            return mlx.core.losses.cross_entropy(logits: flatLogits, targets: flatTargets, reduction: .mean)
        }
        
        // MLX's `valueAndGradient` computes both the loss and the gradients efficiently.
        // The computation graph is built lazily during `model(inputs, mask: causalMask)`
        // and then executed to produce the loss and gradients.
        let (loss, grads) = mlx.core.valueAndGradient(lossFn)(model, inputs, targets, mask)
        
        return (loss, grads)
    }

    // 5. Training Loop
    print("Starting training for AutocompleteModel...")
    model.train() // Set model to training mode

    for i in 0..<numIterations {
        let (inputs, targets) = generateBatch(batchSize: batchSize, sequenceLength: maxSequenceLength, vocabSize: vocabSize)
        
        let (loss, grads) = lossAndGradient(model: model, inputs: inputs, targets: targets, mask: causalMask)
        
        optimizer.update(model: model, gradients: grads)
        
        // Explicitly evaluating `loss` triggers the computation graph execution.
        if i % 100 == 0 {
            // `mlx.core.simplify()` can be used to optimize the graph before evaluation,
            // but it's often not strictly necessary as MLX does some optimization automatically.
            // mlx.core.simplify(loss)
            print("Iteration \(i), Loss: \(loss.item(Float.self))")
        }
    }
    print("Training complete.")

    // 6. Inference Example
    model.eval() // Set model to evaluation mode (e.g., disables dropout if present)

    // Example sequence: [1, 2, 3]
    let startSequence = mlx.core.array([1, 2, 3], dtype: MLXArray.DType.int32).expandedDimensions(axes: [0]) // [1, 3] batch size 1

    print("\nPredicting next token for sequence: \(startSequence.description)")

    // Create a causal mask for the current input sequence length.
    // The mask for inference needs to match the actual input sequence length.
    let inferenceSequenceLength = startSequence.shape[1]
    let inferenceCausalMask = createCausalMask(sequenceLength: inferenceSequenceLength)

    // Pass the sequence through the model to get logits.
    let logits = model(startSequence, mask: inferenceCausalMask)
    
    // The logits are [batchSize, sequenceLength, vocabSize]. We want the prediction
    // for the *next* token, which is based on the last token in the input sequence.
    let lastLogits = logits[0, -1] // Get logits for the last token in the sequence (batch 0, last position)
    let predictedToken = mlx.core.argmax(lastLogits).item(Int.self)

    print("Input sequence: \(startSequence.flattened().items(Int.self))")
    print("Predicted next token: \(predictedToken)")
    
    // The 'zero-copy' benefit of Unified Memory means that during this inference,
    // the model parameters and the input `MLXArray` `startSequence` reside in the same memory space.
    // This eliminates costly data transfers between CPU and GPU, making inference highly efficient
    // on Apple Silicon, especially beneficial for real-time autocomplete suggestions.
}

// Uncomment to run the training and inference example:
// runAutocompleteTraining()
