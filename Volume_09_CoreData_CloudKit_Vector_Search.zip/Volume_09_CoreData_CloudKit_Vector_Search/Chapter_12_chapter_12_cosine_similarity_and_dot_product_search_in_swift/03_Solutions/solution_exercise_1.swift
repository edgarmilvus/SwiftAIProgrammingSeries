
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import Accelerate

/// An actor providing high-performance mathematical utilities for vector operations.
actor VectorMathEngine {
    
    /// Computes the Cosine Similarity between two high-dimensional vectors.
    /// - Parameters:
    ///   - vectorA: The first embedding vector.
    ///   - vectorB: The second embedding vector.
    /// - Returns: The similarity score (0.0 to 1.0, or -1.0 to 1.0), or nil if calculation is impossible.
    /// - Note: This is nonisolated to allow concurrent mathematical computations without blocking the actor's mailbox.
    nonisolated func cosineSimilarity(vectorA: [Float], vectorB: [Float]) -> Float? {
        // 1. Constraint Check: Vectors must be of equal length
        guard vectorA.count == vectorB.count, !vectorA.isEmpty else {
            return nil
        }
        
        let n = vDSP_Length(vectorA.count)
        
        // 2. Calculate Dot Product (Numerator: A · B)
        var dotProduct: Float = 0
        vDSP_dotpr(vectorA, 1, vectorB, 1, &dotProduct, n)
        
        // 3. Calculate Magnitudes (Denominator: ||A|| * ||B||)
        // We calculate the sum of squares for each vector using dot product with itself
        var sumSqA: Float = 0
        var sumSqB: Float = 0
        vDSP_dotpr(vectorA, 1, vectorA, 1, &sumSqA, n)
        vDSP_dotpr(vectorB, 1, vectorB, 1, &sumSqB, n)
        
        let magnitudeA = sqrt(sumSqA)
        let magnitudeB = sqrt(sumSqB)
        
        // 4. Safety Check: Avoid division by zero (zero-magnitude vectors)
        guard magnitudeA > 0, magnitudeB > 0 else {
            return nil
        }
        
        return dotProduct / (magnitudeA * magnitudeB)
    }
}

// MARK: - Verification Logic
func runExercise1Tests() {
    let engine = VectorMathEngine()
    let vec1: [Float] = [1.0, 0.0, 1.0, 0.0]
    let vec2: [Float] = [0.0, 1.0, 0.0, 1.0] // Orthogonal
    let vec3: [Float] = [1.0, 0.0, 1.0, 0.0] // Identical
    
    Task {
        let simOrthogonal = await engine.cosineSimilarity(vectorA: vec1, vectorB: vec2)
        let simIdentical = await engine.cosineSimilarity(vectorA: vec1, vectorB: vec3)
        
        print("Orthogonal Similarity (Expected ~0): \(simOrthogonal ?? -1)")
        print("Identical Similarity (Expected ~1): \(simIdentical ?? -1)")
    }
}
