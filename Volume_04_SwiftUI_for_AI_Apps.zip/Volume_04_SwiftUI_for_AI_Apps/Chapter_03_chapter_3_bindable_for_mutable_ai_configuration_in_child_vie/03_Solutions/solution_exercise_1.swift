
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
import SwiftUI

// 1. Define an Observable Configuration Object
@Observable
class ChatModelConfiguration {
    var temperature: Double
    var maxTokens: Int

    init(temperature: Double = 0.7, maxTokens: Int = 500) {
        self.temperature = temperature
        self.maxTokens = maxTokens
    }
}

// Parent View Setup
@available(iOS 18.0, macOS 15.0, *)
struct ContentView: View {
    // @StateObject owns the lifecycle of the Observable object
    @StateObject private var config = ChatModelConfiguration()

    var body: some View {
        VStack(spacing: 20) {
            Text("Current AI Model Configuration")
                .font(.headline)
            Text("Temperature: \(config.temperature, specifier: "%.2f")")
            Text("Max Tokens: \(config.maxTokens)")

            Divider()

            // 2. Pass the configuration to the child view
            // No explicit @Bindable is needed here; the child declares it.
            ModelSettingsView(config: config)
        }
        .padding()
    }
}

// Child View for Editing
@available(iOS 18.0, macOS 15.0, *)
struct ModelSettingsView: View {
    // 3. Receive the configuration using @Bindable for two-way binding
    @Bindable var config: ChatModelConfiguration

    var body: some View {
        VStack(spacing: 15) {
            Text("Adjust Model Parameters")
                .font(.subheadline)

            HStack {
                Text("Temperature:")
                // 4. Implement UI Controls bound directly to @Bindable properties
                Slider(value: $config.temperature, in: 0.0...2.0) {
                    Text("Temperature")
                } minimumValueLabel: {
                    Text("0.0")
                } maximumValueLabel: {
                    Text("2.0")
                }
            }

            HStack {
                Text("Max Tokens:")
                Stepper(value: $config.maxTokens, in: 1...2000, step: 10) {
                    Text("\(config.maxTokens)")
                }
            }
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(8)
    }
}
