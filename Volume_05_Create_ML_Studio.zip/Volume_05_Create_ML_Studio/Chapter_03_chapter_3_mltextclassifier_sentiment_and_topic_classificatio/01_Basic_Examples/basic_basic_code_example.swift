
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import CreateML // For training the model
import Foundation // For URL, FileManager, etc.
import CoreML // For loading and using the compiled .mlmodel

// MARK: - 1. Define Training Data Structure
/// A simple structure to represent our sentiment data.
/// In a real app, this might come from a database, CSV, or JSON.
struct SentimentData: Identifiable {
    let id = UUID()
    let text: String
    let sentiment: String // This will be our label
}

// MARK: - Main Actor for Example Execution
/// An actor to encapsulate the asynchronous operations for training and prediction.
/// Using @main allows this to be a standalone executable.
@main
@available(macOS 14.0, iOS 17.0, *) // CreateML is primarily macOS. CoreML inference is cross-platform.
actor SentimentClassifierExample {

    /// The entry point for our example.
    func runExample() async {
        print("Starting MLTextClassifier example...")

        // MARK: - 2. Prepare Training Data
        // In a real-world scenario, this data would be much larger and more diverse.
        // It's crucial to have balanced data for each sentiment category.
        let rawTrainingData: [SentimentData] = [
            SentimentData(text: "I love this app, it's amazing!", sentiment: "positive"),
            SentimentData(text: "This feature is fantastic and super useful.", sentiment: "positive"),
            SentimentData(text: "Great experience, highly recommend.", sentiment: "positive"),
            SentimentData(text: "The user interface is intuitive and beautiful.", sentiment: "positive"),
            SentimentData(text: "Absolutely thrilled with the new update!", sentiment: "positive"),
            SentimentData(text: "I hate this bug, it crashes all the time.", sentiment: "negative"),
            SentimentData(text: "Terrible performance, very slow.", sentiment: "negative"),
            SentimentData(text: "This update broke everything, so frustrating.", sentiment: "negative"),
            SentimentData(text: "Worst app ever, completely unusable.", sentiment: "negative"),
            SentimentData(text: "I'm so disappointed with the support.", sentiment: "negative"),
            SentimentData(text: "It's okay, nothing special.", sentiment: "neutral"),
            SentimentData(text: "The app works as expected.", sentiment: "neutral"),
            SentimentData(text: "I have no strong feelings about it.", sentiment: "neutral"),
            SentimentData(text: "The design is functional.", sentiment: "neutral"),
            SentimentData(text: "It does what it's supposed to do.", sentiment: "neutral")
        ]

        // MARK: - 3. Create MLDataTable from Training Data
        // MLDataTable is the primary data structure for CreateML.
        // It can be initialized from various sources like arrays of dictionaries, CSV, JSON, etc.
        let dataTable: MLDataTable
        do {
            dataTable = try MLDataTable(array: rawTrainingData)
            print("MLDataTable created successfully with \(dataTable.rows.count) rows.")
            // print("Schema: \(dataTable.schema)") // Uncomment to see the schema
        } catch {
            print("Error creating MLDataTable: \(error.localizedDescription)")
            return
        }

        // MARK: - 4. Train the MLTextClassifier Model
        // Training can be computationally intensive, so it's often run asynchronously.
        print("Training MLTextClassifier...")
        let sentimentClassifier: MLTextClassifier
        do {
            // The 'text' column is the feature, and 'sentiment' is the label.
            sentimentClassifier = try await MLTextClassifier(trainingData: dataTable,
                                                             textColumn: "text",
                                                             labelColumn: "sentiment")
            print("MLTextClassifier training complete!")
            print("Evaluation metrics: \(sentimentClassifier.evaluation(on: dataTable, textColumn: "text", labelColumn: "sentiment"))")
        } catch {
            print("Error training MLTextClassifier: \(error.localizedDescription)")
            return
        }

        // MARK: - 5. Save the Trained Model
        // The trained model is saved as a .mlmodel file, which can then be deployed.
        let modelURL = FileManager.default.temporaryDirectory.appendingPathComponent("SentimentClassifier.mlmodel")
        do {
            try await sentimentClassifier.write(to: modelURL)
            print("Model saved to: \(modelURL.path)")
        } catch {
            print("Error saving model: \(error.localizedDescription)")
            return
        }

        // MARK: - 6. Load the Model for Inference
        // In a real application, you would typically bundle the .mlmodel file with your app
        // and load it from the app's bundle. For this example, we load from the temp directory.
        print("Loading the saved model for inference...")
        let loadedClassifier: MLTextClassifier
        do {
            // MLTextClassifier has a convenience initializer to load directly.
            loadedClassifier = try MLTextClassifier(contentsOf: modelURL)
            print("Model loaded successfully.")
        } catch {
            print("Error loading model: \(error.localizedDescription)")
            return
        }

        // MARK: - 7. Make Predictions on New Text
        // Simulate new messages coming into our chat app.
        print("\nMaking predictions:")
        let testMessages = [
            "This new update is fantastic!",
            "I'm experiencing some issues with login.",
            "The app is functional.",
            "Absolutely terrible, can't even open it.",
            "It's pretty good.",
            "I love the new dark mode!"
        ]

        for message in testMessages {
            do {
                let prediction = try loadedClassifier.prediction(from: message)
                print("Message: '\(message)' -> Predicted Sentiment: \(prediction)")
            } catch {
                print("Error predicting for '\(message)': \(error.localizedDescription)")
            }
        }

        // MARK: - 8. Get Prediction Probabilities (Optional)
        // For more advanced use cases, you might want to know the confidence of the prediction.
        print("\nGetting prediction probabilities for 'This is great!':")
        do {
            let (prediction, probabilities) = try loadedClassifier.prediction(from: "This is great!")
            print("Message: 'This is great!' -> Predicted Sentiment: \(prediction)")
            print("Probabilities: \(probabilities)")
        } catch {
            print("Error getting probabilities: \(error.localizedDescription)")
        }

        print("\nMLTextClassifier example finished.")
    }

    /// The main function required for a standalone executable.
    static func main() async {
        let example = SentimentClassifierExample()
        await example.runExample()
    }
}
