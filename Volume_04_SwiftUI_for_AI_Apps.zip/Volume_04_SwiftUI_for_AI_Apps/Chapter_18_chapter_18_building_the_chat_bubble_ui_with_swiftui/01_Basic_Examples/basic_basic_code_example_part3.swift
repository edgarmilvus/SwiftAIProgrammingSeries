
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.swift
// Description: Basic Code Example
// ==========================================

    @MainActor
    final class ChatViewModel: ObservableObject {
        @Published var messages: [ChatMessage] = []

        func sendMessageToAI(_ text: String) async {
            // ... add user message ...
            let aiMessage = ChatMessage(content: "...", sender: .ai) // Placeholder
            messages.append(aiMessage) // Updated on main actor because ChatViewModel is @MainActor

            // Simulate AI processing
            let aiResponseContent = await someAIModel.generateResponse(for: text)

            // Find the placeholder and update it, or append new message
            // This update also happens on the main actor
            if let index = messages.firstIndex(where: { $0.id == aiMessage.id }) {
                messages[index].content = aiResponseContent
            } else {
                messages.append(ChatMessage(content: aiResponseContent, sender: .ai))
            }
        }
    }
    