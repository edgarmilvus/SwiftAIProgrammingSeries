
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

/// The data passed between agents in a workflow.
struct AgentContext: Sendable {
    var data: [String: String]
}

/// Represents a single step in a multi-agent workflow.
protocol AgentTask: Sendable {
    var name: String { get }
    func execute(context: AgentContext) async throws -> AgentContext
    func fallback(context: AgentContext) async -> AgentContext?
}

/// The result of a completed workflow.
struct WorkflowResult: Sendable {
    let finalContext: AgentContext
    let completedSteps: [String]
}

actor WorkflowOrchestrator {
    private let retryHandler: LLMRetryHandler
    
    init(retryHandler: LLMRetryHandler) {
        self.retryHandler = retryHandler
    }
    
    func runWorkflow(tasks: [any AgentTask], initialContext: AgentContext) async throws -> WorkflowResult {
        var currentContext = initialContext
        var completedSteps: [String] = []
        
        // Use a TaskGroup to manage the lifecycle of the workflow
        try await withThrowingTaskGroup(of: AgentContext.self) { group in
            // Note: We execute tasks sequentially because each depends on the previous context.
            // We use the TaskGroup structure to ensure that if one task fails fundamentally,
            // the group can handle the cancellation of the entire workflow.
            
            for task in tasks {
                // Check for cancellation before starting each step
                try Task.checkCancellation()
                
                do {
                    // Attempt the task with retries via the handler
                    currentContext = try await retryHandler.execute(maxRetries: 3) {
                        try await task.execute(context: currentContext)
                    }
                    completedSteps.append(task.name)
                } catch {
                    // If retries fail, attempt the fallback mechanism
                    print("Task \(task.name) failed after retries. Attempting fallback...")
                    
                    if let fallbackContext = await task.fallback(context: currentContext) {
                        currentContext = fallbackContext
                        completedSteps.append("\(task.name) (via Fallback)")
                    } else {
                        // No fallback available, the entire workflow fails
                        throw error
                    }
                }
            }
        }
        
        return WorkflowResult(finalContext: currentContext, completedSteps: completedSteps)
    }
}

// --- Example Implementation of a Task ---

struct ResearchAgent: AgentTask {
    let name = "Research Agent"
    
    func execute(context: AgentContext) async throws -> AgentContext {
        // Simulate a transient error
        throw LLMError.rateLimited(retryAfter: 2)
    }
    
    func fallback(context: AgentContext) async -> AgentContext? {
        print("Executing Local Knowledge Fallback...")
        var newContext = context
        newContext.data["research"] = "Local fallback data: The sky is blue."
        return newContext
    }
}
