
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

    // MARK: - Adaptive Contrast Module Definition

    import MLX
    import MLXNN

    /// A simple MLX module for adaptive contrast enhancement.
    /// This module learns a non-linear transformation based on gain, bias, and gamma parameters.
    /// It's designed to take a normalized pixel intensity (0-1) and output an adjusted intensity.
    final class AdaptiveContrastModule: MLXNN.Module {

        // Learnable parameters for the contrast adjustment.
        // Initialized with small random values or ones/zeros to start.
        // .float32 is a common precision for ML models.
        var gain: MLXArray
        var bias: MLXArray
        var gamma: MLXArray

        /// Initializes the AdaptiveContrastModule with learnable parameters.
        /// - Parameters:
        ///   - initialGain: Initial value for the gain parameter.
        ///   - initialBias: Initial value for the bias parameter.
        ///   - initialGamma: Initial value for the gamma parameter.
        init(initialGain: Float = 1.0, initialBias: Float = 0.0, initialGamma: Float = 1.0) {
            // Parameters are wrapped in MLXArray and marked as trainable by default.
            self.gain = MLXArray(initialGain)
            self.bias = MLXArray(initialBias)
            self.gamma = MLXArray(initialGamma)
            super.init() // Call the superclass initializer
        }

        /// Defines the forward pass of the module.
        /// It applies a transformation: `output = (input * gain + bias)^gamma`
        /// - Parameter x: The input MLXArray, representing normalized pixel intensities.
        /// - Returns: The transformed MLXArray.
        func callAsFunction(_ x: MLXArray) -> MLXArray {
            // Clamp gain to be positive to avoid issues with power function
            let clampedGain = MLX.maximum(gain, MLXArray(0.01))
            // Apply the learned transformation
            let transformed = (x * clampedGain + bias)
            // Ensure values remain non-negative before applying power (gamma)
            let nonNegativeTransformed = MLX.maximum(transformed, MLXArray(0.0))
            // Clamp gamma to a reasonable range, e.g., 0.1 to 5.0, to prevent extreme values
            let clampedGamma = MLX.clip(gamma, min: MLXArray(0.1), max: MLXArray(5.0))
            return MLX.power(nonNegativeTransformed, clampedGamma)
        }
    }
    