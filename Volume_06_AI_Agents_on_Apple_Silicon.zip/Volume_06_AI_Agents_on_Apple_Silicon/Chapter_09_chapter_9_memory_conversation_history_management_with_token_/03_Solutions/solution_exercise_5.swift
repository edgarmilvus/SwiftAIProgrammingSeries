
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

// Reuse ChatMessage, Tokenizer protocol/MockTokenizer, calculateTokenCount from Exercise 1

// 1. MemoryPolicy Enum
enum MemoryPolicy: CaseIterable, CustomStringConvertible {
    case tailTruncation
    case headTruncation
    case summarizationDriven

    var description: String {
        switch self {
        case .tailTruncation: return "Tail Truncation (oldest removed)"
        case .headTruncation: return "Head Truncation (newest removed)"
        case .summarizationDriven: return "Summarization Driven"
        }
    }
}

// 2. SummaryMessage Structure (conforming to ChatMessage for consistency)
struct SummaryMessage: ChatMessage {
    let id = UUID()
    let role: String = "system" // Summaries are often treated as system context
    let content: String
    let timestamp: Date = Date() // Timestamp of when the summary was generated
    let originalTokenCount: Int // To indicate how many tokens it conceptually replaced

    // The summary's own token count is typically small and fixed,
    // regardless of the original content's length. For this mock,
    // we let it calculate based on its content, but a real summarizer
    // might ensure a fixed small token count.
}

// 3. Summarizer Protocol and MockSummarizer
protocol Summarizer {
    func summarize(_ messages: [ChatMessage], using tokenizer: Tokenizer) -> SummaryMessage
}

struct MockSummarizer: Summarizer {
    func summarize(_ messages: [ChatMessage], using tokenizer: Tokenizer) -> SummaryMessage {
        let originalContent = messages.map { $0.content }.joined(separator: "\n")
        let originalTokens = tokenizer.countTokens(originalContent)
        let summaryText = "Previous conversation (originally \(originalTokens) tokens) summarized."
        // A real summarizer would generate a concise summary.
        // For this mock, the token count of the summary will be based on `summaryText`.
        return SummaryMessage(content: summaryText, originalTokenCount: originalTokens)
    }
}

// 4. ContextManager Class
class ContextManager {
    private var messages: [ChatMessage] = [] // The full, untruncated history
    let tokenBudget: Int
    private let tokenizer: Tokenizer
    var currentPolicy: MemoryPolicy {
        didSet {
            // Optional: Re-evaluate context when policy changes, or rely on next getEffectiveContext call
            print("Memory policy changed to: \(currentPolicy.description)")
        }
    }
    private let summarizer: Summarizer?

    init(tokenBudget: Int, tokenizer: Tokenizer, initialPolicy: MemoryPolicy, summarizer: Summarizer?) {
        self.tokenBudget = tokenBudget
        self.tokenizer = tokenizer
        self.currentPolicy = initialPolicy
        self.summarizer = summarizer
    }

    func setPolicy(_ newPolicy: MemoryPolicy) {
        self.currentPolicy = newPolicy
    }

    func addMessage(_ newMessage: ChatMessage) {
        messages.append(newMessage)
    }

    func getEffectiveContext() -> [ChatMessage] {
        var currentMessages = messages // Work on a mutable copy of the full history
        var currentTokenCount = calculateTokenCount(for: currentMessages, using: tokenizer)

        // Loop until budget is met or no messages left
        while currentTokenCount > tokenBudget && !currentMessages.isEmpty {
            switch currentPolicy {
            case .tailTruncation:
                // Remove the oldest message (from the beginning)
                currentMessages.removeFirst()
            case .headTruncation:
                // Remove the newest message (from the end)
                currentMessages.removeLast()
            case .summarizationDriven:
                guard let summarizer = self.summarizer else {
                    print("Summarizer not available for summarization-driven policy. Falling back to tail truncation.")
                    currentMessages.removeFirst() // Fallback
                    break // Exit switch, continue while loop if still over budget
                }

                // Strategy for summarization:
                // Identify a block of older messages to summarize.
                // Keep a minimum number of recent messages untouched.
                let minMessagesToKeepAtEnd = 2 // E.g., keep the last 2 messages (user query + AI response)
                let messagesToSummarizeCount = currentMessages.count - minMessagesToKeepAtEnd
                
                if messagesToSummarizeCount >= 2 { // Ensure there's a meaningful block of messages to summarize
                    let messagesForSummary = Array(currentMessages.prefix(messagesToSummarizeCount))
                    let summary = summarizer.summarize(messagesForSummary, using: tokenizer)
                    
                    // Remove the original messages and insert the summary at the beginning
                    currentMessages.removeFirst(messagesToSummarizeCount)
                    currentMessages.insert(summary, at: 0)
                    
                    // After summarization, re-evaluate. If still over budget,
                    // fall back to tail truncation for the remaining context.
                    currentTokenCount = calculateTokenCount(for: currentMessages, using: tokenizer)
                    if currentTokenCount > tokenBudget {
                        print("Summarization didn't fully resolve budget. Applying tail truncation to remaining context.")
                        // Continue to use tail truncation until budget is met
                        while currentTokenCount > tokenBudget && !currentMessages.isEmpty {
                            currentMessages.removeFirst()
                            currentTokenCount = calculateTokenCount(for: currentMessages, using: tokenizer)
                        }
                    }
                } else {
                    // Not enough older messages to form a summary block.
                    // Fall back to simple tail truncation to reduce token count.
                    print("Not enough older messages for effective summarization. Falling back to tail truncation.")
                    currentMessages.removeFirst()
                }
            }
            currentTokenCount = calculateTokenCount(for: currentMessages, using: tokenizer)
        }
        return currentMessages
    }
}

// Example Usage (for testing the implementation)
/*
let tokenizer = MockTokenizer()
let mockSummarizer = MockSummarizer()
let contextManager = ContextManager(tokenBudget: 50, tokenizer: tokenizer, initialPolicy: .tailTruncation, summarizer: mockSummarizer)

// Add some initial system message (e.g., instructions for the AI)
contextManager.addMessage(ChatMessage(role: "system", content: "You are SwiftBuddy, an expert Swift developer. Always provide concise code examples.", timestamp: Date().addingTimeInterval(-500))) // ~20 tokens

contextManager.addMessage(ChatMessage(role: "user", content: "How do I use async/await in a SwiftUI view?", timestamp: Date().addingTimeInterval(-480))) // ~15 tokens
contextManager.addMessage(ChatMessage(role: "assistant", content: "You can use a Task modifier. For example: Task { await fetchData() }", timestamp: Date().addingTimeInterval(-460))) // ~18 tokens
contextManager.addMessage(ChatMessage(role: "user", content: "What about error handling with async/await?", timestamp: Date().addingTimeInterval(-440))) // ~10 tokens
contextManager.addMessage(ChatMessage(role: "assistant", content: "Use do-catch blocks for error handling. func load() async throws { ... }", timestamp: Date().addingTimeInterval(-420))) // ~15 tokens
contextManager.addMessage(ChatMessage(role: "user", content: "Can you provide a full example of an async function loading data?", timestamp: Date().addingTimeInterval(-400))) // ~15 tokens
contextManager.addMessage(ChatMessage(role: "assistant", content: "Sure, here's a basic example fetching data from a URLSession.", timestamp: Date().addingTimeInterval(-380))) // ~15 tokens
contextManager.addMessage(ChatMessage(role: "user", content: "That's great, thank you! I'm now trying to integrate Core Data with SwiftData. What's the best way to migrate existing Core Data models to SwiftData?", timestamp: Date().addingTimeInterval(-360))) // ~30 tokens (long message)

print("Initial total messages: \(contextManager.messages.count), tokens: \(calculateTokenCount(for: contextManager.messages, using: tokenizer))")
// Total tokens: ~20+15+18+10+15+15+15+30 = ~138 tokens. Budget is 50.

print("\n--- Context with \(contextManager.currentPolicy.description) (Budget: 50 tokens) ---")
var effectiveContext = contextManager.getEffectiveContext()
print("Effective context messages: \(effectiveContext.count), tokens: \(calculateTokenCount(for: effectiveContext, using: tokenizer))")
effectiveContext.forEach { print("- \($0.role): \($0.content.prefix(50))...") }

contextManager.setPolicy(.headTruncation)
print("\n--- Context with \(contextManager.currentPolicy.description) (Budget: 50 tokens) ---")
effectiveContext = contextManager.getEffectiveContext()
print("Effective context messages: \(effectiveContext.count), tokens: \(calculateTokenCount(for: effectiveContext, using: tokenizer))")
effectiveContext.forEach { print("- \($0.role): \($0.content.prefix(50))...") }

contextManager.setPolicy(.summarizationDriven)
print("\n--- Context with \(contextManager.currentPolicy.description) (Budget: 50 tokens) ---")
effectiveContext = contextManager.getEffectiveContext()
print("Effective context messages: \(effectiveContext.count), tokens: \(calculateTokenCount(for: effectiveContext, using: tokenizer))")
effectiveContext.forEach { print("- \($0.role): \($0.content.prefix(50))...") }
// Observe how a SummaryMessage replaces older messages, and then tail truncation might occur if still over budget.
*/
