/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React, { useState, useEffect } from 'react';
import { View, Text, Button, Alert, StyleSheet } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';
import { StatusBar } from 'expo-status-bar';

/**
 * BiometricAuthScreen Component
 * 
 * A React Native component that handles the logic for detecting biometric hardware,
 * requesting permissions, and authenticating the user.
 */
export default function BiometricAuthScreen() {
  // State to track if biometric hardware is available on the device
  const [isHardwareAvailable, setIsHardwareAvailable] = useState<boolean>(false);
  
  // State to track if the user is authenticated
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  /**
   * checkBiometricHardware
   * 
   * Checks the device's capabilities upon component mounting.
   * Determines if the device supports FaceID, TouchID, or generic biometrics.
   */
  const checkBiometricHardware = async () => {
    try {
      // 1. Check if hardware supports biometric authentication
      const compatible = await LocalAuthentication.supportedAuthenticationTypesAsync();
      
      // 2. Check if the device has a biometric sensor enrolled
      const enrolled = await LocalAuthentication.isEnrolledAsync();

      if (compatible.length > 0 && enrolled) {
        setIsHardwareAvailable(true);
      } else {
        // Fallback: Handle devices without sensors or without enrolled biometrics
        setIsHardwareAvailable(false);
        console.log('Biometric hardware not available or not enrolled.');
      }
    } catch (error) {
      console.error('Error checking biometric hardware:', error);
    }
  };

  /**
   * handleBiometricAuth
   * 
   * Triggers the native biometric prompt.
   */
  const handleBiometricAuth = async () => {
    if (!isHardwareAvailable) {
      Alert.alert('Error', 'Biometric authentication is not available on this device.');
      return;
    }

    try {
      // 3. Trigger the authentication prompt
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Login to access your secure data',
        fallbackLabel: 'Enter Passcode', // iOS only
        cancelLabel: 'Cancel', // Android only
      });

      // 4. Handle the result
      if (result.success) {
        setIsAuthenticated(true);
        // In a real app, you would now fetch sensitive data or generate a session token
        console.log('Authentication successful!');
      } else {
        setIsAuthenticated(false);
        console.log('Authentication failed or cancelled.');
      }
    } catch (error) {
      console.error('Authentication error:', error);
      Alert.alert('Error', 'An unexpected error occurred during authentication.');
    }
  };

  // Check hardware availability on component mount
  useEffect(() => {
    checkBiometricHardware();
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar style="auto" />
      
      <Text style={styles.title}>Secure Access</Text>
      
      {isAuthenticated ? (
        <View style={styles.secureContent}>
          <Text style={styles.successText}>✅ Authenticated!</Text>
          <Text style={styles.dataText}>Welcome back, User.</Text>
          {/* Sensitive data would be rendered here */}
        </View>
      ) : (
        <View style={styles.authContainer}>
          <Text style={styles.subtitle}>
            {isHardwareAvailable 
              ? 'Biometrics are ready.' 
              : 'Biometrics not detected. Please use fallback.'}
          </Text>
          
          <Button 
            title="Authenticate" 
            onPress={handleBiometricAuth} 
            disabled={!isHardwareAvailable}
          />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: 'center',
    color: '#555',
  },
  authContainer: {
    width: '100%',
    alignItems: 'center',
  },
  secureContent: {
    marginTop: 20,
    padding: 15,
    backgroundColor: '#e8f5e9',
    borderRadius: 8,
    alignItems: 'center',
  },
  successText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2e7d32',
    marginBottom: 5,
  },
  dataText: {
    fontSize: 14,
    color: '#1b5e20',
  },
});
