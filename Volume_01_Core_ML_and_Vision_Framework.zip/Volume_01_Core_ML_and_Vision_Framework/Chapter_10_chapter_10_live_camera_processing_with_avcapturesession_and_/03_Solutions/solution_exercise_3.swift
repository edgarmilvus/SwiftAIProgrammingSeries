
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import AVFoundation
import Vision
import CoreML

// Assume you have a custom Core ML object detection model named 'MyObjectDetector'
// e.g., trained to detect "Mug", "T-Shirt", "Book".
// Add MyObjectDetector.mlmodel to your project.

class CustomObjectDetectionViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {

    private var captureSession: AVCaptureSession!
    private var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    private var overlayLayer: CALayer! // Layer to hold all detection overlays
    private var visionRequest: VNCoreMLRequest!

    private var currentFilteredLabels: Set<String> = ["Mug", "T-Shirt", "Book"] // Default filters
    private var segmentedControl: UISegmentedControl!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCoreMLModel()
        setupCamera()
        setupVisionOverlay()
        setupFilteringUI()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        videoPreviewLayer?.frame = view.bounds
        overlayLayer?.frame = view.bounds
        segmentedControl?.frame = CGRect(x: 10, y: view.safeAreaInsets.bottom - 50, width: view.bounds.width - 20, height: 40)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !captureSession.isRunning {
            DispatchQueue.global(qos: .userInitiated).async {
                self.captureSession.startRunning()
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession.isRunning {
            captureSession.stopRunning()
        }
    }

    private func setupCoreMLModel() {
        do {
            // Replace 'MyObjectDetector' with your actual model class name
            let coreMLModel = try VNCoreMLModel(for: MyObjectDetector().model)
            visionRequest = VNCoreMLRequest(model: coreMLModel) { [weak self] request, error in
                guard let self = self else { return }
                if let error = error {
                    print("Core ML object detection error: \(error.localizedDescription)")
                    return
                }
                self.drawDetectionOverlays(for: request.results as? [VNRecognizedObjectObservation])
            }
            visionRequest.imageCropAndScaleOption = .scaleFill
        } catch {
            print("Failed to load custom Core ML model: \(error)")
        }
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .hd1280x720

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Failed to get the camera device.")
            return
        }

        do {
            let videoInput = try AVCaptureDeviceInput(device: videoDevice)
            if captureSession.canAddInput(videoInput) {
                captureSession.addInput(videoInput)
            } else {
                print("Could not add video input to the session")
                return
            }
        } catch {
            print("Could not create video device input: \(error)")
            return
        }

        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue", qos: .userInitiated))
        videoOutput.alwaysDiscardsLateVideoFrames = true
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        } else {
            print("Could not add video output to the session")
            return
        }

        if let connection = videoOutput.connection(with: .video), connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait
        }

        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        videoPreviewLayer.videoGravity = .resizeAspectFill
        videoPreviewLayer.frame = view.bounds
        view.layer.addSublayer(videoPreviewLayer)
    }

    private func setupVisionOverlay() {
        overlayLayer = CALayer()
        overlayLayer.frame = view.bounds
        videoPreviewLayer.addSublayer(overlayLayer)
    }

    private func setupFilteringUI() {
        let items = ["All", "Mug", "T-Shirt", "Book"] // Adjust based on your model's labels
        segmentedControl = UISegmentedControl(items: items)
        segmentedControl.selectedSegmentIndex = 0 // "All" selected by default
        segmentedControl.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        segmentedControl.selectedSegmentTintColor = .systemBlue
        segmentedControl.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .normal)
        segmentedControl.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
        segmentedControl.addTarget(self, action: #selector(filterChanged(_:)), for: .valueChanged)
        view.addSubview(segmentedControl)
    }

    @objc private func filterChanged(_ sender: UISegmentedControl) {
        let allLabels = ["Mug", "T-Shirt", "Book"] // All possible labels from your model
        switch sender.selectedSegmentIndex {
        case 0: // All
            currentFilteredLabels = Set(allLabels)
        case 1: // Mug
            currentFilteredLabels = ["Mug"]
        case 2: // T-Shirt
            currentFilteredLabels = ["T-Shirt"]
        case 3: // Book
            currentFilteredLabels = ["Book"]
        default:
            currentFilteredLabels = Set(allLabels)
        }
        // No need to re-run Vision, just re-draw overlays on the next frame or immediately if results are cached.
        // For simplicity, we'll let the next captureOutput call handle the redraw.
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up)
        do {
            try imageRequestHandler.perform([visionRequest])
        } catch {
            print("Failed to perform Core ML Vision request: \(error)")
        }
    }

    private func drawDetectionOverlays(for observations: [VNRecognizedObjectObservation]?) {
        DispatchQueue.main.async {
            self.overlayLayer.sublayers?.forEach { $0.removeFromSuperlayer() } // Clear previous overlays

            guard let observations = observations else { return }

            for observation in observations {
                // Get the top label and its confidence
                guard let topLabelObservation = observation.labels.first else { continue }
                let label = topLabelObservation.identifier
                let confidence = topLabelObservation.confidence

                // Apply dynamic filtering
                if !self.currentFilteredLabels.contains(label) {
                    continue // Skip drawing if this label is not currently filtered in
                }

                // Convert Vision bounding box to AVCaptureVideoPreviewLayer coordinates
                let boundingBox = observation.boundingBox
                let convertedRect = self.videoPreviewLayer.rectForMetadataOutputRectOfInterest(boundingBox)

                // Bounding Box Layer
                let shapeLayer = CAShapeLayer()
                shapeLayer.frame = convertedRect
                shapeLayer.borderColor = UIColor.yellow.cgColor
                shapeLayer.borderWidth = 2.0
                shapeLayer.cornerRadius = 5.0
                self.overlayLayer.addSublayer(shapeLayer)

                // Label and Confidence Text Layer
                let text = String(format: "%@ (%.1f%%)", label, confidence * 100)
                let textLayer = CATextLayer()
                textLayer.string = text
                textLayer.foregroundColor = UIColor.white.cgColor
                textLayer.backgroundColor = UIColor.yellow.withAlphaComponent(0.6).cgColor
                textLayer.fontSize = 12
                textLayer.alignmentMode = .center
                textLayer.contentsScale = UIScreen.main.scale

                let textHeight: CGFloat = 20
                textLayer.frame = CGRect(x: convertedRect.origin.x,
                                         y: convertedRect.origin.y + convertedRect.size.height + 5, // Position below box
                                         width: convertedRect.size.width,
                                         height: textHeight)
                self.overlayLayer.addSublayer(textLayer)
            }
        }
    }
}
