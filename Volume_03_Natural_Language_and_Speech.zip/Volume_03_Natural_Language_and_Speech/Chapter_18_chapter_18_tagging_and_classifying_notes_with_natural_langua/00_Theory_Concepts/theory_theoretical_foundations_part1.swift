
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
func analyzeText(_ text: String) {
    let tagger = NLTagger(tagSchemes: [.token, .lemma, .lexicalClass, .nameType])
    tagger.string = text

    let options: NLTagger.Options = [.omitWhitespace, .omitPunctuation, .joinNames]

    // Iterate through tokens and apply schemes
    tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .token, options: options) { tag, tokenRange in
        if let token = tag { // tag here is actually the token itself for .token scheme
            let word = String(text[tokenRange])
            let lemma = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .lemma, options: options)?.0
            let pos = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .lexicalClass, options: options)?.0
            let namedEntity = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .nameType, options: options)?.0

            print("Word: \(word), Token: \(token.rawValue), Lemma: \(lemma?.rawValue ?? "N/A"), POS: \(pos?.rawValue ?? "N/A"), Entity: \(namedEntity?.rawValue ?? "N/A")")
        }
        return true
    }
}

// Example usage
// analyzeText("Apple Inc. is headquartered in Cupertino, California.")
