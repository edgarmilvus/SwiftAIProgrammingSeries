
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Speech
import AVFoundation
import NaturalLanguage // For NLTagger

// Using @available for Swift 6 context, assuming iOS 18.0 / macOS 15.0
@available(iOS 18.0, macOS 15.0, *)
class TaskVoiceParser: NSObject, SFSpeechRecognizerDelegate {

    private let speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine: AVAudioEngine

    override init() {
        self.audioEngine = AVAudioEngine()
        self.speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        super.init()
        self.speechRecognizer?.delegate = self
        
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation {
                switch authStatus {
                case .authorized: print("Speech recognition authorized.")
                case .denied, .restricted, .notDetermined: print("Speech recognition authorization denied, restricted, or not determined.")
                @unknown default: print("Unknown speech recognition authorization status.")
                }
            }
        }
    }

    func startListening() throws {
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            throw VoiceCommandError.recognizerUnavailable
        }
        
        recognitionTask?.cancel()
        self.recognitionTask = nil
        
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            throw VoiceCommandError.audioSessionSetupFailed(error)
        }
        
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            throw VoiceCommandError.recognitionRequestFailed
        }
        
        recognitionRequest.shouldReportPartialResults = false // Only final result needed for parsing
        
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
            if let result = result, result.isFinal {
                self.processVoiceCommand(result.bestTranscription.formattedString)
            } else if let error = error {
                print("Speech recognition error: \(error.localizedDescription)")
            }
            
            // Clean up regardless of success or error
            self.audioEngine.stop()
            self.audioEngine.inputNode.removeTap(onBus: 0)
            self.recognitionRequest = nil
            self.recognitionTask = nil
        }
        
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        try audioEngine.start()
        print("\n--- Listening for task command... ---")
    }
    
    func stopListening() {
        audioEngine.stop()
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        print("--- Listening stopped manually ---")
    }

    private func processVoiceCommand(_ transcribedText: String) {
        print("\n--- Command Received: \"\(transcribedText)\" ---")
        
        let tagger = NLTagger(tagSchemes: [.lexicalCategory, .namedEntity])
        tagger.string = transcribedText
        
        var intent: String?
        var taskDescription: String?
        var listName: String?
        var dueDate: String?
        
        // 1. Identify Intent (primary verb)
        tagger.enumerateTags(in: transcribedText.startIndex..<transcribedText.endIndex, unit: .word, scheme: .lexicalCategory, options: .omitWhitespace) { tag, tokenRange in
            guard let tag = tag else { return true }
            let word = String(transcribedText[tokenRange]).lowercased()
            
            if tag == .verb {
                if ["add", "create"].contains(word) { intent = "Add"; return false }
                if ["delete", "remove"].contains(word) { intent = "Delete"; return false }
                if ["complete", "finish", "mark"].contains(word) { intent = "Complete"; return false }
            }
            return true
        }
        
        // If no clear verb intent, try general keywords
        if intent == nil {
            if transcribedText.localizedCaseInsensitiveContains("add") || transcribedText.localizedCaseInsensitiveContains("create") { intent = "Add" }
            else if transcribedText.localizedCaseInsensitiveContains("delete") || transcribedText.localizedCaseInsensitiveContains("remove") { intent = "Delete" }
            else if transcribedText.localizedCaseInsensitiveContains("complete") || transcribedText.localizedCaseInsensitiveContains("finish") || transcribedText.localizedCaseInsensitiveContains("mark complete") { intent = "Complete" }
        }

        // 2. Extract Entities (Task Description, List Name, Due Date)
        tagger.enumerateTags(in: transcribedText.startIndex..<transcribedText.endIndex, unit: .word, scheme: .namedEntity, options: .omitWhitespace) { tag, tokenRange in
            guard let tag = tag else { return true }
            let entity = String(transcribedText[tokenRange])
            
            if tag == .temporal {
                dueDate = entity
            }
            // Add more named entity types if needed, e.g., .place for locations
            return true
        }
        
        // More specific parsing for Task Description and List Name using Regex and string manipulation
        // This part often requires more sophisticated NLP or rule-based systems
        
        if let intentAction = intent {
            let lowercasedText = transcribedText.lowercased()
            
            // Extract Task Description
            // Example: "Add 'buy groceries' to my shopping list for tomorrow"
            // Example: "create a task to call mom"
            if let taskMatch = lowercasedText.firstMatch(of: #/\b(?:add|create)\s*(?:a\s*task\s*to\s*|')?([^']+?)['"]?\s*(?:to|for|on|\b|$)/#) {
                taskDescription = String(taskMatch.output.1).trimmingCharacters(in: .whitespacesAndNewlines)
            }
            
            // Extract List Name
            if let listMatch = lowercasedText.firstMatch(of: #/(?:to|from)\s*(?:my\s*)?([^']+?)\s*(?:list|tasks|items)/#) {
                listName = String(listMatch.output.1).trimmingCharacters(in: .whitespacesAndNewlines) + " list"
            }
        }
        
        print("Interpreted Command:")
        print("  Intent: \(intent ?? "Unknown")")
        print("  Task: \(taskDescription ?? "N/A")")
        print("  List: \(listName ?? "N/A")")
        print("  Due: \(dueDate ?? "N/A")")
        print("----------------------------------\n")
    }
    
    // MARK: - SFSpeechRecognizerDelegate
    
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            print("Speech recognition available.")
        } else {
            print("Speech recognition unavailable.")
            stopListening()
        }
    }
    
    enum VoiceCommandError: Error, LocalizedError {
        case recognizerUnavailable
        case audioSessionSetupFailed(Error)
        case recognitionRequestFailed
        
        var errorDescription: String? {
            switch self {
            case .recognizerUnavailable: return "Speech recognizer is not available or authorized."
            case .audioSessionSetupFailed(let error): return "Failed to set up audio session: \(error.localizedDescription)"
            case .recognitionRequestFailed: return "Unable to create SFSpeechAudioBufferRecognitionRequest."
            }
        }
    }
}

/*
// Example Usage:
@available(iOS 18.0, macOS 15.0, *)
let taskParser = TaskVoiceParser()

DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
    do {
        try taskParser.startListening()
        print("Try saying: \"Add 'buy groceries' to my shopping list for tomorrow\"")
        print("Or: \"Delete 'call mom' from my urgent tasks\"")
        print("Or: \"Mark 'pay bills' complete on Friday\"")
    } catch {
        print("Failed to start listening: \(error.localizedDescription)")
    }
}

// Stop after some time for demonstration
DispatchQueue.main.asyncAfter(deadline: .now() + 15) {
    taskParser.stopListening()
    print("Demo task parsing session ended.")
}

RunLoop.current.run(until: Date(timeIntervalSinceNow: 18))
*/
