
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import RealityKit
import Speech

@available(visionOS 1.0, *)
struct SemanticLabelComponent: Component {
    var label: String
}

@available(visionOS 1.0, *)
enum SpatialAction: Sendable {
    case changeColor(color: UIColor)
    case resize(scale: Float)
    case delete
}

@available(visionOS 1.0, *)
@MainActor
class SpatialAIAgent: ObservableObject {
    @Published var isProcessing: Bool = false
    @Published var statusMessage: String = "Ready"
    
    func handleInteraction(gazeTarget: Entity?, speechInput: String) async {
        isProcessing = true
        statusMessage = "Thinking..."
        
        // 1. Grounding: Extract the semantic label from the gazed entity
        let targetLabel = gazeTarget?.components[SemanticLabelComponent.self]?.label ?? "unknown"
        
        // 2. Multi-modal Fusion: Pass command + spatial context to the AI
        let action = await simulateLLM(command: speechInput, target: targetLabel)
        
        // 3. Execution: Apply the action to the entity
        if let target = gazeTarget {
            execute(action, on: target)
        }
        
        isProcessing = false
        statusMessage = "Action Completed"
    }
    
    private func simulateLLM(command: String, target: String) async -> SpatialAction {
        // Simulate network/inference latency
        try? await Task.sleep(nanoseconds: 1_500_000_000)
        
        let lowerCommand = command.lowercased()
        
        if lowerCommand.contains("red") {
            return .changeColor(color: .red)
        } else if lowerCommand.contains("bigger") || lowerCommand.contains("large") {
            return .resize(scale: 2.0)
        } else if lowerCommand.contains("remove") || lowerCommand.contains("delete") {
            return .delete
        }
        
        return .changeColor(color: .white) // Default
    }
    
    private func execute(_ action: SpatialAction, on entity: Entity) {
        switch action {
        case .changeColor(let color):
            var material = PhysicallyBasedMaterial()
            material.baseColor = .init(tint: color)
            if var model = entity.components[ModelComponent.self] as? ModelComponent {
                model.materials = [material]
                entity.components.set(model)
            }
        case .resize(let scale):
            entity.scale = [scale, scale, scale]
        case .delete:
            entity.removeFromParent()
        }
    }
}

@available(visionOS 1.0, *)
struct AIAgentExperience: View {
    @StateObject private var agent = SpatialAIAgent()
    @State private var speechText: String = "Make it red"
    
    var body: some View {
        VStack(spacing: 20) {
            Text(agent.statusMessage)
                .font(.headline)
            
            RealityView { content in
                // Setup a Lamp
                let lamp = ModelEntity(mesh: .generateCylinder(height: 0.3, radius: 0.05), materials: [SimpleMaterial(color: .gray, isMetallic: true)])
                lamp.components.set(SemanticLabelComponent(label: "Lamp"))
                lamp.components.set(CollisionComponent(shapes: [.generateCylinder(height: 0.3, radius: 0.05)]))
                lamp.position = [0, 0, -0.5]
                content.add(lamp)
            }
            .frame(width: 400, height: 400)
            .onTapGesture {
                // Simulation: In a real app, we'd use ARKit to find the gazeTarget
                // For this exercise, we assume the lamp is the target.
                Task {
                    await agent.handleInteraction(gazeTarget: nil, speechInput: speechText)
                }
            }
            
            TextField("Voice Command Simulation", text: $speechText)
                .textFieldStyle(.roundedBorder)
                .padding()
        }
    }
}
