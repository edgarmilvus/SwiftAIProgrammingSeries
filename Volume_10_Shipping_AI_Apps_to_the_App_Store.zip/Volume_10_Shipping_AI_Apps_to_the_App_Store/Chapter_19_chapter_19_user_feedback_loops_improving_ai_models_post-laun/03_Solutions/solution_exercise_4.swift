
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import PencilKit
import CoreImage
import CoreImage.CIFilterBuiltins

/// 1. Segmentation Engine (Mock)
class SegmentationEngine {
    func generateInitialMask() -> CIImage {
        // Simulating a 512x512 grayscale mask from a Core ML model
        return CIImage(color: .black).cropped(to: CGRect(x: 0, y: 0, width: 512, height: 512))
    }
}

/// 3. Delta Calculator
struct DeltaCalculator {
    func calculateDelta(original: CIImage, corrected: CIImage) -> Data? {
        let context = CIContext()
        
        // Use a Difference Blend Mode to find |A - B|
        let filter = CIFilter.differenceBlendMode()
        filter.inputImage = original
        filter.backgroundImage = corrected
        
        guard let deltaImage = filter.outputImage else { return nil }
        
        // 4. Privacy Layer: Downsample to 128x128 and convert to low-res bitmask
        let scale = 128.0 / 512.0
        let smallDelta = deltaImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        
        // Convert to Data (simulating a lightweight upload format)
        return context.pngRepresentation(of: smallDelta, format: .RGBA8, colorSpace: CGColorSpaceCreateDeviceRGB())
    }
}

/// 2. Mask Editor View
struct MaskEditorView: View {
    @State private var canvasView = PKCanvasView()
    @State private var aiMask = SegmentationEngine().generateInitialMask()
    let calculator = DeltaCalculator()
    
    var body: some View {
        VStack {
            ZStack {
                // The AI Mask Layer
                Image(uiImage: UIImage(ciImage: aiMask))
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
                // The User Correction Layer (PencilKit)
                CanvasRepresentable(canvasView: $canvasView)
                    .aspectRatio(contentMode: .fit)
            }
            .frame(height: 300)
            .border(Color.gray)

            Button("Capture Semantic Delta") {
                captureAndProcess()
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
    
    private func captureAndProcess() {
        // In a real app, convert PKCanvasView strokes to a CIImage
        // For this exercise, we simulate the corrected mask
        let correctedMask = aiMask.applyingFilter("CIColorControls", parameters: [kCIInputBrightnessKey: 0.5])
        
        if let deltaData = calculator.calculateDelta(original: aiMask, corrected: correctedMask) {
            print("✅ Delta Captured. Size: \(deltaData.count) bytes. Privacy preserved via downsampling.")
        }
    }
}

// Helper to wrap PKCanvasView for SwiftUI
struct CanvasRepresentable: UIViewRepresentable {
    @Binding var canvasView: PKCanvasView
    func makeUIView(context: Context) -> PKCanvasView {
        canvasView.backgroundColor = .clear
        return canvasView
    }
    func updateUIView(_ uiView: PKCanvasView, context: Context) {}
}
