
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor AudioProcessorActor {
    private var rawAudioBuffer: [Float] = [] // Mutable state, isolated to this actor
    private let maxBufferSize: Int
    private let downsampleFactor: Int

    init(maxBufferSize: Int, downsampleFactor: Int) {
        self.maxBufferSize = maxBufferSize
        self.downsampleFactor = downsampleFactor
    }

    /// Appends new audio samples and processes them for visualization.
    func append(samples: [Float]) async -> [Float] {
        // Actor isolation ensures `rawAudioBuffer` is accessed safely.
        rawAudioBuffer.append(contentsOf: samples)

        // Trim buffer to `maxBufferSize`
        if rawAudioBuffer.count > maxBufferSize {
            rawAudioBuffer.removeFirst(rawAudioBuffer.count - maxBufferSize)
        }

        // Perform downsampling and peak/trough detection
        return await processForWaveformDisplay(rawAudioBuffer)
    }

    /// Internal method to perform computationally intensive processing.
    private func processForWaveformDisplay(_ buffer: [Float]) async -> [Float] {
        // This could be offloaded to a background task if extremely heavy
        // or performed directly within the actor's context.
        return await Task.detached {
            guard !buffer.isEmpty else { return [] }

            var processedPoints: [Float] = []
            var i = 0
            while i < buffer.count {
                let endIndex = min(i + self.downsampleFactor, buffer.count)
                let segment = buffer[i..<endIndex]

                if let max = segment.max(), let min = segment.min() {
                    // For waveform, we often need both peak and trough
                    processedPoints.append(max)
                    processedPoints.append(min)
                } else if let avg = segment.reduce(0, +) / Float(segment.count) {
                    // Or just an average for a simpler line
                    processedPoints.append(avg)
                }
                i = endIndex
            }
            return processedPoints
        }.value // Await the detached task's result
    }
}
