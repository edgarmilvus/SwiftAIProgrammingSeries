
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import MLX
    import MLXNN
    import Foundation // For Error

    // Assume LLMModel is defined elsewhere, inheriting from MLXNN.Module

    @available(iOS 18.0, macOS 15.0, *)
    actor LLMInferenceActor {
        private var model: LLMModel
        private var currentKvCache: [MLXArray]?
        private var currentInputTokens: [MLXArray] // Or a single MLXArray representing the sequence

        init(model: LLMModel) {
            self.model = model
            self.currentKvCache = nil
            self.currentInputTokens = []
            // Initialize model on the desired device, e.g., .gpu
            self.model.to(.gpu)
        }

        // Method to initialize with a prompt
        func initialize(with promptTokens: MLXArray) async throws {
            // This would typically involve an initial forward pass to set up the KV cache
            // For simplicity, let's assume `model.initialForward` returns the first KV cache
            // In a real scenario, this would be part of the generateNextToken's first call
            self.currentInputTokens = [promptTokens] // Assuming promptTokens is a single tensor of token IDs
            self.currentKvCache = nil // Will be populated on first generation
        }

        func generateNextToken(inputTokens: MLXArray) async throws -> (MLXArray, [MLXArray]) {
            // This is a simplified representation. A real LLM `callAsFunction` would take
            // input_ids and the KV cache, and return logits and updated KV cache.
            // For MLX, the KV cache would be a tuple of (keys, values) for each layer.
            // We're simplifying to `[MLXArray]` here.

            // The model.callAsFunction would internally manage the KV cache update
            // when it's passed as an argument. MLX's functional style means
            // the model returns the *new* KV cache, rather than mutating an internal one.

            // Example of how MLX model might be called (simplified):
            // let (logits, newKvCache) = model(input_ids: inputTokens, cache: currentKvCache)
            // let nextToken = MLX.argmax(logits, axis: -1).evaluated() // Greedy sampling

            // Placeholder for actual MLX operation
            let (logits, newKvCache) = try await Task.detached { [model, currentKvCache] in
                // Model's callAsFunction needs to be Sendable if called in detached Task or
                // the actor itself ensures isolation.
                // This is where MLX's lazy evaluation comes in. The graph is built, then eval'd.
                let output = model(inputTokens, cache: currentKvCache) // Assuming model takes input and cache
                _ = output.0.eval() // Evaluate logits
                _ = output.1.map { $0.eval() } // Evaluate new KV cache parts
                return (output.0, output.1)
            }.value

            let nextToken = MLX.argmax(logits, axis: -1).evaluated() // Example greedy sampling
            return (nextToken, newKvCache)
        }

        // Public streaming interface
        func streamTokens(prompt: String) async throws -> AsyncStream<String> {
            return AsyncStream { continuation in
                Task { [unowned self] in // Capture self unowned as Task is owned by actor
                    do {
                        let initialTokens = try await self.model.tokenize(prompt)
                        self.currentInputTokens = [initialTokens] // Store the initial prompt as a single tensor

                        // Perform initial forward pass if needed to set up KV cache
                        // Or, let the first generateNextToken handle it when currentKvCache is nil

                        while true {
                            // Only pass the *last* token for next prediction, but model uses full KV cache
                            // This is a common pattern for optimizing input to the model's forward pass
                            let inputForNextStep = self.currentInputTokens.last! // Assuming it's a single token MLXArray

                            let (nextTokenMLX, updatedKvCache) = try await self.generateNextToken(
                                inputTokens: inputForNextStep // Model's call will use the internal currentKvCache
                            )

                            // Update actor's internal state
                            self.currentKvCache = updatedKvCache
                            self.currentInputTokens.append(nextTokenMLX) // Append the new token

                            let decodedToken = try await self.model.decode([nextTokenMLX]) // Decode the MLXArray token
                            if self.model.isEndOfSequence(nextTokenMLX) {
                                continuation.finish()
                                break
                            }
                            continuation.yield(decodedToken)
                        }
                    } catch {
                        continuation.yield(with: .failure(error))
                    }
                }
            }
        }
    }

    // Example Package.swift snippet for MLX Swift
    /*
    // swift-tools-version:6.0
    import PackageDescription

    let package = Package(
        name: "MyMLXApp",
        platforms: [
            .macOS(.v15), .iOS(.v18) // Specify minimum deployment targets
        ],
        products: [
            .library(
                name: "MyMLXApp",
                targets: ["MyMLXApp"]),
        ],
        dependencies: [
            .package(url: "https://github.com/ml-explore/mlx-swift.git", branch: "main") // Or a specific version
        ],
        targets: [
            .target(
                name: "MyMLXApp",
                dependencies: [
                    .product(name: "MLX", package: "mlx-swift"),
                    .product(name: "MLXNN", package: "mlx-swift")
                ]),
        ]
    )
    */
    