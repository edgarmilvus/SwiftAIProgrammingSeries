
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// MARK: - Package.swift
/*
// To use this in a real project, ensure your Package.swift includes:
// dependencies: [
//     .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0"),
//     .package(url: "https://github.com/openai/openai-swift", from: "1.0.0") // Hypothetical
// ]
*/

import SwiftUI
import SwiftData
import Foundation
import Accelerate // Used for high-performance vector math

// MARK: - Models

/// Represents a single note in the MindVault application.
/// The `@Model` macro tells SwiftData to persist this class in a local SQLite database.
@available(iOS 18.0, *)
@Model
final class Note {
    /// The unique identifier for the note.
    var id: UUID
    
    /// The actual text content of the user's note.
    var content: String
    
    /// The semantic embedding of the content. 
    /// This is an array of floating-point numbers representing the note in vector space.
    /// SwiftData handles the persistence of [Float] automatically.
    @Attribute(.externalStorage) var embedding: [Float]?
    
    /// The timestamp of when the note was created or last updated.
    var timestamp: Date

    init(content: String, embedding: [Float]? = nil) {
        self.id = UUID()
        self.content = content
        self.embedding = embedding
        self.timestamp = Date()
    }
}

// MARK: - Services

/// An actor responsible for handling embedding generation.
/// Using an `actor` ensures that the heavy lifting of network calls and 
/// mathematical transformations happens off the Main Actor, preventing UI hangs.
@available(iOS 18.0, *)
actor EmbeddingService {
    
    /// Simulates a call to an external LLM API (like OpenAI) to get an embedding.
    /// - Parameter text: The string to be embedded.
    /// - Returns: A simulated vector of 1536 dimensions (standard for OpenAI).
    func fetchEmbedding(for text: String) async throws -> [Float] {
        // In a real-world scenario, this is where your URLSession call to OpenAI happens.
        // We simulate network latency with Task.sleep.
        try await Task.sleep(for: .seconds(1.5))
        
        // Generating a mock vector of 1536 dimensions.
        // In production, this comes from the API response.
        return (0..<1536).map { _ in Float.random(in: -1...1) }
    }
}

// MARK: - View Model

/// The central coordinator for the UI, managing the SwiftData context and business logic.
@available(iOS 18.0, *)
@MainActor
class NoteViewModel: ObservableObject {
    private var modelContext: ModelContext
    private let embeddingService = EmbeddingService()
    
    @Published var isProcessing: Bool = false
    
    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }
    
    /// Adds a new note, fetches its embedding, and persists it to SwiftData.
    /// - Parameter text: The user-provided text.
    func addNote(text: String) async {
        guard !text.isEmpty else { return }
        
        isProcessing = true
        defer { isProcessing = false }
        
        do {
            // 1. Fetch the embedding from the remote service
            let vector = try await embeddingService.fetchEmbedding(for: text)
            
            // 2. Create the Note model instance
            let newNote = Note(content: text, embedding: vector)
            
            // 3. Insert into SwiftData context
            modelContext.insert(newNote)
            
            // 4. Save changes to disk
            try modelContext.save()
            
        } catch {
            print("Failed to process note: \(error.localizedDescription)")
        }
    }
    
    /// Performs a local semantic search using Cosine Similarity.
    /// This demonstrates the "Offline Support" aspect.
    /// - Parameter query: The user's search query.
    /// - Returns: A list of notes sorted by semantic relevance.
    func semanticSearch(query: String) async -> [Note] {
        do {
            // 1. Embed the query text
            let queryVector = try await embeddingService.fetchEmbedding(for: query)
            
            // 2. Fetch all notes from SwiftData
            let descriptor = FetchDescriptor<Note>()
            let allNotes = (try? modelContext.fetch(descriptor)) ?? []
            
            // 3. Calculate similarity for each note locally
            // We sort the notes based on how close their vector is to the query vector.
            return allNotes.sorted { noteA, noteB in
                let scoreA = cosineSimilarity(queryVector, noteA.embedding ?? [])
                let scoreB = cosineSimilarity(queryVector, noteB.embedding ?? [])
                return scoreA > scoreB
            }
        } catch {
            print("Search failed: \(error)")
            return []
        }
    }
    
    /// Calculates the Cosine Similarity between two vectors.
    /// Formula: (A · B) / (||A|| * ||B||)
    private func cosineSimilarity(_ v1: [Float], _ v2: [Float]) -> Float {
        guard v1.count == v2.count, !v1.isEmpty else { return 0 }
        
        var dotProduct: Float = 0
        var magnitudeV1: Float = 0
        var magnitudeV2: Float = 0
        
        // Using Accelerate framework for high-performance vector math
        vDSP_dotpr(v1, 1, v2, 1, &dotProduct, vDSP_Length(v1.count))
        vDSP_svesq(v1, 1, &magnitudeV1, vDSP_Length(v1.count))
        vDSP_svesq(v2, 1, &magnitudeV2, vDSP_Length(v2.count))
        
        return dotProduct / (sqrt(magnitudeV1) * sqrt(magnitudeV2))
    }
}

// MARK: - UI Layer

@available(iOS 18.0, *)
struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @StateObject private var viewModel: NoteViewModel
    @Query(sort: \Note.timestamp, order: .reverse) private var notes: [Note]
    
    @State private var noteText: String = ""
    @State private var searchText: String = ""
    @State private var searchResults: [Note] = []
    @State private var isSearching: Bool = false

    init(modelContext: ModelContext) {
        // Initialize the ViewModel with the provided context
        _viewModel = StateObject(wrappedValue: NoteViewModel(modelContext: modelContext))
    }

    var body: some View {
        NavigationStack {
            VStack {
                // Input Section
                VStack(spacing: 10) {
                    TextField("Enter a new note...", text: $noteText, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .lineLimit(3...5)
                    
                    Button(action: {
                        Task { await viewModel.addNote(text: noteText) }
                        noteText = ""
                    }) {
                        if viewModel.isProcessing {
                            ProgressView()
                        } else {
                            Text("Save Note & Embed")
                                .frame(maxWidth: .infinity)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(viewModel.isProcessing || noteText.isEmpty)
                }
                .padding()

                Divider()

                // Search Section
                VStack(spacing: 10) {
                    HStack {
                        TextField("Semantic search...", text: $searchText)
                            .textFieldStyle(.roundedBorder)
                        
                        if isSearching {
                            ProgressView()
                        } else {
                            Button("Search") {
                                performSearch()
                            }
                        }
                    }
                    .padding(.horizontal)
                }

                // Results Section
                List {
                    if !searchText.isEmpty && !searchResults.isEmpty {
                        Section("Search Results") {
                            ForEach(searchResults) { note in
                                NoteRow(note: note)
                            }
                        }
                    } else {
                        Section("All Notes") {
                            ForEach(notes) { note in
                                NoteRow(note: note)
                            }
                        }
                    }
                }
            }
            .navigationTitle("MindVault")
        }
    }

    private func performSearch() {
        isSearching = true
        Task {
            searchResults = await viewModel.semanticSearch(query: searchText)
            isSearching = false
        }
    }
}

struct NoteRow: View {
    let note: Note
    var body: some View {
        VStack(alignment: .leading) {
            Text(note.content)
                .font(.body)
            Text(note.timestamp, style: .date)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }
}

// MARK: - App Entry Point

@main
struct MindVaultApp: App {
    let container: ModelContainer

    init() {
        do {
            // Initialize SwiftData container for the Note model
            container = try ModelContainer(for: Note.self)
        } catch {
            fatalError("Could not initialize SwiftData: \(error)")
        }
    }

    var body: some Scene {
        WindowGroup {
            ContentView(modelContext: container.mainContext)
        }
        .modelContainer(container)
    }
}
