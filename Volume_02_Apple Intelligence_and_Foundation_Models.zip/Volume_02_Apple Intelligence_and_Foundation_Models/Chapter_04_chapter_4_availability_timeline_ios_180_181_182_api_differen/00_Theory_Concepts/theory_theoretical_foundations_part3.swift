
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import SwiftUI
import Observation // Import the Observation framework

@available(iOS 18.0, *)
@Observable
class AIResponseModel {
    enum Status {
        case idle
        case generating
        case complete(String)
        case error(Error)
    }

    var status: Status = .idle
    var progress: Double = 0.0 // For long-running tasks, e.g., image generation
}

@available(iOS 18.0, *)
class AIService {
    private let textGenerator: TextGenerator // Assume this is available
    private let responseModel: AIResponseModel

    init(responseModel: AIResponseModel) {
        self.textGenerator = TextGenerator()
        self.responseModel = responseModel
    }

    func generateText(prompt: String) async {
        responseModel.status = .generating
        responseModel.progress = 0.1 // Simulate initial progress

        do {
            // Simulate some work or actual API call
            try await Task.sleep(for: .seconds(1))
            responseModel.progress = 0.5

            let result = try await textGenerator.generate(prompt: prompt) // Actual AI call
            responseModel.progress = 1.0
            responseModel.status = .complete(result.text)
        } catch {
            responseModel.status = .error(error)
            responseModel.progress = 0.0
        }
    }
}

@available(iOS 18.0, *)
struct AIView: View {
    @State private var prompt: String = ""
    @State private var responseModel = AIResponseModel() // State for the observable model
    private var aiService: AIService // Service to perform AI operations

    init() {
        _responseModel = State(initialValue: AIResponseModel())
        self.aiService = AIService(responseModel: _responseModel.wrappedValue)
    }

    var body: some View {
        VStack {
            TextField("Enter prompt", text: $prompt)
                .textFieldStyle(.roundedBorder)
                .padding()

            Button("Generate AI Text") {
                Task {
                    await aiService.generateText(prompt: prompt)
                }
            }
            .disabled(responseModel.status == .generating)

            ProgressView(value: responseModel.progress)
                .opacity(responseModel.status == .generating ? 1 : 0)
                .padding()

            switch responseModel.status {
            case .idle:
                Text("Ready to generate.")
            case .generating:
                Text("Generating...")
            case .complete(let text):
                Text(text)
                    .font(.body)
                    .padding()
            case .error(let error):
                Text("Error: \(error.localizedDescription)")
                    .foregroundColor(.red)
                    .padding()
            }
        }
    }
}
