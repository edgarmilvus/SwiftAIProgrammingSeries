
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
import SwiftUI

// 1. Define an Observable Visualization Settings Object
enum AnomalyDisplayMode: String, CaseIterable, Identifiable {
    case barChart = "Bar Chart"
    case textLabel = "Text Label"
    case gauge = "Gauge"

    var id: String { self.rawValue }
}

@Observable
class AnomalyVisualizationSettings {
    var thresholdColor: Color
    var displayMode: AnomalyDisplayMode
    var animationSpeed: Double // 0.1 (fast) to 2.0 (slow)

    init(thresholdColor: Color = .red, displayMode: AnomalyDisplayMode = .barChart, animationSpeed: Double = 0.5) {
        self.thresholdColor = thresholdColor
        self.displayMode = displayMode
        self.animationSpeed = animationSpeed
    }
}

// Parent View for Display
@available(iOS 18.0, macOS 15.0, *)
struct DashboardView: View {
    @StateObject private var settings = AnomalyVisualizationSettings()

    var body: some View {
        VStack(spacing: 20) {
            Text("Anomaly Visualization Dashboard")
                .font(.headline)

            VStack(alignment: .leading) {
                Text("Current Settings:")
                HStack {
                    Text("Threshold Color:")
                    Rectangle()
                        .fill(settings.thresholdColor)
                        .frame(width: 30, height: 30)
                        .cornerRadius(5)
                }
                Text("Display Mode: \(settings.displayMode.rawValue)")
                Text("Animation Speed: \(settings.animationSpeed, specifier: "%.1f")x")
            }

            Divider()

            // Pass settings to child view
            VisualizationControlsView(settings: settings)
        }
        .padding()
    }
}

// Child View for Controls
@available(iOS 18.0, macOS 15.0, *)
struct VisualizationControlsView: View {
    @Bindable var settings: AnomalyVisualizationSettings

    var body: some View {
        VStack(spacing: 15) {
            Text("Adjust Visualization Controls")
                .font(.subheadline)

            // 4. Implement UI Controls
            ColorPicker("Threshold Color", selection: $settings.thresholdColor)

            Picker("Display Mode", selection: $settings.displayMode) {
                ForEach(AnomalyDisplayMode.allCases) { mode in
                    Text(mode.rawValue).tag(mode)
                }
            }
            .pickerStyle(.segmented)

            HStack {
                Text("Animation Speed:")
                Slider(value: $settings.animationSpeed, in: 0.1...2.0, step: 0.1) {
                    Text("Animation Speed")
                } minimumValueLabel: {
                    Text("0.1x")
                } maximumValueLabel: {
                    Text("2.0x")
                }
            }
        }
        .padding()
        .background(Color.blue.opacity(0.1))
        .cornerRadius(8)
    }
}
