
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import RealityKit
import Combine

// 1. A heavy resource mock
class HeavyMLModel {
    let data = Data(repeating: 0, count: 100_000_000) // 100MB mock
}

// 2. The Flawed Entity
class AIPetEntity: Entity, HasModel {
    var mlModel: HeavyMLModel?
    var subscriptions = Set<AnyCancellable>()
    
    required init() {
        super.init()
        self.mlModel = HeavyMLModel()
        self.model = ModelComponent(mesh: .generateBox(size: 0.2), materials: [SimpleMaterial()])
    }
    
    func setupBehavior(scene: RealityKit.Scene) {
        // --- THE FLAW: Retain Cycle ---
        // The closure captures 'self' strongly. 
        // The 'subscriptions' set is owned by 'self'.
        // 'self' -> 'subscriptions' -> 'closure' -> 'self'
        scene.subscribe(to: SceneEvents.Update.self) { [weak scene] _ in
            // Even though we use [weak scene], we use 'self' strongly inside
            self.performAIThinking() 
        }
        .store(in: &subscriptions)
    }
    
    func performAIThinking() {
        // Simulate AI logic
        _ = mlModel?.data.count
    }
}

@available(visionOS 1.0, *)
struct AIPetView: View {
    @State private var rootEntity = Entity()
    @State private var pets: [AIPetEntity] = []

    var body: some View {
        VStack {
            RealityView { content in
                content.add(rootEntity)
            }
            .gesture(SpatialTapGesture().onEnded { _ in
                summonPet()
            })

            HStack {
                Button("Summon Pet") { summonPet() }
                Button("Despawn All") { despawnAll() }
            }
        }
    }

    func summonPet() {
        let pet = AIPetEntity()
        pet.setupBehavior(scene: rootEntity.scene!) // Note: In real apps, handle scene availability
        rootEntity.addChild(pet)
        pets.append(pet)
    }

    func despawnAll() {
        for pet in pets {
            pet.removeFromParent()
        }
        pets.removeAll()
        // Even though we remove from parent and the array, 
        // the retain cycle keeps them alive in memory!
    }
}
