
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Accelerate
import Observation

/// Represents a single unit of semantic memory within the AI system.
/// In a real-world app, this would be a CoreData entity or a CloudKit record.
struct MemorySnippet: Sendable, Identifiable {
    let id: UUID
    let text: String
    /// The high-dimensional vector representation of the text.
    let embedding: [Float]
    /// The unique identifier for the tenant (e.g., User ID or Workspace ID).
    /// This is the critical piece of metadata used for isolation.
    let tenantID: String
}

/// A high-performance, thread-safe engine for performing semantic searches
/// restricted by tenant metadata.
///
/// This actor ensures that concurrent searches from different users do not
/// cause data races or memory corruption.
@available(iOS 18.0, macOS 15.0, *)
actor MultiTenantVectorEngine {
    
    /// The underlying storage for all memory snippets across all tenants.
    /// In a production environment, this would be a specialized Vector Database.
    private var globalStore: [MemorySnippet] = []
    
    /// Adds a new memory snippet to the global store.
    /// - Parameter snippet: The semantic memory to be indexed.
    func index(snippet: MemorySnippet) {
        globalStore.append(snippet)
    }
    
    /// Performs a similarity search restricted to a specific tenant.
    ///
    /// This method implements "Pre-Filtering": we first narrow down the search
    /// space to only include the requested tenant, then perform the expensive
    /// vector math only on that subset.
    ///
    /// - Parameters:
    ///   - queryEmbedding: The vector representation of the user's query.
    ///   - tenantID: The unique ID of the tenant requesting the data.
    ///   - limit: The maximum number of results to return.
    /// - Returns: An array of the most semantically similar snippets for that tenant.
    func search(
        queryEmbedding: [Float],
        for tenantID: String,
        limit: Int = 3
    ) async -> [MemorySnippet] {
        
        // 1. METADATA FILTERING (The "Pre-filtering" step)
        // We isolate the tenant's data BEFORE doing any vector math.
        // This ensures User A never sees User B's data.
        let tenantData = globalStore.filter { $0.tenantID == tenantID }
        
        // 2. VECTOR SIMILARITY CALCULATION
        // We map the filtered snippets to their similarity scores.
        let scoredResults = tenantData.map { snippet in
            let score = cosineSimilarity(query: queryEmbedding, target: snippet.embedding)
            return (snippet: snippet, score: score)
        }
        
        // 3. RANKING
        // Sort by score descending (highest similarity first) and take the top K.
        let sortedResults = scoredResults
            .sorted { $0.score > $1.score }
            .prefix(limit)
        
        return sortedResults.map { $0.snippet }
    }
    
    /// Calculates the Cosine Similarity between two vectors using the Accelerate framework.
    /// Cosine similarity measures the cosine of the angle between two vectors.
    /// Formula: (A · B) / (||A|| * ||B||)
    ///
    /// - Parameters:
    ///   - query: The first vector.
    ///   - target: The second vector.
    /// - Returns: A Float representing the similarity (1.0 is identical, 0.0 is orthogonal).
    private func cosineSimilarity(query: [Float], target: [Float]) -> Float {
        guard query.count == target.count, !query.isEmpty else { return 0.0 }
        
        var dotProduct: Float = 0.0
        var queryNorm: Float = 0.0
        var targetNorm: Float = 0.0
        
        let n = Int32(query.count)
        
        // Use Accelerate's vDSP (Digital Signal Processing) for hardware-accelerated math.
        // This is significantly faster than a standard 'for' loop.
        
        // Calculate Dot Product: A · B
        vDSP_dotpr(query, 1, target, 1, &dotProduct, vDSP_Length(n))
        
        // Calculate L2 Norm (Magnitude) of Query: ||A||
        vDSP_svesq(query, 1, &queryNorm, vDSP_Length(n))
        queryNorm = sqrt(queryNorm)
        
        // Calculate L2 Norm (Magnitude) of Target: ||B||
        vDSP_svesq(target, 1, &targetNorm, vDSP_Length(n))
        targetNorm = sqrt(targetNorm)
        
        // Avoid division by zero
        guard queryNorm > 0 && targetNorm > 0 else { return 0.0 }
        
        return dotProduct / (queryNorm * targetNorm)
    }
}

// MARK: - Implementation Example

@available(iOS 18.0, macOS 15.0, *)
@MainActor
struct VoiceAssistantViewModel: ObservableObject {
    private let engine = MultiTenantVectorEngine()
    
    @Published var searchResults: [String] = []
    @Published var isSearching: Bool = false
    
    /// Simulates the setup of the database with data from two different users.
    func setupMockData() async {
        // User A's Data (The "Work" Tenant)
        await engine.index(snippet: MemorySnippet(
            id: UUID(),
            text: "Meeting notes: Project Apollo requires a budget increase.",
            embedding: [0.1, 0.8, 0.0, 0.5], // Simplified 4D vectors
            tenantID: "user_work_123"
        ))
        
        await engine.index(snippet: MemorySnippet(
            id: UUID(),
            text: "Reminder: Buy milk and eggs.",
            embedding: [0.9, 0.1, 0.1, 0.0],
            tenantID: "user_personal_456"
        ))
        
        // User B's Data (The "Personal" Tenant)
        await engine.index(snippet: MemorySnippet(
            id: UUID(),
            text: "Project Apollo is a massive success!",
            embedding: [0.1, 0.7, 0.1, 0.4],
            tenantID: "user_personal_456"
        ))
    }
    
    /// Simulates a user asking a question.
    func performQuery(text: String, tenantID: String) async {
        isSearching = true
        
        // In a real app, you would use an LLM or CoreML to generate this embedding.
        // Here, we simulate a query vector looking for "Project Apollo"
        let simulatedQueryEmbedding: [Float] = [0.1, 0.75, 0.0, 0.45]
        
        // Perform the filtered search
        let results = await engine.search(
            queryEmbedding: simulatedQueryEmbedding,
            for: tenantID
        )
        
        // Update UI on the MainActor
        self.searchResults = results.map { $0.text }
        self.isSearching = false
    }
}

// MARK: - Execution Logic

@available(iOS 18.0, macOS 15.0, *)
func runDemo() async {
    let viewModel = await VoiceAssistantViewModel()
    await viewModel.setupMockData()
    
    print("--- Scenario 1: User 'Work' searches for 'Project Apollo' ---")
    // This user should ONLY see the budget increase note.
    // They should NOT see the "Project Apollo is a success" note, because it belongs to the 'Personal' tenant.
    await viewModel.performQuery(text: "What about Apollo?", tenantID: "user_work_123")
    print("Results: \(await viewModel.searchResults)")
    
    print("\n--- Scenario 2: User 'Personal' searches for 'Project Apollo' ---")
    // This user should see the success note.
    await viewModel.performQuery(text: "What about Apollo?", tenantID: "user_personal_456")
    print("Results: \(await viewModel.searchResults)")
}

// To run in a Swift Playground or Command Line Tool:
// Task { await runDemo() }
