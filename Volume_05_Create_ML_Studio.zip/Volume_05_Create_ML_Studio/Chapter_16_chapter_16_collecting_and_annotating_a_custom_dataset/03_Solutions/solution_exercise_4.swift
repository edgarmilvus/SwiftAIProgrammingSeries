
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import CoreMotion // Requires linking CoreMotion.framework
import Foundation

// Ensure this class is available on a reasonable iOS version.
// Using iOS 17.0 for modern SwiftUI and CoreMotion features.
@available(iOS 17.0, *)
@Observable // Swift 6 equivalent of @Published for classes
class MotionCollector: NSObject {
    var isCollecting = false
    var selectedActivity: String = "Walking"
    var collectionError: String?

    let motionManager = CMMotionManager()
    var motionData: [[String: Any]] = [] // To store raw sensor data
    var collectionTimer: Timer?

    let activityTypes = ["Walking", "Running", "Sitting", "Standing", "Upstairs", "Downstairs"]
    let collectionDuration: TimeInterval = 30.0 // seconds per activity session
    let samplingFrequency: Double = 50.0 // Hz (updates per second)

    override init() {
        super.init()
        // Check if motion updates are available early
        if !motionManager.isDeviceMotionAvailable {
            print("Device Motion updates not available on this device.")
            Task { @MainActor in
                self.collectionError = "Motion sensors not available."
            }
        }
    }

    func startCollection() {
        guard motionManager.isDeviceMotionAvailable else {
            print("Device Motion not available.")
            Task { @MainActor in
                self.collectionError = "Device Motion sensors not available."
            }
            return
        }

        // Clear previous data and errors
        motionData.removeAll()
        collectionError = nil

        // Set update interval
        motionManager.deviceMotionUpdateInterval = 1.0 / samplingFrequency

        // Start collecting device motion updates
        // The handler block is typically called on a background queue managed by CoreMotion
        motionManager.startDeviceMotionUpdates(to: .main) { [weak self] (deviceMotion, error) in
            guard let self = self else { return }

            if let error = error {
                print("CoreMotion error: \(error.localizedDescription)")
                Task { @MainActor in
                    self.collectionError = "Motion update error: \(error.localizedDescription)"
                    self.stopCollection() // Stop on error
                }
                return
            }

            if let motion = deviceMotion {
                self.captureMotionData(deviceMotion: motion)
            }
        }

        // Schedule timer to stop collection after duration
        Task { @MainActor in
            self.isCollecting = true
            self.collectionTimer = Timer.scheduledTimer(withTimeInterval: self.collectionDuration, repeats: false) { _ in
                self.stopCollection()
            }
        }
        print("Started collecting motion data for \(selectedActivity) for \(collectionDuration) seconds.")
    }

    private func captureMotionData(deviceMotion: CMDeviceMotion) {
        let timestamp = Date().timeIntervalSince1970
        var dataEntry: [String: Any] = ["timestamp": timestamp]

        // User acceleration (gravity removed)
        dataEntry["userAccel_x"] = deviceMotion.userAcceleration.x
        dataEntry["userAccel_y"] = deviceMotion.userAcceleration.y
        dataEntry["userAccel_z"] = deviceMotion.userAcceleration.z

        // Rotation rate (gyroscope)
        dataEntry["rotationRate_x"] = deviceMotion.rotationRate.x
        dataEntry["rotationRate_y"] = deviceMotion.rotationRate.y
        dataEntry["rotationRate_z"] = deviceMotion.rotationRate.z

        // Attitude (pitch, roll, yaw) - useful for orientation
        dataEntry["attitude_roll"] = deviceMotion.attitude.roll
        dataEntry["attitude_pitch"] = deviceMotion.attitude.pitch
        dataEntry["attitude_yaw"] = deviceMotion.attitude.yaw

        // Gravity vector - useful for device orientation relative to gravity
        dataEntry["gravity_x"] = deviceMotion.gravity.x
        dataEntry["gravity_y"] = deviceMotion.gravity.y
        dataEntry["gravity_z"] = deviceMotion.gravity.z

        motionData.append(dataEntry)
    }

    func stopCollection() {
        motionManager.stopDeviceMotionUpdates()
        collectionTimer?.invalidate()
        collectionTimer = nil

        Task { @MainActor in
            self.isCollecting = false
        }
        print("Stopped collecting motion data. Samples collected: \(motionData.count)")
        saveMotionData()
    }

    private func saveMotionData() {
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            print("Could not find documents directory.")
            Task { @MainActor in
                self.collectionError = "Could not find documents directory to save data."
            }
            return
        }

        let activityDirectory = documentsDirectory.appendingPathComponent(selectedActivity, isDirectory: true)
        if !FileManager.default.fileExists(atPath: activityDirectory.path) {
            do {
                try FileManager.default.createDirectory(at: activityDirectory, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print("Error creating directory: \(error.localizedDescription)")
                Task { @MainActor in
                    self.collectionError = "Error creating activity directory: \(error.localizedDescription)"
                }
                return
            }
        }

        let filename = activityDirectory.appendingPathComponent("\(UUID().uuidString)_\(selectedActivity).json")

        // Convert motionData to JSON
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: motionData, options: [.prettyPrinted, .fragmentsAllowed])
            try jsonData.write(to: filename)
            print("Saved motion data to: \(filename.lastPathComponent)")
        } catch {
            print("Error saving motion data: \(error.localizedDescription)")
            Task { @MainActor in
                self.collectionError = "Error saving motion data: \(error.localizedDescription)"
            }
        }
    }
}

// Basic SwiftUI View to demonstrate the MotionCollector
@available(iOS 17.0, *)
struct MotionCollectorView: View {
    @State private var motionCollector = MotionCollector() // Using @State for simplicity with @Observable

    var body: some View {
        VStack(spacing: 20) {
            Picker("Activity Type", selection: $motionCollector.selectedActivity) {
                ForEach(motionCollector.activityTypes, id: \.self) {
                    Text($0)
                }
            }
            .pickerStyle(.segmented)
            .padding()

            Button(action: motionCollector.isCollecting ? motionCollector.stopCollection : motionCollector.startCollection) {
                Label(motionCollector.isCollecting ? "Stop Collecting" : "Start Collecting",
                      systemImage: motionCollector.isCollecting ? "stop.circle.fill" : "play.circle.fill")
                    .font(.title2)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(motionCollector.isCollecting ? Color.red : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(15)
            }
            .disabled(motionCollector.collectionError != nil) // Disable if sensors not available
            .padding(.horizontal)

            Text(motionCollector.isCollecting ? "Collecting data for \(motionCollector.selectedActivity)..." : "Ready to collect motion data.")
                .font(.headline)
                .foregroundColor(motionCollector.isCollecting ? .blue : .primary)

            if let error = motionCollector.collectionError {
                Text("Error: \(error)")
                    .foregroundColor(.red)
                    .font(.caption)
                    .multilineTextAlignment(.center)
                    .padding()
            }
        }
        .navigationTitle("Activity Data Collector")
    }
}

// Example usage in an App struct (for context, not part of the solution file)
/*
@main
struct ActivityTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            MotionCollectorView()
        }
    }
}
*/
