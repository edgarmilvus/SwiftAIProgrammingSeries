
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreML
import Vision
import Observation

/// A thread-safe actor dedicated to performing ML inference.
/// By using an actor, we ensure that the heavy model is isolated 
/// from the MainActor (UI) and the ARKit update loop.
@available(visionOS 1.0, *)
actor SpatialIntelligenceEngine {
    
    // The underlying Core ML model
    private let model: VNCoreMLModel
    
    // An observable state to communicate results back to the UI
    // We use @Observable to allow SwiftUI to react to changes.
    @Observable
    public struct InferenceState {
        var detectedLabels: [String] = []
        var isProcessing: Bool = false
    }
    
    public private(set) var state = InferenceState()

    init(model: MLModel) throws {
        self.model = try VNCoreMLModel(for: model)
    }

    /// Performs inference on a provided pixel buffer.
    /// This is an 'async' function, meaning it suspends execution 
    /// without blocking the calling thread.
    @available(visionOS 1.0, *)
    func process(pixelBuffer: CVPixelBuffer) async {
        // Update state to indicate processing has started
        state.isProcessing = true
        
        // Perform the request in a Task to allow for asynchronous handling
        let request = VNRecognizeTextRequest { [weak self] request, error in
            // Handle the results within the Vision completion handler
            Task { [weak self] in
                await self?.handleResults(request.results)
            }
        }
        
        // Configure the request
        request.recognitionLevel = .accurate
        
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        
        do {
            // The actual 'work' happens here. 
            // This call suspends the actor, but not the system.
            try handler.perform([request])
        } catch {
            print("Inference error: \(error)")
        }
    }

    /// Private helper to process results and update the observable state.
    /// This must be called from within the actor to maintain isolation.
    private func handleResults(_ results: [Any]?) {
        guard let observations = results as? [VNRecognizedTextObservation] else {
            state.isProcessing = false
            return
        }
        
        // Extract the top labels from the observations
        let labels = observations.compactMap { $0.topCandidates(1).first?.string }
        
        // Update the @Observable state
        // Because this is an actor, this update is thread-safe.
        self.state.detectedLabels = labels
        self.state.isProcessing = false
    }
}
