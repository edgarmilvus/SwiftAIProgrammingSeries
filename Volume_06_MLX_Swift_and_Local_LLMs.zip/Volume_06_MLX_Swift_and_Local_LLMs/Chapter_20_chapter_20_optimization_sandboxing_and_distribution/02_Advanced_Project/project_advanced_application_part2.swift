
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import MLX
import MLXNN // For Module and Linear
import SimpleTokenizer // Conceptual tokenizer

/// Errors specific to the LLM summarizer service.
enum LLMSummarizerError: Error, LocalizedError {
    case modelLoadingFailed(String)
    case inferenceFailed(String)
    case invalidInput(String)
    case tokenizerError(String)

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let message):
            return "Failed to load LLM model: \(message)"
        case .inferenceFailed(let message):
            return "LLM inference failed: \(message)"
        case .invalidInput(let message):
            return "Invalid input for summarization: \(message)"
        case .tokenizerError(let message):
            return "Tokenizer error: \(message)"
        }
    }
}

/// @available annotation for iOS 18.0 and later, ensuring compatibility with MLX Swift's typical targets.
@available(iOS 18.0, macOS 15.0, visionOS 2.0, *)
/// A custom MLXNN.Module that applies Low-Rank Adaptation (LoRA) to a Linear layer.
/// This module replaces a standard Linear layer during fine-tuning and inference.
final class LoRALinear: MLXNN.Module {
    let linear: MLXNN.Linear // The base linear layer
    let lora_A: MLXArray     // LoRA A matrix (down-projection)
    let lora_B: MLXArray     // LoRA B matrix (up-projection)
    let scale: Float         // Scaling factor for LoRA updates

    /// Initializes a LoRA-enabled Linear layer.
    /// - Parameters:
    ///   - inputDim: The input dimension of the linear layer.
    ///   - outputDim: The output dimension of the linear layer.
    ///   - rank: The rank of the LoRA matrices (typically much smaller than input/output dims).
    ///   - scale: A scaling factor applied to the LoRA output.
    ///   - name: The name of the module.
    init(inputDim: Int, outputDim: Int, rank: Int, scale: Float = 1.0, name: String = "") {
        self.linear = MLXNN.Linear(inputDim: inputDim, outputDim: outputDim)
        // Initialize LoRA matrices with random values for demonstration.
        // In a real scenario, these would be loaded from pre-trained LoRA weights.
        self.lora_A = MLXArray.randomUniform(low: -0.01, high: 0.01, shape: [inputDim, rank])
        self.lora_B = MLXArray.randomUniform(low: -0.01, high: 0.01, shape: [rank, outputDim])
        self.scale = scale
        super.init(name: name)
    }

    /// The forward pass applies the base linear transformation and then adds the LoRA adjustment.
    /// - Parameter x: The input MLXArray.
    /// - Returns: The output MLXArray after applying linear and LoRA transformations.
    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // Base linear transformation
        let baseOutput = linear(x)
        
        // LoRA transformation: (x @ lora_A) @ lora_B * scale
        // This is a low-rank approximation of the weight update.
        let loraOutput = (x @ lora_A @ lora_B) * scale
        
        // Combine base and LoRA outputs
        return baseOutput + loraOutput
    }
}

@available(iOS 18.0, macOS 15.0, visionOS 2.0, *)
/// A simplified LLM module incorporating LoRA-enabled layers.
/// This represents a conceptual block within a larger LLM, demonstrating LoRA integration.
final class SimpleLLM: MLXNN.Module {
    let embedding: MLXNN.Embedding
    let transformerBlock: LoRALinear // Using LoRALinear for a key component
    let outputLinear: MLXNN.Linear

    let vocabSize: Int
    let modelDim: Int
    let maxSequenceLength: Int

    /// Initializes the simplified LLM.
    /// - Parameters:
    ///   - vocabSize: The size of the vocabulary.
    ///   - modelDim: The dimensionality of the model's internal representations.
    ///   - maxSequenceLength: The maximum sequence length the model can process.
    ///   - loraRank: The rank for the LoRA layers.
    ///   - name: The name of the module.
    init(vocabSize: Int, modelDim: Int, maxSequenceLength: Int, loraRank: Int, name: String = "") {
        self.vocabSize = vocabSize
        self.modelDim = modelDim
        self.maxSequenceLength = maxSequenceLength

        // Embedding layer to convert token IDs to dense vectors
        self.embedding = MLXNN.Embedding(outputDimensions: modelDim, vocabularySize: vocabSize)
        
        // A transformer-like block, here simplified to a LoRALinear for demonstration
        self.transformerBlock = LoRALinear(inputDim: modelDim, outputDim: modelDim, rank: loraRank)
        
        // Output layer to project back to vocabulary space for token prediction
        self.outputLinear = MLXNN.Linear(inputDim: modelDim, outputDim: vocabSize)
        
        super.init(name: name)
    }

    /// The forward pass of the simplified LLM.
    /// - Parameter inputTokenIDs: An MLXArray of token IDs (e.g., shape `[batch_size, sequence_length]`).
    /// - Returns: An MLXArray of logits (shape `[batch_size, sequence_length, vocab_size]`).
    override func callAsFunction(_ inputTokenIDs: MLXArray) -> MLXArray {
        // 1. Embed the input token IDs
        let embedded = embedding(inputTokenIDs) // Shape: [batch_size, sequence_length, model_dim]
        
        // 2. Pass through the LoRA-enabled transformer block
        // MLX's lazy evaluation means this graph is built, not immediately computed.
        let transformed = transformerBlock(embedded) // Shape: [batch_size, sequence_length, model_dim]
        
        // 3. Project to vocabulary size for logits
        let logits = outputLinear(transformed) // Shape: [batch_size, sequence_length, vocab_size]
        
        return logits
    }
}
