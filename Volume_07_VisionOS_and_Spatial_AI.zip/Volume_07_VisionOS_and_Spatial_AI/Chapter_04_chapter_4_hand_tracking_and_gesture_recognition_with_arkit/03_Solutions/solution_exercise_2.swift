
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import RealityKit
import ARKit
import Combine

enum ButtonState {
    case idle, hovering, pressed
}

struct ProximityTriggerComponent: Component {
    var activationThreshold: Float = 0.05 // 5cm
    var deactivationThreshold: Float = 0.07 // 7cm
    var currentState: ButtonState = .idle
}

class ProximityButtonSystem: System {
    static let query = EntityQuery(where: .has(ProximityTriggerComponent.self))
    
    required init(scene: Scene) {}
    
    func update(context: SceneUpdateContext) {
        // In a real app, you'd pass the HandTrackingProvider to this system
        // For this exercise, we assume the finger position is being updated externally
    }
    
    // Logic to be called within the update loop
    func processProximity(
        button: Entity, 
        fingerPosition: SIMD3<Float>, 
        handTracking: HandTrackingProvider
    ) {
        guard var trigger = button.components[ProximityTriggerComponent.self] as? ProximityTriggerComponent else { return }
        
        let distance = simd_distance(button.position(relativeTo: nil), fingerPosition)
        let oldState = trigger.currentState
        
        // Implement Hysteresis Logic
        switch trigger.currentState {
        case .idle:
            if distance < trigger.activationThreshold {
                trigger.currentState = .hovering
            }
        case .hovering:
            if distance > trigger.deactivationThreshold {
                trigger.currentState = .idle
            } else if distance < 0.02 { // Very close triggers 'pressed'
                trigger.currentState = .pressed
            }
        case .pressed:
            if distance > trigger.deactivationThreshold {
                trigger.currentState = .hovering
            }
        }
        
        // Apply Visual Feedback if state changed
        if oldState != trigger.currentState {
            applyVisuals(to: button, state: trigger.currentState)
            button.components[ProximityTriggerComponent.self] = trigger
        }
    }
    
    private func applyVisuals(to entity: Entity, state: ButtonState) {
        var material = SimpleMaterial()
        
        switch state {
        case .idle:
            material.color = .init(tint: .white.withAlphaComponent(0.5))
            entity.scale = .one
        case .hovering:
            material.color = .init(tint: .white.withAlphaComponent(1.0))
            entity.scale = .one
        case .pressed:
            material.color = .init(tint: .green)
            entity.move(to: Transform(scale: .init(repeating: 1.2), rotation: entity.orientation, translation: entity.position), 
                        relativeTo: nil, duration: 0.1)
        }
        
        if let model = entity as? ModelEntity {
            model.model?.materials = [material]
        }
    }
}
