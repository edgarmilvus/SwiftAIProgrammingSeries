
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import MLX // Import the MLX framework

// Ensure this code is only available on platforms supporting MLX-Swift
@available(iOS 18.0, macOS 14.0, *)
class SmartSensorDataAnalyzer {

    /// 1. Define the MLX Model: Linear Regression
    ///
    /// Our model inherits from `MLXNN.Module`, which is the base class for all neural network modules in MLX.
    /// It provides mechanisms for managing parameters, handling device placement, and enabling functional transformations.
    ///
    /// This simple model performs `y = mx + b`, where `m` (weight) and `b` (bias) are learnable parameters.
    class LinearRegression: MLXNN.Module {
        /// The linear layer, which encapsulates the weight `m` and bias `b`.
        /// `inputFeatures: 1` means our input `x` is a single scalar value.
        /// `outputFeatures: 1` means our output `y` is also a single scalar value.
        let linear: MLXNN.Linear

        /// Initializes the LinearRegression model.
        override init() {
            self.linear = MLXNN.Linear(inputFeatures: 1, outputFeatures: 1)
            super.init() // Call the superclass initializer
            // Register the linear layer as a submodule. This makes its parameters discoverable by MLX.
            self.register(linear: linear)
        }

        /// The forward pass of the model.
        /// This method defines how input data `x` is transformed into an output prediction.
        /// - Parameter x: An `MLXArray` representing the input data (e.g., sensor reading).
        /// - Returns: An `MLXArray` representing the model's prediction.
        func callAsFunction(_ x: MLXArray) -> MLXArray {
            return linear(x)
        }
    }

    /// 2. Define the Loss Function and Gradient Calculation
    ///
    /// This function computes the Mean Squared Error (MSE) loss between predictions and true labels.
    /// It's designed to be used with `valueAndGradient` to automatically compute gradients.
    ///
    /// - Parameters:
    ///   - model: The `LinearRegression` model.
    ///   - x: Input `MLXArray` (sensor readings).
    ///   - y: True output `MLXArray` (target comfort index).
    /// - Returns: An `MLXArray` representing the scalar loss value.
    func lossFunction(model: LinearRegression, x: MLXArray, y: MLXArray) -> MLXArray {
        let predictions = model(x) // Get predictions from the model
        // Compute Mean Squared Error (MSE) loss
        // (predictions - y)^2 / N, where N is the number of samples
        return MLXNN.MSELoss(predictions: predictions, targets: y)
    }

    /// Entry point for demonstrating the MLX workflow.
    func runExample() {
        print("--- MLX Swift Basic Example: Smart Sensor Data Analyzer ---")

        // 3. Prepare Synthetic Data
        //
        // For a linear regression `y = 2x + 1 + noise`, we create `MLXArray` instances.
        // MLXArray is the core tensor type in MLX, representing multi-dimensional arrays.
        // It benefits from Apple's Unified Memory architecture, providing zero-copy data transfer
        // between CPU and GPU, which is crucial for performance on Apple Silicon.
        let numSamples = 100
        let x_data = MLXArray.random(low: 0.0, high: 10.0, [numSamples, 1]) // 100 samples, 1 feature
        let noise = MLXArray.random(low: -1.0, high: 1.0, [numSamples, 1])
        // y = 2x + 1 + noise
        let y_data = x_data * 2.0 + 1.0 + noise

        print("Generated synthetic data:")
        print("x_data sample (first 5): \(x_data[0..<5].description)")
        print("y_data sample (first 5): \(y_data[0..<5].description)")

        // 4. Instantiate the Model and Optimizer
        let model = LinearRegression()
        // MLXNN.Optimizers.SGD (Stochastic Gradient Descent) is a common optimizer.
        // It takes the model's parameters and a learning rate.
        let optimizer = MLXNN.Optimizers.SGD(learningRate: 0.01)

        print("\nInitial model parameters:")
        print("Weight (m): \(model.linear.weight.description)")
        print("Bias (b): \(model.linear.bias.description)")

        // 5. Perform a Single Training Step
        //
        // MLX uses 'lazy evaluation'. This means operations like `model(x)` or `MLXNN.MSELoss`
        // don't immediately execute. Instead, they build up a computation graph.
        // The graph is only executed when an operation requires a concrete value (like `eval()` or `valueAndGradient`).
        // This allows MLX to optimize the entire graph before execution.

        print("\nPerforming a single training step...")

        // `valueAndGradient` is a core functional transformation in MLX.
        // It takes a function (our `lossFunction`) and returns a new function that,
        // when called with the original function's arguments, returns both the
        // loss value and the gradients of that loss with respect to the model's parameters.
        let lossAndGrad = valueAndGradient(lossFunction)

        // Execute the computation graph for loss and gradients.
        // This is where the lazy evaluation graph is materialized and computed on the device.
        let (loss, gradients) = lossAndGrad(model, x_data, y_data)
        MLX.eval(loss, gradients) // Explicitly evaluate the computation graph

        print("Loss after 1 step: \(loss.item(Float.self))")

        // Update model parameters using the optimizer and computed gradients.
        // The optimizer applies the gradients to the model's parameters.
        optimizer.update(model: model, gradients: gradients)
        MLX.eval(model.parameters()) // Evaluate the updated parameters

        print("Model parameters after 1 step:")
        print("Weight (m): \(model.linear.weight.description)")
        print("Bias (b): \(model.linear.bias.description)")

        // 6. Demonstrate Inference
        //
        // After training (even just one step), we can use the model to make predictions
        // on new, unseen data.
        print("\nDemonstrating inference...")
        let newSensorReading = MLXArray(15.0, [1, 1]) // A new single sensor reading
        let predictedOutput = model(newSensorReading)
        MLX.eval(predictedOutput) // Evaluate the prediction

        print("New sensor reading: \(newSensorReading.item(Float.self))")
        print("Predicted output: \(predictedOutput.item(Float.self))")

        // Expected roughly 2*15 + 1 = 31.0
        let expectedOutput = 2 * 15.0 + 1.0
        print("Expected output (true relationship): \(expectedOutput)")
    }
}

// Example usage in an app's lifecycle (e.g., in an `AppDelegate` or `SceneDelegate`)
// Or within a SwiftUI View's `onAppear` or a button action.
@main
@available(iOS 18.0, macOS 14.0, *)
struct MLXSwiftApp {
    static func main() {
        let analyzer = SmartSensorDataAnalyzer()
        analyzer.runExample()
    }
}
