
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import NaturalLanguage

/// Calculates an estimated reading time for a given text.
///
/// - Parameters:
///   - text: The input string for which to estimate reading time.
///   - wordsPerMinute: The average reading speed in words per minute (e.g., 200-250).
/// - Returns: The estimated reading time in seconds as a `TimeInterval`.
func estimateReadingTime(text: String, wordsPerMinute: Int) -> TimeInterval {
    // Handle edge cases: empty text or invalid reading speed.
    guard !text.isEmpty else {
        return 0.0 // 0 seconds for empty text.
    }
    guard wordsPerMinute > 0 else {
        // If wordsPerMinute is 0 or negative, it's an invalid input for calculation.
        // Returning 0.0 or throwing an error are valid strategies.
        // For this exercise, we'll return 0.0 to avoid division by zero.
        print("Warning: wordsPerMinute must be a positive integer. Returning 0 reading time.")
        return 0.0
    }

    var wordCount = 0

    // Initialize NLTokenizer for word units.
    let wordTokenizer = NLTokenizer(unit: .word)
    wordTokenizer.string = text

    // Enumerate over the tokens to count words.
    wordTokenizer.enumerateTokens(in: text.startIndex..<text.endIndex, unit: .word, using: { _, _ in
        wordCount += 1
        return true // Continue enumeration
    })

    // Calculate estimated reading time.
    // Convert counts to Double for accurate floating-point division.
    let totalWords = Double(wordCount)
    let avgWPM = Double(wordsPerMinute)

    // Time in minutes = Total Words / Words Per Minute
    let estimatedMinutes = totalWords / avgWPM

    // Convert minutes to seconds (TimeInterval is in seconds).
    let estimatedSeconds = estimatedMinutes * 60.0

    return estimatedSeconds
}

// Example Usage:
let shortText = "This is a short paragraph. It has a few sentences. Let's see the reading time."
let avgWPM = 220 // Average words per minute

let readingTimeSeconds1 = estimateReadingTime(text: shortText, wordsPerMinute: avgWPM)
let readingTimeMinutes1 = Int(ceil(readingTimeSeconds1 / 60.0)) // Round up to nearest minute
print("Short Text: '\(shortText)'")
print("Estimated reading time: \(String(format: "%.2f", readingTimeSeconds1)) seconds (\(readingTimeMinutes1) minutes)\n")
// Expected: 1 minute (approx 10 words, so 10/220*60 = 2.72 seconds, ceil to 1 minute)

let longArticle = """
Natural Language Processing (NLP) is a fascinating field at the intersection of computer science, artificial intelligence, and linguistics. It focuses on enabling computers to understand, interpret, and generate human language. From simple tasks like spell checking and grammar correction to complex applications such as machine translation and sentiment analysis, NLP plays a pivotal role in how we interact with technology.

The history of NLP dates back to the 1950s, with early efforts focused on rule-based systems and statistical methods. The advent of machine learning and, more recently, deep learning has revolutionized the field, leading to significant advancements. Modern NLP models, often based on neural networks, can process vast amounts of text data, identify patterns, and make predictions with remarkable accuracy.

Key challenges in NLP include dealing with the ambiguity of human language, understanding context, and handling the nuances of different dialects and registers. Despite these challenges, NLP continues to evolve rapidly, opening up new possibilities for human-computer interaction and information processing.
"""
let readingTimeSeconds2 = estimateReadingTime(text: longArticle, wordsPerMinute: avgWPM)
let readingTimeMinutes2 = Int(ceil(readingTimeSeconds2 / 60.0))
print("Long Article (first few words): '\(longArticle.prefix(50))...'")
print("Estimated reading time: \(String(format: "%.2f", readingTimeSeconds2)) seconds (\(readingTimeMinutes2) minutes)\n")
// Expected: ~1 minute (approx 130 words, so 130/220*60 = 35.45 seconds, ceil to 1 minute)

let emptyText = ""
let readingTimeEmpty = estimateReadingTime(text: emptyText, wordsPerMinute: avgWPM)
print("Empty Text: '\(emptyText)'")
print("Estimated reading time: \(readingTimeEmpty) seconds\n")
// Expected: 0.0 seconds

let invalidWPMText = "Some text."
let readingTimeInvalidWPM = estimateReadingTime(text: invalidWPMText, wordsPerMinute: 0)
print("Invalid WPM Text: '\(invalidWPMText)'")
print("Estimated reading time (WPM=0): \(readingTimeInvalidWPM) seconds\n")
// Expected: 0.0 seconds with a warning message
