
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit

class ProductDetailViewController: UIViewController, UIScrollViewDelegate {

    // MARK: - UI Elements
    private let scrollView = UIScrollView()
    private let pageControl = UIPageControl()
    private let productImageViews: [UIImageView]
    private let addToCartButton = UIButton(type: .system)
    private let confirmationLabel = UILabel()

    // MARK: - Carousel Properties
    private var imageCount: Int { productImageViews.count }
    private var currentPage: Int = 0 {
        didSet {
            pageControl.currentPage = currentPage
            // Announce current image for VoiceOver when page changes
            UIAccessibility.post(notification: .announcement, argument: "Image \(currentPage + 1) of \(imageCount)")
        }
    }
    private var autoAdvanceTimer: Timer?
    private var isAutoAdvancePaused: Bool = false {
        didSet {
            if isAutoAdvancePaused {
                autoAdvanceTimer?.invalidate()
                print("Auto-advance paused.")
                UIAccessibility.post(notification: .announcement, argument: "Image carousel auto-advance paused.")
            } else {
                startAutoAdvanceTimer()
                print("Auto-advance resumed.")
                UIAccessibility.post(notification: .announcement, argument: "Image carousel auto-advance resumed.")
            }
        }
    }

    // MARK: - Initialization
    init(productImageNames: [String]) {
        self.productImageViews = productImageNames.map { name in
            let imageView = UIImageView(image: UIImage(named: name))
            imageView.contentMode = .scaleAspectFit
            imageView.clipsToBounds = true
            imageView.isUserInteractionEnabled = true // Essential for accessibility interaction
            return imageView
        }
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupAccessibility()
        startAutoAdvanceTimer()
        
        // Observe changes to Reduced Motion setting
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(reducedMotionStatusDidChange),
                                               name: UIAccessibility.reduceMotionStatusDidChangeNotification,
                                               object: nil)
        updateAddButtonAnimation() // Initial check
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        configureCarouselLayout()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        autoAdvanceTimer?.invalidate()
        autoAdvanceTimer = nil
        NotificationCenter.default.removeObserver(self)
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground

        // Product Image Carousel
        scrollView.delegate = self
        scrollView.isPagingEnabled = true
        scrollView.showsHorizontalScrollIndicator = false
        view.addSubview(scrollView)

        let stackView = UIStackView(arrangedSubviews: productImageViews)
        stackView.axis = .horizontal
        stackView.spacing = 0
        stackView.distribution = .fillEqually
        scrollView.addSubview(stackView)

        pageControl.numberOfPages = imageCount
        pageControl.currentPageIndicatorTintColor = .systemBlue
        pageControl.pageIndicatorTintColor = .lightGray
        view.addSubview(pageControl)

        // Add to Cart Button
        addToCartButton.setTitle("Add to Cart", for: .normal)
        addToCartButton.titleLabel?.font = UIFont.preferredFont(forTextStyle: .headline)
        addToCartButton.backgroundColor = .systemGreen
        addToCartButton.setTitleColor(.white, for: .normal)
        addToCartButton.layer.cornerRadius = 10
        addToCartButton.addTarget(self, action: #selector(addToCartTapped), for: .touchUpInside)
        view.addSubview(addToCartButton)
        
        // Confirmation Label
        confirmationLabel.text = "Item added to cart!"
        confirmationLabel.font = UIFont.preferredFont(forTextStyle: .subheadline)
        confirmationLabel.textColor = .systemGreen
        confirmationLabel.textAlignment = .center
        confirmationLabel.alpha = 0 // Hidden initially
        view.addSubview(confirmationLabel)

        // Layout constraints
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        stackView.translatesAutoresizingMaskIntoConstraints = false
        pageControl.translatesAutoresizingMaskIntoConstraints = false
        addToCartButton.translatesAutoresizingMaskIntoConstraints = false
        confirmationLabel.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.4),

            stackView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            stackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            stackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            stackView.heightAnchor.constraint(equalTo: scrollView.heightAnchor), // Essential for horizontal scroll view

            pageControl.topAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: 8),
            pageControl.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            addToCartButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            addToCartButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            addToCartButton.heightAnchor.constraint(equalToConstant: 50),
            addToCartButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            
            confirmationLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            confirmationLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            confirmationLabel.bottomAnchor.constraint(equalTo: addToCartButton.topAnchor, constant: -10)
        ])
    }

    private func configureCarouselLayout() {
        // Update stackView width to enable horizontal scrolling
        let contentWidth = scrollView.bounds.width * CGFloat(imageCount)
        NSLayoutConstraint.activate([
            stackView.widthAnchor.constraint(equalToConstant: contentWidth)
        ])
        // Ensure each image view takes up the full scroll view width
        for imageView in productImageViews {
            NSLayoutConstraint.activate([
                imageView.widthAnchor.constraint(equalTo: scrollView.widthAnchor)
            ])
        }
        scrollView.contentSize = CGSize(width: contentWidth, height: scrollView.bounds.height)
    }

    // MARK: - Accessibility Setup
    private func setupAccessibility() {
        // Carousel accessibility
        scrollView.isAccessibilityElement = true
        scrollView.accessibilityLabel = "Product Images"
        scrollView.accessibilityValue = "Image \(currentPage + 1) of \(imageCount)"
        scrollView.accessibilityHint = "Swipe left or right to view more images."
        
        // Add custom actions for auto-advance
        let pauseAction = UIAccessibilityCustomAction(name: "Pause Auto-Advance") { [weak self] _ in
            self?.isAutoAdvancePaused = true
            return true
        }
        let resumeAction = UIAccessibilityCustomAction(name: "Resume Auto-Advance") { [weak self] _ in
            self?.isAutoAdvancePaused = false
            return true
        }
        scrollView.accessibilityCustomActions = [pauseAction, resumeAction]

        // Individual image accessibility (optional, if they have unique descriptions)
        for (index, imageView) in productImageViews.enumerated() {
            imageView.isAccessibilityElement = true
            imageView.accessibilityLabel = "Product image \(index + 1)"
            // Example: If images have specific descriptions, you'd add them here
            // imageView.accessibilityValue = "Red t-shirt front view"
            imageView.accessibilityHint = "Double tap to view full image details."
        }
        
        // Make page control accessible as a progress indicator
        pageControl.isAccessibilityElement = true
        pageControl.accessibilityLabel = "Image page indicator"
        pageControl.accessibilityValue = "Currently on page \(currentPage + 1) of \(imageCount)"
        // pageControl.accessibilityTraits = .updatesFrequently // if it changes often
    }

    // MARK: - Carousel Auto-Advance
    private func startAutoAdvanceTimer() {
        autoAdvanceTimer?.invalidate() // Invalidate any existing timer
        if !isAutoAdvancePaused {
            autoAdvanceTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: true) { [weak self] _ in
                self?.advanceCarousel()
            }
        }
    }

    @objc private func advanceCarousel() {
        let nextPage = (currentPage + 1) % imageCount
        let xOffset = CGFloat(nextPage) * scrollView.bounds.width
        scrollView.setContentOffset(CGPoint(x: xOffset, y: 0), animated: true)
        currentPage = nextPage // scrollViewDidScroll will update this based on actual scroll
    }

    // MARK: - UIScrollViewDelegate
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let page = round(scrollView.contentOffset.x / scrollView.bounds.width)
        if Int(page) != currentPage {
            currentPage = Int(page)
            // Update accessibility value for the scroll view itself
            scrollView.accessibilityValue = "Image \(currentPage + 1) of \(imageCount)"
            pageControl.accessibilityValue = "Currently on page \(currentPage + 1) of \(imageCount)"
        }
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        // Pause auto-advance when user interacts with carousel
        if !isAutoAdvancePaused {
            autoAdvanceTimer?.invalidate()
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        // Resume auto-advance after user interaction, if not explicitly paused
        if !isAutoAdvancePaused {
            startAutoAdvanceTimer()
        }
    }

    // MARK: - Add to Cart Logic
    @objc private func addToCartTapped() {
        // Simulate adding item to cart
        print("Item added to cart!")
        
        // 1. Reduced Motion for button feedback
        if UIAccessibility.isReduceMotionEnabled {
            // Non-animated feedback: immediate color change or haptic only
            addToCartButton.backgroundColor = .systemGray
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
                self?.addToCartButton.backgroundColor = .systemGreen
            }
        } else {
            // Animated feedback: subtle bounce
            UIView.animate(withDuration: 0.1, animations: {
                self.addToCartButton.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
            }) { _ in
                UIView.animate(withDuration: 0.2) {
                    self.addToCartButton.transform = .identity
                }
            }
        }
        
        // 2. Haptic Feedback
        let generator = UIImpactFeedbackGenerator(style: .medium)
        generator.prepare()
        generator.impactOccurred()
        
        // 3. VoiceOver Announcement
        let currentCartItemCount = 3 // Example value
        let confirmationMessage = String(format: NSLocalizedString("item_added_to_cart_confirmation", comment: "Confirmation message when item is added to cart"), currentCartItemCount)
        UIAccessibility.post(notification: .announcement, argument: confirmationMessage)
        
        // Show confirmation label temporarily
        confirmationLabel.alpha = 1
        UIView.animate(withDuration: 0.5, delay: 2.0, options: [], animations: {
            self.confirmationLabel.alpha = 0
        }, completion: nil)
        
        // 4. Focus Management: Shift VoiceOver focus to the confirmation label
        // Using .layoutChanged with an argument is the recommended way to move focus.
        UIAccessibility.post(notification: .layoutChanged, argument: confirmationLabel)
    }
    
    // MARK: - Reduced Motion Observation
    @objc private func reducedMotionStatusDidChange() {
        updateAddButtonAnimation()
    }
    
    private func updateAddButtonAnimation() {
        if UIAccessibility.isReduceMotionEnabled {
            print("Reduced motion enabled: No animation for Add to Cart button.")
            // Ensure button is in its default, non-animated state
            addToCartButton.layer.removeAllAnimations()
            addToCartButton.transform = .identity
        } else {
            print("Reduced motion disabled: Animations are allowed for Add to Cart button.")
            // No action needed here, animation will be applied on tap
        }
    }
}

// MARK: - Example Usage (in SceneDelegate or AppDelegate)
/*
// In SceneDelegate.swift (for iOS 13+)
func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
    guard let windowScene = (scene as? UIWindowScene) else { return }
    let window = UIWindow(windowScene: windowScene)
    
    let productImages = ["product_image_1", "product_image_2", "product_image_3", "product_image_4"]
    let productDetailVC = ProductDetailViewController(productImageNames: productImages)
    
    window.rootViewController = productDetailVC
    self.window = window
    window.makeKeyAndVisible()
}

// Ensure you have images named "product_image_1", "product_image_2", etc. in your Asset Catalog.

// For localization of "item_added_to_cart_confirmation":
// Add to Localizable.strings (English):
// "item_added_to_cart_confirmation" = "Item added to cart. Cart now has %d items.";
*/
