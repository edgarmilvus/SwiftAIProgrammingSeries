
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

// Reuse ChatMessage and Tokenizer protocol/MockTokenizer from Exercise 1
// Reuse calculateTokenCount from Exercise 1

class SlidingWindowMemory {
    private var messages: [ChatMessage] = []
    let tokenBudget: Int
    private let tokenizer: Tokenizer

    init(tokenBudget: Int, tokenizer: Tokenizer) {
        self.tokenBudget = tokenBudget
        self.tokenizer = tokenizer
    }

    func addMessage(_ newMessage: ChatMessage) {
        messages.append(newMessage) // Add the new message to the end
        
        // Continuously remove the oldest message from the beginning
        // until the total token count is within the budget or no messages are left.
        while calculateTokenCount(for: messages, using: tokenizer) > tokenBudget && !messages.isEmpty {
            messages.removeFirst() // Remove the oldest message
        }
        // Edge case: If a single message itself exceeds the budget, it will remain
        // as the only message, still over budget, which is acceptable for this strategy.
    }

    func currentContext() -> [ChatMessage] {
        return messages // Return the current state of messages in the window
    }

    func currentTokenCount() -> Int {
        return calculateTokenCount(for: messages, using: tokenizer) // Recalculate current token count
    }
}

// Example Usage (for testing the implementation)
/*
let tokenizer = MockTokenizer()
let windowMemory = SlidingWindowMemory(tokenBudget: 30, tokenizer: tokenizer)

print("--- Adding messages to SlidingWindowMemory (Budget: 30 tokens) ---")

windowMemory.addMessage(ChatMessage(role: "user", content: "This is the first message.", timestamp: Date().addingTimeInterval(-100))) // ~7 tokens
print("After 1st msg (\(windowMemory.currentTokenCount()) tokens): \(windowMemory.currentContext().map { $0.content })")

windowMemory.addMessage(ChatMessage(role: "assistant", content: "And this is the second, a bit longer response from the AI.", timestamp: Date().addingTimeInterval(-90))) // ~12 tokens
print("After 2nd msg (\(windowMemory.currentTokenCount()) tokens): \(windowMemory.currentContext().map { $0.content })")

windowMemory.addMessage(ChatMessage(role: "user", content: "Okay, I understand. Let's move on to the next topic.", timestamp: Date().addingTimeInterval(-80))) // ~13 tokens
print("After 3rd msg (\(windowMemory.currentTokenCount()) tokens): \(windowMemory.currentContext().map { $0.content })")
// Expected: First message might be dropped here as total tokens (~7+12+13 = 32) exceed 30.

windowMemory.addMessage(ChatMessage(role: "assistant", content: "Certainly, what would you like to discuss next?", timestamp: Date().addingTimeInterval(-70))) // ~10 tokens
print("After 4th msg (\(windowMemory.currentTokenCount()) tokens): \(windowMemory.currentContext().map { $0.content })")
// Expected: Oldest messages continue to be dropped to maintain budget, ensuring the window slides.
*/
