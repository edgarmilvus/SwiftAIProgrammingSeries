
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import MLX
import MLXNN
import MLXOptimizers

// Ensure the code runs on recent Apple platforms
@available(macOS 14.0, iOS 17.0, *)
class MLXLoRAExample {

    /// Defines a simple "base model" that represents a pre-trained, frozen component.
    /// In a real app, this would be a much larger model.
    class PhotoAdjusterBase: Module {
        let linear: Linear

        /// Initializes the base model with an input and output feature dimension.
        /// - Parameters:
        ///   - inputFeatures: The number of input features.
        ///   - outputFeatures: The number of output features (e.g., image adjustment parameters).
        public init(inputFeatures: Int, outputFeatures: Int) {
            self.linear = Linear(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
            super.init()
            // Mark the base model's parameters as non-trainable for this example.
            // In MLX, parameters are trainable by default. We'll achieve "freezing"
            // by only updating the adapter's parameters later.
        }

        /// Performs a forward pass through the base model.
        /// - Parameter x: The input MLXArray (e.g., image features).
        /// - Returns: The output MLXArray (e.g., default adjustment values).
        override public func callAsFunction(_ x: MLXArray) -> MLXArray {
            return linear(x)
        }
    }

    /// Defines a small "preference adapter" that learns to adjust the base model's output.
    /// This simulates the LoRA adapter's role, adding a small delta to the base output.
    class UserPreferenceAdapter: Module {
        let adapterLinear: Linear

        /// Initializes the adapter with the same input/output dimensions as the base model's output.
        /// - Parameters:
        ///   - inputFeatures: The number of features to adjust (matching base output).
        ///   - outputFeatures: The number of adjusted features.
        public init(inputFeatures: Int, outputFeatures: Int) {
            // The adapter's output dimension matches the base model's output.
            self.adapterLinear = Linear(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
            super.init()
            // These parameters are intended to be trained.
        }

        /// Performs a forward pass through the adapter.
        /// - Parameter x: The input MLXArray (e.g., the base model's output or relevant features).
        /// - Returns: The MLXArray representing the learned adjustment (delta).
        override public func callAsFunction(_ x: MLXArray) -> MLXArray {
            return adapterLinear(x)
        }
    }

    /// Combines the base model and the adapter to produce the final adjusted output.
    /// Only the adapter's parameters will be updated during training.
    class CombinedPhotoAdjuster: Module {
        let baseModel: PhotoAdjusterBase
        let adapter: UserPreferenceAdapter

        /// Initializes the combined model.
        /// - Parameters:
        ///   - baseModel: An instance of the pre-trained `PhotoAdjusterBase`.
        ///   - adapter: An instance of the `UserPreferenceAdapter`.
        public init(baseModel: PhotoAdjusterBase, adapter: UserPreferenceAdapter) {
            self.baseModel = baseModel
            self.adapter = adapter
            super.init()
        }

        /// Performs a forward pass, combining the base model's output with the adapter's adjustment.
        /// - Parameter x: The input MLXArray (e.g., image features).
        /// - Returns: The final adjusted output.
        override public func callAsFunction(_ x: MLXArray) -> MLXArray {
            // Get the default adjustment from the base model
            let baseOutput = baseModel(x)
            // Get the learned adjustment (delta) from the adapter, using the base output as context
            let adapterOutput = adapter(baseOutput) // Adapter learns to modify baseOutput
            // Combine them: base output + adapter's delta
            return baseOutput + adapterOutput
        }
    }

    /// Defines a simple Mean Squared Error (MSE) loss function.
    /// - Parameters:
    ///   - predictions: The model's output.
    ///   - targets: The desired target values.
    /// - Returns: The scalar loss value.
    static func loss(predictions: MLXArray, targets: MLXArray) -> MLXArray {
        return mean(square(predictions - targets))
    }

    func runExample() {
        let inputFeatures = 10 // e.g., features extracted from an image
        let outputFeatures = 3 // e.g., brightness, contrast, saturation adjustments
        let batchSize = 4 // Number of samples in a batch

        // 1. Initialize Base Model and Adapter
        // The base model is pre-trained and its parameters will not be updated.
        let baseModel = PhotoAdjusterBase(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
        // The adapter is a small module whose parameters will be trained.
        let adapter = UserPreferenceAdapter(inputFeatures: outputFeatures, outputFeatures: outputFeatures)

        // 2. Combine them into a single model for inference and training setup
        let combinedModel = CombinedPhotoAdjuster(baseModel: baseModel, adapter: adapter)

        // 3. Define an Optimizer for the Adapter
        // We only want to optimize the parameters of the 'adapter' module.
        // MLX's functional approach makes this explicit.
        let optimizer = Adam(learningRate: 0.01)

        // 4. Simulate Data (Input features and target user preferences)
        // Dummy input data representing image features
        let x_train = MLXArray.randomUniform(low: 0, high: 1, [batchSize, inputFeatures])
        // Dummy target data representing a user's desired adjustments
        // For simplicity, let's say the user prefers slightly higher values than a baseline.
        let y_train = MLXArray.randomUniform(low: 0.5, high: 1.5, [batchSize, outputFeatures])

        print("--- Starting LoRA-like Adapter Training ---")
        print("Initial parameters of the adapter:")
        combinedModel.parameters().filter { $0.key.contains("adapter") }.forEach { (key, value) in
            print("  \(key): \(value.shape)")
        }

        // 5. Training Loop
        let numEpochs = 100
        for epoch in 0..<numEpochs {
            // MLX's valueAndGradient function computes both the loss and its gradients
            // with respect to the specified parameters (here, the adapter's parameters).
            // This is a key functional transformation pattern in MLX.
            let (lossValue, gradients) = valueAndGradient(combinedModel.parameters()) { params in
                // Create a temporary model with the current parameters for the gradient computation.
                // This is how MLX's functional API works: it rebuilds the computation graph
                // for each gradient calculation.
                let currentModel = combinedModel.update(parameters: params)
                let predictions = currentModel(x_train)
                return MLXLoRAExample.loss(predictions: predictions, targets: y_train)
            }

            // Apply gradients only to the adapter's parameters.
            // We filter the gradients to include only those belonging to the 'adapter' module.
            let adapterGradients = gradients.filter { $0.key.contains("adapter") }

            // Update the adapter's parameters using the optimizer.
            // The `optimizer.update()` returns a new set of parameters for the adapter.
            let adapterParameters = combinedModel.adapter.parameters()
            let (newAdapterParameters, updates) = optimizer.update(
                parameters: adapterParameters,
                gradients: adapterGradients
            )

            // Update the combined model's adapter with the new parameters.
            // This is where the lazy evaluation graph is 'evaluated' and parameters updated.
            combinedModel.adapter.update(parameters: newAdapterParameters)

            // Print loss periodically
            if epoch % 10 == 0 {
                // To get the actual scalar value of the loss, we need to `eval()` it.
                // MLX operations are lazy; `eval()` forces computation.
                print("Epoch \(epoch), Loss: \(lossValue.item(Float.self))")
            }
        }

        print("--- Training Complete ---")
        print("Final parameters of the adapter:")
        combinedModel.parameters().filter { $0.key.contains("adapter") }.forEach { (key, value) in
            print("  \(key): \(value.shape)")
        }

        // 6. Inference with the fine-tuned model
        let testInput = MLXArray.randomUniform(low: 0, high: 1, [1, inputFeatures])
        let finalPrediction = combinedModel(testInput)
        let basePrediction = baseModel(testInput) // What the base model alone would predict

        print("\nTest Input: \(testInput.description)")
        print("Base Model Prediction (frozen): \(basePrediction.description)")
        print("Combined Model Prediction (adapter fine-tuned): \(finalPrediction.description)")
        print("Difference (Adapter's effect): \((finalPrediction - basePrediction).description)")
    }
}

// Entry point for the example
if #available(macOS 14.0, iOS 17.0, *) {
    let example = MLXLoRAExample()
    example.runExample()
} else {
    print("MLX Swift requires macOS 14.0+ or iOS 17.0+.")
}
