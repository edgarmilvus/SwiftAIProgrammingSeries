
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import RealityKit
import ARKit
import simd

struct SpatialEvent {
    let label: String
    let direction: simd_float3 // Unit vector
}

@MainActor
class SpatialSoundManager: ObservableObject {
    var worldAnchor: Entity?
    
    /// Translates a sound event into a physical marker in the world
    func placeMarker(for event: SpatialEvent, relativeTo userTransform: simd_float4x4) {
        // 1. Simulate Distance
        let distance: Float = 1.5
        
        // 2. Calculate Position in Device/Camera Space
        // The sound is 'event.direction' away from the user's head
        let localPosition = event.direction * distance
        
        // 3. Transform Local Position to World Space
        // We multiply the user's world transform by the local offset
        let worldPosition4 = userTransform * simd_float4(localPosition, 1.0)
        let worldPosition3 = simd_make_float3(worldPosition4)
        
        // 4. Create and Place the Marker
        let marker = createMarker(for: event.label)
        marker.position = worldPosition3
        
        // Add to the scene (assuming a root entity exists)
        // In visionOS, we'd ideally attach to an AnchorEntity
    }
    
    private func createMarker(for label: String) -> ModelEntity {
        let mesh = MeshResource.generateSphere(radius: 0.05)
        let material = UnlitMaterial(color: .red) // Glowing effect
        let entity = ModelEntity(mesh: mesh, materials: [material])
        
        // Add a fade-out effect
        Task {
            try? await Task.sleep(for: .seconds(3))
            // Implementation of fade-out would go here
            entity.removeFromParent()
        }
        
        return entity
    }
}

// Helper to simulate the direction detection
func getSimulatedDirection() -> simd_float3 {
    // Returns a random direction on a sphere
    let x = Float.random(in: -1...1)
    let y = Float.random(in: -0.5...0.5) // Keep it mostly at eye level
    let z = Float.random(in: -1...1)
    return normalize(simd_float3(x, y, z))
}
