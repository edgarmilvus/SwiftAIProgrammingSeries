
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
struct EvaluationReport: Sendable, CustomStringConvertible { // Explicitly conform to Sendable
    let accuracy: Double
    let precision: Double
    let recall: Double
    let f1Score: Double // Added for more comprehensive metrics
    let confusionMatrix: [[Int]] // Example: a 2x2 matrix for binary classification

    var description: String {
        "Acc: \(String(format: "%.2f", accuracy)), Prec: \(String(format: "%.2f", precision)), Rec: \(String(format: "%.2f", recall)), F1: \(String(format: "%.2f", f1Score))"
    }

    // Example of a more complex Sendable struct
    struct ConfusionMatrix: Sendable {
        let truePositives: Int
        let trueNegatives: Int
        let falsePositives: Int
        let falseNegatives: Int
        
        // Can also include methods, as long as they don't introduce mutable shared state issues
        var total: Int {
            truePositives + trueNegatives + falsePositives + falseNegatives
        }
    }
    
    // Initializer for demonstration
    init(accuracy: Double, precision: Double, recall: Double, f1Score: Double, confusionMatrix: [[Int]]) {
        self.accuracy = accuracy
        self.precision = precision
        self.recall = recall
        self.f1Score = f1Score
        self.confusionMatrix = confusionMatrix
    }
}

// A function that might pass an EvaluationReport between tasks
@available(iOS 18.0, *)
func processReportInBackground(report: EvaluationReport) async {
    // This task can safely access 'report' because it's Sendable
    print("Processing report in background: \(report.description)")
    try? await Task.sleep(for: .seconds(1))
    print("Background processing complete for report.")
}

// Example of creating and passing a Sendable report
@available(iOS 18.0, *)
func generateAndProcessReport() async {
    let sampleReport = EvaluationReport(
        accuracy: 0.92,
        precision: 0.89,
        recall: 0.95,
        f1Score: 0.92,
        confusionMatrix: [[80, 5], [10, 100]] // Example: 2x2 matrix
    )
    await processReportInBackground(report: sampleReport)
}
