
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import BackgroundTasks
import CoreML // For MLModel compilation
import UIKit // For AppDelegate context

// MARK: - Helper Logger (for all exercises)
struct Logger {
    static func log(_ message: String, category: String = "BackgroundTasks", isError: Bool = false) {
        let timestamp = DateFormatter.localizedString(from: Date(), dateStyle: .medium, timeStyle: .medium)
        let level = isError ? "ERROR" : "INFO"
        print("[\(timestamp)] [\(category)] [\(level)] \(message)")
    }
}

// MARK: - Mock API Service (for Exercise 3)
struct MockAPI {
    static let shared = MockAPI()

    enum APIError: Error {
        case invalidURL
        case networkError(Error)
        case decodingError(Error)
        case serverError(statusCode: Int)
        case cancelled
    }

    // Simulate downloading a Core ML model file
    func downloadMLModel(to destinationURL: URL, progress: ((Double) -> Void)? = nil) async throws {
        Logger.log("Simulating downloading ML model to \(destinationURL.lastPathComponent)...", category: "MockAPI")
        let totalBytes = 10 * 1024 * 1024 // 10 MB
        var downloadedBytes: Int = 0

        _ = Date() // startTime, not used but good for real impl
        while downloadedBytes < totalBytes {
            try Task.checkCancellation() // Allow cancellation during download simulation
            let chunkSize = min(totalBytes - downloadedBytes, 1024 * 1024) // 1 MB chunks
            downloadedBytes += chunkSize
            let currentProgress = Double(downloadedBytes) / Double(totalBytes)
            progress?(currentProgress)
            // Logger.log(String(format: "Download progress: %.2f%%", currentProgress * 100), category: "MockAPI") // Too verbose for background
            try await Task.sleep(nanoseconds: 500_000_000) // Simulate chunk download time
        }
        Logger.log("ML model download simulated successfully.", category: "MockAPI")
        // Create a dummy file at the destination. For .mlpackage, it's a directory.
        // For simplicity, we'll create a dummy file. A real .mlpackage is a directory.
        // The compilation step assumes a .mlpackage (directory) or .mlmodel (file)
        // For this mock, we'll just create a file that `MLModel.compileModel` can "process".
        let dummyContent = "This is a dummy ML model content for simulation purposes. This could be a .mlpackage or .mlmodel."
        try dummyContent.write(to: destinationURL, atomically: true, encoding: .utf8)
        Logger.log("Dummy ML model file created at \(destinationURL.path)", category: "MockAPI")
    }
}

// MARK: - Core ML Model Management (for Exercise 3)
enum MLModelError: Error {
    case downloadFailed(Error)
    case compilationFailed(Error)
    case fileOperationFailed(Error)
    case cancellation
    case unknown
    case invalidModelURL
}

// A wrapper for MLModel.compileModel to make it async
@available(iOS 18.0, macOS 15.0, *) // Assuming modern OS versions for Swift 6 context
func compileCoreMLModel(at sourceURL: URL) async throws -> URL {
    Logger.log("Simulating Core ML model compilation for: \(sourceURL.lastPathComponent)", category: "CoreML")
    return try await withCheckedThrowingContinuation { continuation in
        // Simulate compilation delay
        Task {
            do {
                try await Task.sleep(nanoseconds: 3_000_000_000) // Simulate long compilation
                try Task.checkCancellation()

                // MLModel.compileModel is asynchronous.
                // For a real .mlpackage, sourceURL would be a directory.
                // For this simulation, we assume `sourceURL` is a file that can be "compiled".
                // In a real scenario, you'd download the .mlpackage, then compile its contents.
                // For the purpose of this exercise, we'll simulate the output URL.
                let compiledModelURL = FileManager.default.temporaryDirectory
                    .appendingPathComponent(UUID().uuidString)
                    .appendingPathExtension("mlmodelc")

                // Simulate creation of compiled model directory
                try FileManager.default.createDirectory(at: compiledModelURL, withIntermediateDirectories: true, attributes: nil)
                let dummyCompiledContent = "Compiled model data."
                try dummyCompiledContent.write(to: compiledModelURL.appendingPathComponent("model.bin"), atomically: true, encoding: .utf8)

                Logger.log("Core ML model compilation simulated successfully to: \(compiledModelURL.lastPathComponent)", category: "CoreML")
                continuation.resume(returning: compiledModelURL)

            } catch {
                Logger.log("Core ML model compilation simulation failed: \(error.localizedDescription)", category: "CoreML", isError: true)
                continuation.resume(throwing: MLModelError.compilationFailed(error))
            }
        }
    }
}

// MARK: - AppDelegate / SceneDelegate context
class AppDelegate: UIResponder, UIApplicationDelegate {

    // MARK: - Background Task Identifiers
    static let mlModelUpdateTaskIdentifier = "com.example.app.updateMLModel"
    // Other task identifiers for subsequent exercises would go here
    // ...

    // Cancellation token for the ML model update task
    private var mlModelUpdateTaskCancellationToken: Task<Void, Never>?

    // For Exercise 3
    private var activeMLModelURL: URL? {
        get {
            if let path = UserDefaults.standard.string(forKey: "activeMLModelPath") {
                return URL(fileURLWithPath: path)
            }
            return nil
        }
        set {
            if let path = newValue?.path {
                UserDefaults.standard.set(path, forKey: "activeMLModelPath")
                Logger.log("Active ML model path updated to: \(path)", category: "MLModelManager")
            } else {
                UserDefaults.standard.removeObject(forKey: "activeMLModelPath")
                Logger.log("Active ML model path cleared.", category: "MLModelManager")
            }
        }
    }

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        Logger.log("App finished launching.", category: "AppDelegate")
        
        // Initialize a dummy active model path if not already set
        if activeMLModelURL == nil {
            let modelsDir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("models")
            let initialModelPath = modelsDir.appendingPathComponent("initial_model.mlmodelc")
            try? FileManager.default.createDirectory(at: modelsDir, withIntermediateDirectories: true, attributes: nil)
            let dummyContent = "Initial dummy model content."
            try? dummyContent.write(to: initialModelPath, atomically: true, encoding: .utf8)
            activeMLModelURL = initialModelPath
            Logger.log("Initial dummy ML model set at: \(initialModelPath.path)", category: "Exercise 3 Setup")
        }

        registerBackgroundTasks() // Register all background tasks
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        Logger.log("App entered background. Scheduling tasks...", category: "AppDelegate")
        scheduleMLModelUpdate() // Schedule the ML model update task
        // Other task scheduling for subsequent exercises would go here
        // ...
    }

    // MARK: - Task Registration
    private func registerBackgroundTasks() {
        Logger.log("Registering background tasks...", category: "BGTaskScheduler")

        // Exercise 3: Processing Task (ML Model Update)
        BGTaskScheduler.shared.register(forIdentifier: AppDelegate.mlModelUpdateTaskIdentifier, using: nil) { task in
            Logger.log("Received BGProcessingTask: \(task.identifier)", category: "BGTaskScheduler")
            self.handleMLModelUpdate(task: task as! BGProcessingTask)
        }
        // Other task registrations for subsequent exercises would go here
        // ...
    }

    // MARK: - Task Scheduling
    private func scheduleMLModelUpdate() {
        let request = BGProcessingTaskRequest(identifier: AppDelegate.mlModelUpdateTaskIdentifier)
        request.requiresNetworkAccess = true
        request.requiresExternalPower = true // Model download and compilation can be intensive
        request.earliestBeginDate = Date(timeIntervalSinceNow: 60 * 60 * 4) // Try every 4 hours, or when conditions are optimal (charging, WiFi)

        do {
            try BGTaskScheduler.shared.submit(request)
            Logger.log("Scheduled BGProcessingTask for \(AppDelegate.mlModelUpdateTaskIdentifier)", category: "BGTaskScheduler")
        } catch {
            Logger.log("Could not schedule ML model update task: \(error.localizedDescription)", category: "BGTaskScheduler", isError: true)
        }
    }

    // MARK: - Task Handlers

    // Exercise 3: On-Device Core ML Model Lifecycle Management Handler
    private func handleMLModelUpdate(task: BGProcessingTask) {
        Logger.log("Starting Core ML model update task...", category: "MLModelUpdate")

        // Store the Task in a property so it can be cancelled by the expiration handler.
        mlModelUpdateTaskCancellationToken = Task {
            var success = false
            var tempDownloadedModelURL: URL?
            var tempCompiledModelURL: URL?
            var backupActiveModelURL: URL? // For atomic replacement rollback

            do {
                // Set the expiration handler immediately.
                task.expirationHandler = {
                    Logger.log("ML model update task expired. Cancelling...", category: "MLModelUpdate", isError: true)
                    self.mlModelUpdateTaskCancellationToken?.cancel() // Cancel the async Task
                    task.setTaskCompleted(success: false)
                }

                // 1. Download new model
                let downloadedModelsDir = FileManager.default.temporaryDirectory.appendingPathComponent("downloaded_ml_models")
                try FileManager.default.createDirectory(at: downloadedModelsDir, withIntermediateDirectories: true, attributes: nil)
                tempDownloadedModelURL = downloadedModelsDir.appendingPathComponent("new_model_\(UUID().uuidString).mlpackage") // Or .mlmodel

                try await MockAPI.shared.downloadMLModel(to: tempDownloadedModelURL!) { progress in
                    // Logger.log("Download progress: \(progress * 100)%", category: "MLModelUpdate") // Can log, but often too verbose
                }
                Logger.log("Model download complete.", category: "MLModelUpdate")
                try Task.checkCancellation()

                // 2. Compile (if .mlpackage or .mlmodel)
                // MLModel.compileModel expects a URL to a .mlmodel or .mlpackage
                // Our mock creates a dummy file, which we'll treat as a compile-able source.
                tempCompiledModelURL = try await compileCoreMLModel(at: tempDownloadedModelURL!)
                Logger.log("Model compilation complete.", category: "MLModelUpdate")
                try Task.checkCancellation()

                // 3. Atomic Replacement
                guard let newModelURL = tempCompiledModelURL else {
                    throw MLModelError.unknown
                }

                let modelsDirectory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("models")
                try FileManager.default.createDirectory(at: modelsDirectory, withIntermediateDirectories: true, attributes: nil)

                let targetModelURL = modelsDirectory.appendingPathComponent("active_model.mlmodelc")
                let backupModelURL = modelsDirectory.appendingPathComponent("backup_model.mlmodelc")

                // Attempt to move current active model to backup
                if let currentActiveModel = self.activeMLModelURL, FileManager.default.fileExists(atPath: currentActiveModel.path) {
                    if FileManager.default.fileExists(atPath: backupModelURL.path) {
                        try FileManager.default.removeItem(at: backupModelURL)
                    }
                    try FileManager.default.moveItem(at: currentActiveModel, to: backupModelURL)
                    backupActiveModelURL = backupModelURL
                    Logger.log("Backed up current active model to: \(backupModelURL.lastPathComponent)", category: "MLModelUpdate")
                }

                // Move new compiled model to active location
                if FileManager.default.fileExists(atPath: targetModelURL.path) {
                    try FileManager.default.removeItem(at: targetModelURL) // Remove old active if it wasn't backed up or was a different name
                }
                try FileManager.default.moveItem(at: newModelURL, to: targetModelURL)
                self.activeMLModelURL = targetModelURL // Update our reference
                Logger.log("New model activated at: \(targetModelURL.lastPathComponent)", category: "MLModelUpdate")

                success = true
                Logger.log("Core ML model update completed successfully.", category: "MLModelUpdate")

            } catch {
                if let mlError = error as? MLModelError, mlError == .cancellation {
                    Logger.log("ML model update task was cancelled.", category: "MLModelUpdate", isError: true)
                } else if Task.isCancelled {
                     Logger.log("ML model update task was cancelled by system expiration.", category: "MLModelUpdate", isError: true)
                } else {
                    Logger.log("ML model update failed: \(error.localizedDescription)", category: "MLModelUpdate", isError: true)
                }
                success = false

                // Rollback if a backup exists and new model failed to activate
                if let backup = backupActiveModelURL, FileManager.default.fileExists(atPath: backup.path) {
                    let targetModelURL = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("models").appendingPathComponent("active_model.mlmodelc")
                    Logger.log("Attempting to rollback to backup model: \(backup.lastPathComponent)", category: "MLModelUpdate")
                    do {
                        if FileManager.default.fileExists(atPath: targetModelURL.path) {
                            try FileManager.default.removeItem(at: targetModelURL)
                        }
                        try FileManager.default.moveItem(at: backup, to: targetModelURL)
                        self.activeMLModelURL = targetModelURL
                        Logger.log("Rollback successful.", category: "MLModelUpdate")
                    } catch {
                        Logger.log("Rollback failed: \(error.localizedDescription)", category: "MLModelUpdate", isError: true)
                    }
                }
            }

            // 4. Cleanup
            if let tempDownloadedModelURL = tempDownloadedModelURL {
                try? FileManager.default.removeItem(at: tempDownloadedModelURL)
                try? FileManager.default.removeItem(at: tempDownloadedModelURL.deletingLastPathComponent()) // Remove temp dir
            }
            if let tempCompiledModelURL = tempCompiledModelURL {
                try? FileManager.default.removeItem(at: tempCompiledModelURL) // Remove compiled temp dir
            }
            if let backup = backupActiveModelURL, FileManager.default.fileExists(atPath: backup.path) && success {
                try? FileManager.default.removeItem(at: backup) // Remove backup only if new model was successfully activated
            }
            Logger.log("Cleanup complete.", category: "MLModelUpdate")

            task.setTaskCompleted(success: success)
            self.mlModelUpdateTaskCancellationToken = nil // Clear the reference
        }
    }
    // Other task handlers for subsequent exercises would go here
    // ...
}

/*
// --- Info.plist Configuration ---
// Add the following key-value pair to your app's Info.plist file:
//
// <key>BGTaskSchedulerPermittedIdentifiers</key>
// <array>
//     <string>com.example.app.updateMLModel</string>
//     <!-- Add other identifiers here -->
// </array>
*/
