/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * universal-debug-orchestrator.ts
 * 
 * A TypeScript script demonstrating advanced debugging techniques for universal apps.
 * It simulates a ReAct (Reasoning and Acting) loop to aggregate and normalize logs
 * from both Next.js (Web) and Expo (Native) environments.
 * 
 * CONTEXT: Book 16, Chapter 5, Subsection 3/5
 */

// ============================================================================
// 1. TYPE DEFINITIONS & INTERFACES
// ============================================================================

/**
 * Represents a unified log entry that can be rendered in a debugging dashboard.
 * We normalize browser logs and native logs into this single shape.
 */
interface UnifiedLog {
  id: string;
  timestamp: number;
  source: 'web' | 'native' | 'server';
  level: 'log' | 'warn' | 'error';
  message: string;
  metadata?: Record<string, any>;
}

/**
 * Represents the state of our debugging session.
 * In a Cyclical Graph structure, state is passed between nodes.
 */
interface DebugState {
  logs: UnifiedLog[];
  isRecording: boolean;
  filter: string;
  cycleCount: number;
}

// ============================================================================
// 2. MOCK ENVIRONMENT SIMULATIONS
// ============================================================================

/**
 * Simulates the Browser/Next.js Environment (V8 Engine context).
 * In a real app, this would be `window.console` or `fetch` interceptors.
 */
const WebEnvironment = {
  log: (msg: string) => console.log(`[Web]: ${msg}`),
  error: (msg: string) => console.error(`[Web]: ${msg}`),
  // Simulates a network request to a SaaS API
  fetchAnalytics: async (): Promise<any> => {
    return new Promise((resolve) => {
      setTimeout(() => resolve({ data: [10, 20, 30], source: 'web-api' }), 100);
    });
  }
};

/**
 * Simulates the Expo/iOS Simulator Environment.
 * Native logs often appear in Xcode/Android Studio logs rather than the browser console.
 */
const NativeEnvironment = {
  log: (msg: string) => console.log(`[Native]: ${msg}`),
  error: (msg: string) => console.error(`[Native]: ${msg}`),
  // Simulates a native module network request
  nativeFetch: async (): Promise<any> => {
    return new Promise((resolve) => {
      setTimeout(() => resolve({ data: [5, 15, 25], source: 'native-api' }), 120);
    });
  }
};

// ============================================================================
// 3. THE CYCLICAL GRAPH STRUCTURE (REACT LOOP)
// ============================================================================

/**
 * Orchestrates the debugging workflow.
 * 
 * UNDER THE HOOD:
 * This function mimics a LangGraph cyclical graph. It enters a loop (the cycle)
 * where it performs an action (collecting logs), observes the state, and reasons
 * (filters/normalizes) before deciding whether to continue or terminate.
 * 
 * This is crucial for universal apps because debugging often requires iterative
 * refinement of the view to catch race conditions.
 */
async function* debugOrchestratorGenerator(state: DebugState) {
  let currentState = { ...state };

  // CYCLE 1: Initial Capture
  // -------------------------------------------------
  WebEnvironment.log('User clicked "Refresh Dashboard"');
  NativeEnvironment.log('User clicked "Refresh Dashboard"');
  
  // Simulate network requests
  const [webData, nativeData] = await Promise.all([
    WebEnvironment.fetchAnalytics(),
    NativeEnvironment.nativeFetch()
  ]);

  // Normalize Data into UnifiedLog format
  const newLogs: UnifiedLog[] = [
    {
      id: `log-${Date.now()}-1`,
      timestamp: Date.now(),
      source: 'web',
      level: 'log',
      message: `API Response: ${JSON.stringify(webData)}`
    },
    {
      id: `log-${Date.now()}-2`,
      timestamp: Date.now(),
      source: 'native',
      level: 'log',
      message: `API Response: ${JSON.stringify(nativeData)}`
    }
  ];

  currentState.logs = [...currentState.logs, ...newLogs];
  currentState.cycleCount++;
  
  yield currentState; // Yield control back to the "Main Thread"

  // CYCLE 2: Error Injection & Detection (Simulated)
  // -------------------------------------------------
  // In a real scenario, this detects a bridging error or state mismatch
  if (currentState.cycleCount === 1) {
    NativeEnvironment.error('Bridge: NativeState mismatch detected');
    
    const errorLog: UnifiedLog = {
      id: `log-${Date.now()}-3`,
      timestamp: Date.now(),
      source: 'native',
      level: 'error',
      message: 'Bridge: NativeState mismatch detected',
      metadata: { stack: 'NativeModules.ts:42' }
    };

    currentState.logs.push(errorLog);
    currentState.cycleCount++;
    
    yield currentState; // Yield again for the error state
  }

  // TERMINATION CONDITION
  // -------------------------------------------------
  return currentState;
}

// ============================================================================
// 4. REACT DEVTOOLS INTEGRATION (STATE PROFILING)
// ============================================================================

/**
 * Simulates a React Component that uses the debugging orchestrator.
 * 
 * PEDAGOGY:
 * In a real Next.js/Expo app, we would use `useEffect` to attach this logic.
 * To simulate React DevTools profiling, we expose the state to `window`.
 * This allows the "React DevTools" extension to inspect the `__UNIVERSAL_DEBUG__` object.
 */
class DashboardDebugger {
  private state: DebugState = {
    logs: [],
    isRecording: true,
    filter: '',
    cycleCount: 0
  };

  constructor() {
    this.init();
  }

  private init() {
    // Expose state for React DevTools / Global Inspection
    // This mimics how React attaches state to the virtual DOM fiber nodes.
    (window as any).__UNIVERSAL_DEBUG__ = this.state;
    
    console.log('%c[Debugger Initialized]', 'color: #00ff00; font-weight: bold;');
  }

  /**
   * Runs the cyclical graph loop.
   */
  public async run() {
    const generator = debugOrchestratorGenerator(this.state);

    for await (const newState of generator) {
      this.state = newState;
      
      // Update the global reference for DevTools
      (window as any).__UNIVERSAL_DEBUG__ = this.state;
      
      this.renderLogs();
    }
  }

  /**
   * Renders logs to the console, applying the filter.
   * This simulates the "Console" tab in React Native DevTools.
   */
  private renderLogs() {
    const filteredLogs = this.state.logs.filter(log => 
      log.message.toLowerCase().includes(this.state.filter.toLowerCase())
    );

    console.group(`%cCycle: ${this.state.cycleCount}`, 'background: #222; color: #bada55');
    filteredLogs.forEach(log => {
      const style = log.level === 'error' ? 'color: red;' : 'color: cyan;';
      console.log(`[${new Date(log.timestamp).toLocaleTimeString()}] ${log.source.toUpperCase()}: ${log.message}`, style);
    });
    console.groupEnd();
  }
}

// ============================================================================
// 5. EXECUTION & VISUALIZATION
// ============================================================================

/**
 * Main Entry Point.
 * In a SaaS context, this would be triggered by a "Debug Mode" toggle in the dashboard.
 */
(async function main() {
  // Check if running in a browser-like environment (Next.js) or Node (V8)
  const isBrowser = typeof window !== 'undefined';
  
  if (isBrowser) {
    const debuggerInstance = new DashboardDebugger();
    await debuggerInstance.run();
  } else {
    console.log('This script is designed to run in a browser/Next.js context to visualize the debugger.');
  }
})();

/**
 * VISUALIZATION OF THE CYCLICAL GRAPH STRUCTURE
 * 
 * The following DOT diagram illustrates the flow of the `debugOrchestratorGenerator`.
 * Note the cycle back from "Process Logs" to "Capture Events" until the termination condition is met.
 */
const DOT_DIAGRAM = `


::: {style="text-align: center"}
![This DOT diagram visualizes the cyclical graph structure of the `debugOrchestratorGenerator`, illustrating how the flow cycles back from Process Logs to Capture Events until the termination condition is met.](images/b16_c5_s3_diag1.png){width=80% caption="This DOT diagram visualizes the cyclical graph structure of the `debugOrchestratorGenerator`, illustrating how the flow cycles back from Process Logs to Capture Events until the termination condition is met."}
:::


`;

// Export for module usage if executed in a Node environment (e.g., for testing)
export { debugOrchestratorGenerator, DashboardDebugger };
