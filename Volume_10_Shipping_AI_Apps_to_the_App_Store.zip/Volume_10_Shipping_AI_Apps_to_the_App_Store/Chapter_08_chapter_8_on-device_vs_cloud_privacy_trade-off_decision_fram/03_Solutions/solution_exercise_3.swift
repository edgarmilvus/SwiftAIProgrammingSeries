
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import NaturalLanguage

/// A payload containing the sanitized text and the map to restore it.
struct ScrubbedPayload: Sendable {
    let anonymizedText: String
    let mapping: [String: String] // [Token: OriginalValue]
}

/// Handles the identification and replacement of PII.
struct Scrubber: Sendable {
    func scrub(text: String) throws -> ScrubbedPayload {
        let tagger = NLTagger(tagSchemes: [.nameType])
        tagger.string = text
        
        var mapping: [String: String] = [:]
        var resultText = text
        var tokenCounter = 0
        
        // We iterate through the text to find entities. 
        // Note: In a production environment, we must handle overlapping ranges carefully.
        let options: NLTagger.Options = [.omitWhitespace, .omitPunctuation]
        let range = text.startIndex..<text.endIndex
        
        // To avoid index invalidation during string mutation, we collect replacements first.
        var replacements: [(range: Range<String.Index>, token: String, original: String)] = []

        tagger.enumerateTags(in: range, unit: .word, scheme: .nameType, options: options) { tag, tokenRange in
            if let tag = tag, [.personalName, .emailAddress, .phoneNumber].contains(tag) {
                let originalValue = String(text[tokenRange])
                let token = "[ENTITY_\(tokenCounter)]"
                replacements.append((tokenRange, token, originalValue))
                tokenCounter += 1
            }
            return true
        }

        // Sort replacements in reverse order to prevent index shifting during substitution
        for replacement in replacements.sorted(by: { $0.range.lowerBound > $1.range.lowerBound }) {
            mapping[replacement.token] = replacement.original
            resultText.replaceSubrange(replacement.range, with: replacement.token)
        }

        return ScrubbedPayload(anonymizedText: resultText, mapping: mapping)
    }
}

/// Handles the restoration of original data into the cloud response.
struct ReHydrator: Sendable {
    func rehydrate(response: String, mapping: [String: String]) -> String {
        var finalResponse = response
        for (token, original) in mapping {
            finalResponse = finalResponse.replacingOccurrences(of: token, with: original)
        }
        return finalResponse
    }
}

/// Orchestrates the end-to-end privacy pipeline.
final class PrivacyPreservingPipeline: Sendable {
    private let scrubber = Scrubber()
    private let rehydrator = ReHydrator()
    
    // Simulated Cloud LLM
    private func callCloudLLM(anonymizedText: String) async throws -> String {
        try await Task.sleep(for: .seconds(1))
        // The LLM sees tokens, not names.
        return "Hello [ENTITY_0], based on your request, I recommend a rest."
    }

    func process(userInput: String) async throws -> String {
        // 1. Scrub (Local)
        let scrubbed = try scrubber.scrub(text: userInput)
        
        // 2. Cloud Inference (Remote)
        let anonymizedResponse = try await callCloudLLM(anonymizedText: scrubbed.anonymizedText)
        
        // 3. Re-hydrate (Local)
        return rehydrator.rehydrate(response: anonymizedResponse, mapping: scrubbed.mapping)
    }
}

// MARK: - Execution Example
@main
struct PipelineApp {
    static func main() async {
        let pipeline = PrivacyPreservingPipeline()
        let input = "Hi, my name is Alice."

        print("Input: \(input)")
        do {
            let output = try await pipeline.process(userInput: input)
            print("Final Output: \(output)")
        } catch {
            print("Pipeline Error: \(error)")
        }
    }
}
