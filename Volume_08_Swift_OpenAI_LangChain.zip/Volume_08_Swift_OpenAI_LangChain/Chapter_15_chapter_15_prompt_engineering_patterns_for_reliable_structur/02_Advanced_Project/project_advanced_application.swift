
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// swift-tools-version: 6.0
import PackageDescription

// MARK: - Package.swift Equivalent
// In a real project, you would add:
// .package(url: "https://github.com/openai/openai-swift", from: "1.0.0")
// .target(name: "ExpenseParser", dependencies: ["OpenAISwift"])

import Foundation
import OSLog

/// Represents the specific errors that can occur during the structured extraction process.
enum ExtractionError: Error, LocalizedError {
    case reasoningMissing
    case jsonBlockMissing
    case decodingFailed(String)
    case maxRetriesExceeded
    case invalidSchema(String)

    var errorDescription: String? {
        switch self {
        case .reasoningMissing: return "The model failed to provide a reasoning block."
        case .jsonBlockMissing: return "The model failed to provide a valid JSON block."
        case .decodingFailed(let msg): return "JSON decoding failed: \(msg)"
        case .maxRetriesExceeded: return "Failed to extract valid data after multiple attempts."
        case .invalidSchema(let msg): return "The extracted data does not match the expected schema: \(msg)"
        }
    }
}

/// The target data model we want the LLM to populate.
/// Conforms to `Codable` for seamless integration with `JSONDecoder`.
/// Conforms to `Sendable` to be safely passed across Swift 6 concurrency boundaries.
struct ExpenseReport: Codable, Sendable, Equatable {
    let merchant: String
    let date: Date
    let totalAmount: Decimal
    let currency: String
    let category: ExpenseCategory
    let taxAmount: Decimal?
    
    enum ExpenseCategory: String, Codable, Sendable {
        case food, travel, utilities, entertainment, supplies, unknown
    }
}

/// A wrapper to hold the raw response and the extracted object for debugging purposes.
struct ExtractionResult<T: Decodable & Sendable>: Sendable {
    let extractedData: T
    let reasoning: String
    let attempts: Int
}

/// The `StructuredOutputEngine` is an `actor` to ensure thread-safe access to 
/// parsing state and to manage the complex asynchronous flow of LLM retries.
/// It implements the "Reasoning-then-JSON" pattern.
@available(iOS 18.0, macOS 15.0, *)
actor StructuredOutputEngine {
    private let logger = Logger(subsystem: "com.ai.app", category: "ExtractionEngine")
    private let maxRetries = 3
    
    /// The system prompt template that enforces the "Reasoning-then-JSON" pattern.
    /// We use XML-style delimiters (
        let thoughtRegex = try NSRegularExpression(pattern: "", options: [.dotMatchesLineSeparators])
        // Regex to find content between <json>...</json>
        let jsonRegex = try NSRegularExpression(pattern: "<json>(.*?)</json>", options: [.dotMatchesLineSeparators])
        
        let nsRange = NSRange(input.startIndex..<input.endIndex, in: input)
        
        guard let thoughtMatch = thoughtRegex.firstMatch(in: input, range: nsRange),
              let jsonMatch = jsonRegex.firstMatch(in: input, range: nsRange) else {
            throw ExtractionError.jsonBlockMissing
        }
        
        let reasoning = String(input[Range(thoughtMatch.range(at: 1), in: input)!]).trimmingCharacters(in: .whitespacesAndNewlines)
        let json = String(input[Range(jsonMatch.range(at: 1), in: input)!]).trimmingCharacters(in: .whitespacesAndNewlines)
        
        return (reasoning, json)
    }

    /// Simulated API call to mimic an LLM responding to a prompt.
    /// In production, replace this with: `try await openAIClient.complete(prompt: ...)`
    private func simulateLLMCall(input: String, attempt: Int) async throws -> String {
        // Artificial delay to simulate network latency
        try await Task.sleep(for: .seconds(1))
        
        if attempt == 1 {
            // Simulate a common failure: The LLM provides a slightly malformed date or extra text
            return """
            
            <json>
            {
                "merchant": "Starbucks",
                "date": "2023-10-12T08:30:00Z",
                "totalAmount": 5.50,
                "currency": "USD",
                "category": "food"
            }
            </json>
            """
        } else {
            // Simulate a successful second attempt
            return """
            
            <json>
            {
                "merchant": "Starbucks",
                "date": "2023-10-12T08:30:00Z",
                "totalAmount": 5.50,
                "currency": "USD",
                "category": "food",
                "taxAmount": 0.45
            }
            </json>
            """
        }
    }
}

// MARK: - Implementation Example (SwiftUI Context)

@available(iOS 18.0, macOS 15.0, *)
@MainActor
class ExpenseViewModel: ObservableObject {
    @Published var report: ExpenseReport?
    @Published var isProcessing = false
    @Published var errorMessage: String?
    @Published var reasoningLog: String = ""
    
    private let engine = StructuredOutputEngine()
    
    func processReceipt(text: String) async {
        isProcessing = true
        errorMessage = nil
        
        do {
            let result = try await engine.extract(ExpenseReport.self, from: text)
            self.report = result.extractedData
            self.reasoningLog = result.reasoning
        } catch {
            self.errorMessage = error.localizedDescription
        }
        
        isProcessing = false
    }
}
