
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

// MARK: - Codable Structures (Streaming)

/// Represents the request body for the /api/generate endpoint (streaming).
struct GenerateStreamRequest: Codable {
    let model: String
    let prompt: String
    let stream: Bool // Crucial: Set to true for streaming
    let options: Options?
    let raw: Bool? // Set to true if you want raw output without formatting

    struct Options: Codable {
        let temperature: Double?
        let topK: Int?
        let topP: Double?
        let numPredict: Int?
        // Add other options as needed
    }
}

/// Represents a single chunk/object received during a streaming response.
struct GenerateStreamResponse: Codable {
    let model: String?
    let createdAt: String?
    let response: String? // The actual token/text generated in this chunk
    let done: Bool
    let totalDuration: Int?
    let loadDuration: Int?
    let promptEvalCount: Int?
    let promptEvalDuration: Int?
    let evalCount: Int?
    let evalDuration: Int?

    // Custom CodingKeys for snake_case
    enum CodingKeys: String, CodingKey {
        case model, response, done
        case createdAt = "created_at"
        case totalDuration = "total_duration"
        case loadDuration = "load_duration"
        case promptEvalCount = "prompt_eval_count"
        case promptEvalDuration = "prompt_eval_duration"
        case evalCount = "eval_count"
        case evalDuration = "eval_duration"
    }
}

// MARK: - Ollama Service (Extension for Streaming)

extension OllamaService {
    /// Streams a chat response from Ollama, delivering tokens incrementally.
    /// - Parameters:
    ///   - prompt: The text prompt to send to the AI.
    ///   - model: The name of the Ollama model to use.
    ///   - temperature: Optional generation temperature.
    ///   - onNewToken: A closure called with each new text token received.
    ///   - onComplete: A closure called when the stream finishes, with the final response or an error.
    func streamChatResponse(
        prompt: String,
        model: String,
        temperature: Double? = nil,
        onNewToken: @escaping @MainActor (String) -> Void,
        onComplete: @escaping @MainActor (Result<String, OllamaError>) -> Void
    ) async {
        guard let url = URL(string: "\(baseURLString)/api/generate") else {
            await onComplete(.failure(.invalidURL))
            return
        }

        let requestBody = GenerateStreamRequest(
            model: model,
            prompt: prompt,
            stream: true, // Crucial: Set to true for streaming
            options: temperature != nil ? GenerateStreamRequest.Options(temperature: temperature) : nil,
            raw: false // Generally false for chat interface
        )

        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            let encoder = JSONEncoder()
            encoder.keyEncodingStrategy = .convertToSnakeCase
            urlRequest.httpBody = try encoder.encode(requestBody)
        } catch {
            await onComplete(.failure(.encodingError(error)))
            return
        }

        var accumulatedResponse = ""
        var buffer = Data()
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase

        do {
            let (asyncBytes, response) = try await session.bytes(for: urlRequest)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw OllamaError.networkError(URLError(.badServerResponse))
            }

            guard (200...299).contains(httpResponse.statusCode) else {
                // For streaming, errors might come in the stream itself or as a single JSON object.
                // If it's a non-2xx status, try to decode a single error response.
                let errorData = try await asyncBytes.reduce(Data()) { $0 + $1 } // Consume remaining bytes for error
                if let apiError = try? decoder.decode(OllamaAPIError.self, from: errorData) {
                    throw OllamaError.apiError(apiError.error)
                }
                throw OllamaError.invalidHTTPResponse(httpResponse.statusCode)
            }

            // Iterate over the incoming bytes
            for try await byte in asyncBytes {
                buffer.append(byte)

                // Ollama sends newline-delimited JSON objects
                while let newlineRange = buffer.firstRange(of: Data([0x0A])) { // 0x0A is ASCII for \n
                    let jsonChunkData = buffer.prefix(upTo: newlineRange.lowerBound)
                    buffer.removeSubrange(..<newlineRange.upperBound)

                    if jsonChunkData.isEmpty { continue } // Skip empty lines

                    do {
                        let streamResponse = try decoder.decode(GenerateStreamResponse.self, from: jsonChunkData)

                        if let token = streamResponse.response, !token.isEmpty {
                            accumulatedResponse += token
                            await onNewToken(token) // Pass the new token for incremental UI update
                        }

                        if streamResponse.done {
                            await onComplete(.success(accumulatedResponse))
                            return // Exit the loop as stream is complete
                        }
                    } catch {
                        // Log or handle malformed JSON chunks gracefully, but don't stop the stream
                        print("Warning: Failed to decode stream chunk: \(error.localizedDescription) - Data: \(String(data: jsonChunkData, encoding: .utf8) ?? "N/A")")
                        // It's possible for the last chunk to be an empty string if the stream ends abruptly or has trailing newlines.
                        // Or, if the API sends an error within the stream, we might try to decode it here.
                        if let apiError = try? decoder.decode(OllamaAPIError.self, from: jsonChunkData) {
                            await onComplete(.failure(.apiError(apiError.error)))
                            return
                        }
                    }
                }
            }
            // If the loop finishes without a 'done: true' flag, it might be an incomplete stream
            if !accumulatedResponse.isEmpty {
                 await onComplete(.success(accumulatedResponse)) // Consider it done if we received some response
            } else {
                 await onComplete(.failure(.networkError(URLError(.cancelled)))) // Or a more specific error
            }

        } catch {
            // Catch errors from URLSession.bytes(for:) or initial response validation
            await onComplete(.failure(error as? OllamaError ?? .networkError(error)))
        }
    }
}

// MARK: - Example Usage (Conceptual UI interaction)

@MainActor
class ChatViewModel: ObservableObject {
    @Published var currentPrompt: String = ""
    @Published var fullResponse: String = ""
    @Published var isGenerating: Bool = false
    @Published var errorMessage: String?

    private let ollamaService = OllamaService()
    private var currentTask: Task<Void, Never>?

    func sendMessage() {
        guard !currentPrompt.isEmpty else { return }
        isGenerating = true
        errorMessage = nil
        fullResponse = "" // Clear previous response

        let userPrompt = currentPrompt
        currentPrompt = "" // Clear input field

        currentTask = Task {
            await ollamaService.streamChatResponse(
                prompt: userPrompt,
                model: "llama3", // Ensure this model is pulled
                temperature: 0.7,
                onNewToken: { [weak self] token in
                    self?.fullResponse += token
                },
                onComplete: { [weak self] result in
                    self?.isGenerating = false
                    switch result {
                    case .success(let finalResponse):
                        print("Stream completed. Final response length: \(finalResponse.count)")
                    case .failure(let error):
                        self?.errorMessage = error.localizedDescription
                        print("Stream error: \(error.localizedDescription)")
                    }
                }
            )
        }
    }

    func cancelGeneration() {
        currentTask?.cancel()
        isGenerating = false
        print("Generation cancelled.")
    }
}

// To run this example in a Playground or a Swift application:
// You would typically integrate ChatViewModel into a SwiftUI View.
/*
import SwiftUI

struct ChatView: View {
    @StateObject private var viewModel = ChatViewModel()

    var body: some View {
        VStack {
            ScrollView {
                Text(viewModel.fullResponse)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
            }
            .frame(maxHeight: .infinity)

            if viewModel.isGenerating {
                ProgressView()
            }

            if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
            }

            HStack {
                TextField("Enter your prompt", text: $viewModel.currentPrompt)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .disabled(viewModel.isGenerating)

                Button(action: {
                    if viewModel.isGenerating {
                        viewModel.cancelGeneration()
                    } else {
                        viewModel.sendMessage()
                    }
                }) {
                    Text(viewModel.isGenerating ? "Cancel" : "Send")
                }
                .disabled(viewModel.currentPrompt.isEmpty && !viewModel.isGenerating)
            }
            .padding()
        }
        .padding()
        .navigationTitle("Ollama Chat")
    }
}

// To preview or run:
// #Preview {
//     ChatView()
// }
*/
