
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import PDFKit

/// Error types specific to PDF extraction
enum PDFExtractorError: Error {
    case fileNotFound
    case invalidDocument
    case emptyDocument
}

/// An actor to ensure thread-safe text extraction processes.
@available(iOS 18.0, *)
actor PDFTextExtractor {
    
    /// Extracts and cleans text from a PDF file at the given URL.
    /// - Parameter url: The local file URL of the PDF.
    /// - Returns: A single, sanitized String containing all text from the document.
    func extractCleanText(from url: URL) async throws -> String {
        // 1. Validate file existence
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw PDFExtractorError.fileNotFound
        }
        
        // 2. Load PDF Document
        guard let document = PDFDocument(url: url) else {
            throw PDFExtractorError.invalidDocument
        }
        
        guard document.pageCount > 0 else {
            throw PDFExtractorError.emptyDocument
        }
        
        var fullText = ""
        
        // 3. Iterate through pages
        for i in 0..<document.pageCount {
            guard let page = document.page(at: i),
                  let pageText = page.string, !pageText.isEmpty else {
                continue
            }
            
            // Append page text with a newline to prevent word merging between pages
            fullText += pageText + "\n"
        }
        
        // 4. Run the Sanitization Pipeline
        return sanitize(fullText)
    }
    
    /// Performs whitespace normalization and removes non-printable characters.
    private func sanitize(_ input: String) -> String {
        // A. Remove non-printable control characters using Regex
        // This targets characters in the 'Other, Control' Unicode category
        let controlCharsRegex = /[\p{Cc}]/
        var sanitized = input.replacing(controlCharsRegex, with: "")
        
        // B. Whitespace Normalization
        // Replace multiple consecutive whitespaces/newlines with a single space
        // We use a regex that looks for 2 or more whitespace characters
        let multiWhitespaceRegex = /\s{2,}/
        sanitized = sanitized.replacing(multiWhitespaceRegex, with: " ")
        
        // C. Final trim to remove leading/trailing noise
        return sanitized.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
