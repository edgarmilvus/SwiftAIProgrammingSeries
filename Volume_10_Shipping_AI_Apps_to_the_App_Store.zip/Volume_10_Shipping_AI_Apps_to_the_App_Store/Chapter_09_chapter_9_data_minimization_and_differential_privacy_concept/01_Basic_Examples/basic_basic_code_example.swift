
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import OSLog

/// Represents the possible emotional states detected by the AI.
/// Conforming to `Sendable` is crucial for Swift 6 concurrency safety.
enum MoodState: String, Sendable, CaseIterable {
    case joyful
    case neutral
    case melancholic
}

/// A container for the minimized data. 
/// Instead of sending text, we only send the state and a noisy value.
struct MinimizedMoodReport: Sendable {
    let state: MoodState
    let noisyScore: Double
    let timestamp: Date
}

/// The error types associated with the Privacy Engine.
enum PrivacyError: Error {
    case insufficientEpsilon
    case computationError
}

/// `PrivacyEngine` is implemented as an `actor` to ensure that privacy-preserving 
/// transformations are isolated and thread-safe, preventing data races 
/// when processing multiple high-frequency inputs.
actor PrivacyEngine {
    private let logger = Logger(subsystem: "com.ai.privacy", category: "DifferentialPrivacy")
    
    /// The 'Epsilon' ($\epsilon$) parameter is the "privacy budget."
    /// A smaller epsilon means more noise and more privacy.
    /// A larger epsilon means less noise and more accuracy.
    private let epsilon: Double
    
    /// The 'Sensitivity' ($\Delta f$) represents the maximum change a single 
    /// user's data can have on the output. For a score normalized between 0 and 1, 
    /// the sensitivity is 1.0.
    private let sensitivity: Double = 1.0

    init(epsilon: Double) {
        self.epsilon = epsilon
    }

    /// Applies the Laplace Mechanism to a raw score to achieve Differential Privacy.
    ///
    /// - Parameter rawScore: The actual value produced by the AI model (0.0 to 1.0).
    /// - Returns: A noisy version of the score.
    /// - Throws: `PrivacyError` if parameters are invalid.
    ///
    /// - Note: This implements the formula: $f(x) = \text{rawScore} + \text{Laplace}(\text{sensitivity} / \epsilon)$
    func applyLaplaceNoise(to rawScore: Double) throws -> Double {
        guard epsilon > 0 else { throw PrivacyError.insufficientEpsilon }
        
        // 1. Calculate the scale (b) of the Laplace distribution
        // b = sensitivity / epsilon
        let scale = sensitivity / epsilon
        
        // 2. Generate Laplace noise
        // The Laplace distribution can be generated using two independent 
        // Uniform distributions: L(x) = U1 - U2 where U are specific transformations.
        // A simpler way is using the inverse transform sampling:
        // Noise = -scale * sign(u) * ln(1 - 2|u|) where u is in [-0.5, 0.5]
        let u = Double.random(in: -0.5...0.5)
        let noise = -scale * (u.signum() * log(1 - 2 * abs(u)))
        
        let noisyScore = rawScore + noise
        
        // 3. Clamp the result to ensure it stays within logical bounds [0, 1]
        // While clamping slightly biases the distribution, it is necessary for 
        // practical data representation in bounded domains.
        let clampedScore = max(0.0, min(1.0, noisyScore))
        
        logger.debug("Privacy Transformation: Raw \(rawScore) -> Noisy \(clampedScore) (ε=\(self.epsilon))")
        return clampedScore
    }

    /// The primary entry point for data minimization.
    /// This function takes a raw AI output and turns it into a privacy-protected report.
    func minimizeAndProtect(state: MoodState, rawScore: Double) async throws -> MinimizedMoodReport {
        // Step 1: Data Minimization (Implicitly done by only accepting the score, not the text)
        
        // Step 2: Apply Differential Privacy
        let protectedScore = try applyLaplaceNoise(to: rawScore)
        
        return MinimizedMoodReport(
            state: state,
            noisyScore: protectedScore,
            timestamp: Date()
        )
    }
}

/// A simulation of a UI-driven application (e.g., a Smart Diary).
@MainActor
class DiaryViewModel: ObservableObject {
    @Published var statusMessage: String = "Ready"
    @Published var lastReport: String = ""
    
    private let privacyEngine = PrivacyEngine(epsilon: 0.5) // Strict privacy
    
    /// Simulates the user finishing a diary entry.
    func processUserEntry(text: String, aiDetectedScore: Double, detectedMood: MoodState) {
        statusMessage = "Analyzing and protecting data..."
        
        // We use a Task to bridge the synchronous UI call to the asynchronous PrivacyEngine
        Task {
            do {
                // In a real app, the 'text' variable would be wiped from memory 
                // immediately after the AI model processes it.
                
                // The 'text' is NEVER passed to the privacy engine. 
                // This is the essence of Data Minimization.
                let report = try await privacyEngine.minimizeAndProtect(
                    state: detectedMood,
                    rawScore: aiDetectedScore
                )
                
                // Update UI on the MainActor
                self.statusMessage = "Data protected and ready for upload."
                self.lastReport = "Sent: \(report.state) (Score: \(String(format: "%.2f", report.noisyScore)))"
                
                // Simulate network upload
                try await uploadReport(report)
                
            } catch {
                self.statusMessage = "Privacy Error: \(error.localizedDescription)"
            }
        }
    }
    
    private func uploadReport(_ report: MinimizedMoodReport) async throws {
        // Simulate network latency
        try await Task.sleep(for: .seconds(1))
        print("Successfully uploaded minimized report to server: \(report)")
    }
}

// MARK: - Execution Simulation

@available(iOS 18.0, *)
func runPrivacyDemo() {
    let viewModel = DiaryViewModel()
    
    print("--- Starting Privacy-Preserving AI Workflow ---")
    
    // Scenario: User writes a very happy entry.
    // Raw AI score: 0.98
    viewModel.processUserEntry(
        text: "Today was the best day ever! I felt so much joy.", 
        aiDetectedScore: 0.98, 
        detectedMood: .joyful
    )
}

// To run in a Swift Playground or Command Line Tool:
// runPrivacyDemo()
