
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import Combine // For @Published property wrapper (though not strictly Swift 6 concurrency, it's standard for ViewModels)

/// Defines the interface for a local code completion service.
@available(iOS 18.0, macOS 15.0, *)
protocol CodeCompletionService {
    /// Asynchronously fetches code completions for the given code snippet and cursor position.
    /// - Parameters:
    ///   - code: The current code in the editor.
    ///   - cursorPosition: The 0-based index of the cursor within the `code` string.
    /// - Returns: An array of suggested completion strings.
    func getCompletions(for code: String, cursorPosition: Int) async -> [String]
}

/// A mock implementation of `CodeCompletionService` to simulate completion logic.
@available(iOS 18.0, macOS 15.0, *)
class MockCodeCompletionService: CodeCompletionService {
    private let simulatedLatency: Duration

    init(simulatedLatency: Duration = .milliseconds(300)) {
        self.simulatedLatency = simulatedLatency
    }

    /// Simulates fetching code completions with a delay.
    func getCompletions(for code: String, cursorPosition: Int) async -> [String] {
        print("Mock Completion Service: Requesting completions for code (cursor at \(cursorPosition))...")
        // Simulate processing delay for the completion engine.
        try? await Task.sleep(for: simulatedLatency)

        // Simple mock logic: suggest based on the last word before the cursor.
        let prefix = code.prefix(cursorPosition)
        let words = prefix.split(whereSeparator: \.isWhitespace)
        guard let lastWord = words.last?.lowercased() else { return [] }

        // Provide context-aware suggestions based on the last typed word.
        if lastWord.hasPrefix("func") {
            return ["func myFunction() -> Void {", "func calculate(_ value: Int) -> Int {"]
        } else if lastWord.hasPrefix("var") {
            return ["var myVariable: String", "var count: Int = 0"]
        } else if lastWord.hasPrefix("impo") {
            return ["import Foundation", "import SwiftUI", "import Combine"]
        } else if lastWord.hasPrefix("priva") {
            return ["private var", "private func"]
        }
        return ["// Suggested by local AI for '\(lastWord)'", "print(\"Hello\")"]
    }
}

/// ViewModel for a code editor, handling user input and driving completion requests.
@available(iOS 18.0, macOS 15.0, *)
@MainActor // Ensures all UI-related state changes happen on the main actor.
class CodeEditorViewModel: ObservableObject {
    @Published var currentCode: String = ""
    @Published var suggestions: [String] = []
    @Published var isLoadingCompletions: Bool = false // UI loading state indicator

    private var completionService: CodeCompletionService
    private var currentCompletionTask: Task<Void, Never>? // Holds the ongoing completion task.

    init(completionService: CodeCompletionService) {
        self.completionService = completionService
    }

    /// Called when the user types in the editor. Manages debouncing and cancellation.
    /// - Parameters:
    ///   - newCode: The updated code string.
    ///   - cursorPosition: The current cursor position.
    func userTyped(newCode: String, cursorPosition: Int) {
        self.currentCode = newCode // Update the code displayed in the UI.

        // Cancel any ongoing completion task to avoid stale results and wasted computation.
        currentCompletionTask?.cancel()
        self.isLoadingCompletions = false // Reset loading state immediately on new input.

        // Only request completions if the code isn't empty and the cursor is valid.
        guard !newCode.isEmpty, cursorPosition >= 0, cursorPosition <= newCode.count else {
            self.suggestions = []
            return
        }

        // Debounce input: only request completions after a short pause.
        // This prevents overwhelming the LLM with requests for every single keystroke.
        self.isLoadingCompletions = true // Indicate loading while debouncing.
        currentCompletionTask = Task {
            do {
                try await Task.sleep(for: .milliseconds(150)) // Debounce delay.

                // Crucial: Check for cancellation *after* the debounce delay.
                // If the user typed again during the debounce, this task is stale.
                guard !Task.isCancelled else {
                    print("Completion task was cancelled after debounce.")
                    await MainActor.run { self.isLoadingCompletions = false } // Ensure loading state is reset
                    return
                }

                // If not cancelled, proceed with fetching completions on a background Task.
                let newSuggestions = await completionService.getCompletions(for: newCode, cursorPosition: cursorPosition)

                // Update UI on the main actor.
                await MainActor.run {
                    self.suggestions = newSuggestions
                    self.isLoadingCompletions = false // Completions fetched, reset loading state.
                }
            } catch is CancellationError {
                // Task.sleep throws CancellationError if cancelled. This is expected.
                print("Completion task was explicitly cancelled.")
                await MainActor.run { self.isLoadingCompletions = false }
            } catch {
                print("Completion task failed: \(error)")
                await MainActor.run {
                    self.suggestions = []
                    self.isLoadingCompletions = false
                }
            }
        }
    }
}

// MARK: - Conceptual UI Integration (Example)

/*
import SwiftUI

@available(iOS 18.0, macOS 15.0, *)
struct CodeEditorView: View {
    @StateObject private var viewModel = CodeEditorViewModel(completionService: MockCodeCompletionService())
    @State private var cursorPosition: Int = 0 // Simulate cursor position

    var body: some View {
        VStack {
            TextEditor(text: $viewModel.currentCode)
                .font(.monospaced(.body)())
                .frame(minHeight: 200)
                .border(Color.gray, width: 1)
                .onChange(of: viewModel.currentCode) { newCode in
                    // In a real editor, you'd get the actual cursor position.
                    // For this mock, we'll assume cursor is always at the end.
                    cursorPosition = newCode.count
                    viewModel.userTyped(newCode: newCode, cursorPosition: cursorPosition)
                }

            if viewModel.isLoadingCompletions {
                ProgressView()
                    .progressViewStyle(.circular)
                    .padding(.vertical)
            } else if !viewModel.suggestions.isEmpty {
                List(viewModel.suggestions, id: \.self) { suggestion in
                    Text(suggestion)
                        .font(.footnote)
                        .foregroundColor(.blue)
                        .onTapGesture {
                            // Simulate applying a suggestion
                            let prefix = viewModel.currentCode.prefix(cursorPosition)
                            let words = prefix.split(whereSeparator: \.isWhitespace)
                            let lastWordLength = words.last?.count ?? 0
                            let newCode = viewModel.currentCode.prefix(cursorPosition - lastWordLength) + suggestion + viewModel.currentCode.suffix(viewModel.currentCode.count - cursorPosition)
                            viewModel.userTyped(newCode: String(newCode), cursorPosition: cursorPosition - lastWordLength + suggestion.count)
                        }
                }
                .frame(maxHeight: 150)
                .border(Color.secondary, width: 0.5)
            } else {
                Text("Start typing for suggestions...")
                    .foregroundColor(.secondary)
                    .padding()
            }
        }
        .padding()
        .navigationTitle("SwiftPad Editor")
    }
}
*/
