
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import StoreKit
import Observation

// MARK: - Models

/// Represents the tier of AI intelligence available to the user.
enum AIModelTier: Sendable {
    case standard // Low cost, fast, local or small model
    case premium  // High cost, intelligent, cloud-based LLM
}

/// A simple structure representing an AI response.
struct ChatMessage: Identifiable, Sendable {
    let id = UUID()
    let text: String
    let isUser: Bool
}

// MARK: - Subscription Manager

/// `SubscriptionManager` is a central actor-isolated service that manages 
/// all interactions with Apple's StoreKit 2.
///
/// We use `@Observable` for seamless SwiftUI integration and `@MainActor` 
/// to ensure all UI-facing state changes happen on the main thread.
@Observable
@MainActor
final class SubscriptionManager {
    /// The current set of active entitlements.
    private(set) var hasPremiumAccess: Bool = false
    
    /// The product ID for the premium subscription.
    /// In a real app, this would be fetched from App Store Connect.
    private let premiumProductID = "com.ai_app.premium_monthly"
    
    init() {
        // Task to check status immediately upon initialization.
        Task {
            await updateSubscriptionStatus()
        }
    }
    
    /// Checks the current StoreKit transactions to verify if the user has an active subscription.
    /// This uses the modern StoreKit 2 `Transaction.currentEntitlements` API.
    func updateSubscriptionStatus() async {
        var isPremium = false
        
        // Iterate through all current entitlements.
        for await result in Transaction.currentEntitlements {
            do {
                // Verify the transaction signature.
                let transaction = try await result.verificationResult.authenticated()
                
                // Check if the verified transaction matches our premium product ID.
                if transaction.productID == premiumProductID {
                    isPremium = true
                    break
                }
            } catch {
                // If verification fails, we treat the transaction as invalid.
                print("Transaction verification failed: \(error)")
            }
        }
        
        self.hasPremiumAccess = isPremium
    }
    
    /// Initiates the StoreKit 2 purchase flow.
    func purchasePremium() async throws {
        // In a real implementation, you would fetch the Product from StoreKit first.
        // For this example, we simulate the purchase success.
        try await Task.sleep(for: .seconds(1.5)) 
        self.hasPremiumAccess = true
    }
}

// MARK: - AI Engine

/// `AIEngine` simulates the heavy lifting of an AI model.
/// It is marked as `Sendable` to safely move between concurrency domains.
final class AIEngine: Sendable {
    
    /// Simulates an AI inference call.
    /// - Parameter prompt: The user's input.
    /// - Parameter tier: The model tier to use.
    /// - Returns: A simulated AI response string.
    func generateResponse(for prompt: String, using tier: AIModelTier) async -> String {
        // Simulate network/compute latency.
        let latency: UInt64 = tier == .premium ? 2_000_000_000 : 500_000_000 // 2s vs 0.5s
        try? await Task.sleep(nanoseconds: latency)
        
        switch tier {
        case .standard:
            return "🤖 [Standard Model]: I processed '\(prompt)' quickly using local compute."
        case .premium:
            return "🧠 [Premium Model]: I have analyzed '\(prompt)' using deep reasoning and extensive knowledge."
        }
    }
}

// MARK: - View Model

/// `ChatViewModel` acts as the orchestrator between the AI Engine, 
/// the Subscription Manager, and the SwiftUI View.
@Observable
@MainActor
final class ChatViewModel {
    var messages: [ChatMessage] = []
    var inputText: String = ""
    var isProcessing: Bool = false
    var showPaywall: Bool = false
    
    private let aiEngine = AIEngine()
    private let subscriptionManager: SubscriptionManager
    
    init(subscriptionManager: SubscriptionManager) {
        self.subscriptionManager = subscriptionManager
    }
    
    /// The core logic for sending a message and deciding which AI tier to use.
    func sendMessage() async {
        guard !inputText.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        
        let userPrompt = inputText
        messages.append(ChatMessage(text: userPrompt, isUser: true))
        inputText = ""
        isProcessing = true
        
        // 1. Determine the Tier (The Feature Gate)
        let tier: AIModelTier = subscriptionManager.hasPremiumAccess ? .premium : .standard
        
        // 2. Check if the user is attempting a premium action without access.
        // In this simple example, we allow everyone to use 'Standard', 
        // but let's simulate a 'Premium Only' feature trigger.
        if userPrompt.contains("Deeply analyze") && !subscriptionManager.hasPremiumAccess {
            // Trigger the paywall instead of the AI.
            self.showPaywall = true
            self.isProcessing = false
            return
        }
        
        // 3. Perform the AI inference.
        let responseText = await aiEngine.generateResponse(for: userPrompt, using: tier)
        
        // 4. Update UI.
        messages.append(ChatMessage(text: responseText, isUser: false))
        isProcessing = false
    }
    
    func upgrade() async {
        do {
            try await subscriptionManager.purchasePremium()
            showPaywall = false
        } catch {
            print("Purchase failed: \(error)")
        }
    }
}

// MARK: - Views

/// The main chat interface.
struct ChatView: View {
    @State private var viewModel: ChatViewModel
    @Environment(\.dismiss) private var dismiss
    
    init(subscriptionManager: SubscriptionManager) {
        // We initialize the ViewModel with the shared subscription manager.
        _viewModel = State(initialValue: ChatViewModel(subscriptionManager: subscriptionManager))
    }
    
    var body: some View {
        NavigationStack {
            VStack {
                // Message List
                ScrollViewReader { proxy in
                    List(viewModel.messages) { message in
                        ChatBubble(message: message)
                            .listRowSeparator(.hidden)
                            .id(message.id)
                    }
                    .onChange(of: viewModel.messages.count) {
                        if let lastId = viewModel.messages.last?.id {
                            withAnimation { proxy.scrollTo(lastId, anchor: .bottom) }
                        }
                    }
                }
                
                if viewModel.isProcessing {
                    ProgressView("AI is thinking...")
                        .padding(.vertical, 8)
                }
                
                // Input Area
                HStack {
                    TextField("Ask anything...", text: $viewModel.inputText)
                        .textFieldStyle(.roundedBorder)
                        .submitLabel(.send)
                        .onSubmit {
                            Task { await viewModel.sendMessage() }
                        }
                    
                    Button {
                        Task { await viewModel.sendMessage() }
                    } label: {
                        Image(systemName: "paperplane.fill")
                            .font(.title2)
                    }
                    .disabled(viewModel.inputText.isEmpty || viewModel.isProcessing)
                }
                .padding()
            }
            .navigationTitle("AI Assistant")
            .sheet(isPresented: $viewModel.showPaywall) {
                PaywallView(viewModel: viewModel)
            }
        }
    }
}

/// A component representing a single chat bubble.
struct ChatBubble: View {
    let message: ChatMessage
    
    var body: some View {
        HStack {
            if message.isUser { Spacer() }
            
            Text(message.text)
                .padding(12)
                .background(message.isUser ? Color.blue : Color.gray.opacity(0.2))
                .foregroundColor(message.isUser ? .white : .primary)
                .cornerRadius(16)
            
            if !message.isUser { Spacer() }
        }
        .padding(.vertical, 4)
    }
}

/// The Paywall View presented when a user hits a feature gate.
struct PaywallView: View {
    @Bindable var viewModel: ChatViewModel
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(spacing: 24) {
            Spacer()
            
            Image(systemName: "sparkles")
                .font(.system(size: 80))
                .foregroundStyle(.yellow.gradient)
            
            Text("Unlock Pro Intelligence")
                .font(.largeTitle.bold())
            
            Text("Get access to our most advanced reasoning models, unlimited high-speed responses, and priority server access.")
                .font(.body)
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal)
            
            VStack(spacing: 12) {
                FeatureRow(icon: "brain.head.profile", text: "Advanced Reasoning")
                FeatureRow(icon: "bolt.fill", text: "Priority Speed")
                FeatureRow(icon: "lock.shield.fill", text: "Private Cloud Compute")
            }
            .padding()
            
            Spacer()
            
            Button {
                Task {
                    await viewModel.upgrade()
                    dismiss()
                }
            } label: {
                Text("Upgrade Now")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(12)
            }
            .padding(.horizontal)
            
            Button("Maybe Later") {
                dismiss()
            }
            .foregroundStyle(.secondary)
            .padding(.bottom)
        }
        .presentationDetents([.medium, .large])
    }
}

struct FeatureRow: View {
    let icon: String
    let text: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundStyle(.blue)
            Text(text)
                .font(.subheadline)
        }
    }
}

// MARK: - App Entry Point

@main
struct AIApp: App {
    // The SubscriptionManager is owned by the App to ensure it lives 
    // for the entire lifecycle of the application.
    @State private var subscriptionManager = SubscriptionManager()
    
    var body: some Scene {
        WindowGroup {
            ChatView(subscriptionManager: subscriptionManager)
        }
    }
}
