
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

// MARK: - Exercise 4: LoRA Adapter Integration

@available(iOS 18.0, macOS 15.0, *)
class BaseClassifierLayer: MLXNN.Module {
    let linear: MLXNN.Linear
    
    init(inputDimension: Int, outputDimension: Int) {
        self.linear = MLXNN.Linear(inputDimension, outputDimension)
        super.init()
    }
    
    override func callAsFunction(_ inputs: MLXArray) -> MLXArray {
        // Simple linear transformation
        return linear(inputs)
    }
}

@available(iOS 18.0, macOS 15.0, *)
class LoRAAdapter: MLXNN.Module {
    let linearA: MLXNN.Linear
    let linearB: MLXNN.Linear
    let scale: Float // Scaling factor for LoRA output

    init(inputDimension: Int, outputDimension: Int, rank: Int, scale: Float = 1.0) {
        // linearA projects from inputDimension to a low-rank 'r'
        self.linearA = MLXNN.Linear(inputDimension, rank)
        // linearB projects from low-rank 'r' back to outputDimension
        self.linearB = MLXNN.Linear(rank, outputDimension)
        self.scale = scale
        super.init()
    }
    
    override func callAsFunction(_ inputs: MLXArray) -> MLXArray {
        // Apply linearA then linearB, scaled
        return linearB(linearA(inputs)) * scale
    }
}

@available(iOS 18.0, macOS 15.0, *)
class LoRAClassifier: MLXNN.Module {
    let baseLayer: BaseClassifierLayer
    let loraAdapter: LoRAAdapter
    
    init(inputDimension: Int, hiddenDimension: Int, rank: Int) {
        // The base layer maps input to a hidden representation (e.g., for classification)
        self.baseLayer = BaseClassifierLayer(inputDimension: inputDimension, outputDimension: hiddenDimension)
        // The LoRA adapter adds a low-rank adjustment to the base layer's output
        self.loraAdapter = LoRAAdapter(inputDimension: inputDimension, outputDimension: hiddenDimension, rank: rank)
        super.init()
    }
    
    override func callAsFunction(_ inputs: MLXArray) -> MLXArray {
        // The core LoRA idea: output = base_output + lora_output
        let baseOutput = baseLayer(inputs)
        let loraOutput = loraAdapter(inputs)
        
        // Add the LoRA adjustment to the base model's output
        return baseOutput + loraOutput
    }
}

// MARK: - Outline of a Simplified Training Loop with valueAndGradient

@available(iOS 18.0, macOS 15.0, *)
func outlineLoRATraining() {
    print("\n--- Exercise 4: LoRA Adapter Integration for Custom Text Classifier ---")
    
    let inputDim = 384 // e.g., embedding dimension from a pre-trained model
    let hiddenDim = 128 // e.g., internal dimension for classification
    let numClasses = 10 // e.g., number of text categories
    let loraRank = 8   // Low rank for LoRA adapter, much smaller than input/output dims

    // 1. Instantiate the LoRAClassifier model
    let model = LoRAClassifier(inputDimension: inputDim, hiddenDimension: hiddenDim, rank: loraRank)
    print("LoRAClassifier model instantiated with base layer and LoRA adapter.")
    
    // 2. Define a dummy loss function
    // In a real scenario, this would be CrossEntropyLoss or similar.
    // It takes the model, inputs, and targets, and returns a scalar loss.
    let loss_fn = { (model: LoRAClassifier, inputs: MLXArray, targets: MLXArray) -> MLXArray in
        // Simulate a classification head on top of the LoRAClassifier's output
        let classifierHead = MLXNN.Linear(hiddenDim, numClasses)
        let logits = classifierHead(model(inputs)) // Apply the model, then the classification head
        
        // Dummy loss: sum of squared differences (replace with actual loss like CrossEntropy)
        return MLX.mean(MLX.square(logits - targets))
    }
    
    // 3. Prepare dummy data (batch size 4)
    let dummyInputs = MLXArray.randomUniform([4, inputDim], dtype: .float32) // Batch of 4 embeddings
    let dummyTargets = MLXArray.randomUniform([4, numClasses], dtype: .float32) // Dummy one-hot or regression targets

    // 4. Use MLX.valueAndGradient for parameter-efficient fine-tuning
    // We only want to compute gradients for the LoRA adapter's parameters.
    
    // Get all parameters of the model
    let allParameters = model.parameters()
    
    // Filter parameters to include ONLY those belonging to the LoRA adapter
    // This is the core of parameter-efficient fine-tuning.
    let trainableParameters = allParameters.filter { (name, _) in
        // LoRA adapter parameters will have "loraAdapter" in their name path
        name.contains("loraAdapter")
    }
    
    print("\nTotal model parameters: \(allParameters.count)")
    print("Trainable LoRA adapter parameters: \(trainableParameters.count)")
    
    // Call valueAndGradient, specifying only the trainableParameters
    let (loss, gradients) = MLX.valueAndGradient(loss_fn, model, dummyInputs, dummyTargets, parameters: trainableParameters)
    
    print("\nCalculated dummy loss: \(loss.item() as Float)")
    print("Number of gradients calculated (only for LoRA adapter): \(gradients.count)")
    
    // Demonstrate inspecting gradients for LoRA adapter
    for (name, grad) in gradients {
        print("  Gradient for \(name), shape: \(grad.shape)")
    }
    
    // 5. Outline application of gradients (conceptual)
    print("\n--- Conceptual Gradient Application ---")
    print("In a real training loop, an optimizer (e.g., AdamW) would then update")
    print("ONLY the 'trainableParameters' (LoRA adapter parameters) using these 'gradients'.")
    print("The base model's parameters remain frozen, significantly reducing memory and compute.")
    // Example (conceptual, not runnable without an optimizer):
    // let optimizer = MLXNN.AdamW(learningRate: 0.001)
    // let updatedParameters = optimizer.apply(gradients: gradients, parameters: trainableParameters)
    // model.update(parameters: updatedParameters) // Update only the LoRA parts
}

// Call the demonstration function
// outlineLoRATraining() // Uncomment to run
