
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Vision

// A wrapper for VNFaceObservation to make it Observable
@Observable
@available(iOS 17.0, *) // @Observable requires iOS 17+
class ObservableFace {
    var id: UUID = UUID() // Unique ID for SwiftUI ForEach
    var boundingBox: CGRect
    var roll: NSNumber?
    var yaw: NSNumber?
    var landmarks: VNFaceLandmarks2D?

    init(from observation: VNFaceObservation) {
        self.boundingBox = observation.boundingBox
        self.roll = observation.roll
        self.yaw = observation.yaw
        self.landmarks = observation.landmarks
        // You might copy more specific landmark points if needed
    }

    // Update properties from a new observation (e.g., for tracking)
    func update(with observation: VNFaceObservation) {
        self.boundingBox = observation.boundingBox
        self.roll = observation.roll
        self.yaw = observation.yaw
        self.landmarks = observation.landmarks
    }
}

@available(iOS 17.0, *)
struct FaceDetectionView: View {
    @State private var detectedFaces: [ObservableFace] = []

    // Imagine this function is called after a Vision request completes
    func updateDetectedFaces(newObservations: [VNFaceObservation]) {
        // Simple update logic: replace all for now
        // In a real app, you'd match existing faces to update them
        detectedFaces = newObservations.map { ObservableFace(from: $0) }
    }

    var body: some View {
        VStack {
            Text("Detected Faces: \(detectedFaces.count)")
            ForEach(detectedFaces) { face in
                Rectangle()
                    .stroke(Color.red, lineWidth: 2)
                    .frame(width: face.boundingBox.width * 300, height: face.boundingBox.height * 300) // Scale for display
                    .overlay(
                        Text("Roll: \(face.roll?.doubleValue ?? 0, format: .number.precision(.fractionLength(1)))")
                            .font(.caption)
                            .background(Color.black.opacity(0.5))
                            .foregroundColor(.white)
                            .offset(y: face.boundingBox.height * 150 + 10)
                    )
            }
        }
    }
}
