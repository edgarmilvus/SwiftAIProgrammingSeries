
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
struct MLInput: Sendable { // Conforming to Sendable ensures safe transfer
    let text: String
    let style: String?
}

@available(iOS 18.0, *)
struct MLOutput: Sendable {
    let image: UIImage // UIImage is not Sendable, but often passed by value.
                       // For complex types, ensure deep immutability or copy on transfer.
                       // In practice, UIImage is often an `NSObject` subclass and implicitly
                       // thread-safe for basic operations, but modifications should be on main.
                       // For true Sendable, one might pass `Data` or `URL` to an image.
                       // For this example, we assume UIImage is fine for transfer.
    let metadata: [String: String]
}

@available(iOS 18.0, *)
enum WorkflowState: Sendable, Equatable { // WorkflowState must be Sendable to be passed safely
    case promptInput
    case generatingImage
    case imageReview(MLOutput)
    case refinementOptions(MLOutput)
    case exportOptions(MLOutput)
    case error(String)
}

@available(iOS 18.0, *)
class AIAppModel: ObservableObject {
    @Published var currentWorkflowState: WorkflowState = .promptInput
    private let inferenceEngine = CoreMLInferenceEngine() // Actor instance

    func submitPrompt(_ prompt: String, style: String?) async {
        await MainActor.run { self.currentWorkflowState = .generatingImage }
        let input = MLInput(text: prompt, style: style) // MLInput is Sendable
        do {
            let output = try await inferenceEngine.performInference(input: input) // Input passed to actor
            await MainActor.run { self.currentWorkflowState = .imageReview(output) } // Output passed back
        } catch {
            await MainActor.run { self.currentWorkflowState = .error(error.localizedDescription) }
        }
    }
}
