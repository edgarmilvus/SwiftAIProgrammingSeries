
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

// MARK: - ChatBubbleShape (Custom Shape for the entire bubble with tail)
struct ChatBubbleShape: Shape {
    enum TailDirection {
        case leading, trailing
    }

    let cornerRadius: CGFloat
    let tailDirection: TailDirection

    func path(in rect: CGRect) -> Path {
        var path = Path()

        let tailWidth: CGFloat = 10
        let tailHeight: CGFloat = 10
        let tailOffset: CGFloat = 8 // How far from the bottom edge the tail starts

        // Define the main rounded rectangle
        let mainRect = CGRect(
            x: tailDirection == .leading ? tailWidth : rect.minX,
            y: rect.minY,
            width: rect.width - (tailDirection == .leading ? tailWidth : 0),
            height: rect.height
        )
        
        // Adjust mainRect for trailing tail
        if tailDirection == .trailing {
            mainRect.size.width -= tailWidth
        }

        path.addRoundedRect(in: mainRect, cornerSize: CGSize(width: cornerRadius, height: cornerRadius))

        // Add the tail
        if tailDirection == .leading {
            path.move(to: CGPoint(x: mainRect.minX, y: mainRect.maxY - tailOffset))
            path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY)) // Tip of the tail
            path.addLine(to: CGPoint(x: mainRect.minX + tailWidth, y: mainRect.maxY - tailOffset))
        } else { // Trailing
            path.move(to: CGPoint(x: mainRect.maxX, y: mainRect.maxY - tailOffset))
            path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY)) // Tip of the tail
            path.addLine(to: CGPoint(x: mainRect.maxX - tailWidth, y: mainRect.maxY - tailOffset))
        }

        return path
    }
}

// MARK: - UserChatBubbleView with Tail
struct UserChatBubbleWithTailView: View {
    let message: String
    let bubbleColor: Color = .blue

    var body: some View {
        HStack {
            Spacer()
            Text(message)
                .padding(10)
                .background(
                    ChatBubbleShape(cornerRadius: 15, tailDirection: .trailing)
                        .fill(bubbleColor)
                )
                .foregroundColor(.white)
                .frame(maxWidth: 280, alignment: .trailing)
        }
    }
}

// MARK: - AIChatBubbleView with Tail
struct AIChatBubbleWithTailView: View {
    let message: String
    let bubbleColor: Color = .gray.opacity(0.2)

    var body: some View {
        HStack {
            Text(message)
                .padding(10)
                .background(
                    ChatBubbleShape(cornerRadius: 15, tailDirection: .leading)
                        .fill(bubbleColor)
                )
                .foregroundColor(.primary)
                .frame(maxWidth: 280, alignment: .leading)
            Spacer()
        }
    }
}

// MARK: - ContentView for demonstration
struct ContentViewWithTails: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                AIChatBubbleWithTailView(message: "Hello! How can I assist you today?")
                UserChatBubbleWithTailView(message: "I need help understanding SwiftUI layout.")
                AIChatBubbleWithTailView(message: "SwiftUI uses a declarative approach. Key components are VStack, HStack, and ZStack for arranging views.")
                UserChatBubbleWithTailView(message: "That makes sense. What about modifiers like padding and background?")
                AIChatBubbleWithTailView(message: "Modifiers like `.padding()` add space around a view, and `.background()` changes its visual appearance, often with shapes or colors.")
                UserChatBubbleWithTailView(message: "Thanks! This is very helpful.")
            }
            .padding()
        }
        .navigationTitle("AI Chat with Tails")
    }
}

// MARK: - Preview Provider
#Preview {
    ContentViewWithTails()
}
