
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import RealityKit
import Foundation

struct ProbabilityDensityComponent: Component, Codable, Sendable {
    var points: [SIMD3<Float>]
    var intensity: Float
}

@available(visionOS 1.0, *)
class ProbabilityCloudSystem: System {
    private static let query = EntityQuery(where: .has(ProbabilityDensityComponent.self))
    private let pointName = "ProbabilityPoint"

    required init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        let deltaTime = Float(context.deltaTime)
        let elapsedTime = Float(context.deltaTime) // In a real app, use a total elapsed timer

        context.scene.performQuery(Self.query).forEach { entity in
            guard let density = entity.components[ProbabilityDensityComponent.self] else { return }
            
            // 1. Manage Child Entities (Object Pooling Logic)
            var currentChildren = entity.children.filter { $0.name == pointName }
            let pointCount = density.points.count
            
            // Add missing points
            if currentChildren.count < pointCount {
                for _ in 0..<(pointCount - currentChildren.count) {
                    let dot = ModelEntity(mesh: .generateSphere(radius: 0.02), 
                                         materials: [UnlitMaterial(color: .orange)])
                    dot.name = pointName
                    entity.addChild(dot)
                    currentChildren.append(dot)
                }
            }
            
            // Remove excess points
            if currentChildren.count > pointCount {
                for i in (pointCount..<currentChildren.count).reversed() {
                    currentChildren[i].removeFromParent()
                }
                currentChildren.removeLast(currentChildren.count - pointCount)
            }

            // 2. Update Point Positions and Visual Dynamics
            for (index, pointPosition) in density.points.enumerated() {
                let dot = currentChildren[index]
                dot.position = pointPosition
                
                // Visual Dynamics: Sine wave pulse for a "living" effect
                // We use the index to offset the sine wave so points don't pulse in unison
                let pulse = sin(Float(Date().timeIntervalSince1970) * 3.0 + Float(index))
                let scaleFactor = 1.0 + (pulse * 0.2 * density.intensity)
                dot.scale = SIMD3<Float>(repeating: scaleFactor)
            }
        }
    }
}
