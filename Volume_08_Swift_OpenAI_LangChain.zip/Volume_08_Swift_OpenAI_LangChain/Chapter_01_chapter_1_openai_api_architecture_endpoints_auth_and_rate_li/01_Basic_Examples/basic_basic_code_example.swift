
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Observation

// MARK: - Models

/// Represents the role of a participant in the chat conversation.
/// Conforms to `Sendable` to ensure it can be safely passed across concurrency domains.
enum ChatRole: String, Codable, Sendable {
    case system
    case user
    case assistant
}

/// The fundamental unit of communication in the OpenAI Chat Completions API.
struct ChatMessage: Codable, Identifiable, Sendable {
    let id = UUID() // Local ID for SwiftUI identity
    let role: ChatRole
    let content: String
    
    // CodingKeys allows us to map the local 'id' property (which OpenAI doesn't use)
    // to only the 'role' and 'content' fields required by the API.
    enum CodingKeys: String, CodingKey {
        case role
        case content
    }
}

/// The request body sent to the `v1/chat/completions` endpoint.
struct ChatCompletionRequest: Codable, Sendable {
    let model: String
    let messages: [ChatMessage]
    let temperature: Double
}

/// The top-level response object returned by OpenAI.
struct ChatCompletionResponse: Codable, Sendable {
    struct Choice: Codable, Sendable {
        let message: ChatMessage
    }
    let choices: [Choice]
}

// MARK: - Error Handling

/// Custom error types specifically for OpenAI integration.
enum OpenAIError: Error, LocalizedError {
    case invalidURL
    case requestFailed(Int) // Captures HTTP status codes (e.g., 429 for Rate Limit)
    case decodingError
    case unauthorized // 401 error
    
    var errorDescription: String? {
        switch self {
        case .invalidURL: return "The API endpoint URL is invalid."
        case .requestFailed(let code): return "API request failed with status code: \(code)."
        case .decodingError: return "Failed to parse the response from OpenAI."
        case .unauthorized: return "Invalid API Key. Please check your credentials."
        }
    }
}

// MARK: - Service Layer

/// An actor that handles all network communication with OpenAI.
/// Using an `actor` ensures that the API key and session state are protected 
/// from data races in a multi-threaded Swift 6 environment.
@available(iOS 18.0, *)
actor OpenAIService {
    private let apiKey: String
    private let endpoint = "https://api.openai.com/v1/chat/completions"
    private let session: URLSession

    init(apiKey: String, session: URLSession = .shared) {
        self.apiKey = apiKey
        self.session = session
    }

    /// Sends a prompt to the OpenAI API and returns the assistant's response.
    /// - Parameter messages: An array of `ChatMessage` objects representing the conversation history.
    /// - Returns: The content string from the first choice in the response.
    /// - Throws: `OpenAIError` or standard `Error`.
    func fetchChatCompletion(messages: [ChatMessage]) async throws -> String {
        guard let url = URL(string: endpoint) else {
            throw OpenAIError.invalidURL
        }

        // 1. Prepare the Request Body
        let requestBody = ChatCompletionRequest(
            model: "gpt-4o", // Using the latest flagship model
            messages: messages,
            temperature: 0.7
        )

        // 2. Encode the request to JSON
        let encoder = JSONEncoder()
        let jsonData = try encoder.encode(requestBody)

        // 3. Configure the URLRequest
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.httpBody = jsonData

        // 4. Perform the Network Request
        let (data, response) = try await session.data(for: request)

        // 5. Validate the HTTP Response
        guard let httpResponse = response as? HTTPURLResponse else {
            throw OpenAIError.requestFailed(0)
        }

        switch httpResponse.statusCode {
        case 200:
            break // Success
        case 401:
            throw OpenAIError.unauthorized
        case 429:
            // This is the 'Rate Limit' error mentioned in the chapter
            throw OpenAIError.requestFailed(429)
        default:
            throw OpenAIError.requestFailed(httpResponse.statusCode)
        }

        // 6. Decode the JSON Response
        do {
            let decoder = JSONDecoder()
            let decodedResponse = try decoder.decode(ChatCompletionResponse.self, from: data)
            return decodedResponse.choices.first?.message.content ?? ""
        } catch {
            throw OpenAIError.decodingError
        }
    }
}

// MARK: - ViewModel Layer

/// The ViewModel manages the state of the UI.
/// It is marked with `@MainActor` to ensure all updates to `@Observable` properties
/// occur on the main thread, preventing UI glitches or crashes.
@available(iOS 18.0, *)
@Observable
@MainActor
class ChatViewModel {
    var messages: [ChatMessage] = []
    var isProcessing: Bool = false
    var errorMessage: String?
    
    private let apiService: OpenAIService

    init(apiService: OpenAIService) {
        self.apiService = apiService
        // Initialize with a system prompt to set the AI's behavior
        self.messages = [
            ChatMessage(role: .system, content: "You are a helpful assistant for a Note-Taking app.")
        ]
    }

    /// User-facing function to send a message.
    func sendMessage(_ text: String) async {
        guard !text.isEmpty else { return }
        
        // Append user message to UI
        let userMessage = ChatMessage(role: .user, content: text)
        messages.append(userMessage)
        
        isProcessing = true
        errorMessage = nil
        
        do {
            // Call the actor-isolated service
            let responseText = try await apiService.fetchChatCompletion(messages: messages)
            
            // Append assistant response
            let assistantMessage = ChatMessage(role: .assistant, content: responseText)
            messages.append(assistantMessage)
        } catch let error as OpenAIError {
            errorMessage = error.localizedDescription
        } catch {
            errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
        }
        
        isProcessing = false
    }
}
