
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import CreateML

// Assuming CreateML provides progress updates via an async sequence or similar
@available(iOS 18.0, macOS 15.0, *)
@Observable
class TrainingViewModel {
    var progress: Double = 0.0
    var currentEpoch: Int = 0
    var totalEpochs: Int = 0
    var validationLoss: Double?
    var trainingAccuracy: Double?
    var isTraining: Bool = false
    var errorMessage: String?

    func startTraining(trainingDataURL: URL) async {
        isTraining = true
        errorMessage = nil
        progress = 0.0

        do {
            let trainingData = try await MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)
            let parameters = MLImageClassifier.ModelParameters(
                featureExtractor: .init(augmentation: .standard),
                epochs: 10 // Example
            )

            // Hypothetical Create ML API that provides progress updates
            for await update in MLImageClassifier.trainWithProgress(trainingData: trainingData, parameters: parameters) {
                switch update {
                case .epoch(let epoch, let total, let metrics):
                    self.currentEpoch = epoch
                    self.totalEpochs = total
                    self.progress = Double(epoch) / Double(total)
                    self.validationLoss = metrics.validationLoss
                    self.trainingAccuracy = metrics.trainingAccuracy
                case .completed(let model):
                    print("Training finished. Model: \(model)")
                    self.isTraining = false
                }
            }
        } catch {
            self.errorMessage = error.localizedDescription
            self.isTraining = false
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct TrainingProgressView: View {
    @State private var viewModel = TrainingViewModel()
    let trainingDataURL: URL // Passed in from environment

    var body: some View {
        VStack {
            if viewModel.isTraining {
                ProgressView(value: viewModel.progress) {
                    Text("Training Epoch \(viewModel.currentEpoch) of \(viewModel.totalEpochs)")
                }
                .padding()

                if let loss = viewModel.validationLoss {
                    Text("Validation Loss: \(loss, specifier: "%.4f")")
                }
                if let accuracy = viewModel.trainingAccuracy {
                    Text("Training Accuracy: \(accuracy, specifier: "%.2f")%")
                }
            } else if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
            } else {
                Text("Ready to train.")
            }

            Button("Start Training") {
                Task {
                    await viewModel.startTraining(trainingDataURL: trainingDataURL)
                }
            }
            .disabled(viewModel.isTraining)
        }
    }
}
