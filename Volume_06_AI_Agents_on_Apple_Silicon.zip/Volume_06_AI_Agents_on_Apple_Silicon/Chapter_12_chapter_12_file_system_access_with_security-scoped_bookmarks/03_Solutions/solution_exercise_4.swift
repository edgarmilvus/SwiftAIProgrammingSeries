
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

// This solution focuses on macOS (AppKit) for the UI, but the core
// DataSynchronizer logic is platform-agnostic.

import Foundation
import UniformTypeIdentifiers
import AppKit // For NSOpenPanel and AppKit UI

// MARK: - Data Synchronizer Logic (Platform-Agnostic)

class DataSynchronizer: ObservableObject {
    @Published private(set) var inputFolderURL: URL?
    @Published private(set) var outputFolderURL: URL?
    @Published private(set) var syncStatus: String = "Ready."

    private let inputBookmarkKey = "inputFolderBookmark"
    private let outputBookmarkKey = "outputFolderBookmark"

    // Keep track of active access to stop them when no longer needed
    private var isInputFolderAccessed: Bool = false
    private var isOutputFolderAccessed: Bool = false

    init() {
        // Load bookmarks on initialization
        Task {
            await loadBookmarks()
        }
    }

    // Call this when the app is about to terminate
    func stopAccessingAllResources() {
        if isInputFolderAccessed {
            inputFolderURL?.stopAccessingSecurityScopedResource()
            isInputFolderAccessed = false
        }
        if isOutputFolderAccessed {
            outputFolderURL?.stopAccessingSecurityScopedResource()
            isOutputFolderAccessed = false
        }
        print("Stopped accessing all resources.")
    }

    // MARK: - Bookmark Management

    private func saveBookmark(for url: URL, key: String) throws {
        // Ensure initial access to create bookmark
        guard url.startAccessingSecurityScopedResource() else {
            print("Failed to start accessing resource for saving bookmark: \(key)")
            throw BookmarkError.accessDenied
        }
        defer { url.stopAccessingSecurityScopedResource() }

        let bookmarkData = try url.bookmarkData(options: .withSecurityScopedResource,
                                                includingResourceValuesForKeys: nil,
                                                relativeTo: nil)
        UserDefaults.standard.set(bookmarkData, forKey: key)
        print("Bookmark saved for \(key): \(url.lastPathComponent)")
    }

    private func resolveBookmark(key: String) -> URL? {
        guard let bookmarkData = UserDefaults.standard.data(forKey: key) else {
            print("No bookmark data found for key: \(key)")
            return nil
        }

        var isStale = false
        do {
            let url = try URL(resolvingBookmarkData: bookmarkData,
                              options: .withSecurityScopedResource,
                              relativeTo: nil,
                              bookmarkDataIsStale: &isStale)

            if isStale {
                print("Bookmark for \(key) is stale, attempting to refresh...")
                let newBookmarkData = try url.bookmarkData(options: .withSecurityScopedResource,
                                                           includingResourceValuesForKeys: nil,
                                                           relativeTo: nil)
                UserDefaults.standard.set(newBookmarkData, forKey: key)
                print("Bookmark for \(key) refreshed successfully.")
            }
            return url
        } catch {
            print("Error resolving or refreshing bookmark for \(key): \(error.localizedDescription)")
            UserDefaults.standard.removeObject(forKey: key) // Clear invalid bookmark
            return nil
        }
    }

    @MainActor // UI updates and state changes should be on MainActor
    func updateInputFolder(url: URL) async {
        if isInputFolderAccessed {
            inputFolderURL?.stopAccessingSecurityScopedResource()
            isInputFolderAccessed = false
        }
        do {
            try saveBookmark(for: url, key: inputBookmarkKey)
            self.inputFolderURL = resolveBookmark(key: inputBookmarkKey)
            if let resolvedURL = self.inputFolderURL, resolvedURL.startAccessingSecurityScopedResource() {
                isInputFolderAccessed = true
                self.syncStatus = "Input folder set: \(resolvedURL.lastPathComponent)"
            } else {
                self.inputFolderURL = nil
                self.syncStatus = "Failed to access input folder after setting."
            }
        } catch {
            self.inputFolderURL = nil
            self.syncStatus = "Error setting input folder: \(error.localizedDescription)"
        }
    }

    @MainActor
    func updateOutputFolder(url: URL) async {
        if isOutputFolderAccessed {
            outputFolderURL?.stopAccessingSecurityScopedResource()
            isOutputFolderAccessed = false
        }
        do {
            try saveBookmark(for: url, key: outputBookmarkKey)
            self.outputFolderURL = resolveBookmark(key: outputBookmarkKey)
            if let resolvedURL = self.outputFolderURL, resolvedURL.startAccessingSecurityScopedResource() {
                isOutputFolderAccessed = true
                self.syncStatus = "Output folder set: \(resolvedURL.lastPathComponent)"
            } else {
                self.outputFolderURL = nil
                self.syncStatus = "Failed to access output folder after setting."
            }
        } catch {
            self.outputFolderURL = nil
            self.syncStatus = "Error setting output folder: \(error.localizedDescription)"
        }
    }

    @MainActor
    func loadBookmarks() async {
        stopAccessingAllResources() // Ensure previous access is stopped

        self.inputFolderURL = resolveBookmark(key: inputBookmarkKey)
        if let resolvedURL = self.inputFolderURL, resolvedURL.startAccessingSecurityScopedResource() {
            isInputFolderAccessed = true
        } else {
            self.inputFolderURL = nil
        }

        self.outputFolderURL = resolveBookmark(key: outputBookmarkKey)
        if let resolvedURL = self.outputFolderURL, resolvedURL.startAccessingSecurityScopedResource() {
            isOutputFolderAccessed = true
        } else {
            self.outputFolderURL = nil
        }

        if inputFolderURL != nil && outputFolderURL != nil {
            self.syncStatus = "Folders loaded. Ready to synchronize."
        } else if inputFolderURL != nil {
            self.syncStatus = "Input folder loaded. Output folder missing."
        } else if outputFolderURL != nil {
            self.syncStatus = "Output folder loaded. Input folder missing."
        } else {
            self.syncStatus = "No folders loaded. Please select."
        }
    }

    @MainActor
    func clearBookmarks() {
        stopAccessingAllResources()
        UserDefaults.standard.removeObject(forKey: inputBookmarkKey)
        UserDefaults.standard.removeObject(forKey: outputBookmarkKey)
        inputFolderURL = nil
        outputFolderURL = nil
        syncStatus = "All folders cleared."
        print("All bookmarks cleared from UserDefaults.")
    }

    // MARK: - Synchronization Logic

    @MainActor
    func synchronize() async {
        guard let inputURL = inputFolderURL, isInputFolderAccessed,
              let outputURL = outputFolderURL, isOutputFolderAccessed else {
            self.syncStatus = "Error: Both input and output folders must be selected and accessible."
            return
        }

        self.syncStatus = "Synchronization started..."
        var processedCount = 0

        do {
            let fileManager = FileManager.default
            let contents = try fileManager.contentsOfDirectory(at: inputURL,
                                                               includingPropertiesForKeys: nil,
                                                               options: .skipsHiddenFiles)

            let textFiles = contents.filter { $0.pathExtension.lowercased() == "txt" }

            if textFiles.isEmpty {
                self.syncStatus = "No .txt files found in input folder."
                return
            }

            for fileURL in textFiles {
                let fileName = fileURL.lastPathComponent
                let destinationURL = outputURL.appendingPathComponent(fileName)

                print("Processing file: \(fileName)")
                // Simulate processing: You could read/modify file content here
                // For this exercise, we just move it.

                do {
                    try fileManager.moveItem(at: fileURL, to: destinationURL)
                    print("Moved '\(fileName)' to output folder.")
                    processedCount += 1
                } catch {
                    print("Error moving file '\(fileName)': \(error.localizedDescription)")
                    self.syncStatus = "Error moving file '\(fileName)': \(error.localizedDescription)"
                    // Continue to next file even if one fails
                }
            }
            self.syncStatus = "Synchronization complete. \(processedCount) files processed."

        } catch {
            self.syncStatus = "Error during synchronization: \(error.localizedDescription)"
            print("Error during synchronization: \(error.localizedDescription)")
        }
    }

    enum BookmarkError: Error, LocalizedError {
        case accessDenied
        case bookmarkCreationFailed(Error)

        var errorDescription: String? {
            switch self {
            case .accessDenied: return "Access to the selected resource was denied."
            case .bookmarkCreationFailed(let error): return "Failed to create bookmark: \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - UI Implementation (macOS AppKit)

class SyncAgentViewController: NSViewController {

    let synchronizer = DataSynchronizer()
    var cancellables: Set<AnyCancellable> = []

    let inputLabel = NSTextField(labelWithString: "Input Folder: Not Selected")
    let outputLabel = NSTextField(labelWithString: "Output Folder: Not Selected")
    let statusLabel = NSTextField(labelWithString: "Ready.")

    let selectInputButton = NSButton(title: "Select Input Folder", target: nil, action: nil)
    let selectOutputButton = NSButton(title: "Select Output Folder", target: nil, action: nil)
    let synchronizeButton = NSButton(title: "Run Synchronization", target: nil, action: nil)
    let clearFoldersButton = NSButton(title: "Clear Folders", target: nil, action: nil)

    override func loadView() {
        self.view = NSView()
        self.view.wantsLayer = true
        self.view.layer?.backgroundColor = NSColor.windowBackgroundColor.cgColor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupBindings()
    }

    override func viewWillDisappear() {
        super.viewWillDisappear()
        synchronizer.stopAccessingAllResources()
    }

    func setupUI() {
        inputLabel.alignment = .left
        outputLabel.alignment = .left
        statusLabel.alignment = .center
        statusLabel.maximumNumberOfLines = 0

        inputLabel.translatesAutoresizingMaskIntoConstraints = false
        outputLabel.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.translatesAutoresizingMaskIntoConstraints = false

        selectInputButton.target = self
        selectInputButton.action = #selector(selectInputFolderTapped)
        selectInputButton.translatesAutoresizingMaskIntoConstraints = false

        selectOutputButton.target = self
        selectOutputButton.action = #selector(selectOutputFolderTapped)
        selectOutputButton.translatesAutoresizingMaskIntoConstraints = false

        synchronizeButton.target = self
        synchronizeButton.action = #selector(synchronizeTapped)
        synchronizeButton.translatesAutoresizingMaskIntoConstraints = false

        clearFoldersButton.target = self
        clearFoldersButton.action = #selector(clearFoldersTapped)
        clearFoldersButton.translatesAutoresizingMaskIntoConstraints = false

        let folderSelectionStack = NSStackView(views: [
            selectInputButton, inputLabel,
            selectOutputButton, outputLabel
        ])
        folderSelectionStack.orientation = .vertical
        folderSelectionStack.spacing = 8
        folderSelectionStack.alignment = .leading
        folderSelectionStack.translatesAutoresizingMaskIntoConstraints = false

        let actionButtonStack = NSStackView(views: [synchronizeButton, clearFoldersButton])
        actionButtonStack.orientation = .horizontal
        actionButtonStack.spacing = 10
        actionButtonStack.distribution = .fillEqually
        actionButtonStack.translatesAutoresizingMaskIntoConstraints = false

        let mainStack = NSStackView(views: [
            folderSelectionStack,
            NSView.spacer(), // For visual separation
            actionButtonStack,
            statusLabel
        ])
        mainStack.orientation = .vertical
        mainStack.spacing = 20
        mainStack.distribution = .fill
        mainStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mainStack)

        NSLayoutConstraint.activate([
            mainStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            mainStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            mainStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            mainStack.bottomAnchor.constraint(lessThanOrEqualTo: view.bottomAnchor, constant: -20),
            folderSelectionStack.widthAnchor.constraint(equalTo: mainStack.widthAnchor),
            actionButtonStack.widthAnchor.constraint(equalTo: mainStack.widthAnchor)
        ])
    }

    func setupBindings() {
        synchronizer.$inputFolderURL
            .receive(on: DispatchQueue.main)
            .map { $0?.lastPathComponent ?? "Not Selected" }
            .map { "Input Folder: \($0)" }
            .assign(to: \.stringValue, on: inputLabel)
            .store(in: &cancellables)

        synchronizer.$outputFolderURL
            .receive(on: DispatchQueue.main)
            .map { $0?.lastPathComponent ?? "Not Selected" }
            .map { "Output Folder: \($0)" }
            .assign(to: \.stringValue, on: outputLabel)
            .store(in: &cancellables)

        synchronizer.$syncStatus
            .receive(on: DispatchQueue.main)
            .assign(to: \.stringValue, on: statusLabel)
            .store(in: &cancellables)
    }

    @objc func selectInputFolderTapped() {
        presentFolderPicker { [weak self] url in
            guard let url = url else { return }
            Task { await self?.synchronizer.updateInputFolder(url: url) }
        }
    }

    @objc func selectOutputFolderTapped() {
        presentFolderPicker { [weak self] url in
            guard let url = url else { return }
            Task { await self?.synchronizer.updateOutputFolder(url: url) }
        }
    }

    @objc func synchronizeTapped() {
        Task { await synchronizer.synchronize() }
    }

    @objc func clearFoldersTapped() {
        synchronizer.clearBookmarks()
    }

    private func presentFolderPicker(completion: @escaping (URL?) -> Void) {
        let openPanel = NSOpenPanel()
        openPanel.canChooseFiles = false
        openPanel.canChooseDirectories = true
        openPanel.allowsMultipleSelection = false
        openPanel.prompt = "Select Folder"

        openPanel.begin { response in
            guard response == .OK, let url = openPanel.url else {
                completion(nil)
                return
            }
            completion(url)
        }
    }
}

// Helper for NSStackView
extension NSView {
    static func spacer() -> NSView {
        let spacer = NSView()
        spacer.translatesAutoresizingMaskIntoConstraints = false
        spacer.heightAnchor.constraint(equalToConstant: 1).isActive = true
        return spacer
    }
}

// Example AppDelegate for macOS to set up the window and initial view controller
@main
class AppDelegate: NSObject, NSApplicationDelegate {

    var window: NSWindow!
    var syncAgentVC: SyncAgentViewController!

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 500, height: 350),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.center()
        window.setFrameAutosaveName("SyncAgentWindow")
        
        syncAgentVC = SyncAgentViewController()
        window.contentViewController = syncAgentVC
        
        window.makeKeyAndOrderFront(nil)
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        syncAgentVC.synchronizer.stopAccessingAllResources()
    }

    func applicationSupportsSecureRestorableState(_ app: NSApplication) -> Bool {
        return true
    }
}
