
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import MLX // For context on MLX framework

@available(iOS 18.0, macOS 15.0, *)
struct GetStockPriceTool {
    let name: String = "get_stock_price"
    let description: String = "Fetches the current real-time price for one or more stock ticker symbols. Requires `symbols: [String]`."

    private let mockStockPrices: [String: Double] = [
        "AAPL": 175.25,
        "GOOG": 150.10,
        "TSLA": 180.50,
        "MSFT": 420.00,
        "AMZN": 185.70
    ]

    /// Simulates fetching current stock prices.
    /// - Parameter symbols: An array of stock ticker symbols.
    /// - Returns: A dictionary of symbol to price, or an empty dictionary if no symbols are found.
    func getCurrentPrices(forSymbols symbols: [String]) -> [String: Double] {
        var results: [String: Double] = [:]
        for symbol in symbols {
            if let price = mockStockPrices[symbol.uppercased()] {
                results[symbol.uppercased()] = price
            }
        }
        return results
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct GetHistoricalDataTool {
    let name: String = "get_historical_data"
    let description: String = "Retrieves historical closing prices for a stock over a specified number of days. Requires `symbol: String` and optionally `days: Int` (defaulting to 30)."

    private let mockHistoricalData: [String: [String: Double]] = [
        "AAPL": [
            "2024-03-01": 170.00, "2024-03-02": 171.50, "2024-03-03": 172.00,
            "2024-03-04": 173.20, "2024-03-05": 174.10, "2024-03-06": 175.00
        ],
        "MSFT": [
            "2024-03-01": 410.00, "2024-03-02": 412.50, "2024-03-03": 415.00,
            "2024-03-04": 417.20, "2024-03-05": 418.10, "2024-03-06": 420.00
        ]
    ]

    /// Simulates fetching historical closing prices.
    /// - Parameters:
    ///   - symbol: The stock ticker symbol.
    ///   - days: The number of recent days to retrieve data for.
    /// - Returns: A dictionary of date (String) to price (Double), or nil if data is not available.
    func getHistoricalPrices(forSymbol symbol: String, days: Int) -> [String: Double]? {
        guard let data = mockHistoricalData[symbol.uppercased()] else {
            return nil
        }
        // In a real scenario, you'd filter by date. For mock, we'll just sort and take the last 'days' entries.
        let sortedDates = data.keys.sorted().suffix(days)
        var result: [String: Double] = [:]
        for date in sortedDates {
            result[date] = data[date]
        }
        return result
    }
}

@available(iOS 18.0, macOS 15.0, *)
class FinancialToolDispatcher {
    private let getStockPriceTool = GetStockPriceTool()
    private let getHistoricalDataTool = GetHistoricalDataTool()

    // MARK: - Decodable Structures for LLM Output Parsing

    /// Represents the combined arguments for all financial tools.
    /// Optional properties allow for flexible parsing of different tool call arguments.
    struct ToolCallArguments: Decodable {
        let symbols: [String]? // For get_stock_price
        let symbol: String?    // For get_historical_data
        let days: Int?         // Optional for get_historical_data
    }

    /// Represents a generic tool call structure from the LLM.
    struct ToolCall: Decodable {
        let name: String
        let arguments: ToolCallArguments // Flexible arguments for multiple tools
    }

    /// Represents the overall LLM output containing a tool call.
    struct LLMOutput: Decodable {
        let tool_call: ToolCall
    }

    /// Dispatches a financial tool call based on the LLM's simulated output.
    /// - Parameter llmOutputJson: A JSON string representing the LLM's decision to call a tool.
    /// - Returns: A formatted string representing the result of the tool call or an error message.
    func dispatchToolCall(llmOutputJson: String) -> String {
        guard let jsonData = llmOutputJson.data(using: .utf8) else {
            return "Error: Invalid JSON string."
        }

        do {
            let llmOutput = try JSONDecoder().decode(LLMOutput.self, from: jsonData)
            let toolCall = llmOutput.tool_call

            switch toolCall.name {
            case getStockPriceTool.name:
                guard let symbols = toolCall.arguments.symbols, !symbols.isEmpty else {
                    return "Error: Missing or empty 'symbols' argument for get_stock_price tool."
                }
                let prices = getStockPriceTool.getCurrentPrices(forSymbols: symbols)
                if prices.isEmpty {
                    return "Could not find current prices for any of the requested symbols: \(symbols.joined(separator: ", "))."
                } else {
                    let priceStrings = prices.map { "\($0.key): $\($0.value)" }
                    return "Current stock prices: \(priceStrings.joined(separator: ", "))."
                }

            case getHistoricalDataTool.name:
                guard let symbol = toolCall.arguments.symbol, !symbol.isEmpty else {
                    return "Error: Missing 'symbol' argument for get_historical_data tool."
                }
                let days = toolCall.arguments.days ?? 30 // Default to 30 days
                if let history = getHistoricalDataTool.getHistoricalPrices(forSymbol: symbol, days: days) {
                    if history.isEmpty {
                        return "No historical data found for \(symbol) for the last \(days) days."
                    }
                    let historyStrings = history.sorted { $0.key < $1.key }.map { "\($0.key): $\($0.value)" }
                    return "Historical data for \(symbol) (last \(history.count) days): \(historyStrings.joined(separator: ", "))."
                } else {
                    return "Could not retrieve historical data for \(symbol)."
                }

            default:
                return "Error: Unknown financial tool '\(toolCall.name)'."
            }
        } catch {
            return "Error parsing LLM output for financial tool: \(error.localizedDescription)"
        }
    }
}

// Example Usage:
/*
@available(iOS 18.0, macOS 15.0, *)
func runFinancialAssistantExercise() {
    let dispatcher = FinancialToolDispatcher()

    // 1. Get single stock price
    let llmOutput1 = """
    {
      "tool_call": {
        "name": "get_stock_price",
        "arguments": {
          "symbols": ["AAPL"]
        }
      }
    }
    """
    print("User query: What's Apple's stock price?")
    print("LLM output (simulated): \(llmOutput1)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput1))\n")

    // 2. Get multiple stock prices
    let llmOutput2 = """
    {
      "tool_call": {
        "name": "get_stock_price",
        "arguments": {
          "symbols": ["GOOG", "TSLA", "UNKNOWN"]
        }
      }
    }
    """
    print("User query: What are the prices of Google, Tesla, and some unknown stock?")
    print("LLM output (simulated): \(llmOutput2)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput2))\n")

    // 3. Get historical data with default days
    let llmOutput3 = """
    {
      "tool_call": {
        "name": "get_historical_data",
        "arguments": {
          "symbol": "MSFT"
        }
      }
    }
    """
    print("User query: Show me Microsoft's historical data.")
    print("LLM output (simulated): \(llmOutput3)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput3))\n")

    // 4. Get historical data with specific days
    let llmOutput4 = """
    {
      "tool_call": {
        "name": "get_historical_data",
        "arguments": {
          "symbol": "AAPL",
          "days": 3
        }
      }
    }
    """
    print("User query: Apple's stock history for the last 3 days?")
    print("LLM output (simulated): \(llmOutput4)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput4))\n")

    // 5. Get historical data for an unknown symbol
    let llmOutput5 = """
    {
      "tool_call": {
        "name": "get_historical_data",
        "arguments": {
          "symbol": "FB",
          "days": 7
        }
      }
    }
    """
    print("User query: Facebook's stock history for the last 7 days?")
    print("LLM output (simulated): \(llmOutput5)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput5))\n")
}

// runFinancialAssistantExercise()
*/
