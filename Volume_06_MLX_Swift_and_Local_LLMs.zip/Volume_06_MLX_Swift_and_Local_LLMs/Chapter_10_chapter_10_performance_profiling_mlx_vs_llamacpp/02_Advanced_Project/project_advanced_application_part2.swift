
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import MLX
import MLXNN
import Algorithms // Used for potential utility, not strictly required for this core logic

// MARK: - 1. Define Custom Errors

/// Custom errors for the Smart Chat Assistant operations.
enum ChatAssistantError: Error, LocalizedError {
    case modelLoadingFailed(String)
    case trainingFailed(String)
    case inferenceFailed(String)
    case invalidInput(String)

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let msg): return "Model loading failed: \(msg)"
        case .trainingFailed(let msg): return "Training process failed: \(msg)"
        case .inferenceFailed(let msg): return "Inference failed: \(msg)"
        case .invalidInput(let msg): return "Invalid input: \(msg)"
        }
    }
}

// MARK: - 2. Implement LoRA Layer

/// A LoRA-adapted linear layer, inheriting from `MLXNN.Module`.
/// This layer replaces a standard linear transformation by adding a low-rank update.
/// The original `linear` weights are frozen, and only `loraA` and `loraB` are trainable.
final class LoRALinear: MLXNN.Module {
    /// The original linear layer, whose weights are typically pre-trained and frozen.
    let linear: MLXNN.Linear
    /// The first low-rank projection matrix.
    let loraA: MLXNN.Linear
    /// The second low-rank projection matrix.
    let loraB: MLXNN.Linear
    /// A scaling factor applied to the LoRA output.
    let scaling: Float

    /// Initializes a LoRA-adapted linear layer.
    /// - Parameters:
    ///   - inputFeatures: The number of input features.
    ///   - outputFeatures: The number of output features.
    ///   - rank: The rank of the low-rank approximation (e.g., 4, 8, 16).
    ///   - scaling: A scaling factor for the LoRA output, typically 1.0 or `alpha/rank`.
    init(_ inputFeatures: Int, _ outputFeatures: Int, rank: Int, scaling: Float = 1.0) {
        self.linear = MLXNN.Linear(inputFeatures, outputFeatures, bias: true)
        self.loraA = MLXNN.Linear(inputFeatures, rank, bias: false)
        self.loraB = MLXNN.Linear(rank, outputFeatures, bias: false)
        self.scaling = scaling
        super.init()
        // Mark the original linear layer's parameters as non-trainable for LoRA.
        // In MLX, parameters are trainable by default. To "freeze," we simply
        // don't include them in the optimizer's parameter set.
        // For clarity, we can conceptually consider them 'frozen'.
    }

    /// Performs the forward pass for the LoRA linear layer.
    /// The output is `original_output + loraB(loraA(x)) * scaling`.
    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // Compute the output from the original linear layer.
        let originalOutput = linear(x)
        // Compute the low-rank update.
        let loraOutput = loraB(loraA(x)) * scaling
        // Combine the original output with the LoRA update.
        return originalOutput + loraOutput
    }
}

// MARK: - 3. Build LoRA-Adapted Embedding Model

/// A simple embedding model adapted with LoRA for fine-tuning.
/// This model takes token IDs, converts them to embeddings, and then projects them
/// to a final dimension using a LoRA-adapted linear layer.
final class LoRAAdaptedEmbeddingModel: MLXNN.Module {
    /// The base embedding layer, typically pre-trained.
    let embeddingLayer: MLXNN.Embedding
    /// The LoRA-adapted projection layer. This is where fine-tuning happens.
    let projectionLayer: LoRALinear

    /// Initializes the LoRA-adapted embedding model.
    /// - Parameters:
    ///   - vocabSize: The size of the vocabulary.
    ///   - embeddingDim: The dimensionality of the word embeddings.
    ///   - projectionDim: The final dimensionality of the projected embeddings.
    ///   - loraRank: The rank for the LoRA layers within the projection.
    init(vocabSize: Int, embeddingDim: Int, projectionDim: Int, loraRank: Int) {
        self.embeddingLayer = MLXNN.Embedding(vocabSize, embeddingDim)
        self.projectionLayer = LoRALinear(embeddingDim, projectionDim, rank: loraRank)
        super.init()
    }

    /// Performs the forward pass for the entire model.
    /// - Parameter x: An `MLXArray` of shape `(batch_size, sequence_length)` containing token IDs.
    /// - Returns: An `MLXArray` of shape `(batch_size, sequence_length, projection_dim)` representing the embeddings.
    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // 1. Convert token IDs to dense embeddings.
        let embedded = embeddingLayer(x) // Shape: (batch_size, sequence_length, embedding_dim)

        // 2. Reshape for the projection layer.
        // The linear layer expects `(..., input_features)`. We need to flatten the batch
        // and sequence dimensions together for the projection.
        let batchSize = x.dim(0)
        let sequenceLength = x.dim(1)
        let reshapedForProjection = embedded.reshaped([batchSize * sequenceLength, embedded.dim(-1)])

        // 3. Apply the LoRA-adapted projection.
        let projected = projectionLayer(reshapedForProjection) // Shape: (batch_size * sequence_length, projection_dim)

        // 4. Reshape back to the original (batch, sequence) structure.
        return projected.reshaped([batchSize, sequenceLength, projected.dim(-1)])
    }
}

// MARK: - 4. Create `SmartChatAssistantViewModel`

/// ViewModel for the Smart Chat Assistant, managing model loading, fine-tuning, and inference.
@available(iOS 18.0, macOS 15.0, *)
@MainActor // Ensure all UI-related updates happen on the main actor.
final class SmartChatAssistantViewModel: ObservableObject {
    @Published var statusMessage: String = "Initializing..."
    @Published var isTraining: Bool = false
    @Published var currentLoss: Float = 0.0
    @Published var lastInferenceEmbedding: [Float]?

    private var model: LoRAAdaptedEmbeddingModel?
    // Model configuration parameters (example values)
    private let vocabSize: Int = 1000
    private let embeddingDim: Int = 128
    private let projectionDim: Int = 64
    private let loraRank: Int = 8
    private let learningRate: Float = 1e-3

    init() {
        // Asynchronously load the model upon initialization.
        Task {
            await loadModel()
        }
    }

    // MARK: - 5. Model Loading and Initialization

    /// Loads or initializes the base model and its LoRA adapter.
    /// In a production app, this would involve loading pre-trained weights from disk.
    func loadModel() async {
        statusMessage = "Loading model..."
        do {
            // For demonstration, we just initialize a new model.
            // In a real application, `MLX.load` would be used to load pre-trained weights.
            model = LoRAAdaptedEmbeddingModel(
                vocabSize: vocabSize,
                embeddingDim: embeddingDim,
                projectionDim: projectionDim,
                loraRank: loraRank
            )
            // Accessing parameters ensures they are initialized and on the default device.
            // MLX automatically manages device placement (CPU/GPU) based on availability.
            _ = model!.parameters()
            statusMessage = "Model loaded. Ready for training or inference."
        } catch {
            statusMessage = "Failed to load model: \(error.localizedDescription)"
        }
    }

    // MARK: - 6. Fine-Tuning Step

    /// Performs a single training step using LoRA fine-tuning.
    /// This demonstrates MLX's `valueAndGradient` for efficient differentiation.
    /// - Parameters:
    ///   - inputTokens: A batch of tokenized input sequences (`MLXArray` of shape `(batch_size, sequence_length)`).
    ///   - targetEmbeddings: The target embeddings for the input sequences (`MLXArray` of shape `(batch_size, sequence_length, projection_dim)`).
    func fineTuneStep(inputTokens: MLXArray, targetEmbeddings: MLXArray) async throws {
        guard let model = self.model else {
            throw ChatAssistantError.modelLoadingFailed("Model not initialized.")
        }

        isTraining = true
        statusMessage = "Training..."

        do {
            // Define the loss function closure.
            // This function takes the model and data, and returns the loss.
            let lossFn = { (model: LoRAAdaptedEmbeddingModel, inputs: MLXArray, targets: MLXArray) -> MLXArray in
                let predictions = model(inputs)
                // Mean Squared Error (MSE) loss: (predictions - targets)^2 / N
                return MLX.mean(MLX.square(predictions - targets))
            }

            // --- MLX Functional Transformation: `valueAndGradient` ---
            // This is a core MLX pattern. It computes the value of the function
            // and its gradients with respect to the *trainable parameters* of the model.

            // We only want to update LoRA parameters. So, we filter the model's parameters
            // to get only those belonging to the `loraA` and `loraB` layers.
            let loraParams = model.parameters().filter { name, _ in name.contains("lora") }

            // `valueAndGradient` returns a tuple: (function_value, gradients_dictionary).
            // Both `loss` and `grad` are initially lazy `MLXArray`s representing computation graphs.
            let (loss, grad) = valueAndGradient(lossFn, model, inputTokens, targetEmbeddings)
            
            // --- MLX Lazy Evaluation ---
            // At this point, `loss` and `grad` are not yet computed. They are symbolic
            // representations of the computation graph. The actual numerical computation
            // will occur when `.eval()` is called on them or on any `MLXArray` that depends on them.

            // Update LoRA parameters using a simple Stochastic Gradient Descent (SGD) optimizer.
            let updatedParams = loraParams.mapValues { param in
                // Retrieve the gradient for the current parameter.
                // MLX ensures `grad` contains gradients for all parameters passed to `valueAndGradient`.
                let gradient = grad[param.key]!
                // Apply the update rule: param = param - learning_rate * gradient
                return param.value - learningRate * gradient
            }

            // Assign the updated parameters back to the model.
            // This implicitly triggers the computation of `grad` and `loss` because
            // `updatedParams` depend on `grad`, and `MLX.eval` is called internally
            // when assigning updated parameters to ensure they are concrete values.
            model.update(parameters: updatedParams)

            // Explicitly evaluate the loss to get its concrete scalar value for reporting.
            // This `eval()` call will trigger the actual computation of the `loss` graph.
            let computedLoss = loss.eval().item(Float.self)
            currentLoss = computedLoss
            statusMessage = "Training step complete. Loss: \(String(format: "%.4f", computedLoss))"

        } catch {
            isTraining = false
            statusMessage = "Training failed: \(error.localizedDescription)"
            throw ChatAssistantError.trainingFailed(error.localizedDescription)
        }
        isTraining = false
    }

    // MARK: - 7. Inference Step

    /// Performs inference to get an embedding for a given input sequence.
    /// - Parameter inputTokens: A tokenized input sequence (`MLXArray` of shape `(batch_size, sequence_length)`).
    /// - Returns: An array of floats representing the generated embedding.
    func inferEmbedding(inputTokens: MLXArray) async throws -> [Float] {
        guard let model = self.model else {
            throw ChatAssistantError.modelLoadingFailed("Model not initialized.")
        }
        guard inputTokens.ndim == 2 else { // Expects (batch_size, sequence_length)
            throw ChatAssistantError.invalidInput("Input tokens must be 2D (batch_size, sequence_length).")
        }

        statusMessage = "Performing inference..."
        do {
            // Perform the forward pass. `outputEmbedding` is a lazy `MLXArray`.
            let outputEmbedding = model(inputTokens)

            // --- Unified Memory & Zero-Copy ---
            // When `outputEmbedding.eval().asArray(Float.self)` is called,
            // MLX performs the computation on the GPU (if available).
            // Since `MLXArray` uses Unified Memory on Apple Silicon, the resulting
            // tensor data is directly accessible by the CPU without explicit copying,
            // enabling "zero-copy" data transfer and maximizing efficiency.

            // Evaluate the computation graph and convert to a Swift Array.
            // The result will be `[[[Float]]]`, representing (batch, sequence, projection_dim).
            let computedEmbedding = outputEmbedding.eval().asArray(Float.self)

            // For simplicity, average across the sequence length to get a single embedding per item in batch.
            // If batch_size is 1, this flattens the sequence dimension.
            let flattenedEmbedding = computedEmbedding.flatMap { $0.flatMap { $0 } }
            lastInferenceEmbedding = flattenedEmbedding
            statusMessage = "Inference complete. Embedding generated."
            return flattenedEmbedding
        } catch {
            statusMessage = "Inference failed: \(error.localizedDescription)"
            throw ChatAssistantError.inferenceFailed(error.localizedDescription)
        }
    }

    // MARK: - Utility for demonstration

    /// Generates dummy training data for demonstration purposes.
    /// In a real scenario, this data would come from a specialized data loader.
    /// - Parameters:
    ///   - batchSize: The number of sequences in a batch.
    ///   - sequenceLength: The length of each sequence.
    /// - Returns: A tuple containing dummy input tokens and target embeddings.
    func generateDummyTrainingData(batchSize: Int, sequenceLength: Int) -> (inputs: MLXArray, targets: MLXArray) {
        // Dummy inputs: batch of token IDs (e.g., 0-999)
        let inputs = MLXArray.randomUniform(low: 0, high: Float(vocabSize), shape: [batchSize, sequenceLength], .int32)

        // Dummy targets: target embeddings. These would be actual high-quality
        // embeddings for the domain-specific text in a real scenario.
        let targets = MLXArray.randomUniform(low: -1.0, high: 1.0, shape: [batchSize, sequenceLength, projectionDim])
        return (inputs, targets)
    }
}

// MARK: - Example Usage (within an app context)

/*
// This would typically be part of a SwiftUI View or similar app entry point.
@available(iOS 18.0, macOS 15.0, *)
struct ChatAssistantView: View {
    @StateObject private var viewModel = SmartChatAssistantViewModel()
    @State private var inputText: String = "What is myocardial infarction?"

    var body: some View {
        VStack {
            Text(viewModel.statusMessage)
                .font(.headline)
                .padding()

            if viewModel.isTraining {
                ProgressView("Training...")
                Text("Current Loss: \(viewModel.currentLoss, specifier: "%.4f")")
            }

            TextField("Enter text for embedding", text: $inputText)
                .textFieldStyle(.roundedBorder)
                .padding()

            HStack {
                Button("Start Fine-Tuning (1 Step)") {
                    Task {
                        let (inputs, targets) = viewModel.generateDummyTrainingData(batchSize: 2, sequenceLength: 10)
                        try? await viewModel.fineTuneStep(inputTokens: inputs, targetEmbeddings: targets)
                    }
                }
                .disabled(viewModel.isTraining)

                Button("Get Embedding") {
                    Task {
                        // Dummy tokenization: convert string to MLXArray of token IDs
                        let dummyTokens = MLXArray.randomUniform(low: 0, high: Float(viewModel.vocabSize), shape: [1, inputText.count], .int32)
                        try? await viewModel.inferEmbedding(inputTokens: dummyTokens)
                    }
                }
            }
            .padding()

            if let embedding = viewModel.lastInferenceEmbedding {
                Text("Last Embedding (first 5 values):")
                Text(embedding.prefix(5).map { String(format: "%.2f", $0) }.joined(separator: ", "))
            }
        }
    }
}
*/
