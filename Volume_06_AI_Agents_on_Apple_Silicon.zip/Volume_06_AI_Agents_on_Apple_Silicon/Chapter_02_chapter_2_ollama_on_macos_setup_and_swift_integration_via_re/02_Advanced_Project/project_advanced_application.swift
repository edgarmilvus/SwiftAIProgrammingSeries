
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation

// MARK: - 1. Ollama API Data Models

/// Represents a single message in the chat context (though not directly used in the /generate endpoint,
/// it's a common pattern for chat APIs like /api/chat).
struct OllamaMessage: Codable {
    let role: String // e.g., "user", "assistant"
    let content: String
}

/// A type-erased `Codable` wrapper for dictionary values.
/// This allows `options` in `OllamaGenerateRequest` to be `[String: AnyCodable]`,
/// accommodating various data types for model parameters.
struct AnyCodable: Codable {
    let value: Any

    init<T: Codable>(_ value: T) {
        self.value = value
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let string = try? container.decode(String.self) {
            value = string
        } else if let int = try? container.decode(Int.self) {
            value = int
        } else if let double = try? container.decode(Double.self) {
            value = double
        } else if let bool = try? container.decode(Bool.self) {
            value = bool
        } else if let array = try? container.decode([AnyCodable].self) {
            value = array.map { $0.value }
        } else if let dictionary = try? container.decode([String: AnyCodable].self) {
            value = dictionary.mapValues { $0.value }
        } else if container.decodeNil() {
            value = NSNull()
        } else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "AnyCodable value cannot be decoded")
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        if let string = value as? String {
            try container.encode(string)
        } else if let int = value as? Int {
            try container.encode(int)
        } else if let double = value as? Double {
            try container.encode(double)
        } else if let bool = value as? Bool {
            try container.encode(bool)
        } else if let array = value as? [Any] {
            try container.encode(array.map(AnyCodable.init))
        } else if let dictionary = value as? [String: Any] {
            try container.encode(dictionary.mapValues(AnyCodable.init))
        } else if value is NSNull {
            try container.encodeNil()
        } else {
            throw EncodingError.invalidValue(value, EncodingError.Context(codingPath: encoder.codingPath, debugDescription: "AnyCodable value cannot be encoded"))
        }
    }
}

/// Represents the request body for the Ollama `/api/generate` endpoint.
struct OllamaGenerateRequest: Codable {
    let model: String
    let prompt: String
    let stream: Bool // Crucial for enabling streaming responses
    let options: [String: AnyCodable]? // Optional, for advanced model parameters (e.g., temperature, top_k)
    let system: String? // Optional system message for context or instructions
    let template: String? // Optional custom prompt template
    let context: [Int]? // Optional model's current context window (for chat history continuity)

    // Custom encoding to handle AnyCodable due to its type-erased nature
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(model, forKey: .model)
        try container.encode(prompt, forKey: .prompt)
        try container.encode(stream, forKey: .stream)
        try container.encodeIfPresent(system, forKey: .system)
        try container.encodeIfPresent(template, forKey: .template)
        try container.encodeIfPresent(context, forKey: .context)
        if let options = options {
            // Encode the dictionary by mapping AnyCodable to its underlying value
            var optionsContainer = container.nestedContainer(keyedBy: DynamicCodingKey.self, forKey: .options)
            for (key, anyCodableValue) in options {
                let dynamicKey = DynamicCodingKey(stringValue: key)!
                try anyCodableValue.encode(to: optionsContainer.superEncoder(forKey: dynamicKey))
            }
        }
    }

    private enum CodingKeys: String, CodingKey {
        case model, prompt, stream, options, system, template, context
    }
    
    // Helper for encoding dynamic keys in options
    private struct DynamicCodingKey: CodingKey {
        var stringValue: String
        init?(stringValue: String) { self.stringValue = stringValue }
        var intValue: Int?
        init?(intValue: Int) { return nil }
    }
}

/// Represents a single chunk of a streaming response from Ollama.
/// Each chunk contains a piece of the generated text and metadata.
struct OllamaResponseChunk: Codable {
    let model: String
    let createdAt: String
    let response: String? // The actual text chunk
    let done: Bool // True when the generation is complete
    let totalDuration: Int? // Total duration of the generation (only in final chunk)
    let loadDuration: Int?
    let promptEvalCount: Int?
    let promptEvalDuration: Int?
    let evalCount: Int?
    let evalDuration: Int?

    enum CodingKeys: String, CodingKey {
        case model
        case createdAt = "created_at"
        case response
        case done
        case totalDuration = "total_duration"
        case loadDuration = "load_duration"
        case promptEvalCount = "prompt_eval_count"
        case promptEvalDuration = "prompt_eval_duration"
        case evalCount = "eval_count"
        case evalDuration = "eval_duration"
    }
}

/// Represents a complete (non-streaming) response from Ollama.
/// Used when `stream: false` in the request.
struct OllamaFullResponse: Codable {
    let model: String
    let createdAt: String
    let response: String
    let done: Bool
    let totalDuration: Int
    let loadDuration: Int
    let promptEvalCount: Int
    let promptEvalDuration: Int
    let evalCount: Int
    let evalDuration: Int

    enum CodingKeys: String, CodingKey {
        case model
        case createdAt = "created_at"
        case response
        case done
        case totalDuration = "total_duration"
        case loadDuration = "load_duration"
        case promptEvalCount = "prompt_eval_count"
        case promptEvalDuration = "prompt_eval_duration"
        case evalCount = "eval_count"
        case evalDuration = "eval_duration"
    }
}

/// Represents an error response from the Ollama server.
struct OllamaErrorResponse: Codable, Error {
    let error: String
}


// MARK: - 2. OllamaClient for REST Interaction

/// Custom error types for the OllamaClient, providing clear, localized error messages.
enum OllamaClientError: Error, LocalizedError {
    case invalidURL
    case networkError(Error)
    case serverError(statusCode: Int, message: String?)
    case decodingError(Error)
    case encodingError(Error)
    case unknownError(Error? = nil)

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "The Ollama API URL is invalid. Please check the base URL."
        case .networkError(let error):
            return "Network request failed: \(error.localizedDescription). Ensure Ollama server is running and reachable."
        case .serverError(let statusCode, let message):
            return "Ollama server returned an error (\(statusCode)): \(message ?? "No specific message")."
        case .decodingError(let error):
            return "Failed to decode Ollama response: \(error.localizedDescription). Response format might be unexpected."
        case .encodingError(let error):
            return "Failed to encode Ollama request: \(error.localizedDescription). Request body might be malformed."
        case .unknownError(let error):
            return "An unknown error occurred: \(error?.localizedDescription ?? "No details")."
        }
    }
}

/// A client for interacting with the local Ollama instance via its REST API.
/// This client supports both standard (non-streaming) and streaming responses using Swift's modern concurrency features.
@available(macOS 12.0, *) // Requires async/await, available on macOS 12+, iOS 15+, watchOS 8+, tvOS 15+
class OllamaClient {
    private let baseURL: URL
    private let session: URLSession

    /// Initializes the OllamaClient.
    /// - Parameters:
    ///   - baseURL: The base URL of your local Ollama instance (e.g., `http://localhost:11434`).
    ///   - session: The `URLSession` to use for network requests. Defaults to `URLSession.shared`.
    init(baseURL: URL, session: URLSession = .shared) {
        self.baseURL = baseURL
        self.session = session
    }

    /// Sends a prompt to Ollama and receives a complete, non-streaming response.
    /// This is suitable for scenarios where the full response is needed at once, or for shorter prompts.
    /// - Parameters:
    ///   - prompt: The text prompt to send to the LLM.
    ///   - model: The name of the Ollama model to use (e.g., "llama2", "mistral").
    ///   - systemMessage: An optional system message to provide context or instructions.
    ///   - template: An optional custom prompt template.
    ///   - options: Optional advanced model parameters as a dictionary (e.g., `temperature: 0.8`).
    ///   - context: Optional context window from a previous response for chat continuity.
    /// - Returns: An `OllamaFullResponse` containing the LLM's complete response.
    /// - Throws: `OllamaClientError` if the request fails or response cannot be decoded.
    func generate(
        prompt: String,
        model: String,
        systemMessage: String? = nil,
        template: String? = nil,
        options: [String: AnyCodable]? = nil,
        context: [Int]? = nil
    ) async throws -> OllamaFullResponse {
        guard let url = URL(string: "/api/generate", relativeTo: baseURL) else {
            throw OllamaClientError.invalidURL
        }

        let requestBody = OllamaGenerateRequest(
            model: model,
            prompt: prompt,
            stream: false, // Set to false for non-streaming
            options: options,
            system: systemMessage,
            template: template,
            context: context
        )

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            let encoder = JSONEncoder()
            // encoder.outputFormatting = .prettyPrinted // For debugging, remove in production for smaller payload
            request.httpBody = try encoder.encode(requestBody)
        } catch {
            throw OllamaClientError.encodingError(error)
        }

        do {
            let (data, response) = try await session.data(for: request)

            guard let httpResponse = response as? HTTPURLResponse else {
                throw OllamaClientError.unknownError()
            }

            guard (200...299).contains(httpResponse.statusCode) else {
                // Attempt to decode Ollama's specific error response for better diagnostics
                if let ollamaError = try? JSONDecoder().decode(OllamaErrorResponse.self, from: data) {
                    throw OllamaClientError.serverError(statusCode: httpResponse.statusCode, message: ollamaError.error)
                } else {
                    let message = String(data: data, encoding: .utf8) ?? "Failed to decode error message."
                    throw OllamaClientError.serverError(statusCode: httpResponse.statusCode, message: message)
                }
            }

            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601 // Assuming ISO 8601 format for dates from Ollama
            return try decoder.decode(OllamaFullResponse.self, from: data)
        } catch let urlError as URLError {
            throw OllamaClientError.networkError(urlError)
        } catch let decodingError as DecodingError {
            throw OllamaClientError.decodingError(decodingError)
        } catch {
            throw OllamaClientError.unknownError(error)
        }
    }

    // MARK: - 3. Streaming Response Parsing

    /// Sends a prompt to Ollama and receives a streaming response, yielding chunks as they arrive.
    /// This method leverages `AsyncThrowingStream` to provide a modern Swift concurrency interface for streaming data,
    /// ideal for real-time text generation.
    /// - Parameters:
    ///   - prompt: The text prompt to send to the LLM.
    ///   - model: The name of the Ollama model to use (e.g., "llama2", "mistral").
    ///   - systemMessage: An optional system message to provide context or instructions.
    ///   - template: An optional custom prompt template.
    ///   - options: Optional advanced model parameters as a dictionary.
    ///   - context: Optional context window from a previous response for chat continuity.
    /// - Returns: An `AsyncThrowingStream` of `OllamaResponseChunk` objects, allowing consumers to iterate over incoming data.
    /// - Throws: `OllamaClientError` if the initial request setup fails or a network error occurs.
    func generateStream(
        prompt: String,
        model: String,
        systemMessage: String? = nil,
        template: String? = nil,
        options: [String: AnyCodable]? = nil,
        context: [Int]? = nil
    ) -> AsyncThrowingStream<OllamaResponseChunk, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                guard let url = URL(string: "/api/generate", relativeTo: baseURL) else {
                    continuation.finish(throwing: OllamaClientError.invalidURL)
                    return
                }

                let requestBody = OllamaGenerateRequest(
                    model: model,
                    prompt: prompt,
                    stream: true, // Crucially set to true for streaming
                    options: options,
                    system: systemMessage,
                    template: template,
                    context: context
                )

                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.addValue("application/json", forHTTPHeaderField: "Content-Type")

                do {
                    let encoder = JSONEncoder()
                    request.httpBody = try encoder.encode(requestBody)
                } catch {
                    continuation.finish(throwing: OllamaClientError.encodingError(error))
                    return
                }

                do {
                    // Use `session.bytes(for: request)` for an AsyncSequence of Data chunks
                    let (bytes, response) = try await session.bytes(for: request)

                    guard let httpResponse = response as? HTTPURLResponse else {
                        throw OllamaClientError.unknownError()
                    }

                    // Check for initial server errors before streaming begins.
                    // Note: For streaming, errors might sometimes come as a single non-chunked response
                    // or malformed chunks. This check handles initial HTTP status codes.
                    guard (200...299).contains(httpResponse.statusCode) else {
                        let message = "Server error (\(httpResponse.statusCode)) before streaming started."
                        throw OllamaClientError.serverError(statusCode: httpResponse.statusCode, message: message)
                    }

                    var buffer = Data() // Buffer to accumulate incomplete JSON lines
                    let newlineData = "\n".data(using: .utf8)! // Separator for JSON chunks
                    let decoder = JSONDecoder()
                    decoder.dateDecodingStrategy = .iso8601

                    // Iterate over the incoming byte stream
                    for try await chunk in bytes {
                        buffer.append(chunk)

                        // Process buffer line by line. Ollama sends newline-delimited JSON.
                        while let range = buffer.range(of: newlineData) {
                            let lineData = buffer.subdata(in: buffer.startIndex..<range.lowerBound)
                            // Remove the processed line and the newline character from the buffer
                            buffer.removeSubrange(buffer.startIndex...range.upperBound)

                            if lineData.isEmpty { continue } // Skip empty lines that might occur between chunks

                            do {
                                let ollamaChunk = try decoder.decode(OllamaResponseChunk.self, from: lineData)
                                continuation.yield(ollamaChunk) // Emit the decoded chunk
                                if ollamaChunk.done {
                                    continuation.finish() // Stream is complete when 'done' is true
                                    return
                                }
                            } catch {
                                // Log decoding error but try to continue if possible, or finish with error.
                                // For robustness, we log and skip malformed chunks to keep the stream alive
                                // if subsequent chunks might be valid. In a strict app, you might `finish(throwing:)` here.
                                print("Warning: Failed to decode Ollama response chunk: \(error.localizedDescription) - Data: \(String(data: lineData, encoding: .utf8) ?? "N/A")")
                            }
                        }
                    }

                    // After the byte stream ends, check for any remaining data in the buffer
                    // which might be a final, non-newline-terminated chunk.
                    if !buffer.isEmpty {
                        do {
                            let ollamaChunk = try decoder.decode(OllamaResponseChunk.self, from: buffer)
                            continuation.yield(ollamaChunk)
                        } catch {
                            print("Warning: Failed to decode final Ollama response chunk from remaining buffer: \(error.localizedDescription) - Data: \(String(data: buffer, encoding: .utf8) ?? "N/A")")
                        }
                    }
                    continuation.finish() // Ensure stream is finished if the loop completes naturally
                } catch let urlError as URLError {
                    continuation.finish(throwing: OllamaClientError.networkError(urlError))
                } catch let decodingError as DecodingError {
                    continuation.finish(throwing: OllamaClientError.decodingError(decodingError))
                } catch {
                    continuation.finish(throwing: OllamaClientError.unknownError(error))
                }
            }
        }
    }
}

// MARK: - 4. ContractAnalyzerService - Real-world Apple App Context

/// A service responsible for analyzing contract text using Ollama.
/// This service acts as an application-specific layer, orchestrating the interaction with the `OllamaClient`
/// and processing the LLM's output into a more consumable format for the UI.
@available(macOS 12.0, *)
class ContractAnalyzerService {
    private let ollamaClient: OllamaClient
    private let model: String // The LLM model to use for analysis (e.g., "llama2", "mistral")

    /// Initializes the ContractAnalyzerService.
    /// - Parameters:
    ///   - ollamaClient: An initialized `OllamaClient` instance.
    ///   - model: The specific Ollama model name (e.g., "llama2", "mistral") to use for contract analysis.
    init(ollamaClient: OllamaClient, model: String) {
        self.ollamaClient = ollamaClient
        self.model = model
    }

    /// Analyzes a given contract text by sending it to Ollama and streaming the response.
    /// It constructs a specific prompt to instruct the LLM on what to extract or summarize.
    /// - Parameters:
    ///   - contractText: The full text content of the contract to analyze.
    ///   - analysisTask: A clear description of what to analyze (e.g., "Identify the Force Majeure clause and summarize its key conditions.").
    ///   - progressHandler: An optional closure to call with each new chunk of the LLM's response.
    ///                      This is useful for updating a UI in real-time.
    /// - Returns: An `AsyncThrowingStream` of `String` representing the LLM's streamed output,
    ///            providing only the meaningful response text.
    func analyzeContractStream(
        contractText: String,
        analysisTask: String,
        progressHandler: ((String) -> Void)? = nil
    ) -> AsyncThrowingStream<String, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                // Construct a clear and specific prompt for the LLM
                let prompt = """
                Analyze the following contract text and \(analysisTask):

                --- CONTRACT START ---
                \(contractText)
                --- CONTRACT END ---
                """

                do {
                    // Get the raw streaming chunks from the Ollama client
                    let stream = ollamaClient.generateStream(prompt: prompt, model: model)
                    for try await chunk in stream {
                        if let responseText = chunk.response, !responseText.isEmpty {
                            continuation.yield(responseText) // Yield only the response text
                            progressHandler?(responseText) // Call the progress handler for UI updates
                        }
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error) // Propagate any errors from the client
                }
            }
        }
    }

    /// Analyzes a given contract text by sending it to Ollama and awaiting a complete response.
    /// This is a simpler, non-streaming alternative for tasks where immediate full output is acceptable.
    /// - Parameters:
    ///   - contractText: The full text content of the contract to analyze.
    ///   - analysisTask: A description of what to analyze.
    /// - Returns: A `String` containing the LLM's complete analysis.
    /// - Throws: `OllamaClientError` if the analysis fails.
    func analyzeContract(
        contractText: String,
        analysisTask: String
    ) async throws -> String {
        let prompt = """
        Analyze the following contract text and \(analysisTask):

        --- CONTRACT START ---
        \(contractText)
        --- CONTRACT END ---
        """

        let response = try await ollamaClient.generate(prompt: prompt, model: model)
        return response.response
    }
}

// MARK: - 5. Demonstration of Usage in a macOS App

/// A simple struct to represent a document in our hypothetical app.
struct Document {
    let id = UUID()
    let title: String
    let content: String
}

/// The main entry point for our command-line demonstration of the Contract Analyzer App.
/// In a real macOS app, this logic would be integrated into a SwiftUI View Model or an AppKit Controller.
@available(macOS 12.0, *)
@main // Entry point for a command-line tool or a simple app
struct ContractAnalyzerApp {
    static func main() async {
        print("🚀 Starting Smart Contract Clause Analyzer Demo...")

        // --- Configuration ---
        // IMPORTANT: Ensure Ollama is running on localhost:11434 and you have a model downloaded
        // (e.g., run `ollama run llama2` in your terminal).
        guard let ollamaBaseURL = URL(string: "http://localhost:11434") else {
            print("❌ Error: Invalid Ollama base URL. Please verify 'http://localhost:11434'.")
            return
        }
        let ollamaClient = OllamaClient(baseURL: ollamaBaseURL)
        let analysisModel = "llama2" // Specify the LLM model name. Change if you use "mistral", "codellama", etc.

        let analyzerService = ContractAnalyzerService(ollamaClient: ollamaClient, model: analysisModel)

        // --- Sample Contract Data ---
        let sampleContract = Document(
            title: "Software Development Agreement",
            content: """
            This Software Development Agreement ("Agreement") is made effective as of January 1, 2024,
            by and between Tech Solutions Inc. ("Company") and Innovate Dev LLC ("Developer").

            1. Scope of Work: Developer agrees to develop custom software as detailed in Schedule A.

            2. Payment: Company shall pay Developer a total fee of $50,000, payable in milestones.

            3. Intellectual Property: All intellectual property rights in the software developed
               under this Agreement shall exclusively belong to the Company.

            4. Confidentiality: Both parties agree to keep all proprietary information confidential.

            5. Force Majeure: Neither party shall be liable for any failure or delay in performance
               under this Agreement due to causes beyond its reasonable control, including, but not
               limited to, acts of God, war, terrorism, riots, embargoes, acts of civil or military
               authorities, fire, floods, accidents, strikes, or shortages of transportation, facilities,
               fuel, energy, labor, or materials. The party affected by such an event shall promptly
               notify the other party and use reasonable efforts to mitigate the effects of the event.

            6. Termination: This Agreement may be terminated by either party with 30 days written notice.

            7. Governing Law: This Agreement shall be governed by the laws of the State of California.
            """
        )

        print("\n--- Analyzing Contract: '\(sampleContract.title)' ---")

        // --- Streaming Analysis Example ---
        print("\n[STREAMING ANALYSIS] Task: Identify the 'Force Majeure' clause and summarize its key conditions.")
        print("LLM Response (streaming):")
        do {
            var fullResponse = ""
            // The `progressHandler` simulates updating a UI in real-time.
            let stream = analyzerService.analyzeContractStream(
                contractText: sampleContract.content,
                analysisTask: "Identify the 'Force Majeure' clause and summarize its key conditions."
            ) { chunk in
                // In a real SwiftUI app, this would be `self.analysisText += chunk` in an ObservableObject.
                print(chunk, terminator: "") // Print chunks as they arrive without newlines
            }

            // Consume the stream, accumulating the full response
            for try await chunk in stream {
                fullResponse += chunk
            }
            print("\n[STREAMING COMPLETE]")
            // print("\nFull Streamed Response:\n\(fullResponse)") // Uncomment to see the full accumulated response
        } catch {
            print("\n❌ Error during streaming analysis: \(error.localizedDescription)")
            if let ollamaError = error as? OllamaClientError {
                print("Ollama Client Error Details: \(ollamaError.errorDescription ?? "N/A")")
            }
        }

        // --- Non-Streaming Analysis Example ---
        print("\n[NON-STREAMING ANALYSIS] Task: Summarize the key obligations of both the Company and the Developer.")
        print("LLM Response (non-streaming):")
        do {
            let analysisResult = try await analyzerService.analyzeContract(
                contractText: sampleContract.content,
                analysisTask: "Summarize the key obligations of both the Company and the Developer."
            )
            print("\nSummary of Obligations:\n\(analysisResult)")
        } catch {
            print("\n❌ Error during non-streaming analysis: \(error.localizedDescription)")
            if let ollamaError = error as? OllamaClientError {
                print("Ollama Client Error Details: \(ollamaError.errorDescription ?? "N/A")")
            }
        }

        print("\n✅ Smart Contract Clause Analyzer Demo Finished.")
    }
}
