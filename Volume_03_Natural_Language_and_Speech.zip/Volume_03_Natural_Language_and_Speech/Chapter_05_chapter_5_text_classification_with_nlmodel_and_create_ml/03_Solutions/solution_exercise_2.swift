
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import NaturalLanguage // Required for NLModel

@available(iOS 18.0, *) // Conforming to the provided example's availability
class TicketClassifierViewController: UIViewController, UITextViewDelegate {

    // MARK: - UI Elements
    @IBOutlet weak var ticketDescriptionTextView: UITextView!
    @IBOutlet weak var primaryPredictionLabel: UILabel!
    @IBOutlet weak var secondaryPredictionLabel: UILabel!
    @IBOutlet weak var classifyButton: UIButton!

    // MARK: - Model Instance
    private var ticketModel: NLModel?

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadTicketClassifierModel()
    }

    // MARK: - UI Setup
    private func setupUI() {
        ticketDescriptionTextView.delegate = self
        ticketDescriptionTextView.layer.borderColor = UIColor.lightGray.cgColor
        ticketDescriptionTextView.layer.borderWidth = 1.0
        ticketDescriptionTextView.layer.cornerRadius = 5.0
        ticketDescriptionTextView.text = "Describe your support issue here..."
        ticketDescriptionTextView.textColor = .lightGray
        
        primaryPredictionLabel.text = "Primary Category: N/A"
        secondaryPredictionLabel.text = "Secondary Category: N/A"
        
        classifyButton.setTitle("Classify Ticket", for: .normal)
        classifyButton.isEnabled = false // Disable until model is loaded
    }

    // MARK: - Model Loading
    private func loadTicketClassifierModel() {
        guard let modelURL = Bundle.main.url(forResource: "TicketClassifier", withExtension: "mlmodelc") else {
            primaryPredictionLabel.text = "Error: TicketClassifier.mlmodelc not found."
            print("Error: TicketClassifier.mlmodelc not found in app bundle.")
            return
        }

        do {
            ticketModel = try NLModel(contentsOf: modelURL)
            primaryPredictionLabel.text = "Model loaded. Ready for input."
            classifyButton.isEnabled = true
            print("TicketClassifier loaded successfully.")
        } catch {
            primaryPredictionLabel.text = "Error loading model."
            print("Error loading ticket classifier model: \(error.localizedDescription)")
        }
    }

    // MARK: - Classification Logic
    @IBAction func classifyButtonTapped(_ sender: UIButton) {
        performTicketClassification()
    }

    private func performTicketClassification() {
        // Clear previous results
        primaryPredictionLabel.text = "Primary Category: N/A"
        secondaryPredictionLabel.text = "Secondary Category: N/A"
        primaryPredictionLabel.textColor = .label
        secondaryPredictionLabel.textColor = .label

        let ticketText = ticketDescriptionTextView.text.trimmingCharacters(in: .whitespacesAndNewlines)
        if ticketText.isEmpty || ticketText == "Describe your support issue here..." {
            primaryPredictionLabel.text = "Primary Category: Please enter a description."
            primaryPredictionLabel.textColor = .systemOrange
            return
        }

        guard let model = ticketModel else {
            primaryPredictionLabel.text = "Primary Category: Model not loaded."
            primaryPredictionLabel.textColor = .systemRed
            return
        }

        // Perform prediction with hypotheses
        let hypotheses = model.predictedLabelHypotheses(for: ticketText, maximumHypotheses: 2)

        if hypotheses.isEmpty {
            primaryPredictionLabel.text = "Primary Category: No prediction."
            primaryPredictionLabel.textColor = .systemGray
            return
        }

        // Display top prediction
        let topPrediction = hypotheses[0]
        let formattedConfidence = String(format: "%.2f%%", topPrediction.confidence * 100)
        primaryPredictionLabel.text = "Primary Category: \(topPrediction.label) (\(formattedConfidence))"

        // Display second prediction if available
        if hypotheses.count > 1 {
            let secondPrediction = hypotheses[1]
            let formattedConfidence = String(format: "%.2f%%", secondPrediction.confidence * 100)
            secondaryPredictionLabel.text = "Secondary Category: \(secondPrediction.label) (\(formattedConfidence))"
        } else {
            secondaryPredictionLabel.text = "Secondary Category: N/A (Only one strong prediction)"
            secondaryPredictionLabel.textColor = .systemGray
        }
    }

    // MARK: - UITextViewDelegate for Placeholder behavior
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == .lightGray {
            textView.text = nil
            textView.textColor = .label
        }
    }

    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Describe your support issue here..."
            textView.textColor = .lightGray
        }
    }
}
