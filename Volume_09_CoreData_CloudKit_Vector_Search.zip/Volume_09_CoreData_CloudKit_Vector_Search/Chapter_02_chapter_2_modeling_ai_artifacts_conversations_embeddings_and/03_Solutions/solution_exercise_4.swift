
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CoreData

@available(iOS 18.0, *)
actor MemoryManager {
    private let embeddingService = EmbeddingService()
    private let context: NSManagedObjectContext
    private let topK: Int

    init(context: NSManagedObjectContext, topK: Int = 3) {
        self.context = context
        self.topK = topK
    }

    /// The core RAG workflow: Retrieve -> Synthesize -> Inject
    func retrieveContext(for query: String) async throws -> String {
        // 1. Embed the user's query
        let queryData = try await embeddingService.generateAndConvert(for: query)
        let queryVector = embeddingService.convertFromData(queryData)
        
        // 2. Fetch all memories (In production, use a more optimized fetch)
        let request: NSFetchRequest<Memory> = NSFetchRequest(entityName: "Memory")
        let allMemories = try await context.perform {
            try self.context.fetch(request)
        }
        
        // 3. Perform semantic retrieval (Brute force similarity)
        let searchService = SemanticSearchService()
        let relevantMemories = try await searchService.search(
            query: query, 
            in: allMemories.map { $0 as! Note }, // Casting for demonstration
            topK: topK
        )
        
        // 4. Synthesize the context string
        return synthesize(from: relevantMemories)
    }

    private func synthesize(from results: [(any AnyObject, Float)]) -> String {
        guard !results.isEmpty else { return "" }
        
        var contextBuilder = "[Relevant Context from Past Interactions]:\n"
        
        for (item, similarity) in results {
            if let memory = item as? Memory {
                contextBuilder += "- \(memory.content) (Relevance: \(String(format: "%.2f", similarity)))\n"
            }
        }
        
        contextBuilder += "[End of Context]"
        return contextBuilder
    }
}
