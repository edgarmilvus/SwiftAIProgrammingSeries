
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import NaturalLanguage
import CreateML
import Foundation

// MARK: - 1. Data Preparation

// Helper function to generate synthetic data
func generateNoteTrainingData() -> [(text: String, label: String)] {
    var data: [(text: String, label: String)] = []

    // Shopping
    data.append(("Buy milk, eggs, bread for breakfast.", "Shopping"))
    data.append(("Grocery list: apples, cheese, pasta.", "Shopping"))
    data.append(("Need to pick up dry cleaning and dog food.", "Shopping"))
    data.append(("Order new shoes online for the event.", "Shopping"))
    data.append(("Don't forget the birthday gift for Sarah.", "Shopping"))
    data.append(("Check prices for flight tickets to Hawaii.", "Shopping"))
    data.append(("Compare laptop models before purchase.", "Shopping"))
    data.append(("Renew subscription for streaming service.", "Shopping"))
    data.append(("Get a new phone charger.", "Shopping"))
    data.append(("Hardware store for screws and paint.", "Shopping"))

    // Work
    data.append(("Meeting with John at 2 PM regarding Q3 report.", "Work"))
    data.append(("Prepare presentation for Monday's client meeting.", "Work"))
    data.append(("Finish the budget proposal by end of day.", "Work"))
    data.append(("Email marketing team about new campaign.", "Work"))
    data.append(("Review pull request from dev team.", "Work"))
    data.append(("Schedule a follow-up call with vendor.", "Work"))
    data.append(("Update project status in Jira.", "Work"))
    data.append(("Attend the daily stand-up at 9:30 AM.", "Work"))
    data.append(("Research competitors for market analysis.", "Work"))
    data.append(("Draft new employee onboarding document.", "Work"))

    // Personal
    data.append(("Call mom to wish her happy birthday.", "Personal"))
    data.append(("Book dentist appointment for next month.", "Personal"))
    data.append(("Plan weekend trip to the mountains.", "Personal"))
    data.append(("Go for a run in the park this evening.", "Personal"))
    data.append(("Read chapter 5 of 'The Great Gatsby'.", "Personal"))
    data.append(("Organize photos from last vacation.", "Personal"))
    data.append(("Practice guitar for 30 minutes.", "Personal"))
    data.append(("Water the plants.", "Personal"))
    data.append(("Watch the new episode of my favorite show.", "Personal"))
    data.append(("Catch up with old friends this Friday.", "Personal"))

    // Idea
    data.append(("Idea for a new app: a personalized meal planner.", "Idea"))
    data.append(("Brainstorming session for blog post topics.", "Idea"))
    data.append(("Concept for a sci-fi novel about time travel.", "Idea"))
    data.append(("Design idea: minimalist UI for the new feature.", "Idea"))
    data.append(("Think about starting a podcast on tech trends.", "Idea"))
    data.append(("New business idea: artisanal coffee subscription.", "Idea"))
    data.append(("Consider learning a new programming language.", "Idea"))
    data.append(("Improve efficiency by automating report generation.", "Idea"))
    data.append(("Experiment with new painting techniques.", "Idea"))
    data.append(("Develop a new recipe for vegan cookies.", "Idea"))

    // Reminder
    data.append(("Reminder: Pay electricity bill by Friday.", "Reminder"))
    data.append(("Don't forget to take out the trash tonight.", "Reminder"))
    data.append(("Set alarm for 6 AM tomorrow.", "Reminder"))
    data.append(("Pick up kids from school at 3:30 PM.", "Reminder"))
    data.append(("Medication reminder: take pills after dinner.", "Reminder"))
    data.append(("Renew driver's license next month.", "Reminder"))
    data.append(("Call landlord about leaky faucet.", "Reminder"))
    data.append(("Vet appointment for Buster on Tuesday.", "Reminder"))
    data.append(("Return library books by due date.", "Reminder"))
    data.append(("Charge laptop overnight.", "Reminder"))

    // Add more examples to reach 50-100 total
    data.append(("Buy groceries for the week.", "Shopping"))
    data.append(("Finish the sprint tasks.", "Work"))
    data.append(("Call grandma.", "Personal"))
    data.append(("New feature concept.", "Idea"))
    data.append(("Remember to send the email.", "Reminder"))
    data.append(("Need to buy new shoes.", "Shopping"))
    data.append(("Prepare for the client demo.", "Work"))
    data.append(("Workout in the morning.", "Personal"))
    data.append(("Innovative solution for scaling.", "Idea"))
    data.append(("Don't forget the doctor's appointment.", "Reminder"))
    
    // Shuffle the data for better training
    return data.shuffled()
}

// MARK: - 2. Model Training

func trainAndSaveNoteClassifier() throws -> URL {
    let trainingData = generateNoteTrainingData()
    
    // Convert to MLDataTable
    let dataTable = try MLDataTable(array: trainingData.map { ["text": $0.text, "label": $0.label] })

    // Split data for training and testing (optional but good practice)
    let (trainingTable, testingTable) = dataTable.randomSplit(by: 0.8, seed: 0)

    // Train the model
    let classifier = try MLTextClassifier(trainingData: trainingTable,
                                          textColumn: "text",
                                          labelColumn: "label")

    // Evaluate the model (optional)
    let evaluation = classifier.evaluation(on: testingTable, textColumn: "text", labelColumn: "label")
    print("Model Training Accuracy: \(evaluation.accuracy)")

    // Save the model
    let fileManager = FileManager.default
    let documentsURL = try fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    let modelURL = documentsURL.appendingPathComponent("NoteClassifier.mlmodel")

    try classifier.write(to: modelURL)
    print("Model saved to: \(modelURL.path)")
    return modelURL
}

// MARK: - 3. Model Integration & 4. Prediction

class NoteClassifier {
    private var model: NLModel?

    init(modelURL: URL) {
        do {
            self.model = try NLModel(contentsOf: modelURL)
            print("Note classifier model loaded successfully.")
        } catch {
            print("Error loading NLModel: \(error.localizedDescription)")
            self.model = nil
        }
    }

    func predictCategory(for note: String) -> String {
        guard let model = model else {
            print("Model not loaded. Cannot predict.")
            return "Unknown"
        }
        return model.predictedLabel(for: note) ?? "Unknown"
    }
    
    // Advanced: Get probabilities to handle low-confidence predictions
    func predictCategoryWithConfidence(for note: String) -> (label: String, confidence: Double) {
        guard let model = model else {
            print("Model not loaded. Cannot predict.")
            return ("Unknown", 0.0)
        }
        let (label, probabilities) = model.predictedLabel(for: note, probabilities: ())
        if let label = label, let confidence = probabilities[label] {
            return (label, confidence)
        }
        return ("Unknown", 0.0)
    }
}

// MARK: - Main Execution

// Simulate an iOS/macOS app lifecycle
func runNoteCategorizationDemo() {
    var modelURL: URL?
    do {
        // Train and save the model (this would typically be a one-time step during development)
        modelURL = try trainAndSaveNoteClassifier()
    } catch {
        print("Failed to train or save model: \(error.localizedDescription)")
        return
    }

    guard let loadedModelURL = modelURL else {
        print("Model URL not available.")
        return
    }

    // Load the model in the app
    let classifier = NoteClassifier(modelURL: loadedModelURL)

    // Test predictions
    print("\n--- Testing Predictions ---")
    let notesToClassify = [
        "Remember to buy groceries for dinner tonight.",
        "Finalize the presentation for the board meeting.",
        "Plan a hiking trip for the upcoming long weekend.",
        "New idea for a sustainable energy solution.",
        "Don't forget to pick up the mail.",
        "Check flight prices for holiday.",
        "Review code before merging.",
        "Meet friends for coffee."
    ]

    let confidenceThreshold = 0.7 // Example threshold for low confidence

    for note in notesToClassify {
        let (predictedLabel, confidence) = classifier.predictCategoryWithConfidence(for: note)
        let confidenceString = String(format: "%.2f", confidence)
        
        if confidence < confidenceThreshold {
            print("Note: '\(note)' -> Predicted: \(predictedLabel) (Confidence: \(confidenceString)) - Consider as Low Confidence/Unknown.")
        } else {
            print("Note: '\(note)' -> Predicted: \(predictedLabel) (Confidence: \(confidenceString))")
        }
    }
}

// Call the demo function to run the solution
runNoteCategorizationDemo()
