
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CloudKit
import Observation

/// Represents the types of storage available within the Memoria ecosystem.
enum MemoriaStorageType {
    case privateVault   // User-only, uses user's iCloud quota
    case communityFeed  // Global, uses developer's quota
    case collaborative  // Shared via CKShare, uses participant's quota
}

/// Custom error types for granular error handling in CloudKit operations.
enum MemoriaCloudError: Error, LocalizedError {
    case accountNotFound
    case permissionDenied
    case recordSaveFailed(Error)
    case fetchFailed(Error)
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .accountNotFound: return "No iCloud account found. Please sign in to iCloud in Settings."
        case .permissionDenied: return "You do not have permission to access this record."
        case .recordSaveFailed(let error): return "Failed to save record: \(error.localizedDescription)"
        case .fetchFailed(let error): return "Failed to fetch data: \(error.localizedDescription)"
        case .unknown(let error): return "An unexpected error occurred: \(error.localizedDescription)"
        }
    }
}

/// A model representing a Journal Entry in the Memoria app.
/// We use a struct to ensure value semantics, making it easier to work with in concurrent environments.
struct JournalEntry: Identifiable, Sendable {
    let id: CKRecord.ID
    let content: String
    let timestamp: Date
    let storageType: MemoriaStorageType
}

/// The central manager responsible for all CloudKit interactions.
/// Marked with `@MainActor` to ensure all UI-related updates and state changes 
/// occur on the main thread, preventing data races in the View layer.
@MainActor
final class CloudKitManager: ObservableObject {
    
    /// The container used to access all CloudKit databases.
    /// In a real app, this matches your Bundle Identifier.
    private let container = CKContainer.default()
    
    /// The private database for personal user data.
    private var privateDatabase: CKDatabase { container.privateCloudDatabase }
    
    /// The public database for community-wide data.
    private var publicDatabase: CKDatabase { container.publicCloudDatabase }
    
    /// The shared database for collaborative data.
    private var sharedDatabase: CKDatabase { container.sharedCloudDatabase }
    
    /// Published property to track the status of the iCloud account.
    @Published var isCloudEnabled: Bool = false
    
    /// Published property to store fetched entries for the UI.
    @Published var entries: [JournalEntry] = []
    
    /// Published property to track loading states.
    @Published var isLoading: Bool = false

    init() {
        // In a production app, you would check account status on initialization.
        Task {
            await checkCloudStatus()
        }
    }

    /// Verifies if the user is logged into iCloud.
    /// This is a critical first step before attempting any database operations.
    func checkCloudStatus() async {
        do {
            let status = try await container.accountStatus()
            switch status {
            case .available:
                self.isCloudEnabled = true
            case .noAccount:
                self.isCloudEnabled = false
                print("User is not logged into iCloud.")
            case .restricted:
                self.isCloudEnabled = false
                print("iCloud access is restricted (e.g., Parental Controls).")
            case .couldNotDetermine:
                self.isCloudEnabled = false
                print("Could not determine iCloud status.")
            @unknown default:
                self.isCloudEnabled = false
            }
        } catch {
            self.isCloudEnabled = false
            print("Error checking iCloud status: \(error)")
        }
    }

    /// Saves a personal journal entry to the user's Private Database.
    /// - Parameter content: The text content of the journal entry.
    /// - Throws: `MemoriaCloudError` if the save operation fails.
    @available(iOS 18.0, *)
    func savePrivateEntry(content: String) async throws {
        isLoading = true
        defer { isLoading = false }
        
        // 1. Create a CKRecord representing the entry.
        // We define a Record Type "JournalEntry" which must exist in the CloudKit Dashboard.
        let record = CKRecord(recordType: "JournalEntry")
        record["content"] = content as CKRecordValue
        record["timestamp"] = Date() as CKRecordValue
        
        do {
            // 2. Attempt to save the record to the private database.
            let savedRecord = try await privateDatabase.save(record)
            
            // 3. Map the CKRecord back to our local domain model.
            let newEntry = JournalEntry(
                id: savedRecord.recordID,
                content: savedRecord["content"] as? String ?? "",
                timestamp: savedRecord["timestamp"] as? Date ?? Date(),
                storageType: .privateVault
            )
            
            // 4. Update the UI state.
            self.entries.insert(newEntry, at: 0)
            print("Successfully saved private entry.")
        } catch {
            throw MemoriaCloudError.recordSaveFailed(error)
        }
    }

    /// Saves a community-wide announcement to the Public Database.
    /// - Parameter content: The text content of the announcement.
    /// - Throws: `MemoriaCloudError` if the save operation fails.
    @available(iOS 18.0, *)
    func savePublicAnnouncement(content: String) async throws {
        isLoading = true
        defer { isLoading = false }
        
        let record = CKRecord(recordType: "JournalEntry")
        record["content"] = content as CKRecordValue
        record["timestamp"] = Date() as CKRecordValue
        
        do {
            // Note: We use the publicDatabase here. 
            // This record will be visible to ALL users of the app.
            let savedRecord = try await publicDatabase.save(record)
            
            let newEntry = JournalEntry(
                id: savedRecord.recordID,
                content: savedRecord["content"] as? String ?? "",
                timestamp: savedRecord["timestamp"] as? Date ?? Date(),
                storageType: .communityFeed
            )
            
            self.entries.insert(newEntry, at: 0)
            print("Successfully saved public announcement.")
        } catch {
            throw MemoriaCloudError.recordSaveFailed(error)
        }
    }

    /// Fetches all entries from the Private Database.
    /// Demonstrates how to query the database for specific record types.
    @available(iOS 18.0, *)
    func fetchPrivateEntries() async throws {
        isLoading = true
        defer { isLoading = false }
        
        // 1. Define a predicate. 'TRUEPREDICATE' means "fetch everything."
        let predicate = NSPredicate(value: true)
        
        // 2. Create a query for the "JournalEntry" record type.
        let query = CKQuery(recordType: "JournalEntry", predicate: predicate)
        
        // 3. Sort by timestamp descending (newest first).
        query.sortDescriptors = [NSSortDescriptor(key: "timestamp", ascending: false)]
        
        do {
            // 4. Execute the query using the modern async API.
            // matchResults is a collection of (CKRecord.ID, Result<CKRecord, Error>).
            let (results, _) = try await privateDatabase.records(matching: query)
            
            var fetchedEntries: [JournalEntry] = []
            
            // 5. Iterate through the results and handle individual record successes/failures.
            for (_, result) in results {
                switch result {
                case .success(let record):
                    let entry = JournalEntry(
                        id: record.recordID,
                        content: record["content"] as? String ?? "",
                        timestamp: record["timestamp"] as? Date ?? Date(),
                        storageType: .privateVault
                    )
                    fetchedEntries.append(entry)
                case .failure(let error):
                    print("Error fetching individual record: \(error)")
                }
            }
            
            // 6. Update the UI state on the MainActor.
            self.entries = fetchedEntries
        } catch {
            throw MemoriaCloudError.fetchFailed(error)
        }
    }
}
