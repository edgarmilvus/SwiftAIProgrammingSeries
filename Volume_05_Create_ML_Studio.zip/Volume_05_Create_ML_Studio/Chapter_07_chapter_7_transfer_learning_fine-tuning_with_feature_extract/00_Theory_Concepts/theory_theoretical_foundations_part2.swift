
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Vision // For VNImageRequestHandler

@available(iOS 18.0, *)
actor InferenceEngine {
    private let model: MLModel // The Core ML model instance
    private var predictionCount: Int = 0

    init(modelURL: URL) throws {
        self.model = try MLModel(contentsOf: modelURL)
    }

    func predict(imageBuffer: CVImageBuffer) async throws -> MLFeatureProvider {
        // Ensure only one prediction happens at a time to protect internal state
        // and potentially the model itself if it's not thread-safe.
        predictionCount += 1 // Safely incremented due to actor isolation

        let input = MLImage(cvPixelBuffer: imageBuffer)
        let prediction = try await model.prediction(from: input) // Assuming MLModel.prediction is now async

        print("Prediction #\(predictionCount) completed.")
        return prediction
    }

    func getCurrentPredictionCount() -> Int {
        return predictionCount // Read-only access is fine
    }
}

// Analogy: Actor isolation is akin to `@MainActor` for UI updates.
// Just as `@MainActor` ensures all UI modifications happen on the main thread,
// an actor ensures all modifications to its internal state happen sequentially
// within the actor's isolated context, preventing data races.

// Example usage:
@available(iOS 18.0, *)
func performInference(image: CVImageBuffer) {
    Task {
        do {
            let modelURL = Bundle.main.url(forResource: "MyFineTunedModel", withExtension: "mlmodelc")!
            let engine = try InferenceEngine(modelURL: modelURL)

            // Multiple tasks can request predictions, the actor will serialize them.
            async let prediction1 = engine.predict(imageBuffer: image)
            async let prediction2 = engine.predict(imageBuffer: image)

            let result1 = try await prediction1
            let result2 = try await prediction2

            print("Result 1: \(result1)")
            print("Result 2: \(result2)")
        } catch {
            print("Inference error: \(error)")
        }
    }
}
