
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

// MARK: - Data Structures

enum AnimalType: String, CaseIterable, Hashable {
    case deer = "Deer"
    case bear = "Bear"
    case rabbit = "Rabbit"
    case wolf = "Wolf" // The rare class
}

struct AnimalPrediction {
    let actual: AnimalType
    let predicted: AnimalType
}

// Reusing ConfusionMatrix struct (from Exercise 1) and multi-class functions (from Exercise 2)
// struct ConfusionMatrix { ... }
// func calculateMultiClassConfusionMatrix(predictions: [PhotoPrediction]) -> [PetType: [PetType: Int]] { ... }
// func calculatePerClassMetrics(multiClassMatrix: [PetType: [PetType: Int]], forClass targetClass: PetType) -> (precision: Double, recall: Double, f1Score: Double) { ... }
// func calculateMacroAverages(perClassMetrics: [PetType: (precision: Double, recall: Double, f1Score: Double)]) -> (macroPrecision: Double, macroRecall: Double, macroF1Score: Double) { ... }

// MARK: - Adaptations for AnimalType

// Adaptation of multi-class confusion matrix function for AnimalType
func calculateMultiClassAnimalConfusionMatrix(predictions: [AnimalPrediction]) -> [AnimalType: [AnimalType: Int]] {
    var matrix: [AnimalType: [AnimalType: Int]] = [:]

    for actualClass in AnimalType.allCases {
        matrix[actualClass] = [:]
        for predictedClass in AnimalType.allCases {
            matrix[actualClass]?[predictedClass] = 0
        }
    }

    for prediction in predictions {
        matrix[prediction.actual]?[prediction.predicted]? += 1
    }
    return matrix
}

// Adaptation of per-class metrics function for AnimalType
func calculatePerClassAnimalMetrics(multiClassMatrix: [AnimalType: [AnimalType: Int]], forClass targetClass: AnimalType) -> (precision: Double, recall: Double, f1Score: Double) {
    let allAnimalClasses = AnimalType.allCases

    let tp = multiClassMatrix[targetClass]?[targetClass] ?? 0

    var fp = 0
    for actualClass in allAnimalClasses where actualClass != targetClass {
        fp += multiClassMatrix[actualClass]?[targetClass] ?? 0
    }

    var fn = 0
    for predictedClass in allAnimalClasses where predictedClass != targetClass {
        fn += multiClassMatrix[targetClass]?[predictedClass] ?? 0
    }

    let precisionDenominator = Double(tp + fp)
    let precision = (precisionDenominator > 0) ? Double(tp) / precisionDenominator : 0.0

    let recallDenominator = Double(tp + fn)
    let recall = (recallDenominator > 0) ? Double(tp) / recallDenominator : 0.0
    
    let f1ScoreDenominator = precision + recall
    let f1Score = (f1ScoreDenominator > 0) ? 2 * (precision * recall) / f1ScoreDenominator : 0.0

    return (precision, recall, f1Score)
}

// Adaptation of macro-average function for AnimalType
func calculateMacroAveragedAnimalMetrics(perClassMetrics: [AnimalType: (precision: Double, recall: Double, f1Score: Double)]) -> (macroPrecision: Double, macroRecall: Double, macroF1Score: Double) {
    guard !perClassMetrics.isEmpty else { return (0.0, 0.0, 0.0) }

    let totalPrecision = perClassMetrics.values.reduce(0.0) { $0 + $1.precision }
    let totalRecall = perClassMetrics.values.reduce(0.0) { $0 + $1.recall }
    let totalF1Score = perClassMetrics.values.reduce(0.0) { $0 + $1.f1Score }

    let numClasses = Double(perClassMetrics.count)
    return (totalPrecision / numClasses, totalRecall / numClasses, totalF1Score / numClasses)
}


// MARK: - Simulation and Reporting

// 2. Simulate Imbalanced Data (1000 records)
var animalPredictions: [AnimalPrediction] = []

// Actual Deer: 400 records
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .deer, predicted: .deer), count: 380)) // Correct
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .deer, predicted: .bear), count: 10)) // Misclassified as Bear
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .deer, predicted: .rabbit), count: 10)) // Misclassified as Rabbit

// Actual Bear: 300 records
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .bear, predicted: .bear), count: 280)) // Correct
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .bear, predicted: .deer), count: 15)) // Misclassified as Deer
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .bear, predicted: .rabbit), count: 5)) // Misclassified as Rabbit

// Actual Rabbit: 250 records
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .rabbit, predicted: .rabbit), count: 230)) // Correct
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .rabbit, predicted: .deer), count: 10)) // Misclassified as Deer
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .rabbit, predicted: .bear), count: 10)) // Misclassified as Bear

// Actual Wolf: 50 records (the rare class)
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .wolf, predicted: .wolf), count: 25)) // Correct (TP)
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .wolf, predicted: .deer), count: 15)) // Misclassified as Deer (FN)
animalPredictions.append(contentsOf: Array(repeating: AnimalPrediction(actual: .wolf, predicted: .bear), count: 10)) // Misclassified as Bear (FN)

animalPredictions.shuffle() // Mix the data

print("--- Wildlife Classifier with Rare Species Evaluation ---")
print("Total Images: \(animalPredictions.count)\n")

// 3. Calculate Overall Accuracy
var correctPredictions = 0
for prediction in animalPredictions {
    if prediction.actual == prediction.predicted {
        correctPredictions += 1
    }
}
let overallAccuracy = Double(correctPredictions) / Double(animalPredictions.count)
print(String(format: "Overall Accuracy: %.4f", overallAccuracy))
print("\n")

// 4. Calculate Multi-Class Confusion Matrix
let multiClassAnimalMatrix = calculateMultiClassAnimalConfusionMatrix(predictions: animalPredictions)

print("--- Multi-Class Confusion Matrix ---")
// Print header
print(String(format: "%-10s | %@", "Actual \\ Pred", AnimalType.allCases.map { String(format: "%-10s", $0.rawValue) }.joined(separator: " | ")))
print(String(repeating: "-", count: 10 + (13 * AnimalType.allCases.count)))

// Print rows
for actualClass in AnimalType.allCases {
    let rowValues = AnimalType.allCases.map { predictedClass in
        String(format: "%-10d", multiClassAnimalMatrix[actualClass]?[predictedClass] ?? 0)
    }.joined(separator: " | ")
    print(String(format: "%-10s | %@", actualClass.rawValue, rowValues))
}
print(String(repeating: "-", count: 10 + (13 * AnimalType.allCases.count)))
print("\n")

// 5. Calculate Per-Class Precision, Recall, and F1-Score
var perClassAnimalMetrics: [AnimalType: (precision: Double, recall: Double, f1Score: Double)] = [:]
print("--- Per-Class Metrics ---")
for animalType in AnimalType.allCases {
    let metrics = calculatePerClassAnimalMetrics(multiClassMatrix: multiClassAnimalMatrix, forClass: animalType)
    perClassAnimalMetrics[animalType] = metrics
    print(String(format: "%@: Precision = %.4f, Recall = %.4f, F1-Score = %.4f", animalType.rawValue, metrics.precision, metrics.recall, metrics.f1Score))
}
print("\n")

// Calculate Macro Averages (optional, but good for overall view)
let (macroPrecision, macroRecall, macroF1Score) = calculateMacroAveragedAnimalMetrics(perClassMetrics: perClassAnimalMetrics)
print("--- Macro-Averaged Metrics ---")
print(String(format: "Macro-Averaged Precision: %.4f", macroPrecision))
print(String(format: "Macro-Averaged Recall:    %.4f", macroRecall))
print(String(format: "Macro-Averaged F1-Score:  %.4f", macroF1Score))
print("\n")

// 6. Report and Interpret
print("--- Interpretation ---")
print("Critique of Accuracy:")
print(String(format: "The overall accuracy is %.2f%%. This number looks quite good on its own.", overallAccuracy * 100))
print("However, accuracy can be misleading in scenarios with class imbalance, like this one.")
print("The model could achieve a high accuracy simply by being good at classifying the majority classes (Deer, Bear, Rabbit) and ignoring the minority class (Wolf).")
print("For example, if the model always predicted 'Deer', it would still be correct for 40% of the data, plus potentially some others. If it correctly predicted all Deer, Bear, Rabbit and missed all Wolf, accuracy would still be (400+300+250)/1000 = 95%.")
print("This high accuracy hides the poor performance on the rare 'Wolf' class.")

print("\nFocus on the Rare Class (Wolf):")
let wolfMetrics = perClassAnimalMetrics[.wolf]!
print(String(format: "- Wolf Precision: %.2f", wolfMetrics.precision))
print(String(format: "- Wolf Recall:    %.2f", wolfMetrics.recall))
print(String(format: "- Wolf F1-Score:  %.2f", wolfMetrics.f1Score))
print("The **Wolf Precision (%.2f)** means that when the model *does* predict 'Wolf', it's correct about %.0f%% of the time. This is decent, suggesting when it's confident, it's often right.".formatted(wolfMetrics.precision, wolfMetrics.precision * 100))
print("The **Wolf Recall (%.2f)** is much lower, meaning that out of all actual wolf sightings, the model only correctly identifies %.0f%% of them. This is a significant problem; many wolves are being missed.".formatted(wolfMetrics.recall, wolfMetrics.recall * 100))
print("The **Wolf F1-Score (%.2f)**, which is the harmonic mean of precision and recall, provides a single metric that balances both. Its relatively low value reflects the poor recall for the Wolf class, indicating a substantial challenge in detecting this rare species.".formatted(wolfMetrics.f1Score))
print("The confusion matrix confirms this: out of 50 actual wolves, only 25 were correctly identified. 15 were mistaken for Deer, and 10 for Bear (False Negatives).")

print("\nProposed Improvements for the 'Wolf' class:")
print("1.  **Data Augmentation:** Artificially increasing the number of 'Wolf' images by rotating, flipping, cropping, changing brightness, etc., to make the model see more variations.")
print("2.  **Re-sampling Techniques:**")
print("    - **Oversampling:** Duplicating existing 'Wolf' images or generating synthetic ones (e.g., SMOTE).")
print("    - **Undersampling:** Reducing the number of majority class images (Deer, Bear, Rabbit) to balance the dataset (use with caution, as it discards valuable data).")
print("3.  **Collect More Data:** The most straightforward but often hardest solution: actively seek out and label more 'Wolf' images.")
print("4.  **Cost-Sensitive Learning:** Adjusting the loss function during training to penalize misclassifications of 'Wolf' more heavily than misclassifications of common species.")
print("5.  **Ensemble Methods:** Combining multiple models, some of which might be specialized in detecting rare classes.")
print("6.  **Transfer Learning with Pre-trained Models:** Using models pre-trained on vast image datasets and fine-tuning them with your specific (albeit imbalanced) wildlife data.")
