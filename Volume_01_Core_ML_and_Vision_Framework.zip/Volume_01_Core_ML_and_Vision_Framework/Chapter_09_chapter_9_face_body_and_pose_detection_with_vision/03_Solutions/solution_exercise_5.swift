
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import AVFoundation
import Vision
import CoreImage
import CoreMedia
import UIKit // For UIImage/UIImageView in example, can be NSImage/NSImageView for macOS

// MARK: - FaceSegmentationProcessorDelegate
protocol FaceSegmentationProcessorDelegate: AnyObject {
    func faceSegmentationProcessor(_ processor: FaceSegmentationProcessor, didOutputPixelBuffer pixelBuffer: CVPixelBuffer)
    func faceSegmentationProcessor(_ processor: FaceSegmentationProcessor, didEncounterError error: Error)
}

// MARK: - FaceSegmentationProcessor
class FaceSegmentationProcessor: NSObject {

    weak var delegate: FaceSegmentationProcessorDelegate?

    private let captureSession = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let videoOutputQueue = DispatchQueue(label: "com.example.faceSegmentationVideoQueue", qos: .userInitiated)
    private let ciContext = CIContext(options: [.workingColorSpace: NSNull()]) // Re-use CIContext, no color space for faster processing

    // The background image to use for replacement.
    private var backgroundImage: CIImage?

    // Availability check for VNDetectFaceSegmentationRequest
    private var isFaceSegmentationAvailable: Bool {
        if #available(iOS 17.0, macOS 14.0, *) {
            return true
        } else {
            return false
        }
    }

    override init() {
        super.init()
        setupCaptureSession()
        loadBackgroundImage()
    }

    private func setupCaptureSession() {
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
            delegate?.faceSegmentationProcessor(self, didEncounterError: NSError(domain: "FaceSegmentationProcessor", code: 1, userInfo: [NSLocalizedDescriptionKey: "No front camera found."]))
            return
        }

        guard let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            delegate?.faceSegmentationProcessor(self, didEncounterError: NSError(domain: "FaceSegmentationProcessor", code: 2, userInfo: [NSLocalizedDescriptionKey: "Could not create video device input."]))
            return
        }

        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            delegate?.faceSegmentationProcessor(self, didEncounterError: NSError(domain: "FaceSegmentationProcessor", code: 3, userInfo: [NSLocalizedDescriptionKey: "Could not add video input to session."]))
            return
        }

        videoOutput.setSampleBufferDelegate(self, queue: videoOutputQueue)
        videoOutput.alwaysDiscardsLateVideoFrames = true
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        } else {
            delegate?.faceSegmentationProcessor(self, didEncounterError: NSError(domain: "FaceSegmentationProcessor", code: 4, userInfo: [NSLocalizedDescriptionKey: "Could not add video output to session."]))
            return
        }
        
        // Ensure video orientation and mirroring for front camera
        if let connection = videoOutput.connection(with: .video), connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = true
        }
    }

    private func loadBackgroundImage() {
        // Load a static background image. For a real app, this might be configurable.
        if let image = UIImage(named: "virtual_background") { // Replace with your background image asset
            backgroundImage = CIImage(image: image)?.transformed(by: CGAffineTransform(scaleX: -1, y: 1).translatedBy(x: image.size.width, y: 0)) // Mirror for front camera
        } else {
            print("Warning: 'virtual_background' image not found. Using solid color background.")
            backgroundImage = CIImage(color: .green).cropped(to: CGRect(x: 0, y: 0, width: 1280, height: 720)) // Default to green screen
        }
    }

    func startRunning() {
        guard isFaceSegmentationAvailable else {
            delegate?.faceSegmentationProcessor(self, didEncounterError: NSError(domain: "FaceSegmentationProcessor", code: 6, userInfo: [NSLocalizedDescriptionKey: "Face segmentation requires iOS 17.0+ or macOS 14.0+."]))
            return
        }

        AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
            guard let self = self else { return }
            if granted {
                self.videoOutputQueue.async {
                    self.captureSession.startRunning()
                    print("AVCaptureSession started for face segmentation.")
                }
            } else {
                self.delegate?.faceSegmentationProcessor(self, didEncounterError: NSError(domain: "FaceSegmentationProcessor", code: 5, userInfo: [NSLocalizedDescriptionKey: "Camera access denied."]))
            }
        }
    }

    func stopRunning() {
        videoOutputQueue.async {
            self.captureSession.stopRunning()
            print("AVCaptureSession stopped for face segmentation.")
        }
    }
}

// MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
extension FaceSegmentationProcessor: AVCaptureVideoDataOutputSampleBufferDelegate {

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard isFaceSegmentationAvailable else { return } // Double check availability

        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Create CIImage from the current video frame
        var inputCIImage = CIImage(cvPixelBuffer: pixelBuffer)

        // Ensure the background image matches the input frame's dimensions
        let frameExtent = inputCIImage.extent
        let scaledBackgroundImage = backgroundImage?.transformed(by: CGAffineTransform(
            scaleX: frameExtent.width / (backgroundImage?.extent.width ?? 1),
            y: frameExtent.height / (backgroundImage?.extent.height ?? 1)
        ))?.cropped(to: frameExtent) // Crop to ensure it's exactly the same size

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
        let request = VNDetectFaceSegmentationRequest()

        var outputPixelBuffer: CVPixelBuffer?
        var finalCIImage: CIImage = inputCIImage // Default to original frame

        do {
            try handler.perform([request])

            if let observation = request.results?.first as? VNFaceObservation,
               let segmentationMask = observation.segmentationMask {

                // Convert the segmentation mask to a CIImage.
                let maskCIImage = CIImage(cvPixelBuffer: segmentationMask.pixelBuffer)

                // The mask needs to be scaled and oriented correctly to match the input image.
                // Vision masks are normalized to the observation's bounding box, but segmentationMask.pixelBuffer
                // is usually the same size as the input image and already aligned.
                // However, the Y-axis might need to be flipped for CIImage if not already handled by Vision.
                // Let's assume it's already aligned, if not, adjust `maskCIImage`'s transform.

                // Blend the foreground (face) with the new background using the mask.
                if let bg = scaledBackgroundImage {
                    let blendFilter = CIFilter(name: "CIBlendWithMask", parameters: [
                        kCIInputImageKey: inputCIImage, // Foreground (original frame)
                        kCIInputBackgroundImageKey: bg, // New background
                        kCIInputMaskImageKey: maskCIImage // Mask from Vision
                    ])
                    finalCIImage = blendFilter?.outputImage ?? inputCIImage
                } else {
                    // Fallback if background image not loaded, maybe just blur background
                    let blurredBackground = CIFilter(name: "CIGaussianBlur", parameters: [kCIInputImageKey: inputCIImage, kCIInputRadiusKey: 10])?.outputImage
                    let blendFilter = CIFilter(name: "CIBlendWithMask", parameters: [
                        kCIInputImageKey: inputCIImage,
                        kCIInputBackgroundImageKey: blurredBackground ?? inputCIImage,
                        kCIInputMaskImageKey: maskCIImage
                    ])
                    finalCIImage = blendFilter?.outputImage ?? inputCIImage
                }

            } else {
                // No face detected, or segmentation failed. Display only the new background or original feed.
                finalCIImage = scaledBackgroundImage ?? inputCIImage
            }

            // Convert the final CIImage back to CVPixelBuffer for display.
            var newPixelBuffer: CVPixelBuffer?
            CVPixelBufferCreate(kCFAllocatorDefault,
                                Int(frameExtent.width),
                                Int(frameExtent.height),
                                kCVPixelFormatType_32BGRA,
                                nil,
                                &newPixelBuffer)
            
            if let outputBuffer = newPixelBuffer {
                ciContext.render(finalCIImage, to: outputBuffer, bounds: frameExtent, colorSpace: CGColorSpaceCreateDeviceRGB())
                outputPixelBuffer = outputBuffer
            }

        } catch {
            print("Failed to perform face segmentation request: \(error)")
        }

        if let outputPixelBuffer = outputPixelBuffer {
            DispatchQueue.main.async {
                self.delegate?.faceSegmentationProcessor(self, didOutputPixelBuffer: outputPixelBuffer)
            }
        }
    }
}

// MARK: - VideoPreviewView (Example for displaying CVPixelBuffer)
// This is a simplified example. In a real app, you'd use AVSampleBufferDisplayLayer for efficiency.
class VideoPreviewView: UIView {
    private var imageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        return iv
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }

    private func setupView() {
        addSubview(imageView)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: topAnchor),
            imageView.bottomAnchor.constraint(equalTo: bottomAnchor),
            imageView.leadingAnchor.constraint(equalTo: leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: trailingAnchor)
        ])
    }

    func display(pixelBuffer: CVPixelBuffer) {
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        let context = CIContext()
        if let cgImage = context.createCGImage(ciImage, from: ciImage.extent) {
            imageView.image = UIImage(cgImage: cgImage)
        }
    }
}

// MARK: - Example Usage (in a UIViewController)
/*
class VideoCallViewController: UIViewController, FaceSegmentationProcessorDelegate {
    let processor = FaceSegmentationProcessor()
    var videoPreviewView: VideoPreviewView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        videoPreviewView = VideoPreviewView(frame: view.bounds)
        view.addSubview(videoPreviewView)
        videoPreviewView.autoresizingMask = [.flexibleWidth, .flexibleHeight]

        processor.delegate = self
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        processor.startRunning()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        processor.stopRunning()
    }

    // MARK: - FaceSegmentationProcessorDelegate
    func faceSegmentationProcessor(_ processor: FaceSegmentationProcessor, didOutputPixelBuffer pixelBuffer: CVPixelBuffer) {
        videoPreviewView.display(pixelBuffer: pixelBuffer)
    }

    func faceSegmentationProcessor(_ processor: FaceSegmentationProcessor, didEncounterError error: Error) {
        print("Error from face segmentation processor: \(error.localizedDescription)")
        // Show alert to user
    }
}
*/
