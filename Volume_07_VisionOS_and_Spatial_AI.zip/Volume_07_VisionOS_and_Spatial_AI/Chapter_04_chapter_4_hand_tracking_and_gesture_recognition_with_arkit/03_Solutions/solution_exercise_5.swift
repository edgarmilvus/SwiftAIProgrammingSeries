
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import ARKit
import Foundation

struct NormalizedSkeleton {
    let joints: [HandJointName: SIMD3<Float>]
}

class GestureRecognizer {
    private var poseHoldTimer: TimeInterval = 0
    private let requiredHoldTime: TimeInterval = 0.5 // 500ms
    
    /// Normalizes the hand skeleton to be scale and translation invariant
    func normalize(_ anchor: HandAnchor) -> NormalizedSkeleton {
        let wristPos = anchor.handSkeleton.transform(for: .wrist).translation
        
        // Calculate Hand Scale (Distance from wrist to middle finger knuckle)
        let middleKnucklePos = anchor.handSkeleton.transform(for: .middleFingerKnuckle).translation
        let handScale = simd_distance(wristPos, middleKnucklePos)
        
        var normalizedJoints: [HandJointName: SIMD3<Float>] = [:]
        
        for jointName in HandJointName.allCases {
            let jointTransform = anchor.handSkeleton.transform(for: jointName)
            // 1. Translation Invariance: Subtract wrist position
            // 2. Scale Invariance: Divide by hand scale
            let relativePos = (jointTransform.translation - wristPos) / handScale
            normalizedJoints[jointName] = relativePos
        }
        
        return NormalizedSkeleton(joints: normalizedJoints)
    }
    
    func processFrame(anchor: HandAnchor, deltaTime: TimeInterval) -> Bool {
        let skeleton = normalize(anchor)
        
        if isPeaceSign(skeleton) {
            poseHoldTimer += deltaTime
            if poseHoldTimer >= requiredHoldTime {
                poseHoldTimer = 0 // Reset after trigger
                return true
            }
        } else {
            poseHoldTimer = 0
        }
        return false
    }
    
    private func isPeaceSign(_ skeleton: NormalizedSkeleton) -> Bool {
        guard let indexTip = skeleton.joints[.indexFingerTip],
              let middleTip = skeleton.joints[.middleFingerTip],
              let ringTip = skeleton.joints[.ringFingerTip],
              let pinkyTip = skeleton.joints[.pinkyFingerTip],
              let wrist = skeleton.joints[.wrist] else { return false }
        
        // Heuristic: Index and Middle are far from wrist, Ring and Pinky are close
        let indexDist = simd_distance(indexTip, wrist)
        let middleDist = simd_distance(middleTip, wrist)
        let ringDist = simd_distance(ringTip, wrist)
        let pinkyDist = simd_distance(pinkyTip, wrist)
        
        return indexDist > 0.4 && middleDist > 0.4 && ringDist < 0.25 && pinkyDist < 0.25
    }
}
