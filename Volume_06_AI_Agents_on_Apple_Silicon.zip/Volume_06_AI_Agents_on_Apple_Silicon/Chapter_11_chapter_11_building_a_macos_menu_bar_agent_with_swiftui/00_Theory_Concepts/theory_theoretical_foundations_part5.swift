
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

@available(macOS 14.0, *)
@Observable // Mark this class as observable
final class MenuBarAgentState { // Renamed from ViewModel for clarity with @Observable
    var currentPrompt: String = ""
    var aiResponse: String = "Waiting for prompt..."
    var isProcessing: Bool = false
    var errorMessage: String?
    var conversation: [ConversationTurn] = []

    // The LLMAgent is still a separate actor, not part of the @Observable state itself
    // It's managed by the logic that updates this @Observable state.
}

@available(macOS 14.0, *)
struct MenuBarContentView: View {
    @State private var agentState = MenuBarAgentState() // State for the UI
    private let llmAgent = LLMAgent() // The actor instance

    var body: some View {
        VStack {
            Text("AI Response:")
                .font(.headline)
            ScrollView {
                Text(agentState.aiResponse)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
            }
            .frame(height: 150)

            TextField("Enter your prompt", text: $agentState.currentPrompt)
                .textFieldStyle(.roundedBorder)
                .padding(.vertical, 5)

            Button("Ask AI") {
                Task { // Use a Task to call async methods
                    await sendPromptToLLM()
                }
            }
            .disabled(agentState.isProcessing || agentState.currentPrompt.isEmpty)

            if agentState.isProcessing {
                ProgressView()
            }

            if let error = agentState.errorMessage {
                Text(error)
                    .foregroundStyle(.red)
            }
        }
        .padding()
        .frame(width: 400) // Typical size for a Menu Bar popover
    }

    @MainActor // Ensure this method runs on the main actor
    private func sendPromptToLLM() async {
        guard !agentState.currentPrompt.isEmpty else { return }

        agentState.isProcessing = true
        agentState.errorMessage = nil
        let promptToSend = agentState.currentPrompt
        agentState.currentPrompt = ""

        do {
            if !await llmAgent.isModelAvailable {
                try await llmAgent.loadModel(path: "/Users/user/models/my_llm.gguf")
            }
            let response = try await llmAgent.generateResponse(prompt: promptToSend)
            agentState.aiResponse = response
            // Potentially update agentState.conversation here
        } catch {
            agentState.errorMessage = "LLM Error: \(error.localizedDescription)"
            agentState.aiResponse = "Error occurred."
        }
        agentState.isProcessing = false
    }
}
