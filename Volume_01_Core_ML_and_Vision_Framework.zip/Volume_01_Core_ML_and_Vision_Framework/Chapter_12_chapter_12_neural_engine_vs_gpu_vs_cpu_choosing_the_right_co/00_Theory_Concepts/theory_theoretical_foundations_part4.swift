
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

// Example of a custom Sendable input (simplified)
@available(iOS 18.0, *)
struct MyImageInput: MLFeatureProvider, Sendable {
    let pixelBuffer: CVPixelBuffer // CVPixelBuffer is generally Sendable
    let featureName: String = "image"

    var featureNames: Set<String> { [featureName] }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == self.featureName {
            return MLFeatureValue(pixelBuffer: pixelBuffer)
        }
        return nil
    }
    
    // Conformance to Sendable is implicit if all stored properties are Sendable.
    // CVPixelBuffer is an opaque type managed by CoreFoundation, generally safe for passing.
}

// Example of passing Sendable data to an async task
@available(iOS 18.0, *)
func processImageWithModel(input: MyImageInput, manager: MLModelManager) async throws -> String {
    let processedResult = await Task.detached {
        // 'input' is safely passed to this detached task because MyImageInput is Sendable
        let prediction = try await manager.predict(input: input)
        return prediction.featureValue(for: "classLabel")?.stringValue ?? "N/A"
    }.value
    return processedResult
}
