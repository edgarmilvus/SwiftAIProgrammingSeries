
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import Foundation

    @available(iOS 18.0, macOS 15.0, *)
    @Observable
    class TrainingViewModel {
        // This mirrors the TrainingManager.TrainingSessionStatus but is designed for UI observation
        class TrainingProgress: Identifiable, Sendable {
            let id: UUID
            let modelName: String
            var progress: Double
            var message: String
            var isActive: Bool
            var error: String?
            var trainedModelURL: URL?

            init(id: UUID, modelName: String, progress: Double, message: String, isActive: Bool, error: String? = nil, trainedModelURL: URL? = nil) {
                self.id = id
                self.modelName = modelName
                self.progress = progress
                self.message = message
                self.isActive = isActive
                self.error = error
                self.trainedModelURL = trainedModelURL
            }

            // Update function to be called by the actor
            func update(from status: TrainingManager.TrainingSessionStatus) {
                self.progress = status.progress
                self.message = status.message
                self.isActive = status.isActive
                self.error = status.error
                self.trainedModelURL = status.trainedModelURL
            }
        }

        var currentTrainingSessions: [UUID: TrainingProgress] = [:]
        private let trainingManager = TrainingManager() // Our actor

        func startTraining(name: String, trainingDataURL: URL, parameters: MLImageClassifier.ModelParameters) async {
            do {
                let sessionId = try await trainingManager.startNewTraining(
                    name: name,
                    trainingDataURL: trainingDataURL,
                    parameters: parameters
                )
                // Initialize a UI-observable object
                let initialStatus = await trainingManager.getSessionStatus(for: sessionId)!
                currentTrainingSessions[sessionId] = TrainingProgress(
                    id: initialStatus.id,
                    modelName: initialStatus.modelName,
                    progress: initialStatus.progress,
                    message: initialStatus.message,
                    isActive: initialStatus.isActive
                )

                // Start observing the actor's state changes
                Task { [weak self] in
                    while await self?.trainingManager.getSessionStatus(for: sessionId)?.isActive ?? false {
                        try await Task.sleep(for: .milliseconds(500)) // Poll every 0.5 seconds
                        if let status = await self?.trainingManager.getSessionStatus(for: sessionId) {
                            await MainActor.run { // Ensure UI updates on main actor
                                self?.currentTrainingSessions[sessionId]?.update(from: status)
                            }
                        }
                    }
                    // Final update after training completes or fails
                    if let status = await self?.trainingManager.getSessionStatus(for: sessionId) {
                        await MainActor.run {
                            self?.currentTrainingSessions[sessionId]?.update(from: status)
                        }
                    }
                }

            } catch {
                print("Failed to start training: \(error)")
            }
        }
    }

    // Example SwiftUI View
    /*
    @available(iOS 18.0, macOS 15.0, *)
    struct TrainingView: View {
        @State private var viewModel = TrainingViewModel()
        @State private var modelName: String = ""
        @State private var dataURL: String = ""

        var body: some View {
            VStack {
                TextField("Model Name", text: $modelName)
                TextField("Data URL", text: $dataURL)
                Button("Start Training") {
                    Task {
                        let params = MLImageClassifier.ModelParameters(maxIterations: 10, augmentation: .all)
                        await viewModel.startTraining(
                            name: modelName,
                            trainingDataURL: URL(fileURLWithPath: dataURL),
                            parameters: params
                        )
                    }
                }

                List {
                    ForEach(Array(viewModel.currentTrainingSessions.values)) { session in
                        VStack(alignment: .leading) {
                            Text(session.modelName)
                            ProgressView(value: session.progress) {
                                Text(session.message)
                            }
                            if let error = session.error {
                                Text("Error: \(error)").foregroundStyle(.red)
                            }
                            if let url = session.trainedModelURL {
                                Text("Model saved at: \(url.lastPathComponent)")
                            }
                        }
                    }
                }
            }
        }
    }
    */
    