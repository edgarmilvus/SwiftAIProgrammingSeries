
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import AppIntents
import Foundation

// Reusing TaskMasterDomain from Exercise 2 for consistency
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct TaskMasterDomain: AppIntentDomain {
    static var identifier: String = "taskMaster"
    static var displayName: LocalizedStringResource = "TaskMaster"
    static var description: LocalizedStringResource = "Intents for managing tasks in the TaskMaster app."
}

// 1. Define TaskEntity
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct TaskEntity: AppEntity {
    let id: UUID
    var title: String
    var dueDate: Date?
    var isCompleted: Bool

    // Required by AppEntity: How the entity type is displayed
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Task"

    // Required by AppEntity: How a specific instance of the entity is displayed
    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(
            title: "\(title)",
            subtitle: isCompleted ? "Completed" : "Due: \(dueDate?.formatted(date: .abbreviated, time: .omitted) ?? "N/A")"
        )
    }

    // Required by AppEntity: A unique string identifier for the entity instance
    var appEntityIdentifier: String { id.uuidString }
    
    // Initializer to create instances
    init(id: UUID, title: String, dueDate: Date? = nil, isCompleted: Bool = false) {
        self.id = id
        self.title = title
        self.dueDate = dueDate
        self.isCompleted = isCompleted
    }
}

// 2. Implement TaskEntityQuery
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct TaskEntityQuery: AppEntityQuery {
    // Simulate a simple in-memory task store. In a real app, this would be a database.
    // Making it static allows it to be accessed and modified by the intent.
    static var allTasks: [TaskEntity] = [
        TaskEntity(id: UUID(uuidString: "E621E1F8-C36C-495A-93FC-0C247A3E6E5F")!, title: "Prepare Project Presentation", dueDate: Calendar.current.date(byAdding: .day, value: 3, to: Date())),
        TaskEntity(id: UUID(uuidString: "F621E1F8-C36C-495A-93FC-0C247A3E6E5F")!, title: "Review Q3 Report", dueDate: Calendar.current.date(byAdding: .day, value: 1, to: Date())),
        TaskEntity(id: UUID(uuidString: "A621E1F8-C36C-495A-93FC-0C247A3E6E5F")!, title: "Schedule Team Meeting", dueDate: Calendar.current.date(byAdding: .day, value: 7, to: Date())),
        TaskEntity(id: UUID(uuidString: "B621E1F8-C36C-495A-93FC-0C247A3E6E5F")!, title: "Order New Office Supplies", dueDate: Calendar.current.date(byAdding: .day, value: 5, to: Date()))
    ]

    // Required: Resolves specific entities by their unique identifiers
    func entities(for identifiers: [TaskEntity.ID]) async throws -> [TaskEntity] {
        return Self.allTasks.filter { identifiers.contains($0.id) }
    }

    // Optional but highly recommended: Provides entities matching a user query string
    func entities(matching query: String) async throws -> [TaskEntity] {
        // Filter tasks that are not yet completed and whose title matches the query
        return Self.allTasks.filter { !$0.isCompleted && $0.title.localizedCaseInsensitiveContains(query) }
    }

    // Optional but highly recommended: Provides a general list of suggested entities
    func suggestedEntities() async throws -> [TaskEntity] {
        // Suggest uncompleted tasks, perhaps sorted by due date
        return Self.allTasks.filter { !$0.isCompleted }.sorted { ($0.dueDate ?? .distantFuture) < ($1.dueDate ?? .distantFuture) }
    }
}

// 3. Create CompleteTaskIntent
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct CompleteTaskIntent: AppIntent {
    static var title: LocalizedStringResource = "Complete Task"
    static var description: LocalizedStringResource = "Marks a specific task as complete."
    static var openAppWhenRun: Bool = false
    static var domain: AppIntentDomain.Type? = TaskMasterDomain.self

    // The key here: a parameter of type TaskEntity
    @Parameter(title: "Task to Complete", description: "The task to be marked as complete.", requestValueDialog: "Which task should I complete?")
    var task: TaskEntity

    // 4. Implement perform()
    func perform() async throws -> some IntentResult {
        // In a real app, you would update the task's `isCompleted` status in your data store.
        // For this exercise, we simulate the action by modifying the static array.
        if let index = TaskEntityQuery.allTasks.firstIndex(where: { $0.id == task.id }) {
            TaskEntityQuery.allTasks[index].isCompleted = true
            print("✅ TaskMaster: Task '\(task.title)' (ID: \(task.id.uuidString.prefix(8))) marked as complete.")
            return .result(
                dialog: "I've marked '\(task.title)' as complete."
            )
        } else {
            print("❌ TaskMaster: Task '\(task.title)' (ID: \(task.id.uuidString.prefix(8))) not found or already completed.")
            return .result(
                dialog: "I couldn't find or update the task '\(task.title)'."
            )
        }
    }
}

// 5. Make Discoverable (Add to existing or new AppShortcutsProvider)
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
extension TaskMasterShortcuts { // Extending the provider from Exercise 2
    static var appShortcuts: [AppShortcut] {
        [
            // Keep existing shortcuts from Exercise 2 if desired
            AppShortcut(
                intent: UpdateTaskStatusIntent(taskID: UUID(), newStatus: .done),
                phrases: [
                    "Change status of task \(.parameter(\.$taskID)) to \(.parameter(\.$newStatus))",
                    "Mark task \(.parameter(\.$taskID)) as \(.parameter(\.$newStatus))"
                ],
                shortTitle: "Update Task",
                systemImageName: "checklist.checked"
            ),
            // Add the new CompleteTaskIntent shortcut
            AppShortcut(
                // When defining a shortcut with an AppEntity parameter, provide a placeholder instance.
                // This instance is not used for actual execution, but for App Intents to infer types.
                intent: CompleteTaskIntent(task: TaskEntity(id: UUID(), title: "Sample Task for Shortcut")),
                phrases: [
                    "Mark \(.parameter(\.$task)) as done",
                    "Complete \(.parameter(\.$task))"
                ],
                shortTitle: "Complete Task",
                systemImageName: "checkmark.circle.fill"
            )
        ]
    }
}
