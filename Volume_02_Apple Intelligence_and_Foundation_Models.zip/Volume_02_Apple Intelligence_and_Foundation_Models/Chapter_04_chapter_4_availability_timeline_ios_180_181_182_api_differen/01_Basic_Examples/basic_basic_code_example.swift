
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import UIKit
import Intelligence // Requires iOS 18.0+ and the Intelligence framework

/// A basic view controller demonstrating how to use Apple Intelligence's Writing Tools
/// to rephrase selected text within a UITextView.
///
/// This class is only available on iOS 18.0 and later, as it relies on the
/// Intelligence framework and its associated APIs.
@available(iOS 18.0, *)
class BasicIntelligenceViewController: UIViewController {

    /// The UITextView where the user can input and select text for rephrasing.
    private let textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = .preferredFont(forTextStyle: .body)
        tv.isEditable = true
        tv.isSelectable = true
        tv.backgroundColor = .systemBackground
        tv.textColor = .label
        tv.layer.cornerRadius = 8
        tv.layer.borderColor = UIColor.systemGray3.cgColor
        tv.layer.borderWidth = 1
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return tv
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "AI Writing Tools Demo"
        view.backgroundColor = .systemGroupedBackground

        setupTextView()
        // Ensure the text view is the first responder to allow its selection menu to appear
        textView.becomeFirstResponder()

        // Provide some initial placeholder text for demonstration
        textView.text = "This is a sample sentence that I want to rephrase using Apple Intelligence. I think it could be written better. Let's see what suggestions the AI provides."
    }

    /// Configures the UITextView and adds it to the view hierarchy with Auto Layout constraints.
    private func setupTextView() {
        view.addSubview(textView)
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 200) // Fixed height for simplicity
        ])
    }

    // MARK: - UITextInput Custom Menu Actions

    /// This method is part of the `UIResponderStandardEditActions` protocol and is called by the system
    /// to determine which actions can be performed when a text selection menu is displayed.
    ///
    /// We override it to dynamically enable or disable our custom "Rephrase" action.
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        // 1. Check if the system is querying about our specific "rephraseSelectedText" action.
        if action == #selector(rephraseSelectedText) {
            // 2. The "Rephrase" action should only be available if there is selected text.
            // We ensure `selectedTextRange` is not nil and the text within it is not empty.
            return textView.selectedTextRange != nil && !textView.text(in: textView.selectedTextRange!)!.isEmpty
        }
        // 3. For all other standard actions (e.g., copy, paste, select all),
        // we defer to the superclass implementation.
        return super.canPerformAction(action, withSender: sender)
    }

    /// This method is the action handler for our custom "Rephrase" menu item.
    /// It's marked `@objc` because it's called via a `Selector` from `UIAction`.
    @objc private func rephraseSelectedText() {
        // 1. Safely unwrap the currently selected text range and the text itself.
        // If no text is selected, we print a message and exit.
        guard let selectedRange = textView.selectedTextRange,
              let selectedText = textView.text(in: selectedRange),
              !selectedText.isEmpty else {
            print("No text selected for rephrasing.")
            return
        }

        print("Attempting to rephrase: '\(selectedText)'")

        // 2. Create an instance of `INRephraseTextIntent`.
        // This is a specific `AppIntent` provided by the `Intelligence` framework
        // that represents the "rephrase text" action.
        let intent = INRephraseTextIntent()
        // Assign the selected text to the intent's `text` parameter.
        intent.text = selectedText

        // 3. Create an `INInteraction` object.
        // An `INInteraction` encapsulates an `INIntent` and is the mechanism
        // through which your app communicates with the system's intent services.
        let interaction = INInteraction(intent: intent, response: nil)

        // 4. Perform the interaction asynchronously using Swift's concurrency model.
        // The system will take over, process the intent (potentially using the on-device LLM),
        // and return a response. This operation can take some time.
        Task {
            do {
                // 5. Execute the interaction and await its response.
                // This call blocks the current `Task` until the system provides a result.
                let response = try await interaction.perform()

                // 6. Safely cast the generic `INIntentResponse` to `INRephraseTextIntentResponse`
                // and extract the `rephrasedText` property.
                // If the response is not of the expected type or contains no rephrased text,
                // it indicates a failure or no suggestion from the AI.
                guard let rephraseResponse = response.intentResponse as? INRephraseTextIntentResponse,
                      let rephrasedText = rephraseResponse.rephrasedText else {
                    print("Rephrasing failed or no rephrased text received.")
                    // Inform the user, or handle the case where AI might not have a suggestion.
                    return
                }

                // 7. Update the `UITextView` with the rephrased text.
                // UI updates must always occur on the main actor.
                await MainActor.run {
                    textView.replace(selectedRange, withText: rephrasedText)
                    print("Rephrased text: '\(rephrasedText)'")
                }

            } catch {
                // 8. Handle any errors that occur during the intent execution.
                // This could be due to system limitations, permissions, or other issues.
                print("Error rephrasing text: \(error.localizedDescription)")
                // Present an alert to the user on the main actor to inform them of the error.
                await MainActor.run {
                    let alert = UIAlertController(title: "Rephrase Error", message: "Failed to rephrase text: \(error.localizedDescription)", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(alert, animated: true)
                }
            }
        }
    }

    // MARK: - Menu Controller Presentation

    /// This property must return `true` for a `UIResponder` to become the first responder
    /// and thus be able to display a UIMenuController or respond to menu actions.
    override var canBecomeFirstResponder: Bool {
        return true
    }

    /// This method is called by the system to build the contextual menu (like the one that appears
    /// when you select text). We use it to insert our custom "Rephrase" action.
    /// This is the modern way to customize text selection menus in iOS 13+.
    override func buildMenu(with builder: UIMenuBuilder) {
        super.buildMenu(with: builder)

        // 1. Ensure we are modifying the menu specifically for text selection.
        // If `textSelection` menu doesn't exist, there's nothing for us to add to.
        guard builder.menu(for: .textSelection) != nil else { return }

        // 2. Create a `UIAction` for our custom "Rephrase" command.
        // The `title` is what the user sees, and the `image` provides a visual cue.
        // The `handler` closure is executed when the menu item is tapped.
        let rephraseAction = UIAction(title: "Rephrase", image: UIImage(systemName: "lightbulb.fill")) { [weak self] _ in
            // Call our custom action method.
            self?.rephraseSelectedText()
        }

        // 3. Create a `UIMenu` to contain our action.
        // `options: .displayInline` means the action will appear directly in the menu,
        // rather than as a submenu. An empty title (`""`) means it won't have a header.
        let customMenu = UIMenu(title: "", options: .displayInline, children: [rephraseAction])

        // 4. Insert our custom menu into the system's text selection menu.
        // We place it `afterMenu: .StandardCommand.lookup` (the system's "Look Up" option)
        // for a sensible placement.
        builder.insertSibling(customMenu, afterMenu: .StandardCommand.lookup)
    }
}
