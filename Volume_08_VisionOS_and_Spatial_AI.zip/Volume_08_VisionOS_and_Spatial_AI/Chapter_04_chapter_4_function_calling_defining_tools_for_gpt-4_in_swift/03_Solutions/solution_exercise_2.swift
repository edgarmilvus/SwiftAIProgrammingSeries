
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

enum ReminderError: Error, LocalizedError {
    case invalidDate(String)
    case priorityOutOfRange(Int)

    var errorDescription: String? {
        switch self {
        case .invalidDate(let val): return "The date '\(val)' is invalid or too far in the past. Please provide a valid ISO8601 date."
        case .priorityOutOfRange(let val): return "Priority \(val) is invalid. Must be an integer between 1 and 5."
        }
    }
}

struct Reminder: Codable, Sendable {
    let title: String
    let dueDate: Date
    let priority: Int
    let tags: [String]
}

actor TaskStore {
    private var reminders: [Reminder] = []
    
    func add(reminder: Reminder) {
        reminders.append(reminder)
        print("✅ Added: \(reminder.title) for \(reminder.dueDate)")
    }
}

struct ReminderOrchestrator {
    let store: TaskStore
    let dateFormatter: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter
    }()
    
    func createReminder(title: String, due_date: String, priority: Int, tags: [String]) async throws -> String {
        // 1. Validate Priority
        guard (1...5).contains(priority) else {
            throw ReminderError.priorityOutOfRange(priority)
        }
        
        // 2. Parse Date (Strict Schema Approach)
        guard let date = dateFormatter.date(from: due_date) else {
            throw ReminderError.invalidDate(due_date)
        }
        
        // 3. Logic Check: Prevent dates before the year 2000
        if date.timeIntervalSince1970 < 946684800 {
            throw ReminderError.invalidDate("Date is logically impossible.")
        }
        
        let newReminder = Reminder(title: title, dueDate: date, priority: priority, tags: tags)
        await store.add(reminder: newReminder)
        
        return "Success: Reminder created."
    }
}

// --- Simulation of the Feedback Loop ---
Task {
    let store = TaskStore()
    let orchestrator = ReminderOrchestrator(store: store)
    
    // Scenario: LLM fails to use ISO8601 and sends a human string instead
    let badLLMInput = """
    {
        "title": "Buy milk",
        "due_date": "Tomorrow at 9am",
        "priority": 3,
        "tags": ["grocery"]
    }
    """.data(using: .utf8)!
    
    do {
        let decoder = JSONDecoder()
        // This mimics the internal parsing logic
        struct RawArgs: Codable {
            let title: String; let due_date: String; let priority: Int; let tags: [String]
        }
        let args = try decoder.decode(RawArgs.self, from: badLLMInput)
        
        _ = try await orchestrator.createReminder(
            title: args.title,
            due_date: args.due_date,
            priority: args.priority,
            tags: args.tags
        )
    } catch {
        // CRITICAL: This error string is what we send back to the LLM
        print("FEEDBACK TO LLM: \(error.localizedDescription)")
        print("The LLM will now see this error and attempt to re-format the date.")
    }
}
