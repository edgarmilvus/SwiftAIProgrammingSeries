
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import Combine
import PrivateCloudCompute

// Mark the entire class as available only on iOS 18.0 and later,
// as PrivateCloudComputeManager is an iOS 18+ API.
@available(iOS 18.0, *)
class PCCStatusViewModel: ObservableObject {
    // @Published property to automatically update SwiftUI views when its value changes.
    @Published var statusMessage: String = "Checking Private Cloud Compute status..."
    
    // Set to store Combine cancellables to prevent retain cycles and manage subscriptions.
    private var cancellables = Set<AnyCancellable>()

    init() {
        // Step 4: Graceful Handling - Check if PrivateCloudComputeManager is supported on the current OS.
        // This prevents runtime crashes on older iOS versions.
        guard PrivateCloudComputeManager.isSupported else {
            statusMessage = "Private Cloud Compute not supported on this device/OS."
            return
        }
        
        // Step 3: Initial State - Immediately update the UI with the current PCC availability.
        updateStatus(isAvailable: PrivateCloudComputeManager.shared.isAvailable)

        // Step 1 & 2: Monitor PCC Status and Display Status
        // Subscribe to changes in PrivateCloudComputeManager's availability.
        PrivateCloudComputeManager.shared.availabilityPublisher
            .receive(on: DispatchQueue.main) // Ensure UI updates are on the main thread.
            .sink { [weak self] isAvailable in
                // Update the status message whenever PCC availability changes.
                self?.updateStatus(isAvailable: isAvailable)
            }
            .store(in: &cancellables) // Store the subscription to keep it active.
    }

    // Helper method to format the status message based on availability.
    private func updateStatus(isAvailable: Bool) {
        if isAvailable {
            statusMessage = "Private Cloud Compute: Available"
        } else {
            statusMessage = "Private Cloud Compute: Unavailable"
        }
    }
}
