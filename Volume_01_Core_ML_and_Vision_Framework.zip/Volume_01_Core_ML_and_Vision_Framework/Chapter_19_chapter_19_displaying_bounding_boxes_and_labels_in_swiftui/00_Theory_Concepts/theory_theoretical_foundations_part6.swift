
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.swift
// Description: Theoretical Foundations
// ==========================================

    import Vision
    import CoreGraphics // For CGRect, CGSize

    func transformVisionRect(
        _ visionRect: CGRect,
        imageSize: CGSize,
        viewSize: CGSize,
        orientation: CGImagePropertyOrientation = .up
    ) -> CGRect {
        // First, convert Vision's normalized rect to image-specific pixel rect
        let imageRect = VNImageRectForNormalizedRect(visionRect, Int(imageSize.width), Int(imageSize.height))

        // Then, scale the image-specific rect to the view's coordinate space.
        // This assumes the image is displayed using .fit or .fill content mode.
        // For .fit, we need to calculate the actual displayed image size within the view.
        let scaleX = viewSize.width / imageSize.width
        let scaleY = viewSize.height / imageSize.height
        let scale = min(scaleX, scaleY) // For .fit content mode

        let scaledWidth = imageSize.width * scale
        let scaledHeight = imageSize.height * scale

        let offsetX = (viewSize.width - scaledWidth) / 2.0
        let offsetY = (viewSize.height - scaledHeight) / 2.0

        // Apply scaling and offset
        let transformedX = imageRect.origin.x * scale + offsetX
        let transformedY = viewSize.height - (imageRect.origin.y * scale + offsetY) - (imageRect.size.height * scale) // Vision's origin is bottom-left
        let transformedWidth = imageRect.size.width * scale
        let transformedHeight = imageRect.size.height * scale

        return CGRect(x: transformedX, y: transformedY, width: transformedWidth, height: transformedHeight)
    }
    