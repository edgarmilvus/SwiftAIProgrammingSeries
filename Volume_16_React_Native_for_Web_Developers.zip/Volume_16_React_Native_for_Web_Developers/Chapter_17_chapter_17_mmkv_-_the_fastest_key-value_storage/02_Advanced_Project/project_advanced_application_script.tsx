/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// pages/dashboard.tsx
import React, { useState, useEffect, useCallback } from 'react';

/**
 * @description Mock implementation of the MMKV storage interface for Next.js.
 * In a real React Native environment, this would be imported from 'react-native-mmkv'.
 * We simulate the synchronous behavior to demonstrate the architectural pattern.
 */
class MMKVStorage {
  private storage: Map<string, string> = new Map();

  /**
   * Retrieves a value synchronously.
   * @param key - The unique identifier for the storage entry.
   * @returns The stored value or undefined if not found.
   */
  getString(key: string): string | undefined {
    // Simulate synchronous read (no Promise/await required)
    return this.storage.get(key);
  }

  /**
   * Sets a value synchronously.
   * @param key - The unique identifier.
   * @param value - The string value to store.
   */
  set(key: string, value: string): void {
    // Simulate synchronous write
    this.storage.set(key, value);
    console.log(`[MMKV] Synchronously set key: ${key}`);
  }

  /**
   * Deletes a key synchronously.
   * @param key - The key to remove.
   */
  delete(key: string): void {
    this.storage.delete(key);
  }
}

// Initialize the storage instance (Singleton pattern)
const mmkv = new MMKVStorage();

/**
 * @description Custom React Hook for managing state with MMKV persistence.
 * This hook mimics the behavior of 'useMMKV' from react-native-mmkv.
 * It ensures that state changes are immediately persisted to the synchronous storage.
 * 
 * @param key - The storage key for the preference.
 * @param initialValue - The default value if no storage entry exists.
 * @returns A tuple containing the current state and the state setter function.
 */
function useMMKVStorage<T>(key: string, initialValue: T): [T, (value: T) => void] {
  // State to hold the current value
  const [state, setState] = useState<T>(initialValue);

  // Load initial value from MMKV on component mount
  useEffect(() => {
    try {
      const storedValue = mmkv.getString(key);
      if (storedValue !== undefined) {
        // Parse the stored JSON string back to the original type
        setState(JSON.parse(storedValue) as T);
      } else {
        // If no value exists, set the initial value in storage
        mmkv.set(key, JSON.stringify(initialValue));
      }
    } catch (error) {
      console.error(`Error loading from MMKV for key ${key}:`, error);
    }
  }, [key, initialValue]);

  /**
   * @description Setter function that updates both React state and MMKV storage.
   * This ensures data persistence happens synchronously without async/await overhead.
   */
  const setValue = useCallback((value: T) => {
    try {
      // Allow functional updates (e.g., setCount(c => c + 1))
      const valueToStore = value instanceof Function ? value(state) : value;
      
      // Update React State
      setState(valueToStore);
      
      // Persist to MMKV Synchronously
      mmkv.set(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.error(`Error saving to MMKV for key ${key}:`, error);
    }
  }, [key, state]);

  return [state, setValue];
}

/**
 * @description Dashboard Component demonstrating MMKV usage.
 * Simulates a SaaS application managing user interface preferences.
 */
export default function Dashboard() {
  // 1. Theme Preference (Dark Mode / Light Mode)
  const [theme, setTheme] = useMMKVStorage<'light' | 'dark'>('app_theme', 'light');

  // 2. User Session Token (Mocked)
  const [sessionToken, setSessionToken] = useMMKVStorage<string | null>('session_token', null);

  // 3. Notification Settings (Complex Object)
  const [notifications, setNotifications] = useMMKVStorage<{
    email: boolean;
    push: boolean;
  }>('notification_settings', { email: true, push: false });

  /**
   * @description Handler to toggle theme and persist immediately.
   * Because MMKV writes are synchronous, the UI updates instantly without waiting for a Promise.
   */
  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
  };

  /**
   * @description Handler to login (mock) and store token.
   */
  const handleLogin = () => {
    const mockToken = `tok_${Math.random().toString(36).substring(7)}`;
    setSessionToken(mockToken);
  };

  /**
   * @description Handler to logout (clear token).
   */
  const handleLogout = () => {
    setSessionToken(null);
  };

  /**
   * @description Handler to toggle specific notification settings.
   */
  const toggleNotification = (type: keyof typeof notifications) => {
    setNotifications((prev) => ({
      ...prev,
      [type]: !prev[type],
    }));
  };

  return (
    <div style={{ 
      padding: '2rem', 
      fontFamily: 'sans-serif',
      background: theme === 'dark' ? '#1a1a1a' : '#ffffff',
      color: theme === 'dark' ? '#ffffff' : '#000000',
      minHeight: '100vh',
      transition: 'background 0.3s ease'
    }}>
      <h1>SaaS Dashboard Settings</h1>
      <p style={{ opacity: 0.7 }}>Using MMKV for synchronous state persistence.</p>

      <div style={{ marginTop: '2rem', border: '1px solid #ccc', padding: '1rem', borderRadius: '8px' }}>
        <h2>1. Appearance</h2>
        <p>Current Theme: <strong>{theme.toUpperCase()}</strong></p>
        <button onClick={toggleTheme} style={{ padding: '8px 16px', cursor: 'pointer' }}>
          Toggle Theme
        </button>
      </div>

      <div style={{ marginTop: '2rem', border: '1px solid #ccc', padding: '1rem', borderRadius: '8px' }}>
        <h2>2. Authentication</h2>
        {sessionToken ? (
          <div>
            <p>Status: <span style={{ color: 'green' }}>Logged In</span></p>
            <p style={{ fontSize: '0.8rem', background: '#eee', padding: '4px', display: 'inline-block' }}>
              Token: {sessionToken}
            </p>
            <br />
            <button onClick={handleLogout} style={{ marginTop: '8px', padding: '8px 16px', cursor: 'pointer' }}>
              Logout
            </button>
          </div>
        ) : (
          <div>
            <p>Status: <span style={{ color: 'red' }}>Logged Out</span></p>
            <button onClick={handleLogin} style={{ padding: '8px 16px', cursor: 'pointer' }}>
              Login (Mock)
            </button>
          </div>
        )}
      </div>

      <div style={{ marginTop: '2rem', border: '1px solid #ccc', padding: '1rem', borderRadius: '8px' }}>
        <h2>3. Notification Preferences</h2>
        <div style={{ display: 'flex', gap: '1rem' }}>
          <label>
            <input 
              type="checkbox" 
              checked={notifications.email} 
              onChange={() => toggleNotification('email')}
            /> 
            Email Notifications
          </label>
          <label>
            <input 
              type="checkbox" 
              checked={notifications.push} 
              onChange={() => toggleNotification('push')}
            /> 
            Push Notifications
          </label>
        </div>
        <pre style={{ background: '#f0f0f0', padding: '10px', marginTop: '10px', borderRadius: '4px' }}>
          {JSON.stringify(notifications, null, 2)}
        </pre>
      </div>
    </div>
  );
}
