
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import NaturalLanguage // Essential for NLEmbedding
import Foundation    // For UUID and String operations like lowercasing

// MARK: - 1. Data Model: Representing a Note

/// A simple structure to represent a user's note.
struct Note: Identifiable {
    let id: UUID
    let title: String
    let content: String
}

// MARK: - 2. Service Layer: Managing Notes and Semantic Operations

/// A service class responsible for managing notes and providing semantic similarity operations.
class SmartNoteService {
    /// Internal storage for all notes managed by the service.
    private var notes: [Note] = []

    /// Initializes the service with an optional array of initial notes.
    /// - Parameter initialNotes: An array of `Note` objects to preload into the service.
    init(initialNotes: [Note] = []) {
        self.notes = initialNotes
    }

    /// Adds a new note to the service's collection.
    /// - Parameter note: The `Note` object to add.
    func addNote(_ note: Note) {
        notes.append(note)
        print("Added note: \"\(note.title)\"")
    }

    /// Calculates the semantic distance between two text strings using `NLEmbedding`.
    /// A smaller distance value indicates higher semantic similarity.
    ///
    /// - Parameters:
    ///   - text1: The first text string for comparison.
    ///   - text2: The second text string for comparison.
    ///   - language: The natural language to use for embedding. Defaults to `.english`.
    /// - Returns: A `Double` representing the semantic distance. Returns `nil` if the
    ///            embedding model for the specified language is not available or supported.
    func calculateSemanticDistance(text1: String, text2: String, language: NLLanguage = .english) -> Double? {
        // Step 1: Check if the specified language is supported by NLEmbedding.
        // This is crucial as embedding models are language-specific.
        guard NLEmbedding.supports(language) else {
            print("Error: NLEmbedding does not support language: \(language.rawValue)")
            return nil
        }

        // Step 2: Obtain the NLEmbedding instance for word embeddings in the specified language.
        // This loads the pre-trained on-device model.
        guard let embeddingModel = NLEmbedding.wordEmbedding(for: language) else {
            print("Error: Failed to load word embedding model for \(language.rawValue).")
            return nil
        }

        // Step 3: Calculate the distance between the two texts.
        // NLEmbedding.distance(between:and:language:) is a high-level API that
        // efficiently handles tokenization, embedding lookup, and aggregation (e.g., averaging word vectors)
        // for the entire input strings to compute a single semantic distance.
        // We lowercase the text for better consistency, as embeddings can sometimes be sensitive to case,
        // though many models are robust to it.
        let distance = embeddingModel.distance(between: text1.lowercased(), and: text2.lowercased(), language: language)

        // Step 4: Return the calculated distance.
        // Remember: smaller distance means higher similarity.
        return distance
    }

    /// Finds the most semantically similar note to a given query text from the service's existing notes.
    ///
    /// - Parameters:
    ///   - queryText: The text to compare against the content of existing notes.
    ///   - language: The natural language to use for embedding. Defaults to `.english`.
    /// - Returns: An optional tuple containing the most similar `Note` and its semantic distance.
    ///            Returns `nil` if no notes are available or if no valid distance could be calculated.
    func findMostSimilarNote(to queryText: String, language: NLLanguage = .english) -> (note: Note, distance: Double)? {
        var closestNote: Note?
        // Initialize smallestDistance to infinity so any valid distance will be smaller.
        var smallestDistance: Double = Double.infinity

        // Pre-check: If there are no notes, we can't find a similar one.
        guard !notes.isEmpty else {
            print("No notes available to compare.")
            return nil
        }

        // Step 1: Iterate through all existing notes.
        for note in notes {
            // Step 2: Calculate the semantic distance between the query text and the current note's content.
            // We use the note's content for a richer semantic comparison.
            if let distance = calculateSemanticDistance(text1: queryText, text2: note.content, language: language) {
                // Step 3: Update the closest note if the current note is more similar (has a smaller distance).
                if distance < smallestDistance {
                    smallestDistance = distance
                    closestNote = note
                }
            }
        }

        // Step 4: Return the closest note and its distance if a valid one was found.
        if let closestNote = closestNote, smallestDistance != Double.infinity {
            return (note: closestNote, distance: smallestDistance)
        } else {
            return nil // No similar note found or an error occurred during calculation.
        }
    }
}

// MARK: - 3. Example Usage in an App Context

print("--- Initializing Smart Note Service ---")

// Initialize the Smart Note Service with some existing notes.
let noteService = SmartNoteService(initialNotes: [
    Note(id: UUID(), title: "Cooking Recipes", content: "A collection of pasta recipes, including carbonara and pesto."),
    Note(id: UUID(), title: "Travel Plans", content: "Planning a trip to Paris next summer, visiting the Eiffel Tower."),
    Note(id: UUID(), title: "Workout Routine", content: "Daily exercise routine: running, push-ups, and yoga."),
    Note(id: UUID(), title: "Gardening Tips", content: "Best practices for growing tomatoes and herbs in your backyard."),
    Note(id: UUID(), title: "Software Development", content: "Learning about Swift concurrency and async/await patterns.")
])

print("\n--- Current Notes in the System ---")
noteService.notes.forEach { print("- \($0.title)") }

// Scenario 1: User adds a new note about cooking.
print("\n--- Scenario 1: Adding a new note about cooking ---")
let newCookingNoteContent = "I need to find a good recipe for Italian food, maybe a lasagna."
let newCookingNote = Note(id: UUID(), title: "New Recipe Idea", content: newCookingNoteContent)
noteService.addNote(newCookingNote)

print("\n--- Finding similar notes for: \"\(newCookingNote.title)\" ---")
if let (similarNote, distance) = noteService.findMostSimilarNote(to: newCookingNote.content) {
    print("Most similar note found: \"\(similarNote.title)\"")
    print("Content: \"\(similarNote.content)\"")
    print(String(format: "Semantic Distance: %.4f (smaller is more similar)", distance))

    // Interpret the distance: closer to 0 means very similar.
    // The exact thresholds are heuristic and depend on the domain and desired sensitivity.
    if distance < 0.5 {
        print("Suggestion: This note is highly similar to an existing one. Consider linking them!")
    } else if distance < 1.0 {
        print("Suggestion: This note is moderately similar to an existing one.")
    } else {
        print("Suggestion: This note is somewhat different from existing ones.")
    }
} else {
    print("Could not find any similar notes for the new cooking note.")
}

// Scenario 2: User adds a new note about programming.
print("\n--- Scenario 2: Adding a new note about programming ---")
let newProgrammingNoteContent = "I'm exploring machine learning frameworks on iOS, like Core ML and Natural Language."
let newProgrammingNote = Note(id: UUID(), title: "iOS ML Exploration", content: newProgrammingNoteContent)
noteService.addNote(newProgrammingNote)

print("\n--- Finding similar notes for: \"\(newProgrammingNote.title)\" ---")
if let (similarNote, distance) = noteService.findMostSimilarNote(to: newProgrammingNote.content) {
    print("Most similar note found: \"\(similarNote.title)\"")
    print("Content: \"\(similarNote.content)\"")
    print(String(format: "Semantic Distance: %.4f", distance))
    if distance < 0.5 {
        print("Suggestion: This note is highly similar to an existing one.")
    } else {
        print("Suggestion: This note is moderately similar to an existing one.")
    }
} else {
    print("Could not find any similar notes for the new programming note.")
}

// Scenario 3: Directly comparing specific words to illustrate NLEmbedding's semantic understanding.
print("\n--- Scenario 3: Direct Word Comparisons ---")
guard let embedding = NLEmbedding.wordEmbedding(for: .english) else {
    print("Error: English word embedding not available for direct comparison.")
    exit(1)
}

let distanceAppleFruit = embedding.distance(between: "apple", and: "fruit", language: .english)
let distanceAppleCompany = embedding.distance(between: "apple", and: "company", language: .english)
let distanceAppleCar = embedding.distance(between: "apple", and: "car", language: .english)
let distanceKingQueen = embedding.distance(between: "king", and: "queen", language: .english)
let distanceKingCar = embedding.distance(between: "king", and: "car", language: .english)

print(String(format: "Distance between 'apple' and 'fruit': %.4f", distanceAppleFruit))
print(String(format: "Distance between 'apple' and 'company': %.4f", distanceAppleCompany))
print(String(format: "Distance between 'apple' and 'car': %.4f", distanceAppleCar))
print(String(format: "Distance between 'king' and 'queen': %.4f", distanceKingQueen))
print(String(format: "Distance between 'king' and 'car': %.4f", distanceKingCar))

// Expected output for distances:
// 'apple' and 'fruit' should be the smallest distance (highest similarity).
// 'apple' and 'company' should be somewhat larger.
// 'apple' and 'car' should be the largest distance (lowest similarity).
// 'king' and 'queen' should be small.
// 'king' and 'car' should be large.
