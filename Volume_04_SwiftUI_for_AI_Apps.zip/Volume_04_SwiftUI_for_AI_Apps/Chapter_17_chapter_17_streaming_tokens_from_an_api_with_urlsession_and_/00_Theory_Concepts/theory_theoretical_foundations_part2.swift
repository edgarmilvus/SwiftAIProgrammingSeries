
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 15.0, *)
func streamTokens(from url: URL) async throws {
    let (asyncBytes, response) = try await URLSession.shared.bytes(for: URLRequest(url: url))
    
    guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
        throw StreamingError.invalidResponse
    }
    
    // Iterate over the incoming bytes as they arrive
    for try await byteChunk in asyncBytes {
        // Process each 'byteChunk' (which is a Data instance or similar)
        // In a real AI streaming scenario, you'd likely decode this into tokens.
        print("Received \(byteChunk.count) bytes.")
        // Example: Decode and append to a string
        if let string = String(data: byteChunk, encoding: .utf8) {
            print("Decoded: \(string)")
            // Here you would typically parse for actual AI tokens
        }
    }
    print("Stream finished.")
}

enum StreamingError: Error {
    case invalidResponse
}
