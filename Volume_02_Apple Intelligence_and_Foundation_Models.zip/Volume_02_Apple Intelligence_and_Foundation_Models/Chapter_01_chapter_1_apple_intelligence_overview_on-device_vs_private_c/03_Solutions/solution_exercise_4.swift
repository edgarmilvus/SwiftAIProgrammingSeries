
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
// In a real scenario, you would import Apple's WritingTools or Foundation.ML framework.
// import AppleIntelligence.WritingTools // Hypothetical framework import

@available(iOS 18.0, macOS 15.0, *)
class WritingAssistant {
    // This class simulates the functionality of Apple's on-device Writing Tools.
    // All text processing, including context analysis and generation, occurs locally
    // on the user's device, ensuring privacy of intellectual property.

    /// Provides rephrased alternatives for a given text, considering its surrounding context.
    /// This method simulates an on-device LLM call for text transformation.
    ///
    /// - Parameters:
    ///   - text: The specific text snippet to rephrase.
    ///   - context: The surrounding text (e.g., paragraph or document) to provide contextual understanding.
    /// - Returns: An array of suggested rephrased strings.
    /// - Throws: An error if the simulated rephrasing process encounters an issue.
    func rephrase(text: String, context: String) async throws -> [String] {
        // --- ON-DEVICE LLM PROCESSING BEGINS ---
        // In a production app, this would involve calling Apple's on-device LLM
        // via the WritingTools framework or Foundation.ML APIs.
        // The LLM would leverage the 'context' to generate semantically relevant and coherent alternatives.
        
        // Simulate a brief processing time for an on-device LLM inference.
        // This ensures the UI remains responsive during generation.
        try await Task.sleep(for: .milliseconds(700))

        // Basic validation for demonstration purposes.
        guard !text.isEmpty else {
            return [] // No text to rephrase.
        }

        var suggestions: [String] = []
        let lowercasedText = text.lowercased()
        let lowercasedContext = context.lowercased()

        // --- MOCK REPHRASING LOGIC ---
        // This mock applies simple transformations and context awareness.
        // A real LLM would generate much more sophisticated and varied output.

        // Contextual awareness: Adjust suggestions based on detected tone or style.
        let isFormalContext = lowercasedContext.contains("academic") || lowercasedContext.contains("report")
        let isInformalContext = lowercasedContext.contains("chat") || lowercasedContext.contains("casual")

        if lowercasedText.contains("very good") {
            suggestions.append("Excellent")
            suggestions.append("Outstanding")
            if isFormalContext { suggestions.append("Commendable") }
        } else if lowercasedText.contains("important") {
            suggestions.append("Crucial")
            suggestions.append("Significant")
            if isFormalContext { suggestions.append("Pivotal") }
        } else if lowercasedText.contains("big") {
            suggestions.append("Large")
            suggestions.append("Substantial")
            if isFormalContext { suggestions.append("Considerable") }
        } else {
            // Generic rephrasing with a touch of context simulation
            if isFormalContext {
                suggestions.append("To reiterate, \(text.replacingOccurrences(of: "is", with: "is indeed").capitalizedFirstLetter())")
                suggestions.append("\(text.capitalizedFirstLetter().replacingOccurrences(of: "is", with: "is often"))")
            } else if isInformalContext {
                suggestions.append("Basically, \(text.lowercased())")
                suggestions.append("Another way to say this is: \(text.lowercased().replacingOccurrences(of: "is", with: "is also"))")
            } else {
                suggestions.append("\(text.capitalizedFirstLetter().replacingOccurrences(of: "is", with: "can be considered"))")
                suggestions.append("Perhaps, \(text.capitalizedFirstLetter().replacingOccurrences(of: "is", with: "is viewed as"))")
            }
        }

        if suggestions.isEmpty {
            suggestions.append("Consider revising: \(text)")
        }
        // --- ON-DEVICE LLM PROCESSING ENDS ---

        return suggestions
    }

    /// Elaborates on a given text, expanding it with more detail based on its context.
    /// This method simulates an on-device LLM call for text generation.
    ///
    /// - Parameters:
    ///   - text: The specific text snippet to elaborate on.
    ///   - context: The surrounding text (e.g., paragraph or document) to provide contextual understanding.
    /// - Returns: An elaborated version of the text, or nil if elaboration fails.
    /// - Throws: An error if the simulated elaboration process encounters an issue.
    func elaborate(text: String, context: String) async throws -> String? {
        // --- ON-DEVICE LLM PROCESSING BEGINS ---
        // In a production app, this would interact with Apple's on-device LLM
        // to generate additional sentences or details based on 'text' and 'context'.
        
        // Simulate processing time for generative AI, which can be longer.
        try await Task.sleep(for: .seconds(1))

        // Basic validation.
        guard !text.isEmpty else {
            return nil // No text to elaborate on.
        }

        // --- MOCK ELABORATION LOGIC ---
        // This mock provides generic elaboration based on length and context.
        // A real LLM would generate highly specific and contextually rich content.

        let elaboratedText: String
        if text.count < 15 {
            elaboratedText = "To elaborate on the idea of '\(text)', one must consider its foundational aspects and broader implications. Within the context of \"\(context.prefix(100))...\", this concept plays a crucial role in shaping the overall narrative and understanding. It is not merely a standalone point but rather an integral part of a larger, interconnected system."
        } else {
            elaboratedText = "Building upon the point that '\(text)', it's crucial to understand that this concept is deeply intertwined with the prevailing themes and arguments present in the surrounding text. Further analysis of \"\(context.prefix(150))...\" reveals several key components and contributing factors that collectively enhance its overall significance and impact on the subject matter."
        }
        // --- ON-DEVICE LLM PROCESSING ENDS ---

        return elaboratedText
    }
}

// Helper extension for capitalization, used in mock for better output
extension String {
    func capitalizedFirstLetter() -> String {
        guard let first = first else { return "" }
        return String(first).uppercased() + dropFirst()
    }
}

// Example Usage:
@available(iOS 18.0, macOS 15.0, *)
func demonstrateWritingAssistant() async {
    let assistant = WritingAssistant()
    let documentContext = """
    The recent advancements in on-device machine learning have revolutionized how applications handle user data.
    This paradigm shift prioritizes privacy and performance by executing complex AI models directly on the user's device,
    rather than relying on cloud servers. This approach has significant implications for sensitive applications
    like health trackers and personal journaling apps. The user experience is greatly enhanced due to reduced latency.
    """

    let selectedSentence1 = "This paradigm shift prioritizes privacy and performance."
    let selectedSentence2 = "The user experience is greatly enhanced."
    let selectedPhrase = "significant implications"
    let selectedShortPhrase = "very good"

    print("--- Exercise 4: Contextual Writing Assistant ---")

    do {
        print("\n--- Rephrasing: '\(selectedSentence1)' ---")
        let rephrasedOptions1 = try await assistant.rephrase(text: selectedSentence1, context: documentContext)
        print("Original: '\(selectedSentence1)'")
        print("Rephrased Options:")
        rephrasedOptions1.forEach { print("  - \($0)") }

        print("\n--- Rephrasing: '\(selectedShortPhrase)' (in a formal context) ---")
        let formalContext = "This academic report discusses the very good results of the study."
        let rephrasedOptions2 = try await assistant.rephrase(text: selectedShortPhrase, context: formalContext)
        print("Original: '\(selectedShortPhrase)'")
        print("Rephrased Options:")
        rephrasedOptions2.forEach { print("  - \($0)") }

        print("\n--- Elaborating: '\(selectedPhrase)' ---")
        if let elaboratedText1 = try await assistant.elaborate(text: selectedPhrase, context: documentContext) {
            print("Original: '\(selectedPhrase)'")
            print("Elaborated: '\(elaboratedText1)'")
        }

        print("\n--- Elaborating: '\(selectedSentence2)' ---")
        if let elaboratedText2 = try await assistant.elaborate(text: selectedSentence2, context: documentContext) {
            print("Original: '\(selectedSentence2)'")
            print("Elaborated: '\(elaboratedText2)'")
        }
    } catch {
        print("Error with writing assistant: \(error.localizedDescription)")
    }
    print("----------------------------------------------------\n")
}

// To run this example in a playground or application:
// Task {
//     await demonstrateWritingAssistant()
// }
