
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

import Foundation

/// Custom errors for the SmartPhotoOrganizer.
enum SmartPhotoOrganizerError: LocalizedError {
    case modelNotFound(name: String)
    case modelLoadingFailed(underlyingError: Error)
    case modelNotLoaded
    case imageProcessingFailed(id: String, reason: String)
    case classificationFailed(id: String, reason: String)
    case photoLibraryAccessDenied

    var errorDescription: String? {
        switch self {
        case .modelNotFound(let name):
            return "Classification model '\(name).mlmodelc' not found in the app bundle. Please ensure it's included."
        case .modelLoadingFailed(let error):
            return "Failed to load the Core ML model: \(error.localizedDescription). Please check the model file."
        case .modelNotLoaded:
            return "The classification model has not been loaded. Please load the model before attempting classification."
        case .imageProcessingFailed(let id, let reason):
            return "Failed to process image \(id) for classification: \(reason)"
        case .classificationFailed(let id, let reason):
            return "Classification failed for image \(id): \(reason)"
        case .photoLibraryAccessDenied:
            return "Access to the photo library was denied. Please grant permission in Settings."
        }
    }
}
