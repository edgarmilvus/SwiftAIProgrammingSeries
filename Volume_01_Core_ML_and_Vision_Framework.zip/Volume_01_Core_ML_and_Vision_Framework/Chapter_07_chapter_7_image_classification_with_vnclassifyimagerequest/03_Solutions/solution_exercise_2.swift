
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Cocoa
import Vision

class BatchClassifierViewController: NSViewController {

    private let selectFolderButton = NSButton()
    private let resultsTextView = NSTextView()
    private let scrollView = NSScrollView()
    private let progressIndicator = NSProgressIndicator()

    // Supported image file extensions
    private let supportedImageExtensions: Set<String> = ["jpg", "jpeg", "png", "gif", "heic", "tiff", "webp"]

    override func loadView() {
        self.view = NSView()
        self.view.wantsLayer = true // Enable layer-backed views for better performance
        setupUI()
    }

    private func setupUI() {
        view.translatesAutoresizingMaskIntoConstraints = false

        // Select Folder Button Setup
        selectFolderButton.title = "Select Folder"
        selectFolderButton.target = self
        selectFolderButton.action = #selector(selectFolderTapped)
        selectFolderButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(selectFolderButton)

        // Progress Indicator Setup
        progressIndicator.style = .bar
        progressIndicator.isIndeterminate = false
        progressIndicator.isHidden = true
        progressIndicator.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(progressIndicator)

        // Results Text View Setup
        resultsTextView.isEditable = false
        resultsTextView.isSelectable = true
        resultsTextView.font = NSFont.monospacedSystemFont(ofSize: 12, weight: .regular)
        resultsTextView.string = "Click 'Select Folder' to begin batch classification."

        // Scroll View for Text View
        scrollView.hasVerticalScroller = true
        scrollView.documentView = resultsTextView
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)

        // Constraints
        NSLayoutConstraint.activate([
            selectFolderButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            selectFolderButton.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),

            progressIndicator.centerYAnchor.constraint(equalTo: selectFolderButton.centerYAnchor),
            progressIndicator.leadingAnchor.constraint(equalTo: selectFolderButton.trailingAnchor, constant: 20),
            progressIndicator.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            progressIndicator.heightAnchor.constraint(equalToConstant: 20),

            scrollView.topAnchor.constraint(equalTo: selectFolderButton.bottomAnchor, constant: 20),
            scrollView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            scrollView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    @objc private func selectFolderTapped() {
        let openPanel = NSOpenPanel()
        openPanel.canChooseFiles = false
        openPanel.canChooseDirectories = true
        openPanel.allowsMultipleSelection = false
        openPanel.prompt = "Choose Folder"

        openPanel.beginSheetModal(for: view.window!) { [weak self] response in
            guard let self = self else { return }
            if response == .OK, let folderURL = openPanel.url {
                Task { @MainActor in // Ensure UI updates are on the main actor
                    self.resultsTextView.string = "Processing images in: \(folderURL.lastPathComponent)...\n"
                    self.progressIndicator.isHidden = false
                    self.progressIndicator.doubleValue = 0
                    self.progressIndicator.maxValue = 1 // Will be updated after file count
                    self.selectFolderButton.isEnabled = false // Disable button during processing
                }
                await self.processFolder(folderURL)
                Task { @MainActor in
                    self.progressIndicator.isHidden = true
                    self.selectFolderButton.isEnabled = true
                }
            } else {
                Task { @MainActor in
                    self.resultsTextView.string = "Folder selection cancelled."
                }
            }
        }
    }

    private func processFolder(_ folderURL: URL) async {
        let fileManager = FileManager.default
        var imageFiles: [URL] = []

        do {
            let contents = try fileManager.contentsOfDirectory(at: folderURL, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])
            for url in contents {
                if supportedImageExtensions.contains(url.pathExtension.lowercased()) {
                    imageFiles.append(url)
                }
            }
        } catch {
            await MainActor.run {
                self.resultsTextView.string = "Error enumerating folder contents: \(error.localizedDescription)"
            }
            return
        }

        if imageFiles.isEmpty {
            await MainActor.run {
                self.resultsTextView.string = "No supported image files found in the selected folder."
            }
            return
        }

        await MainActor.run {
            self.progressIndicator.maxValue = Double(imageFiles.count)
            self.resultsTextView.string += "Found \(imageFiles.count) image(s). Classifying...\n\n"
        }

        var processedCount = 0
        // Use a TaskGroup for concurrent processing
        await withTaskGroup(of: (String, String?).self) { group in
            for fileURL in imageFiles {
                group.addTask { [weak self] in
                    guard let self = self else { return (fileURL.lastPathComponent, "Error: Self deallocated") }
                    let filename = fileURL.lastPathComponent
                    do {
                        guard let image = NSImage(contentsOf: fileURL) else {
                            return (filename, "Error: Could not load image.")
                        }
                        guard let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
                            return (filename, "Error: Could not convert image to CGImage.")
                        }

                        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
                        let request = VNClassifyImageRequest()
                        request.resultsLimit = 1 // Only need the top classification

                        try handler.perform([request])

                        guard let observations = request.results as? [VNClassificationObservation],
                              let topObservation = observations.first else {
                            return (filename, "No classification found.")
                        }

                        let confidencePercentage = String(format: "%.2f%%", topObservation.confidence * 100)
                        return (filename, "\(topObservation.identifier) (\(confidencePercentage))")

                    } catch {
                        return (filename, "Vision Error: \(error.localizedDescription)")
                    }
                }
            }

            for await result in group {
                let (filename, classification) = result
                await MainActor.run {
                    processedCount += 1
                    self.progressIndicator.doubleValue = Double(processedCount)
                    let output = "\(filename): \(classification ?? "Failed to classify")\n"
                    self.resultsTextView.textStorage?.append(NSAttributedString(string: output))
                    self.resultsTextView.scrollToEndOfDocument(nil) // Scroll to show latest results
                }
            }
        }
        await MainActor.run {
            self.resultsTextView.string += "\nBatch classification complete."
        }
    }
}
