
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import CoreData

class DataOptimizationService {
    let container: NSPersistentCloudKitContainer
    
    init(container: NSPersistentCloudKitContainer) {
        self.container = container
    }
    
    // 1. High-Performance Batch Ingestion
    func ingestHistoricalMessages(payload: [[String: Any]]) async throws {
        let context = container.newBackgroundContext()
        
        try await context.perform {
            // NSBatchInsertRequest works directly at the SQLite level
            let batchInsert = NSBatchInsertRequest(entityName: "Message", objects: payload)
            batchInsert.resultType = .statusOnly
            
            let result = try context.execute(batchInsert) as? NSBatchInsertResult
            if let success = result?.result as? Bool, success {
                print("Successfully ingested \(payload.count) messages.")
            }
        }
    }
    
    // 2. The Pruning Engine (Delete old embeddings)
    func pruneOldEmbeddings() async throws {
        let context = container.newBackgroundContext()
        
        try await context.perform {
            let thirtyDaysAgo = Calendar.current.date(byAdding: .day, value: -30, to: Date())!
            
            // Find embeddings where the parent message is older than 30 days
            let request: NSFetchRequest<NSFetchRequestResult> = MessageEmbedding.fetchRequest()
            request.predicate = NSPredicate(format: "message.timestamp < %@", thirtyDaysAgo as NSDate)
            
            let batchDelete = NSBatchDeleteRequest(fetchRequest: request)
            batchDelete.resultType = .resultTypeObjectIDs
            
            let result = try context.execute(batchDelete) as? NSBatchDeleteResult
            let objectIDs = result?.result as? [NSManagedObjectID] ?? []
            
            // Merge deletions into the main context so the UI updates
            let changes = [NSDeletedObjectsKey: objectIDs]
            NSManagedObjectContext.mergeChanges(fromRemoteContextSave: changes, into: [self.container.viewContext])
            
            print("Pruned \(objectIDs.count) old embeddings.")
        }
    }
}

// 3. UX Feedback: Sync Status Monitor
@MainActor
class SyncStatusManager: ObservableObject {
    @Published var isSyncing: Bool = false
    private var cancellables = Set<AnyCancellable>()
    
    init(container: NSPersistentCloudKitContainer) {
        NotificationCenter.default.publisher(for: NSPersistentCloudKitContainer.eventChangedNotification)
            .sink { notification in
                guard let event = notification.userInfo?[NSPersistentCloudKitContainer.eventNotificationUserInfoKey] 
                        as? NSPersistentCloudKitContainer.Event else { return }
                
                // Update UI based on whether a sync event is currently active
                Task { @MainActor in
                    // If an event is not finished, we are currently syncing
                    self.isSyncing = !event.isFinished
                }
            }
            .store(in: &cancellables)
    }
}
