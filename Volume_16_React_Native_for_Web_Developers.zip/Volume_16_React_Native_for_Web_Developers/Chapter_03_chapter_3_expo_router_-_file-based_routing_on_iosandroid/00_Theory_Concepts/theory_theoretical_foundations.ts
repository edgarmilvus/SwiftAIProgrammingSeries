/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph G {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#4F46E5", fontcolor="white"];
    edge [color="#333333"];

    subgraph cluster_0 {
        label = "Developer Source";
        style = "rounded,dashed";
        color = "#64748B";
        node [color="#4F46E5"];
        
        FS [label = "File System (app/)\n- index.tsx\n- users/[id].tsx\n- settings.tsx"];
    }

    subgraph cluster_1 {
        label = "Expo Router Compiler";
        style = "rounded,dashed";
        color = "#64748B";
        node [color="#0F766E"];
        
        Manifest [label = "Routing Manifest\n(Route Object Array)"];
    }

    subgraph cluster_2 {
        label = "Platform Specific Output";
        style = "rounded,dashed";
        color = "#64748B";
        
        node [color="#7C3AED"];
        Native [label = "Native Stack Config\n(React Navigation)"];
        
        node [color="#EA580C"];
        Web [label = "Web Router Config\n(React Router / Next.js)"];
    }

    FS -> Manifest [label = "Parses Structure"];
    Manifest -> Native [label = "Generates Native Stack"];
    Manifest -> Web [label = "Generates Web Routes"];
}
