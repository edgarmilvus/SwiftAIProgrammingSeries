
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// MARK: - Package Dependencies
/*
 [Package.swift]
 dependencies: [
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0"),
    .package(url: "https://github.com/apple/swift-collections", from: "1.1.0")
 ]
*/

import Foundation
import CloudKit
import CoreData
import Accelerate // For high-performance vector math
import OSLog

/// Represents the types of conflicts encountered in AI-driven semantic data.
enum SemanticConflictError: Error {
    case vectorDivergenceTooHigh(similarity: Float)
    case textualInconsistency(difference: String)
    case cloudKitError(CKError)
    case resolutionFailed(reason: String)
}

/// A high-level representation of an AI Memory for synchronization purposes.
/// In a real app, this would be mirrored in a Core Data Entity.
struct SemanticMemoryRecord: Codable, Sendable {
    let id: UUID
    var text: String
    var embedding: [Float]
    var importanceScore: Double
    var lastModified: Date
    var deviceID: String
}

/// The `SemanticResolutionActor` is a Swift 6 actor responsible for 
/// performing heavy mathematical and logic-based conflict resolution
/// off the main thread, ensuring thread safety for the sync engine.
@available(iOS 18.0, *)
actor SemanticResolutionActor {
    private let logger = Logger(subsystem: "com.aura.ai.sync", category: "ConflictResolution")
    
    /// Threshold for determining if two vectors are "close enough" to be considered the same concept.
    private let similarityThreshold: Float = 0.92
    
    /// Resolves a conflict between a local version and a server version of a memory.
    /// - Parameters:
    ///   - local: The version currently on the device.
    ///   - server: The version currently in CloudKit.
    /// - Returns: A resolved `SemanticMemoryRecord`.
    func resolve(local: SemanticMemoryRecord, server: SemanticMemoryRecord) async throws -> SemanticMemoryRecord {
        logger.info("Starting semantic resolution for memory: \(local.id)")
        
        // 1. Calculate Cosine Similarity between the two embeddings
        let similarity = cosineSimilarity(local.embedding, server.embedding)
        logger.debug("Calculated Cosine Similarity: \(similarity)")
        
        // 2. Decision Logic: Branching vs. Merging
        if similarity > similarityThreshold {
            // The concepts are the same, but the text or metadata might differ.
            // We perform a "Semantic Merge".
            return try await performSemanticMerge(local: local, server: server)
        } else {
            // The concepts have diverged significantly. 
            // This is a 'Branching' event. We should not overwrite; we should create a new record.
            // For this implementation, we throw an error to signal the UI to prompt a "Split Memory" action.
            throw SemanticConflictError.vectorDivergenceTooHigh(similarity: similarity)
        }
    }
    
    /// Performs a merge by prioritizing manual edits over AI-generated text.
    /// In a production app, this might call a local LLM (via CoreML) to synthesize a new text.
    private func performSemanticMerge(local: SemanticMemoryRecord, server: SemanticMemoryRecord) async throws -> SemanticMemoryRecord {
        // Heuristic: If the local text has a significantly different length or 
        // different characters, assume it's a manual user correction.
        let isLocalManualEdit = abs(local.text.count - server.text.count) > 5
        
        var resolvedText = server.text
        var resolvedImportance = server.importanceScore
        
        if isLocalManualEdit {
            logger.info("Local manual edit detected. Prioritizing local text.")
            resolvedText = local.text
            // We keep the server's embedding if it's newer, or re-calculate if we have the text.
            // For this demo, we take the most recent timestamp's metadata.
        }
        
        // Use the most recent timestamp for the metadata
        let latestDate = max(local.lastModified, server.lastModified)
        let latestImportance = max(local.importanceScore, server.importanceScore)
        
        // We prioritize the embedding from the record with the highest importance score
        // to ensure the vector space remains high-quality.
        let resolvedEmbedding = local.importanceScore >= server.importanceScore 
            ? local.embedding 
            : server.embedding

        return SemanticMemoryRecord(
            id: local.id,
            text: resolvedText,
            embedding: resolvedEmbedding,
            importanceScore: latestImportance,
            lastModified: latestDate,
            deviceID: local.deviceID // In a real app, track all contributing devices
        )
    }
    
    /// Computes the cosine similarity using Apple's Accelerate framework.
    /// This is critical for performance when dealing with 1536-dimension vectors.
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return 0.0 }
        
        var dotProduct: Float = 0.0
        var normA: Float = 0.0
        var normB: Float = 0.0
        
        // Use vDSP (Digital Signal Processing) for high-speed vector math
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        vDSP_svesq(a, 1, &normA, vDSP_Length(a.count))
        vDSP_svesq(b, 1, &normB, vDSP_Length(b.count))
        
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}

/// The `CloudKitSyncManager` manages the lifecycle of CloudKit operations.
/// It handles the specific error cases where a conflict is detected.
@available(iOS 18.0, *)
final class CloudKitSyncManager: ObservableObject {
    private let container: CKContainer
    private let database: CKDatabase
    private let resolver = SemanticResolutionActor()
    private let logger = Logger(subsystem: "com.aura.ai.sync", category: "SyncManager")
    
    init(containerIdentifier: String) {
        self.container = CKContainer(identifier: containerIdentifier)
        self.database = container.privateCloudDatabase
    }
    
    /// Attempts to save a record, handling conflicts via the Semantic Resolution Actor.
    /// - Parameter record: The CKRecord to save.
    /// - Parameter localMemory: The local semantic model to use for resolution.
    func saveMemory(record: CKRecord, localMemory: SemanticMemoryRecord) async throws {
        do {
            try await database.save(record)
            logger.info("Successfully saved record \(record.recordID)")
        } catch let error as CKError {
            // Check if the error is a conflict
            if error.code == .serverRecordChanged {
                try await handleConflict(error: error, localMemory: localMemory)
            } else {
                throw error
            }
        } catch {
            throw error
        }
    }
    
    /// Extracts the conflicting records from the CKError and invokes the resolver.
    private func handleConflict(error: CKError, localMemory: SemanticMemoryRecord) async throws {
        logger.warning("Conflict detected. Extracting records for semantic resolution.")
        
        // CKError.serverRecordChanged provides:
        // 1. The version currently on the server
        // 2. The version we attempted to save (the ancestor)
        // 3. The version we actually have locally
        guard let serverRecord = error.serverRecord,
              let ancestorRecord = error.ancestorRecord else {
            throw SemanticConflictError.resolutionFailed(reason: "Missing record data in CKError")
        }
        
        // Convert CKRecords back to our SemanticMemoryRecord domain model
        let serverMemory = mapToDomain(serverRecord)
        let localMemoryRef = localMemory // Already in domain model
        
        do {
            // Perform the heavy lifting in the Actor
            let resolvedMemory = try await resolver.resolve(local: localMemoryRef, server: serverMemory)
            
            // Convert the resolved domain model back to a CKRecord
            let resolvedRecord = mapToCloudKit(resolvedMemory, originalRecord: serverRecord)
            
            // Retry the save with the resolved record
            try await saveMemory(record: resolvedRecord, localMemory: resolvedMemory)
            logger.info("Conflict resolved successfully via semantic merge.")
            
        } catch SemanticConflictError.vectorDivergenceTooHigh(let similarity) {
            logger.error("Semantic Divergence too high (\(similarity)). Prompting user for branching.")
            // In a real app, trigger a UI event to ask the user:
            // "The AI detected two different ideas. Should we save them as separate memories?"
            throw SemanticConflictError.vectorDivergenceTooHigh(similarity: similarity)
        } catch {
            throw error
        }
    }
    
    // MARK: - Mapping Helpers
    
    private func mapToDomain(_ record: CKRecord) -> SemanticMemoryRecord {
        // In production, handle optionality and type casting carefully
        return SemanticMemoryRecord(
            id: UUID(uuidString: record["id"] as? String ?? "") ?? UUID(),
            text: record["text"] as? String ?? "",
            embedding: record["embedding"] as? [Float] ?? [],
            importanceScore: record["importance"] as? Double ?? 0.0,
            lastModified: record.modificationDate ?? Date(),
            deviceID: record["deviceID"] as? String ?? "unknown"
        )
    }
    
    private func mapToCloudKit(_ memory: SemanticMemoryRecord, originalRecord: CKRecord) -> CKRecord {
        // We must use the serverRecord as the base to ensure the 'etag' matches,
        // otherwise the next save will fail immediately.
        let record = originalRecord
        record["id"] = memory.id.uuidString
        record["text"] = memory.text
        record["embedding"] = memory.embedding
        record["importance"] = memory.importanceScore
        record["lastModified"] = memory.lastModified
        record["deviceID"] = memory.deviceID
        return record
    }
}
