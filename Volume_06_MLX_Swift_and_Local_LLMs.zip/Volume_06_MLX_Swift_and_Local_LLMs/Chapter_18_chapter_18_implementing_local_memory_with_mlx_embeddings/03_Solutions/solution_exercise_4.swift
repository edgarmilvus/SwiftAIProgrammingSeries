
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
struct JournalEntry: Identifiable, CustomStringConvertible {
    let id: UUID
    let timestamp: Date
    let text: String

    var description: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return "[\(formatter.string(from: timestamp))] \(text.prefix(50))..."
    }
}

@available(iOS 18.0, macOS 15.0, *)
class JournalEmbeddingStore {
    private var entries: [JournalEntry]
    // The main MLXArray containing all entry embeddings.
    // It's optional initially, becomes [N, D] after the first entry.
    private var embeddingsTensor: MLXArray?
    private let embeddingModel: MLXNN.Module
    private let embeddingDimension: Int

    init(embeddingModel: MLXNN.Module, embeddingDimension: Int) {
        self.entries = []
        self.embeddingModel = embeddingModel
        self.embeddingDimension = embeddingDimension
        print("JournalEmbeddingStore initialized.")
    }

    func addEntry(entry: JournalEntry) {
        // 1. Generate embedding for the new entry
        let entryDummyInput = entry.text.toDummyMLXInput()
        let newEmbedding = embeddingModel(entryDummyInput) // Shape [1, D]

        // 2. Add the JournalEntry to its internal array
        entries.append(entry)

        // 3. Efficient MLXArray Concatenation: Append the new embedding
        if let existingEmbeddings = embeddingsTensor {
            // Concatenate along axis 0 (batch dimension)
            embeddingsTensor = MLX.concatenate([existingEmbeddings, newEmbedding], axis: 0)
        } else {
            // First entry, initialize the tensor
            embeddingsTensor = newEmbedding
        }
        print("Added journal entry: \(entry.description)")
    }

    func search(query: String, topK: Int) -> [(JournalEntry, Float)] {
        guard let allEmbeddings = embeddingsTensor, !entries.isEmpty else {
            print("Journal is empty or embeddings not available for search.")
            return []
        }

        // 1. Generate query embedding
        let queryDummyInput = query.toDummyMLXInput()
        let queryEmbedding = embeddingModel(queryDummyInput)
        
        // Ensure queryEmbedding is 2D for consistent matmul
        let queryEmbedding2D = queryEmbedding.reshaped([1, embeddingDimension])

        // 2. Calculate cosine similarity against the entire MLXArray of stored embeddings
        let similarities = MLXArray.cosineSimilarity(a: queryEmbedding2D, b: allEmbeddings)
        
        // Convert to Swift array of Floats
        let similarityScores = similarities.flattened().toFloatArray()

        // 3. Pair entries with scores and sort
        let scoredEntries = zip(entries, similarityScores).map { (entry, score) in
            (entry, score)
        }
        
        let sortedResults = scoredEntries.sorted { $0.1 > $1.1 }

        // 4. Return topK results
        return Array(sortedResults.prefix(topK))
    }
}

// MARK: - Demonstration
@available(iOS 18.0, macOS 15.0, *)
func demonstrateIncrementalStore() {
    print("\n--- Exercise 3: Incremental Embedding Store ---")
    let embeddingDimension = 384

    do {
        let model = try EmbeddingModelLoader.loadSentenceTransformerModel(embeddingDimension: embeddingDimension)
        let journalStore = JournalEmbeddingStore(embeddingModel: model, embeddingDimension: embeddingDimension)

        // Add entries incrementally
        journalStore.addEntry(entry: JournalEntry(id: UUID(), timestamp: Date().addingTimeInterval(-86400 * 3), text: "Had a great weekend trip to the mountains. Saw some amazing wildlife and hiked a challenging trail."))
        journalStore.addEntry(entry: JournalEntry(id: UUID(), timestamp: Date().addingTimeInterval(-86400 * 2), text: "Started a new project at work focused on improving AI model performance on edge devices."))
        
        print("\n--- Search 1 ---")
        var results = journalStore.search(query: "weekend activities in nature", topK: 1)
        print("Top 1 result for 'weekend activities in nature':")
        for (entry, score) in results {
            print(String(format: "- %@ (Score: %.4f)", entry.description, score))
        }

        journalStore.addEntry(entry: JournalEntry(id: UUID(), timestamp: Date().addingTimeInterval(-86400 * 1), text: "Today I learned about MLX Swift and its unified memory architecture. Very impressive for Apple Silicon."))
        journalStore.addEntry(entry: JournalEntry(id: UUID(), timestamp: Date(), text: "Reviewed the progress on the AI project. Facing some challenges with data preprocessing but making good progress."))

        print("\n--- Search 2 ---")
        results = journalStore.search(query: "AI development challenges", topK: 2)
        print("Top 2 results for 'AI development challenges':")
        for (entry, score) in results {
            print(String(format: "- %@ (Score: %.4f)", entry.description, score))
        }
        
        print("\n--- Search 3 ---")
        results = journalStore.search(query: "Apple's machine learning framework", topK: 1)
        print("Top 1 result for 'Apple's machine learning framework':")
        for (entry, score) in results {
            print(String(format: "- %@ (Score: %.4f)", entry.description, score))
        }

    } catch {
        print("Error loading model: \(error)")
    }
}

// Call the demonstration function
// demonstrateIncrementalStore() // Uncomment to run
