
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import Observation // Required for @Observable

    // @available(iOS 17.0, *) indicates this feature is available from iOS 17.0 onwards.
    // For Swift 6, this is a standard feature.
    @available(iOS 17.0, *)
    @Observable
    class AIModelPredictionState {
        var predictionLabel: String
        var confidenceScore: Double // This property is automatically observed
        var modelOutput: [Double] // e.g., raw probabilities

        init(predictionLabel: String, confidenceScore: Double, modelOutput: [Double]) {
            self.predictionLabel = predictionLabel
            self.confidenceScore = confidenceScore
            self.modelOutput = modelOutput
        }

        func update(newConfidence: Double, newLabel: String, newOutput: [Double]) {
            // Updating these properties will automatically notify observing views
            self.confidenceScore = newConfidence
            self.predictionLabel = newLabel
            self.modelOutput = newOutput
        }
    }

    @available(iOS 17.0, *)
    struct ConfidenceBarView: View {
        // The view observes changes to the AIModelPredictionState instance
        @State var predictionState: AIModelPredictionState

        var body: some View {
            VStack {
                Text("Prediction: \(predictionState.predictionLabel)")
                ProgressView(value: predictionState.confidenceScore, total: 1.0)
                    .progressViewStyle(.linear)
                    .tint(confidenceColor(for: predictionState.confidenceScore))
                    .animation(.easeInOut(duration: 0.5), value: predictionState.confidenceScore) // Smooth animation
                Text(String(format: "Confidence: %.1f%%", predictionState.confidenceScore * 100))
            }
            .padding()
            .onAppear {
                // Simulate real-time updates from an AI model
                Task {
                    for i in 0...10 {
                        let newConfidence = Double(i) / 10.0
                        await Task.sleep(for: .milliseconds(300))
                        // Ensure UI updates are on the main actor if not implicitly handled by @Observable
                        await MainActor.run {
                            predictionState.update(newConfidence: newConfidence, newLabel: "Simulated", newOutput: [])
                        }
                    }
                }
            }
        }

        private func confidenceColor(for score: Double) -> Color {
            if score > 0.8 { return .green }
            if score > 0.5 { return .orange }
            return .red
        }
    }
    