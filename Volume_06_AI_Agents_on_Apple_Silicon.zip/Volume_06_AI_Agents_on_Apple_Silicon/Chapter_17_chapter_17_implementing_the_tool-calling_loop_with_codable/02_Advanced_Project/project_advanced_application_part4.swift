
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

// MARK: - 3. Custom Error Types

@available(macOS 15.0, *)
enum SmartHomeError: Error, LocalizedError {
    case toolNotFound(String)
    case invalidToolArguments(toolName: String, decodingError: Error)
    case toolExecutionFailed(toolName: String, message: String)
    case llmResponseParsingFailed(Error)
    case llmCommunicationFailed(Error)
    case noToolsCalled

    var errorDescription: String? {
        switch self {
        case .toolNotFound(let name):
            return "Tool '\(name)' was requested but not found or implemented."
        case .invalidToolArguments(let toolName, let decodingError):
            return "Failed to decode arguments for tool '\(toolName)': \(decodingError.localizedDescription)"
        case .toolExecutionFailed(let toolName, let message):
            return "Tool '\(toolName)' failed to execute: \(message)"
        case .llmResponseParsingFailed(let error):
            return "Failed to parse LLM response: \(error.localizedDescription)"
        case .llmCommunicationFailed(let error):
            return "LLM communication error: \(error.localizedDescription)"
        case .noToolsCalled:
            return "LLM did not suggest any tools to call."
        }
    }
}
