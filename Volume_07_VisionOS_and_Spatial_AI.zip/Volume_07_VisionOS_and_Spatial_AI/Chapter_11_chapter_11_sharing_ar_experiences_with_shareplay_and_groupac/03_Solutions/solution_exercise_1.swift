
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import GroupActivities

/// Represents the visual atmosphere of the shared mood board.
enum MoodTheme: String, Codable, Sendable {
    case calm
    case energetic
    case focused
}

/// The shared state object that defines the environment settings.
/// Conforms to Sendable to ensure safety across concurrency boundaries.
struct MoodBoardConfiguration: Codable, Sendable {
    let theme: MoodTheme
    let globalIntensity: Float
}

/// The GroupActivity definition that the system uses to identify the session.
struct MoodBoardActivity: GroupActivity {
    var targetConfiguration: GroupActivityConfiguration {
        // We use a custom configuration to carry our Codable state.
        GroupActivityConfiguration(metadata: [
            "theme": MoodBoardConfiguration(theme: .calm, globalIntensity: 0.5).theme.rawValue.data(using: .utf8)!
        ])
    }
    
    // A unique identifier for the activity type.
    static let activityIdentifier = ActivityIdentifier("com.spatial.moodboard.shared-state")
    
    // The actual data payload that will be synchronized via SharePlay.
    var configuration: MoodBoardConfiguration
    
    init(configuration: MoodBoardConfiguration) {
        self.configuration = configuration
    }
}
