
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Combine // For AnyCancellable if using older ObservableObject

// Re-using the TrainingState enum from the MLManager actor example
@available(iOS 18.0, *)
@Observable
class TrainingViewModel {
    var trainingState: MLManager.TrainingState = .idle
    private let mlManager = MLManager() // The actor instance

    init() {
        // In a real app, the actor would push updates to this ViewModel.
        // For demonstration, let's simulate the actor's state changes.
        // A more robust solution might involve the actor publishing updates via AsyncStream.
        Task {
            // This is a simplified, conceptual example.
            // A production-ready actor would expose an AsyncStream or similar for observation.
            // For now, imagine the actor pushes updates.
            await MainActor.run { self.trainingState = .loadingData }
            try await Task.sleep(for: .seconds(1))
            await MainActor.run { self.trainingState = .training(progress: 0.2, message: "Loading data...") }
            try await Task.sleep(for: .seconds(2))
            await MainActor.run { self.trainingState = .training(progress: 0.5, message: "Epoch 5/10") }
            try await Task.sleep(for: .seconds(2))
            await MainActor.run { self.trainingState = .training(progress: 0.9, message: "Saving model...") }
            try await Task.sleep(for: .seconds(1))
            // Assuming a successful training, we'd get the model here
            let dummyModel = try! await MLImageClassifier.train(dataSource: .labeledDirectories(at: URL(fileURLWithPath: "/dev/null")), parameters: .init())
            await MainActor.run { self.trainingState = .trained(dummyModel) }
        }
    }

    func startTrainingProcess() {
        Task {
            if let dataURL = Bundle.main.url(forResource: "TrainingData", withExtension: nil) {
                await mlManager.startTraining(dataDirectory: dataURL, modelName: "MyCustomModel")
                // After the actor completes, you'd fetch its final state or it would push it.
                await MainActor.run {
                    self.trainingState = mlManager.currentTrainingState // Direct access from actor is unsafe, use actor method
                }
            } else {
                await MainActor.run { self.trainingState = .failed(NSError(domain: "App", code: 0, userInfo: [NSLocalizedDescriptionKey: "Data not found"])) }
            }
        }
    }
}

@available(iOS 18.0, *)
struct TrainingView: View {
    @State private var viewModel = TrainingViewModel()

    var body: some View {
        VStack {
            Text("Model Training Status")
                .font(.headline)
                .padding()

            switch viewModel.trainingState {
            case .idle:
                Text("Ready to train.")
                Button("Start Training") {
                    viewModel.startTrainingProcess()
                }
            case .loadingData:
                ProgressView("Loading data...")
            case .training(let progress, let message):
                ProgressView(message, value: progress, total: 1.0)
                    .padding()
                Text(String(format: "Progress: %.1f%%", progress * 100))
            case .trained(_):
                Text("Model trained successfully!")
                    .foregroundColor(.green)
                Button("Use Model") {
                    // Navigate to inference view or similar
                }
            case .failed(let error):
                Text("Training failed: \(error.localizedDescription)")
                    .foregroundColor(.red)
                Button("Retry") {
                    viewModel.startTrainingProcess()
                }
            }
        }
    }
}
