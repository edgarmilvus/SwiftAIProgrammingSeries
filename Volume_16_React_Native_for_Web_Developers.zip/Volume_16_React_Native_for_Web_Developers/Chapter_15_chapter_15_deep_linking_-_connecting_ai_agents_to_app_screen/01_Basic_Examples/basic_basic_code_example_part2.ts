/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/_layout.tsx

import { Stack, useRouter, useLocalSearchParams } from 'expo-router';
import { useEffect } from 'react';
import { Linking } from 'expo-linking';

export default function RootLayout() {
  const router = useRouter();
  
  // 1. Define the App's Deep Link Scheme
  // This must match the 'scheme' in your app.json or app.config.js
  const scheme = 'myapp';

  useEffect(() => {
    // 2. Listen for incoming URLs (Deep Links)
    const handleDeepLink = ({ url }: { url: string }) => {
      console.log('Incoming URL:', url);
      
      // 3. Parse the URL to extract screen and params
      // Example URL: myapp://reports?id=42&type=financial
      const { pathname, queryParams } = Linking.parse(url);

      if (pathname) {
        // 4. Navigate to the specific screen with parameters
        // We strip the leading slash if present (e.g., '/reports' -> 'reports')
        const screenName = pathname.startsWith('/') ? pathname.slice(1) : pathname;
        
        router.push({
          pathname: `/${screenName}` as any, // Cast to any to satisfy TS for dynamic paths
          params: queryParams
        });
      }
    };

    // Subscribe to linking events
    const subscription = Linking.addEventListener('url', handleDeepLink);

    // Check if the app was opened via a deep link initially
    Linking.getInitialURL().then((url) => {
      if (url) handleDeepLink({ url });
    });

    return () => subscription.remove();
  }, [router]);

  return (
    <Stack>
      <Stack.Screen name="index" options={{ title: 'Home' }} />
      <Stack.Screen name="reports" options={{ title: 'Financial Report' }} />
      <Stack.Screen name="profile" options={{ title: 'User Profile' }} />
    </Stack>
  );
}
