
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import AVFoundation // For camera access and preview layers

// MARK: - 1. Custom UIView to Host the Camera Preview Layer

/// A custom UIView subclass that hosts the AVCaptureVideoPreviewLayer.
/// This view is designed to be embedded within a SwiftUI view using UIViewRepresentable.
@available(iOS 13.0, *) // AVCaptureSession and SwiftUI are available from iOS 13.0
class CameraPreviewView: UIView {
    /// The AVCaptureSession instance that manages camera input and output.
    /// This session is responsible for capturing video from the camera.
    private var session: AVCaptureSession?

    /// Overrides the default layer class to use AVCaptureVideoPreviewLayer.
    /// This tells the view that its primary layer should be a video preview layer,
    /// which is optimized for displaying camera feeds.
    override class var layerClass: AnyClass {
        return AVCaptureVideoPreviewLayer.self
    }

    /// Convenience getter for the view's layer, cast to AVCaptureVideoPreviewLayer.
    /// This allows easy access to the preview layer's properties, such as its session.
    var videoPreviewLayer: AVCaptureVideoPreviewLayer {
        return layer as! AVCaptureVideoPreviewLayer
    }

    /// Initializes the CameraPreviewView with a given AVCaptureSession.
    /// - Parameter session: The AVCaptureSession to associate with this preview view.
    init(session: AVCaptureSession) {
        self.session = session
        super.init(frame: .zero) // Initialize with a zero frame, SwiftUI will manage layout.
        self.videoPreviewLayer.session = session // Link the preview layer to the capture session.
        self.videoPreviewLayer.videoGravity = .resizeAspectFill // Scale video to fill the layer's bounds.
    }

    /// Required initializer for UIView, not used in this SwiftUI context.
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    /// Starts the AVCaptureSession on a background queue.
    /// Session operations should not block the main thread.
    func startSession() {
        // Ensure the session is not nil and not already running.
        guard let session = session, !session.isRunning else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            session.startRunning() // Start the camera capture.
        }
    }

    /// Stops the AVCaptureSession on a background queue.
    func stopSession() {
        guard let session = session, session.isRunning else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            session.stopRunning() // Stop the camera capture.
        }
    }
}

// MARK: - 2. UIViewRepresentable Wrapper for SwiftUI

/// A SwiftUI view that wraps the CameraPreviewView to display a live camera feed.
/// This struct conforms to UIViewRepresentable, making a UIKit UIView available in SwiftUI.
@available(iOS 13.0, *)
struct CameraPreviewRepresentable: UIViewRepresentable {
    /// The AVCaptureSession instance shared with the CameraPreviewView.
    @Binding var session: AVCaptureSession?

    /// Creates and configures the CameraPreviewView.
    /// This method is called once by SwiftUI to instantiate the underlying UIKit view.
    /// - Parameter context: The context struct containing information about the current state of the representable.
    /// - Returns: An instance of CameraPreviewView.
    func makeUIView(context: Context) -> CameraPreviewView {
        // Ensure a session is available. If not, create a dummy one or handle error.
        // For this basic example, we assume `session` is provided externally.
        guard let session = session else {
            // In a real app, you might want to show an error view or a placeholder.
            print("Error: AVCaptureSession is nil in makeUIView.")
            return CameraPreviewView(session: AVCaptureSession()) // Provide a dummy session to prevent crash
        }
        let previewView = CameraPreviewView(session: session)
        return previewView
    }

    /// Updates the CameraPreviewView.
    /// This method is called when SwiftUI detects changes in the data passed to the representable.
    /// For a basic camera preview, we might not need to do much here, as session management
    /// is handled by the CameraPreviewView itself or its parent SwiftUI view.
    /// - Parameters:
    ///   - uiView: The current instance of CameraPreviewView to update.
    ///   - context: The context struct.
    func updateUIView(_ uiView: CameraPreviewView, context: Context) {
        // If the session changes (e.g., switching cameras), update the preview layer.
        if uiView.videoPreviewLayer.session != session {
            uiView.videoPreviewLayer.session = session
        }
    }

    // MARK: - Coordinator (Optional for basic cases, but good practice)
    // A Coordinator can be used to facilitate communication between the UIKit view
    // and the SwiftUI view. For instance, if the CameraPreviewView needed to send
    // delegate messages back to SwiftUI, the Coordinator would handle them.
    // For this basic example, we don't need a Coordinator as there's no complex
    // two-way communication.
}

// MARK: - 3. SwiftUI ViewModel/Manager for Camera Setup

/// A class to manage the AVCaptureSession lifecycle and camera authorization.
/// This class acts as a bridge between SwiftUI and AVFoundation, handling permissions
/// and session configuration.
@available(iOS 13.0, *)
class CameraManager: NSObject, ObservableObject {
    /// The AVCaptureSession instance. Published so SwiftUI views can react to changes.
    @Published var session: AVCaptureSession?
    /// Published property to indicate camera authorization status.
    @Published var isAuthorized: Bool = false
    /// Published property to store any authorization error message.
    @Published var authorizationError: String?

    /// A background queue for AVFoundation operations to avoid blocking the main thread.
    private let sessionQueue = DispatchQueue(label: "session queue", qos: .userInitiated)

    override init() {
        super.init()
        checkCameraAuthorization()
    }

    /// Checks and requests camera authorization.
    @MainActor // UI updates (like setting authorizationError) should be on the main actor.
    func checkCameraAuthorization() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            isAuthorized = true
            setupSession() // Setup session only if authorized
        case .notDetermined:
            // Request authorization on a background queue to not block UI.
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                DispatchQueue.main.async { // Update UI on main thread
                    self?.isAuthorized = granted
                    if granted {
                        self?.setupSession()
                    } else {
                        self?.authorizationError = "Camera access denied. Please enable it in Settings."
                    }
                }
            }
        case .denied, .restricted:
            isAuthorized = false
            authorizationError = "Camera access denied or restricted. Please enable it in Settings."
        @unknown default:
            isAuthorized = false
            authorizationError = "Unknown camera authorization status."
        }
    }

    /// Sets up the AVCaptureSession with camera input.
    private func setupSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            let newSession = AVCaptureSession()
            newSession.beginConfiguration() // Begin configuration changes

            // Try to add back camera input
            guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
                DispatchQueue.main.async {
                    self.authorizationError = "Failed to find a suitable camera device."
                }
                newSession.commitConfiguration()
                return
            }

            guard let videoDeviceInput = try? AVCaptureDeviceInput(device: videoDevice) else {
                DispatchQueue.main.async {
                    self.authorizationError = "Failed to create video device input."
                }
                newSession.commitConfiguration()
                return
            }

            if newSession.canAddInput(videoDeviceInput) {
                newSession.addInput(videoDeviceInput)
            } else {
                DispatchQueue.main.async {
                    self.authorizationError = "Could not add video device input to the session."
                }
                newSession.commitConfiguration()
                return
            }

            newSession.commitConfiguration() // Commit all configuration changes
            DispatchQueue.main.async {
                self.session = newSession // Update the published session on the main thread
                // The CameraPreviewRepresentable will now pick up this session and start running it.
            }
        }
    }

    /// Starts the camera session when the view appears.
    func startSession() {
        sessionQueue.async { [weak self] in
            self?.session?.startRunning()
        }
    }

    /// Stops the camera session when the view disappears.
    func stopSession() {
        sessionQueue.async { [weak self] in
            self?.session?.stopRunning()
        }
    }
}

// MARK: - 4. SwiftUI View to Display the Camera Preview

/// The main SwiftUI view that integrates the camera preview.
@available(iOS 13.0, *)
struct CameraView: View {
    /// An observed object to manage camera session and authorization.
    @StateObject private var cameraManager = CameraManager()

    var body: some View {
        VStack {
            if cameraManager.isAuthorized {
                if let session = cameraManager.session {
                    // Display the CameraPreviewRepresentable if authorized and session is available.
                    CameraPreviewRepresentable(session: $cameraManager.session)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .onAppear {
                            // Start the session when the view appears.
                            // The CameraPreviewView itself will call startRunning() on its session.
                            // However, explicit start/stop from the manager ensures proper lifecycle.
                            cameraManager.startSession()
                        }
                        .onDisappear {
                            // Stop the session when the view disappears to save battery.
                            cameraManager.stopSession()
                        }
                } else {
                    // Show a loading indicator while the session is being set up.
                    ProgressView("Setting up camera...")
                        .font(.headline)
                }
            } else if let error = cameraManager.authorizationError {
                // Show an error message if camera access is denied.
                Text(error)
                    .foregroundColor(.red)
                    .padding()
                    .multilineTextAlignment(.center)
            } else {
                // Initial state while authorization is being checked.
                Text("Requesting camera access...")
                    .font(.headline)
            }
        }
        .navigationTitle("AI Camera Preview") // For navigation stacks
        .onAppear {
            // Check authorization status when the view appears.
            // This ensures status is re-checked if user changes settings.
            cameraManager.checkCameraAuthorization()
        }
    }
}

// MARK: - 5. App Entry Point (for Xcode Previews and App Launch)

@main
@available(iOS 13.0, *)
struct AICameraApp: App {
    var body: some Scene {
        WindowGroup {
            CameraView()
        }
    }
}

// MARK: - Required Info.plist Entry
/*
 To make this app work, you MUST add the following key to your app's Info.plist file:

 Key: Privacy - Camera Usage Description
 Value: We need access to your camera to provide a live video feed for AI analysis.
 */

