
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import ARKit
import RealityKit
import Vision

struct PostItView: View {
    let text: String
    var body: some View {
        Text(text)
            .padding()
            .background(.yellow.opacity(0.8))
            .cornerRadius(8)
            .shadow(radius: 5)
    }
}

@MainActor
class SpatialReaderManager: NSObject, ARSessionDelegate {
    var arView: ARView?
    var attachments: [UUID: Entity] = [:]

    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        // In a production app, throttle this to ~5-10 FPS
        performOCR(on: frame)
    }

    private func performOCR(on frame: ARFrame) {
        let request = VNRecognizeTextRequest { [weak self] request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation] else { return }
            Task { @MainActor in
                await self?.processTextObservations(observations, in: frame)
            }
        }
        request.recognitionLevel = .accurate
        
        let handler = VNImageRequestHandler(cvPixelBuffer: frame.capturedImage, orientation: .up, options: [:])
        try? handler.perform([request])
    }

    private func processTextObservations(_ observations: [VNRecognizedTextObservation], in frame: ARFrame) async {
        guard let arView = arView else { return }

        for observation in observations {
            let text = observation.topCandidates(1).first?.string ?? ""
            let rect = observation.boundingBox
            
            // Convert center of text box to screen point
            let center = CGPoint(x: rect.midX, y: 1 - rect.midY) 
            let screenPoint = CGPoint(x: center.x * Float(arView.bounds.width), 
                                      y: center.y * Float(arView.bounds.height))

            if let result = arView.raycast(from: screenPoint, allowing: .estimatedPlane, alignment: .any).first {
                createPostIt(at: result.worldTransform, text: text, in: arView)
            }
        }
    }

    private func createPostIt(at transform: simd_float4x4, text: String, in arView: ARView) {
        // 1. Create the Attachment Entity
        let attachmentID = UUID()
        let entity = Entity()
        
        // In visionOS, we use ViewAttachmentEntity to host SwiftUI
        // This is a simplified representation of the attachment logic
        let postIt = ViewAttachmentEntity(id: attachmentID, content: PostItView(text: text))
        entity.addChild(postIt)
        
        // 2. Anchor it
        let anchor = AnchorEntity(world: transform)
        anchor.addChild(entity)
        arView.scene.addAnchor(anchor)
        
        attachments[attachmentID] = entity
    }

    // Billboarding Logic: Called every frame via a DisplayLink or Scene Update
    func updateBillboarding(cameraTransform: simd_float4x4) {
        for entity in attachments.values {
            // Calculate vector from entity to camera
            let entityPos = entity.position(relativeTo: nil)
            let cameraPos = simd_make_float3(cameraTransform.columns.3)
            let direction = simd_normalize(cameraPos - entityPos)
            
            // Create a rotation that looks at the camera
            // We want the Z-axis (forward) of the entity to point at the camera
            let lookAtTransform = simd_quaternion(direction, [0, 0, 1]) 
            entity.orientation = lookAtTransform
        }
    }
}
