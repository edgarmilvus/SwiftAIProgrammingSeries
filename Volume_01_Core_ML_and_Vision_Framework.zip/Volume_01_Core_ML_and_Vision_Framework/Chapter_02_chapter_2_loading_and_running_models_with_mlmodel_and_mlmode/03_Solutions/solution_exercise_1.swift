
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CoreML
import Vision
import UIKit

// MARK: - Utility Extension for UIImage to CVPixelBuffer Conversion

extension UIImage {
    /// Converts a UIImage to a CVPixelBuffer, resizing it to the targetSize and ensuring the specified pixel format.
    /// This is a common utility function for Core ML image inputs.
    func toCVPixelBuffer(targetSize: CGSize, pixelFormat: OSType = kCVPixelFormatType_32BGRA) -> CVPixelBuffer? {
        let width = Int(targetSize.width)
        let height = Int(targetSize.height)

        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(nil, width, height, pixelFormat, nil, &pixelBuffer)

        guard status == kCVReturnSuccess, let buffer = pixelBuffer else {
            print("Error creating CVPixelBuffer: \(status)")
            return nil
        }

        CVPixelBufferLockBaseAddress(buffer, .readOnly) // Lock for writing, then unlock
        defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }

        let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue // BGRA format
        )

        guard let cgImage = self.cgImage else {
            print("Failed to get CGImage from UIImage.")
            return nil
        }

        // Draw the image into the context, resizing it
        context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        return buffer
    }
}

// MARK: - ImageClassifier Class

@available(iOS 17.0, *) // Using iOS 17.0 as a reasonable baseline for modern Core ML features
class ImageClassifier {
    private var model: MLModel?
    private let modelInputName: String
    private let modelOutputName: String
    private let modelImageSize: CGSize

    /// Initializes the ImageClassifier with a model URL and expected input/output details.
    /// - Parameters:
    ///   - modelURL: The URL to the compiled Core ML model (.mlmodelc).
    ///   - inputName: The name of the image input feature in the model (e.g., "image").
    ///   - outputName: The name of the classification output feature (e.g., "classLabel").
    ///   - imageSize: The expected input image size for the model (e.g., 224x224).
    init(modelURL: URL, inputName: String, outputName: String, imageSize: CGSize) {
        self.modelInputName = inputName
        self.modelOutputName = outputName
        self.modelImageSize = imageSize
        do {
            self.model = try MLModel(contentsOf: modelURL)
            print("Model loaded successfully from \(modelURL.lastPathComponent).")
        } catch {
            print("Error loading model from \(modelURL.lastPathComponent): \(error.localizedDescription)")
            self.model = nil
        }
    }

    /// Classifies a given UIImage and returns the top prediction and its confidence.
    /// - Parameter image: The UIImage to classify.
    /// - Returns: A tuple containing the class label and confidence, or nil if classification fails.
    func classifyImage(_ image: UIImage) -> (label: String, confidence: Double)? {
        guard let model = model else {
            print("Model not loaded. Cannot classify.")
            return nil
        }

        // 1. Convert UIImage to CVPixelBuffer
        guard let pixelBuffer = image.toCVPixelBuffer(targetSize: modelImageSize) else {
            print("Failed to convert UIImage to CVPixelBuffer.")
            return nil
        }

        do {
            // 2. Create an MLFeatureProvider from the CVPixelBuffer
            let inputFeatures = try MLDictionaryFeatureProvider(dictionary: [modelInputName: MLFeatureValue(pixelBuffer: pixelBuffer)])

            // 3. Perform prediction
            let prediction = try model.prediction(input: inputFeatures)

            // 4. Interpret the output
            guard let classLabel = prediction.featureValue(forName: modelOutputName)?.stringValue else {
                print("Could not find expected output feature '\(modelOutputName)'.")
                return nil
            }

            // For models that provide probabilities, the output name might be different (e.g., "classLabelProbs")
            // and its value would be an MLMultiArray or MLDictionaryFeatureProvider.
            // This example assumes a direct string output for the label and looks for a corresponding probability dictionary.
            let confidenceKey = modelOutputName + "Probs" // Common naming convention for probabilities
            if let probabilities = prediction.featureValue(forName: confidenceKey)?.dictionaryValue as? [String: Double],
               let confidence = probabilities[classLabel] {
                return (label: classLabel, confidence: confidence)
            } else {
                // Fallback if probabilities are not directly available or named differently
                print("Warning: Could not find confidence for class '\(classLabel)'. Returning default confidence 1.0.")
                return (label: classLabel, confidence: 1.0)
            }

        } catch {
            print("Error during prediction: \(error.localizedDescription)")
            return nil
        }
    }
}

// MARK: - Example Usage in a ViewController or App Delegate

@available(iOS 17.0, *)
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        performClassification()
    }

    private func setupUI() {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(named: "sampleImage") // Make sure "sampleImage" is in your Assets.xcassets
        imageView.backgroundColor = .secondarySystemBackground
        imageView.layer.cornerRadius = 8
        imageView.clipsToBounds = true

        let resultLabel = UILabel()
        resultLabel.textAlignment = .center
        resultLabel.numberOfLines = 0
        resultLabel.font = .preferredFont(forTextStyle: .headline)
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        resultLabel.tag = 100 // Use a tag to easily find it later

        let stackView = UIStackView(arrangedSubviews: [imageView, resultLabel])
        stackView.axis = .vertical
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalToConstant: 250)
        ])
    }

    private func performClassification() {
        // IMPORTANT: Replace "MobileNetV3" with the actual name of your .mlmodelc file
        // and adjust input/output names and image size according to your model's specification.
        // For MobileNetV3 (from Apple's Core ML Models gallery):
        // Input: "image" (Image, 224x224, BGRA)
        // Output: "classLabel" (String), "classLabelProbs" (Dictionary<String, Double>)

        guard let modelURL = Bundle.main.url(forResource: "MobileNetV3", withExtension: "mlmodelc") else {
            print("Error: MobileNetV3.mlmodelc not found in bundle.")
            return
        }

        let classifier = ImageClassifier(
            modelURL: modelURL,
            inputName: "image",
            outputName: "classLabel",
            imageSize: CGSize(width: 224, height: 224)
        )

        guard let imageToClassify = UIImage(named: "sampleImage") else {
            print("Error: 'sampleImage' asset not found.")
            return
        }

        if let (label, confidence) = classifier.classifyImage(imageToClassify) {
            let resultText = "Prediction: \(label)\nConfidence: \(String(format: "%.2f", confidence * 100))%"
            print(resultText)
            if let resultLabel = view.viewWithTag(100) as? UILabel {
                resultLabel.text = resultText
            }
        } else {
            print("Classification failed.")
            if let resultLabel = view.viewWithTag(100) as? UILabel {
                resultLabel.text = "Classification Failed!"
            }
        }
    }
}

// To run this example:
// 1. Create a new iOS project.
// 2. Drag a compiled Core ML model (e.g., MobileNetV3.mlmodelc) into your project.
//    (You can download MobileNetV3 from Apple's Core ML Models website).
// 3. Add an image named "sampleImage" to your Assets.xcassets.
// 4. Replace the contents of your ViewController.swift with the code above.
