
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import AppTrackingTransparency
import Observation

/// Represents the level of data access the AI engine is permitted to use.
/// This is a Sendable enum to ensure safe transfer across concurrency boundaries.
@Sendable
enum PrivacyLevel: Sendable {
    case restricted // No third-party data allowed, strictly on-device/first-party
    case enhanced   // IDFA/Third-party signals allowed for personalization
}

/// A thread-safe actor that manages the application's privacy state.
/// This prevents data races when the user changes settings mid-inference.
actor PrivacyManager {
    @ObservationIgnored
    private(set) var currentLevel: PrivacyLevel = .restricted
    
    /// Updates the privacy level based on the current ATT status.
    /// @available(iOS 18.0, *)
    @available(iOS 18.0, *)
    func refreshPrivacyStatus() async {
        // In a real app, we would check ATTrackingManager.trackingAuthorizationStatus
        let status = ATTrackingManager.trackingAuthorizationStatus
        
        switch status {
        case .authorized:
            currentLevel = .enhanced
        case .denied, .restricted, .notDetermined:
            currentLevel = .restricted
        @unknown default:
            currentLevel = .restricted
        }
    }
    
    func getPrivacyLevel() -> PrivacyLevel {
        return currentLevel
    }
}

/// The core engine responsible for AI inference.
/// It is isolated to its own actor to ensure heavy computations don't block the UI.
actor AIInferenceEngine {
    private let privacyManager: PrivacyManager
    
    init(privacyManager: PrivacyManager) {
        self.privacyManager = privacyManager
    }
    
    /// Performs inference, adjusting the model's behavior based on privacy constraints.
    func generatePersonalizedResponse(prompt: String) async throws -> String {
        let privacy = await privacyManager.getPrivacyLevel()
        
        if privacy == .enhanced {
            return try await performEnhancedInference(prompt: prompt)
        } else {
            return try await performGenericInference(prompt: prompt)
        }
    }
    
    @available(iOS 18.0, *)
    private func performEnhancedInference(prompt: String) async throws -> String {
        // Here, we would include the IDFA or cross-app interest vectors
        // in the prompt context or as part of the embedding lookup.
        print("Executing high-fidelity inference with cross-app signals...")
        return "Personalized response based on your interests."
    }
    
    @available(iOS 18.0, *)
    private func performGenericInference(prompt: String) async throws -> String {
        // Strictly using on-device, first-party data.
        print("Executing privacy-preserving generic inference...")
        return "General response based on current session only."
    }
}

/// The ViewModel that bridges the PrivacyManager and the UI using @Observable.
@Observable
@MainActor
class AIViewModel {
    var response: String = ""
    var privacyLevelLabel: String = "Checking..."
    
    private let privacyManager: PrivacyManager
    private let engine: AIInferenceEngine
    
    init(privacyManager: PrivacyManager, engine: AIInferenceEngine) {
        self.privacyManager = privacyManager
        self.engine = engine
    }
    
    func updateStatus() async {
        await privacyManager.refreshPrivacyStatus()
        let level = await privacyManager.getPrivacyLevel()
        self.privacyLevelLabel = level == .enhanced ? "Enhanced Mode" : "Privacy Mode"
    }
    
    func askAI(prompt: String) async {
        do {
            self.response = try await engine.generatePersonalizedResponse(prompt: prompt)
        } catch {
            self.response = "Error generating response."
        }
    }
}
