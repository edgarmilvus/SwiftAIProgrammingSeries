
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

        import CreateML
        import Foundation // For URL, Measurement

        @available(iOS 18.0, *) // Create ML updates often align with OS releases
        struct HyperparameterTrialResult: Sendable {
            let learningRate: Double
            let batchSize: Int
            let validationAccuracy: Double
            let modelURL: URL? // URL to the trained model
        }

        @available(iOS 18.0, *)
        actor HyperparameterTuner {
            private var bestResult: HyperparameterTrialResult?
            private var results: [HyperparameterTrialResult] = []

            func recordResult(_ result: HyperparameterTrialResult) {
                results.append(result)
                if let currentBest = bestResult {
                    if result.validationAccuracy > currentBest.validationAccuracy {
                        bestResult = result
                    }
                } else {
                    bestResult = result
                }
                print("Recorded result: \(result.validationAccuracy). Current best: \(bestResult?.validationAccuracy ?? 0.0)")
            }

            func getBestResult() -> HyperparameterTrialResult? {
                return bestResult
            }

            func getAllResults() -> [HyperparameterTrialResult] {
                return results
            }
        }

        @available(iOS 18.0, *)
        func runHyperparameterTrial(
            trainingData: MLDataTable,
            validationData: MLDataTable,
            learningRate: Double,
            batchSize: Int,
            tuner: HyperparameterTuner
        ) async throws {
            print("Starting trial with LR: \(learningRate), BS: \(batchSize)")
            do {
                let parameters = MLImageClassifier.ModelParameters(
                    validationData: validationData,
                    maxIterations: 10, // Simplified for example
                    learningRate: learningRate,
                    batchSize: batchSize
                )
                
                // In a real scenario, Create ML might not expose learningRate/batchSize directly
                // for all classifiers, but the concept applies to any configurable parameter.
                // For demonstration, we'll simulate a training process.
                
                // Simulate training and evaluation
                let simulatedAccuracy = Double.random(in: 0.7...0.95)
                try await Task.sleep(for: .seconds(Double.random(in: 1...5))) // Simulate work
                
                let result = HyperparameterTrialResult(
                    learningRate: learningRate,
                    batchSize: batchSize,
                    validationAccuracy: simulatedAccuracy,
                    modelURL: nil // In a real scenario, save the model
                )
                await tuner.recordResult(result)
                print("Finished trial with LR: \(learningRate), BS: \(batchSize), Accuracy: \(simulatedAccuracy)")

            } catch {
                print("Trial failed for LR: \(learningRate), BS: \(batchSize) with error: \(error)")
                // Potentially record a failed trial or handle error
            }
        }

        @available(iOS 18.0, *)
        func performHyperparameterTuning(
            trainingData: MLDataTable,
            validationData: MLDataTable
        ) async {
            let learningRates = [0.001, 0.01, 0.1]
            let batchSizes = [16, 32, 64]
            
            let tuner = HyperparameterTuner()
            
            await withTaskGroup(of: Void.self) { group in
                for lr in learningRates {
                    for bs in batchSizes {
                        group.addTask {
                            await runHyperparameterTrial(
                                trainingData: trainingData,
                                validationData: validationData,
                                learningRate: lr,
                                batchSize: bs,
                                tuner: tuner
                            )
                        }
                    }
                }
            }
            
            if let best = await tuner.getBestResult() {
                print("\n--- Tuning Complete ---")
                print("Best Hyperparameters: Learning Rate = \(best.learningRate), Batch Size = \(best.batchSize)")
                print("Best Validation Accuracy: \(best.validationAccuracy)")
            } else {
                print("No successful trials completed.")
            }
        }

        // Example Usage (requires actual MLDataTable instances)
        /*
        @available(iOS 18.0, *)
        Task {
            // Placeholder: In a real app, load your actual MLDataTable
            let dummyTrainingData = try! MLDataTable(dictionary: ["image": [], "label": []])
            let dummyValidationData = try! MLDataTable(dictionary: ["image": [], "label": []])

            await performHyperparameterTuning(
                trainingData: dummyTrainingData,
                validationData: dummyValidationData
            )
        }
        */
        