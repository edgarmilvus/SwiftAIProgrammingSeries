
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import AVFoundation
import Vision

@available(iOS 18.0, *)
class RealtimeObjectDetectionViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {

    private var captureSession: AVCaptureSession!
    private var previewLayer: AVCaptureVideoPreviewLayer!
    // Dedicated queue for video data output to avoid blocking the main thread.
    private let videoOutputQueue = DispatchQueue(label: "videoOutputQueue", qos: .userInitiated)
    // Dedicated queue for Vision requests to avoid blocking the video output queue.
    private let visionRequestQueue = DispatchQueue(label: "visionRequestQueue", qos: .userInitiated)

    private var detectionOverlayLayers: [CALayer] = []
    private var lastDetectionTimestamp = Date()
    private let detectionInterval: TimeInterval = 0.1 // Limit detections to 10 frames per second

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.bounds
        // Ensure overlays are also updated if layout changes
        updateDetectionOverlays(with: []) // Clear and redraw based on new previewLayer frame
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .hd1280x720 // Or .vga640x480 for lower resolution, higher performance

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Failed to get video device.")
            return
        }

        do {
            let videoInput = try AVCaptureDeviceInput(device: videoDevice)
            if captureSession.canAddInput(videoInput) {
                captureSession.addInput(videoInput)
            } else {
                print("Could not add video input.")
                return
            }
        } catch {
            print("Could not create video input: \(error.localizedDescription)")
            return
        }

        let videoOutput = AVCaptureVideoDataOutput()
        if captureSession.canAddOutput(videoOutput) {
            videoOutput.setSampleBufferDelegate(self, queue: videoOutputQueue)
            // kCVPixelFormatType_32BGRA is a good choice for Vision processing
            videoOutput.videoSettings = [kCVPixelFormatType_32BGRA as String: NSNumber(value: kCVPixelFormatType_32BGRA)]
            captureSession.addOutput(videoOutput)
        } else {
            print("Could not add video output.")
            return
        }

        // Configure video orientation for the output
        if let connection = videoOutput.connection(with: .video), connection.isSupportedVideoOrientation {
            connection.videoOrientation = .portrait // Assuming portrait orientation for the app
        }

        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = .resizeAspectFill
        previewLayer.frame = view.bounds
        view.layer.addSublayer(previewLayer)

        // Start the session on a background queue to avoid blocking UI
        videoOutputQueue.async {
            self.captureSession.startRunning()
        }
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Limit detection frequency
        guard Date().timeIntervalSince(lastDetectionTimestamp) > detectionInterval else { return }
        lastDetectionTimestamp = Date()

        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Create VNImageRequestHandler with the CVPixelBuffer.
        // Vision requests should be performed on a background queue.
        visionRequestQueue.async {
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])

            // Choose ONE detection request:
            // For people:
            let request = VNDetectHumanRectanglesRequest()
            // For animals (dogs/cats):
            // let request = VNDetectAnimalBodyPoseRequest()

            request.completionHandler = { [weak self] request, error in
                if let error = error {
                    print("Vision request error: \(error.localizedDescription)")
                    return
                }

                // Update UI on the main queue
                DispatchQueue.main.async {
                    // For VNDetectHumanRectanglesRequest:
                    guard let observations = request.results as? [VNRectangleObservation] else {
                        self?.updateDetectionOverlays(with: []) // Clear old overlays if no new detections
                        return
                    }
                    self?.updateDetectionOverlays(with: observations)

                    // For VNDetectAnimalBodyPoseRequest, you would iterate VNAnimalBodyPoseObservation
                    // and extract the bounding box (if available or calculate from points)
                    // and then update overlays. This is more complex than simple rectangles.
                    // Example for animal body pose (more involved):
                    /*
                    guard let animalObservations = request.results as? [VNAnimalBodyPoseObservation] else {
                        self?.updateDetectionOverlays(with: [])
                        return
                    }
                    let animalRects: [VNRectangleObservation] = animalObservations.compactMap { observation in
                         // AnimalBodyPose doesn't directly give a single bounding box like VNRectangleObservation.
                         // You'd typically extract a bounding box from its joint points.
                         // For simplicity in this example, we'll skip the complex animal body pose bounding box calculation
                         // and focus on VNDetectHumanRectanglesRequest as per the prompt's simplicity.
                         // If using VNDetectAnimalBodyPoseRequest, you'd calculate a bounding box from
                         // the detected joints and create a VNRectangleObservation-like object or directly use CALayer.
                         return nil // Placeholder
                    }
                    self?.updateDetectionOverlays(with: animalRects)
                    */
                }
            }

            do {
                try handler.perform([request])
            } catch {
                print("Failed to perform Vision request: \(error.localizedDescription)")
            }
        }
    }

    private func updateDetectionOverlays(with observations: [VNRectangleObservation]) {
        // Remove existing overlay layers
        detectionOverlayLayers.forEach { $0.removeFromSuperlayer() }
        detectionOverlayLayers.removeAll()

        guard let previewLayer = previewLayer else { return }

        for observation in observations {
            // Convert Vision's normalized bounding box to AVCaptureVideoPreviewLayer coordinates.
            // Vision's (0,0) is bottom-left, AVCaptureVideoPreviewLayer's (0,0) is top-left.
            // Also, Vision's Y-axis is inverted relative to UIKit/CoreGraphics.
            // previewLayer.layerRectConverted(fromMetadataOutputRect:) handles this transformation.
            let boundingBox = observation.boundingBox
            let layerRect = previewLayer.layerRectConverted(fromMetadataOutputRect: boundingBox)

            let overlayLayer = CALayer()
            overlayLayer.frame = layerRect
            overlayLayer.borderColor = UIColor.red.cgColor
            overlayLayer.borderWidth = 2.0
            overlayLayer.cornerRadius = 5.0
            previewLayer.addSublayer(overlayLayer)
            detectionOverlayLayers.append(overlayLayer)
        }
    }
}
