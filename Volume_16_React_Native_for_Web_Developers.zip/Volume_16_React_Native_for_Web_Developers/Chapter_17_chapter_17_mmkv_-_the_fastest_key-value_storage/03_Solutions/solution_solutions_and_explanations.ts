/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// lib/storage.ts
import { MMKV } from 'react-native-mmkv';

export const storage = new MMKV({
  id: 'user-storage',
  // Optional: For security, in production, retrieve this from Keychain/Keystore
  // encryptionKey: 'your-secure-key-here' 
});

// hooks/useThemePreference.ts
import { useState, useEffect } from 'react';
import { storage } from '../lib/storage';

type ThemeType = 'light' | 'dark';

export const useThemePreference = () => {
  // 1. Initialize state synchronously from MMKV during hook initialization.
  // This prevents the FOUC because the initial render has the correct value immediately.
  const [theme, setTheme] = useState<ThemeType>(() => {
    const savedTheme = storage.getString('theme_preference');
    return (savedTheme as ThemeType) || 'light'; // Default to 'light' if not found
  });

  // 2. Create a setter function that updates both MMKV and React state.
  const updateTheme = (newTheme: ThemeType) => {
    // MMKV writes are synchronous, so this happens instantly.
    storage.set('theme_preference', newTheme);
    setTheme(newTheme);
  };

  return { theme, setTheme: updateTheme };
};
