
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import AppIntents
import SwiftUI // For ObservableObject and @Published
import Foundation // For UUID, Date, etc.

// MARK: - Mock Data Model and Store

struct Task: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var isComplete: Bool
}

class TaskStore: ObservableObject {
    static let shared = TaskStore() // Singleton for easy access from AppIntents

    @Published var tasks: [Task] {
        didSet {
            saveTasks()
        }
    }

    private init() {
        self.tasks = loadTasks()
        // Add some initial tasks if none are loaded
        if tasks.isEmpty {
            tasks.append(Task(id: UUID(), title: "Buy groceries", isComplete: false))
            tasks.append(Task(id: UUID(), title: "Finish App Intents exercise", isComplete: false))
            tasks.append(Task(id: UUID(), title: "Call mom", isComplete: true))
        }
    }

    private func saveTasks() {
        if let encoded = try? JSONEncoder().encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: "myTasks")
        }
    }

    private func loadTasks() -> [Task] {
        if let savedTasksData = UserDefaults.standard.data(forKey: "myTasks"),
           let decodedTasks = try? JSONDecoder().decode([Task].self, from: savedTasksData) {
            return decodedTasks
        }
        return []
    }

    func completeTask(title: String) -> Bool {
        if let index = tasks.firstIndex(where: { $0.title.lowercased() == title.lowercased() }) {
            tasks[index].isComplete = true
            return true
        }
        return false
    }

    func createTask(title: String) {
        // Prevent creating duplicate tasks with the same title (case-insensitive)
        guard !tasks.contains(where: { $0.title.lowercased() == title.lowercased() }) else {
            print("Task '\(title)' already exists.")
            return
        }
        tasks.append(Task(id: UUID(), title: title, isComplete: false))
    }
}

// MARK: - App Intents

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct CompleteTaskIntent: AppIntent {
    static var title: LocalizedStringResource = "Complete a Task"
    static var description = IntentDescription("Marks a specific task as complete in MyTasks.")

    @Parameter(title: "Task Title", description: "The title of the task to complete.")
    var taskTitle: String

    // Optional: Provide dynamic suggestions for task titles
    static var parameterEditor: some ParameterEditor {
        ParameterEditor(keyPath: \.taskTitle) { editor in
            editor.suggestedValues(TaskStore.shared.tasks.filter { !$0.isComplete }.map { $0.title })
        }
    }

    func perform() async throws -> some IntentResult {
        let success = TaskStore.shared.completeTask(title: taskTitle)

        if success {
            return .result(dialog: "Task '\(taskTitle)' marked as complete. Good job!")
        } else {
            throw IntentError.runtimeError("Task '\(taskTitle)' not found or already complete.")
        }
    }
}

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct CreateTaskIntent: AppIntent {
    static var title: LocalizedStringResource = "Create New Task"
    static var description = IntentDescription("Adds a new task to MyTasks.")

    @Parameter(title: "New Task Title", description: "The title for the new task.")
    var newTaskTitle: String

    func perform() async throws -> some IntentResult {
        // Check for existing tasks to avoid duplicates, or let the store handle it
        if TaskStore.shared.tasks.contains(where: { $0.title.lowercased() == newTaskTitle.lowercased() }) {
             throw IntentError.runtimeError("A task with the title '\(newTaskTitle)' already exists.")
        }

        TaskStore.shared.createTask(title: newTaskTitle)
        return .result(dialog: "Task '\(newTaskTitle)' created successfully.")
    }
}

// MARK: - AppIntent Extension (for discoverability)

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct MyTasksAppIntents: AppIntentExtension {
    static var appName: LocalizedStringResource = "MyTasks"
    static var category: IntentCategory = .productivity
}
