
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// This code is designed for iOS 18.0 and later due to the use of @Observable.
@available(iOS 18.0, *)
import Foundation
import UIKit // For UIImage
import SwiftUI // For @Observable and potential UI context

// MARK: - 1. AI Model Output Structures
// These structs define the shape of the data that our simulated AI models will produce.

/// Represents a recognized entity within the document text.
struct RecognizedEntity: Identifiable, Hashable {
    let id = UUID()
    let type: String // e.g., "Person", "Organization", "Date", "Location"
    let value: String // The actual text recognized
    let confidence: Double // Confidence score from the AI model

    static let example = RecognizedEntity(type: "Person", value: "John Doe", confidence: 0.98)
}

/// Represents the sentiment analysis result for a block of text.
enum SentimentCategory: String, Codable {
    case positive = "Positive"
    case negative = "Negative"
    case neutral = "Neutral"
    case mixed = "Mixed"
    case unknown = "Unknown"
}

/// A structure to hold the sentiment analysis result.
struct SentimentAnalysis: Codable, Hashable {
    let category: SentimentCategory
    let score: Double // e.g., -1.0 to 1.0 for negative to positive

    static let example = SentimentAnalysis(category: .neutral, score: 0.0)
}

/// A comprehensive structure to hold all AI analysis results for a document.
struct DocumentAnalysisResult: Identifiable, Hashable {
    let id = UUID()
    var fullOCRText: String
    var entities: [RecognizedEntity]
    var sentiment: SentimentAnalysis?
    var analysisDate: Date = Date()
}

// MARK: - 2. Simulated AI Service
// This class simulates interactions with an AI backend or local Core ML models.
// It uses AsyncSequence to mimic streaming results for OCR and entity extraction.

/// Defines potential errors that can occur during AI processing.
enum AIServiceError: Error, LocalizedError {
    case imageProcessingFailed
    case ocrFailed(String)
    case entityExtractionFailed(String)
    case sentimentAnalysisFailed(String)
    case cancelled

    var errorDescription: String? {
        switch self {
        case .imageProcessingFailed: return "Failed to process the image."
        case .ocrFailed(let details): return "OCR failed: \(details)"
        case .entityExtractionFailed(let details): return "Entity extraction failed: \(details)"
        case .sentimentAnalysisFailed(let details): return "Sentiment analysis failed: \(details)"
        case .cancelled: return "AI analysis was cancelled."
        }
    }
}

/// A simulated AI service that performs document analysis tasks.
/// In a real application, this would interact with Vision Framework, Core ML, or a cloud API.
actor AIService {

    /// Simulates Optical Character Recognition (OCR) on an image, streaming text chunks.
    /// - Parameter image: The `UIImage` to perform OCR on.
    /// - Returns: An `AsyncThrowingStream` of `String` chunks, representing the OCR output.
    func performOCR(on image: UIImage) -> AsyncThrowingStream<String, Error> {
        AsyncThrowingStream { continuation in
            Task {
                // Simulate image processing delay
                try await Task.sleep(for: .seconds(0.5))
                guard !Task.isCancelled else {
                    continuation.finish(throwing: AIServiceError.cancelled)
                    return
                }

                // Simulate OCR failure for certain conditions (e.g., very small images)
                if image.size.width < 50 || image.size.height < 50 {
                    continuation.finish(throwing: AIServiceError.ocrFailed("Image too small for OCR."))
                    return
                }

                let sampleText = """
                Invoice #2023-08-15-001
                Date: August 15, 2023
                Customer: Acme Corp.
                Address: 123 Main St, Anytown, USA
                Item: Consulting Services
                Quantity: 10 hours
                Unit Price: $150.00
                Total: $1,500.00
                Payment Due: September 15, 2023
                Contact: Jane Doe (jane.doe@acmecorp.com)
                """

                // Simulate streaming text output
                let lines = sampleText.split(separator: "\n").map(String.init)
                for (index, line) in lines.enumerated() {
                    try await Task.sleep(for: .milliseconds(100 + Int.random(in: 0...50))) // Simulate variable processing time per line
                    guard !Task.isCancelled else {
                        continuation.finish(throwing: AIServiceError.cancelled)
                        return
                    }
                    continuation.yield(line + "\n")
                    if index == lines.count / 2 && Bool.random() { // Simulate a mid-process error
                         // continuation.finish(throwing: AIServiceError.ocrFailed("Mid-OCR processing error."))
                         // return
                    }
                }
                continuation.finish()
            }
        }
    }

    /// Simulates entity extraction from a given text, streaming entities as they are found.
    /// - Parameter text: The full text extracted from the document.
    /// - Returns: An `AsyncThrowingStream` of `RecognizedEntity`.
    func extractEntities(from text: String) -> AsyncThrowingStream<RecognizedEntity, Error> {
        AsyncThrowingStream { continuation in
            Task {
                try await Task.sleep(for: .seconds(0.8)) // Initial processing delay
                guard !Task.isCancelled else {
                    continuation.finish(throwing: AIServiceError.cancelled)
                    return
                }

                let potentialEntities: [RecognizedEntity] = [
                    RecognizedEntity(type: "InvoiceNumber", value: "2023-08-15-001", confidence: 0.99),
                    RecognizedEntity(type: "Date", value: "August 15, 2023", confidence: 0.95),
                    RecognizedEntity(type: "Organization", value: "Acme Corp.", confidence: 0.97),
                    RecognizedEntity(type: "Address", value: "123 Main St, Anytown, USA", confidence: 0.92),
                    RecognizedEntity(type: "Currency", value: "$150.00", confidence: 0.98),
                    RecognizedEntity(type: "Currency", value: "$1,500.00", confidence: 0.99),
                    RecognizedEntity(type: "Date", value: "September 15, 2023", confidence: 0.96),
                    RecognizedEntity(type: "Person", value: "Jane Doe", confidence: 0.98),
                    RecognizedEntity(type: "Email", value: "jane.doe@acmecorp.com", confidence: 0.94)
                ]

                for entity in potentialEntities {
                    try await Task.sleep(for: .milliseconds(150 + Int.random(in: 0...100))) // Simulate finding entities over time
                    guard !Task.isCancelled else {
                        continuation.finish(throwing: AIServiceError.cancelled)
                        return
                    }
                    continuation.yield(entity)
                }
                continuation.finish()
            }
        }
    }

    /// Simulates sentiment analysis on a given text.
    /// - Parameter text: The text to analyze sentiment for.
    /// - Returns: A `SentimentAnalysis` result.
    func analyzeSentiment(of text: String) async throws -> SentimentAnalysis {
        try await Task.sleep(for: .seconds(0.7)) // Simulate processing delay
        guard !Task.isCancelled else { throw AIServiceError.cancelled }

        // Simple heuristic for sentiment:
        if text.lowercased().contains("failed") || text.lowercased().contains("error") {
            return SentimentAnalysis(category: .negative, score: -0.8)
        } else if text.lowercased().contains("excellent") || text.lowercased().contains("great") {
            return SentimentAnalysis(category: .positive, score: 0.9)
        } else if text.contains("Invoice") || text.contains("Payment Due") {
            return SentimentAnalysis(category: .neutral, score: 0.1) // Typical for transactional docs
        }
        return SentimentAnalysis(category: .neutral, score: 0.0)
    }
}

// MARK: - 3. DocumentScannerViewModel (@Observable Core)
// This ViewModel orchestrates the AI processing and updates the UI state using @Observable.

/// The ViewModel for our Smart Document Scanner, managing AI processing and UI state.
/// Marked with `@Observable` to allow SwiftUI views to react to its property changes.
@Observable
final class DocumentScannerViewModel {
    // MARK: - UI State Properties
    var isLoading: Bool = false // Indicates if an AI analysis is currently in progress
    var errorMessage: String? // Stores any error messages for display
    var currentImage: UIImage? // The image currently being analyzed

    // Properties for streaming/progressive updates
    var ocrProgressText: String = "" // Accumulates OCR text as it streams in
    var extractedEntities: [RecognizedEntity] = [] // Accumulates entities as they are found
    var sentimentAnalysis: SentimentAnalysis? // The final sentiment result

    // Comprehensive result, updated once all stages are complete or significantly processed
    var fullAnalysisResult: DocumentAnalysisResult?

    private let aiService = AIService()
    private var currentAnalysisTask: Task<Void, Never>? // To manage and cancel ongoing analysis

    init() {
        // Initial setup if needed
    }

    // MARK: - Public Methods

    /// Initiates the AI analysis process for a given image.
    /// This method orchestrates OCR, entity extraction, and sentiment analysis.
    /// It uses a `Task` to run the asynchronous operations and updates `@Observable` properties
    /// to reflect the real-time state of the analysis.
    /// - Parameter image: The `UIImage` to be analyzed.
    func analyzeDocument(image: UIImage) {
        // Cancel any previous analysis to avoid race conditions or stale data.
        cancelAnalysis()

        // Reset UI state for a new analysis
        currentImage = image
        isLoading = true
        errorMessage = nil
        ocrProgressText = ""
        extractedEntities = []
        sentimentAnalysis = nil
        fullAnalysisResult = nil

        // Create a new task to perform the AI analysis asynchronously.
        // This task is stored so it can be cancelled later if needed.
        currentAnalysisTask = Task { @MainActor in
            do {
                var accumulatedOCRText = ""
                var accumulatedEntities: [RecognizedEntity] = []

                // Step 1: Perform OCR and update UI progressively
                // The `for await` loop handles the `AsyncThrowingStream` from `performOCR`.
                for await textChunk in aiService.performOCR(on: image) {
                    guard !Task.isCancelled else { throw AIServiceError.cancelled }
                    accumulatedOCRText += textChunk
                    ocrProgressText = accumulatedOCRText // Update @Observable property on MainActor
                }

                // Ensure we have some text to proceed
                guard !accumulatedOCRText.isEmpty else {
                    throw AIServiceError.ocrFailed("No text recognized from the document.")
                }

                // Step 2: Extract Entities and update UI progressively
                // Similar to OCR, entities are streamed and accumulated.
                for await entity in aiService.extractEntities(from: accumulatedOCRText) {
                    guard !Task.isCancelled else { throw AIServiceError.cancelled }
                    accumulatedEntities.append(entity)
                    // It's efficient to sort here if the order matters for display
                    extractedEntities = accumulatedEntities.sorted { $0.type < $1.type } // Update @Observable property
                }

                // Step 3: Perform Sentiment Analysis (typically a single, final result)
                let sentiment = try await aiService.analyzeSentiment(of: accumulatedOCRText)
                sentimentAnalysis = sentiment // Update @Observable property

                // Step 4: Assemble the final comprehensive result
                fullAnalysisResult = DocumentAnalysisResult(
                    fullOCRText: accumulatedOCRText,
                    entities: accumulatedEntities,
                    sentiment: sentiment
                )

            } catch let error as AIServiceError {
                // Catch specific AI service errors and display them
                errorMessage = error.localizedDescription
                print("AI Service Error: \(error.localizedDescription)")
            } catch {
                // Catch any other unexpected errors
                errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                print("Unexpected Error: \(error.localizedDescription)")
            } finally {
                // Ensure loading state is reset regardless of success or failure
                isLoading = false
                currentAnalysisTask = nil // Clear the task reference
            }
        }
    }

    /// Cancels any ongoing document analysis task.
    func cancelAnalysis() {
        currentAnalysisTask?.cancel()
        currentAnalysisTask = nil
        // Optionally reset state immediately upon cancellation if desired
        // isLoading = false
        // errorMessage = "Analysis cancelled."
        // ocrProgressText = ""
        // extractedEntities = []
        // sentimentAnalysis = nil
        // fullAnalysisResult = nil
    }
}

// MARK: - 4. SwiftUI View Integration (Illustrative)
// A minimal SwiftUI view to demonstrate how the ViewModel drives the UI.

/// An illustrative SwiftUI view that uses the `DocumentScannerViewModel`
/// to display AI analysis results in real-time.
struct DocumentScannerView: View {
    @State private var viewModel = DocumentScannerViewModel()
    @State private var selectedImage: UIImage? // In a real app, this would come from PhotoPicker or Camera

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 15) {
                    Text("Smart Document Scanner")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.bottom, 10)

                    // Image selection (simplified for example)
                    Button("Select/Simulate Image") {
                        // In a real app, integrate PhotoPicker or Camera here
                        selectedImage = UIImage(systemName: "doc.text.image") // Placeholder image
                        if let image = selectedImage {
                            viewModel.analyzeDocument(image: image)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(viewModel.isLoading)
                    .padding(.bottom)

                    if viewModel.isLoading {
                        ProgressView("Analyzing Document...")
                            .progressViewStyle(.circular)
                            .padding()
                        Button("Cancel Analysis") {
                            viewModel.cancelAnalysis()
                        }
                        .buttonStyle(.destructive)
                    }

                    if let errorMessage = viewModel.errorMessage {
                        Text("Error: \(errorMessage)")
                            .foregroundColor(.red)
                            .font(.headline)
                            .padding()
                            .background(Color.red.opacity(0.1))
                            .cornerRadius(8)
                    }

                    if let image = viewModel.currentImage {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 200, maxHeight: 200)
                            .cornerRadius(10)
                            .padding(.bottom)
                    }

                    // Display OCR Progress (streaming)
                    if !viewModel.ocrProgressText.isEmpty {
                        Divider()
                        Text("OCR Text:")
                            .font(.headline)
                        Text(viewModel.ocrProgressText)
                            .font(.body)
                            .padding(5)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(5)
                    }

                    // Display Extracted Entities (streaming)
                    if !viewModel.extractedEntities.isEmpty {
                        Divider()
                        Text("Extracted Entities:")
                            .font(.headline)
                        ForEach(viewModel.extractedEntities) { entity in
                            HStack {
                                Text(entity.type)
                                    .font(.caption)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 3)
                                    .background(Color.blue.opacity(0.2))
                                    .cornerRadius(5)
                                Text(entity.value)
                                Spacer()
                            }
                        }
                    }

                    // Display Sentiment Analysis (final result)
                    if let sentiment = viewModel.sentimentAnalysis {
                        Divider()
                        Text("Sentiment Analysis:")
                            .font(.headline)
                        HStack {
                            Text(sentiment.category.rawValue)
                                .font(.subheadline)
                                .foregroundColor(sentimentColor(sentiment.category))
                            Text(String(format: "Score: %.2f", sentiment.score))
                                .font(.subheadline)
                        }
                    }

                    // Display Full Analysis Result (once complete)
                    if let fullResult = viewModel.fullAnalysisResult {
                        Divider()
                        Text("Full Document Analysis Complete!")
                            .font(.title2)
                            .fontWeight(.medium)
                            .padding(.top, 10)
                        Text("Analyzed on: \(fullResult.analysisDate.formatted(date: .abbreviated, time: .shortened))")
                            .font(.caption)
                    }
                }
                .padding()
            }
            .navigationTitle("")
            .navigationBarHidden(true)
        }
    }

    private func sentimentColor(_ category: SentimentCategory) -> Color {
        switch category {
        case .positive: return .green
        case .negative: return .red
        case .neutral: return .gray
        case .mixed: return .orange
        case .unknown: return .purple
        }
    }
}

// MARK: - App Entry Point (for SwiftUI Previews and App)
@available(iOS 18.0, *)
struct DocumentScannerApp: App {
    var body: some Scene {
        WindowGroup {
            DocumentScannerView()
        }
    }
}

// MARK: - Swift Package Manager Dependencies (Illustrative)
// This `Package.swift` snippet demonstrates how you might declare external
// AI-related dependencies for a real-world project.
// In this specific example, the `AIService` is simulated, so these are
// purely for demonstration of production-quality dependency management.

/*
// Package.swift
import PackageDescription

let package = Package(
    name: "SmartDocumentScannerApp",
    platforms: [
        .iOS(.v18), // Requires iOS 18 for @Observable and latest concurrency features
        .macOS(.v15)
    ],
    products: [
        .library(
            name: "SmartDocumentScannerApp",
            targets: ["SmartDocumentScannerApp"]),
    ],
    dependencies: [
        // Hypothetical AI SDK for advanced document processing.
        // In a real app, this might be a local package wrapping Core ML models,
        // or a remote SDK for cloud-based AI services like Google Cloud Vision, AWS Rekognition, or Azure AI Vision.
        .package(url: "https://github.com/YourOrg/AIKit.git", from: "1.0.0"),

        // Another common dependency for advanced image processing, though Vision framework
        // covers much of this natively. This is illustrative.
        .package(url: "https://github.com/ImageProcessingCo/ImageProKit.git", from: "2.5.0")
    ],
    targets: [
        .target(
            name: "SmartDocumentScannerApp",
            dependencies: [
                .product(name: "AIKit", package: "AIKit"),
                .product(name: "ImageProKit", package: "ImageProKit")
            ]),
        .testTarget(
            name: "SmartDocumentScannerAppTests",
            dependencies: ["SmartDocumentScannerApp"]),
    ]
)
*/
