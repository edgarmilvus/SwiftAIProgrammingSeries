
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// Errors specific to vector mathematical operations.
enum VectorError: Error, LocalizedError {
    case dimensionMismatch
    
    var errorDescription: String? {
        switch self {
        case .dimensionMismatch:
            return "Vectors must have the same number of dimensions."
        }
    }
}

/// A utility module for high-dimensional vector mathematics.
struct VectorMath {
    /// Calculates the cosine similarity between two vectors.
    /// - Returns: A value between -1.0 and 1.0, where 1.0 is identical. 
    ///            Returns 0.0 if one vector is a zero vector.
    /// - Throws: `VectorError.dimensionMismatch` if lengths differ.
    static func cosineSimilarity(between vectorA: [Float], and vectorB: [Float]) throws -> Float {
        // 1. Validation: Ensure dimensions match
        guard vectorA.count == vectorB.count else {
            throw VectorError.dimensionMismatch
        }
        
        // Handle empty vectors
        guard !vectorA.isEmpty else { return 0.0 }
        
        var dotProduct: Float = 0.0
        var normASquared: Float = 0.0
        var normBSquared: Float = 0.0
        
        // 2. Single-pass calculation for efficiency
        for i in 0..<vectorA.count {
            let a = vectorA[i]
            let b = vectorB[i]
            
            dotProduct += a * b
            normASquared += a * a
            normBSquared += b * b
        }
        
        // 3. Zero-Vector Handling: Prevent division by zero
        // If magnitude is 0, similarity is undefined; we return 0.0 per requirements.
        guard normASquared > 0, normBSquared > 0 else {
            return 0.0
        }
        
        let magnitudeA = sqrt(normASquared)
        let magnitudeB = sqrt(normBSquared)
        
        return dotProduct / (magnitudeA * magnitudeB)
    }
}

// MARK: - Testing the Implementation
Task {
    let v1: [Float] = [1.0, 2.0, 3.0]
    let v2: [Float] = [1.0, 2.0, 3.0] // Identical
    let v3: [Float] = [0.0, 0.0, 0.0] // Zero vector
    let v4: [Float] = [3.0, 2.0, 1.0] // Different direction
    
    do {
        print("Similarity (Identical): \(try VectorMath.cosineSimilarity(between: v1, and: v2))")
        print("Similarity (Zero Vector): \(try VectorMath.cosineSimilarity(between: v1, and: v3))")
        print("Similarity (Different): \(try VectorMath.cosineSimilarity(between: v1, and: v4))")
    } catch {
        print("Error: \(error.localizedDescription)")
    }
}
