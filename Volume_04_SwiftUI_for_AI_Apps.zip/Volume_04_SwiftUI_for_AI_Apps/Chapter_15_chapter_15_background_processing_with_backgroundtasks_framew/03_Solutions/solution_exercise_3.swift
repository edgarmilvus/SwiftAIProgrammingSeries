
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import BackgroundTasks
import UIKit // Needed for AppDelegate context

// MARK: - Background Task Manager

@available(iOS 18.0, *)
class BackgroundTaskManager {

    static let shared = BackgroundTaskManager()

    private let refreshIdentifier = "com.yourcompany.yourapp.chatRefreshTask"
    private let processingIdentifier = "com.yourcompany.yourapp.chatProcessingTask"

    // Keep track of ongoing operations to allow cancellation
    private var currentSyncSummarizationTask: Task<Void, Never>?
    private var currentNetworkTask: URLSessionDataTask?

    private init() {} // Singleton

    // MARK: - Registration

    func registerChatBackgroundTasks() {
        // App Refresh Task for light checks (can run on main queue, as it's quick)
        BGTaskScheduler.shared.register(forTaskWithIdentifier: refreshIdentifier, onQueue: .main) { task in
            guard let appRefreshTask = task as? BGAppRefreshTask else {
                print("Error: Task is not a BGAppRefreshTask.")
                task.setTaskCompleted(success: false)
                return
            }
            self.handleChatRefreshCheck(task: appRefreshTask)
        }
        print("Registered chat refresh task: \(refreshIdentifier)")

        // Processing Task for heavy sync and summarization (use a background queue)
        BGTaskScheduler.shared.register(forTaskWithIdentifier: processingIdentifier, onQueue: .global(qos: .utility)) { task in
            guard let processingTask = task as? BGProcessingTask else {
                print("Error: Task is not a BGProcessingTask.")
                task.setTaskCompleted(success: false)
                return
            }
            self.handleChatSyncAndSummarization(task: processingTask)
        }
        print("Registered chat processing task: \(processingIdentifier)")
    }

    // MARK: - Scheduling

    func scheduleChatRefreshTask() {
        let request = BGAppRefreshTaskRequest(identifier: refreshIdentifier)
        request.earliestBeginDate = Date(timeIntervalSinceNow: 60 * 30) // Check every 30 minutes
        do {
            try BGTaskScheduler.shared.submit(request)
            print("Scheduled chat refresh task.")
        } catch {
            print("Could not schedule chat refresh: \(error.localizedDescription)")
        }
    }

    func scheduleChatProcessingTask(earliestBeginDate: Date? = nil) {
        let request = BGProcessingTaskRequest(identifier: processingIdentifier)
        request.requiresNetworkConnectivity = true // Needs network for syncing
        request.requiresExternalPower = false      // Assume summarization is light, or set to true if heavy
        request.earliestBeginDate = earliestBeginDate ?? Date(timeIntervalSinceNow: 60 * 2) // Default to 2 mins from now

        do {
            try BGTaskScheduler.shared.submit(request)
            print("Scheduled chat processing task.")
        } catch {
            print("Could not schedule chat processing: \(error.localizedDescription)")
        }
    }

    // MARK: - App Refresh Task Handler

    private func handleChatRefreshCheck(task: BGAppRefreshTask) {
        print("Chat refresh check started for \(task.identifier).")
        task.expirationHandler = {
            print("Chat refresh check expired for \(task.identifier).")
            task.setTaskCompleted(success: false)
        }

        // Simulate checking for new messages/unsynced summaries
        // In a real app, this would involve a quick database query or a lightweight API call.
        let hasPendingWork = UserDefaults.standard.bool(forKey: "hasPendingChatWork")

        if hasPendingWork {
            print("Pending chat work found, scheduling processing task.")
            // Schedule the processing task to run soon
            scheduleChatProcessingTask(earliestBeginDate: Date(timeIntervalSinceNow: 30)) // Schedule for 30 seconds from now
        } else {
            print("No pending chat work found.")
        }

        // Always reschedule the app refresh task for the next check
        scheduleChatRefreshTask()
        task.setTaskCompleted(success: true) // The refresh check itself completed successfully
    }

    // MARK: - Processing Task Handler

    private func handleChatSyncAndSummarization(task: BGProcessingTask) {
        print("Chat sync and summarization task started for \(task.identifier).")

        currentSyncSummarizationTask = Task {
            task.expirationHandler = {
                print("Chat sync and summarization task expired for \(task.identifier). Cancelling ongoing operations.")
                self.currentNetworkTask?.cancel() // Cancel network ops
                self.currentSyncSummarizationTask?.cancel() // Cancel the Swift Concurrency Task
                task.setTaskCompleted(success: false)
                // Mark pending work as still needing processing
                UserDefaults.standard.set(true, forKey: "hasPendingChatWork")
            }

            var success = false
            do {
                // 1. Fetch unsynced chat history and pending summaries from local storage.
                let pendingChats = await fetchPendingChats()
                print("Fetched \(pendingChats.count) pending chats.")

                if pendingChats.isEmpty {
                    print("No chats to process. Completing task.")
                    success = true
                } else {
                    // Check for cancellation before starting heavy work
                    if Task.isCancelled || task.isCancelled { throw CancellationError() }

                    // 2. Perform local summarization for new long conversations.
                    let chatsToSync = await summarizePendingChats(pendingChats: pendingChats)
                    print("Summarized \(chatsToSync.count) chats.")

                    // Check for cancellation before network operation
                    if Task.isCancelled || task.isCancelled { throw CancellationError() }

                    // 3. Upload chat history and summaries to the cloud backend.
                    success = await uploadChatData(chats: chatsToSync)
                }

            } catch is CancellationError {
                print("Chat sync/summarization task was cancelled.")
                success = false
            } catch {
                print("Error during chat sync/summarization: \(error.localizedDescription)")
                success = false
            }

            // Ensure the task is marked complete only if not already expired
            if !Task.isCancelled && !task.isCancelled {
                print("Chat sync and summarization task for \(task.identifier) completed with success: \(success).")
                task.setTaskCompleted(success: success)
                if success {
                    UserDefaults.standard.set(false, forKey: "hasPendingChatWork") // Clear flag on success
                } else {
                    // If failed, ensure the flag remains true or reschedule for retry
                    UserDefaults.standard.set(true, forKey: "hasPendingChatWork")
                    // Implement retry logic: schedule again with a delay
                    self.scheduleChatProcessingTask(earliestBeginDate: Date(timeIntervalSinceNow: 60 * 5)) // Retry in 5 mins
                }
            } else {
                print("Chat sync and summarization task for \(task.identifier) was cancelled externally (e.g., by expiration handler).")
                // Expiration handler already set task.setTaskCompleted(success: false) and marked pending work.
            }
            self.currentSyncSummarizationTask = nil
        }
    }

    // MARK: - Simulated Operations

    private func fetchPendingChats() async -> [String] {
        // Simulate fetching from a local database
        await Task.sleep(for: .seconds(0.5))
        let pendingCount = UserDefaults.standard.integer(forKey: "numPendingChats")
        if pendingCount > 0 {
            print("Simulating fetching \(pendingCount) pending chats.")
            return Array(repeating: "Chat message content", count: pendingCount)
        }
        return []
    }

    private func summarizePendingChats(pendingChats: [String]) async -> [String] {
        guard !pendingChats.isEmpty else { return [] }
        print("Simulating local summarization for \(pendingChats.count) chats...")
        await Task.sleep(for: .seconds(Double.random(in: 2...5))) // Simulate CPU-intensive work
        return pendingChats.map { "Summary of: \($0)" } // Return summarized content
    }

    private func uploadChatData(chats: [String]) async -> Bool {
        guard !chats.isEmpty else { return true }
        print("Simulating uploading \(chats.count) chats to cloud...")
        let mockURL = URL(string: "https://mockapi.example.com/sync_chats")!
        let successRate = 0.7 // 70% chance of success

        do {
            // Simulate network request with a delay
            let (data, response) = try await URLSession.shared.data(from: mockURL) // Use a real URLSession call
            _ = data // Ignore data for simulation
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                print("Successfully uploaded chat data.")
                // In a real app, update local state to mark chats as synced
                UserDefaults.standard.set(0, forKey: "numPendingChats") // Clear pending count
                return true
            } else {
                print("Simulated network upload failed with status code: \((response as? HTTPURLResponse)?.statusCode ?? -1)")
                return false
            }
        } catch is URLError where (error as? URLError)?.code == .cancelled {
            print("Chat data upload cancelled.")
            throw CancellationError() // Propagate cancellation
        } catch {
            print("Error uploading chat data: \(error.localizedDescription)")
            // Implement retry logic if transient error
            return false
        }
    }

    // Helper to simulate adding new chats
    func addPendingChat() {
        var currentCount = UserDefaults.standard.integer(forKey: "numPendingChats")
        currentCount += 1
        UserDefaults.standard.set(currentCount, forKey: "numPendingChats")
        UserDefaults.standard.set(true, forKey: "hasPendingChatWork")
        print("Added a new pending chat. Total: \(currentCount). Flag set: hasPendingChatWork = true")
        // Schedule a processing task immediately if app is active, or rely on refresh
        if UIApplication.shared.applicationState == .active {
             scheduleChatProcessingTask(earliestBeginDate: Date(timeIntervalSinceNow: 10)) // Try to process soon
        }
    }
}

// MARK: - AppDelegate Integration Example

// Extend AppDelegate to call the BackgroundTaskManager methods
/*
@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    let backgroundTaskManager = BackgroundTaskManager.shared

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        if #available(iOS 18.0, *) {
            backgroundTaskManager.registerChatBackgroundTasks()
            // Schedule initial refresh and potentially processing if there's pending work
            backgroundTaskManager.scheduleChatRefreshTask()
            if UserDefaults.standard.bool(forKey: "hasPendingChatWork") {
                backgroundTaskManager.scheduleChatProcessingTask()
            }
        } else {
            // Fallback for older iOS versions
        }
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        if #available(iOS 18.0, *) {
            // Reschedule tasks when app goes to background
            backgroundTaskManager.scheduleChatRefreshTask()
            if UserDefaults.standard.bool(forKey: "hasPendingChatWork") {
                backgroundTaskManager.scheduleChatProcessingTask()
            }
        }
    }

    // Example of triggering new work
    func applicationDidBecomeActive(_ application: UIApplication) {
        if #available(iOS 18.0, *) {
            // This is just for demonstration. In a real app, adding a chat
            // would trigger `addPendingChat` from the UI.
            // backgroundTaskManager.addPendingChat()
        }
    }
}
*/
