/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// cartStore.ts
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

// 1. Define the State Interface
interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

interface CartState {
  items: CartItem[];
  totalPrice: number;
}

// 2. Define Actions Interface
interface CartActions {
  addItem: (item: { id: string; name: string; price: number }) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
}

// 3. Create the Store with Persistence Middleware
export const useCartStore = create<CartState & CartActions>()(
  persist(
    (set, get) => ({
      items: [],
      totalPrice: 0,

      // Action: Add Item
      addItem: (newItem) => {
        set((state) => {
          const existingItem = state.items.find((item) => item.id === newItem.id);
          
          let updatedItems;
          if (existingItem) {
            // Increment quantity if exists
            updatedItems = state.items.map((item) =>
              item.id === newItem.id
                ? { ...item, quantity: item.quantity + 1 }
                : item
            );
          } else {
            // Add new item with quantity 1
            updatedItems = [...state.items, { ...newItem, quantity: 1 }];
          }

          // Recalculate total
          const totalPrice = updatedItems.reduce(
            (sum, item) => sum + item.price * item.quantity,
            0
          );

          return { items: updatedItems, totalPrice };
        });
      },

      // Action: Remove Item
      removeItem: (id) => {
        set((state) => {
          const updatedItems = state.items.filter((item) => item.id !== id);
          const totalPrice = updatedItems.reduce(
            (sum, item) => sum + item.price * item.quantity,
            0
          );
          return { items: updatedItems, totalPrice };
        });
      },

      // Action: Update Quantity
      updateQuantity: (id, quantity) => {
        set((state) => {
          let updatedItems;
          
          if (quantity <= 0) {
            // Remove if quantity is 0 or less
            updatedItems = state.items.filter((item) => item.id !== id);
          } else {
            // Update quantity
            updatedItems = state.items.map((item) =>
              item.id === id ? { ...item, quantity } : item
            );
          }

          const totalPrice = updatedItems.reduce(
            (sum, item) => sum + item.price * item.quantity,
            0
          );

          return { items: updatedItems, totalPrice };
        });
      },

      // Action: Clear Cart
      clearCart: () => {
        set({ items: [], totalPrice: 0 });
      },
    }),
    {
      name: '@shopping-cart', // Storage key
      // Detect platform to choose storage adapter
      storage: createJSONStorage(() => (typeof window !== 'undefined' ? localStorage : AsyncStorage)),
    }
  )
);
