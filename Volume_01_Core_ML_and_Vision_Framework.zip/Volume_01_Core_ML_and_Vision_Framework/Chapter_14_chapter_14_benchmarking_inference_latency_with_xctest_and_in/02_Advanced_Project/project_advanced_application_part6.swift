
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

/// @available(iOS 17.0, *)
/// Manages the dynamic selection of an optimal `ObjectDetectionModel` based on performance benchmarks.
actor DynamicModelSelector {
    private let benchmarkService = ModelBenchmarkService()
    private let logHandle = OSLog(subsystem: "com.example.SmartCameraApp", category: "DynamicModelSelection")

    /// Selects the optimal model from a list by benchmarking their inference latency.
    /// - Parameters:
    ///   - models: An array of `ObjectDetectionModel` candidates.
    ///   - samplePixelBuffer: A representative `CVPixelBuffer` to use for benchmarking.
    ///   - iterations: The number of inference runs per model for latency measurement.
    ///   - targetLatencyThreshold: An optional target latency. If a model is faster than this, it's preferred.
    /// - Returns: The `ObjectDetectionModel` deemed optimal, or `nil` if no model can be selected.
    func selectOptimalModel(
        models: [ObjectDetectionModel],
        samplePixelBuffer: CVPixelBuffer,
        iterations: Int = 5,
        targetLatencyThreshold: TimeInterval? = 0.05 // e.g., 50ms for real-time
    ) async throws -> ObjectDetectionModel? {
        os_log("Starting dynamic model selection with %d candidate models.", log: logHandle, type: .info, models.count)
        var benchmarkResults: [String: TimeInterval] = [:]

        // Benchmark each model
        for model in models {
            do {
                let latency = try await benchmarkService.measureLatency(model: model, pixelBuffer: samplePixelBuffer, iterations: iterations)
                benchmarkResults[model.modelIdentifier] = latency
                os_log("Benchmarked model '%{public}s': %.4f s", log: logHandle, type: .info, model.modelIdentifier, latency)
            } catch {
                os_log("Failed to benchmark model '%{public}s': %{public}s", log: logHandle, type: .error, model.modelIdentifier, error.localizedDescription)
                // Continue to next model even if one fails
            }
        }

        // Decision logic: Find the fastest model that meets criteria
        guard !benchmarkResults.isEmpty else {
            os_log("No models were successfully benchmarked.", log: logHandle, type: .error)
            return nil
        }

        let sortedResults = benchmarkResults.sorted { $0.value < $1.value }
        os_log("Benchmark results: %{public}s", log: logHandle, type: .debug, sortedResults.description)

        if let threshold = targetLatencyThreshold {
            if let bestModelIdentifier = sortedResults.first(where: { $0.value <= threshold })?.key {
                os_log("Selected model '%{public}s' as it met the target latency threshold (%.4f s).", log: logHandle, type: .info, bestModelIdentifier, threshold)
                return models.first(where: { $0.modelIdentifier == bestModelIdentifier })
            } else {
                os_log("No model met the target latency threshold (%.4f s). Selecting the fastest available.", log: logHandle, type: .warning, threshold)
            }
        }

        // Fallback: If no model meets the threshold or no threshold is set, pick the absolute fastest
        if let fastestModelIdentifier = sortedResults.first?.key {
            os_log("Selected model '%{public}s' as the overall fastest.", log: logHandle, type: .info, fastestModelIdentifier)
            return models.first(where: { $0.modelIdentifier == fastestModelIdentifier })
        }

        os_log("Failed to select any optimal model.", log: logHandle, type: .error)
        return nil
    }
}
