
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI // Required for @Observable

/// ViewModel for managing photo categorization logic and UI state.
@Observable // Requires iOS 17.0+
@available(iOS 17.0, *)
class PhotoOrganizerViewModel {
    /// The label assigned to the photo after categorization.
    var categorizedLabel: String = "Not Categorized"
    /// An optional error object to display in the UI. Nil if no error.
    var activeError: PhotoCategorizationError?
    /// Indicates if an AI operation is currently in progress.
    var isLoading: Bool = false

    /// The mock AI categorizer instance.
    private let categorizer = MockAICategorizer()

    /// Configures the mock categorizer to simulate specific failures.
    /// - Parameters:
    ///   - modelLoading: If true, `modelLoadingFailed` will be thrown.
    ///   - inputValidation: If true, `invalidInputImage` will be thrown.
    ///   - inference: If true, `inferenceFailed` will be thrown.
    func configureMockFailures(modelLoading: Bool = false, inputValidation: Bool = false, inference: Bool = false) {
        categorizer.shouldFailModelLoading = modelLoading
        categorizer.shouldFailInputValidation = inputValidation
        categorizer.shouldFailInference = inference
    }

    /// Performs the photo categorization asynchronously.
    /// All UI updates within this method must be on the main actor.
    @MainActor
    func performCategorization(image: UIImage) async {
        // Reset state for a new operation
        isLoading = true
        activeError = nil
        categorizedLabel = "Categorizing..."
        print("DEBUG: Starting categorization...")

        do {
            // Attempt to categorize the photo
            let label = try await categorizer.categorizePhoto(image: image)
            // If successful, update the label
            self.categorizedLabel = label
            print("DEBUG: Categorization successful: \(label)")
        } catch let error as PhotoCategorizationError {
            // Catch specific PhotoCategorizationError types
            self.activeError = error
            self.categorizedLabel = "Failed" // Indicate failure in the main label
            print("DEBUG: Categorization failed with specific error: \(error.localizedDescription)")
        } catch {
            // Catch any other unexpected errors
            self.activeError = .unknownError // Use our generic unknown error
            self.categorizedLabel = "Failed"
            print("DEBUG: Categorization failed with unknown error: \(error.localizedDescription)")
        }

        // Ensure loading state is reset regardless of success or failure
        isLoading = false
        print("DEBUG: Categorization finished. IsLoading: \(isLoading)")
    }
}
