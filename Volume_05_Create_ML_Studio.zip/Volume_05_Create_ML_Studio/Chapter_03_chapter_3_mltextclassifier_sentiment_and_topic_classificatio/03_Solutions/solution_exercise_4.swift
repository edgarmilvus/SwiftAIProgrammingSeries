
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import CoreML

// MARK: - App Structure (for a runnable SwiftUI app)
@main
struct ContentModeratorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentModeratorView()
                .frame(minWidth: 500, minHeight: 450) // Set initial window size for macOS
        }
    }
}

// MARK: - ContentModeratorView
@available(iOS 18.0, macOS 15.0, *) // Adjust minimum OS versions as needed
struct ContentModeratorView: View {
    @State private var contentText: String = ""
    @State private var moderationResult: String = "Enter content to moderate."
    @State private var probabilityDetails: String = ""
    let confidenceThreshold: Double = 0.75 // 75% confidence threshold for automated action

    // Load the ContentModerator model
    let moderator: ContentModerator = {
        do {
            let config = MLModelConfiguration()
            return try ContentModerator(configuration: config)
        } catch {
            fatalError("Failed to load ContentModerator: \(error.localizedDescription)")
        }
    }()

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Social Media Content Moderation")
                .font(.title)
                .padding(.bottom)

            TextEditor(text: $contentText)
                .frame(height: 150)
                .border(Color.gray, width: 1)
                .padding(.bottom)
                .accessibilityLabel("Social Media Content Input")

            Button("Moderate Content") {
                moderateContent()
            }
            .buttonStyle(.borderedProminent)
            .accessibilityLabel("Moderate Content Button")

            Divider()

            Text("Moderation Status:")
                .bold()
            Text(moderationResult)
                .font(.headline)
                .foregroundColor(statusColor(for: moderationResult)) // Dynamic color based on status
                .accessibilityLabel("Moderation Status Result")
                .accessibilityValue(moderationResult)

            Text("Prediction Confidence:")
                .bold()
                .padding(.top, 5)
            Text(probabilityDetails)
                .font(.footnote)
                .foregroundColor(.secondary)
                .accessibilityLabel("Prediction Confidence Details")
                .accessibilityValue(probabilityDetails)

            Spacer()
        }
        .padding()
        .navigationTitle("Content Moderator") // For potential navigation contexts
    }

    /// Determines the color for the moderation status text.
    private func statusColor(for status: String) -> Color {
        switch status {
        case "Inappropriate": return .red
        case "Review Needed": return .orange
        case "Appropriate": return .green
        default: return .primary
        }
    }

    /// Moderates the user-entered content, including uncertainty handling.
    func moderateContent() {
        guard !contentText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            moderationResult = "Please enter some content."
            probabilityDetails = ""
            return
        }

        do {
            // Use the prediction method that returns labelProbs
            let prediction = try moderator.prediction(from: contentText)
            let predictedLabel = prediction.label
            let probabilities = prediction.labelProbs

            // Find the highest probability among all labels
            let maxProb = probabilities.values.max() ?? 0.0

            // Format probabilities for display
            let formattedProbs = probabilities.sorted { $0.value > $1.value }.map { (key, value) in
                "\(key): \(String(format: "%.1f", value * 100))%"
            }.joined(separator: ", ")
            probabilityDetails = formattedProbs

            // Apply uncertainty handling logic
            if maxProb < confidenceThreshold {
                moderationResult = "Review Needed (Confidence below \(String(format: "%.0f", confidenceThreshold * 100))%)"
            } else {
                moderationResult = predictedLabel
            }

        } catch {
            moderationResult = "Error moderating content: \(error.localizedDescription)"
            probabilityDetails = ""
            print("Moderation error: \(error)")
        }
    }
}
