
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.swift
// Description: Solution for Exercise 6
// ==========================================

// PopoverRootView.swift (Updated for Exercise 4)
import SwiftUI

struct PopoverRootView: View {
    @Binding var isPopoverShown: Bool
    @StateObject private var llamaService = LlamaService() // Instantiate LlamaService
    
    @State private var topic: String = ""
    @State private var isDarkMode: Bool = false // Kept from Exercise 2/3

    var body: some View {
        VStack(spacing: 15) {
            Text("Brainstormer: Real-time LLM Generator")
                .font(.headline)
                .padding(.bottom, 5)

            // Model loading indicator
            if llamaService.isLoadingModel {
                ProgressView("Loading LLM model...")
                    .progressViewStyle(.circular)
                    .padding(.vertical, 10)
            } else if llamaService.llama == nil {
                Text("LLM model not loaded.")
                    .foregroundColor(.red)
                    .font(.caption)
                    .padding(.vertical, 10)
                Button("Try Load Model") {
                    llamaService.loadModel()
                }
                .buttonStyle(.bordered)
            } else {
                // Topic Input
                TextField("Enter a topic (e.g., 'app ideas')", text: $topic)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                    .frame(width: 220)

                // Generate/Stop Buttons
                HStack {
                    Button("Generate Ideas") {
                        llamaService.generate(prompt: "Generate 5 ideas for: \(topic)")
                    }
                    .padding(.horizontal)
                    .buttonStyle(.borderedProminent)
                    .disabled(topic.isEmpty || llamaService.isGenerating)

                    if llamaService.isGenerating {
                        Button("Stop") {
                            llamaService.stopGeneration()
                        }
                        .buttonStyle(.bordered)
                        .tint(.red)
                    }
                }

                // Loading Indicator for generation
                if llamaService.isGenerating {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .padding(.vertical, 10)
                }

                // Generated Ideas Display (streaming)
                ScrollView {
                    Text(llamaService.currentResponse.isEmpty ? "Ideas will appear here..." : llamaService.currentResponse)
                        .font(.subheadline)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(8)
                }
                .frame(maxHeight: 150)
                .border(Color.gray.opacity(0.3), width: 1)
                .cornerRadius(5)
                .padding(.horizontal)
            }
            
            // Toggle for Dark Mode (from Exercise 2)
            Toggle(isOn: $isDarkMode) {
                Text("Dark Mode")
            }
            .toggleStyle(.switch)
            .padding(.horizontal)
            .frame(width: 220, alignment: .leading)
            .padding(.top, 5)

            Spacer()

            Button("Dismiss") {
                isPopoverShown = false
            }
            .buttonStyle(.bordered)
            .tint(isDarkMode ? .white : .accentColor)
        }
        .padding()
        .frame(width: 280, height: 400)
        .background(isDarkMode ? Color.black.opacity(0.9) : Color.white)
        .foregroundColor(isDarkMode ? Color.white : Color.black)
        .cornerRadius(10)
        .onAppear {
            // Load model when popover appears, if not already loaded
            if llamaService.llama == nil && !llamaService.isLoadingModel {
                llamaService.loadModel()
            }
        }
        // Error Alert
        .alert("LLM Error", isPresented: $llamaService.showingErrorAlert, presenting: llamaService.errorMessage) { errorMessage in
            Button("OK") { llamaService.showingErrorAlert = false }
        } message: { errorMessage in
            Text(errorMessage)
        }
    }
}
