
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

struct PromptVariant: Sendable {
    let versionID: String
    let systemPrompt: String
}

struct PromptMetadata: Sendable {
    let versionID: String
    let modelID: String
    let latency: TimeInterval
}

struct AIResponse: Sendable {
    let text: String
    let metadata: PromptMetadata
}

actor PromptExperimentEngine {
    private let flagProvider: FeatureFlagProvider
    private var assignedVariant: PromptVariant?
    
    init(flagProvider: FeatureFlagProvider) {
        self.flagProvider = flagProvider
    }
    
    func getVariant() async -> PromptVariant {
        // Implementation of "Session Stickiness"
        if let existing = assignedVariant { return existing }
        
        let useCoT = await flagProvider.isEnabled(.experimentalPromptV2)
        
        let variant: PromptVariant
        if useCoT {
            variant = PromptVariant(versionID: "cot_v1", systemPrompt: "Think step-by-step.")
        } else {
            variant = PromptVariant(versionID: "direct_v1", systemPrompt: "Give a direct answer.")
        }
        
        self.assignedVariant = variant
        return variant
    }
}

final class AIClient: Sendable {
    private let engine: PromptExperimentEngine
    private let service: LLMService
    private let modelID: String = "gpt-4o"

    init(engine: PromptExperimentEngine, service: LLMService) {
        self.engine = engine
        self.service = service
    }

    func ask(prompt: String) async throws -> AIResponse {
        let variant = await engine.getVariant()
        let fullPrompt = "\(variant.systemPrompt)\n\nUser: \(prompt)"
        
        let start = ContinuousClock.now
        let text = try await service.generateResponse(prompt: fullPrompt)
        let duration = start.duration(to: .now)
        
        // Convert Duration to TimeInterval (seconds)
        let seconds = Double(duration.components.seconds) + Double(duration.components.attoseconds) * 1e-18
        
        let metadata = PromptMetadata(
            versionID: variant.versionID,
            modelID: modelID,
            latency: seconds
        )
        
        return AIResponse(text: text, metadata: metadata)
    }
}
