/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part5.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ==============================================================================
 * FILE: app/actions.ts
 * PURPOSE: Server Actions.
 *          Secure, type-safe mutations running exclusively on the server.
 *          No API route required.
 * ==============================================================================
 */
'use server';

import { revalidatePath } from 'next/cache';

export async function updateProjectName(prevState: any, formData: FormData) {
  const projectId = formData.get('projectId') as string;
  const newName = formData.get('projectName') as string;

  if (!newName || newName.length < 3) {
    return { message: 'Name must be at least 3 characters.' };
  }

  // Perform secure DB update
  // await db.project.update({ where: { id: projectId }, data: { name: newName } });
  console.log(`Updating project ${projectId} to ${newName}`);

  // Revalidate the cache for the dashboard page
  revalidatePath(`/projects/${projectId}/dashboard`);

  return { message: `Successfully updated to ${newName}` };
}
