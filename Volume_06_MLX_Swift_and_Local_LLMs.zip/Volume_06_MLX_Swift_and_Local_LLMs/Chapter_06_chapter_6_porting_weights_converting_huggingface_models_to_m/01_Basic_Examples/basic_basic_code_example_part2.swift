
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import MLX
import MLXNN

// Ensure this code is available for the required OS versions.
// MLX Swift typically targets macOS 14+ and iOS 17+.
@available(macOS 14.0, iOS 17.0, *)
final class SimpleSentimentClassifier: MLXNN.Module {
    /// A linear layer to project input features to an intermediate dimension.
    let linear1: MLXNN.Linear
    /// A linear layer to project the intermediate dimension to the output (e.g., sentiment score).
    let linear2: MLXNN.Linear

    /// Initializes the sentiment classifier with specified input and hidden dimensions.
    /// - Parameters:
    ///   - inputDim: The dimensionality of the input feature vector (e.g., word embedding size).
    ///   - hiddenDim: The dimensionality of the hidden layer.
    ///   - outputDim: The dimensionality of the output (e.g., 1 for a single sentiment score).
    init(inputDim: Int, hiddenDim: Int, outputDim: Int) {
        self.linear1 = MLXNN.Linear(inputSize: inputDim, outputSize: hiddenDim)
        self.linear2 = MLXNN.Linear(inputSize: hiddenDim, outputSize: outputDim)
        super.init() // Call the superclass initializer
    }

    /// Performs the forward pass of the model.
    /// - Parameter input: An `MLXArray` representing the input features.
    /// - Returns: An `MLXArray` representing the model's output (e.g., raw sentiment score).
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Apply the first linear layer, then a ReLU activation function.
        let x = MLX.relu(linear1(input))
        // Apply the second linear layer to produce the final output.
        return linear2(x)
    }

    /// A utility function to load weights from a dictionary.
    /// In a real application, this dictionary would come from deserializing a file
    /// (e.g., .safetensors, .npz) that contains the converted MLXArray weights.
    /// - Parameter weights: A dictionary where keys are parameter names (e.g., "linear1.weight")
    ///                      and values are `MLXArray` instances.
    func load(weights: [String: MLXArray]) {
        // Iterate through the model's parameters and assign the loaded weights.
        for (name, param) in self.parameters() {
            if let loadedWeight = weights[name] {
                // Ensure shapes match to prevent runtime errors.
                // In a real scenario, you might add more robust shape checking.
                precondition(param.shape == loadedWeight.shape,
                             "Shape mismatch for parameter \(name): expected \(param.shape), got \(loadedWeight.shape)")
                param.update(loadedWeight) // Update the parameter with the loaded MLXArray
                print("Loaded weight for: \(name)")
            } else {
                print("Warning: No loaded weight found for parameter: \(name)")
            }
        }
    }
}

// --- Main Application Logic ---

@available(macOS 14.0, iOS 17.0, *)
class ChatSentimentAnalyzer {

    private var classifier: SimpleSentimentClassifier

    init() {
        // 1. Define Model Architecture
        // These dimensions would match the original HuggingFace model's architecture.
        let inputDimension = 128 // e.g., embedding size for a word or phrase
        let hiddenDimension = 64
        let outputDimension = 1   // Single output for sentiment score (e.g., -1 to 1)

        classifier = SimpleSentimentClassifier(
            inputDim: inputDimension,
            hiddenDim: hiddenDimension,
            outputDim: outputDimension
        )

        // 2. Simulate Loading Ported Weights
        // In a real application, 'portedWeights' would be loaded from a file
        // (e.g., a .safetensors file) that was generated by a Python script
        // converting the HuggingFace model's weights to MLX format.
        // We're creating dummy MLXArrays here for demonstration.
        let portedWeights: [String: MLXArray] = [
            "linear1.weight": MLXArray.rand([hiddenDimension, inputDimension], stream: .current),
            "linear1.bias": MLXArray.rand([hiddenDimension], stream: .current),
            "linear2.weight": MLXArray.rand([outputDimension, hiddenDimension], stream: .current),
            "linear2.bias": MLXArray.rand([outputDimension], stream: .current)
        ]

        // Assign the loaded weights to the model.
        print("--- Loading Ported Weights ---")
        classifier.load(weights: portedWeights)
        print("--- Weights Loaded Successfully ---")
    }

    /// Performs sentiment analysis on a given input feature vector.
    /// - Parameter inputFeatures: An `MLXArray` representing the input to the model.
    ///                            This would typically be an embedding of the chat message.
    /// - Returns: A `Double` representing the sentiment score.
    func analyzeSentiment(inputFeatures: MLXArray) -> Double {
        print("\n--- Performing Sentiment Analysis ---")

        // 3. Perform Inference
        // The `classifier` is called like a function, executing its `callAsFunction` method.
        // MLX uses lazy evaluation: the computation graph is built, but not executed yet.
        let output = classifier(inputFeatures)

        // 4. Eager Execution and Unified Memory
        // `output.eval()` forces the computation graph to execute on the GPU/Neural Engine.
        // The result is computed and made available.
        // Because MLX leverages Apple's Unified Memory architecture, the MLXArray
        // data can be accessed directly by the CPU after `eval()` without costly
        // memory copies between CPU and GPU memory. This is a "zero-copy" benefit.
        output.eval()

        // Access the scalar result.
        let sentimentScore = output.item(Float.self)
        print("Input features shape: \(inputFeatures.shape)")
        print("Raw sentiment score: \(sentimentScore)")
        print("--- Sentiment Analysis Complete ---")

        return Double(sentimentScore)
    }

    /// Demonstrates a basic functional transformation: calculating value and gradient.
    /// While not typically part of *inference* or *weight loading*, this illustrates
    /// MLX's core functional API for training/fine-tuning.
    /// - Parameters:
    ///   - inputFeatures: The input to the model.
    ///   - targetScore: A dummy target score for demonstration.
    func demonstrateGradient(inputFeatures: MLXArray, targetScore: MLXArray) {
        print("\n--- Demonstrating Value and Gradient (for fine-tuning) ---")

        // Define a simple loss function for demonstration.
        // This closure captures the model and calculates Mean Squared Error.
        let lossFn = { (model: SimpleSentimentClassifier, input: MLXArray, target: MLXArray) -> MLXArray in
            let prediction = model(input)
            let loss = MLX.mean(MLX.square(prediction - target))
            return loss
        }

        // `valueAndGradient` is an MLX functional transformation.
        // It takes a function (our `lossFn`) and returns a new function
        // that computes both the value of the original function (the loss)
        // and the gradients of that value with respect to the model's parameters.
        let valueAndGradFn = valueAndGradient(lossFn)

        // Execute the transformed function.
        // This builds and executes the computation graph for both forward pass and backward pass.
        let (loss, gradients) = valueAndGradFn(classifier, inputFeatures, targetScore)

        // `eval()` to force computation and retrieve results.
        loss.eval()
        gradients.eval()

        print("Computed Loss: \(loss.item(Float.self))")
        print("Gradients for parameters:")
        for (name, grad) in gradients {
            print("  \(name): \(grad.shape)")
            // In a real scenario, you'd use these gradients to update model parameters
            // using an optimizer (e.g., SGD, Adam).
        }
        print("--- Gradient Demonstration Complete ---")
    }
}

// --- Entry Point for Demonstration ---

@available(macOS 14.0, iOS 17.0, *)
func runSentimentAnalysisDemo() {
    let analyzer = ChatSentimentAnalyzer()

    // Create dummy input features representing a chat message.
    // Shape: [batch_size, input_dimension]
    let dummyInput = MLXArray.rand([1, 128], stream: .current)

    // Perform sentiment analysis.
    let score = analyzer.analyzeSentiment(inputFeatures: dummyInput)
    print("Final sentiment score: \(String(format: "%.4f", score))")

    // Demonstrate gradient calculation (simulating a fine-tuning step).
    let dummyTargetScore = MLXArray(0.8, stream: .current) // Example target
    analyzer.demonstrateGradient(inputFeatures: dummyInput, targetScore: dummyTargetScore)
}

// Call the demo function to execute the example.
// This would typically be called from your app's main entry point, e.g.,
// in an `@main` App struct or `AppDelegate`.
// Ensure it's called on the main thread if it interacts with UI,
// but for pure MLX computation, it can be on a background thread.
// For this simple example, we'll run it directly.
if #available(macOS 14.0, iOS 17.0, *) {
    runSentimentAnalysisDemo()
} else {
    print("MLX Swift requires macOS 14.0+ or iOS 17.0+ to run this example.")
}
