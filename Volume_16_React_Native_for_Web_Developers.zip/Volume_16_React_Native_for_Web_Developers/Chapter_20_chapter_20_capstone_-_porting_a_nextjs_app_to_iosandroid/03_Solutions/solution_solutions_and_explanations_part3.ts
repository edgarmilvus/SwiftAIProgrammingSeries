/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// components/ProductCard.tsx
import React from 'react';
import { View, Text, Image, Pressable, Platform } from 'react-native';
import { cn } from '../lib/utils'; // Assume this is configured with Tailwind

// Define the Props interface
interface ProductCardProps {
  title: string;
  price: number | null;
  imageUrl: string;
}

export default function ProductCard({ title, price, imageUrl }: ProductCardProps) {
  return (
    <Pressable
      // Apply base styles and platform-specific active/hover states
      className={({ pressed }) => 
        cn(
          'flex-row items-center p-4 bg-white rounded-lg shadow-sm border border-gray-100 mb-3 transition-all',
          // Native: active state (pressed)
          pressed && 'active:opacity-75 active:scale-95',
          // Web: hover state (handled by CSS in NativeWind)
          'hover:shadow-md hover:border-gray-200'
        )
      }
      // Fallback for web hover if needed via inline styles or CSS
      style={({ pressed }) => Platform.OS === 'ios' && pressed ? { opacity: 0.75 } : {}}
    >
      {/* Image Container */}
      <View className="w-16 h-16 rounded-md overflow-hidden bg-gray-200 mr-4">
        <Image 
          source={{ uri: imageUrl }} 
          className="w-full h-full object-cover"
          resizeMode="cover"
        />
      </View>

      {/* Content Container */}
      <View className="flex-1 justify-center">
        <Text className="text-base font-semibold text-gray-900 mb-1" numberOfLines={1}>
          {title}
        </Text>
        
        {/* Conditional Price Rendering */}
        {price !== null ? (
          <Text className="text-sm font-bold text-green-600">
            ${price.toFixed(2)}
          </Text>
        ) : (
          <View className="bg-gray-100 px-2 py-1 rounded self-start">
            <Text className="text-xs font-medium text-gray-500 uppercase tracking-wide">
              Call for Price
            </Text>
          </View>
        )}
      </View>
    </Pressable>
  );
}
