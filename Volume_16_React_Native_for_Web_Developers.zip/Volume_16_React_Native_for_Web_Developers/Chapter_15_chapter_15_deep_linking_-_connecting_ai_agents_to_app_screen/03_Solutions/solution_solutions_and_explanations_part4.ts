/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// AIChatScreen.tsx
import React, { useState } from 'react';
import { View, TextInput, Button, Text, ScrollView } from 'react-native';
import * as Linking from 'expo-linking';

type LogEntry = { agent: string; message: string };

const AIChatScreen = () => {
  const [input, setInput] = useState('');
  const [logs, setLogs] = useState<LogEntry[]>([]);

  const addLog = (agent: string, message: string) => {
    setLogs(prev => [...prev, { agent, message }]);
  };

  // 1. Navigation Agent Logic
  const generateDeepLinkFromIntent = (intent: string): string | null => {
    const lowerIntent = intent.toLowerCase();
    if (lowerIntent.includes('settings')) return Linking.createURL('/settings');
    if (lowerIntent.includes('profile')) return Linking.createURL('/profile/me');
    if (lowerIntent.includes('search')) {
      const query = lowerIntent.replace('search for', '').trim();
      return `${Linking.createURL('/search')}?q=${encodeURIComponent(query)}`;
    }
    return null;
  };

  // 2. Consensus Mechanism (Validation)
  const validateLink = (url: string): boolean => {
    // Check if URL starts with our app's scheme
    return url.startsWith(Linking.createURL('/'));
  };

  // 3. Executor Agent Logic
  const executeNavigation = async (url: string) => {
    const canOpen = await Linking.canOpenURL(url);
    if (canOpen) {
      await Linking.openURL(url);
      return `Navigated via ${url}`;
    }
    return 'App not installed or cannot handle URL';
  };

  const processCommand = async () => {
    setLogs([]); // Reset logs for new command
    addLog('User', input);

    // Step 1: Supervisor Agent
    addLog('Supervisor', 'Interpreting intent...');
    const intentType = input.toLowerCase().includes('search') || 
                       input.toLowerCase().includes('profile') || 
                       input.toLowerCase().includes('settings') 
                       ? 'Navigation' : 'Unknown';
    
    if (intentType === 'Unknown') {
      addLog('Supervisor', 'Task not recognized.');
      return;
    }

    // Step 2: Worker Agent (Navigation)
    addLog('Worker (Nav)', 'Generating deep link...');
    const link = generateDeepLinkFromIntent(input);
    
    if (!link) {
      addLog('Worker (Nav)', 'Failed to generate link.');
      return;
    }
    addLog('Worker (Nav)', `Generated: ${link}`);

    // Step 3: Reviewer Node (Consensus)
    addLog('Reviewer', 'Validating link format...');
    const isValid = validateLink(link);
    
    if (!isValid) {
      addLog('Reviewer', 'Validation failed. Aborting.');
      return;
    }
    addLog('Reviewer', 'Link is valid.');

    // Step 4: Executor Agent
    addLog('Executor', 'Executing navigation...');
    const result = await executeNavigation(link);
    addLog('Executor', result);
  };

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <View style={{ flexDirection: 'row' }}>
        <TextInput 
          style={{ flex: 1, borderWidth: 1, padding: 8 }} 
          value={input} 
          onChangeText={setInput} 
          placeholder="e.g. Go to settings" 
        />
        <Button title="Send" onPress={processCommand} />
      </View>
      
      <ScrollView style={{ marginTop: 20 }}>
        {logs.map((log, idx) => (
          <Text key={idx} style={{ fontWeight: log.agent === 'User' ? 'bold' : 'normal', marginVertical: 2 }}>
            <Text style={{ color: 'gray' }}>[{log.agent}]</Text> {log.message}
          </Text>
        ))}
      </ScrollView>
    </View>
  );
};

export default AIChatScreen;
