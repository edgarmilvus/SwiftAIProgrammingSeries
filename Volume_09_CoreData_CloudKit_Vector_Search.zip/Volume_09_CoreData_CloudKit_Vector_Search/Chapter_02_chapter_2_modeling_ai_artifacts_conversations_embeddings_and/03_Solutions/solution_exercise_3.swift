
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import Accelerate
import CoreData

@available(iOS 18.0, *)
actor SemanticSearchService {
    private let embeddingService = EmbeddingService()

    /// Performs a semantic search by comparing a query vector to all stored note vectors.
    func search(query: String, in notes: [Note], topK: Int) async throws -> [(Note, Float)] {
        // 1. Generate query embedding
        let queryData = try await embeddingService.generateAndConvert(for: query)
        let queryVector = embeddingService.convertFromData(queryData)
        
        // 2. Calculate similarities in parallel/background
        var results: [(Note, Float)] = []
        
        for note in notes {
            guard let noteData = note.embedding else { continue }
            let noteVector = embeddingService.convertFromData(noteData)
            
            let similarity = cosineSimilarity(queryVector, noteVector)
            results.append((note, similarity))
        }
        
        // 3. Sort by highest similarity and return top K
        return results.sorted { $0.1 > $1.1 }.prefix(topK).map { $0 }
    }

    /// Hardware-accelerated Cosine Similarity using Accelerate (vDSP)
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count, !a.isEmpty else { return 0 }
        
        var dotProduct: Float = 0
        // vDSP_dotpr: Computes the dot product of two vectors using SIMD
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        
        // Calculate magnitudes: ||A|| and ||B||
        var sumSqA: Float = 0
        var sumSqB: Float = 0
        vDSP_svesq(a, 1, &sumSqA, vDSP_Length(a.count))
        vDSP_svesq(b, 1, &sumSqB, vDSP_Length(b.count))
        
        let magnitudeA = sqrt(sumSqA)
        let magnitudeB = sqrt(sumSqB)
        
        guard magnitudeA > 0 && magnitudeB > 0 else { return 0 }
        
        return dotProduct / (magnitudeA * magnitudeB)
    }
}
