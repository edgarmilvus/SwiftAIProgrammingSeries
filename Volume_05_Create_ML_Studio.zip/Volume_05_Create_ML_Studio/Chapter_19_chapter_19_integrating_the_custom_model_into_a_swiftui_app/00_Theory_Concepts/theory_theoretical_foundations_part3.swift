
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import CoreML

    @available(iOS 17.0, *) // @Observable requires iOS 17+
    @Observable
    class InferenceViewModel {
        var predictionLabel: String?
        var confidence: Double?
        var isLoading: Bool = false
        var error: Error?

        // In a real app, this would interact with the ModelManager actor
        // For simplicity, let's simulate a prediction
        func performDummyPrediction() async {
            isLoading = true
            error = nil
            do {
                // Simulate network/model delay
                try await Task.sleep(for: .seconds(1))
                // Simulate successful prediction
                self.predictionLabel = "Golden Retriever"
                self.confidence = 0.98
            } catch {
                self.error = error
            }
            isLoading = false
        }
    }

    @available(iOS 17.0, *)
    struct PredictionView: View {
        @State private var viewModel = InferenceViewModel() // An instance of the observable view model

        var body: some View {
            VStack {
                if viewModel.isLoading {
                    ProgressView("Predicting...")
                } else if let label = viewModel.predictionLabel, let confidence = viewModel.confidence {
                    Text("Prediction: \(label)")
                    Text("Confidence: \(confidence, format: .percent)")
                } else if let error = viewModel.error {
                    Text("Error: \(error.localizedDescription)")
                } else {
                    Text("Tap to predict.")
                }

                Button("Get Prediction") {
                    Task {
                        await viewModel.performDummyPrediction()
                    }
                }
            }
        }
    }
    