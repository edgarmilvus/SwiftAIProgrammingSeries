
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Observation // Required for @Observable

@available(iOS 18.0, *)
@Observable
class AIResponseModel {
    var generatedText: String = "Waiting for AI..."
    var isGenerating: Bool = false
    var error: String?

    // This method would be called by our AIRequestProcessor or a similar orchestrator
    // to update the UI-facing state.
    func update(generatedText: String?, isGenerating: Bool, error: Error?) {
        self.generatedText = generatedText ?? self.generatedText
        self.isGenerating = isGenerating
        self.error = error?.localizedDescription
    }
}

@available(iOS 18.0, *)
struct AIView: View {
    @State private var query: String = ""
    @State private var responseModel = AIResponseModel()
    private let aiProcessor = AIRequestProcessor() // Or injected via environment

    var body: some View {
        VStack {
            TextField("Enter your query", text: $query)
                .textFieldStyle(.roundedBorder)
                .padding()

            Button("Ask AI") {
                responseModel.isGenerating = true
                responseModel.error = nil
                Task {
                    do {
                        let result = try await aiProcessor.processPrompt(query)
                        responseModel.update(generatedText: result, isGenerating: false, error: nil)
                    } catch {
                        responseModel.update(generatedText: nil, isGenerating: false, error: error)
                    }
                }
            }
            .disabled(responseModel.isGenerating)

            if responseModel.isGenerating {
                ProgressView()
            } else if let error = responseModel.error {
                Text("Error: \(error)")
                    .foregroundColor(.red)
            } else {
                Text(responseModel.generatedText)
                    .padding()
            }
        }
    }
}
