
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import XCTest

// 1. Protocol Definition
enum NetworkError: Error, Sendable {
    case timeout
}

protocol LLMProvider: Sendable {
    func fetchResponse(for prompt: String) async throws -> String
}

// 2. The Mock Implementation
final class MockLLMProvider: LLMProvider, @unchecked Sendable {
    var mockResult: Result<String, Error>?
    var delayNanoseconds: UInt64 = 0
    var callCount = 0

    func fetchResponse(for prompt: String) async throws -> String {
        callCount += 1
        if delayNanoseconds > 0 {
            try await Task.sleep(nanoseconds: delayNanoseconds)
        }
        
        guard let result = mockResult else {
            throw NetworkError.timeout
        }
        
        switch result {
        case .success(let text): return text
        case .failure(let error): throw error
        }
    }
}

// 3. ViewModel Logic
@MainActor
final class ChatViewModel: ObservableObject {
    @Published var messages: [String] = []
    @Published var errorMessage: String?
    @Published var isProcessing: Bool = false
    
    private let provider: LLMProvider
    
    init(provider: LLMProvider) {
        self.provider = provider
    }
    
    func sendPrompt(_ prompt: String) async {
        guard !isProcessing else { return } // Prevent race conditions
        
        isProcessing = true
        errorMessage = nil
        
        do {
            let response = try await provider.fetchResponse(for: prompt)
            if !response.isEmpty {
                messages.append(response)
            }
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isProcessing = false
    }
}

// 4. Unit Test Cases
final class NomadAITests: XCTestCase {
    var sut: ChatViewModel!
    var mockProvider: MockLLMProvider!

    @MainActor
    override func setUp() {
        mockProvider = MockLLMProvider()
        sut = ChatViewModel(provider: mockProvider)
    }

    @MainActor
    func test_sendPrompt_success_updatesMessages() async {
        // Arrange
        mockProvider.mockResult = .success("Paris is beautiful")
        
        // Act
        await sut.sendPrompt("Tell me about Paris")
        
        // Assert
        XCTAssertEqual(sut.messages.count, 1)
        XCTAssertEqual(sut.messages.first, "Paris is beautiful")
        XCTAssertNil(sut.errorMessage)
    }

    @MainActor
    func test_sendPrompt_error_updatesErrorMessage() async {
        // Arrange
        mockProvider.mockResult = .failure(NetworkError.timeout)
        
        // Act
        await sut.sendPrompt("Hello")
        
        // Assert
        XCTAssertTrue(sut.messages.isEmpty)
        XCTAssertNotNil(sut.errorMessage)
    }

    @MainActor
    func test_sendPrompt_emptyResponse_doesNotAddMessage() async {
        // Arrange
        mockProvider.mockResult = .success("")
        
        // Act
        await sut.sendPrompt("Say nothing")
        
        // Assert
        XCTAssertTrue(sut.messages.isEmpty)
    }
    
    @MainActor
    func test_sendPrompt_preventsConcurrentRequests() async {
        // Arrange
        mockProvider.mockResult = .success("Slow response")
        mockProvider.delayNanoseconds = 1_000_000_000 // 1 second
        
        // Act: Fire two requests simultaneously
        async let firstCall: () = sut.sendPrompt("First")
        async let secondCall: () = sut.sendPrompt("Second")
        let _ = await [firstCall, secondCall]
        
        // Assert: Only one request should have actually been processed by the provider
        XCTAssertEqual(mockProvider.callCount, 1)
    }
}
