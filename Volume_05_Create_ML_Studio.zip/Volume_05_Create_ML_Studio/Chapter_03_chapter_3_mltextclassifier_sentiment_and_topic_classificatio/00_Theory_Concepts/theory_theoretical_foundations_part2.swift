
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import CoreML
    import Foundation // For URL

    // Assuming MyTextClassifier is the generated class from your .mlmodel
    @available(iOS 18.0, macOS 15.0, *)
    actor ModelPredictor {
        private var model: MyTextClassifier // Assume MyTextClassifier is the generated class

        init() async throws {
            // Load the model asynchronously
            let config = MLModelConfiguration()
            self.model = try await MyTextClassifier(configuration: config)
        }

        func predictSentiment(for text: String) async throws -> (String, Double) {
            let prediction = try await model.prediction(text: text)
            // Core ML models typically return a dictionary of confidence scores
            // and the top prediction.
            let topLabel = prediction.label
            let confidence = prediction.labelProbs[topLabel] ?? 0.0
            return (topLabel, confidence)
        }

        func batchPredictSentiments(for texts: [String]) async throws -> [(String, Double)] {
            var results: [(String, Double)] = []
            for text in texts {
                let (label, confidence) = try await predictSentiment(for: text)
                results.append((label, confidence))
            }
            return results
        }
    }
    