
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift (Illustrative for demonstrating SPM structure)
// For Apple Intelligence features, you primarily rely on system frameworks.
// This snippet shows how you *would* declare dependencies if they were external.

/*
import PackageDescription

let package = Package(
    name: "MeetingNotesApp",
    platforms: [
        .iOS(.v18), // Requires iOS 18 for Apple Intelligence and advanced App Intents
        .macOS(.v15) // Or other platforms supporting App Intents
    ],
    products: [
        .library(
            name: "MeetingNotesCore",
            targets: ["MeetingNotesCore"]),
    ],
    dependencies: [
        // AppIntents is a system framework, but if it were a package:
        // .package(url: "https://github.com/apple/swift-app-intents", from: "1.0.0"),
        // Future Apple Intelligence-specific packages could go here.
    ],
    targets: [
        .target(
            name: "MeetingNotesCore",
            dependencies: [
                // .product(name: "AppIntents", package: "swift-app-intents"),
            ]),
    ]
)
*/

import Foundation
import AppIntents // Core framework for App Intents, available on iOS 18+
import os.log // For structured logging, a best practice in production apps

// Mark the entire file as available for iOS 18.0 and later, as Apple Intelligence and
// advanced App Intents features are tied to this OS version.
@available(iOS 18.0, *)
fileprivate let logger = Logger(subsystem: "com.example.MeetingNotesApp", category: "AISummarization")

// MARK: - 1. Data Model

/// Represents a single meeting note within the application.
struct MeetingNote: Identifiable, Hashable {
    let id: UUID
    let title: String
    let content: String
    let date: Date
    let project: Project

    /// Initializes a new meeting note.
    /// - Parameters:
    ///   - id: A unique identifier for the note. Defaults to a new UUID.
    ///   - title: The title of the meeting.
    ///   - content: The detailed content/transcript of the meeting.
    ///   - date: The date the meeting took place.
    ///   - project: The project this note is associated with.
    init(id: UUID = UUID(), title: String, content: String, date: Date, project: Project) {
        self.id = id
        self.title = title
        self.content = content
        self.date = date
        self.project = project
    }
}

/// Represents a project that meeting notes can be associated with.
struct Project: Identifiable, Hashable {
    let id: UUID
    let name: String

    /// Initializes a new project.
    /// - Parameters:
    ///   - id: A unique identifier for the project. Defaults to a new UUID.
    ///   - name: The name of the project.
    init(id: UUID = UUID(), name: String) {
        self.id = id
        self.name = name
    }
}

// MARK: - 2. Data Store (Mock)

/// A mock data store for `MeetingNote` objects.
/// In a real application, this would interact with persistent storage (e.g., Core Data, SwiftData, or a remote API).
@available(iOS 18.0, *)
class MeetingNotesStore {
    static let shared = MeetingNotesStore() // Singleton instance for easy access across the app

    private var notes: [MeetingNote] = []
    private var projects: [Project] = []

    private init() {
        // Seed with some dummy data for demonstration purposes
        let projectA = Project(name: "Project Alpha")
        let projectB = Project(name: "Project Beta")
        projects.append(projectA)
        projects.append(projectB)

        notes.append(MeetingNote(title: "Kickoff Meeting", content: "Discussed initial requirements, team roles, and sprint planning. Key decision: Use SwiftData for persistence. Action item: Research SwiftData migration strategies.", date: Calendar.current.date(byAdding: .day, value: -7, to: Date())!, project: projectA))
        notes.append(MeetingNote(title: "Daily Standup", content: "Team reported progress on UI components. Blockers: API integration pending backend deployment. Action item: Follow up with backend team on API readiness.", date: Calendar.current.date(byAdding: .day, value: -6, to: Date())!, project: projectA))
        notes.append(MeetingNote(title: "Client Review", content: "Presented initial mockups. Client provided feedback on color scheme and navigation flow. Action item: Revise design based on client feedback and schedule follow-up.", date: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, project: projectA))
        notes.append(MeetingNote(title: "Brainstorming Session", content: "Explored new features for analytics dashboard. Ideas included real-time data streaming and custom report generation. Key decision: Prioritize real-time streaming for MVP.", date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, project: projectB))
        notes.append(MeetingNote(title: "Weekly Sync", content: "Reviewed overall project status. Project Alpha is on track. Project Beta needs more resources for Q4. Action item: Allocate additional resources to Project Beta.", date: Date(), project: projectA))
    }

    /// Fetches meeting notes asynchronously, applying optional filters.
    /// - Parameters:
    ///   - projectName: An optional project name to filter notes by. Case-insensitive.
    ///   - dateFilter: An optional date filter to narrow down notes by their creation date.
    /// - Returns: An array of `MeetingNote` objects.
    /// - Throws: `SummarizationError.dataNotFound` if no notes match the criteria.
    func fetchMeetingNotes(projectName: String? = nil, dateFilter: DateFilter? = nil) async throws -> [MeetingNote] {
        logger.info("Fetching meeting notes with project: \(projectName ?? "N/A"), dateFilter: \(dateFilter?.rawValue ?? "N/A")")
        // Simulate network/disk latency to mimic real-world asynchronous data fetching
        try await Task.sleep(for: .milliseconds(200))

        var filteredNotes = notes

        if let projectName = projectName {
            filteredNotes = filteredNotes.filter { $0.project.name.localizedCaseInsensitiveContains(projectName) }
        }

        if let dateFilter = dateFilter {
            let now = Date()
            let calendar = Calendar.current
            switch dateFilter {
            case .today:
                filteredNotes = filteredNotes.filter { calendar.isDateInToday($0.date) }
            case .yesterday:
                filteredNotes = filteredNotes.filter { calendar.isDateInYesterday($0.date) }
            case .last7Days:
                if let sevenDaysAgo = calendar.date(byAdding: .day, value: -7, to: now) {
                    filteredNotes = filteredNotes.filter { $0.date >= sevenDaysAgo && $0.date <= now }
                }
            case .last30Days:
                if let thirtyDaysAgo = calendar.date(byAdding: .day, value: -30, to: now) {
                    filteredNotes = filteredNotes.filter { $0.date >= thirtyDaysAgo && $0.date <= now }
                }
            case .allTime:
                break // No date filtering applied for 'all time'
            }
        }

        guard !filteredNotes.isEmpty else {
            logger.warning("No meeting notes found for the given criteria.")
            throw SummarizationError.dataNotFound
        }

        // Sort by date descending for consistent summarization order (most recent first)
        return filteredNotes.sorted { $0.date > $1.date }
    }
    
    /// Fetches a project by its name.
    /// - Parameter name: The name of the project to fetch. Case-insensitive.
    /// - Returns: The `Project` object if found, otherwise `nil`.
    func fetchProject(byName name: String) async throws -> Project? {
        logger.info("Fetching project by name: \(name)")
        try await Task.sleep(for: .milliseconds(50)) // Simulate latency
        return projects.first { $0.name.localizedCaseInsensitiveContains(name) }
    }
    
    /// Returns all available projects.
    /// - Returns: An array of `Project` objects.
    var allProjects: [Project] {
        return projects
    }
}

// MARK: - 3. Apple Intelligence Summarization Service (Conceptual)

/// A conceptual service for interacting with Apple's on-device LLM for summarization.
/// This service abstracts away the specifics of the Apple Intelligence APIs (e.g., LLMSession, SummaryService).
/// It demonstrates the pattern of interaction without relying on specific, potentially unreleased, API details.
@available(iOS 18.0, *)
class AISummaryService {
    static let shared = AISummaryService()

    private init() {} // Private initializer for singleton pattern

    /// Generates a summary from a collection of text inputs, optionally guided by a context.
    /// - Parameters:
    ///   - texts: An array of strings (e.g., meeting note contents) to be summarized.
    ///   - context: An optional string providing additional context or instructions for the summary (e.g., "focus on action items").
    /// - Returns: A concise summary string.
    /// - Throws: `SummarizationError.llmFailed` if the LLM operation fails or `SummarizationError.inputTooShort` if input is insufficient.
    func generateSummary(for texts: [String], context: String? = nil) async throws -> String {
        guard !texts.isEmpty else {
            logger.error("Attempted to summarize an empty list of texts.")
            throw SummarizationError.inputTooShort
        }

        let combinedText = texts.joined(separator: "\n\n")
        
        // In a real Apple Intelligence integration, this would involve calling the actual on-device LLM API.
        // The specific APIs (e.g., within IntelligenceKit or a dedicated SummaryService) will be revealed.
        // Example conceptual API call (syntax is illustrative):
        //
        // let llmSession = LLMSession.shared // Or a specific SummaryService instance
        // let prompt = "Summarize the following meeting notes. \(context ?? "")\n\n\(combinedText)"
        // let options = LLMGenerationOptions(maxTokens: 200, temperature: 0.7) // Control output length and creativity
        // let result = try await llmSession.generate(prompt: prompt, options: options)
        // return result.text
        
        // For demonstration purposes, we'll simulate a summary generation.
        logger.info("Simulating LLM summary generation for \(texts.count) texts with context: \(context ?? "None")")
        try await Task.sleep(for: .seconds(2)) // Simulate LLM processing time, which can be non-trivial

        if combinedText.count < 50 { // Example: LLM might struggle or fail on very short input
            logger.warning("Combined text too short for meaningful summarization.")
            throw SummarizationError.inputTooShort
        }
        
        // A very basic simulated summary: take the first few sentences and add a concluding remark.
        let sentences = combinedText.components(separatedBy: CharacterSet(charactersIn: ".!?")).filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        let simulatedSummary = sentences.prefix(3).joined(separator: ". ") + ". " + (context ?? "Key points") + " were highlighted."

        // Ensure the simulated summary isn't excessively long for Siri to read out.
        let maxLength = 250 // Max characters for a reasonable Siri response
        let finalSummary = String(simulatedSummary.prefix(maxLength)) + (simulatedSummary.count > maxLength ? "..." : "")
        
        logger.info("Generated simulated summary: \(finalSummary)")
        return finalSummary
    }
}

// MARK: - 6. Error Handling Strategy

/// Custom errors for the summarization process, providing user-friendly descriptions.
/// Conforms to `LocalizedError` for user-facing messages and `CustomStringConvertible` for logging.
@available(iOS 18.0, *)
enum SummarizationError: LocalizedError, CustomStringConvertible {
    case dataNotFound
    case inputTooShort
    case llmFailed(String) // Includes a message for specific LLM failures
    case invalidProjectName
    case unknown(Error) // Captures any other unexpected errors

    var errorDescription: String? {
        switch self {
        case .dataNotFound:
            return "No meeting notes found matching your criteria. Please try a different project or date."
        case .inputTooShort:
            return "The content is too short to generate a meaningful summary. More details are needed."
        case .llmFailed(let message):
            return "The summarization service encountered an error: \(message). Please try again later."
        case .invalidProjectName:
            return "I couldn't find a project with that name. Please check the project name and try again."
        case .unknown(let error):
            return "An unexpected error occurred: \(error.localizedDescription). Please contact support if this persists."
        }
    }
    
    var description: String {
        return errorDescription ?? "An unknown error occurred." // Fallback for logging
    }
}

// MARK: - DateFilter for App Intent Parameter

/// Defines common date filters for retrieving meeting notes, making intent parameters user-friendly.
@available(iOS 18.0, *)
enum DateFilter: String, AppEnum, CaseIterable, Identifiable {
    case today = "Today"
    case yesterday = "Yesterday"
    case last7Days = "Last 7 Days"
    case last30Days = "Last 30 Days"
    case allTime = "All Time"

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Date Filter"
    static var caseDisplayRepresentations: [DateFilter: DisplayRepresentation] = [
        .today: "today",
        .yesterday: "yesterday",
        .last7Days: "last 7 days",
        .last30Days: "last 30 days",
        .allTime: "all time"
    ]

    var id: String { rawValue } // Conformance to Identifiable for SwiftUI and AppEnum
}


// MARK: - 4. The AppIntent (`SummarizeMeetingNotesIntent`)

/// An App Intent that allows Siri to summarize meeting notes based on project and date filters.
/// This intent is the primary interface for Siri to interact with the app's summarization capabilities.
@available(iOS 18.0, *)
struct SummarizeMeetingNotesIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize Meeting Notes"
    static var description = IntentDescription(
        "Generates a summary of meeting notes, optionally filtered by project or date, using Apple Intelligence.",
        category: .productivity,
        searchKeywords: ["meeting", "notes", "summary", "AI", "intelligence", "project", "Siri"]
    )

    /// The optional name of the project to filter notes by.
    /// Siri can suggest existing project names dynamically.
    @Parameter(title: "Project Name", description: "The name of the project to summarize notes for.", requestValueDialog: "Which project's notes would you like to summarize?")
    var projectName: String?

    /// The date range to filter meeting notes by.
    /// Defaults to 'today' for convenience, allowing users to quickly summarize recent meetings.
    @Parameter(title: "Date Filter", description: "Filter notes by their creation date.", default: .today)
    var dateFilter: DateFilter
    
    /// Provides dynamic options for the `projectName` parameter.
    /// This allows Siri to suggest existing project names from `MeetingNotesStore`, improving user experience.
    static func projectOptionsCollection(for projectName: String?) -> IntentProjectOptionsCollection {
        let store = MeetingNotesStore.shared
        // Assuming projects are accessible synchronously for options, or cached.
        // In a more complex app, this might also be async.
        let allProjects = store.allProjects.map { IntentProject(id: $0.id.uuidString, name: $0.name) }
        
        if let projectName = projectName, !projectName.isEmpty {
            let filtered = allProjects.filter { $0.name.localizedStandardContains(projectName) }
            return IntentProjectOptionsCollection(filtered)
        }
        return IntentProjectOptionsCollection(allProjects)
    }
    
    /// A nested type for dynamic options, conforming to `AppEntity`.
    /// This is used by `projectOptionsCollection` to represent selectable projects.
    struct IntentProject: AppEntity {
        let id: String
        let name: String
        
        static var typeDisplayRepresentation: TypeDisplayRepresentation = "Project"
        
        var displayRepresentation: DisplayRepresentation {
            DisplayRepresentation(title: "\(name)")
        }
    }

    /// The main execution block for the App Intent.
    /// This asynchronous method is called when Siri or the Shortcuts app invokes the intent.
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        logger.info("SummarizeMeetingNotesIntent initiated for project: \(projectName ?? "N/A"), dateFilter: \(dateFilter.rawValue)")

        do {
            // 1. Validate project name if provided, ensuring it exists in our store.
            if let projectName = projectName {
                let project = try await MeetingNotesStore.shared.fetchProject(byName: projectName)
                guard project != nil else {
                    logger.error("Invalid project name provided: \(projectName)")
                    throw SummarizationError.invalidProjectName
                }
            }
            
            // 2. Fetch relevant meeting notes from the data store based on user-provided filters.
            let notes = try await MeetingNotesStore.shared.fetchMeetingNotes(projectName: projectName, dateFilter: dateFilter)
            
            // 3. Extract content for summarization. Combine title and content for richer input to the LLM.
            let noteContents = notes.map { "\($0.title):\n\($0.content)" }
            
            // 4. Generate summary using the conceptual Apple Intelligence service.
            // Provide context to guide the LLM towards relevant information (e.g., action items).
            let summary = try await AISummaryService.shared.generateSummary(
                for: noteContents,
                context: "Focus on key decisions and action items from these meeting notes."
            )
            
            logger.info("Successfully generated summary.")
            // Return the summary, along with a dialog for Siri to speak/display.
            return .result(value: summary, dialog: "Here's a summary of your meeting notes: \(summary)")

        } catch let error as SummarizationError {
            logger.error("Summarization error: \(error.localizedDescription)")
            throw error // Re-throw custom error for Siri to present a user-friendly message
        } catch {
            logger.critical("Unexpected error during summarization intent: \(error.localizedDescription)")
            throw SummarizationError.unknown(error) // Wrap any other unexpected errors
        }
    }
}

// MARK: - 5. App Shortcuts Provider

/// Exposes the `SummarizeMeetingNotesIntent` to Siri and the Shortcuts app.
/// This makes the intent discoverable and allows users to define custom phrases.
@available(iOS 18.0, *)
struct MeetingNotesShortcutsProvider: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: SummarizeMeetingNotesIntent(),
            // Define natural language phrases Siri can recognize to invoke this intent.
            // .parameter(\.$propertyName) dynamically inserts parameter values.
            phrases: [
                "Summarize my \(.parameter(\.$dateFilter)) meeting notes",
                "Summarize \(.parameter(\.$projectName)) notes",
                "Summarize \(.parameter(\.$projectName)) meeting notes from \(.parameter(\.$dateFilter))",
                "Give me a summary of my \(.parameter(\.$dateFilter)) meetings"
            ],
            shortTitle: "Summarize Notes", // A concise title for the Shortcuts app
            systemImageName: "note.text" // An SF Symbol to represent the shortcut
        )
    }
}
