
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import MLX // Assuming MLX is imported for context, though not directly used in the tool itself

@available(iOS 18.0, macOS 15.0, *)
struct CalculatorTool {
    let name: String = "calculator"
    let description: String = "Performs basic arithmetic operations like addition, subtraction, multiplication, and division. Requires two operands (numbers) and an operation symbol."

    /// Performs the specified arithmetic calculation.
    /// - Parameters:
    ///   - operand1: The first number.
    ///   - operand2: The second number.
    ///   - operation: The arithmetic operation symbol (+, -, *, /).
    /// - Returns: The result of the calculation, or nil if the operation is invalid or division by zero occurs.
    func performCalculation(operand1: Double, operand2: Double, operation: String) -> Double? {
        switch operation {
        case "+": return operand1 + operand2
        case "-": return operand1 - operand2
        case "*": return operand1 * operand2
        case "/":
            guard operand2 != 0 else {
                print("Error: Division by zero.")
                return nil
            }
            return operand1 / operand2
        default:
            print("Error: Invalid operation '\(operation)'")
            return nil
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
class ToolDispatcher {
    private let calculatorTool = CalculatorTool()

    // MARK: - Decodable Structures for LLM Output Parsing

    /// Represents the arguments for the calculator tool.
    struct CalculatorArguments: Decodable {
        let operand1: Double
        let operand2: Double
        let operation: String
    }

    /// Represents a generic tool call structure from the LLM.
    struct ToolCall: Decodable {
        let name: String
        let arguments: CalculatorArguments // Specific to CalculatorTool for this exercise
    }

    /// Represents the overall LLM output containing a tool call.
    struct LLMOutput: Decodable {
        let tool_call: ToolCall
    }

    /// Dispatches a tool call based on the LLM's simulated output.
    /// - Parameter llmOutputJson: A JSON string representing the LLM's decision to call a tool.
    /// - Returns: A string representing the result of the tool call or an error message.
    func dispatchToolCall(llmOutputJson: String) -> String {
        guard let jsonData = llmOutputJson.data(using: .utf8) else {
            return "Error: Invalid JSON string."
        }

        do {
            let llmOutput = try JSONDecoder().decode(LLMOutput.self, from: jsonData)
            let toolCall = llmOutput.tool_call

            if toolCall.name == calculatorTool.name {
                let args = toolCall.arguments
                if let result = calculatorTool.performCalculation(operand1: args.operand1, operand2: args.operand2, operation: args.operation) {
                    return "The result of \(args.operand1) \(args.operation) \(args.operand2) is \(result)."
                } else {
                    return "Calculation failed due to an invalid operation or division by zero."
                }
            } else {
                return "Error: Unknown tool '\(toolCall.name)'."
            }
        } catch {
            return "Error parsing LLM output: \(error.localizedDescription)"
        }
    }
}

// Example Usage:
/*
@available(iOS 18.0, macOS 15.0, *)
func runCalculatorExercise() {
    let dispatcher = ToolDispatcher()

    // Simulate LLM output for "What is 15 times 3?"
    let llmOutput1 = """
    {
      "tool_call": {
        "name": "calculator",
        "arguments": {
          "operand1": 15.0,
          "operand2": 3.0,
          "operation": "*"
        }
      }
    }
    """
    print("User query: What is 15 times 3?")
    print("LLM output (simulated): \(llmOutput1)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput1))\n")

    // Simulate LLM output for "Divide 100 by 5"
    let llmOutput2 = """
    {
      "tool_call": {
        "name": "calculator",
        "arguments": {
          "operand1": 100.0,
          "operand2": 5.0,
          "operation": "/"
        }
      }
    }
    """
    print("User query: Divide 100 by 5")
    print("LLM output (simulated): \(llmOutput2)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput2))\n")

    // Simulate LLM output for an invalid operation
    let llmOutput3 = """
    {
      "tool_call": {
        "name": "calculator",
        "arguments": {
          "operand1": 10.0,
          "operand2": 2.0,
          "operation": "power"
        }
      }
    }
    """
    print("User query: Calculate 10 power 2")
    print("LLM output (simulated): \(llmOutput3)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput3))\n")

    // Simulate LLM output for division by zero
    let llmOutput4 = """
    {
      "tool_call": {
        "name": "calculator",
        "arguments": {
          "operand1": 10.0,
          "operand2": 0.0,
          "operation": "/"
        }
      }
    }
    """
    print("User query: Divide 10 by 0")
    print("LLM output (simulated): \(llmOutput4)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput4))\n")
}

// runCalculatorExercise()
*/
