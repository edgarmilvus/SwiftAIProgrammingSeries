
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import Swiftgger // Make sure to add this dependency in Package.swift

// MARK: - Main execution for the Command Line Tool

@main
struct CodeExplainer {
    static func main() async { // Use async for top-level code in Swift 5.5+
        print("--- Local Code Explainer powered by llama.cpp (Swiftgger) ---")

        // 1. Define the model path
        // IMPORTANT: Replace with the actual path to your downloaded GGUF model.
        // For a CLI tool, placing it in the same directory as the executable is common.
        // For a SwiftUI app, you might bundle it as a resource.
        let modelFileName = "phi-3-mini-4k-instruct.Q4_K_M.gguf"
        
        // Attempt to find the model in the current working directory
        let currentDirectory = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
        let modelPath = currentDirectory.appendingPathComponent(modelFileName)

        print("Attempting to load model from: \(modelPath.path)")

        // Check if the model file exists
        guard FileManager.default.fileExists(atPath: modelPath.path) else {
            print("\nError: Model file not found at \(modelPath.path)")
            print("Please download '\(modelFileName)' and place it in the same directory as this executable, or update the 'modelPath' variable.")
            print("You can download it from Hugging Face, e.g., 'microsoft/phi-3-mini-4k-instruct-gguf' on TheBloke.")
            return
        }

        // 2. User input for code snippet
        print("\nEnter a Swift code snippet to explain (type 'END' on a new line to finish):")
        var userCodeInput = ""
        while let line = readLine(), line != "END" {
            userCodeInput += line + "\n"
        }
        userCodeInput = userCodeInput.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !userCodeInput.isEmpty else {
            print("No code snippet provided. Exiting.")
            return
        }

        // 3. Construct the prompt
        let prompt = """
        Explain the following Swift code snippet in a concise and clear manner, focusing on its purpose, key components, and how it works.

        