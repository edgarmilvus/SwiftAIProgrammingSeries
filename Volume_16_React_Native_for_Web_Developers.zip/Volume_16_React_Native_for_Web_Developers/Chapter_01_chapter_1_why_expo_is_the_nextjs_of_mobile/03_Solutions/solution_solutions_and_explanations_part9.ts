/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/AIChat.tsx

/**
 * INTERACTIVE CHALLENGE: UNIVERSAL AI CHAT
 * 
 * PATTERN EXPLANATION:
 * This component uses standard React primitives. The logic (fetching/simulating) 
 * runs in the JavaScript thread. 
 * 
 * EXTENDING TO VERCEL AI SDK:
 * In a production scenario, you might run a Next.js server (Web) handling Vercel AI SDK 
 * streams. For mobile, you have two options:
 * 1. Mobile Web: The Expo app loads the Next.js route in a WebView.
 * 2. Native App: The Expo app calls the Next.js API endpoint directly via `fetch`.
 * 
 * TRADE-OFFS:
 * - WebView: Easier to implement, shares code with web, but slower and less native feel.
 * - Native Fetch: Faster, native UI, but requires managing network states and JSON parsing manually.
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  View, Text, TextInput, TouchableOpacity, FlatList, 
  KeyboardAvoidingView, Platform, StyleSheet, Switch 
} from 'react-native';

type Message = {
  role: 'user' | 'ai';
  content: string;
};

export default function AIChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isRealMode, setIsRealMode] = useState(false); // Interactive Twist
  const [isLoading, setIsLoading] = useState(false);
  const flatListRef = useRef<FlatList>(null);

  // Mock API call simulation
  const simulateAIResponse = async (userMessage: string): Promise<string> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (isRealMode) {
          // In "Real Mode", we would actually fetch from an API
          resolve(`Simulated API Response to: "${userMessage}"`);
        } else {
          // Local simulation logic
          const responses = [
            "That's an interesting point!",
            "I can help with that.",
            "Let me think about it...",
            "Here is a universal response."
          ];
          const randomIndex = Math.floor(Math.random() * responses.length);
          resolve(responses[randomIndex]);
        }
      }, 1500); // 1.5 second latency
    });
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    // 1. Add user message
    const userMsg: Message = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    // 2. Get AI response
    try {
      const responseContent = await simulateAIResponse(input);
      const aiMsg: Message = { role: 'ai', content: responseContent };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (flatListRef.current) {
      setTimeout(() => flatListRef.current?.scrollToEnd(), 100);
    }
  }, [messages]);

  const renderMessage = ({ item }: { item: Message }) => (
    <View style={[styles.msgBubble, item.role === 'user' ? styles.userBubble : styles.aiBubble]}>
      <Text style={styles.msgText}>{item.content}</Text>
    </View>
  );

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <View style={styles.header}>
        <Text style={styles.title}>Universal AI Chat</Text>
        <View style={styles.toggleContainer}>
          <Text>Local</Text>
          <Switch value={isRealMode} onValueChange={setIsRealMode} />
          <Text>API Mode</Text>
        </View>
      </View>

      <FlatList
        ref={flatListRef}
        data={messages}
        renderItem={renderMessage}
        keyExtractor={(item, index) => index.toString()}
        contentContainerStyle={styles.listContent}
      />

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="Ask something..."
          onSubmitEditing={handleSend}
          editable={!isLoading}
        />
        <TouchableOpacity 
          style={[styles.sendButton, isLoading && styles.disabledButton]} 
          onPress={handleSend}
          disabled={isLoading}
        >
          <Text style={styles.sendText}>{isLoading ? '...' : 'Send'}</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { 
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 15, paddingTop: 15, backgroundColor: '#fff', paddingBottom: 10
  },
  title: { fontSize: 18, fontWeight: 'bold' },
  toggleContainer: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  listContent: { padding: 15, gap: 10 },
  msgBubble: { padding: 12, borderRadius: 15, maxWidth: '80%' },
  userBubble: { backgroundColor: '#007AFF', alignSelf: 'flex-end' },
  aiBubble: { backgroundColor: '#e5e5ea', alignSelf: 'flex-start' },
  msgText: { color: '#000' },
  inputContainer: { 
    flexDirection: 'row', padding: 10, backgroundColor: '#fff', 
    borderTopWidth: 1, borderColor: '#eee' 
  },
  input: { 
    flex: 1, backgroundColor: '#f0f0f0', borderRadius: 20, 
    paddingHorizontal: 15, marginRight: 10, height: 45 
  },
  sendButton: { 
    backgroundColor: '#007AFF', justifyContent: 'center', alignItems: 'center', 
    paddingHorizontal: 20, borderRadius: 20, height: 45 
  },
  disabledButton: { backgroundColor: '#ccc' },
  sendText: { color: '#fff', fontWeight: 'bold' },
});
