
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import AppTrackingTransparency
import AdSupport

// MARK: - Models

/// Represents the possible states of our AI's personalization capability.
/// This abstraction allows the UI to react to privacy decisions without
/// being tightly coupled to the AppTrackingTransparency framework.
enum PersonalizationStatus {
    case undetermined
    case authorized
    case denied
    case restricted
}

// MARK: - Privacy Coordinator

/// `PrivacyCoordinator` is a Swift 6 Actor responsible for managing the 
/// App Tracking Transparency lifecycle.
///
/// Using an `actor` ensures that the state of our privacy permissions 
/// is protected from data races, which is critical when multiple 
/// asynchronous AI processes might query the permission status simultaneously.
actor PrivacyCoordinator {
    
    /// The current authorization status of the app.
    /// Private to the actor to prevent external mutation.
    private(set) var currentStatus: PersonalizationStatus = .undetermined

    /// Initializes the coordinator and performs an initial check of the current status.
    init() {
        // Note: In a real app, you might want to check status on startup.
        // However, status checks are often best triggered when the app 
        // reaches the 'active' state in the app lifecycle.
    }

    /// Requests tracking authorization from the user via the iOS system dialog.
    ///
    /// - Returns: A `PersonalizationStatus` representing the user's choice.
    /// - Throws: This function is designed to be non-throwing for simplicity, 
    ///   but in a production environment, you might handle system errors.
    @available(iOS 18.0, *)
    func requestPermission() async -> PersonalizationStatus {
        // 1. Check the current status before requesting.
        // If the user has already made a choice, requesting again will 
        // immediately return the existing status without showing the dialog.
        let status = ATTrackingManager.trackingAuthorizationStatus
        
        let mappedStatus: PersonalizationStatus
        switch status {
        case .notDetermined:
            mappedStatus = .undetermined
        case .restricted:
            mappedStatus = .restricted
        case .denied:
            mappedStatus = .denied
        case .authorized:
            mappedStatus = .authorized
        @unknown default:
            mappedStatus = .undetermined
        }
        
        // 2. If status is undetermined, trigger the system dialog.
        if mappedStatus == .undetermined {
            // We must ensure the app is in the 'active' state before calling this,
            // otherwise the dialog may fail to appear.
            let newStatus = await requestSystemDialog()
            self.currentStatus = newStatus
            return newStatus
        } else {
            self.currentStatus = mappedStatus
            return mappedStatus
        }
    }

    /// A private helper to wrap the legacy callback-based ATTrackingManager 
    /// into a modern Swift 6 async function.
    @available(iOS 18.0, *)
    private func requestSystemDialog() async -> PersonalizationStatus {
        // Since ATTrackingManager.requestTrackingAuthorization is a completion-handler 
        // based API, we use withCheckedContinuation to bridge it to async/await.
        return await withCheckedContinuation { continuation in
            ATTrackingManager.requestTrackingAuthorization { status in
                let mapped: PersonalizationStatus
                switch status {
                case .notDetermined: mapped = .undetermined
                case .restricted:    mapped = .restricted
                case .denied:        mapped = .denied
                case .authorized:    mapped = .authorized
                @unknown default:    mapped = .undetermined
                }
                continuation.resume(returning: mapped)
            }
        }
    }
}

// MARK: - View Model

/// `AuraViewModel` manages the UI state for the Aura AI interface.
/// It uses `@MainActor` to ensure all updates to the `@Published` properties
/// occur on the main thread, adhering to Swift 6's strict concurrency rules.
@MainActor
class AuraViewModel: ObservableObject {
    
    /// The visual state used to drive the SwiftUI view.
    @Published var status: PersonalizationStatus = .undetermined
    
    /// The coordinator instance, encapsulated within the ViewModel.
    private let privacyCoordinator = PrivacyCoordinator()
    
    /// Triggers the permission flow.
    func enableAdvancedPersonalization() async {
        // Call the actor's method. This is an 'await' because the 
        // PrivacyCoordinator is an actor and the method is async.
        let newStatus = await privacyCoordinator.requestPermission()
        
        // Update the UI on the MainActor.
        self.status = newStatus
        
        // Logic to trigger AI model reconfiguration based on status
        if newStatus == .authorized {
            print("AI: Loading cross-app context for enhanced personalization...")
        } else {
            print("AI: Switching to local-only privacy mode.")
        }
    }
}

// MARK: - UI Layer

/// The main interface for Aura AI.
struct AuraAIView: View {
    @StateObject private var viewModel = AuraViewModel()

    var body: some View {
        NavigationStack {
            VStack(spacing: 30) {
                Image(systemName: "waveform.circle.fill")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .foregroundStyle(.blue)
                
                Text("Aura AI Assistant")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("Personalization Mode:")
                        .font(.headline)
                    
                    statusBadge
                }
                .padding()
                .background(Color.secondary.opacity(0.1))
                .cornerRadius(12)

                Text(statusDescription)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                    .foregroundStyle(.secondary)

                Button(action: {
                    Task {
                        await viewModel.enableAdvancedPersonalization()
                    }
                }) {
                    Text(viewModel.status == .authorized ? "Re-evaluate Privacy" : "Enable Deep Personalization")
                        .fontWeight(.semibold)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.horizontal)
            }
            .padding()
            .navigationTitle("Settings")
        }
    }

    /// A computed property to provide a visual badge for the current status.
    @ViewBuilder
    private var statusBadge: some View {
        HStack {
            Circle()
                .fill(statusColor)
                .frame(width: 12, height: 12)
            Text(statusText)
                .font(.subheadline)
                .monospaced()
        }
    }

    private var statusColor: Color {
        switch viewModel.status {
        case .authorized: return .green
        case .denied: return .red
        case .restricted: return .orange
        case .undetermined: return .gray
        }
    }

    private var statusText: String {
        switch viewModel.status {
        case .authorized: return "AUTHORIZED"
        case .denied: return "DENIED"
        case .restricted: return "RESTRICTED"
        case .undetermined: return "NOT DETERMINED"
        }
    }

    private var statusDescription: String {
        switch viewModel.status {
        case .authorized:
            return "Aura will use your interaction patterns to build a cross-app profile for seamless assistance."
        case .denied:
            return "Personalization is limited to this device and this app only. Your data stays local."
        case .undetermined:
            return "Enable personalization to allow Aura to learn your preferences across your digital ecosystem."
        default:
            return "Privacy settings are managed by your system configuration."
        }
    }
}

// MARK: - Preview

#Preview {
    AuraAIView()
}
