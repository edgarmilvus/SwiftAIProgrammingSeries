
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI

@available(iOS 18.0, macOS 15.0, *)
struct TokenProbability: Identifiable, Equatable {
    let id = UUID() // For ForEach
    let token: String
    var probability: Double
}

@available(iOS 18.0, macOS 15.0, *)
struct TokenPredictionView: View {
    @State var topTokenPredictions: [TokenProbability] = []
    let maxDisplayTokens = 5

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Next Token Predictions:")
                .font(.headline)
                .padding(.bottom, 5)

            GeometryReader { geometry in
                let barWidthScale = geometry.size.width * 0.7 // Max width for the bar
                let maxProbability = topTokenPredictions.max(by: { $0.probability < $1.probability })?.probability ?? 1.0

                VStack(alignment: .leading, spacing: 8) {
                    ForEach(topTokenPredictions.sorted(by: { $0.probability > $1.probability }).prefix(maxDisplayTokens)) { prediction in
                        HStack(alignment: .center) {
                            Text(prediction.token)
                                .font(prediction.probability == maxProbability ? .title3.bold() : .body)
                                .foregroundColor(prediction.probability == maxProbability ? .accentColor : .primary)
                                .frame(width: 80, alignment: .trailing) // Fixed width for token text
                                .animation(.easeInOut(duration: 0.4), value: prediction.probability) // Animate font/color changes

                            // Custom animated bar
                            Rectangle()
                                .fill(prediction.probability == maxProbability ? Color.accentColor.opacity(0.8) : Color.blue.opacity(0.5))
                                .frame(width: barWidthScale * CGFloat(prediction.probability), height: 20)
                                .cornerRadius(4)
                                .animation(.easeInOut(duration: 0.4), value: prediction.probability) // Smooth bar length animation
                                .animation(.easeInOut(duration: 0.4), value: maxProbability) // Animate bar color change

                            Text(prediction.probability, format: .percent.precision(.fractionLength(1)))
                                .font(.caption)
                                .frame(width: 60, alignment: .leading)
                                .animation(.easeInOut(duration: 0.4), value: prediction.probability) // Animate percentage text
                        }
                        .transition(.opacity.animation(.easeInOut(duration: 0.3))) // Fade in/out for new tokens
                    }
                }
            }
            .frame(height: CGFloat(maxDisplayTokens) * 35) // Fixed height to prevent layout jumps
        }
        .padding()
        .onAppear {
            simulateTokenUpdates()
        }
    }

    private func simulateTokenUpdates() {
        // Initial state
        topTokenPredictions = [
            TokenProbability(token: "the", probability: 0.4),
            TokenProbability(token: "a", probability: 0.3),
            TokenProbability(token: "I", probability: 0.1),
            TokenProbability(token: "is", probability: 0.05),
            TokenProbability(token: "it", probability: 0.05)
        ]

        // Refinement 1
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            withAnimation(.easeInOut(duration: 0.7)) {
                if let index = topTokenPredictions.firstIndex(where: { $0.token == "the" }) {
                    topTokenPredictions[index].probability = 0.6
                }
                if let index = topTokenPredictions.firstIndex(where: { $0.token == "a" }) {
                    topTokenPredictions[index].probability = 0.2
                }
                // Update other probabilities to ensure sum is 1 (simplified here)
                topTokenPredictions = topTokenPredictions.map { tokenProb in
                    var updated = tokenProb
                    if updated.token == "I" { updated.probability = 0.05 }
                    if updated.token == "is" { updated.probability = 0.08 }
                    if updated.token == "it" { updated.probability = 0.07 }
                    return updated
                }
                topTokenPredictions.sort(by: { $0.probability > $1.probability }) // Re-sort to maintain order
            }
        }

        // Refinement 2 (new token emerges, others fade out)
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
            withAnimation(.easeInOut(duration: 0.8)) {
                topTokenPredictions = [
                    TokenProbability(token: "quick", probability: 0.7),
                    TokenProbability(token: "fast", probability: 0.15),
                    TokenProbability(token: "slow", probability: 0.05),
                    TokenProbability(token: "rapid", probability: 0.05),
                    TokenProbability(token: "swift", probability: 0.05)
                ]
            }
        }
        
        // Final commitment (simulated - new set of predictions for the *next* token)
        DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
            withAnimation(.easeInOut(duration: 0.8)) {
                topTokenPredictions = [
                    TokenProbability(token: "brown", probability: 0.95), // The model committed to "quick", now predicting "brown"
                    TokenProbability(token: "red", probability: 0.02),
                    TokenProbability(token: "dark", probability: 0.01),
                    TokenProbability(token: "dog", probability: 0.01),
                ]
            }
        }
    }
}
