
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation

/// Represents the current economic state of the AI session.
@available(iOS 18.0, *)
actor TokenBudgetActor {
    private(set) var consumedTokens: Int = 0
    private let maxTokenLimit: Int
    
    init(maxTokenLimit: Int) {
        self.maxTokenLimit = maxTokenLimit
    }
    
    /// Checks if a request is permissible within the remaining budget.
    /// This prevents "Agentic Loops" from bankrupting the user.
    func requestPermission(for estimatedTokens: Int) throws -> Bool {
        if consumedTokens + estimatedTokens > maxTokenLimit {
            throw TokenError.budgetExceeded
        }
        return true
    }
    
    /// Updates the budget after a real response is received.
    func updateUsage(actualTokens: Int) {
        consumedTokens += actualTokens
    }
    
    enum TokenError: Error {
        case budgetExceeded
    }
}

/// A high-level service that coordinates between the Budget and the API.
@available(iOS 18.0, *)
@Observable
class AIService {
    private let budget: TokenBudgetActor
    private let privacyGuard: PrivacyGuard
    
    var isBudgetExhausted: Bool = false
    
    init(budget: TokenBudgetActor, privacyGuard: PrivacyGuard) {
        self.budget = budget
        self.privacyGuard = privacyGuard
    }
    
    func performSmartQuery(_ prompt: String) async throws -> String {
        // 1. Privacy Check
        let safePrompt = await privacyGuard.scrub(prompt)
        
        // 2. Cost Check (Estimate 500 tokens for a standard query)
        let estimatedCost = 500
        guard try await budget.requestPermission(for: estimatedCost) else {
            isBudgetExhausted = true
            return "Error: Budget exceeded."
        }
        
        // 3. Execution (Simulated API Call)
        // In a real app, this would be an OpenAI/LangChain call.
        let response = try await simulateLLMCall(safePrompt)
        
        // 4. Update Budget with actual usage
        await budget.updateUsage(actualTokens: estimatedCost) 
        
        return response
    }
    
    private func simulateLLMCall(_ input: String) async throws -> String {
        try await Task.sleep(for: .seconds(1))
        return "Processed: \(input)"
    }
}
