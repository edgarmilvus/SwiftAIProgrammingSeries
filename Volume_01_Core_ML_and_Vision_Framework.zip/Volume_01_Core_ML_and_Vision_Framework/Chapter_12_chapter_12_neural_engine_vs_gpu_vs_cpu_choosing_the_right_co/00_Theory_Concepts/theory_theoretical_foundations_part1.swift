
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
class ImageClassifier {
    private let model: MLModel // Assume model is loaded and configured

    init(model: MLModel) {
        self.model = model
    }

    /// Performs image classification asynchronously.
    func classifyImage(input: MLFeatureProvider) async throws -> MLFeatureProvider {
        // The actual prediction call is often synchronous, but we wrap it
        // to indicate that it might involve waiting for hardware or offloading work.
        // For Core ML, the underlying framework handles async dispatch to compute units.
        return try await Task.detached(priority: .userInitiated) {
            // This is where Core ML's internal compute unit selection happens.
            // It might dispatch to ANE, GPU, or CPU.
            let prediction = try self.model.prediction(from: input)
            return prediction
        }.value
    }

    // Example usage in a UI context
    @MainActor
    func updateUIWithPrediction(imageInput: MLFeatureProvider) {
        Task {
            do {
                let result = try await classifyImage(input: imageInput)
                // Process result and update UI
                print("Prediction: \(result.featureValue(for: "classLabel")?.stringValue ?? "N/A")")
            } catch {
                print("Error classifying image: \(error)")
            }
        }
    }
}
