
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

struct AIRequest: Sendable {
    let prompt: String
}

struct AIResponse: Sendable {
    let text: String
    let safetyScore: Double
}

protocol GuardrailMiddleware: Sendable {
    func process(request: AIRequest) async throws -> AIRequest
    func validate(response: AIResponse) async -> Bool
}

// Strategy B: Modifies Input (Proactive)
final class HardFilterMiddleware: GuardrailMiddleware {
    func process(request: AIRequest) async throws -> AIRequest {
        let safePrompt = "You are a safe assistant for children. Do not use profanity. User says: \(request.prompt)"
        return AIRequest(prompt: safePrompt)
    }
    
    func validate(response: AIResponse) async -> Bool {
        return true // Input filtering is proactive, so validation is secondary
    }
}

// Strategy A: Checks Output (Reactive)
final class SoftFilterMiddleware: GuardrailMiddleware {
    func process(request: AIRequest) async throws -> AIRequest {
        return request // No change to input
    }
    
    func validate(response: AIResponse) async -> Bool {
        // Simulate checking for toxic words
        let toxicWords = ["badword1", "badword2"]
        let isToxic = toxicWords.contains { response.text.contains($0) }
        return !isToxic
    }
}

actor SafetyPipeline {
    private let flagProvider: FeatureFlagProvider
    private let hardFilter = HardFilterMiddleware()
    private let softFilter = SoftFilterMiddleware()
    
    init(flagProvider: FeatureFlagProvider) {
        self.flagProvider = flagProvider
    }
    
    func execute(request: AIRequest, llmService: LLMService) async throws -> AIResponse {
        let start = ContinuousClock.now
        
        // 1. Determine Strategy via Feature Flag
        let useHardFilter = await flagProvider.isEnabled(.useAdvancedReasoning)
        
        // 2. Input Phase (Hard Filter)
        var currentRequest = request
        if useHardFilter {
            currentRequest = try await hardFilter.process(request: request)
        }
        
        // 3. LLM Execution
        let rawText = try await llmService.generateResponse(prompt: currentRequest.prompt)
        var response = AIResponse(text: rawText, safetyScore: 1.0)
        
        // 4. Output Phase (Soft Filter)
        if !useHardFilter {
            let isValid = await softFilter.validate(response: response)
            if !isValid {
                response = AIResponse(text: "I cannot answer that.", safetyScore: 0.0)
            }
        }
        
        let duration = start.duration(to: .now)
        print("[Safety Audit] Pipeline Overhead: \(duration)")
        
        return response
    }
}
