
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI

// Define the DetectedObject struct as specified.
// Removed @available(iOS 18.0, *) as Canvas is available from iOS 15,
// and this struct does not introduce any iOS 18 specific features.
struct DetectedObject: Identifiable {
    let id = UUID()
    var boundingBox: CGRect // Normalized 0-1 coordinates
    var label: String
    var confidence: Double
}

struct MultiObjectDetectionView: View {
    // @State array of DetectedObject instances, simulating AI model output.
    @State private var detectedObjects: [DetectedObject] = [
        DetectedObject(boundingBox: CGRect(x: 0.1, y: 0.1, width: 0.3, height: 0.2), label: "Person", confidence: 0.95),
        DetectedObject(boundingBox: CGRect(x: 0.5, y: 0.4, width: 0.4, height: 0.3), label: "Car", confidence: 0.72),
        DetectedObject(boundingBox: CGRect(x: 0.2, y: 0.7, width: 0.25, height: 0.15), label: "Bicycle", confidence: 0.48),
        DetectedObject(boundingBox: CGRect(x: 0.6, y: 0.15, width: 0.2, height: 0.1), label: "Sign", confidence: 0.88)
    ]

    var body: some View {
        VStack {
            Text("Dynamic Multi-Object Detection")
                .font(.headline)
                .padding()

            Image(systemName: "photo.fill")
                .resizable()
                .scaledToFit()
                .foregroundColor(.gray)
                .padding()
                .overlay(
                    GeometryReader { geometry in
                        Canvas { context, size in
                            // Iterate through all detected objects
                            for object in detectedObjects {
                                // 1. Convert normalized bounding box to actual drawing coordinates
                                let drawRect = CGRect(
                                    x: object.boundingBox.origin.x * size.width,
                                    y: object.boundingBox.origin.y * size.height,
                                    width: object.boundingBox.size.width * size.width,
                                    height: object.boundingBox.size.height * size.height
                                )

                                // 2. Determine stroke color based on confidence
                                let strokeColor: Color
                                if object.confidence > 0.8 {
                                    strokeColor = .green
                                } else if object.confidence > 0.5 {
                                    strokeColor = .yellow
                                } else {
                                    strokeColor = .red
                                }

                                // 3. Draw the bounding box
                                let path = Path(roundedRect: drawRect, cornerRadius: 5)
                                context.stroke(path, with: .color(strokeColor), lineWidth: 2)

                                // 4. Draw the label text
                                let labelText = "\(object.label) (\(String(format: "%.0f", object.confidence * 100))%)"
                                let resolvedText = context.resolve(
                                    Text(labelText)
                                        .font(.caption)
                                        .bold()
                                        .foregroundColor(.white)
                                )

                                // Calculate text size to draw a background rectangle
                                let textSize = resolvedText.measure(in: size)

                                // Position the text above the bounding box
                                let textOriginX = drawRect.origin.x
                                let textOriginY = drawRect.origin.y - textSize.height - 5 // 5 points padding above box

                                // Ensure text doesn't go off-screen to the left or top
                                let adjustedTextOriginX = max(0, textOriginX)
                                let adjustedTextOriginY = max(0, textOriginY)

                                // Draw a background rectangle for the text for better contrast
                                let textBackgroundRect = CGRect(
                                    x: adjustedTextOriginX,
                                    y: adjustedTextOriginY,
                                    width: textSize.width + 8, // Add some horizontal padding
                                    height: textSize.height + 4 // Add some vertical padding
                                )
                                let textBackgroundPath = Path(roundedRect: textBackgroundRect, cornerRadius: 3)
                                context.fill(textBackgroundPath, with: .color(strokeColor.opacity(0.8)))

                                // Draw the text itself, centered within its background rect
                                context.draw(
                                    resolvedText,
                                    at: CGPoint(x: adjustedTextOriginX + 4, y: adjustedTextOriginY + 2),
                                    anchor: .topLeading
                                )
                            }
                        }
                        .allowsHitTesting(false)
                    }
                )
                .frame(width: 300, height: 200)
                .background(Color.secondary.opacity(0.1))
        }
    }
}

// Preview Provider
struct MultiObjectDetectionView_Previews: PreviewProvider {
    static var previews: some View {
        MultiObjectDetectionView()
    }
}
