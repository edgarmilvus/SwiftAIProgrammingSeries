
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

/// An AppIntent that allows users to summarize a specific note from Smart Notes Pro.
/// This intent demonstrates advanced features like parameter resolution, asynchronous operations,
/// and rich result handling, integrating a simulated Apple Intelligence service.
@available(iOS 18.0, *) // AppIntents and Apple Intelligence features are typically iOS 18+
struct SummarizeNoteIntent: AppIntent {
    /// The display name for the intent in Siri and Shortcuts.
    static var title: LocalizedStringResource = "Summarize Note"

    /// A brief description of what the intent does.
    static var description: IntentDescription = IntentDescription(
        "Summarizes a specific note from Smart Notes Pro using on-device Apple Intelligence.",
        category: .productivity,
        searchKeywords: ["note", "summary", "AI", "intelligence", "smart notes"]
    )

    /// Defines the input parameter for the note identifier.
    /// This parameter is optional, allowing the user to be prompted if not provided.
    @Parameter(
        title: "Note Identifier",
        description: "The title or ID of the note to summarize.",
        inputConnectionBehavior: .connectToPreviousIntentResult(
            type: .text,
            outputPattern: .localizedStringResource("Summarized \(.previousIntentResult)")
        )
    )
    var noteIdentifier: String?

    /// The main execution logic for the intent.
    /// This method is asynchronous to handle potentially long-running operations like fetching data
    /// and performing AI analysis.
    func perform() async throws -> some IntentResult & ProvidesDialog {
        // 1. Validate Input
        guard let identifier = noteIdentifier, !identifier.isEmpty else {
            throw SmartNotesError.invalidInput
        }

        // 2. Fetch the Note Asynchronously
        // We attempt to fetch by UUID first, then by title if UUID fails.
        var note: Note?
        if let uuid = UUID(uuidString: identifier) {
            note = await NoteStore.shared.fetchNote(by: uuid)
        }
        if note == nil {
            note = await NoteStore.shared.fetchNote(by: identifier)
        }

        guard let foundNote = note else {
            // If the note is not found, throw a specific error that can be localized.
            throw SmartNotesError.noteNotFound(identifier: identifier)
        }

        // 3. Perform AI Summarization Asynchronously
        let summary: String
        do {
            summary = try await AIService.shared.summarizeText(foundNote.content)
        } catch {
            // Catch specific AI service errors and re-throw as our custom error.
            throw SmartNotesError.summarizationFailed
        }

        // 4. Construct and Return the Rich Intent Result
        // We provide a dialog response for Siri and a rich output for Shortcuts.
        return .result(
            dialog: "I've summarized '\(foundNote.title)': \(summary)",
            view: SummarizeNoteIntentResultView(noteTitle: foundNote.title, summary: summary)
        ) {
            // This block defines the output that Shortcuts can use.
            // We can provide multiple outputs, here we just provide the summary text.
            // The `output` property is automatically inferred from the `ProvidesOutput` protocol.
            Output("Summary of \(foundNote.title)", summary: summary)
        }
    }
}

/// A custom output type for the SummarizeNoteIntent, allowing structured data for Shortcuts.
@available(iOS 18.0, *)
struct Output: AppIntentOutput, Codable {
    var summary: String

    /// Provides a user-friendly summary of the output for Shortcuts.
    var description: LocalizedStringResource {
        "The summarized text."
    }
}

/// A custom view to display the result within Siri or the Shortcuts app.
/// This allows for a richer user experience than just a plain text dialog.
@available(iOS 18.0, *)
struct SummarizeNoteIntentResultView: View {
    let noteTitle: String
    let summary: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Summary for: **\(noteTitle)**")
                .font(.headline)
            Text(summary)
                .font(.body)
                .padding(.vertical, 5)
            Divider()
            Text("Powered by Apple Intelligence")
                .font(.footnote)
                .foregroundColor(.gray)
        }
        .padding()
    }
}

// In a real app, you would register your intents in an AppIntents.swift file or similar.
// For example, in your main App file or an extension:
// @main
// struct SmartNotesProApp: App {
//     var body: some Scene {
//         WindowGroup {
//             ContentView()
//         }
//     }
// }
//
// struct SmartNotesProAppIntents: AppIntentProvider {
//     static var appIntents: [AppIntent.Type] {
//         [SummarizeNoteIntent.self]
//     }
// }
