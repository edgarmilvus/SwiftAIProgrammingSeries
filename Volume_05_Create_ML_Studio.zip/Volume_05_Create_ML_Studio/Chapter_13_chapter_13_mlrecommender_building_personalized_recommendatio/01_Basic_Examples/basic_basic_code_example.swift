
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CreateML
import CoreML // For MLModel and related types

/// Represents a single user-filter interaction in our dataset.
/// This struct helps organize our raw data before converting it to an MLDataTable.
struct FilterInteraction {
    let userID: String
    let filterID: String
    let usageCount: Double // Represents how many times a user applied a filter
}

/// A service class to encapsulate the MLRecommender functionality.
/// It handles data preparation, model training, and generating recommendations.
@available(iOS 17.0, macOS 14.0, tvOS 17.0, watchOS 10.0, *)
class FilterRecommenderService {

    private var recommender: MLRecommender?

    /// Initializes the recommender service.
    /// In a real app, you might load a pre-trained model here or trigger training.
    init() {
        // For this basic example, we will train a model upon explicit call.
        // In a production app, you'd likely manage model training and loading separately,
        // perhaps loading a bundled model or downloading an updated one.
    }

    /// 1. Prepare the Training Data
    /// This function generates synthetic filter usage data for demonstration purposes.
    /// In a real application, this data would come from your app's analytics,
    /// a local database, or a backend service.
    private func prepareTrainingData() -> [FilterInteraction] {
        return [
            // User A likes "Vintage", "Sepia", "Grayscale"
            FilterInteraction(userID: "user_A", filterID: "Vintage", usageCount: 5.0),
            FilterInteraction(userID: "user_A", filterID: "Sepia", usageCount: 4.0),
            FilterInteraction(userID: "user_A", filterID: "Grayscale", usageCount: 3.0),
            FilterInteraction(userID: "user_A", filterID: "Vivid", usageCount: 1.0), // Less frequent
            
            // User B likes "Vivid", "Contrast", "Saturation"
            FilterInteraction(userID: "user_B", filterID: "Vivid", usageCount: 6.0),
            FilterInteraction(userID: "user_B", filterID: "Contrast", usageCount: 5.0),
            FilterInteraction(userID: "user_B", filterID: "Saturation", usageCount: 4.0),
            FilterInteraction(userID: "user_B", filterID: "Sepia", usageCount: 1.0), // Less frequent
            
            // User C likes "Vintage", "Sepia", "Noir" (similar to User A)
            FilterInteraction(userID: "user_C", filterID: "Vintage", usageCount: 7.0),
            FilterInteraction(userID: "user_C", filterID: "Sepia", usageCount: 6.0),
            FilterInteraction(userID: "user_C", filterID: "Noir", usageCount: 5.0),
            FilterInteraction(userID: "user_C", filterID: "Vivid", usageCount: 2.0),
            
            // User D likes "Contrast", "Saturation", "Warmth" (similar to User B)
            FilterInteraction(userID: "user_D", filterID: "Contrast", usageCount: 8.0),
            FilterInteraction(userID: "user_D", filterID: "Saturation", usageCount: 7.0),
            FilterInteraction(userID: "user_D", filterID: "Warmth", usageCount: 6.0),
            FilterInteraction(userID: "user_D", filterID: "Grayscale", usageCount: 1.0),
            
            // User E, a newer user with some initial interactions
            FilterInteraction(userID: "user_E", filterID: "Vintage", usageCount: 2.0),
            FilterInteraction(userID: "user_E", filterID: "Contrast", usageCount: 2.0),
            FilterInteraction(userID: "user_E", filterID: "Grayscale", usageCount: 1.0)
        ]
    }

    /// 2. Convert Raw Data to MLDataTable
    /// An `MLDataTable` is the standard input format for Create ML models.
    /// It's a tabular data structure similar to a spreadsheet or a DataFrame.
    /// - Parameter interactions: An array of `FilterInteraction` structs.
    /// - Returns: An `MLDataTable` suitable for training.
    /// - Throws: `RecommenderError` if data conversion fails.
    private func createDataTable(from interactions: [FilterInteraction]) throws -> MLDataTable {
        // MLDataTable can be initialized directly from an array of dictionaries or Codable types.
        // For clarity, we'll build it column by column here.
        var dataTable = MLDataTable()
        
        // Add columns to the data table.
        // The column names ("userID", "filterID", "usageCount") are crucial
        // as they will be referenced by `MLRecommender.RecommendationParameters`.
        dataTable.addColumns(from: interactions.map { $0.userID }, named: "userID")
        dataTable.addColumns(from: interactions.map { $0.filterID }, named: "filterID")
        dataTable.addColumns(from: interactions.map { $0.usageCount }, named: "usageCount")
        
        print("--- Training Data Table ---")
        print(dataTable)
        print("---------------------------")
        
        return dataTable
    }

    /// 3. Train the MLRecommender Model
    /// This is where the core machine learning happens. The model learns patterns
    /// from the provided user-item interactions to make future recommendations.
    /// - Parameters:
    ///   - userColumn: The name of the column containing user identifiers in the `MLDataTable`.
    ///   - itemColumn: The name of the column containing item identifiers in the `MLDataTable`.
    ///   - ratingColumn: The name of the column containing interaction/rating values in the `MLDataTable`.
    /// - Throws: `Error` if training fails.
    func trainRecommender(userColumn: String = "userID",
                          itemColumn: String = "filterID",
                          ratingColumn: String = "usageCount") async throws {
        
        let interactions = prepareTrainingData()
        let dataTable = try createDataTable(from: interactions)

        print("\n--- Starting MLRecommender Training ---")
        // `MLRecommender.RecommendationParameters` specifies which columns in the `MLDataTable`
        // correspond to the user, item, and rating. These must match the column names exactly.
        let parameters = MLRecommender.RecommendationParameters(
            userColumn: userColumn,
            itemColumn: itemColumn,
            ratingColumn: ratingColumn
        )

        // Training can be an intensive operation, especially with large datasets.
        // It's performed asynchronously to avoid blocking the main thread.
        self.recommender = try await MLRecommender.train(trainingData: dataTable, parameters: parameters)
        print("--- MLRecommender Training Complete ---")
        
        // In a more advanced scenario, you might split your data into training and testing sets
        // and evaluate the model's performance using `recommender.evaluation(on: testData)`.
    }

    /// 4. Generate Recommendations
    /// Once the model is trained, we can ask it for recommendations for a specific user.
    /// - Parameters:
    ///   - userID: The identifier of the user for whom to generate recommendations.
    ///   - top: The maximum number of recommendations to return.
    /// - Returns: An array of recommended filter IDs (strings).
    /// - Throws: `RecommenderError.modelNotTrained` if the model hasn't been trained yet.
    func getRecommendations(forUserID userID: String, top: Int = 5) throws -> [String] {
        guard let recommender = self.recommender else {
            throw RecommenderError.modelNotTrained
        }

        print("\n--- Generating Recommendations for \(userID) ---")
        // The `recommendations` method returns an `MLDataTable` with recommended items and scores.
        let recommendationsTable = try recommender.recommendations(forUser: userID, top: top)
        
        print("Raw Recommendations Table:")
        print(recommendationsTable)
        
        // Extract the filter IDs from the recommendations table.
        // The column containing item IDs will have the name specified as `itemColumn` during training.
        let recommendedFilterIDs = recommendationsTable[recommender.parameters.itemColumn].map { String(describing: $0) }
        
        print("Recommended Filters for \(userID): \(recommendedFilterIDs)")
        return recommendedFilterIDs
    }

    /// 5. Save and Load the Model (Conceptual)
    /// In a real application, you would typically save the trained model to disk
    /// and load it later to avoid retraining every time the app launches.
    /// This improves app launch time and allows for offline recommendations.
    /// - Parameter url: The file URL where the .mlmodel file should be saved.
    /// - Throws: `Error` if saving fails.
    func saveModel(to url: URL) throws {
        guard let recommender = self.recommender else {
            throw RecommenderError.modelNotTrained
        }
        print("\n--- Saving Model to \(url.lastPathComponent) ---")
        try recommender.write(to: url)
        print("Model saved successfully.")
    }

    /// Loads a previously saved MLRecommender model from a file URL.
    /// - Parameter url: The file URL of the .mlmodel file to load.
    /// - Throws: `Error` if loading fails.
    func loadModel(from url: URL) throws {
        print("\n--- Loading Model from \(url.lastPathComponent) ---")
        // When loading, you can also specify an `MLModel.Configuration` to control compute units.
        self.recommender = try MLRecommender(contentsOf: url)
        print("Model loaded successfully.")
    }
    
    /// Custom error types for the recommender service.
    enum RecommenderError: Error, LocalizedError {
        case modelNotTrained
        case dataConversionFailed(String)
        
        var errorDescription: String? {
            switch self {
            case .modelNotTrained: return "The MLRecommender model has not been trained yet."
            case .dataConversionFailed(let message): return "Failed to convert data: \(message)"
            }
        }
    }
}

// MARK: - Example Usage in an App Lifecycle (e.g., SwiftUI App or ViewController)

/// An asynchronous function to demonstrate the full lifecycle of the FilterRecommenderService.
/// This function would typically be called from an `async` context, e.g., in a SwiftUI `Task` modifier
/// or a `Task` block in a `ViewController`'s `viewDidLoad`.
@available(iOS 17.0, macOS 14.0, tvOS 17.0, watchOS 10.0, *)
@MainActor // Ensures that any UI-related operations (even print statements here) are conceptualized as main-thread safe.
func runFilterRecommenderExample() async {
    let service = FilterRecommenderService()

    do {
        // 1. Train the model
        print("\n--- Initiating Recommender Training Process ---")
        // Training is an async operation, so we await its completion.
        try await service.trainRecommender()
        print("Recommender training process finished.")

        // 2. Get recommendations for existing users
        _ = try service.getRecommendations(forUserID: "user_A", top: 3)
        _ = try service.getRecommendations(forUserID: "user_B", top: 3)
        
        // 3. Get recommendations for a new user (or user with limited data)
        // MLRecommender can still provide recommendations for users it hasn't seen
        // directly by finding similar users or popular items.
        _ = try service.getRecommendations(forUserID: "user_E", top: 3)
        
        // 4. Demonstrate saving and loading the model
        // We'll save to the app's documents directory for demonstration purposes.
        let documentsDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let modelURL = documentsDirectory.appendingPathComponent("FilterFlowRecommender.mlmodel")
        
        try service.saveModel(to: modelURL)
        
        // Create a new service instance to demonstrate loading a previously saved model.
        // This simulates restarting the app or loading a model in a different part of the app.
        let loadedService = FilterRecommenderService()
        try loadedService.loadModel(from: modelURL)
        
        // Verify the loaded model can still make predictions.
        _ = try loadedService.getRecommendations(forUserID: "user_C", top: 2)

    } catch {
        print("\nAn error occurred: \(error.localizedDescription)")
        if let recommenderError = error as? FilterRecommenderService.RecommenderError {
            print("Recommender Specific Error: \(recommenderError)")
        }
    }
}

// To execute this example:
// In an Xcode project (e.g., an iOS App target supporting iOS 17.0+):
// Call `Task { await runFilterRecommenderExample() }` from an appropriate lifecycle method
// (e.g., `application(_:didFinishLaunchingWithOptions:)` in AppDelegate,
// or `ContentView().onAppear { Task { await runFilterRecommenderExample() } }` in SwiftUI).
//
// In a Swift Playground:
// Ensure your Playground is configured for an iOS 17.0+ or macOS 14.0+ platform.
// Simply add `Task { await runFilterRecommenderExample() }` at the top level.
