
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

@available(iOS 18.0, macOS 15.0, *)
struct SentimentBarChartView: View {
    // Represents probabilities for [Positive, Neutral, Negative]
    @State var probabilities: [Double] = [0.3, 0.4, 0.3]
    let categories = ["Positive", "Neutral", "Negative"]
    let colors: [Color] = [.green, .gray, .red]

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Sentiment Distribution")
                .font(.headline)
                .padding(.bottom, 5)

            GeometryReader { geometry in
                let totalWidth = geometry.size.width - 80 // Reserve space for labels
                
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(0..<categories.count, id: \.self) { index in
                        HStack {
                            Text(categories[index])
                                .font(.subheadline)
                                .frame(width: 70, alignment: .trailing) // Fixed width for labels
                            
                            Rectangle()
                                .fill(colors[index])
                                .frame(width: totalWidth * CGFloat(probabilities[index]), height: 25)
                                .cornerRadius(5) // Slightly rounded corners for aesthetics
                                .animation(.easeInOut(duration: 0.7), value: probabilities[index]) // Smooth bar length animation
                            
                            Text(probabilities[index], format: .percent.precision(.fractionLength(1)))
                                .font(.caption)
                                .frame(width: 50, alignment: .leading)
                                .animation(.easeInOut(duration: 0.7), value: probabilities[index]) // Animate text updates
                        }
                    }
                }
            }
            .frame(height: CGFloat(categories.count) * 40) // Adjust height based on number of categories
        }
        .padding()
        .onAppear {
            // Simulate updates
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                withAnimation(.easeInOut(duration: 1.0)) {
                    probabilities = [0.1, 0.8, 0.1] // Mostly Neutral
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                withAnimation(.easeInOut(duration: 1.0)) {
                    probabilities = [0.7, 0.2, 0.1] // Mostly Positive
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
                withAnimation(.easeInOut(duration: 1.0)) {
                    probabilities = [0.25, 0.35, 0.4] // Mostly Negative
                }
            }
        }
    }
}
