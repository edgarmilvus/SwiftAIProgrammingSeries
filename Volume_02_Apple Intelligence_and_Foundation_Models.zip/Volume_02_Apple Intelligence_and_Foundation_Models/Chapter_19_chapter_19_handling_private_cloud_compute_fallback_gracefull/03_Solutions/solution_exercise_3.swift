
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import PrivateCloudCompute // For PrivateCloudComputeManager.Error
import Combine // For ObservableObject and @Published

// MARK: - Mock AI Service for Code Analysis

// Custom error types for the mock AI service
enum CodeAnalysisAIError: Error, LocalizedError {
    case genericAIError(String)
    case invalidCodeInput
    
    var errorDescription: String? {
        switch self {
        case .genericAIError(let message): return "AI Error: \(message)"
        case .invalidCodeInput: return "Invalid code provided for analysis."
        }
    }
}

// Mark the mock service as available only on macOS 15.0 and later (or iOS 18.0)
@available(macOS 15.0, *) // Assuming a macOS IDE context
class MockCodeAnalysisAI {
    var forcePCCUnavailable: Bool = false // Flag to simulate PCC unavailability
    var currentCodeBaseContext: String = "" // Simulates a larger context for deep refactoring

    func analyzeAndSuggestRefactoring(for selectedCode: String) async throws -> String {
        // Simulate network delay and complex AI processing
        try await Task.sleep(for: .milliseconds(800))

        if selectedCode.isEmpty {
            throw CodeAnalysisAIError.invalidCodeInput
        }

        if forcePCCUnavailable {
            // Simulate Private Cloud Compute being unavailable
            throw PrivateCloudComputeManager.Error.unavailable(reason: .systemLimited)
        }

        // Simulate a "deep" refactoring suggestion based on code content
        if selectedCode.contains("func calculate") && selectedCode.contains("if") {
            return """
            Deep Refactor Suggestion (PCC-enhanced):
            - Extract conditional logic into a separate helper method.
            - Consider using a switch statement for better readability if more conditions are added.
            - Rename 'calculate' to 'determineValueForInput'.
            """
        } else if selectedCode.contains("let values = [") {
            return """
            Deep Refactor Suggestion (PCC-enhanced):
            - Use `map` or `compactMap` for array transformations instead of a for-loop.
            - Consider using a `Set` if order doesn't matter and uniqueness is desired.
            """
        } else {
            return """
            Deep Refactor Suggestion (PCC-enhanced):
            - Analyze potential for method extraction.
            - Review variable naming for clarity within the broader context.
            - Identify opportunities for Swift concurrency adoption.
            """
        }
    }
}

// MARK: - Code Refactoring Service

// Struct to hold the refactoring result
struct RefactoringResult {
    let suggestion: String
    let refactorType: RefactorType
    let message: String // User-facing message
    
    enum RefactorType: String {
        case deep = "Deep (AI-powered)"
        case basic = "Basic (Local Fallback)"
        case failed = "Failed"
    }
}

// Mark the service as available only on macOS 15.0 and later
@available(macOS 15.0, *)
class CodeRefactoringService: ObservableObject {
    private let aiService: MockCodeAnalysisAI
    
    // @Published properties for UI to react to changes
    @Published private(set) var lastRefactorResult: RefactoringResult?
    @Published private(set) var isRefactoring: Bool = false
    
    // For retry mechanism: store the last attempted code
    private var lastAttemptedCode: String?

    // Dependency injection
    init(aiService: MockCodeAnalysisAI) {
        self.aiService = aiService
    }

    func performSmartRefactor(for selectedCode: String) async {
        // Indicate that refactoring is in progress
        await MainActor.run {
            self.isRefactoring = true
            self.lastAttemptedCode = selectedCode // Store for potential retry
        }
        
        do {
            // Attempt deep refactoring using AI
            let deepSuggestion = try await aiService.analyzeAndSuggestRefactoring(for: selectedCode)
            await MainActor.run {
                self.lastRefactorResult = RefactoringResult(
                    suggestion: deepSuggestion,
                    refactorType: .deep,
                    message: "Deep refactoring suggestion generated using AI."
                )
            }
        } catch let error as PrivateCloudComputeManager.Error where error == .unavailable {
            // Catch specific PCC unavailability error
            let basicSuggestion = generateBasicRefactorSuggestion(for: selectedCode)
            await MainActor.run {
                self.lastRefactorResult = RefactoringResult(
                    suggestion: basicSuggestion,
                    refactorType: .basic,
                    message: "Private Cloud Compute unavailable. Providing basic refactoring suggestion."
                )
            }
        } catch let error as CodeAnalysisAIError {
            // Handle other AI-specific errors
            await MainActor.run {
                self.lastRefactorResult = RefactoringResult(
                    suggestion: "Could not generate refactoring suggestion.",
                    refactorType: .failed,
                    message: "AI Error: \(error.localizedDescription)"
                )
            }
        } catch {
            // Catch any other unexpected errors
            await MainActor.run {
                self.lastRefactorResult = RefactoringResult(
                    suggestion: "An unexpected error occurred during refactoring.",
                    refactorType: .failed,
                    message: "Unknown error: \(error.localizedDescription)"
                )
            }
        }
        
        // Indicate refactoring is complete
        await MainActor.run {
            self.isRefactoring = false
        }
    }

    // Local heuristic for basic refactoring suggestions
    private func generateBasicRefactorSuggestion(for code: String) -> String {
        if code.contains("var temp") {
            return "Basic Refactor Suggestion: Consider renaming 'temp' to a more descriptive variable name."
        } else if code.contains("func doSomething()") {
            return "Basic Refactor Suggestion: Ensure function names clearly describe their purpose."
        } else if code.count > 100 && code.contains("{") && code.contains("}") {
            return "Basic Refactor Suggestion: This block of code seems long. Consider extracting parts into separate functions for better modularity."
        }
        return "Basic Refactor Suggestion: No specific basic refactoring found, but always review for clarity and conciseness."
    }
    
    // Retry mechanism
    func retryLastRefactor() async {
        // Ensure there was a previous attempt and no refactoring is currently in progress
        guard let codeToRetry = lastAttemptedCode, !isRefactoring else {
            print("No previous code to retry or refactoring is already in progress.")
            return
        }
        print("Retrying last refactor attempt for code: '\(codeToRetry.prefix(50))...'")
        await performSmartRefactor(for: codeToRetry)
    }
}
