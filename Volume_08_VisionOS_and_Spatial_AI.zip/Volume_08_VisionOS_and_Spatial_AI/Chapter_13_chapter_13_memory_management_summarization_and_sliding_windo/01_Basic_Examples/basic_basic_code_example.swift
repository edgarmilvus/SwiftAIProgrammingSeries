
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation

// MARK: - Package Dependencies
/*
 To run this example, you would typically include the following in your Package.swift:
 
 dependencies: [
     .package(url: "https://github.com/apple/swift-collections.git", from: "1.1.0")
 ],
 targets: [
     .target(name: "ChatEngine", dependencies: [
         .product(name: "DequeModule", package: "swift-collections")
     ])
 ]
*/

/// Represents the role of a participant in the conversation.
enum ChatRole: String, Codable {
    case system
    case user
    case assistant
}

/// A single unit of communication within the chat interface.
struct ChatMessage: Identifiable, Codable, Sendable {
    let id: UUID
    let role: ChatRole
    let content: String
    let timestamp: Date

    init(role: ChatRole, content: String) {
        self.id = UUID()
        self.role = role
        self.content = content
        self.timestamp = Date()
    }
}

/// An error type specific to context management operations.
enum ContextError: Error {
    case summarizationFailed
    case bufferOverflow
}

/// The `ConversationManager` is an `actor` to ensure that the conversation state 
/// is thread-safe, preventing data races when multiple asynchronous tasks 
/// (like UI updates and LLM API calls) attempt to modify the message history.
@available(iOS 18.0, macOS 15.0, *)
actor ConversationManager {
    
    /// The current history of the conversation.
    private(set) var messages: [ChatMessage] = []
    
    /// A condensed summary of the conversation history used to preserve long-term memory.
    private(set) var conversationSummary: String?
    
    /// The maximum number of messages allowed in the "active" sliding window.
    private let maxWindowSize: Int
    
    /// The threshold of messages that triggers the summarization process.
    private let summarizationThreshold: Int

    /// Initializes the manager with specific constraints.
    /// - Parameters:
    ///   - maxWindowSize: The maximum number of recent messages to keep in the sliding window.
    ///   - summarizationThreshold: The message count at which we trigger summarization.
    init(maxWindowSize: Int = 10, summarizationThreshold: Int = 6) {
        self.maxWindowSize = maxWindowSize
        self.summarizationThreshold = summarizationThreshold
    }

    /// Adds a new message to the conversation and manages the context window.
    /// - Parameter message: The new message to append.
    func addMessage(_ message: ChatMessage) async {
        messages.append(message)
        print("DEBUG: Added message from \(message.role). Total count: \(messages.count)")
        
        await manageContext()
    }

    /// The core logic for deciding whether to slide the window or summarize.
    /// This is a private method called after every new message.
    private func manageContext() async {
        // 1. Check if we have exceeded the summarization threshold.
        // If we have, we compress the oldest messages into a summary.
        if messages.count >= summarizationThreshold {
            await performSummarization()
        }

        // 2. Apply the Sliding Window.
        // Even with summarization, we must ensure the array doesn't grow indefinitely.
        // We keep only the 'maxWindowSize' most recent messages.
        if messages.count > maxWindowSize {
            let overflow = messages.count - maxWindowSize
            print("DEBUG: Sliding window triggered. Removing \(overflow) oldest messages.")
            messages.removeFirst(overflow)
        }
    }

    /// Simulates an LLM call to summarize the conversation history.
    /// In a real app, this would call an OpenAI/Anthropic endpoint.
    private func performSummarization() async {
        print("DEBUG: 🧠 Summarization triggered...")
        
        // We take the oldest messages to summarize.
        // For this example, we'll summarize everything except the very last message.
        let messagesToSummarize = messages.dropLast()
        let textToSummarize = messagesToSummarize.map { "\($0.role.rawValue): \($0.content)" }.joined(separator: "\n")
        
        // Simulate network latency for the LLM call.
        try? await Task.sleep(for: .seconds(1.5))
        
        // MOCK LOGIC: In a real scenario, the LLM returns a string.
        // Here, we create a mock summary.
        let mockSummary = "The user and assistant discussed technical Swift 6 implementation details."
        
        self.conversationSummary = mockSummary
        
        // After summarizing, we clear the messages that were just condensed
        // to make room for new ones in the window.
        // We keep the last message so the conversation flow remains unbroken.
        if let lastMessage = messages.last {
            self.messages = [lastMessage]
        }
        
        print("DEBUG: ✅ Summarization complete. Summary: \(mockSummary)")
    }

    /// Returns the formatted prompt ready to be sent to an LLM API.
    /// This combines the summary (if any) with the recent sliding window messages.
    func getFullContextForAPI() -> [ChatMessage] {
        var context: [ChatMessage] = []
        
        // If a summary exists, we inject it as a 'system' message at the very beginning.
        if let summary = conversationSummary {
            let summaryMessage = ChatMessage(role: .system, content: "Summary of previous conversation: \(summary)")
            context.append(summaryMessage)
        }
        
        // Append the recent sliding window messages.
        context.append(contentsOf: messages)
        return context
    }
}

// MARK: - Execution Logic (Simulating the App)

@available(iOS 18.0, macOS 15.0, *)
@MainActor
struct ChatAppSimulator {
    let manager = ConversationManager(maxWindowSize: 5, summarizationThreshold: 4)

    func runSimulation() async {
        print("--- Starting Chat Simulation ---")

        let dialogue = [
            ChatMessage(role: .user, content: "Hello! I'm learning Swift 6."),
            ChatMessage(role: .assistant, content: "That's great! Swift 6 introduces powerful concurrency features."),
            ChatMessage(role: .user, content: "Can you explain Actors?"),
            ChatMessage(role: .assistant, content: "Actors are reference types that protect their internal state from data races."),
            ChatMessage(role: .user, content: "How do they differ from Classes?"),
            ChatMessage(role: .assistant, content: "Unlike classes, actors only allow one task to access their mutable state at a time."),
            ChatMessage(role: .user, content: "That makes sense. Tell me more about Sendable."),
            ChatMessage(role: .assistant, content: "Sendable is a protocol that indicates a type can be safely passed across concurrency boundaries.")
        ]

        for message in dialogue {
            // Add the message to our manager
            await manager.addMessage(message)
            
            // Simulate a small delay between user/assistant turns
            try? await Task.sleep(for: .milliseconds(500))
        }

        print("\n--- Final Context Sent to LLM ---")
        let finalContext = await manager.getFullContextForAPI()
        for msg in finalContext {
            print("[\(msg.role.rawValue.uppercased())]: \(msg.content)")
        }
    }
}

// To execute in a Swift Playground or Command Line Tool:
// Task {
//    await ChatAppSimulator().runSimulation()
// }
