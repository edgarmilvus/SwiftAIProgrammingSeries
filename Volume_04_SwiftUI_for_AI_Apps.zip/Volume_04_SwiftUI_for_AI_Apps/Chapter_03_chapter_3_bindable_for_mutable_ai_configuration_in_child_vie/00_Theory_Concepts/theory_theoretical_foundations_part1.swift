
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// MARK: - AI Model Configuration
@Observable
@available(iOS 18.0, *)
final class AIModelConfiguration: Sendable { // Conforms to Sendable for actor safety
    var temperature: Double
    var topP: Double
    var maxTokens: Int
    var modelIdentifier: String
    var enableStreaming: Bool

    init(temperature: Double = 0.7, topP: Double = 0.9, maxTokens: Int = 512, modelIdentifier: String = "gpt-4o", enableStreaming: Bool = true) {
        self.temperature = temperature
        self.topP = topP
        self.maxTokens = maxTokens
        self.modelIdentifier = modelIdentifier
        self.enableStreaming = enableStreaming
    }

    // Example of a method that might be called by an AI actor
    func validateParameters() {
        // Perform validation logic
        if temperature < 0.0 || temperature > 2.0 {
            print("Warning: Temperature out of typical range.")
        }
        // ... more validation
    }
}

// MARK: - Parent View (owning the configuration)
@available(iOS 18.0, *)
struct ContentView: View {
    @State private var config = AIModelConfiguration() // Parent owns the @Observable instance

    var body: some View {
        NavigationStack {
            VStack {
                Text("Current Temperature: \(config.temperature, specifier: "%.2f")")
                Text("Current Max Tokens: \(config.maxTokens)")

                Divider()

                // Pass the observable object to the child view
                AIConfigurationEditor(configuration: config)

                Button("Trigger Inference (Simulated)") {
                    // In a real app, this would call an AI actor
                    print("Simulating inference with config: \(config.modelIdentifier), temp: \(config.temperature)")
                }
                .padding()
            }
            .navigationTitle("AI App Settings")
        }
    }
}

// MARK: - Child View (mutating the configuration)
@available(iOS 18.0, *)
struct AIConfigurationEditor: View {
    // @Bindable creates a mutable binding to the @Observable object
    @Bindable var configuration: AIModelConfiguration

    var body: some View {
        Form {
            Section("Model Parameters") {
                Slider(value: $configuration.temperature, in: 0.0...2.0, step: 0.05) {
                    Text("Temperature")
                } minimumValueLabel: {
                    Text("0.0")
                } maximumValueLabel: {
                    Text("2.0")
                }
                Text("Value: \(configuration.temperature, specifier: "%.2f")")

                Stepper("Max Tokens: \(configuration.maxTokens)", value: $configuration.maxTokens, in: 100...2048, step: 100)

                Toggle("Enable Streaming", isOn: $configuration.enableStreaming)
            }

            Section("Model Selection") {
                TextField("Model Identifier", text: $configuration.modelIdentifier)
            }
        }
        .padding()
        .navigationTitle("Edit Configuration")
    }
}
