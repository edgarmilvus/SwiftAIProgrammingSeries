
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import RealityKit
import AVFoundation

// MARK: - Data Model
enum DeviceType: String, Sendable {
    case light, thermostat, lock
}

protocol SmartDevice: Sendable {
    var id: UUID { get }
    var type: DeviceType { get }
    var location: SIMD3<Float> { get }
    var status: String { get }
}

struct SmartLight: SmartDevice {
    let id = UUID()
    let type: DeviceType = .light
    let location: SIMD3<Float>
    let status: String
}

// MARK: - State Management
/// Actor to ensure thread-safe updates from various IoT sensors.
actor DeviceRegistry {
    private var devices: [UUID: any SmartDevice] = [:]
    
    func updateDevice(_ device: any SmartDevice) {
        devices[device.id] = device
    }
    
    func getAllDevices() -> [any SmartDevice] {
        return Array(devices.values)
    }
}

// MARK: - AI Service
struct SceneAnalysisService {
    /// Simulates an LLM processing the device list.
    func generateSummary(from devices: [any SmartDevice]) async -> String {
        guard !devices.isEmpty else { return "The room is empty." }
        
        let deviceDescriptions = devices.map { "\($0.type.rawValue) is \($0.status)" }
        return "Current status: \(deviceDescriptions.joined(separator: ", "))."
    }
}

// MARK: - The Narrator
@MainActor
class SceneNarrator {
    private let registry: DeviceRegistry
    private let aiService: SceneAnalysisService
    private let synthesizer = AVSpeechSynthesizer()
    
    init(registry: DeviceRegistry, aiService: SceneAnalysisService) {
        self.registry = registry
        self.aiService = aiService
    }
    
    /// Triggers a spatially-aware summary.
    func narrateScene() async {
        let devices = await registry.getAllDevices()
        let summary = await aiService.generateSummary(from: devices)
        
        print("AI Narrator: \(summary)")
        
        // Semantic Grouping Logic:
        // 1. Play a spatialized "ping" at the location of the first mentioned device.
        // 2. Speak the summary via VoiceOver.
        if let firstDevice = devices.first {
            playSpatialCue(at: firstDevice.location)
        }
        
        let utterance = AVSpeechUtterance(string: summary)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        synthesizer.speak(utterance)
    }
    
    private func playSpatialCue(at position: SIMD3<Float>) {
        // In a real visionOS app, we would attach an AudioFileResource 
        // to a transient Entity at 'position'.
        print("Playing spatial cue at \(position)")
    }
}

// MARK: - Execution
@MainActor
func runLuminaHomeDemo() async {
    let registry = DeviceRegistry()
    let aiService = SceneAnalysisService()
    let narrator = SceneNarrator(registry: registry, aiService: aiService)
    
    // Simulate IoT updates
    await registry.updateDevice(SmartLight(location: [1, 0, -2], status: "ON"))
    await registry.updateDevice(SmartLight(location: [-1, 0, -1], status: "OFF"))
    
    // User asks: "What is the status of my room?"
    await narrator.narrateScene()
}
