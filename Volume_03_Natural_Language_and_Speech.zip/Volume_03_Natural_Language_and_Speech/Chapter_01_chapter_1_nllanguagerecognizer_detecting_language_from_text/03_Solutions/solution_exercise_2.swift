
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import NaturalLanguage

// Main app entry point (for a complete SwiftUI app)
@main
struct SnippetAnalyzerApp: App {
    var body: some Scene {
        WindowGroup {
            MultilingualSnippetAnalyzerView()
        }
    }
}

// Structure to hold the analysis result for a single snippet
struct SnippetAnalysisResult: Identifiable {
    let id = UUID()
    let originalText: String
    let hypotheses: [(language: NLLanguage, confidence: Double)]
}

struct MultilingualSnippetAnalyzerView: View {
    let snippets: [String] = [
        "Hello, how are you?", // English
        "¿Cómo estás? ¡Hola!", // Spanish
        "Bonjour, comment ça va?", // French
        "Guten Tag, wie geht es Ihnen?", // German
        "こんにちは、お元気ですか？", // Japanese
        "مرحبا كيف حالك؟", // Arabic
        "This is a short text.", // English
        "Ein kurzer Text.", // German
        "Undetermined", // Very short/ambiguous
        "Ceci est un test.", // French
        "The quick brown fox jumps over the lazy dog.", // English
        "El veloz murciélago hindú comía feliz cardillo y kiwi. La cigüeña tocaba el saxofón detrás del palenque de paja.", // Spanish pangram
        "Sphinx of black quartz, judge my vow.", // English
        "Wie geht es dir?", // German
        "Test", // Too short for good detection
        "Hola", // Short but common
    ]

    @State private var analysisResults: [SnippetAnalysisResult] = []

    var body: some View {
        NavigationView {
            List(analysisResults) { result in
                VStack(alignment: .leading, spacing: 5) {
                    Text("Original: \"\(result.originalText)\"")
                        .font(.headline)
                        .lineLimit(2) // Limit display for long snippets

                    Divider()

                    ForEach(result.hypotheses.prefix(5), id: \.language) { hypothesis in
                        HStack {
                            Text(languageDisplayName(hypothesis.language))
                                .font(.subheadline)
                            Spacer()
                            Text(String(format: "%.1f%%", hypothesis.confidence * 100))
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                    }
                    if result.hypotheses.isEmpty {
                        Text("No language hypotheses found.")
                            .foregroundColor(.secondary)
                    }
                }
                .padding(.vertical, 5)
            }
            .navigationTitle("Snippet Language Analysis")
            .onAppear {
                performAnalysis()
            }
        }
    }

    private func performAnalysis() {
        var results: [SnippetAnalysisResult] = []
        for snippet in snippets {
            // Use NLLanguageRecognizer to get language hypotheses with confidence scores
            // Requesting up to 5 solutions (languages)
            let hypotheses = NLLanguageRecognizer().languageHypotheses(for: snippet, maximumSolutions: 5)

            // Convert NLLanguage to a user-friendly string for display
            let formattedHypotheses = hypotheses
                .map { (language, confidence) in
                    (language: language, confidence: confidence)
                }
                .sorted { $0.confidence > $1.confidence } // Sort by confidence, highest first

            results.append(SnippetAnalysisResult(originalText: snippet, hypotheses: formattedHypotheses))
        }
        self.analysisResults = results
    }

    // Helper function to get a localized display name for an NLLanguage
    private func languageDisplayName(_ language: NLLanguage) -> String {
        if language == .undetermined {
            return "Undetermined"
        }
        let locale = Locale(identifier: language.rawValue)
        return locale.localizedString(forLanguageCode: language.rawValue)?.capitalized ?? language.rawValue
    }
}

// MARK: - Preview Provider (for Xcode Canvas)
#Preview {
    MultilingualSnippetAnalyzerView()
}
