/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/ImageProfiler.tsx
import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Button, StyleSheet, Image as RNImage } from 'react-native';
import { Image as ExpoImage } from 'expo-image';

const TEST_URL = 'https://picsum.photos/200/300'; // Random image service

export const ImageProfiler = () => {
    const [reloadKey, setReloadKey] = useState(0);
    const [metrics, setMetrics] = useState({
        native: { start: 0, end: 0, duration: 0 },
        expo: { start: 0, end: 0, duration: 0 },
    });
    const [winner, setWinner] = useState<string | null>(null);

    // Reset and trigger reload
    const handleReload = () => {
        // Clear metrics
        setMetrics({ native: { start: 0, end: 0, duration: 0 }, expo: { start: 0, end: 0, duration: 0 } });
        setWinner(null);
        // Change URL to bypass browser cache and force load (Simulating cache clear)
        setReloadKey(prev => prev + 1);
    };

    // Determine winner once both loads are complete
    useEffect(() => {
        if (metrics.native.duration > 0 && metrics.expo.duration > 0) {
            if (metrics.native.duration < metrics.expo.duration) {
                setWinner('native');
            } else {
                setWinner('expo');
            }
        }
    }, [metrics]);

    // Helper to update metrics
    const onLoadStart = (type: 'native' | 'expo') => {
        setMetrics(prev => ({
            ...prev,
            [type]: { ...prev[type], start: Date.now(), duration: 0 }
        }));
    };

    const onLoadEnd = (type: 'native' | 'expo') => {
        setMetrics(prev => {
            const start = prev[type].start;
            const duration = start > 0 ? Date.now() - start : 0;
            return {
                ...prev,
                [type]: { ...prev[type], end: Date.now(), duration }
            };
        });
    };

    const imageUri = `${TEST_URL}?t=${reloadKey}`;

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Image Performance Profiler</Text>
            
            <View style={styles.row}>
                {/* Left: Standard RN Image (No Caching) */}
                <View style={[styles.box, winner === 'native' ? styles.winner : (winner === 'expo' ? styles.loser : null)]}>
                    <Text style={styles.label}>Standard RN Image</Text>
                    <RNImage
                        source={{ uri: imageUri }}
                        style={styles.img}
                        onLoadStart={() => onLoadStart('native')}
                        onLoadEnd={() => onLoadEnd('native')}
                    />
                    <Text style={styles.metric}>
                        {metrics.native.duration > 0 ? `${metrics.native.duration}ms` : 'Loading...'}
                    </Text>
                </View>

                {/* Right: Expo Image (With Caching) */}
                <View style={[styles.box, winner === 'expo' ? styles.winner : (winner === 'native' ? styles.loser : null)]}>
                    <Text style={styles.label}>Expo Image (Cached)</Text>
                    <ExpoImage
                        source={{ uri: imageUri }}
                        style={styles.img}
                        cachePolicy="memory-disk"
                        onLoadStart={() => onLoadStart('expo')}
                        onLoadEnd={() => onLoadEnd('expo')}
                    />
                    <Text style={styles.metric}>
                        {metrics.expo.duration > 0 ? `${metrics.expo.duration}ms` : 'Loading...'}
                    </Text>
                </View>
            </View>

            <View style={styles.btnContainer}>
                <Button title="Reload Images" onPress={handleReload} />
            </View>

            {winner && (
                <View style={styles.analysis}>
                    <Text style={styles.analysisTitle}>Analysis:</Text>
                    <Text>
                        {winner === 'expo' 
                            ? "WINNER: Expo Image. It likely utilized the memory/disk cache, skipping the network handshake for subsequent loads or parallelizing decoding efficiently."
                            : "WINNER: Standard Image. (Rare, but possible on very first load if network conditions are perfect)."}
                    </Text>
                    {metrics.expo.duration === 0 && metrics.native.duration === 0 && (
                        <Text style={styles.note}>Note: In a real app, the 'Expo Image' cache advantage is most visible on the *second* load. This tool simulates cache clearing via URL params.</Text>
                    )}
                </View>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    container: { padding: 20, flex: 1, backgroundColor: '#f5f5f5' },
    title: { fontSize: 20, fontWeight: 'bold', marginBottom: 15, textAlign: 'center' },
    row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
    box: { 
        width: '48%', 
        backgroundColor: 'white', 
        padding: 10, 
        borderRadius: 8, 
        borderWidth: 2, 
        borderColor: '#ddd' 
    },
    winner: { borderColor: 'green', backgroundColor: '#e8f5e9' },
    loser: { borderColor: 'red', backgroundColor: '#ffebee' },
    label: { fontSize: 12, fontWeight: 'bold', marginBottom: 5, textAlign: 'center' },
    img: { width: '100%', height: 100, borderRadius: 4 },
    metric: { marginTop: 5, textAlign: 'center', fontWeight: 'bold' },
    btnContainer: { marginBottom: 20 },
    analysis: { padding: 15, backgroundColor: '#fff', borderRadius: 8, borderLeftWidth: 4, borderLeftColor: '#2196F3' },
    analysisTitle: { fontWeight: 'bold', marginBottom: 5 },
    note: { marginTop: 5, fontSize: 11, color: '#666', fontStyle: 'italic' }
});
