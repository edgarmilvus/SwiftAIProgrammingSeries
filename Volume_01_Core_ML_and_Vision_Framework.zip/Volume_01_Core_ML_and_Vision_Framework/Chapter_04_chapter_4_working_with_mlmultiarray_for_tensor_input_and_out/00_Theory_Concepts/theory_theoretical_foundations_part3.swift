
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import CoreML

// Assume MLModelPredictor actor from above
// Assume InferenceResult is a simple struct to hold processed output
struct InferenceResult {
    let topLabel: String
    let confidence: Float
    let processedOutputTensor: MLMultiArray // Keep a reference if needed for debugging/further analysis
}

@available(iOS 17.0, *)
@Observable
class InferenceViewModel {
    private let predictor: MLModelPredictor
    var currentResult: InferenceResult?
    var isLoading: Bool = false
    var errorMessage: String?

    init(predictor: MLModelPredictor) {
        self.predictor = predictor
    }

    @MainActor // Ensure UI updates happen on the main actor
    func performInference(inputMultiArray: MLMultiArray) async {
        isLoading = true
        errorMessage = nil
        do {
            let outputMultiArray = try await predictor.performPrediction(inputMultiArray: inputMultiArray)
            // Post-process the MLMultiArray output into a user-friendly format
            let (label, confidence) = postProcessOutput(outputMultiArray)
            self.currentResult = InferenceResult(topLabel: label, confidence: confidence, processedOutputTensor: outputMultiArray)
        } catch {
            self.errorMessage = "Inference failed: \(error.localizedDescription)"
            self.currentResult = nil
        }
        isLoading = false
    }

    private func postProcessOutput(_ multiArray: MLMultiArray) -> (String, Float) {
        // Example: Find the index with the highest value in a 1D output
        var maxConfidence: Float = 0.0
        var maxIndex: Int = 0
        for i in 0..<multiArray.count {
            let value = multiArray[i].floatValue
            if value > maxConfidence {
                maxConfidence = value
                maxIndex = i
            }
        }
        // Map index to a label (simplified)
        let labels = ["Cat", "Dog", "Bird"] // Example labels
        let label = (maxIndex < labels.count) ? labels[maxIndex] : "Unknown"
        return (label, maxConfidence)
    }
}

@available(iOS 17.0, *)
struct InferenceView: View {
    @State private var viewModel: InferenceViewModel // StateObject for older iOS, @State for @Observable

    init(predictor: MLModelPredictor) {
        _viewModel = State(initialValue: InferenceViewModel(predictor: predictor))
    }

    var body: some View {
        VStack {
            if viewModel.isLoading {
                ProgressView("Analyzing...")
            } else if let result = viewModel.currentResult {
                Text("Top Label: \(result.topLabel)")
                    .font(.headline)
                Text("Confidence: \(String(format: "%.2f%%", result.confidence * 100))")
                    .font(.subheadline)
            } else if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
            }

            Button("Perform Inference") {
                Task {
                    // Create a dummy input multi-array for demonstration
                    let inputShape = [1, 3] as [NSNumber]
                    let inputMultiArray = try MLMultiArray(shape: inputShape, dataType: .float32)
                    inputMultiArray[0] = 0.1 // Example values
                    inputMultiArray[1] = 0.8
                    inputMultiArray[2] = 0.1
                    await viewModel.performInference(inputMultiArray: inputMultiArray)
                }
            }
        }
    }
}

// In your App:
/*
@main
@available(iOS 17.0, *)
struct MyApp: App {
    private let predictor: MLModelPredictor

    init() {
        do {
            self.predictor = try MLModelPredictor()
        } catch {
            fatalError("Failed to load ML model: \(error)")
        }
    }

    var body: some Scene {
        WindowGroup {
            InferenceView(predictor: predictor)
        }
    }
}
*/
