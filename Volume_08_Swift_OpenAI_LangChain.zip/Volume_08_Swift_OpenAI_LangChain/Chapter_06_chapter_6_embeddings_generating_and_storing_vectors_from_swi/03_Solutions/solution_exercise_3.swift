
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import SwiftData

@Model
final class JournalEntry {
    var id: UUID
    var text: String
    var timestamp: Date
    /// We store the vector as Data for efficient SwiftData persistence
    @Attribute(.externalStorage) var embeddingData: Data

    init(text: String, vector: Vector) {
        self.id = UUID()
        self.text = text
        self.timestamp = Date()
        // Convert [Float] to Data
        self.embeddingData = vector.withUnsafeBytes { Data($0) }
    }

    /// Helper to reconstruct the vector from Data
    var vector: Vector {
        return embeddingData.withUnsafeBytes { buffer in
            Array(buffer.bindMemory(to: Float.self))
        }
    }
}

@MainActor
class SemanticJournalStore {
    private let modelContext: ModelContext
    private let similarityEngine = SimilarityEvaluator(threshold: 0.0) // We want raw scores for ranking

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }

    /// Performs a semantic search for the top K entries.
    func search(queryVector: Vector, limit: Int = 5) async throws -> [(entry: JournalEntry, score: Float)] {
        // 1. Fetch all entries
        // In a massive database, we would use a vector index, but for local, we fetch all.
        let descriptor = FetchDescriptor<JournalEntry>()
        let allEntries = try modelContext.fetch(descriptor)

        // 2. Perform Similarity Search in a background task to avoid blocking UI
        return try await Task.detached(priority: .userInitiated) {
            let scoredEntries = allEntries.map { entry -> (JournalEntry, Float) in
                let score = self.similarityEngine.cosineSimilarity(between: queryVector, and: entry.vector)
                return (entry, score)
            }

            // 3. Sort by score descending and take top K
            return scoredEntries
                .sorted { $0.1 > $1.1 }
                .prefix(limit)
                .map { $0 }
        }.value
    }

    func saveEntry(text: String, vector: Vector) {
        let newEntry = JournalEntry(text: text, vector: vector)
        modelContext.insert(newEntry)
    }
}
