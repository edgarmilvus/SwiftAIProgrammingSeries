
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

    /// `DocumentEnhancer` acts as the central component within our `DocumentScannerApp`
    /// responsible for managing and fine-tuning the `TextEnhancementModel`.
    /// It encapsulates the model, optimizer, and the training logic.
    ///
    /// **Swift Concurrency and Apple Framework Best Practices:**
    /// Using an `actor` for `DocumentEnhancer` ensures that access to the model's state
    /// (parameters, optimizer state) is synchronized, preventing data races in a concurrent
    /// application environment. This is a key Apple best practice for managing mutable state
    /// in concurrent Swift applications.
    @available(iOS 18.0, macOS 15.0, *)
    actor DocumentEnhancer {
        private var model: TextEnhancementModel
        private var optimizer: Adam<TextEnhancementModel>
        private let patchSize: Int
        private let inputFeatureCount: Int

        /// Initializes the `DocumentEnhancer` with a new `TextEnhancementModel` and `Adam` optimizer.
        /// - Parameters:
        ///   - patchSize: The size of the square pixel patch (e.g., 16 for 16x16).
        ///   - hiddenSize: The size of the hidden layer in the model.
        ///   - learningRate: The learning rate for the Adam optimizer.
        init(patchSize: Int, hiddenSize: Int, learningRate: Float = 1e-3) {
            self.patchSize = patchSize
            self.inputFeatureCount = patchSize * patchSize
            self.model = TextEnhancementModel(inputSize: inputFeatureCount, hiddenSize: hiddenSize, outputSize: inputFeatureCount)
            self.optimizer = Adam(model: model, learningRate: learningRate)
            print("DocumentEnhancer initialized with model and optimizer.")
        }

        /// Performs a fine-tuning step on the model using a batch of simulated data.
        ///
        /// **MLX Functional Transformation (`valueAndGradient`):**
        /// This is the core of MLX's efficient differentiation. Instead of manually computing
        /// gradients (which is error-prone and complex), `MLX.valueAndGradient` takes a
        /// function (`loss_fn` in this case) and automatically computes both its output
        /// (the loss value) and the gradients of that output with respect to the specified
        /// parameters (our `model.parameters()`). This functional approach is powerful
        /// and declarative.
        ///
        /// **Lazy Evaluation "Under the Hood":**
        /// When `loss_fn` is executed, MLX operations like `linear1(x)`, `relu`, `linear2(h)`,
        /// `square`, `mean` etc., do *not* immediately perform computations. Instead, they
        /// build up a computation graph in memory. The actual numerical computation
        /// (evaluation of the graph) only happens when `valueAndGradient` needs to
        /// compute the final loss and its gradients, or when an `MLXArray` is explicitly
        /// materialized (e.g., printed, converted to Swift `Array`, or used in a CPU-bound operation).
        /// This lazy evaluation allows MLX to optimize the entire graph before execution,
        /// potentially fusing operations and reducing memory traffic.
        ///
        /// - Parameters:
        ///   - batchSize: The number of samples to use in this training step.
        /// - Returns: The loss value for the current training step.
        func fineTuneStep(batchSize: Int) async throws -> Float {
            // Simulate data for the current batch
            let (noisy, clean) = simulateTextPatchData(batchSize: batchSize, patchSize: patchSize)

            // Define the loss function closure that MLX will differentiate
            // This closure takes the model's parameters and returns the loss.
            let loss_fn = { (parameters: MLXArray, input: MLXArray, target: MLXArray) -> MLXArray in
                // Temporarily update the model's parameters for this specific evaluation
                // This is how functional transformation works: you provide the parameters to differentiate against.
                self.model.update(parameters: parameters)
                let predictions = self.model(input)
                return meanSquaredError(predictions: predictions, targets: target)
            }

            // Compute loss and gradients using MLX's functional differentiation
            let (loss, gradients) = MLX.valueAndGradient(loss_fn, parameters: model.parameters(), noisy, clean)
            
            // Apply the gradients to update the model's parameters using the optimizer
            // The optimizer updates the internal state of the model based on gradients and learning rate.
            self.optimizer.update(model: model, gradients: gradients)

            // Materialize the loss value to return it. This forces the computation graph to execute.
            let lossValue = try await loss.item() as! Float
            return lossValue
        }

        /// Public method to retrieve the current model parameters.
        /// Useful for saving the model or using it for inference after training.
        func currentModelParameters() -> MLX.Parameters {
            return model.parameters()
        }

        /// Public method to perform inference with the current model.
        /// - Parameter noisyPatch: An `MLXArray` representing a single noisy patch.
        /// - Returns: An `MLXArray` representing the enhanced (cleaned) patch.
        func enhance(_ noisyPatch: MLXArray) -> MLXArray {
            return model(noisyPatch)
        }
    }
    