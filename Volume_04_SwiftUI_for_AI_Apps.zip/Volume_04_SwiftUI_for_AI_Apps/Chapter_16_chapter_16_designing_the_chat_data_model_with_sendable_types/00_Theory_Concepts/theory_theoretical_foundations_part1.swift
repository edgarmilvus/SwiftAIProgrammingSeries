
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift snippet (illustrative, not strictly required for theoretical explanation)
/*
import PackageDescription

let package = Package(
    name: "AIAppChatModel",
    platforms: [
        .iOS(.v17), // For @Observable
        .macOS(.v14)
    ],
    products: [
        .library(
            name: "AIAppChatModel",
            targets: ["AIAppChatModel"]),
    ],
    targets: [
        .target(
            name: "AIAppChatModel",
            dependencies: []),
        .testTarget(
            name: "AIAppChatModelTests",
            dependencies: ["AIAppChatModel"]),
    ]
)
*/

// MARK: - Sendable Types for Message Content

/// Represents a single piece of content within a message.
/// This could be text, an image URL, or structured AI output.
/// Enums with Sendable associated values are implicitly Sendable.
@available(iOS 18.0, *) // Assume Swift 6 features are fully available here
public enum MessageContent: Sendable, Identifiable, Hashable {
    // A simple ID generation for example purposes. Real apps might use a more robust scheme.
    public var id: UUID {
        switch self {
        case .text(let string): return UUID(name: string, namespace: .url) // Example, real UUIDs would be better
        case .imageURL(let url): return UUID(name: url.absoluteString, namespace: .url)
        case .structuredData(let data): return UUID(name: data.description, namespace: .url)
        }
    }

    case text(String)
    case imageURL(URL)
    case structuredData(Data) // JSON, Protobuf, etc.
}

/// Represents the role of the message sender.
/// Enums with no associated values are implicitly Sendable.
@available(iOS 18.0, *)
public enum MessageRole: Sendable, Hashable {
    case user
    case assistant
    case system
    case tool
}

// MARK: - The Chat Message (Sendable Value Type)

/// Represents a single message in the chat conversation.
/// This is a value type (`struct`), and all its properties (`UUID`, `MessageRole`, `[MessageContent]`, `Date`)
/// are themselves `Sendable`. Therefore, `ChatMessage` is implicitly `Sendable`.
/// This allows `ChatMessage` instances to be safely passed across concurrency boundaries.
@available(iOS 18.0, *)
public struct ChatMessage: Sendable, Identifiable, Hashable {
    public let id: UUID
    public let role: MessageRole
    public var content: [MessageContent] // Can be multiple parts, e.g., text + image
    public let timestamp: Date

    public init(id: UUID = UUID(), role: MessageRole, content: [MessageContent], timestamp: Date = Date()) {
        self.id = id
        self.role = role
        self.content = content
        self.timestamp = timestamp
    }

    /// Appends a new content part to an existing message.
    /// Useful for streaming text or adding follow-up AI outputs.
    public mutating func appendContent(_ newContent: MessageContent) {
        self.content.append(newContent)
    }

    /// Appends a string to the last text content part, or creates a new one.
    /// This is crucial for real-time token streaming from LLMs.
    public mutating func appendText(_ text: String) {
        if var lastTextContent = self.content.last,
           case .text(var existingText) = lastTextContent {
            existingText += text
            self.content[self.content.count - 1] = .text(existingText)
        } else {
            self.content.append(.text(text))
        }
    }
}

// MARK: - Observable State for SwiftUI

/// This class holds the observable state that SwiftUI views will consume.
/// It must be a class and conform to `@Observable` to enable SwiftUI's observation framework.
/// All properties accessed by SwiftUI must be on the MainActor.
@MainActor @Observable
@available(iOS 18.0, *)
public class ObservableChatState {
    public var messages: [ChatMessage] = []
    public var isLoadingAIResponse: Bool = false
    public var currentStreamingMessageID: UUID?

    public init() {}
}

// MARK: - The Chat Conversation Actor (Manages Mutable State Safely)

/// `ChatConversation` is an `actor` responsible for managing the mutable state of a chat.
/// It ensures that `_messages` (the source of truth) is only accessed and modified
/// in a thread-safe manner. It also bridges updates to the `ObservableChatState` on the `MainActor`.
@available(iOS 18.0, *)
public actor ChatConversation {
    public let id: UUID
    // The observable state is managed by the actor, but its properties are
    // accessed by SwiftUI on the MainActor.
    private let chatState: ObservableChatState

    // The actor's internal, mutable source of truth for messages.
    // This property is actor-isolated and only accessed within actor methods.
    private var _messages: [ChatMessage]

    public init(id: UUID = UUID(), initialMessages: [ChatMessage] = []) {
        self.id = id
        self.chatState = ObservableChatState()
        self._messages = initialMessages
        // Initialize the observable state from the actor's internal state on the MainActor.
        Task { @MainActor in
            self.chatState.messages = initialMessages
        }
    }

    // MARK: - Actor-Isolated Methods for Mutating State

    /// Adds a new message to the conversation.
    /// This method is `async` because it modifies the actor's isolated state (`_messages`).
    /// It then updates the `ObservableChatState` on the `MainActor` to reflect the change in the UI.
    public func addMessage(_ message: ChatMessage) async {
        _messages.append(message)
        // Update the observable state on the MainActor to trigger UI updates.
        await MainActor.run {
            chatState.messages.append(message)
        }
    }

    /// Initiates a new AI response message, typically when an LLM starts generating.
    public func startStreamingAIResponse(role: MessageRole = .assistant, id: UUID = UUID()) async {
        let newMessage = ChatMessage(id: id, role: role, content: [])
        _messages.append(newMessage)
        await MainActor.run {
            chatState.messages.append(newMessage)
            chatState.currentStreamingMessageID = id
            chatState.isLoadingAIResponse = true
        }
    }

    /// Appends a token to the currently streaming AI message.
    /// This method is called repeatedly by a background task generating tokens.
    /// It safely modifies the actor's state and updates the UI-facing observable state.
    public func appendTokenToStreamingMessage(token: String) async {
        // Accessing chatState.currentStreamingMessageID needs to be on MainActor
        guard let streamingMessageID = await MainActor.run({ chatState.currentStreamingMessageID }),
              let index = _messages.firstIndex(where: { $0.id == streamingMessageID }) else {
            print("Error: No streaming message active or message not found.")
            return
        }

        _messages[index].appendText(token)
        // Update the observable state on the MainActor
        await MainActor.run {
            if let observableIndex = chatState.messages.firstIndex(where: { $0.id == streamingMessageID }) {
                chatState.messages[observableIndex].appendText(token)
            }
        }
    }

    /// Marks the completion of an AI response stream.
    public func finishStreamingAIResponse() async {
        await MainActor.run {
            chatState.currentStreamingMessageID = nil
            chatState.isLoadingAIResponse = false
        }
    }

    /// Retrieves a snapshot of the current messages.
    /// Returns a copy (`ChatMessage` is a value type) to prevent external modification of actor state.
    public func getMessages() async -> [ChatMessage] {
        return _messages
    }

    // MARK: - Accessing Observable State for SwiftUI

    /// Provides read-only access to the observable state for SwiftUI views.
    /// This property is accessed directly on the MainActor.
    @MainActor
    public var observableState: ObservableChatState {
        chatState
    }
}

// MARK: - Example Usage in a SwiftUI View

import SwiftUI

@available(iOS 18.0, *)
struct ChatView: View {
    // @State holds the actor instance, ensuring its lifetime.
    @State private var conversation: ChatConversation

    init(conversation: ChatConversation) {
        _conversation = State(initialValue: conversation)
    }

    // Access the observable state directly on the MainActor.
    // SwiftUI observes changes to properties within `observableChatState`.
    @MainActor
    private var observableChatState: ChatConversation.ObservableChatState {
        conversation.observableState
    }

    var body: some View {
        VStack {
            ScrollView {
                LazyVStack(alignment: .leading) {
                    // ForEach observes changes to observableChatState.messages
                    ForEach(observableChatState.messages) { message in
                        MessageRow(message: message)
                    }
                }
            }
            .padding()

            if observableChatState.isLoadingAIResponse {
                ProgressView()
                    .padding()
            }

            HStack {
                TextField("Type a message...", text: .constant("")) // Simplified for example
                    .textFieldStyle(.roundedBorder)
                Button("Send") {
                    // Simulate sending a message and getting a streaming AI response
                    Task {
                        let userMessage = ChatMessage(role: .user, content: [.text("Tell me about Sendable types.")])
                        await conversation.addMessage(userMessage)

                        // Simulate AI response generation on a background task
                        await conversation.startStreamingAIResponse()
                        let aiResponseTokens = ["The ", "Sendable ", "protocol ", "in ", "Swift ", "6 ",
                                                "ensures ", "type ", "safety ", "across ", "concurrency ",
                                                "boundaries.", " It's ", "key ", "for ", "data ", "integrity."]
                        for token in aiResponseTokens {
                            await Task.sleep(nanoseconds: 100_000_000) // Simulate network/generation delay
                            await conversation.appendTokenToStreamingMessage(token: token)
                        }
                        await conversation.finishStreamingAIResponse()
                    }
                }
            }
            .padding()
        }
        .navigationTitle("AI Chat")
    }
}

@available(iOS 18.0, *)
struct MessageRow: View {
    let message: ChatMessage // ChatMessage is Sendable, safe to pass as value type

    var body: some View {
        HStack {
            if message.role == .user {
                Spacer()
                messageContentView
                    .padding(10)
                    .background(Color.blue)
                    .cornerRadius(10)
                    .foregroundColor(.white)
            } else {
                messageContentView
                    .padding(10)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                Spacer()
            }
        }
    }

    @ViewBuilder
    private var messageContentView: some View {
        VStack(alignment: .leading) {
            ForEach(message.content) { contentPart in
                switch contentPart {
                case .text(let text):
                    Text(text)
                case .imageURL(let url):
                    AsyncImage(url: url) { image in
                        image.resizable().aspectRatio(contentMode: .fit).frame(maxHeight: 200)
                    } placeholder: {
                        ProgressView()
                    }
                case .structuredData(let data):
                    Text("Structured Data: \(String(data: data, encoding: .utf8) ?? "N/A")")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
    }
}
