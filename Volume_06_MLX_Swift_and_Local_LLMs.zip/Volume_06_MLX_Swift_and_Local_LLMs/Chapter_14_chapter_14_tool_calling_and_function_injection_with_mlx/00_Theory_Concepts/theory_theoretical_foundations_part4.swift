
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 18.0, *)
    @Observable
    class ChatViewModel {
        var messages: [Message] = []
        var isLoading: Bool = false
        var currentInput: String = ""
        
        private let llmActor: LLMInferenceActor
        private let toolRegistryActor: ToolRegistryActor

        init(llmActor: LLMInferenceActor, toolRegistryActor: ToolRegistryActor) {
            selfm.llmActor = llmActor
            self.toolRegistryActor = toolRegistryActor
            
            // Register example tools
            Task {
                await toolRegistryActor.registerTool(
                    name: "getCurrentWeather",
                    schema: "{ \"city\": \"string\" }",
                    handler: { args in
                        guard let city = args["city"] else { throw ToolRegistryActor.ToolError.executionFailed(name: "getCurrentWeather", details: "Missing city") }
                        // Simulate API call
                        try await Task.sleep(for: .seconds(1))
                        return "The weather in \(city) is sunny with 25°C."
                    }
                )
            }
        }

        func sendMessage() async {
            guard !currentInput.isEmpty else { return }
            let userMessage = Message.user(content: currentInput)
            messages.append(userMessage)
            isLoading = true
            let input = currentInput
            currentInput = "" // Clear input field

            do {
                let finalResponse = try await processUserRequest(input, llm: llmActor, toolRegistry: toolRegistryActor)
                messages.append(.assistant(content: finalResponse))
            } catch {
                messages.append(.system(content: "Error: \(error.localizedDescription)"))
            }
            isLoading = false
        }
    }
    