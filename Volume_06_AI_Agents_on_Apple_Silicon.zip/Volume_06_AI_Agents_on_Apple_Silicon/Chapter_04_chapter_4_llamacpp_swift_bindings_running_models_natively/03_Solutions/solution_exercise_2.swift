
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import AppKit
import Foundation // For URL, String, Data, etc.

// Assume LlamaKit bindings (LlamaModel, LlamaContext, LlamaModelParams, LlamaContextParams, LlamaError)
// as defined in Exercise 1 are available in the project.
// For this solution, the mock LlamaKit definitions from Exercise 1 are implicitly included.

// MARK: - Chat Manager to encapsulate LLM logic

@MainActor // All UI updates and state changes should happen on the main actor
class LlamaChatManager: ObservableObject {
    private var llamaModel: LlamaModel?
    private var llamaContext: LlamaContext?
    private var modelPath: String // Path to the GGUF model
    
    @Published var chatHistory: String = ""
    @Published var isGenerating: Bool = false
    @Published var errorMessage: String?

    private var currentChatSessionHistory: [(role: String, content: String)] = []
    private let maxTokensToGenerate = 200 // Max tokens per response
    private let contextWindowSize: UInt32 = 2048 // Example context window size
    private let systemPrompt = "You are a helpful AI assistant. Respond concisely."

    init(modelPath: String) {
        self.modelPath = modelPath
    }

    func loadModelAndContext() async {
        guard !isGenerating else { return } // Prevent re-loading while generating
        isGenerating = true
        errorMessage = nil
        chatHistory = "Loading model...\n"

        do {
            // 1. Model Loading
            llamaModel = LlamaModel(path: modelPath)
            try llamaModel?.load()

            guard let model = llamaModel else {
                throw LlamaError.generalError("Failed to initialize LlamaModel.")
            }

            // 2. Context Initialization
            var contextParams = LlamaContextParams()
            contextParams.n_ctx = contextWindowSize
            contextParams.n_threads = 6 // Example: Use 6 threads
            contextParams.temp = 0.7 // Slightly lower temp for more focused chat
            contextParams.top_p = 0.9
            llamaContext = try LlamaContext(model: model, params: contextParams)

            chatHistory = "Model loaded and context initialized. Ready to chat!\n"
            print("LlamaChatManager: Model and context ready.")
        } catch {
            errorMessage = error.localizedDescription
            chatHistory = "Error: \(error.localizedDescription)\n"
            print("LlamaChatManager: Error loading model/context: \(error.localizedDescription)")
        }
        isGenerating = false
    }

    func sendMessage(_ userMessage: String) async {
        guard !userMessage.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              let model = llamaModel,
              let context = llamaContext,
              !isGenerating else { return }

        isGenerating = true
        errorMessage = nil
        
        // Append user message to history and UI
        currentChatSessionHistory.append((role: "User", content: userMessage))
        chatHistory += "User: \(userMessage)\n"
        chatHistory += "Assistant: " // Prepare for streaming response

        // Construct the full prompt including history
        let fullPrompt = buildFullPrompt()
        print("LlamaChatManager: Full prompt for inference:\n\(fullPrompt)")

        do {
            // Clear context and feed new prompt
            try context.reset() // Reset context to clear previous state
            let promptTokens = model.tokenize(text: fullPrompt, addBos: true)
            try context.feedPrompt(tokens: promptTokens)

            var assistantResponse = ""
            var generatedTokensCount = 0

            // 4. Streaming Inference
            for _ in 0..<maxTokensToGenerate {
                // Check for cancellation if user types again or task is explicitly cancelled
                try Task.checkCancellation()

                let nextToken = context.sampleNextToken()

                if nextToken == model.getEosToken() {
                    print("LlamaChatManager: [EOS] detected.")
                    break
                }
                if nextToken == -1 {
                    throw LlamaError.inferenceFailed("Invalid token generated.")
                }

                let newText = model.detokenize(tokens: [nextToken])
                assistantResponse += newText
                generatedTokensCount += 1

                // Append to UI on the main thread
                chatHistory += newText
                
                // Simulate real-time token generation delay
                try await Task.sleep(seconds: 0.02)
            }

            // Append full assistant response to history
            currentChatSessionHistory.append((role: "Assistant", content: assistantResponse.trimmingCharacters(in: .whitespacesAndNewlines)))
            print("LlamaChatManager: Assistant response complete.")

        } catch is LlamaError {
            errorMessage = "LLM Error: \(error.localizedDescription)"
            chatHistory += "\n[Error: \(error.localizedDescription)]\n"
            print("LlamaChatManager: LLM error during inference: \(error.localizedDescription)")
        } catch is CancellationError {
            chatHistory += "\n[Generation cancelled]\n"
            print("LlamaChatManager: Inference task cancelled.")
        } catch {
            errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
            chatHistory += "\n[Error: \(error.localizedDescription)]\n"
            print("LlamaChatManager: Unexpected error during inference: \(error.localizedDescription)")
        }
        isGenerating = false
    }
    
    // Helper to construct prompt with history
    private func buildFullPrompt() -> String {
        var prompt = systemPrompt + "\n"
        for item in currentChatSessionHistory {
            prompt += "\(item.role): \(item.content)\n"
        }
        prompt += "Assistant: " // Indicate that the assistant should respond next
        return prompt
    }
    
    deinit {
        print("LlamaChatManager: Deallocating.")
        // Explicitly nil out model and context to trigger deinit for cleanup
        llamaContext = nil
        llamaModel = nil
    }
}

// MARK: - macOS AppKit UI

class ChatWindowController: NSWindowController {
    convenience init() {
        let window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 600, height: 500),
            styleMask: [.titled, .closable, .resizable, .miniaturizable],
            backing: .buffered,
            defer: false
        )
        window.center()
        window.title = "Llama.cpp Swift Chat"
        self.init(window: window)
    }

    private let chatManager: LlamaChatManager
    private var chatTextView: NSTextView!
    private var inputTextField: NSTextField!
    private var sendButton: NSButton!
    private var scrollView: NSScrollView!

    // Using Combine for observing @Published properties
    private var cancellables = Set<AnyCancellable>()

    override init(window: NSWindow?) {
        // IMPORTANT: Replace with the actual path to your .gguf model file.
        // For this mock, a dummy file will be created/used at this path.
        let modelFileName = "dummy_model.gguf"
        let modelPath = FileManager.default.temporaryDirectory.appendingPathComponent(modelFileName).path
        self.chatManager = LlamaChatManager(modelPath: modelPath)
        super.init(window: window)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func windowDidLoad() {
        super.windowDidLoad()
        setupUI()
        bindViewModel()
        
        // Load model and context asynchronously on app launch
        Task {
            await chatManager.loadModelAndContext()
        }
    }

    private func setupUI() {
        guard let contentView = window?.contentView else { return }
        contentView.autoresizesSubviews = true

        // Chat Text View (for history and responses)
        scrollView = NSScrollView()
        scrollView.hasVerticalScroller = true
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(scrollView)

        chatTextView = NSTextView()
        chatTextView.isEditable = false
        chatTextView.isSelectable = true
        chatTextView.textContainerInset = NSSize(width: 10, height: 10)
        chatTextView.font = NSFont.systemFont(ofSize: 14)
        scrollView.documentView = chatTextView

        // Input Text Field
        inputTextField = NSTextField()
        inputTextField.translatesAutoresizingMaskIntoConstraints = false
        inputTextField.placeholderString = "Type your message here..."
        inputTextField.delegate = self // To handle Return key
        contentView.addSubview(inputTextField)

        // Send Button
        sendButton = NSButton(title: "Send", target: self, action: #selector(sendPrompt(_:)))
        sendButton.translatesAutoresizingMaskIntoConstraints = false
        sendButton.bezelStyle = .rounded
        contentView.addSubview(sendButton)

        // Layout Constraints
        NSLayoutConstraint.activate([
            // ScrollView constraints
            scrollView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            scrollView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            scrollView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            scrollView.bottomAnchor.constraint(equalTo: inputTextField.topAnchor, constant: -10),

            // Input Text Field constraints
            inputTextField.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            inputTextField.trailingAnchor.constraint(equalTo: sendButton.leadingAnchor, constant: -10),
            inputTextField.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20),
            inputTextField.heightAnchor.constraint(equalToConstant: 28),

            // Send Button constraints
            sendButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            sendButton.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20),
            sendButton.widthAnchor.constraint(equalToConstant: 60),
            sendButton.heightAnchor.constraint(equalToConstant: 28)
        ])
    }

    private func bindViewModel() {
        // Observe chat history changes and update UI
        chatManager.$chatHistory
            .receive(on: DispatchQueue.main) // Ensure UI updates on main thread
            .sink { [weak self] newHistory in
                self?.chatTextView.string = newHistory
                self?.scrollToBottom()
            }
            .store(in: &cancellables)

        // Observe generation state to enable/disable UI
        chatManager.$isGenerating
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isGenerating in
                self?.inputTextField.isEnabled = !isGenerating
                self?.sendButton.isEnabled = !isGenerating
                if isGenerating {
                    self?.inputTextField.placeholderString = "Generating response..."
                } else {
                    self?.inputTextField.placeholderString = "Type your message here..."
                }
            }
            .store(in: &cancellables)
        
        // Observe error messages
        chatManager.$errorMessage
            .receive(on: DispatchQueue.main)
            .sink { [weak self] errorMessage in
                if let message = errorMessage {
                    let alert = NSAlert()
                    alert.messageText = "Error"
                    alert.informativeText = message
                    alert.alertStyle = .critical
                    alert.runModal()
                }
            }
            .store(in: &cancellables)
    }

    @objc private func sendPrompt(_ sender: NSButton) {
        let message = inputTextField.stringValue
        guard !message.isEmpty else { return }

        inputTextField.stringValue = "" // Clear input field
        Task {
            await chatManager.sendMessage(message)
        }
    }
    
    private func scrollToBottom() {
        if let textContainer = chatTextView.textContainer,
           let layoutManager = chatTextView.layoutManager {
            let rect = layoutManager.usedRect(for: textContainer)
            chatTextView.scrollRangeToVisible(NSRange(location: chatTextView.string.count, length: 0))
        }
    }
}

// MARK: - NSTextFieldDelegate for Return key

extension ChatWindowController: NSTextFieldDelegate {
    func controlTextDidEndEditing(_ obj: Notification) {
        if let textField = obj.object as? NSTextField, textField == inputTextField {
            // Check if the user pressed Return (or Enter)
            if let event = NSApp.currentEvent, event.type == .keyDown, event.keyCode == 36 { // Key code for Return
                sendPrompt(sendButton)
            }
        }
    }
}

// MARK: - App Delegate for macOS

@main
class AppDelegate: NSObject, NSApplicationDelegate {
    var windowController: ChatWindowController!

    func applicationDidFinishLaunching(_ notification: Notification) {
        windowController = ChatWindowController()
        windowController.showWindow(nil)
        
        // Ensure the app doesn't terminate when window is closed
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
    }
    
    func applicationWillTerminate(_ notification: Notification) {
        // Perform any final cleanup if necessary
        print("Application will terminate.")
    }
    
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true // Terminate when the last window is closed
    }
}
