/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/_layout.tsx
import React from 'react';
import { 
  Stack, 
  Drawer, 
  Tabs, 
  useNavigationContainerRef 
} from 'expo-router';
import { 
  useColorScheme, 
  Appearance, 
  Dimensions, 
  Platform, 
  View, 
  Text 
} from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// Mock ThemeProvider (replace with your actual provider)
const ThemeProvider = ({ children, colorScheme }: { children: React.ReactNode, colorScheme: 'light' | 'dark' }) => (
  <View style={{ flex: 1, backgroundColor: colorScheme === 'dark' ? '#000' : '#fff' }}>
    {children}
  </View>
);

// Helper to determine layout type based on width
const getLayoutType = () => {
  const width = Dimensions.get('window').width;
  return width > 768 ? 'tablet' : 'mobile';
};

export default function RootLayout() {
  const colorScheme = useColorScheme() || 'light';
  const layoutType = getLayoutType();

  return (
    <SafeAreaProvider>
      <ThemeProvider colorScheme={colorScheme}>
        {/* Conditionally render navigators based on layout type */}
        {layoutType === 'tablet' ? <DesktopDrawerLayout /> : <MobileTabsLayout />}
      </ThemeProvider>
    </SafeAreaProvider>
  );
}

// Tablet/Desktop Layout: Drawer
function DesktopDrawerLayout() {
  return (
    <Drawer>
      <Drawer.Screen 
        name="(dashboard)" 
        options={{ 
          headerShown: false,
          title: 'Dashboard' 
        }} 
      />
      <Drawer.Screen 
        name="(auth)" 
        options={{ 
          title: 'Authentication',
          headerShown: false 
        }} 
      />
    </Drawer>
  );
}

// Mobile Layout: Bottom Tabs
function MobileTabsLayout() {
  return (
    <Tabs>
      <Tabs.Screen 
        name="(dashboard)" 
        options={{ 
          headerShown: false,
          title: 'Dashboard',
          tabBarIcon: ({ color }) => <Text style={{ color }}>📊</Text>
        }} 
      />
      <Tabs.Screen 
        name="(auth)" 
        options={{ 
          title: 'Auth',
          headerShown: false,
          tabBarIcon: ({ color }) => <Text style={{ color }}>🔐</Text>
        }} 
      />
    </Tabs>
  );
}
