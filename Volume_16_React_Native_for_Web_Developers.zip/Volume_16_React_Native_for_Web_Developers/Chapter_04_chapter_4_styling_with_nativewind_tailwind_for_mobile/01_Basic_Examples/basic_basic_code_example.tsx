/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// @ts-nocheck
// NOTE: This is a self-contained example. In a real project, you would need to
// install dependencies: `npx expo install react-native react-native-safe-area-context`
// and configure NativeWind in your `tailwind.config.js`.

import React, { useState } from 'react';
import {
  Text,
  View,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from 'react-native';

/**
 * @description A simple, universal login screen component styled with NativeWind.
 * This component demonstrates the core syntax of using Tailwind utility classes
 * within a React Native/Expo application.
 * @returns {JSX.Element} A styled login screen component.
 */
export default function LoginScreen() {
  // State management for form inputs
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  /**
   * @description Handles the login form submission.
   * In a real SaaS application, this would call an API endpoint (e.g., via fetch or a GraphQL client).
   * For this example, we simulate an async network request.
   */
  const handleLogin = async () => {
    // Basic client-side validation
    if (!email || !password) {
      Alert.alert('Error', 'Please enter both email and password.');
      return;
    }

    setIsLoading(true);

    // Simulate an API call
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000)); // 2-second delay
      console.log(`Logging in with email: ${email}`);
      Alert.alert('Success', 'Login successful!');
    } catch (error) {
      Alert.alert('Login Failed', 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    // SafeAreaView ensures content isn't obscured by device notches or status bars
    <SafeAreaView className="flex-1 bg-slate-900">
      {/* KeyboardAvoidingView pushes the content up when the keyboard appears */}
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
      >
        {/* ScrollView allows content to scroll if it overflows */}
        <ScrollView
          contentContainerStyle={{ flexGrow: 1 }}
          keyboardShouldPersistTaps="handled"
        >
          <View className="flex-1 justify-center items-center px-6">
            {/* Header Section */}
            <View className="mb-8 items-center">
              <Text className="text-4xl font-bold text-white mb-2">
                Welcome Back
              </Text>
              <Text className="text-slate-400 text-base">
                Sign in to your account
              </Text>
            </View>

            {/* Form Container */}
            <View className="w-full max-w-sm space-y-4">
              {/* Email Input Field */}
              <View>
                <Text className="text-slate-300 text-sm font-medium mb-2">
                  Email Address
                </Text>
                <TextInput
                  value={email}
                  onChangeText={setEmail}
                  placeholder="you@example.com"
                  placeholderTextColor="#64748b" // slate-500
                  keyboardType="email-address"
                  autoCapitalize="none"
                  className="bg-slate-800 text-white text-base px-4 py-3 rounded-lg border border-slate-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                  editable={!isLoading}
                />
              </View>

              {/* Password Input Field */}
              <View>
                <Text className="text-slate-300 text-sm font-medium mb-2">
                  Password
                </Text>
                <TextInput
                  value={password}
                  onChangeText={setPassword}
                  placeholder="••••••••"
                  placeholderTextColor="#64748b"
                  secureTextEntry
                  className="bg-slate-800 text-white text-base px-4 py-3 rounded-lg border border-slate-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                  editable={!isLoading}
                />
              </View>

              {/* Login Button */}
              <TouchableOpacity
                onPress={handleLogin}
                disabled={isLoading}
                className={`w-full py-3 px-4 rounded-lg items-center justify-center mt-4 transition-opacity ${
                  isLoading ? 'opacity-60' : 'opacity-100'
                } ${isLoading ? 'bg-slate-600' : 'bg-blue-600 hover:bg-blue-700'}`}
              >
                <Text className="text-white font-semibold text-base">
                  {isLoading ? 'Signing In...' : 'Sign In'}
                </Text>
              </TouchableOpacity>

              {/* Footer Links */}
              <View className="flex-row justify-between mt-4">
                <TouchableOpacity>
                  <Text className="text-blue-400 text-sm font-medium">
                    Forgot Password?
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity>
                  <Text className="text-blue-400 text-sm font-medium">
                    Create Account
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
