
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import Vision
import PhotosUI // For modern photo picker on iOS 14+

// MARK: - Smart Category Definition
struct SmartCategory {
    let name: String
    let keywords: [String] // Keywords to look for in VNClassificationObservation.identifier
}

extension SmartCategory: Identifiable { // Conformance for potential UI lists
    var id: String { name }
}

let predefinedCategories: [SmartCategory] = [
    SmartCategory(name: "Animals", keywords: ["dog", "cat", "bird", "horse", "fish", "animal", "pet", "wildlife", "mammal", "reptile", "insect"]),
    SmartCategory(name: "Food", keywords: ["food", "pizza", "sushi", "fruit", "vegetable", "dessert", "dish", "meal", "drink", "cuisine", "snack"]),
    SmartCategory(name: "Nature", keywords: ["tree", "mountain", "river", "ocean", "sky", "flower", "landscape", "forest", "beach", "lake", "plant", "garden"]),
    SmartCategory(name: "Vehicles", keywords: ["car", "bicycle", "truck", "boat", "airplane", "train", "motorcycle", "vehicle", "transport"]),
    SmartCategory(name: "People", keywords: ["person", "people", "face", "human", "portrait", "group", "crowd", "man", "woman", "child"]),
    SmartCategory(name: "Buildings", keywords: ["building", "house", "city", "architecture", "tower", "structure", "urban", "skyline"]),
    SmartCategory(name: "Art & Culture", keywords: ["art", "painting", "sculpture", "museum", "gallery", "statue", "cultural", "performance", "music", "book"]),
    SmartCategory(name: "Sports", keywords: ["sport", "game", "athlete", "ball", "field", "stadium", "action", "player"]),
    SmartCategory(name: "Electronics", keywords: ["phone", "computer", "laptop", "tablet", "device", "screen", "keyboard", "electronics"]),
    SmartCategory(name: "Furniture", keywords: ["chair", "table", "couch", "bed", "furniture", "room", "interior"])
    // Add more categories as needed
]

// MARK: - Photo Categorization Logic
struct PhotoCategoryResult {
    let image: UIImage
    let originalFilename: String?
    let assignedCategories: [SmartCategory]
    let topClassification: (identifier: String, confidence: Float)?
}

class PhotoCategorizer {
    // Confidence threshold for a classification to be considered valid for categorization
    private let minimumConfidenceThreshold: Float = 0.7

    func categorize(image: UIImage, originalFilename: String?) async -> PhotoCategoryResult {
        guard let cgImage = image.cgImage else {
            print("Error: Could not convert image to CGImage for \(originalFilename ?? "unknown").")
            return PhotoCategoryResult(image: image, originalFilename: originalFilename, assignedCategories: [], topClassification: nil)
        }

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        let request = VNClassifyImageRequest()
        // Request more results to allow for broader categorization
        request.resultsLimit = 10 

        var assignedCategories: [SmartCategory] = []
        var topClassification: (identifier: String, confidence: Float)?

        do {
            try handler.perform([request])

            guard let observations = request.results as? [VNClassificationObservation], !observations.isEmpty else {
                return PhotoCategoryResult(image: image, originalFilename: originalFilename, assignedCategories: [], topClassification: nil)
            }

            // Store the very top classification for reporting
            if let firstObservation = observations.first {
                topClassification = (firstObservation.identifier, firstObservation.confidence)
            }

            // Iterate through all observations and check against predefined categories
            for observation in observations {
                guard observation.confidence >= minimumConfidenceThreshold else { continue }

                for category in predefinedCategories {
                    // Check if any keyword in the category matches the observation identifier (case-insensitive)
                    if category.keywords.contains(where: { observation.identifier.lowercased().contains($0.lowercased()) }) {
                        if !assignedCategories.contains(where: { $0.name == category.name }) {
                            assignedCategories.append(category)
                        }
                    }
                }
            }

        } catch {
            print("Vision request failed for \(originalFilename ?? "unknown") with error: \(error.localizedDescription)")
        }

        return PhotoCategoryResult(image: image, originalFilename: originalFilename, assignedCategories: assignedCategories, topClassification: topClassification)
    }

    // Batch categorization using TaskGroup
    func categorizeBatch(images: [UIImage], filenames: [String?]) async -> [PhotoCategoryResult] {
        var results: [PhotoCategoryResult] = []
        await withTaskGroup(of: PhotoCategoryResult.self) { group in
            for (index, image) in images.enumerated() {
                let filename = filenames.count > index ? filenames[index] : nil
                group.addTask { [weak self] in
                    guard let self = self else {
                        // Return a default result if self is deallocated
                        return PhotoCategoryResult(image: image, originalFilename: filename, assignedCategories: [], topClassification: nil)
                    }
                    return await self.categorize(image: image, originalFilename: filename)
                }
            }

            for await result in group {
                results.append(result)
            }
        }
        return results
    }
}

// MARK: - UIViewController for demonstration
class SmartAlbumCategorizationViewController: UIViewController {

    private let selectPhotosButton = UIButton(type: .system)
    private let resultsTextView = UITextView()
    private let activityIndicator = UIActivityIndicatorView(style: .large)
    private let categorizer = PhotoCategorizer()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
    }

    private func setupUI() {
        selectPhotosButton.setTitle("Select Photos for Categorization", for: .normal)
        selectPhotosButton.addTarget(self, action: #selector(selectPhotosTapped), for: .touchUpInside)
        selectPhotosButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(selectPhotosButton)

        resultsTextView.isEditable = false
        resultsTextView.font = UIFont.monospacedSystemFont(ofSize: 12, weight: .regular)
        resultsTextView.layer.borderColor = UIColor.systemGray4.cgColor
        resultsTextView.layer.borderWidth = 1
        resultsTextView.layer.cornerRadius = 5
        resultsTextView.text = "Select photos to see them automatically categorized."
        resultsTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(resultsTextView)

        activityIndicator.hidesWhenStopped = true
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(activityIndicator)

        NSLayoutConstraint.activate([
            selectPhotosButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            selectPhotosButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            resultsTextView.topAnchor.constraint(equalTo: selectPhotosButton.bottomAnchor, constant: 20),
            resultsTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultsTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            resultsTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: resultsTextView.centerYAnchor)
        ])
    }

    @objc private func selectPhotosTapped() {
        resultsTextView.text = "Loading photos..."
        activityIndicator.startAnimating()
        selectPhotosButton.isEnabled = false

        if #available(iOS 14, *) {
            var configuration = PHPickerConfiguration()
            configuration.filter = .images
            configuration.selectionLimit = 0 // Allow multiple selections
            let picker = PHPickerViewController(configuration: configuration)
            picker.delegate = self
            present(picker, animated: true)
        } else {
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .photoLibrary
            picker.allowsEditing = false // For multiple selection, UIImagePickerController is limited
            present(picker, animated: true)
            // Note: UIImagePickerController doesn't support multiple selection easily.
            // For older iOS, a custom photo picker library would be needed for true batch import.
            // This example will only process one image if using UIImagePickerController.
        }
    }

    private func processSelectedImages(images: [UIImage], filenames: [String?]) {
        Task { @MainActor in
            self.resultsTextView.text = "Categorizing \(images.count) photo(s)... This may take a moment."
            self.activityIndicator.startAnimating()
        }

        Task.detached(priority: .userInitiated) { // Use detached task for long-running background work
            let categorizedResults = await self.categorizer.categorizeBatch(images: images, filenames: filenames)

            await MainActor.run {
                self.activityIndicator.stopAnimating()
                self.selectPhotosButton.isEnabled = true
                self.displayCategorizationResults(categorizedResults)
            }
        }
    }

    private func displayCategorizationResults(_ results: [PhotoCategoryResult]) {
        var outputText = "--- Photo Categorization Results ---\n\n"
        var categorizedCount = 0
        var uncategorizedCount = 0

        // Group results by category for a cleaner output
        var groupedResults: [String: [PhotoCategoryResult]] = [:]
        for category in predefinedCategories {
            groupedResults[category.name] = []
        }
        groupedResults["Uncategorized"] = []

        for result in results {
            if result.assignedCategories.isEmpty {
                groupedResults["Uncategorized"]?.append(result)
                uncategorizedCount += 1
            } else {
                categorizedCount += 1
                for category in result.assignedCategories {
                    groupedResults[category.name]?.append(result)
                }
            }
        }

        for categoryName in groupedResults.keys.sorted() { // Sort categories alphabetically
            guard let categoryResults = groupedResults[categoryName], !categoryResults.isEmpty else { continue }

            outputText += "### \(categoryName) (\(categoryResults.count) photos)\n"
            for result in categoryResults {
                let filename = result.originalFilename ?? "Unnamed Photo"
                let topClass = result.topClassification.map { "\($0.identifier) (\(String(format: "%.1f%%", $0.confidence * 100)))" } ?? "N/A"
                outputText += "  - \(filename) [Top: \(topClass)]\n"
            }
            outputText += "\n"
        }

        outputText += "--- Summary ---\n"
        outputText += "Total Photos: \(results.count)\n"
        outputText += "Categorized: \(categorizedCount)\n"
        outputText += "Uncategorized: \(uncategorizedCount)\n"

        resultsTextView.text = outputText
        resultsTextView.scrollRangeToVisible(NSRange(location: 0, length: 0)) // Scroll to top
    }
}

// MARK: - UIImagePickerControllerDelegate & UINavigationControllerDelegate (for iOS < 14)
extension SmartAlbumCategorizationViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true) {
            if let selectedImage = info[.originalImage] as? UIImage {
                // UIImagePickerController only allows single selection for this basic setup
                self.processSelectedImages(images: [selectedImage], filenames: ["Selected Photo"])
            } else {
                self.activityIndicator.stopAnimating()
                self.selectPhotosButton.isEnabled = true
                self.resultsTextView.text = "No image selected or image could not be loaded."
            }
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true) {
            self.activityIndicator.stopAnimating()
            self.selectPhotosButton.isEnabled = true
            self.resultsTextView.text = "Photo selection cancelled."
        }
    }
}

// MARK: - PHPickerViewControllerDelegate (for iOS 14+)
@available(iOS 14, *)
extension SmartAlbumCategorizationViewController: PHPickerViewControllerDelegate {
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true) {
            guard !results.isEmpty else {
                self.activityIndicator.stopAnimating()
                self.selectPhotosButton.isEnabled = true
                self.resultsTextView.text = "Photo selection cancelled."
                return
            }

            self.resultsTextView.text = "Loading \(results.count) photos..."

            var images: [UIImage] = []
            var filenames: [String?] = []
            let dispatchGroup = DispatchGroup() // Use DispatchGroup to wait for all images to load

            for result in results {
                dispatchGroup.enter()
                result.itemProvider.loadObject(ofClass: UIImage.self) { (object, error) in
                    if let image = object as? UIImage {
                        images.append(image)
                        filenames.append(result.itemProvider.suggestedName) // Get suggested filename
                    } else if let error = error {
                        print("Error loading image from picker: \(error.localizedDescription)")
                    }
                    dispatchGroup.leave()
                }
            }

            dispatchGroup.notify(queue: .main) {
                if images.isEmpty {
                    self.resultsTextView.text = "Failed to load any selected photos."
                    self.activityIndicator.stopAnimating()
                    self.selectPhotosButton.isEnabled = true
                } else {
                    self.processSelectedImages(images: images, filenames: filenames)
                }
            }
        }
    }
}
