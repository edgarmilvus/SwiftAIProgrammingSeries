
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import RealityKit
import SpatialAudio

// 1. The Event Coordinator: A Swift Actor for thread-safe event timing
actor WeatherCoordinator {
    func triggerEvent() -> (position: SIMD3<Float>, intensity: Float) {
        // Randomize the location of the lightning/thunder in the room
        let randomPos = SIMD3<Float>(
            Float.random(in: -2...2),
            Float.random(in: 1...4),
            Float.random(in: -2...2)
        )
        return (randomPos, 1000.0)
    }
}

struct WeatherImmersiveView: View {
    @State private var coordinator = WeatherCoordinator()
    @State private var flashIntensity: Float = 0.0
    
    var body: some View {
        RealityView { content in
            // Setup: Create a light entity
            let light = DirectionalLight()
            light.name = "lightning_light"
            content.add(light)
            
            // Setup: Create an audio entity
            let audioEntity = Entity()
            audioEntity.name = "thunder_entity"
            // Attach spatial audio component
            var audioComponent = SpatialAudioComponent()
            audioComponent.reverbLevel = 0.5
            audioEntity.components.set(audioComponent)
            content.add(audioEntity)
            
            // 2. The Synchronization Engine: Hook into the frame update loop
            content.subscribe(to: SceneEvents.Update.self) { event in
                // We check a trigger (in a real app, this would be a timer or logic)
                // For this demo, we simulate a random trigger
                if Float.random(in: 0...1) < 0.005 { 
                    Task {
                        await self.performSynchronizedEvent(content: content)
                    }
                }
            }
        }
    }

    @MainActor
    private func performSynchronizedEvent(content: RealityViewContent) async {
        // 1. Get the synchronized data from the Actor
        let eventData = await coordinator.triggerEvent()
        
        // 2. FIND ENTITIES
        guard let light = content.entities.first(where: { $0.name == "lightning_light" }),
              let thunder = content.entities.first(where: { $0.name == "thunder_entity" }) else { return }
        
        // 3. EXECUTE SIMULTANEOUSLY
        // Position the light and sound at the same spatial coordinate
        light.position = eventData.position
        thunder.position = eventData.position
        
        // Trigger Audio
        // (Assuming 'thunder_sound' is a pre-loaded resource)
        if let audioResource = try? await AudioFileResource.load(named: "thunder_sound", in: .main) {
            thunder.playAudio(audioResource)
        }
        
        // Trigger Visual Flash (Animate intensity)
        withAnimation(.easeOut(duration: 0.1)) {
            // We use a hack here: RealityKit light intensity is updated 
            // by setting the component in the update loop, but for 
            // simplicity in this demo, we simulate the peak.
            var lightComp = DirectionalLightComponent()
            lightComp.intensity = eventData.intensity
            light.components.set(lightComp)
        }
        
        // Reset light after the flash
        try? await Task.sleep(for: .seconds(0.1))
        var resetComp = DirectionalLightComponent()
        resetComp.intensity = 0
        light.components.set(resetComp)
    }
}

@main
struct WeatherApp: App {
    var body: some Scene {
        ImmersiveSpace(id: "weather-space") {
            WeatherImmersiveView()
        }
    }
}
