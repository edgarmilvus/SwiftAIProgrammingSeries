
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import AppKit

// MARK: - 1. Custom NSView subclass wrapping NSTextView

class AdvancedTextView: NSView {
    let scrollView: NSScrollView
    let textView: NSTextView

    // Delegate property to communicate text changes
    weak var textDelegate: NSTextViewDelegate?

    init() {
        self.scrollView = NSScrollView()
        self.textView = NSTextView()

        super.init(frame: .zero) // Initialize with zero frame, Auto Layout will set it

        setupScrollView()
        setupTextView()
        setupLayout()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupScrollView() {
        scrollView.hasVerticalScroller = true
        scrollView.hasHorizontalScroller = false
        scrollView.autohidesScrollers = true
        scrollView.borderType = .noBorder
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(scrollView)
    }

    private func setupTextView() {
        textView.minSize = NSSize(width: 0, height: contentRect.height)
        textView.maxSize = NSSize(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]

        // Customization as per task: custom font, disable rich text, enable smart quotes
        textView.font = NSFont.monospacedSystemFont(ofSize: 14, weight: .regular)
        textView.isRichText = false
        textView.usesRuler = false
        textView.isEditable = true
        textView.isSelectable = true
        textView.allowsUndo = true
        textView.textContainerInset = NSSize(width: 5, height: 5)
        textView.fieldEditor = false // Not a field editor for basic text
        textView.isAutomaticQuoteSubstitutionEnabled = true // Enable smart quotes
        textView.isAutomaticDashSubstitutionEnabled = true

        // Set the text view as the document view of the scroll view
        scrollView.documentView = textView
    }

    private func setupLayout() {
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
        
        // Ensure the text container matches the width of the scroll view
        textView.textContainer?.widthTracksTextView = true
    }
}

// MARK: - 2. NSViewRepresentable Bridge

struct AdvancedTextEditorRepresentable: NSViewRepresentable {
    @Binding var text: String

    func makeNSView(context: Context) -> AdvancedTextView {
        let advancedTextView = AdvancedTextView()
        advancedTextView.textView.delegate = context.coordinator // Set the coordinator as the delegate
        return advancedTextView
    }

    func updateNSView(_ nsView: AdvancedTextView, context: Context) {
        // Only update if the text from SwiftUI is different from the NSTextView's current text
        // This prevents an infinite loop when the user types and updates the binding
        if nsView.textView.string != text {
            nsView.textView.string = text
            // Ensure cursor is at the end if new text is set programmatically
            if nsView.textView.selectedRange().location == nsView.textView.string.count {
                nsView.textView.setSelectedRange(NSRange(location: nsView.textView.string.count, length: 0))
            }
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    // MARK: - 3. Coordinator for bidirectional binding

    class Coordinator: NSObject, NSTextViewDelegate {
        var parent: AdvancedTextEditorRepresentable

        init(parent: AdvancedTextEditorRepresentable) {
            self.parent = parent
        }

        func textDidChange(_ notification: Notification) {
            guard let textView = notification.object as? NSTextView else { return }
            // Update the SwiftUI binding when the NSTextView's content changes
            parent.text = textView.string
        }
        
        // Optional: Implement other NSTextViewDelegate methods as needed
    }
}

// MARK: - 4. Integrate in SwiftUI

struct Exercise1View: View {
    @State private var multilineText: String = "Start typing here...\nThis is a custom AppKit text view embedded in SwiftUI.\nIt supports multiple lines and basic AppKit features."

    var body: some View {
        VStack(alignment: .leading) {
            Text("Advanced Text Editor (AppKit)")
                .font(.headline)
                .padding(.bottom, 5)

            AdvancedTextEditorRepresentable(text: $multilineText)
                .frame(minWidth: 300, maxWidth: .infinity, minHeight: 150, maxHeight: .infinity)
                .border(Color.gray.opacity(0.5), width: 1) // Add a border for visual clarity

            Text("Current Content (SwiftUI Binding):")
                .font(.subheadline)
                .padding(.top, 10)
            Text(multilineText)
                .font(.caption)
                .foregroundColor(.secondary)
                .lineLimit(nil) // Allow unlimited lines for display
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 4)
                .padding(.vertical, 2)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(4)
        }
        .padding()
        .navigationTitle("Exercise 1")
    }
}

// To run this in a preview or an actual app:
// @main
// struct AppKitSwiftUIApp: App {
//     var body: some Scene {
//         WindowGroup {
//             Exercise1View()
//         }
//     }
// }
