
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import MLX
import MLXNN // For building neural network modules

// Ensure the code runs on platforms supporting MLX, typically iOS 17+/macOS 14+
@available(iOS 17.0, macOS 14.0, *)
class BasicMLXExample {

    /// Demonstrates basic MLXArray operations, Unified Memory benefits,
    /// and the concept of lazy evaluation.
    func runBasicExample() {
        print("--- MLX Basic Example: Voice Assistant Intent Recognition ---")

        // 1. Creating MLXArray Instances
        // MLXArray is the core tensor type. It can be initialized from Swift arrays, scalars, etc.
        // When created, the data resides in Unified Memory, accessible by both CPU and GPU.

        // Simulate an audio feature vector (e.g., MFCCs, loudness, pitch)
        // Let's say we have 5 features for a very simple intent.
        let audioFeaturesSwift: [Float] = [0.1, 0.5, 0.2, 0.8, 0.3]
        let inputTensor = MLXArray(audioFeaturesSwift, [1, 5]) // Shape: 1 batch, 5 features
        print("\n1. Input Tensor (audioFeatures):")
        print("   Value: \(inputTensor)")
        print("   Shape: \(inputTensor.shape)")
        print("   Data Type: \(inputTensor.dtype)")

        // Simulate a weight tensor for a very simple linear model
        // We want to classify into 3 intents (e.g., "play music", "set timer", "call contact")
        let weightsSwift: [Float] = [
            0.1, 0.2, 0.3, 0.4, 0.5, // Weights for intent 1
            0.6, 0.7, 0.8, 0.9, 0.1, // Weights for intent 2
            0.2, 0.3, 0.4, 0.5, 0.6  // Weights for intent 3
        ]
        let weightsTensor = MLXArray(weightsSwift, [5, 3]) // Shape: 5 features, 3 output intents
        print("\n   Weights Tensor:")
        print("   Value: \(weightsTensor)")
        print("   Shape: \(weightsTensor.shape)")

        // 2. Basic Arithmetic Operations
        // MLXArray supports common arithmetic operations. These operations
        // define a computation graph but do not execute immediately (lazy evaluation).

        // Example: Element-wise addition
        let biasSwift: [Float] = [0.01, 0.02, 0.03]
        let biasTensor = MLXArray(biasSwift, [1, 3]) // Shape: 1 batch, 3 output intents
        print("\n   Bias Tensor:")
        print("   Value: \(biasTensor)")

        // Perform a simple matrix multiplication (input * weights) + bias
        // This is a common operation in neural networks.
        let linearOutput = matmul(inputTensor, weightsTensor) + biasTensor
        print("\n2. Linear Output (matmul + bias):")
        print("   Value (lazy): \(linearOutput)") // Notice it prints as a 'lazy' computation
        print("   Shape: \(linearOutput.shape)")

        // 3. Unified Memory and Zero-Copy Benefits
        // Crucially, `inputTensor`, `weightsTensor`, `biasTensor`, and `linearOutput`
        // all refer to data that lives in the *same shared memory space* on Apple Silicon.
        // When `matmul` and `+` operations are performed, the GPU (or Neural Engine)
        // operates directly on this data without needing to copy it from CPU RAM to GPU VRAM.
        // This 'zero-copy' approach is a cornerstone of MLX's efficiency on Apple platforms.
        print("\n3. Unified Memory & Zero-Copy:")
        print("   MLXArray leverages Apple Silicon's Unified Memory. All tensors (input, weights, output)")
        print("   reside in the same memory pool, eliminating costly data transfers between CPU and GPU.")
        print("   This is a fundamental performance advantage for MLX on Apple devices.")

        // 4. Lazy Evaluation and `eval()`
        // MLX operations build a computation graph. The actual computation is deferred
        // until the result is explicitly needed or `eval()` is called.
        // This allows MLX to optimize the entire graph before execution.

        print("\n4. Lazy Evaluation:")
        print("   The `linearOutput` above is a symbolic representation of a computation.")
        print("   To get the actual numerical result, we must 'evaluate' the graph.")
        linearOutput.eval() // Force computation
        print("   Evaluated Linear Output: \(linearOutput)")

        // Let's apply an activation function, e.g., softmax, to get probabilities
        let probabilities = softMax(linearOutput, axis: -1) // Apply softmax along the last axis
        probabilities.eval() // Evaluate to see the actual probabilities
        print("\n   Probabilities (after softmax and eval()): \(probabilities)")

        // We can get the Swift array back if needed
        let resultSwiftArray = probabilities.asArray(Float.self)
        print("   Probabilities as Swift Array: \(resultSwiftArray)")

        // Determine the predicted intent (index of the max probability)
        if let maxIndex = resultSwiftArray.first?.maxIndex() {
            let intents = ["Play Music", "Set Timer", "Call Contact"]
            print("   Predicted Intent Index: \(maxIndex)")
            print("   Predicted Intent: \(intents[maxIndex])")
        }
    }
}

// Helper to find index of max element in a Swift array
extension Array where Element: Comparable {
    func maxIndex() -> Int? {
        guard let maxElement = self.max() else { return nil }
        return self.firstIndex(of: maxElement)
    }
}

// To run the example in an actual app or command-line tool:
// In your AppDelegate, SceneDelegate, or main.swift:
/*
if #available(iOS 17.0, macOS 14.0, *) {
    let example = BasicMLXExample()
    example.runBasicExample()
} else {
    print("MLX requires iOS 17.0+ or macOS 14.0+.")
}
*/
