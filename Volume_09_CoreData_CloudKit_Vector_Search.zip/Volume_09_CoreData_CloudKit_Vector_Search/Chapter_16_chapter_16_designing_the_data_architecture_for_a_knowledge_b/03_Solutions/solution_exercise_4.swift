
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CoreData
import Combine

// MARK: - Chunking Entity
@objc(NoteChunk)
public class NoteChunk: NSManagedObject, Sendable {
    // Attributes: text (String), embedding (Data)
    // Relationships: parentNode (Node)
}

// MARK: - Insight Manager
actor ContextualInsightManager: ObservableObject {
    private let searchEngine: SemanticSearchEngine
    private let container: NSPersistentContainer
    
    // For debouncing
    private var searchTask: Task<Void, Never>?
    
    // Published results (must be handled on MainActor)
    @MainActor @Published private(set) var suggestions: [Node] = []

    init(searchEngine: SemanticSearchEngine, container: NSPersistentContainer) {
        self.searchEngine = searchEngine
        self.container = container
    }

    /// The entry point for the UI: User types text
    func observeTextChange(_ text: String, for nodeID: NSManagedObjectID) {
        // 1. Cancel the previous pending search (Debounce)
        searchTask?.cancel()

        searchTask = Task {
            // 2. Wait for 750ms of silence
            try? await Task.sleep(nanoseconds: 750_000_000)
            
            if Task.isCancelled { return }

            // 3. Perform the heavy lifting
            await performInsightSearch(text: text, nodeID: nodeID)
        }
    }

    private func performInsightSearch(text: String, nodeID: NSManagedObjectID) async {
        do {
            // 4. Generate embedding for the current snippet
            let queryVector = try await searchEngine.generateEmbedding(for: text)
            
            // 5. Perform semantic search (using the Accelerate engine from Ex 3)
            // In a real app, we'd search NoteChunks, not just Nodes.
            let relatedNodes = try await searchEngine.searchSimilarNodes(to: text, limit: 5)
            
            // 6. Filter out the current node itself
            let filtered = relatedNodes.filter { $0.objectID != nodeID }

            // 7. Update UI on Main Thread
            await MainActor.run {
                self.suggestions = filtered
            }
        } catch {
            print("Insight Engine Error: \(error)")
        }
    }

    /// Re-chunks a node when it is significantly modified
    func rechunkNode(_ node: Node) async throws {
        let context = container.newBackgroundContext()
        try await context.perform {
            // Delete old chunks
            let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "NoteChunk")
            fetchRequest.predicate = NSPredicate(format: "parentNode == %@", node)
            let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
            try context.execute(deleteRequest)

            // Simple Chunking Logic: Split by paragraph (double newline)
            let paragraphs = node.content?.components(separatedBy: "\n\n") ?? []
            
            for paragraph in paragraphs where paragraph.count > 20 {
                let chunk = NoteChunk(context: context)
                chunk.text = paragraph
                chunk.parentNode = node
                // In a full implementation, we would generate embeddings here too
            }
            try context.save()
        }
    }
}

// MARK: - SwiftUI View Integration
import SwiftUI

struct SuggestionSidebar: View {
    @StateObject var manager: ContextualInsightManager // In real app, passed in
    @State private var text: String = ""
    let currentNodeID: NSManagedObjectID

    var body: some View {
        VStack {
            Text("Contextual Insights").font(.headline)
            List(manager.suggestions, id: \.objectID) { node in
                VStack(alignment: .leading) {
                    Text(node.title ?? "Untitled").fontWeight(.bold)
                    Text("Related Concept").font(.caption).foregroundColor(.secondary)
                }
            }
        }
        .onChange(of: text) { _, newValue in
            Task {
                await manager.observeTextChange(newValue, for: currentNodeID)
            }
        }
        .padding()
    }
}
