
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import CoreMotion
import CoreML // For MLModel, though MLActivityClassifier abstracts it
import Foundation

// Assume ActivityClassifierModel is your trained MLActivityClassifier model
// @available(iOS 18.0, *) // Or appropriate deployment target for your model

actor SensorDataManager {
    let motionManager = CMMotionManager()
    private var accelerometerDataStream: AsyncStream<CMAccelerometerData>?
    private var gyroscopeDataStream: AsyncStream<CMGyroData>?

    init() {
        // Setup motion manager if needed (e.g., check availability)
    }

    func startSensorUpdates() async {
        guard motionManager.isAccelerometerAvailable, motionManager.isGyroAvailable else {
            print("Accelerometer or Gyroscope not available.")
            return
        }

        // Create an AsyncStream for accelerometer data
        accelerometerDataStream = AsyncStream { continuation in
            motionManager.accelerometerUpdateInterval = 1.0 / 50.0 // 50 Hz
            motionManager.startAccelerometerUpdates(to: .main) { (data, error) in
                if let data = data {
                    continuation.yield(data)
                } else if let error = error {
                    print("Accelerometer error: \(error.localizedDescription)")
                    continuation.finish()
                }
            }
            continuation.onTermination = { @Sendable _ in
                self.motionManager.stopAccelerometerUpdates()
            }
        }

        // Create an AsyncStream for gyroscope data (similar logic)
        gyroscopeDataStream = AsyncStream { continuation in
            motionManager.gyroUpdateInterval = 1.0 / 50.0 // 50 Hz
            motionManager.startGyroUpdates(to: .main) { (data, error) in
                if let data = data {
                    continuation.yield(data)
                } else if let error = error {
                    print("Gyroscope error: \(error.localizedDescription)")
                    continuation.finish()
                }
            }
            continuation.onTermination = { @Sendable _ in
                self.motionManager.stopGyroUpdates()
            }
        }

        // Example of consuming the stream (in a separate task)
        Task {
            for await accelData in accelerometerDataStream! {
                // Process accelerometer data
                // print("Accel: \(accelData.acceleration.x)")
            }
        }
    }

    func stopSensorUpdates() {
        motionManager.stopAccelerometerUpdates()
        motionManager.stopGyroUpdates()
    }
}

@available(iOS 18.0, *) // Example for a potential future MLActivityClassifier API
actor ActivityClassifierProcessor {
    // Assuming your trained MLActivityClassifier model is loaded
    // let classifier = try! MLActivityClassifier(configuration: .init()) // Placeholder

    func classifySensorData(accelerometerData: [CMAccelerometerData], gyroscopeData: [CMGyroData]) async throws -> String {
        // In a real scenario, you'd feed a window of data to your MLActivityClassifier
        // For theoretical explanation, this is a placeholder for the actual inference call.
        // The MLActivityClassifier's prediction method would likely be an async function itself
        // or accept a completion handler.
        
        // Example: Simulating a classification delay
        try await Task.sleep(for: .milliseconds(50))
        
        let randomActivity = ["Walking", "Running", "Standing", "Sitting"].randomElement()!
        return randomActivity
    }
}
