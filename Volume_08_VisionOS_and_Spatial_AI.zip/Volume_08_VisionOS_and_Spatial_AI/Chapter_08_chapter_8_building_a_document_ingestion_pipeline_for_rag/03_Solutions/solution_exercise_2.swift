
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import UniformTypeIdentifiers

/// Represents a single unit of data in the RAG pipeline.
struct Document: Sendable {
    let id: UUID
    let content: String
    let metadata: [String: String]
}

enum LoaderError: Error {
    case invalidFileType
    case fileNotFound
    case readError(Error)
}

protocol DocumentLoader: Sendable {
    func load(from url: URL) async throws -> Document
}

@available(iOS 18.0, macOS 15.0, *)
actor LocalFileLoader: DocumentLoader {
    
    func load(from url: URL) async throws -> Document {
        // 1. Check if the file exists
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw LoaderError.fileNotFound
        }
        
        // 2. Verify the file is a plain text file using UTType
        let resourceValues = try url.resourceValues(forKeys: [.contentTypeKey])
        guard let contentType = resourceValues.contentType,
              contentType.conforms(to: .plainText) else {
            throw LoaderError.invalidFileType
        }
        
        // 3. Read the file content asynchronously
        // We use Task.detached or simply perform the I/O in the actor.
        // Since this is an actor, it won't block the Main Thread.
        do {
            let content = try String(contentsOf: url, encoding: .utf8)
            
            // 4. Return the Document
            return Document(
                id: UUID(),
                content: content,
                metadata: [
                    "fileName": url.lastPathComponent,
                    "fileExtension": url.pathExtension,
                    "loadedAt": ISO8601DateFormatter().string(from: Date())
                ]
            )
        } catch {
            throw LoaderError.readError(error)
        }
    }
}
