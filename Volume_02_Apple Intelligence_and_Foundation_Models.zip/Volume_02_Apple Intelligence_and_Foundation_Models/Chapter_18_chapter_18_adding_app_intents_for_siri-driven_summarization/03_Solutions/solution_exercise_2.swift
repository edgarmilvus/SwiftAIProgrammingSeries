
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import AppIntents
import Foundation
import CoreML // Placeholder for Apple Intelligence TextGenerationService

// MARK: - Mock Data Store and Models

// A simple struct to represent an article in the reading list
struct Article: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var url: URL
    var savedDate: Date = Date()
}

// In-memory mock data store for articles
class ArticleStore {
    static let shared = ArticleStore()
    private var articles: [Article] = [
        Article(title: "The Future of AI in Healthcare", url: URL(string: "https://example.com/ai-healthcare")!, savedDate: Date().addingTimeInterval(-86400 * 2)), // 2 days ago
        Article(title: "Swift 6 Concurrency Deep Dive", url: URL(string: "https://example.com/swift-concurrency")!, savedDate: Date().addingTimeInterval(-86400 * 1)), // 1 day ago
        Article(title: "New Trends in Sustainable Energy", url: URL(string: "https://example.com/sustainable-energy")!, savedDate: Date().addingTimeInterval(-3600)) // 1 hour ago (most recent)
    ]

    func getLatestArticle() -> Article? {
        articles.sorted(by: { $0.savedDate > $1.savedDate }).first
    }
}

// MARK: - HTML Parsing Utility (Basic)

// A very basic utility to strip HTML tags.
// For production, consider a robust HTML parsing library.
func stripHTMLTags(from htmlString: String) -> String {
    var cleanString = htmlString
    // Replace <br> with newline for readability
    cleanString = cleanString.replacingOccurrences(of: "<br>", with: "\n")
    cleanString = cleanString.replacingOccurrences(of: "<br/>", with: "\n")
    // Remove all other HTML tags
    cleanString = cleanString.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
    // Trim whitespace and multiple newlines
    cleanString = cleanString.replacingOccurrences(of: "\n\n+", with: "\n\n", options: .regularExpression, range: nil)
    cleanString = cleanString.trimmingCharacters(in: .whitespacesAndNewlines)
    return cleanString
}

// MARK: - App Intent Implementation

@available(iOS 18.0, macOS 15.0, *)
struct SummarizeLatestArticleIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize Latest Article"
    static var description = IntentDescription("Summarizes the most recently saved web article from your reading list using Apple Intelligence.")
    static var openAppWhenRun: Bool = false

    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        guard let latestArticle = ArticleStore.shared.getLatestArticle() else {
            throw AppIntentError.noArticlesFound
        }

        let articleURL = latestArticle.url
        var articleContent: String

        do {
            let (data, _) = try await URLSession.shared.data(from: articleURL)
            guard let htmlString = String(data: data, encoding: .utf8) else {
                throw AppIntentError.invalidArticleContent(url: articleURL)
            }
            articleContent = stripHTMLTags(from: htmlString)

            // Basic check for minimal content after stripping HTML
            if articleContent.trimmingCharacters(in: .whitespacesAndNewlines).count < 50 {
                throw AppIntentError.insufficientContentForSummary(url: articleURL)
            }

        } catch let urlError as URLError {
            throw AppIntentError.networkError(urlError)
        } catch {
            throw AppIntentError.failedToFetchContent(url: articleURL, reason: error.localizedDescription)
        }

        do {
            let summary = try await TextGenerationService.shared.generateSummary(for: articleContent)
            return .result(value: summary, dialog: "Here's the summary for your latest article, '\(latestArticle.title)': \(summary)")
        } catch let error as TextGenerationService.TextGenerationError {
            throw AppIntentError.summarizationFailed(reason: error.description)
        } catch {
            throw AppIntentError.summarizationFailed(reason: "An unexpected error occurred during summarization: \(error.localizedDescription)")
        }
    }
}

// MARK: - Custom App Intent Errors (Extended for this exercise)

@available(iOS 18.0, macOS 15.0, *)
extension AppIntentError {
    static var noArticlesFound: AppIntentError { .summarizationFailed(reason: "No articles found in your reading list.") }
    static func invalidArticleContent(url: URL) -> AppIntentError { .summarizationFailed(reason: "Could not decode content from \(url.absoluteString).") }
    static func networkError(_ error: URLError) -> AppIntentError { .summarizationFailed(reason: "Network error fetching article: \(error.localizedDescription).") }
    static func failedToFetchContent(url: URL, reason: String) -> AppIntentError { .summarizationFailed(reason: "Failed to fetch content from \(url.absoluteString): \(reason)") }
    static func insufficientContentForSummary(url: URL) -> AppIntentError { .summarizationFailed(reason: "The article at \(url.absoluteString) has insufficient text content for summarization after processing.") }
}
