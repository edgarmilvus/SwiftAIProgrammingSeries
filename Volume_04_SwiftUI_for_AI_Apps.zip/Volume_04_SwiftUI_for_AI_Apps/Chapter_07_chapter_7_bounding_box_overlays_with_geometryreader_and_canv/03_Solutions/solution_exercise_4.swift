
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import Foundation // For Timer and UUID

// Re-using DetectedObject from Exercise 3, adding Equatable for potential animation optimization
struct DetectedObject: Identifiable, Equatable {
    let id = UUID()
    var boundingBox: CGRect // Normalized 0-1 coordinates
    var label: String
    var confidence: Double

    // For simulation: a method to slightly move the box
    func moved(by delta: CGPoint, clampTo: CGRect = CGRect(x: 0, y: 0, width: 1, height: 1)) -> DetectedObject {
        var newBox = boundingBox.offsetBy(dx: delta.x, dy: delta.y)

        // Clamp coordinates to stay within the 0-1 range
        newBox.origin.x = max(clampTo.minX, min(clampTo.maxX - newBox.width, newBox.origin.x))
        newBox.origin.y = max(clampTo.minY, min(clampTo.maxY - newBox.height, newBox.origin.y))

        return DetectedObject(boundingBox: newBox, label: label, confidence: confidence)
    }
}

// ObjectTracker class as specified, adjusted for Swift 6 and modern concurrency practices
class ObjectTracker: ObservableObject {
    @Published var detectedObjects: [DetectedObject] = []
    private var timer: Timer?

    init() {
        startSimulation()
    }

    func startSimulation() {
        // Ensure timer is invalidated before starting a new one
        timer?.invalidate()

        // Schedule timer on the main run loop to ensure @Published updates happen on the main thread
        timer = Timer.scheduledTimer(withTimeInterval: 0.8, repeats: true) { [weak self] _ in
            // All UI-related updates (like @Published properties) should occur on the main thread.
            // Timer.scheduledTimer, when created on the main thread, typically fires on the main thread.
            // However, explicit dispatch to main queue is safer for robustness in complex scenarios.
            DispatchQueue.main.async {
                self?.updateObjects()
            }
        }
    }

    private func updateObjects() {
        var newObjects: [DetectedObject] = []

        // Simulate movement for existing objects
        for object in detectedObjects {
            let dx = CGFloat.random(in: -0.02...0.02)
            let dy = CGFloat.random(in: -0.02...0.02)
            newObjects.append(object.moved(by: CGPoint(x: dx, y: dy)))
        }

        // Simulate adding/removing objects
        if newObjects.count < 3 && Bool.random() { // Add new object sometimes if count is low
            let newX = CGFloat.random(in: 0...0.7)
            let newY = CGFloat.random(in: 0...0.7)
            let newWidth = CGFloat.random(in: 0.1...0.3)
            let newHeight = CGFloat.random(in: 0.1...0.3)
            let labels = ["Person", "Car", "Bike", "Dog", "Cat", "Tree"]
            let randomLabel = labels.randomElement()!
            let confidence = Double.random(in: 0.4...0.99)
            newObjects.append(DetectedObject(boundingBox: CGRect(x: newX, y: newY, width: newWidth, height: newHeight), label: randomLabel, confidence: confidence))
        }

        if newObjects.count > 1 && Bool.random() { // Remove an object sometimes if count is high enough
            newObjects.remove(at: Int.random(in: 0..<newObjects.count))
        }

        // Apply animation when updating the @Published property
        // This makes the Canvas redraw with animation.
        withAnimation(.easeInOut(duration: 0.7)) {
            self.detectedObjects = newObjects
        }
    }

    deinit {
        timer?.invalidate()
    }
}

struct RealtimeObjectTrackingView: View {
    // Instantiate the ObservableObject using @StateObject
    @StateObject private var tracker = ObjectTracker()

    var body: some View {
        VStack {
            Text("Real-time Object Tracking (Simulated)")
                .font(.headline)
                .padding()

            Image(systemName: "video.fill") // Placeholder for video frame
                .resizable()
                .scaledToFit()
                .foregroundColor(.gray)
                .padding()
                .overlay(
                    GeometryReader { geometry in
                        Canvas { context, size in
                            // Iterate through all detected objects from the tracker
                            for object in tracker.detectedObjects {
                                // 1. Convert normalized bounding box to actual drawing coordinates
                                let drawRect = CGRect(
                                    x: object.boundingBox.origin.x * size.width,
                                    y: object.boundingBox.origin.y * size.height,
                                    width: object.boundingBox.size.width * size.width,
                                    height: object.boundingBox.size.height * size.height
                                )

                                // 2. Determine stroke color based on confidence (same as Ex3)
                                let strokeColor: Color
                                if object.confidence > 0.8 {
                                    strokeColor = .green
                                } else if object.confidence > 0.5 {
                                    strokeColor = .yellow
                                } else {
                                    strokeColor = .red
                                }

                                // 3. Draw the bounding box
                                let path = Path(roundedRect: drawRect, cornerRadius: 5)
                                context.stroke(path, with: .color(strokeColor), lineWidth: 2)

                                // 4. Draw the label text (same as Ex3)
                                let labelText = "\(object.label) (\(String(format: "%.0f", object.confidence * 100))%)"
                                let resolvedText = context.resolve(
                                    Text(labelText)
                                        .font(.caption)
                                        .bold()
                                        .foregroundColor(.white)
                                )

                                let textSize = resolvedText.measure(in: size)
                                let textOriginX = drawRect.origin.x
                                let textOriginY = drawRect.origin.y - textSize.height - 5

                                let adjustedTextOriginX = max(0, textOriginX)
                                let adjustedTextOriginY = max(0, textOriginY)

                                let textBackgroundRect = CGRect(
                                    x: adjustedTextOriginX,
                                    y: adjustedTextOriginY,
                                    width: textSize.width + 8,
                                    height: textSize.height + 4
                                )
                                let textBackgroundPath = Path(roundedRect: textBackgroundRect, cornerRadius: 3)
                                context.fill(textBackgroundPath, with: .color(strokeColor.opacity(0.8)))

                                context.draw(
                                    resolvedText,
                                    at: CGPoint(x: adjustedTextOriginX + 4, y: adjustedTextOriginY + 2),
                                    anchor: .topLeading
                                )
                            }
                        }
                        .allowsHitTesting(false)
                    }
                )
                .frame(width: 300, height: 200)
                .background(Color.secondary.opacity(0.1))
        }
    }
}

// Preview Provider
struct RealtimeObjectTrackingView_Previews: PreviewProvider {
    static var previews: some View {
        RealtimeObjectTrackingView()
    }
}
