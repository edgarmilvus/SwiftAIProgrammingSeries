
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import NaturalLanguage // Required for NLModel

@available(iOS 18.0, *) // Conforming to the provided example's availability
class NewsArticleClassifier {
    private var currentModel: NLModel?
    private var currentModelVersion: String = "None"
    
    // MARK: - Model Loading
    /// Loads an NLModel from a given URL.
    /// This method is async to simulate a potentially long-running operation (e.g., network download).
    func loadModel(from url: URL, version: String) async throws {
        print("Attempting to load model \(version) from \(url.lastPathComponent)...")
        do {
            // NLModel(contentsOf:) can be a blocking call for very large models or network files.
            // Executing it in a Task allows the calling context to remain responsive.
            let newModel = try NLModel(contentsOf: url)
            
            // Update model and version on the main actor to ensure thread safety for UI-bound properties
            await MainActor.run {
                self.currentModel = newModel
                self.currentModelVersion = version
                print("Model \(version) loaded successfully.")
            }
        } catch {
            print("Failed to load model from \(url.lastPathComponent): \(error.localizedDescription)")
            throw ModelLoadingError.failedToLoad(error.localizedDescription)
        }
    }
    
    // MARK: - Classification
    /// Classifies an article title using the currently loaded model.
    func classifyArticle(title: String) -> (label: String?, version: String) {
        guard !title.isEmpty else { return (nil, currentModelVersion) }
        guard let model = currentModel else { return ("Model not loaded.", currentModelVersion) }
        
        let predictedLabel = model.predictedLabel(for: title)
        return (predictedLabel, currentModelVersion)
    }
    
    // MARK: - Accessors
    func getCurrentModelVersion() -> String {
        return currentModelVersion
    }
    
    // MARK: - Custom Error for Model Loading
    enum ModelLoadingError: Error, LocalizedError {
        case failedToLoad(String)
        
        var errorDescription: String? {
            switch self {
            case .failedToLoad(let details):
                return "Failed to load machine learning model: \(details)"
            }
        }
    }
}

@available(iOS 18.0, *) // Conforming to the provided example's availability
class NewsFlowViewController: UIViewController, UITextViewDelegate {
    
    // MARK: - UI Elements
    @IBOutlet weak var articleTextView: UITextView!
    @IBOutlet weak var predictionLabel: UILabel!
    @IBOutlet weak var currentModelVersionLabel: UILabel!
    @IBOutlet weak var loadModelV1Button: UIButton!
    @IBOutlet weak var loadModelV2Button: UIButton!
    @IBOutlet weak var classifyButton: UIButton!
    
    // MARK: - Classifier Instance
    let classifier = NewsArticleClassifier()
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        updateModelVersionLabel()
    }
    
    // MARK: - UI Setup
    private func setupUI() {
        articleTextView.delegate = self
        articleTextView.layer.borderColor = UIColor.lightGray.cgColor
        articleTextView.layer.borderWidth = 1.0
        articleTextView.layer.cornerRadius = 5.0
        articleTextView.text = "Enter news article title or summary..."
        articleTextView.textColor = .lightGray
        
        predictionLabel.text = "Category: N/A"
        
        loadModelV1Button.setTitle("Load Model V1", for: .normal)
        loadModelV2Button.setTitle("Load Model V2", for: .normal)
        classifyButton.setTitle("Classify Article", for: .normal)
    }
    
    private func updateModelVersionLabel() {
        currentModelVersionLabel.text = "Active Model: \(classifier.getCurrentModelVersion())"
    }

    // MARK: - Actions
    @IBAction func loadModelV1Tapped(_ sender: UIButton) {
        loadModel(version: "V1", resourceName: "NewsClassifier_v1")
    }
    
    @IBAction func loadModelV2Tapped(_ sender: UIButton) {
        loadModel(version: "V2", resourceName: "NewsClassifier_v2")
    }
    
    private func loadModel(version: String, resourceName: String) {
        guard let url = Bundle.main.url(forResource: resourceName, withExtension: "mlmodelc") else {
            predictionLabel.text = "Error: \(resourceName).mlmodelc not found."
            predictionLabel.textColor = .systemRed
            print("Error: \(resourceName).mlmodelc not found in app bundle.")
            return
        }
        
        // Use a Task for async model loading to keep the UI responsive
        Task {
            do {
                predictionLabel.text = "Loading Model \(version)..."
                predictionLabel.textColor = .systemBlue
                
                try await classifier.loadModel(from: url, version: version)
                
                // Update UI on successful load
                predictionLabel.text = "Model \(version) loaded successfully."
                predictionLabel.textColor = .systemGreen
                updateModelVersionLabel()
                
            } catch {
                // Handle error in UI
                predictionLabel.text = "Failed to load Model \(version): \(error.localizedDescription)"
                predictionLabel.textColor = .systemRed
                updateModelVersionLabel() // Still show old version or "None"
            }
        }
    }
    
    @IBAction func classifyButtonTapped(_ sender: UIButton) {
        performArticleClassification()
    }
    
    private func performArticleClassification() {
        predictionLabel.textColor = .label // Reset color
        let articleText = articleTextView.text.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if articleText.isEmpty || articleText == "Enter news article title or summary..." {
            predictionLabel.text = "Category: Please enter article text."
            predictionLabel.textColor = .systemOrange
            return
        }
        
        let (label, version) = classifier.classifyArticle(title: articleText)
        
        if let category = label {
            predictionLabel.text = "Category (\(version)): \(category)"
        } else {
            predictionLabel.text = "Category (\(version)): Could not classify (Model not loaded or error)."
            predictionLabel.textColor = .systemGray
        }
    }
    
    // MARK: - UITextViewDelegate for Placeholder behavior
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == .lightGray {
            textView.text = nil
            textView.textColor = .label
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Enter news article title or summary..."
            textView.textColor = .lightGray
        }
    }
    
    // MARK: - Advanced Consideration (Discussion Point)
    /*
    How might you implement a versioning strategy or A/B testing framework if models were truly fetched from a remote server?

    1.  **Remote Configuration Service:** A backend service would provide the app with the URL to the latest model, or specific model versions for A/B testing groups. This could be a simple JSON endpoint.
    2.  **Model Caching & Storage:** Downloaded models would be saved to the app's `Documents` or `Library/Caches` directory. `NLModel(contentsOf:)` can load from any file URL.
    3.  **Versioning & Metadata:** The remote configuration would include model version numbers, release notes, and perhaps a hash for integrity checking. The `NewsArticleClassifier` could store this metadata alongside the `NLModel` instance.
    4.  **A/B Testing Integration:**
        *   **Client-side:** The app could randomly assign a user to an A/B test group, or use a persistent identifier.
        *   **Server-side:** The remote configuration service could determine the model version to serve based on user ID, device characteristics, or other criteria.
        *   **Analytics:** Track which model version is active for a user and collect classification results to compare performance metrics (e.g., accuracy, user engagement).
    5.  **Graceful Degradation:** If a remote model fails to download or load, the app should fall back to a bundled default model or indicate that the feature is unavailable.
    6.  **Background Updates:** Use `URLSession` background tasks to download new models without requiring the app to be active.
    7.  **User Consent:** For large model downloads, consider asking for user consent, especially over cellular data.
    */
}
