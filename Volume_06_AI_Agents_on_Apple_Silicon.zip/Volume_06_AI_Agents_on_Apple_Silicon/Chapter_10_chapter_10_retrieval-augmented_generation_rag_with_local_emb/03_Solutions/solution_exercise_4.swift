
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import SwiftData
import LlamaCpp
import AppKit // For NSPasteboard and potentially UI elements
import Combine // For reactive pasteboard monitoring

// Reusing KnowledgeChunk, EmbeddingService, LlamaCppEmbeddingService, TextChunker, AdvancedTextChunker,
// LLMService, LlamaCppLLMService, Array<Float> extensions, cosineSimilarity,
// KnowledgeIngestor, DocumentProcessor from previous exercises.

// MARK: - 1. Global Text Selection Monitoring

// More robust Pasteboard Monitor using Combine
class PasteboardMonitor: ObservableObject {
    @Published var selectedText: String = ""
    private var timer: Timer?
    private var lastChangeCount: Int = NSPasteboard.general.changeCount
    private var cancellables = Set<AnyCancellable>()

    func startMonitoring(interval: TimeInterval = 1.0) {
        // Invalidate any existing timer
        timer?.invalidate()
        cancellables.removeAll()

        // Use a timer to periodically check pasteboard for changes
        timer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            self?.checkForNewSelection()
        }
        RunLoop.current.add(timer!, forMode: .common) // Ensure timer runs even when UI is busy
        print("Pasteboard monitoring started.")
    }

    func stopMonitoring() {
        timer?.invalidate()
        timer = nil
        cancellables.removeAll()
        print("Pasteboard monitoring stopped.")
    }

    private func checkForNewSelection() {
        let pasteboard = NSPasteboard.general
        if pasteboard.changeCount != lastChangeCount {
            lastChangeCount = pasteboard.changeCount
            if let newText = pasteboard.string(forType: .string), !newText.isEmpty {
                // Only update if the text is different to avoid redundant processing
                if newText != selectedText {
                    print("Detected new selected text: \(newText.prefix(50))...")
                    DispatchQueue.main.async { // Ensure @Published update on main thread
                        self.selectedText = newText
                    }
                }
            }
        }
    }
}

// MARK: - 2. Pre-indexed Knowledge Base (Assumed from Exercise 1 & 3)

// MARK: - 3. Dynamic Query Generation & 4. Contextual Retrieval & LLM Processing

@available(macOS 15.0, *)
class ContextualRAGAssistant {
    private let modelContext: ModelContext
    private let embeddingService: EmbeddingService
    private let llmService: LLMService

    init(modelContext: ModelContext, embeddingService: EmbeddingService, llmService: LLMService) {
        self.modelContext = modelContext
        self.embeddingService = embeddingService
        self.llmService = llmService
    }

    func generateContextualSuggestion(selectedText: String, topK: Int = 3, maxContextTokens: Int = 512) async throws -> String {
        guard !selectedText.isEmpty else { return "No text selected for context." }
        print("Generating contextual suggestion for selected text: '\(selectedText.prefix(50))...'")

        // 1. Generate embedding for selected text (query)
        let queryEmbedding = try await embeddingService.generateEmbedding(for: selectedText)

        // 2. Retrieve relevant chunks from pre-indexed knowledge base
        let storedChunks = try modelContext.fetch(FetchDescriptor<KnowledgeChunk>())
        
        var rankedChunks: [(KnowledgeChunk, Float)] = []
        for chunk in storedChunks {
            guard let storedEmbedding = Array<Float>(data: chunk.embeddingData) else { continue }
            if let similarity = cosineSimilarity(vectorA: queryEmbedding, vectorB: storedEmbedding) {
                rankedChunks.append((chunk, similarity))
            }
        }
        
        let sortedChunks = rankedChunks.sorted { $0.1 > $1.1 }
        
        var contextText = ""
        var currentContextTokens = 0
        var retrievedChunkCount = 0

        for (chunk, _) in sortedChunks {
            if retrievedChunkCount >= topK { break }
            let chunkContent = chunk.content
            let estimatedTokens = chunkContent.count / 4
            
            if currentContextTokens + estimatedTokens <= maxContextTokens {
                contextText += (contextText.isEmpty ? "" : "\n\n") + chunkContent
                currentContextTokens += estimatedTokens
                retrievedChunkCount += 1
            } else {
                break
            }
        }

        print("Retrieved \(retrievedChunkCount) relevant chunks for contextual RAG.")

        // 3. Construct LLM prompt for summarization/suggestion
        let llmPrompt = """
        The user has selected the following text: "\(selectedText)".
        Based on the context provided below, provide a concise summary, explanation, or relevant suggestion related to the selected text.
        If the context does not provide relevant information, simply state "No relevant information found in your knowledge base."
        Be brief and to the point.

        Context:
        \(contextText)

        Suggestion:
        """

        // 4. Generate LLM response
        print("Sending contextual prompt to local LLM...")
        let llmResponse = try await llmService.generateResponse(prompt: llmPrompt)
        return llmResponse
    }
}

// MARK: - 5. Non-Intrusive Display & CLI Application Entry Point

@main
@available(macOS 15.0, *)
struct RAGAssistantApp {
    static let embeddingModelPath = "/path/to/your/embedding_model.gguf" // !!! REPLACE THIS !!!
    static let llmModelPath = "/path/to/your/llm_model.gguf" // !!! REPLACE THIS !!!

    static func main() async {
        // --- SwiftData Setup ---
        let schema = Schema([KnowledgeChunk.self])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredDynamically: true)
        guard let modelContainer = try? ModelContainer(for: schema, configurations: [modelConfiguration]) else {
            fatalError("Failed to create ModelContainer.")
        }
        let modelContext = ModelContext(modelContainer)

        // --- Embedding Service Setup ---
        guard let embeddingModelBundlePath = Bundle.main.path(forResource: "all-MiniLM-L6-v2-f16", ofType: "gguf") else {
            print("Error: Embedding model 'all-MiniLM-L6-v2-f16.gguf' not found in bundle.")
            print("Please download a .gguf embedding model and add it to your Xcode project's resources.")
            return
        }
        let embeddingService = LlamaCppEmbeddingService(modelPath: embeddingModelBundlePath)
        print("Attempting to load embedding model from: \(embeddingModelBundlePath)")
        do {
            try await embeddingService.loadModel()
            print("Embedding model loaded successfully.")
        } catch {
            print("Failed to load embedding model: \(error.localizedDescription)")
            return
        }

        // --- LLM Service Setup ---
        guard let llmModelBundlePath = Bundle.main.path(forResource: "tinyllama-1.1b-chat-v1.0.Q4_K_M", ofType: "gguf") else {
            print("Error: LLM model 'tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf' not found in bundle.")
            print("Please download a .gguf LLM model and add it to your Xcode project's resources.")
            return
        }
        let llmService = LlamaCppLLMService(modelPath: llmModelBundlePath)
        print("Attempting to load LLM model from: \(llmModelBundlePath)")
        do {
            try await llmService.loadModel()
            print("LLM model loaded successfully.")
        } catch {
            print("Failed to load LLM model: \(error.localizedDescription)")
            return
        }

        // --- RAG Assistant Setup ---
        let assistant = ContextualRAGAssistant(modelContext: modelContext, embeddingService: embeddingService, llmService: llmService)
        let pasteboardMonitor = PasteboardMonitor()

        // --- Monitor selected text and generate suggestions ---
        pasteboardMonitor.$selectedText
            .dropFirst() // Don't trigger on initial empty value
            .debounce(for: .seconds(0.5), scheduler: DispatchQueue.main) // Debounce to avoid rapid triggers
            .sink { newText in
                Task {
                    do {
                        let suggestion = try await assistant.generateContextualSuggestion(selectedText: newText)
                        // For CLI, we print. In a real app, this would be a popover/notification.
                        print("\n--- Contextual Suggestion ---")
                        print("Selected Text: '\(newText.prefix(50))...'")
                        print("Suggestion: \(suggestion)")
                        print("-----------------------------\n")
                    } catch {
                        print("Error generating suggestion: \(error.localizedDescription)")
                    }
                }
            }
            .store(in: &pasteboardMonitor.cancellables) // Store cancellable for Combine

        pasteboardMonitor.startMonitoring(interval: 1.0) // Check pasteboard every second

        print("\n--- Real-time Contextual RAG Assistant ---")
        print("Monitor is active. Select text in any application to get suggestions.")
        print("Type 'ingest' to add documents, 'list' to view, 'exit' to quit.")

        // --- CLI Loop for management (ingestion, listing) ---
        let chunker = AdvancedTextChunker()
        let documentProcessor = DocumentProcessor(modelContext: modelContext, embeddingService: embeddingService, chunker: chunker)

        while true {
            print("\nEnter command: ", terminator: "")
            guard let input = readLine() else { continue }
            let components = input.split(separator: " ", maxSplits: 1).map(String.init)
            let command = components.first?.lowercased() ?? ""
            let argument = components.count > 1 ? components[1] : ""

            switch command {
            case "ingest":
                if argument.isEmpty {
                    print("Usage: ingest <filepath>")
                    continue
                }
                let filePath = (argument as NSString).expandingTildeInPath
                let fileURL = URL(fileURLWithPath: filePath)
                do {
                    try await documentProcessor.ingestDocument(url: fileURL)
                    print("Document ingestion complete.")
                } catch {
                    print("Document ingestion failed: \(error.localizedDescription)")
                }
            case "list":
                do {
                    let chunks = try modelContext.fetch(FetchDescriptor<KnowledgeChunk>())
                    if chunks.isEmpty {
                        print("No knowledge chunks found.")
                    } else {
                        print("\n--- Stored Knowledge Chunks ---")
                        for (index, chunk) in chunks.enumerated() {
                            print("Chunk \(index + 1) (ID: \(chunk.id.uuidString.prefix(8))):")
                            print("  Document: \(chunk.documentIdentifier ?? "N/A")")
                            print("  Content: \(chunk.content.prefix(100))...")
                            print("--------------------")
                        }
                    }
                } catch {
                    print("Failed to fetch chunks: \(error.localizedDescription)")
                }
            case "exit":
                pasteboardMonitor.stopMonitoring()
                print("Exiting.")
                return
            default:
                print("Unknown command. Try 'ingest <filepath>', 'list', or 'exit'.")
            }
        }
    }
}
