
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// MARK: - Swift Package Manager Dependencies (No external dependencies for core functionality)
// For Apple's Natural Language and Speech frameworks, and SwiftData,
// no explicit 'Package.swift' entry is needed as they are built-in system frameworks.
// If you were to use third-party libraries, they would be declared here.

// package: SwiftDataVoiceJournalAI
// products:
//   - library: SwiftDataVoiceJournalAI
// targets:
//   - target: SwiftDataVoiceJournalAI
//     dependencies: [] // No external dependencies for this example.

// MARK: - 1. SwiftData Model Definition

import Foundation
import SwiftData // Required for SwiftData models

/// Represents a single journal entry, storing transcribed audio, sentiment, and extracted keywords.
///
/// This model uses SwiftData for persistent storage, allowing the application to save
/// and retrieve journal entries with their associated linguistic analysis.
@Model
@available(iOS 18.0, *) // SwiftData is available from iOS 17, but targeting iOS 18 for Swift 6 context.
final class JournalEntry {
    /// A unique identifier for the journal entry.
    let id: UUID
    /// The date and time the entry was created.
    let timestamp: Date
    /// The file path to the recorded audio for this entry.
    /// Storing a URL is generally preferred over raw Data for large audio files.
    let audioFilePath: URL?
    /// The full transcribed text of the audio entry.
    let transcription: String
    /// A numerical score representing the sentiment of the transcription.
    /// Typically ranges from -1 (negative) to 1 (positive).
    let sentimentScore: Double
    /// An array of keywords or named entities extracted from the transcription.
    let keywords: [String]

    /// Initializes a new `JournalEntry` with all its analytical data.
    /// - Parameters:
    ///   - id: The unique identifier for the entry. Defaults to a new UUID.
    ///   - timestamp: The creation date of the entry. Defaults to the current date.
    ///   - audioFilePath: The URL to the stored audio file, if available.
    ///   - transcription: The full text transcription of the audio.
    ///   - sentimentScore: The calculated sentiment score.
    ///   - keywords: An array of extracted keywords.
    init(id: UUID = UUID(), timestamp: Date = Date(), audioFilePath: URL?, transcription: String, sentimentScore: Double, keywords: [String]) {
        self.id = id
        self.timestamp = timestamp
        self.audioFilePath = audioFilePath
        self.transcription = transcription
        self.sentimentScore = sentimentScore
        self.keywords = keywords
    }
}

// MARK: - 2. Speech Recognition Service

import Speech // Required for SFSpeechRecognizer
import AVFoundation // Required for AVAudioEngine

/// Manages speech recognition, converting spoken audio into text.
///
/// This service handles audio session configuration, microphone input, and
/// streams audio to `SFSpeechRecognizer` for transcription. It requires
/// microphone and speech recognition permissions.
@available(iOS 18.0, *)
class SpeechRecognizerService: NSObject, SFSpeechRecognizerDelegate, ObservableObject {
    private let speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    /// Published property to provide the latest transcribed text.
    @Published var transcribedText: String = ""
    /// Published property to indicate if speech recognition is currently active.
    @Published var isRecording: Bool = false
    /// Published property to communicate errors.
    @Published var error: Error?

    /// Initializes the speech recognizer for the default locale.
    override init() {
        // Initialize with the default locale, or a specific one if needed.
        speechRecognizer = SFSpeechRecognizer()
        super.init()
        speechRecognizer?.delegate = self
        // Request authorization immediately upon service creation.
        requestAuthorization()
    }

    /// Requests authorization for speech recognition and microphone usage.
    ///
    /// This is an asynchronous operation and should be called before starting
    /// any recognition tasks.
    private func requestAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation {
                switch authStatus {
                case .authorized:
                    print("Speech recognition authorized.")
                case .denied:
                    self.error = SpeechRecognitionError.permissionDenied("User denied speech recognition authorization.")
                case .restricted:
                    self.error = SpeechRecognitionError.permissionRestricted("Speech recognition restricted on this device.")
                case .notDetermined:
                    self.error = SpeechRecognitionError.permissionNotDetermined("Speech recognition authorization not determined.")
                @unknown default:
                    self.error = SpeechRecognitionError.unknown("Unknown authorization status.")
                }
            }
        }
        AVAudioSession.sharedInstance().requestRecordPermission { granted in
            if !granted {
                OperationQueue.main.addOperation {
                    self.error = SpeechRecognitionError.microphoneDenied("User denied microphone access.")
                }
            }
        }
    }

    /// Starts the speech recognition process.
    /// - Throws: `SpeechRecognitionError` if setup fails or permissions are not granted.
    func startRecording() async throws {
        guard speechRecognizer?.isAvailable ?? false else {
            throw SpeechRecognitionError.unavailable("Speech recognizer is not available on this device.")
        }
        guard SFSpeechRecognizer.authorizationStatus() == .authorized else {
            throw SpeechRecognitionError.permissionDenied("Speech recognition not authorized.")
        }
        guard AVAudioSession.sharedInstance().recordPermission == .granted else {
            throw SpeechRecognitionError.microphoneDenied("Microphone access not granted.")
        }

        // Cancel the previous task if it's running.
        recognitionTask?.cancel()
        self.recognitionTask = nil
        self.transcribedText = ""
        self.error = nil

        let audioSession = AVAudioSession.sharedInstance()
        do {
            // Configure the audio session for recording.
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            throw SpeechRecognitionError.audioSessionSetupFailed("Failed to set up audio session: \(error.localizedDescription)")
        }

        // Create and configure the recognition request.
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            throw SpeechRecognitionError.requestCreationFailed("Unable to create SFSpeechAudioBufferRecognitionRequest object.")
        }
        recognitionRequest.shouldReportPartialResults = true // Get results as the user speaks.
        recognitionRequest.requiresOnDeviceRecognition = false // Prefer cloud for better accuracy, set to true for offline.

        // Start the recognition task.
        recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }
            var isFinal = false
            if let result = result {
                self.transcribedText = result.bestTranscription.formattedString
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                // If an error occurs or recognition is final, stop the audio engine.
                self.audioEngine.stop()
                self.audioEngine.inputNode.removeTap(onBus: 0)
                self.recognitionRequest = nil
                self.recognitionTask = nil
                self.isRecording = false
                if let error = error {
                    self.error = SpeechRecognitionError.recognitionFailed("Speech recognition failed: \(error.localizedDescription)")
                }
            }
        }

        // Configure the audio engine for microphone input.
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
            self.isRecording = true
            print("Audio engine started. Recording...")
        } catch {
            self.stopRecording() // Ensure cleanup if engine fails to start
            throw SpeechRecognitionError.audioEngineStartFailed("Audio engine couldn't start: \(error.localizedDescription)")
        }
    }

    /// Stops the speech recognition process.
    func stopRecording() {
        audioEngine.stop()
        recognitionRequest?.endAudio()
        recognitionTask?.cancel() // Cancel to ensure all resources are released
        recognitionTask = nil
        recognitionRequest = nil
        isRecording = false
        print("Audio engine stopped. Recording ended.")

        // Deactivate audio session
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
        }
    }

    // MARK: - SFSpeechRecognizerDelegate

    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if !available {
            self.error = SpeechRecognitionError.unavailable("Speech recognizer availability changed to unavailable.")
            stopRecording() // Stop if recognizer becomes unavailable mid-recording
        }
    }

    /// Custom error types for speech recognition.
    enum SpeechRecognitionError: LocalizedError {
        case permissionDenied(String)
        case permissionRestricted(String)
        case permissionNotDetermined(String)
        case microphoneDenied(String)
        case unavailable(String)
        case audioSessionSetupFailed(String)
        case requestCreationFailed(String)
        case audioEngineStartFailed(String)
        case recognitionFailed(String)
        case unknown(String)

        var errorDescription: String? {
            switch self {
            case .permissionDenied(let message), .permissionRestricted(let message),
                 .permissionNotDetermined(let message), .microphoneDenied(let message),
                 .unavailable(let message), .audioSessionSetupFailed(let message),
                 .requestCreationFailed(let message), .audioEngineStartFailed(let message),
                 .recognitionFailed(let message), .unknown(let message):
                return message
            }
        }
    }
}

// MARK: - 3. Natural Language Processing Service

import NaturalLanguage // Required for NLTagger

/// Provides natural language processing capabilities, including sentiment analysis
/// and keyword extraction, using Apple's Natural Language framework.
@available(iOS 18.0, *)
class NLProcessorService {

    /// Performs sentiment analysis on the given text.
    /// - Parameter text: The text to analyze.
    /// - Returns: A `Double` representing the sentiment score, typically between -1.0 (very negative) and 1.0 (very positive).
    ///            Returns 0.0 if sentiment cannot be determined.
    /// - Throws: `NLProcessorError` if the tagger fails to process the text.
    ///
    /// The sentiment tagger works by analyzing the emotional tone of the text.
    /// Under the hood, `NLTagger` uses a pre-trained Core ML model provided by Apple
    /// to classify the sentiment of the input text.
    func analyzeSentiment(for text: String) async throws -> Double {
        guard !text.isEmpty else { return 0.0 }

        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = text

        // Request sentiment score for the entire string.
        let (sentiment, _) = tagger.tag(at: text.startIndex, unit: .paragraph, scheme: .sentimentScore)

        guard let sentimentScoreString = sentiment?.rawValue,
              let score = Double(sentimentScoreString) else {
            throw NLProcessorError.sentimentAnalysisFailed("Could not determine sentiment for text: '\(text)'")
        }
        return score
    }

    /// Extracts keywords (named entities) from the given text.
    /// - Parameter text: The text from which to extract keywords.
    /// - Returns: An array of `String` representing the extracted keywords.
    /// - Throws: `NLProcessorError` if the tagger fails to process the text.
    ///
    /// This method uses `NLTagger` with the `.namedEntity` tag scheme to identify
    /// persons, places, and organizations within the text. These are commonly
    /// considered good candidates for keywords.
    func extractKeywords(from text: String) async throws -> [String] {
        guard !text.isEmpty else { return [] }

        let tagger = NLTagger(tagSchemes: [.nameType])
        tagger.string = text

        var keywords: [String] = []
        // Iterate over the text to find named entities.
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .nameType, options: .omitWhitespace) { tag, tokenRange in
            if let tag = tag, tag == .personalName || tag == .placeName || tag == .organizationName {
                keywords.append(String(text[tokenRange]))
            }
            return true // Continue enumeration
        }
        return Array(Set(keywords)) // Return unique keywords
    }

    /// Custom error types for Natural Language Processing.
    enum NLProcessorError: LocalizedError {
        case sentimentAnalysisFailed(String)
        case keywordExtractionFailed(String)
        case textIsEmpty

        var errorDescription: String? {
            switch self {
            case .sentimentAnalysisFailed(let message), .keywordExtractionFailed(let message):
                return message
            case .textIsEmpty:
                return "Input text for NLP is empty."
            }
        }
    }
}

// MARK: - 4. Voice Journal Management Service (Integration with SwiftData)

import SwiftData // Required for ModelContext
import Combine // For observing SpeechRecognizerService

/// Manages the full lifecycle of a voice journal entry:
/// recording, transcribing, analyzing, and persisting to SwiftData.
@available(iOS 18.0, *)
class VoiceJournalService: ObservableObject {
    /// The SwiftData model context for persistence operations.
    private let modelContext: ModelContext
    /// The service responsible for speech-to-text conversion.
    private let speechRecognizerService: SpeechRecognizerService
    /// The service responsible for natural language processing.
    private let nlProcessorService: NLProcessorService

    private var cancellables = Set<AnyCancellable>()

    /// Published property to provide a list of all journal entries.
    @Published var journalEntries: [JournalEntry] = []
    /// Published property to indicate if an operation is in progress.
    @Published var isLoading: Bool = false
    /// Published property to communicate errors from this service.
    @Published var serviceError: Error?

    /// Initializes the `VoiceJournalService`.
    /// - Parameter modelContext: The SwiftData `ModelContext` to use for persistence.
    ///
    /// This initializer sets up the necessary services and fetches existing data.
    init(modelContext: ModelContext) {
        self.modelContext = modelContext
        self.speechRecognizerService = SpeechRecognizerService()
        self.nlProcessorService = NLProcessorService()
        
        // Observe errors from the speech recognizer and propagate them.
        speechRecognizerService.$error
            .compactMap { $0 } // Only pass non-nil errors
            .sink { [weak self] error in
                self?.serviceError = error
                self?.isLoading = false // Ensure loading state is reset on error
            }
            .store(in: &cancellables)

        // Fetch initial data when the service is created.
        Task { await fetchJournalEntries() }
    }

    /// Starts the recording process via `SpeechRecognizerService`.
    func startRecording() {
        isLoading = true
        serviceError = nil
        Task {
            do {
                try await speechRecognizerService.startRecording()
            } catch {
                serviceError = error
                isLoading = false
            }
        }
    }

    /// Stops the recording process and triggers transcription, NLP, and persistence.
    /// - Returns: The newly created `JournalEntry` if successful, otherwise `nil`.
    func stopRecording() async -> JournalEntry? {
        speechRecognizerService.stopRecording()
        isLoading = false // Reset loading here, as transcription is now 'final'
        
        let transcription = speechRecognizerService.transcribedText
        guard !transcription.isEmpty else {
            serviceError = NLProcessorService.NLProcessorError.textIsEmpty
            return nil
        }

        do {
            isLoading = true
            // Perform NLP analysis asynchronously.
            let sentiment = try await nlProcessorService.analyzeSentiment(for: transcription)
            let keywords = try await nlProcessorService.extractKeywords(from: transcription)

            // Create and save the new journal entry using SwiftData.
            let newEntry = JournalEntry(audioFilePath: nil, // For simplicity, we're not saving actual audio files in this example
                                        transcription: transcription,
                                        sentimentScore: sentiment,
                                        keywords: keywords)
            modelContext.insert(newEntry)
            try modelContext.save() // Explicitly save changes.
            
            // Add to our published array for UI updates.
            await MainActor.run {
                journalEntries.insert(newEntry, at: 0) // Add to the beginning for most recent.
                isLoading = false
            }
            print("Successfully saved new journal entry: \(newEntry.transcription)")
            return newEntry

        } catch {
            await MainActor.run {
                serviceError = error
                isLoading = false
            }
            print("Failed to save journal entry: \(error.localizedDescription)")
            return nil
        }
    }

    /// Fetches all existing journal entries from SwiftData.
    @MainActor
    func fetchJournalEntries() async {
        isLoading = true
        serviceError = nil
        do {
            let descriptor = FetchDescriptor<JournalEntry>(sortBy: [SortDescriptor(\.timestamp, order: .reverse)])
            journalEntries = try modelContext.fetch(descriptor)
            isLoading = false
        } catch {
            serviceError = error
            isLoading = false
            print("Failed to fetch journal entries: \(error.localizedDescription)")
        }
    }

    /// Deletes a specific journal entry from SwiftData.
    /// - Parameter entry: The `JournalEntry` to delete.
    @MainActor
    func deleteJournalEntry(_ entry: JournalEntry) {
        do {
            modelContext.delete(entry)
            try modelContext.save()
            journalEntries.removeAll { $0.id == entry.id } // Update local array.
        } catch {
            serviceError = error
            print("Failed to delete journal entry: \(error.localizedDescription)")
        }
    }
}

// MARK: - 5. Conceptual Application Integration (SwiftUI View)

import SwiftUI // Required for SwiftUI views and App lifecycle

/// A conceptual SwiftUI view demonstrating how the VoiceJournalService would be used.
///
/// This view would typically be part of a larger SwiftUI application. It shows
/// how to inject `ModelContext` and interact with the `VoiceJournalService`
/// to record, process, and display journal entries.
@available(iOS 18.0, *)
struct ContentView: View {
    // Access the SwiftData model context provided by the environment.
    @Environment(\.modelContext) private var modelContext

    // State object for the VoiceJournalService, initialized with the model context.
    // This allows the view to observe changes in the service.
    @StateObject private var voiceJournalService: VoiceJournalService

    // State to manage the recording button's appearance.
    @State private var isRecording: Bool = false
    // State to show alerts for errors.
    @State private var showingErrorAlert: Bool = false

    /// Custom initializer to inject `ModelContext` into the `StateObject`.
    /// This is a common pattern for services that depend on environment objects.
    init(modelContext: ModelContext) {
        _voiceJournalService = StateObject(wrappedValue: VoiceJournalService(modelContext: modelContext))
    }

    var body: some View {
        NavigationView {
            VStack {
                // Display current transcription from the speech recognizer service.
                Text(voiceJournalService.speechRecognizerService.transcribedText.isEmpty ?
                     "Tap to record your journal entry..." :
                     voiceJournalService.speechRecognizerService.transcribedText)
                    .font(.title2)
                    .padding()
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity, minHeight: 100)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(10)
                    .padding(.horizontal)

                // Recording button.
                Button {
                    Task {
                        if voiceJournalService.speechRecognizerService.isRecording {
                            // Stop recording and process the entry.
                            await voiceJournalService.stopRecording()
                            isRecording = false
                        } else {
                            // Start recording.
                            voiceJournalService.startRecording()
                            isRecording = true
                        }
                    }
                } label: {
                    Image(systemName: isRecording ? "mic.fill" : "mic.circle")
                        .font(.largeTitle)
                        .padding()
                        .background(isRecording ? Color.red : Color.blue)
                        .foregroundColor(.white)
                        .clipShape(Circle())
                }
                .padding(.vertical)
                .disabled(voiceJournalService.isLoading) // Disable button during processing

                // Progress indicator when loading or processing.
                if voiceJournalService.isLoading {
                    ProgressView("Processing entry...")
                        .padding()
                }

                Divider()

                // List of journal entries.
                List {
                    ForEach(voiceJournalService.journalEntries) { entry in
                        VStack(alignment: .leading) {
                            Text(entry.timestamp, format: .dateTime)
                                .font(.caption)
                                .foregroundColor(.gray)
                            Text(entry.transcription)
                                .font(.body)
                                .lineLimit(2)
                            HStack {
                                Text("Sentiment: \(String(format: "%.2f", entry.sentimentScore))")
                                    .font(.footnote)
                                    .foregroundColor(entry.sentimentScore > 0.1 ? .green : (entry.sentimentScore < -0.1 ? .red : .orange))
                                Spacer()
                                ForEach(entry.keywords, id: \.self) { keyword in
                                    Text("#\(keyword)")
                                        .font(.caption2)
                                        .padding(.horizontal, 6)
                                        .padding(.vertical, 3)
                                        .background(Capsule().fill(Color.blue.opacity(0.2)))
                                }
                            }
                        }
                    }
                    .onDelete(perform: deleteEntries)
                }
                .navigationTitle("Voice Journal AI")
                .alert("Error", isPresented: $showingErrorAlert, presenting: voiceJournalService.serviceError) { _ in
                    Button("OK") { }
                } message: { error in
                    Text(error.localizedDescription)
                }
                .onChange(of: voiceJournalService.serviceError) { oldError, newError in
                    if newError != nil {
                        showingErrorAlert = true
                    }
                }
                .onAppear {
                    // Ensure permissions are requested when the view appears.
                    // The SpeechRecognizerService already requests on init, but good to ensure.
                    // In a real app, you might have a dedicated onboarding for permissions.
                }
            }
        }
    }

    /// Helper function for deleting entries from the list.
    private func deleteEntries(at offsets: IndexSet) {
        for index in offsets {
            let entry = voiceJournalService.journalEntries[index]
            voiceJournalService.deleteJournalEntry(entry)
        }
    }
}

/// The main App structure for the SwiftUI application.
@available(iOS 18.0, *)
@main
struct VoiceJournalAIApp: App {
    /// Configures the SwiftData model container for `JournalEntry`.
    /// This makes the `ModelContext` available in the environment.
    let modelContainer: ModelContainer

    init() {
        do {
            modelContainer = try ModelContainer(for: JournalEntry.self)
        } catch {
            fatalError("Failed to create ModelContainer for JournalEntry: \(error.localizedDescription)")
        }
    }

    var body: some Scene {
        WindowGroup {
            // Inject the modelContext into the ContentView.
            ContentView(modelContext: modelContainer.mainContext)
        }
        .modelContainer(modelContainer) // Provide the model container to the entire app.
    }
}
