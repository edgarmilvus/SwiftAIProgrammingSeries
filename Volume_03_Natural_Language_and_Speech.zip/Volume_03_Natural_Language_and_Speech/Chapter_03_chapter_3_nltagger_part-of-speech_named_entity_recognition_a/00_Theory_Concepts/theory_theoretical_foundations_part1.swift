
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor TextProcessor {
    // NLTagger instances can be stateful (e.g., if you set a specific string or options)
    // but the core tagging operation itself is usually stateless and can be called concurrently.
    // For simplicity, we'll create one per operation in this example,
    // but in a real app, you might cache or reuse taggers for performance.

    func analyzeText(_ text: String, schemes: [NLTagScheme]) async throws -> [String: [String]] {
        return try await withCheckedThrowingContinuation { continuation in
            let tagger = NLTagger(tagSchemes: schemes)
            tagger.string = text
            
            var results: [String: [String]] = [:]
            
            // Perform PoS tagging
            if schemes.contains(.lexicalClass) {
                var posTags: [String] = []
                tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lexicalClass, options: .omitWhitespace) { tag, tokenRange in
                    if let tag = tag {
                        posTags.append("\(text[tokenRange]): \(tag.rawValue)")
                    }
                    return true
                }
                results["PoS Tags"] = posTags
            }
            
            // Perform NER
            if schemes.contains(.nameType) {
                var namedEntities: [String] = []
                tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .nameType, options: .joinNames) { tag, tokenRange in
                    if let tag = tag, tag != .other { // .other means not a named entity
                        namedEntities.append("\(text[tokenRange]): \(tag.rawValue)")
                    }
                    return true
                }
                results["Named Entities"] = namedEntities
            }
            
            // Perform Lemmatization
            if schemes.contains(.lemma) {
                var lemmas: [String] = []
                tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lemma, options: .omitWhitespace) { tag, tokenRange in
                    if let tag = tag {
                        lemmas.append("\(text[tokenRange]): \(tag.rawValue)")
                    }
                    return true
                }
                results["Lemmas"] = lemmas
            }
            
            continuation.resume(returning: results)
        }
    }
}

@available(iOS 18.0, *)
extension ContentView { // Assuming a SwiftUI View
    @MainActor
    func processButtonTapped() async {
        let processor = TextProcessor()
        let inputText = "Apple Inc. announced its new iPhone 16 in Cupertino, California on September 10, 2024, and the company's stock rose significantly."
        
        do {
            // Offload the potentially long-running NLP task to the actor
            let analysisResult = try await processor.analyzeText(inputText, schemes: [.lexicalClass, .nameType, .lemma])
            print("Analysis complete: \(analysisResult)")
            // Update UI with results
        } catch {
            print("Error during text analysis: \(error)")
        }
    }
}
