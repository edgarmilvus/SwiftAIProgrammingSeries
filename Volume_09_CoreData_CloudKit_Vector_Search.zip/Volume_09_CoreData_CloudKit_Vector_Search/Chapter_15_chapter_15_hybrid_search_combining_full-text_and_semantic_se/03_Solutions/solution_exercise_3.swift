
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

struct SearchResult: Sendable {
    let id: UUID
    let rank: Int // 1-based index
}

enum RRFError: Error {
    case emptyInput
}

actor RRFMerger {
    private let k: Double = 60.0
    
    /// Merges two ranked lists into a single list of results with RRF scores.
    func merge(listA: [SearchResult], listB: [SearchResult]) throws -> [(id: UUID, rrfScore: Double)] {
        guard !listA.isEmpty || !listB.isEmpty else {
            throw RRFError.emptyInput
        }
        
        // Dictionary to aggregate scores: [ID: AccumulatedRRFScore]
        // This allows O(1) lookup, keeping total complexity O(n)
        var scores: [UUID: Double] = [:]
        
        // Process first list
        for result in listA {
            let score = 1.0 / (k + Double(result.rank))
            scores[result.id, default: 0.0] += score
        }
        
        // Process second list
        for result in listB {
            let score = 1.0 / (k + Double(result.rank))
            scores[result.id, default: 0.0] += score
        }
        
        // Convert dictionary to sorted array
        return scores.map { (id: $0.key, rrfScore: $0.value) }
            .sorted { $0.rrfScore > $1.rrfScore }
    }
    
    /// Simulates fetching lists from two different engines concurrently.
    func performConcurrentMerge() async throws -> [(id: UUID, rrfScore: Double)] {
        try await withThrowingTaskGroup(of: [SearchResult].self) { group in
            // Task 1: Mock SQL Engine
            group.addTask {
                try await Task.sleep(nanoseconds: 100_000_000) // 100ms
                return [
                    SearchResult(id: UUID(), rank: 1),
                    SearchResult(id: UUID(), rank: 2),
                    SearchResult(id: UUID(), rank: 3)
                ]
            }
            
            // Task 2: Mock Vector Engine
            group.addTask {
                try await Task.sleep(nanoseconds: 150_000_000) // 150ms
                return [
                    SearchResult(id: UUID(), rank: 1), // A different UUID
                    SearchResult(id: UUID(), rank: 2)
                ]
            }
            
            var allLists: [[SearchResult]] = []
            for try await list in group {
                allLists.append(list)
            }
            
            // In a real scenario, we'd handle the case where group returns < 2 lists
            return try self.merge(listA: allLists[0], listB: allLists[1])
        }
    }
}

// MARK: - Example Usage
@main
struct RRFApp {
    static func main() async {
        let merger = RRFMerger()
        do {
            let finalResults = try await merger.performConcurrentMerge()
            print("Merged RRF Results:")
            for res in finalResults {
                print("ID: \(res.id), Score: \(res.rrfScore)")
            }
        } catch {
            print("Error: \(error)")
        }
    }
}
