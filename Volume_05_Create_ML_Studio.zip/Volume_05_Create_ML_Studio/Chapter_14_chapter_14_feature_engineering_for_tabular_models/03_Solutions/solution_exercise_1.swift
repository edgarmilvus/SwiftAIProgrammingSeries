
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import CreateML

@available(macOS 14.0, iOS 18.0, *)
struct ProductListing: Codable {
    let productID: String
    let category: String
    let priceUSD: Double
    let weightKG: Double
    let material: String
    let listingDate: Date // Assuming ISO 8601 format in CSV
    let descriptionLength: Int
    let hasImages: Bool
    let isFeatured: Bool
    let likelihoodOfSale: String
}

@available(macOS 14.0, iOS 18.0, *)
func prepareProductData(csvURL: URL) throws -> MLDataTable {
    // 1. Data Loading and Initial MLDataTable Creation
    // For demonstration, we'll create a dummy MLDataTable.
    // In a real scenario, you'd use MLDataTable(contentsOf: csvURL, options: ...)
    // For Date parsing, MLDataTable.ReadingOptions can specify a dateDecodingStrategy.
    // The prompt assumes ISO 8601, which Create ML can handle.
    
    // Simulating CSV content for demonstration purposes
    let productData: [String: MLDataColumn] = [
        "productID": .init(array: ["P001", "P002", "P003", "P004", "P005"]),
        "category": .init(array: ["Electronics", "Home Goods", "Apparel", "Electronics", "Home Goods"]),
        "priceUSD": .init(array: [120.50, 25.00, 75.99, 1500.00, 49.99]),
        "weightKG": .init(array: [1.2, 0.5, 0.3, 5.8, 1.1]),
        "material": .init(array: ["Plastic", "Wood", "Fabric", "Metal", "Plastic"]),
        "listingDate": .init(array: [
            ISO8601DateFormatter().date(from: "2023-10-26T14:30:00Z")!,
            ISO8601DateFormatter().date(from: "2023-10-27T09:00:00Z")!,
            ISO8601DateFormatter().date(from: "2023-10-28T18:15:00Z")!,
            ISO8601DateFormatter().date(from: "2023-10-29T11:45:00Z")!,
            ISO8601DateFormatter().date(from: "2023-10-30T07:30:00Z")!
        ]),
        "descriptionLength": .init(array: [150, 30, 80, 500, 120]),
        "hasImages": .init(array: [true, false, true, true, false]),
        "isFeatured": .init(array: [false, false, true, true, false]),
        "likelihoodOfSale": .init(array: ["Medium", "Low", "High", "High", "Medium"])
    ]
    var dataTable = MLDataTable(dictionary: productData)

    // 2. Categorical Feature Encoding
    // Create ML automatically handles String columns as categorical features (e.g., via one-hot encoding
    // or embedding-like representations depending on the model type) when training a classifier.
    // No explicit encoding code is needed for `category` and `material`.
    // Boolean columns (`hasImages`, `isFeatured`) are also handled directly by Create ML.
    // They are typically treated as binary (0 or 1) numerical features.

    // 3. Numerical Feature Scaling
    // Apply min-max scaling (or similar normalization) to priceUSD and weightKG.
    // descriptionLength is also a numerical feature and can benefit from scaling.
    dataTable["priceUSD_scaled"] = dataTable["priceUSD"].normalized()
    dataTable["weightKG_scaled"] = dataTable["weightKG"].normalized()
    dataTable["descriptionLength_scaled"] = dataTable["descriptionLength"].normalized()

    // 4. Date and Time Feature Extraction
    // Extract dayOfWeek, month, year, hourOfDay from listingDate.
    let calendar = Calendar.current
    dataTable["dayOfWeek"] = dataTable["listingDate"].map { (date: Date) -> Int in
        calendar.component(.weekday, from: date) // 1 for Sunday, 2 for Monday, etc.
    }
    dataTable["month"] = dataTable["listingDate"].map { (date: Date) -> Int in
        calendar.component(.month, from: date)
    }
    dataTable["year"] = dataTable["listingDate"].map { (date: Date) -> Int in
        calendar.component(.year, from: date)
    }
    dataTable["hourOfDay"] = dataTable["listingDate"].map { (date: Date) -> Int in
        calendar.component(.hour, from: date)
    }

    // 5. Final MLDataTable for Training
    // Select the engineered features and the target column.
    // Exclude 'productID' (identifier), and the original 'priceUSD', 'weightKG',
    // 'descriptionLength', 'listingDate' which have been replaced by engineered versions.
    let finalColumns = [
        "category",
        "material",
        "hasImages",
        "isFeatured",
        "priceUSD_scaled",
        "weightKG_scaled",
        "descriptionLength_scaled",
        "dayOfWeek",
        "month",
        "year",
        "hourOfDay",
        "likelihoodOfSale" // Target variable
    ]
    dataTable = dataTable[finalColumns]

    return dataTable
}

// Example usage (conceptual, as we mocked the CSV loading):
// if let csvURL = Bundle.main.url(forResource: "products", withExtension: "csv") {
//     do {
//         let preparedTable = try prepareProductData(csvURL: csvURL)
//         print("Prepared Product Data Table:\n\(preparedTable.description)")
//         // Now preparedTable can be used for MLClassifier training
//         // let classifier = try MLClassifier(trainingData: preparedTable, targetColumn: "likelihoodOfSale")
//     } catch {
//         print("Error preparing data: \(error)")
//     }
// }

// To run the example:
if #available(macOS 14.0, iOS 18.0, *) {
    do {
        // Pass a dummy URL, as the data is hardcoded for demonstration
        let dummyURL = URL(fileURLWithDataRepresentation: Data(), relativeTo: nil)
        let preparedTable = try prepareProductData(csvURL: dummyURL)
        print("Prepared Product Data Table:\n\(preparedTable.description)")
    } catch {
        print("Error preparing data: \(error)")
    }
} else {
    print("CreateML features require macOS 14.0 / iOS 18.0 or later.")
}
