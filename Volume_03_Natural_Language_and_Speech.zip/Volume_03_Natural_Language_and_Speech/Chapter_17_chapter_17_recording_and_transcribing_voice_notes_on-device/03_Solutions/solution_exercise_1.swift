
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import AVFoundation
import Speech

// MARK: - LiveVoiceNoteRecorderViewController

@MainActor
class LiveVoiceNoteRecorderViewController: UIViewController, SFSpeechRecognizerDelegate {

    // MARK: - UI Elements
    private let startButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Recording", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .systemGreen
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let stopButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Stop Recording", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .systemRed
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isEnabled = false // Disabled initially
        return button
    }()

    private let transcriptionTextView: UITextView = {
        let textView = UITextView()
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.isEditable = false
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1
        textView.layer.cornerRadius = 8
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "Tap 'Start Recording' to begin..."
        return textView
    }()

    private let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Ready"
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 16)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - Speech Recognition Properties
    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    // MARK: - Audio Recording Properties
    private var audioFile: AVAudioFile?
    private var audioFileURL: URL?

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupSpeechRecognizer()
        requestPermissions()
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground

        let stackView = UIStackView(arrangedSubviews: [startButton, stopButton])
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(statusLabel)
        view.addSubview(stackView)
        view.addSubview(transcriptionTextView)

        NSLayoutConstraint.activate([
            statusLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 30),

            stackView.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            stackView.heightAnchor.constraint(equalToConstant: 50),

            transcriptionTextView.topAnchor.constraint(equalTo: stackView.bottomAnchor, constant: 20),
            transcriptionTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            transcriptionTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            transcriptionTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])

        startButton.addTarget(self, action: #selector(startRecordingTapped), for: .touchUpInside)
        stopButton.addTarget(self, action: #selector(stopRecordingTapped), for: .touchUpInside)
    }

    // MARK: - Speech Recognition Setup
    private func setupSpeechRecognizer() {
        speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        speechRecognizer?.delegate = self
    }

    // MARK: - Permissions Handling
    private func requestPermissions() {
        Task {
            // Request Microphone Permission
            let audioSession = AVAudioSession.sharedInstance()
            do {
                if audioSession.recordPermission != .granted {
                    await audioSession.requestRecordPermission()
                }
            } catch {
                print("Failed to request audio session permission: \(error)")
                self.showPermissionAlert(message: "Microphone access is required for recording.")
                return
            }

            // Request Speech Recognition Permission
            guard let speechRecognizer = speechRecognizer else {
                self.statusLabel.text = "Speech recognizer not available."
                return
            }

            if speechRecognizer.authorizationStatus != .authorized {
                let status = await SFSpeechRecognizer.requestAuthorization()
                if status != .authorized {
                    self.showPermissionAlert(message: "Speech recognition access is required for transcription.")
                }
            }
            updateUIForPermissions()
        }
    }

    private func updateUIForPermissions() {
        let audioSession = AVAudioSession.sharedInstance()
        let speechAuthStatus = SFSpeechRecognizer.authorizationStatus()

        if audioSession.recordPermission == .granted && speechAuthStatus == .authorized {
            startButton.isEnabled = true
            statusLabel.text = "Ready to record."
        } else {
            startButton.isEnabled = false
            statusLabel.text = "Permissions denied. Check settings."
        }
    }

    private func showPermissionAlert(message: String) {
        let alert = UIAlertController(title: "Permission Required", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Settings", style: .default) { _ in
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url)
            }
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    // MARK: - Recording Actions
    @objc private func startRecordingTapped() {
        Task {
            await startRecording()
        }
    }

    @objc private func stopRecordingTapped() {
        Task {
            await stopRecording()
        }
    }

    // MARK: - Core Recording and Transcription Logic
    private func startRecording() async {
        // Stop any existing task
        if let recognitionTask = recognitionTask {
            recognitionTask.cancel()
            self.recognitionTask = nil
        }

        // Configure Audio Session
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            print("Failed to set up audio session: \(error)")
            statusLabel.text = "Audio session error: \(error.localizedDescription)"
            return
        }

        // Prepare for Speech Recognition
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        recognitionRequest?.shouldReportPartialResults = true // Enable live streaming results

        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create a SFSpeechAudioBufferRecognitionRequest object")
        }
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            statusLabel.text = "Speech recognizer is not available for this locale."
            return
        }

        // Create temporary file for audio recording
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        audioFileURL = documentsPath.appendingPathComponent(UUID().uuidString).appendingPathExtension("caf")

        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)

        do {
            audioFile = try AVAudioFile(forWriting: audioFileURL!, settings: recordingFormat.settings)
        } catch {
            print("Could not create audio file: \(error)")
            statusLabel.text = "Error creating audio file: \(error.localizedDescription)"
            return
        }

        // Install audio tap on input node
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { [weak self] buffer, _ in
            self?.recognitionRequest?.append(buffer) // Feed buffers to speech recognizer
            do {
                try self?.audioFile?.write(from: buffer) // Write buffers to audio file
            } catch {
                print("Error writing audio buffer to file: \(error)")
            }
        }

        // Start the audio engine
        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            print("Failed to start audio engine: \(error)")
            statusLabel.text = "Audio engine error: \(error.localizedDescription)"
            return
        }

        // Start the recognition task
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            var isFinal = false

            if let result = result {
                self.transcriptionTextView.text = result.bestTranscription.formattedString
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                // Stop audio engine and recognition if error or final result
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                self.recognitionRequest = nil
                self.recognitionTask = nil
                self.audioFile = nil // Close the audio file
                
                if let error = error {
                    print("Recognition error: \(error)")
                    self.statusLabel.text = "Transcription error: \(error.localizedDescription)"
                } else if isFinal {
                    self.statusLabel.text = "Recording finished. Final transcription saved."
                    print("Final Transcription: \(self.transcriptionTextView.text ?? "")")
                    if let audioURL = self.audioFileURL {
                        print("Audio saved to: \(audioURL.lastPathComponent)")
                        // In a real app, you'd save this URL and transcription persistently
                    }
                }
                self.updateUIForRecordingState(isRecording: false)
            }
        }

        transcriptionTextView.text = "Recording..."
        statusLabel.text = "Recording started..."
        updateUIForRecordingState(isRecording: true)
    }

    private func stopRecording() async {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0) // Important to remove tap
        recognitionRequest?.endAudio() // Signal the end of audio for the request
        recognitionTask?.finish() // Explicitly finish the task
        
        // Ensure audio file is closed and resources are released
        audioFile = nil
        recognitionRequest = nil
        recognitionTask = nil

        // Deactivate audio session
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error)")
        }

        statusLabel.text = "Recording stopped. Processing final transcription..."
        updateUIForRecordingState(isRecording: false)
    }

    private func updateUIForRecordingState(isRecording: Bool) {
        startButton.isEnabled = !isRecording
        stopButton.isEnabled = isRecording
        startButton.backgroundColor = isRecording ? .gray : .systemGreen
        stopButton.backgroundColor = isRecording ? .systemRed : .gray
    }

    // MARK: - SFSpeechRecognizerDelegate
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            startButton.isEnabled = true
            statusLabel.text = "Ready to record."
        } else {
            startButton.isEnabled = false
            statusLabel.text = "Speech recognition currently unavailable."
        }
    }
}
