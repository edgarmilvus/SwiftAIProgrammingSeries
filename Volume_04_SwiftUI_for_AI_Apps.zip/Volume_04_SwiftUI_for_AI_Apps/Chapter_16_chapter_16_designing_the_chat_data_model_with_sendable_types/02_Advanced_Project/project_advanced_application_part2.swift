
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation // Provides UUID, Date, Error types

// MARK: - 1. Sendable Data Models for Chat Messages and AI Tokens

/// Represents the role of a participant in the chat.
/// Conforms to `Sendable` because it's an enum with associated values that are also `Sendable` (or none).
@available(iOS 18.0, *)
public enum ChatMessageType: Sendable, Identifiable, Equatable {
    public var id: String {
        switch self {
        case .user: return "user"
        case .ai(let model): return "ai_\(model)"
        }
    }

    case user
    case ai(model: String) // e.g., "GPT-4o", "Claude 3.5 Sonnet"
}

/// Represents a single token streamed from an AI model.
/// Conforms to `Sendable` because it contains only `String` which is `Sendable`.
@available(iOS 18.0, *)
public struct AIToken: Sendable, Identifiable, Equatable {
    public let id = UUID()
    public let content: String
    public let isFinal: Bool // Indicates if this is the last token in the stream

    public init(content: String, isFinal: Bool = false) {
        self.content = content
        self.isFinal = isFinal
    }
}

/// Represents a complete chat message, either from a user or an AI.
/// Conforms to `Sendable` because all its properties (`UUID`, `ChatMessageType`, `String`, `Date`) are `Sendable`.
@available(iOS 18.0, *)
public struct ChatMessage: Sendable, Identifiable, Equatable {
    public let id: UUID
    public let type: ChatMessageType
    public var content: String
    public let timestamp: Date

    public init(id: UUID = UUID(), type: ChatMessageType, content: String, timestamp: Date = Date()) {
        self.id = id
        self.type = type
        self.content = content
        self.timestamp = timestamp
    }

    /// Appends content to an existing message, typically used for AI streaming.
    public mutating func appendContent(_ newContent: String) {
        self.content += newContent
    }
}

// MARK: - 2. Error Handling for AI Model Interactions

/// Custom error types for AI model interactions.
/// Conforms to `Sendable` because `Error` protocol conformance implies `Sendable` for most Swift errors.
@available(iOS 18.0, *)
public enum AIModelServiceError: Error, Sendable, Equatable {
    case inferenceFailed(reason: String)
    case networkError(underlyingError: String)
    case invalidResponse(details: String)
    case streamInterrupted
}

// MARK: - 3. AI Model Service (Simulated)

/// A simulated AI model service that generates token streams.
/// This class simulates network delays and potential errors.
@available(iOS 18.0, *)
public class AIModelService: @unchecked Sendable { // @unchecked Sendable as it's a class with internal mutable state (though not directly exposed)
                                                  // For production, ensure all internal state is protected (e.g., with actors or locks)
                                                  // or make it an actor if it manages shared resources.
                                                  // Here, it's stateless per request, so @unchecked Sendable is acceptable for simulation.
    private let modelName: String

    public init(modelName: String) {
        self.modelName = modelName
    }

    /// Simulates streaming an AI response token by token.
    /// - Parameter prompt: The user's input prompt.
    /// - Returns: An `AsyncThrowingStream` of `AIToken`s.
    public func streamResponse(for prompt: String) -> AsyncThrowingStream<AIToken, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                let responseText = "Hello! I am \(self.modelName), your smart assistant. How can I help you today? I can answer questions, write stories, or provide information."
                let words = responseText.split(separator: " ").map { String($0) + " " }
                let errorTriggerWord = "stories" // Simulate an error after this word

                for (index, word) in words.enumerated() {
                    // Simulate network delay
                    try? await Task.sleep(nanoseconds: UInt64.random(in: 50_000_000...200_000_000)) // 50-200ms

                    if word.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == errorTriggerWord {
                        print("Simulating error after '\(errorTriggerWord)'...")
                        continuation.finish(throwing: AIModelServiceError.inferenceFailed(reason: "Simulated error during complex query processing."))
                        return
                    }

                    let isFinal = (index == words.count - 1)
                    continuation.yield(AIToken(content: word, isFinal: isFinal))
                }
                continuation.finish()
            }
        }
    }
}

// MARK: - 4. Chat Session Actor for State Management

/// An actor responsible for managing the chat session's state, including messages.
/// Using an actor ensures thread-safe access to the `messages` array.
@available(iOS 18.0, *)
public actor ChatSessionActor {
    public private(set) var messages: [ChatMessage] = [] // Mutable state, protected by the actor

    private let aiService: AIModelService

    public init(aiService: AIModelService) {
        self.aiService = aiService
    }

    /// Adds a user message to the chat session.
    /// - Parameter content: The text content of the user's message.
    public func addUserMessage(content: String) {
        let message = ChatMessage(type: .user, content: content)
        messages.append(message)
        print("User added: '\(message.content)'")
    }

    /// Initiates an AI response stream and updates the chat session in real-time.
    /// - Parameter prompt: The prompt to send to the AI model.
    /// - Returns: The final `ChatMessage` from the AI, or throws an error.
    public func requestAIResponse(for prompt: String) async throws -> ChatMessage {
        // Create a placeholder message for the AI response
        var aiMessage = ChatMessage(type: .ai(model: aiService.modelName), content: "")
        messages.append(aiMessage) // Add placeholder to the chat
        let aiMessageIndex = messages.count - 1

        print("AI response initiated for prompt: '\(prompt)'")

        do {
            for try await token in aiService.streamResponse(for: prompt) {
                // Safely update the AI message content within the actor's isolated context
                messages[aiMessageIndex].appendContent(token.content)
                print("Received AI token: '\(token.content.trimmingCharacters(in: .whitespacesAndNewlines))'")
                // In a real SwiftUI app, you'd publish this change, e.g., via an ObservableObject
                // or by passing the updated messages array to a view model.
            }
            print("AI response stream finished.")
            return messages[aiMessageIndex] // Return the finalized message
        } catch {
            // Handle streaming errors
            messages[aiMessageIndex].content += "\n(Error: \(error.localizedDescription))"
            print("AI response stream failed: \(error.localizedDescription)")
            throw error // Re-throw the error for the caller to handle
        }
    }

    /// Retrieves the current list of messages.
    /// This method is `nonisolated` if `messages` were an immutable copy,
    /// but since it's a mutable array, it must remain `isolated` to ensure safe access.
    public func getMessages() -> [ChatMessage] {
        return messages
    }
}

// MARK: - 5. Orchestration and Demonstration

/// Main function to demonstrate the chat assistant's functionality.
@available(iOS 18.0, *)
func runChatAssistantDemo() async {
    print("--- Smart Chat Assistant Demo ---")

    let aiService = AIModelService(modelName: "SwiftGPT-6")
    let chatSession = ChatSessionActor(aiService: aiService)

    // 1. User sends a message
    await chatSession.addUserMessage(content: "What is the capital of France?")
    print("\nCurrent messages: \(await chatSession.getMessages().map { $0.content })")

    // 2. AI responds to the first message
    do {
        let finalAIMessage = try await chatSession.requestAIResponse(for: "What is the capital of France?")
        print("\nFinal AI message received: '\(finalAIMessage.content)'")
    } catch {
        print("\nFailed to get AI response: \(error.localizedDescription)")
    }
    print("\nCurrent messages after first AI interaction: \(await chatSession.getMessages().map { $0.content })")

    // 3. User sends another message
    await chatSession.addUserMessage(content: "Tell me a short story about a brave knight.")
    print("\nCurrent messages: \(await chatSession.getMessages().map { $0.content })")

    // 4. AI responds to the second message (with a simulated error)
    do {
        let finalAIMessage = try await chatSession.requestAIResponse(for: "Tell me a short story about a brave knight.")
        print("\nFinal AI message received: '\(finalAIMessage.content)'")
    } catch {
        print("\nFailed to get AI response for story: \(error.localizedDescription)")
    }
    print("\nCurrent messages after second AI interaction: \(await chatSession.getMessages().map { $0.content })")

    print("\n--- Demo End ---")
}

// Kick off the demo
@available(iOS 18.0, *)
Task {
    await runChatAssistantDemo()
}
