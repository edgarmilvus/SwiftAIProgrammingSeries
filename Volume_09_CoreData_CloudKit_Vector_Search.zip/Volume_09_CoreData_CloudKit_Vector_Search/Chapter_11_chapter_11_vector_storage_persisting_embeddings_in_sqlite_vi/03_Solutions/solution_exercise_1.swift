
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import GRDB

// 1. The Model
struct Note: Codable, FetchableRecord, PersistableRecord, Sendable {
    var id: Int64?
    var title: String
    var content: String
    var createdAt: Date
    var vectorEmbedding: [Float]? // The new field
    
    // Define columns for GRDB
    enum Columns {
        static let id = Column(CodingKeys.id)
        static let title = Column(CodingKeys.title)
        static let content = Column(CodingKeys.content)
        static let createdAt = Column(CodingKeys.createdAt)
        static let vectorEmbedding = Column(CodingKeys.vectorEmbedding)
    }
}

// 2. Type Mapping Extension
// This handles the bit-for-bit conversion between [Float] and Data
extension Data {
    func toFloatArray() -> [Float]? {
        guard self.count % MemoryLayout<Float>.size == 0 else { return nil }
        return self.withUnsafeBytes { pointer in
            Array(pointer.bindMemory(to: Float.self))
        }
    }
}

extension Array where Element == Float {
    var toData: Data {
        return self.withUnsafeBytes { Data(buffer: $0) }
    }
}

// 3. The Migration Logic
struct DatabaseManager {
    let dbWriter: any DatabaseWriter
    
    func setupMigrations() throws {
        var migrator = DatabaseMigrator()
        
        // v1: Initial Schema
        migrator.registerMigration("createNotes") { db in
            try db.create(table: "note") { t in
                t.autoIncrementedPrimaryKey("id")
                t.column("title", .text).notNull()
                t.column("content", .text).notNull()
                t.column("createdAt", .datetime).notNull()
            }
        }
        
        // v2: The Semantic Search Evolution
        migrator.registerMigration("addVectorEmbeddings") { db in
            // Adding a NULLABLE BLOB column is non-destructive.
            // Existing rows will simply have NULL for this column.
            try db.alter(table: "note") { t in
                t.add(column: "vectorEmbedding", .blob)
            }
        }
        
        try migrator.migrate(dbWriter)
    }
}
