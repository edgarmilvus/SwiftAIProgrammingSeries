
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    // Assuming this was introduced in a previous chapter on SwiftUI data flow
    @available(iOS 18.0, *)
    @Observable
    class AIDetectionViewModel {
        var detections: [BoundingBoxDetection] = []
        // ... other properties related to AI state ...

        func runInference(on image: UIImage) async {
            // Simulate AI inference
            try? await Task.sleep(for: .seconds(1))
            // Update detections, which will automatically trigger UI refresh
            self.detections = [
                BoundingBoxDetection(label: "Person", confidence: 0.98, rect: CGRect(x: 0.2, y: 0.3, width: 0.4, height: 0.5)),
                BoundingBoxDetection(label: "Bicycle", confidence: 0.90, rect: CGRect(x: 0.6, y: 0.7, width: 0.2, height: 0.25))
            ]
        }
    }
    