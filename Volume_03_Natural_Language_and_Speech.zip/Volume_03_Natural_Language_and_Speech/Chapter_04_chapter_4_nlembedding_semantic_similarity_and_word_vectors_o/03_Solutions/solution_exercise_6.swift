
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.swift
// Description: Solution for Exercise 6
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 18.0, macOS 15.0, *)
struct ModerationResult {
    let isFlagged: Bool // True if content exceeds any moderation threshold
    let mostSimilarConcept: String? // The prohibited concept with the highest similarity
    let similarityScore: Double? // The highest similarity score found
}

@available(iOS 18.0, macOS 15.0, *)
class ContentModerator {
    private let prohibitedConcepts: [String]
    // Pre-computed embeddings for prohibited concepts
    private var conceptEmbeddings: [String: [Double]] = [:]
    private let moderationThreshold: Double // Threshold for flagging content
    private let language: NLLanguage
    private let embeddingModel: NLEmbedding?

    /// Initializes the ContentModerator with a list of prohibited concepts and a moderation threshold.
    /// - Parameters:
    ///   - prohibitedConcepts: An array of strings representing concepts that should be flagged.
    ///   - moderationThreshold: The minimum similarity score to flag content.
    ///   - language: The natural language for the embedding model.
    init(prohibitedConcepts: [String], moderationThreshold: Double, language: NLLanguage) {
        self.prohibitedConcepts = prohibitedConcepts
        self.moderationThreshold = moderationThreshold
        self.language = language
        self.embeddingModel = NLEmbedding.wordEmbedding(for: language)

        if self.embeddingModel == nil {
            print("Warning: NLEmbedding word model not available for \(language.rawValue). Content moderation will be limited.")
            return
        }

        // Pre-computation of concept embeddings:
        // Generate and store embeddings for each prohibited concept during initialization.
        for concept in prohibitedConcepts {
            if let conceptEmbedding = self.averageWordEmbedding(for: concept) {
                self.conceptEmbeddings[concept] = conceptEmbedding
            } else {
                print("Could not generate embedding for prohibited concept: \(concept)")
            }
        }
    }

    /// Generates an average word embedding for a given text (e.g., user content or a concept).
    /// This is a helper function, similar to Exercises 2 and 3.
    /// - Parameter text: The text to embed.
    /// - Returns: An array of Doubles representing the averaged embedding, or nil.
    private func averageWordEmbedding(for text: String) -> [Double]? {
        guard let embeddingModel = self.embeddingModel else { return nil }

        let tokenizer = NLTokenizer(unit: .word)
        tokenizer.string = text

        var sumEmbedding: [Double]? = nil
        var wordCount = 0

        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
            let word = String(text[tokenRange])
            if let currentWordEmbedding = embeddingModel.embedding(for: word) {
                if sumEmbedding == nil {
                    sumEmbedding = Array(repeating: 0.0, count: currentWordEmbedding.count)
                }
                for i in 0..<currentWordEmbedding.count {
                    sumEmbedding?[i] += currentWordEmbedding[i]
                }
                wordCount += 1
            }
            return true
        }

        guard let finalSumEmbedding = sumEmbedding, wordCount > 0 else { return nil }
        return finalSumEmbedding.map { $0 / Double(wordCount) }
    }

    /// Analyzes user-submitted content for semantic similarity to prohibited concepts.
    /// - Parameter content: The user-submitted text to analyze.
    /// - Returns: A ModerationResult indicating if the content was flagged, and if so, which concept it was most similar to.
    func analyze(content: String) -> ModerationResult {
        guard let embeddingModel = self.embeddingModel else {
            print("Embedding model not available. Cannot analyze content.")
            return ModerationResult(isFlagged: false, mostSimilarConcept: nil, similarityScore: nil)
        }

        // 1. Generate embedding for the user's content
        guard let contentEmbedding = self.averageWordEmbedding(for: content) else {
            print("Could not generate embedding for content: \(content)")
            return ModerationResult(isFlagged: false, mostSimilarConcept: nil, similarityScore: nil)
        }

        var highestSimilarity: Double = 0.0
        var mostSimilarConcept: String? = nil

        // 2. Compare content embedding against each prohibited concept embedding
        for (concept, conceptVector) in conceptEmbeddings {
            let currentSimilarity = embeddingModel.similarity(for: contentEmbedding, to: conceptVector)
            if currentSimilarity > highestSimilarity {
                highestSimilarity = currentSimilarity
                mostSimilarConcept = concept
            }
        }

        // 3. Determine if content is flagged based on the highest similarity score
        let isFlagged = highestSimilarity >= moderationThreshold
        return ModerationResult(isFlagged: isFlagged, mostSimilarConcept: mostSimilarConcept, similarityScore: highestSimilarity)
    }
}

// MARK: - Example Usage
@available(iOS 18.0, macOS 15.0, *)
func demonstrateContentModerator() {
    print("\n--- Exercise 4: On-Device Content Moderation Helper ---")

    let prohibitedConcepts = [
        "hate speech",
        "violence threat",
        "spam advertising",
        "self-harm encouragement",
        "illegal drug sales"
    ]
    let moderator = ContentModerator(prohibitedConcepts: prohibitedConcepts, moderationThreshold: 0.75, language: .english)

    let userContents = [
        "I love this product, it's amazing!", // Safe
        "I will harm you if you don't comply.", // Violence threat
        "Check out this amazing new crypto investment opportunity!", // Spam advertising
        "Feeling very down, I want to end it all.", // Self-harm encouragement (high similarity)
        "You are all terrible people and don't deserve to live.", // Hate speech
        "Where can I buy some recreational substances?", // Illegal drug sales (semantic match)
        "This movie was violent and full of hateful characters.", // Contains keywords, but context might be different
        "I need help, feeling distressed." // Needs help, but not self-harm encouragement
    ]

    for content in userContents {
        let result = moderator.analyze(content: content)
        print("\nContent: \"\(content)\"")
        print("  Flagged: \(result.isFlagged)")
        if result.isFlagged {
            print("  Most similar concept: \(result.mostSimilarConcept ?? "N/A") (Score: \(result.similarityScore ?? 0.0, specifier: "%.4f"))")
        } else if let score = result.similarityScore, let concept = result.mostSimilarConcept {
            print("  Highest similarity: \(concept) (Score: \(score, specifier: "%.4f")), below threshold.")
        } else {
            print("  No similarity score calculated or model unavailable.")
        }
    }
}

// Call the demonstration function
// demonstrateContentModerator()
