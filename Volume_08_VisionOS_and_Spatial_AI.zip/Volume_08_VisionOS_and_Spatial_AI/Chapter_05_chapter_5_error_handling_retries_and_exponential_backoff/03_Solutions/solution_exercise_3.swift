
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

struct BackoffStrategy {
    let base: TimeInterval
    let maxDelay: TimeInterval
    let jitterFactor: Double // e.g., 0.25 for 25%

    /// Calculates the delay for a specific attempt number using:
    /// delay = (base * 2^attempt) + random_jitter
    func delay(forAttempt attempt: Int) -> Duration {
        // 1. Calculate exponential part: base * 2^attempt
        let exponentialPart = base * pow(2.0, Double(attempt))
        
        // 2. Calculate jitter: random value between 0 and (exponentialPart * jitterFactor)
        let maxJitter = exponentialPart * jitterFactor
        let jitter = Double.random(in: 0...maxJitter)
        
        // 3. Apply cap
        let totalDelay = min(exponentialPart + jitter, maxDelay)
        
        // 4. Convert to Swift 6 Duration
        return .seconds(totalDelay)
    }
}

actor LLMRetryHandler {
    private let strategy: BackoffStrategy

    init(strategy: BackoffStrategy) {
        self.strategy = strategy
    }

    func execute<T>(
        maxRetries: Int,
        task: @escaping @Sendable () async throws -> T
    ) async throws -> T {
        var attempt = 0
        
        while true {
            do {
                return try await task()
            } catch let error as LLMError where error.isRetryable {
                if attempt < maxRetries {
                    let delay = strategy.delay(forAttempt: attempt)
                    
                    print("Retry attempt \(attempt + 1) after \(delay) delay...")
                    
                    try await Task.sleep(for: delay)
                    attempt += 1
                    continue
                }
                throw error
            } catch {
                throw error
            }
        }
    }
}

// Usage Example:
// let handler = LLMRetryHandler(strategy: BackoffStrategy(base: 1.0, maxDelay: 30.0, jitterFactor: 0.25))
