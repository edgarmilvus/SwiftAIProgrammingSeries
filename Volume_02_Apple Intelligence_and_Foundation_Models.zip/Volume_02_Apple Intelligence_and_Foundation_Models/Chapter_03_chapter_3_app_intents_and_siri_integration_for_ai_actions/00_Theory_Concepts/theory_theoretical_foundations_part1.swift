
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    import AppIntents
    import Foundation // For URL, etc.

    @available(iOS 18.0, *)
    struct SummarizeDocumentIntent: AppIntent {
        static var title: LocalizedStringResource = "Summarize Document"
        static var description = IntentDescription(
            "Summarizes the content of a document using on-device AI.",
            category: .productivity, // Categorize for better system understanding
            searchKeywords: ["summarize", "document", "AI", "notes"]
        )

        // Parameters for the intent
        @Parameter(title: "Document Content", description: "The text content of the document to summarize.")
        var content: String

        @Parameter(title: "Length", description: "Desired length of the summary (e.g., 'short', 'medium', 'long').", default: "medium")
        var length: SummaryLength // Custom enum for clarity

        // The actual logic of the intent
        func perform() async throws -> some IntentResult & ReturnsValue<String> {
            // In a real app, this would call into your app's AI model
            // For demonstration, let's simulate an AI call
            print("Performing summary for content: \(content) with length: \(length.rawValue)")

            // Simulate on-device LLM inference
            try await Task.sleep(for: .seconds(2)) // Simulate AI processing time

            let simulatedSummary = "This is a simulated summary of your document content, processed on-device by Apple Intelligence. The summary length requested was \(length.rawValue)."

            // Return the result
            return .result(value: simulatedSummary, view: IntentResultView {
                Text("Summary Generated!")
                Text(simulatedSummary)
                    .font(.caption)
            })
        }
    }

    @available(iOS 18.0, *)
    enum SummaryLength: String, AppEnum, CaseIterable, Identifiable {
        static var typeDisplayRepresentation: TypeDisplayRepresentation = "Summary Length"
        static var caseDisplayRepresentations: [Self: LocalizedStringResource] = [
            .short: "Short",
            .medium: "Medium",
            .long: "Long"
        ]

        case short, medium, long
        var id: Self { self }
    }
    