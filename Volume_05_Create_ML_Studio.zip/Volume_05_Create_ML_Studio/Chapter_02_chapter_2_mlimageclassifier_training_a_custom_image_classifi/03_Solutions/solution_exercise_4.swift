
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import Vision
import CoreML
import PhotosUI // For modern image picking

// 1. Model Training (Conceptual - performed in Create ML)
//    - Assume 'PlantDiseaseClassifier.mlmodel' is trained and added to the Xcode project.
//    - It classifies images into categories like "Healthy", "Powdery Mildew", "Leaf Rust", "Aphids".

struct PlantDiseaseIdentifierView: View {
    @State private var selectedImage: UIImage?
    @State private var diagnosisMessage: String = "Upload a plant leaf image for diagnosis."
    @State private var showingImagePicker = false
    @State private var selectedPhotoItem: PhotosPickerItem?

    // Define the confidence threshold
    let confidenceThreshold: Float = 0.75 // 75% confidence required for a definitive diagnosis

    var body: some View {
        NavigationView {
            VStack {
                if let image = selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 300)
                        .padding()
                } else {
                    Image(systemName: "leaf.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                        .foregroundColor(.green)
                        .padding()
                }

                Text(diagnosisMessage)
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding()

                Spacer()

                Button("Select Image") {
                    if #available(iOS 16, *) {
                        selectedPhotoItem = nil
                    } else {
                        showingImagePicker = true
                    }
                }
                .buttonStyle(.borderedProminent)
                .padding()
            }
            .navigationTitle("GreenThumb AI")
            .onChange(of: selectedPhotoItem) { newItem in
                Task {
                    if let data = try? await newItem?.loadTransferable(type: Data.self),
                       let uiImage = UIImage(data: data) {
                        selectedImage = uiImage
                        await classifyPlantDisease(uiImage)
                    }
                }
            }
            .sheet(isPresented: $showingImagePicker) {
                ImagePicker(selectedImage: $selectedImage, isPresented: $showingImagePicker, sourceType: .photoLibrary)
            }
            .photosPicker(isPresented: .init(get: {
                #available(iOS 16, *)
                return !showingImagePicker && selectedPhotoItem == nil
            }, set: { newValue in
                if #available(iOS 16, *) {
                    if !newValue { selectedPhotoItem = nil }
                }
            }), selection: $selectedPhotoItem, matching: .images)
        }
    }

    // Function to perform Core ML inference and apply confidence threshold
    @MainActor
    private func classifyPlantDisease(_ image: UIImage) async {
        diagnosisMessage = "Diagnosing..."

        guard let ciImage = CIImage(image: image) else {
            diagnosisMessage = "Error: Could not convert image to CIImage."
            return
        }

        do {
            let config = MLModelConfiguration()
            let model = try PlantDiseaseClassifier(configuration: config)
            let visionModel = try VNCoreMLModel(for: model.model)

            let request = VNCoreMLRequest(model: visionModel) { request, error in
                if let error = error {
                    self.diagnosisMessage = "Vision error: \(error.localizedDescription)"
                    return
                }

                guard let observations = request.results as? [VNClassificationObservation],
                      let topObservation = observations.first else {
                    self.diagnosisMessage = "No classification results."
                    return
                }

                self.diagnosisMessage = self.getDiagnosis(for: observations, confidenceThreshold: self.confidenceThreshold)
            }
            request.imageCropAndScaleOption = .centerCrop // Or .scaleFit

            let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])
            try handler.perform([request])

        } catch {
            diagnosisMessage = "Model error: \(error.localizedDescription)"
        }
    }

    // Helper function to apply confidence threshold logic
    private func getDiagnosis(for observations: [VNClassificationObservation], confidenceThreshold: Float) -> String {
        guard let topObservation = observations.first else {
            return "No diagnosis available."
        }

        let confidencePercentage = String(format: "%.1f%%", topObservation.confidence * 100)

        if topObservation.confidence >= confidenceThreshold {
            return "Diagnosis: \(topObservation.identifier) (\(confidencePercentage) confident)"
        } else {
            // Check for ambiguity if multiple classes are close but below threshold
            if observations.count > 1,
               let secondObservation = observations.dropFirst().first,
               (topObservation.confidence - secondObservation.confidence) < 0.1 { // If top two are very close (within 10%)
                let secondConfidencePercentage = String(format: "%.1f%%", secondObservation.confidence * 100)
                return "Diagnosis Unclear: Could be \(topObservation.identifier) (\(confidencePercentage)) or \(secondObservation.identifier) (\(secondConfidencePercentage)). Please provide more images or consult an expert."
            } else {
                return "Diagnosis Unclear: Confidence too low (\(confidencePercentage)). Please provide more images or consult an expert."
            }
        }
    }
}

// Re-using ImagePicker from Exercise 1 for older iOS / convenience
// (Definition omitted here for brevity, assume it's available)

// For preview purposes
struct PlantDiseaseIdentifierView_Previews: PreviewProvider {
    static var previews: some View {
        PlantDiseaseIdentifierView()
    }
}
