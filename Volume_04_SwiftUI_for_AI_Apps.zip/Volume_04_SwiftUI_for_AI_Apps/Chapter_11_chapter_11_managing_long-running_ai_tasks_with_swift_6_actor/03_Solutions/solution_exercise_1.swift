
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

// 1. Define SentimentResult enum
enum SentimentResult: String, CustomStringConvertible {
    case positive = "Positive 😊"
    case negative = "Negative 😠"
    case neutral = "Neutral 😐"
    case mixed = "Mixed 🤔"

    var description: String {
        return self.rawValue
    }
}

// 2. Define SentimentAnalyzer Actor
actor SentimentAnalyzer {
    // 4. Manage Analysis State (Optional but Recommended)
    private var currentAnalysisText: String?
    private var analysisCounter: Int = 0 // To track sequential analyses

    init() {
        print("SentimentAnalyzer initialized.")
    }

    // 3. Simulate AI Model Latency and analyzeSentiment method
    func analyzeSentiment(for text: String) async throws -> SentimentResult {
        let analysisID = analysisCounter + 1
        analysisCounter += 1
        print("[\(analysisID)] SentimentAnalyzer: Starting analysis for '\(text)'...")

        // Update isolated state
        self.currentAnalysisText = text

        // Simulate AI model inference latency
        try await Task.sleep(for: .seconds(1))

        // Check for cancellation during long-running task
        guard !Task.isCancelled else {
            print("[\(analysisID)] Sentiment analysis for '\(text)' was cancelled.")
            throw CancellationError()
        }

        // Simplified heuristic for sentiment
        let lowercasedText = text.lowercased()
        var result: SentimentResult

        if lowercasedText.contains("good") || lowercasedText.contains("great") || lowercasedText.contains("happy") {
            result = .positive
        } else if lowercasedText.contains("bad") || lowercasedText.contains("terrible") || lowercasedText.contains("sad") {
            result = .negative
        } else if lowercasedText.contains("but") || lowercasedText.contains("however") {
            result = .mixed
        } else {
            result = .neutral
        }

        print("[\(analysisID)] SentimentAnalyzer: Finished analysis for '\(text)'. Result: \(result)")
        self.currentAnalysisText = nil // Clear state after completion
        return result
    }

    // Optional: A method to check the currently analyzed text
    func getCurrentAnalysis() -> String? {
        return currentAnalysisText
    }
}

// 5. Demonstrate Usage (simulated UI context)
@main
struct SentimentApp {
    static func main() async {
        let analyzer = SentimentAnalyzer()

        print("\n--- Demonstrating sequential analysis ---")
        // First analysis
        Task {
            do {
                let text1 = "This is a great chapter on actors!"
                let result1 = try await analyzer.analyzeSentiment(for: text1)
                print("UI received result for '\(text1)': \(result1)")
            } catch {
                print("UI received error for first analysis: \(error.localizedDescription)")
            }
        }

        // Second analysis, initiated shortly after the first, will still be processed sequentially by the actor
        Task {
            do {
                // Introduce a small delay to simulate concurrent UI interaction
                try await Task.sleep(for: .milliseconds(200))
                let text2 = "The weather is bad today, but I'm happy to learn Swift."
                let result2 = try await analyzer.analyzeSentiment(for: text2)
                print("UI received result for '\(text2)': \(result2)")
            } catch {
                print("UI received error for second analysis: \(error.localizedDescription)")
            }
        }

        // Third analysis, demonstrating actor isolation for state
        Task {
            do {
                try await Task.sleep(for: .milliseconds(50))
                let text3 = "I'm feeling neutral about this."
                let result3 = try await analyzer.analyzeSentiment(for: text3)
                print("UI received result for '\(text3)': \(result3)")
            } catch {
                print("UI received error for third analysis: \(error.localizedDescription)")
            }
        }

        // Demonstrate accessing isolated state
        Task {
            try await Task.sleep(for: .milliseconds(500))
            let current = await analyzer.getCurrentAnalysis()
            print("UI check: Currently analyzing: \(current ?? "Nothing")")
        }

        // Keep the main task alive long enough for all async tasks to complete
        try? await Task.sleep(for: .seconds(5))
        print("\n--- All sentiment analysis tasks initiated. ---")
    }
}
