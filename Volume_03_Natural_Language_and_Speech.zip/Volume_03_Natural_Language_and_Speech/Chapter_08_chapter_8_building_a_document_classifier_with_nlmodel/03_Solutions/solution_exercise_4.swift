
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import NaturalLanguage
import CreateML
import Foundation

// MARK: - 1. Define Aspects & Labels

enum ProductAspect: String, CaseIterable {
    case camera = "Camera"
    case batteryLife = "Battery Life"
    case performance = "Performance"
    case design = "Design"
}

enum SentimentLabel: String, CaseIterable {
    case positive = "Positive"
    case negative = "Negative"
    case neutral = "Neutral"
    case notAboutAspect = "Not_About_Aspect" // For aspect-specific models
}

// MARK: - 2. Dataset Creation (Conceptual & Partial Implementation)

// Strategy: Train a separate NLModel for each aspect.
// Each aspect-specific model will classify text as "Aspect_Positive", "Aspect_Negative",
// "Aspect_Neutral", or "Not_About_Aspect".

// Helper to generate synthetic data for the "Camera" aspect
func generateCameraSentimentTrainingData() -> [(text: String, label: String)] {
    var data: [(text: String, label: String)] = []

    // Camera_Positive
    data.append(("The camera on this phone is absolutely stunning, takes amazing photos.", "Camera_Positive"))
    data.append(("Photos are crisp and clear, especially in low light. Best camera ever!", "Camera_Positive"))
    data.append(("I love the camera features; the portrait mode is fantastic.", "Camera_Positive"))
    data.append(("Video recording quality is superb, very smooth and stable.", "Camera_Positive"))
    data.append(("The zoom capabilities are surprisingly good for a smartphone camera.", "Camera_Positive"))
    data.append(("Excellent camera for everyday use, colors are vibrant.", "Camera_Positive"))
    data.append(("The front camera takes beautiful selfies.", "Camera_Positive"))
    data.append(("Never seen such high-quality images from a phone camera before.", "Camera_Positive"))
    data.append(("The camera app is fast and responsive.", "Camera_Positive"))
    data.append(("Optical image stabilization works wonders.", "Camera_Positive"))

    // Camera_Negative
    data.append(("The camera is a huge disappointment, blurry photos in any light.", "Camera_Negative"))
    data.append(("Takes terrible pictures, especially indoors. Very grainy.", "Camera_Negative"))
    data.append(("I regret buying this phone, the camera is just awful.", "Camera_Negative"))
    data.append(("Video quality is very poor, constantly pixelated.", "Camera_Negative"))
    data.append(("Zoom is practically unusable, just a blurry mess.", "Camera_Negative"))
    data.append(("Colors look washed out and unnatural from the camera.", "Camera_Negative"))
    data.append(("The front camera produces distorted images.", "Camera_Negative"))
    data.append(("Expected much better image quality for this price.", "Camera_Negative"))
    data.append(("The camera app frequently crashes.", "Camera_Negative"))
    data.append(("No optical image stabilization, very shaky videos.", "Camera_Negative"))

    // Camera_Neutral
    data.append(("The camera is decent, nothing spectacular but gets the job done.", "Camera_Neutral"))
    data.append(("Picture quality is average for a phone in this price range.", "Camera_Neutral"))
    data.append(("It has a camera, and it takes pictures.", "Camera_Neutral"))
    data.append(("Video recording is okay, not the best, not the worst.", "Camera_Neutral"))
    data.append(("The camera functions as expected.", "Camera_Neutral"))
    data.append(("The camera is adequate for casual photos.", "Camera_Neutral"))
    data.append(("Standard camera features are included.", "Camera_Neutral"))
    data.append(("The camera is neither good nor bad.", "Camera_Neutral"))
    data.append(("I haven't used the camera much.", "Camera_Neutral"))
    data.append(("It has multiple lenses, but I don't notice a huge difference.", "Camera_Neutral"))

    // Not_About_Camera
    data.append(("Battery life is exceptional, lasts all day with heavy use.", "Not_About_Camera"))
    data.append(("The phone's performance is incredibly fast and smooth.", "Not_About_Camera"))
    data.append(("I love the sleek design and premium feel of the device.", "Not_About_Camera"))
    data.append(("The screen is vibrant and bright, perfect for media consumption.", "Not_About_Camera"))
    data.append(("Charging speed is impressive, full charge in under an hour.", "Not_About_Camera"))
    data.append(("Gaming on this device is a fantastic experience.", "Not_About_Camera"))
    data.append(("The operating system is intuitive and user-friendly.", "Not_About_Camera"))
    data.append(("Sound quality from the speakers is surprisingly good.", "Not_About_Camera"))
    data.append(("The phone overheats quickly during intensive tasks.", "Not_About_Camera"))
    data.append(("The phone feels cheap and flimsy in hand.", "Not_About_Camera"))
    data.append(("I am very happy with my new purchase.", "Not_About_Camera"))
    data.append(("This is the best phone I've ever owned.", "Not_About_Camera"))
    data.append(("The customer service was excellent.", "Not_About_Camera"))
    data.append(("I received the product quickly.", "Not_About_Camera"))
    data.append(("The packaging was very secure.", "Not_About_Camera"))

    // Add more examples to reach a decent dataset size for training
    for _ in 0..<20 { // Add 20 more random samples
        let allExamples = data.map { $0.text }
        data.append((allExamples.randomElement()!, data.randomElement()!.label))
    }
    
    return data.shuffled()
}

// MARK: - 3. Aspect-Specific Model Training

func trainAndSaveAspectSentimentClassifier(for aspect: ProductAspect) throws -> URL {
    let trainingData: [(text: String, label: String)]
    
    // In a real app, you'd have similar functions for other aspects
    switch aspect {
    case .camera:
        trainingData = generateCameraSentimentTrainingData()
    default:
        // For other aspects, we'll just return a dummy URL or throw error for this exercise
        // as we are only implementing for 'Camera'.
        print("Warning: Training data not implemented for \(aspect.rawValue).")
        throw NSError(domain: "SentimentTrainer", code: 1, userInfo: [NSLocalizedDescriptionKey: "Training data not found for \(aspect.rawValue)"])
    }
    
    let dataTable = try MLDataTable(array: trainingData.map { ["text": $0.text, "label": $0.label] })
    let (trainingTable, testingTable) = dataTable.randomSplit(by: 0.8, seed: 77)

    let classifier = try MLTextClassifier(trainingData: trainingTable,
                                          textColumn: "text",
                                          labelColumn: "label")

    let evaluation = classifier.evaluation(on: testingTable, textColumn: "text", labelColumn: "label")
    print("\(aspect.rawValue) Sentiment Classifier Training Accuracy: \(evaluation.accuracy)")

    let fileManager = FileManager.default
    let documentsURL = try fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    let modelURL = documentsURL.appendingPathComponent("\(aspect.rawValue.replacingOccurrences(of: " ", with: ""))Sentiment.mlmodel")

    try classifier.write(to: modelURL)
    print("\(aspect.rawValue) Sentiment model saved to: \(modelURL.path)")
    return modelURL
}

// MARK: - 4. Multi-Aspect Analysis (Integration & Logic)

class MultiAspectSentimentAnalyzer {
    private var aspectModels: [ProductAspect: NLModel] = [:]
    
    // Keywords for simple aspect detection
    private let aspectKeywords: [ProductAspect: [String]] = [
        .camera: ["camera", "photo", "picture", "image", "lens", "zoom", "megapixel", "video"],
        .batteryLife: ["battery", "charge", "life", "drain", "power", "hours"],
        .performance: ["performance", "speed", "fast", "slow", "lag", "processor", "chip", "smooth"],
        .design: ["design", "look", "feel", "build", "material", "sleek", "premium", "plastic"]
    ]

    init(modelURLs: [ProductAspect: URL]) {
        for (aspect, url) in modelURLs {
            do {
                let model = try NLModel(contentsOf: url)
                aspectModels[aspect] = model
                print("Loaded model for \(aspect.rawValue).")
            } catch {
                print("Error loading model for \(aspect.rawValue): \(error.localizedDescription)")
            }
        }
    }

    // Function to split review text into sentences
    private func sentences(from text: String) -> [String] {
        let tagger = NLTagger(tagSchemes: [.tokenType])
        tagger.string = text
        var result: [String] = []
        tagger.enumerateTokens(in: text.startIndex..<text.endIndex, unit: .sentence) { tokenRange, _ in
            result.append(String(text[tokenRange]))
            return true
        }
        return result
    }

    func analyzeProductReview(reviewText: String) -> [String: String] {
        var aspectSentiments: [String: String] = [:]
        let reviewSentences = sentences(from: reviewText)
        
        for aspect in ProductAspect.allCases {
            guard let model = aspectModels[aspect] else {
                aspectSentiments[aspect.rawValue] = "Model Not Loaded"
                continue
            }
            
            var relevantSentences: [String] = []
            let keywords = aspectKeywords[aspect] ?? []
            
            // Simple keyword matching to find relevant sentences
            for sentence in reviewSentences {
                let lowercasedSentence = sentence.lowercased()
                if keywords.contains(where: lowercasedSentence.contains) {
                    relevantSentences.append(sentence)
                }
            }
            
            if relevantSentences.isEmpty {
                // If no relevant sentences, assume neutral or not applicable
                aspectSentiments[aspect.rawValue] = "Not Applicable"
            } else {
                // Combine relevant sentences (or process individually) and predict
                // For simplicity, we'll classify each relevant sentence and take the majority,
                // or just the first if only one.
                var sentimentCounts: [String: Int] = [:]
                for sentence in relevantSentences {
                    let prediction = model.predictedLabel(for: sentence) ?? SentimentLabel.notAboutAspect.rawValue
                    // Only count actual sentiment labels, ignore "Not_About_Aspect" here
                    if prediction != SentimentLabel.notAboutAspect.rawValue {
                        sentimentCounts[prediction, default: 0] += 1
                    }
                }
                
                if let dominantSentiment = sentimentCounts.max(by: { $0.value < $1.value })?.key {
                    // Extract the base sentiment (e.g., "Camera_Positive" -> "Positive")
                    let baseSentiment = dominantSentiment.replacingOccurrences(of: "\(aspect.rawValue)_", with: "")
                    aspectSentiments[aspect.rawValue] = baseSentiment
                } else {
                    // If no sentiment-specific predictions, it's neutral or not enough info
                    aspectSentiments[aspect.rawValue] = "Neutral"
                }
            }
        }
        
        return aspectSentiments
    }
}

// MARK: - Main Execution

func runMultiAspectSentimentDemo() {
    var cameraModelURL: URL?
    do {
        // Train only the Camera sentiment model for this demo
        cameraModelURL = try trainAndSaveAspectSentimentClassifier(for: .camera)
    } catch {
        print("Failed to train Camera sentiment model: \(error.localizedDescription)")
        return
    }

    guard let loadedCameraModelURL = cameraModelURL else {
        print("Camera sentiment model URL not available.")
        return
    }

    // Simulate loading models for other aspects (they won't be trained in this demo)
    // In a real app, you'd train and save these too.
    let dummyModelURL = URL(fileURLWithPath: "/dev/null") // Placeholder for other models
    let modelURLs: [ProductAspect: URL] = [
        .camera: loadedCameraModelURL,
        .batteryLife: dummyModelURL, // This model won't actually work
        .performance: dummyModelURL, // This model won't actually work
        .design: dummyModelURL      // This model won't actually work
    ]
    
    let analyzer = MultiAspectSentimentAnalyzer(modelURLs: modelURLs)

    print("\n--- Testing Multi-Aspect Sentiment Analysis ---")
    let reviews = [
        "The camera is amazing, takes beautiful photos. But the battery life is terrible, dies so fast. Performance is okay.",
        "This phone has a sleek design, very premium feel. The battery lasts forever. I haven't used the camera much, but performance is snappy.",
        "The performance is outstanding, no lag whatsoever. Camera is decent, nothing special. Design is a bit generic. Battery life is average.",
        "Worst phone ever. The camera is blurry, battery drains quickly, and performance lags constantly. The design is also ugly.",
        "Great phone overall! The camera is good for the price point, and the battery life is solid. Performance is also smooth."
    ]

    for review in reviews {
        print("\nReview: \"\(review)\"")
        let sentiments = analyzer.analyzeProductReview(reviewText: review)
        for (aspect, sentiment) in sentiments {
            print("  \(aspect): \(sentiment)")
        }
    }
}

// Call the demo function
runMultiAspectSentimentDemo()
