
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import StoreKit
import Foundation

enum SecurityError: Error {
    case tamperedTransaction(details: String)
    case environmentMismatch(details: String)
}

@available(iOS 18.0, *)
actor SecurityService {
    
    /// Performs deep cryptographic validation of the transaction JWS.
    func validateTransactionIntegrity(_ result: VerificationResult<Transaction>) throws -> Transaction {
        switch result {
        case .verified(let transaction):
            // Hard Mode: Environment Checking
            // Ensure production builds don't accept sandbox transactions
            #if !DEBUG
            if transaction.environment == .sandbox {
                throw SecurityError.environmentMismatch(details: "Sandbox transaction in Production environment.")
            }
            #endif
            
            return transaction
            
        case .unverified(let transaction, let error):
            // Log the specific JWS error for security auditing
            let details = "Transaction \(transaction.id) failed verification. Error: \(error.localizedDescription)"
            print("CRITICAL SECURITY ALERT: \(details)")
            throw SecurityError.tamperedTransaction(details: details)
        }
    }
}

// Integration Example with SubscriptionObserver
/*
// Inside SubscriptionObserver's handleUpdate:
let verifiedTransaction = try await securityService.validateTransactionIntegrity(result)
await entitlementManager.refreshEntitlements()
*/
