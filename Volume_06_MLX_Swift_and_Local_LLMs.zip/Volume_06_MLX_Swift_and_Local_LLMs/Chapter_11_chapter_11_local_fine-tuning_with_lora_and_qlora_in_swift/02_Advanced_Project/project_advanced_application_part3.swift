
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

import MLX
import MLXNN

/// A Linear layer augmented with a LoRA adapter.
/// This module combines a base `MLXNN.Linear` layer with a `LoRALinearAdapter`.
/// During fine-tuning, only the LoRA adapter's parameters are updated,
/// while the base linear layer's weights remain frozen.
final class LoRA_Augmented_Linear: MLXNN.Module {
    let baseLinear: MLXNN.Linear
    let loraAdapter: LoRALinearAdapter

    /// Initializes a new LoRA-augmented linear layer.
    /// - Parameters:
    ///   - inputDimensions: Input feature dimension.
    ///   - outputDimensions: Output feature dimension.
    ///   - rank: The low rank `r` for the LoRA matrices.
    ///   - alpha: Scaling factor for the LoRA output.
    ///   - key: The `MLXRandom.Key` for parameter initialization.
    init(inputDimensions: Int, outputDimensions: Int, rank: Int, alpha: Double, key: MLXRandom.Key) {
        // Initialize the base linear layer. Its parameters will be frozen.
        self.baseLinear = MLXNN.Linear(inputDimensions: inputDimensions, outputDimensions: outputDimensions, key: key)
        // Initialize the LoRA adapter. Its parameters will be trained.
        self.loraAdapter = LoRALinearAdapter(inputDimensions: inputDimensions, outputDimensions: outputDimensions, rank: rank, alpha: alpha, key: key)
        super.init()
    }

    /// Performs the forward pass, combining the base linear layer output and the LoRA update.
    /// - Parameter input: The input tensor.
    /// - Returns: The combined output: `baseLinear(input) + loraAdapter(input)`.
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Compute the output from the base linear layer.
        let baseOutput = baseLinear(input)
        // Compute the output from the LoRA adapter.
        let loraOutput = loraAdapter(input)
        // Add the LoRA update to the base output.
        return baseOutput + loraOutput
    }
}
