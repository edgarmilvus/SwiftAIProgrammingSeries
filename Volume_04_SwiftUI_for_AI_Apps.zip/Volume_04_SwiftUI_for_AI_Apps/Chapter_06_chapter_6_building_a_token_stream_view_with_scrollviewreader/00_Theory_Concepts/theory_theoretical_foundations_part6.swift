
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 17.0, *)
struct TokenStreamView: View {
    @Environment(TokenStore.self) private var tokenStore // Injected via environment
    @State private var scrollViewProxy: ScrollViewProxy? // Store the proxy

    var body: some View {
        ScrollView {
            ScrollViewReader { proxy in // This is where ScrollViewReader is instantiated
                VStack(alignment: .leading) {
                    ForEach(tokenStore.tokens.indices, id: \.self) { index in
                        Text(tokenStore.tokens[index])
                            .id(index) // Important: give each token an ID for scrolling
                    }
                }
                .onChange(of: tokenStore.tokens.count) { oldVal, newVal in
                    // When new tokens arrive, scroll to the last one
                    if newVal > oldVal {
                        proxy.scrollTo(newVal - 1, anchor: .bottom)
                    }
                }
            }
        }
    }
}
