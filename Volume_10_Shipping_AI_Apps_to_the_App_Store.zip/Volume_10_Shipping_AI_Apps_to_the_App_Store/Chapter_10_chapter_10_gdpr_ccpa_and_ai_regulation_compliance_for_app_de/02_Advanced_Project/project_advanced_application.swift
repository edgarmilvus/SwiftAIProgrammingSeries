
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import OSLog

/// Represents the various types of data an AI application might collect.
/// Essential for granular consent management under GDPR/CCPA.
enum AIDataCategory: String, Codable, CaseIterable {
    case voiceInput          // Audio recordings used for STT
    case textPrompts         // User text inputs sent to LLM
    case inferenceLogs       // Metadata about AI responses
    case personalizedContext // RAG (Retrieval-Augmented Generation) vector embeddings
}

/// Errors specific to the privacy orchestration lifecycle.
enum PrivacyComplianceError: Error, LocalizedError {
    case remoteProviderUnreachable(provider: String)
    case localStorageFailure(reason: String)
    case partialErasureFailure(completed: [AIDataCategory], failed: [AIDataCategory])
    case unauthorizedRequest
    
    var errorDescription: String? {
        switch self {
        case .remoteProviderUnreachable(let p): return "Failed to signal erasure to AI provider: \(p)"
        case .localStorageFailure(let r): return "Local data purge failed: \(r)"
        case .partialErasureFailure(let c, let f): return "Partial success. Completed: \(c). Failed: \(f)."
        case .unauthorizedRequest: return "User authentication required for Data Subject Request."
        }
    }
}

/// A formal request to exercise privacy rights (e.g., Right to Erasure).
struct DataSubjectRequest: Sendable {
    let id: UUID
    let timestamp: Date
    let categoriesToPurge: Set<AIDataCategory>
    let userIdentifier: String
}

/// A mock representation of a remote AI Service (e.g., OpenAI or a custom backend).
/// In a real app, this would involve network calls to a privacy-compliant endpoint.
protocol AIProviderClient: Sendable {
    var name: String { get }
    func signalDataErasure(for userID: String, categories: Set<AIDataCategory>) async throws
}

/// The core Privacy Orchestrator. 
/// Using an `actor` ensures that privacy state changes are thread-safe and 
/// prevents data races during sensitive deletion operations.
@available(iOS 18.0, *)
actor PrivacyComplianceManager {
    private let logger = Logger(subsystem: "com.ai.app.privacy", category: "Compliance")
    private let remoteProviders: [any AIProviderClient]
    private let localFileSystemManager: LocalDataPurgeService
    
    /// Tracks the status of ongoing Data Subject Requests.
    private(set) var activeRequests: [UUID: DataSubjectRequest] = [:]

    init(remoteProviders: [any AIProviderClient], localFileSystemManager: LocalDataPurgeService) {
        self.remoteProviders = remoteProviders
        self.localFileSystemManager = localFileSystemManager
    }

    /// Executes a full 'Right to Erasure' workflow.
    /// This is a complex, multi-stage operation that must be orchestrated carefully.
    /// - Parameter request: The formal DSR request.
    /// - Throws: `PrivacyComplianceError` if the process fails.
    func processErasureRequest(_ request: DataSubjectRequest) async throws {
        logger.info("Starting Erasure Request \(request.id) for user \(request.userIdentifier)")
        activeRequests[request.id] = request
        
        // Defer cleanup of the request tracking
        defer { activeRequests.removeValue(forKey: request.id) }

        var completedCategories: Set<AIDataCategory> = []
        var failedCategories: Set<AIDataCategory> = []

        // 1. Local Purge (Highest Priority: Minimize local footprint immediately)
        do {
            try await localFileSystemManager.purgeLocalData(for: request.userIdentifier, categories: request.categoriesToPurge)
            completedCategories.formUnion(request.categoriesToPurge)
            logger.info("Local data purge successful.")
        } catch {
            logger.error("Local purge failed: \(error.localizedDescription)")
            // We don't stop here; we attempt remote purge even if local fails to maximize compliance.
            failedCategories.formUnion(request.categoriesToPurge)
        }

        // 2. Remote Provider Coordination (The 'Distributed Erasure' problem)
        // We use a TaskGroup to signal all AI providers in parallel for efficiency.
        try await withThrowingTaskGroup(of: AIDataCategory.self) { group in
            for category in request.categoriesToPurge {
                group.addTask {
                    // For each category, we signal all providers
                    for provider in self.remoteProviders {
                        try await provider.signalDataErasure(for: request.userIdentifier, categories: [category])
                    }
                    return category
                }
            }

            while let result = await group.nextResult() {
                switch result {
                case .success(let category):
                    completedCategories.insert(category)
                case .failure(let error):
                    logger.error("Remote signal failed: \(error.localizedDescription)")
                    // In a production app, we would map the error back to specific categories.
                    // For this demo, we treat the whole request as partially failed.
                }
            }
        }

        // 3. Final Audit Logging (Crucial for demonstrating compliance to regulators)
        try await logComplianceEvent(request: request, success: completedCategories.count == request.categoriesToPurge.count)

        // 4. Validation
        if completedCategories.count < request.categoriesToPurge.count {
            throw PrivacyComplianceError.partialErasureFailure(
                completed: Array(completedCategories),
                failed: Array(request.categoriesToPurge.subtracting(completedCategories))
            )
        }
    }

    private func logComplianceEvent(request: DataSubjectRequest, success: Bool) async throws {
        // In production, this would write to a secure, immutable audit log.
        logger.notice("COMPLIANCE AUDIT: Request \(request.id) status: \(success ? "SUCCESS" : "PARTIAL_FAILURE")")
    }
}

/// Service responsible for interacting with the local file system and CoreData.
struct LocalDataPurgeService: Sendable {
    func purgeLocalData(for userID: String, categories: Set<AIDataCategory>) async throws {
        // Simulate file system latency and potential I/O errors
        try await Task.sleep(for: .seconds(1))
        
        // Logic would involve deleting files in Application Support/
        // or executing DELETE queries in CoreData/SwiftData.
        print("Successfully purged local files for \(userID) in categories: \(categories)")
    }
}

// MARK: - Example Usage

@available(iOS 18.0, *)
struct ComplianceDemo {
    struct MockAIProvider: AIProviderClient {
        let name: String
        func signalDataErasure(for userID: String, categories: Set<AIDataCategory>) async throws {
            // Simulate network call to OpenAI/Anthropic/etc.
            try await Task.sleep(for: .milliseconds(500))
            print("[\(name)] Received erasure signal for \(userID)")
        }
    }

    static func run() async {
        let providers: [any AIProviderClient] = [
            MockAIProvider(name: "OpenAI-Cloud"),
            MockAIProvider(name: "Internal-Vector-DB")
        ]
        
        let manager = PrivacyComplianceManager(
            remoteProviders: providers,
            localFileSystemManager: LocalDataPurgeService()
        )
        
        let request = DataSubjectRequest(
            id: UUID(),
            timestamp: Date(),
            categoriesToPurge: [.voiceInput, .textPrompts, .personalizedContext],
            userIdentifier: "user_12345_alpha"
        )
        
        do {
            print("🚀 Initiating Privacy Request...")
            try await manager.processErasureRequest(request)
            print("✅ Compliance Workflow Complete.")
        } catch {
            print("❌ Compliance Workflow Failed: \(error.localizedDescription)")
        }
    }
}
