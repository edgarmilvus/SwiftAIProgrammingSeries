
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import PhotosUI // For PHPickerViewController

@available(iOS 15.0, *)
struct SmartPhotoOrganizerView: View {
    @StateObject private var organizer = SmartPhotoOrganizer()
    @State private var showingImagePicker = false
    @State private var selectedPhotos: [ImageInput] = []

    var body: some View {
        NavigationView {
            VStack {
                if organizer.isLoading {
                    ProgressView("Classifying photos...")
                        .padding()
                } else if let error = organizer.errorMessage {
                    Text("Error: \(error)")
                        .foregroundColor(.red)
                        .padding()
                } else if organizer.classificationResults.isEmpty {
                    Text("No photos classified yet. Tap 'Select Photos' to begin.")
                        .foregroundColor(.gray)
                        .padding()
                } else {
                    List(organizer.classificationResults) { result in
                        HStack {
                            if let thumbnailData = result.thumbnailData,
                               let uiImage = UIImage(data: thumbnailData) {
                                Image(uiImage: uiImage)
                                    .resizable()
                                    .frame(width: 50, height: 50)
                                    .cornerRadius(8)
                            } else {
                                Image(systemName: "photo")
                                    .resizable()
                                    .frame(width: 50, height: 50)
                                    .cornerRadius(8)
                                    .foregroundColor(.gray)
                            }
                            VStack(alignment: .leading) {
                                Text(result.predictedCategory)
                                    .font(.headline)
                                Text("Confidence: \(result.confidence * 100, specifier: "%.1f")%")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                }

                Spacer()

                Button("Select Photos") {
                    showingImagePicker = true
                }
                .buttonStyle(.borderedProminent)
                .padding()
            }
            .navigationTitle("Photo Organizer")
            .task {
                // Load the model when the view appears.
                // This uses a detached Task to avoid blocking the UI while loading.
                do {
                    try await organizer.loadModel()
                } catch {
                    print("Initial model load failed: \(error.localizedDescription)")
                    // Error message will be published to `organizer.errorMessage`
                }
            }
            .sheet(isPresented: $showingImagePicker) {
                // Using PHPickerViewController for modern photo selection
                PhotoPicker(selectedPhotos: $selectedPhotos, isPresented: $showingImagePicker) { assets in
                    // When photos are selected, process them.
                    Task {
                        await organizer.processPhotos(photos: assets)
                    }
                }
            }
        }
    }
}

// MARK: - PHPickerViewController Wrapper for SwiftUI

@available(iOS 15.0, *)
struct PhotoPicker: UIViewControllerRepresentable {
    @Binding var selectedPhotos: [ImageInput]
    @Binding var isPresented: Bool
    var onSelection: ([PHAsset]) -> Void

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var configuration = PHPickerConfiguration()
        configuration.filter = .images // Only allow images
        configuration.selectionLimit = 0 // 0 means unlimited selection
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: PHPickerViewControllerDelegate {
        var parent: PhotoPicker

        init(_ parent: PhotoPicker) {
            self.parent = parent
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            parent.isPresented = false // Dismiss the picker

            // Convert results to PHAsset (requires permission handling in a real app)
            // This is a simplified approach. In production, you'd load assets more carefully.
            var assets: [PHAsset] = []
            let identifiers = results.compactMap(\.assetIdentifier)
            let fetchResult = PHAsset.fetchAssets(withLocalIdentifiers: identifiers, options: nil)
            fetchResult.enumerateObjects { asset, _, _ in
                assets.append(asset)
            }
            
            parent.onSelection(assets)
        }
    }
}

// MARK: - App Entry Point (for demonstration)
@main
@available(iOS 15.0, *)
struct SmartPhotoOrganizerApp: App {
    var body: some Scene {
        WindowGroup {
            SmartPhotoOrganizerView()
        }
    }
}
