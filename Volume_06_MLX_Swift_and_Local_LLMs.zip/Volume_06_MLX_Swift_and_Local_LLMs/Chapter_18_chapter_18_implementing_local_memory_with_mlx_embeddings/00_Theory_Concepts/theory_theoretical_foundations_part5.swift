
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import Observation // For @Observable

    @available(iOS 18.0, *)
    @Observable
    class EmbeddingViewModel {
        var searchResults: [String] = []
        var isLoading: Bool = false
        private let embeddingService: EmbeddingService

        init(embeddingService: EmbeddingService) {
            self.embeddingService = embeddingService
        }

        @MainActor // Ensure UI updates are on the main thread
        func performSearch(query: String) async {
            isLoading = true
            searchResults = [] // Clear previous results

            // Simulate tokenization
            let tokenizedQuery = MLXArray.randomUniform(low: 0, high: 10000, [1, query.count], type: .int32)

            do {
                let queryEmbedding = try await embeddingService.getEmbedding(for: query, tokenizedInput: tokenizedQuery)
                // In a real app, you'd use queryEmbedding to find similar items
                // For demonstration, let's just add a dummy result
                searchResults = ["Result for '\(query)' (embedding processed)"]
            } catch {
                print("Search error: \(error)")
                searchResults = ["Error performing search."]
            }
            isLoading = false
        }
    }

    @available(iOS 18.0, *)
    struct EmbeddingSearchView: View {
        @State private var query: String = ""
        @State private var viewModel: EmbeddingViewModel // Initialized elsewhere or via Environment

        init(service: EmbeddingService) {
            _viewModel = State(initialValue: EmbeddingViewModel(embeddingService: service))
        }

        var body: some View {
            VStack {
                TextField("Enter query", text: $query)
                    .textFieldStyle(.roundedBorder)
                    .padding()

                Button("Search") {
                    Task {
                        await viewModel.performSearch(query: query)
                    }
                }
                .disabled(viewModel.isLoading)

                if viewModel.isLoading {
                    ProgressView()
                } else {
                    List(viewModel.searchResults, id: \.self) { result in
                        Text(result)
                    }
                }
            }
        }
    }
    