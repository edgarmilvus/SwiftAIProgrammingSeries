
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import Observation

enum MessageSender {
    case user
    case assistant
}

struct Message: Identifiable, Equatable {
    let id = UUID()
    let sender: MessageSender
    var content: String
}

@Observable
@MainActor
class ChatViewModel {
    var messages: [Message] = []
    
    func sendMessage(_ text: String) async {
        // 1. Append User Message
        messages.append(Message(sender: .user, content: text))
        
        // 2. Append an empty Assistant Message to "hold the place"
        let assistantMsgId = UUID()
        messages.append(Message(sender: .assistant, content: ""))
        
        // 3. Simulate Streaming
        let stream = simulateStreaming()
        
        for await chunk in stream {
            // Find the index of the last message (the assistant one)
            if let index = messages.indices.last {
                messages[index].content += chunk
            }
        }
    }
    
    private func simulateStreaming() -> AsyncStream<String> {
        AsyncStream { continuation in
            Task {
                let words = ["I", " am", " processing", " your", " request", " with", " precision."]
                for word in words {
                    try? await Task.sleep(for: .milliseconds(200))
                    continuation.yield(word)
                }
                continuation.finish()
            }
        }
    }
}

struct ChatBubbleView: View {
    let message: Message
    
    var body: some View {
        HStack {
            if message.sender == .user { Spacer() }
            
            Text(message.content)
                .padding(12)
                .background(message.sender == .user ? Color.blue : Color.gray.opacity(0.2))
                .foregroundColor(message.sender == .user ? .white : .primary)
                .cornerRadius(16)
            
            if message.sender == .assistant { Spacer() }
        }
        .padding(.horizontal)
    }
}

struct ChatView: View {
    @State private var viewModel = ChatViewModel()
    @State private var inputText = ""

    var body: some View {
        VStack {
            ScrollView {
                LazyVStack {
                    ForEach(viewModel.messages) { message in
                        ChatBubbleView(message: message)
                    }
                }
            }
            
            HStack {
                TextField("Message...", text: $inputText)
                    .textFieldStyle(.roundedBorder)
                
                Button("Send") {
                    let text = inputText
                    inputText = ""
                    Task {
                        await viewModel.sendMessage(text)
                    }
                }
            }
            .padding()
        }
    }
}
