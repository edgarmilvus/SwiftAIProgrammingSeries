/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Graphviz DOT Language String
const imageUploadFlow = `
digraph OfflineImageUpload {
  rankdir=LR;
  node [shape=box, style="rounded,filled", color=lightblue];

  // Nodes
  UI [label="UI Component\n(Camera/Gallery)"];
  LocalState [label="Local State\n(Optimistic UI)", fillcolor=lightyellow];
  MutationHook [label="useMutation\n(uploadImage)", fillcolor=lightgreen];
  OnlineCheck [label="OnlineManager\n.isOnline()?", shape=diamond, fillcolor=lightcoral];
  
  subgraph cluster_queue {
    label="Offline Handling";
    style=dashed;
    AsyncStorage [label="AsyncStorage\n(Mutation Queue)", fillcolor=lightgrey];
    RetryLogic [label="Retry Logic\n(Exponential Backoff)", fillcolor=orange];
  }

  Server [label="API Server", shape=ellipse, fillcolor=white];
  Cache [label="Query Cache\n(Invalidate/Update)", fillcolor=lightsteelblue];

  // Edges & Flow
  UI -> LocalState [label="1. User takes photo"];
  LocalState -> MutationHook [label="2. Trigger mutation"];
  MutationHook -> OnlineCheck [label="3. Check status"];
  
  // Online Path
  OnlineCheck -> Server [label="Online\n(onMutate)", constraint=false];
  
  // Offline Path
  OnlineCheck -> AsyncStorage [label="Offline\n(queue mutation)"];
  AsyncStorage -> RetryLogic [label="Network Restored"];
  RetryLogic -> Server [label="Retry Request"];

  // Response & Sync
  Server -> MutationHook [label="Response\n(onSuccess/onError)"];
  MutationHook -> Cache [label="Invalidate ['images']"];
  Cache -> UI [label="Refetch & Update UI"];
  
  // Visualizing the "Split Brain" scenario (Advanced)
  Server -> RetryLogic [label="Network Drop\n(in-flight failure)", style=dashed, color=red];
}
`;

// To render this, you would typically copy the string into a Graphviz tool.
// For this exercise, the string is the solution.
console.log(imageUploadFlow);
