
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor ModelManager {
    private var customNLModel: NLModel?

    func loadModel(named modelName: String) async throws {
        // Simulating model loading, which might be an expensive operation
        try? await Task.sleep(for: .milliseconds(500))
        let config = MLModelConfiguration()
        // Assume MyCustomClassifier is a generated Core ML model class
        let coreMLModel = try MyCustomClassifier(configuration: config).model
        self.customNLModel = try NLModel(mlModel: coreMLModel)
        print("Model '\(modelName)' loaded.")
    }

    func classify(_ text: String) async throws -> String {
        guard let model = customNLModel else {
            throw ModelManagerError.modelNotLoaded
        }
        return model.predictedLabel(for: text) ?? "Unknown"
    }

    enum ModelManagerError: Error {
        case modelNotLoaded
    }
}

// Example usage
/*
@available(iOS 18.0, *)
func demonstrateActorUsage() async {
    let manager = ModelManager()
    Task {
        do {
            try await manager.loadModel(named: "MyCustomClassifier")
            let category = try await manager.classify("This movie was fantastic!")
            print("Classified as: \(category)")
        } catch {
            print("Error: \(error)")
        }
    }

    // Another task trying to classify concurrently
    Task {
        do {
            // This will await the model to be loaded by the first task implicitly
            let category = try await manager.classify("The stock market is volatile.")
            print("Classified as: \(category)")
        } catch {
            print("Error: \(error)")
        }
    }
}
*/

// Package.swift snippet (if MyCustomClassifier were from a local package)
/*
// This is illustrative, MyCustomClassifier would be generated from a .mlmodel
// and usually resides directly in the app target, not a separate package.
// However, if your custom models were part of a larger ML library, this is how
// you might structure it.
//
// package.swift
// dependencies: [
//     .package(name: "CoreMLModels", path: "../CoreMLModels")
// ]
// targets: [
//     .target(
//         name: "MyApp",
//         dependencies: ["CoreMLModels"]
//     )
// ]
*/
