/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export const LoginScreen = () => {
  const insets = useSafeAreaInsets();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  /*
   * ASYNC TOOL HANDLING (Pseudo-code Description):
   * 
   * const onLoginPress = async () => {
   *   // 1. Validate inputs (e.g., check if empty).
   *   if (!username || !password) return;
   * 
   *   // 2. Update UI state: Disable button, show spinner.
   *   setIsLoading(true);
   * 
   *   try {
   *     // 3. Perform API call.
   *     const response = await api.login(username, password);
   *     
   *     // 4. Handle success: Navigate to Home screen.
   *     if (response.success) {
   *       navigation.navigate('Home');
   *     } else {
   *       // 5. Handle API logic error (e.g., invalid credentials).
   *       Alert.alert('Login Failed', response.message);
   *     }
   *   } catch (error) {
   *     // 6. Handle network or server error.
   *     Alert.alert('Error', 'An unexpected error occurred.');
   *   } finally {
   *     // 7. Always reset loading state.
   *     setIsLoading(false);
   *   }
   * };
   */

  const onLoginPress = () => {
    // Placeholder for the logic described above
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 2000); // Simulate network request
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#f5f5f5' }}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        {/* Main Scrollable Area */}
        <ScrollView
          contentContainerStyle={{
            flexGrow: 1,
            paddingTop: insets.top + 20, // Add extra padding below status bar
            paddingHorizontal: 20,
            justifyContent: 'center',
          }}
          keyboardShouldPersistTaps="handled"
        >
          <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' }}>
            Welcome Back
          </Text>
          
          <TextInput
            placeholder="Username"
            value={username}
            onChangeText={setUsername}
            style={{
              height: 50,
              borderWidth: 1,
              borderColor: '#ddd',
              borderRadius: 8,
              paddingHorizontal: 10,
              marginBottom: 15,
              backgroundColor: 'white',
            }}
            autoCapitalize="none"
          />
          
          <TextInput
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            style={{
              height: 50,
              borderWidth: 1,
              borderColor: '#ddd',
              borderRadius: 8,
              paddingHorizontal: 10,
              marginBottom: 30,
              backgroundColor: 'white',
            }}
          />
          
          {/* Spacer to ensure button visibility when keyboard is closed */}
          <View style={{ height: 60 }} />
        </ScrollView>

        {/* Fixed Bottom Button - Positioned absolutely or within the KeyboardAvoidingView context */}
        <View
          style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            padding: 20,
            paddingBottom: insets.bottom + 20, // Ensure button sits above home indicator
            backgroundColor: '#f5f5f5', // Matches screen background to cover scrolling content
          }}
        >
          <TouchableOpacity
            onPress={onLoginPress}
            disabled={isLoading}
            style={{
              backgroundColor: isLoading ? '#ccc' : '#007AFF',
              height: 50,
              borderRadius: 10,
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            {isLoading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={{ color: 'white', fontWeight: '600', fontSize: 16 }}>Login</Text>
            )}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
};
