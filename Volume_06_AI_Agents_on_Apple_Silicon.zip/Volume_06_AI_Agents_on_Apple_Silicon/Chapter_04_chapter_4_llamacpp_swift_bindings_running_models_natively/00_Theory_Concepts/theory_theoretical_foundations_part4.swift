
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Observation // Required for @Observable

// Example: An Observable class to hold streaming LLM output
@available(iOS 18.0, macOS 15.0, *)
@Observable
public class LLMOutputViewModel {
    var currentText: String = ""
    var isGenerating: Bool = false
    var error: String?

    func appendToken(_ token: String) {
        self.currentText += token
    }

    func reset() {
        self.currentText = ""
        self.isGenerating = false
        self.error = nil
    }
}

// Example usage in a SwiftUI View
@available(iOS 18.0, macOS 15.0, *)
struct InferenceView: View {
    @State private var prompt: String = "What is the capital of France?"
    @State private var outputViewModel = LLMOutputViewModel()
    @State private var agent = LLMAgent() // Actor instance

    var body: some View {
        VStack {
            TextField("Enter prompt", text: $prompt)
                .textFieldStyle(.roundedBorder)
                .padding()

            Button("Generate") {
                Task {
                    outputViewModel.reset()
                    outputViewModel.isGenerating = true
                    do {
                        // Ensure model is loaded before generation
                        if agent.modelPath == nil {
                            await agent.loadModel(from: "/path/to/my/model.gguf")
                        }
                        for await token in try await agent.generate(prompt: prompt, maxTokens: 50) {
                            outputViewModel.appendToken(token)
                        }
                    } catch {
                        outputViewModel.error = error.localizedDescription
                    }
                    outputViewModel.isGenerating = false
                }
            }
            .disabled(outputViewModel.isGenerating)
            .padding()

            Text(outputViewModel.currentText)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)

            if outputViewModel.isGenerating {
                ProgressView()
            }

            if let error = outputViewModel.error {
                Text("Error: \(error)")
                    .foregroundStyle(.red)
            }
            Spacer()
        }
        .padding()
        .task { // Load model when view appears
            await agent.loadModel(from: "/path/to/my/model.gguf")
        }
    }
}
