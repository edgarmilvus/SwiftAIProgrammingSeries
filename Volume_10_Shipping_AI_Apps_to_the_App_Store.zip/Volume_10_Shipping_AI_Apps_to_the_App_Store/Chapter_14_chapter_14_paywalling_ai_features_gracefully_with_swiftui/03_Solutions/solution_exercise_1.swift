
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Observation

@available(iOS 18.0, *)
@Observable
class UserSession {
    var isPremium: Bool = false
    var username: String = "AI_Explorer"
}

@available(iOS 18.0, *)
struct PremiumBadgeView: View {
    // 1. Accept a UserSession instance
    var session: UserSession
    
    var body: some View {
        Group {
            if session.isPremium {
                // 2. Show a gold-colored icon and "Pro" text
                Label("Pro", systemImage: "crown.fill")
                    .font(.caption.bold())
                    .foregroundStyle(.yellow)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.yellow.opacity(0.15), in: Capsule())
            } else {
                // 3. Show a subtle "Upgrade" button
                Button(action: {
                    // Trigger paywall logic here
                }) {
                    Label("Upgrade", systemImage: "sparkles")
                        .font(.caption.bold())
                        .foregroundStyle(.blue)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.blue.opacity(0.1), in: Capsule())
                }
                .buttonStyle(.plain)
            }
        }
        // 4. Ensure the transition is smooth
        .animation(.spring(duration: 0.3), value: session.isPremium)
    }
}

// Preview for testing
@available(iOS 18.0, *)
struct PremiumBadgeView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            List {
                Section("User Profile") {
                    HStack {
                        Text("Account Status")
                        Spacer()
                        PremiumBadgeView(session: UserSession())
                    }
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    // Testing the Pro state
                    let proSession = UserSession()
                    proSession.isPremium = true
                    PremiumBadgeView(session: proSession)
                }
            }
        }
    }
}
