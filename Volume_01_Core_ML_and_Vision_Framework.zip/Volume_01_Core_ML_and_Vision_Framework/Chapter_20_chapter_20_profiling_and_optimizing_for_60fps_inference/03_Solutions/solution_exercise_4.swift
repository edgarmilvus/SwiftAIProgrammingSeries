
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CoreML
import Vision
import CoreMedia
import Foundation
import UIKit // For UIImage and creating initial pixel buffers

// Assume MobileNetV2.mlmodel is included in your project (same as Exercise 1)

@available(iOS 18.0, *)
actor MyCVPixelBufferPool {
    private let pixelBufferPool: CVPixelBufferPool
    private let lock = NSLock() // NSLock is used here for CVPixelBufferPoolCreatePixelBuffer,
                               // but for actual pool management, `actor` provides safety.
    private let capacity: Int

    init?(width: Int, height: Int, pixelFormat: OSType, capacity: Int) {
        let pixelBufferAttributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: pixelFormat,
            kCVPixelBufferWidthKey as String: width,
            kCVPixelBufferHeightKey as String: height,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:] // Enable Metal/GPU compatibility
        ]
        
        var pool: CVPixelBufferPool?
        let status = CVPixelBufferPoolCreate(kCFAllocatorDefault, nil, pixelBufferAttributes as CFDictionary, &pool)
        
        guard status == kCVReturnSuccess, let unwrappedPool = pool else {
            return nil
        }
        self.pixelBufferPool = unwrappedPool
        self.capacity = capacity

        // Pre-allocate buffers to fill the pool.
        // CVPixelBufferPoolCreatePixelBuffer will create new buffers if pool is empty
        // up to kCVPixelBufferPoolMaximumBufferAgeKey.
        // For a fixed capacity, we can pre-fill and then rely on ARC for return.
        var pixelBuffers: [CVPixelBuffer] = []
        for _ in 0..<capacity {
            if let buffer = requestPixelBuffer() {
                pixelBuffers.append(buffer)
            }
        }
        // These buffers will be returned to the pool when `pixelBuffers` array is deallocated.
        // For explicit control, you'd manage a custom array of CVPixelBuffers and return them.
        // For CVPixelBufferPool, simply releasing the last strong reference returns it to the pool.
        print("CVPixelBufferPool initialized with capacity: \(capacity)")
    }
    
    // Request a pixel buffer from the pool.
    // This is an `actor` method, so access to `pixelBufferPool` is serialized.
    func requestPixelBuffer() -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        // kCVPixelBufferPoolAllocationThresholdKey can be used to control allocation
        let status = CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, pixelBufferPool, &pixelBuffer)
        if status != kCVReturnSuccess {
            print("Failed to create pixel buffer from pool: \(status)")
        }
        return pixelBuffer
    }
    
    // For CVPixelBufferPool, returning is implicit via ARC.
    // This method is primarily for conceptual clarity or if you had a custom wrapper.
    func returnPixelBuffer(_ pixelBuffer: CVPixelBuffer) {
        // CVPixelBufferPool automatically handles buffer return when last reference is released.
        // If you had a custom pool (e.g., an array of CVPixelBuffers), this is where you'd add it back.
        // For CVPixelBufferPool, simply letting the last strong reference go out of scope is sufficient.
    }
}

@available(iOS 18.0, *)
class VideoFrameProcessor {
    private let pixelBufferPool: MyCVPixelBufferPool
    private let vnCoreMLModel: VNCoreMLModel
    private let targetSize = CGSize(width: 224, height: 224) // MobileNetV2 input size
    
    // For backpressure: limit concurrent tasks
    private let maxConcurrentFrames = 3 // Allow 3 frames to be processed concurrently
    private var activeFrameTasks = 0
    private let activeFrameTasksLock = NSLock() // Protects activeFrameTasks count

    init?(pool: MyCVPixelBufferPool) {
        self.pixelBufferPool = pool
        
        let config = MLModelConfiguration()
        config.computeUnits = .neuralEngine // Prioritize Neural Engine for real-time
        guard let model = try? MobileNetV2(configuration: config) else { // Replace with your model
            print("Failed to load Core ML model for VideoFrameProcessor.")
            return nil
        }
        self.vnCoreMLModel = try! VNCoreMLModel(for: model.model)
    }
    
    /// Preprocesses a CVPixelBuffer (scaling, format conversion) using a pooled buffer.
    private func preprocessPixelBuffer(_ inputPixelBuffer: CVPixelBuffer) async -> CVPixelBuffer? {
        guard let outputPixelBuffer = await pixelBufferPool.requestPixelBuffer() else {
            print("Failed to get pixel buffer from pool for preprocessing.")
            return nil
        }

        CVPixelBufferLockBaseAddress(inputPixelBuffer, .init(rawValue: 0))
        defer { CVPixelBufferUnlockBaseAddress(inputPixelBuffer, .init(rawValue: 0)) }
        CVPixelBufferLockBaseAddress(outputPixelBuffer, .init(rawValue: 0))
        defer { CVPixelBufferUnlockBaseAddress(outputPixelBuffer, .init(rawValue: 0)) }

        let inputWidth = CVPixelBufferGetWidth(inputPixelBuffer)
        let inputHeight = CVPixelBufferGetHeight(inputPixelBuffer)
        let outputWidth = CVPixelBufferGetWidth(outputPixelBuffer)
        let outputHeight = CVPixelBufferGetHeight(outputPixelBuffer)
        
        // Example: Simple CoreGraphics scaling for demonstration.
        // For production, use vImage for YCbCr to BGRA conversion and scaling.
        guard let inputImage = CIImage(cvPixelBuffer: inputPixelBuffer) else { return nil }
        let scaledImage = inputImage.transformed(by: CGAffineTransform(scaleX: targetSize.width / CGFloat(inputWidth), y: targetSize.height / CGFloat(inputHeight)))
                                   .cropped(to: CGRect(origin: .zero, size: targetSize))

        let ciContext = CIContext()
        ciContext.render(scaledImage, to: outputPixelBuffer)
        
        return outputPixelBuffer
    }

    /// Processes a single video frame (CMSampleBuffer) asynchronously.
    func processFrame(sampleBuffer: CMSampleBuffer) async throws -> [VNClassificationObservation]? {
        activeFrameTasksLock.lock()
        if activeFrameTasks >= maxConcurrentFrames {
            activeFrameTasksLock.unlock()
            // print("Dropping frame due to backpressure.")
            return nil // Drop frame
        }
        activeFrameTasks += 1
        activeFrameTasksLock.unlock()

        defer {
            activeFrameTasksLock.lock()
            activeFrameTasks -= 1
            activeFrameTasksLock.unlock()
        }

        guard let inputPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            print("Failed to get CVPixelBuffer from CMSampleBuffer.")
            return nil
        }

        // Preprocess (scale/format convert) using a pooled buffer
        guard let preprocessedPixelBuffer = await preprocessPixelBuffer(inputPixelBuffer) else {
            print("Failed to preprocess pixel buffer.")
            return nil
        }
        
        let request = VNCoreMLRequest(model: vnCoreMLModel)
        request.imageCropAndScaleOption = .centerCrop
        
        let handler = VNImageRequestHandler(cvPixelBuffer: preprocessedPixelBuffer, options: [:])
        try handler.perform([request])
        
        guard let observations = request.results as? [VNClassificationObservation] else {
            return nil
        }
        
        // The preprocessedPixelBuffer will be returned to the pool when its last strong reference is released.
        return observations
    }
}

@available(iOS 18.0, *)
class VideoFeedSimulator {
    private let targetFPS: Double
    private let frameDuration: Duration
    private let numberOfFrames: Int
    private var frameCount: Int = 0
    private let framePixelBuffers: [CVPixelBuffer] // Pre-loaded sample buffers
    private let processor: VideoFrameProcessor
    
    init?(targetFPS: Double, numberOfFrames: Int, processor: VideoFrameProcessor) {
        self.targetFPS = targetFPS
        self.frameDuration = .seconds(1.0 / targetFPS)
        self.numberOfFrames = numberOfFrames
        self.processor = processor
        
        // Create some sample pixel buffers to simulate video frames
        var tempBuffers: [CVPixelBuffer] = []
        for i in 0..<3 { // Use 3 different images to cycle through
            guard let sampleImage = UIImage(named: "sample_image_\(i + 1)") else {
                print("Error: sample_image_\(i + 1).jpg not found in assets.")
                return nil
            }
            // Assume camera frames are 1080p, model needs 224x224
            guard let pixelBuffer = UIImage.init(cgImage: sampleImage.cgImage!)
                                          .toCVPixelBufferCoreGraphics(targetSize: CGSize(width: 1920, height: 1080)) else { // Simulate high-res camera input
                print("Error creating sample pixel buffer for image \(i).")
                return nil
            }
            tempBuffers.append(pixelBuffer)
        }
        self.framePixelBuffers = tempBuffers
    }
    
    /// Simulates generating CMSampleBuffers at a target frame rate.
    func startSimulation() async {
        print("--- Video Feed Simulation Started (Target: \(targetFPS) FPS) ---")
        var lastFrameTime = ContinuousClock().now
        var processedFrames = 0
        var droppedFrames = 0
        var totalProcessingTime: Duration = .zero

        for i in 0..<numberOfFrames {
            let frameStartTime = ContinuousClock().now
            
            // Simulate getting a CMSampleBuffer (just wrap a CVPixelBuffer here)
            let currentPixelBuffer = framePixelBuffers[i % framePixelBuffers.count]
            var sampleBuffer: CMSampleBuffer?
            var timingInfo = CMSampleTimingInfo(duration: frameDuration.cmTime, presentationTimeStamp: .zero, decodeTimeStamp: .invalid)
            CMSampleBufferCreateReadyWithImageBuffer(allocator: kCFAllocatorDefault,
                                                     imageBuffer: currentPixelBuffer,
                                                     formatDescription: nil,
                                                     sampleTiming: &timingInfo,
                                                     &sampleBuffer)
            
            guard let buffer = sampleBuffer else {
                print("Failed to create sample buffer.")
                continue
            }
            
            // Process the frame asynchronously
            let processingTask = Task {
                let inferenceStartTime = ContinuousClock().now
                let results = try await processor.processFrame(sampleBuffer: buffer)
                let inferenceEndTime = ContinuousClock().now
                
                if let results = results {
                    // print("Frame \(i) processed. Top result: \(results.first?.identifier ?? "N/A")")
                    totalProcessingTime += (inferenceEndTime - inferenceStartTime)
                    processedFrames += 1
                } else {
                    droppedFrames += 1
                }
            }
            
            // Wait to maintain target FPS
            let elapsed = ContinuousClock().now - lastFrameTime
            let timeToSleep = frameDuration - elapsed
            if timeToSleep > .zero {
                try? await Task.sleep(for: timeToSleep)
            }
            lastFrameTime = ContinuousClock().now
            
            // Await the processing task if we want to ensure completion before next frame,
            // but for backpressure, we launch and let it run.
            // For this setup, we rely on `maxConcurrentFrames` in `VideoFrameProcessor` for backpressure.
        }
        
        // Give some time for remaining tasks to complete
        try? await Task.sleep(for: .seconds(Double(processor.maxConcurrentFrames) / targetFPS + 1.0))

        let actualDuration = ContinuousClock().now - lastFrameTime // Approximate total simulation time
        let actualFPS = Double(processedFrames) / actualDuration.timeInterval
        let avgProcessingLatency = totalProcessingTime / Double(processedFrames)
        
        print("\n--- Simulation Results ---")
        print("Total frames simulated: \(numberOfFrames)")
        print("Frames processed: \(processedFrames)")
        print("Frames dropped (due to backpressure): \(droppedFrames)")
        print("Actual processing FPS: \(String(format: "%.2f", actualFPS))")
        print("Average processing latency per frame: \(avgProcessingLatency.formatted(.units(fractionalPart: .show(length: 6))))")
        print("Target FPS: \(targetFPS)")
        print("Achieved FPS (processed frames only): \(String(format: "%.2f", Double(processedFrames) / (actualDuration.timeInterval)))")
        print("Overall pipeline efficiency: \(String(format: "%.2f", Double(processedFrames) / Double(numberOfFrames) * 100))%")
    }
}

// Helper for Duration to CMTime conversion
extension Duration {
    var cmTime: CMTime {
        let seconds = self.timeInterval
        return CMTime(seconds: seconds, preferredTimescale: 600) // Using 600 timescale for precision
    }
    
    var timeInterval: TimeInterval {
        return TimeInterval(self.components.seconds) + TimeInterval(self.components.attoseconds) / 1e18
    }
}

// To run this code, you would typically call:
/*
@available(iOS 18.0, *)
Task {
    let poolCapacity = 5 // Example capacity
    let frameWidth = 1920
    let frameHeight = 1080
    let pixelFormat = kCVPixelFormatType_32BGRA
    
    guard let pixelBufferPool = MyCVPixelBufferPool(width: frameWidth, height: frameHeight, pixelFormat: pixelFormat, capacity: poolCapacity) else {
        fatalError("Failed to create CVPixelBufferPool.")
    }
    
    guard let processor = VideoFrameProcessor(pool: pixelBufferPool) else {
        fatalError("Failed to create VideoFrameProcessor.")
    }
    
    let simulator = VideoFeedSimulator(targetFPS: 60, numberOfFrames: 300, processor: processor)
    await simulator?.startSimulation()
}
*/
