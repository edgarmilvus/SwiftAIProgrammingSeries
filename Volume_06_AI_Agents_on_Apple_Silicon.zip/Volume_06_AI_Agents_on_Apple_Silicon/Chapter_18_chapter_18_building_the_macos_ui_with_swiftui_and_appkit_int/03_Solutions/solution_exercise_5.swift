
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import AppKit

// MARK: - 2. Design SwiftUI Console View

// ObservableObject to manage log messages and commands
class ConsoleViewModel: ObservableObject {
    @Published var logMessages: [String] = []
    @Published var currentCommand: String = ""

    func addLogMessage(_ message: String) {
        let timestamp = DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .medium)
        DispatchQueue.main.async { // Ensure UI updates on main thread
            self.logMessages.append("[\(timestamp)] \(message)")
            // Keep log messages within a reasonable limit
            if self.logMessages.count > 50 {
                self.logMessages.removeFirst()
            }
        }
    }

    func sendCommand(_ command: String) {
        guard !command.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        addLogMessage("> \(command)")
        // Simulate command processing
        Task {
            // Simulate async processing
            await Task.sleep(nanoseconds: UInt64.random(in: 500_000_000...2_000_000_000)) // 0.5 to 2 seconds
            await MainActor.run {
                if command.lowercased().contains("error") {
                    addLogMessage("Error: Command '\(command)' failed.")
                } else if command.lowercased().contains("status") {
                    addLogMessage("Status: System nominal.")
                } else {
                    addLogMessage("Command '\(command)' executed successfully.")
                }
            }
        }
        currentCommand = "" // Clear input field
    }
}

struct ConsoleContentView: View {
    @EnvironmentObject var viewModel: ConsoleViewModel
    @State private var scrollViewProxy: ScrollViewProxy?

    var body: some View {
        VStack(spacing: 0) {
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(viewModel.logMessages, id: \.self) { message in
                            Text(message)
                                .font(.system(.footnote, design: .monospaced))
                                .foregroundColor(message.contains("Error:") ? .red : .primary)
                                .id(message) // For ScrollViewReader
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(8)
                }
                .onChange(of: viewModel.logMessages.count) { _ in
                    // Scroll to bottom when new messages arrive
                    if let lastMessage = viewModel.logMessages.last {
                        proxy.scrollTo(lastMessage, anchor: .bottom)
                    }
                }
                .onAppear {
                    // Initial scroll to bottom
                    if let lastMessage = viewModel.logMessages.last {
                        proxy.scrollTo(lastMessage, anchor: .bottom)
                    }
                }
            }
            .background(Color.black.opacity(0.05))
            .border(Color.gray.opacity(0.3), width: 0.5)

            HStack {
                TextField("Enter command...", text: $viewModel.currentCommand, onCommit: {
                    viewModel.sendCommand(viewModel.currentCommand)
                })
                .textFieldStyle(.roundedBorder)
                .padding(.leading, 8)

                Button("Send") {
                    viewModel.sendCommand(viewModel.currentCommand)
                }
                .buttonStyle(.borderedProminent)
                .padding(.trailing, 8)
            }
            .padding(.vertical, 8)
            .background(Color.gray.opacity(0.1))
        }
    }
}

// MARK: - 1. NSWindowController Subclass

class ConsoleWindowController: NSWindowController, NSWindowDelegate {
    // Singleton instance for the console window
    static var shared: ConsoleWindowController?

    convenience init(viewModel: ConsoleViewModel) {
        let rootView = ConsoleContentView().environmentObject(viewModel)
        let hostingController = NSHostingController(rootView: rootView)

        let windowWidth: CGFloat = 600
        let windowHeight: CGFloat = 400
        let screenFrame = NSScreen.main?.visibleFrame ?? NSRect(x: 0, y: 0, width: 800, height: 600)
        let initialX = screenFrame.maxX - windowWidth - 20 // Position near top-right
        let initialY = screenFrame.maxY - windowHeight - 20

        let window = NSWindow(
            contentRect: NSRect(x: initialX, y: initialY, width: windowWidth, height: windowHeight),
            styleMask: [.titled, .closable, .utilityWindow], // Utility panel look
            backing: .buffered,
            defer: false
        )
        
        window.title = "AI Console Output"
        window.setFrameAutosaveName("AIConsoleWindow") // Save position/size
        window.level = .floating // Always stay on top
        window.isReleasedWhenClosed = false // Don't deallocate on close, just hide
        window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary] // Behave well with spaces/fullscreen
        
        // Explicitly disable resizable and miniaturizable
        window.styleMask.remove(.resizable)
        window.styleMask.remove(.miniaturizable)

        // Set the hosting controller as the window's content view controller
        window.contentViewController = hostingController

        self.init(window: window)
        self.window?.delegate = self // Set self as window delegate
        ConsoleWindowController.shared = self // Store singleton reference
    }

    override init(window: NSWindow?) {
        super.init(window: window)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - NSWindowDelegate Methods (Optional)

    func windowShouldClose(_ sender: NSWindow) -> Bool {
        print("Console window is attempting to close.")
        // You can add custom logic here, e.g., prompt for confirmation
        return true // Allow closing
    }

    func windowDidBecomeKey(_ notification: Notification) {
        print("Console window became key (focused).")
    }

    func windowDidResignKey(_ notification: Notification) {
        print("Console window resigned key (lost focus).")
    }
    
    func windowWillClose(_ notification: Notification) {
        print("Console window will close.")
        // If you want to clear the singleton reference when the user closes the window
        // ConsoleWindowController.shared = nil // This would allow a new instance to be created next time
    }
}

// MARK: - 4. Manage Window Lifecycle from SwiftUI

struct Exercise5View: View {
    // Shared view model for the console, initialized once for the app
    @StateObject private var consoleViewModel = ConsoleViewModel()
    
    // We manage the NSWindowController lifecycle indirectly via the static shared property
    // No @State for the controller itself, as it's a singleton managed by AppKit
    
    var body: some View {
        VStack {
            Text("Main Application Window")
                .font(.largeTitle)
                .padding()

            Button("Show AI Console") {
                showConsoleWindow()
            }
            .buttonStyle(.borderedProminent)
            .padding()

            // Example of pushing logs from the main app
            Button("Add Log from Main App") {
                consoleViewModel.addLogMessage("Log message from main app.")
            }
            .buttonStyle(.bordered)
            .padding(.bottom)
        }
        .frame(minWidth: 500, minHeight: 400)
        .onAppear {
            // Pre-fill some logs for demonstration
            consoleViewModel.addLogMessage("System initialized.")
            consoleViewModel.addLogMessage("Loading AI models...")
            consoleViewModel.addLogMessage("Models loaded successfully.")
        }
        // Provide the consoleViewModel as an environment object globally if other parts of the app need it
        // .environmentObject(consoleViewModel) 
    }

    private func showConsoleWindow() {
        // Use the singleton pattern for ConsoleWindowController
        if ConsoleWindowController.shared == nil {
            // Create a new instance if it doesn't exist
            _ = ConsoleWindowController(viewModel: consoleViewModel)
        }
        // Show the existing (or newly created) window
        ConsoleWindowController.shared?.showWindow(nil)
        ConsoleWindowController.shared?.window?.makeKeyAndOrderFront(nil) // Ensure it's frontmost and active
    }
}

// To run this in a preview or an actual app:
// @main
// struct AppKitSwiftUIApp: App {
//     @StateObject private var appConsoleViewModel = ConsoleViewModel() // Global view model for the app

//     var body: some Scene {
//         WindowGroup {
//             Exercise5View()
//                 .environmentObject(appConsoleViewModel) // Provide to main view
//         }
//         .commands {
//             CommandGroup(replacing: .appInfo) {
//                 Button("Show Console") {
//                     if ConsoleWindowController.shared == nil {
//                         _ = ConsoleWindowController(viewModel: appConsoleViewModel)
//                     }
//                     ConsoleWindowController.shared?.showWindow(nil)
//                     ConsoleWindowController.shared?.window?.makeKeyAndOrderFront(nil)
//                 }
//             }
//         }
//     }
// }
