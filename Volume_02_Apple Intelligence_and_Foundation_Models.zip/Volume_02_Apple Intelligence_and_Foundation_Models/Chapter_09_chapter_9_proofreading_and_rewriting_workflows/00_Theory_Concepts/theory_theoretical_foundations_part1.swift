
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
import WritingTools
import Foundation

class DocumentEditorViewModel: ObservableObject {
    @Published var documentText: String = "The quick brown fox jump over the lazy dog."
    @Published var suggestions: [WritingSuggestion] = []
    @Published var isLoading: Bool = false

    private let writingToolsManager = WritingToolsManager() // Manages AI requests

    func requestProofreadingSuggestions() async {
        isLoading = true
        suggestions = [] // Clear previous suggestions

        do {
            // The AI operation is asynchronous. `await` suspends this task
            // but allows the UI to remain responsive.
            let proofreadingRequest = WritingProofreadingRequest(text: documentText)
            let newSuggestions = try await writingToolsManager.proofread(request: proofreadingRequest)
            
            // Once results are available, update the UI
            await MainActor.run {
                self.suggestions = newSuggestions
                self.isLoading = false
            }
        } catch {
            print("Error requesting proofreading: \(error.localizedDescription)")
            await MainActor.run {
                self.isLoading = false
            }
        }
    }
}
