
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation

// MARK: - Hypothetical Apple Intelligence API (Simulated for Demonstration)
// This section simulates the API that Apple would provide for
// on-device text rewriting using Apple Intelligence.
// In a real scenario, you would import a framework like 'AppleIntelligence'
// or use extensions on 'Foundation' types that expose these capabilities.

/// Represents various styles for text rewriting using Apple Intelligence.
/// These styles guide the on-device Large Language Model (LLM) on how to transform the text.
@available(iOS 18.0, macOS 15.0, *)
public enum AITextRewritingStyle: Sendable {
    /// Corrects grammar, spelling, and punctuation, aiming for clarity and correctness.
    case proofread

    /// Rewrites text to be more concise, removing redundancy while preserving meaning.
    case concise

    /// Rewrites text to be more elaborate or detailed, expanding on the original ideas.
    case elaborate

    /// Rewrites text to adopt a more formal tone, suitable for professional communications.
    case formal

    /// Rewrites text to adopt a more casual tone, suitable for informal conversations.
    case casual

    /// Rewrites text based on a custom instruction provided by the developer or user.
    /// - Parameter instruction: A specific, natural language instruction for how to rewrite the text.
    case custom(instruction: String)
}

/// Errors that can occur during text rewriting operations with Apple Intelligence.
@available(iOS 18.0, macOS 15.0, *)
public enum AITextRewriterError: Error, LocalizedError {
    /// Indicates that the Apple Intelligence model required for the operation is not available
    /// on the current device or under current conditions (e.g., low power mode, insufficient storage).
    case modelUnavailable
    /// Indicates that the provided text input is invalid, too long, or does not meet other requirements.
    case invalidInput
    /// A general error indicating that the rewriting operation failed for an unspecified reason.
    /// - Parameter message: A descriptive message providing more details about the failure.
    case operationFailed(String)

    public var errorDescription: String? {
        switch self {
        case .modelUnavailable:
            return "The Apple Intelligence model is currently unavailable. Please check device compatibility and settings."
        case .invalidInput:
            return "The provided text input is invalid or exceeds the maximum allowed length."
        case .operationFailed(let message):
            return "Text rewriting operation failed: \(message)"
        }
    }
}

/// A service for rewriting text using Apple Intelligence's on-device models.
/// This class provides a high-level interface to perform various text transformations
/// powered by Apple's integrated Large Language Models.
@available(iOS 18.0, macOS 15.0, *)
public struct AITextRewriter {

    /// Rewrites the given text according to the specified style.
    /// This asynchronous operation leverages Apple's on-device large language models
    /// to perform intelligent text transformations without sending data off-device.
    ///
    /// - Parameters:
    ///   - text: The original text to be rewritten.
    ///   - style: The desired rewriting style, guiding the AI model's output.
    /// - Returns: The rewritten text string.
    /// - Throws: An `AITextRewriterError` if the rewriting operation encounters an issue,
    ///           such as an unavailable model or invalid input.
    public static func rewrite(_ text: String, style: AITextRewritingStyle) async throws -> String {
        // In a real Apple Intelligence implementation, this would involve calling
        // into the private Apple Intelligence framework APIs.
        // For this basic example, we simulate a simple transformation and
        // introduce a small delay to mimic asynchronous AI processing.
        try await Task.sleep(for: .milliseconds(700)) // Simulate AI processing time

        // Basic input validation: ensure text is not empty and within a reasonable length.
        guard !text.isEmpty && text.count < 1000 else {
            throw AITextRewriterError.invalidInput
        }

        switch style {
        case .proofread:
            // Simulate basic proofreading: common typos, capitalization, punctuation.
            var correctedText = text
                .replacingOccurrences(of: "im", with: "I'm", options: .caseInsensitive)
                .replacingOccurrences(of: "dont", with: "don't", options: .caseInsensitive)
                .replacingOccurrences(of: "teh", with: "the", options: .caseInsensitive)
                .replacingOccurrences(of: "recieve", with: "receive", options: .caseInsensitive)
            
            // Simple 'i' to 'I' correction, ensuring it's not part of another word.
            correctedText = correctedText.replacingOccurrences(of: " i ", with: " I ")
            if correctedText.hasPrefix("i ") {
                correctedText = "I" + correctedText.dropFirst()
            }
            
            // Basic sentence-start capitalization and end punctuation
            if let firstChar = correctedText.first, firstChar.isLowercase {
                correctedText = firstChar.uppercased() + correctedText.dropFirst()
            }
            if correctedText.last != "." && correctedText.last != "?" && correctedText.last != "!" {
                correctedText += "."
            }
            return correctedText

        case .concise:
            // Simulate conciseness by shortening common verbose phrases.
            let conciseMapping: [String: String] = [
                "I am writing to inform you that": "FYI:",
                "in order to": "to",
                "due to the fact that": "because",
                "at this point in time": "now",
                "it is important to note that": "note:",
                "we would like to request": "please request"
            ]
            var result = text
            for (phrase, replacement) in conciseMapping {
                result = result.replacingOccurrences(of: phrase, with: replacement, options: .caseInsensitive)
            }
            return "Concise: \(result)"

        case .elaborate:
            // Placeholder for elaboration. A real LLM would generate more text.
            return "Elaborated version of: \"\(text)\" - providing more context and detail on the subject, exploring its implications and background."

        case .formal:
            // Placeholder for formal tone. A real LLM would adjust vocabulary and sentence structure.
            return "Formally stated: \"\(text)\" - adopting a professional and respectful tone, suitable for official correspondence."

        case .casual:
            // Placeholder for casual tone. A real LLM would use slang and informal phrasing.
            return "Hey, just wanted to say: \"\(text)\" - keeping it chill and informal, no biggie."

        case .custom(let instruction):
            // Placeholder for custom instruction. A real LLM would follow the instruction.
            return "Following your instruction '\(instruction)', I've rewritten: \"\(text)\" - attempting to meet your specific creative or stylistic requirements."
        }
    }
}

// MARK: - Main Application Logic: Messaging App Drafting Assistant

/// A simple command-line application simulating a messaging app's drafting assistant.
/// This assistant uses the hypothetical `AITextRewriter` from Apple Intelligence
/// to help users refine their messages for various purposes.
@main
@available(iOS 18.0, macOS 15.0, *)
struct MessagingAppDraftingAssistant {
    static func main() async {
        print("--- Apple Intelligence Messaging App Drafting Assistant ---")
        print("This simulation demonstrates on-device text rewriting capabilities.")

        // 1. Proofread a message with common errors.
        let originalMessage1 = "hey, im going to be late to the meeting. dont worry about it, ill catch up."
        print("\nOriginal Message 1: \"\(originalMessage1)\"")
        await processMessage(
            originalMessage1,
            style: .proofread,
            description: "Proofreading for grammar, spelling, and punctuation"
        )

        // 2. Make a message sound more formal.
        let originalMessage2 = "i need to talk to you about the project. its not going well."
        print("\nOriginal Message 2: \"\(originalMessage2)\"")
        await processMessage(
            originalMessage2,
            style: .formal,
            description: "Making the message more formal"
        )

        // 3. Make a verbose message more concise.
        let originalMessage3 = "I am writing to inform you that I will be unable to attend the scheduled meeting due to the fact that I have a prior engagement."
        print("\nOriginal Message 3: \"\(originalMessage3)\"")
        await processMessage(
            originalMessage3,
            style: .concise,
            description: "Making the message more concise"
        )
        
        // 4. Rewrite a message with a custom instruction (e.g., poetic style).
        let originalMessage4 = "The sun is shining today."
        print("\nOriginal Message 4: \"\(originalMessage4)\"")
        await processMessage(
            originalMessage4,
            style: .custom(instruction: "Describe it poetically, like a haiku."),
            description: "Rewriting with a custom poetic instruction"
        )

        // 5. Demonstrate error handling for invalid input (e.g., an empty message).
        let emptyMessage = ""
        print("\nOriginal Message 5: \"\(emptyMessage)\"")
        await processMessage(
            emptyMessage,
            style: .proofread,
            description: "Attempting to proofread an empty message (error expected)"
        )

        print("\n--- End of Simulation ---")
    }

    /// Processes a given message using the `AITextRewriter` with a specified style.
    /// This helper function encapsulates the AI interaction, including asynchronous calls
    /// and robust error handling, making the main logic cleaner.
    ///
    /// - Parameters:
    ///   - message: The text message to be processed by Apple Intelligence.
    ///   - style: The `AITextRewritingStyle` to apply (e.g., `.proofread`, `.formal`).
    ///   - description: A human-readable description of the operation being performed,
    ///                  used for console output.
    static func processMessage(
        _ message: String,
        style: AITextRewritingStyle,
        description: String
    ) async {
        print("\n\(description)...")
        do {
            // This is the core interaction point with the simulated Apple Intelligence API.
            // The `await` keyword indicates that this is an asynchronous operation
            // that might take some time to complete, as the on-device LLM processes the request.
            let rewrittenMessage = try await AITextRewriter.rewrite(message, style: style)
            print("Rewritten Message: \"\(rewrittenMessage)\"")
        } catch let error as AITextRewriterError {
            // Catch specific AITextRewriter errors for tailored feedback.
            print("Error during rewriting: \(error.localizedDescription)")
        } catch {
            // Catch any other unexpected errors.
            print("An unexpected error occurred: \(error.localizedDescription)")
        }
    }
}
