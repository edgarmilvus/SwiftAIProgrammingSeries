
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import AVFoundation
import Vision
import CoreML // Even if we simulate, VNCoreMLRequest is part of CoreML/Vision integration

// MARK: - 1. Data Model: DetectedDocumentField

/// Represents a single detected document field with its properties.
/// Conforms to `Identifiable` for use in SwiftUI's `ForEach` views.
struct DetectedDocumentField: Identifiable {
    let id = UUID() // Unique identifier for SwiftUI ForEach
    let label: String // The classification label (e.g., "Invoice No.")
    let boundingBox: CGRect // Normalized CGRect (0.0 to 1.0) with top-left origin
    let confidence: Float // Confidence score of the detection/classification
    var status: FieldStatus = .detected // Current status of the field, e.g., verified by user

    /// Defines the possible statuses for a detected document field.
    enum FieldStatus {
        case detected // Initially detected by Vision
        case verified // Marked as verified by the user
        case missing // Could be used in a more advanced app to track expected fields
    }
}

// MARK: - 2. ViewModel/Controller: DocumentFieldDetectionManager

/// Manages camera input, Vision processing, and publishes detected document fields.
/// This class acts as the central data source and logic handler for the document scanner.
@available(iOS 18.0, *) // Using modern concurrency features and potentially future Vision updates
final class DocumentFieldDetectionManager: NSObject, ObservableObject {
    /// Published array of detected document fields, triggering UI updates.
    @Published var detectedFields: [DetectedDocumentField] = []
    /// Published boolean indicating if the camera session is running and ready.
    @Published var cameraIsReady: Bool = false
    /// Published error if camera setup or access fails.
    @Published var cameraError: Error?

    let captureSession = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    // Dedicated queue for video output processing to avoid blocking the main thread.
    private let videoOutputQueue = DispatchQueue(label: "com.example.videoOutputQueue", qos: .userInitiated)

    // Using VNRequest? to allow for different Vision requests.
    // In a Core ML integration, this would specifically be VNCoreMLRequest.
    private var visionRequest: VNRequest?

    override init() {
        super.init()
        setupVisionRequest()
        setupCamera()
    }

    /// Configures the Vision framework request for document field detection.
    ///
    /// **Pedagogical Note on Custom Model Integration:**
    /// To integrate a custom Core ML model (e.g., `DocumentFieldDetector.mlmodelc`),
    /// you would typically replace `VNDetectRectanglesRequest` with `VNCoreMLRequest`.
    ///
    /// Example of `VNCoreMLRequest` integration:
    /// 