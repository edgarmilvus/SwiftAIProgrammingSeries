
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

struct BlockUpdate: Codable, Sendable {
    let blockID: Int
    let position: SIMD3<Float>
    let sequenceNumber: UInt64
}

actor WorldStateActor {
    private var blockStates: [Int: BlockUpdate] = [:]
    private var lastProcessedSequence: [Int: UInt64] = [:]
    
    // An AsyncStream to broadcast updates to the renderer
    private var continuation: AsyncStream<[BlockUpdate]>.Continuation?
    lazy var stateStream: AsyncStream<[BlockUpdate]> = {
        AsyncStream { self.continuation = $0 }
    }()

    /// Processes a batch of updates, discarding stale/out-of-order data.
    func process(batch: [BlockUpdate]) {
        var appliedUpdates: [BlockUpdate] = []
        
        for update in batch {
            let lastSeq = lastProcessedSequence[update.blockID] ?? 0
            
            // Handling Out-of-Order Delivery:
            // Only apply the update if its sequence number is newer than the last one we saw.
            if update.sequenceNumber > lastSeq {
                blockStates[update.blockID] = update
                lastProcessedSequence[update.blockID] = update.sequenceNumber
                appliedUpdates.append(update)
            }
        }
        
        if !appliedUpdates.isEmpty {
            continuation?.yield(appliedUpdates)
        }
    }
}

/// The Batching Engine to prevent thread explosion and network saturation.
final class BatchingEngine {
    private var pendingUpdates: [BlockUpdate] = []
    private let actor: WorldStateActor
    private var timerTask: Task<Void, Never>?
    
    init(actor: WorldStateActor) {
        self.actor = actor
        startBatchingLoop()
    }
    
    func queueUpdate(_ update: BlockUpdate) {
        pendingUpdates.append(update)
    }
    
    private func startBatchingLoop() {
        timerTask = Task {
            while !Task.isCancelled {
                // Wait for the next frame (approx 16ms)
                try? await Task.sleep(for: .milliseconds(16))
                
                if !pendingUpdates.isEmpty {
                    let batchToSend = pendingUpdates
                    pendingUpdates.removeAll()
                    
                    // Send the entire batch as a single unit of work
                    await actor.process(batch: batchToSend)
                }
            }
        }
    }
    
    func stop() {
        timerTask?.cancel()
    }
}
