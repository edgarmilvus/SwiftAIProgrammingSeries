
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

@available(iOS 18.0, macOS 14.0, *)
import MLX
import MLXNN // For MLXNN.Module

// 1. Model Definition
/// A simple Linear Regression model implemented as an MLXNN.Module.
/// It has two learnable parameters: `weight` and `bias`.
class LinearRegression: MLXNN.Module {
    var weight: MLXArray
    var bias: MLXArray

    init() {
        // Initialize weight and bias as scalar MLXArrays.
        // requiresGrad = true tells MLX to track gradients for these parameters.
        self.weight = MLXArray.randomNormal(shape: [], requiresGrad: true)
        self.bias = MLXArray.zeros(shape: [], requiresGrad: true)
        super.init() // Call the superclass initializer
    }

    // 2. Forward Pass
    /// Performs the linear transformation: y_pred = X * weight + bias.
    /// - Parameter input: The input features (X), typically a 1D MLXArray.
    /// - Returns: The predicted output (y_pred) as an MLXArray.
    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Ensure input is float for consistent type operations
        let floatInput = input.astype(Float.self)
        return floatInput * weight + bias
    }
}

// 3. Loss Function
/// Computes the Mean Squared Error (MSE) loss.
/// MSE = mean((predictions - targets)^2)
/// - Parameters:
///   - predictions: The model's predicted values.
///   - targets: The actual target values.
/// - Returns: A scalar MLXArray representing the MSE loss.
func mseLoss(predictions: MLXArray, targets: MLXArray) -> MLXArray {
    // Ensure targets are float for consistent type operations
    let floatTargets = targets.astype(Float.self)
    let error = predictions - floatTargets
    let squaredError = pow(error, 2)
    return squaredError.mean()
}

// Example usage:
let model = LinearRegression()
let learningRate: Float = 0.01

// Sample Data (e.g., X = days, Y = weight)
let X = MLXArray([1.0, 2.0, 3.0, 4.0, 5.0]) // Features
let Y = MLXArray([60.2, 60.5, 60.1, 60.8, 61.0]) // Targets

print("--- Before Training Step ---")
print("Initial Weight:", model.weight.eval())
print("Initial Bias:", model.bias.eval())

// 4. Gradient Calculation
// valueAndGradient computes the loss and its gradients with respect to model's parameters.
let (loss, gradients) = valueAndGradient(model.parameters()) { (parameters: [String: MLXArray]) -> MLXArray in
    // The closure captures the model and data, and computes the loss.
    // MLX will trace operations involving `parameters` to compute gradients.
    let predictions = model.callAsFunction(X)
    return mseLoss(predictions: predictions, targets: Y)
}

print("Initial Loss:", loss.eval())
print("Gradients for Weight:", gradients["weight"]?.eval())
print("Gradients for Bias:", gradients["bias"]?.eval())


// 5. Parameter Update (Single Step of Gradient Descent)
// Update model parameters by subtracting (learningRate * gradient)
// MLXNN.Module has a convenient `update` method for this.
model.update(parameters: gradients.mapValues { $0 * learningRate })

print("\n--- After One Training Step ---")
print("Updated Weight:", model.weight.eval())
print("Updated Bias:", model.bias.eval())

// Verify updated loss (optional)
let updatedPredictions = model.callAsFunction(X)
let updatedLoss = mseLoss(predictions: updatedPredictions, targets: Y)
print("Updated Loss (after one step):", updatedLoss.eval())
