
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part7.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN
import Foundation

// @available(iOS 18.0, *)
// func exampleSendable() async {
// Our MySimpleMLP is already declared `final class MySimpleMLP: MLXNN.Module, Sendable`
// This means instances of MySimpleMLP can be safely passed across concurrency domains.

func processModelInBackgroundTask(model: MySimpleMLP, input: MLXArray) async -> MLXArray {
    // The model and input MLXArray are safely passed to this async function
    // which might run on a different thread.
    print("Processing model in background task...")
    let output = model(input)
    output.eval()
    return output
}

Task {
    let model = MySimpleMLP()
    let input = MLXArray.rand([1, 10])

    let result = await processModelInBackgroundTask(model: model, input: input)
    print("Background task result shape: \(result.shape)")
}
// }
