
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import AppIntents
import Foundation // For Date and basic types
import CoreML // Placeholder for Apple Intelligence TextGenerationService

// MARK: - Mock Data Store and Models

// A simple struct to represent a note
struct Note: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var content: String
    var creationDate: Date = Date()
}

// In-memory mock data store for notes
class NoteStore {
    static let shared = NoteStore() // Singleton
    private var notes: [Note] = [
        Note(title: "Meeting Notes", content: "Discussed Q3 strategy, assigned John to market research, Sarah to design mockups. Next meeting on Friday."),
        Note(title: "Grocery List", content: "Milk, Eggs, Bread, Apples, Bananas, Spinach, Chicken Breast, Olive Oil."),
        Note(title: "Swift 6 Features", content: "Async/await improvements, enhanced Actors, improved Sendable conformance, new App Intents framework, Apple Intelligence integration with TextGenerationService, Vision, etc."),
        Note(title: "Project Alpha Update", content: "Project Alpha is progressing well. Frontend team completed login screen. Backend team integrated user authentication. Remaining tasks: payment gateway, user profile, and notification system. Deadline remains end of month.")
    ]

    func getNote(byTitle title: String) -> Note? {
        notes.first { $0.title.localizedCaseInsensitiveContains(title) }
    }
}

// MARK: - Placeholder for Apple Intelligence TextGenerationService

// This is a conceptual placeholder. In a real scenario, this would be provided by Apple's frameworks.
// It simulates the asynchronous nature and potential for errors.
@available(iOS 18.0, macOS 15.0, *)
class TextGenerationService {
    static let shared = TextGenerationService()

    enum TextGenerationError: Error, CustomStringConvertible {
        case serviceUnavailable
        case contentTooLong
        case generationFailed(String)

        var description: String {
            switch self {
            case .serviceUnavailable: return "Text generation service is currently unavailable."
            case .contentTooLong: return "The provided content is too long for summarization."
            case .generationFailed(let reason): return "Text generation failed: \(reason)"
            }
        }
    }

    /// Simulates generating a summary using Apple Intelligence.
    /// In a real implementation, this would interact with a system service.
    func generateSummary(for text: String, prompt: String? = nil) async throws -> String {
        // Simulate network/processing delay
        try await Task.sleep(for: .milliseconds(500))

        // Simulate potential errors
        if text.count > 5000 { // Arbitrary token limit simulation
            throw TextGenerationError.contentTooLong
        }
        if Bool.random() && text.contains("error") { // Simulate random failure
            throw TextGenerationError.generationFailed("Internal model error.")
        }

        // Simple mock summarization logic (replace with actual AI model call)
        let baseSummary = "Here's a summary of '\(text.prefix(50))...': "
        if let customPrompt = prompt {
            return "\(baseSummary) Based on your request: \(customPrompt) The key points are: [Mock AI Summary based on prompt]"
        } else {
            return "\(baseSummary) The main points are: [Mock AI Summary]"
        }
    }
}

// MARK: - App Intent Implementation

@available(iOS 18.0, macOS 15.0, *)
struct SummarizeNoteIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize Note"
    static var description = IntentDescription("Summarizes a specific note by its title using Apple Intelligence.")
    static var openAppWhenRun: Bool = false // Can be true if you want to open the app

    @Parameter(title: "Note Title", description: "The title of the note to summarize.")
    var noteTitle: String

    init() {} // Default initializer for AppIntents
    init(noteTitle: String) {
        self.noteTitle = noteTitle
    }

    // This method is called when the intent is executed by Siri or Shortcuts.
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        guard let note = NoteStore.shared.getNote(byTitle: noteTitle) else {
            throw AppIntentError.noteNotFound(noteTitle: noteTitle)
        }

        do {
            let summary = try await TextGenerationService.shared.generateSummary(for: note.content)
            return .result(value: summary, dialog: "Here's the summary for '\(note.title)': \(summary)")
        } catch let error as TextGenerationService.TextGenerationError {
            throw AppIntentError.summarizationFailed(reason: error.description)
        } catch {
            throw AppIntentError.summarizationFailed(reason: "An unexpected error occurred during summarization: \(error.localizedDescription)")
        }
    }
}

// MARK: - Custom App Intent Errors

@available(iOS 18.0, macOS 15.0, *)
enum AppIntentError: CustomLocalizedStringResourceConvertible, Error {
    case noteNotFound(noteTitle: String)
    case summarizationFailed(reason: String)

    var localizedStringResource: LocalizedStringResource {
        switch self {
        case .noteNotFound(let title):
            return "Could not find a note with the title '\(title)'."
        case .summarizationFailed(let reason):
            return "Failed to summarize the note: \(reason)"
        }
    }
}
