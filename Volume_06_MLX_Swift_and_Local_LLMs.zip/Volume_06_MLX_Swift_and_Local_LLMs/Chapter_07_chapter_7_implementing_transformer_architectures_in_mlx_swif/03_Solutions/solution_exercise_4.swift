
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import MLX
import MLXNN // For MLXNN.Module, MLXNN.Linear, MLXNN.LayerNorm, MLXNN.Embedding
import MLXOptimizers // For Adam optimizer
import MLXRandom // For mlx.random

// Reusing FeedForward from Exercise 3
@available(iOS 18.0, macOS 15.0, *)
class FeedForward: MLXNN.Module {
    let linear1: MLXNN.Linear
    let linear2: MLXNN.Linear

    init(modelDimension: Int, innerDimension: Int) {
        self.linear1 = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: innerDimension)
        self.linear2 = MLXNN.Linear(inputDimensions: innerDimension, outputDimensions: modelDimension)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        return linear2(mlx.core.gelu(linear1(x)))
    }
}

// Reusing MultiHeadSelfAttention from Exercise 1 (unmasked version for encoder)
@available(iOS 18.0, macOS 15.0, *)
class MultiHeadSelfAttention: MLXNN.Module {
    let queryProjection: MLXNN.Linear
    let keyProjection: MLXNN.Linear
    let valueProjection: MLXNN.Linear
    let outputProjection: MLXNN.Linear
    let numHeads: Int
    let headDimension: Int

    init(modelDimension: Int, numHeads: Int, keyQueryValueBias: Bool = true) {
        precondition(modelDimension % numHeads == 0, "modelDimension must be divisible by numHeads")
        self.numHeads = numHeads
        self.headDimension = modelDimension / numHeads

        self.queryProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension, bias: keyQueryValueBias)
        self.keyProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension, bias: keyQueryValueBias)
        self.valueProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension, bias: keyQueryValueBias)
        self.outputProjection = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        let batchSize = x.shape[0]
        let sequenceLength = x.shape[1]

        let q = queryProjection(x)
        let k = keyProjection(x)
        let v = valueProjection(x)

        let q_heads = q.reshaped([batchSize, sequenceLength, numHeads, headDimension]).transposed(0, 2, 1, 3)
        let k_heads = k.reshaped([batchSize, sequenceLength, numHeads, headDimension]).transposed(0, 2, 1, 3)
        let v_heads = v.reshaped([batchSize, sequenceLength, numHeads, headDimension]).transposed(0, 2, 1, 3)

        let scores = mlx.core.matmul(q_heads, k_heads.transposed(0, 1, 3, 2))
        let scaledScores = scores / MLXArray(Float(headDimension).squareRoot())

        let attentionWeights = mlx.core.softmax(scaledScores, axis: -1)
        let outputHeads = mlx.core.matmul(attentionWeights, v_heads)

        let concatenatedOutput = outputHeads.transposed(0, 2, 1, 3).reshaped([batchSize, sequenceLength, numHeads * headDimension])
        let finalOutput = outputProjection(concatenatedOutput)

        return finalOutput
    }
}

@available(iOS 18.0, macOS 15.0, *)
class TransformerEncoderBlock: MLXNN.Module {
    let selfAttention: MultiHeadSelfAttention // Encoder uses unmasked attention
    let norm1: MLXNN.LayerNorm
    let feedForward: FeedForward
    let norm2: MLXNN.LayerNorm

    init(modelDimension: Int, numHeads: Int, innerDimension: Int) {
        self.selfAttention = MultiHeadSelfAttention(modelDimension: modelDimension, numHeads: numHeads)
        self.norm1 = MLXNN.LayerNorm(dimensions: modelDimension)
        self.feedForward = FeedForward(modelDimension: modelDimension, innerDimension: innerDimension)
        self.norm2 = MLXNN.LayerNorm(dimensions: modelDimension)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // First sub-layer: LayerNorm -> Self-Attention -> Residual Connection
        var output = norm1(x)
        output = output + selfAttention(output) // Skip connection

        // Second sub-layer: LayerNorm -> Feed-Forward -> Residual Connection
        output = norm2(output)
        output = output + feedForward(output) // Skip connection

        return output
    }
}

// Reusing SinusoidalPositionalEncoding from Exercise 2
@available(iOS 18.0, macOS 15.0, *)
class SinusoidalPositionalEncoding: MLXNN.Module {
    let positionalEncoding: MLXArray

    init(maxSequenceLength: Int, modelDimension: Int) {
        let positions = mlx.core.arange(0, maxSequenceLength, dtype: MLXArray.DType.float32)
        let indices = mlx.core.arange(0, modelDimension, step: 2, dtype: MLXArray.DType.float32)
        let divTerm = mlx.core.power(MLXArray(10000.0), indices / MLXArray(Float(modelDimension)))

        let positionsExpanded = positions.expandedDimensions(axes: [1])
        let divTermExpanded = divTerm.expandedDimensions(axes: [0])
        let arg = positionsExpanded / divTermExpanded

        var pe = MLXArray.zeros([maxSequenceLength, modelDimension], dtype: MLXArray.DType.float32)
        pe[0 ..< maxSequenceLength, 0 ..< modelDimension, step: 2] = mlx.core.sin(arg)
        pe[0 ..< maxSequenceLength, 1 ..< modelDimension, step: 2] = mlx.core.cos(arg)

        self.positionalEncoding = pe
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        let currentSequenceLength = x.shape[1]
        let currentPE = positionalEncoding[0 ..< currentSequenceLength]
        return x + currentPE
    }
}


@available(iOS 18.0, macOS 15.0, *)
class CustomTransformerEncoder: MLXNN.Module {
    let positionalEncoding: SinusoidalPositionalEncoding
    let encoderBlocks: [TransformerEncoderBlock]

    init(numLayers: Int, modelDimension: Int, numHeads: Int, innerDimension: Int, maxSequenceLength: Int) {
        self.positionalEncoding = SinusoidalPositionalEncoding(maxSequenceLength: maxSequenceLength, modelDimension: modelDimension)
        // Create an array of TransformerEncoderBlock instances
        self.encoderBlocks = (0..<numLayers).map { _ in
            TransformerEncoderBlock(modelDimension: modelDimension, numHeads: numHeads, innerDimension: innerDimension)
        }
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // x is assumed to be already embedded: [batchSize, sequenceLength, modelDimension]
        var output = positionalEncoding(x) // Add positional information
        for block in encoderBlocks {
            output = block(output) // Pass through each encoder block
        }
        return output
    }
}

@available(iOS 18.0, macOS 15.0, *)
class SentimentClassifier: MLXNN.Module {
    let embedding: MLXNN.Embedding
    let encoder: CustomTransformerEncoder
    let classifierHead: MLXNN.Linear
    let numClasses: Int

    init(vocabSize: Int, modelDimension: Int, numHeads: Int, innerDimension: Int, numEncoderLayers: Int, maxSequenceLength: Int, numClasses: Int) {
        self.embedding = MLXNN.Embedding(outputDimensions: modelDimension, inputDimensions: vocabSize)
        self.encoder = CustomTransformerEncoder(numLayers: numEncoderLayers, modelDimension: modelDimension, numHeads: numHeads, innerDimension: innerDimension, maxSequenceLength: maxSequenceLength)
        self.classifierHead = MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: numClasses)
        self.numClasses = numClasses
        super.init()
    }

    override func callAsFunction(_ tokenIDs: MLXArray) -> MLXArray {
        // tokenIDs: [batchSize, sequenceLength]
        let embedded = embedding(tokenIDs) // Convert token IDs to embeddings
        let encoded = encoder(embedded)    // Process embeddings through the Transformer Encoder

        // For sentiment classification, we typically aggregate the sequence output.
        // A common strategy is to take the representation of a special [CLS] token (if used)
        // or to mean-pool across the sequence dimension. Here, we mean-pool.
        let pooledOutput = mlx.core.mean(encoded, axis: 1) // [batchSize, modelDimension]
        let logits = classifierHead(pooledOutput)          // Project to sentiment classes
        return logits
    }
}

// --- Fine-tuning Loop Example ---
@available(iOS 18.0, macOS 15.0, *)
func runSentimentFineTuning() {
    let vocabSize = 100 // Example vocabulary size
    let modelDimension = 128
    let numHeads = 8
    let innerDimension = 256
    let numEncoderLayers = 2
    let maxSequenceLength = 20
    let numClasses = 2 // e.g., Positive/Negative
    let learningRate: Float = 1e-4
    let numIterations = 500
    let batchSize = 16

    // 1. Model Initialization
    let model = SentimentClassifier(
        vocabSize: vocabSize,
        modelDimension: modelDimension,
        numHeads: numHeads,
        innerDimension: innerDimension,
        numEncoderLayers: numEncoderLayers,
        maxSequenceLength: maxSequenceLength,
        numClasses: numClasses
    )

    // Simulate loading a pre-trained embedding. In a real scenario, you would
    // load actual weights into `model.embedding`. For this exercise, we initialize
    // it randomly and then proceed to fine-tune it along with the encoder.
    // If you wanted to freeze a layer, you would not include its parameters in the `grads` map.

    let optimizer = MLXOptimizers.Adam(learningRate: learningRate)

    // 2. Synthetic Data Generation
    func generateSentimentBatch(batchSize: Int, sequenceLength: Int, vocabSize: Int, numClasses: Int) -> (MLXArray, MLXArray) {
        var inputs: [MLXArray] = []
        var targets: [MLXArray] = []

        for _ in 0..<batchSize {
            // Random sequence of token IDs
            let sequence = mlx.random.randint(low: 0, high: vocabSize, shape: [sequenceLength], key: mlx.random.key())
            inputs.append(sequence)

            // Random sentiment label
            let label = mlx.random.randint(low: 0, high: numClasses, shape: [], key: mlx.random.key())
            targets.append(label)
        }
        return (mlx.core.stack(inputs), mlx.core.stack(targets))
    }

    // 3. Loss and Gradient Function for Selective Fine-tuning
    func lossAndGradient(model: SentimentClassifier, inputs: MLXArray, targets: MLXArray) -> (MLXArray, MLX.Core.mlx_array_from_map) {
        // Define the loss calculation closure for `mlx.core.grad`
        let lossFn = { (m: SentimentClassifier, x: MLXArray, y: MLXArray) -> MLXArray in
            let logits = m(x)
            return mlx.core.losses.cross_entropy(logits: logits, targets: y, reduction: .mean)
        }

        // Compute gradients for all trainable parameters in the model.
        let allGrads = mlx.core.grad(lossFn)(model, inputs, targets)

        // Filter gradients to only include those from the `embedding` layer and the `encoder`.
        // This is how selective fine-tuning is achieved in MLX Swift: by providing a subset
        // of gradients to the optimizer.
        var filteredGrads: MLX.Core.mlx_array_from_map = [:]
        for (name, grad) in allGrads {
            // Parameter names are hierarchical (e.g., "embedding.weight", "encoder.encoderBlocks.0.selfAttention.queryProjection.weight")
            if name.hasPrefix("embedding.") || name.hasPrefix("encoder.") {
                filteredGrads[name] = grad
            }
        }
        
        // Compute the loss separately (or take it from `valueAndGradient` if used directly)
        let logits = model(inputs)
        let loss = mlx.core.losses.cross_entropy(logits: logits, targets: targets, reduction: .mean)

        return (loss, filteredGrads)
    }

    // 4. Training Loop
    print("Starting fine-tuning for SentimentClassifier...")
    model.train() // Ensure model is in training mode

    for i in 0..<numIterations {
        let (inputs, targets) = generateSentimentBatch(batchSize: batchSize, sequenceLength: maxSequenceLength, vocabSize: vocabSize, numClasses: numClasses)

        let (loss, grads) = lossAndGradient(model: model, inputs: inputs, targets: targets)
        
        // The optimizer will only update parameters for which gradients are provided in `grads`.
        // Parameters not present in `grads` (e.g., `classifierHead` parameters) will remain unchanged.
        optimizer.update(model: model, gradients: grads)
        
        // Explicitly evaluating `loss` triggers the computation graph execution.
        if i % 50 == 0 {
            print("Fine-tuning Iteration \(i), Loss: \(loss.item(Float.self))")
        }
    }
    print("Fine-tuning complete.")

    // 5. Inference Example
    model.eval() // Set model to evaluation mode
    // Example test sentence (token IDs)
    let testSentence = mlx.core.array([10, 25, 5, 80, 15], dtype: MLXArray.DType.int32)
        .padded(to: [maxSequenceLength], value: 0) // Pad to max length if shorter
        .expandedDimensions(axes: [0]) // Add batch dimension [1, maxSequenceLength]

    print("\nTest sentence (token IDs): \(testSentence.description)")

    let logits = model(testSentence)
    let probabilities = mlx.core.softmax(logits, axis: -1)
    let predictedClass = mlx.core.argmax(probabilities, axis: -1).item(Int.self)

    print("Predicted probabilities: \(probabilities.description)")
    print("Predicted sentiment class: \(predictedClass) (0: Negative, 1: Positive)")
    
    // The 'zero-copy' benefit of Unified Memory is paramount here.
    // The embedding table, even if large, and the encoder's parameters are co-located
    // with the input `MLXArray`s in the same memory pool. This means that during
    // both the forward and backward passes (fine-tuning) and inference,
    // there are no expensive memory copies between CPU and GPU, leading to
    // significantly faster and more energy-efficient execution on Apple Silicon.
}

// Uncomment to run the fine-tuning and inference example:
// runSentimentFineTuning()
