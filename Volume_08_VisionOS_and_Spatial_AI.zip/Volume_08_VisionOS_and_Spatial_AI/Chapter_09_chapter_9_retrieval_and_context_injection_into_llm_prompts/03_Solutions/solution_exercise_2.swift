
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

@available(iOS 18.0, *)
struct Ingredient: Codable {
    let name: String
    let quantity: String
}

@available(iOS 18.0, *)
class PromptBuilder {
    private let systemTemplate: String
    private let constraintReinforcement = "\n\nSTRICT CONSTRAINT: Do not suggest any ingredients not listed above. If a recipe requires an ingredient not in the list, omit it or suggest a substitute only if it is also in the list."
    
    init(systemTemplate: String) {
        self.systemTemplate = systemTemplate
    }
    
    func buildPrompt(ingredients: [Ingredient], userQuery: String) -> String {
        // 1. Convert ingredients to a clean, readable comma-separated string
        // Format: "2 Eggs, 500ml Milk, 1 tsp Salt"
        let ingredientList = ingredients
            .map { "\($0.quantity) \($0.name)" }
            .joined(separator: ", ")
        
        // 2. Perform placeholder replacement
        // We use a simple replacement strategy for {{ingredients}} and {{query}}
        var prompt = systemTemplate
            .replacingOccurrences(of: "{{ingredients}}", with: ingredientList)
            .replacingOccurrences(of: "{{query}}", with: userQuery)
        
        // 3. Append strict constraints to anchor the LLM (Grounding)
        prompt += constraintReinforcement
        
        return prompt
    }
}

// Example Usage:
// let builder = PromptBuilder(systemTemplate: "You are a chef. Pantry: {{ingredients}}. Task: {{query}}.")
// let prompt = builder.buildPrompt(ingredients: [Ingredient(name: "Eggs", quantity: "2")], userQuery: "Omelette")
