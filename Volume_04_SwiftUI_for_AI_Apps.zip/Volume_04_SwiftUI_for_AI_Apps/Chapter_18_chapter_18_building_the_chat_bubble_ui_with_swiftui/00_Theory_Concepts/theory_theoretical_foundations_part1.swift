
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation
import SwiftUI // For @MainActor, though not strictly part of @Observable itself

@available(iOS 17.0, *)
@Observable
final class ChatViewModel {
    var messages: [ChatMessage] = [] // Holds all chat messages
    var currentAIMessageContent: String = "" // Content of the message currently being streamed by AI
    var isLoading: Bool = false // Indicates if AI is generating a response

    // Represents a single message in the chat
    struct ChatMessage: Identifiable, Hashable {
        let id = UUID()
        let content: String
        let isUser: Bool
    }

    // Function to simulate appending streamed tokens
    // In a real app, this would be called from an async task consuming an AsyncSequence
    @MainActor // Ensure UI updates happen on the main thread
    func appendToken(_ token: String) {
        currentAIMessageContent += token
    }

    @MainActor
    func startNewAIMessage() {
        isLoading = true
        currentAIMessageContent = ""
        // Add a placeholder message or similar
    }

    @MainActor
    func finishAIMessage() {
        if !currentAIMessageContent.isEmpty {
            messages.append(ChatMessage(content: currentAIMessageContent, isUser: false))
        }
        currentAIMessageContent = ""
        isLoading = false
    }

    @MainActor
    func addUserMessage(_ content: String) {
        messages.append(ChatMessage(content: content, isUser: true))
    }
}
