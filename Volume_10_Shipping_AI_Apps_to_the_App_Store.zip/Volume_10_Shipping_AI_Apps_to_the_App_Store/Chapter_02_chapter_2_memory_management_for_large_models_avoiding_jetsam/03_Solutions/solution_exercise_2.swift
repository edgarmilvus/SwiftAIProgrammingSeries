
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import UIKit

/// A node for the doubly-linked list used in LRU eviction.
final class CacheNode: Sendable {
    let key: String
    let value: [Float]
    let byteSize: Int
    
    // We use UnsafeMutablePointer to implement a manual doubly-linked list 
    // within an actor to avoid complex reference counting issues with 'self'.
    // However, for this exercise, we will use a standard class-based approach
    // and ensure the Actor manages the synchronization.
    var prev: CacheNode?
    var next: CacheNode?

    init(key: String, value: [Float], byteSize: Int) {
        self.key = key
        self.value = value
        self.byteSize = byteSize
    }
}

// Since CacheNode has mutable properties (prev/next), it cannot be Sendable.
// We will use a private internal class and manage it strictly inside the Actor.
private class LRUNode {
    let key: String
    let value: [Float]
    let byteSize: Int
    var prev: LRUNode?
    var next: LRUNode?

    init(key: String, value: [Float], byteSize: Int) {
        self.key = key
        self.value = value
        self.byteSize = byteSize
    }
}

actor EmbeddingCache {
    private var cache: [String: LRUNode] = [:]
    private var head: LRUNode?
    private var tail: LRUNode?
    
    private(set) var currentByteSize: Int = 0
    private let maxByteSize: Int
    
    init(maxByteSize: Int) {
        self.maxByteSize = maxByteSize
        
        // Listen for memory warnings to purge cache
        NotificationCenter.default.addObserver(
            forName: UIApplication.didReceiveMemoryWarningNotification,
            object: nil,
            queue: .main
        ) { _ in
            Task { [weak self] in
                await self?.purgeHalf()
            }
        }
    }

    func insert(key: String, vector: [Float]) {
        let size = estimateByteSize(vector)
        
        // If the single item is larger than the whole cache, don't cache it
        guard size <= maxByteSize else { return }

        // Remove existing if present
        if let existing = cache[key] {
            removeNode(existing)
        }

        // Evict until we have space
        while currentByteSize + size > maxByteSize, let last = tail {
            evict(last)
        }

        let newNode = LRUNode(key: key, value: vector, byteSize: size)
        addAtHead(newNode)
        cache[key] = newNode
        currentByteSize += size
    }

    func get(key: String) -> [Float]? {
        guard let node = cache[key] else { return nil }
        
        // Move to head (Most Recently Used)
        removeNode(node)
        addAtHead(node)
        
        return node.value
    }

    private func purgeHalf() {
        var itemsToPurge = 0
        let targetCount = cache.count / 2
        
        while itemsToPurge < targetCount, let last = tail {
            evict(last)
            itemsToPurge += 1
        }
    }

    // MARK: - Private Helpers

    private func estimateByteSize(_ vector: [Float]) -> Int {
        // Array overhead + (count * 4 bytes per Float)
        return MemoryLayout<[Float]>.stride + (vector.count * MemoryLayout<Float>.stride)
    }

    private func addAtHead(_ node: LRUNode) {
        node.next = head
        node.prev = nil
        head?.prev = node
        head = node
        if tail == nil { tail = node }
    }

    private func removeNode(_ node: LRUNode) {
        if node === head { head = node.next }
        if node === tail { tail = node.prev }
        
        node.prev?.next = node.next
        node.next?.prev = node.prev
        
        node.prev = nil
        node.next = nil
    }

    private func evict(_ node: LRUNode) {
        removeNode(node)
        cache.removeValue(forKey: node.key)
        currentByteSize -= node.byteSize
    }
}
