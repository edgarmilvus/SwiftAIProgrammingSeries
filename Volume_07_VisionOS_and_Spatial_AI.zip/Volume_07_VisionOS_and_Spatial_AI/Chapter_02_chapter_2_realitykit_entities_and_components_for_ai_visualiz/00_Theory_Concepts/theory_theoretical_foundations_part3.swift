
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import RealityKit
    import Combine

    // A system to visualize detected objects
    @available(iOS 18.0, *)
    struct ObjectVisualizationSystem: System {
        static let query = EntityQuery(where: .has(ObjectDetectionComponent.self))
        private var cancellables: Set<AnyCancellable> = []

        init(scene: RealityKit.Scene) {
            // Register for component changes if needed, or simply run per frame
        }

        func update(context: SceneUpdateContext) {
            // Iterate over all entities that have an ObjectDetectionComponent
            for entity in context.scene.performQuery(Self.query) {
                guard let detectionComponent = entity.components[ObjectDetectionComponent.self] else { continue }

                // Retrieve or create a visual representation for the detection
                if let visualizationModel = entity.findEntity(named: "DetectionVisual_\(entity.id)") as? ModelEntity {
                    // Update existing visualization based on new detection data
                    updateVisualization(visualizationModel, with: detectionComponent)
                } else {
                    // Create new visualization
                    let newVisualization = createVisualization(for: detectionComponent)
                    newVisualization.name = "DetectionVisual_\(entity.id)"
                    entity.addChild(newVisualization)
                }
            }
        }

        private func createVisualization(for detection: ObjectDetectionComponent) -> ModelEntity {
            // Example: Create a simple red box
            let mesh = MeshResource.generateBox(size: 0.1) // Placeholder size
            let material = SimpleMaterial(color: .red, is
            Metallic: false)
            let model = ModelEntity(mesh: mesh, materials: [material])
            // Position and scale based on detection.boundingBox (requires conversion from normalized to world space)
            // This logic would be more complex in a real scenario
            model.scale = SIMD3<Float>(detection.boundingBox.z, detection.boundingBox.w, 0.01) // Width, Height, Depth
            model.position = SIMD3<Float>(detection.boundingBox.x, detection.boundingBox.y, 0)
            return model
        }

        private func updateVisualization(_ model: ModelEntity, with detection: ObjectDetectionComponent) {
            // Update position, scale, color, or text of the model
            model.scale = SIMD3<Float>(detection.boundingBox.z, detection.boundingBox.w, 0.01)
            model.position = SIMD3<Float>(detection.boundingBox.x, detection.boundingBox.y, 0)
            // Potentially update material color based on confidence or label
        }
    }

    // Register the system in your app's setup
    @available(iOS 18.0, *)
    func setupRealityKitScene(arView: ARView) {
        // Ensure systems are registered before scene updates begin
        ObjectVisualizationSystem.registerSystem()
        // ... add AR content ...
    }
    