
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN

@available(iOS 18.0, *)
final class SimpleMLP: MLXNN.Module {
    let linear1: MLXNN.Linear
    let linear2: MLXNN.Linear

    init(inputSize: Int, hiddenSize: Int, outputSize: Int) {
        self.linear1 = MLXNN.Linear(inputSize, hiddenSize)
        self.linear2 = MLXNN.Linear(hiddenSize, outputSize)
        super.init() // Call super.init() after all properties are initialized
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        let x = MLX.relu(linear1(input))
        return linear2(x)
    }
}

// Example usage
@available(iOS 18.0, *)
func demonstrateMLP() {
    let model = SimpleMLP(inputSize: 10, hiddenSize: 20, outputSize: 2)
    let inputData = MLXArray.randomUniform(low: 0, high: 1, [1, 10]) // Batch size 1, 10 features
    let output = model(inputData)
    print("Model output shape: \(output.shape)") // e.g., [1, 2]
}
