
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN
import Foundation

// @available(iOS 18.0, *)
// func defineCustomModule() {
final class MySimpleMLP: MLXNN.Module, Sendable {
    let linear1: MLXNN.Linear
    let linear2: MLXNN.Linear

    required init() {
        // Define layers. MLXNN.Linear is also an MLXNN.Module.
        self.linear1 = MLXNN.Linear(inputFeatures: 10, outputFeatures: 5)
        self.linear2 = MLXNN.Linear(inputFeatures: 5, outputFeatures: 1)
        super.init() // Call super.init() after all properties are initialized
    }

    // Define the forward pass using callAsFunction
    func callAsFunction(_ x: MLXArray) -> MLXArray {
        let h = MLX.relu(linear1(x)) // First layer with ReLU activation
        return linear2(h)            // Second layer
    }
}

let model = MySimpleMLP()
print("Model parameters: \(model.parameters().keys)")
// Example output: Model parameters: ["linear1.weight", "linear1.bias", "linear2.weight", "linear2.bias"]

let dummyInput = MLXArray.rand([1, 10]) // Batch size 1, 10 input features
let output = model(dummyInput)
print("Output shape: \(output.shape)") // Output shape: [1, 1]
// }
