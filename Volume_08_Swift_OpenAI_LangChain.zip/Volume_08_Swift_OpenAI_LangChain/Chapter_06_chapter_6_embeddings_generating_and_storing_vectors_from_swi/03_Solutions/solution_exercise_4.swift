
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

struct SearchResult: Sendable {
    let id: UUID
    let text: String
}

class HybridSearchService {
    private let semanticStore: SemanticJournalStore
    private let kConstant: Float = 60.0

    init(semanticStore: SemanticJournalStore) {
        self.semanticStore = semanticStore
    }

    /// Combines keyword matching and semantic similarity using RRF.
    func hybridSearch(query: String, queryVector: Vector, allEntries: [JournalEntry]) async throws -> [SearchResult] {
        
        // 1. Lexical Search (Keyword matching)
        let lexicalResults = allEntries.enumerated().compactMap { (index, entry) -> (UUID, Int)? in
            let words = query.lowercased().components(separatedBy: .whitespaces)
            let matchCount = words.filter { entry.text.lowercased().contains($0) }.count
            return matchCount > 0 ? (entry.id, index + 1) : nil
        }

        // 2. Semantic Search
        let semanticResults = try await semanticStore.search(queryVector: queryVector, limit: 100)
        let semanticRanked = semanticResults.enumerated().map { (index, result) in
            (result.entry.id, index + 1)
        }

        // 3. Reciprocal Rank Fusion (RRF)
        // Score(d) = Sum( 1 / (k + rank) )
        var scores: [UUID: Float] = [:]

        for (id, rank) in lexicalResults {
            scores[id, default: 0] += 1.0 / (kConstant + Float(rank))
        }

        for (id, rank) in semanticRanked {
            scores[id, default: 0] += 1.0 / (kConstant + Float(rank))
        }

        // 4. Re-rank and Map to SearchResult
        let sortedIDs = scores.sorted { $0.value > $1.value }.map { $0.key }
        
        // Map IDs back to actual content
        let finalResults = sortedIDs.compactMap { id -> SearchResult? in
            guard let entry = allEntries.first(where: { $0.id == id }) else { return nil }
            return SearchResult(id: entry.id, text: entry.text)
        }

        return finalResults
    }
}
