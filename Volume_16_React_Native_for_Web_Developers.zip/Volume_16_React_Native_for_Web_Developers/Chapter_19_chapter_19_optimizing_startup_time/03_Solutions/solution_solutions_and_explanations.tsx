/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// components/HeavyChart.tsx
'use client';

import React from 'react';

// Define props for the heavy component
interface HeavyChartProps {
  data: Array<{ label: string; value: number }>;
}

export default function HeavyChart({ data }: HeavyChartProps) {
  // Simulate a heavy component that might throw an error during rendering
  // or depends on a large library.
  return (
    <div style={{ border: '1px solid #ccc', padding: '1rem', marginTop: '1rem' }}>
      <h2>Heavy Chart Visualization</h2>
      <ul>
        {data.map((item, index) => (
          <li key={index}>
            {item.label}: {item.value}
          </li>
        ))}
      </ul>
    </div>
  );
}

// components/ErrorBoundary.tsx
'use client';

import React from 'react';

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    // Update state so the next render will show the fallback UI
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Log the error to an error reporting service
    console.error("Error caught by boundary:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '1rem', backgroundColor: '#ffebee', color: '#c62828' }}>
          <h2>Something went wrong loading the chart.</h2>
          <button onClick={() => this.setState({ hasError: false })}>
            Try Again
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

// components/Dashboard.tsx
'use client';

import React, { Suspense, useState } from 'react';
import { ErrorBoundary } from './ErrorBoundary';

// 1. Define the Lazy Loaded Component
// We use a dynamic import. In a real app, this might be a heavy library like 'recharts' or 'chart.js'
const HeavyChart = React.lazy(() => import('./HeavyChart'));

export default function Dashboard() {
  const [showChart, setShowChart] = useState(false);

  return (
    <div>
      <h1>Dashboard</h1>
      <button onClick={() => setShowChart(true)}>Load Chart</button>

      {/* 2. Implement Suspense and Error Boundary */}
      {/* The Error Boundary wraps the Suspense boundary to catch both loading errors 
          (network failures) and runtime errors in the component. */}
      <ErrorBoundary>
        <Suspense fallback={<div>Loading chart data...</div>}>
          {showChart && (
            <HeavyChart 
              data={[
                { label: 'Sales', value: 100 },
                { label: 'Revenue', value: 250 },
              ]} 
            />
          )}
        </Suspense>
      </ErrorBoundary>
    </div>
  );
}
