/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/middleware.ts
import { router, MiddlewareConfig } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Mock Auth Store Check
async function isAuthenticated(): Promise<boolean> {
  try {
    const token = await AsyncStorage.getItem('user_token');
    return token !== null;
  } catch (e) {
    return false;
  }
}

export const middleware: MiddlewareConfig = async (ev) => {
  // Prevent infinite loops by checking if we are already redirecting
  if (ev.action === 'REPLACE') return;

  const authed = await isAuthenticated();
  const path = ev.pathname;

  // Scenario 1: Unauthenticated user trying to access Dashboard
  if (path.startsWith('/dashboard') && !authed) {
    ev.preventDefault();
    router.replace('/login');
    return;
  }

  // Scenario 2: Authenticated user trying to access Login
  if (path === '/login' && authed) {
    ev.preventDefault();
    router.replace('/dashboard');
    return;
  }
};

// Optional: Configure specific routes to run middleware on
export const config: MiddlewareConfig = {
  matcher: ['/dashboard', '/login'],
};
