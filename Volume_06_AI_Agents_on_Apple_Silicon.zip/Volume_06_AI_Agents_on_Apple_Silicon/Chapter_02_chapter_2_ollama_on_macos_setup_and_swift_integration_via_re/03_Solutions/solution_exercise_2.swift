
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

// MARK: - Codable Structures

/// Represents details of a single Ollama model.
struct OllamaModel: Codable, Identifiable {
    let id = UUID() // Useful for SwiftUI List/Identifiable protocol
    let name: String
    let modifiedAt: String // e.g., "2024-04-29T18:03:59.083756Z"
    let size: Int // Size in bytes
    let digest: String
    let details: ModelDetails // Nested structure for more info

    // Custom CodingKeys to map snake_case JSON keys to camelCase Swift properties
    enum CodingKeys: String, CodingKey {
        case name
        case modifiedAt = "modified_at"
        case size
        case digest
        case details
    }

    struct ModelDetails: Codable {
        let parentModel: String? // e.g., "llama3:8b-instruct-q4_0"
        let format: String // e.g., "gguf"
        let family: String // e.g., "llama"
        let families: [String]? // e.g., ["llama"]
        let parameterSize: String // e.g., "8B"
        let quantizationLevel: String // e.g., "Q4_0"

        enum CodingKeys: String, CodingKey {
            case parentModel = "parent_model"
            case format
            case family
            case families
            case parameterSize = "parameter_size"
            case quantizationLevel = "quantization_level"
        }
    }

    /// Helper to convert byte size to a human-readable format.
    var humanReadableSize: String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        return formatter.string(fromByteCount: Int64(size))
    }
}

/// Represents the overall response from the /api/tags endpoint.
struct ModelsResponse: Codable {
    let models: [OllamaModel]
}

// MARK: - Ollama Service (Extension for Model Inventory)

extension OllamaService {
    /// Fetches a list of all available local Ollama models.
    /// - Returns: An array of `OllamaModel` objects.
    /// - Throws: `OllamaError` if the request fails or decoding is unsuccessful.
    func fetchAvailableModels() async throws -> [OllamaModel] {
        guard let url = URL(string: "\(baseURLString)/api/tags") else {
            throw OllamaError.invalidURL
        }

        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET" // GET request for /api/tags

        let (data, response) = try await session.data(for: urlRequest)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw OllamaError.networkError(URLError(.badServerResponse))
        }

        guard (200...299).contains(httpResponse.statusCode) else {
            if let apiError = try? JSONDecoder().decode(OllamaAPIError.self, from: data) {
                throw OllamaError.apiError(apiError.error)
            }
            throw OllamaError.invalidHTTPResponse(httpResponse.statusCode)
        }

        do {
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let modelsResponse = try decoder.decode(ModelsResponse.self, from: data)
            return modelsResponse.models
        } catch {
            throw OllamaError.decodingError(error)
        }
    }
}

// MARK: - Example Usage (Conceptual UI interaction)

@MainActor
func runModelInventoryExample() async {
    let ollamaService = OllamaService()

    print("--- Local AI Model Inventory ---")

    do {
        print("Fetching available models...")
        let models = try await ollamaService.fetchAvailableModels()

        if models.isEmpty {
            print("No models found locally. Please pull some models (e.g., `ollama pull llama3`).")
        } else {
            print("\nAvailable Models:")
            for model in models.sorted(by: { $0.name < $1.name }) {
                print("  - Name: \(model.name)")
                print("    Size: \(model.humanReadableSize) (\(model.size) bytes)")
                print("    Family: \(model.details.family)")
                print("    Quantization: \(model.details.quantizationLevel)")
                print("    Digest: \(model.digest)")
                print("    Last Modified: \(model.modifiedAt)")
                print("    ---")
            }
        }
    } catch {
        print("\nError fetching models: \(error.localizedDescription)")
        if let ollamaError = error as? OllamaError {
            print("Detailed Error: \(ollamaError.errorDescription ?? "Unknown Ollama Error")")
        }
    }
    print("--------------------------------")
}

// To run this example in a Playground or a Swift application:
// Task {
//     await runModelInventoryExample()
// }
