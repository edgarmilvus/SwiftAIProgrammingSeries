
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// MARK: - Utility Extensions (Place in a separate file in a real project)
import UIKit
import CoreVideo
import CoreGraphics
import CoreImage // For CVPixelBuffer to UIImage and Core Image filters

// UIImage+toCVPixelBuffer (from Exercise 1)
extension UIImage {
    func toCVPixelBuffer(pixelFormatType: OSType = kCVPixelFormatType_32BGRA, width: Int? = nil, height: Int? = nil) -> CVPixelBuffer? {
        let imageWidth = width ?? Int(self.size.width)
        let imageHeight = height ?? Int(self.size.height)

        var pixelBuffer: CVPixelBuffer?
        let attributes: [String: Any] = [
            kCVPixelBufferCGImageCompatibilityKey as String: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey as String: true,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]

        CVPixelBufferCreate(kCFAllocatorDefault,
                            imageWidth,
                            imageHeight,
                            pixelFormatType,
                            attributes as CFDictionary,
                            &pixelBuffer)

        guard let buffer = pixelBuffer else { return nil }

        CVPixelBufferLockBaseAddress(buffer, .zero)
        defer { CVPixelBufferUnlockBaseAddress(buffer, .zero) }

        let pixelData = CVPixelBufferGetBaseAddress(buffer)
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: pixelData,
                                width: imageWidth,
                                height: imageHeight,
                                bitsPerComponent: 8,
                                bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
                                space: rgbColorSpace,
                                bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue)

        context?.translateBy(x: 0, y: CGFloat(imageHeight))
        context?.scaleBy(x: 1.0, y: -1.0)

        UIGraphicsPushContext(context!)
        self.draw(in: CGRect(x: 0, y: 0, width: CGFloat(imageWidth), height: CGFloat(imageHeight)))
        UIGraphicsPopContext()

        return buffer
    }
}

// CVPixelBuffer+toUIImage (from Exercise 4 - pre-analysis)
extension CVPixelBuffer {
    func toUIImage() -> UIImage? {
        let ciImage = CIImage(cvPixelBuffer: self)
        let context = CIContext()
        guard let cgImage = context.createCGImage(ciImage, from: ciImage.extent) else { return nil }
        return UIImage(cgImage: cgImage)
    }
}

// MARK: - ViewController (Assumes a basic iOS project with a ViewController)
import UIKit
import Vision
import CoreImage // For image processing and filters

// Assume 'HumanSegmenterModel' is the name of your Core ML model file.
// For this example, let's assume the model expects 512x512 input and outputs a 1-channel CVPixelBuffer
// with raw logits (or probabilities).
// The output pixel format might be kCVPixelFormatType_OneComponent8 or kCVPixelFormatType_OneComponentF.
// We'll assume kCVPixelFormatType_OneComponent8 for simplicity, representing 0-255 values (0=background, 255=person).

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    // MARK: - UI Elements
    private let originalImageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.backgroundColor = .systemGray5
        iv.layer.cornerRadius = 8
        iv.clipsToBounds = true
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let processedImageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.backgroundColor = .systemGray5
        iv.layer.cornerRadius = 8
        iv.clipsToBounds = true
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let selectImageButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Select Image", for: .normal)
        button.titleLabel?.font = .preferredFont(forTextStyle: .title3)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let activityIndicator: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.hidesWhenStopped = true
        indicator.translatesAutoresizingMaskIntoConstraints = false
        return indicator
    }()

    private let blurSlider: UISlider = {
        let slider = UISlider()
        slider.minimumValue = 0.0
        slider.maximumValue = 20.0
        slider.value = 5.0 // Default blur radius
        slider.translatesAutoresizingMaskIntoConstraints = false
        return slider
    }()

    private let blurLabel: UILabel = {
        let label = UILabel()
        label.text = "Blur Radius: 5.0"
        label.font = .preferredFont(forTextStyle: .caption1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - Model & Vision Setup
    private var humanSegmenter: VNCoreMLModel?
    private var segmentationRequest: VNCoreMLRequest?
    private let ciContext = CIContext() // Core Image context for rendering

    // Store the original image and its mask for dynamic blur changes
    private var currentOriginalImage: UIImage?
    private var currentSegmentationMask: CIImage?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupModel()
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        let stackView = UIStackView(arrangedSubviews: [originalImageView, processedImageView])
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 10
        stackView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(stackView)
        view.addSubview(selectImageButton)
        view.addSubview(activityIndicator)
        view.addSubview(blurLabel)
        view.addSubview(blurSlider)

        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            stackView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.4), // Adjust height as needed

            blurLabel.topAnchor.constraint(equalTo: stackView.bottomAnchor, constant: 20),
            blurLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            blurSlider.topAnchor.constraint(equalTo: blurLabel.bottomAnchor, constant: 10),
            blurSlider.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            blurSlider.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            selectImageButton.topAnchor.constraint(equalTo: blurSlider.bottomAnchor, constant: 30),
            selectImageButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            selectImageButton.widthAnchor.constraint(equalToConstant: 200),
            selectImageButton.heightAnchor.constraint(equalToConstant: 50),
            selectImageButton.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])

        selectImageButton.addTarget(self, action: #selector(selectImageTapped), for: .touchUpInside)
        blurSlider.addTarget(self, action: #selector(blurSliderChanged), for: .valueChanged)
    }

    private func setupModel() {
        do {
            let model = try HumanSegmenterModel(configuration: MLModelConfiguration())
            humanSegmenter = try VNCoreMLModel(for: model.model)

            segmentationRequest = VNCoreMLRequest(model: humanSegmenter!) { [weak self] request, error in
                self?.processSegmentation(for: request, error: error)
            }
            // For segmentation, .scaleFill might be appropriate if the model expects a fixed size
            // and you want to fill it without letterboxing, potentially distorting the image.
            // Or .scaleFit if you want to preserve aspect ratio and pad.
            // For U-Net, usually a fixed square input is expected.
            segmentationRequest?.imageCropAndScaleOption = .scaleFit
        } catch {
            print("Failed to load Vision ML model: \(error)")
        }
    }

    // MARK: - Image Selection
    @objc private func selectImageTapped() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)

        guard let selectedImage = info[.originalImage] as? UIImage else { return }

        originalImageView.image = selectedImage
        processedImageView.image = nil
        activityIndicator.startAnimating()
        currentOriginalImage = selectedImage // Store original for re-processing
        currentSegmentationMask = nil

        Task {
            await performSegmentationAndBlur(image: selectedImage, blurRadius: blurSlider.value)
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }

    // MARK: - Segmentation and Blurring
    private func performSegmentationAndBlur(image: UIImage, blurRadius: Float) async {
        guard let segmentationRequest = segmentationRequest else {
            await MainActor.run { self.activityIndicator.stopAnimating() }
            return
        }

        guard let cgImage = image.cgImage else {
            await MainActor.run { self.activityIndicator.stopAnimating() }
            return
        }

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        do {
            try handler.perform([segmentationRequest])
        } catch {
            await MainActor.run {
                self.activityIndicator.stopAnimating()
                print("Failed to perform segmentation: \(error)")
            }
        }
    }

    private func processSegmentation(for request: VNRequest, error: Error?) {
        Task { @MainActor in // Ensure UI updates are on the main actor
            activityIndicator.stopAnimating()

            if let error = error {
                print("Segmentation Error: \(error)")
                return
            }

            guard let observations = request.results as? [VNPixelBufferObservation],
                  let segmentationMap = observations.first?.pixelBuffer else {
                print("No segmentation map received.")
                return
            }

            guard let originalImage = currentOriginalImage else { return }

            // CHALLENGE: Custom Post-processing & Core Image Blurring
            // 1. Convert raw segmentation map (CVPixelBuffer) to a CIImage mask
            let maskCIImage = CIImage(cvPixelBuffer: segmentationMap)

            // Resize the mask to match the original image dimensions if necessary
            // Model outputs might be a fixed size (e.g., 512x512) while input image is different.
            let originalImageSize = originalImage.size
            let maskResized = maskCIImage.transformed(by: CGAffineTransform.identity
                                                        .scaledBy(x: originalImageSize.width / maskCIImage.extent.width,
                                                                  y: originalImageSize.height / maskCIImage.extent.height))

            // Store the mask for dynamic blur changes
            currentSegmentationMask = maskResized

            // Apply blur and composite
            let processedImage = await applyBlurAndComposite(
                originalImage: originalImage,
                mask: maskResized,
                blurRadius: blurSlider.value
            )
            processedImageView.image = processedImage
        }
    }

    // MARK: - Core Image Processing
    @MainActor
    private func applyBlurAndComposite(originalImage: UIImage, mask: CIImage, blurRadius: Float) async -> UIImage? {
        guard let originalCIImage = CIImage(image: originalImage) else { return nil }

        // Create a blurred version of the original image
        let blurredImage = originalCIImage.applyingGaussianBlur(radius: blurRadius)

        // Use CIMaskToAlpha to convert the grayscale mask to an alpha mask
        // This is crucial if your model outputs a grayscale image where white=person, black=background
        // and you want to use it as an alpha channel for blending.
        // Assuming mask is 0-1 (or 0-255) where higher value means 'person'.
        // We want the person to be opaque and background transparent, so use the mask directly.
        // If the mask is inverted (e.g., background=1, person=0), you'd use CIColorInvert.
        let alphaMask = mask // Directly use the mask as alpha for blending

        // Composite the original (foreground) onto the blurred (background) using the mask
        // CIBlendWithMask takes:
        // - InputImage: The image to be masked (foreground - original person)
        // - BackgroundImage: The image to blend with (blurred background)
        // - Mask: The alpha mask
        if let blendFilter = CIFilter(name: "CIBlendWithMask") {
            blendFilter.setValue(originalCIImage, forKey: kCIInputImageKey)
            blendFilter.setValue(blurredImage, forKey: kCIInputBackgroundImageKey)
            blendFilter.setValue(alphaMask, forKey: kCIInputMaskImageKey)

            if let outputCIImage = blendFilter.outputImage {
                // Render the final CIImage to a UIImage
                if let cgImage = ciContext.createCGImage(outputCIImage, from: outputCIImage.extent) {
                    return UIImage(cgImage: cgImage)
                }
            }
        }
        return nil
    }

    // MARK: - Dynamic Blur Challenge
    @objc private func blurSliderChanged() {
        let newBlurRadius = blurSlider.value
        blurLabel.text = String(format: "Blur Radius: %.1f", newBlurRadius)

        // Re-apply blur if an image and mask are available
        guard let originalImage = currentOriginalImage,
              let segmentationMask = currentSegmentationMask else { return }

        Task { @MainActor in
            activityIndicator.startAnimating()
            let processedImage = await applyBlurAndComposite(
                originalImage: originalImage,
                mask: segmentationMask,
                blurRadius: newBlurRadius
            )
            processedImageView.image = processedImage
            activityIndicator.stopAnimating()
        }
    }
}
