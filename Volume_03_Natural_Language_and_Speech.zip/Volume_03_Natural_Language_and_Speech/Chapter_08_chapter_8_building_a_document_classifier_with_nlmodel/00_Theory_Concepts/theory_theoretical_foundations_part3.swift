
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import NaturalLanguage

// Requires iOS 17.0+ for @Observable
@available(iOS 18.0, *)
@Observable
class ClassificationViewModel {
    var inputText: String = ""
    var predictedLabel: String?
    var topLabelsWithConfidences: [(label: String, confidence: Double)] = []
    var isClassifying: Bool = false
    var errorMessage: String?

    private let classifierActor = ClassifierActor() // One actor instance for the view model

    @MainActor // Ensure UI updates happen on the main actor
    func performClassification() async {
        guard !inputText.isEmpty else {
            predictedLabel = nil
            topLabelsWithConfidences = []
            errorMessage = "Please enter text to classify."
            return
        }

        isClassifying = true
        errorMessage = nil

        do {
            let label = await classifierActor.classifyAsync(text: inputText)
            let confidences = await classifierActor.classifyWithConfidencesAsync(text: inputText)

            self.predictedLabel = label
            self.topLabelsWithConfidences = confidences
        } catch {
            self.errorMessage = "Classification failed: \(error.localizedDescription)"
        }
        isClassifying = false
    }
}

// A simple SwiftUI view demonstrating usage
@available(iOS 18.0, *)
struct ClassificationView: View {
    @State private var viewModel = ClassificationViewModel()

    var body: some View {
        VStack(spacing: 20) {
            TextField("Enter text to classify", text: $viewModel.inputText, axis: .vertical)
                .textFieldStyle(.roundedBorder)
                .padding()
                .frame(minHeight: 80)
                .border(Color.gray, width: 0.5)

            Button {
                Task {
                    await viewModel.performClassification()
                }
            } label: {
                Text(viewModel.isClassifying ? "Classifying..." : "Classify Text")
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(viewModel.isClassifying ? Color.gray : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .disabled(viewModel.isClassifying || viewModel.inputText.isEmpty)
            .padding(.horizontal)

            if let label = viewModel.predictedLabel {
                Text("Predicted Label: **\(label)**")
                    .font(.title2)
            }

            if !viewModel.topLabelsWithConfidences.isEmpty {
                VStack(alignment: .leading) {
                    Text("Top Confidences:")
                        .font(.headline)
                    ForEach(viewModel.topLabelsWithConfidences, id: \.label) { item in
                        Text("- \(item.label): \(String(format: "%.2f", item.confidence * 100))%")
                    }
                }
            }

            if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
            }

            Spacer()
        }
        .padding()
        .navigationTitle("Document Classifier")
    }
}
