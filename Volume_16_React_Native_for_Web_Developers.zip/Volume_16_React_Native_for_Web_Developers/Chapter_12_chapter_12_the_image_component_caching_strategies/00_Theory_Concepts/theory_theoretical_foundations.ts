/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// A generic definition for an image source
// This allows flexibility while maintaining type safety
type ImageSource<T extends string | number> = {
  uri: T extends string ? T : never; // If it's a string, it's a URI
  width?: number;
  height?: number;
};

// A theoretical generic Image component wrapper
// This enforces that the source matches the expected type structure
function GenericImage<T extends string>(props: {
  source: ImageSource<T>;
  resizeMode?: 'contain' | 'cover';
}) {
  // In a real app, this would bridge to the native Image component
  // Here we demonstrate the type checking logic
  return null; // Placeholder for rendering logic
}

// Usage Example:
// This works because the type is a string
const networkSource: ImageSource<"https://example.com/img.jpg"> = {
  uri: "https://example.com/img.jpg"
};

// This would cause a TypeScript error if uncommented,
// ensuring we don't pass invalid types to the native bridge
// const invalidSource: ImageSource<123> = { uri: 123 };
