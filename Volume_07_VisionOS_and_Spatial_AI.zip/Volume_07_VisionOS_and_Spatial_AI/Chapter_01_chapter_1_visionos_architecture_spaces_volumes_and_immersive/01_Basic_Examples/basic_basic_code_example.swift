
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import RealityKit
import RealityKitContent // Assuming a RealityKit content bundle

// MARK: - App Entry Point

@main
struct SpatialDesignStudioApp: App {
    // We use a StateObject to manage the global state of our spatial experience.
    // This ensures that when we switch from a Window to an Immersive Space,
    // the data (like the selected color) remains consistent.
    @StateObject private var appState = AppState()

    var body: some Scene {
        // 1. THE WINDOW: A standard 2D interface for tool selection.
        WindowGroup(id: "ToolPalette") {
            ToolPaletteView(appState: appState)
        }
        .windowStyle(.automatic)
        .defaultSize(width: 400, height: 500)

        // 2. THE VOLUME: A 3D container to view the model.
        // We use a specific ID so we can call it programmatically.
        WindowGroup(id: "ModelPreview") {
            ModelPreviewView(appState: appState)
        }
        .windowStyle(.volumetric) // CRITICAL: This turns the window into a 3D Volume.
        .defaultSize(width: 0.5, height: 0.5, depth: 0.5) // Dimensions in meters.

        // 3. THE IMMERSIVE SPACE: The full environmental experience.
        ImmersiveSpace(id: "GalleryEnvironment") {
            GalleryEnvironmentView()
        }
    }
}

// MARK: - State Management

/// Manages the shared state across different spatial layers.
/// Using @MainActor ensures all updates happen on the main thread, 
/// which is vital for SwiftUI and RealityKit synchronization.
@MainActor
class AppState: ObservableObject {
    @Published var selectedColor: Color = .blue
    @Published var isImmersiveActive: Bool = false
    
    /// Orchestrates the transition into the immersive environment.
    /// This is an async function because opening a space is an asynchronous system request.
    func enterImmersiveMode(context: <any ScenePresenter>) async {
        // In a real app, you would use the Environment values to trigger this.
        // For this example, we assume the logic is called from a View.
    }
}

// MARK: - 2D Window View

/// A 2D interface for selecting tools and colors.
struct ToolPaletteView: View {
    @ObservedObject var appState: AppState
    @Environment(\.openWindow) private var openWindow
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("Design Studio")
                    .font(.largeTitle)
                
                ColorPicker("Sculpture Color", selection: $appState.selectedColor)
                    .padding()

                Button("Preview in 3D Volume") {
                    // Opens the volumetric window.
                    openWindow(id: "ModelPreview")
                }
                .buttonStyle(.borderedProminent)

                Divider()

                Button(appState.isImmersiveActive ? "Exit Gallery" : "Enter Gallery Mode") {
                    Task {
                        if appState.isImmersiveActive {
                            await dismissImmersiveSpace()
                            appState.isImmersiveActive = false
                        } else {
                            let result = await openImmersiveSpace(id: "GalleryEnvironment")
                            if case .opened = result {
                                appState.isImmersiveActive = true
                            }
                        }
                    }
                }
                .buttonStyle(.bordered)
            }
            .padding()
            .navigationTitle("Tools")
        }
    }
}

// MARK: - 3D Volume View

/// A view that renders a 3D object inside a volumetric window.
struct ModelPreviewView: View {
    @ObservedObject var appState: AppState

    var body: some View {
        // RealityView is the bridge between SwiftUI and RealityKit.
        RealityView { content in
            // Create a simple sphere to represent our sculpture.
            let mesh = MeshResource.generateSphere(radius: 0.2)
            let material = SimpleMaterial(color: .blue, isMetallic: true)
            let modelEntity = ModelEntity(mesh: mesh, materials: [material])
            
            // Add the entity to the RealityView's content.
            content.add(modelEntity)
        } update: { content in
            // The 'update' closure runs whenever the SwiftUI state changes.
            // Here, we update the sphere's color when the user picks a new one in the Window.
            if let entity = content.entities.first as? ModelEntity {
                entity.model?.materials = [SimpleMaterial(color: appState.selectedColor, isMetallic: true)]
            }
        }
    }
}

// MARK: - Immersive Space View

/// A view that takes over the entire user environment.
struct GalleryEnvironmentView: View {
    var body: some View {
        RealityView { content in
            // In a real app, you would load a complex USDZ environment here.
            // For this example, we add a large floor plane to ground the user.
            let floorMesh = MeshResource.generatePlane(width: 10, depth: 10)
            let floorMaterial = SimpleMaterial(color: .darkGray, isMetallic: false)
            let floorEntity = ModelEntity(mesh: floorMesh, materials: [floorMaterial])
            
            // Position the floor slightly below the user's feet.
            floorEntity.position.y = -1.0
            
            content.add(floorEntity)
            
            // Add some "floating" ambient lights to simulate a gallery.
            let light = DirectionalLight()
            light.light.intensity = 5000
            light.position = [0, 5, 0]
            content.add(light)
        }
    }
}
