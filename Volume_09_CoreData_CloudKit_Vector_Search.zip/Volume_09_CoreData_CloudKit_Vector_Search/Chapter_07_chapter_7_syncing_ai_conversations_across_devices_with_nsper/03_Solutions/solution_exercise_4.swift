
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CoreData
import Foundation

// 1. The Secure Value Transformer
@objc(VectorTransformer)
final class VectorTransformer: NSSecureUnarchiveFromDataTransformer {
    static let name = NSValueTransformerName(rawValue: "VectorTransformer")

    override static var allowedTopLevelClasses: [AnyClass] {
        return [NSArray.self, NSData.self, NSNumber.self]
    }

    static func register() {
        let transformer = VectorTransformer()
        ValueTransformer.setValueTransformer(transformer, forName: name)
    }
}

// 2. The Data Model Structure (Conceptual)
/*
 Entity: Message
  - text: String
  - timestamp: Date
  - embedding: Relationship (One-to-One, Destination: MessageEmbedding, Delete Rule: Cascade)

 Entity: MessageEmbedding
  - vectorData: Data (Transformable, uses "VectorTransformer")
  - message: Relationship (One-to-One, Destination: Message, Delete Rule: Nullify)
*/

@objc(MessageEmbedding)
public class MessageEmbedding: NSManagedObject {
    @NSManaged public var vectorData: Data? // This will hold the [Float] via the transformer
    @NSManaged public var message: Message?
}

// 3. Usage Pattern
extension Message {
    /// Access the vector only when needed (Lazy Loading)
    func getVector() -> [Float]? {
        guard let embedding = self.value(forKey: "embedding") as? MessageEmbedding,
              let data = embedding.vectorData else { return nil }
        
        // Convert Data back to [Float]
        return data.withUnsafeBytes { Array($0.bindMemory(to: Float.self)) }
    }
    
    func setVector(_ vector: [Float]) {
        let context = self.managedObjectContext
        let embedding = MessageEmbedding(context: context!)
        
        // Convert [Float] to Data
        let data = vector.withUnsafeBytes { Data($0) }
        embedding.vectorData = data
        embedding.message = self
    }
}
