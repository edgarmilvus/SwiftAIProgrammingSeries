
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import Foundation
    import MLX
    import MLXNN // Assuming MySimpleLLM is defined here
    import Observation // For @Observable

    @available(iOS 18.0, macOS 15.0, *)
    actor LLMGenerator {
        private var model: MySimpleLLM // The MLX model instance
        private var currentPrompt: String = ""
        private var generatedTokens: [String] = [] // State isolated by the actor
        private var modelParameters: Parameters // Loaded model weights

        // A separate Observable object to publish updates to SwiftUI
        // This is necessary because actors cannot be @Observable themselves.
        @MainActor // Ensure this object's state is updated on the main actor
        @Observable
        class OutputPublisher {
            var text: String = ""
            var isGenerating: Bool = false
        }

        @MainActor // The publisher must be created and owned by the MainActor
        let publisher = OutputPublisher()

        init(modelPath: String) async throws {
            // Assume model loading from a previous chapter
            // Example: modelParameters = try await loadModelParameters(from: modelPath)
            // For this example, we'll use a dummy init for MySimpleLLM
            self.modelParameters = Parameters() // Placeholder
            self.model = MySimpleLLM(parameters: self.modelParameters)
            MLX.setSeed(0) // For reproducibility
        }

        func generate(prompt: String) async throws {
            currentPrompt = prompt
            generatedTokens = []
            await publisher.update { publisher in
                publisher.text = prompt // Start with the prompt
                publisher.isGenerating = true
            }

            // Simulate tokenization and initial input MLXArray
            var inputMLXArray = MLXArray.ones([1, 1], type: .int32) // Placeholder for actual token IDs

            // The core streaming loop
            while true {
                // Perform MLX inference
                let logits = model(inputMLXArray)
                let nextTokenID = MLX.argmax(logits, axis: -1).evaluated // Get next token ID
                // In a real LLM, you'd update the inputMLXArray with the new token
                // and potentially manage a KV cache.

                let nextTokenString = " \(Int.random(in: 0...9))" // Simulate decoding
                generatedTokens.append(nextTokenString)

                // Update the @Observable object on the MainActor
                await publisher.update { publisher in
                    publisher.text = generatedTokens.joined()
                }

                // Simulate end condition
                if generatedTokens.count > 10 {
                    break
                }
                try await Task.sleep(for: .milliseconds(50)) // Simulate processing time
            }

            await publisher.update { publisher in
                publisher.isGenerating = false
            }
        }

        // Helper to update @Observable properties safely on the MainActor
        @MainActor
        private func update(block: (OutputPublisher) -> Void) {
            block(publisher)
        }
    }
    