
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CoreML // Used conceptually to represent where an ML model would be
import Accelerate // For efficient vector math (e.g., dot product, magnitude)

// MARK: - 1. Core Concepts & Data Structures

/// Type alias for a vector embedding, typically an array of floats.
/// The dimension (e.g., 384, 768) depends on the specific embedding model used.
typealias VectorEmbedding = [Float]

/// Represents a small, semantically coherent piece of text from a larger document,
/// along with its generated embedding.
struct TextChunk: Identifiable, CustomStringConvertible {
    let id: UUID
    let content: String
    let embedding: VectorEmbedding

    init(content: String, embedding: VectorEmbedding) {
        self.id = UUID()
        self.content = content
        self.embedding = embedding
    }

    var description: String {
        "Chunk ID: \(id.uuidString.prefix(8))... - Content: \"\(content.prefix(50))...\""
    }
}

// MARK: - 2. Embedding Generation (Conceptual)

/// A conceptual class to simulate an embedding model.
/// In a real application, this would load a CoreML model (e.g., a sentence transformer like `all-MiniLM-L6-v2`)
/// or use a local `llama.cpp` binding to generate embeddings.
/// For this basic example, it generates a simple, deterministic-but-unique vector
/// based on the input string to demonstrate the *concept* of an embedding and its data type.
actor EmbeddingGenerator {
    private let embeddingDimension: Int
    private let randomSeed: UInt64 // For deterministic "random" vectors, useful for testing

    /// Initializes the embedding generator.
    /// - Parameter dimension: The desired dimension of the output embedding vectors.
    ///                        Common dimensions are 384, 768, or 1024.
    /// - Parameter seed: A seed for deterministic "random" vector generation.
    init(dimension: Int = 384, seed: UInt64 = 42) {
        self.embeddingDimension = dimension
        self.randomSeed = seed
    }

    /// Simulates the asynchronous generation of an embedding for a given text.
    /// In a real scenario, this would involve:
    /// 1. Preprocessing the text (tokenization).
    /// 2. Running inference on a `CoreML` model (`MLModel.prediction(from:)`).
    /// 3. Extracting the embedding output.
    /// - Parameter text: The input text to embed.
    /// - Returns: A `VectorEmbedding` (an array of floats).
    func generateEmbedding(for text: String) async throws -> VectorEmbedding {
        // Simulate some asynchronous work, like CoreML inference latency.
        // A real CoreML model might take milliseconds to tens of milliseconds depending on model size and device.
        try await Task.sleep(for: .milliseconds(50))

        // --- Basic Example Mock Embedding Generation ---
        // This is NOT a real semantic embedding. It's a placeholder to demonstrate the
        // data structure and workflow. A real embedding would capture semantic meaning.
        // Here, we use a simple hash-based approach to get *some* unique vector per string.
        let stringHash = text.hashValue
        var vector = VectorEmbedding(repeating: 0.0, count: embeddingDimension)

        // Fill the vector deterministically based on the hash.
        // The values are scaled to be roughly between -1 and 1, similar to some embedding outputs.
        for i in 0..<embeddingDimension {
            vector[i] = Float((stringHash * (i + 1) + Int(randomSeed)) % 1000) / 500.0 - 1.0
        }
        
        // Normalize the vector to unit length (L2 norm).
        // This is CRUCIAL for cosine similarity to work correctly, as it measures
        // the angle between vectors, not their magnitude.
        return normalize(vector: vector)
    }
    
    /// Normalizes a vector to unit length (L2 norm).
    /// Uses `vDSP` for efficient array operations.
    private func normalize(vector: VectorEmbedding) -> VectorEmbedding {
        // Calculate the magnitude (L2 norm) of the vector.
        // vDSP.dot(vector, vector) computes the sum of squares.
        let magnitude = sqrt(vDSP.dot(vector, vector))
        
        // Avoid division by zero if the vector is a zero vector.
        guard magnitude > 1e-6 else { return VectorEmbedding(repeating: 0.0, count: vector.count) }
        
        // Divide each element by the magnitude to get a unit vector.
        return vDSP.divide(vector, magnitude)
    }
}

// MARK: - 3. Vector Store

/// A simple in-memory vector store for `TextChunk` objects.
/// In a real application, this might be a more sophisticated database
/// (e.g., ChromaDB, Pinecone, or a custom FAISS/Annoy integration for large datasets).
actor VectorStore {
    private var chunks: [TextChunk] = []

    /// Adds a text chunk with its embedding to the store.
    /// - Parameter chunk: The `TextChunk` to add.
    func addChunk(_ chunk: TextChunk) {
        chunks.append(chunk)
        print("Added chunk: \(chunk.id.uuidString.prefix(8))... (Content: \"\(chunk.content.prefix(30))...\")")
    }

    /// Finds the `topK` most similar `TextChunk`s to a given query embedding.
    /// Uses cosine similarity for ranking, which is a common metric for semantic similarity.
    /// - Parameters:
    ///   - queryEmbedding: The embedding of the user's query.
    ///   - topK: The number of top similar chunks to retrieve.
    /// - Returns: An array of `TextChunk`s, ordered by similarity (most similar first).
    func findMostSimilar(queryEmbedding: VectorEmbedding, topK: Int) -> [TextChunk] {
        guard !chunks.isEmpty else { return [] }

        // Calculate similarity for each stored chunk against the query embedding.
        let similarities = chunks.map { chunk in
            (chunk, cosineSimilarity(queryEmbedding, chunk.embedding))
        }

        // Sort by similarity score in descending order, take the top K, and return only the chunks.
        return similarities
            .sorted { $0.1 > $1.1 } // Sort by similarity score, descending
            .prefix(topK)           // Take the top K results
            .map { $0.0 }           // Extract just the TextChunk objects
    }

    /// Calculates the cosine similarity between two vectors.
    /// Cosine similarity measures the cosine of the angle between two vectors.
    /// It ranges from -1 (opposite) to 1 (identical), with 0 indicating orthogonality.
    /// A higher score means greater similarity.
    /// Uses `vDSP` for efficient vector operations.
    /// - Parameters:
    ///   - vec1: The first vector (e.g., query embedding).
    ///   - vec2: The second vector (e.g., document chunk embedding).
    /// - Returns: The cosine similarity score.
    private func cosineSimilarity(_ vec1: VectorEmbedding, _ vec2: VectorEmbedding) -> Float {
        // Ensure vectors are of the same dimension for valid comparison.
        guard vec1.count == vec2.count else {
            print("Warning: Vector dimensions mismatch. Returning 0.0 similarity.")
            return 0.0
        }

        // Calculate the dot product of the two vectors.
        let dotProduct = vDSP.dot(vec1, vec2)
        
        // Calculate the magnitudes (L2 norms) of both vectors.
        let magnitude1 = sqrt(vDSP.dot(vec1, vec1))
        let magnitude2 = sqrt(vDSP.dot(vec2, vec2))

        // Avoid division by zero if one of the vectors is a zero vector.
        guard magnitude1 > 1e-6 && magnitude2 > 1e-6 else { return 0.0 }

        // Cosine similarity formula: (A . B) / (||A|| * ||B||)
        return dotProduct / (magnitude1 * magnitude2)
    }
}

// MARK: - 4. RAG Orchestration in an Apple App Context

/// A mock `LLMInterface` to simulate interacting with a large language model.
/// In a real application, this would use Ollama, `llama.cpp` Swift bindings,
/// or a cloud-based LLM API.
/// This is a placeholder to show where the retrieved context would go.
actor MockLLMInterface {
    /// Simulates generating a response from an LLM given a query and context.
    /// - Parameters:
    ///   - query: The user's original query.
    ///   - contextChunks: The relevant text chunks retrieved from the vector store.
    /// - Returns: A simulated LLM response.
    func generateResponse(query: String, contextChunks: [TextChunk]) async throws -> String {
        // Simulate LLM inference latency. Real LLMs can take seconds.
        try await Task.sleep(for: .milliseconds(200))

        let context = contextChunks.map { $0.content }.joined(separator: "\n---\n")
        
        if context.isEmpty {
            return """
            (Simulated LLM Response - No Context Found)
            I couldn't find enough relevant information in the documents to answer your question: "\(query)".
            Please try rephrasing or asking about a different topic within the document.
            """
        } else {
            return """
            (Simulated LLM Response - With Context)
            Based on the following retrieved information from the document:
            ---
            \(context)
            ---
            Regarding your question, "\(query)", the documents provide details indicating that...
            (Further LLM generation would happen here, synthesizing a coherent and grounded answer
            by combining the query and the provided context. For example, it might rephrase or
            summarize the retrieved chunks to directly answer the question.)
            """
        }
    }
}

/// Represents a "Document Scanner" application's RAG assistant.
/// This class orchestrates the entire Retrieval-Augmented Generation process.
@available(iOS 18.0, macOS 15.0, *) // Requires modern async/await features
@MainActor // Best practice for app-level logic that might interact with UI, even if console-based here.
class DocumentScannerRAGAssistant {
    private let embeddingGenerator: EmbeddingGenerator
    private let vectorStore: VectorStore
    private let llmInterface: MockLLMInterface

    /// Initializes the RAG assistant with necessary components.
    /// - Parameter embeddingDimension: The dimension of the embeddings to be generated.
    init(embeddingDimension: Int = 384) {
        self.embeddingGenerator = EmbeddingGenerator(dimension: embeddingDimension)
        self.vectorStore = VectorStore()
        self.llmInterface = MockLLMInterface()
    }

    /// Processes a raw document string by chunking it, generating embeddings,
    /// and storing them in the vector store. This builds the searchable knowledge base.
    /// - Parameter documentText: The full text of the scanned document.
    func ingestDocument(documentText: String) async throws {
        print("\n--- Ingesting Document ---")
        let chunks = chunkDocument(documentText) // Split the document into manageable pieces
        
        for (index, chunkContent) in chunks.enumerated() {
            print("Embedding chunk \(index + 1)/\(chunks.count)...")
            // Generate an embedding for each chunk
            let embedding = try await embeddingGenerator.generateEmbedding(for: chunkContent)
            let chunk = TextChunk(content: chunkContent, embedding: embedding)
            // Add the chunk (text + embedding) to the vector store
            await vectorStore.addChunk(chunk)
        }
        print("Document ingestion complete. \(chunks.count) chunks indexed.")
    }

    /// Answers a user's query by performing the RAG workflow:
    /// 1. Embeds the user's query.
    /// 2. Retrieves relevant chunks from the vector store based on similarity.
    /// 3. Passes the query and retrieved chunks to an LLM for augmented generation.
    /// - Parameters:
    ///   - query: The user's question.
    ///   - topK: The number of top similar chunks to retrieve from the vector store.
    /// - Returns: The LLM's generated response, augmented with document context.
    func answerQuery(query: String, topK: Int = 3) async throws -> String {
        print("\n--- Answering Query: \"\(query)\" ---")
        
        // 1. Embed the query
        print("Generating embedding for query...")
        let queryEmbedding = try await embeddingGenerator.generateEmbedding(for: query)

        // 2. Retrieve relevant chunks from the vector store
        print("Searching vector store for top \(topK) similar chunks...")
        let retrievedChunks = await vectorStore.findMostSimilar(queryEmbedding: queryEmbedding, topK: topK)
        
        if retrievedChunks.isEmpty {
            print("No relevant chunks found for the query.")
        } else {
            print("Retrieved \(retrievedChunks.count) chunks:")
            retrievedChunks.forEach { print("- \($0.description)") }
        }

        // 3. Generate response using LLM with context
        print("Sending query and context to LLM for final response generation...")
        let llmResponse = try await llmInterface.generateResponse(query: query, contextChunks: retrievedChunks)
        
        return llmResponse
    }

    /// A simple document chunking strategy for demonstration purposes.
    /// In a real RAG system, this would be more sophisticated, considering:
    /// - Token limits of the embedding model and LLM.
    /// - Sentence boundaries to maintain semantic coherence.
    /// - Overlap between chunks to prevent loss of context at boundaries.
    /// - Recursive splitting strategies.
    /// - Parameter document: The full text of the document.
    /// - Parameter chunkSize: The maximum number of characters per chunk.
    /// - Returns: An array of strings, each representing a document chunk.
    private func chunkDocument(_ document: String, chunkSize: Int = 500, overlap: Int = 50) -> [String] {
        var chunks: [String] = []
        var currentIndex = document.startIndex
        
        while currentIndex < document.endIndex {
            let endIndex = document.index(currentIndex, offsetBy: chunkSize, limitedBy: document.endIndex) ?? document.endIndex
            let chunk = String(document[currentIndex..<endIndex])
            chunks.append(chunk)
            
            // Move the current index for the next chunk, applying overlap
            let nextStartIndex = document.index(endIndex, offsetBy: -overlap, limitedBy: document.startIndex) ?? endIndex
            currentIndex = nextStartIndex
            
            // If the next chunk would be very small, just take the rest
            if document.distance(from: currentIndex, to: document.endIndex) < overlap && currentIndex < document.endIndex {
                chunks.append(String(document[currentIndex..<document.endIndex]))
                break // Processed the rest of the document
            }
        }
        return chunks
    }
}

// MARK: - Main Execution Block

/// Entry point for the RAG demonstration.
/// This uses `@main` for a simple console application.
@available(iOS 18.0, macOS 15.0, *)
@main
struct RAGExampleApp {
    static func main() async {
        print("=== Starting RAG Basic Example ===")

        let assistant = DocumentScannerRAGAssistant(embeddingDimension: 384) // Using a common embedding dimension

        // --- Sample Document: Text from an imaginary Apple Vision Pro review ---
        let sampleDocument = """
        The Apple Vision Pro is a revolutionary spatial computer that seamlessly blends digital content with your physical world.
        It introduces a revolutionary new input system controlled entirely by your eyes, hands, and voice, offering an intuitive experience.
        Vision Pro is built on visionOS, the world’s first spatial operating system, which unlocks powerful spatial experiences and new ways to interact.
        Users can interact with apps in a whole new way, expanding their workspace, enjoying immersive entertainment, and connecting with others.
        It features an ultra-high-resolution display system with 23 million pixels across two micro-OLED displays, delivering stunning visuals.
        The device is powered by a unique dual-chip design, featuring an M2 chip for powerful standalone performance
        and the brand-new R1 chip, which processes input from 12 cameras, five sensors, and six microphones to
        ensure content feels like it’s appearing right in front of the user’s eyes, in real time, with virtually no lag.
        Vision Pro redefines how users connect, create, and collaborate across various applications.
        It integrates seamlessly with the Apple ecosystem, allowing for continuity across devices like iPhone, iPad, and Mac.
        The price point for the Vision Pro is set at $3,499, making it a premium device aimed at early adopters and professionals.
        It offers up to 2 hours of general use on its external battery pack, or all-day use when plugged in.
        """

        // 1. Ingest the document: Chunk, Embed, and Index
        do {
            try await assistant.ingestDocument(documentText: sampleDocument)

            // 2. Ask questions about the document, and get RAG-augmented answers
            let queries = [
                "What powers the Apple Vision Pro?",
                "How does the Vision Pro interact with users?",
                "What is visionOS?",
                "Tell me about its display system.",
                "What is the price of the Vision Pro?",
                "How long does the battery last?",
                "When was the Vision Pro released?" // Query for information NOT explicitly in the document
            ]

            for (index, query) in queries.enumerated() {
                let response = try await assistant.answerQuery(query: query)
                print("\n--- Query \(index + 1) Response ---\nQuery: \"\(query)\"\nLLM Response:\n\(response)\n")
            }

        } catch {
            print("\n!!! An error occurred during RAG processing: \(error.localizedDescription) !!!")
        }

        print("=== RAG Basic Example Finished ===")
    }
}
