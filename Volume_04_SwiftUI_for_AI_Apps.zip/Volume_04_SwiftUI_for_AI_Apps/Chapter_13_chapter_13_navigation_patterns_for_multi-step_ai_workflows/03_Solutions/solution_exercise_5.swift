
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI

// Mark the entire struct as available for iOS 18.0
@available(iOS 18.0, *)
struct AIStreamSessionApp: App {
    var body: some Scene {
        WindowGroup {
            MainAppView()
        }
    }
}

@available(iOS 18.0, *)
struct MainAppView: View {
    @State private var showTranscriptionSession = false

    var body: some View {
        VStack {
            Spacer()
            Text("AI Streaming Application")
                .font(.largeTitle)
                .padding()

            Button("Start Live AI Transcription") {
                showTranscriptionSession = true
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            Spacer()
        }
        .fullScreenCover(isPresented: $showTranscriptionSession) {
            TranscriptionSessionView(isShowingSession: $showTranscriptionSession)
        }
    }
}

@available(iOS 18.0, *)
struct TranscriptionSessionView: View {
    @Binding var isShowingSession: Bool
    @State private var isSessionActive = true // Simulates the transcription session's active state
    @State private var transcribedText: String = "Starting transcription..."
    @State private var progress: Double = 0.0
    @State private var showDismissConfirmation = false

    // Timer to simulate real-time transcription
    @State private var timer: Timer?

    let transcriptionTokens = ["Hello...", "how...", "are...", "you...", "today?", "The...", "AI...", "is...", "listening..."]
    @State private var tokenIndex = 0

    var body: some View {
        VStack {
            Text("Live AI Transcription Session")
                .font(.largeTitle)
                .padding()

            ProgressView(value: progress, total: 1.0)
                .progressViewStyle(.linear)
                .padding()

            ScrollView {
                Text(transcribedText)
                    .font(.body)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(10)
            }
            .padding(.horizontal)

            Spacer()

            Button("Stop Session") {
                if isSessionActive {
                    showDismissConfirmation = true // Ask for confirmation if active
                } else {
                    dismissSession() // Directly dismiss if already inactive
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(.red)
            .controlSize(.large)
            .padding(.bottom)
        }
        .onAppear(perform: startTranscription)
        .onDisappear(perform: stopTranscription)
        .interactiveDismissDisabled(isSessionActive) // Prevent swipe dismissal if session is active
        .alert("End Transcription?", isPresented: $showDismissConfirmation) {
            Button("End Session", role: .destructive) {
                dismissSession() // User confirmed, stop and dismiss
            }
            Button("Cancel", role: .cancel) {
                // User cancelled, keep session active and modal open
            }
        } message: {
            Text("Your AI transcription session is still active. Are you sure you want to end it?")
        }
    }

    private func startTranscription() {
        isSessionActive = true
        progress = 0.0
        transcribedText = "Starting transcription..."
        tokenIndex = 0

        timer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { _ in
            if tokenIndex < transcriptionTokens.count {
                transcribedText += " " + transcriptionTokens[tokenIndex]
                tokenIndex += 1
                progress = Double(tokenIndex) / Double(transcriptionTokens.count)
            } else {
                // Session naturally ends
                isSessionActive = false
                transcribedText += "\n\nSession ended."
                stopTranscription() // Invalidate timer
            }
        }
    }

    private func stopTranscription() {
        timer?.invalidate()
        timer = nil
        isSessionActive = false // Ensure session is marked inactive
    }

    private func dismissSession() {
        stopTranscription() // Ensure timer is stopped
        isShowingSession = false // Dismiss the fullScreenCover
    }
}
