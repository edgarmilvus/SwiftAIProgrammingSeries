
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI

// MARK: - 1. Data Model for the Workflow

/// A simple struct to hold the document data as it progresses through the workflow.
/// Conforms to `Hashable` so it can be used as a `value` in `NavigationLink`.
struct DocumentModel: Identifiable, Hashable {
    let id = UUID()
    var originalImageName: String // Simulates the captured/selected image
    var aiProcessedText: String?  // AI's extracted text
    var aiProcessedImageName: String? // AI's enhanced image
    var finalEditedText: String?  // User's refined text

    static func == (lhs: DocumentModel, rhs: DocumentModel) -> Bool {
        lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

// MARK: - 2. Navigation Path Enum

/// Defines the possible destinations in our navigation stack.
/// Conforming to `Hashable` allows `NavigationStack` to use it for path management.
enum DocumentScannerPath: Hashable {
    case processing(DocumentModel)
    case reviewExport(DocumentModel)
}

// MARK: - 3. Capture/Select Document View (Initial Step)

/// The first view in the workflow, where the user initiates a scan.
/// Simulates selecting an image and navigates to the processing step.
@available(iOS 16.0, *) // NavigationStack requires iOS 16.0+
struct CaptureImageView: View {
    @Binding var path: [DocumentScannerPath] // The navigation path

    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "doc.text.viewfinder")
                .resizable()
                .scaledToFit()
                .frame(width: 100, height: 100)
                .foregroundColor(.accentColor)

            Text("Ready to scan a document?")
                .font(.title2)
                .padding(.bottom, 10)

            Button("Simulate Capture & Process") {
                // Simulate capturing an image and preparing for AI processing
                let newDocument = DocumentModel(originalImageName: "scanned_invoice.png")
                // Programmatically push to the next view in the path
                path.append(.processing(newDocument))
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
        }
        .navigationTitle("Capture Document")
    }
}

// MARK: - 4. AI Processing View

/// Simulates the AI processing step.
/// This view will automatically navigate to the next step after a delay.
@available(iOS 16.0, *)
struct ProcessingView: View {
    @Binding var path: [DocumentScannerPath]
    let document: DocumentModel // The document being processed

    @State private var processingMessage: String = "Analyzing document..."
    @State private var isProcessing: Bool = true

    var body: some View {
        VStack(spacing: 20) {
            ProgressView(processingMessage)
                .progressViewStyle(.circular)
                .scaleEffect(1.5)
                .padding()

            Text("AI is working its magic on '\(document.originalImageName)'")
                .font(.headline)
                .multilineTextAlignment(.center)
        }
        .navigationTitle("Processing...")
        .navigationBarBackButtonHidden(true) // Hide back button during processing
        .onAppear {
            simulateAIProcessing()
        }
    }

    /// Simulates an asynchronous AI processing task.
    /// After completion, it updates the document model and navigates to the review step.
    private func simulateAIProcessing() {
        Task {
            // Simulate a network request or local ML model inference
            try await Task.sleep(for: .seconds(3)) // Simulate 3 seconds of processing
            
            // Ensure UI updates are on the main actor
            await MainActor.run {
                var updatedDocument = document
                updatedDocument.aiProcessedText = "Extracted text: This is a simulated invoice from Acme Corp. Total: $123.45. Date: 2024-07-26."
                updatedDocument.aiProcessedImageName = "enhanced_invoice.png"
                
                self.isProcessing = false
                self.processingMessage = "Processing complete!"
                
                // Programmatically push to the next view in the path
                path.append(.reviewExport(updatedDocument))
            }
        }
    }
}

// MARK: - 5. Review & Export View (Final Step)

/// The final view where the user reviews AI output and can export/save.
@available(iOS 16.0, *)
struct ReviewExportView: View {
    @Binding var path: [DocumentScannerPath]
    @State var document: DocumentModel // @State because user might edit text

    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "checkmark.circle.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 80, height: 80)
                .foregroundColor(.green)

            Text("AI Analysis Complete!")
                .font(.title)

            Text("Original: \(document.originalImageName)")
            Text("Processed Image: \(document.aiProcessedImageName ?? "N/A")")

            TextEditor(text: Binding(
                get: { document.finalEditedText ?? document.aiProcessedText ?? "No text extracted." },
                set: { document.finalEditedText = $0 }
            ))
            .frame(height: 150)
            .border(Color.gray.opacity(0.3))
            .padding()
            .navigationTitle("Review & Export")

            Button("Export Document") {
                // Simulate exporting the document
                print("Exporting document with final text: \(document.finalEditedText ?? document.aiProcessedText ?? "N/A")")
                // Clear the navigation stack to return to root or a new workflow
                path.removeAll() // Go back to the root of the NavigationStack
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
        }
        .padding()
        // Optional: Provide a custom back button that resets the workflow
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button("Cancel Workflow") {
                    path.removeAll() // Reset the entire workflow
                }
            }
        }
    }
}

// MARK: - 6. Main App Entry Point

/// The main application view, hosting the `NavigationStack`.
@available(iOS 16.0, *)
struct DocumentScannerAppView: View {
    /// The `NavigationPath` manages the stack of pushed views.
    /// It's an array of `Hashable` types, in our case `DocumentScannerPath`.
    @State private var navigationPath: [DocumentScannerPath] = []

    var body: some View {
        NavigationStack(path: $navigationPath) {
            // The root view of our navigation stack
            CaptureImageView(path: $navigationPath)
                // Define how to display each type of destination in the path
                .navigationDestination(for: DocumentScannerPath.self) { pathType in
                    switch pathType {
                    case .processing(let document):
                        ProcessingView(path: $navigationPath, document: document)
                    case .reviewExport(let document):
                        ReviewExportView(path: $navigationPath, document: document)
                    }
                }
        }
    }
}

// MARK: - Preview Provider

@available(iOS 16.0, *)
struct DocumentScannerAppView_Previews: PreviewProvider {
    static var previews: some View {
        DocumentScannerAppView()
    }
}
