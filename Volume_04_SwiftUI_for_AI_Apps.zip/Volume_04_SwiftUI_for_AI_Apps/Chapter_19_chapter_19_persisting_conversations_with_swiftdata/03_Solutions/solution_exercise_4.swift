
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import SwiftData
import Foundation

// MARK: - SwiftData Models

@available(iOS 18.0, macOS 15.0, *)
@Model
final class Conversation {
    var id: UUID
    var title: String
    var creationDate: Date
    var lastUpdateDate: Date // New property for Exercise 4
    @Relationship(deleteRule: .cascade, inverse: \Message.conversation)
    var messages: [Message]

    init(id: UUID = UUID(), title: String, creationDate: Date = Date()) {
        self.id = id
        self.title = title
        self.creationDate = creationDate
        self.lastUpdateDate = creationDate // Initialize lastUpdateDate
        self.messages = []
    }
}

@available(iOS 18.0, macOS 15.0, *)
@Model
final class Message {
    var id: UUID
    var content: String
    var timestamp: Date
    var isFromUser: Bool
    var conversation: Conversation? // Inverse relationship

    init(id: UUID = UUID(), content: String, timestamp: Date = Date(), isFromUser: Bool) {
        self.id = id
        self.content = content
        self.timestamp = timestamp
        self.isFromUser = isFromUser
    }
}

// MARK: - AI Simulation Utility (from Exercise 3, repeated for completeness)

@available(iOS 18.0, macOS 15.0, *)
func simulateAITokenStream(fullResponse: String, delay: Duration) -> AsyncStream<String> {
    AsyncStream { continuation in
        Task {
            let words = fullResponse.split(separator: " ").map(String.init)
            for word in words {
                try? await Task.sleep(for: delay)
                continuation.yield(word + " ")
            }
            continuation.finish()
        }
    }
}

// MARK: - SwiftUI Views

@available(iOS 18.0, macOS 15.0, *)
enum ConversationSortOption: String, CaseIterable, Identifiable {
    case creationDate = "Newest First (Creation Date)"
    case lastActivity = "Most Recent Activity"

    var id: String { self.rawValue }

    var sortDescriptor: SortDescriptor<Conversation> {
        switch self {
        case .creationDate:
            return SortDescriptor(\.creationDate, order: .reverse)
        case .lastActivity:
            return SortDescriptor(\.lastUpdateDate, order: .reverse)
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct ConversationDetailView: View { // From Exercise 3, updated to set lastUpdateDate
    @Environment(\.modelContext) private var modelContext
    let conversation: Conversation

    @Query private var messages: [Message]
    @State private var newMessageContent: String = ""
    @State private var isStreamingAIResponse: Bool = false

    init(conversation: Conversation) {
        self.conversation = conversation
        _messages = Query(
            filter: #Predicate<Message> { $0.conversation?.id == conversation.id },
            sort: \.timestamp
        )
    }

    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                List {
                    ForEach(messages) { message in
                        HStack {
                            if message.isFromUser {
                                Spacer()
                                Text(message.content)
                                    .padding()
                                    .background(Color.blue.opacity(0.8))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            } else {
                                Text(message.content)
                                    .padding()
                                    .background(Color.gray.opacity(0.2))
                                    .cornerRadius(10)
                            }
                        }
                        .listRowSeparator(.hidden)
                        .id(message.id)
                    }
                    .onDelete(perform: deleteMessages)
                }
                .listStyle(.plain)
                .onChange(of: messages.count) { oldVal, newVal in
                    if newVal > oldVal, let lastMessage = messages.last {
                        proxy.scrollTo(lastMessage.id, anchor: .bottom)
                    }
                }
                .onChange(of: messages.last?.content) { _, _ in
                    if let lastMessage = messages.last, !lastMessage.isFromUser {
                        proxy.scrollTo(lastMessage.id, anchor: .bottom)
                    }
                }
            }

            HStack {
                TextField("Type a message...", text: $newMessageContent)
                    .textFieldStyle(.roundedBorder)
                Button("Send") {
                    sendUserMessageAndStreamAIResponse()
                }
                .disabled(newMessageContent.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isStreamingAIResponse)
            }
            .padding()
        }
        .navigationTitle(conversation.title)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func sendUserMessageAndStreamAIResponse() {
        guard !newMessageContent.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        // Update lastUpdateDate on the conversation
        conversation.lastUpdateDate = Date()

        let userMessage = Message(content: newMessageContent, isFromUser: true)
        conversation.messages.append(userMessage)
        modelContext.insert(userMessage)
        let userMessageContent = newMessageContent
        newMessageContent = ""

        let aiMessage = Message(content: "", isFromUser: false)
        conversation.messages.append(aiMessage)
        modelContext.insert(aiMessage)

        isStreamingAIResponse = true

        Task {
            let aiFullResponse = "Okay, you asked about '\(userMessageContent)'. Here is a detailed answer that should help you understand it completely."
            for await token in simulateAITokenStream(fullResponse: aiFullResponse, delay: .milliseconds(70)) {
                aiMessage.content += token
            }
            // Update lastUpdateDate again when AI finishes its response
            conversation.lastUpdateDate = Date()
            isStreamingAIResponse = false
        }
    }

    private func deleteMessages(at offsets: IndexSet) {
        for index in offsets {
            let messageToDelete = messages[index]
            modelContext.delete(messageToDelete)
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @State private var showingNewConversationSheet = false
    @State private var searchText: String = ""
    @State private var selectedSortOption: ConversationSortOption = .lastActivity

    // Dynamic Query based on search text and sort option
    @Query private var conversations: [Conversation]

    init() {
        // Initialize with default sort order, predicate will be updated dynamically
        _conversations = Query(sort: [ConversationSortOption.lastActivity.sortDescriptor])
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(conversations) { conversation in
                    NavigationLink(destination: ConversationDetailView(conversation: conversation)) {
                        VStack(alignment: .leading) {
                            Text(conversation.title)
                                .font(.headline)
                            Text("Created: \(conversation.creationDate.formatted(date: .abbreviated, time: .shortened))")
                                .font(.caption)
                                .foregroundColor(.gray)
                            Text("Last Activity: \(conversation.lastUpdateDate.formatted(date: .abbreviated, time: .shortened))")
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                    }
                }
                .onDelete(perform: deleteConversations)
                if conversations.isEmpty && !searchText.isEmpty {
                    ContentUnavailableView.search(text: searchText)
                } else if conversations.isEmpty {
                     ContentUnavailableView("No Conversations", systemImage: "bubble.left.and.bubble.right.fill", description: Text("Start a new chat to see it appear here."))
                }
            }
            .navigationTitle("AI Chats")
            .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always))
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Picker("Sort", selection: $selectedSortOption) {
                        ForEach(ConversationSortOption.allCases) { option in
                            Text(option.rawValue).tag(option)
                        }
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showingNewConversationSheet = true
                    } label: {
                        Label("New Conversation", systemImage: "plus.circle.fill")
                    }
                }
            }
            .sheet(isPresented: $showingNewConversationSheet) {
                NewConversationView()
            }
            // Update the Query dynamically when search text or sort option changes
            .onChange(of: searchText) { oldVal, newVal in
                updateQuery(searchText: newVal, sortOption: selectedSortOption)
            }
            .onChange(of: selectedSortOption) { oldVal, newVal in
                updateQuery(searchText: searchText, sortOption: newVal)
            }
            // Initial query update when view appears
            .onAppear {
                updateQuery(searchText: searchText, sortOption: selectedSortOption)
            }
        }
    }

    private func updateQuery(searchText: String, sortOption: ConversationSortOption) {
        var predicate: Predicate<Conversation>? = nil
        if !searchText.isEmpty {
            let searchLowercased = searchText.lowercased()
            predicate = #Predicate<Conversation> { conversation in
                conversation.title.localizedStandardContains(searchLowercased) ||
                conversation.messages.contains { message in
                    message.content.localizedStandardContains(searchLowercased)
                }
            }
        }
        _conversations = Query(filter: predicate, sort: [sortOption.sortDescriptor])
    }

    private func deleteConversations(at offsets: IndexSet) {
        for index in offsets {
            let conversationToDelete = conversations[index]
            modelContext.delete(conversationToDelete)
        }
    }
}

// NewConversationView and AIApp (from Exercise 1) remain unchanged.
// For brevity, not repeated here but would be part of the full app.
// @available(iOS 18.0, macOS 15.0, *) @main struct AIApp: App { ... }
