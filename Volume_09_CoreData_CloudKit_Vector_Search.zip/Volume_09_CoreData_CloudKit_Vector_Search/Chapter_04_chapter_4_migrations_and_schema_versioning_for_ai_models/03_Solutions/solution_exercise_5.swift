
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import CoreData
import CloudKit

class CloudKitSyncObserver {
    
    // 1. The "Shadow Store" implementation
    // In the Core Data Model, 'Note' should have an attribute:
    // 'shadowStore' -> Type: Transformable (Dictionary [String: Data])
    
    func handleSyncEvent(notification: Notification) {
        // In a real app, we listen for NSPersistentCloudKitContainer.eventChangedNotification
        print("Sync event detected. Checking for schema drift...")
        
        // 2. Simulation of detecting unknown keys
        let incomingCKRecordKeys = ["title", "text", "semanticTag", "timestamp"] // 'semanticTag' is unknown locally
        let localModelKeys = ["title", "text", "timestamp"]
        
        let unknownKeys = incomingCKRecordKeys.filter { !localModelKeys.contains($0) }
        
        if !unknownKeys.isEmpty {
            print("⚠️ Schema Drift Detected! Unknown keys: \(unknownKeys)")
            stashUnknownKeys(unknownKeys, into: "Note")
        }
    }
    
    private func stashUnknownKeys(_ keys: [String], into entityName: String) {
        // In a real implementation, you would intercept the CKRecord 
        // before it is mapped to the NSManagedObject.
        // Since NSPersistentCloudKitContainer handles mapping automatically, 
        // the 'Shadow Store' approach usually requires a custom middleware 
        // or a post-sync reconciliation step.
        
        print("📦 Stashing \(keys) into the Shadow Store to prevent data loss.")
    }
}

/*
 AI IMPACT ANALYSIS (Comments):
 
 The "Shadow Store" approach creates a "Blind Spot" for local vector engines. 
 
 1. The Problem: If a remote user adds a 'semanticTag' and a corresponding 'vector', 
    the local user's device will stash the 'vector' in the 'shadowStore' (a dictionary).
    The local Core Data Fetch Requests and local Vector Search engines (like Accelerate 
    or CoreML) will NOT see this data because it isn't in a proper attribute column.
 
 2. The Consequence: The local user's search results will be incomplete. They 
    will see the text of the note, but the note won't appear in semantic searches 
    until the local app is updated to the new schema.
 
 3. The Solution: A "Hybrid Search" strategy. The app should:
    a) Search the local indexed vectors.
    b) Periodically scan the 'shadowStore' for vector data and perform a 
       background 're-indexing' to bring shadow data into the formal schema.
*/
