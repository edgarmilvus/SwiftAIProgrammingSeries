
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

    @available(iOS 18.0, *)
    class SmartDocumentProcessorApp {
        let documentProcessor: DocumentProcessorActor

        init() {
            let aiService = AIService()
            self.documentProcessor = DocumentProcessorActor(aiService: aiService)
        }

        /// Simulates scanning multiple documents and initiating their AI processing.
        /// - Parameter documentTexts: An array of raw text strings representing scanned documents.
        func simulateDocumentScanningAndProcessing(documentTexts: [String]) async {
            print("\n--- Starting Document Processing Simulation ---")

            var documentIDs: [UUID] = []

            // Add documents sequentially (this could also be concurrent if `addDocument` was non-mutating)
            for (index, text) in documentTexts.enumerated() {
                let doc = documentProcessor.addDocument(rawText: text)
                documentIDs.append(doc.id)
                print("Document \(index + 1) added with ID: \(doc.id)")
            }

            // Concurrently process all added documents
            await withTaskGroup(of: Void.self) { group in
                for id in documentIDs {
                    group.addTask {
                        await self.documentProcessor.processDocument(documentId: id)
                    }
                }
            }

            print("\n--- All Document Processing Tasks Initiated ---")

            // Periodically check and print the status of documents
            // In a real app, this would be observed via Combine/SwiftUI updates.
            await Task.sleep(nanoseconds: 3_000_000_000) // Wait for some processing to complete
            print("\n--- Current Document States After Initial Processing ---")
            let currentDocuments = await documentProcessor.getAllDocuments()
            for doc in currentDocuments.sorted(by: { $0.rawText.prefix(10) < $1.rawText.prefix(10) }) {
                print("Document ID: \(doc.id.uuidString.prefix(8))...")
                print("  Status: \(doc.status.rawValue)")
                print("  Summary: \(doc.summary ?? "N/A")")
                print("  Keywords: \(doc.keywords?.joined(separator: ", ") ?? "N/A")")
                if let error = doc.processingError {
                    print("  Error: \(error.localizedDescription)")
                }
                print("---")
            }
            print("\n--- Simulation Complete ---")
        }
    }

    // MARK: - Example Usage

    // Only run this example on iOS 18.0 or later due to `@available` annotations.
    if #available(iOS 18.0, *) {
        let app = SmartDocumentProcessorApp()

        let sampleTexts = [
            "This is a sample document about Swift 6 concurrency and actors. It highlights the importance of thread safety in modern applications, especially when dealing with shared mutable state. Apple Intelligence will leverage these patterns.",
            "A second document discussing the features of iOS 18, including new privacy enhancements and on-device machine learning capabilities. The user experience is greatly improved with these additions.",
            "Another short text. This one is designed to trigger an error trigger in the AI summarization to demonstrate error handling.",
            "This document is about Swift Package Manager and its role in managing dependencies. It simplifies the development workflow for large projects.",
            "A final document that is slightly longer, discussing the future of AI in mobile devices and how on-device models provide superior performance and privacy. Keyword error might occur."
        ]

        Task {
            await app.simulateDocumentScanningAndProcessing(documentTexts: sampleTexts)
        }
    } else {
        print("This application requires iOS 18.0 or later to run Apple Intelligence features.")
    }
    