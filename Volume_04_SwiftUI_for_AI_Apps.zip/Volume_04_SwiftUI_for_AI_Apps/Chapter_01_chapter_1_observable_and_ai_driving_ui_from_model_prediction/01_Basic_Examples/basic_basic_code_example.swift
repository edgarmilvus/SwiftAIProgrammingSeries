
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Observation // Required for @Observable

// MARK: - 1. Define the @Observable AI Model Class

/// @available(iOS 17.0, *) // @Observable is available from iOS 17.0
/// Represents the AI Chat Assistant's state and prediction logic.
/// This class is marked with @Observable, making its properties automatically observed by SwiftUI views.
/// When 'predictedSentiment', 'confidence', or 'isLoading' change, any SwiftUI view
/// observing an instance of this class will automatically re-render its relevant parts.
@Observable
final class AIChatAssistantModel {
    /// The current message being typed or analyzed by the user.
    var currentMessage: String = ""

    /// The sentiment predicted by the AI model (e.g., "Positive", "Negative", "Neutral").
    /// Optional, as there might not be a prediction yet.
    var predictedSentiment: String?

    /// The confidence score of the AI's prediction, ranging from 0.0 to 1.0.
    /// Optional, as there might not be a prediction yet.
    var confidence: Double?

    /// A boolean flag indicating if the AI model is currently processing a request.
    /// This is useful for showing loading indicators in the UI.
    var isLoading: Bool = false

    /// Initializes a new instance of the AIChatAssistantModel.
    init() {}

    /// /// Simulates an asynchronous AI sentiment analysis.
    /// /// In a real application, this would involve calling a Core ML model, a backend API,
    /// /// or a cloud-based AI service.
    /// ///
    /// /// - Parameter message: The text message to analyze for sentiment.
    /// ///
    /// /// This method is marked `async` to represent a potentially long-running operation.
    /// /// It updates the `isLoading` flag to provide UI feedback.
    /// /// Critically, any updates to UI-bound properties (`predictedSentiment`, `confidence`, `isLoading`)
    /// /// that originate from a background task must be performed on the `MainActor`
    /// /// to ensure thread safety and prevent UI glitches.
    @MainActor // Ensures all property updates within this method are on the main thread.
    func analyzeSentiment(message: String) async {
        guard !message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            predictedSentiment = nil
            confidence = nil
            return // Don't analyze empty messages
        }

        isLoading = true // Start loading indicator

        // Simulate network/model inference delay
        try? await Task.sleep(for: .seconds(1.5))

        // MARK: - 2. Implement the AI Prediction Logic (Simulated)

        // Simple simulated AI logic based on keywords
        let lowercasedMessage = message.lowercased()
        if lowercasedMessage.contains("great") || lowercasedMessage.contains("happy") || lowercasedMessage.contains("love") {
            predictedSentiment = "Positive 😊"
            confidence = Double.random(in: 0.8...0.99)
        } else if lowercasedMessage.contains("bad") || lowercasedMessage.contains("sad") || lowercasedMessage.contains("hate") {
            predictedSentiment = "Negative 😞"
            confidence = Double.random(in: 0.7...0.95)
        } else if lowercasedMessage.contains("maybe") || lowercasedMessage.contains("perhaps") || lowercasedMessage.contains("neutral") {
            predictedSentiment = "Neutral 😐"
            confidence = Double.random(in: 0.5...0.7)
        } else {
            predictedSentiment = "Unclear 🤔"
            confidence = Double.random(in: 0.3...0.6)
        }

        isLoading = false // End loading indicator
    }
}

// MARK: - 3. Create the SwiftUI View

/// @available(iOS 17.0, *) // SwiftUI views using @Observable typically require iOS 17.0+
/// The main SwiftUI view for our AI Chat Assistant.
/// This view observes changes in the `AIChatAssistantModel` and updates its UI accordingly.
struct AIChatAssistantView: View {
    /// An instance of our @Observable model, owned by this view.
    /// @StateObject is used here to ensure the model's lifecycle is tied to the view's lifecycle.
    /// The view will create and own a single instance of `AIChatAssistantModel` for its lifetime.
    @StateObject private var model = AIChatAssistantModel()

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Spacer()

                // Display the current message being typed
                Text("Your Message:")
                    .font(.headline)
                TextField("Type your message here...", text: $model.currentMessage)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                    .disabled(model.isLoading) // Disable input while loading

                // Button to trigger AI analysis
                Button {
                    // Task creates a new asynchronous context to run the async function
                    Task {
                        await model.analyzeSentiment(message: model.currentMessage)
                    }
                } label: {
                    if model.isLoading {
                        ProgressView()
                            .progressViewStyle(.circular)
                            .tint(.white)
                    } else {
                        Text("Analyze Sentiment")
                    }
                }
                .padding()
                .background(model.isLoading ? Color.gray : Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .disabled(model.currentMessage.isEmpty || model.isLoading) // Disable button if no message or loading

                Spacer()

                // MARK: - Displaying AI Predictions

                // Display the predicted sentiment
                Text("Predicted Sentiment:")
                    .font(.headline)
                if let sentiment = model.predictedSentiment {
                    Text(sentiment)
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(sentiment.contains("Positive") ? .green : (sentiment.contains("Negative") ? .red : .orange))
                } else {
                    Text("Awaiting input...")
                        .foregroundColor(.secondary)
                }

                // Display the confidence score
                Text("Confidence:")
                    .font(.headline)
                if let confidence = model.confidence {
                    Text(String(format: "%.2f%%", confidence * 100))
                        .font(.title3)
                        .foregroundColor(.primary)
                } else {
                    Text("N/A")
                        .foregroundColor(.secondary)
                }

                Spacer()
            }
            .navigationTitle("AI Sentiment Analyzer")
            .padding()
        }
    }
}

// MARK: - 4. Create the App Entry Point

/// @available(iOS 17.0, *) // App entry point for SwiftUI 4+
/// The entry point for the SwiftUI application.
/// This struct conforms to the `App` protocol and defines the root view of the application.
@main
struct AIChatAssistantApp: App {
    var body: some Scene {
        WindowGroup {
            AIChatAssistantView()
        }
    }
}
