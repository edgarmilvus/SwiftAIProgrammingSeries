
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CreateML
import Foundation

// MARK: - Exercise 2: Categorizing Customer Feedback Sentiment

// Function to generate synthetic data for customer feedback sentiment
func generateFeedbackSentimentData() -> [[String: MLDataValue]] {
    var data: [[String: MLDataValue]] = []
    let numSamples = 150 // Generate 150 samples

    let sentiments = ["Positive", "Needs Improvement"]

    for _ in 0..<numSamples {
        let sentiment = sentiments.randomElement()!
        var positiveWordCount: Int
        var negativeWordCount: Int
        let containsQuestionMark = Bool.random()
        let feedbackLengthChars = Int.random(in: 30...300)

        if sentiment == "Positive" {
            positiveWordCount = Int.random(in: 3...15)
            negativeWordCount = Int.random(in: 0...3) // Mostly low negative words
        } else { // Needs Improvement
            positiveWordCount = Int.random(in: 0...5) // Mostly low positive words
            negativeWordCount = Int.random(in: 5...20)
        }

        // Add some variation based on question mark and length
        if containsQuestionMark && sentiment == "Needs Improvement" {
            negativeWordCount += Int.random(in: 1...3)
        }
        if feedbackLengthChars > 200 && sentiment == "Positive" {
            positiveWordCount += Int.random(in: 1...5)
        }

        data.append([
            "positiveWordCount": .int(positiveWordCount),
            "negativeWordCount": .int(negativeWordCount),
            "containsQuestionMark": .int(containsQuestionMark ? 1 : 0), // Convert Bool to Int (0 or 1)
            "feedbackLengthChars": .int(feedbackLengthChars),
            "sentiment": .string(sentiment)
        ])
    }
    return data
}

// Main function to run Exercise 2
func runExercise2() {
    print("--- Exercise 2: Categorizing Customer Feedback Sentiment ---")

    // 1. Data Loading: Generate synthetic data
    let rawData = generateFeedbackSentimentData()
    guard let dataTable = try? MLDataTable(array: rawData) else {
        print("Error: Could not create MLDataTable from raw data.")
        return
    }
    print("Generated \(dataTable.rows.count) samples.")
    // print(dataTable.description) // Uncomment to see the raw data table

    // 2. Feature and Label Definition
    let featureColumns = ["positiveWordCount", "negativeWordCount", "containsQuestionMark", "feedbackLengthChars"]
    let targetColumn = "sentiment"

    // Split data into training and testing sets
    let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 1)
    print("Training data size: \(trainingData.rows.count)")
    print("Testing data size: \(testingData.rows.count)")

    // 3. Model Training
    do {
        let classifier = try MLDecisionTreeClassifier(trainingData: trainingData,
                                                      targetColumn: targetColumn,
                                                      featureColumns: featureColumns)
        print("Model training complete.")

        // 4. Model Evaluation
        let evaluationMetrics = classifier.evaluation(on: testingData, targetColumn: targetColumn)
        
        print("Model Evaluation:")
        print("  Overall Accuracy: \(String(format: "%.2f", evaluationMetrics.accuracy * 100))%")

        // Report precision and recall for each class
        if let classMetrics = evaluationMetrics.classificationMetricsByClass {
            for (className, metrics) in classMetrics {
                print("  Class '\(className)':")
                print("    Precision: \(String(format: "%.2f", metrics.precision * 100))%")
                print("    Recall: \(String(format: "%.2f", metrics.recall * 100))%")
            }
        }

        // 5. Prediction Example
        print("\nDemonstrating a prediction:")
        let newFeedbackFeatures: [String: MLDataValue] = [
            "positiveWordCount": .int(1),
            "negativeWordCount": .int(8),
            "containsQuestionMark": .int(1), // Contains question mark
            "feedbackLengthChars": .int(90)
        ]
        
        guard let predictionInput = try? MLDataTable(array: [newFeedbackFeatures]) else {
            print("Error: Could not create prediction input MLDataTable.")
            return
        }

        let predictions = try classifier.predictions(from: predictionInput)
        if let predictedSentiment = predictions[targetColumn]?.first?.stringValue {
            print("  Input Features: Positive=1, Negative=8, QuestionMark=True, Length=90")
            print("  Predicted Sentiment: \(predictedSentiment)")
        } else {
            print("  Could not retrieve prediction.")
        }
        
        // Example of saving the model
        // let modelURL = URL(fileURLWithPath: "/tmp/FeedbackSentimentClassifier.mlmodel")
        // try classifier.write(to: modelURL)
        // print("\nModel saved to: \(modelURL.path)")

    } catch {
        print("Error during model training or evaluation: \(error.localizedDescription)")
    }
    print("--------------------------------------------------\n")
}

// Call the function to run the exercise
runExercise2()
