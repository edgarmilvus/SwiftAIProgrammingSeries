
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

import SwiftUI // Only for @Observable, otherwise not strictly needed in this core logic file

/// An observable class that manages the chat logic, integrating AI interaction and SwiftData persistence.
/// This class would typically be used by a SwiftUI View.
@available(iOS 18.0, *)
@Observable
final class ChatEngine {
    private let persistenceActor: ChatPersistenceActor
    var currentConversation: Conversation?
    var allConversations: [Conversation] = [] // For displaying a list of conversations

    /// Initializes the ChatEngine with a ChatPersistenceActor.
    /// - Parameter persistenceActor: An instance of ChatPersistenceActor.
    init(persistenceActor: ChatPersistenceActor) {
        self.persistenceActor = persistenceActor
    }

    /// Loads all existing conversations from persistence.
    func loadAllConversations() async {
        do {
            allConversations = try await persistenceActor.fetchAllConversations()
            print("Loaded \(allConversations.count) conversations.")
        } catch {
            print("Error loading conversations: \(error.localizedDescription)")
            // Handle UI error display
        }
    }

    /// Starts a new conversation, persists it, and sets it as the current conversation.
    func startNewConversation() async {
        do {
            let newConversation = try await persistenceActor.createConversation()
            currentConversation = newConversation
            await loadAllConversations() // Refresh the list
            print("Started new conversation with ID: \(newConversation.id)")
        } catch {
            print("Error starting new conversation: \(error.localizedDescription)")
            // Handle UI error display
        }
    }

    /// Sends a user message, persists it, and triggers the AI response process.
    /// - Parameters:
    ///   - text: The content of the user's message.
    ///   - conversationID: The ID of the current conversation.
    func sendUserMessage(text: String, to conversationID: UUID) async {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        do {
            // 1. Persist user message
            let userMessage = try await persistenceActor.addMessage(to: conversationID, content: text, sender: .user, status: .completed)
            print("User message persisted: \(userMessage.id)")

            // 2. Create a placeholder for AI response and persist it
            let aiMessagePlaceholder = try await persistenceActor.addMessage(to: conversationID, content: "", sender: .ai, status: .streaming)
            print("AI message placeholder created: \(aiMessagePlaceholder.id)")

            // 3. Process AI response in a separate task
            Task {
                await processAIResponse(conversationID: conversationID, aiMessageID: aiMessagePlaceholder.id)
            }

            // Refresh current conversation to update UI if needed (e.g., in a SwiftUI @Query)
            currentConversation = try await persistenceActor.fetchConversation(id: conversationID)

        } catch {
            print("Error sending user message or creating AI placeholder: \(error.localizedDescription)")
            // Handle UI error display, potentially update user message status to error
        }
    }

    /// Processes the AI's streaming response, updating the message in SwiftData incrementally.
    /// - Parameters:
    ///   - conversationID: The ID of the current conversation.
    ///   - aiMessageID: The ID of the AI message placeholder to update.
    private func processAIResponse(conversationID: UUID, aiMessageID: UUID) async {
        let simulatedAIResponse = "Hello there! I am an AI assistant, and I am here to help you with your queries. I can provide information, generate creative content, or assist with various tasks. How can I help you today?"
        var currentAIContent = ""

        do {
            for await token in simulateAIResponseStream(fullResponse: simulatedAIResponse) {
                currentAIContent += token
                // Update the AI message content in SwiftData incrementally
                try await persistenceActor.updateMessageContent(messageID: aiMessageID, newContent: currentAIContent, newStatus: .streaming)
                // Refresh current conversation to update UI
                currentConversation = try await persistenceActor.fetchConversation(id: conversationID)
            }
            // Once streaming is complete, update the status to completed
            try await persistenceActor.updateMessageStatus(messageID: aiMessageID, newStatus: .completed)
            currentConversation = try await persistenceActor.fetchConversation(id: conversationID) // Final refresh
            print("AI response completed for message \(aiMessageID).")
        } catch {
            print("Error processing AI response for message \(aiMessageID): \(error.localizedDescription)")
            // Update AI message status to error
            do {
                try await persistenceActor.updateMessageStatus(messageID: aiMessageID, newStatus: .error)
                currentConversation = try await persistenceActor.fetchConversation(id: conversationID) // Final refresh
            } catch {
                print("Critical error: Could not update AI message \(aiMessageID) status to error: \(error.localizedDescription)")
            }
        }
    }

    /// Selects an existing conversation to make it the current one.
    /// - Parameter id: The ID of the conversation to select.
    func selectConversation(id: UUID) async {
        do {
            currentConversation = try await persistenceActor.fetchConversation(id: id)
            print("Selected conversation: \(id)")
        } catch {
            print("Error selecting conversation: \(error.localizedDescription)")
        }
    }

    /// Deletes a conversation and refreshes the list.
    /// - Parameter conversationID: The ID of the conversation to delete.
    func deleteConversation(conversationID: UUID) async {
        do {
            try await persistenceActor.deleteConversation(id: conversationID)
            await loadAllConversations()
            if currentConversation?.id == conversationID {
                currentConversation = nil // Clear current if deleted
            }
            print("Conversation \(conversationID) deleted.")
        } catch {
            print("Error deleting conversation: \(error.localizedDescription)")
        }
    }
}
