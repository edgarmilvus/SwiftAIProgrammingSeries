
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

// MARK: - Models

/// The deterministic contract we expect the LLM to fulfill.
/// Conforming to Sendable ensures this can move safely between actors and the MainActor.
struct WeatherReport: Codable, Sendable, Equatable {
    let temperature: Double
    let condition: WeatherCondition
    let summary: String
    
    enum WeatherCondition: String, Codable, Sendable {
        case sunny, cloudy, rainy, snowy, stormy
    }
}

/// Represents the various stages of our structured output pipeline.
enum ParsingResult<T: Sendable> {
    case idle
    case processing
    case success(T)
    case failure(ParsingError)
}

enum ParsingError: Error, Sendable {
    case malformedJSON(String)
    case schemaMismatch(String)
    case modelRefusal(String)
}

// MARK: - The Engine

/// An Actor that manages the stochastic-to-deterministic transformation.
/// It encapsulates the prompt engineering logic and ensures thread safety.
@available(iOS 18.0, *)
actor StructuredOutputEngine {
    
    private let apiKey: String
    private let decoder = JSONDecoder()
    
    init(apiKey: String) {
        self.apiKey = apiKey
    }
    
    /// The core method implementing the Pattern Taxonomy:
    /// 1. Schema-First (via the prompt)
    /// 2. Delimiters (via the formatting)
    /// 3. CoT (via the instruction to use 
        