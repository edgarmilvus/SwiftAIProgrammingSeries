
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import Speech
import AVFoundation

@available(iOS 18.0, *) // Adapt for macOS if needed
class QuickMemoViewController: UIViewController, SFSpeechRecognizerDelegate {

    // MARK: - UI Elements
    private let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Ready"
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let textView: UITextView = {
        let tv = UITextView()
        tv.font = .systemFont(ofSize: 18)
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8.0
        tv.isEditable = false
        tv.translatesAutoresizingMaskIntoConstraints = false
        return tv
    }()

    private let startButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Recording", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 20, weight: .bold)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let stopButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Stop Recording", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 20, weight: .bold)
        button.isEnabled = false // Disabled initially
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    // MARK: - Speech Recognition Properties
    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine() // Manages audio input and output

    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupSpeechRecognizer()
        requestSpeechAuthorization()
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground
        view.addSubview(statusLabel)
        view.addSubview(textView)
        view.addSubview(startButton)
        view.addSubview(stopButton)

        startButton.addTarget(self, action: #selector(startRecordingTapped), for: .touchUpInside)
        stopButton.addTarget(self, action: #selector(stopRecordingTapped), for: .touchUpInside)

        NSLayoutConstraint.activate([
            statusLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 30),

            textView.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 200),

            startButton.topAnchor.constraint(equalTo: textView.bottomAnchor, constant: 40),
            startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            startButton.widthAnchor.constraint(equalToConstant: 200),
            startButton.heightAnchor.constraint(equalToConstant: 50),

            stopButton.topAnchor.constraint(equalTo: startButton.bottomAnchor, constant: 20),
            stopButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stopButton.widthAnchor.constraint(equalToConstant: 200),
            stopButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    // MARK: - Speech Recognizer Setup
    private func setupSpeechRecognizer() {
        // Crucially, initialize SFSpeechRecognizer for on-device only
        // Use the current locale for better user experience, but check for on-device support.
        let desiredLocale = Locale.current // Or Locale(identifier: "en-US") for specific testing
        
        if SFSpeechRecognizer.onDeviceSupportedLocales.contains(desiredLocale) {
            self.speechRecognizer = SFSpeechRecognizer(locale: desiredLocale, onDevice: true)
            self.speechRecognizer?.delegate = self
            statusLabel.text = "Ready (On-Device)"
        } else {
            // On-device recognition not supported for the current locale.
            // Inform the user and disable functionality.
            self.speechRecognizer = nil
            statusLabel.text = "On-Device Not Supported for \(desiredLocale.identifier)"
            startButton.isEnabled = false
            print("Error: On-device recognition not supported for \(desiredLocale.identifier).")
        }
    }

    // MARK: - Authorization
    private func requestSpeechAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            // Must be on the main queue to update UI
            OperationQueue.main.addOperation { [weak self] in
                guard let self = self else { return }
                switch authStatus {
                case .authorized:
                    self.startButton.isEnabled = (self.speechRecognizer != nil)
                    self.statusLabel.text = self.speechRecognizer != nil ? "Ready (On-Device)" : "On-Device Not Supported"
                case .denied:
                    self.startButton.isEnabled = false
                    self.statusLabel.text = "Speech Authorization Denied"
                case .restricted:
                    self.startButton.isEnabled = false
                    self.statusLabel.text = "Speech Restricted on Device"
                case .notDetermined:
                    self.startButton.isEnabled = false
                    self.statusLabel.text = "Speech Authorization Not Determined"
                @unknown default:
                    self.startButton.isEnabled = false
                    self.statusLabel.text = "Unknown Authorization Status"
                }
            }
        }
    }

    // MARK: - Recording Actions
    @objc private func startRecordingTapped() {
        do {
            try startRecording()
            startButton.isEnabled = false
            stopButton.isEnabled = true
            textView.text = "" // Clear previous text
            statusLabel.text = "Recording..."
        } catch {
            print("Error starting recording: \(error.localizedDescription)")
            statusLabel.text = "Error: \(error.localizedDescription)"
            startButton.isEnabled = true
            stopButton.isEnabled = false
        }
    }

    @objc private func stopRecordingTapped() {
        stopRecording()
        startButton.isEnabled = true
        stopButton.isEnabled = false
        statusLabel.text = "Processing..."
    }

    private func startRecording() throws {
        // Cancel the previous task if it's running.
        recognitionTask?.cancel()
        self.recognitionTask = nil

        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            throw SFSpeechRecognizerError.unavailable
        }

        // Configure the audio session for recording.
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

        let inputNode = audioEngine.inputNode
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else { fatalError("Unable to create a SFSpeechAudioBufferRecognitionRequest object") }
        recognitionRequest.shouldReportPartialResults = true // For real-time updates

        // The onDevice setting is on the SFSpeechRecognizer instance, not the request.
        // The recognizer created with onDevice: true will only use on-device.

        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }
            var isFinal = false

            if let result = result {
                self.textView.text = result.bestTranscription.formattedString
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                // Stop audio engine and clean up resources
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                self.recognitionRequest = nil
                self.recognitionTask = nil
                
                // Update UI on main thread
                OperationQueue.main.addOperation {
                    self.statusLabel.text = isFinal ? "Transcription Complete" : "Error Occurred"
                    self.startButton.isEnabled = true
                    self.stopButton.isEnabled = false
                    if let error = error {
                        print("Recognition error: \(error.localizedDescription)")
                        self.statusLabel.text = "Error: \(error.localizedDescription)"
                    }
                }
            }
        }

        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer: AVAudioPCMBuffer, when: AVAudioTime) in
            self.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        try audioEngine.start()
    }

    private func stopRecording() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0) // Remove the tap to stop feeding audio
        recognitionRequest?.endAudio() // Signal the request that no more audio will be appended
        recognitionTask?.cancel() // Cancel the task if not already finished
        recognitionTask = nil
        recognitionRequest = nil
        statusLabel.text = "Ready (On-Device)"
    }

    // MARK: - SFSpeechRecognizerDelegate
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        OperationQueue.main.addOperation { [weak self] in
            guard let self = self else { return }
            if available {
                self.startButton.isEnabled = true
                self.statusLabel.text = "Ready (On-Device)"
            } else {
                self.startButton.isEnabled = false
                self.stopButton.isEnabled = false
                self.statusLabel.text = "Recognizer Unavailable (On-Device)"
            }
        }
    }
}

// Custom error for speech recognizer unavailability
enum SFSpeechRecognizerError: Error, LocalizedError {
    case unavailable
    
    var errorDescription: String? {
        switch self {
        case .unavailable:
            return "Speech recognizer is currently unavailable or not configured correctly for on-device use."
        }
    }
}
