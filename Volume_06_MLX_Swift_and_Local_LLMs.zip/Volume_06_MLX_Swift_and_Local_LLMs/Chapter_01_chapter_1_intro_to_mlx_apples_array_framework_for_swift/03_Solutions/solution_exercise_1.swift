
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

@available(iOS 18.0, macOS 14.0, *)
import MLX

/// Normalizes a 3D MLXArray image from [0, 255] to [-1, 1].
///
/// - Parameter image: A 3D MLXArray representing an image with Float pixel values
///                    in the range [0, 255]. Expected shape: [height, width, channels].
/// - Returns: A new MLXArray with pixel values normalized to the range [-1, 1].
func normalizeImage(_ image: MLXArray) -> MLXArray {
    // Ensure the image data is Float type, as required for the formula.
    // If it's already Float, astype() is a no-op or very cheap.
    let floatImage = image.astype(Float.self)

    // Apply the normalization formula: (pixel / 127.5) - 1
    // MLXArray operations are element-wise when scalars are involved.
    let normalized = (floatImage / 127.5) - 1.0
    return normalized
}

// Example usage:
// A small 2x3 image with 2 channels (e.g., Red and Green values)
let sampleImagePixels: [Float] = [
    0,   50,  100, 150, 200, 255, // Channel 1 data
    255, 200, 150, 100, 50,  0    // Channel 2 data
]
// Reshape to [height, width, channels] -> [2, 3, 2]
let sampleImage = MLXArray(sampleImagePixels, shape: [2, 3, 2])

print("Original Image (first channel, first row):\n", sampleImage[0, 0].eval())
print("Original Image (first channel, second row):\n", sampleImage[0, 1].eval())

let normalizedImage = normalizeImage(sampleImage)

print("\nNormalized Image (first channel, first row):\n", normalizedImage[0, 0].eval())
print("Normalized Image (first channel, second row):\n", normalizedImage[0, 1].eval())

// Verify a specific pixel value transformation:
// Original: 0 -> (0 / 127.5) - 1 = -1
// Original: 255 -> (255 / 127.5) - 1 = 2 - 1 = 1
// Original: 127.5 -> (127.5 / 127.5) - 1 = 1 - 1 = 0
let midValueImage = MLXArray([127.5], shape: [1, 1, 1])
let normalizedMidValue = normalizeImage(midValueImage)
print("\nNormalized 127.5 pixel:", normalizedMidValue.eval())
