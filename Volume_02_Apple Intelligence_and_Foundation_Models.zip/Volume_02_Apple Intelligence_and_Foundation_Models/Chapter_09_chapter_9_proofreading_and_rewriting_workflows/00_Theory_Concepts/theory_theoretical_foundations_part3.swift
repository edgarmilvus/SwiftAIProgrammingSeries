
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

// (ViewModel definition as above, using @Observable)
@available(iOS 18.0, *)
import SwiftUI

@Observable // Make the ViewModel observable for SwiftUI
class DocumentEditorViewModel {
    var documentText: String = "The quick brown fox jump over the lazy dog." {
        didSet {
            // Automatically request suggestions when text changes
            Task { await requestProofreadingSuggestionsViaActor() }
        }
    }
    var suggestions: [WritingSuggestion] = []
    var isLoading: Bool = false

    private let aiActor = AIManagementActor() // Instantiate the actor

    // ... (requestProofreadingSuggestionsViaActor implementation as above)
}

@available(iOS 18.0, *)
struct DocumentEditorView: View {
    @State private var viewModel = DocumentEditorViewModel() // Observe the ViewModel

    var body: some View {
        VStack {
            TextEditor(text: $viewModel.documentText)
                .frame(height: 200)
                .border(Color.gray)
                .padding()

            if viewModel.isLoading {
                ProgressView()
            } else {
                List(viewModel.suggestions, id: \.id) { suggestion in
                    VStack(alignment: .leading) {
                        Text(suggestion.description)
                            .font(.headline)
                        if let replacement = suggestion.replacement {
                            Text("Replacement: \(replacement)")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
        }
        .navigationTitle("Intelligent Editor")
        .task {
            // Initial load of suggestions
            await viewModel.requestProofreadingSuggestionsViaActor()
        }
    }
}
