
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import Observation

enum InteractionMode: Sendable {
    case rewrite
    case suggestions
}

class TelemetryService: Sendable {
    static let shared = TelemetryService()
    func trackAction(type: String, success: Bool) {
        print("[Telemetry] Action: \(type) | Success: \(success)")
    }
}

@Observable
@available(iOS 18.0, *)
class EditorInteractionManager {
    var currentMode: InteractionMode = .rewrite
    private let flagProvider: FeatureFlagProvider
    
    init(flagProvider: FeatureFlagProvider) {
        self.flagProvider = flagProvider
    }
    
    func refreshMode() async {
        let useSuggestions = await flagProvider.isEnabled(.experimentalPromptV2)
        // Mapping experimental flag to specific interaction mode
        self.currentMode = useSuggestions ? .suggestions : .rewrite
    }
    
    func trackAction(type: String, success: Bool) {
        TelemetryService.shared.trackAction(type: type, success: success)
    }
}

struct ZenWriteEditorView: View {
    @State private var manager: EditorInteractionManager
    @State private var text: String = "Once upon a time..."
    @State private var isProcessing: Bool = false
    
    init(flagProvider: FeatureFlagProvider) {
        _manager = State(initialValue: EditorInteractionManager(flagProvider: flagProvider))
    }
    
    var body: some View {
        VStack {
            TextEditor(text: $text)
                .overlay(alignment: .bottom) {
                    if manager.currentMode == .suggestions {
                        suggestionOverlay
                    }
                }
            
            if manager.currentMode == .rewrite {
                rewriteToolbar
            }
        }
        .task {
            await manager.refreshMode()
        }
    }
    
    // Pattern A: Floating Toolbar
    private var rewriteToolbar: some View {
        HStack {
            Button("Smart Rewrite") {
                Task { await performRewrite() }
            }
            .disabled(isProcessing)
            if isProcessing { ProgressView() }
        }
        .padding()
        .background(.ultraThinMaterial)
    }
    
    // Pattern B: Inline Ghost Text (Simulated)
    private var suggestionOverlay: some View {
        Text("Tab to accept suggestion...")
            .font(.caption)
            .foregroundStyle(.secondary)
            .padding(4)
            .background(.ultraThinMaterial)
            .cornerRadius(4)
            .padding(.bottom, 40)
    }
    
    private func performRewrite() async {
        isProcessing = true
        // Simulate AI Delay
        try? await Task.sleep(for: .seconds(1.5))
        text = "The rewritten version of the story."
        isProcessing = false
        manager.trackAction(type: "rewrite_request", success: true)
    }
}
