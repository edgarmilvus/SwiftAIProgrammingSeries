
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import ARKit
import Observation

/// A thread-safe manager for handling spatial sensor data.
/// Using an `actor` ensures that the sensitive state of our 
/// spatial awareness is isolated from concurrent data races.
@available(visionOS 1.0, *)
actor SpatialSensorManager {
    
    // The current state of the world, encapsulated within the actor.
    // This is protected from external mutation.
    private(set) var lastKnownHandPose: HandPose?
    private(set) var isTrackingActive: Bool = false

    /// Updates the internal state with new data from the system.
    /// The input `pose` must be `Sendable` to cross the actor boundary.
    func updateHandPose(_ pose: HandPose) {
        self.lastKnownHandPose = pose
        self.isTrackingActive = true
    }
    
    func reset() {
        lastKnownHandPose = nil
        isTrackingActive = false
    }
}

/// An observable model that the UI uses to react to sensor changes.
/// We use @Observable to bridge the gap between the Actor (background)
/// and the @MainActor (UI).
@available(visionOS 1.0, *)
@Observable
@MainActor
class SpatialAIViewModel {
    
    var handPosition: SIMD3<Float> = .zero
    var isHandDetected: Bool = false
    
    private let sensorManager = SpatialSensorManager()

    /// This function demonstrates the async/await pattern required to 
    /// safely bridge the gap between the background sensor actor 
    /// and the main UI thread.
    func processSensorUpdate(newPose: HandPose) async {
        // 1. Send the data to the isolated actor for safe storage/processing.
        // This is a 'cross-actor' call, which is safe because HandPose is Sendable.
        await sensorManager.updateHandPose(newPose)
        
        // 2. Retrieve the data back to the MainActor to update the UI.
        // This ensures the UI update happens on the correct thread.
        if let pose = await sensorManager.lastKnownHandPose {
            self.handPosition = pose.anchorPose.translation
            self.isHandDetected = true
        }
    }
}
