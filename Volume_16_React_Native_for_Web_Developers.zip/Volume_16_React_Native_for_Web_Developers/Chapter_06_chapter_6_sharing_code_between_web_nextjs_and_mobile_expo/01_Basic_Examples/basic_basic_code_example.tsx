/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Button.tsx
 * This file acts as the "entry point" for the shared component. In a universal setup,
 * the bundler looks for this file first. However, to demonstrate platform-specific logic,
 * we will usually rely on the bundler's automatic resolution of `.web.tsx` and `.native.tsx`.
 * 
 * For this example, we will explicitly create two separate files to demonstrate the architecture.
 */

// ==========================================
// File 1: packages/ui/src/Button.web.tsx
// ==========================================

import React from 'react';

/**
 * Web Implementation of the Button.
 * Uses a standard HTML <button> element.
 * @param {ButtonProps} props - The component props.
 */
export const Button = ({ label, onPress }: { label: string; onPress: () => void }) => {
  return (
    <button 
      onClick={onPress}
      style={{ 
        padding: '10px 20px', 
        backgroundColor: '#0070f3', 
        color: 'white', 
        borderRadius: '8px',
        border: 'none',
        cursor: 'pointer'
      }}
    >
      {label}
    </button>
  );
};

// ==========================================
// File 2: packages/ui/src/Button.native.tsx
// ==========================================

import React from 'react';
import { Pressable, Text, StyleSheet } from 'react-native';

/**
 * Native Implementation of the Button.
 * Uses React Native's <Pressable> and <Text> components.
 * @param {ButtonProps} props - The component props.
 */
export const Button = ({ label, onPress }: { label: string; onPress: () => void }) => {
  return (
    <Pressable 
      style={styles.button} 
      onPress={onPress}
      android_ripple={{ color: '#ccc' }} // Android ripple effect
    >
      <Text style={styles.text}>{label}</Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  button: {
    backgroundColor: '#0070f3',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 8,
  },
  text: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});
