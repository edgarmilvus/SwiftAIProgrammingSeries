
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import NaturalLanguage

func categorizeNoteByLanguageAndKeywords(noteText: String) -> (language: NLLanguage, category: String) {
    // 1. Language Identification
    let tagger = NLTagger(tagSchemes: [.language])
    tagger.string = noteText

    // Get the dominant language of the note
    let dominantLanguage = tagger.dominantLanguage ?? .undetermined

    // 2. Keyword-based Categorization
    var category = "General" // Default category

    switch dominantLanguage {
    case .english:
        let englishWorkKeywords = ["meeting", "agenda", "report", "project", "deadline", "task"]
        let englishPersonalKeywords = ["recipe", "shopping", "diary", "vacation", "family", "friends"]

        if englishWorkKeywords.contains(where: { noteText.localizedStandardContains($0) }) {
            category = "Work"
        } else if englishPersonalKeywords.contains(where: { noteText.localizedStandardContains($0) }) {
            category = "Personal"
        }
    case .spanish:
        let spanishWorkKeywords = ["reunión", "agenda", "informe", "proyecto", "plazo", "tarea"]
        let spanishPersonalKeywords = ["receta", "compras", "diario", "vacaciones", "familia", "amigos"]

        if spanishWorkKeywords.contains(where: { noteText.localizedStandardContains($0) }) {
            category = "Trabajo" // Spanish for Work
        } else if spanishPersonalKeywords.contains(where: { noteText.localizedStandardContains($0) }) {
            category = "Personal" // Spanish for Personal
        }
    // Add more languages and their keywords as needed
    case .undetermined:
        category = "Undetermined Language"
    default:
        category = "Other Language"
    }

    return (language: dominantLanguage, category: category)
}

// Example Usage (for testing your implementation)
/*
let englishNote = "Today's meeting agenda includes budget review and project status update."
let spanishNote = "Necesito comprar leche, pan y huevos para la receta de esta noche."
let frenchNote = "Bonjour, je dois faire une présentation pour le projet demain." // Untagged for specific keywords
let germanNote = "Ich muss einkaufen gehen und dann ein Buch lesen."

let (lang1, cat1) = categorizeNoteByLanguageAndKeywords(noteText: englishNote)
let (lang2, cat2) = categorizeNoteByLanguageAndKeywords(noteText: spanishNote)
let (lang3, cat3) = categorizeNoteByLanguageAndKeywords(noteText: frenchNote)
let (lang4, cat4) = categorizeNoteByLanguageAndKeywords(noteText: germanNote)

print("English Note: Language \(lang1), Category: \(cat1)") // Expected: .english, Work
print("Spanish Note: Language \(lang2), Category: \(cat2)") // Expected: .spanish, Personal
print("French Note: Language \(lang3), Category: \(cat3)") // Expected: .french, Other Language (or General)
print("German Note: Language \(lang4), Category: \(cat4)") // Expected: .german, Other Language (or General)
*/
