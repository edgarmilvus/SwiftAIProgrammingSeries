
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// This code is designed for Swift 6 and the latest iOS/macOS SDKs.
// It uses features available from iOS 17.0, ensuring compatibility with modern SwiftUI.

import SwiftUI
import Foundation // For UUID and Task.sleep

/// An identifiable structure to represent a single token in the stream.
/// Using a UUID ensures each token has a unique, stable identity, which is crucial for ForEach performance.
struct Token: Identifiable, Equatable {
    let id = UUID()
    let text: String
}

/// A ViewModel responsible for simulating the AI token stream.
/// It publishes changes to its 'tokens' array, which the SwiftUI view observes.
@MainActor // Ensures all UI-related updates happen on the main thread.
class TokenStreamViewModel: ObservableObject {
    @Published var tokens: [Token] = []
    @Published var isStreaming: Bool = false

    private var streamTask: Task<Void, Never>?

    /// Simulates an AI generating a response token by token.
    /// This asynchronous function adds tokens to the 'tokens' array with a delay.
    func startStreaming() {
        guard !isStreaming else { return } // Prevent multiple simultaneous streams
        isStreaming = true
        tokens = [] // Clear previous stream for a new simulation

        let exampleResponse = "Hello! I am an AI assistant. I can help you with a variety of tasks, from answering questions to generating creative content. How can I assist you today?"
        let words = exampleResponse.components(separatedBy: " ")

        streamTask = Task {
            for word in words {
                // Simulate network delay for each token
                try? await Task.sleep(for: .milliseconds(150))
                tokens.append(Token(text: word + " ")) // Add a space after each word for readability
            }
            isStreaming = false
        }
    }

    /// Stops the current streaming task if one is active.
    func stopStreaming() {
        streamTask?.cancel()
        streamTask = nil
        isStreaming = false
    }

    /// Clears all tokens from the display.
    func clearTokens() {
        stopStreaming()
        tokens = []
    }
}

/// The main SwiftUI view for displaying the AI token stream.
/// It uses ScrollViewReader to automatically scroll to the latest token.
@available(iOS 17.0, macOS 14.0, *) // Specify minimum deployment target for modern SwiftUI features
struct TokenStreamView: View {
    @StateObject private var viewModel = TokenStreamViewModel()
    
    // A unique ID to target the very last item in the list for scrolling.
    // Using a specific ID (e.g., "bottomID") is often more robust than trying to scroll to the last item's dynamic ID,
    // especially when the list might be empty or in flux.
    private let bottomScrollID = "bottomOfStream"

    var body: some View {
        VStack(spacing: 0) {
            Text("AI Voice Assistant Response")
                .font(.headline)
                .padding(.bottom, 8)

            // 1. Wrap the ScrollView with ScrollViewReader
            ScrollViewReader { proxy in
                ScrollView {
                    // 2. Use LazyVStack for performance with potentially many tokens
                    LazyVStack(alignment: .leading, spacing: 4) {
                        if viewModel.tokens.isEmpty {
                            Text("Waiting for AI response...")
                                .foregroundColor(.gray)
                                .padding()
                        } else {
                            // 3. Iterate over tokens, ensuring each has a stable ID
                            ForEach(viewModel.tokens) { token in
                                Text(token.text)
                                    .font(.body)
                                    .padding(.horizontal, 4)
                                    .background(Color.blue.opacity(0.1))
                                    .cornerRadius(5)
                            }
                            // 4. Place an invisible view at the very bottom with a known ID
                            // This is our target for automatic scrolling.
                            Rectangle()
                                .fill(Color.clear)
                                .frame(height: 1) // Minimal height
                                .id(bottomScrollID) // Assign a stable ID
                        }
                    }
                    .padding()
                }
                .background(Color.white)
                .cornerRadius(10)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                )
                .frame(maxHeight: 300) // Constrain height for demonstration

                // 5. Observe changes in the token count
                .onChange(of: viewModel.tokens.count) { newCount in
                    // 6. When new tokens arrive, scroll to the bottom
                    if newCount > 0 {
                        // Use a small delay to ensure the UI has updated and rendered the new token
                        // before attempting to scroll. This can prevent glitches.
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                            withAnimation {
                                proxy.scrollTo(bottomScrollID, anchor: .bottom)
                            }
                        }
                    }
                }
            }

            // Control buttons
            HStack {
                Button(action: viewModel.startStreaming) {
                    Label("Start Stream", systemImage: "play.fill")
                }
                .disabled(viewModel.isStreaming)
                .buttonStyle(.borderedProminent)

                Button(action: viewModel.stopStreaming) {
                    Label("Stop Stream", systemImage: "stop.fill")
                }
                .disabled(!viewModel.isStreaming)
                .buttonStyle(.bordered)

                Button(action: viewModel.clearTokens) {
                    Label("Clear", systemImage: "xmark.circle.fill")
                }
                .buttonStyle(.bordered)
            }
            .padding(.top)
        }
        .padding()
        .frame(minWidth: 400, minHeight: 500) // For macOS window sizing
    }
}

// MARK: - Preview Provider
@available(iOS 17.0, macOS 14.0, *)
#Preview {
    TokenStreamView()
}
