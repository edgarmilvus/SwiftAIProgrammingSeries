
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import NaturalLanguage // For NLTagger, Apple's built-in NLP framework
import CoreML // For integrating custom machine learning models

// MARK: - 1. Define Sentiment Categories

/// Represents the possible sentiment categories for a given text.
/// This enum is designed to be extensible for more nuanced sentiment analysis
/// beyond just positive/negative.
enum SentimentCategory: String, Codable, CaseIterable {
    case positive = "Positive"
    case neutral = "Neutral"
    case negative = "Negative"
    case mixed = "Mixed" // Indicates presence of both positive and negative aspects
    case undefined = "Undefined" // Default or error state, or when sentiment cannot be determined
}

// MARK: - 2. Error Handling

/// Custom errors that can occur during sentiment analysis operations.
/// This provides specific context for debugging and user feedback.
enum SentimentAnalysisError: Error, LocalizedError {
    case modelLoadingFailed(String)
    case predictionFailed(String)
    case invalidInput(String)
    case unknownError(String)

    /// Provides a user-friendly description for each error type.
    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let message):
            return "Failed to load sentiment model: \(message)"
        case .predictionFailed(let message):
            return "Sentiment prediction failed: \(message)"
        case .invalidInput(let message):
            return "Invalid input for analysis: \(message)"
        case .unknownError(let message):
            return "An unknown error occurred: \(message)"
        }
    }
}

// MARK: - 3. Custom Core ML Model Integration (Conceptual)

/// A conceptual wrapper for a custom Core ML sentiment model.
/// In a real application, this class would load and interact with a generated
/// `MLModel` class (e.g., `MyCustomSentimentModel`).
///
/// For this pedagogical example, it simulates model loading and prediction logic
/// to demonstrate the integration pattern without requiring an actual `.mlmodel` file.
@available(iOS 18.0, *) // Using iOS 18.0 to demonstrate `@available` and future-proof patterns
class CustomSentimentModel {
    let modelName: String

    /// Initializes the custom sentiment model wrapper.
    /// - Parameter modelName: The name of the Core ML model asset (e.g., "ProductSentimentClassifier").
    ///   In a real scenario, this would attempt to load the compiled `.mlmodelc` from the app bundle.
    /// - Throws: `SentimentAnalysisError.modelLoadingFailed` if the model cannot be found or loaded.
    init(modelName: String) throws {
        self.modelName = modelName
        // Simulate model loading success/failure for demonstration
        if modelName.isEmpty || modelName == "InvalidModel" {
            throw SentimentAnalysisError.modelLoadingFailed("Model '\(modelName)' not found or invalid.")
        }
        print("✅ Custom sentiment model '\(modelName)' conceptually loaded.")
    }

    /// Predicts the sentiment category for a given text using the custom model.
    /// - Parameter text: The input text string to analyze.
    /// - Returns: The predicted `SentimentCategory`.
    /// - Throws: `SentimentAnalysisError.predictionFailed` if the prediction process encounters an issue.
    func predictSentiment(for text: String) throws -> SentimentCategory {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw SentimentAnalysisError.invalidInput("Input text cannot be empty for custom model prediction.")
        }

        // --- REAL-WORLD CORE ML INTEGRATION WOULD GO HERE ---
        // Example of how a real Core ML model would be used:
        // guard let model = try? MyCustomSentimentModel(configuration: MLModelConfiguration()) else {
        //     throw SentimentAnalysisError.modelLoadingFailed("Could not instantiate MyCustomSentimentModel.")
        // }
        // let prediction = try model.prediction(text: text)
        // let sentimentLabel = prediction.label // Assuming the model outputs a string label
        // return SentimentCategory(rawValue: sentimentLabel) ?? .undefined
        // ---------------------------------------------------

        // Simulate prediction logic for pedagogical purposes based on keywords.
        // This allows the example to run without an actual .mlmodel file.
        let lowercasedText = text.lowercased()
        if lowercasedText.contains("excellent") || lowercasedText.contains("love") || lowercasedText.contains("fantastic") {
            return .positive
        } else if lowercasedText.contains("bad") || lowercasedText.contains("terrible") || lowercasedText.contains("hate") {
            return .negative
        } else if lowercasedText.contains("okay") || lowercasedText.contains("average") {
            return .neutral
        } else if lowercasedText.contains("but") && (lowercasedText.contains("good") || lowercasedText.contains("bad")) {
            return .mixed
        } else {
            return .neutral // Default for simulated model
        }
    }
}

// MARK: - 4. Data Structure for Feedback

/// Represents a single piece of customer feedback, including its original text,
/// the analyzed sentiment, and metadata about the analysis.
struct FeedbackEntry: Identifiable, CustomStringConvertible {
    let id = UUID() // Unique identifier for each feedback entry
    let text: String
    var sentiment: SentimentCategory? // The determined sentiment
    var analysisMethod: String? // Which method was used (NLTagger or Custom Model)
    var error: Error? // Any error encountered during analysis

    var description: String {
        let sentimentString = sentiment?.rawValue ?? "N/A"
        let methodString = analysisMethod ?? "N/A"
        let errorString = error != nil ? " (Error: \(error!.localizedDescription))" : ""
        return "Feedback: \"\(text)\" -> Sentiment: \(sentimentString) (Method: \(methodString))\(errorString)"
    }
}

// MARK: - 5. Sentiment Analysis Service

/// A robust sentiment analysis service that can utilize both `NLTagger`'s built-in
/// sentiment analysis and a custom Core ML model for domain-specific insights.
/// It prioritizes the custom model if available.
@available(iOS 18.0, *)
class SentimentAnalyzer {
    private let customModel: CustomSentimentModel? // Optional custom model
    private let nlTagger: NLTagger // NLTagger instance for built-in sentiment

    /// Initializes the `SentimentAnalyzer`.
    /// - Parameter customModelName: The name of the custom Core ML model to use.
    ///   If `nil`, only `NLTagger`'s built-in sentiment analysis will be available.
    /// - Throws: `SentimentAnalysisError.modelLoadingFailed` if the custom model fails to load.
    init(customModelName: String? = nil) throws {
        // NLTagger is initialized with the .sentimentScore tag scheme.
        self.nlTagger = NLTagger(tagSchemes: [.sentimentScore])

        if let modelName = customModelName {
            // Attempt to load the custom model if a name is provided.
            self.customModel = try CustomSentimentModel(modelName: modelName)
        } else {
            self.customModel = nil
            print("ℹ️ No custom model provided. Using only NLTagger's built-in sentiment.")
        }
    }

    /// Analyzes the sentiment of a single piece of text.
    /// It prioritizes the custom model if available and falls back to `NLTagger`
    /// if the custom model fails or is not provided.
    /// - Parameter text: The input string to analyze.
    /// - Returns: A tuple containing the `SentimentCategory` and the method used for analysis.
    /// - Throws: `SentimentAnalysisError` if analysis fails even after fallback.
    func analyzeSentiment(for text: String) async throws -> (SentimentCategory, String) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw SentimentAnalysisError.invalidInput("Input text cannot be empty for sentiment analysis.")
        }

        // 5.1. Attempt to use the custom Core ML model first (if available)
        if let customModel = self.customModel {
            do {
                let sentiment = try customModel.predictSentiment(for: text)
                return (sentiment, "Custom Model (\(customModel.modelName))")
            } catch let error as SentimentAnalysisError {
                // Log the custom model failure and attempt to fallback to NLTagger.
                print("⚠️ Custom model prediction failed for text: \"\(text)\" with error: \(error.localizedDescription). Falling back to NLTagger.")
            } catch {
                // Catch any other unexpected errors from the custom model.
                print("⚠️ Unexpected error with custom model for text: \"\(text)\": \(error.localizedDescription). Falling back to NLTagger.")
            }
        }

        // 5.2. Fallback to NLTagger's built-in sentiment analysis
        // Set the string for NLTagger to analyze.
        nlTagger.string = text
        // Perform sentiment tagging for the entire document.
        let (sentimentScoreTag, _) = nlTagger.tag(at: text.startIndex, unit: .document, scheme: .sentimentScore)

        guard let scoreString = sentimentScoreTag?.rawValue, let score = Double(scoreString) else {
            // If NLTagger cannot provide a score, return undefined.
            return (.undefined, "NLTagger (Score N/A)")
        }

        // NLTagger returns a sentiment score between -1.0 (most negative) and 1.0 (most positive).
        // We map this continuous score to our discrete `SentimentCategory` enum.
        switch score {
        case 0.001...1.0: return (.positive, "NLTagger")
        case -0.001..<0.001: return (.neutral, "NLTagger") // Scores very close to zero are considered neutral
        case -1.0..<(-0.001): return (.negative, "NLTagger")
        default: return (.undefined, "NLTagger (Score Out of Range)") // Should not happen with valid scores
        }
    }

    /// Analyzes a batch of feedback entries concurrently using Swift 6 concurrency (`TaskGroup`).
    /// This is ideal for processing many feedback items efficiently without blocking the main thread.
    /// - Parameter feedbackEntries: An array of `FeedbackEntry` objects to analyze.
    /// - Returns: An array of `FeedbackEntry` objects with sentiment and analysis method populated.
    func analyzeFeedbackBatch(feedbackEntries: [FeedbackEntry]) async -> [FeedbackEntry] {
        var analyzedFeedback = [FeedbackEntry]()
        // Use a TaskGroup to run multiple analysis tasks in parallel.
        await withTaskGroup(of: FeedbackEntry.self) { group in
            for var entry in feedbackEntries {
                // Add each feedback entry's analysis as a separate task to the group.
                group.addTask {
                    do {
                        let (sentiment, method) = try await self.analyzeSentiment(for: entry.text)
                        entry.sentiment = sentiment
                        entry.analysisMethod = method
                    } catch {
                        // If an error occurs, record it in the feedback entry.
                        entry.sentiment = .undefined
                        entry.analysisMethod = "Error"
                        entry.error = error
                        print("❌ Failed to analyze feedback \"\(entry.text)\": \(error.localizedDescription)")
                    }
                    return entry // Return the updated entry
                }
            }

            // Collect results as they complete. The order of completion is not guaranteed.
            for await result in group {
                analyzedFeedback.append(result)
            }
        }
        // Sort the results by ID to maintain a consistent order, useful for UI display.
        return analyzedFeedback.sorted { $0.id.uuidString < $1.id.uuidString }
    }
}

// MARK: - 6. Real-world Application Context: Enterprise Feedback Analysis Dashboard

/// This `ObservableObject` class simulates a ViewModel for an Enterprise Feedback Dashboard.
/// It manages the state, triggers analysis, and provides results for a hypothetical UI.
@available(iOS 18.0, *)
class EnterpriseFeedbackDashboardViewModel: ObservableObject {
    @Published var feedbackToAnalyze: [FeedbackEntry] = [] // Raw feedback awaiting analysis
    @Published var analyzedFeedback: [FeedbackEntry] = [] // Results after analysis
    @Published var isLoading: Bool = false // Indicates if analysis is in progress
    @Published var errorMessage: String? // Stores any errors for UI display

    private var sentimentAnalyzer: SentimentAnalyzer? // The core analysis service

    /// Initializes the view model, attempting to set up the sentiment analyzer.
    /// - Parameter useCustomModel: A boolean indicating whether to attempt loading a custom Core ML model.
    init(useCustomModel: Bool = true) {
        setupAnalyzer(useCustomModel: useCustomModel)
    }

    /// Configures the `SentimentAnalyzer` instance based on whether a custom model should be used.
    private func setupAnalyzer(useCustomModel: Bool) {
        isLoading = true
        errorMessage = nil
        do {
            // If useCustomModel is true, provide a model name; otherwise, pass nil for NLTagger only.
            let modelName = useCustomModel ? "ProductSentimentClassifier" : nil
            self.sentimentAnalyzer = try SentimentAnalyzer(customModelName: modelName)
            print("✅ SentimentAnalyzer initialized successfully.")
        } catch {
            self.errorMessage = "Failed to initialize SentimentAnalyzer: \(error.localizedDescription)"
            print("❌ Initialization error: \(error.localizedDescription)")
        }
        isLoading = false
    }

    /// Loads a sample set of feedback entries into the `feedbackToAnalyze` array.
    func loadSampleFeedback() {
        feedbackToAnalyze = [
            FeedbackEntry(text: "The new feature is excellent, but the UI is a bit clunky."),
            FeedbackEntry(text: "Terrible customer service, very slow response times."),
            FeedbackEntry(text: "The product works as expected, nothing special."),
            FeedbackEntry(text: "I love the design and performance!"),
            FeedbackEntry(text: "It's okay, could be better."),
            FeedbackEntry(text: "The app crashed frequently, very frustrating."),
            FeedbackEntry(text: "Absolutely fantastic experience, highly recommend!"),
            FeedbackEntry(text: "The documentation is unclear, but the support team was helpful."),
            FeedbackEntry(text: "This is just a test sentence."),
            FeedbackEntry(text: "") // Empty input to test error handling
        ]
        analyzedFeedback = [] // Clear previous results when loading new feedback
        print("✅ Sample feedback loaded.")
    }

    /// Triggers the sentiment analysis for the loaded feedback entries.
    /// This method uses a `Task` to perform the asynchronous analysis.
    func performAnalysis() {
        guard let analyzer = sentimentAnalyzer else {
            errorMessage = "Sentiment analyzer not initialized."
            return
        }

        isLoading = true
        errorMessage = nil
        // A detached Task is used here to run the async operation without tying it to a specific view lifecycle,
        // mimicking a background operation in a real app.
        Task {
            let results = await analyzer.analyzeFeedbackBatch(feedbackEntries: feedbackToAnalyze)
            // Update UI-bound properties on the main actor.
            await MainActor.run {
                self.analyzedFeedback = results
                self.isLoading = false
                print("✅ Analysis complete.")
            }
        }
    }

    /// Resets the analysis state of the dashboard.
    func reset() {
        feedbackToAnalyze = []
        analyzedFeedback = []
        errorMessage = nil
        isLoading = false
        print("🔄 Analysis reset.")
    }
}

// MARK: - Main Execution Context (Simulating an App Entry Point)

/// This function demonstrates how the `EnterpriseFeedbackDashboardViewModel`
/// would be used in a main application entry point or a Swift Playground.
@available(iOS 18.0, *)
func runSentimentAnalysisDemo() async {
    print("--- Starting Enterprise Feedback Analysis Demo ---")

    // Scenario 1: Initialize the ViewModel with a custom model enabled.
    // The custom model will be prioritized.
    let viewModelWithCustomModel = EnterpriseFeedbackDashboardViewModel(useCustomModel: true)

    // Simulate loading feedback into the dashboard.
    viewModelWithCustomModel.loadSampleFeedback()

    // Simulate a user action to perform analysis.
    print("\n--- Performing Analysis with Custom Model (and NLTagger fallback) ---")
    viewModelWithCustomModel.performAnalysis()

    // In a real app, the UI would observe `viewModelWithCustomModel.analyzedFeedback`.
    // For this demo, we'll wait a short period for the async tasks to complete.
    try? await Task.sleep(for: .seconds(2))

    if let error = viewModelWithCustomModel.errorMessage {
        print("❌ Dashboard Error: \(error)")
    } else {
        print("\n--- Analysis Results (Custom Model Priority) ---")
        viewModelWithCustomModel.analyzedFeedback.forEach { print($0) }
    }

    // Scenario 2: Demonstrate analysis using NLTagger only (no custom model).
    print("\n--- Resetting and Performing Analysis with NLTagger Only ---")
    let nlTaggerOnlyViewModel = EnterpriseFeedbackDashboardViewModel(useCustomModel: false)
    nlTaggerOnlyViewModel.loadSampleFeedback()
    nlTaggerOnlyViewModel.performAnalysis()

    try? await Task.sleep(for: .seconds(2))

    if let error = nlTaggerOnlyViewModel.errorMessage {
        print("❌ Dashboard Error (NLTagger Only): \(error)")
    } else {
        print("\n--- Analysis Results (NLTagger Only) ---")
        nlTaggerOnlyViewModel.analyzedFeedback.forEach { print($0) }
    }

    print("\n--- Demo Finished ---")
}

// To run this demo in a Swift Playground or a main app entry point:
// await runSentimentAnalysisDemo()
