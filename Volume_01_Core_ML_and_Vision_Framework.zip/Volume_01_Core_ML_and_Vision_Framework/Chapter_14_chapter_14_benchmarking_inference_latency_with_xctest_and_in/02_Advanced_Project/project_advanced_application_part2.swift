
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import CoreML
import Vision
import UIKit
import ImageIO
import os.log // For advanced logging and Instruments integration

/// @available(iOS 17.0, *)
/// A protocol defining the common interface for Core ML object detection models.
/// This allows for interchangeable use and benchmarking of different models.
protocol ObjectDetectionModel {
    /// A unique identifier for the model (e.g., "FastDetector", "AccurateDetector").
    var modelIdentifier: String { get }

    /// The underlying `MLModel` instance.
    var coreMLModel: MLModel { get }

    /// Performs object detection on a given `CVPixelBuffer`.
    /// - Parameter pixelBuffer: The input image buffer for detection.
    /// - Returns: An array of `VNRecognizedObjectObservation` representing detected objects.
    /// - Throws: An error if the prediction fails.
    func predict(pixelBuffer: CVPixelBuffer) async throws -> [VNRecognizedObjectObservation]
}
