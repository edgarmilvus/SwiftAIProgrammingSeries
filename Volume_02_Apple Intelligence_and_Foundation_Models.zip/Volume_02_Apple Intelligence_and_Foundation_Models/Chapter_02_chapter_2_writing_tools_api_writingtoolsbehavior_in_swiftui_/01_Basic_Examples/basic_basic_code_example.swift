
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Foundation // Although not strictly necessary for this basic example, often useful for text processing

/// A simple SwiftUI view demonstrating the integration of Apple Intelligence Writing Tools.
/// This view provides a text editor where users can type and access system-level writing
/// suggestions and tools like rephrase, summarize, or proofread, provided by Apple Intelligence.
@available(iOS 18.0, *) // Apple Intelligence features require iOS 18.0 or later.
struct AIDocumentEditorView: View {
    // 1. State Variable for Text Content
    /// `@State` property to hold the text content of our document editor.
    /// Changes to this variable will automatically update the `TextEditor`.
    @State private var documentText: String = "Start typing your document here. Try writing a sentence and then using the system's writing tools to rephrase it. For example, type 'The quick brown fox jumps over the lazy dog.' and then select the sentence to see the options."

    var body: some View {
        NavigationView { // Provides a navigation bar for the title
            VStack(spacing: 15) {
                Text("Your Document")
                    .font(.headline)
                    .padding(.top)

                // 2. TextEditor for User Input
                /// `TextEditor` is a multi-line text input view in SwiftUI.
                /// It's suitable for editing longer blocks of text, like a document.
                TextEditor(text: $documentText)
                    .frame(minHeight: 200, maxHeight: .infinity) // Flexible height for the editor
                    .padding(8)
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.gray.opacity(0.4), lineWidth: 1) // Add a subtle border
                    )
                    .padding(.horizontal)
                    // 3. Applying writingToolsBehavior Modifier
                    /// This is the core of the example. The `.writingToolsBehavior(.automatic)`
                    /// modifier tells the system to automatically enable Apple Intelligence
                    /// writing tools for this `TextEditor`.
                    ///
                    /// When enabled, users can long-press on text, select text, or use the
                    /// context menu to access features like:
                    /// - **Rephrase:** Suggests alternative ways to phrase selected text.
                    /// - **Proofread:** Checks for grammar, spelling, and punctuation errors.
                    /// - **Summarize:** Provides a concise summary of selected text (if applicable).
                    /// - **Generate:** Can generate text based on prompts (not directly shown here,
                    ///   but part of the broader Apple Intelligence framework, often invoked via context menu).
                    ///
                    /// Other options for `WritingToolsBehavior` include:
                    /// - `.disabled`: Explicitly disables all writing tools for this view.
                    /// - `.custom(isEnabled: Binding<Bool>)`: Allows dynamic control over
                    ///   whether writing tools are enabled or disabled, based on a boolean binding.
                    .writingToolsBehavior(.automatic)

                Spacer() // Pushes content to the top
            }
            .navigationTitle("AI Document Editor") // Title for the navigation bar
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

/// A preview provider for the `AIDocumentEditorView`.
/// This allows you to see your SwiftUI view in Xcode's canvas.
@available(iOS 18.0, *)
#Preview {
    AIDocumentEditorView()
}
