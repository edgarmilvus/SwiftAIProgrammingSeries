
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import SwiftData

@Model
final class JournalEntry {
    @Attribute(.unique) var id: UUID
    var timestamp: Date
    var content: String
    var isArchived: Bool
    
    init(id: UUID = UUID(), timestamp: Date = .now, content: String, isArchived: Bool = false) {
        self.id = id
        self.timestamp = timestamp
        self.content = content
        self.isArchived = isArchived
    }
}

/// A ModelActor to handle background fetching operations safely.
actor JournalFetcher: ModelActor {
    let modelContainer: ModelContainer
    let modelExecutor: any ModelExecutor
    
    init(container: ModelContainer) {
        self.modelContainer = container
        let context = ModelContext(container)
        self.modelExecutor = DefaultSerialModelExecutor(modelContext: context)
    }
    
    /// Performs the heavy fetch and returns only the IDs to maintain Sendable compliance.
    func fetchRecentUnarchivedIDs() throws -> [PersistentIdentifier] {
        let predicate = #Predicate<JournalEntry> { $0.isArchived == false }
        let descriptor = FetchDescriptor<JournalEntry>(
            predicate: predicate,
            sortBy: [SortDescriptor(\.timestamp, order: .reverse)]
        )
        
        // Simulate heavy computation/disk latency
        try? await Task.sleep(for: .milliseconds(500))
        
        let entries = try modelContext.fetch(descriptor)
        return entries.map { $0.persistentModelID }
    }
}

@MainActor
@Observable
class JournalViewModel {
    var entries: [JournalEntry] = []
    var isLoading = false
    private let container: ModelContainer
    
    init(container: ModelContainer) {
        self.container = container
    }
    
    func loadEntries() {
        isLoading = true
        
        // Trigger background work
        Task {
            let fetcher = JournalFetcher(container: container)
            
            do {
                // 1. Perform fetch on background actor
                let ids = try await fetcher.fetchRecentUnarchivedIDs()
                
                // 2. Hand-off: Use the IDs to resolve objects on the MainActor
                // We fetch them in the mainContext using the IDs obtained from the background.
                let mainContext = container.mainContext
                let resolvedEntries = ids.compactMap { id in
                    try? mainContext.model(for: id) as? JournalEntry
                }
                
                self.entries = resolvedEntries
            } catch {
                print("Fetch failed: \(error)")
            }
            
            isLoading = false
        }
    }
}
