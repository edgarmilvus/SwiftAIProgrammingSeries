
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import NaturalLanguage // For NLEmbedding and NLTokenizer

@available(iOS 18.0, macOS 15.0, *)
struct JournalEntry: Identifiable, Hashable {
    let id: UUID
    let date: Date
    let content: String
}

@available(iOS 18.0, macOS 15.0, *)
class JournalEntryStore {
    // Stores entries along with their pre-computed document embeddings
    private var entriesWithEmbeddings: [UUID: (JournalEntry, NLEmbedding.Vector)] = [:]
    // NLTokenizer is used to split entry content into sentences
    private let tokenizer = NLTokenizer(unit: .sentence)

    init() {
        // Initialize with dummy data for demonstration
        addEntry(JournalEntry(id: UUID(), date: Date().addingTimeInterval(-86400 * 5), content: "Today was a good day. I went for a long walk in the park and saw many beautiful flowers. The sun was shining brightly, and I felt very relaxed. Nature always brings me peace."))
        addEntry(JournalEntry(id: UUID(), date: Date().addingTimeInterval(-86400 * 3), content: "I've been thinking a lot about my career path lately. Should I pursue further education or look for new opportunities? It's a big decision. I need to plan my professional future carefully."))
        addEntry(JournalEntry(id: UUID(), date: Date().addingTimeInterval(-86400 * 1), content: "Spent the evening with friends. We had a delicious dinner and played board games. Laughter filled the air. These moments are precious and make life enjoyable."))
        addEntry(JournalEntry(id: UUID(), date: Date(), content: "Reflecting on my career again. The decision weighs heavily on me. I need to consider all pros and cons before making a move. Perhaps talking to a mentor would help with my professional development."))
        addEntry(JournalEntry(id: UUID(), date: Date().addingTimeInterval(-86400 * 10), content: "Had a wonderful time hiking in the mountains last week. The views were breathtaking, and the fresh air was invigorating. Nature always recharges me and makes me feel alive."))
        addEntry(JournalEntry(id: UUID(), date: Date().addingTimeInterval(-86400 * 2), content: "A quiet day at home. Read a book and listened to some music. Sometimes, these simple days are the best. Feeling content and peaceful in my own space."))
        addEntry(JournalEntry(id: UUID(), date: Date().addingTimeInterval(-86400 * 7), content: "Visited an art gallery today. The modern art pieces were thought-provoking. It's fascinating how different artists express themselves. Art enriches my perspective."))
    }

    /// Generates a document embedding by averaging sentence embeddings within the text.
    /// This provides a robust semantic representation for longer pieces of text.
    private func generateDocumentEmbedding(for text: String) -> NLEmbedding.Vector? {
        tokenizer.string = text // Set the string for the tokenizer
        var sentenceEmbeddings: [NLEmbedding.Vector] = []
        
        // Enumerate over sentences and generate embeddings for each
        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
            let sentence = String(text[tokenRange])
            if let embedding = NLEmbedding.embedding(for: sentence, language: .english) {
                sentenceEmbeddings.append(embedding)
            }
            return true // Continue enumeration
        }

        guard !sentenceEmbeddings.isEmpty else { return nil }
        
        // Average the embeddings to get a single document vector
        // NLEmbedding.Vector.zero is used as the initial value for reduction
        return sentenceEmbeddings.reduce(NLEmbedding.Vector.zero) { $0 + $1 } / Double(sentenceEmbeddings.count)
    }

    /// Adds a new journal entry and computes its embedding.
    func addEntry(_ entry: JournalEntry) {
        if let embedding = generateDocumentEmbedding(for: entry.content) {
            entriesWithEmbeddings[entry.id] = (entry, embedding)
            // print("Added entry: \(entry.id) - '\(entry.content.prefix(30))...'")
        } else {
            print("Failed to generate embedding for entry: \(entry.id)")
        }
    }

    /// Finds semantically similar journal entries to a given entry.
    /// - Parameters:
    ///   - entryID: The ID of the journal entry to find related entries for.
    ///   - maxResults: The maximum number of related entries to return.
    /// - Returns: An array of related `JournalEntry` objects, sorted by similarity.
    func findRelatedEntries(for entryID: UUID, maxResults: Int = 3) async -> [JournalEntry] {
        guard let (targetEntry, targetEmbedding) = entriesWithEmbeddings[entryID] else {
            print("Entry with ID \(entryID) not found.")
            return []
        }

        var results: [(entry: JournalEntry, distance: Double)] = []
        for (id, (entry, embedding)) in entriesWithEmbeddings {
            // Exclude the target entry itself from the results
            if id != entryID {
                let distance = NLEmbedding.distance(between: targetEmbedding, and: embedding)
                results.append((entry: entry, distance: distance))
            }
        }

        return results.sorted { $0.distance < $1.distance }
                     .prefix(maxResults)
                     .map { $0.entry }
    }
    
    // Helper to get an arbitrary entry for demonstration
    func getFirstEntryID() -> UUID? {
        return entriesWithEmbeddings.keys.first
    }
    
    // Helper to find an entry by content for specific demonstrations
    func findEntryID(containing text: String) -> UUID? {
        return entriesWithEmbeddings.first(where: { $0.value.0.content.contains(text) })?.key
    }
}

// Example Usage (in an async context)
/*
@available(iOS 18.0, macOS 15.0, *)
func demonstrateJournalSearch() async {
    let store = JournalEntryStore()
    
    print("--- Journal Entry Search Demo ---")
    
    // Demonstrate with an entry that has a clear semantic match ("career path")
    if let careerEntryID = store.findEntryID(containing: "career path") {
        let targetCareerEntry = store.entriesWithEmbeddings[careerEntryID]!.0
        print("\nFinding related entries for: '\(targetCareerEntry.content.prefix(50))...'")
        let relatedCareerEntries = await store.findRelatedEntries(for: careerEntryID, maxResults: 2)
        print("\nRelated Career Entries:")
        for entry in relatedCareerEntries {
            print("- [\(entry.date.formatted(date: .numeric, time: .omitted))] '\(entry.content.prefix(50))...'")
        }
        // Expected: The other career-related entry
    }
    
    // Demonstrate with an entry about nature/relaxation
    if let natureEntryID = store.findEntryID(containing: "Nature always recharges me") {
        let targetNatureEntry = store.entriesWithEmbeddings[natureEntryID]!.0
        print("\nFinding related entries for: '\(targetNatureEntry.content.prefix(50))...'")
        let relatedNatureEntries = await store.findRelatedEntries(for: natureEntryID, maxResults: 2)
        print("\nRelated Nature/Relaxation Entries:")
        for entry in relatedNatureEntries {
            print("- [\(entry.date.formatted(date: .numeric, time: .omitted))] '\(entry.content.prefix(50))...'")
        }
        // Expected: The other nature/walk entry, and the quiet day at home entry
    }
    
    // Demonstrate with an entry about friends
    if let friendsEntryID = store.findEntryID(containing: "Spent the evening with friends") {
        let targetFriendsEntry = store.entriesWithEmbeddings[friendsEntryID]!.0
        print("\nFinding related entries for: '\(targetFriendsEntry.content.prefix(50))...'")
        let relatedFriendsEntries = await store.findRelatedEntries(for: friendsEntryID, maxResults: 2)
        print("\nRelated Friends Entries:")
        for entry in relatedFriendsEntries {
            print("- [\(entry.date.formatted(date: .numeric, time: .omitted))] '\(entry.content.prefix(50))...'")
        }
        // Expected: Likely the quiet day at home or art gallery, as there's no other direct "friends" entry,
        // which highlights the semantic nature – it might find entries related to general well-being/activities.
    }
}

// To run this example, embed it in a Task:
// Task { await demonstrateJournalSearch() }
*/
