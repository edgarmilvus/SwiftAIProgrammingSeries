
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import CreateML
import Foundation // For URL, etc.

@available(iOS 18.0, macOS 15.0, *) // Hypothetical API for future Create ML
func trainImageClassifier(
    from trainingDataURL: URL,
    validationDataURL: URL? = nil
) async throws -> MLImageClassifier {
    print("Starting image classifier training...")

    // Data loading can be an async operation
    let trainingData = try await MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)
    let validationData = try await validationDataURL.map {
        try await MLImageClassifier.DataSource.labeledDirectories(at: $0)
    }

    // Create ML's train function is typically asynchronous
    let parameters = MLImageClassifier.ModelParameters(
        featureExtractor: .init(
            augmentation: .standard,
            preprocessing: .standard
        ),
        epochs: 10,
        validationData: validationData
    )

    // The actual training process, leveraging transfer learning/feature extraction
    // This is where the heavy lifting happens, potentially on a background thread.
    let classifier = try await MLImageClassifier.train(
        trainingData: trainingData,
        parameters: parameters
    )

    print("Image classifier training completed.")
    return classifier
}

// Example usage within a task
@available(iOS 18.0, macOS 15.0, *)
func setupAndTrain() {
    Task {
        do {
            let trainingURL = URL(fileURLWithPath: "/path/to/training_images")
            let model = try await trainImageClassifier(from: trainingURL)
            print("Model trained: \(model)")
            // Further steps: save model, deploy with Core ML
        } catch {
            print("Error during training: \(error)")
        }
    }
}
