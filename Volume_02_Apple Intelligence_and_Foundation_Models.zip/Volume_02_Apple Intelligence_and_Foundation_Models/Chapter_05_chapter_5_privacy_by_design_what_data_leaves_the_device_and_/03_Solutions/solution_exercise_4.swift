
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import Foundation // For LLM and Date

// Simplified Email model
struct Email: Identifiable, Hashable {
    let id = UUID()
    var sender: String
    var subject: String
    var body: String // Potentially sensitive
    var date: Date
    var isRead: Bool = false
    var threadID: UUID // For grouping emails into threads
}

@available(iOS 18.0, macOS 15.0, *)
class EmailViewModel: ObservableObject {
    @Published var selectedEmail: Email?
    @Published var emails: [Email] = [
        Email(sender: "Alice", subject: "Project Update", body: "Hi Team,\n\nJust wanted to provide a quick update on the 'Phoenix' project. We've hit a minor roadblock with the API integration, but expect to resolve it by end of week. The client meeting is still scheduled for Tuesday. Please review the attached document for details.\n\nBest,\nAlice", date: Date().addingTimeInterval(-3600), threadID: UUID()),
        Email(sender: "Bob", subject: "Re: Project Update", body: "Thanks for the update, Alice. Can you elaborate on the API roadblock? Is it a technical issue or a third-party dependency?\n\nRegards,\nBob", date: Date().addingTimeInterval(-1800), threadID: UUID()),
        Email(sender: "Charlie", subject: "New Marketing Campaign", body: "Team,\n\nExciting news! Our new marketing campaign 'Quantum Leap' is ready to launch next month. We'll be targeting key demographics in Europe and Asia. I've attached the full strategy document, including budget and expected ROI. This is highly confidential and should not be shared externally.\n\nThanks,\nCharlie", date: Date().addingTimeInterval(-7200), threadID: UUID()),
        Email(sender: "David", subject: "Weekly Sync", body: "Hi All,\n\nReminder for our weekly sync at 10 AM. Agenda: Q2 review, upcoming deadlines, and new client onboarding process. Please come prepared with your updates.\n\nBest,\nDavid", date: Date().addingTimeInterval(-10800), threadID: UUID()),
        Email(sender: "Eve", subject: "Follow-up: Q2 Review", body: "David,\n\nRegarding the Q2 review, I've consolidated all financial reports and performance metrics. The numbers look promising. I'll share a detailed breakdown during the sync. This data is proprietary.\n\nThanks,\nEve", date: Date().addingTimeInterval(-9000), threadID: UUID())
    ]
    @Published var draftReplyText: String = ""

    // 1. Email Summarization (On-Device)
    func summarizeEmail(email: Email) async -> String {
        print("Attempting on-device summarization for email ID: \(email.id)")
        
        // --- Privacy Mandate ---
        // Absolutely no email content leaves the device during this operation.
        // The LLM.textGeneration model runs entirely locally on the user's device.
        // This ensures the privacy of sensitive email content.

        do {
            // Conceptual call to Foundation.LLM.textGeneration
            // In a real app, you would import the Foundation.LLM framework and use it directly.
            // For this exercise, we simulate the output.
            // let llm = LLM.textGeneration()
            // let prompt = "Summarize the following email concisely:\n\n\(email.body)"
            // let result = try await llm.generate(prompt)
            // return result.first?.text ?? "Could not generate on-device summary."
            
            // Simulated output:
            let simulatedSummary = "On-device summary of subject '\(email.subject)': The email from \(email.sender) on \(email.date.formatted(date: .abbreviated, time: .omitted)) discusses \(email.body.prefix(50)). Key points: [Simulated key points derived locally]."
            return simulatedSummary
        } catch {
            print("Error summarizing email (simulated): \(error.localizedDescription)")
            return "Failed to generate on-device summary due to error."
        }
    }

    // 2. Draft Reply Assistant (On-Device)
    // This function provides programmatic suggestions. WritingTools also provide
    // UI-driven suggestions directly in UITextViews.
    func getReplySuggestions(currentDraft: String, originalEmailBody: String) async -> [String] {
        print("Generating on-device reply suggestions.")
        // --- Privacy Mandate ---
        // All draft text and original email content used for suggestions remain on-device.
        // No draft data or original email content is sent externally.
        // The LLM.textGeneration model runs entirely locally.

        do {
            // Conceptual call to Foundation.LLM.textGeneration
            // let llm = LLM.textGeneration()
            // let prompt = """
            // Original Email:
            // \(originalEmailBody)
            //
            // Current Draft:
            // \(currentDraft)
            //
            // Suggest 3 concise ways to continue or rephrase the current draft, or common reply phrases.
            // """
            // let result = try await llm.generate(prompt, options: .init(maxTokens: 100))
            // let suggestions = result.first?.text?.split(separator: "\n").map(String.init) ?? []
            // return suggestions.prefix(3).map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }

            // Simulated output:
            let simulatedSuggestions = [
                "I'll look into that immediately.",
                "Thanks for the update.",
                "Could you provide more details?"
            ]
            return simulatedSuggestions
        } catch {
            print("Error generating reply suggestions (simulated): \(error.localizedDescription)")
            return ["Cannot generate suggestions."]
        }
    }

    // 3. Advanced Thread Summarization (PCC Consideration - Design Only)
    // This function outlines the design principles for a feature that *could* use PCC.
    func summarizeEmailThread(threadID: UUID) async -> String {
        let threadEmails = emails.filter { $0.threadID == threadID }.sorted(by: { $0.date < $1.date })
        guard !threadEmails.isEmpty else { return "No emails in this thread." }

        let totalEmailCount = threadEmails.count
        let totalBodyLength = threadEmails.map { $0.body.count }.reduce(0, +)

        // On-device threshold: e.g., small number of emails AND total length not too long
        let onDeviceThresholdEmailCount = 3
        let onDeviceThresholdBodyLength = 1000 // characters

        if totalEmailCount <= onDeviceThresholdEmailCount && totalBodyLength <= onDeviceThresholdBodyLength {
            // Small thread, summarize on-device using the existing email summarization logic
            let combinedBody = threadEmails.map { $0.body }.joined(separator: "\n---\n")
            print("Summarizing small thread (\(totalEmailCount) emails, \(totalBodyLength) chars) on-device.")
            return await summarizeEmail(email: Email(sender: "System", subject: "Combined Thread for Summary", body: combinedBody, date: Date(), threadID: threadID))
        } else {
            // --- PRIVACY-BY-DESIGN FOR POTENTIAL PCC USAGE ---
            print("\n--- Designing for Advanced Thread Summarization (Potential PCC) ---")
            print("This thread has \(totalEmailCount) emails and a total body length of \(totalBodyLength) characters. This complexity *could* lead the system to consider Private Cloud Compute (PCC) for a comprehensive summary.")

            // **Step 1: User Consent (Crucial)**
            print("\n**1. User Consent:** Before any data leaves the device, the app would present a clear, explicit dialog to the user, explaining the need and privacy safeguards:")
            print("   'This email thread is very long and complex. For a comprehensive summary, Apple Intelligence may use Private Cloud Compute. This involves sending *anonymized thread metadata* (e.g., subjects, message count, non-sensitive snippets, but NO full email bodies or personal content) to Apple's secure servers, which are cryptographically protected, not logged, and processed ephemerally. Do you consent to this for an enhanced summary?'")
            print("   - If the user declines, the app would either provide a basic, on-device summary (if feasible with local resources) or state that a comprehensive summary cannot be generated.")
            print("   - This consent would ideally be a one-time prompt or granularly manageable in settings.")
            
            // **Step 2: Data Minimization for PCC Eligibility**
            print("\n**2. Data Minimization:** If user consent is given, only the *absolute minimum, anonymized, non-sensitive data* would be extracted and prepared for potential PCC processing. This is critical to prevent sensitive email content from leaving the device.")
            print("   - **Data to potentially send (after anonymization/redaction):**")
            print("     - ThreadID (anonymized/hashed for PCC context, not user-identifiable)")
            print("     - Message count in thread")
            print("     - List of anonymized sender IDs (e.g., hash of sender email, not actual email address)")
            print("     - Subjects of each email (after scrubbing for PII and sensitive keywords)")
            print("     - Date ranges of the thread")
            print("     - *Highly redacted snippets* of email bodies, carefully chosen to remove PII and sensitive context, only if absolutely necessary for summary quality and with explicit user understanding.")
            print("   - **Data NEVER to send:**")
            print("     - Full email body content (unless explicitly selected by user for specific interaction, like rephrasing a paragraph, which would be handled by on-device WritingTools or LLM).")
            print("     - Attachments")
            print("     - Personally identifiable information (PII) within subjects, senders, or redacted snippets.")
            
            let pccEligibleDataExample = threadEmails.map { email in
                let redactedSubject = email.subject.prefix(50).replacingOccurrences(of: "confidential", with: "[redacted]").replacingOccurrences(of: "proprietary", with: "[redacted]")
                return "Subject: \(redactedSubject). SenderHash: \(email.sender.hashValue). Date: \(email.date.formatted())."
            }.joined(separator: "\n")
            print("   Example of PCC-eligible, anonymized data for a large thread:\n\(pccEligibleDataExample)")

            // **Step 3: Transparency Indicator**
            print("\n**3. Transparency:** If PCC were engaged by the system, the app's UI would display a clear, persistent indicator (e.g., a pulsing AI icon, similar to Siri's PCC indicator) to show that cloud processing is occurring. This provides real-time user awareness.")
            
            // **Step 4: No Logging/Profiling**
            print("\n**4. No Logging/Profiling:** Reiterate to the user (and internally confirm) that Apple's PCC infrastructure ensures no data is logged, user profiles are not built from this data, and sessions are ephemeral and cryptographically isolated. Independent experts can audit the code running on PCC.")

            // --- Simulation of PCC-assisted summary ---
            return """
            (Simulated) Advanced Summary of Email Thread (ID: \(threadID)):
            This thread contains \(totalEmailCount) emails, spanning from \(threadEmails.first?.date.formatted(date: .abbreviated, time: .omitted) ?? "") to \(threadEmails.last?.date.formatted(date: .abbreviated, time: .omitted) ?? "").
            Key subjects include: \(threadEmails.map { $0.subject }.joined(separator: ", ")).
            A comprehensive summary was generated with conceptual Private Cloud Compute assistance, ensuring strict privacy protocols, user consent, and data minimization.
            """
        }
    }
}

// SwiftUI View for the custom email client
struct EmailClientView: View {
    @StateObject private var viewModel = EmailViewModel()
    @State private var summary: String?
    @State private var showReplySheet = false

    var body: some View {
        NavigationView {
            List(viewModel.emails) { email in
                Button(action: { viewModel.selectedEmail = email }) {
                    VStack(alignment: .leading) {
                        Text(email.subject).font(.headline)
                        Text(email.sender).font(.subheadline)
                        Text(email.body.prefix(100) + "...").font(.body)
                    }
                }
            }
            .navigationTitle("SecureMail Inbox")
            .sheet(item: $viewModel.selectedEmail) { email in
                EmailDetailView(email: email, viewModel: viewModel, summary: $summary, showReplySheet: $showReplySheet)
            }
        }
    }
}

struct EmailDetailView: View {
    let email: Email
    @ObservedObject var viewModel: EmailViewModel
    @Binding var summary: String?
    @Binding var showReplySheet: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Subject: \(email.subject)").font(.title2)
            Text("From: \(email.sender)").font(.subheadline)
            Text("Date: \(email.date.formatted())").font(.caption)
            Divider()
            ScrollView {
                Text(email.body)
            }
            
            HStack {
                Button("Summarize Email (On-Device)") {
                    Task {
                        summary = await viewModel.summarizeEmail(email: email)
                    }
                }
                .buttonStyle(.borderedProminent)

                Button("Reply with Assistant (On-Device)") {
                    viewModel.draftReplyText = "Re: \(email.subject)\n\n" // Pre-fill reply
                    showReplySheet = true
                }
                .buttonStyle(.bordered)
            }

            if let summary = summary {
                Text("Summary:").font(.headline)
                Text(summary).font(.body)
                    .padding(.top, 5)
            }
            
            Button("Summarize Thread (Advanced - PCC Design)") {
                Task {
                    summary = await viewModel.summarizeEmailThread(threadID: email.threadID)
                }
            }
            .buttonStyle(.bordered)
            .tint(.orange)
            .padding(.top)

        }
        .padding()
        .navigationTitle("Email Detail")
        .sheet(isPresented: $showReplySheet) {
            ReplySheetView(viewModel: viewModel, originalEmailBody: email.body, showReplySheet: $showReplySheet)
        }
    }
}

struct ReplySheetView: View {
    @ObservedObject var viewModel: EmailViewModel
    let originalEmailBody: String
    @Binding var showReplySheet: Bool
    @State private var suggestions: [String] = []

    var body: some View {
        NavigationView {
            VStack {
                TextEditor(text: $viewModel.draftReplyText)
                    .frame(minHeight: 200)
                    .border(Color.gray, width: 0.5)
                    .padding()
                    // WritingTools for UITextView are automatically available here
                    // if this were a UIKit UITextView. For SwiftUI TextEditor,
                    // system-level WritingTools integration might be more limited
                    // or require specific view modifiers as they evolve.
                    // The programmatic suggestions below provide a similar function.

                HStack {
                    Button("Get Suggestions (On-Device)") {
                        Task {
                            suggestions = await viewModel.getReplySuggestions(currentDraft: viewModel.draftReplyText, originalEmailBody: originalEmailBody)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    
                    Button("Send") {
                        print("Sending email: \(viewModel.draftReplyText)")
                        showReplySheet = false
                    }
                    .buttonStyle(.bordered)
                }
                .padding(.horizontal)

                if !suggestions.isEmpty {
                    VStack(alignment: .leading) {
                        Text("Suggestions:").font(.headline)
                        ForEach(suggestions, id: \.self) { suggestion in
                            Button(action: {
                                viewModel.draftReplyText += "\n" + suggestion
                            }) {
                                Text(suggestion)
                                    .padding(.vertical, 5)
                                    .padding(.horizontal, 10)
                                    .background(Capsule().fill(Color.blue.opacity(0.2)))
                                    .foregroundColor(.blue)
                            }
                        }
                    }
                    .padding()
                }

                Spacer()
            }
            .navigationTitle("Compose Reply")
            .navigationBarItems(leading: Button("Cancel") { showReplySheet = false })
        }
    }
}

// Preview Provider
@available(iOS 18.0, macOS 15.0, *)
#Preview {
    EmailClientView()
}
