
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import UIKit

/// A thread-safe service that monitors the device's thermal state.
/// Available on iOS 18.0+ to utilize advanced concurrency patterns.
@available(iOS 18.0, *)
actor ThermalMonitor {
    
    /// Represents the current thermal state of the device.
    private(set) var currentState: ProcessInfo.ThermalState = .nominal
    
    /// A list of continuations to support multiple subscribers to the thermal stream.
    private var continuations: [UUID: AsyncStream<ProcessInfo.ThermalState>.Continuation] = [:]
    
    init() {
        // Initial state capture
        self.currentState = ProcessInfo.processInfo.thermalState
        
        // Start observing system notifications
        observeThermalChanges()
    }
    
    /// Returns an asynchronous stream of thermal state updates.
    /// Each call creates a new subscriber.
    func thermalStateStream() -> AsyncStream<ProcessInfo.ThermalState> {
        let id = UUID()
        return AsyncStream { continuation in
            // Add the new continuation to our list of subscribers
            continuation.yield(currentState)
            continuation.onTermination = { @Sendable [weak self] _ in
                Task { [weak self] in
                    await self?.removeContinuation(id: id)
                }
            }
            self.addContinuation(continuation, id: id)
        }
    }
    
    private func addContinuation(_ continuation: AsyncStream<ProcessInfo.ThermalState>.Continuation, id: UUID) {
        continuations[id] = continuation
    }
    
    private func removeContinuation(id: UUID) {
        continuations.removeValue(forKey: id)
    }
    
    private func observeThermalChanges() {
        // We use a Task to bridge the NotificationCenter callback into the Actor's isolated context
        NotificationCenter.default.addObserver(
            forName: ProcessInfo.thermalStateDidChangeNotification,
            object: nil,
            queue: .main // Notifications arrive on the main thread
        ) { [weak self] _ in
            Task { [weak self] in
                await self?.handleThermalChange()
            }
        }
    }
    
    private func handleThermalChange() {
        let newState = ProcessInfo.processInfo.thermalState
        let oldState = currentState
        
        if newState != oldState {
            currentState = newState
            let timestamp = ISO8601DateFormatter().string(from: Date())
            print("[\(timestamp)] Thermal State Transition: \(oldState) -> \(newState)")
            
            // Broadcast the new state to all active subscribers
            for continuation in continuations.values {
                continuation.yield(newState)
            }
        }
    }
}

// MARK: - Example Usage
@available(iOS 18.0, *)
@MainActor
struct ThermalDemo {
    static func run() async {
        let monitor = ThermalMonitor()
        
        // Subscriber 1: Logging Task
        Task {
            for await state in await monitor.thermalStateStream() {
                print("Subscriber 1 received: \(state)")
            }
        }
        
        // Subscriber 2: UI Update Simulation
        Task {
            for await state in await monitor.thermalStateStream() {
                print("Subscriber 2 (UI) updating for: \(state)")
            }
        }
    }
}
