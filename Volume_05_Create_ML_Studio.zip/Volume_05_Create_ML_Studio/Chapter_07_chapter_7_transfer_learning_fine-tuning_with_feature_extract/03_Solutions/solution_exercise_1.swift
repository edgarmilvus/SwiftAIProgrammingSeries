
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CoreML
import Vision
import UIKit

// Ensure your generated Core ML model class (e.g., 'IngredientClassifierModel')
// is added to your project and replace 'IngredientClassifierModel' below.
// The @available attribute is kept as provided in the exercise.
@available(iOS 18.0, *)
class IngredientClassifier {

    // VNCoreMLModel wraps your MLModel for Vision framework integration.
    private var model: VNCoreMLModel?

    /// Initializes the classifier with the name of the Core ML model.
    /// - Parameter modelName: The name of the .mlmodelc file (without extension) in the app bundle.
    init?(modelName: String) {
        // Locate the compiled Core ML model in the app's bundle.
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            print("Error: Model \(modelName).mlmodelc not found in bundle.")
            return nil
        }
        do {
            // Load the MLModel from the URL.
            let coreMLModel = try MLModel(contentsOf: modelURL)
            // Create a VNCoreMLModel for use with the Vision framework.
            self.model = try VNCoreMLModel(for: coreMLModel)
        } catch {
            print("Error loading Core ML model: \(error)")
            return nil
        }
    }

    /// Classifies a given UIImage asynchronously.
    /// - Parameters:
    ///   - image: The UIImage to classify.
    ///   - completion: A closure to be called with the classification result or an error.
    func classifyImage(_ image: UIImage, completion: @escaping (Result<String, Error>) -> Void) {
        guard let model = model else {
            completion(.failure(IngredientClassificationError.modelNotLoaded))
            return
        }

        // Convert UIImage to CIImage, which Vision framework uses.
        guard let ciImage = CIImage(image: image) else {
            completion(.failure(IngredientClassificationError.invalidImage))
            return
        }

        // Create a Vision request for Core ML model.
        let request = VNCoreMLRequest(model: model) { [weak self] request, error in
            guard let self = self else { return } // Safely unwrap self

            if let error = error {
                completion(.failure(error))
                return
            }

            // Ensure results are VNClassificationObservation.
            guard let observations = request.results as? [VNClassificationObservation] else {
                completion(.failure(IngredientClassificationError.noObservations))
                return
            }

            // Get the top classification.
            if let bestClassification = observations.first {
                // Format the output string with identifier and confidence.
                completion(.success("\(bestClassification.identifier) (Confidence: \(String(format: "%.2f", bestClassification.confidence * 100))%)"))
            } else {
                completion(.failure(IngredientClassificationError.noClassificationsFound))
            }
        }

        // Create a request handler for the image.
        let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])
        
        // Perform the Vision request on a background queue as it's a synchronous, blocking call.
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try handler.perform([request])
            } catch {
                completion(.failure(error))
            }
        }
    }

    // Custom error types for better error handling.
    enum IngredientClassificationError: Error, LocalizedError {
        case modelNotLoaded
        case invalidImage
        case noObservations
        case noClassificationsFound

        var errorDescription: String? {
            switch self {
            case .modelNotLoaded: return "The Core ML model could not be loaded."
            case .invalidImage: return "The input image is invalid."
            case .noObservations: return "No observations were returned from the classification request."
            case .noClassificationsFound: return "No classifications were found for the image."
            }
        }
    }
}
