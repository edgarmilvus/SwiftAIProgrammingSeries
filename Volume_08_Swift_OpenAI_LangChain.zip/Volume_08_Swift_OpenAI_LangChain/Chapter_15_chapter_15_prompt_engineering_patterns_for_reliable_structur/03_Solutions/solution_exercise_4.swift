
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct ChronosTask: Identifiable, Sendable {
    let id = UUID()
    let title: String
    let dueDate: Date
    let priority: String
    let folderName: String
}

@available(iOS 18.0, macOS 15.0, *)
actor TaskArchitect {
    
    // Represents the JSON Schema sent to the LLM's 'tools' parameter
    private let toolDefinition: [String: Any] = [
        "type": "function",
        "function": [
            "name": "create_task",
            "description": "Creates a new task in the Chronos manager",
            "parameters": [
                "type": "object",
                "properties": [
                    "title": ["type": "string"],
                    "dueDate": ["type": "string", "description": "ISO8601 format"],
                    "priority": ["type": "string", "enum": ["low", "medium", "high"]],
                    "folderName": ["type": "string"]
                ],
                "required": ["title", "dueDate", "priority", "folderName"]
            ]
        ]
    ]

    private func callLLMWithTools(input: String) async throws -> [String: Any]? {
        try await Task.sleep(for: .seconds(1))
        // Simulated LLM response indicating a Tool Call was triggered
        // In reality, this comes from the 'tool_calls' field in the OpenAI response
        return [
            "tool_calls": [
                [
                    "function": [
                        "name": "create_task",
                        "arguments": "{\"title\": \"Prep for board meeting\", \"dueDate\": \"2025-05-20T10:00:00Z\", \"priority\": \"high\", \"folderName\": \"Work\"}"
                    ]
                ]
            ]
        ]
    }

    func processCommand(_ input: String) async throws -> ChronosTask? {
        let response = try await callLLMWithTools(input: input)
        
        // 1. Detect if a tool call exists
        guard let toolCalls = response?["tool_calls"] as? [[String: Any]],
              let firstCall = toolCalls.first,
              let functionInfo = firstCall["function"] as? [String: Any],
              let functionName = functionInfo["name"] as? String,
              functionName == "create_task",
              let argsString = functionInfo["arguments"] as? String else {
            return nil
        }

        // 2. Parse the arguments string into a dictionary
        let argsData = Data(argsString.utf8)
        let args = try JSONSerialization.jsonObject(with: argsData) as? [String: Any] ?? [:]

        // 3. Map arguments to the Swift model
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        
        // We decode the dictionary via a temporary Codable wrapper or direct mapping
        // For brevity, we use a specialized decoding approach:
        let taskData = try JSONSerialization.data(withJSONObject: args)
        
        // Internal helper struct to decode the raw arguments
        struct TaskArgs: Codable {
            let title: String
            let dueDate: Date
            let priority: String
            let folderName: String
        }
        
        let decodedArgs = try decoder.decode(TaskArgs.self, from: taskData)
        
        return ChronosTask(
            title: decodedArgs.title,
            dueDate: decodedArgs.dueDate,
            priority: decodedArgs.priority,
            folderName: decodedArgs.folderName
        )
    }
}
