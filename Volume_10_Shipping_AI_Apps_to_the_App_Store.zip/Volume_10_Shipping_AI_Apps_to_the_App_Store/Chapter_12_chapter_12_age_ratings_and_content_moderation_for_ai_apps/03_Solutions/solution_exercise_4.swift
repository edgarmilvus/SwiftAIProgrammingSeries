
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import Vision
import UIKit

// MARK: - Models
enum SafetyStatus: Equatable {
    case approved
    case blurred
    case blocked(reason: String)
}

struct GeneratedAsset {
    let id: UUID = UUID()
    let imageData: Data
    let status: SafetyStatus
    let correlationID: String
}

enum SentinelError: Error {
    case invalidPrompt(String)
    case visionModelFailed
    case systemError(String)
}

// MARK: - Coordinator
actor SentinelSafetyCoordinator {
    private let reportingService = ReportingService()
    
    /// The main entry point for the SafeGen feature
    func processRequest(prompt: String) async throws -> GeneratedAsset {
        let correlationID = UUID().uuidString
        
        // 1. Prompt Guard (Pre-Generation)
        try validatePrompt(prompt)
        
        // 2. Generation (Simulated)
        let generatedData = try await simulateImageGeneration(prompt: prompt)
        
        // 3. Vision Guard (Post-Generation)
        let status = await performVisionAnalysis(on: generatedData)
        
        // 4. Handle Blocked Content
        if case .blocked(let reason) = status {
            // Log for human-in-the-loop review
            print("Audit Log [\(correlationID)]: Content blocked. Reason: \(reason)")
        }
        
        return GeneratedAsset(
            imageData: generatedData,
            status: status,
            correlationID: correlationID
        )
    }
    
    private func validatePrompt(_ prompt: String) throws {
        let jailbreakPatterns = ["ignore all previous instructions", "system override"]
        for pattern in jailbreakPatterns {
            if prompt.lowercased().contains(pattern) {
                throw SentinelError.invalidPrompt("Jailbreak attempt detected.")
            }
        }
    }
    
    private func performVisionAnalysis(on data: Data) async -> SafetyStatus {
        // In a real app, we would use VNCoreMLRequest here.
        // Mocking the Vision Framework behavior:
        do {
            try await Task.sleep(for: .milliseconds(500))
            
            // Mocking a result: if data is "small", pretend it's sensitive
            if data.count < 100 {
                return .blocked(reason: "NSFW Content Detected")
            } else if data.count < 500 {
                return .blurred
            } else {
                return .approved
            }
        } catch {
            return .blocked(reason: "Vision analysis failed")
        }
    }
    
    private func simulateImageGeneration(prompt: String) async throws -> Data {
        try await Task.sleep(for: .seconds(2))
        return "mock_image_data_\(prompt.count)".data(using: .utf8)!
    }
}

// MARK: - Reporting Service
final class ReportingService {
    private let session: URLSession
    
    init() {
        // Use background configuration to ensure reports are sent even if app is closed
        let config = URLSessionConfiguration.background(withIdentifier: "com.socialflow.sentinel.reporting")
        config.isDiscretionary = true
        self.session = URLSession(configuration: config)
    }
    
    func report(asset: GeneratedAsset, reason: String) {
        let reportPayload: [String: Any] = [
            "assetID": asset.id.uuidString,
            "correlationID": asset.correlationID,
            "reason": reason,
            "timestamp": Date().timeIntervalSince1970
        ]
        
        guard let url = URL(string: "https://api.socialflow.com/report"),
              let body = try? JSONSerialization.data(withJSONObject: reportPayload) else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = body
        
        // The task is handed off to the OS background daemon
        let task = session.uploadTask(with: request, from: body)
        task.resume()
        print("Report queued for Asset: \(asset.id)")
    }
}
