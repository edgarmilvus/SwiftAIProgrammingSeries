
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import AppIntents
import Foundation // Required for UUID, Date, etc., though not strictly used in this specific example, it's good practice.

// 1. Define a Custom AppIntentDomain
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct QuickNotesDomain: AppIntentDomain {
    static var identifier: String = "quickNotes" // Unique identifier for the domain
    static var displayName: LocalizedStringResource = "QuickNotes" // User-facing name
    static var description: LocalizedStringResource = "Intents for managing notes in the QuickNotes app."
}

// 2. Create CreateNoteIntent
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct CreateNoteIntent: AppIntent {
    static var title: LocalizedStringResource = "Create Note"
    static var description: LocalizedStringResource = "Creates a new note with a specified title."
    static var openAppWhenRun: Bool = true // Indicate that the app might open when this intent is run
    
    // Assign this intent to the QuickNotesDomain
    static var domain: AppIntentDomain.Type? = QuickNotesDomain.self

    // Define a required parameter for the note's title
    @Parameter(title: "Note Title", description: "The title for the new note.", requestValueDialog: "What should the note be titled?")
    var title: String

    // 3. Implement perform()
    func perform() async throws -> some IntentResult {
        // In a real app, you would interact with your app's data model
        // to save the new note (e.g., to Core Data, Realm, or a file).
        print("✅ QuickNotes: Successfully created a new note titled: '\(title)'")
        
        // Provide a user-friendly dialog response
        return .result(
            dialog: "I've created a note titled \(title)."
        )
    }
}

// 4. Make Discoverable (via AppShortcutsProvider)
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct QuickNotesShortcuts: AppShortcutsProvider {
    // Define the category for these shortcuts
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: CreateNoteIntent(), // Provide an instance of the intent
            phrases: [
                "Create a note titled \(.parameter(\.$title)) in QuickNotes", // Natural language phrases
                "Make a new note \(.parameter(\.$title))"
            ],
            shortTitle: "Create Note",
            systemImageName: "note.text.badge.plus" // Icon for the shortcut
        )
    }
}
