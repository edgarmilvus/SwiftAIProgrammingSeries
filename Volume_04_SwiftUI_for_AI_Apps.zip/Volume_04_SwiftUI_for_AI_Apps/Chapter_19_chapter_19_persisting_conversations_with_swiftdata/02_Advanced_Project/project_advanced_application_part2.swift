
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import SwiftData

/// Represents the sender of a message in a conversation.
enum MessageSender: String, Codable, Identifiable, CaseIterable {
    case user
    case ai
    case system // For internal system messages, e.g., "AI disconnected"

    var id: String { rawValue }
}

/// Represents the status of an AI message, especially during streaming.
enum MessageStatus: String, Codable, Identifiable, CaseIterable {
    case sending // User message being sent to AI
    case streaming // AI response is actively being streamed
    case completed // AI response fully received
    case error // An error occurred during AI processing or persistence
    case cancelled // AI response was cancelled

    var id: String { rawValue }
}

@Model
@available(iOS 18.0, *) // SwiftData is available from iOS 17, but we target 18 for newer features
final class Conversation {
    @Attribute(.unique) var id: UUID
    var createdAt: Date
    @Relationship(deleteRule: .cascade, inverse: \Message.conversation)
    var messages: [Message]?

    init(id: UUID = UUID(), createdAt: Date = Date()) {
        self.id = id
        self.createdAt = createdAt
        self.messages = []
    }
}

@Model
@available(iOS 18.0, *)
final class Message {
    @Attribute(.unique) var id: UUID
    var content: String
    var sender: MessageSender
    var timestamp: Date
    var status: MessageStatus // For AI responses, can be streaming, completed, error
    var conversation: Conversation? // Inverse relationship

    init(id: UUID = UUID(), content: String, sender: MessageSender, timestamp: Date = Date(), status: MessageStatus = .completed) {
        self.id = id
        self.content = content
        self.sender = sender
        self.timestamp = timestamp
        self.status = status
    }
}
