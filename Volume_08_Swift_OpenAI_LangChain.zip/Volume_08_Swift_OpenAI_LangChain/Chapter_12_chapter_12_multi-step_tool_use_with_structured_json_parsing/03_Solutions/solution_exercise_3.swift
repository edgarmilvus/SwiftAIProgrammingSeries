
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

/// Represents the roles in a conversation.
enum ChatRole: String, Codable, Sendable {
    case user, assistant, tool
}

/// A single message in the conversation history.
struct ChatMessage: Sendable {
    let role: ChatRole
    let content: String
    let toolCallID: String? // Only used for 'tool' role
    
    init(role: ChatRole, content: String, toolCallID: String? = nil) {
        self.role = role
        self.content = content
        self.toolCallID = toolCallID
    }
}

/// Represents a request from the LLM to use a tool.
struct ToolCall: Sendable {
    let id: String
    let name: String
    let arguments: String
}

/// Mock LLM Client to simulate the agentic loop.
actor MockLLMClient {
    private var turnCount = 0
    
    func generateResponse(history: [ChatMessage]) async -> (String, [ToolCall]?) {
        turnCount += 1
        
        // Simulation Logic:
        // Turn 1: Request two stock prices
        if turnCount == 1 {
            return ("I need to fetch stock prices.", [
                ToolCall(id: "call_1", name: "get_stock_price", arguments: "{\"symbol\": \"AAPL\"}"),
                ToolCall(id: "call_2", name: "get_stock_price", arguments: "{\"symbol\": \"MSFT\"}")
            ])
        }
        // Turn 2: Final Answer
        if turnCount == 2 {
            return ("Apple performed better with a 2% gain vs Microsoft's 1%.", nil)
        }
        
        return ("I'm not sure how to help.", nil)
    }
}

/// The core Agent loop.
actor ResearchAgent {
    private let llm: MockLLMClient
    private let engine: ExecutionEngine
    private var history: [ChatMessage] = []

    init(llm: MockLLMClient, engine: ExecutionEngine) {
        self.llm = llm
        self.engine = engine
    }

    func run(userQuery: String) async -> String {
        // 1. Initial User Message
        history.append(ChatMessage(role: .user, content: userQuery))
        
        // 2. The Agentic Loop
        while true {
            let (assistantText, toolCalls) = await llm.generateResponse(history: history)
            
            // Add assistant's thought/call to history
            history.append(ChatMessage(role: .assistant, content: assistantText))
            
            // Termination Condition: No more tool calls
            guard let calls = toolCalls, !calls.isEmpty else {
                return assistantText
            }

            // 3. Parallel Tool Execution using TaskGroup
            print("🤖 Agent is calling \(calls.count) tools in parallel...")
            
            let toolResults = await withTaskGroup(of: (String, String).self) { group in
                for call in calls {
                    group.addTask {
                        let result = await self.engine.process(toolCallName: call.name)
                        return (call.id, result)
                    }
                }
                
                var results: [(String, String)] = []
                for await result in group {
                    results.append(result)
                }
                return results
            }

            // 4. Append tool results to history
            for (callID, resultText) in toolResults {
                history.append(ChatMessage(role: .tool, content: resultText, toolCallID: callID))
            }
        }
    }
}

// --- Mock Implementation of the Engine for Testing ---
struct MockEngine: ExecutionEngineProtocol {
    func process(toolCallName: String) async -> String {
        try? await Task.sleep(for: .milliseconds(500))
        if toolCallName == "get_stock_price" { return "Price: $150.00" }
        return "Error"
    }
}

protocol ExecutionEngineProtocol: Sendable {
    func process(toolCallName: String) async -> String
}

// --- Main Execution ---
@main
struct ResearchAgentApp {
    static func main() async {
        // Setup
        let mockLLM = MockLLMClient()
        // We use a real engine with mock tools for the simulation
        let registry = ToolRegistry(tools: [CPUUsageTool()]) // Reusing tool from Ex 2
        let engine = ExecutionEngine(registry: registry) 
        
        // Note: In a real scenario, 'engine' would have 'get_stock_price'
        // For this demo, we assume the engine is configured correctly.
        let agent = ResearchAgent(llm: mockLLM, engine: engine)

        print("🚀 Starting Research Task...")
        let finalAnswer = await agent.run(userQuery: "Compare AAPL and MSFT.")
        print("\n🏁 Final Agent Response: \(finalAnswer)")
    }
}
