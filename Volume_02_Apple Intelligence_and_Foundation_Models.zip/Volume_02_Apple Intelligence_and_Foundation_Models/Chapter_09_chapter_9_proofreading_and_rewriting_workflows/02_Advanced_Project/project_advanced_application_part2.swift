
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

    import Foundation
    import Intelligence // Requires iOS 18.0+, macOS 15.0+, visionOS 2.0+

    /// Represents the types of text refinement actions a user can request.
    /// These map directly to the capabilities of Apple Intelligence's TextProcessor.
    enum TextRefinementAction: String, CaseIterable, Identifiable {
        case proofread = "Proofread Text"
        case makeConcise = "Make More Concise"
        case expand = "Expand on Idea"
        case rephrase = "Rephrase for Clarity"
        case summarize = "Summarize Section"
        case changeToneToProfessional = "Change Tone: Professional"
        case changeToneToFriendly = "Change Tone: Friendly"

        var id: String { self.rawValue }

        /// Converts the refinement action into the corresponding `TextRefinement` type.
        /// This is the bridge between our app's UI/logic and the Apple Intelligence API.
        @available(iOS 18.0, *)
        var textRefinement: TextRefinement {
            switch self {
            case .proofread:
                return .proofread
            case .makeConcise:
                return .makeConcise
            case .expand:
                return .expand
            case .rephrase:
                return .rephrase
            case .summarize:
                return .summarize
            case .changeToneToProfessional:
                return .changeTone(tone: .professional)
            case .changeToneToFriendly:
                return .changeTone(tone: .friendly)
            }
        }
    }

    /// Custom errors specific to our document refinement service.
    enum DocumentRefinementError: Error, LocalizedError {
        case invalidRange
        case noTextSelected
        case intelligenceServiceUnavailable(Error?)
        case refinementFailed(String)
        case unsupportedAction

        var errorDescription: String? {
            switch self {
            case .invalidRange:
                return "The selected text range is invalid or out of bounds."
            case .noTextSelected:
                return "No text was selected for refinement."
            case .intelligenceServiceUnavailable(let underlyingError):
                return "Apple Intelligence service is currently unavailable. Please check device capabilities and network connection. \(underlyingError?.localizedDescription ?? "")"
            case .refinementFailed(let message):
                return "Text refinement failed: \(message)"
            case .unsupportedAction:
                return "The selected action is not supported by the current text processor configuration."
            }
        }
    }
    