
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CoreML
import MetricKit
import OSLog

@available(iOS 18.0, *)
struct PerformanceReport: Sendable {
    let cpuUsage: Double
    let timestamp: Date
    let isDowngraded: Bool
}

@available(iOS 18.0, *)
class PerformanceMonitor: NSObject, MXMetricManagerSubscriber {
    private let logger = Logger(subsystem: "com.app.ai", category: "Performance")
    private var onThresholdExceeded: ((PerformanceReport) -> Void)?

    func setup() {
        MXMetricManager.shared.add(self)
    }

    func didReceive(_ payloads: [MXMetricPayload]) {
        for payload in payloads {
            guard let cpuMetrics = payload.cpuMetrics else { continue }
            
            let usage = cpuMetrics.cumulativeCPUUsage
            let report = PerformanceReport(
                cpuUsage: usage,
                timestamp: Date(),
                isDowngraded: false // Logic would be expanded to check session state
            )
            
            // Flag if CPU usage is abnormally high (e.g., > 80% during inference)
            if usage > 0.8 {
                logger.warning("High CPU usage detected: \(usage)")
                onThresholdExceeded?(report)
            }
        }
    }
    
    func setThresholdCallback(_ callback: @escaping (PerformanceReport) -> Void) {
        self.onThresholdExceeded = callback
    }
}

@available(iOS 18.0, *)
class CaptioningEngine {
    private var model: MLModel?
    private let logger = Logger(subsystem: "com.app.ai", category: "Engine")
    private let monitor = PerformanceMonitor()
    
    var onPerformanceDowngrade: ((String) -> Void)?

    func setupEngine() async throws {
        let config = MLModelConfiguration()
        
        // Optimization: Prioritize Neural Engine for energy efficiency
        // .cpuAndNeuralEngine is the gold standard for battery-sensitive AI apps.
        config.computeUnits = .cpuAndNeuralEngine 
        
        do {
            // Simulated loading
            try await Task.sleep(for: .milliseconds(500))
            // In real code: self.model = try MLModel(contentsOf: url, configuration: config)
            self.model = MLModel() 
            logger.info("Engine initialized on ANE/CPU.")
        } catch {
            logger.error("ANE initialization failed. Attempting GPU fallback...")
            try await attemptFallback()
        }
    }
    
    private func attemptFallback() async throws {
        let config = MLModelConfiguration()
        config.computeUnits = .all // Allows GPU fallback
        
        // In real code: self.model = try MLModel(contentsOf: url, configuration: config)
        self.model = MLModel()
        
        // Log the performance downgrade for telemetry
        onPerformanceDowngrade?("Fallback to GPU due to ANE incompatibility.")
        logger.notice("Performance Downgrade: Switched to GPU.")
    }
    
    func performInference(on image: CGImage) async throws -> String {
        guard model != nil else { throw NSError(domain: "EngineError", code: 0) }
        
        // Simulate inference
        try await Task.sleep(for: .milliseconds(500))
        return "A beautiful sunset over the mountains"
    }
    
    func startMonitoring() {
        monitor.setup()
        monitor.setThresholdCallback { report in
            print("Telemetry Alert: \(report.cpuUsage) usage at \(report.timestamp)")
        }
    }
}
