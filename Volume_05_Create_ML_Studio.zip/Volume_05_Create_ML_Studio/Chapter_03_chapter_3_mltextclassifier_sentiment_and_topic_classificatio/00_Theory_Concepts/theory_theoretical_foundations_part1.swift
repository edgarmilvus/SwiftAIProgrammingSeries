
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    import CreateML
    import Foundation

    @available(iOS 18.0, macOS 15.0, *)
    func trainSentimentClassifier() async {
        do {
            // Assume 'trainingData' is an MLTextClassifier.DataSource
            // prepared from your labeled text data (e.g., JSON, CSV).
            // As explained in a previous chapter, Create ML's DataSources
            // provide a flexible way to ingest various data formats.
            let trainingData = try MLTextClassifier.DataSource(
                at: URL(fileURLWithPath: "path/to/your/data.json"),
                textColumn: "text",
                labelColumn: "sentiment"
            )

            print("Starting model training...")
            let parameters = MLTextClassifier.ModelParameters(
                validationData: trainingData.randomSplit(by: 0.8).validation
            )
            let classifier = try await MLTextClassifier.train(
                trainingData: trainingData.randomSplit(by: 0.8).training,
                parameters: parameters
            )
            print("Model training complete.")

            // Save the trained model
            let modelURL = URL(fileURLWithPath: "SentimentClassifier.mlmodel")
            try classifier.write(to: modelURL)
            print("Model saved to \(modelURL.lastPathComponent)")

        } catch {
            print("Error during training: \(error.localizedDescription)")
        }
    }

    // Example usage in an async context
    @available(iOS 18.0, macOS 15.0, *)
    @main
    struct MyApp {
        static func main() async {
            await trainSentimentClassifier()
        }
    }
    