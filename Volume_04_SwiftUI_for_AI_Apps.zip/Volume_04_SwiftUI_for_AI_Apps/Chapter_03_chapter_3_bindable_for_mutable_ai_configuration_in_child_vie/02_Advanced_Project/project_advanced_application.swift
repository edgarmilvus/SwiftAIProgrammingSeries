
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift (Simulated Swift Package Manager dependencies)
// In a real project, this file would define your package and its dependencies.
// For this example, we're using core Swift and SwiftUI, so no external dependencies are strictly required.
// If integrating a real AI model, you might have something like:
/*
import PackageDescription

let package = Package(
    name: "VoiceAssistantAI",
    platforms: [.iOS(.v17), .macOS(.v14)], // @Observable and @Bindable require iOS 17+
    products: [
        .library(
            name: "VoiceAssistantAI",
            targets: ["VoiceAssistantAI"]),
    ],
    dependencies: [
        // Example: If using Hugging Face Transformers.swift for local models:
        // .package(url: "https://github.com/huggingface/swift-transformers.git", from: "0.1.0"),
        // Example: If using Core ML Tools for model conversion/utility:
        // .package(url: "https://github.com/apple/coremltools.git", .upToNextMajor(from: "7.0.0"))
    ],
    targets: [
        .target(
            name: "VoiceAssistantAI",
            dependencies: []),
        .testTarget(
            name: "VoiceAssistantAITests",
            dependencies: ["VoiceAssistantAI"]),
    ]
)
*/

// --- Start of the actual Swift 6 script/app component ---

import SwiftUI
import Foundation // For UUID, Double, etc.

// MARK: - 1. VoiceAssistantConfiguration: The Observable AI Model Settings

/// Represents the mutable configuration for the voice assistant's AI behavior.
/// This object is marked with `@Observable` to automatically notify SwiftUI
/// when any of its properties change, triggering UI updates.
///
/// Properties like `modelTemperature`, `responseLength`, and `selectedVoiceModel`
/// directly influence how the AI model processes requests and generates responses.
@Observable
@available(iOS 18.0, *) // @Observable and @Bindable are available from iOS 17, but Swift 6 context implies latest.
class VoiceAssistantConfiguration {
    /// Controls the randomness of the AI's output. Higher values lead to more creative/diverse responses.
    /// Values typically range from 0.0 (deterministic) to 1.0 or 2.0 (very creative).
    var modelTemperature: Double {
        didSet {
            // Ensure temperature stays within a valid range.
            if modelTemperature < 0.0 { modelTemperature = 0.0 }
            if modelTemperature > 2.0 { modelTemperature = 2.0 }
            print("Configuration: modelTemperature changed to \(modelTemperature)")
        }
    }

    /// Defines the desired length of the AI's generated responses, in tokens or words.
    /// This can influence verbosity and conciseness.
    var responseLength: Int {
        didSet {
            // Ensure response length is reasonable.
            if responseLength < 10 { responseLength = 10 }
            if responseLength > 500 { responseLength = 500 }
            print("Configuration: responseLength changed to \(responseLength)")
        }
    }

    /// The specific AI voice model selected for generating speech.
    /// This might correspond to different voices, languages, or emotional tones.
    var selectedVoiceModel: String {
        didSet {
            print("Configuration: selectedVoiceModel changed to \(selectedVoiceModel)")
        }
    }

    /// A flag indicating whether the AI should stream its responses token by token.
    /// Useful for real-time interaction and reducing perceived latency.
    var isStreamingResponses: Bool {
        didSet {
            print("Configuration: isStreamingResponses changed to \(isStreamingResponses)")
        }
    }

    /// Initializes a new voice assistant configuration with default values.
    init(modelTemperature: Double = 0.7, responseLength: Int = 100, selectedVoiceModel: String = "Neural-Voice-1", isStreamingResponses: Bool = true) {
        self.modelTemperature = modelTemperature
        self.responseLength = responseLength
        self.selectedVoiceModel = selectedVoiceModel
        self.isStreamingResponses = isStreamingResponses
    }
}

// MARK: - 2. VoiceAssistantService: Simulated AI Backend Interaction

/// A simulated service layer responsible for applying AI configuration changes.
/// In a real application, this would interact with a backend API or a local Core ML model.
@available(iOS 18.0, *)
class VoiceAssistantService {
    /// Custom error types for the service layer, providing localized descriptions.
    enum ServiceError: Error, LocalizedError {
        case invalidConfiguration(String)
        case backendError(String)

        var errorDescription: String? {
            switch self {
            case .invalidConfiguration(let message):
                return "Invalid Configuration: \(message)"
            case .backendError(let message):
                return "Backend Error: \(message)"
            }
        }
    }

    /// Asynchronously applies the given configuration to the AI system.
    /// This method simulates network latency and potential backend validation errors.
    /// - Parameter config: The `VoiceAssistantConfiguration` to apply.
    /// - Throws: `ServiceError` if the configuration is invalid or a backend issue occurs.
    func applyConfiguration(config: VoiceAssistantConfiguration) async throws {
        print("Service: Attempting to apply configuration...")
        // Simulate network delay
        try await Task.sleep(for: .seconds(Double.random(in: 0.5...1.5)))

        // Simulate backend validation logic
        if config.modelTemperature < 0.1 {
            throw ServiceError.invalidConfiguration("Temperature too low for meaningful responses (must be >= 0.1).")
        }
        if config.responseLength < 20 && config.isStreamingResponses == false {
            throw ServiceError.invalidConfiguration("Non-streaming responses below 20 words are often too abrupt.")
        }
        if config.selectedVoiceModel == "Legacy-Voice-Model" {
            throw ServiceError.backendError("Legacy voice models are no longer supported. Please select a modern model.")
        }

        // Simulate successful application
        print("Service: Configuration applied successfully!")
        print("  - Model Temperature: \(config.modelTemperature)")
        print("  - Response Length: \(config.responseLength)")
        print("  - Selected Voice Model: \(config.selectedVoiceModel)")
        print("  - Streaming: \(config.isStreamingResponses)")
    }
}

// MARK: - 3. ModelSelectionView: Child View for Voice Model Configuration

/// A child view responsible for allowing the user to select an AI voice model.
/// It receives a `@Bindable` `VoiceAssistantConfiguration` instance,
/// enabling direct, mutable access to the shared configuration object.
@available(iOS 18.0, *)
struct ModelSelectionView: View {
    /// `@Bindable` is used here because `configuration` is an `Observable` object
    /// that we want to pass down to a child view for direct, mutable access.
    /// This allows `ModelSelectionView` to modify the `selectedVoiceModel` property
    /// directly on the *same instance* of `VoiceAssistantConfiguration` owned by the parent.
    @Bindable var configuration: VoiceAssistantConfiguration

    /// A list of available voice models for the user to choose from.
    let availableModels = ["Neural-Voice-1", "Crisp-Voice-2", "Deep-Voice-3", "Friendly-Voice-4", "Legacy-Voice-Model"]

    var body: some View {
        VStack(alignment: .leading) {
            Text("Select Voice Model")
                .font(.headline)
            // Picker directly binds to `configuration.selectedVoiceModel`,
            // modifying the shared Observable object.
            Picker("Voice Model", selection: $configuration.selectedVoiceModel) {
                ForEach(availableModels, id: \.self) { model in
                    Text(model).tag(model)
                }
            }
            .pickerStyle(.segmented)
            // Observe changes for logging or additional side effects if needed.
            .onChange(of: configuration.selectedVoiceModel) { oldModel, newModel in
                print("ModelSelectionView: Selected model changed from '\(oldModel)' to '\(newModel)'")
            }
            Text("Current: \(configuration.selectedVoiceModel)")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 8)
    }
}

// MARK: - 4. ResponseTuningView: Child View for Response Parameter Configuration

/// A child view for fine-tuning AI response parameters like temperature and length.
/// Like `ModelSelectionView`, it uses `@Bindable` to directly modify the shared
/// `VoiceAssistantConfiguration` object.
@available(iOS 18.0, *)
struct ResponseTuningView: View {
    /// `@Bindable` provides mutable access to the `VoiceAssistantConfiguration`
    /// object, allowing this view to directly change `modelTemperature`,
    /// `responseLength`, and `isStreamingResponses`.
    @Bindable var configuration: VoiceAssistantConfiguration

    var body: some View {
        VStack(alignment: .leading) {
            Text("Response Behavior Tuning")
                .font(.headline)

            // Slider for Model Temperature: Directly binds to `configuration.modelTemperature`.
            HStack {
                Text("Temperature: \(configuration.modelTemperature, format: .number.precision(.fractionLength(2)))")
                Slider(value: $configuration.modelTemperature, in: 0.0...2.0, step: 0.1) {
                    Text("Model Temperature")
                } minimumValueLabel: {
                    Text("0.0")
                } maximumValueLabel: {
                    Text("2.0")
                }
            }
            .padding(.vertical, 4)

            // Stepper for Response Length: Directly binds to `configuration.responseLength`.
            HStack {
                Text("Length: \(configuration.responseLength) words")
                Stepper("Response Length", value: $configuration.responseLength, in: 10...500, step: 10)
            }
            .padding(.vertical, 4)

            // Toggle for Streaming Responses: Directly binds to `configuration.isStreamingResponses`.
            Toggle(isOn: $configuration.isStreamingResponses) {
                Text("Stream Responses")
            }
            .padding(.vertical, 4)
        }
        .padding(.vertical, 8)
    }
}

// MARK: - 5. VoiceAssistantSettingsView: Parent View Managing Configuration

/// The main settings view for the voice assistant.
/// It owns the `VoiceAssistantConfiguration` instance using `@State`,
/// ensuring that changes propagate throughout its child views and trigger UI updates.
/// It also orchestrates the application of these settings via `VoiceAssistantService`.
@available(iOS 18.0, *)
struct VoiceAssistantSettingsView: View {
    /// The source of truth for the voice assistant's configuration.
    /// `@State` ensures that `VoiceAssistantSettingsView` owns this object
    /// and that any changes to its `@Observable` properties will trigger a view re-render.
    @State private var configuration = VoiceAssistantConfiguration()

    /// The service responsible for interacting with the AI backend.
    /// `@State` also manages this instance, though it's not Observable itself.
    @State private var service = VoiceAssistantService()

    /// UI state for showing loading indicators during asynchronous operations.
    @State private var isApplyingSettings = false

    /// UI state for displaying error messages to the user.
    @State private var errorMessage: String?

    var body: some View {
        NavigationView {
            Form {
                Section("AI Model Selection") {
                    // Pass the configuration using @Bindable.
                    // This creates a binding to the *object itself*, not just a property.
                    // Children can then modify properties of this shared object directly.
                    ModelSelectionView(configuration: configuration)
                }

                Section("Response Behavior Tuning") {
                    // Similarly, pass the *same* configuration object to another child.
                    // Both children operate on the identical instance, ensuring consistency.
                    ResponseTuningView(configuration: configuration)
                }

                Section {
                    Button {
                        // Use a Task to perform the asynchronous settings application.
                        Task {
                            await applySettings()
                        }
                    } label: {
                        HStack {
                            if isApplyingSettings {
                                ProgressView() // Show loading indicator
                            }
                            Text("Apply Settings")
                        }
                    }
                    .disabled(isApplyingSettings) // Disable button while applying settings
                }

                // Display error message if present, in a separate section for clarity.
                if let errorMessage = errorMessage {
                    Section {
                        Text(errorMessage)
                            .foregroundColor(.red)
                    }
                }
            }
            .navigationTitle("AI Assistant Settings")
        }
    }

    /// Asynchronously applies the current configuration using the `VoiceAssistantService`.
    /// Handles loading state and error presentation.
    private func applySettings() async {
        isApplyingSettings = true
        errorMessage = nil // Clear previous errors before a new attempt

        do {
            // Call the service with the current configuration object.
            // The service receives the up-to-date configuration as modified by child views.
            try await service.applyConfiguration(config: configuration)
            print("Settings applied successfully!")
        } catch {
            // Catch and display any errors thrown by the service.
            errorMessage = error.localizedDescription
            print("Error applying settings: \(error.localizedDescription)")
        }

        isApplyingSettings = false // Reset loading state
    }
}

// MARK: - 6. VoiceAssistantApp: App Entry Point

/// The entry point for the SwiftUI application.
@available(iOS 18.0, *)
@main
struct VoiceAssistantApp: App {
    var body: some Scene {
        WindowGroup {
            VoiceAssistantSettingsView()
        }
    }
}
