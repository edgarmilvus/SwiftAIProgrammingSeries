
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import ARKit
import RealityKit
import Vision
import Combine

/// Errors specific to the Spatial Intelligence Engine, 
/// focusing on privacy and entitlement failures.
enum SpatialPrivacyError: LocalizedError {
    case cameraAccessDenied
    case sensorDataUnavailable
    case insufficientEntitlements(String)
    case processingFailure(Error)

    var errorDescription: String? {
        switch self {
        case .cameraAccessDenied:
            return "The user has denied access to spatial sensors."
        case .sensorDataUnavailable:
            return "Spatial sensor data is currently unavailable."
        case .insufficientEntitlements(let detail):
            return "Missing required entitlement: \(detail)"
        case .processingFailure(let error):
            return "AI Processing failed: \(error.localizedDescription)"
        }
    }
}

/// A thread-safe actor responsible for managing the ARKit session 
/// and ensuring privacy-compliant data handling.
/// Using an actor prevents data races when high-frequency sensor updates 
/// arrive from the ARKit background threads.
@available(visionOS 1.0, *)
actor SpatialSessionManager {
    
    private var session: ARKitSession?
    private var worldTracking: WorldTrackingProvider?
    private var isRunning = false
    
    /// An asynchronous stream that emits semantic updates (e.g., new planes or meshes).
    /// This uses Swift 6's AsyncStream to provide a modern, non-blocking way 
    /// to consume sensor data.
    private var continuation: AsyncStream<ARKitWorldTrackingFrame>.Continuation?
    lazy var frameStream: AsyncStream<ARKitWorldTrackingFrame> = {
        AsyncStream { continuation in
            self.continuation = continuation
        }
    }()

    init() {}

    /// Initializes the session and checks for necessary entitlements.
    /// In a real-world app, this would verify if 'com.apple.developer.arkit.scene-reconstruction'
    /// is present in the Info.plist and the provisioning profile.
    func startSession() async throws {
        guard !isRunning else { return }
        
        // Simulation of entitlement check logic
        // In visionOS, many entitlements are checked at runtime by the system.
        try await validateEntitlements()

        let session = ARKitSession()
        let worldTracking = WorldTrackingProvider()
        
        self.session = session
        self.worldTracking = worldTracking
        self.isRunning = true

        // Start the session task
        Task {
            do {
                try await session.run()
                try await monitorWorldTracking()
            } catch {
                print("Session error: \(error)")
                self.isRunning = false
            }
        }
    }

    /// Validates that the app has the required capabilities.
    /// This is a critical step in "Advanced Application" privacy management.
    private func validateEntitlements() async throws {
        // In production, you would check for specific ARKit capabilities.
        // For example, checking if Scene Reconstruction is available on the hardware.
        let isSceneReconstructionSupported = true // Placeholder for hardware check
        
        if !isSceneReconstructionSupported {
            throw SpatialPrivacyError.insufficientEntitlements("Scene Reconstruction")
        }
    }

    /// Continuously monitors the world tracking provider and yields frames to the stream.
    private func monitorWorldTracking() async throws {
        guard let worldTracking = worldTracking else { return }

        // We use the 'updates' stream provided by ARKit to react to changes.
        // This is more efficient than a polling loop.
        for await update in worldTracking.anchorUpdates {
            // We do NOT pass raw pixel buffers here. 
            // We pass the semantic information (Anchors/Meshes).
            if let frame = try? await worldTracking.queryFrame() {
                continuation?.yield(frame)
            }
        }
    }

    func stopSession() {
        isRunning = false
        continuation?.finish()
        session = nil
        worldTracking = nil
    }
}

/// A service that takes semantic data and applies AI/Vision logic to it.
/// This represents the "Spatial AI" component of the book.
@available(visionOS 1.0, *)
struct SpatialIntelligenceService {
    
    /// Analyzes a frame for semantic meaning.
    /// Note that we are working with ARKit frames, which contain spatial data,
    /// NOT the raw camera feed.
    func analyzeSpatialContext(in frame: ARKitWorldTrackingFrame) async throws -> [String] {
        // In a real app, you would use the frame's anchors to identify objects.
        // Example: Detecting a table via ARPlaneAnchor or a mesh via SceneReconstruction.
        
        // Simulation of AI processing latency
        try await Task.sleep(for: .milliseconds(100))
        
        let detectedObjects = ["Horizontal Plane (Table)", "Vertical Plane (Wall)"]
        return detectedObjects
    }
}

/// The ViewModel that bridges the Actor-based logic and the SwiftUI view.
/// It uses @MainActor to ensure all UI updates happen on the main thread.
@available(visionOS 1.0, *)
@MainActor
class SpatialIntelligenceViewModel: ObservableObject {
    
    @Published var status: String = "Idle"
    @Published var detectedFeatures: [String] = []
    @Published var isProcessing: Bool = false
    @Published var errorMessage: String?

    private let sessionManager = SpatialSessionManager()
    private let aiService = SpatialIntelligenceService()

    /// Starts the spatial intelligence pipeline.
    func startAnalysis() {
        status = "Initializing Sensors..."
        
        Task {
            do {
                try await sessionManager.startSession()
                status = "Monitoring Space..."
                
                // Consume the stream of semantic updates
                for await frame in await sessionManager.frameStream {
                    await processFrame(frame)
                }
            } catch {
                handleError(error)
            }
        }
    }

    /// Processes a single frame of semantic data.
    /// This is called for every update yielded by the session manager.
    private func processFrame(_ frame: ARKitWorldTrackingFrame) async {
        isProcessing = true
        do {
            let features = try await aiService.analyzeSpatialContext(in: frame)
            self.detectedFeatures = features
            self.status = "Scanning..."
        } catch {
            handleError(error)
        }
        isProcessing = false
    }

    private func handleError(_ error: Error) {
        self.errorMessage = error.localizedDescription
        self.status = "Error"
        print("Error: \(error.localizedDescription)")
    }
    
    func stop() {
        Task {
            await sessionManager.stopSession()
            status = "Stopped"
        }
    }
}

/// The SwiftUI View representing the user interface in visionOS.
@available(visionOS 1.0, *)
import SwiftUI

struct SpatialIntelligenceView: View {
    @StateObject private var viewModel = SpatialIntelligenceViewModel()

    var body: some View {
        VStack(spacing: 30) {
            Text("Spatial Intelligence Engine")
                .font(.largeTitle)
                .fontWeight(.bold)

            VStack(alignment: .leading, spacing: 10) {
                Text("System Status: \(viewModel.status)")
                    .font(.headline)
                    .foregroundColor(viewModel.status == "Error" ? .red : .secondary)

                if viewModel.isProcessing {
                    ProgressView()
                        .scaleEffect(0.5)
                }
            }
            .padding()
            .background(.ultraThinMaterial)
            .cornerRadius(12)

            Divider()

            VStack(alignment: .leading) {
                Text("Detected Semantic Features")
                    .font(.title2)
                
                if viewModel.detectedFeatures.isEmpty {
                    Text("No features detected yet. Move your head to scan.")
                        .font(.caption)
                        .italic()
                        .foregroundColor(.secondary)
                } else {
                    ForEach(viewModel.detectedFeatures, id: \.self) { feature in
                        HStack {
                            Image(systemName: "cube.transparent")
                            Text(feature)
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(.thinMaterial)
            .cornerRadius(12)

            HStack(spacing: 20) {
                Button(action: { viewModel.startAnalysis() }) {
                    Label("Start Scan", systemImage: "play.fill")
                }
                .disabled(viewModel.status == "Monitoring Space...")
                .buttonStyle(.borderedProminent)

                Button(action: { viewModel.stop() }) {
                    Label("Stop", systemImage: "stop.fill")
                }
                .buttonStyle(.bordered)
            }

            if let error = viewModel.errorMessage {
                Text(error)
                    .font(.caption)
                    .foregroundColor(.red)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(40)
        .frame(width: 600, height: 500)
    }
}
