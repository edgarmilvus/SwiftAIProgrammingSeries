
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import AppKit
import Foundation
import NaturalLanguage // Contains TextSummarizer

@available(macOS 15.0, *)
class DocumentViewController: NSViewController, NSTextViewDelegate, NSMenuDelegate {
    @IBOutlet var textView: NSTextView!

    // A preference to decide if the summary replaces or is inserted below
    private let summarizePreference: SummarizeAction = .insertBelow

    enum SummarizeAction {
        case replaceSelection
        case insertBelow
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        textView.delegate = self
        // Ensure the text view has a context menu
        textView.menu = NSMenu()
        textView.menu?.delegate = self
        textView.isRichText = false // For simpler text manipulation in this example
        textView.string = "This is a long document that requires summarization. Users often write extensive notes, reports, or articles within this text editor. The ability to quickly extract the main points from a selected portion of text would significantly enhance productivity. For example, if a user selects this entire paragraph, they should be able to right-click and choose 'Summarize Selection' from the context menu. The generated summary should then appear directly below the selected text, providing an immediate overview of the content without requiring them to manually copy, paste, and process it elsewhere. This feature would be invaluable for reviewing long passages, extracting key points, or generating executive summaries for various types of documents."
    }

    // MARK: - NSMenuDelegate
    func menuNeedsUpdate(_ menu: NSMenu) {
        // Clear existing items to add custom ones, but preserve system items if desired
        // For simplicity, we'll clear and add only our custom item if applicable.
        // In a real app, you might iterate and remove only specific custom items.
        menu.removeAllItems()

        // Add standard text editing items if desired (example)
        menu.addItem(NSMenuItem(title: "Cut", action: #selector(NSText.cut(_:)), keyEquivalent: "x"))
        menu.addItem(NSMenuItem(title: "Copy", action: #selector(NSText.copy(_:)), keyEquivalent: "c"))
        menu.addItem(NSMenuItem(title: "Paste", action: #selector(NSText.paste(_:)), keyEquivalent: "v"))
        menu.addItem(NSMenuItem.separator()) // Separator for clarity

        // Your custom "Summarize Selection" item logic
        if let selectedText = textView.selectedString, !selectedText.isEmpty {
            let summarizeItem = NSMenuItem(title: "Summarize Selection", action: #selector(summarizeSelectedText), keyEquivalent: "")
            menu.addItem(summarizeItem)
        }
    }

    @objc func summarizeSelectedText(_ sender: Any?) {
        guard let selectedText = textView.selectedString, !selectedText.isEmpty else { return }

        // Indicate loading state (e.g., cursor change, status bar message)
        self.view.window?.makeFirstResponder(nil) // Deselect to prevent further input
        NSApp.beginIgnoringInteractionEvents() // Prevent user interaction during async operation

        Task { @MainActor in // Ensure UI updates happen on the main actor
            do {
                let summarizer = TextSummarizer()
                let summary = try await summarizer.summarize(selectedText)

                // Perform text manipulation based on preference
                let currentSelectedRange = textView.selectedRange() // Re-get in case it changed
                if currentSelectedRange.length > 0 { // Ensure there's still a selection
                    switch summarizePreference {
                    case .replaceSelection:
                        textView.insertText(summary, replacementRange: currentSelectedRange)
                    case .insertBelow:
                        // Find the end of the selection, insert summary with newlines
                        let insertionPoint = currentSelectedRange.location + currentSelectedRange.length
                        let textToInsert = "\n\n--- Summary ---\n\(summary)\n--- End Summary ---\n"
                        textView.insertText(textToInsert, replacementRange: NSRange(location: insertionPoint, length: 0))
                        
                        // Select the newly inserted text for user visibility
                        textView.setSelectedRange(NSRange(location: insertionPoint + "\n\n--- Summary ---\n".count, length: summary.count))
                    }
                }
            } catch {
                print("Error summarizing text: \(error)")
                self.presentErrorAlert(message: "Failed to summarize text: \(error.localizedDescription)")
            }
            NSApp.endIgnoringInteractionEvents() // Re-enable user interaction
            self.view.window?.makeFirstResponder(textView) // Restore focus
        }
    }

    private func presentErrorAlert(message: String) {
        let alert = NSAlert()
        alert.messageText = "Summarization Error"
        alert.informativeText = message
        alert.alertStyle = .warning
        alert.addButton(withTitle: "OK")
        alert.beginSheet(for: self.view.window!) { response in
            // Handle alert dismissal if needed
        }
    }
}

extension NSTextView {
    // Helper to get the currently selected string
    var selectedString: String? {
        guard let textStorage = textStorage else { return nil }
        let selectedRange = self.selectedRange()
        guard selectedRange.length > 0 else { return nil }
        return textStorage.attributedSubstring(from: selectedRange).string
    }
}

// To run this, you would typically set up a simple macOS app with a WindowController
// and a ViewController containing an NSTextView, then connect the IBOutlet.
// For example, in Main.storyboard, drag an NSTextView into the ViewController's view,
// and connect its outlet to the textView property in DocumentViewController.
