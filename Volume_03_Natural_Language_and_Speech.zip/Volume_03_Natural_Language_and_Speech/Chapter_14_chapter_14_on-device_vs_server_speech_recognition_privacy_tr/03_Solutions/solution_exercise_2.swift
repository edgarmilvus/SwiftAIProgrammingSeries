
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import Speech
import AVFoundation

@available(iOS 18.0, *)
class SpeechSettingsManager {
    static let shared = SpeechSettingsManager()
    private let userDefaultsKey = "speechRecognitionModeOnDeviceEnabled" // true for on-device, false for server

    // Persists and retrieves the user's preference for on-device mode.
    var isOnDeviceModeEnabled: Bool {
        get {
            // Default to server-based (false) for wider compatibility if no preference is set.
            // This is a safer default regarding functionality, though not privacy.
            // Exercise description implies true for high privacy, so returning true as default if not set.
            // Let's stick to the prompt's implied default: if not set, assume server-based (false).
            return UserDefaults.standard.bool(forKey: userDefaultsKey)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: userDefaultsKey)
            // Post a notification so active speech recognition instances can react
            NotificationCenter.default.post(name: .speechRecognitionModeDidChange, object: nil)
        }
    }

    // Creates an SFSpeechRecognizer based on the user's preference.
    func createSpeechRecognizer(for locale: Locale) -> SFSpeechRecognizer? {
        if isOnDeviceModeEnabled {
            if SFSpeechRecognizer.onDeviceSupportedLocales.contains(locale) {
                print("Creating on-device speech recognizer for \(locale.identifier).")
                return SFSpeechRecognizer(locale: locale, onDevice: true)
            } else {
                print("Warning: On-device recognition not available for \(locale.identifier). Falling back to server-based.")
                // In a real app, you might want to show a UI alert here or disable the toggle.
                return SFSpeechRecognizer(locale: locale, onDevice: false) // Fallback to server
            }
        } else {
            print("Creating server-based speech recognizer for \(locale.identifier).")
            return SFSpeechRecognizer(locale: locale, onDevice: false) // Server-based
        }
    }
}

extension Notification.Name {
    static let speechRecognitionModeDidChange = Notification.Name("speechRecognitionModeDidChange")
}

@available(iOS 18.0, *)
class SpeechSettingsViewController: UIViewController {

    // MARK: - UI Elements
    private let modeSwitch: UISwitch = {
        let sw = UISwitch()
        sw.translatesAutoresizingMaskIntoConstraints = false
        return sw
    }()

    private let switchLabel: UILabel = {
        let label = UILabel()
        label.text = "High Privacy (On-Device Only)"
        label.font = .systemFont(ofSize: 17)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let privacyDescriptionLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: 15)
        label.textColor = .secondaryLabel
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let accuracyDescriptionLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: 15)
        label.textColor = .secondaryLabel
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        updateUIForCurrentMode()
        
        // Observe changes to the system locale if the app supports multiple languages
        NotificationCenter.default.addObserver(self, selector: #selector(localeDidChange), name: NSLocale.currentLocaleDidChangeNotification, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Speech Settings"

        let stackView = UIStackView(arrangedSubviews: [switchLabel, modeSwitch])
        stackView.axis = .horizontal
        stackView.alignment = .center
        stackView.spacing = 10
        stackView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(stackView)
        view.addSubview(privacyDescriptionLabel)
        view.addSubview(accuracyDescriptionLabel)

        modeSwitch.addTarget(self, action: #selector(modeSwitchToggled), for: .valueChanged)

        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            privacyDescriptionLabel.topAnchor.constraint(equalTo: stackView.bottomAnchor, constant: 10),
            privacyDescriptionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            privacyDescriptionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            accuracyDescriptionLabel.topAnchor.constraint(equalTo: privacyDescriptionLabel.bottomAnchor, constant: 20),
            accuracyDescriptionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            accuracyDescriptionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }

    // MARK: - Actions
    @objc private func modeSwitchToggled(_ sender: UISwitch) {
        let desiredState = sender.isOn
        let currentLocale = Locale.current

        if desiredState && !SFSpeechRecognizer.onDeviceSupportedLocales.contains(currentLocale) {
            // If user tries to enable on-device mode but it's not supported for the locale
            let alert = UIAlertController(title: "On-Device Not Available",
                                          message: "On-device recognition is not supported for your current language (\(currentLocale.localizedString(forIdentifier: currentLocale.identifier) ?? currentLocale.identifier)). Please choose 'Higher Accuracy' or change your device's language.",
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                sender.isOn = false // Revert the switch state
                SpeechSettingsManager.shared.isOnDeviceModeEnabled = false // Ensure manager reflects this
                self.updateDescriptionLabels(isOnDevice: false)
            })
            present(alert, animated: true)
        } else {
            SpeechSettingsManager.shared.isOnDeviceModeEnabled = desiredState
            updateDescriptionLabels(isOnDevice: desiredState)
        }
    }
    
    @objc private func localeDidChange() {
        // Re-evaluate on-device support if locale changes
        updateUIForCurrentMode()
    }

    // MARK: - UI Update Logic
    private func updateUIForCurrentMode() {
        let isOnDevice = SpeechSettingsManager.shared.isOnDeviceModeEnabled
        modeSwitch.isOn = isOnDevice
        updateDescriptionLabels(isOnDevice: isOnDevice)
    }

    private func updateDescriptionLabels(isOnDevice: Bool) {
        if isOnDevice {
            privacyDescriptionLabel.text = "✅ High Privacy (On-Device Only): Your audio data never leaves your device. May have slightly lower accuracy or limited language support."
            accuracyDescriptionLabel.text = "Higher Accuracy (Server-Based): (Currently OFF) Leverages Apple's powerful cloud-based recognition for best results. Audio data is sent to Apple's servers, anonymized, and used to improve speech recognition technologies."
            privacyDescriptionLabel.textColor = .label
            accuracyDescriptionLabel.textColor = .secondaryLabel
        } else {
            privacyDescriptionLabel.text = "High Privacy (On-Device Only): (Currently OFF) Your audio data never leaves your device. May have slightly lower accuracy or limited language support."
            accuracyDescriptionLabel.text = "✅ Higher Accuracy (Server-Based): Leverages Apple's powerful cloud-based recognition for best results. Audio data is sent to Apple's servers, anonymized, and used to improve speech recognition technologies."
            privacyDescriptionLabel.textColor = .secondaryLabel
            accuracyDescriptionLabel.textColor = .label
        }
    }
}

// Example of how to use the SpeechSettingsManager in another part of the app (e.g., a journaling view)
@available(iOS 18.0, *)
class JournalingViewController: UIViewController {
    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private let audioEngine = AVAudioEngine() // Simplified for example

    override func viewDidLoad() {
        super.viewDidLoad()
        // Listen for changes in speech recognition mode
        NotificationCenter.default.addObserver(self, selector: #selector(handleSpeechModeChange), name: .speechRecognitionModeDidChange, object: nil)
        setupSpeechRecognition()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        stopRecognition() // Clean up resources
    }

    private func setupSpeechRecognition() {
        // Stop any existing recognition before setting up new one
        stopRecognition()
        
        let currentLocale = Locale.current
        speechRecognizer = SpeechSettingsManager.shared.createSpeechRecognizer(for: currentLocale)
        
        if speechRecognizer == nil {
            print("Could not initialize speech recognizer with current settings.")
            // Disable voice input UI or show an alert
        } else {
            print("Speech recognizer initialized with mode: \(SpeechSettingsManager.shared.isOnDeviceModeEnabled ? "On-Device" : "Server-Based")")
            // Enable voice input UI
        }
    }
    
    @objc private func handleSpeechModeChange() {
        print("Speech recognition mode changed. Reconfiguring recognizer...")
        setupSpeechRecognition() // Re-initialize the recognizer
    }
    
    // Simplified start/stop for demonstration
    func startRecognition() {
        guard let recognizer = speechRecognizer else {
            print("Speech recognizer not available.")
            return
        }
        // ... (AVAudioEngine setup and recognition task as in Exercise 1) ...
        print("Starting recognition in \(SpeechSettingsManager.shared.isOnDeviceModeEnabled ? "On-Device" : "Server-Based") mode.")
    }
    
    func stopRecognition() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionRequest = nil
        // recognitionTask?.cancel() // If a task was active
        print("Stopped recognition.")
    }
}
