
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import RealityKit
import Foundation

enum MaterialType: String, Codable, Sendable {
    case wood, marble, fabric, glass, unknown
}

struct MaterialInferenceComponent: Component, Codable, Sendable {
    let type: MaterialType
    let surfaceRoughness: Float
}

struct VirtualFurnitureComponent: Component, Codable, Sendable {}

struct ReflectivityBoostComponent: Component, Codable, Sendable {
    var boostFactor: Float
}

@available(visionOS 1.0, *)
class MaterialIntelligenceSystem: System {
    private static let materialQuery = EntityQuery(where: .has(MaterialInferenceComponent.self))
    private static let furnitureQuery = EntityQuery(where: .has(VirtualFurnitureComponent.self))
    
    required init(scene: Scene) {}

    func update(context: SceneUpdateContext) {
        // 1. Simulate Gaze Detection (In real visionOS, this uses Gaze/Raycast)
        // For this exercise, we assume we have a 'gazeTarget' entity.
        let gazeTarget: Entity? = nil // Simulated result of a raycast
        
        if let target = gazeTarget, var model = target.components[ModelComponent.self] {
            // Trigger Pulse: Modulate emissive color
            // Note: In production, ensure the material is unique to this entity
            var material = PhysicallyBasedMaterial()
            material.emissiveColor = .init(color: .white)
            material.emissiveIntensity = 2.0 
            model.materials = [material]
            target.components[ModelComponent.self] = model
        }

        // 2. Propagation Logic: Reflectivity Boost
        let materials = context.scene.performQuery(Self.materialQuery)
        let furniture = context.scene.performQuery(Self.furnitureQuery)

        for furnitureEntity in furniture {
            var maxBoost: Float = 1.0
            
            for materialEntity in materials {
                let matData = materialEntity.components[MaterialInferenceComponent.self]!
                
                // Check proximity and material type
                if matData.type == .marble {
                    let distance = distance(furnitureEntity.position(relativeTo: nil), 
                                            materialEntity.position(relativeTo: nil))
                    
                    if distance < 1.5 { // 1.5 meter radius
                        maxBoost = max(maxBoost, 2.5) // Boost factor for marble
                    }
                }
            }
            
            // Update or Add the ReflectivityBoostComponent
            furnitureEntity.components[ReflectivityBoostComponent.self] = ReflectivityBoostComponent(boostFactor: maxBoost)
        }
    }
}
