
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import SwiftData
import OSLog

/// Protocol ensuring all data models can be converted to a portable JSON format.
protocol ExportableEntity: Sendable {
    func toExportableJSON() throws -> Data
}

/// A container for the final export package.
struct UserDataArchive: Codable, Sendable {
    let exportDate: Date
    let interactions: [Data] // Encoded JSON blobs of individual entities
}

@available(iOS 18.0, *)
final actor DataExportManager {
    private let logger = Logger(subsystem: "com.zenith.compliance", category: "DSAR")
    private let fileManager = FileManager.default
    
    /// Aggregates data from multiple sources concurrently.
    func generateDSARArchive(
        chatInteractions: [ChatInteraction],
        userPreferences: [String: String]
    ) async throws -> URL {
        logger.info("Starting DSAR archive generation.")
        
        // Use TaskGroup for concurrent data processing
        let aggregatedData = try await withThrowingTaskGroup(of: Data.self) { group in
            // 1. Process Chat Interactions
            for interaction in chatInteractions {
                group.addTask {
                    let encoder = JSONEncoder()
                    encoder.dateEncodingStrategy = .iso8601
                    return try encoder.encode(interaction)
                }
            }
            
            // 2. Process Preferences
            group.addTask {
                let encoder = JSONEncoder()
                return try encoder.encode(userPreferences)
            }
            
            var results = [Data]()
            for try await data in group {
                results.append(data)
            }
            return results
        }
        
        // Create the final archive structure
        let archive = UserDataArchive(exportDate: Date(), interactions: aggregatedData)
        let finalData = try JSONEncoder().encode(archive)
        
        // Define secure storage path
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let archiveURL = documentsURL.appendingPathComponent("DSAR_Export_\(Date().timeIntervalSince1970).json")
        
        // Write with strict file protection (GDPR requirement for data at rest)
        try finalData.write(to: archiveURL, options: [.atomic, .completeUntilFirstUserAuthentication])
        
        logger.info("DSAR Archive successfully created at: \(archiveURL.path)")
        return archiveURL
    }
}

// Mock implementation of the model for completeness
@available(iOS 18.0, *)
@Model
final class ChatInteraction: ExportableEntity, Codable {
    var timestamp: Date
    var userPrompt: String
    var aiResponse: String
    var modelIdentifier: String
    var temperature: Float
    
    init(userPrompt: String, aiResponse: String, modelIdentifier: String, temperature: Float) {
        self.timestamp = Date()
        self.userPrompt = userPrompt
        self.aiResponse = aiResponse
        self.modelIdentifier = modelIdentifier
        self.temperature = temperature
    }
    
    // Codable implementation for ExportableEntity
    enum CodingKeys: String, CodingKey {
        case timestamp, userPrompt, aiResponse, modelIdentifier, temperature
    }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        timestamp = try container.decode(Date.self, forKey: .timestamp)
        userPrompt = try container.decode(String.self, forKey: .userPrompt)
        aiResponse = try container.decode(String.self, forKey: .aiResponse)
        modelIdentifier = try container.decode(String.self, forKey: .modelIdentifier)
        temperature = try container.decode(Float.self, forKey: .temperature)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(timestamp, forKey: .timestamp)
        try container.encode(userPrompt, forKey: .userPrompt)
        try container.encode(aiResponse, forKey: .aiResponse)
        try container.encode(modelIdentifier, forKey: .modelIdentifier)
        try container.encode(temperature, forKey: .temperature)
    }
    
    func toExportableJSON() throws -> Data {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        return try encoder.encode(self)
    }
}
