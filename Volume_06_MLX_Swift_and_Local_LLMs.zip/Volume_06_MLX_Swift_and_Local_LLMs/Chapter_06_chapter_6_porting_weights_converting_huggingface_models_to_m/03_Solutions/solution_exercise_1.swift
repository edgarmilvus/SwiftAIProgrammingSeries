
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import MLX
import MLXNN

@available(iOS 18.0, macOS 15.0, *)
class SimpleTextClassifier: MLXNN.Module {
    let embedding: MLXNN.Embedding
    let encoderLayer: MLXNN.TransformerEncoderLayer
    let classifier: MLXNN.Linear

    init(vocabSize: Int, embeddingDim: Int, numHeads: Int, ffnDim: Int, numClasses: Int) {
        self.embedding = MLXNN.Embedding(outputDimensions: embeddingDim, vocabularySize: vocabSize)
        self.encoderLayer = MLXNN.TransformerEncoderLayer(
            dimensions: embeddingDim,
            numHeads: numHeads,
            feedForwardDimensions: ffnDim
        )
        self.classifier = MLXNN.Linear(inputDimensions: embeddingDim, outputDimensions: numClasses)
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // input: [batch_size, sequence_length] - e.g., token IDs
        let embedded = embedding(input) // [batch_size, sequence_length, embedding_dim]
        let encoded = encoderLayer(embedded) // [batch_size, sequence_length, embedding_dim]

        // For classification, typically take the [CLS] token's representation (first token)
        // or perform pooling. Here, we simulate taking the first token for simplicity.
        // encoded.dim: [batch_size, sequence_length, embedding_dim]
        // We want [batch_size, 1, embedding_dim]
        let clsToken = encoded[0..<(encoded.dim[0]), 0..<1, 0..<(encoded.dim[2])]
        // Flatten to [batch_size, embedding_dim] for the linear classifier
        let pooledOutput = MLX.flatten(clsToken, start: 1) 

        return classifier(pooledOutput) // [batch_size, num_classes] (logits)
    }
}

// MARK: - Weight Conversion and Inference Logic

@available(iOS 18.0, macOS 15.0, *)
func runTextClassifierExercise() {
    print("--- Exercise 1: Basic Text Classifier for Sentiment Analysis ---")

    // Model Hyperparameters
    let vocabSize = 10000
    let embeddingDim = 256
    let numHeads = 4
    let ffnDim = 512
    let numClasses = 3 // e.g., Positive, Negative, Neutral
    let batchSize = 2
    let sequenceLength = 10

    // 1. Instantiate the MLX Swift model
    let model = SimpleTextClassifier(
        vocabSize: vocabSize,
        embeddingDim: embeddingDim,
        numHeads: numHeads,
        ffnDim: ffnDim,
        numClasses: numClasses
    )

    // 2. Simulate HuggingFace-like weights
    // These would typically be loaded from a .safetensors or .bin file
    var hfWeights: [String: MLXArray] = [:]

    // Embedding layer
    hfWeights["embeddings.word_embeddings.weight"] = MLXArray.rand([vocabSize, embeddingDim], .float32)

    // Transformer Encoder Layer (simplified, only one layer for demonstration)
    // Attention QKV
    hfWeights["encoder.layer.0.attention.self.query.weight"] = MLXArray.rand([embeddingDim, embeddingDim], .float32)
    hfWeights["encoder.layer.0.attention.self.query.bias"] = MLXArray.rand([embeddingDim], .float32)
    hfWeights["encoder.layer.0.attention.self.key.weight"] = MLXArray.rand([embeddingDim, embeddingDim], .float32)
    hfWeights["encoder.layer.0.attention.self.key.bias"] = MLXArray.rand([embeddingDim], .float32)
    hfWeights["encoder.layer.0.attention.self.value.weight"] = MLXArray.rand([embeddingDim, embeddingDim], .float32)
    hfWeights["encoder.layer.0.attention.self.value.bias"] = MLXArray.rand([embeddingDim], .float32)

    // Attention Output
    hfWeights["encoder.layer.0.attention.output.dense.weight"] = MLXArray.rand([embeddingDim, embeddingDim], .float32)
    hfWeights["encoder.layer.0.attention.output.dense.bias"] = MLXArray.rand([embeddingDim], .float32)
    hfWeights["encoder.layer.0.attention.output.LayerNorm.weight"] = MLXArray.rand([embeddingDim], .float32)
    hfWeights["encoder.layer.0.attention.output.LayerNorm.bias"] = MLXArray.rand([embeddingDim], .float32)

    // FFN Intermediate (up-projection)
    hfWeights["encoder.layer.0.intermediate.dense.weight"] = MLXArray.rand([ffnDim, embeddingDim], .float32)
    hfWeights["encoder.layer.0.intermediate.dense.bias"] = MLXArray.rand([ffnDim], .float32)

    // FFN Output (down-projection)
    hfWeights["encoder.layer.0.output.dense.weight"] = MLXArray.rand([embeddingDim, ffnDim], .float32)
    hfWeights["encoder.layer.0.output.dense.bias"] = MLXArray.rand([embeddingDim], .float32)
    hfWeights["encoder.layer.0.output.LayerNorm.weight"] = MLXArray.rand([embeddingDim], .float32)
    hfWeights["encoder.layer.0.output.LayerNorm.bias"] = MLXArray.rand([embeddingDim], .float32)

    // Classification Head
    hfWeights["classifier.weight"] = MLXArray.rand([numClasses, embeddingDim], .float32)
    hfWeights["classifier.bias"] = MLXArray.rand([numClasses], .float32)

    print("Simulated HuggingFace weights created. Total: \(hfWeights.count) tensors.")

    // 3. Implement Weight Conversion Logic
    // Mapping PyTorch-style weights to MLX Swift model parameters
    // Note: PyTorch Linear layers often have `out_features, in_features` for weight,
    // while MLXNN.Linear expects `in_features, out_features`. Thus, transposition is needed.
    // Embedding weights are typically `vocab_size, embedding_dim` in both.
    
    model.embedding.weight = hfWeights["embeddings.word_embeddings.weight"]!

    // Transformer Encoder Layer
    // Self-Attention
    model.encoderLayer.selfAttention.query.weight = hfWeights["encoder.layer.0.attention.self.query.weight"]!.transposed()
    model.encoderLayer.selfAttention.query.bias = hfWeights["encoder.layer.0.attention.self.query.bias"]!
    model.encoderLayer.selfAttention.key.weight = hfWeights["encoder.layer.0.attention.self.key.weight"]!.transposed()
    model.encoderLayer.selfAttention.key.bias = hfWeights["encoder.layer.0.attention.self.key.bias"]!
    model.encoderLayer.selfAttention.value.weight = hfWeights["encoder.layer.0.attention.self.value.weight"]!.transposed()
    model.encoderLayer.selfAttention.value.bias = hfWeights["encoder.layer.0.attention.self.value.bias"]!
    model.encoderLayer.selfAttention.output.weight = hfWeights["encoder.layer.0.attention.output.dense.weight"]!.transposed()
    model.encoderLayer.selfAttention.output.bias = hfWeights["encoder.layer.0.attention.output.dense.bias"]!
    
    // Layer Norms
    model.encoderLayer.norm1.weight = hfWeights["encoder.layer.0.attention.output.LayerNorm.weight"]!
    model.encoderLayer.norm1.bias = hfWeights["encoder.layer.0.attention.output.LayerNorm.bias"]!

    // Feed-Forward Network
    model.encoderLayer.feedForward.linear1.weight = hfWeights["encoder.layer.0.intermediate.dense.weight"]!.transposed()
    model.encoderLayer.feedForward.linear1.bias = hfWeights["encoder.layer.0.intermediate.dense.bias"]!
    model.encoderLayer.feedForward.linear2.weight = hfWeights["encoder.layer.0.output.dense.weight"]!.transposed()
    model.encoderLayer.feedForward.linear2.bias = hfWeights["encoder.layer.0.output.dense.bias"]!

    model.encoderLayer.norm2.weight = hfWeights["encoder.layer.0.output.LayerNorm.weight"]!
    model.encoderLayer.norm2.bias = hfWeights["encoder.layer.0.output.LayerNorm.bias"]!

    // Classifier Head
    model.classifier.weight = hfWeights["classifier.weight"]!.transposed()
    model.classifier.bias = hfWeights["classifier.bias"]!

    print("Weights successfully converted and loaded into the MLX Swift model.")

    // 4. Perform Inference
    // Create a dummy input representing tokenized sentences
    // Batch size of 2, sequence length of 10, token IDs from 0 to vocabSize-1
    let dummyInput = MLXArray.rand([batchSize, sequenceLength], .int32) * MLXArray(vocabSize)
    MLX.eval(dummyInput) // Force computation of dummy input

    print("\nDummy input shape: \(dummyInput.shape)")
    print("Dummy input (first sentence): \(dummyInput[0])")

    let logits = model(dummyInput)
    MLX.eval(logits) // Force computation of the output logits

    print("\nInference complete.")
    print("Output logits shape: \(logits.shape)") // Expected: [batch_size, num_classes]
    print("Output logits (first batch item): \(logits[0])") // Logits for the first sentence
    
    // Example: get predicted class for the first item in the batch
    let predictedClass = MLX.argmax(logits[0]).item(Int.self)
    print("Predicted class for first item: \(predictedClass)")
    
    print("--- End Exercise 1 ---")
}

// Call the function to run the exercise
// runTextClassifierExercise() // Uncomment to run in a playground or main.swift
