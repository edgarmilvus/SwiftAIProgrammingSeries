
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

// Re-using User and ChatMessage structs from previous exercises (assumed Sendable)
struct User: Identifiable, Hashable { // Hashable for Set<User.ID>
    let id: UUID
    let name: String
    let avatarURL: URL?
}

struct ChatMessage: Identifiable {
    let id: UUID
    let sender: User
    let content: String
    let timestamp: Date
    // Assuming attachment: Attachment? from Ex2 is also here, but not critical for this exercise's core logic.
}

// 1. Define a Conversation struct
struct Conversation: Identifiable, Sendable { // Explicit Sendable for clarity
    let id: UUID
    var participants: [User] // Array<User> is Sendable if User is Sendable
    var messages: [ChatMessage] // Array<ChatMessage> is Sendable if ChatMessage is Sendable
    var lastUpdated: Date
    var readBy: Set<User.ID> // Set<UUID> is Sendable if UUID is Sendable (UUID is Hashable & Sendable)
    
    // Conversation is automatically Sendable because all its properties are Sendable.
    // Arrays and Sets of Sendable types are themselves Sendable.
}

// 2. Create a ConversationManager actor
actor ConversationManager {
    private var conversations: [UUID: Conversation] = [:] // Dictionary<UUID, Conversation> is Sendable if its Key and Value are Sendable
    
    // 3. Implement asynchronous methods
    
    /// Adds a new message to an existing conversation or creates a new one.
    func addMessage(_ message: ChatMessage, toConversationId: UUID) {
        if var conversation = conversations[toConversationId] {
            // Add message to existing conversation
            conversation.messages.append(message)
            conversation.lastUpdated = message.timestamp
            // Ensure sender is in participants if not already
            if !conversation.participants.contains(where: { $0.id == message.sender.id }) {
                conversation.participants.append(message.sender)
            }
            conversations[toConversationId] = conversation
        } else {
            // Create a new conversation
            let newConversation = Conversation(
                id: toConversationId,
                participants: [message.sender],
                messages: [message],
                lastUpdated: message.timestamp,
                readBy: [] // Initially empty
            )
            conversations[toConversationId] = newConversation
        }
        print("ConversationManager: Message '\(message.content)' added to conversation \(toConversationId)")
    }
    
    /// Retrieves a specific conversation by its ID.
    func getConversation(id: UUID) -> Conversation? {
        return conversations[id]
    }
    
    /// Returns a list of all managed conversations, sorted by `lastUpdated` in descending order.
    func getAllConversations() -> [Conversation] {
        return conversations.values.sorted { $0.lastUpdated > $1.lastUpdated }
    }
    
    /// Marks a conversation as read for a specific user.
    func markConversationAsRead(id: UUID, forUser user: User) {
        guard var conversation = conversations[id] else {
            print("ConversationManager: Conversation \(id) not found to mark as read.")
            return
        }
        conversation.readBy.insert(user.id)
        conversations[id] = conversation
        print("ConversationManager: Conversation \(id) marked as read by \(user.name)")
    }
}

// Example Usage
func demonstrateActorManagement() async {
    let manager = ConversationManager()
    
    let userA = User(id: UUID(), name: "Alice", avatarURL: nil)
    let userB = User(id: UUID(), name: "Bob", avatarURL: nil)
    
    let convoId1 = UUID()
    let convoId2 = UUID()
    
    // Add messages to convoId1
    let msg1 = ChatMessage(id: UUID(), sender: userA, content: "Hi Bob!", timestamp: Date())
    await manager.addMessage(msg1, toConversationId: convoId1)
    
    try? await Task.sleep(for: .milliseconds(50)) // Simulate time passing
    
    let msg2 = ChatMessage(id: UUID(), sender: userB, content: "Hey Alice!", timestamp: Date())
    await manager.addMessage(msg2, toConversationId: convoId1)
    
    try? await Task.sleep(for: .milliseconds(50))
    
    let msg3 = ChatMessage(id: UUID(), sender: userA, content: "How are you?", timestamp: Date())
    await manager.addMessage(msg3, toConversationId: convoId1)
    
    // Add a message to a new convoId2
    let msg4 = ChatMessage(id: UUID(), sender: userB, content: "New chat with Alice.", timestamp: Date())
    await manager.addMessage(msg4, toConversationId: convoId2)
    
    // Get and print a specific conversation
    if let convo1 = await manager.getConversation(id: convoId1) {
        print("\n--- Conversation \(convo1.id) ---")
        print("Participants: \(convo1.participants.map { $0.name }.joined(separator: ", "))")
        print("Last message: \(convo1.messages.last?.content ?? "N/A")")
        print("Read by: \(convo1.readBy.count > 0 ? "Some" : "None")")
    }
    
    // Mark convoId1 as read by userA
    await manager.markConversationAsRead(id: convoId1, forUser: userA)
    if let convo1 = await manager.getConversation(id: convoId1) {
        print("Convo 1 read by count after marking: \(convo1.readBy.count)")
    }
    
    // Get all conversations
    let allConvos = await manager.getAllConversations()
    print("\n--- All Conversations (sorted by last updated) ---")
    for convo in allConvos {
        print("ID: \(convo.id), Last Message: \(convo.messages.last?.content ?? "N/A"), Last Updated: \(convo.lastUpdated)")
    }
}

// Call to demonstrate
// Task { await demonstrateActorManagement() }
