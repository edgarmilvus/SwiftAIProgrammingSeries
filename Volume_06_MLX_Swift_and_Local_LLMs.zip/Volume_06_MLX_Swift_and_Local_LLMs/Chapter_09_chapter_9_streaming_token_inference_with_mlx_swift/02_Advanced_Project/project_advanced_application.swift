
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// swift-tools-version:6.0
import PackageDescription

let package = Package(
    name: "SmartChatAssistant",
    platforms: [
        .iOS(.v18), // Requires iOS 18+ for MLX Swift
        .macOS(.v15), // Requires macOS 15+ for MLX Swift
    ],
    products: [
        .library(
            name: "SmartChatAssistant",
            targets: ["SmartChatAssistant"]),
    ],
    dependencies: [
        // MLX Swift for high-performance on-device machine learning
        .package(url: "https://github.com/ml-explore/mlx-swift.git", from: "0.1.0"),
        // A hypothetical tokenizer library. In a real app, this would be a robust,
        // often custom-built, BPE or WordPiece tokenizer.
        // For this example, we'll use a simplified internal one.
        // .package(url: "https://github.com/your-org/tokenizers-swift.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "SmartChatAssistant",
            dependencies: [
                .product(name: "MLX", package: "mlx-swift"),
                .product(name: "MLXNN", package: "mlx-swift"),
            ]),
        .testTarget(
            name: "SmartChatAssistantTests",
            dependencies: ["SmartChatAssistant"]),
    ]
)
