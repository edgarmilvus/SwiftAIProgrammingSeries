
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// This solution provides a combined approach for iOS (UIKit) and macOS (AppKit)
// by using conditional compilation. For a real app, you'd typically have separate
// UI codebases. The core bookmark logic is platform-agnostic.

import Foundation
import UniformTypeIdentifiers // For UTType on iOS/macOS
#if canImport(UIKit)
import UIKit
#elseif canImport(AppKit)
import AppKit
#endif

// MARK: - Bookmark Management Logic (Platform-Agnostic)

class DocumentBookmarkManager {
    static let shared = DocumentBookmarkManager()
    private let userDefaultsKey = "lastEditedDocumentBookmark"

    private var currentAccessedURL: URL? {
        didSet {
            // Ensure stopAccessing is called if the URL changes or is set to nil
            if oldValue != currentAccessedURL {
                oldValue?.stopAccessingSecurityScopedResource()
            }
        }
    }

    // Call this when the app is about to terminate or when access is no longer needed
    func stopAccessingCurrentDocument() {
        currentAccessedURL?.stopAccessingSecurityScopedResource()
        currentAccessedURL = nil
    }

    // Saves a bookmark for the given URL to UserDefaults
    func saveBookmark(for url: URL) throws {
        guard url.startAccessingSecurityScopedResource() else {
            print("Failed to start accessing security-scoped resource for saving bookmark.")
            throw BookmarkError.accessDenied
        }
        defer { url.stopAccessingSecurityScopedResource() }

        let bookmarkData = try url.bookmarkData(options: .withSecurityScopedResource,
                                                includingResourceValuesForKeys: nil,
                                                relativeTo: nil)
        UserDefaults.standard.set(bookmarkData, forKey: userDefaultsKey)
        print("Bookmark saved for: \(url.lastPathComponent)")
    }

    // Resolves the stored bookmark and returns the URL, handling stale bookmarks
    func resolveBookmark() -> URL? {
        guard let bookmarkData = UserDefaults.standard.data(forKey: userDefaultsKey) else {
            print("No bookmark data found.")
            return nil
        }

        var isStale = false
        do {
            let url = try URL(resolvingBookmarkData: bookmarkData,
                              options: .withSecurityScopedResource,
                              relativeTo: nil,
                              bookmarkDataIsStale: &isStale)

            if isStale {
                print("Bookmark is stale, attempting to refresh...")
                // If stale, try to create a new bookmark from the resolved URL
                // This updates the stored bookmark to the latest path/identifier
                let newBookmarkData = try url.bookmarkData(options: .withSecurityScopedResource,
                                                           includingResourceValuesForKeys: nil,
                                                           relativeTo: nil)
                UserDefaults.standard.set(newBookmarkData, forKey: userDefaultsKey)
                print("Bookmark refreshed successfully.")
            }

            // Attempt to gain access to the resource
            guard url.startAccessingSecurityScopedResource() else {
                print("Failed to start accessing security-scoped resource after resolving bookmark.")
                return nil
            }
            currentAccessedURL = url
            print("Successfully resolved and accessed: \(url.lastPathComponent)")
            return url

        } catch {
            print("Error resolving or refreshing bookmark: \(error.localizedDescription)")
            // If resolution fails, clear the invalid bookmark
            clearBookmark()
            return nil
        }
    }

    // Removes the stored bookmark from UserDefaults
    func clearBookmark() {
        stopAccessingCurrentDocument() // Ensure access is stopped before clearing
        UserDefaults.standard.removeObject(forKey: userDefaultsKey)
        print("Bookmark cleared from UserDefaults.")
    }

    enum BookmarkError: Error, LocalizedError {
        case accessDenied
        case bookmarkCreationFailed(Error)

        var errorDescription: String? {
            switch self {
            case .accessDenied: return "Access to the selected resource was denied."
            case .bookmarkCreationFailed(let error): return "Failed to create bookmark: \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - UI Implementation (Conditional for iOS/macOS)

#if canImport(UIKit) // iOS Implementation

class ViewController: UIViewController, UIDocumentPickerDelegate {

    let statusLabel = UILabel()
    let contentTextView = UITextView()
    let selectButton = UIButton(type: .system)
    let clearButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadLastDocument()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        DocumentBookmarkManager.shared.stopAccessingCurrentDocument()
    }

    func setupUI() {
        view.backgroundColor = .systemBackground

        statusLabel.text = "No document loaded."
        statusLabel.textAlignment = .center
        statusLabel.numberOfLines = 0
        statusLabel.translatesAutoresizingMaskIntoConstraints = false

        contentTextView.isEditable = false
        contentTextView.layer.borderColor = UIColor.lightGray.cgColor
        contentTextView.layer.borderWidth = 1.0
        contentTextView.translatesAutoresizingMaskIntoConstraints = false

        selectButton.setTitle("Select Document", for: .normal)
        selectButton.addTarget(self, action: #selector(selectDocumentTapped), for: .touchUpInside)
        selectButton.translatesAutoresizingMaskIntoConstraints = false

        clearButton.setTitle("Clear Last Document", for: .normal)
        clearButton.addTarget(self, action: #selector(clearDocumentTapped), for: .touchUpInside)
        clearButton.translatesAutoresizingMaskIntoConstraints = false

        let stackView = UIStackView(arrangedSubviews: [statusLabel, contentTextView, selectButton, clearButton])
        stackView.axis = .vertical
        stackView.spacing = 10
        stackView.distribution = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            stackView.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            contentTextView.heightAnchor.constraint(equalToConstant: 200)
        ])
    }

    @objc func selectDocumentTapped() {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.text], asCopy: false)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        present(documentPicker, animated: true, completion: nil)
    }

    @objc func clearDocumentTapped() {
        DocumentBookmarkManager.shared.clearBookmark()
        statusLabel.text = "Last document cleared."
        contentTextView.text = ""
    }

    func loadLastDocument() {
        Task { // Use Task for potential async operations, though file I/O here is simple
            if let url = DocumentBookmarkManager.shared.resolveBookmark() {
                do {
                    let content = try String(contentsOf: url, encoding: .utf8)
                    DispatchQueue.main.async { // Ensure UI updates on main thread
                        self.statusLabel.text = "Loaded: \(url.lastPathComponent) (from bookmark)"
                        self.contentTextView.text = content
                    }
                } catch {
                    DispatchQueue.main.async {
                        self.statusLabel.text = "Error reading file from bookmark: \(error.localizedDescription)"
                        self.contentTextView.text = ""
                        DocumentBookmarkManager.shared.clearBookmark() // Clear invalid bookmark
                    }
                }
            } else {
                DispatchQueue.main.async {
                    self.statusLabel.text = "No last document found or accessible."
                    self.contentTextView.text = ""
                }
            }
        }
    }

    // MARK: - UIDocumentPickerDelegate

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }

        Task {
            do {
                try DocumentBookmarkManager.shared.saveBookmark(for: url)
                // Reload the document to ensure the newly saved bookmark is used
                await MainActor.run { // Ensure UI updates happen on main actor
                    self.loadLastDocument()
                }
            } catch {
                await MainActor.run {
                    self.statusLabel.text = "Error saving bookmark: \(error.localizedDescription)"
                }
            }
        }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("Document picker cancelled.")
    }
}

#elseif canImport(AppKit) // macOS Implementation

class ViewController: NSViewController {

    let statusLabel = NSTextField(labelWithString: "No document loaded.")
    let contentTextView = NSTextView()
    let selectButton = NSButton(title: "Select Document", target: nil, action: nil)
    let clearButton = NSButton(title: "Clear Last Document", target: nil, action: nil)

    override func loadView() {
        self.view = NSView()
        self.view.wantsLayer = true // Needed for background color
        self.view.layer?.backgroundColor = NSColor.windowBackgroundColor.cgColor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadLastDocument()
    }

    override func viewWillDisappear() {
        super.viewWillDisappear()
        DocumentBookmarkManager.shared.stopAccessingCurrentDocument()
    }

    func setupUI() {
        statusLabel.alignment = .center
        statusLabel.maximumNumberOfLines = 0
        statusLabel.translatesAutoresizingMaskIntoConstraints = false

        let scrollView = NSScrollView()
        scrollView.hasVerticalScroller = true
        scrollView.documentView = contentTextView
        contentTextView.isEditable = false
        contentTextView.isSelectable = true
        contentTextView.font = NSFont.monospacedSystemFont(ofSize: 12, weight: .regular)
        scrollView.translatesAutoresizingMaskIntoConstraints = false

        selectButton.target = self
        selectButton.action = #selector(selectDocumentTapped)
        selectButton.translatesAutoresizingMaskIntoConstraints = false

        clearButton.target = self
        clearButton.action = #selector(clearDocumentTapped)
        clearButton.translatesAutoresizingMaskIntoConstraints = false

        let stackView = NSStackView(views: [statusLabel, scrollView, selectButton, clearButton])
        stackView.orientation = .vertical
        stackView.spacing = 10
        stackView.distribution = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            stackView.bottomAnchor.constraint(lessThanOrEqualTo: view.bottomAnchor, constant: -20),
            scrollView.heightAnchor.constraint(equalToConstant: 200)
        ])
    }

    @objc func selectDocumentTapped() {
        let openPanel = NSOpenPanel()
        openPanel.canChooseFiles = true
        openPanel.canChooseDirectories = false
        openPanel.allowsMultipleSelection = false
        openPanel.allowedContentTypes = [UTType.text] // Use UTType for modern macOS

        openPanel.begin { [weak self] response in
            guard response == .OK, let url = openPanel.url else {
                print("Open panel cancelled or no URL selected.")
                return
            }

            Task {
                do {
                    try DocumentBookmarkManager.shared.saveBookmark(for: url)
                    await MainActor.run {
                        self?.loadLastDocument()
                    }
                } catch {
                    await MainActor.run {
                        self?.statusLabel.stringValue = "Error saving bookmark: \(error.localizedDescription)"
                    }
                }
            }
        }
    }

    @objc func clearDocumentTapped() {
        DocumentBookmarkManager.shared.clearBookmark()
        statusLabel.stringValue = "Last document cleared."
        contentTextView.string = ""
    }

    func loadLastDocument() {
        Task {
            if let url = DocumentBookmarkManager.shared.resolveBookmark() {
                do {
                    let content = try String(contentsOf: url, encoding: .utf8)
                    await MainActor.run {
                        self.statusLabel.stringValue = "Loaded: \(url.lastPathComponent) (from bookmark)"
                        self.contentTextView.string = content
                    }
                } catch {
                    await MainActor.run {
                        self.statusLabel.stringValue = "Error reading file from bookmark: \(error.localizedDescription)"
                        self.contentTextView.string = ""
                        DocumentBookmarkManager.shared.clearBookmark()
                    }
                }
            } else {
                await MainActor.run {
                    self.statusLabel.stringValue = "No last document found or accessible."
                    self.contentTextView.string = ""
                }
            }
        }
    }
}

// Example AppDelegate for macOS to set up the window and initial view controller
@main
class AppDelegate: NSObject, NSApplicationDelegate {

    var window: NSWindow!

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 600, height: 400),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.center()
        window.setFrameAutosaveName("MainWindow")
        window.contentViewController = ViewController()
        window.makeKeyAndOrderFront(nil)
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        DocumentBookmarkManager.shared.stopAccessingCurrentDocument()
    }

    func applicationSupportsSecureRestorableState(_ app: NSApplication) -> Bool {
        return true
    }
}
#endif
