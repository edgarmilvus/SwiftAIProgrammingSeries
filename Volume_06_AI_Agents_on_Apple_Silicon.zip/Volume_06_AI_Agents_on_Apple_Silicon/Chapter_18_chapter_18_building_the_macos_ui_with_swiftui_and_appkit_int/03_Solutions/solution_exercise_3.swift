
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import AppKit

// MARK: - 2. Design SwiftUI Dashboard View

class AIDashboardViewModel: ObservableObject {
    @Published var modelStatus: String = "Loading..."
    @Published var inferenceRunning: Bool = false
    @Published var autoUpdateModels: Bool = UserDefaults.standard.bool(forKey: "autoUpdateModels")
    @Published var recentInteractions: [String] = []

    init() {
        // Simulate initial model loading
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.modelStatus = "Model Loaded: Llama 3 (7B)"
            self.addLog("AI Model initialized.")
        }
    }

    func toggleInference() {
        inferenceRunning.toggle()
        if inferenceRunning {
            addLog("Inference started.")
            // Simulate inference activity
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                if self.inferenceRunning { // Check if still running
                    self.addLog("Inference completed one cycle.")
                }
            }
        } else {
            addLog("Inference stopped.")
        }
    }

    func addLog(_ message: String) {
        let timestamp = DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .medium)
        recentInteractions.insert("[\(timestamp)] \(message)", at: 0)
        if recentInteractions.count > 10 { // Keep only latest 10 logs
            recentInteractions.removeLast()
        }
    }
    
    func toggleAutoUpdate(_ enabled: Bool) {
        autoUpdateModels = enabled
        UserDefaults.standard.set(enabled, forKey: "autoUpdateModels")
        addLog("Auto-update models: \(enabled ? "Enabled" : "Disabled")")
    }
}

struct AIDashboardView: View {
    @EnvironmentObject var viewModel: AIDashboardViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("AI Agent Dashboard")
                .font(.headline)
                .padding(.bottom, 5)

            HStack {
                Text("Status:")
                Spacer()
                Text(viewModel.modelStatus)
                    .font(.subheadline)
                    .foregroundColor(viewModel.modelStatus.contains("Loaded") ? .green : .orange)
            }

            Divider()

            HStack {
                Button(viewModel.inferenceRunning ? "Stop Inference" : "Start Inference") {
                    viewModel.toggleInference()
                }
                .buttonStyle(.borderedProminent)
                .tint(viewModel.inferenceRunning ? .red : .accentColor)
                
                Toggle("Auto-update Models", isOn: Binding(
                    get: { viewModel.autoUpdateModels },
                    set: { viewModel.toggleAutoUpdate($0) }
                ))
                .toggleStyle(.switch)
            }
            .padding(.vertical, 5)

            Text("Recent Interactions:")
                .font(.subheadline)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    if viewModel.recentInteractions.isEmpty {
                        Text("No recent interactions.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    } else {
                        ForEach(viewModel.recentInteractions, id: \.self) { log in
                            Text(log)
                                .font(.caption)
                                .foregroundColor(.gray)
                                .lineLimit(1)
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(height: 100)
            .padding(5)
            .background(Color.black.opacity(0.05))
            .cornerRadius(5)
        }
        .padding()
        .frame(width: 300) // Fixed width for the popover content
    }
}

// MARK: - 1 & 3. AppKit NSStatusItem Setup and Host SwiftUI in Popover

// This class will manage the NSStatusItem and NSPopover
class StatusBarManager: NSObject, NSPopoverDelegate {
    var statusItem: NSStatusItem!
    var popover: NSPopover!
    let dashboardViewModel = AIDashboardViewModel() // Shared view model for the popover

    override init() {
        super.init()
        setupStatusItem()
        setupPopover()
    }

    private func setupStatusItem() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)

        if let button = statusItem.button {
            button.image = NSImage(systemSymbolName: "brain.head.profile", accessibilityDescription: "AI Agent Dashboard")
            button.action = #selector(togglePopover(_:))
            button.target = self
        }
    }

    private func setupPopover() {
        popover = NSPopover()
        popover.contentSize = NSSize(width: 300, height: 350) // Adjust content size as needed
        popover.behavior = .transient // Dismisses when clicking outside
        popover.delegate = self // Set delegate to manage popover lifecycle

        // Host the SwiftUI view with the shared view model
        popover.contentViewController = NSHostingController(rootView:
            AIDashboardView()
                .environmentObject(dashboardViewModel)
        )
    }

    @objc func togglePopover(_ sender: AnyObject?) {
        if popover.isShown {
            popover.performClose(sender)
        } else {
            if let button = statusItem.button {
                popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
            }
        }
    }
    
    // MARK: - NSPopoverDelegate (Optional but good practice)
    func popoverDidClose(_ notification: Notification) {
        // Optional: Perform any cleanup or state reset when popover closes
        print("Popover did close.")
    }
    
    func popoverWillShow(_ notification: Notification) {
        // Optional: Perform actions before popover shows
        print("Popover will show.")
    }
}

// MARK: - App Delegate Integration

// Modify your AppDelegate to instantiate and manage StatusBarManager
class AppDelegate: NSObject, NSApplicationDelegate {
    var statusBarManager: StatusBarManager?

    func applicationDidFinishLaunching(_ notification: Notification) {
        // Ensure the app is running as an agent (no dock icon, no main window)
        // This is optional for menu bar apps, but common for utilities.
        // If you want a dock icon and main window, comment this out.
        // NSApp.setActivationPolicy(.accessory) // For agent app without dock icon

        // Create the status bar manager
        statusBarManager = StatusBarManager()
    }
    
    func applicationWillTerminate(_ notification: Notification) {
        // Clean up resources if necessary
        statusBarManager = nil
    }
}

// MARK: - Main App Structure
@main
struct AppKitSwiftUIApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        // An empty WindowGroup is often used for menu bar apps if they don't have a main window.
        // If you remove it, ensure NSApp.setActivationPolicy(.accessory) is used in AppDelegate
        // to prevent an empty window from appearing.
        Settings {
            // Settings window content (e.g., general app settings)
            // This will appear if you click "Settings..." from the app menu
            Text("General App Settings (Optional)")
        }
    }
}
