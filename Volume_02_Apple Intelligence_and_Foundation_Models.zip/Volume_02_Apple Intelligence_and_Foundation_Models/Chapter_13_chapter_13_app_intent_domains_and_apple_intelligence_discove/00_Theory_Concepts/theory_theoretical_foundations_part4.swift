
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

    import AppIntents
    import Foundation

    // Custom struct used as a parameter, must be Sendable
    struct DocumentMetadata: Codable, Sendable {
        let title: String
        let author: String
        let creationDate: Date
    }

    // Custom struct used as a return value, must be Sendable
    struct SummarizationResult: Codable, Sendable {
        let summaryText: String
        let wordCount: Int
        let modelUsed: String
    }

    @available(iOS 18.0, *)
    struct AdvancedSummarizeIntent: AppIntent {
        static var title: LocalizedStringResource = "Advanced Document Summarization"

        @Parameter(title: "Metadata")
        var metadata: DocumentMetadata // DocumentMetadata must be Sendable

        @Parameter(title: "Full Content")
        var documentContent: String

        func perform() async throws -> some IntentResult {
            // Simulate advanced LLM call
            let result = try await performAdvancedLLMSummarization(
                content: documentContent,
                metadata: metadata
            )
            return .result(value: result) // SummarizationResult must be Sendable
        }

        private func performAdvancedLLMSummarization(
            content: String,
            metadata: DocumentMetadata
        ) async throws -> SummarizationResult {
            try await Task.sleep(for: .seconds(2))
            let summary = "Advanced summary of '\(metadata.title)' by \(metadata.author): \(content.prefix(50))..."
            return SummarizationResult(
                summaryText: summary,
                wordCount: summary.split(separator: " ").count,
                modelUsed: "On-Device LLM v2"
            )
        }
    }
    