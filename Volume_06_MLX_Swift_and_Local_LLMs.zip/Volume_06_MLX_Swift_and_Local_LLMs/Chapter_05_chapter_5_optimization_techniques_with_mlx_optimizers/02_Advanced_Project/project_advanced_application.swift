
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift
// This is the Swift Package Manager manifest for your project.

import PackageDescription

let package = Package(
    name: "MLXTextEnhancer",
    platforms: [
        .macOS(.v14), // MLX Swift requires macOS 14+
        .iOS(.v17),   // or iOS 17+
        .visionOS(.v1) // or visionOS 1+
    ],
    products: [
        .library(
            name: "MLXTextEnhancer",
            targets: ["MLXTextEnhancer"]),
    ],
    dependencies: [
        // MLX Swift library - Use the latest stable version
        .package(url: "https://github.com/ml-explore/mlx-swift.git", from: "0.10.0"),
    ],
    targets: [
        .target(
            name: "MLXTextEnhancer",
            dependencies: [
                .product(name: "MLX", package: "mlx-swift"),
                .product(name: "MLXNN", package: "mlx-swift"),
                .product(name: "MLXOptimizers", package: "mlx-swift")
            ]),
        .testTarget(
            name: "MLXTextEnhancerTests",
            dependencies: ["MLXTextEnhancer"]),
    ]
)
