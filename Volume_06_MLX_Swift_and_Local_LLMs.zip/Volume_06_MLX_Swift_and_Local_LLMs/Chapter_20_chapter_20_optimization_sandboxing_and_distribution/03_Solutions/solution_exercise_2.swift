
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import MLX
import MLXNN
import Foundation // For abs

@available(iOS 18.0, macOS 14.0, *)
final class SmoothReLU: MLXNN.Module {
    init() {
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Implement f(x) = x * sigmoid(x)
        return input * MLX.sigmoid(input)
    }
}

@available(iOS 18.0, macOS 14.0, *)
/// Computes the numerical gradient of the sum of a function's output with respect to its input.
/// This approximates d(sum(f(x))) / dx_i for each element x_i.
/// - Parameters:
///   - function: The function for which to compute the gradient. It should take an MLXArray and return an MLXArray.
///   - input: The input MLXArray at which to compute the gradient.
///   - epsilon: The small perturbation value for finite difference approximation.
/// - Returns: An MLXArray representing the numerical gradient, with the same shape as the input.
func numericalGradientOfSum(function: (MLXArray) -> MLXArray, input: MLXArray, epsilon: Float = 1e-4) -> MLXArray {
    let originalShape = input.shape
    let flatInputData = input.flatten().data(as: Float.self)! // Get raw data for perturbation
    var numericalGradData = [Float](repeating: 0, count: flatInputData.count)

    for i in 0..<flatInputData.count {
        // Perturb x_i by +epsilon
        var inputPlusEpsilonData = flatInputData
        inputPlusEpsilonData[i] += epsilon
        let xPlusEpsilon = MLXArray(inputPlusEpsilonData, shape: originalShape, type: .float32)

        // Perturb x_i by -epsilon
        var inputMinusEpsilonData = flatInputData
        inputMinusEpsilonData[i] -= epsilon
        let xMinusEpsilon = MLXArray(inputMinusEpsilonData, shape: originalShape, type: .float32)

        // Compute f(x + epsilon) and f(x - epsilon), then sum their outputs
        let f_x_plus_epsilon_sum = function(xPlusEpsilon).sum().item(Float.self)!
        let f_x_minus_epsilon_sum = function(xMinusEpsilon).sum().item(Float.self)!

        // Calculate the numerical gradient for this element
        numericalGradData[i] = (f_x_plus_epsilon_sum - f_x_minus_epsilon_sum) / (2 * epsilon)
    }
    return MLXArray(numericalGradData, shape: originalShape, type: .float32)
}

@available(iOS 18.0, macOS 14.0, *)
func runGradientCheck() {
    let input = MLXArray.random(low: -5, high: 5, [100], type: .float32)
    let smoothReLU = SmoothReLU()
    let epsilon: Float = 1e-4
    let tolerance: Float = 1e-4

    print("Running gradient check for SmoothReLU...")

    // 1. Compute gradient using MLX's auto-diff
    // We compute the gradient of the sum of the activation's output with respect to its input.
    // This is a common way to get a scalar loss for gradient computation.
    let (value, autoDiffGradient) = MLX.valueAndGradient(of: { x in
        let activation = smoothReLU(x)
        return activation.sum() // Sum to get a scalar for gradient computation
    }, arg: input)
    MLX.eval(value, autoDiffGradient) // Force computation

    // 2. Compute numerical gradient
    let numericalGradient = numericalGradientOfSum(function: smoothReLU.callAsFunction, input: input, epsilon: epsilon)
    MLX.eval(numericalGradient) // Force computation

    // 3. Compare and print results
    let diff = MLX.abs(autoDiffGradient - numericalGradient)
    let maxDiff = diff.max().item(Float.self)!

    print("Max absolute difference between auto-diff and numerical gradient: \(maxDiff)")

    if maxDiff < tolerance {
        print("Gradient check PASSED: Gradients are sufficiently close (tolerance: \(tolerance)).")
    } else {
        print("Gradient check FAILED: Gradients differ significantly.")
        // Optionally print parts of the gradients for inspection
        // print("Auto-diff gradient (first 5): \(autoDiffGradient.flatten().data(as: Float.self)!.prefix(5))")
        // print("Numerical gradient (first 5): \(numericalGradient.flatten().data(as: Float.self)!.prefix(5))")
    }
}

// Call the example function
// runGradientCheck()
