
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CoreML
import Vision
import Foundation
import UIKit
import VideoToolbox // For CVPixelBuffer creation

@available(iOS 18.0, *)
class ObjectDetectionService {
    private var primaryVNCoreMLModel: VNCoreMLModel?
    private var simpleVNCoreMLModel: VNCoreMLModel?

    init() {
        loadModels()
    }

    private func loadModels() {
        // Assume these models exist in the bundle as .mlmodelc files
        // For testing, you can create dummy .mlmodel files in Xcode and compile them.
        // To simulate failure, rename or remove one of the files.

        // Load primary model
        if let primaryModelURL = Bundle.main.url(forResource: "PrimaryObjectDetector", withExtension: "mlmodelc") {
            do {
                let primaryMLModel = try MLModel(contentsOf: primaryModelURL)
                self.primaryVNCoreMLModel = try VNCoreMLModel(for: primaryMLModel)
                print("PrimaryObjectDetector loaded successfully.")
            } catch {
                print("Error loading PrimaryObjectDetector: \(error.localizedDescription) - will rely on fallback.")
            }
        } else {
            print("PrimaryObjectDetector.mlmodelc not found in bundle.")
        }

        // Load simple model
        if let simpleModelURL = Bundle.main.url(forResource: "SimpleObjectDetector", withExtension: "mlmodelc") {
            do {
                let simpleMLModel = try MLModel(contentsOf: simpleModelURL)
                self.simpleVNCoreMLModel = try VNCoreMLModel(for: simpleMLModel)
                print("SimpleObjectDetector loaded successfully.")
            } catch {
                print("Error loading SimpleObjectDetector: \(error.localizedDescription) - will rely on non-ML fallback.")
            }
        } else {
            print("SimpleObjectDetector.mlmodelc not found in bundle.")
        }
    }

    /// Performs object detection with a primary model, falling back to simpler models or non-ML requests on failure.
    /// - Parameters:
    ///   - pixelBuffer: The CVPixelBuffer containing the image data.
    ///   - completion: A closure to be called with the results ([VNRecognizedObjectObservation]?) and a status message.
    func detectObjects(in pixelBuffer: CVPixelBuffer, completion: @escaping ([VNRecognizedObjectObservation]?, String) -> Void) {
        // Ensure the pixel buffer is valid before proceeding
        guard CVPixelBufferGetPixelFormatType(pixelBuffer) != 0 else {
            print("Error: Invalid CVPixelBuffer provided.")
            completion(nil, "Invalid input image.")
            return
        }

        guard let primaryModel = primaryVNCoreMLModel else {
            print("Primary model not available. Attempting fallback immediately.")
            performFallbackDetection(in: pixelBuffer, completion: completion)
            return
        }

        let primaryRequest = VNCoreMLRequest(model: primaryModel) { [weak self] request, error in
            if let error = error {
                print("Error with PrimaryObjectDetector request: \(error.localizedDescription)")
                if let visionError = error as? VisionError {
                    print("Specific VisionError with PrimaryObjectDetector: \(visionError.localizedDescription)")
                    // Handle specific VisionError types if needed, e.g., .requestFailed, .modelRuntimeError
                }
                self?.performFallbackDetection(in: pixelBuffer, completion: completion)
            } else {
                // Primary model succeeded
                let observations = request.results as? [VNRecognizedObjectObservation]
                print("Primary model successful. Found \(observations?.count ?? 0) objects.")
                completion(observations, "Primary model successful.")
            }
        }
        
        // Configure primary request if needed, e.g., .imageCropAndScaleOption
        primaryRequest.imageCropAndScaleOption = .centerCrop
        primaryRequest.usesCPUOnly = false // Try to use GPU if available

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up)
        do {
            try handler.perform([primaryRequest])
        } catch let error as VisionError {
            print("VisionError during primary request handler performance: \(error.localizedDescription)")
            performFallbackDetection(in: pixelBuffer, completion: completion)
        } catch {
            print("Unexpected error during primary request handler performance: \(error.localizedDescription)")
            performFallbackDetection(in: pixelBuffer, completion: completion)
        }
    }

    /// Performs detection using the simpler Core ML model.
    private func performFallbackDetection(in pixelBuffer: CVPixelBuffer, completion: @escaping ([VNRecognizedObjectObservation]?, String) -> Void) {
        guard let simpleModel = simpleVNCoreMLModel else {
            print("Simple model not available. Falling back to basic text detection.")
            performNonMLFallbackDetection(in: pixelBuffer, completion: completion)
            return
        }

        let simpleRequest = VNCoreMLRequest(model: simpleModel) { [weak self] request, error in
            if let error = error {
                print("Error with SimpleObjectDetector request: \(error.localizedDescription)")
                if let visionError = error as? VisionError {
                    print("Specific VisionError with SimpleObjectDetector: \(visionError.localizedDescription)")
                }
                self?.performNonMLFallbackDetection(in: pixelBuffer, completion: completion)
            } else {
                // Simple model succeeded
                let observations = request.results as? [VNRecognizedObjectObservation]
                print("Fallback (simple model) successful. Found \(observations?.count ?? 0) objects.")
                completion(observations, "Fallback (simple model) successful.")
            }
        }

        simpleRequest.imageCropAndScaleOption = .scaleFit
        simpleRequest.usesCPUOnly = true // Use CPU for simpler model to ensure it runs

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up)
        do {
            try handler.perform([simpleRequest])
        } catch let error as VisionError {
            print("VisionError during simple request handler performance: \(error.localizedDescription)")
            performNonMLFallbackDetection(in: pixelBuffer, completion: completion)
        } catch {
            print("Unexpected error during simple request handler performance: \(error.localizedDescription)")
            performNonMLFallbackDetection(in: pixelBuffer, completion: completion)
        }
    }

    /// Performs a non-ML Vision request (e.g., text detection) as a last resort fallback.
    private func performNonMLFallbackDetection(in pixelBuffer: CVPixelBuffer, completion: @escaping ([VNRecognizedObjectObservation]?, String) -> Void) {
        print("Performing non-ML fallback (e.g., basic text detection).")
        let textRequest = VNDetectTextRectanglesRequest { request, error in
            if let error = error {
                print("Error with VNDetectTextRectanglesRequest (non-ML fallback): \(error.localizedDescription)")
                completion(nil, "All detection attempts failed.")
            } else {
                // VNDetectTextRectanglesRequest returns VNTextObservation, not VNRecognizedObjectObservation.
                // For this exercise, we'll return an empty array of the expected type or nil.
                let textObservations = request.results as? [VNTextObservation]
                print("Non-ML text detection fallback performed. Found \(textObservations?.count ?? 0) text blocks.")
                completion([], "Non-ML fallback (text detection) performed.") // Return empty for object detection type
            }
        }
        textRequest.reportCharacterBoxes = false // Only detect lines of text

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up)
        do {
            try handler.perform([textRequest])
        } catch {
            print("Error during non-ML text detection handler performance: \(error.localizedDescription)")
            completion(nil, "All detection attempts failed.")
        }
    }

    // Helper to create a dummy CVPixelBuffer for testing
    static func createDummyPixelBuffer(width: Int, height: Int) -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        let attributes: [CFString: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferMetalCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferWidthKey: width,
            kCVPixelBufferHeightKey: height,
            kCVPixelBufferPixelFormatTypeKey: kCVPixelFormatType_32BGRA
        ]
        
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         kCVPixelFormatType_32BGRA,
                                         attributes as CFDictionary,
                                         &pixelBuffer)
        
        guard status == kCVReturnSuccess else {
            print("Failed to create dummy CVPixelBuffer: \(status)")
            return nil
        }
        
        // Lock base address and fill with some data (e.g., black)
        CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let buffer = CVPixelBufferGetBaseAddress(pixelBuffer!)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer!)
        memset(buffer, 0, height * bytesPerRow) // Fill with black
        CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        
        return pixelBuffer
    }
    
    // Helper to create an invalid CVPixelBuffer for testing failure
    static func createInvalidPixelBuffer() -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        // Create with an invalid pixel format or dimensions
        let status = CVPixelBufferCreate(kCFAllocatorDefault, 0, 0, kCVPixelFormatType_32BGRA, nil, &pixelBuffer)
        if status != kCVReturnSuccess {
            print("Failed to create intentionally invalid CVPixelBuffer.")
        }
        return pixelBuffer
    }
}

// Example Usage (e.g., in a ViewController or background task)
/*
@available(iOS 18.0, *)
func demonstrateObjectDetectionFallbacks() {
    let detectorService = ObjectDetectionService()

    // 1. Test with a valid pixel buffer (assuming models load successfully)
    if let validPixelBuffer = ObjectDetectionService.createDummyPixelBuffer(width: 640, height: 480) {
        detectorService.detectObjects(in: validPixelBuffer) { observations, status in
            print("\n--- Test 1 (Valid Input) ---")
            print("Status: \(status)")
            print("Observations: \(observations?.count ?? 0)")
        }
    }

    // 2. Test simulating primary model failure (e.g., by making primaryVNCoreMLModel nil after init)
    // For a real test, you'd rename PrimaryObjectDetector.mlmodelc in your bundle.
    detectorService.primaryVNCoreMLModel = nil // Force primary model failure
    if let validPixelBuffer = ObjectDetectionService.createDummyPixelBuffer(width: 640, height: 480) {
        detectorService.detectObjects(in: validPixelBuffer) { observations, status in
            print("\n--- Test 2 (Primary Model Forced Failure) ---")
            print("Status: \(status)")
            print("Observations: \(observations?.count ?? 0)")
        }
    }
    detectorService.primaryVNCoreMLModel = try? VNCoreMLModel(for: MLModel(contentsOf: Bundle.main.url(forResource: "PrimaryObjectDetector", withExtension: "mlmodelc")!)) // Restore for next tests

    // 3. Test simulating both primary and simple model failure
    // For a real test, you'd rename both PrimaryObjectDetector.mlmodelc and SimpleObjectDetector.mlmodelc
    detectorService.primaryVNCoreMLModel = nil
    detectorService.simpleVNCoreMLModel = nil
    if let validPixelBuffer = ObjectDetectionService.createDummyPixelBuffer(width: 640, height: 480) {
        detectorService.detectObjects(in: validPixelBuffer) { observations, status in
            print("\n--- Test 3 (Primary & Simple Models Forced Failure) ---")
            print("Status: \(status)")
            print("Observations: \(observations?.count ?? 0)")
        }
    }
    detectorService.loadModels() // Reload models for subsequent tests if needed

    // 4. Test with an invalid CVPixelBuffer to trigger handler.perform() error
    if let invalidPixelBuffer = ObjectDetectionService.createInvalidPixelBuffer() {
        detectorService.detectObjects(in: invalidPixelBuffer) { observations, status in
            print("\n--- Test 4 (Invalid CVPixelBuffer Input) ---")
            print("Status: \(status)")
            print("Observations: \(observations?.count ?? 0)")
        }
    }
}
// Call demonstrateObjectDetectionFallbacks() from your AppDelegate or a UIViewController
// DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
//     demonstrateObjectDetectionFallbacks()
// }
*/
