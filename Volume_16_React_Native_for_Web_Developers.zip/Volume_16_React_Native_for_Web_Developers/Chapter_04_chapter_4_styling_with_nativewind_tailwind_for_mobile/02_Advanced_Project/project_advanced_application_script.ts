/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import React, { useState, useTransition } from 'react';
import { View, Text, ScrollView, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { styled } from 'nativewind';

/**
 * --------------------------------------------------------------------------
 * STYLED COMPONENTS
 * --------------------------------------------------------------------------
 * We use `styled()` to wrap standard React Native components. This injects
 * the NativeWind `className` prop capability into them.
 * 
 * Under the hood: NativeWind transforms these classes into optimized 
 * StyleSheet.create objects during the build process.
 */

// A styled View acting as the main application container.
const StyledContainer = styled(View);
// A styled Text component for headers.
const StyledHeader = styled(Text);
// A styled View for the dashboard cards.
const StyledCard = styled(View);
// A styled TouchableOpacity for interactive buttons.
const StyledButton = styled(TouchableOpacity);
// A styled ScrollView for scrollable content.
const StyledScroll = styled(ScrollView);

/**
 * --------------------------------------------------------------------------
 * TYPE DEFINITIONS
 * --------------------------------------------------------------------------
 */

interface AnalyticsData {
  id: string;
  metric: string;
  value: string;
  trend: 'up' | 'down';
}

/**
 * --------------------------------------------------------------------------
 * COMPONENT: DashboardView
 * --------------------------------------------------------------------------
 * 
 * @description
 * A universal dashboard component that fetches data and renders it using
 * NativeWind utility classes. It demonstrates resilience against network
 * failures and utilizes React 18's `useTransition` for non-blocking UI updates.
 */
export default function DashboardView() {
  // State for storing the analytics data
  const [data, setData] = useState<AnalyticsData[]>([]);
  
  // State for tracking the loading status explicitly
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // useTransition: Allows us to mark the data fetch as a non-urgent update.
  // This keeps the UI responsive even if the data fetch takes a moment.
  const [isPending, startTransition] = useTransition();

  /**
   * --------------------------------------------------------------------------
   * LOGIC: Data Fetching & Resilience
   * --------------------------------------------------------------------------
   * 
   * The "Exhaustive Asynchronous Resilience" mandate is applied here.
   * We wrap the async operation in a try/catch/finally block to ensure
   * the UI never gets stuck in a loading state and errors are handled.
   */
  const fetchDashboardData = async () => {
    // Start the transition for a smoother UX
    startTransition(() => {
      setIsLoading(true);
    });

    try {
      // Simulate a network request to a SaaS backend
      const response = await simulateNetworkRequest();

      if (!response.ok) {
        // Simulate a potential API failure
        throw new Error('Failed to fetch analytics data');
      }

      // Simulated data payload
      const mockData: AnalyticsData[] = [
        { id: '1', metric: 'Daily Active Users', value: '12,405', trend: 'up' },
        { id: '2', metric: 'Revenue', value: '$8,420', trend: 'up' },
        { id: '3', metric: 'Churn Rate', value: '1.2%', trend: 'down' },
      ];

      setData(mockData);
    } catch (error) {
      // Resilience: Graceful error handling
      console.error('Dashboard Error:', error);
      Alert.alert(
        "Connection Error", 
        "We couldn't load your analytics. Please try again."
      );
    } finally {
      // Resilience: Guaranteed cleanup
      // We use the `window` check to ensure this runs safely in both 
      // Web and Native environments, though `setIsLoading` is safe everywhere.
      setIsLoading(false);
    }
  };

  return (
    <StyledContainer 
      className="flex-1 bg-gray-50 dark:bg-gray-900 px-4 pt-10"
    >
      {/* Header Section */}
      <StyledHeader className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
        Analytics Overview
      </StyledHeader>

      {/* Controls Section */}
      <StyledButton
        onPress={fetchDashboardData}
        className="bg-blue-600 hover:bg-blue-700 active:opacity-80 
                   rounded-lg px-6 py-3 mb-6 items-center justify-center 
                   shadow-sm transition-all duration-200"
        disabled={isLoading || isPending}
      >
        <Text className="text-white font-semibold text-sm">
          {(isLoading || isPending) ? 'Loading Data...' : 'Refresh Data'}
        </Text>
      </StyledButton>

      {/* Loading State UI */}
      {(isLoading || isPending) && (
        <View className="flex-row items-center justify-center py-4 gap-2">
          <ActivityIndicator size="small" color="#2563EB" />
          <Text className="text-blue-600 dark:text-blue-400 font-medium">
            Updating metrics...
          </Text>
        </View>
      )}

      {/* Data Grid Section */}
      <StyledScroll className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="gap-4">
          {data.length > 0 ? (
            data.map((item) => (
              <StyledCard 
                key={item.id}
                className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
              >
                <View className="flex-row justify-between items-center mb-2">
                  <Text className="text-sm font-medium text-gray-500 dark:text-gray-400">
                    {item.metric}
                  </Text>
                  {/* Trend Indicator using conditional colors */}
                  <Text className={`text-xs font-bold px-2 py-1 rounded-full ${
                    item.trend === 'up' 
                      ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' 
                      : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
                  }`}>
                    {item.trend === 'up' ? '▲' : '▼'}
                  </Text>
                </View>
                <Text className="text-2xl font-bold text-gray-900 dark:text-white">
                  {item.value}
                </Text>
              </StyledCard>
            ))
          ) : (
            /* Empty State UI */
            !isLoading && (
              <View className="p-8 items-center justify-center border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-xl">
                <Text className="text-gray-500 dark:text-gray-400 text-center">
                  No data loaded. Tap "Refresh Data" to fetch metrics.
                </Text>
              </View>
            )
          )}
        </View>
      </StyledScroll>
    </StyledContainer>
  );
}

/**
 * --------------------------------------------------------------------------
 * MOCK API UTILITIES
 * --------------------------------------------------------------------------
 * Simulates network latency and potential failure for demonstration.
 */
async function simulateNetworkRequest(): Promise<{ ok: boolean }> {
  return new Promise((resolve) => {
    setTimeout(() => {
      // 90% success rate
      resolve({ ok: Math.random() > 0.1 });
    }, 1500);
  });
}
