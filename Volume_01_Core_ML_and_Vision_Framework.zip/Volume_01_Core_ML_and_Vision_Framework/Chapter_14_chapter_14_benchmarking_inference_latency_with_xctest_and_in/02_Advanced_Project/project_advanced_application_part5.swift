
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

/// @available(iOS 17.0, *)
/// A service responsible for benchmarking the inference latency of `ObjectDetectionModel`s.
actor ModelBenchmarkService {
    private let logHandle = OSLog(subsystem: "com.example.SmartCameraApp", category: "ModelBenchmarking")

    /// Measures the average inference latency of a given model over multiple iterations.
    /// - Parameters:
    ///   - model: The `ObjectDetectionModel` to benchmark.
    ///   - pixelBuffer: A sample `CVPixelBuffer` to use for inference.
    ///   - iterations: The number of times to run the inference for averaging.
    /// - Returns: The average inference latency in seconds.
    /// - Throws: `CoreMLError.predictionFailed` if any prediction fails.
    func measureLatency(model: ObjectDetectionModel, pixelBuffer: CVPixelBuffer, iterations: Int = 10) async throws -> TimeInterval {
        guard iterations > 0 else {
            os_log("Benchmarking requires at least one iteration.", log: logHandle, type: .error)
            throw CoreMLError.invalidInput(description: "Iterations must be greater than 0.")
        }

        var totalLatency: TimeInterval = 0.0
        os_signpost(.begin, log: logHandle, name: "Benchmark Model", "%{public}s", model.modelIdentifier)

        for i in 0..<iterations {
            os_signpost(.event, log: logHandle, name: "Iteration", "Model: %{public}s, Iteration: %d", model.modelIdentifier, i + 1)
            let startTime = Date()
            do {
                _ = try await model.predict(pixelBuffer: pixelBuffer)
                let endTime = Date()
                let latency = endTime.timeIntervalSince(startTime)
                totalLatency += latency
                os_log("Model: %{public}s, Iteration %d, Latency: %.4f s", log: logHandle, type: .debug, model.modelIdentifier, i + 1, latency)
            } catch {
                os_signpost(.end, log: logHandle, name: "Benchmark Model", "Failed")
                os_log("Prediction failed during benchmarking for model %{public}s: %{public}s", log: logHandle, type: .error, model.modelIdentifier, error.localizedDescription)
                throw CoreMLError.predictionFailed(description: "Benchmarking failed for \(model.modelIdentifier) at iteration \(i + 1): \(error.localizedDescription)")
            }
        }

        let averageLatency = totalLatency / Double(iterations)
        os_signpost(.end, log: logHandle, name: "Benchmark Model", "Completed, Avg Latency: %.4f s", averageLatency)
        os_log("Benchmarking complete for %{public}s. Average latency: %.4f seconds over %d iterations.", log: logHandle, type: .info, model.modelIdentifier, averageLatency, iterations)
        return averageLatency
    }
}
