
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

@available(iOS 18.0, *)
struct EmailMetadata {
    let sender: String
    let timestamp: Date
    let isImportant: Bool
    let subject: String
}

@available(iOS 18.0, *)
struct EmailMessage: Identifiable {
    let id: UUID
    let body: String
    let metadata: EmailMetadata
}

@available(iOS 18.0, *)
enum SearchFilter {
    case sender(String)
    case dateRange(Date, Date)
    case importance(Bool)
}

@available(iOS 18.0, *)
protocol LLMClient {
    func generateResponse(prompt: String) async throws -> String
    func planSearch(request: String) async throws -> (query: String, filters: [SearchFilter])
}

@available(iOS 18.0, *)
protocol HybridRetriever {
    func search(query: String, filters: [SearchFilter], semanticLimit: Int, keywordLimit: Int) async throws -> [EmailMessage]
}

@available(iOS 18.0, *)
actor SmartThreadAgent {
    private let hybridRetriever: HybridRetriever
    private let llmClient: LLMClient
    
    init(hybridRetriever: HybridRetriever, llmClient: LLMClient) {
        self.hybridRetriever = hybridRetriever
        self.llmClient = llmClient
    }
    
    func performDeepSummarization(for thread: [EmailMessage]) async throws -> String {
        var gatheredContext: [EmailMessage] = thread
        var iterations = 0
        let maxIterations = 3
        
        while iterations < maxIterations {
            // 1. Use LLM to plan search parameters based on current context
            let currentThreadSummary = thread.map { $0.subject }.joined(separator: ", ")
            let plan = try await llmClient.planSearch(request: "Summarize this thread: \(currentThreadSummary)")
            
            // 2. Execute Parallel Searches using TaskGroup
            // We use a TaskGroup to perform hybrid retrieval concurrently
            let newResults = try await withThrowingTaskGroup(of: [EmailMessage].self) { group in
                // In a real HybridRetriever, the search might internally use TaskGroups,
                // but here we demonstrate the pattern of parallelizing retrieval components.
                group.addTask {
                    try await self.hybridRetriever.search(
                        query: plan.query,
                        filters: plan.filters,
                        semanticLimit: 5,
                        keywordLimit: 5
                    )
                }
                
                var combined: [EmailMessage] = []
                for try await batch in group {
                    combined.append(contentsOf: batch)
                }
                return combined
            }
            
            // 3. Update context (Avoid duplicates)
            let newUniqueMessages = newResults.filter { newMsg in 
                !gatheredContext.contains(where: { $0.id == newMsg.id }) 
            }
            
            if newUniqueMessages.isEmpty { break }
            gatheredContext.append(contentsOf: newUniqueMessages)
            
            // 4. Evaluate Information Sufficiency (Agentic Loop)
            let evaluationPrompt = "Based on these emails: \(gatheredContext.map { $0.body }.joined(separator: "\n")), is there enough info to summarize the thread? Answer ONLY 'YES' or 'NO'."
            let evaluation = try await llmClient.generateResponse(prompt: evaluationPrompt)
            
            if evaluation.uppercased().contains("YES") {
                break
            }
            
            iterations += 1
        }
        
        // 5. Final Synthesis
        let finalPrompt = "Summarize the following email history: \(gatheredContext.map { $0.body }.joined(separator: "\n\n"))"
        return try await llmClient.generateResponse(prompt: finalPrompt)
    }
}

// MARK: - RRF Implementation Helper
extension SmartThreadAgent {
    /// Reciprocal Rank Fusion (RRF) implementation
    /// Merges two ranked lists into one based on their positions.
    func rrf(semanticList: [EmailMessage], keywordList: [EmailMessage], k: Float = 60.0) -> [EmailMessage] {
        var scores: [UUID: Float] = [:]
        var messageMap: [UUID: EmailMessage] = [:]
        
        for (rank, msg) in semanticList.enumerated() {
            let score = 1.0 / (k + Float(rank + 1))
            scores[msg.id, default: 0] += score
            messageMap[msg.id] = msg
        }
        
        for (rank, msg) in keywordList.enumerated() {
            let score = 1.0 / (k + Float(rank + 1))
            scores[msg.id, default: 0] += score
            messageMap[msg.id] = msg
        }
        
        return scores.sorted { $0.value > $1.value }
            .compactMap { messageMap[$0.key] }
    }
}
