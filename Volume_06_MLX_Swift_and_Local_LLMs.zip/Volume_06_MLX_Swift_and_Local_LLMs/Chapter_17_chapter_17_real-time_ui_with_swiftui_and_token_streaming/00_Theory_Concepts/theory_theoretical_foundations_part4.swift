
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import Observation

    @available(iOS 18.0, macOS 15.0, *)
    struct ChatView: View {
        @State private var prompt: String = "Tell me a story about a brave knight."
        @State private var generator: LLMGenerator // State for the actor instance

        // Observe the actor's publisher for UI updates
        @ObservedObject private var outputPublisher: LLMGenerator.OutputPublisher

        init() {
            // Initialize the actor and its publisher
            _generator = State(initialValue: try! LLMGenerator(modelPath: "path/to/model")) // Error handling omitted for brevity
            _outputPublisher = ObservedObject(wrappedValue: generator.publisher)
        }

        var body: some View {
            VStack {
                TextEditor(text: $outputPublisher.text)
                    .frame(minHeight: 200)
                    .border(Color.gray)
                    .padding()

                TextField("Enter prompt", text: $prompt)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                Button("Generate") {
                    Task {
                        await generator.generate(prompt: prompt)
                    }
                }
                .disabled(outputPublisher.isGenerating)
                .padding()
            }
            .navigationTitle("Local LLM Chat")
        }
    }
    