
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct Contact: Codable {
    let firstName: String
    let lastName: String?
    let email: String
    let phone: String
    let company: String?
}

@available(iOS 18.0, macOS 15.0, *)
func solveExercise1() {
    print("--- Exercise 1: Basic Contact Card Extraction ---")

    let decoder = JSONDecoder()

    // Simulate LLM Output 1: Complete Contact
    let jsonString1 = """
    {
      "firstName": "Jane",
      "lastName": "Smith",
      "email": "jane.smith@example.com",
      "phone": "+1-555-9876",
      "company": "Widgets Inc."
    }
    """

    // Simulate LLM Output 2: Contact with missing optional fields
    let jsonString2 = """
    {
      "firstName": "Alice",
      "email": "alice@example.com",
      "phone": "+1-555-4321"
    }
    """

    // Simulate LLM Output 3: Malformed JSON for error handling (phone is an Int, expected String)
    let jsonString3 = """
    {
      "firstName": "Bob",
      "email": "bob@example.com",
      "phone": 12345,
      "company": "Error Corp"
    }
    """

    // Decoding Logic and Error Handling for jsonString1
    print("\nAttempting to decode Contact 1 (complete):")
    if let jsonData = jsonString1.data(using: .utf8) {
        do {
            let contact = try decoder.decode(Contact.self, from: jsonData)
            print("Successfully decoded Contact 1:")
            print("  First Name: \(contact.firstName)")
            print("  Last Name: \(contact.lastName ?? "N/A")")
            print("  Email: \(contact.email)")
            print("  Phone: \(contact.phone)")
            print("  Company: \(contact.company ?? "N/A")")
        } catch {
            print("Error decoding Contact 1: \(error.localizedDescription)")
        }
    } else {
        print("Failed to convert JSON string 1 to Data.")
    }

    // Decoding Logic and Error Handling for jsonString2
    print("\nAttempting to decode Contact 2 (missing optionals):")
    if let jsonData = jsonString2.data(using: .utf8) {
        do {
            let contact = try decoder.decode(Contact.self, from: jsonData)
            print("Successfully decoded Contact 2:")
            print("  First Name: \(contact.firstName)")
            print("  Last Name: \(contact.lastName ?? "N/A")")
            print("  Email: \(contact.email)")
            print("  Phone: \(contact.phone)")
            print("  Company: \(contact.company ?? "N/A")")
        } catch {
            print("Error decoding Contact 2: \(error.localizedDescription)")
        }
    } else {
        print("Failed to convert JSON string 2 to Data.")
    }

    // Decoding Logic and Error Handling for jsonString3 (malformed)
    print("\nAttempting to decode Contact 3 (malformed phone type):")
    if let jsonData = jsonString3.data(using: .utf8) {
        do {
            let contact = try decoder.decode(Contact.self, from: jsonData)
            print("Successfully decoded Contact 3 (unexpected!):")
            print("  First Name: \(contact.firstName)")
        } catch let decodingError as DecodingError {
            print("Error decoding Contact 3 (expected): \(decodingError.localizedDescription)")
            switch decodingError {
            case .typeMismatch(let type, let context):
                print("  Type Mismatch: Expected \(type) but found different type at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            case .valueNotFound(let type, let context):
                print("  Value Not Found: Expected \(type) but value was missing at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            case .keyNotFound(let key, let context):
                print("  Key Not Found: Key '\(key.stringValue)' was missing at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            case .dataCorrupted(let context):
                print("  Data Corrupted: \(context.debugDescription) at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            @unknown default:
                print("  An unknown decoding error occurred.")
            }
        } catch {
            print("Generic error decoding Contact 3: \(error.localizedDescription)")
        }
    } else {
        print("Failed to convert JSON string 3 to Data.")
    }
}

// Uncomment to run Exercise 1
// solveExercise1()
