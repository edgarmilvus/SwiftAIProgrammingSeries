/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/NotificationPreferences.tsx
import React, { useState, useEffect, useCallback } from 'react';
import debounce from 'lodash.debounce';

const CATEGORIES = [
  { id: 'new_messages', label: 'New Messages' },
  { id: 'mentions', label: 'Mentions' },
  { id: 'promotions', label: 'Promotions' },
];

export const NotificationPreferences = ({ isNative }: { isNative: boolean }) => {
  // Initial state (would typically come from an API fetch)
  const [preferences, setPreferences] = useState<Record<string, boolean>>({
    new_messages: true,
    mentions: true,
    promotions: false,
  });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  // Optimistic Update Handler
  const handleToggle = (categoryId: string) => {
    // 1. Optimistic Update: Flip UI immediately
    setPreferences(prev => ({
      ...prev,
      [categoryId]: !prev[categoryId],
    }));

    // 2. Trigger Debounced Save
    savePreferencesDebounced({
      ...preferences,
      [categoryId]: !preferences[categoryId],
    });
  };

  // Debounced Server Sync
  const savePreferencesDebounced = useCallback(
    debounce(async (newPrefs) => {
      setSaving(true);
      setError(null);
      
      try {
        const response = await fetch('/api/user/preferences', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            preferences: newPrefs,
            isNative: isNative, // Pass platform info
          }),
        });

        if (!response.ok) throw new Error('Sync failed');

        // Success: No action needed, UI is already updated
      } catch (err) {
        setError('Failed to save preferences. Reverting changes.');
        // Revert logic: In a real app, you might refetch from server
        setPreferences(preferences); 
      } finally {
        setSaving(false);
      }
    }, 500), // 500ms debounce
    [preferences, isNative]
  );

  // Preview Logic
  const getPreviewMessage = (catId: string, enabled: boolean) => {
    if (catId === 'new_messages' && enabled) return "Preview: 'Hey, can we meet at 5?'";
    if (catId === 'mentions' && enabled) return "Preview: '@you mentioned you in #general'";
    return "Preview: (Notifications silenced)";
  };

  return (
    <div className="preferences-container">
      <h3>Notification Preferences</h3>
      {saving && <p className="status">Saving...</p>}
      {error && <p className="error">{error}</p>}
      
      {CATEGORIES.map(cat => (
        <div key={cat.id} className="preference-row">
          <label>
            <input
              type="checkbox"
              checked={preferences[cat.id] || false}
              onChange={() => handleToggle(cat.id)}
            />
            {cat.label}
          </label>
          <small className="preview">
            {getPreviewMessage(cat.id, preferences[cat.id] || false)}
          </small>
        </div>
      ))}
    </div>
  );
};

// SERVER-SIDE: API Route
// File: pages/api/user/preferences.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { Expo } from 'expo-server-sdk';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  if (!session?.user?.id) return res.status(401).end();

  const { preferences, isNative } = req.body;

  try {
    // 1. Save to Database (e.g., UserSettings table)
    // await prisma.userSettings.upsert(...)

    // 2. Update Expo Tags if Native
    if (isNative) {
      const expo = new Expo();
      // Fetch user's tokens
      // const tokens = await prisma.pushToken.findMany({ where: { userId: session.user.id } });
      
      // Construct tags based on preferences
      // If 'new_messages' is false, we want a tag that excludes it, or simply don't send.
      // Expo allows setting tags on tickets during send, but updating existing subscriptions 
      // usually requires re-registering with tags or using a backend logic to filter.
      
      // Logic: We store the preferences in DB. When sending, we check DB before sending.
      // However, to "Update Expo Push Ticket tags", we simulate updating the backend logic
      // that determines whether to send to this device.
      console.log(`Updating backend logic for user ${session.user.id} to respect tags:`, preferences);
    }

    res.status(200).json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
