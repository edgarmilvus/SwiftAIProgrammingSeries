
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import UIKit
import AVFoundation
import Vision
import CoreImage
import CoreImage.CIFilterBuiltins
import MetalKit // For efficient Core Image rendering

class PersonSegmentationViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate, MTKViewDelegate {

    private var captureSession: AVCaptureSession!
    private var videoOutput: AVCaptureVideoDataOutput!
    private var mtkView: MTKView!
    private var ciContext: CIContext!
    private var segmentationRequest: VNGeneratePersonSegmentationRequest!

    private var backgroundCIImage: CIImage! // Static background image
    private var currentCIImage: CIImage? // Current frame's CIImage

    private var videoOutputQueue = DispatchQueue(label: "videoOutputQueue", qos: .userInitiated)
    private var visionRequestQueue = DispatchQueue(label: "visionRequestQueue", qos: .userInitiated)

    override func viewDidLoad() {
        super.viewDidLoad()
        setupMetal()
        setupCoreImage()
        setupSegmentationRequest()
        setupCamera()
        loadBackgroundImage()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        mtkView.frame = view.bounds
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !captureSession.isRunning {
            videoOutputQueue.async {
                self.captureSession.startRunning()
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession.isRunning {
            captureSession.stopRunning()
        }
    }

    private func setupMetal() {
        guard let defaultDevice = MTLCreateSystemDefaultDevice() else {
            fatalError("Metal is not supported on this device")
        }
        mtkView = MTKView(frame: view.bounds, device: defaultDevice)
        mtkView.delegate = self
        mtkView.framebufferOnly = false // Allow texture reading
        mtkView.colorPixelFormat = .bgra8Unorm
        mtkView.contentScaleFactor = UIScreen.main.scale
        view.addSubview(mtkView)
    }

    private func setupCoreImage() {
        ciContext = CIContext(mtlDevice: mtkView.device!)
    }

    private func setupSegmentationRequest() {
        segmentationRequest = VNGeneratePersonSegmentationRequest()
        segmentationRequest.qualityLevel = .accurate // Or .fast for performance
        segmentationRequest.revision = VNGeneratePersonSegmentationRequest.currentRevision
    }

    private func loadBackgroundImage() {
        // Replace "background" with your image asset name
        guard let image = UIImage(named: "background"),
              let cgImage = image.cgImage else {
            fatalError("Background image not found or failed to load.")
        }
        backgroundCIImage = CIImage(cgImage: cgImage)
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .hd1920x1080 // Higher resolution for better segmentation

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
            print("Failed to get the camera device.")
            return
        }

        do {
            let videoInput = try AVCaptureDeviceInput(device: videoDevice)
            if captureSession.canAddInput(videoInput) {
                captureSession.addInput(videoInput)
            } else {
                print("Could not add video input to the session")
                return
            }
        } catch {
            print("Could not create video device input: \(error)")
            return
        }

        videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: videoOutputQueue)
        videoOutput.alwaysDiscardsLateVideoFrames = true
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        } else {
            print("Could not add video output to the session")
            return
        }

        if let connection = videoOutput.connection(with: .video), connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait
            connection.isPortraitUpsideDown = false
        }
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Create CIImage from the current frame
        let inputCIImage = CIImage(cvPixelBuffer: pixelBuffer)
        currentCIImage = inputCIImage

        // Perform segmentation request on a background queue
        visionRequestQueue.async {
            let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up)
            do {
                try imageRequestHandler.perform([self.segmentationRequest])
            } catch {
                print("Failed to perform segmentation request: \(error)")
            }
        }
    }

    // MARK: - MTKViewDelegate

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        // Handle resize if needed, not critical for this example
    }

    func draw(in view: MTKView) {
        guard let currentFrameCIImage = currentCIImage,
              let segmentationObservation = segmentationRequest.results?.first as? VNSegmentationObservation else {
            // If no segmentation or current frame, just draw the last frame or black
            if let drawable = view.currentDrawable {
                let commandBuffer = ciContext.commandQueue?.makeCommandBuffer()
                ciContext.render(currentCIImage ?? CIImage.black, to: drawable.texture, commandBuffer: commandBuffer, bounds: currentFrameCIImage.extent, colorSpace: ciContext.workingColorSpace!)
                commandBuffer?.present(drawable)
                commandBuffer?.commit()
            }
            return
        }

        // Get the segmentation mask
        let maskPixelBuffer = segmentationObservation.pixelBuffer
        var maskCIImage = CIImage(cvPixelBuffer: maskPixelBuffer)

        // Adjust mask to match input image orientation and extent
        let originalImageSize = currentFrameCIImage.extent.size
        let maskSize = maskCIImage.extent.size

        let scaleX = originalImageSize.width / maskSize.width
        let scaleY = originalImageSize.height / maskSize.height
        maskCIImage = maskCIImage.transformed(by: CGAffineTransform(scaleX: scaleX, y: scaleY))

        // Scale and position background image
        let backgroundScaleX = originalImageSize.width / backgroundCIImage.extent.width
        let backgroundScaleY = originalImageSize.height / backgroundCIImage.extent.height
        let scaledBackgroundImage = backgroundCIImage
            .transformed(by: CGAffineTransform(scaleX: backgroundScaleX, y: backgroundScaleY))
            .cropped(to: currentFrameCIImage.extent) // Ensure it matches input frame size

        // Use CIMaskToAlpha to create a transparent foreground based on the mask
        let foregroundWithAlpha = currentFrameCIImage.applyingFilter("CIMaskToAlpha", parameters: [
            kCIInputMaskImageKey: maskCIImage
        ])

        // Blend the foreground with the background
        let blendedImage = foregroundWithAlpha.applyingFilter("CISourceOverCompositing", parameters: [
            kCIInputBackgroundImageKey: scaledBackgroundImage
        ])

        // Render to MTKView
        if let drawable = view.currentDrawable {
            let commandBuffer = ciContext.commandQueue?.makeCommandBuffer()
            ciContext.render(blendedImage, to: drawable.texture, commandBuffer: commandBuffer, bounds: currentFrameCIImage.extent, colorSpace: ciContext.workingColorSpace!)
            commandBuffer?.present(drawable)
            commandBuffer?.commit()
        }
    }
}
