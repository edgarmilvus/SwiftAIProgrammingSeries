
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import NaturalLanguage // Essential for NLLanguageRecognizer and NLLanguage

/// A utility class designed to assist with localization tasks by identifying the language of text.
/// This is crucial for dynamic content adaptation, routing, and accessibility features like screen readers.
@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, *)
class LocalizationHelper {

    /// Initializes a new instance of the LocalizationHelper.
    init() {
        // NLLanguageRecognizer instances are lightweight and can be created per-use or reused.
        // For simple language identification, its state is reset with each new string.
    }

    /// Identifies the primary language of the given text string.
    ///
    /// This method uses `NLLanguageRecognizer` to analyze the text and determine the most
    /// probable language. It returns the detected language along with a confidence score.
    ///
    /// - Parameter text: The string whose language needs to be identified.
    /// - Returns: A tuple containing the detected `NLLanguage` and its `Double` confidence score.
    ///            Returns `.undetermined` with a confidence of 0.0 if no language can be reliably identified.
    /// - Throws: An error if the language recognition process fails (though rare for this API).
    func identifyPrimaryLanguage(for text: String) async throws -> (language: NLLanguage, confidence: Double) {
        // 1. Create an NLLanguageRecognizer instance.
        // This object performs the actual language detection.
        let recognizer = NLLanguageRecognizer()

        // 2. Process the text.
        // This tells the recognizer to analyze the provided string.
        recognizer.processString(text)

        // 3. Retrieve the top language hypothesis.
        // `dominantLanguage` provides the single most likely language.
        // For more detailed analysis, `languageHypotheses(withMaximum: Int)` can be used.
        guard let (language, confidence) = recognizer.dominantLanguage else {
            // If dominantLanguage is nil, it means no language could be determined.
            print("Warning: Could not determine dominant language for text: \"\(text)\"")
            return (.undetermined, 0.0)
        }

        return (language, confidence)
    }

    /// Identifies multiple possible languages for the given text string, ordered by confidence.
    ///
    /// This method can be useful when the text might contain mixed languages or when
    /// the primary language is not clear-cut, allowing for more nuanced handling.
    ///
    /// - Parameters:
    ///   - text: The string whose languages need to be identified.
    ///   - maxHypotheses: The maximum number of language hypotheses to return.
    /// - Returns: An array of tuples, each containing an `NLLanguage` and its `Double` confidence score.
    ///            Returns an empty array if no languages can be reliably identified.
    /// - Throws: An error if the language recognition process fails.
    func identifyLanguageHypotheses(for text: String, maxHypotheses: Int = 3) async throws -> [(language: NLLanguage, confidence: Double)] {
        let recognizer = NLLanguageRecognizer()
        recognizer.processString(text)

        // 4. Retrieve multiple language hypotheses.
        // This provides a dictionary where keys are NLLanguage and values are confidence scores.
        let hypotheses = recognizer.languageHypotheses(withMaximum: maxHypotheses)

        // Convert the dictionary to an array of tuples for easier consumption,
        // and sort by confidence in descending order.
        let sortedHypotheses = hypotheses
            .map { (language: $0.key, confidence: $0.value) }
            .sorted { $0.confidence > $1.confidence }

        return sortedHypotheses
    }
}

// MARK: - Example Usage

/// An asynchronous function to demonstrate the usage of LocalizationHelper.
@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, *)
func demonstrateLanguageRecognition() async {
    print("--- Demonstrating Language Recognition ---")

    let helper = LocalizationHelper()

    let textsToAnalyze = [
        "Hello, world!",                                          // English
        "Bonjour le monde!",                                      // French
        "Hola mundo!",                                            // Spanish
        "Hallo Welt!",                                            // German
        "こんにちは世界！",                                       // Japanese
        "This is a mixed text with some French: C'est la vie!",   // English with French
        "Swift is amazing. Apple makes great tools.",             // English
        "Ceci est un texte en français.",                         // French
        "Guten Tag, wie geht es Ihnen?",                          // German
        "This text is deliberately ambiguous or too short.",      // Ambiguous
        "A"                                                       // Too short
    ]

    for text in textsToAnalyze {
        do {
            // Demonstrate primary language identification
            let (primaryLang, primaryConfidence) = try await helper.identifyPrimaryLanguage(for: text)
            print("\nText: \"\(text)\"")
            print("  Primary Language: \(primaryLang.rawValue) (Confidence: \(String(format: "%.2f", primaryConfidence)))")

            // Demonstrate multiple hypotheses identification
            let hypotheses = try await helper.identifyLanguageHypotheses(for: text, maxHypotheses: 3)
            if !hypotheses.isEmpty {
                print("  Top Hypotheses:")
                for (lang, conf) in hypotheses {
                    print("    - \(lang.rawValue) (Confidence: \(String(format: "%.2f", conf)))")
                }
            } else {
                print("  No reliable hypotheses found.")
            }

        } catch {
            print("\nError identifying language for \"\(text)\": \(error.localizedDescription)")
        }
    }
    print("\n--- End of Demonstration ---")
}

// To run this example in a Swift Playground or an app's entry point (e.g., in an AppDelegate or a Task block):
// Ensure your target is set to iOS 18.0+ or macOS 15.0+ to use @available attributes.
//
// Task {
//     await demonstrateLanguageRecognition()
// }
