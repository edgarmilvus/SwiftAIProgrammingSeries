
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import SwiftData
import Observation

/// Represents a single piece of information remembered by the Aura AI.
/// The @Model macro transforms this class into a schema-backed entity.
@available(iOS 18.0, macOS 15.0, *)
@Model
final class MemorySnippet {
    /// The actual text content of the memory.
    var content: String
    
    /// The timestamp of when this memory was captured.
    var timestamp: Date
    
    /// A semantic category (e.g., "Preference", "Fact", "Reminder").
    /// Using an enum requires extra care in SwiftData (usually via RawRepresentable).
    var category: String
    
    /// The confidence score of the AI's extraction (0.0 to 1.0).
    var confidenceScore: Double

    /// Initializer required by the @Model macro to instantiate new objects.
    init(content: String, category: String, confidenceScore: Double) {
        self.content = content
        self.category = category
        self.confidenceScore = confidenceScore
        self.timestamp = Date.now
    }
}

/// A Controller responsible for managing the Aura AI's memory lifecycle.
/// We use @MainActor to ensure all UI-related data operations happen on the main thread.
@available(iOS 18.0, macOS 15.0, *)
@MainActor
final class MemoryManager {
    
    /// The ModelContainer acts as the bridge between your code and the actual SQLite database.
    private let container: ModelContainer
    
    /// The ModelContext is your "scratchpad." You perform inserts, deletes, and saves here.
    private let context: ModelContext

    /// Initializes the manager and sets up the persistent storage.
    /// - Throws: An error if the container cannot be initialized.
    init() throws {
        // Define the schema explicitly to ensure the container knows what to manage.
        let schema = Schema([MemorySnippet.self])
        
        // Configure storage options (e.g., cloud sync, file location).
        let config = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
        
        // Initialize the container.
        self.container = try ModelContainer(for: schema, configurations: [config])
        
        // The context is derived from the container.
        self.context = container.mainContext
    }

    /// Adds a new memory to the persistent store.
    /// - Parameters:
    ///   - content: The text captured by the AI.
    ///   - category: The classification of the memory.
    ///   - score: The AI's confidence level.
    func recordMemory(content: String, category: String, score: Double) {
        let newSnippet = MemorySnippet(content: content, category: category, confidenceScore: score)
        
        // Insert the object into the context.
        context.insert(newSnippet)
        
        // In SwiftData, autosave is often enabled by default, 
        // but explicit saving is safer for critical data.
        try? context.save()
        
        print("Successfully recorded memory: \(content)")
    }
    
    /// Fetches all recorded memories, sorted by most recent.
    /// - Returns: An array of MemorySnippet objects.
    func fetchAllMemories() -> [MemorySnippet] {
        let descriptor = FetchDescriptor<MemorySnippet>(
            sortBy: [SortDescriptor(\.timestamp, order: .reverse)]
        )
        
        do {
            return try context.fetch(descriptor)
        } catch {
            print("Failed to fetch memories: \(error)")
            return []
        }
    }
}
