
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CreateML
import Foundation

// MARK: - Exercise 4: User Churn Prediction for a Subscription Service

// Function to generate synthetic data for user churn prediction
func generateChurnPredictionData(numSamples: Int) -> [[String: MLDataValue]] {
    var data: [[String: MLDataValue]] = []
    let planTypes = ["Basic", "Standard", "Premium"]

    for _ in 0..<numSamples {
        let subscriptionDurationMonths = Int.random(in: 1...60) // 1 month to 5 years
        let dailyAverageWatchTimeHours = Double.random(in: 0.1...5.0)
        let uniqueShowsWatchedLastMonth = Int.random(in: 0...50)
        let lastLoginDaysAgo = Int.random(in: 1...90) // Last login 1 day to 3 months ago
        let supportTicketsOpenedLastYear = Int.random(in: 0...5)
        let paymentMethodFailureCount = Int.random(in: 0...3)
        let deviceCount = Int.random(in: 1...5)
        let planType = planTypes.randomElement()!

        var willChurn = false

        // Logic to simulate churn:
        // Users with short duration, low watch time, few shows, long login ago,
        // many support tickets, payment failures, or basic plan are more likely to churn.
        if subscriptionDurationMonths < 6 { willChurn = Bool.random(0.4) } // 40% chance if new
        if dailyAverageWatchTimeHours < 1.0 { willChurn = Bool.random(0.6) } // 60% chance if low watch time
        if uniqueShowsWatchedLastMonth < 5 { willChurn = Bool.random(0.5) } // 50% chance if few shows
        if lastLoginDaysAgo > 30 { willChurn = Bool.random(0.7) } // 70% chance if hasn't logged in for a month
        if supportTicketsOpenedLastYear > 1 { willChurn = Bool.random(0.5) } // 50% chance if support issues
        if paymentMethodFailureCount > 0 { willChurn = Bool.random(0.8) } // 80% chance if payment issues
        if planType == "Basic" && subscriptionDurationMonths < 12 { willChurn = Bool.random(0.3) } // Basic plan + new
        
        // Premium users are less likely to churn
        if planType == "Premium" && subscriptionDurationMonths > 12 && dailyAverageWatchTimeHours > 2.0 {
            willChurn = Bool.random(0.1) // 10% chance
        } else if planType == "Premium" {
            willChurn = Bool.random(0.2) // Overall lower churn for premium
        }

        // Add some random noise to churn decision to prevent perfect linearity
        if Bool.random() { willChurn.toggle() } // Randomly flip churn for 50% of cases

        data.append([
            "subscriptionDurationMonths": .int(subscriptionDurationMonths),
            "dailyAverageWatchTimeHours": .double(dailyAverageWatchTimeHours),
            "uniqueShowsWatchedLastMonth": .int(uniqueShowsWatchedLastMonth),
            "lastLoginDaysAgo": .int(lastLoginDaysAgo),
            "supportTicketsOpenedLastYear": .int(supportTicketsOpenedLastYear),
            "paymentMethodFailureCount": .int(paymentMethodFailureCount),
            "deviceCount": .int(deviceCount),
            "planType": .string(planType),
            "willChurn": .bool(willChurn)
        ])
    }
    return data
}

// Helper extension for Bool.random with probability
extension Bool {
    init(probability: Double) {
        self = Double.random(in: 0.0...1.0) < probability
    }
}

// Preprocessing function for one-hot encoding a categorical column
// This function needs to be available in the context where it's used.
// For Create ML, MLDataTable operations are generally synchronous.
@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, *)
func preprocessPlanType(dataTable: MLDataTable) throws -> MLDataTable {
    var processedTable = dataTable
    
    // Example: One-hot encode 'planType'
    // Create new columns for each plan type
    let uniquePlanTypes = try processedTable["planType"].uniqueKeys().map { $0.stringValue! }
    for planType in uniquePlanTypes {
        processedTable.addColumn(
            MLDataColumn(try processedTable["planType"].map { $0.stringValue == planType ? 1 : 0 }),
            toColumn: "planType_\(planType)" // Renamed column for clarity
        )
    }
    // Remove the original 'planType' column
    processedTable.removeColumn(named: "planType")
    
    return processedTable
}

// Main function to run Exercise 4
func runExercise4() {
    print("--- Exercise 4: User Churn Prediction for a Subscription Service ---")

    // 1. Data Loading & Preprocessing:
    let numSamples = 1500
    var rawData = generateChurnPredictionData(numSamples: numSamples)
    
    // Introduce some class imbalance for demonstration
    // Filter out some 'false' churners to make 'true' churners relatively fewer
    let initialChurnCount = rawData.filter { $0["willChurn"]?.boolValue == true }.count
    let initialRetentionCount = rawData.filter { $0["willChurn"]?.boolValue == false }.count
    print("Initial data: Churners=\(initialChurnCount), Retention=\(initialRetentionCount)")

    // Example of simple undersampling for imbalance (optional, for demonstration)
    // For a real scenario, use Create ML's oversampling/undersampling features if available
    // or implement more sophisticated techniques.
    var balancedData: [[String: MLDataValue]] = []
    let churners = rawData.filter { $0["willChurn"]?.boolValue == true }
    let nonChurners = rawData.filter { $0["willChurn"]?.boolValue == false }
    
    // Keep all churners, and an equal number of non-churners
    let targetNonChurnersCount = churners.count
    balancedData.append(contentsOf: churners)
    balancedData.append(contentsOf: nonChurners.shuffled().prefix(targetNonChurnersCount))
    
    print("After (simple) balancing: Churners=\(churners.count), Retention=\(targetNonChurnersCount)")
    
    guard var dataTable = try? MLDataTable(array: balancedData) else {
        print("Error: Could not create MLDataTable from raw data.")
        return
    }
    print("Generated \(dataTable.rows.count) samples.")
    
    // Preprocess 'planType' using one-hot encoding
    do {
        if #available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, *) {
            dataTable = try preprocessPlanType(dataTable: dataTable)
            print("Successfully preprocessed 'planType' feature.")
        } else {
            print("Warning: Skipping 'planType' preprocessing. Requires iOS 18+/macOS 15+ for MLDataTable operations used.")
            // Fallback for older OS versions: remove planType or handle differently
            dataTable.removeColumn(named: "planType")
        }
    } catch {
        print("Error during planType preprocessing: \(error.localizedDescription)")
        return
    }

    // 2. Feature and Label Definition
    var featureColumns = [
        "subscriptionDurationMonths", "dailyAverageWatchTimeHours", "uniqueShowsWatchedLastMonth",
        "lastLoginDaysAgo", "supportTicketsOpenedLastYear", "paymentMethodFailureCount", "deviceCount"
    ]
    if #available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, *) {
        // Add one-hot encoded columns
        let planTypes = ["Basic", "Standard", "Premium"] // Assuming these are the unique plan types
        featureColumns.append(contentsOf: planTypes.map { "planType_\($0)" })
    }
    
    let targetColumn = "willChurn" // This will be inferred as Bool or String("true"/"false")

    // Split data into training and testing sets
    let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 3)
    print("Training data size: \(trainingData.rows.count)")
    print("Testing data size: \(testingData.rows.count)")

    // 3. Model Training
    do {
        let classifier = try MLDecisionTreeClassifier(trainingData: trainingData,
                                                      targetColumn: targetColumn,
                                                      featureColumns: featureColumns)
        print("Model training complete.")

        // 4. Advanced Evaluation
        let evaluationMetrics = classifier.evaluation(on: testingData, targetColumn: targetColumn)
        
        print("\nModel Evaluation:")
        print("  Overall Accuracy: \(String(format: "%.2f", evaluationMetrics.accuracy * 100))%")

        if let classMetrics = evaluationMetrics.classificationMetricsByClass {
            for (className, metrics) in classMetrics {
                print("  Class '\(className)':")
                print("    Precision: \(String(format: "%.2f", metrics.precision * 100))%")
                print("    Recall: \(String(format: "%.2f", metrics.recall * 100))%")
                print("    F1-Score: \(String(format: "%.2f", metrics.fMeasure * 100))%")
            }
        }
        
        // ROC AUC is not directly available from MLClassifierMetrics in CreateML 1.0 (Xcode 11-14).
        // It might be available in newer versions or require manual calculation.
        // For demonstration, we'll note its importance.
        print("  Note: ROC AUC would be a critical metric for imbalanced datasets, but is not directly exposed in MLClassifierMetrics.")
        print("  It measures the trade-off between true positive rate and false positive rate.")

        // 5. Feature Importance
        print("\nFeature Importance (Top 5):")
        if let featureImportance = classifier.featureImportance {
            let sortedFeatures = featureImportance.sorted { $0.value > $1.value }
            for (feature, importance) in sortedFeatures.prefix(5) {
                print("  \(feature): \(String(format: "%.4f", importance))")
            }
        } else {
            print("  Feature importance not available for this model configuration.")
        }

        // 6. Prediction Example
        print("\nDemonstrating a prediction:")
        // Example: A new user with high risk factors
        let newUserData: [String: MLDataValue] = [
            "subscriptionDurationMonths": .int(3),
            "dailyAverageWatchTimeHours": .double(0.5),
            "uniqueShowsWatchedLastMonth": .int(1),
            "lastLoginDaysAgo": .int(60),
            "supportTicketsOpenedLastYear": .int(3),
            "paymentMethodFailureCount": .int(1),
            "deviceCount": .int(1),
            // One-hot encoded plan type for prediction
            "planType_Basic": .int(1),
            "planType_Standard": .int(0),
            "planType_Premium": .int(0)
        ]
        
        guard let predictionInput = try? MLDataTable(array: [newUserData]) else {
            print("Error: Could not create prediction input MLDataTable.")
            return
        }

        let predictions = try classifier.predictions(from: predictionInput)
        if let predictedChurn = predictions[targetColumn]?.first?.boolValue {
            print("  Input Features: New user, low watch time, inactive, support issues, payment failure, Basic plan.")
            print("  Predicted Churn: \(predictedChurn ? "TRUE (High Risk)" : "FALSE (Low Risk)")")
        } else {
            print("  Could not retrieve prediction.")
        }

    } catch {
        print("Error during model training or evaluation: \(error.localizedDescription)")
    }
    print("--------------------------------------------------\n")
}

// Call the function to run the exercise
runExercise4()
