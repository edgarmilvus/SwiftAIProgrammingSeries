
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import ARKit
import RealityKit
import SwiftUI

// 1. Data Model for Persistence
struct SavedFurnitureItem: Codable, Sendable {
    let anchorIdentifier: UUID
    let modelName: String
}

@MainActor
class PersistenceManager: ObservableObject {
    private let storageKey = "SavedLayout"
    private let session = ARKitSession()
    private let worldTracking = WorldTrackingProvider()
    
    @Published var placedItems: [UUID: String] = [:] // Map Anchor ID to Model Name
    @Published var isRelocalizing = true

    // 2. Save the layout to UserDefaults
    func saveLayout(items: [SavedFurnitureItem]) {
        if let encoded = try? JSONEncoder().encode(items) {
            UserDefaults.standard.set(encoded, forKey: storageKey)
        }
    }

    // 3. Load the layout
    func loadLayout() -> [SavedFurnitureItem] {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([SavedFurnitureItem].self, from: data) else {
            return []
        }
        return decoded
    }

    // 4. The Restoration Loop
    func startRestoration(in content: RealityViewContent) async {
        let savedItems = loadLayout()
        
        do {
            try await session.run([worldTracking])
            
            // Monitor anchors discovered by ARKit
            for await anchor in worldTracking.anchors {
                // Check if this discovered anchor matches one of our saved IDs
                if let match = savedItems.first(where: { $0.anchorIdentifier == anchor.id }) {
                    await restoreEntity(for: match, at: anchor, in: content)
                }
            }
        } catch {
            print("Restoration failed: \(error)")
        }
    }

    private func restoreEntity(for item: SavedFurnitureItem, at anchor: AnchorEntity, in content: RealityViewContent) async {
        // In a real app, load the actual 3D model from a USDZ file
        let model = ModelEntity(mesh: .generateBox(size: 0.3), materials: [SimpleMaterial(color: .orange, isMetallic: false)])
        
        let entityAnchor = AnchorEntity(anchor)
        entityAnchor.addChild(model)
        content.add(entityAnchor)
        
        print("Successfully re-materialized \(item.modelName)")
        isRelocalizing = false
    }
}
