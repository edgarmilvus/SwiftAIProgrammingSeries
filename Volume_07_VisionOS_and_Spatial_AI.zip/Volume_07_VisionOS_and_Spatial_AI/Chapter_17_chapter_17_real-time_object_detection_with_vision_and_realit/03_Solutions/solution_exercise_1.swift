
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import AVFoundation
import Vision

/// An actor to handle heavy Vision inference off the main thread.
actor VisionProcessor {
    private var isProcessing = false
    
    /// Processes a pixel buffer and returns detected bounding boxes.
    func process(pixelBuffer: CVPixelBuffer, completion: @escaping @Sendable ([VNRecognizedObjectObservation]) -> Void) {
        guard !isProcessing else { return }
        isProcessing = true
        
        let request = VNDetectRectanglesRequest { request, error in
            guard let results = request.results as? [VNRecognizedObjectObservation] else {
                completion([])
                return
            }
            completion(results)
        }
        
        // In a real app, use a VNCoreMLRequest here for specific labels
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        
        Task {
            do {
                try handler.perform([request])
            } catch {
                print("Vision error: \(error)")
            }
            self.isProcessing = false
        }
    }
}

struct VisionDetectionView: View {
    @State private var detections: [CGRect] = []
    let visionProcessor = VisionProcessor()
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                CameraPreviewView() // Standard AVCaptureVideoPreviewLayer wrapper
                
                Canvas { context, size in
                    for rect in detections {
                        let path = Path(rect)
                        context.stroke(path, with: .color(.green), lineWidth: 3)
                    }
                }
            }
            .onAppear { /* Start Camera Session */ }
        }
    }
    
    /// Converts Vision's normalized (bottom-left) coordinates to SwiftUI (top-left) view coordinates.
    func transform(observation: VNRecognizedObjectObservation, in viewSize: CGSize) -> CGRect {
        let rect = observation.boundingBox
        // Flip Y coordinate because Vision is bottom-up and SwiftUI is top-down
        let flippedY = 1.0 - rect.origin.y - rect.size.height
        
        return CGRect(
            x: rect.origin.x * viewSize.width,
            y: flippedY * viewSize.height,
            width: rect.size.width * viewSize.width,
            height: rect.size.height * viewSize.height
        )
    }
}

// Delegate implementation to bridge AVCapture to VisionProcessor
extension VisionDetectionView: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        
        Task {
            await visionProcessor.process(pixelBuffer: pixelBuffer) { observations in
                Task { @MainActor in
                    // Update UI on the main thread
                    self.detections = observations.map { self.transform(observation: $0, in: UIScreen.main.bounds.size) }
                }
            }
        }
    }
}
