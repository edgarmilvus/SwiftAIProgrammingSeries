
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CreateML
import AVFoundation // To create dummy audio files

// MARK: - Helper to create dummy WAV audio files
func createDummyWAV(at url: URL, duration: TimeInterval = 1.0, sampleRate: Double = 44100, frequency: Double = 440.0) throws {
    let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 1)!
    let audioFile = try AVAudioFile(forWriting: url, settings: format.settings)
    
    let frameCount = AVAudioFrameCount(sampleRate * duration)
    let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frameCount)!
    buffer.frameLength = frameCount
    
    for i in 0..<frameCount {
        let sample = sin(2 * .pi * frequency * (Double(i) / sampleRate)) * 0.5 // Sine wave
        buffer.floatChannelData![0][Int(i)] = Float(sample)
    }
    
    try audioFile.write(from: buffer)
}

// MARK: - Main Training Logic
func runExercise3() async {
    print("\n--- Exercise 3: Wildlife Sound Detection ---")
    
    let fileManager = FileManager.default
    let tempDirectory = fileManager.temporaryDirectory
    let wildlifeSoundsDir = tempDirectory.appendingPathComponent("WildlifeSounds_\(UUID().uuidString)")
    
    do {
        // 1. Data Preparation: Create directory structure and dummy audio files
        let speciesSounds: [String: Double] = ["OwlHoot": 200.0, "FrogCroak": 600.0, "BackgroundNoise": 1000.0] // Different frequencies for distinction
        
        for (species, freq) in speciesSounds {
            let speciesDir = wildlifeSoundsDir.appendingPathComponent(species)
            try fileManager.createDirectory(at: speciesDir, withIntermediateDirectories: true, attributes: nil)
            
            for i in 1...20 { // Create 20 dummy audio files per species
                let audioName = "\(species.lowercased())_\(String(format: "%02d", i)).wav"
                let audioUrl = speciesDir.appendingPathComponent(audioName)
                try createDummyWAV(at: audioUrl, frequency: freq + Double.random(in: -50...50)) // Add slight variation
            }
        }
        print("Simulated wildlife sound data created at: \(wildlifeSoundsDir.path)")
        
        // 2. MLSoundClassifier Training: Load data
        let dataSource = MLSoundClassifier.DataSource.labeledDirectories(at: wildlifeSoundsDir)
        
        // Split data into training and testing sets
        let (trainingData, testingData) = try dataSource.randomSplit(by: 0.8, seed: 42)
        
        print("Training data audio files: \(trainingData.count)")
        print("Testing data audio files: \(testingData.count)")
        
        // 3. Advanced Training with Model Parameters
        // Experiment with different feature extractors and validation data
        let modelParameters = MLSoundClassifier.ModelParameters(
            featureExtractor: .melspectrogram(
                MLSoundClassifier.ModelParameters.MelSpectrogramParameters(
                    frameLength: 0.04, // 40ms frame length
                    hopLength: 0.02    // 20ms hop length
                )
            ),
            validationData: testingData // Use testing data as explicit validation data
        )
        
        let soundClassifier = try await MLSoundClassifier(trainingData: trainingData, parameters: modelParameters)
        
        print("MLSoundClassifier trained successfully with custom parameters.")
        
        // 4. Model Evaluation
        let evaluation = soundClassifier.evaluation(on: testingData)
        let accuracy = (1.0 - evaluation.classificationError) * 100
        print("Model evaluation accuracy on test data: \(String(format: "%.2f", accuracy))%")
        
        // 5. Model Saving
        let modelURL = tempDirectory.appendingPathComponent("WildlifeSoundClassifier.mlmodel")
        try soundClassifier.write(to: modelURL)
        print("Model saved to: \(modelURL.path)")
        
        // Optional: Clean up
        try fileManager.removeItem(at: wildlifeSoundsDir)
        print("Cleaned up: removed simulated audio directory.")
        // try fileManager.default.removeItem(at: modelURL)
        // print("Cleaned up: removed saved model.")
        
    } catch {
        print("Error during Exercise 3: \(error.localizedDescription)")
    }
}

// Run the exercise
// Task { await runExercise3() } // Uncomment to run directly if not part of a larger app
