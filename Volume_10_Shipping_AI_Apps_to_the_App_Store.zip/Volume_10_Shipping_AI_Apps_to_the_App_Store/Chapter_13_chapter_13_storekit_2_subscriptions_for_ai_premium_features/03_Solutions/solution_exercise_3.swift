
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import StoreKit

@available(iOS 18.0, *)
class SubscriptionObserver {
    private let entitlementManager: EntitlementManager
    private var updateTask: Task<Void, Never>?
    
    init(entitlementManager: EntitlementManager) {
        self.entitlementManager = entitlementManager
    }
    
    /// Starts the long-running listener for transaction updates.
    func startListening() {
        // Ensure we don't start multiple tasks
        guard updateTask == nil else { return }
        
        updateTask = Task(priority: .background) {
            // Transaction.updates is an AsyncSequence that stays open
            for await result in Transaction.updates {
                await handleUpdate(result)
            }
        }
    }
    
    private func handleUpdate(_ result: VerificationResult<Transaction>) async {
        switch result {
        case .verified(let transaction):
            print("Transaction verified: \(transaction.id)")
            // Immediately sync the manager's state
            await entitlementManager.refreshEntitlements()
            // Always finish the transaction to prevent duplicate processing
            await transaction.finish()
            
        case .unverified(let transaction, let error):
            // Security logging: This could indicate a compromised device or spoofing attempt
            print("SECURITY WARNING: Unverified transaction \(transaction.id). Error: \(error)")
        }
    }
    
    func stopListening() {
        updateTask?.cancel()
        updateTask = nil
    }
    
    deinit {
        updateTask?.cancel()
    }
}
