/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Text, Platform } from 'react-native';
import { Accelerometer } from 'expo-sensors';

export default function TiltColorMixer() {
  // State for accelerometer data
  const [data, setData] = useState({ x: 0, y: 0, z: 0 });
  // State for subscription
  const [subscription, setSubscription] = useState<any>(null);

  useEffect(() => {
    // Check if Accelerometer is available (not available on web)
    if (Platform.OS === 'web') {
      // Mock data generator for web
      const interval = setInterval(() => {
        setData({
          x: Math.random() * 2 - 1, // Simulate range -1 to 1
          y: Math.random() * 2 - 1,
          z: Math.random() * 2 - 1,
        });
      }, 100);
      return () => clearInterval(interval);
    } else {
      // Native device logic
      const subscribe = async () => {
        // Set update interval (optional, defaults to 16ms)
        await Accelerometer.setUpdateInterval(100);
        
        const sub = Accelerometer.addListener(accelerometerData => {
          setData(accelerometerData);
        });
        setSubscription(sub);
      };
      subscribe();

      // Cleanup function
      return () => {
        if (subscription) {
          subscription.remove();
        }
      };
    }
  }, []);

  // Map x and y to Red and Green channels (0-255)
  // Accelerometer values typically range from -1 to 1. We normalize to 0-1 then multiply by 255.
  const normalize = (val: number) => Math.min(Math.max(val, -1), 1); // Clamp values
  const r = Math.floor((normalize(data.x) + 1) / 2 * 255);
  const g = Math.floor((normalize(data.y) + 1) / 2 * 255);
  const b = 0; // Ignored per requirements

  return (
    <View style={[styles.container, { backgroundColor: `rgb(${r}, ${g}, ${b})` }]}>
      <Text style={styles.text}>Tilt the device to change the color!</Text>
      <Text style={styles.dataText}>
        X: {data.x.toFixed(2)} Y: {data.y.toFixed(2)} Z: {data.z.toFixed(2)}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
    marginBottom: 10,
  },
  dataText: {
    color: 'white',
    fontSize: 14,
    fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace',
  },
});
