
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CoreML

// 1. Define the UserPreferences struct here.
struct UserPreferences {
    let actionRating: Float
    let comedyRating: Float
    let dramaRating: Float
    let sciFiRating: Float
    let horrorRating: Float

    init(action: Float, comedy: Float, drama: Float, sciFi: Float, horror: Float) {
        self.actionRating = action
        self.comedyRating = comedy
        self.dramaRating = drama
        self.sciFiRating = sciFi
        self.horrorRating = horror
    }
}

// 2. Implement the function signature.
func encodeUserPreferences(users: [UserPreferences]) throws -> MLMultiArray {
    let numberOfUsers = users.count
    let numberOfGenres = 5 // Fixed as per scenario

    guard numberOfUsers > 0 else {
        throw NSError(domain: "UserPreferencesError", code: 101, userInfo: [NSLocalizedDescriptionKey: "Input 'users' array cannot be empty."])
    }

    // Initialize an MLMultiArray with the shape [num_users, 5] and .float32 data type.
    let shape: [NSNumber] = [NSNumber(value: numberOfUsers), NSNumber(value: numberOfGenres)]
    let preferenceMatrix = try MLMultiArray(shape: shape, dataType: .float32)

    // Loop through the 'users' array and for each user, assign their 5 genre ratings
    // to the corresponding row in the MLMultiArray.
    for userIndex in 0..<numberOfUsers {
        let user = users[userIndex]
        preferenceMatrix[[userIndex, 0]] = NSNumber(value: user.actionRating)
        preferenceMatrix[[userIndex, 1]] = NSNumber(value: user.comedyRating)
        preferenceMatrix[[userIndex, 2]] = NSNumber(value: user.dramaRating)
        preferenceMatrix[[userIndex, 3]] = NSNumber(value: user.sciFiRating)
        preferenceMatrix[[userIndex, 4]] = NSNumber(value: user.horrorRating)
    }

    return preferenceMatrix
}

// Example usage (for testing your implementation):
/*
let user1 = UserPreferences(action: 4.5, comedy: 2.0, drama: 5.0, sciFi: 3.5, horror: 1.0)
let user2 = UserPreferences(action: 3.0, comedy: 4.0, drama: 2.5, sciFi: 4.0, horror: 3.0)
let user3 = UserPreferences(action: 5.0, comedy: 1.0, drama: 4.5, sciFi: 5.0, horror: 0.5)

let allUsers = [user1, user2, user3]

do {
    let preferenceMatrix = try encodeUserPreferences(users: allUsers)
    print("User Preference Matrix Shape: \(preferenceMatrix.shape)")
    print("User Preference Matrix DataType: \(preferenceMatrix.dataType)")

    // 3. Access and print a specific rating.
    //    For example, the 2nd user's (index 1) rating for 'Drama' (assuming Drama is the 3rd genre, index 2).
    let dramaRatingForUser2 = preferenceMatrix[[1, 2]].floatValue // Assuming Drama is at index 2
    print("User 2's Drama rating: \(dramaRatingForUser2)")

    // You can also print the whole matrix for verification (carefully for large matrices)
    // for userIndex in 0..<preferenceMatrix.shape[0].intValue {
    //     print("User \(userIndex): ", terminator: "")
    //     for genreIndex in 0..<preferenceMatrix.shape[1].intValue {
    //         print(String(format: "%.1f ", preferenceMatrix[[userIndex, genreIndex]].floatValue), terminator: "")
    //     }
    //     print("")
    // }

} catch {
    print("Error encoding user preferences: \(error)")
}
*/
