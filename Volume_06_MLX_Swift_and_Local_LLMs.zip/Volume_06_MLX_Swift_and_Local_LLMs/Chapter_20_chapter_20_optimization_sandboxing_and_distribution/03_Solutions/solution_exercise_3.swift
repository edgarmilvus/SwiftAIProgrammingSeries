
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import MLX
import MLXNN
import Foundation // For URL, NSTemporaryDirectory

@available(macOS 14.0, iOS 18.0, *)
final class LoRALinear: MLXNN.Module {
    let baseLinear: MLXNN.Linear
    let loraA: MLXNN.Linear
    let loraB: MLXNN.Linear
    let scale: Float // Scaling factor for LoRA output

    init(_ baseLinear: MLXNN.Linear, rank: Int, alpha: Float = 1.0) {
        self.baseLinear = baseLinear
        // Disable gradients for the base layer's parameters
        self.baseLinear.parameters().forEach { $0.value.requires_grad = false }

        let inputDim = baseLinear.inputDim
        let outputDim = baseLinear.outputDim

        self.loraA = MLXNN.Linear(inputDim, rank)
        self.loraB = MLXNN.Linear(rank, outputDim)
        
        // Initialize loraB to zeros as per LoRA paper
        self.loraB.parameters()["weight"]?.value = MLX.zeros([outputDim, rank], type: .float32)
        
        // LoRA scaling factor
        self.scale = alpha / Float(rank)
        
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Original output from the base linear layer
        let originalOutput = baseLinear(input)
        
        // LoRA delta: (input @ lora_A @ lora_B) * scale
        let loraDelta = MLX.matmul(MLX.matmul(input, loraA(input)), loraB(input)) * scale
        
        return originalOutput + loraDelta
    }
}

@available(macOS 14.0, iOS 18.0, *)
final class SimpleLLM: MLXNN.Module {
    var embedding: MLXNN.Embedding
    var norm1: MLXNN.LayerNorm
    var linear1: MLXNN.Linear // Will be replaced by LoRA
    var norm2: MLXNN.LayerNorm
    var linear2: MLXNN.Linear // Will be replaced by LoRA
    var outputProjection: MLXNN.Linear

    init(vocabSize: Int, hiddenDim: Int, outputDim: Int) {
        self.embedding = MLXNN.Embedding(vocabSize, hiddenDim)
        self.norm1 = MLXNN.LayerNorm(hiddenDim)
        self.linear1 = MLXNN.Linear(hiddenDim, hiddenDim * 4) // FFN expansion
        self.norm2 = MLXNN.LayerNorm(hiddenDim * 4)
        self.linear2 = MLXNN.Linear(hiddenDim * 4, hiddenDim) // FFN contraction
        self.outputProjection = MLXNN.Linear(hiddenDim, outputDim) // Final output layer
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Input: [batch, sequence_length] (token IDs)
        var x = embedding(input) // [batch, sequence_length, hidden_dim]
        
        // Simple Transformer-like block (simplified)
        x = norm1(x)
        x = MLX.relu(linear1(x)) // FFN 1
        x = norm2(x)
        x = MLX.relu(linear2(x)) // FFN 2
        
        let output = outputProjection(x) // [batch, sequence_length, output_dim] (logits for next token)
        return output
    }

    /// Applies LoRA to specific MLXNN.Linear layers within the model.
    func applyLoRA(rank: Int) {
        // Replace target linear layers with LoRALinear wrappers
        self.linear1 = LoRALinear(self.linear1, rank: rank)
        self.linear2 = LoRALinear(self.linear2, rank: rank)
        
        // Note: For a real LLM, you'd typically target attention projection layers (Q, K, V, O)
        // and potentially some FFN layers. This example targets two FFN layers.
    }
}

@available(macOS 14.0, iOS 18.0, *)
func runLoRAFineTuning() {
    let vocabSize = 1000
    let hiddenDim = 256
    let outputDim = vocabSize // For next token prediction
    let loraRank = 4
    let learningRate: Float = 1e-4
    let numSteps = 10
    let sequenceLength = 128
    let batchSize = 1

    print("Initializing SimpleLLM and applying LoRA...")
    let baseLLM = SimpleLLM(vocabSize: vocabSize, hiddenDim: hiddenDim, outputDim: outputDim)
    baseLLM.applyLoRA(rank: loraRank)

    // Verify that only LoRA parameters have requires_grad = true
    let trainableParameters = baseLLM.parameters().filter { $0.value.requires_grad }
    print("Number of trainable (LoRA) parameters: \(trainableParameters.count)")
    for (name, param) in trainableParameters {
        print("  - Trainable parameter: \(name), shape: \(param.shape)")
    }
    
    let optimizer = MLXNN.Optimizers.Adam(learningRate: learningRate)

    // Simulate training data: input token IDs and target next token IDs
    let inputTokens = MLXArray.random(low: 0, high: vocabSize - 1, [batchSize, sequenceLength], type: .int32)
    let targetTokens = MLXArray.random(low: 0, high: vocabSize - 1, [batchSize, sequenceLength], type: .int32)

    print("\nStarting LoRA fine-tuning loop...")
    for step in 0..<numSteps {
        // Compute loss and gradients.
        // MLX.valueAndGradient on a Module automatically computes gradients for all
        // parameters within the module that have `requires_grad = true`.
        let (loss, grads) = MLX.valueAndGradient(of: { model in
            let output = model(inputTokens) // [batch, seq_len, vocab_size]
            // Cross-entropy loss expects predictions [N, C] and targets [N]
            return MLXNN.losses.crossEntropy(
                predictions: output.reshaped([batchSize * sequenceLength, vocabSize]),
                targets: targetTokens.reshaped([batchSize * sequenceLength]),
                reduction: .mean
            )
        }, arg: baseLLM) // Pass the module itself as the arg

        // Update parameters using the optimizer
        optimizer.update(model: baseLLM, gradients: grads)
        
        // Force computation of loss and updated parameters
        MLX.eval(loss, baseLLM.parameters())

        print("Step \(step + 1)/\(numSteps), Loss: \(loss.item(Float.self)!)")
    }

    // Save LoRA weights
    let finalLoRAWeights = baseLLM.parameters().filter { $0.value.requires_grad }
    let filePath = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("lora_adapter_weights.safetensors")
    
    do {
        // MLX.save expects a dictionary of [String: MLXArray]
        var loraWeightsDict: [String: MLXArray] = [:]
        for (name, param) in finalLoRAWeights {
            loraWeightsDict[name] = param
        }
        try MLX.save(loraWeightsDict, filePath: filePath.path)
        print("\nLoRA weights saved to \(filePath.path)")
    } catch {
        print("Error saving LoRA weights: \(error.localizedDescription)")
    }
    
    // Discussion on sandboxing implications
    print("\n--- Sandboxing Implications ---")
    print("On macOS, the App Sandbox significantly restricts file system access.")
    print("1. Loading Base LLM:")
    print("   - If the base LLM is bundled with the app, it's accessible.")
    print("   - If the user provides a path to an external LLM (e.g., in Downloads),")
    print("     the app would need explicit user consent via `NSOpenPanel` to grant")
    print("     read access to that specific file or directory. Persistent access")
    print("     requires security-scoped bookmarks.")
    print("2. Saving LoRA Weights:")
    print("   - Saving to the app's sandboxed container (e.g., `Application Support`")
    print("     or `Caches` directories) is allowed without user prompt.")
    print("   - Saving to a user-selected location (e.g., `Documents` or `Desktop`)")
    print("     requires explicit user consent via `NSSavePanel` to grant write access.")
    print("   - The `NSTemporaryDirectory()` used here is within the sandbox and is always accessible.")
    print("These measures ensure user privacy and system integrity by limiting an app's")
    print("ability to read/write arbitrary files without user permission.")
}

// Call the example function
// runLoRAFineTuning()
