
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// MARK: - 1. Necessary Imports
import AppIntents // Core framework for defining intents
import Foundation // For basic data types like Date and String

// Ensure this code is only available on iOS 18.0 and later, where AppIntents for AI are fully supported.
@available(iOS 18.0, *)
enum JournalError: Error, CustomLocalizedStringResourceConvertible {
    case noJournalEntries
    case summarizationFailed
    case unknown

    var localizedStringResource: LocalizedStringResource {
        switch self {
        case .noJournalEntries:
            return "You haven't written any journal entries yet."
        case .summarizationFailed:
            return "Failed to summarize the journal entry."
        case .unknown:
            return "An unknown error occurred."
        }
    }
}

// MARK: - 2. Supporting Data Models and Storage
/// Represents a single journal entry.
struct JournalEntry: Identifiable, Codable {
    let id = UUID()
    let date: Date
    let content: String
}

/// A simplified in-memory store for journal entries.
/// In a real app, this would interact with Core Data, SwiftData, or a backend.
class JournalStore: ObservableObject {
    static let shared = JournalStore() // Singleton instance
    @Published private(set) var entries: [JournalEntry] = []

    private init() {
        // Populate with some dummy data for demonstration
        addEntry(content: "Today was a productive day. I finished the App Intents chapter, which was challenging but rewarding. I also went for a long walk in the park and enjoyed the autumn leaves. Planning to start the next chapter on on-device LLMs tomorrow.")
        addEntry(content: "Reflected on yesterday's work. Realized the importance of clear documentation for complex APIs. Had a great coffee and read a book. The weather was a bit gloomy, but it didn't dampen my spirits.")
        addEntry(content: "Started prototyping the new AI feature. Encountered some issues with model loading, but managed to debug them. Feeling optimistic about the progress. Also, remembered to water my plants!")
    }

    /// Adds a new journal entry.
    func addEntry(content: String) {
        let newEntry = JournalEntry(date: Date(), content: content)
        entries.append(newEntry)
        entries.sort { $0.date > $1.date } // Keep latest entry first
    }

    /// Retrieves the most recent journal entry.
    func getLatestEntry() -> JournalEntry? {
        entries.first
    }

    /// Simulates an AI summarization of a given text.
    /// In a real AI app, this would invoke an on-device LLM or Apple Intelligence framework.
    func summarize(text: String) -> String {
        // For this basic example, we'll just take the first few sentences or words.
        // A real implementation would use Apple Intelligence's TextGenerationService or similar.
        let sentences = text.split(separator: ".").map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }
        guard !sentences.isEmpty else { return text }

        let summarySentenceCount = min(2, sentences.count)
        let summary = sentences.prefix(summarySentenceCount).joined(separator: ". ")
        return summary + (sentences.count > summarySentenceCount ? "..." : "")
    }
}

// MARK: - 3. Defining the App Intent
/// An App Intent that allows Siri to summarize the user's latest journal entry.
@available(iOS 18.0, *)
struct SummarizeLatestJournalEntryIntent: AppIntent {
    // MARK: - Intent Metadata
    static var title: LocalizedStringResource = "Summarize Latest Journal Entry"
    static var description: IntentDescription = "Provides a summary of your most recently added journal entry."
    static var openAppWhenRun: Bool = false // Set to true if the intent should open the app's UI.
                                          // For a background action like summarization, false is typical.

    // MARK: - Intent Parameters (None for this basic example, but shown for completeness)
    // @Parameter(title: "Include Date", description: "Whether to include the entry's date in the summary.")
    // var includeDate: Bool = false

    // MARK: - The Core Logic: perform()
    /// Executes the intent's action.
    /// This is where you would integrate with your app's logic and AI models.
    func perform() async throws -> some IntentResult {
        guard let latestEntry = JournalStore.shared.getLatestEntry() else {
            // If no entries exist, throw a specific error.
            throw JournalError.noJournalEntries
        }

        // Simulate AI summarization.
        // In a real scenario, this would involve:
        // 1. Importing AppleIntelligence
        // 2. Initializing a TextGenerationService: `let textGenerationService = TextGenerationService()`
        // 3. Calling a summarization method: `let summary = try await textGenerationService.summarize(latestEntry.content)`
        let summary = JournalStore.shared.summarize(text: latestEntry.content)

        // Return a dialog result for Siri to speak.
        // You can also include other types of results like images, files, or custom views.
        return .result(
            dialog: "Here's a summary of your latest entry from \(latestEntry.date.formatted(date: .abbreviated, time: .shortened)): \(summary)",
            view: nil // Optional: A custom view to display in Shortcuts/Siri UI.
        )
    }
}

// MARK: - 4. Registering the Intent
/// The main container for all App Intents provided by your application.
/// This struct makes your intents discoverable by the system.
@available(iOS 18.0, *)
struct JournalAppIntents: AppIntents {
    static var intents: [any AppIntent.Type] {
        [SummarizeLatestJournalEntryIntent.self] // Register your intent here
    }

    // Optional: Provide a custom App Shortcuts provider if you want to define custom phrases
    // or provide dynamic shortcuts. For basic discovery, this isn't strictly necessary.
    // static var appShortcuts: [AppShortcut] {
    //     AppShortcut(
    //         intent: SummarizeLatestJournalEntryIntent(),
    //         phrases: ["summarize my latest journal entry", "what's my last journal entry about"]
    //     )
    // }
}

// MARK: - Example Usage (for testing within an app's lifecycle, e.g., SwiftUI App struct)
/*
 @main
 struct JournalApp: App {
     // Ensure the JournalStore is initialized early, e.g., in your App struct
     @StateObject private var journalStore = JournalStore.shared

     var body: some Scene {
         WindowGroup {
             ContentView() // Your main app UI
         }
     }
 }

 struct ContentView: View {
     @ObservedObject var journalStore = JournalStore.shared

     var body: some View {
         VStack {
             Text("Journal Entries:")
             ForEach(journalStore.entries) { entry in
                 Text(entry.date.formatted() + ": " + entry.content)
                     .font(.caption)
                     .padding(.bottom, 5)
             }
             Button("Add New Entry") {
                 journalStore.addEntry(content: "Another day, another thought. Thinking about the future of AI and its impact on development workflows.")
             }
             .padding()

             Button("Test Summarize Intent (Programmatic)") {
                 Task {
                     do {
                         let intent = SummarizeLatestJournalEntryIntent()
                         let result = try await intent.perform()
                         if let dialog = result.dialog {
                             print("Intent Result Dialog: \(dialog)")
                         }
                     } catch {
                         print("Intent Error: \(error.localizedDescription)")
                     }
                 }
             }
             .padding()
         }
     }
 }
 */
