
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import CoreML
import Vision
import PhotosUI
import AVFoundation

// MARK: - Models

/// Represents the result of an AI analysis.
/// Using a struct ensures value semantics, which is safer in concurrent environments.
struct AnalysisResult: Identifiable, Sendable {
    let id = UUID()
    let label: String
    let confidence: Float
}

/// Errors specific to the AI Analysis workflow.
/// Essential for complying with App Review guidelines regarding "Graceful Error Handling."
enum AnalysisError: LocalizedError {
    case modelLoadingFailed
    case permissionDenied
    case processingError(String)
    
    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed: return "Could not initialize the AI model."
        case .permissionDenied: return "Camera access was denied. Please enable it in Settings."
        case .processingError(let msg): return "Analysis failed: \(msg)"
        }
    }
}

// MARK: - AI Engine (The Core Logic)

/// An actor that manages the heavy lifting of AI inference.
/// Using an `actor` is a Swift 6 best practice to ensure that the CoreML model 
/// and the Vision requests are isolated from the Main Actor, preventing data races.
/// This addresses the 'Performance' pillar by offloading work from the UI thread.
@available(iOS 18.0, *)
actor ImageAnalysisEngine {
    
    /// The Vision request object.
    private var request: VNCoreMLRequest?
    
    /// The underlying CoreML model.
    private var model: VNCoreMLModel?

    /// Initializes the engine and loads the ML model.
    /// - Throws: `AnalysisError.modelLoadingFailed` if the model cannot be loaded.
    init() throws {
        // In a real app, you would use your compiled .mlmodel file.
        // For this example, we assume a model named 'MobileNetV2' is in the bundle.
        // We specify .all to allow the system to choose between CPU, GPU, and Neural Engine.
        guard let mlModel = try? VNCoreMLModel(for: MobileNetV2(configuration: MLModelConfiguration()).model) else {
            throw AnalysisError.modelLoadingFailed
        }
        self.model = mlModel
        
        // Prepare the request once during initialization to optimize performance.
        self.request = VNCoreMLRequest(model: mlModel) { [weak self] request, error in
            // Note: In a real implementation, you would handle the completion 
            // via a continuation or a callback.
        }
    }

    /// Performs object detection on a provided image.
    /// - Parameter image: The `CGImage` to analyze.
    /// - Returns: An array of `AnalysisResult` objects.
    /// - Throws: `AnalysisError.processingError` if inference fails.
    func analyze(image: CGImage) async throws -> [AnalysisResult] {
        guard let model = model, let request = request else {
            throw AnalysisError.modelLoadingFailed
        }

        // Perform the request using the Vision framework.
        // Vision handles the scaling and aspect ratio adjustments automatically.
        let handler = VNImageRequestHandler(cgImage: image, options: [:])
        
        return try await withCheckedThrowingContinuation { continuation in
            do {
                try handler.perform([request])
                
                // Extracting results from the Vision request.
                let observations = request.results as? [VNClassificationObservation] ?? []
                let results = observations.map { 
                    AnalysisResult(label: $0.identifier, confidence: $0.confidence) 
                }
                
                continuation.resume(returning: results)
            } catch {
                continuation.resume(throwing: AnalysisError.processingError(error.localizedDescription))
            }
        }
    }
}

// MARK: - ViewModel (The Coordinator)

/// The ViewModel manages the state of the UI.
/// It is marked with `@MainActor` to ensure all UI updates (like setting `results`)
/// happen on the main thread, satisfying Swift 6 strict concurrency requirements.
@available(iOS 18.0, *)
@MainActor
class ImageAnalyzerViewModel: ObservableObject {
    
    @Published var results: [AnalysisResult] = []
    @Published var isAnalyzing = false
    @Published var errorMessage: String?
    @Published var selectedItem: PhotosPickerItem? {
        didSet {
            Task { await processSelectedImage() }
        }
    }
    
    private var engine: ImageAnalysisEngine?

    init() {
        // Initialize the engine. We wrap this in a Task because the init is not async.
        Task {
            do {
                self.engine = try await ImageAnalysisEngine()
            } catch {
                self.errorMessage = error.localizedDescription
            }
        }
    }

    /// Orchestrates the flow: Permission Check -> Image Loading -> AI Analysis.
    private func processSelectedImage() async {
        guard let engine = engine else { return }
        
        // 1. Reset state
        self.results = []
        self.errorMessage = nil
        
        // 2. Load the image from PhotosPicker
        guard let data = try? await selectedItem?.loadTransferable(type: Data.self),
              let uiImage = UIImage(data: data),
              let cgImage = uiImage.cgImage else {
            self.errorMessage = "Failed to load image."
            return
        }

        // 3. Perform Analysis
        isAnalyzing = true
        defer { isAnalyzing = false } // Ensures loading state is cleared even if error occurs.

        do {
            // The actual heavy lifting happens inside the 'engine' (the Actor).
            // This call suspends the MainActor, allowing the UI to remain responsive.
            let analysis = try await engine.analyze(image: cgImage)
            self.results = analysis
        } catch {
            self.errorMessage = error.localizedDescription
        }
    }
}

// MARK: - View (The Interface)

@available(iOS 18.0, *)
struct ImageAnalyzerView: View {
    @StateObject private var viewModel = ImageAnalyzerViewModel()
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                // Image Selection Area
                PhotosPicker(selection: $viewModel.selectedItem, matching: .images) {
                    Label("Select a Photo", systemImage: "photo.on.rectangle")
                        .font(.headline)
                        .padding()
                        .background(Color.accentColor.opacity(0.1))
                        .cornerRadius(10)
                }
                
                if viewModel.isAnalyzing {
                    ProgressView("AI is thinking...")
                        .transition(.opacity)
                }
                
                // Results List
                List(viewModel.results) { result in
                    HStack {
                        Text(result.label.capitalized)
                        Spacer()
                        Text("\(Int(result.confidence * 100))%")
                            .foregroundStyle(.secondary)
                    }
                }
                .overlay {
                    if viewModel.results.isEmpty && !viewModel.isAnalyzing {
                        ContentUnavailableView("No Analysis", 
                            systemImage: "magnifyingglass", 
                            description: Text("Select an image to start the AI analysis."))
                    }
                }
            }
            .navigationTitle("AI Inspector")
            .alert("Error", isPresented: Binding(
                get: { viewModel.errorMessage != nil },
                set: { _ in viewModel.errorMessage = nil }
            )) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(viewModel.errorMessage ?? "Unknown error")
            }
        }
    }
}

// Note: MobileNetV2 is a placeholder for a real compiled CoreML class.
// In a real project, this class is auto-generated by Xcode from your .mlmodel file.
