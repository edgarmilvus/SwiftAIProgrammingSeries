
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor SpeechRecognizerManager {
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    enum SpeechRecognizerError: Error {
        case notAuthorized
        case audioEngineSetupFailed
        case alreadyRunning
    }

    func startRecognition() async throws -> AsyncStream<String> {
        guard !audioEngine.isRunning else { throw SpeechRecognizerError.alreadyRunning }
        guard let speechRecognizer, speechRecognizer.isAvailable else {
            throw SpeechRecognizerError.notAuthorized // Or a more specific error
        }

        // Request authorization if not already granted
        if speechRecognizer.authorizationStatus != .authorized {
            await SFSpeechRecognizer.requestAuthorization()
            guard speechRecognizer.authorizationStatus == .authorized else {
                throw SpeechRecognizerError.notAuthorized
            }
        }

        return AsyncStream { continuation in
            do {
                recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
                guard let recognitionRequest else { return }
                recognitionRequest.shouldReportPartialResults = true

                recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
                    if let result {
                        continuation.yield(result.bestTranscription.formattedString)
                    } else if let error {
                        continuation.finish(throwing: error)
                    }
                }

                let inputNode = audioEngine.inputNode
                let recordingFormat = inputNode.outputFormat(forBus: 0)
                inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
                    recognitionRequest.append(buffer)
                }

                audioEngine.prepare()
                try audioEngine.start()
            } catch {
                continuation.finish(throwing: error)
            }

            continuation.onTermination = { @Sendable _ in
                // Clean up resources when the stream is cancelled or finishes
                Task { await self.stopRecognition() }
            }
        }
    }

    func stopRecognition() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionRequest = nil
        recognitionTask?.cancel()
        recognitionTask = nil
    }
}
