
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation // Required for Codable, Data, JSONDecoder

// MARK: - 1. Define Swift Structures for LLM Output

/// Represents the type of command the LLM has identified.
/// This makes our parsing type-safe and prevents typos.
enum VoiceCommandType: String, Codable, CaseIterable, Identifiable {
    case setTimer = "setTimer"
    case playMusic = "playMusic"
    case unknown = "unknown" // Good practice for robustness

    var id: String { self.rawValue }
}

/// Represents a structured command parsed from the LLM's JSON output.
/// This struct conforms to `Decodable` to allow it to be initialized from JSON data.
struct VoiceCommand: Decodable {
    /// The type of command identified by the LLM.
    let commandType: VoiceCommandType
    
    /// A dictionary of parameters relevant to the command.
    /// Using `[String: AnyCodable]` allows for flexible parameter types.
    /// `AnyCodable` is a common pattern for handling heterogeneous JSON dictionaries.
    /// For simplicity in this basic example, we'll use `[String: CodableValue]`
    /// where `CodableValue` is a custom enum to represent different JSON types.
    let parameters: [String: CodableValue]?
    
    /// A confidence score from the LLM, indicating how certain it is about the command.
    let confidenceScore: Double

    /// Custom initializer to handle potential parsing issues for `commandType`
    /// and provide a default for `parameters` if not present.
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Attempt to decode commandType, defaulting to .unknown if it fails
        if let typeString = try? container.decode(String.self, forKey: .commandType) {
            self.commandType = VoiceCommandType(rawValue: typeString) ?? .unknown
        } else {
            self.commandType = .unknown
        }
        
        // Decode parameters, which might be optional
        self.parameters = try container.decodeIfPresent([String: CodableValue].self, forKey: .parameters)
        
        // Decode confidenceScore, providing a default if not present or invalid
        self.confidenceScore = (try? container.decode(Double.self, forKey: .confidenceScore)) ?? 0.0
    }
    
    // MARK: - Nested Types for Flexible Parameters

    /// A custom `Codable` enum to represent different JSON value types.
    /// This is useful when `parameters` can contain mixed types (String, Int, Bool, etc.).
    enum CodableValue: Codable, Hashable {
        case string(String)
        case int(Int)
        case double(Double)
        case bool(Bool)
        case null
        
        init(from decoder: Decoder) throws {
            let container = try decoder.singleValueContainer()
            if let string = try? container.decode(String.self) {
                self = .string(string)
            } else if let int = try? container.decode(Int.self) {
                self = .int(int)
            } else if let double = try? container.decode(Double.self) {
                self = .double(double)
            } else if let bool = try? container.decode(Bool.self) {
                self = .bool(bool)
            } else if container.decodeNil() {
                self = .null
            } else {
                throw DecodingError.typeMismatch(CodableValue.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Unsupported type"))
            }
        }
        
        func encode(to encoder: Encoder) throws {
            var container = encoder.singleValueContainer()
            switch self {
            case .string(let value): try container.encode(value)
            case .int(let value): try container.encode(value)
            case .double(let value): try container.encode(value)
            case .bool(let value): try container.encode(value)
            case .null: try container.encodeNil()
            }
        }
    }
}

// MARK: - 2. Simulate LLM Output

/// Simulates the raw JSON string output from an LLM.
/// In a real application, this would come from an API call to your local LLM.
let llmJSONOutputSetTimer = """
{
  "commandType": "setTimer",
  "parameters": {
    "durationMinutes": 10,
    "label": "cooking eggs"
  },
  "confidenceScore": 0.98
}
"""

let llmJSONOutputPlayMusic = """
{
  "commandType": "playMusic",
  "parameters": {
    "genre": "jazz",
    "artist": null,
    "mood": "relaxing"
  },
  "confidenceScore": 0.92
}
"""

let llmJSONOutputUnknownCommand = """
{
  "commandType": "unrecognizedAction",
  "parameters": {},
  "confidenceScore": 0.65
}
"""

let llmJSONOutputMalformed = """
{
  "commandType": "setTimer",
  "parameters": {
    "durationMinutes": "ten" // Incorrect type for durationMinutes
  },
  "confidenceScore": 0.90
}
"""

// MARK: - 3. Create a JSONDecoder

/// An instance of `JSONDecoder` used to convert JSON data into Swift objects.
/// We don't need any special configuration for this basic example,
/// but it's where you'd set key decoding strategies, date decoding strategies, etc.
let decoder = JSONDecoder()

// MARK: - 4. Define a Function to Process LLM Output

/// Processes the raw JSON string from an LLM into a `VoiceCommand` object.
/// This function simulates the asynchronous nature of interacting with an LLM.
///
/// - Parameter jsonString: The raw JSON string received from the LLM.
/// - Returns: An optional `VoiceCommand` object if parsing is successful.
/// - Throws: `DecodingError` if JSON parsing fails.
@available(iOS 18.0, macOS 15.0, *) // Using async/await, typically available from iOS 13/macOS 10.15, but for Swift 6 context, assume latest SDK.
func processLLMOutput(jsonString: String) async throws -> VoiceCommand? {
    // Simulate network delay or LLM processing time
    try await Task.sleep(for: .milliseconds(50))
    
    guard let jsonData = jsonString.data(using: .utf8) else {
        print("Error: Could not convert JSON string to Data.")
        return nil
    }
    
    do {
        let command = try decoder.decode(VoiceCommand.self, from: jsonData)
        return command
    } catch {
        print("Error decoding LLM output: \(error.localizedDescription)")
        // In a real app, you might log the full error or send it to an analytics service.
        throw error // Re-throw to allow caller to handle specific decoding errors
    }
}

// MARK: - 5. Demonstrate Usage in an App Context

/// Simulates the main application logic that receives and acts on LLM commands.
@available(iOS 18.0, macOS 15.0, *)
@MainActor // UI updates should always happen on the main actor.
func handleVoiceCommand(_ command: VoiceCommand) {
    print("\n--- Handling Voice Command ---")
    print("Command Type: \(command.commandType.rawValue)")
    print("Confidence: \(command.confidenceScore * 100)%")
    
    if let parameters = command.parameters {
        print("Parameters:")
        for (key, value) in parameters {
            switch value {
            case .string(let s): print("  - \(key): \(s) (String)")
            case .int(let i): print("  - \(key): \(i) (Int)")
            case .double(let d): print("  - \(key): \(d) (Double)")
            case .bool(let b): print("  - \(key): \(b) (Bool)")
            case .null: print("  - \(key): null")
            }
        }
    } else {
        print("No parameters provided.")
    }

    // Perform actions based on the parsed command
    switch command.commandType {
    case .setTimer:
        if let durationValue = command.parameters?["durationMinutes"],
           case .int(let minutes) = durationValue {
            print("Action: Setting a timer for \(minutes) minutes.")
            // In a real app: Call TimerManager.setTimer(duration: minutes)
        } else {
            print("Action: Could not set timer, missing duration.")
        }
    case .playMusic:
        if let genreValue = command.parameters?["genre"],
           case .string(let genre) = genreValue {
            print("Action: Playing \(genre) music.")
            // In a real app: Call MusicPlayer.play(genre: genre)
        } else {
            print("Action: Playing generic music.")
        }
    case .unknown:
        print("Action: Unknown command. Prompting user for clarification.")
        // In a real app: Display a UI prompt or speak a clarifying question.
    }
}

// MARK: - Main Execution Block

@available(iOS 18.0, macOS 15.0, *)
Task {
    // Example 1: Successful timer command
    do {
        if let command = try await processLLMOutput(jsonString: llmJSONOutputSetTimer) {
            handleVoiceCommand(command)
        }
    } catch {
        print("Failed to process timer command: \(error)")
    }

    // Example 2: Successful music command
    do {
        if let command = try await processLLMOutput(jsonString: llmJSONOutputPlayMusic) {
            handleVoiceCommand(command)
        }
    } catch {
        print("Failed to process music command: \(error)")
    }

    // Example 3: Unknown command
    do {
        if let command = try await processLLMOutput(jsonString: llmJSONOutputUnknownCommand) {
            handleVoiceCommand(command)
        }
    } catch {
        print("Failed to process unknown command: \(error)")
    }

    // Example 4: Malformed JSON (incorrect type for durationMinutes)
    do {
        _ = try await processLLMOutput(jsonString: llmJSONOutputMalformed)
    } catch let DecodingError.typeMismatch(type, context) {
        print("\n--- Handling Malformed JSON ---")
        print("Decoding Error: Type mismatch for \(type) at \(context.codingPath.map { $0.stringValue }.joined(separator: ".")): \(context.debugDescription)")
        print("Application might prompt user for clarification or retry.")
    } catch {
        print("\n--- Handling Malformed JSON ---")
        print("Other decoding error for malformed JSON: \(error.localizedDescription)")
    }
}
