
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import BackgroundTasks
import UIKit // Needed for AppDelegate context

// MARK: - Background Task Manager

@available(iOS 18.0, *)
class BackgroundTaskManager {

    static let shared = BackgroundTaskManager()

    private let refreshTaskIdentifier = "com.yourcompany.yourapp.modelRefreshTask"
    private var urlSessionTask: URLSessionDataTask? // To allow cancellation

    private init() {} // Singleton

    // MARK: - Registration

    func registerBackgroundTasks() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: refreshTaskIdentifier, onQueue: .main) { task in
            guard let appRefreshTask = task as? BGAppRefreshTask else {
                print("Error: Task is not a BGAppRefreshTask.")
                task.setTaskCompleted(success: false)
                return
            }
            self.handleModelRefresh(task: appRefreshTask)
        }
        print("Registered background refresh task: \(refreshTaskIdentifier)")
    }

    // MARK: - Scheduling

    func scheduleAppRefresh() {
        let request = BGAppRefreshTaskRequest(identifier: refreshTaskIdentifier)
        // Request to run no earlier than 15 minutes from now.
        // The system determines the optimal time based on device conditions.
        request.earliestBeginDate = Date(timeIntervalSinceNow: 60 * 15)

        do {
            try BGTaskScheduler.shared.submit(request)
            print("Scheduled background app refresh request.")
        } catch {
            print("Could not schedule app refresh: \(error.localizedDescription)")
        }
    }

    // MARK: - Task Handler

    private func handleModelRefresh(task: BGAppRefreshTask) {
        print("Background app refresh task started for \(task.identifier).")

        // Create a new Task for asynchronous operations
        let backgroundTask = Task {
            // Set an expiration handler to clean up if the system terminates the task early.
            task.expirationHandler = {
                print("Background app refresh task expired for \(task.identifier). Cancelling ongoing operations.")
                self.urlSessionTask?.cancel() // Cancel the network request
                task.setTaskCompleted(success: false) // Mark as failed due to expiration
            }

            // Simulate downloading model weights
            let success = await downloadModelWeights()

            // Ensure the task is marked complete only if not already expired
            if !Task.isCancelled {
                print("Background app refresh task for \(task.identifier) completed with success: \(success).")
                task.setTaskCompleted(success: success)
            } else {
                print("Background app refresh task for \(task.identifier) was cancelled externally (e.g., by expiration handler).")
            }
            // Reschedule for the next interval regardless of success/failure
            self.scheduleAppRefresh()
        }

        // Store the task or its cancellation handle if needed for external cancellation (e.g., by expirationHandler)
        // For URLSession, we store the data task itself.
    }

    // MARK: - Simulated Network Request

    private func downloadModelWeights() async -> Bool {
        let mockURL = URL(string: "https://mockapi.example.com/model_weights.json")!
        let successRate = 0.8 // 80% chance of success

        do {
            // Simulate a network request with a delay
            try await Task.sleep(for: .seconds(Double.random(in: 3...8))) // Simulate download time

            if Double.random(in: 0...1) < successRate {
                // Simulate successful data download
                let mockData = "{\"version\": \"1.0.1\", \"weights\": \"base64encodeddata...\"}".data(using: .utf8)!
                print("Successfully downloaded \(mockData.count) bytes of model weights.")
                // Process the downloaded data here
                return true
            } else {
                print("Simulated network error during model weights download.")
                return false
            }
        } catch is URLError {
            print("URLError encountered during model weights download.")
            return false
        } catch {
            print("An unexpected error occurred during model weights download: \(error.localizedDescription)")
            return false
        }
    }
}

// MARK: - AppDelegate Integration Example

// Extend AppDelegate to call the BackgroundTaskManager methods
/*
@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    let backgroundTaskManager = BackgroundTaskManager.shared

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        if #available(iOS 18.0, *) {
            backgroundTaskManager.registerBackgroundTasks()
            backgroundTaskManager.scheduleAppRefresh() // Schedule initial refresh
        } else {
            // Fallback for older iOS versions if needed
        }
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        if #available(iOS 18.0, *) {
            backgroundTaskManager.scheduleAppRefresh() // Reschedule when app goes to background
        }
    }
}
*/
