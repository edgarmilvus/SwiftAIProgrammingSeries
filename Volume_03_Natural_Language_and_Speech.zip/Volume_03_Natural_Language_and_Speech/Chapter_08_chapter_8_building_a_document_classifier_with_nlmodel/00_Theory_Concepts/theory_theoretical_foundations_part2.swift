
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import NaturalLanguage
import Foundation

@available(iOS 18.0, *)
actor ClassifierActor {
    private var model: NLModel?

    init() {
        // Model loading can also be async if it involves network or heavy I/O
        Task {
            await loadModel()
        }
    }

    private func loadModel() async {
        guard let modelURL = Bundle.main.url(forResource: "MyDocumentClassifier", withExtension: "mlmodel") else {
            print("Error: MyDocumentClassifier.mlmodel not found in app bundle.")
            return
        }
        do {
            self.model = try NLModel(contentsOf: modelURL)
            print("NLModel loaded successfully on actor.")
        } catch {
            print("Error loading NLModel on actor: \(error.localizedDescription)")
        }
    }

    /// Asynchronously classifies text.
    func classifyAsync(text: String) async -> String? {
        // Ensure model is loaded before attempting classification
        guard let model = await model else {
            print("Model not loaded yet. Cannot classify.")
            return nil
        }
        // Perform classification on a background thread managed by the actor
        return model.predictedLabel(for: text)
    }

    /// Asynchronously classifies text and returns top labels with confidences.
    func classifyWithConfidencesAsync(text: String, maximumCount: Int = 3) async -> [(label: String, confidence: Double)] {
        guard let model = await model else {
            print("Model not loaded yet. Cannot classify.")
            return []
        }
        return model.predictedLabels(for: text, maximumCount: maximumCount).map { (label: $0.0, confidence: $0.1) }
    }
}

// Example Usage in a SwiftUI View or elsewhere
@available(iOS 18.0, *)
func performAsyncClassification() async {
    let classifier = ClassifierActor() // Create an instance of the actor

    let textToClassify = "This is an amazing product, I highly recommend it!"
    let startTime = Date()

    // Await the classification result
    if let label = await classifier.classifyAsync(text: textToClassify) {
        let endTime = Date()
        print("Async Classification Result: '\(textToClassify)' -> \(label) (took \(endTime.timeIntervalSince(startTime))s)")
    } else {
        print("Async classification failed.")
    }

    let textWithConfidences = "Not sure if I like it, it's pretty average."
    let topLabels = await classifier.classifyWithConfidencesAsync(text: textWithConfidences, maximumCount: 2)
    print("Async Classification with Confidences:")
    for (label, confidence) in topLabels {
        print("  - \(label) (Confidence: \(String(format: "%.2f", confidence * 100))%)")
    }
}

// Task { await performAsyncClassification() }
