
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// Represents the temperature scale. 
/// Conforming to String and Codable allows easy mapping from LLM JSON.
enum WeatherUnit: String, Codable, Sendable {
    case celsius
    case fahrenheit
}

/// The structure of the data returned by our service.
struct WeatherResponse: Codable, Sendable {
    let temperature: Double
    let unit: WeatherUnit
    let condition: String
    let location: String
}

/// An actor to ensure thread-safe access to weather data/caching.
actor WeatherService {
    func getWeatherForecast(location: String, unit: WeatherUnit, forecastType: String) async throws -> WeatherResponse {
        // In a real app, this would be an API call to OpenWeather or similar.
        // Simulating network latency.
        try await Task.sleep(for: .seconds(1))
        
        // Mocking logic: if location is empty, throw error for LLM to handle.
        guard !location.isEmpty else {
            throw NSError(domain: "WeatherService", code: 400, userInfo: [NSLocalizedDescriptionKey: "Location is required."])
        }
        
        let mockTemp: Double = unit == .celsius ? 22.0 : 71.6
        
        return WeatherResponse(
            temperature: mockTemp,
            unit: unit,
            condition: "Partly Cloudy",
            location: location
        )
    }
}

/// Represents the tool definition sent to the LLM.
struct ToolDefinition {
    let name: String
    let description: String
    let parameters: [String: Any]
}

/// The Dispatcher: Bridges the gap between LLM JSON and Swift code.
struct WeatherToolDispatcher {
    let service: WeatherService
    
    /// Simulates receiving a ToolCall from the OpenAI API.
    func dispatch(toolName: String, argumentsJSON: Data) async throws -> String {
        guard toolName == "get_weather_forecast" else {
            throw NSError(domain: "Dispatcher", code: 404, userInfo: [NSLocalizedDescriptionKey: "Tool not found"])
        }
        
        // 1. Decode the arguments into a temporary Decodable struct.
        struct Arguments: Codable {
            let location: String
            let unit: WeatherUnit
            let forecast_type: String
        }
        
        let args = try JSONDecoder().decode(Arguments.self, from: argumentsJSON)
        
        // 2. Route to the actor.
        let response = try await service.getWeatherForecast(
            location: args.location,
            unit: args.unit,
            forecastType: args.forecast_type
        )
        
        // 3. Convert response back to JSON string for the LLM.
        let responseData = try JSONEncoder().encode(response)
        return String(data: responseData, encoding: .utf8) ?? "{}"
    }
}

// --- Execution Example ---
Task {
    let service = WeatherService()
    let dispatcher = WeatherToolDispatcher(service: service)
    
    // Simulated JSON from LLM: "What's the temperature in Tokyo right now?"
    let llmArguments = """
    {
        "location": "Tokyo, Japan",
        "unit": "celsius",
        "forecast_type": "current"
    }
    """.data(using: .utf8)!
    
    do {
        let result = try await dispatcher.dispatch(toolName: "get_weather_forecast", argumentsJSON: llmArguments)
        print("LLM Received: \(result)")
    } catch {
        print("Error: \(error.localizedDescription)")
    }
}
