
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CloudKit
import Observation

/// A thread-safe coordinator that manages the synchronization 
/// between CloudKit and the local AI memory.
@available(iOS 18.0, *)
actor MemoryCoordinator {
    // The local cache of semantic embeddings
    private var semanticCache: [String: [Float]] = [:]
    
    // Tracks the last known server change tag to prevent stale writes
    private var lastKnownChangeTag: String?

    /// Resolves a conflict between local and remote semantic data.
    /// Uses a weighted average approach for vector stability.
    func resolveVectorConflict(
        local: [Float], 
        remote: [Float], 
        weight: Float = 0.5
    ) -> [Float] {
        // Ensure vectors are of the same dimensionality
        guard local.count == remote.count else { return remote }
        
        // Perform a weighted interpolation to prevent "Vector Drift"
        return zip(local, remote).map { (l, r) in
            (l * weight) + (r * (1.0 - weight))
        }
    }

    /// Updates the local cache with a new vector, ensuring actor isolation.
    func updateVector(id: String, vector: [Float], tag: String) {
        semanticCache[id] = vector
        lastKnownChangeTag = tag
    }
    
    func getVector(id: String) -> [Float]? {
        return semanticCache[id]
    }
}
