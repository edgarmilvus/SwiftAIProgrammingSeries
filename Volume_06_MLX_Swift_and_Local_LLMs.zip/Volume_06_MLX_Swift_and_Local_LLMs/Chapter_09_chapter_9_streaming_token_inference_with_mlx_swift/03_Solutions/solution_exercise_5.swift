
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import MLX

// Re-using TokenizerProtocol from Exercise 1
protocol TokenizerProtocol: Sendable {
    func tokenize(text: String) -> [Int]
    func detokenize(ids: [Int]) -> String
    var eosTokenID: Int { get }
}

// Re-using MockTokenizer from Exercise 1
class MockTokenizer: TokenizerProtocol {
    let vocab: [String: Int]
    let reverseVocab: [Int: String]
    let eosTokenID: Int

    init(vocab: [String: Int], eosTokenID: Int) {
        self.vocab = vocab
        self.reverseVocab = vocab.reduce(into: [:]) { $0[$1.value] = $1.key }
        self.eosTokenID = eosTokenID
    }

    func tokenize(text: String) -> [Int] {
        return text.split(separator: " ", omittingEmptySubsequences: true).compactMap { vocab[String($0)] }
    }

    func detokenize(ids: [Int]) -> String {
        return ids.compactMap { reverseVocab[$0] }.joined(separator: " ")
    }
}

// MARK: - LoRA Enhanced MLX Modules

@available(iOS 18.0, macOS 14.0, *)
class LoRALinear: MLXNN.Module {
    let baseLinear: MLXNN.Linear
    var lora_A: MLXArray?
    var lora_B: MLXArray?
    let r: Int // LoRA rank
    let alpha: Float // LoRA scaling factor (often alpha/r)

    init(baseLinear: MLXNN.Linear, rank: Int, alpha: Float = 1.0) {
        self.baseLinear = baseLinear
        self.r = rank
        self.alpha = alpha
        super.init()
    }

    // This is the core LoRA application logic
    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        var output = baseLinear(x)
        if let lora_A = lora_A, let lora_B = lora_B {
            // Apply LoRA adapter: W_lora = (x @ lora_A) @ lora_B * (alpha / r)
            let lora_output = (x @ lora_A) @ lora_B * (alpha / Float(r))
            output = output + lora_output // Add LoRA output to base output
        }
        return output
    }

    func loadLoRAWeights(a: MLXArray, b: MLXArray) {
        // Basic validation: Check shapes if possible
        guard a.shape.count == 2, b.shape.count == 2,
              a.shape[1] == r, b.shape[0] == r,
              a.shape[0] == baseLinear.weight.shape[1], // Input dim
              b.shape[1] == baseLinear.weight.shape[0] // Output dim
        else {
            print("Warning: LoRA weight shapes mismatch for \(name). A:\(a.shape), B:\(b.shape) vs base: \(baseLinear.weight.shape)")
            // In a real scenario, this would be a fatal error or more robust handling.
            // For this mock, we'll proceed if shapes are off, but it might lead to runtime errors.
            // For MLX, `MLXNN.Linear` typically has `weight` as `[output_dim, input_dim]`.
            // So `x @ W.T` or `x @ W` depending on how the linear layer is defined.
            // Assuming `x` is `[..., input_dim]`, `W` is `[input_dim, output_dim]` for matrix multiplication.
            // `MLXNN.Linear`'s `weight` is `[output_dim, input_dim]`. So `x @ weight.T`.
            // lora_A: `[input_dim, r]`, lora_B: `[r, output_dim]`
            // Then `(x @ lora_A) @ lora_B` would be `[..., input_dim] @ [input_dim, r] @ [r, output_dim]` -> `[..., output_dim]`
            // This means `a.shape[0]` should be `baseLinear.weight.shape[1]` (input dim)
            // and `b.shape[1]` should be `baseLinear.weight.shape[0]` (output dim).
        }
        self.lora_A = a
        self.lora_B = b
    }

    func clearLoRAWeights() {
        self.lora_A = nil
        self.lora_B = nil
    }
}

// Placeholder for Attention mechanism with LoRA
@available(iOS 18.0, macOS 14.0, *)
class LoRAAttention: MLXNN.Module {
    let q_proj: LoRALinear
    let k_proj: LoRALinear
    let v_proj: LoRALinear
    let out_proj: LoRALinear
    let hiddenSize: Int

    init(hiddenSize: Int, loraRank: Int, loraAlpha: Float) {
        self.hiddenSize = hiddenSize
        // Base Linear layers must be initialized first.
        let baseQ = MLXNN.Linear(inputDimensions: hiddenSize, outputDimensions: hiddenSize)
        let baseK = MLXNN.Linear(inputDimensions: hiddenSize, outputDimensions: hiddenSize)
        let baseV = MLXNN.Linear(inputDimensions: hiddenSize, outputDimensions: hiddenSize)
        let baseOut = MLXNN.Linear(inputDimensions: hiddenSize, outputDimensions: hiddenSize)
        
        self.q_proj = LoRALinear(baseLinear: baseQ, rank: loraRank, alpha: loraAlpha)
        self.k_proj = LoRALinear(baseLinear: baseK, rank: loraRank, alpha: loraAlpha)
        self.v_proj = LoRALinear(baseLinear: baseV, rank: loraRank, alpha: loraAlpha)
        self.out_proj = LoRALinear(baseLinear: baseOut, rank: loraRank, alpha: loraAlpha)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray, previousKVCache: (MLXArray, MLXArray)? = nil) -> (MLXArray, (MLXArray, MLXArray)?) {
        // Simplified attention logic for demonstration
        let q = q_proj(x)
        let k = k_proj(x)
        let v = v_proj(x)
        
        // Mock KV cache update: just pass through. In reality, k and v would be appended/concatenated.
        let newKVCache = previousKVCache ?? (MLXArray(0), MLXArray(0)) // Dummy new cache

        // Simplified attention calculation: just return q for now
        let output = out_proj(q) // Placeholder for actual attention output
        return (output, newKVCache)
    }
    
    // Helper to apply LoRA weights to its internal linear layers
    func applyLoRA(weights: [String: (lora_A: MLXArray, lora_B: MLXArray)], prefix: String) {
        if let (a, b) = weights["\(prefix).q_proj"] { q_proj.loadLoRAWeights(a: a, b: b) }
        if let (a, b) = weights["\(prefix).k_proj"] { k_proj.loadLoRAWeights(a: a, b: b) }
        if let (a, b) = weights["\(prefix).v_proj"] { v_proj.loadLoRAWeights(a: a, b: b) }
        if let (a, b) = weights["\(prefix).out_proj"] { out_proj.loadLoRAWeights(a: a, b: b) }
    }
    
    func clearLoRA() {
        q_proj.clearLoRAWeights()
        k_proj.clearLoRAWeights()
        v_proj.clearLoRAWeights()
        out_proj.clearLoRAWeights()
    }
}

// Placeholder for FeedForward network with LoRA
@available(iOS 18.0, macOS 14.0, *)
class LoRAFeedForward: MLXNN.Module {
    let linear1: LoRALinear
    let linear2: LoRALinear
    let hiddenSize: Int

    init(hiddenSize: Int, loraRank: Int, loraAlpha: Float) {
        self.hiddenSize = hiddenSize
        let baseL1 = MLXNN.Linear(inputDimensions: hiddenSize, outputDimensions: hiddenSize * 4)
        let baseL2 = MLXNN.Linear(inputDimensions: hiddenSize * 4, outputDimensions: hiddenSize)
        self.linear1 = LoRALinear(baseLinear: baseL1, rank: loraRank, alpha: loraAlpha)
        self.linear2 = LoRALinear(baseLinear: baseL2, rank: loraRank, alpha: loraAlpha)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        return linear2(MLX.relu(linear1(x)))
    }
    
    func applyLoRA(weights: [String: (lora_A: MLXArray, lora_B: MLXArray)], prefix: String) {
        if let (a, b) = weights["\(prefix).linear1"] { linear1.loadLoRAWeights(a: a, b: b) }
        if let (a, b) = weights["\(prefix).linear2"] { linear2.loadLoRAWeights(a: a, b: b) }
    }
    
    func clearLoRA() {
        linear1.clearLoRAWeights()
        linear2.clearLoRAWeights()
    }
}

// A placeholder for a Transformer Block that uses LoRALinear
@available(iOS 18.0, macOS 14.0, *)
class LoRATransformerBlock: MLXNN.Module {
    let attention: LoRAAttention
    let feedForward: LoRAFeedForward
    let blockID: Int // To help with unique naming for LoRA weights

    init(hiddenSize: Int, loraRank: Int, loraAlpha: Float, blockID: Int) {
        self.blockID = blockID
        self.attention = LoRAAttention(hiddenSize: hiddenSize, loraRank: loraRank, loraAlpha: loraAlpha)
        self.feedForward = LoRAFeedForward(hiddenSize: hiddenSize, loraRank: loraRank, loraAlpha: loraAlpha)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray, previousKVCache: (MLXArray, MLXArray)? = nil) -> (MLXArray, (MLXArray, MLXArray)?) {
        let (attn_out, newKVCache) = attention(x, previousKVCache: previousKVCache)
        let ff_out = feedForward(attn_out)
        return (ff_out, newKVCache)
    }
    
    func applyLoRA(weights: [String: (lora_A: MLXArray, lora_B: MLXArray)]) {
        let prefix = "transformerBlocks.\(blockID)"
        attention.applyLoRA(weights: weights, prefix: "\(prefix).attention")
        feedForward.applyLoRA(weights: weights, prefix: "\(prefix).feedForward")
    }
    
    func clearLoRA() {
        attention.clearLoRA()
        feedForward.clearLoRA()
    }
}

@available(iOS 18.0, macOS 14.0, *)
class LoRABaseLLM: MLXNN.Module {
    let embedding: MLXNN.Embedding
    let transformerBlocks: [LoRATransformerBlock]
    let finalLinear: MLXNN.Linear
    let vocabSize: Int

    init(vocabSize: Int, hiddenSize: Int, numLayers: Int, loraRank: Int, loraAlpha: Float) {
        self.vocabSize = vocabSize
        self.embedding = MLXNN.Embedding(inputDimensions: vocabSize, outputDimensions: hiddenSize)
        self.transformerBlocks = (0..<numLayers).map { i in
            LoRATransformerBlock(hiddenSize: hiddenSize, loraRank: loraRank, loraAlpha: loraAlpha, blockID: i)
        }
        self.finalLinear = MLXNN.Linear(inputDimensions: hiddenSize, outputDimensions: vocabSize)
        super.init()
    }

    override func callAsFunction(_ inputIDs: MLXArray, previousKVCache: (MLXArray, MLXArray)? = nil) -> (MLXArray, (MLXArray, MLXArray)?) {
        var x = embedding(inputIDs)
        var currentKVCache = previousKVCache
        for block in transformerBlocks {
            (x, currentKVCache) = block(x, previousKVCache: currentKVCache)
        }
        let logits = finalLinear(x)
        return (logits, currentKVCache)
    }

    func applyPersonaLoRA(personaWeights: [String: (lora_A: MLXArray, lora_B: MLXArray)]) {
        for block in transformerBlocks {
            block.applyLoRA(weights: personaWeights)
        }
        print("LoRA weights applied for new persona.")
    }
    
    func clearAllLoRA() {
        for block in transformerBlocks {
            block.clearLoRA()
        }
        print("All LoRA weights cleared, reverting to base model.")
    }

    func generate(inputIDs: MLXArray, maxTokens: Int, temperature: Float, tokenizer: TokenizerProtocol) async throws -> AsyncThrowingStream<MLXArray, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                var currentIDs = inputIDs
                var kvCache: (MLXArray, MLXArray)? = nil // Initialize KV cache

                for _ in 0..<maxTokens {
                    let (logits, newKVCache) = self.callAsFunction(currentIDs, previousKVCache: kvCache)
                    kvCache = newKVCache

                    // Sample next token (simplified argmax for illustration)
                    let nextTokenID = MLX.argmax(logits[0, -1, MLX.all], axis: -1).item(Int.self)!
                    
                    continuation.yield(MLXArray(scalar: nextTokenID))

                    // Append the new token to the input for the next step
                    currentIDs = MLX.concatenate([currentIDs, MLXArray(scalar: nextTokenID).reshaped([1, 1])], axis: 1)

                    if nextTokenID == tokenizer.eosTokenID {
                        break
                    }
                }
                continuation.finish()
            }
        }
    }
}

// MARK: - Persona Manager

enum Persona: String, CaseIterable, Identifiable {
    case supportiveFriend = "Supportive Friend"
    case criticalAnalyst = "Critical Analyst"
    case zenMaster = "Zen Master"
    case baseModel = "Base Model"

    var id: String { self.rawValue }
}

enum LoRAError: Error, LocalizedError {
    case modelNotLoaded
    case tokenizerNotLoaded
    case personaWeightsNotFound(String)
    
    var errorDescription: String? {
        switch self {
        case .modelNotLoaded: return "Base LLM not loaded."
        case .tokenizerNotLoaded: return "Tokenizer not loaded."
        case .personaWeightsNotFound(let persona): return "LoRA weights for persona '\(persona)' not found."
        }
    }
}

@available(iOS 18.0, macOS 14.0, *)
@Observable
class PersonaManager {
    private var baseLLM: LoRABaseLLM?
    private var tokenizer: (any TokenizerProtocol)?
    private var loraWeights: [Persona: [String: (lora_A: MLXArray, lora_B: MLXArray)]] = [:]

    var currentPersona: Persona = .baseModel {
        didSet {
            if oldValue != currentPersona {
                applyCurrentPersonaLoRA()
            }
        }
    }
    var chatOutput: String = ""
    var isLoading: Bool = false
    var errorMessage: String?

    init() {
        let mockVocab: [String: Int] = [
            "hello": 1, "friend": 2, "how": 3, "are": 4, "you": 5, "?": 6, "that's": 7, "interesting": 8, "perspective": 9,
            "consider": 10, "the": 11, "data": 12, "and": 13, "facts": 14, ".": 15, "reflect": 16, "on": 17, "your": 18, "inner": 19, "peace": 20,
            "base": 21, "model": 22, "response": 23, "calm": 24, "analysis": 25, "empathy": 26,
            "<|eos|>": 1000
        ]
        let eosTokenID = mockVocab["<|eos|>"]!
        self.tokenizer = MockTokenizer(vocab: mockVocab, eosTokenID: eosTokenID)
        
        let hiddenSize = 64 // Small for mock
        let numLayers = 2
        let loraRank = 4
        let loraAlpha: Float = 32.0 // Common alpha value for LoRA
        self.baseLLM = LoRABaseLLM(vocabSize: mockVocab.count, hiddenSize: hiddenSize, numLayers: numLayers, loraRank: loraRank, loraAlpha: loraAlpha)
        
        // Simulate loading LoRA weights
        loadMockLoRAWeights(hiddenSize: hiddenSize, loraRank: loraRank)
    }
    
    // Simulates loading LoRA weights for different personas
    private func loadMockLoRAWeights(hiddenSize: Int, loraRank: Int) {
        // Create dummy MLXArray for lora_A and lora_B
        // Shapes: lora_A [input_dim, rank], lora_B [rank, output_dim]
        // Assuming all LoRALinear layers have input/output dim = hiddenSize or hiddenSize*4
        
        func createLoRAParams(inputDim: Int, outputDim: Int) -> (lora_A: MLXArray, lora_B: MLXArray) {
            let a = MLXArray.randomUniform(low: -0.01, high: 0.01, shape: [inputDim, loraRank], type: .float16)
            let b = MLXArray.randomUniform(low: -0.01, high: 0.01, shape: [loraRank, outputDim], type: .float16)
            return (a, b)
        }

        var supportiveWeights: [String: (lora_A: MLXArray, lora_B: MLXArray)] = [:]
        var criticalWeights: [String: (lora_A: MLXArray, lora_B: MLXArray)] = [:]
        var zenWeights: [String: (lora_A: MLXArray, lora_B: MLXArray)] = [:]

        // Populate weights for each block and sub-layer
        for i in 0..<baseLLM!.transformerBlocks.count {
            let blockPrefix = "transformerBlocks.\(i)"
            // Attention layers
            supportiveWeights["\(blockPrefix).attention.q_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)
            criticalWeights["\(blockPrefix).attention.q_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)
            zenWeights["\(blockPrefix).attention.q_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)
            
            supportiveWeights["\(blockPrefix).attention.k_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)
            criticalWeights["\(blockPrefix).attention.k_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)
            zenWeights["\(blockPrefix).attention.k_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)

            supportiveWeights["\(blockPrefix).attention.v_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)
            criticalWeights["\(blockPrefix).attention.v_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)
            zenWeights["\(blockPrefix).attention.v_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)

            supportiveWeights["\(blockPrefix).attention.out_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)
            criticalWeights["\(blockPrefix).attention.out_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)
            zenWeights["\(blockPrefix).attention.out_proj"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize)

            // FeedForward layers
            supportiveWeights["\(blockPrefix).feedForward.linear1"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize * 4)
            criticalWeights["\(blockPrefix).feedForward.linear1"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize * 4)
            zenWeights["\(blockPrefix).feedForward.linear1"] = createLoRAParams(inputDim: hiddenSize, outputDim: hiddenSize * 4)

            supportiveWeights["\(blockPrefix).feedForward.linear2"] = createLoRAParams(inputDim: hiddenSize * 4, outputDim: hiddenSize)
            criticalWeights["\(blockPrefix).feedForward.linear2"] = createLoRAParams(inputDim: hiddenSize * 4, outputDim: hiddenSize)
            zenWeights["\(blockPrefix).feedForward.linear2"] = createLoRAParams(inputDim: hiddenSize * 4, outputDim: hiddenSize)
        }
        
        loraWeights[.supportiveFriend] = supportiveWeights
        loraWeights[.criticalAnalyst] = criticalWeights
        loraWeights[.zenMaster] = zenWeights
        print("Mock LoRA weights loaded for all personas.")
    }

    private func applyCurrentPersonaLoRA() {
        guard let baseLLM = self.baseLLM else {
            errorMessage = LoRAError.modelNotLoaded.localizedDescription
            return
        }

        if currentPersona == .baseModel {
            baseLLM.clearAllLoRA()
        } else if let weights = loraWeights[currentPersona] {
            baseLLM.applyPersonaLoRA(personaWeights: weights)
        } else {
            errorMessage = LoRAError.personaWeightsNotFound(currentPersona.rawValue).localizedDescription
            baseLLM.clearAllLoRA() // Fallback to base model
        }
    }

    @MainActor
    func generateResponse(prompt: String) async {
        guard let baseLLM = self.baseLLM, let tokenizer = self.tokenizer else {
            errorMessage = LoRAError.modelNotLoaded.localizedDescription
            return
        }

        isLoading = true
        chatOutput = ""
        errorMessage = nil

        print("\n--- Generating response for '\(prompt)' with persona: \(currentPersona.rawValue) ---")
        
        do {
            let inputTokens = tokenizer.tokenize(text: prompt)
            let mlxInput = MLXArray(inputTokens)
            
            let tokenStream = try await baseLLM.generate(
                inputIDs: mlxInput,
                maxTokens: 50,
                temperature: 0.7,
                tokenizer: tokenizer
            )
            
            for try await tokenIDArray in tokenStream {
                guard let tokenID = tokenIDArray.item(Int.self) else { continue }
                if tokenID == tokenizer.eosTokenID { break }
                
                let detokenized = tokenizer.detokenize(ids: [tokenID])
                chatOutput += detokenized + (detokenized.hasSuffix(" ") ? "" : " ")
                print("Streamed: \(detokenized)")
            }
            print("Response finished.")
        } catch {
            errorMessage = error.localizedDescription
            print("Error generating response: \(error.localizedDescription)")
        }
        isLoading = false
    }
}

// MARK: - Conceptual Usage

@available(iOS 18.0, macOS 14.0, *)
@MainActor
func runLoRAStreamingExample() {
    let personaManager = PersonaManager()
    
    Task {
        try await Task.sleep(for: .seconds(1)) // Simulate loading base model
        
        print("\n--- Initial Base Model Response ---")
        personaManager.currentPersona = .baseModel
        await personaManager.generateResponse(prompt: "Hello")
        print("Final Output: \(personaManager.chatOutput)")

        try await Task.sleep(for: .seconds(2))
        
        print("\n--- Switching to Supportive Friend ---")
        personaManager.currentPersona = .supportiveFriend
        await personaManager.generateResponse(prompt: "I'm feeling a bit down today.")
        print("Final Output: \(personaManager.chatOutput)")

        try await Task.sleep(for: .seconds(2))

        print("\n--- Switching to Critical Analyst ---")
        personaManager.currentPersona = .criticalAnalyst
        await personaManager.generateResponse(prompt: "I have a new idea for a project.")
        print("Final Output: \(personaManager.chatOutput)")

        try await Task.sleep(for: .seconds(2))

        print("\n--- Switching to Zen Master ---")
        personaManager.currentPersona = .zenMaster
        await personaManager.generateResponse(prompt: "I'm struggling with a decision.")
        print("Final Output: \(personaManager.chatOutput)")

        if let error = personaManager.errorMessage {
            print("Error: \(error)")
        }
    }
}

// Call this to run the conceptual example
// runLoRAStreamingExample()
