
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import Combine // For NotificationCenter publisher

/// The main SwiftUI view for the AI chat interface.
@available(iOS 18.0, *) // Targeting iOS 18 for latest SwiftUI features like @FocusState
struct ChatView: View {
    @StateObject private var viewModel = ChatViewModel()
    @State private var keyboardHeight: CGFloat = 0
    @FocusState private var isInputFocused: Bool
    @State private var scrollViewContentSize: CGSize = .zero // To track scroll view content height for auto-scroll

    // MARK: - Keyboard Avoidance Setup
    // Monitors keyboard notifications to adjust UI padding.
    private var keyboardPublisher: AnyPublisher<CGFloat, Never> {
        NotificationCenter.default.publisher(for: UIResponder.keyboardWillChangeNotification)
            .compactMap { notification in
                let endFrame = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
                let screenHeight = UIScreen.main.bounds.height
                // Calculate height relative to the screen bottom
                return endFrame?.origin.y ?? screenHeight < screenHeight ? (screenHeight - (endFrame?.origin.y ?? screenHeight)) : 0
            }
            .eraseToAnyPublisher()
    }

    var body: some View {
        VStack(spacing: 0) {
            // MARK: - Message Display Area
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 12) {
                        // Use GeometryReader to get content height for auto-scrolling logic
                        GeometryReader { geometry in
                            Color.clear.preference(key: ContentSizePreferenceKey.self, value: geometry.size)
                        }
                        .frame(height: 0) // Make it invisible

                        ForEach(viewModel.messages) { message in
                            ChatMessageView(message: message)
                                .id(message.id) // Assign ID for ScrollViewReader
                                .accessibilityElement(children: .combine) // Combine children for better VoiceOver
                                .accessibilityLabel(message.isFromUser ?
                                                    "User message: \(message.content)" :
                                                    "AI response: \(message.content)")
                        }

                        // Loading indicator for AI response
                        if viewModel.isLoadingAIResponse {
                            ProgressView()
                                .padding()
                                .accessibilityLabel("AI is typing")
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top)
                    // Observe content size changes for auto-scrolling
                    .onPreferenceChange(ContentSizePreferenceKey.self) { size in
                        scrollViewContentSize = size
                    }
                }
                // Auto-scroll to the latest message when messages change or content size changes
                .onChange(of: viewModel.messages.count) { _ in
                    scrollToBottom(proxy: proxy)
                }
                .onChange(of: scrollViewContentSize) { _ in
                    scrollToBottom(proxy: proxy)
                }
            }

            // MARK: - Error Message Display
            if let errorMessage = viewModel.errorMessage {
                Text(errorMessage)
                    .foregroundColor(.white)
                    .padding(.vertical, 8)
                    .padding(.horizontal)
                    .frame(maxWidth: .infinity)
                    .background(Color.red)
                    .cornerRadius(8)
                    .padding(.horizontal)
                    .padding(.bottom, 8)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .animation(.easeInOut, value: errorMessage)
                    .accessibilityLiveRegion(.assertive) // Announce immediately
                    .accessibilityLabel("Error: \(errorMessage)")
            }

            // MARK: - Input Area
            HStack {
                TextField("Type your message...", text: $viewModel.currentInput, axis: .vertical)
                    .textFieldStyle(.roundedBorder)
                    .focused($isInputFocused)
                    .padding(.vertical, 8)
                    .padding(.horizontal, 4)
                    .background(Color.secondary.opacity(0.1))
                    .cornerRadius(10)
                    .lineLimit(1...5) // Allow multi-line input up to 5 lines
                    .accessibilityLabel("Message input field")
                    .accessibilityHint("Type your message to the AI assistant here.")

                Button {
                    viewModel.sendMessage()
                    isInputFocused = true // Keep focus on the text field after sending
                } label: {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.title)
                        .foregroundColor(viewModel.currentInput.isEmpty ? .gray : .accentColor)
                }
                .disabled(viewModel.currentInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || viewModel.isLoadingAIResponse)
                .accessibilityLabel("Send message")
                .accessibilityAddTraits(.isButton)
                .accessibilityHint("Sends your typed message to the AI assistant.")
            }
            .padding()
            .background(.ultraThinMaterial)
            .cornerRadius(15, corners: [.topLeft, .topRight]) // Polish: rounded top corners for input area
            .shadow(radius: 5)
        }
        .background(Color.gray.opacity(0.1).ignoresSafeArea())
        .navigationTitle("AI Chat")
        .navigationBarTitleDisplayMode(.inline)
        // MARK: - Keyboard Avoidance Logic Application
        // Apply padding based on keyboard height, respecting safe area insets.
        .padding(.bottom, keyboardHeight)
        .animation(.easeOut(duration: 0.3), value: keyboardHeight) // Smooth keyboard animation
        .onReceive(keyboardPublisher) { newHeight in
            // Only update if the new height is different to avoid unnecessary redraws
            if newHeight != keyboardHeight {
                keyboardHeight = newHeight
            }
        }
        // MARK: - Accessibility for New AI Messages
        .onChange(of: viewModel.messages.last?.content) { oldContent, newContent in
            // Announce new AI messages for VoiceOver users
            if let lastMessage = viewModel.messages.last, !lastMessage.isFromUser, newContent != oldContent {
                // Delay slightly to ensure the UI has updated and is ready for VoiceOver to read.
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    UIAccessibility.post(notification: .screenChanged, argument: lastMessage.content)
                }
            }
        }
    }

    /// Scrolls the `ScrollView` to the bottom to show the latest message.
    /// - Parameter proxy: The `ScrollViewProxy` used for scrolling.
    private func scrollToBottom(proxy: ScrollViewProxy) {
        if let lastMessageId = viewModel.messages.last?.id {
            // Use a small delay to ensure the UI has rendered the new message before scrolling.
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                withAnimation(.easeOut(duration: 0.3)) {
                    proxy.scrollTo(lastMessageId, anchor: .bottom)
                }
            }
        }
    }
}

/// A custom preference key to track the content size of the ScrollView.
struct ContentSizePreferenceKey: PreferenceKey {
    static var defaultValue: CGSize = .zero
    static func reduce(value: inout CGSize, nextValue: () -> CGSize) {
        value = nextValue()
    }
}

/// A helper view for displaying individual chat messages.
struct ChatMessageView: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.isFromUser {
                Spacer()
            }
            Text(message.content)
                .padding(.vertical, 10)
                .padding(.horizontal, 15)
                .background(message.isFromUser ? Color.blue : Color.green.opacity(0.8))
                .foregroundColor(.white)
                .cornerRadius(15)
                .frame(maxWidth: UIScreen.main.bounds.width * 0.7, alignment: message.isFromUser ? .trailing : .leading)
            if !message.isFromUser {
                Spacer()
            }
        }
    }
}

// Helper to extend View for corner radius on specific corners (Polish)
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}
