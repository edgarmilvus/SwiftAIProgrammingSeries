
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import RealityKit
import SoundAnalysis
import Combine

/// Events emitted by the audio service
enum AudioTriggerEvent: Sendable {
    case clapDetected
}

/// A decoupled service that handles audio and emits events via an AsyncStream
final class AudioTriggerService: Sendable {
    // Using a stream to decouple the "What" (Sound) from the "How" (Animation)
    let eventStream: AsyncStream<AudioTriggerEvent>
    private let continuation: AsyncStream<AudioTriggerEvent>.Continuation

    init() {
        var cont: AsyncStream<AudioTriggerEvent>.Continuation?
        self.eventStream = AsyncStream { cont = $0 }
        self.continuation = cont!
    }

    // Simulated detection logic (In a real app, this integrates Exercise 1)
    func simulateClap() {
        continuation.yield(.clapDetected)
    }
    
    // In a real implementation, the SoundClassifierEngine would call this
    func handleClassification(_ label: String) {
        if label == "clap" {
            continuation.yield(.clapDetected)
        }
    }
}

struct SonicTriggerView: View {
    let audioService: AudioTriggerService
    @State private var sphereEntity: ModelEntity?

    var body: some View {
        RealityView { content in
            // Create a simple sphere
            let sphere = ModelEntity(mesh: .generateSphere(radius: 0.1), 
                                   materials: [SimpleMaterial(color: .blue, isMetallic: true)])
            sphere.position = [0, 1.5, -1] // In front of user
            content.add(sphere)
            self.sphereEntity = sphere
        }
        .task {
            // Subscribe to the decoupled event stream
            for await event in audioService.eventStream {
                switch event {
                case .clapDetected:
                    triggerAnimation()
                }
            }
        }
        .overlay(alignment: .bottom) {
            Button("Simulate Clap") {
                audioService.simulateClap()
            }
            .padding()
        }
    }

    @MainActor
    private func triggerAnimation() {
        guard let entity = sphereEntity else { return }
        
        // Prevent animation stacking: check if already animating (simplified check)
        // In a production app, you'd track animation state in a @State variable
        
        let originalTransform = entity.transform
        var targetTransform = originalTransform
        targetTransform.scale = [2.0, 2.0, 2.0]
        
        // 1. Scale Up
        entity.move(to: targetTransform, relativeTo: entity.parent, duration: 0.2, timingFunction: .easeOut)
        
        // 2. Scale Down (using Task to sequence animations)
        Task {
            try? await Task.sleep(for: .seconds(0.2))
            entity.move(to: originalTransform, relativeTo: entity.parent, duration: 0.2, timingFunction: .easeIn)
        }
    }
}
