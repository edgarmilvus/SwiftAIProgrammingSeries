
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import SwiftData
import LlamaCpp

// Reusing KnowledgeChunk, EmbeddingService, LlamaCppEmbeddingService, Array<Float> extensions from Exercise 1

// MARK: - 1. Query Embedding (already handled by LlamaCppEmbeddingService)

// MARK: - 2. Similarity Calculation

func cosineSimilarity(vectorA: [Float], vectorB: [Float]) -> Float? {
    guard vectorA.count == vectorB.count else { return nil }

    let dotProduct = zip(vectorA, vectorB).map(*).reduce(0, +)

    let magnitudeA = sqrt(vectorA.map { $0 * $0 }.reduce(0, +))
    let magnitudeB = sqrt(vectorB.map { $0 * $0 }.reduce(0, +))

    guard magnitudeA > 1e-6 && magnitudeB > 1e-6 else { // Handle near-zero magnitudes
        return 0.0 // Vectors are essentially zero, so no similarity
    }

    return dotProduct / (magnitudeA * magnitudeB)
}

// MARK: - 3. Vector Search & 4. Ranking and Display

@available(macOS 15.0, *)
class KnowledgeSearcher {
    private let modelContext: ModelContext
    private let embeddingService: EmbeddingService

    init(modelContext: ModelContext, embeddingService: EmbeddingService) {
        self.modelContext = modelContext
        self.embeddingService = embeddingService
    }

    func performSemanticSearch(query: String, topK: Int = 5) async throws -> [(KnowledgeChunk, Float)] {
        print("Generating embedding for query: '\(query)'...")
        let queryEmbedding = try await embeddingService.generateEmbedding(for: query)
        print("Query embedding generated.")

        let storedChunks = try modelContext.fetch(FetchDescriptor<KnowledgeChunk>())
        print("Retrieved \(storedChunks.count) stored knowledge chunks.")

        var results: [(KnowledgeChunk, Float)] = []
        for chunk in storedChunks {
            guard let storedEmbedding = Array<Float>(data: chunk.embeddingData) else {
                print("Warning: Could not convert embeddingData for chunk ID \(chunk.id) to [Float]. Skipping.")
                continue
            }

            if let similarity = cosineSimilarity(vectorA: queryEmbedding, vectorB: storedEmbedding) {
                results.append((chunk, similarity))
            } else {
                print("Warning: Could not calculate similarity for chunk ID \(chunk.id). Skipping.")
            }
        }
        
        // Sort by similarity in descending order and take the top K
        return results.sorted { $0.1 > $1.1 }.prefix(topK).map { $0 }
    }
}

// MARK: - 5. Search CLI (integrated into main app)

@main
@available(macOS 15.0, *)
struct KnowledgeBaseApp { // Reusing and extending the app from Exercise 1
    static let embeddingModelPath = "/path/to/your/embedding_model.gguf" // !!! REPLACE THIS !!!
    
    static func main() async {
        // --- SwiftData Setup ---
        let schema = Schema([KnowledgeChunk.self])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredDynamically: true)
        // For persistence, use: ModelConfiguration(schema: schema, url: URL(fileURLWithPath: "KnowledgeBase.sqlite"))

        guard let modelContainer = try? ModelContainer(for: schema, configurations: [modelConfiguration]) else {
            fatalError("Failed to create ModelContainer.")
        }
        let modelContext = ModelContext(modelContainer)

        // --- Embedding Service Setup ---
        guard let embeddingModelBundlePath = Bundle.main.path(forResource: "all-MiniLM-L6-v2-f16", ofType: "gguf") else {
            print("Error: Embedding model 'all-MiniLM-L6-v2-f16.gguf' not found in bundle.")
            print("Please download a .gguf embedding model (e.g., from Hugging Face) and add it to your Xcode project's resources.")
            return
        }
        let embeddingService = LlamaCppEmbeddingService(modelPath: embeddingModelBundlePath)
        print("Attempting to load embedding model from: \(embeddingModelBundlePath)")
        do {
            try await embeddingService.loadModel()
            print("Embedding model loaded successfully.")
        } catch {
            print("Failed to load embedding model: \(error.localizedDescription)")
            return
        }

        // --- Text Chunker Setup ---
        let chunker = SimpleTextChunker()

        // --- Ingestor & Searcher Setup ---
        let ingestor = KnowledgeIngestor(modelContext: modelContext, embeddingService: embeddingService, chunker: chunker)
        let searcher = KnowledgeSearcher(modelContext: modelContext, embeddingService: embeddingService)

        // --- CLI Loop ---
        print("\n--- Knowledge Base CLI ---")
        print("Type 'ingest' to add new text, 'search' to query, 'list' to see all chunks, 'exit' to quit.")

        while true {
            print("\nEnter command: ", terminator: "")
            guard let command = readLine()?.lowercased() else { continue }

            switch command {
            case "ingest":
                print("Paste text to ingest (type 'END' on a new line to finish):")
                var fullText = ""
                while let line = readLine(), line != "END" {
                    fullText += line + "\n"
                }
                if !fullText.isEmpty {
                    print("Enter optional source URL (or leave blank): ", terminator: "")
                    let urlString = readLine()
                    let sourceURL = urlString.flatMap { URL(string: $0) }

                    print("Enter optional document identifier (e.g., filename): ", terminator: "")
                    let docId = readLine()

                    do {
                        try await ingestor.ingestText(text: fullText, sourceURL: sourceURL, documentIdentifier: docId, maxChunkSize: 512, overlapSize: 50)
                        print("Text ingested successfully!")
                    } catch {
                        print("Ingestion failed: \(error.localizedDescription)")
                    }
                } else {
                    print("No text provided for ingestion.")
                }
            case "search":
                print("Enter your search query: ", terminator: "")
                guard let query = readLine(), !query.isEmpty else {
                    print("Query cannot be empty.")
                    continue
                }
                do {
                    let results = try await searcher.performSemanticSearch(query: query, topK: 5)
                    if results.isEmpty {
                        print("No relevant results found.")
                    } else {
                        print("\n--- Top \(results.count) Semantic Search Results ---")
                        for (index, (chunk, similarity)) in results.enumerated() {
                            print("Result \(index + 1) (Similarity: \(String(format: "%.4f", similarity))):")
                            print("  Source: \(chunk.documentIdentifier ?? chunk.sourceURL?.lastPathComponent ?? "N/A")")
                            print("  Content: \(chunk.content.prefix(200))...")
                            print("--------------------")
                        }
                    }
                } catch {
                    print("Search failed: \(error.localizedDescription)")
                }
            case "list": // Existing list command
                do {
                    let chunks = try modelContext.fetch(FetchDescriptor<KnowledgeChunk>())
                    if chunks.isEmpty {
                        print("No knowledge chunks found.")
                    } else {
                        print("\n--- Stored Knowledge Chunks ---")
                        for (index, chunk) in chunks.enumerated() {
                            print("Chunk \(index + 1) (ID: \(chunk.id.uuidString.prefix(8))):")
                            print("  Content: \(chunk.content.prefix(100))...")
                            print("  Source: \(chunk.sourceURL?.lastPathComponent ?? "N/A")")
                            print("  Timestamp: \(chunk.timestamp)")
                            print("  Embedding Size: \(chunk.embeddingData.count / MemoryLayout<Float>.size) floats")
                            print("--------------------")
                        }
                    }
                } catch {
                    print("Failed to fetch chunks: \(error.localizedDescription)")
                }
            case "exit":
                print("Exiting.")
                return
            default:
                print("Unknown command. Try 'ingest', 'search', 'list', or 'exit'.")
            }
        }
    }
}
