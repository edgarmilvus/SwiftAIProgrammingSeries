/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// packages/shared/api/client.ts

import { AnalyticsConfig } from '../types/analytics';

/**
 * @description A universal fetch wrapper.
 * In a real monorepo, this might detect the environment (process.env.EXPO_PUBLIC_ vs NEXT_PUBLIC_)
 * to adjust the base URL or headers.
 * 
 * @param config - The configuration object containing the API endpoint and Key.
 * @returns A Promise resolving to the analytics data.
 */
export async function fetchAnalyticsData(config: AnalyticsConfig): Promise<any> {
  try {
    // Construct headers. In a mobile context, we might add device-specific headers.
    const headers: HeadersInit = {
      'Authorization': `Bearer ${config.apiKey}`,
      'Content-Type': 'application/json',
    };

    // In Expo, 'Accept-Encoding' might need to be handled differently depending on the native version.
    // This wrapper abstracts that complexity away from the business logic.
    
    const response = await fetch(config.apiEndpoint, {
      method: 'GET',
      headers,
      // Next.js allows caching options; Expo fetch does not always support the same options.
      // We keep it simple for universality.
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    // Normalize data to our AnalyticsDataPoint interface
    // This is crucial: the backend might return different shapes for web vs mobile,
    // but the shared code enforces a single shape.
    return data.map((item: any) => ({
      id: item.id,
      timestamp: new Date(item.timestamp),
      metric: item.metric,
      value: item.value,
      userId: item.userId,
    }));

  } catch (error) {
    console.error('[Universal Fetcher] Failed to fetch analytics:', error);
    throw error;
  }
}
