
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Vision
import Foundation

// Assume 'MyImageClassifier' is an MLModel generated from a .mlmodel file.
// In a previous chapter, we learned to load and use this model.
// Now, we focus on *safely* loading and using it.

enum MLFeatureProcessingError: Error {
    case invalidInputImage
    case featureConversionFailed
}

class ModelManager {
    private var currentModel: MLModel?
    private var currentVisionModel: VNCoreMLModel?

    // Explicitly referencing a concept from a previous chapter:
    // We learned how to initialize MLModel and VNCoreMLModel.
    // Here, we add error handling to that initialization.
    func loadModel(named modelName: String, bundle: Bundle = .main) throws {
        guard let modelURL = bundle.url(forResource: modelName, withExtension: "mlmodelc") else {
            // This error isn't a CoreMLError, but a file system/bundle error.
            // It's a good practice to wrap it or throw a custom error.
            throw CoreMLError.modelLoadingFailed // Or a custom AppError.modelNotFound
        }

        do {
            let config = MLModelConfiguration()
            config.computeUnits = .all // Or .cpuOnly, .cpuAndGPU, .neuralEngine
            self.currentModel = try MLModel(contentsOf: modelURL, configuration: config)
            self.currentVisionModel = try VNCoreMLModel(for: self.currentModel!)
            print("Successfully loaded model: \(modelName)")
        } catch let error as CoreMLError {
            print("Core ML Model loading failed with specific error: \(error.localizedDescription)")
            throw error // Re-throw to allow caller to handle
        } catch {
            print("An unexpected error occurred during model loading: \(error.localizedDescription)")
            throw error
        }
    }

    func performClassification(on pixelBuffer: CVPixelBuffer) async throws -> [VNClassificationObservation] {
        guard let visionModel = currentVisionModel else {
            throw CoreMLError.predictionFailed // Or a custom AppError.modelNotLoaded
        }

        let request = VNCoreMLRequest(model: visionModel) { request, error in
            // This completion handler is for *Vision's* internal error handling,
            // but the primary error for *your* `async throws` function is handled below.
            if let error = error {
                print("Vision request internal error: \(error.localizedDescription)")
            }
        }

        // Configure request for desired behavior
        request.imageCropAndScaleOption = .centerCrop // Example configuration

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        do {
            try handler.perform([request])
            guard let observations = request.results as? [VNClassificationObservation] else {
                throw VisionError.requestFailed // Or a custom AppError.noClassificationResults
            }
            return observations
        } catch let error as VisionError {
            print("Vision Request failed with specific error: \(error.localizedDescription)")
            throw error // Re-throw Vision-specific error
        } catch {
            print("An unexpected error occurred during Vision request: \(error.localizedDescription)")
            throw error
        }
    }
}
