
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

@available(iOS 18.0, macOS 15.0, *)
struct JournalEntryWithTitleView: View {
    @State private var entryTitle: String = "My Day's Reflections"
    @State private var entryText: String = "Today was a fascinating day. I encountered several new concepts that challenged my previous understandings. The weather was also quite pleasant, contributing to a productive afternoon."

    var body: some View {
        VStack {
            TextField("Entry Title", text: $entryTitle)
                // Configure Writing Tools for the title field.
                // We start with all default tools and then explicitly exclude 'summarize' and 'simplify'.
                .writingTools(WritingToolsConfiguration.default.excluding(.summarize, .simplify))
                .padding()
                .border(Color.gray.opacity(0.5))
                .accessibilityLabel("Journal Entry Title")

            TextEditor(text: $entryText)
                // This TextEditor retains all default tools as per Exercise 1.
                .writingTools(.default)
                .border(Color.gray.opacity(0.5))
                .padding()
                .accessibilityLabel("Journal Entry Content")
        }
        .padding()
        .navigationTitle("Edit Journal")
    }
}
