
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import ARKit
import RealityKit
import SwiftUI
import Combine

// MARK: - Dependencies

/// Package.swift equivalent dependencies:
/// - RealityKit (Built-in)
/// - ARKit (Built-in)
/// - SwiftData (For metadata persistence)

// MARK: - Error Handling

/// Defines specific failure states for spatial operations.
enum SpatialError: Error, LocalizedError {
    case sessionNotRunning
    case relocalizationFailed
    case meshGenerationUnavailable
    case anchorPersistenceFailure(Error)
    case invalidTransform

    var errorDescription: String? {
        switch self {
        case .sessionNotRunning: return "The AR session is not currently active."
        case .relocalizationFailed: return "Unable to recognize the environment. Please scan the room."
        case .meshGenerationUnavailable: return "LiDAR/Scene reconstruction is not supported on this device."
        case .anchorPersistenceFailure(let err): return "Failed to save spatial data: \(err.localizedDescription)"
        case .invalidTransform: return "The requested transformation is mathematically invalid."
        }
    }
}

// MARK: - Models

/// A lightweight representation of a persistent spatial object.
struct PersistentSpatialObject: Codable, Identifiable {
    let id: UUID
    let modelName: String
    let transform: simd_float4x4
    let creationDate: Date
    
    // Custom encoding for simd_float4x4 as it doesn't conform to Codable by default
    enum CodingKeys: String, CodingKey {
        case id, modelName, transformArray, creationDate
    }
    
    init(id: UUID = UUID(), modelName: String, transform: simd_float4x4, creationDate: Date = Date()) {
        self.id = id
        self.modelName = modelName
        self.transform = transform
        self.creationDate = creationDate
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        modelName = try container.decode(String.self, forKey: .modelName)
        creationDate = try container.decode(Date.self, forKey: .creationDate)
        let array = try container.decode([Float].self, forKey: .transformArray)
        transform = simd_float4x4(
            simd_float4(array[0...3]),
            simd_float4(array[4...7]),
            simd_float4(array[8...11]),
            simd_float4(array[12...15])
        )
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(modelName, forKey: .modelName)
        try container.encode(creationDate, forKey: .creationDate)
        let array = [
            transform.columns.0.x, transform.columns.0.y, transform.columns.0.z, transform.columns.0.w,
            transform.columns.1.x, transform.columns.1.y, transform.columns.1.z, transform.columns.1.w,
            transform.columns.2.x, transform.columns.2.y, transform.columns.2.z, transform.columns.2.w,
            transform.columns.3.x, transform.columns.3.y, transform.columns.3.z, transform.columns.3.w
        ]
        try container.encode(array, forKey: .transformArray)
    }
}

// MARK: - Core Engine

/// An Actor responsible for managing the thread-safe persistence of spatial anchors and object metadata.
/// Using an actor ensures that as the ARSession updates at 60-90Hz, our data mutations are isolated.
actor SpatialPersistenceManager {
    private let fileURL: URL
    private var savedObjects: [UUID: PersistentSpatialObject] = [:]
    
    init() {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        self.fileURL = paths[0].appendingPathComponent("spatial_design_data.json")
        Task { await loadFromDisk() }
    }
    
    /// Saves a new object's spatial data to the persistent store.
    /// - Parameter object: The object to persist.
    func saveObject(_ object: PersistentSpatialObject) async throws {
        savedObjects[object.id] = object
        try await persistToDisk()
    }
    
    /// Retrieves all saved objects for reconstruction.
    func getAllSavedObjects() -> [PersistentSpatialObject] {
        return Array(savedObjects.values)
    }
    
    private func persistToDisk() async throws {
        let data = try JSONEncoder().encode(Array(savedObjects.values))
        try data.write(to: fileURL, options: [.atomic, .completeFileProtection])
    }
    
    private func loadFromDisk() async {
        guard let data = try? Data(contentsOf: fileURL) else { return }
        if let decoded = try? JSONDecoder().decode([PersistentSpatialObject].self, from: data) {
            for obj in decoded {
                savedObjects[obj.id] = obj
            }
        }
    }
}

/// The primary coordinator for the AR experience, managing the ARSession and RealityKit Scene.
@MainActor
class SpatialDesignEngine: ObservableObject {
    @Published var isRelocalizing = false
    @Published var lastError: SpatialError?
    @Published var isSceneReconstructed = false
    
    private var arView: ARView // In visionOS, this would be an ImmersiveSpace/RealityView context
    private let persistenceManager = SpatialPersistenceManager()
    private var arSession: ARSession?
    
    init(arView: ARView) {
        self.arView = arView
        self.arSession = arView.session
        setupSession()
    }
    
    /// Configures the ARSession with Scene Reconstruction and World Tracking enabled.
    private func setupSession() {
        let configuration = ARWorldTrackingConfiguration()
        
        // Enable Scene Reconstruction (LiDAR Mesh)
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) {
            configuration.sceneReconstruction = .mesh
            configuration.environmentTexturing = .automatic
        } else {
            self.lastError = .meshGenerationUnavailable
        }
        
        // Enable Plane Detection for fallback/hybrid placement
        configuration.planeDetection = [.horizontal, .vertical]
        
        // Enable Object/Image tracking if needed
        configuration.isCollaborationEnabled = true 
        
        arView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
        
        // Observe session updates
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleSessionUpdate),
            name: ARSession.didUpdateFrame,
            object: arView.session
        )
    }
    
    @objc private func handleSessionUpdate(_ notification: Notification) {
        guard let frame = arView.session.currentFrame else { return }
        
        // Check if we have achieved sufficient tracking quality
        switch frame.camera.trackingState {
        case .limited(.relocalizing):
            isRelocalizing = true
        case .normal:
            isRelocalizing = false
        default:
            break
        }
        
        // Verify if mesh is being generated
        if frame.anchors.contains(where: { $0 is ARMeshAnchor }) {
            isSceneReconstructed = true
        }
    }
    
    /// Places a virtual object using Raycasting against the reconstructed mesh.
    /// This ensures the object "sits" on real-world geometry.
    /// - Parameters:
    ///   - modelName: The name of the USDZ model to place.
    ///   - screenPoint: The 2D point in the viewport.
    func placeObject(modelName: String, at screenPoint: CGPoint) async {
        // 1. Perform Raycast against the Mesh (Scene Reconstruction)
        // We prioritize .estimatedPlane for speed, but .existingPlaneGeometry for accuracy
        let results = arView.raycast(from: screenPoint, allowing: .estimatedPlane, alignment: .any)
        
        guard let firstResult = results.first else {
            self.lastError = .invalidTransform
            return
        }
        
        let worldTransform = firstResult.worldTransform
        let objectID = UUID()
        
        // 2. Create the RealityKit Entity
        do {
            let entity = try await loadModelAsync(named: modelName)
            entity.setTransformMatrix(worldTransform, relativeTo: nil)
            
            // 3. Create an ARAnchor to tie the entity to the physical world
            // This is the key to persistence.
            let arAnchor = ARAnchor(name: objectID.uuidString, transform: worldTransform)
            arView.session.add(anchor: arAnchor)
            
            // 4. Attach Entity to Anchor
            let anchorEntity = AnchorEntity(anchor: arAnchor)
            anchorEntity.addChild(entity)
            arView.scene.addAnchor(anchorEntity)
            
            // 5. Persist the metadata via the Actor
            let metadata = PersistentSpatialObject(
                id: objectID,
                modelName: modelName,
                transform: worldTransform
            )
            try await persistenceManager.saveObject(metadata)
            
        } catch {
            self.lastError = .anchorPersistenceFailure(error)
        }
    }
    
    /// Asynchronously loads a USDZ model to prevent main-thread hitches.
    private func loadModelAsync(named name: String) async throws -> Entity {
        // In a production app, this would use a background task to load from the bundle
        return try await withCheckedThrowingContinuation { continuation in
            Entity.loadAsync(named: name)
                .sink(receiveCompletion: { completion in
                    if case .failure(let error) = completion {
                        continuation.resume(throwing: error)
                    }
                }, receiveValue: { entity in
                    continuation.resume(returning: entity)
                })
                .store(in: &cancellables)
        }
    }
    
    /// Restores previously saved objects by relocalizing the session.
    func restoreSavedSession() async {
        let savedObjects = await persistenceManager.getAllSavedObjects()
        
        for object in savedObjects {
            // In a real implementation, we would search for the ARAnchor 
            // that matches the object.id and re-attach the entity.
            // For this demonstration, we recreate them at their stored transforms.
            do {
                let entity = try await loadModelAsync(named: object.modelName)
                let anchorEntity = AnchorEntity(world: object.transform)
                anchorEntity.addChild(entity)
                arView.scene.addAnchor(anchorEntity)
            } catch {
                print("Failed to restore object \(object.id): \(error)")
            }
        }
    }
    
    private var cancellables = Set<AnyCancellable>()
}

// MARK: - UI Layer

struct SpatialDesignView: View {
    @StateObject private var engine: SpatialDesignEngine
    
    init(arView: ARView) {
        _engine = StateObject(wrappedValue: SpatialDesignEngine(arView: arView))
    }
    
    var body: some View {
        ZStack {
            // The AR View is typically provided via a UIViewRepresentable
            Color.black.ignoresSafeArea()
            
            VStack {
                if engine.isRelocalizing {
                    StatusBadge(text: "Relocalizing...", color: .orange)
                }
                
                if engine.isSceneReconstructed {
                    StatusBadge(text: "Mesh Ready", color: .green)
                }
                
                Spacer()
                
                HStack(spacing: 20) {
                    Button("Add Chair") {
                        Task { await engine.placeObject(modelName: "chair_modern", at: CGPoint(x: 0.5, y: 0.5)) }
                    }
                    .buttonStyle(.borderedProminent)
                    
                    Button("Restore Session") {
                        Task { await engine.restoreSavedSession() }
                    }
                    .buttonStyle(.bordered)
                }
                .padding(.bottom, 50)
            }
        }
        .alert(item: Binding(
            get: { engine.lastError.map { ErrorWrapper(error: $0) } },
            set: { _ in /* Handle dismissal */ }
        )) { wrapper in
            Alert(title: Text("Spatial Error"), message: Text(wrapper.error.localizedDescription))
        }
    }
}

struct StatusBadge: View {
    let text: String
    let color: Color
    var body: some View {
        Text(text)
            .font(.caption.bold())
            .padding(8)
            .background(color.opacity(0.8))
            .foregroundColor(.white)
            .cornerRadius(8)
            .padding(.top, 60)
    }
}

struct ErrorWrapper: Identifiable {
    let id = UUID()
    let error: SpatialError
}
