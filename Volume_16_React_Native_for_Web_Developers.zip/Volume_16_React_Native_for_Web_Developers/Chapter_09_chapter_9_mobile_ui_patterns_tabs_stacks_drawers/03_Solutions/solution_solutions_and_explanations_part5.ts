/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// App.tsx
import React from 'react';
import { View, Text, TouchableOpacity, Button, PanResponder, Animated } from 'react-native';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator, StackNavigationOptions } from '@react-navigation/stack';
import { MaterialIcons } from '@expo/vector-icons';
import { cn } from 'nativewind';

type RootStackParamList = {
  MainTabs: undefined;
  EditProfileModal: undefined;
};

type TabParamList = {
  Profile: undefined;
  Home: undefined;
};

const RootStack = createStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<TabParamList>();

// --- Components ---

// 1. Profile Screen (Entry for the modal flow)
const ProfileScreen = ({ navigation }: any) => {
  return (
    <View className="flex-1 bg-slate-900 items-center justify-center p-4">
      <Text className="text-white text-2xl font-bold mb-6">My Profile</Text>
      <Button 
        title="Edit Profile (Modal)" 
        onPress={() => navigation.navigate('EditProfileModal')}
        color="#8b5cf6"
      />
    </View>
  );
};

// 2. Home Screen (Placeholder)
const HomeScreen = () => (
  <View className="flex-1 bg-slate-900 items-center justify-center">
    <Text className="text-white text-xl">Home</Text>
  </View>
);

// 3. Edit Profile Modal (With Swipe to Dismiss)
const EditProfileModal = () => {
  const navigation = useNavigation();
  const pan = React.useRef(new Animated.ValueXY()).current;

  // PanResponder for Swipe Down Gesture
  const panResponder = React.useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderMove: (e, gestureState) => {
        // Only allow downward movement
        if (gestureState.dy > 0) {
          pan.setValue({ x: 0, y: gestureState.dy });
        }
      },
      onPanResponderRelease: (e, gestureState) => {
        // If swiped down more than 100px, dismiss
        if (gestureState.dy > 100) {
          navigation.goBack();
        } else {
          // Spring back to original position
          Animated.spring(pan, { toValue: { x: 0, y: 0 }, useNativeDriver: true }).start();
        }
      },
    })
  ).current;

  return (
    <View className="flex-1 justify-end bg-black/50">
      <Animated.View
        style={{ transform: [{ translateY: pan.y }] }}
        className={cn(
          "bg-slate-800 w-full rounded-t-3xl p-6 shadow-xl",
          "h-[80%]" // Modal height
        )}
        {...panResponder.panHandlers}
      >
        {/* Grabber Handle */}
        <View className="w-12 h-1.5 bg-slate-600 rounded-full self-center mb-6" />
        
        <Text className="text-white text-2xl font-bold mb-4">Edit Profile</Text>
        
        {/* Form Placeholders */}
        <View className="bg-slate-700 h-12 rounded mb-3 w-full" />
        <View className="bg-slate-700 h-12 rounded mb-6 w-full" />
        
        <Button title="Save Changes" onPress={() => navigation.goBack()} color="#10b981" />
        <TouchableOpacity onPress={() => navigation.goBack()} className="mt-4 items-center">
          <Text className="text-slate-400">Cancel</Text>
        </TouchableOpacity>
      </Animated.View>
    </View>
  );
};

// --- Navigators ---

const TabNavigator = () => (
  <Tab.Navigator
    screenOptions={{
      headerShown: false,
      tabBarStyle: { backgroundColor: '#0f172a', borderTopColor: '#334155' },
      tabBarActiveTintColor: '#a78bfa',
    }}
  >
    <Tab.Screen name="Home" component={HomeScreen} options={{ tabBarIcon: ({ color }) => <MaterialIcons name="home" color={color} size={24} /> }} />
    <Tab.Screen name="Profile" component={ProfileScreen} options={{ tabBarIcon: ({ color }) => <MaterialIcons name="person" color={color} size={24} /> }} />
  </Tab.Navigator>
);

export default function App() {
  // Modal Presentation Style Configuration
  const modalOptions: StackNavigationOptions = {
    presentation: 'modal',
    cardStyle: { backgroundColor: 'transparent' }, // Allows the overlay to show through
    headerShown: false,
    // Standard animation: slide up from bottom
    // Note: On Android, 'modal' behaves similarly to 'card' by default, 
    // but Expo/React Navigation handles the transition.
  };

  return (
    <NavigationContainer>
      <RootStack.Navigator>
        <RootStack.Screen 
          name="MainTabs" 
          component={TabNavigator} 
          options={{ headerShown: false }} 
        />
        <RootStack.Screen 
          name="EditProfileModal" 
          component={EditProfileModal} 
          options={modalOptions}
        />
      </RootStack.Navigator>
    </NavigationContainer>
  );
}
