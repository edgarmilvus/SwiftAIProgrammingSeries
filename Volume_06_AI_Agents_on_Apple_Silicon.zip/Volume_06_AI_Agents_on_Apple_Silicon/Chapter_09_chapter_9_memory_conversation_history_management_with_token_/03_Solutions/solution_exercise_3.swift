
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

// Reuse ChatMessage, Tokenizer protocol/MockTokenizer, calculateTokenCount from Exercise 1

// 1. MemoryPolicy Enum
enum MemoryPolicy: CaseIterable, CustomStringConvertible { // CaseIterable for UI selection, CustomStringConvertible for easy printing
    case tailTruncation
    case headTruncation
    case summarizationDriven

    var description: String {
        switch self {
        case .tailTruncation: return "Tail Truncation (oldest removed)"
        case .headTruncation: return "Head Truncation (newest removed)"
        case .summarizationDriven: return "Summarization Driven"
        }
    }
}

// 2. SummaryMessage Structure (conforming to ChatMessage for consistency)
struct SummaryMessage: ChatMessage {
    let id = UUID()
    let role: String = "system" // Summaries are often treated as system context
    let content: String
    let timestamp: Date = Date() // Timestamp of when the summary was generated
    let originalTokenCount: Int // To indicate how many tokens it conceptually replaced

    // Override the default content-based token count if the summary has a fixed token value
    // For this mock, we'll let it use its content's token count, but a real summary
    // might have a fixed small token footprint regardless of content length.
    // func summaryTokenCount(using tokenizer: Tokenizer) -> Int { return 10 } // Example fixed token count
}

// 3. Summarizer Protocol and MockSummarizer
protocol Summarizer {
    func summarize(_ messages: [ChatMessage], using tokenizer: Tokenizer) -> SummaryMessage
}

struct MockSummarizer: Summarizer {
    func summarize(_ messages: [ChatMessage], using tokenizer: Tokenizer) -> SummaryMessage {
        let originalContent = messages.map { $0.content }.joined(separator: "\n")
        let originalTokens = tokenizer.countTokens(originalContent)
        let summaryText = "Previous conversation (originally \(originalTokens) tokens) summarized."
        return SummaryMessage(content: summaryText, originalTokenCount: originalTokens)
    }
}

// 4. ContextManager Class
class ContextManager {
    private var messages: [ChatMessage] = [] // The full, untruncated history
    let tokenBudget: Int
    private let tokenizer: Tokenizer
    var currentPolicy: MemoryPolicy
    private let summarizer: Summarizer?

    init(tokenBudget: Int, tokenizer: Tokenizer, initialPolicy: MemoryPolicy, summarizer: Summarizer?) {
        self.tokenBudget = tokenBudget
        self.tokenizer = tokenizer
        self.currentPolicy = initialPolicy
        self.summarizer = summarizer
    }

    func setPolicy(_ newPolicy: MemoryPolicy) {
        self.currentPolicy = newPolicy
    }

    func addMessage(_ newMessage: ChatMessage) {
        messages.append(newMessage)
    }

    func getEffectiveContext() -> [ChatMessage] {
        var currentMessages = messages // Work on a mutable copy
        var currentTokenCount = calculateTokenCount(for: currentMessages, using: tokenizer)

        while currentTokenCount > tokenBudget && !currentMessages.isEmpty {
            switch currentPolicy {
            case .tailTruncation:
                currentMessages.removeFirst()
            case .headTruncation:
                // Remove the newest message (last element)
                currentMessages.removeLast()
            case .summarizationDriven:
                guard let summarizer = self.summarizer else {
                    print("Summarizer not available for summarization-driven policy. Falling back to tail truncation.")
                    currentMessages.removeFirst()
                    break // Exit switch, continue while loop
                }

                // Strategy: Summarize a block of older messages, keeping a few recent ones.
                // For simplicity, let's try to summarize the first half of messages
                // if there are enough messages to make it meaningful.
                let minMessagesToKeepAtEnd = 2 // Always keep the last N messages
                let messagesToSummarizeCount = currentMessages.count - minMessagesToKeepAtEnd
                
                if messagesToSummarizeCount >= 2 { // Ensure there's a block of at least 2 messages to summarize
                    let messagesForSummary = Array(currentMessages.prefix(messagesToSummarizeCount))
                    let summary = summarizer.summarize(messagesForSummary, using: tokenizer)
                    
                    // Remove the summarized messages and insert the summary at the beginning
                    currentMessages.removeFirst(messagesToSummarizeCount)
                    currentMessages.insert(summary, at: 0)
                    
                    // After summarization, re-evaluate the token count. If still over budget,
                    // apply tail truncation to the remaining (non-summary) messages as a fallback.
                    currentTokenCount = calculateTokenCount(for: currentMessages, using: tokenizer)
                    if currentTokenCount > tokenBudget {
                        print("Summarization didn't fully resolve budget. Applying tail truncation to remaining context.")
                        while currentTokenCount > tokenBudget && !currentMessages.isEmpty {
                            currentMessages.removeFirst()
                            currentTokenCount = calculateTokenCount(for: currentMessages, using: tokenizer)
                        }
                    }
                } else {
                    // Not enough messages to summarize or only recent messages left.
                    // Fall back to simple tail truncation to reduce token count.
                    print("Not enough older messages for effective summarization. Falling back to tail truncation.")
                    currentMessages.removeFirst()
                }
            }
            currentTokenCount = calculateTokenCount(for: currentMessages, using: tokenizer)
        }
        return currentMessages
    }
}

// Example Usage (for testing the implementation)
/*
let tokenizer = MockTokenizer()
let mockSummarizer = MockSummarizer()
let contextManager = ContextManager(tokenBudget: 50, tokenizer: tokenizer, initialPolicy: .tailTruncation, summarizer: mockSummarizer)

// Add some initial system message (e.g., instructions for the AI)
contextManager.addMessage(ChatMessage(role: "system", content: "You are SwiftBuddy, an expert Swift developer. Always provide concise code examples.", timestamp: Date().addingTimeInterval(-500))) // ~20 tokens

contextManager.addMessage(ChatMessage(role: "user", content: "How do I use async/await in a SwiftUI view?", timestamp: Date().addingTimeInterval(-480))) // ~15 tokens
contextManager.addMessage(ChatMessage(role: "assistant", content: "You can use a Task modifier. For example: Task { await fetchData() }", timestamp: Date().addingTimeInterval(-460))) // ~18 tokens
contextManager.addMessage(ChatMessage(role: "user", content: "What about error handling with async/await?", timestamp: Date().addingTimeInterval(-440))) // ~10 tokens
contextManager.addMessage(ChatMessage(role: "assistant", content: "Use do-catch blocks for error handling. func load() async throws { ... }", timestamp: Date().addingTimeInterval(-420))) // ~15 tokens
contextManager.addMessage(ChatMessage(role: "user", content: "Can you provide a full example of an async function loading data?", timestamp: Date().addingTimeInterval(-400))) // ~15 tokens
contextManager.addMessage(ChatMessage(role: "assistant", content: "Sure, here's a basic example fetching data from a URLSession.", timestamp: Date().addingTimeInterval(-380))) // ~15 tokens
contextManager.addMessage(ChatMessage(role: "user", content: "That's great, thank you! I'm now trying to integrate Core Data with SwiftData. What's the best way to migrate existing Core Data models to SwiftData?", timestamp: Date().addingTimeInterval(-360))) // ~30 tokens (long message)


print("--- Context with \(contextManager.currentPolicy.description) (Budget: 50 tokens) ---")
var effectiveContext = contextManager.getEffectiveContext()
print("Effective context tokens: \(calculateTokenCount(for: effectiveContext, using: tokenizer))")
effectiveContext.forEach { print("- \($0.role): \($0.content.prefix(50))...") }

contextManager.setPolicy(.headTruncation)
print("\n--- Context with \(contextManager.currentPolicy.description) (Budget: 50 tokens) ---")
effectiveContext = contextManager.getEffectiveContext()
print("Effective context tokens: \(calculateTokenCount(for: effectiveContext, using: tokenizer))")
effectiveContext.forEach { print("- \($0.role): \($0.content.prefix(50))...") }

contextManager.setPolicy(.summarizationDriven)
print("\n--- Context with \(contextManager.currentPolicy.description) (Budget: 50 tokens) ---")
effectiveContext = contextManager.getEffectiveContext()
print("Effective context tokens: \(calculateTokenCount(for: effectiveContext, using: tokenizer))")
effectiveContext.forEach { print("- \($0.role): \($0.content.prefix(50))...") }
// Observe how a SummaryMessage replaces older messages, and then tail truncation might occur if still over budget.
*/
