
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Example of an AppIntent for summarization
import AppIntents
import Foundation // For String

@available(iOS 18.0, *)
struct SummarizeTextIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize Text"
    static var description = IntentDescription("Summarizes the provided text using on-device intelligence.")

    @Parameter(title: "Text to Summarize", description: "The content that needs to be summarized.")
    var text: String

    // The result type for this intent
    static var parameterDialog: ParameterDialog {
        // Customize the dialog presented to the user for parameter input if needed
        // For example, if 'text' is optional and we want to prompt the user.
        ParameterDialog("What text would you like to summarize?")
    }

    // The actual work of the intent is performed here
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        // In a real scenario, this would interact with Apple's TextGenerationService
        // or a similar Writing Tools API for summarization.
        // For demonstration, we'll simulate a summarization.

        // Reference to previous chapter concept:
        // Instead of directly calling a low-level TextGenerationService API
        // as we might have done in Chapter X for basic inference,
        // App Intents provide a structured, system-integrated way to expose this capability.
        // The underlying call might still be to TextGenerationService,
        // but the intent abstracts it for system interaction.

        guard !text.isEmpty else {
            throw SummarizationError.emptyText
        }

        // Simulate an asynchronous call to an on-device LLM for summarization
        let summarizedContent = await simulateSummarization(for: text)

        return .result(value: summarizedContent)
    }
}

@available(iOS 18.0, *)
enum SummarizationError: LocalizedError {
    case emptyText

    var errorDescription: String? {
        switch self {
        case .emptyText:
            return "Cannot summarize empty text. Please provide some content."
        }
    }
}

// A helper function to simulate the AI call
@available(iOS 18.0, *)
fileprivate func simulateSummarization(for text: String) async -> String {
    // In a real app, this would use TextGenerationService or WritingTools
    // For example:
    // let service = TextGenerationService.shared
    // let summary = try await service.summarize(text)
    // return summary

    try? await Task.sleep(for: .seconds(1.5)) // Simulate network/processing delay
    let words = text.split(separator: " ")
    guard words.count > 10 else {
        return text // Too short to summarize meaningfully
    }
    let summaryWords = words.prefix(words.count / 3).joined(separator: " ") + "..."
    return "Summary: \(summaryWords)"
}
