
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor EvaluationReportStore {
    private var reports: [String: EvaluationReport] = [:] // Key: iteration ID, Value: report

    /// Adds or updates an evaluation report for a given iteration.
    func addReport(forIteration iterationID: String, report: EvaluationReport) {
        reports[iterationID] = report
        print("Stored report for iteration \(iterationID). Total reports: \(reports.count)")
    }

    /// Retrieves an evaluation report for a specific iteration.
    func getReport(forIteration iterationID: String) -> EvaluationReport? {
        reports[iterationID]
    }

    /// Retrieves all stored reports.
    func getAllReports() -> [String: EvaluationReport] {
        reports
    }
    
    /// Clears all stored reports.
    func clearReports() {
        reports.removeAll()
        print("All reports cleared.")
    }
}

// Example Usage:
@available(iOS 18.0, *)
func demonstrateActorUsage() async {
    let store = EvaluationReportStore()
    
    // Simulate multiple evaluations happening concurrently
    await withTaskGroup(of: Void.self) { group in
        for i in 1...3 {
            group.addTask {
                let report = EvaluationReport(
                    accuracy: Double.random(in: 0.8...0.95),
                    precision: Double.random(in: 0.75...0.9),
                    recall: Double.random(in: 0.7...0.85)
                )
                await store.addReport(forIteration: "Iteration_\(i)", report: report)
            }
        }
    }
    
    // Retrieve reports safely
    let allReports = await store.getAllReports()
    print("\n--- All Stored Reports ---")
    for (id, report) in allReports {
        print("\(id): \(report)")
    }
    
    // Clear reports
    await store.clearReports()
    let clearedReports = await store.getAllReports()
    print("Reports after clearing: \(clearedReports.isEmpty)")
}
