/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

// hooks/useUniversalChat.ts
// TODO: Create a custom hook to handle AI chat logic.
// It should accept an API endpoint URL.
// If running on native, ensure it handles the response stream correctly (if applicable).
// Return: { messages, input, handleInputChange, handleSubmit, isLoading }

// screens/ChatScreen.tsx
import { View, TextInput, FlatList, Text, KeyboardAvoidingView } from 'react-native';
// TODO: Import your useUniversalChat hook.
// TODO: Implement the ChatScreen.
// 1. Use KeyboardAvoidingView to handle the keyboard on iOS/Android.
// 2. Render the list of messages using FlatList.
// 3. Connect the TextInput to the hook's input state.
// 4. Handle the "Send" button press via the hook's handleSubmit.
