
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import CoreML
import Vision // For CVPixelBuffer conversion

// MARK: - Helper: UIImage to CVPixelBuffer Conversion (reused from Exercise 1)
extension UIImage {
    func toCVPixelBuffer(width: Int, height: Int, pixelFormatType: OSType) -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        let attributes: [NSObject: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue!,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ]

        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormatType,
                                         attributes as CFDictionary,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess, let finalPixelBuffer = pixelBuffer else {
            print("Failed to create CVPixelBuffer: \(status)")
            return nil
        }

        CVPixelBufferLockBaseAddress(finalPixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(finalPixelBuffer, .readOnly) }

        let pixelData = CVPixelBufferGetBaseAddress(finalPixelBuffer)
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()

        guard let context = CGContext(data: pixelData,
                                      width: width,
                                      height: height,
                                      bitsPerComponent: 8,
                                      bytesPerRow: CVPixelBufferGetBytesPerRow(finalPixelBuffer),
                                      space: rgbColorSpace,
                                      bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue) else {
            print("Failed to create CGContext for CVPixelBuffer.")
            return nil
        }

        context.translateBy(x: 0, y: CGFloat(height))
        context.scaleBy(x: 1.0, y: -1.0)

        UIGraphicsPushContext(context)
        self.draw(in: CGRect(x: 0, y: 0, width: width, height: height))
        UIGraphicsPopContext()

        return finalPixelBuffer
    }
}

// MARK: - PlantClassifier (Assumed auto-generated Core ML model interface, reused from Exercise 1)
// We'll use the same mock interface for input/output, but the actual model would be loaded.
struct PlantClassifierInput : MLFeatureProvider {
    var image: CVPixelBuffer

    var featureNames: Set<String> { return ["image"] }
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "image" { return MLFeatureValue(pixelBuffer: image) }
        return nil
    }
}

struct PlantClassifierOutput : MLFeatureProvider {
    var classLabel: String
    var classLabelProbs: [String : Double]

    var featureNames: Set<String> { return ["classLabel", "classLabelProbs"] }
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "classLabel" { return MLFeatureValue(string: classLabel) }
        if featureName == "classLabelProbs" { return MLFeatureValue(dictionary: classLabelProbs as [AnyHashable : NSNumber]) }
        return nil
    }
}

// Mock MLModel class for demonstration.
class PlantClassifier {
    let model: MLModel
    let modelInputWidth = 224
    let modelInputHeight = 224
    let modelPixelFormat = kCVPixelFormatType_32BGRA
    let classLabels = ["Sunflower", "Rose", "Tulip", "Orchid", "Lily"] // Example labels

    init() throws {
        // In a real app, load your model:
        let url = Bundle.main.url(forResource: "PlantClassifier", withExtension: "mlmodelc")!
        self.model = try MLModel(contentsOf: url)
    }

    // Mock for individual prediction
    func prediction(input: PlantClassifierInput) throws -> PlantClassifierOutput {
        // In a real app, call the underlying MLModel's prediction method
        // let predictionOutput = try model.prediction(from: input)
        // return PlantClassifierOutput(classLabel: predictionOutput.classLabel, classLabelProbs: predictionOutput.classLabelProbs)

        // For mock, return a random but consistent prediction
        let randomLabel = classLabels.randomElement()!
        var probs: [String: Double] = [:]
        for label in classLabels {
            probs[label] = label == randomLabel ? 0.9 : 0.025 // Simple distribution
        }
        return PlantClassifierOutput(classLabel: randomLabel, classLabelProbs: probs)
    }

    // Mock for batch prediction (Core ML's predictions(inputs:options:))
    func predictions(inputs: MLArrayBatchProvider, options: MLPredictionOptions) throws -> MLBatchProvider {
        // In a real app, call the underlying MLModel's batch prediction method
        // return try model.predictions(from: inputs, options: options)

        // For mock, simulate batch processing
        var outputs: [MLFeatureProvider] = []
        for i in 0..<inputs.count {
            if let inputProvider = inputs.features(at: i) as? PlantClassifierInput {
                let output = try prediction(input: inputProvider) // Use individual mock for each item
                outputs.append(output)
            }
        }
        return MLArrayBatchProvider(featureProviderArray: outputs)
    }
}

// MARK: - Image Gallery Organizer Service
class ImageGalleryOrganizerService {
    private var plantClassifier: PlantClassifier?

    init() {
        do {
            plantClassifier = try PlantClassifier()
            print("PlantClassifier model loaded successfully for batch processing.")
        } catch {
            print("Error loading PlantClassifier model: \(error)")
        }
    }

    /// Generates an array of placeholder UIImages for testing.
    func generatePlaceholderImages(count: Int) -> [UIImage] {
        var images: [UIImage] = []
        for i in 0..<count {
            let size = CGSize(width: 224, height: 224)
            UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
            let context = UIGraphicsGetCurrentContext()!

            // Draw a simple colored square with a number
            let color: UIColor
            switch i % 3 {
            case 0: color = .red
            case 1: color = .green
            case 2: color = .blue
            default: color = .gray
            }
            color.setFill()
            context.fill(CGRect(origin: .zero, size: size))

            let text = "\(i + 1)"
            let attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 50),
                .foregroundColor: UIColor.white
            ]
            let textSize = text.size(withAttributes: attributes)
            let textRect = CGRect(x: (size.width - textSize.width) / 2, y: (size.height - textSize.height) / 2, width: textSize.width, height: textSize.height)
            text.draw(in: textRect, withAttributes: attributes)

            if let image = UIGraphicsGetImageFromCurrentImageContext() {
                images.append(image)
            }
            UIGraphicsEndImageContext()
        }
        return images
    }

    /// Performs batch classification on an array of UIImages.
    /// - Parameters:
    ///   - images: An array of UIImages to classify.
    ///   - completion: A closure to call with the results and performance metrics.
    func classifyImagesBatch(images: [UIImage], completion: @escaping (Result<([String], TimeInterval), Error>) -> Void) {
        guard let classifier = plantClassifier else nil {
            completion(.failure(BatchPredictionError.modelNotLoaded))
            return
        }

        DispatchQueue.global(qos: .userInitiated).async {
            let startTime = CFAbsoluteTimeGetCurrent()
            var inputProviders: [MLFeatureProvider] = []

            for image in images {
                guard let pixelBuffer = image.toCVPixelBuffer(width: classifier.modelInputWidth, height: classifier.modelInputHeight, pixelFormatType: classifier.modelPixelFormat) else {
                    DispatchQueue.main.async { completion(.failure(BatchPredictionError.imageConversionFailed)) }
                    return
                }
                inputProviders.append(PlantClassifierInput(image: pixelBuffer))
            }

            let batchInput = MLArrayBatchProvider(featureProviderArray: inputProviders)
            let options = MLPredictionOptions()
            options.usesCPUOnly = false // Use GPU/Neural Engine if available

            do {
                let batchOutput = try classifier.predictions(inputs: batchInput, options: options)

                var results: [String] = []
                for i in 0..<batchOutput.count {
                    if let outputProvider = batchOutput.features(at: i) as? PlantClassifierOutput {
                        results.append(outputProvider.classLabel)
                    }
                }
                let endTime = CFAbsoluteTimeGetCurrent()
                let duration = endTime - startTime

                DispatchQueue.main.async {
                    completion(.success((results, duration)))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(BatchPredictionError.predictionFailed(error)))
                }
            }
        }
    }

    /// Performs sequential individual classification on an array of UIImages.
    /// - Parameters:
    ///   - images: An array of UIImages to classify.
    ///   - completion: A closure to call with the results and performance metrics.
    func classifyImagesSequentially(images: [UIImage], completion: @escaping (Result<([String], TimeInterval), Error>) -> Void) {
        guard let classifier = plantClassifier else {
            completion(.failure(BatchPredictionError.modelNotLoaded))
            return
        }

        DispatchQueue.global(qos: .userInitiated).async {
            let startTime = CFAbsoluteTimeGetCurrent()
            var results: [String] = []

            for image in images {
                guard let pixelBuffer = image.toCVPixelBuffer(width: classifier.modelInputWidth, height: classifier.modelInputHeight, pixelFormatType: classifier.modelPixelFormat) else {
                    DispatchQueue.main.async { completion(.failure(BatchPredictionError.imageConversionFailed)) }
                    return
                }
                let input = PlantClassifierInput(image: pixelBuffer)
                do {
                    let output = try classifier.prediction(input: input)
                    results.append(output.classLabel)
                } catch {
                    DispatchQueue.main.async { completion(.failure(BatchPredictionError.predictionFailed(error))) }
                    return
                }
            }
            let endTime = CFAbsoluteTimeGetCurrent()
            let duration = endTime - startTime

            DispatchQueue.main.async {
                completion(.success((results, duration)))
            }
        }
    }

    enum BatchPredictionError: Error, LocalizedError {
        case modelNotLoaded
        case imageConversionFailed
        case predictionFailed(Error)

        var errorDescription: String? {
            switch self {
            case .modelNotLoaded: return "The Core ML model could not be loaded."
            case .imageConversionFailed: return "Failed to convert image to the required pixel buffer format."
            case .predictionFailed(let error): return "Prediction failed: \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - Example Usage (e.g., in a ViewController)
/*
class ViewController: UIViewController {
    let organizerService = ImageGalleryOrganizerService()
    let numberOfImages = 50

    override func viewDidLoad() {
        super.viewDidLoad()

        let imagesToClassify = organizerService.generatePlaceholderImages(count: numberOfImages)
        print("Generated \(imagesToClassify.count) images.")

        // Perform sequential classification
        organizerService.classifyImagesSequentially(images: imagesToClassify) { result in
            switch result {
            case .success(let (labels, duration)):
                print("\n--- Sequential Classification Results ---")
                print("Total images: \(labels.count)")
                print("Time taken: \(String(format: "%.4f", duration)) seconds")
                // for (index, label) in labels.enumerated() {
                //     print("Image \(index + 1): \(label)")
                // }
            case .failure(let error):
                print("Sequential classification error: \(error.localizedDescription)")
            }

            // Perform batch classification after sequential is done
            self.organizerService.classifyImagesBatch(images: imagesToClassify) { batchResult in
                switch batchResult {
                case .success(let (labels, duration)):
                    print("\n--- Batch Classification Results ---")
                    print("Total images: \(labels.count)")
                    print("Time taken: \(String(format: "%.4f", duration)) seconds")
                    // for (index, label) in labels.enumerated() {
                    //     print("Image \(index + 1): \(label)")
                    // }
                    print("\n--- Performance Comparison ---")
                    // You would compare durations here
                case .failure(let error):
                    print("Batch classification error: \(error.localizedDescription)")
                }
            }
        }
    }
}
*/
