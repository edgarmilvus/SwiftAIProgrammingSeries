
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// No Package.swift needed for core Apple frameworks like AppleIntelligence.
// It's part of the SDK on iOS 18+.

import UIKit
import AppleIntelligence // This framework provides AIWritingToolsService

// MARK: - Error Handling

/// Custom error types for the SmartWritingTextView.
/// These errors provide specific context for issues encountered during AI writing tool operations.
enum SmartWritingError: Error, LocalizedError {
    case noTextSelected
    case writingToolsUnavailable
    case serviceError(AIWritingToolsServiceError)
    case noSuggestionsFound
    case invalidTextRange

    /// Provides a localized description for each error case, suitable for user-facing alerts.
    var errorDescription: String? {
        switch self {
        case .noTextSelected:
            return "No text is currently selected for rewriting. Please select some text first."
        case .writingToolsUnavailable:
            return "Apple Intelligence Writing Tools are not available on this device or iOS version. Please ensure your device supports Apple Intelligence and is running iOS 18 or later."
        case .serviceError(let aiError):
            // The AIWritingToolsServiceError itself provides a localized description.
            return "Writing Tools Service Error: \(aiError.localizedDescription)"
        case .noSuggestionsFound:
            return "No rewrite suggestions were generated for the selected text. Please try again with different text."
        case .invalidTextRange:
            return "An internal error occurred with the selected text range. Please try again."
        }
    }
}

// MARK: - SmartWritingTextView: An Advanced Writing Canvas

/// A `UITextView` subclass that integrates Apple Intelligence Writing Tools
/// to provide advanced text rewriting suggestions based on user selection and desired tone.
///
/// This component demonstrates how to:
/// 1. Initialize and use `AIWritingToolsService`.
/// 2. Integrate custom actions into the `UIEditMenuInteraction` for selected text.
/// 3. Construct `AIWritingToolsRequest` with `RewriteOptions` to specify tone.
/// 4. Handle asynchronous AI service calls using Swift concurrency (`async`/`await`).
/// 5. Process `AIWritingToolsResult` and present suggestions to the user.
/// 6. Implement robust error handling for AI operations.
@available(iOS 18.0, *)
class SmartWritingTextView: UITextView, UIEditMenuInteractionDelegate {

    // MARK: - Properties

    /// The core service for interacting with Apple Intelligence Writing Tools.
    /// This service is responsible for performing all AI-powered text operations.
    private let writingToolsService = AIWritingToolsService()

    /// An interaction object that manages the presentation and dismissal of a menu.
    /// Used here to provide custom rewrite actions when text is selected by the user.
    private lazy var editMenuInteraction: UIEditMenuInteraction = {
        let interaction = UIEditMenuInteraction(delegate: self)
        return interaction
    }()

    // MARK: - Initialization

    override init(frame: CGRect, textContainer: NSTextContainer?) {
        super.init(frame: frame, textContainer: textContainer)
        setupTextView()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupTextView()
    }

    /// Configures the text view and adds the edit menu interaction.
    /// This method performs initial setup and checks for AI tool availability.
    private func setupTextView() {
        // Essential check: If writing tools are not available, we shouldn't add the interaction
        // or offer AI features. In a production app, you might disable the feature's UI.
        guard writingToolsService.isAvailable else {
            print("Apple Intelligence Writing Tools are not available on this device. Disabling Smart Rewrite features.")
            return
        }
        // Add the custom edit menu interaction to the text view.
        addInteraction(editMenuInteraction)

        // Basic text view configuration for a good user experience.
        font = UIFont.preferredFont(forTextStyle: .body)
        isEditable = true // Allow user to type and edit.
        isSelectable = true // Allow user to select text for AI operations.
        allowsEditingTextAttributes = true // Support rich text editing.
        textContainerInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16) // Padding
    }

    // MARK: - UIEditMenuInteractionDelegate

    /// Defines the configuration for the edit menu when text is selected.
    /// This is where we inject our custom "Smart Rewrite" actions into the standard text selection menu.
    /// - Parameters:
    ///   - interaction: The `UIEditMenuInteraction` requesting the configuration.
    ///   - location: The location in the view's coordinate system where the menu is being presented.
    ///   - suggestedActions: An array of `UIMenuElement` objects suggested by the system (e.g., Copy, Paste).
    /// - Returns: A `UIEditMenuConfiguration` containing the menu elements, or `nil` if no custom menu should be shown.
    func editMenuInteraction(_ interaction: UIEditMenuInteraction,
                             configurationForMenuAtLocation location: CGPoint,
                             suggestedActions: [UIMenuElement]) -> UIEditMenuConfiguration? {

        // Only show our custom actions if there is text currently selected.
        guard let selectedText = self.selectedText, !selectedText.isEmpty else {
            return nil // Return nil to show default menu (if any) or no menu if no text selected.
        }

        // Create custom actions for different rewrite tones.
        // Each action triggers `performSmartRewrite` with a specific tone option.
        let professionalAction = UIAction(title: "Rewrite: Professional", image: UIImage(systemName: "person.text.rectangle.fill")) { [weak self] _ in
            self?.performSmartRewrite(tone: .professional)
        }
        let creativeAction = UIAction(title: "Rewrite: Creative", image: UIImage(systemName: "lightbulb.fill")) { [weak self] _ in
            self?.performSmartRewrite(tone: .creative)
        }
        let casualAction = UIAction(title: "Rewrite: Casual", image: UIImage(systemName: "face.smiling.fill")) { [weak self] _ in
            self?.performSmartRewrite(tone: .casual)
        }
        let conciseAction = UIAction(title: "Rewrite: Concise", image: UIImage(systemName: "text.alignleft")) { [weak self] _ in
            self?.performSmartRewrite(tone: .concise)
        }
        let elaborateAction = UIAction(title: "Rewrite: Elaborate", image: UIImage(systemName: "text.alignright")) { [weak self] _ in
            self?.performSmartRewrite(tone: .elaborate)
        }

        // Group our custom actions into a submenu for better organization within the edit menu.
        let rewriteMenu = UIMenu(title: "Smart Rewrite", image: UIImage(systemName: "wand.and.stars"), children: [
            professionalAction,
            creativeAction,
            casualAction,
            conciseAction,
            elaborateAction
        ])

        // Combine the system's suggested actions with our custom rewrite menu.
        // We append our menu to keep standard actions accessible.
        let combinedActions = suggestedActions + [rewriteMenu]

        // Return a configuration for the edit menu, including our custom actions.
        return UIEditMenuConfiguration(identifier: "SmartRewriteMenu", sourcePoint: location, elements: combinedActions)
    }

    // MARK: - Core Logic: Performing Smart Rewrite

    /// Initiates a smart rewrite operation for the currently selected text
    /// using Apple Intelligence Writing Tools, with a specified tone.
    /// This method demonstrates how to construct and execute an advanced AI request.
    /// - Parameter tone: The desired tone for the rewritten text, influencing the AI's output style.
    private func performSmartRewrite(tone: AIWritingToolsRequest.RewriteOptions.Tone) {
        // First, check if Apple Intelligence Writing Tools are actually available.
        guard writingToolsService.isAvailable else {
            presentError(SmartWritingError.writingToolsUnavailable)
            return
        }

        // Ensure there is selected text to perform the rewrite on.
        guard let selectedRange = self.selectedTextRange,
              let selectedText = self.text(in: selectedRange),
              !selectedText.isEmpty else {
            presentError(SmartWritingError.noTextSelected)
            return
        }

        // Capture the original `NSRange` of the selected text. This is crucial
        // for later replacing the text accurately after the AI provides suggestions.
        let originalNSRange = self.selectedRange

        // Construct the rewrite request with advanced options.
        // `AIWritingToolsRequest.RewriteOptions` allows specifying parameters like `tone`.
        let rewriteOptions = AIWritingToolsRequest.RewriteOptions(tone: tone)
        let request = AIWritingToolsRequest.rewrite(text: selectedText, options: rewriteOptions)

        // Perform the request asynchronously using a Swift `Task`.
        // This keeps the UI responsive while the AI service processes the request.
        Task {
            do {
                // Await the result from the AI Writing Tools Service.
                let result = try await writingToolsService.perform(request)

                // Ensure the result type is indeed a rewrite result.
                guard case let .rewrite(rewriteResult) = result else {
                    throw SmartWritingError.noSuggestionsFound // Unexpected result type.
                }

                // Extract suggestions; if none, throw an error.
                guard let suggestions = rewriteResult.suggestions, !suggestions.isEmpty else {
                    throw SmartWritingError.noSuggestionsFound
                }

                // Present suggestions to the user on the main thread.
                // In a production app, this might be a more sophisticated custom popover
                // with previews, but an alert serves for demonstration.
                await MainActor.run {
                    self.presentSuggestions(suggestions, originalRange: originalNSRange)
                }

            } catch let serviceError as AIWritingToolsServiceError {
                // Handle specific errors from the AIWritingToolsService.
                await MainActor.run {
                    self.presentError(SmartWritingError.serviceError(serviceError))
                }
            } catch {
                // Handle any other unexpected errors during the process.
                await MainActor.run {
                    self.presentError(error)
                }
            }
        }
    }

    // MARK: - UI Presentation Helpers

    /// Presents a list of rewrite suggestions to the user in an action sheet.
    /// The user can select a suggestion to replace the original text.
    /// - Parameters:
    ///   - suggestions: An array of `AIWritingToolsResult.RewriteSuggestion` objects from the AI.
    ///   - originalRange: The `NSRange` of the text that was originally selected for rewriting.
    private func presentSuggestions(_ suggestions: [AIWritingToolsResult.RewriteSuggestion], originalRange: NSRange) {
        let alertController = UIAlertController(
            title: "Rewrite Suggestions",
            message: "Choose a suggestion to replace the selected text:",
            preferredStyle: .actionSheet
        )

        // Add an action for each suggestion provided by the AI.
        for suggestion in suggestions {
            let action = UIAlertAction(title: suggestion.text, style: .default) { [weak self] _ in
                guard let self = self else { return }
                // Apply the selected suggestion to the text view on user tap.
                self.replaceText(in: originalRange, with: suggestion.text)
            }
            alertController.addAction(action)
        }

        // Always provide a cancel option.
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))

        // Find the topmost view controller to present the alert correctly.
        if let presentingVC = findTopmostViewController() {
            presentingVC.present(alertController, animated: true, completion: nil)
        } else {
            print("Error: Could not find a view controller to present suggestions.")
        }
    }

    /// Replaces the text within a given `NSRange` with new text.
    /// This method ensures the text view's content is updated and the new text is selected.
    /// - Parameters:
    ///   - range: The `NSRange` of the text to be replaced.
    ///   - newText: The new text to insert in place of the old text.
    private func replaceText(in range: NSRange, with newText: String) {
        // Convert `NSRange` to `UITextRange` which is required by `UITextView`'s `replace` method.
        guard let textRange = textRange(from: range) else {
            print("Error: Could not convert NSRange to UITextRange for replacement.")
            presentError(SmartWritingError.invalidTextRange)
            return
        }
        self.replace(textRange, withText: newText)

        // After replacement, select the newly inserted text to provide visual feedback.
        let newSelectionStart = self.position(from: beginningOfDocument, offset: range.location)!
        let newSelectionEnd = self.position(from: newSelectionStart, offset: newText.count)!
        self.selectedTextRange = self.textRange(from: newSelectionStart, to: newSelectionEnd)
    }

    /// Presents an error message to the user using a `UIAlertController`.
    /// - Parameter error: The `Error` object to present, whose `localizedDescription` will be shown.
    private func presentError(_ error: Error) {
        let alertController = UIAlertController(
            title: "Error",
            message: error.localizedDescription,
            preferredStyle: .alert
        )
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))

        // Find the topmost view controller to present the alert correctly.
        if let presentingVC = findTopmostViewController() {
            presentingVC.present(alertController, animated: true, completion: nil)
        } else {
            print("Error: Could not find a view controller to present error: \(error.localizedDescription)")
        }
    }

    /// Helper to find the topmost view controller in the current window scene.
    /// This is a common pattern for presenting UI from non-view controller classes.
    /// - Returns: The currently visible `UIViewController`, or `nil` if one cannot be found.
    private func findTopmostViewController() -> UIViewController? {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let rootViewController = windowScene.windows.first(where: { $0.isKeyWindow })?.rootViewController else {
            return nil
        }

        var topController = rootViewController
        while let presentedVC = topController.presentedViewController {
            topController = presentedVC
        }
        return topController
    }
}

// MARK: - NSRange to UITextRange Conversion Helper

/// Extension to `UITextInput` to facilitate conversion between `NSRange` and `UITextRange`.
/// This is a common utility needed when working with `UITextView`'s text manipulation methods,
/// as `NSRange` is often used for string operations, while `UITextRange` is used for text input views.
extension UITextInput {
    /// Converts an `NSRange` to a `UITextRange`.
    /// - Parameter range: The `NSRange` to convert.
    /// - Returns: A `UITextRange` corresponding to the `NSRange`, or `nil` if the conversion fails
    ///            (e.g., if the range is out of bounds).
    func textRange(from range: NSRange) -> UITextRange? {
        // Get the starting position from the beginning of the document.
        guard let start = position(from: beginningOfDocument, offset: range.location) else {
            return nil
        }
        // Get the ending position by advancing from the start position by the length of the range.
        guard let end = position(from: start, offset: range.length) else {
            return nil
        }
        // Create and return the `UITextRange`.
        return textRange(from: start, to: end)
    }
}

// MARK: - Example Usage (within a UIViewController)

/*
/// Example `UIViewController` demonstrating how to integrate `SmartWritingTextView`.
/// This controller would typically be part of a document editor, notes app, or messaging interface.
@available(iOS 18.0, *)
class DocumentEditorViewController: UIViewController {

    /// The custom text view instance with Apple Intelligence capabilities.
    private let smartTextView = SmartWritingTextView()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Smart Document Editor" // Set a title for the navigation bar.
        setupSmartTextView()

        // Provide some initial text for demonstration purposes.
        smartTextView.text = "The quick brown fox jumps over the lazy dog. This is a sentence that could be improved. We need to make it more engaging and perhaps a bit more concise. I am writing this text to test the new Apple Intelligence features."

        // Optionally, set a default selection to immediately test the feature.
        // smartTextView.selectedRange = NSRange(location: 40, length: 30) // Select "This is a sentence that could be improved."
    }

    /// Configures and lays out the `SmartWritingTextView` within the view controller.
    private func setupSmartTextView() {
        smartTextView.translatesAutoresizingMaskIntoConstraints = false
        smartTextView.layer.borderColor = UIColor.systemGray3.cgColor
        smartTextView.layer.borderWidth = 1.0
        smartTextView.layer.cornerRadius = 8.0
        smartTextView.backgroundColor = .secondarySystemBackground // Differentiate from background.

        view.addSubview(smartTextView)

        // Set up Auto Layout constraints for the text view.
        NSLayoutConstraint.activate([
            smartTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            smartTextView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            smartTextView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            smartTextView.heightAnchor.constraint(equalToConstant: 300) // Fixed height for example, could be dynamic.
        ])
    }
}

// To integrate this into an Xcode project:
// 1. Create a new iOS project (ensure target is iOS 18.0 or later).
// 2. Replace the content of a ViewController (e.g., ViewController.swift) with the above code.
// 3. In your `SceneDelegate.swift` (for SwiftUI App Lifecycle) or `AppDelegate.swift` (for UIKit App Delegate),
//    set `DocumentEditorViewController` as the root view controller.
//
//    Example for SceneDelegate.swift:
//    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
//        guard let windowScene = (scene as? UIWindowScene) else { return }
//        let window = UIWindow(windowScene: windowScene)
//        window.rootViewController = UINavigationController(rootViewController: DocumentEditorViewController()) // Embed in navigation controller for title.
//        self.window = window
//        window.makeKeyAndVisible()
//    }
*/
