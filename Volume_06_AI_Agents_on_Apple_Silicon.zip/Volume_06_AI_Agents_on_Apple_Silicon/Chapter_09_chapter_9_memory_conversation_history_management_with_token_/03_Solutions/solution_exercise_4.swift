
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

@available(macOS 14.0, iOS 18.0, *) // Adjust platform availability as per llama.cpp.swift support
import Foundation
import llama_cpp // From Package.swift dependency

// Reuse ChatMessage from Exercise 1

// 2. LlamaTokenizerWrapper (Mocked for easier exercise setup)
// In a real application, this would wrap llama_cpp.LlamaTokenizer
// and require a LlamaContext initialized with a .gguf model.
struct LlamaTokenizerWrapper: Tokenizer { // Conforms to Tokenizer from Exercise 1
    // Using MockTokenizer internally for simplicity in this exercise.
    // In a real app, you'd initialize and hold a llama_cpp.LlamaTokenizer instance.
    private let internalMockTokenizer = MockTokenizer() 

    // For a real llama.cpp integration, this init would take a LlamaContext
    // or an already initialized llama_cpp.LlamaTokenizer.
    // Example for real llama.cpp (requires a tiny .gguf model file):
    /*
    private let realLlamaTokenizer: llama_cpp.LlamaTokenizer
    init(context: LlamaContext) throws {
        self.realLlamaTokenizer = try llama_cpp.LlamaTokenizer(context: context)
    }
    */
    init() {
        // No-op for mock, or complex real LlamaContext/LlamaTokenizer setup.
    }
    
    func tokenize(_ text: String) -> [Int] {
        // In a real app: return try realLlamaTokenizer.tokenize(text: text)
        return internalMockTokenizer.tokenize(text)
    }

    func countTokens(_ text: String) -> Int {
        // In a real app: do { return try realLlamaTokenizer.tokenize(text: text).count } catch { return 0 }
        return internalMockTokenizer.countTokens(text)
    }
}

// 3. AsyncTokenBudgetManager Actor
actor AsyncTokenBudgetManager {
    private var messages: [ChatMessage] = []
    let tokenBudget: Int
    private let tokenizer: LlamaTokenizerWrapper
    private var currentTotalTokens: Int = 0

    init(tokenBudget: Int, tokenizer: LlamaTokenizerWrapper) {
        self.tokenBudget = tokenBudget
        self.tokenizer = tokenizer
    }

    // Helper to perform token calculation and truncation asynchronously.
    // This method is internal to the actor and ensures its state is consistent.
    private func recalculateAndTruncate() async {
        // Offload the potentially CPU-intensive token counting and truncation
        // to a detached task. This prevents blocking the actor's executor,
        // allowing other actor calls to be processed concurrently if they don't
        // depend on the mutable state being updated here.
        let (newMessages, newTotalTokens) = await Task.detached { [tokenizer, tokenBudget] in
            // Capture `messages` by value from the actor's isolated state
            // to work on a snapshot. This avoids re-accessing `self.messages`
            // within the detached task, which would require `await` calls back
            // to the actor, potentially causing deadlocks or performance issues.
            var tempMessages = self.messages
            var tokens = 0
            
            // Calculate initial token count for the snapshot
            for msg in tempMessages {
                tokens += tokenizer.countTokens(msg.content)
            }

            // Truncate if necessary (tail truncation strategy)
            while tokens > tokenBudget && !tempMessages.isEmpty {
                tempMessages.removeFirst() // Remove the oldest message
                tokens = 0 // Recalculate after removal (can be optimized by subtracting removed message's tokens)
                for msg in tempMessages {
                    tokens += tokenizer.countTokens(msg.content)
                }
            }
            return (tempMessages, tokens)
        }.value // Await the result of the detached task
        
        // Once the background work is done, update the actor's isolated state.
        self.messages = newMessages
        self.currentTotalTokens = newTotalTokens
    }

    func addMessage(_ newMessage: ChatMessage) async {
        messages.append(newMessage) // Modify isolated state
        await recalculateAndTruncate() // Trigger asynchronous recalculation and truncation
    }

    func getEffectiveContext() async -> [ChatMessage] {
        await recalculateAndTruncate() // Ensure context is up-to-date before returning
        return messages // Return isolated state
    }

    func getCurrentTokenCount() async -> Int {
        await recalculateAndTruncate() // Ensure count is up-to-date before returning
        return currentTotalTokens // Return isolated state
    }
}

// Example Usage (for testing the implementation)
@available(macOS 14.0, iOS 18.0, *)
func runAsyncTokenBudgetManagerExample() async {
    // For this exercise, we use the mocked LlamaTokenizerWrapper.
    // In a real app, you'd have a properly initialized llama_cpp.LlamaTokenizer instance
    // (e.g., loaded from a tiny GGUF model once at app startup).
    let tokenizer = LlamaTokenizerWrapper() 
    let manager = AsyncTokenBudgetManager(tokenBudget: 50, tokenizer: tokenizer)

    print("--- AsyncTokenBudgetManager Example (Budget: 50 tokens) ---")

    await manager.addMessage(ChatMessage(role: "user", content: "This is a short message.", timestamp: Date())) // ~6 tokens
    print("Current tokens after 1st message: \(await manager.getCurrentTokenCount())")

    await manager.addMessage(ChatMessage(role: "assistant", content: "This is a slightly longer response from the AI, explaining some concepts.", timestamp: Date().addingTimeInterval(10))) // ~15 tokens
    print("Current tokens after 2nd message: \(await manager.getCurrentTokenCount())")

    // Add many long messages to trigger truncation
    for i in 0..<5 {
        await manager.addMessage(ChatMessage(role: "user", content: "This is message number \(i) and it is intentionally very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very very `SlidingWindowMemory` class that manages a dynamic list of `ChatMessage` objects, ensuring the total token count does not exceed a `tokenBudget`. When a new message is added and the budget is exceeded, the oldest messages are removed.

**Swift Solution:**

