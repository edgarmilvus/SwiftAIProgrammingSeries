
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import SIMD

actor SpatialStabilizer {
    private struct TrackedObject {
        var smoothedPosition: SIMD3<Float>
        var confidenceCounter: Int
        var lastVelocity: SIMD3<Float>
    }
    
    private var trackedObjects: [UUID: TrackedObject] = [:]
    
    // Configuration constants
    private let alphaBase: Float = 0.2   // Base smoothing factor (lower = smoother/slower)
    private let confidenceThreshold = 5  // Frames needed to show object
    
    /// Processes a new raw position and returns a stabilized position.
    func stabilize(id: UUID, rawPosition: SIMD3<Float>, isDetected: Bool) -> (SIMD3<Float>?, Bool) {
        if !isDetected {
            trackedObjects.removeValue(forKey: id)
            return (nil, false)
        }
        
        guard var object = trackedObjects[id] else {
            // First time seeing this object: "Snap" to position to avoid sliding from origin
            trackedObjects[id] = TrackedObject(smoothedPosition: rawPosition, 
                                               confidenceCounter: 1, 
                                               lastVelocity: .zero)
            return (nil, false) // Don't show yet (hysteresis)
        }
        
        // 1. Hysteresis: Increment confidence
        object.confidenceCounter += 1
        
        // 2. Velocity-Aware Smoothing
        // Calculate velocity: (current - last)
        let velocity = rawPosition - object.smoothedPosition
        object.lastVelocity = velocity
        
        // If moving fast, increase alpha (less smoothing) to reduce lag.
        // If still, decrease alpha (more smoothing) to reduce jitter.
        let speed = length(velocity)
        let adaptiveAlpha = min(0.8, alphaBase + (speed * 0.5))
        
        // 3. Exponential Moving Average (EMA) Formula: S_t = α * Y_t + (1 - α) * S_{t-1}
        let newSmoothedPosition = (adaptiveAlpha * rawPosition) + ((1.0 - adaptiveAlpha) * object.smoothedPosition)
        
        object.smoothedPosition = newSmoothedPosition
        trackedObjects[id] = object
        
        // 4. Check if we have passed the confidence threshold
        let isReady = object.confidenceCounter >= confidenceThreshold
        return (isReady ? newSmoothedPosition : nil, isReady)
    }
}

// Usage in the main loop
@MainActor
func updateLoop(id: UUID, rawPos: SIMD3<Float>, detected: Bool) {
    Task {
        let (stabilizedPos, ready) = await stabilizer.stabilize(id: id, rawPosition: rawPos, isDetected: detected)
        
        if let pos = stabilizedPos, ready {
            // Update the RealityKit entity position smoothly
            myEntity.position = pos
        } else if !detected {
            myEntity.removeFromParent()
        }
    }
}
