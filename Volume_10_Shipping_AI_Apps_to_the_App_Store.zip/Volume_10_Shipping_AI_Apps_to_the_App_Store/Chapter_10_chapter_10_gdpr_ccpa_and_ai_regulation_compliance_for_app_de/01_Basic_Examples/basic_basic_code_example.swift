
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import SwiftUI
import OSLog

// MARK: - Models & Types

/// Represents the types of sensitive information we aim to protect.
/// This is crucial for mapping technical scrubbing to legal definitions of PII.
enum PIIType: String, CaseIterable, Sendable {
    case email = "Email Address"
    case phoneNumber = "Phone Number"
    case name = "Potential Name"
}

/// A structure representing the result of a privacy scrubbing operation.
struct ScrubbingResult: Sendable {
    let originalText: String
    let scrubbedText: String
    let detectedPII: [PIIType]
}

/// Represents the user's legal consent state regarding AI data processing.
enum ConsentStatus: Int, Codable, Sendable {
    case none = 0
    case granted = 1
    case withdrawn = 2
}

// MARK: - Privacy Core

/// `PrivacyGuard` is an Actor that manages the user's consent state.
/// Using an `actor` ensures that consent checks are thread-safe, preventing 
/// race conditions where data might be sent during the exact millisecond 
/// a user withdraws consent.
@available(iOS 18.0, *)
actor PrivacyGuard {
    private let consentKey = "com.aijournal.consent.status"
    private(set) var currentStatus: ConsentStatus {
        didSet {
            saveConsent()
        }
    }

    init() {
        // Load existing consent from UserDefaults
        let rawValue = UserDefaults.standard.integer(forKey: consentKey)
        self.currentStatus = ConsentStatus(rawValue: rawValue) ?? .none
    }

    /// Updates the user's consent status.
    /// - Parameter status: The new `ConsentStatus`.
    func updateConsent(to status: ConsentStatus) {
        self.currentStatus = status
    }

    /// Validates if the pipeline is allowed to proceed to cloud transmission.
    /// - Returns: A boolean indicating if processing is permitted.
    func isProcessingPermitted() -> Bool {
        return currentStatus == .granted
    }

    private func saveConsent() {
        UserDefaults.standard.set(currentStatus.rawValue, forKey: consentKey)
    }
}

/// `PIIScrubber` provides deterministic, local-first redaction of sensitive data.
/// This implements the "Data Minimization" requirement of GDPR Article 5.
struct PIIScrubber: Sendable {
    
    /// Patterns for detecting common PII using Swift 5.7+ Regex literals.
    /// In a production app, these would be more robust or use Natural Language framework.
    private let emailRegex = /[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,64}/
    private let phoneRegex = /\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}/

    /// Scans text and replaces sensitive patterns with redaction labels.
    /// - Parameter text: The raw user input.
    /// - Returns: A `ScrubbingResult` containing the safe text.
    func scrub(_ text: String) -> ScrubbingResult {
        var scrubbed = text
        var detected: [PIIType] = []

        // Scrub Emails
        if text.contains(emailRegex) {
            detected.append(.email)
            scrubbed = scrubbed.replacing(emailRegex, with: "[EMAIL_REDACTED]")
        }

        // Scrub Phone Numbers
        if text.contains(phoneRegex) {
            detected.append(.phoneNumber)
            scrubbed = scrubbed.replacing(phoneRegex, with: "[PHONE_REDACTED]")
        }

        return ScrubbingResult(
            originalText: text,
            scrubbedText: scrubbed,
            detectedPII: detected
        )
    }
}

// MARK: - AI Pipeline

/// `AIPipeline` coordinates the flow from raw input to AI response,
/// enforcing privacy gates at every step.
@available(iOS 18.0, *)
@MainActor
class JournalViewModel: ObservableObject {
    @Published var userInput: String = ""
    @Published var aiResponse: String = ""
    @Published var isProcessing: Bool = false
    @Published var privacyWarning: String?
    
    // Dependencies
    private let privacyGuard = PrivacyGuard()
    private let scrubber = PIIScrubber()
    private let logger = Logger(subsystem: "com.aijournal.app", category: "PrivacyPipeline")

    /// The primary entry point for processing a journal entry.
    /// This function demonstrates the "Gatekeeper" pattern.
    func processJournalEntry() async {
        isProcessing = true
        privacyWarning = nil
        
        // 1. Consent Check (The Gatekeeper)
        guard await privacyGuard.isProcessingPermitted() else {
            self.privacyWarning = "AI processing is disabled. Please grant consent in Settings."
            self.isProcessing = false
            return
        }

        // 2. Local Scrubbing (Data Minimization)
        // We perform this BEFORE any network calls.
        let result = scrubber.scrub(userInput)
        
        if !result.detectedPII.isEmpty {
            logger.info("PII detected and scrubbed: \(result.detectedPII.map { $0.rawValue }.joined(separator: ", "))")
        }

        // 3. Simulated Cloud Transmission
        // In a real app, 'result.scrubbedText' is what hits your API.
        do {
            let response = try await simulateCloudAIRequest(with: result.scrubbedText)
            self.aiResponse = response
        } catch {
            self.aiResponse = "Error: Could not reach AI service."
            logger.error("AI Request failed: \(error.localizedDescription)")
        }

        isProcessing = false
    }

    /// Updates the user's consent via the PrivacyGuard actor.
    func toggleConsent(granted: Bool) async {
        let newStatus: ConsentStatus = granted ? .granted : .withdrawn
        await privacyGuard.updateConsent(to: newStatus)
        logger.notice("User consent updated to: \(newStatus.rawValue)")
    }

    /// A mock function representing a network call to an LLM provider (e.g., OpenAI, Anthropic).
    private func simulateCloudAIRequest(with text: String) async throws -> String {
        // Simulate network latency
        try await Task.sleep(for: .seconds(2))
        
        // The AI "sees" the scrubbed text, not the original.
        return "AI Insight: Your entry '\(text)' suggests a reflective mood. (Processed safely)"
    }
}

// MARK: - UI Layer

@available(iOS 18.0, *)
struct JournalView: View {
    @StateObject private var viewModel = JournalViewModel()
    @State private var consentEnabled: Bool = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("AI Privacy-First Journal")
                    .font(.headline)

                // Consent Toggle (The Transparency UI)
                Toggle("Allow AI Cloud Processing", isOn: $consentEnabled)
                    .toggleStyle(.switch)
                    .onChange(of: consentEnabled) { _, newValue in
                        Task {
                            await viewModel.toggleConsent(granted: newValue)
                        }
                    }
                    .padding()
                    .background(Color.secondary.opacity(0.1))
                    .cornerRadius(10)

                TextEditor(text: $viewModel.userInput)
                    .frame(height: 150)
                    .border(Color.gray.opacity(0.5))
                    .overlay(
                        Group {
                            if viewModel.userInput.isEmpty {
                                Text("Write your thoughts here...")
                                    .foregroundColor(.gray)
                                    .padding(.leading, 5)
                                    .padding(.top, 8)
                            }
                        }, alignment: .topLeading
                    )

                if let warning = viewModel.privacyWarning {
                    Text(warning)
                        .foregroundColor(.red)
                        .font(.caption)
                }

                Button(action: {
                    Task {
                        await viewModel.processJournalEntry()
                    }
                }) {
                    if viewModel.isProcessing {
                        ProgressView()
                    } else {
                        Text("Get AI Insight")
                            .bold()
                            .frame(maxWidth: .infinity)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(viewModel.isProcessing)

                Divider()

                ScrollView {
                    Text(viewModel.aiResponse)
                        .italic()
                        .padding()
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("Journal")
        }
    }
}

// MARK: - App Entry Point

@main
struct AIJournalApp: App {
    var body: some Scene {
        WindowGroup {
            JournalView()
        }
    }
}
