
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

struct CachedVector: Sendable {
    let id: UUID
    let vector: [Float]
    let lastAccessed: Date
    let importanceScore: Float // Provided by AI model
}

actor VectorCacheManager {
    private var cache: [UUID: CachedVector] = [:]
    private let maxCapacity = 500
    private let pruningThresholdPercent = 0.2 // Prune 20% when full
    
    func getVector(id: UUID) -> [Float]? {
        guard let entry = cache[id] else { return nil }
        
        // Update last accessed date (requires updating the cache)
        let updatedEntry = CachedVector(
            id: entry.id,
            vector: entry.vector,
            lastAccessed: Date(),
            importanceScore: entry.importanceScore
        )
        cache[id] = updatedEntry
        return entry.vector
    }
    
    func insert(_ entry: CachedVector) {
        cache[entry.id] = entry
        if cache.count > maxCapacity {
            prune()
        }
    }
    
    /// Prunes the cache based on a Utility Score: (Importance * 0.7) + (Recency * 0.3)
    func prune() {
        let now = Date()
        let allEntries = Array(cache.values)
        
        // 1. Calculate Utility Scores
        // We define RecencyFactor based on a 1-hour window for normalization
        let entriesWithScores: [(id: UUID, score: Float)] = allEntries.map { entry in
            let timeInterval = now.timeIntervalSince(entry.lastAccessed)
            // Normalize recency: 1.0 if just accessed, 0.0 if > 1 hour ago
            let recencyFactor = max(0, 1.0 - (timeInterval / 3600.0))
            
            let utilityScore = (entry.importanceScore * 0.7) + (recencyFactor * 0.3)
            return (entry.id, utilityScore)
        }
        
        // 2. Sort by score ascending (lowest utility first)
        let sortedByUtility = entriesWithScores.sorted { $0.score < $1.score }
        
        // 3. Determine how many to remove
        let amountToRemove = Int(Double(cache.count) * Double(pruningThresholdPercent))
        let idsToRemove = sortedByUtility.prefix(amountToRemove).map { $0.id }
        
        // 4. Perform eviction
        for id in idsToRemove {
            cache.removeValue(forKey: id)
        }
        
        print("Pruned \(idsToRemove.count) vectors. Remaining: \(cache.count)")
    }
    
    /// Responds to system memory pressure
    func handleMemoryWarning() {
        // Aggressive pruning: remove bottom 50%
        print("Memory Warning: Performing aggressive pruning.")
        let currentCount = cache.count
        let amountToRemove = currentCount / 2
        
        let allEntries = Array(cache.values).map { entry -> (UUID, Float) in
            let recency = max(0, 1.0 - (Date().timeIntervalSince(entry.lastAccessed) / 3600.0))
            return (entry.id, (entry.importanceScore * 0.7) + (recency * 0.3))
        }.sorted { $0.1 < $1.1 }
        
        for i in 0..<amountToRemove {
            cache.removeValue(forKey: allEntries[i].0)
        }
    }
}
