
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

@available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, visionOS 1.0, *)
@MainActor
class SoundClassifierTrainer: ObservableObject {
    @Published var trainingStatus: String = "Idle"
    @Published var isTraining: Bool = false
    @Published var progressFraction: Double = 0.0
    @Published var currentLoss: Double = -1.0

    private var currentCancellationToken: MLProgress.CancellationToken?
    private var trainingTask: Task<Void, Never>?

    func startTraining(simulateFailure: Bool = false) {
        guard !isTraining else { return }
        isTraining = true
        trainingStatus = "Starting training..."
        progressFraction = 0.0
        currentLoss = -1.0

        let cancellationToken = MLProgress.CancellationToken()
        self.currentCancellationToken = cancellationToken

        // Simulate failure at iteration 30 if requested
        let failAtIndex = simulateFailure ? 30 : nil
        let mlProgress = createMockMLProgress(
            iterations: 100,
            delay: .milliseconds(100),
            cancellationToken: cancellationToken,
            failAtIndex: failAtIndex
        )

        trainingTask = Task {
            do {
                for await event in mlProgress {
                    // It's good practice to also check Task.isCancelled here,
                    // in case the observing task itself was cancelled externally
                    // before the MLProgress token could be checked.
                    if Task.isCancelled {
                        await MainActor.run {
                            self.trainingStatus = "Training task cancelled by system or parent."
                            self.isTraining = false
                        }
                        return // Exit the for await loop
                    }

                    switch event {
                    case .snapshot(let snapshot):
                        await MainActor.run {
                            self.trainingStatus = "Iteration \(snapshot.currentIteration), Phase: \(snapshot.phase.description)"
                            self.progressFraction = snapshot.fractionCompleted
                            self.currentLoss = snapshot.metrics[.loss]?.doubleValue ?? -1.0
                        }
                    case .completed:
                        await MainActor.run {
                            self.trainingStatus = "Training Completed Successfully!"
                            self.isTraining = false
                            self.progressFraction = 1.0 // Ensure full progress on completion
                        }
                    case .failed(let error):
                        await MainActor.run {
                            if let mlError = error as? MLProgress.Error, mlError == .cancelled {
                                self.trainingStatus = "Training Cancelled by User."
                            } else {
                                self.trainingStatus = "Training Failed: \(error.localizedDescription)"
                            }
                            self.isTraining = false
                        }
                    }
                }
            } catch {
                // Catch any other unexpected errors from the AsyncSequence itself
                await MainActor.run {
                    self.trainingStatus = "An unexpected error occurred: \(error.localizedDescription)"
                    self.isTraining = false
                }
            }
            // Clean up the cancellation token reference once the task is done
            await MainActor.run {
                self.currentCancellationToken = nil
            }
        }
    }

    func cancelTraining() {
        guard isTraining else { return }
        trainingStatus = "Cancellation requested..."
        currentCancellationToken?.cancel() // Signal the cancellation to the MLProgress source
        trainingTask?.cancel() // Also cancel the observing Task itself
    }
}

@available(macOS 14.0, iOS 17.0, tvOS 17.0, watchOS 10.0, visionOS 1.0, *)
struct SoundClassifierTrainingView: View {
    @StateObject private var trainer = SoundClassifierTrainer()

    var body: some View {
        VStack(spacing: 20) {
            Text("Sound Classifier Training")
                .font(.largeTitle)

            VStack(alignment: .leading, spacing: 10) {
                Text("Status: \(trainer.trainingStatus)")
                    .font(.headline)
                    .foregroundColor(trainer.trainingStatus.contains("Failed") ? .red : .primary)
                
                ProgressView(value: trainer.progressFraction)
                    .progressViewStyle(.linear)
                
                if trainer.currentLoss != -1.0 {
                    Text(String(format: "Current Loss: %.4f", trainer.currentLoss))
                        .font(.subheadline)
                }
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)

            HStack {
                Button("Start Training") {
                    trainer.startTraining()
                }
                .disabled(trainer.isTraining)

                Button("Start Training (Simulate Failure)") {
                    trainer.startTraining(simulateFailure: true)
                }
                .disabled(trainer.isTraining)

                Button("Cancel Training") {
                    trainer.cancelTraining()
                }
                .disabled(!trainer.isTraining)
            }
        }
        .padding()
    }
}
