/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// src/components/Dashboard.tsx
// ------------------------------------------------------------
// UI Component utilizing Zustand State & NativeWind Styling
// ------------------------------------------------------------

import React, { useState } from 'react';
import { useAppStore } from '../lib/store';
import { View, Text, TextInput, TouchableOpacity, FlatList, Switch } from 'react-native';

/**
 * Dashboard Component
 * A universal component that renders the SaaS dashboard.
 * Uses NativeWind (Tailwind classes) for styling.
 */
export const Dashboard: React.FC = () => {
  // Select specific slices of the state to minimize re-renders
  const { user, tasks, addTask, toggleTask, clearCompleted, login, logout } = useAppStore((state) => ({
    user: state.user,
    tasks: state.tasks,
    addTask: state.addTask,
    toggleTask: state.toggleTask,
    clearCompleted: state.clearCompleted,
    login: state.login,
    logout: state.logout,
  }));

  const [newTaskTitle, setNewTaskTitle] = useState('');

  const handleAddTask = () => {
    if (newTaskTitle.trim()) {
      addTask(newTaskTitle);
      setNewTaskTitle('');
    }
  };

  // Mock Login for demonstration
  const handleAuth = () => {
    if (user.isAuthenticated) {
      logout();
    } else {
      login('admin@saas.com');
    }
  };

  return (
    <View className="flex-1 bg-gray-50 p-4">
      {/* Header Section */}
      <View className="flex-row justify-between items-center mb-6">
        <Text className="text-2xl font-bold text-gray-800">SaaS Dashboard</Text>
        <TouchableOpacity
          onPress={handleAuth}
          className={`px-4 py-2 rounded-lg ${user.isAuthenticated ? 'bg-red-500' : 'bg-blue-600'}`}
        >
          <Text className="text-white font-semibold">
            {user.isAuthenticated ? 'Logout' : 'Login'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* User Status */}
      {user.isAuthenticated ? (
        <View className="mb-4 p-4 bg-white rounded-xl shadow-sm">
          <Text className="text-sm text-gray-500">Logged in as</Text>
          <Text className="text-lg font-medium text-blue-700">{user.username}</Text>
        </View>
      ) : (
        <View className="mb-4 p-4 bg-yellow-50 border border-yellow-200 rounded-xl">
          <Text className="text-yellow-800">Please login to view tasks.</Text>
        </View>
      )}

      {/* Task Input */}
      {user.isAuthenticated && (
        <View className="flex-row gap-2 mb-4">
          <TextInput
            className="flex-1 bg-white border border-gray-300 rounded-lg px-4 py-2"
            placeholder="Add a new task..."
            value={newTaskTitle}
            onChangeText={setNewTaskTitle}
            onSubmitEditing={handleAddTask}
          />
          <TouchableOpacity
            onPress={handleAddTask}
            className="bg-green-600 px-4 py-2 rounded-lg justify-center"
          >
            <Text className="text-white font-bold">+</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Task List */}
      {user.isAuthenticated && (
        <View className="flex-1">
          <View className="flex-row justify-between items-center mb-2">
            <Text className="text-lg font-semibold text-gray-700">Tasks</Text>
            <TouchableOpacity onPress={clearCompleted}>
              <Text className="text-sm text-blue-600">Clear Completed</Text>
            </TouchableOpacity>
          </View>
          
          <FlatList
            data={tasks}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View className="flex-row items-center bg-white p-3 mb-2 rounded-lg shadow-sm">
                <Switch
                  value={item.completed}
                  onValueChange={() => toggleTask(item.id)}
                  className="mr-3"
                />
                <Text
                  className={`flex-1 text-base ${item.completed ? 'line-through text-gray-400' : 'text-gray-800'}`}
                >
                  {item.title}
                </Text>
              </View>
            )}
            ListEmptyComponent={
              <Text className="text-center text-gray-400 mt-8">No tasks yet. Add one above!</Text>
            }
          />
        </View>
      )}
    </View>
  );
};
