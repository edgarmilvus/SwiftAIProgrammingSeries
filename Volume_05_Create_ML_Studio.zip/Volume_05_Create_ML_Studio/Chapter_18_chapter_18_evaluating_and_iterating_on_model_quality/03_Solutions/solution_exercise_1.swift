
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// This exercise is purely conceptual and does not require a Swift code solution
// for model training or evaluation interpretation, as it focuses on analyzing
// Create ML Studio's output and proposing strategies.
//
// In a real-world scenario, after training in Create ML Studio, you would export
// the .mlmodel and integrate it into a Swift application like this:

import CoreML
import Vision
import UIKit

// Example of how you might use a trained MLImageClassifier in Swift
@available(iOS 14.0, *) // Or appropriate version for Create ML model
class FruitClassifier {
    private var model: VNCoreMLModel?
    private let classificationRequest: VNCoreMLRequest

    init() {
        // 1. Load the compiled Core ML model
        // Replace "FruitClassifierModel" with the actual name of your exported .mlmodel
        guard let coreMLModel = try? FruitClassifierModel(configuration: MLModelConfiguration()).model else {
            fatalError("Failed to load Core ML model.")
        }

        // 2. Create a Vision model from the Core ML model
        guard let visionModel = try? VNCoreMLModel(for: coreMLModel) else {
            fatalError("Failed to create VNCoreMLModel.")
        }
        self.model = visionModel

        // 3. Create a Vision classification request
        self.classificationRequest = VNCoreMLRequest(model: visionModel) { request, error in
            if let error = error {
                print("Image classification error: \(error.localizedDescription)")
                return
            }
            guard let observations = request.results as? [VNClassificationObservation] else {
                print("No classification observations.")
                return
            }

            // Process the classification results
            for observation in observations {
                print("Detected \(observation.identifier) with confidence \(observation.confidence)")
            }
        }
        // Configure the request to only return the top 1 classification
        self.classificationRequest.uses // This line seems incomplete, likely meant for .imageCropAndScaleOption or similar.
                                       // A common practice is to sort and take the first:
        self.classificationRequest.results // This is not a property to configure, but to access results.
                                          // For top-k results, you'd process `observations` after they are returned.
    }

    func classifyImage(_ image: UIImage) {
        guard let ciImage = CIImage(image: image) else {
            print("Failed to convert UIImage to CIImage.")
            return
        }

        let handler = VNImageRequestHandler(ciImage: ciImage)
        do {
            try handler.perform([classificationRequest])
        } catch {
            print("Failed to perform classification: \(error.localizedDescription)")
        }
    }
}

/*
// Example Usage (conceptual, as no actual image is provided)
if #available(iOS 14.0, *) {
    let classifier = FruitClassifier()
    // Imagine 'someImage' is a UIImage loaded from somewhere
    // classifier.classifyImage(someImage)
}
*/
