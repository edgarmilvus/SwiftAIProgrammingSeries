
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import NaturalLanguage

@available(iOS 18.0, *)
@Observable
class EmbeddingViewModel {
    var textInput1: String = ""
    var textInput2: String = ""
    var similarityScore: Double?
    var isLoading: Bool = false
    var errorMessage: String?

    private let embeddingProcessor = EmbeddingProcessor() // Reusing our processor

    func calculateSimilarity() async {
        isLoading = true
        errorMessage = nil
        similarityScore = nil // Clear previous result

        do {
            // Ensure UI updates happen on the main actor after async work
            let score = try await embeddingProcessor.compareTexts(text1: textInput1, text2: textInput2)
            await MainActor.run {
                self.similarityScore = score
                self.isLoading = false
            }
        } catch {
            await MainActor.run {
                self.errorMessage = "Failed to calculate similarity: \(error.localizedDescription)"
                self.isLoading = false
            }
        }
    }
}

// Example SwiftUI View (conceptual)
/*
@available(iOS 18.0, *)
struct EmbeddingView: View {
    @State private var viewModel = EmbeddingViewModel()

    var body: some View {
        VStack {
            TextField("Enter text 1", text: $viewModel.textInput1)
            TextField("Enter text 2", text: $viewModel.textInput2)
            Button("Calculate Similarity") {
                Task {
                    await viewModel.calculateSimilarity()
                }
            }
            if viewModel.isLoading {
                ProgressView()
            }
            if let score = viewModel.similarityScore {
                Text("Similarity: \(score, specifier: "%.3f")")
            }
            if let error = viewModel.errorMessage {
                Text("Error: \(error)").foregroundColor(.red)
            }
        }
    }
}
*/
