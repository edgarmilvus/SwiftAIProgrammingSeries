
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import ARKit
import RealityKit
import Observation

/// A thread-safe manager for the spatial environment.
/// Using an Actor ensures that updates to the world map are synchronized.
@available(visionOS 1.0, *)
actor SpatialEnvironmentManager {
    
    // The underlying ARWorldMap is a complex structure.
    // We wrap it in an actor to ensure thread-safe access.
    private var currentWorldMap: ARWorldMap?
    
    // Using @Observable for the UI layer to react to spatial changes.
    // Note: The Actor manages the data, while the @Observable 
    // object (on the @MainActor) reflects it to the user.
    @MainActor @Observable public var isRelocalizing: Bool = false
    
    /// Updates the world map with new spatial data.
    /// This is called from the ARSession delegate.
    func updateMap(_ newMap: ARWorldMap) async {
        self.currentWorldMap = newMap
        
        // Update the UI-facing state on the MainActor
        await MainActor.run {
            self.isRelocalizing = false
        }
    }
    
    /// Retrieves a snapshot of the current world map.
    /// The map itself must be Sendable to cross the actor boundary.
    func getMapSnapshot() -> ARWorldMap? {
        return currentWorldMap
    }
}

/// A Sendable wrapper for mesh data to ensure safe transfer 
/// between the ARKit processing thread and the RealityKit rendering thread.
struct SpatialMeshSnapshot: Sendable {
    let vertices: [SIMD3<Float>]
    let indices: [UInt32]
    let semanticLabel: String
}
