
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import Speech
import AVFoundation

class MultilingualVoiceMemoViewController: UIViewController, SFSpeechRecognizerDelegate {

    // MARK: - UI Elements
    private let statusLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        label.textColor = .systemGray
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let languageSegmentedControl: UISegmentedControl = {
        let segmentedControl = UISegmentedControl(items: ["English (US)", "Spanish (ES)", "French (FR)"])
        segmentedControl.selectedSegmentIndex = 0 // Default to English
        segmentedControl.translatesAutoresizingMaskIntoConstraints = false
        return segmentedControl
    }()

    private let startButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Recording", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        button.backgroundColor = .systemGreen
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isEnabled = false // Disabled initially
        return button
    }()

    private let stopButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Stop Recording", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        button.backgroundColor = .systemRed
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 10
        button.translatesAutoresizingMaskIntoConstraints = false
        button.isEnabled = false // Disabled initially
        return button
    }()

    private let transcriptionTextView: UITextView = {
        let textView = UITextView()
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.textColor = .label
        textView.backgroundColor = .systemBackground
        textView.layer.borderColor = UIColor.systemGray3.cgColor
        textView.layer.borderWidth = 1
        textView.layer.cornerRadius = 8
        textView.isEditable = false
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "Select a language and tap 'Start Recording'."
        return textView
    }()

    // MARK: - Speech Recognition Properties
    private var speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    private let supportedLocales: [String: Locale] = [
        "English (US)": Locale(identifier: "en-US"),
        "Spanish (ES)": Locale(identifier: "es-ES"),
        "French (FR)": Locale(identifier: "fr-FR")
    ]
    private var currentLocale: Locale = Locale(identifier: "en-US") // Default

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Initial setup of speech recognizer with default locale
        setupSpeechRecognizer(locale: currentLocale)
        // Request authorization and update UI based on status
        checkAndRequestAuthorization()

        // Observe when the app returns from background (e.g., after changing permissions in Settings)
        NotificationCenter.default.addObserver(self, selector: #selector(appWillEnterForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopRecording()
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Multilingual Voice Memo"

        let stackView = UIStackView(arrangedSubviews: [startButton, stopButton])
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(statusLabel)
        view.addSubview(languageSegmentedControl)
        view.addSubview(stackView)
        view.addSubview(transcriptionTextView)

        NSLayoutConstraint.activate([
            statusLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 40),

            languageSegmentedControl.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 20),
            languageSegmentedControl.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            languageSegmentedControl.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            languageSegmentedControl.heightAnchor.constraint(equalToConstant: 40),

            stackView.topAnchor.constraint(equalTo: languageSegmentedControl.bottomAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            stackView.heightAnchor.constraint(equalToConstant: 50),

            transcriptionTextView.topAnchor.constraint(equalTo: stackView.bottomAnchor, constant: 20),
            transcriptionTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            transcriptionTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            transcriptionTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])

        startButton.addTarget(self, action: #selector(startRecordingTapped), for: .touchUpInside)
        stopButton.addTarget(self, action: #selector(stopRecordingTapped), for: .touchUpInside)
        languageSegmentedControl.addTarget(self, action: #selector(languageChanged), for: .valueChanged)

        // Initial UI state based on default locale availability
        updateUIForSpeechRecognizerAvailability(SFSpeechRecognizer(locale: currentLocale)?.isAvailable ?? false)
    }

    // MARK: - Speech Recognition Setup
    private func setupSpeechRecognizer(locale: Locale) {
        // Ensure any existing task is cancelled before re-initializing
        stopRecording()
        
        if let recognizer = SFSpeechRecognizer(locale: locale) {
            speechRecognizer = recognizer
            speechRecognizer?.delegate = self
            currentLocale = locale
            // Update UI based on the availability of the new recognizer
            updateUIForSpeechRecognizerAvailability(recognizer.isAvailable)
        } else {
            speechRecognizer = nil
            DispatchQueue.main.async {
                self.startButton.isEnabled = false
                self.stopButton.isEnabled = false
                self.statusLabel.text = "Speech recognition is not supported for \(locale.localizedString(forIdentifier: locale.identifier) ?? locale.identifier)."
                self.statusLabel.textColor = .systemRed
            }
        }
    }

    // MARK: - Authorization
    @objc private func appWillEnterForeground() {
        // Re-check permissions when the app becomes active again
        checkAndRequestAuthorization()
    }

    private func checkAndRequestAuthorization() {
        let speechAuthStatus = SFSpeechRecognizer.authorizationStatus()
        let audioRecordPermission = AVAudioSession.sharedInstance().recordPermission

        // If authorization hasn't been determined for speech, request it.
        // Microphone permission will be requested implicitly by AVAudioSession setup,
        // or explicitly if notDetermined.
        if speechAuthStatus == .notDetermined {
            SFSpeechRecognizer.requestAuthorization { [weak self] newAuthStatus in
                DispatchQueue.main.async {
                    self?.updateUIForAuthorizationStatus(speechAuthStatus: newAuthStatus, microphonePermission: AVAudioSession.sharedInstance().recordPermission)
                }
            }
        } else if audioRecordPermission == .undetermined {
            AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                DispatchQueue.main.async {
                    self?.updateUIForAuthorizationStatus(speechAuthStatus: speechAuthStatus, microphonePermission: (granted ? .granted : .denied))
                }
            }
        } else {
            // Permissions already determined, just update UI
            updateUIForAuthorizationStatus(speechAuthStatus: speechAuthStatus, microphonePermission: audioRecordPermission)
        }
    }

    private func updateUIForAuthorizationStatus(speechAuthStatus: SFSpeechRecognizerAuthorizationStatus, microphonePermission: AVAudioSession.RecordPermission) {
        DispatchQueue.main.async {
            let isSpeechAuthorized = (speechAuthStatus == .authorized)
            let isMicrophoneGranted = (microphonePermission == .granted)
            let isRecognizerAvailable = self.speechRecognizer?.isAvailable ?? false

            let canStartRecording = isSpeechAuthorized && isMicrophoneGranted && isRecognizerAvailable && !self.audioEngine.isRunning

            self.startButton.isEnabled = canStartRecording
            self.stopButton.isEnabled = self.audioEngine.isRunning // Only enable stop if recording is active

            if !isSpeechAuthorized || !isMicrophoneGranted {
                self.statusLabel.text = "Speech recognition or microphone access denied. Please enable in Settings."
                self.statusLabel.textColor = .systemRed
            } else if !isRecognizerAvailable {
                self.statusLabel.text = "Speech recognition is not available for the selected language or on this device."
                self.statusLabel.textColor = .systemRed
            } else if speechAuthStatus == .notDetermined || microphonePermission == .undetermined {
                self.statusLabel.text = "Authorization not yet determined. Please grant permissions."
                self.statusLabel.textColor = .systemOrange
            } else {
                self.statusLabel.text = "Ready to record with \(self.currentLocale.localizedString(forIdentifier: self.currentLocale.identifier) ?? self.currentLocale.identifier)."
                self.statusLabel.textColor = .systemGreen
            }
        }
    }

    private func updateUIForSpeechRecognizerAvailability(_ available: Bool) {
        DispatchQueue.main.async {
            let speechAuthStatus = SFSpeechRecognizer.authorizationStatus()
            let microphonePermission = AVAudioSession.sharedInstance().recordPermission
            let isSpeechAuthorized = (speechAuthStatus == .authorized)
            let isMicrophoneGranted = (microphonePermission == .granted)

            let canStartRecording = available && isSpeechAuthorized && isMicrophoneGranted && !self.audioEngine.isRunning
            self.startButton.isEnabled = canStartRecording
            self.stopButton.isEnabled = self.audioEngine.isRunning

            if !available {
                self.statusLabel.text = "Speech recognition is not available for the selected language or on this device."
                self.statusLabel.textColor = .systemRed
            } else if isSpeechAuthorized && isMicrophoneGranted {
                self.statusLabel.text = "Ready to record with \(self.currentLocale.localizedString(forIdentifier: self.currentLocale.identifier) ?? self.currentLocale.identifier)."
                self.statusLabel.textColor = .systemGreen
            }
            // Other authorization status messages will be handled by updateUIForAuthorizationStatus
        }
    }

    // MARK: - Recording Actions
    @objc private func startRecordingTapped() {
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            displayError(NSError(domain: "MultilingualVoiceMemo", code: 0, userInfo: [NSLocalizedDescriptionKey: "Speech recognizer not available for the selected language."]), title: "Recognizer Unavailable")
            return
        }

        if audioEngine.isRunning {
            stopRecording()
            return
        }

        do {
            try startRecording()
            startButton.isEnabled = false
            stopButton.isEnabled = true
            languageSegmentedControl.isEnabled = false // Disable language change during recording
            transcriptionTextView.text = ""
            statusLabel.text = "Recording in \(currentLocale.localizedString(forIdentifier: currentLocale.identifier) ?? currentLocale.identifier)..."
            statusLabel.textColor = .systemBlue
        } catch {
            displayError(error, title: "Recording Error")
            startButton.isEnabled = true
            stopButton.isEnabled = false
            languageSegmentedControl.isEnabled = true
            statusLabel.text = "Error starting recording."
            statusLabel.textColor = .systemRed
        }
    }

    @objc private func stopRecordingTapped() {
        stopRecording()
        startButton.isEnabled = true
        stopButton.isEnabled = false
        languageSegmentedControl.isEnabled = true
        statusLabel.text = "Recording stopped."
        statusLabel.textColor = .systemGray
        checkAndRequestAuthorization() // Re-check and update UI after stopping
    }

    private func startRecording() throws {
        recognitionTask?.cancel()
        recognitionTask = nil

        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create a SFSpeechAudioBufferRecognitionRequest object")
        }
        recognitionRequest.shouldReportPartialResults = true

        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        try audioEngine.start()

        recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            var isFinal = false

            if let result = result {
                self.transcriptionTextView.text = result.bestTranscription.formattedString
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                self.recognitionRequest = nil
                self.recognitionTask = nil

                DispatchQueue.main.async {
                    self.startButton.isEnabled = true
                    self.stopButton.isEnabled = false
                    self.languageSegmentedControl.isEnabled = true
                    if error != nil {
                        self.displayError(error!, title: "Speech Recognition Error")
                        self.statusLabel.text = "Error during recognition."
                        self.statusLabel.textColor = .systemRed
                    } else if isFinal {
                        self.statusLabel.text = "Transcription complete."
                        self.statusLabel.textColor = .systemGreen
                    }
                    self.checkAndRequestAuthorization() // Update UI after task completion
                }
            }
        }
    }

    private func stopRecording() {
        audioEngine.stop()
        if let inputNode = audioEngine.inputNode {
            inputNode.removeTap(onBus: 0)
        }
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionRequest = nil
        recognitionTask = nil

        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
        }
    }

    // MARK: - Language Selection
    @objc private func languageChanged(_ sender: UISegmentedControl) {
        stopRecording() // Stop any ongoing recording before changing language
        
        let selectedLanguageKey = sender.titleForSegment(at: sender.selectedSegmentIndex) ?? "English (US)"
        if let newLocale = supportedLocales[selectedLanguageKey] {
            setupSpeechRecognizer(locale: newLocale)
            checkAndRequestAuthorization() // Re-evaluate permissions and UI for the new locale
        }
    }

    // MARK: - SFSpeechRecognizerDelegate
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        updateUIForSpeechRecognizerAvailability(available)
    }

    // MARK: - Error Handling
    private func displayError(_ error: Error, title: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true)
        }
    }
}
