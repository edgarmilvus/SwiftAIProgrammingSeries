/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// pages/dashboard.tsx
import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import { z } from 'zod';

// ==========================================
// 1. RUNTIME VALIDATION DEFINITIONS
// ==========================================

/**
 * @description Schema definition for the external API response.
 * We use Zod to define the expected shape of the data.
 * This ensures that even if the API changes or returns malformed JSON,
 * our application handles it gracefully.
 */
const AnalyticsDataSchema = z.object({
  chartId: z.string(),
  title: z.string(),
  // Expecting an array of data points with numeric values
  dataPoints: z.array(
    z.object({
      timestamp: z.number(), // Unix timestamp
      value: z.number().min(0), // Value must be non-negative
    })
  ),
  // Metadata must exist and contain a specific flag
  meta: z.object({
    isRealtime: z.boolean(),
    refreshRate: z.number().optional(),
  }),
});

// Infer the TypeScript type from the Zod schema for compile-time safety
export type AnalyticsData = z.infer<typeof AnalyticsDataSchema>;

// ==========================================
// 2. HEAVY COMPONENT (Simulated)
// ==========================================

/**
 * @description A simulated heavy component. In a real app, this would import
 * large libraries (e.g., D3.js, Chart.js, or heavy UI libraries).
 * By keeping this in a separate file imported via dynamic(), we exclude it
 * from the main bundle.
 */
const AnalyticsChart = ({ data }: { data: AnalyticsData }) => {
  return (
    <div style={{ border: '1px solid #ccc', padding: '20px', marginTop: '10px' }}>
      <h3>{data.title}</h3>
      <p>Type: {data.meta.isRealtime ? 'Realtime' : 'Historical'}</p>
      <ul>
        {data.dataPoints.slice(0, 5).map((point, idx) => (
          <li key={idx}>
            Time: {point.timestamp}, Value: {point.value}
          </li>
        ))}
      </ul>
      {/* In a real app, this is where the Chart Canvas would render */}
      <div style={{ height: '200px', background: '#f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        [Heavy Charting Library Rendered Here]
      </div>
    </div>
  );
};

// ==========================================
// 3. DYNAMIC IMPORT (Code Splitting)
// ==========================================

/**
 * @description Dynamically import the AnalyticsChart component.
 * - `ssr: false`: Ensures the component is not rendered on the server,
 *   which is ideal for heavy client-side visualizations.
 * - Loading: Provides a fallback UI while the chunk is being fetched.
 */
const DynamicAnalyticsChart = dynamic(
  () => import('../components/AnalyticsChart'), // Assuming separate file, or inline as above
  { 
    ssr: false,
    loading: () => <p>Loading Chart Module...</p> 
  }
);

// Mock implementation for the standalone script context:
// In a real project, we would import the component above. 
// For this script, we will use the inline component defined earlier.
const MockDynamicChart = ({ data }: { data: AnalyticsData }) => <AnalyticsChart data={data} />;


// ==========================================
// 4. MAIN DASHBOARD CONTAINER
// ==========================================

export default function Dashboard() {
  const [view, setView] = useState<'main' | 'analytics'>('main');
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  /**
   * @description Simulates fetching data from an external SaaS API.
   * This function includes a mock success and failure case to demonstrate
   * Runtime Validation.
   */
  const fetchAnalyticsData = async (simulateError: boolean = false) => {
    setLoading(true);
    setError(null);
    
    // Simulate network delay
    await new Promise(r => setTimeout(r, 1000));

    // Mock raw API response (could be malformed if simulateError is true)
    const rawResponse = simulateError 
      ? { title: "Broken Data", dataPoints: "not-an-array" } // Malformed
      : {
          chartId: "chart_123",
          title: "User Signups (Last 7 Days)",
          dataPoints: Array.from({ length: 5 }, (_, i) => ({
            timestamp: Date.now() - (i * 86400000),
            value: Math.floor(Math.random() * 100)
          })),
          meta: { isRealtime: false }
        };

    // ==========================================
    // 5. RUNTIME VALIDATION EXECUTION
    // ==========================================
    
    /**
     * We parse the raw data using the Zod schema.
     * This is the critical step for startup optimization safety.
     * If validation fails, we catch the error and prevent the 
     * application from rendering invalid data structures.
     */
    const result = AnalyticsDataSchema.safeParse(rawResponse);

    if (result.success) {
      setAnalyticsData(result.data);
    } else {
      // Handle validation errors gracefully
      console.error("API Validation Failed:", result.error.errors);
      setError("The data received from the server was invalid. Please try again.");
      setAnalyticsData(null);
    }

    setLoading(false);
  };

  return (
    <div style={{ fontFamily: 'sans-serif', maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
      <header style={{ marginBottom: '20px', borderBottom: '1px solid #eee', paddingBottom: '10px' }}>
        <h1>SaaS Dashboard</h1>
        <nav>
          <button 
            onClick={() => setView('main')} 
            style={{ marginRight: '10px', fontWeight: view === 'main' ? 'bold' : 'normal' }}
          >
            Main
          </button>
          <button 
            onClick={() => {
              setView('analytics');
              // Trigger data fetch only when the user actually needs the heavy view
              if (!analyticsData) fetchAnalyticsData();
            }}
            style={{ fontWeight: view === 'analytics' ? 'bold' : 'normal' }}
          >
            Analytics (Lazy Loaded)
          </button>
        </nav>
      </header>

      <main>
        {view === 'main' && (
          <div>
            <h2>Welcome Back</h2>
            <p>This is the lightweight main view. It loads instantly.</p>
          </div>
        )}

        {view === 'analytics' && (
          <div>
            <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
              <button onClick={() => fetchAnalyticsData(false)}>Load Valid Data</button>
              <button onClick={() => fetchAnalyticsData(true)}>Load Invalid Data (Test Error)</button>
            </div>

            {loading && <p>Fetching data...</p>}
            
            {error && (
              <div style={{ color: 'red', background: '#ffe6e6', padding: '10px', border: '1px solid red' }}>
                <strong>Error:</strong> {error}
              </div>
            )}

            {/* 
              CONDITIONAL RENDERING:
              The heavy chart logic is only executed if data is valid.
              We pass the validated data (AnalyticsData type) to the component.
            */}
            {analyticsData && !loading && !error && (
              <MockDynamicChart data={analyticsData} />
            )}

            {!analyticsData && !loading && !error && (
              <p>No data loaded yet. Click "Load Valid Data".</p>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
