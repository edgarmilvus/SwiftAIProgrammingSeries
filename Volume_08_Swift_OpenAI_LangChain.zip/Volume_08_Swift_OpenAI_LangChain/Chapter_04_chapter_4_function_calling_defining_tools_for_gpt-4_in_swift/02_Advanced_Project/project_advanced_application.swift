
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Observation

// MARK: - Package Dependencies
/*
 To use this in a real project, add the following to your Package.swift:
 
 dependencies: [
     .package(url: "https://github.com/openai/openai-swift", from: "1.0.0")
 ]
*/

/// Represents the possible errors during the agentic loop.
enum AgentError: Error, LocalizedError {
    case toolNotFound(String)
    case executionFailed(String)
    case invalidArguments
    case apiError(String)

    var errorDescription: String? {
        switch self {
        case .toolNotFound(let name): return "The tool '\(name)' is not registered."
        case .executionFailed(let msg): return "Execution failed: \(msg)"
        case .invalidArguments: return "The LLM provided malformed arguments."
        case .apiError(let msg): return "OpenAI API Error: \(msg)"
        }
    }
}

/// A protocol defining the requirements for any tool available to the LLM.
/// Using `Sendable` ensures that tools can be safely passed across actor boundaries.
protocol SmartHomeTool: Sendable {
    /// The unique identifier used by the LLM to call this tool.
    var name: String { get }
    
    /// The JSON Schema definition used to describe the tool to GPT-4.
    var toolDefinition: [String: Any] { get }
    
    /// The actual logic to execute when the tool is called.
    func execute(arguments: [String: Any]) async throws -> String
}

// MARK: - Hardware Mock Layer

/// An Actor representing the physical state of the home.
/// Actors are critical here to prevent data races when multiple tools 
/// attempt to modify the same device simultaneously.
@available(iOS 18.0, *)
actor HomeHardwareManager {
    private var lightBrightness: Int = 50
    private var thermostatTemp: Double = 70.0
    private var isLocked: Bool = true

    func setLight(level: Int) async -> String {
        self.lightBrightness = max(0, min(100, level))
        return "Success: Light brightness set to \(lightBrightness)%."
    }

    func setThermostat(temp: Double) async -> String {
        self.thermostatTemp = temp
        return "Success: Thermostat set to \(temp)°F."
    }

    func setLock(locked: Bool) async -> String {
        self.isLocked = locked
        return "Success: Door is now \(locked ? "locked" : "unlocked")."
    }
    
    func getStatus() -> String {
        return "Status: Light \(lightBrightness)%, Temp \(thermostatTemp)°F, Locked: \(isLocked)"
    }
}

// MARK: - Concrete Tool Implementations

/// Tool for controlling lighting.
struct LightControlTool: SmartHomeTool {
    let name = "set_light_brightness"
    let hardware: HomeHardwareManager

    var toolDefinition: [String: Any] {
        [
            "type": "function",
            "function": [
                "name": name,
                "description": "Adjust the brightness of the lights in a specific room.",
                "parameters": [
                    "type": "object",
                    "properties": [
                        "level": ["type": "integer", "description": "Brightness level from 0 to 100"],
                        "room": ["type": "string", "description": "The room name, e.g., 'living room'"]
                    ],
                    "required": ["level", "room"]
                ]
            ]
        ]
    }

    func execute(arguments: [String: Any]) async throws -> String {
        guard let level = arguments["level"] as? Int,
              let room = arguments["room"] as? String else {
            throw AgentError.invalidArguments
        }
        // In a real app, we'd pass the room to the hardware manager
        return await hardware.setLight(level: level)
    }
}

/// Tool for controlling the HVAC system.
struct ThermostatTool: SmartHomeTool {
    let name = "set_thermostat"
    let hardware: HomeHardwareManager

    var toolDefinition: [String: Any] {
        [
            "type": "function",
            "function": [
                "name": name,
                "description": "Set the temperature of the thermostat.",
                "parameters": [
                    "type": "object",
                    "properties": [
                        "temperature": ["type": "number", "description": "Target temperature in Fahrenheit"]
                    ],
                    "required": ["temperature"]
                ]
            ]
        ]
    }

    func execute(arguments: [String: Any]) async throws -> String {
        guard let temp = arguments["temperature"] as? Double else {
            throw AgentError.invalidArguments
        }
        return await hardware.setThermostat(temp: temp)
    }
}

// MARK: - The Orchestrator (The Agent)

/// The Agent acts as the brain of the application.
/// It manages the conversation state and the tool execution loop.
@available(iOS 18.0, *)
actor SmartHomeAgent {
    private let hardware: HomeHardwareManager
    private var toolRegistry: [String: any SmartHomeTool] = [:]
    
    /// The conversation history, essential for multi-turn reasoning.
    private var messages: [[String: String]] = []

    init(hardware: HomeHardwareManager) {
        self.hardware = hardware
    }

    /// Registers a new tool into the agent's capabilities.
    func register(tool: any SmartHomeTool) {
        toolRegistry[tool.name] = tool
    }

    /// Returns the list of tool definitions formatted for the OpenAI API.
    func getToolSchemas() -> [[String: Any]] {
        return toolRegistry.values.map { $0.toolDefinition }
    }

    /// The primary entry point for user interaction.
    /// This implements the "Agentic Loop": Prompt -> LLM -> Tool Call -> Result -> LLM -> Final Answer.
    func processUserRequest(_ input: String) async throws -> String {
        // 1. Add user message to history
        messages.append(["role": "user", "content": input])
        
        // 2. Start the reasoning loop
        return try await runReasoningLoop()
    }

    private func runReasoningLoop() async throws -> String {
        // NOTE: In a real implementation, you would call the OpenAI API here.
        // We are simulating the API response for the purpose of this technical demonstration.
        
        // SIMULATION: User says "It's dark and cold."
        // The LLM would return a 'tool_calls' array.
        let simulatedToolCalls = [
            (id: "call_001", name: "set_light_brightness", args: ["level": 80, "room": "living room"]),
            (id: "call_002", name: "set_thermostat", args: ["temperature": 72.5])
        ]

        // 3. Handle Tool Calls
        var toolResults: [[String: String]] = []
        
        // We use a TaskGroup to execute multiple tool calls in parallel, 
        // maximizing efficiency in a real-world hardware environment.
        try await withThrowingTaskGroup(of: (String, String).self) { group in
            for call in simulatedToolCalls {
                group.addTask {
                    guard let tool = self.toolRegistry[call.name] else {
                        throw AgentError.toolNotFound(call.name)
                    }
                    
                    let result = try await tool.execute(arguments: call.args)
                    return (call.id, result)
                }
            }

            for try await (callId, result) in group {
                toolResults.append([
                    "role": "tool",
                    "tool_call_id": callId,
                    "content": result
                ])
            }
        }

        // 4. Feed the results back to the LLM (Simulated)
        // In reality, you'd append toolResults to 'messages' and call the API again.
        let finalResponse = "I've adjusted the lights to 80% and set the thermostat to 72.5°F for you."
        
        return finalResponse
    }
}

// MARK: - Application Entry Point Simulation

@main
struct SmartHomeApp {
    static func main() async {
        print("🚀 Initializing Smart Home Orchestrator...")
        
        let hardware = HomeHardwareManager()
        let agent = SmartHomeAgent(hardware: hardware)
        
        // Registering tools
        await agent.register(tool: LightControlTool(hardware: hardware))
        await agent.register(tool: ThermostatTool(hardware: hardware))
        
        print("✅ Agent Ready. Waiting for user input...")
        
        do {
            let userPrompt = "It's a bit dark and chilly in here."
            print("👤 User: \(userPrompt)")
            
            let response = try await agent.processUserRequest(userPrompt)
            print("🤖 Agent: \(response)")
            
            let finalState = await hardware.getStatus()
            print("🏠 Current Home State: \(finalState)")
            
        } catch {
            print("❌ Error: \(error.localizedDescription)")
        }
    }
}
