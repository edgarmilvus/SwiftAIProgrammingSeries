
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import Observation

    @available(iOS 18.0, *)
    @Observable
    class SpeechViewModel {
        private let speechService = SpeechRecognitionService() // An instance of our actor
        var currentTranscription: String = "Tap to speak..."
        var isRecognizing: Bool = false
        var recognitionError: Error?

        func toggleRecognition() {
            Task {
                if isRecognizing {
                    await speechService.stopRecognition()
                    await MainActor.run {
                        self.isRecognizing = await speechService.isRecognizing
                        // Potentially reset transcription or show final result
                    }
                } else {
                    do {
                        try await speechService.startRecognition()
                        // Start polling/observing the actor's state
                        await MainActor.run {
                            self.isRecognizing = await speechService.isRecognizing
                            self.currentTranscription = await speechService.currentTranscription
                            self.recognitionError = nil
                        }
                        // Continuously update transcription from the actor
                        for await newText in speechService.transcriptionStream() { // Hypothetical stream from actor
                           await MainActor.run { self.currentTranscription = newText }
                        }
                    } catch {
                        await MainActor.run {
                            self.recognitionError = error
                            self.isRecognizing = false
                        }
                    }
                }
            }
        }

        // A better way to observe actor state without polling:
        // The actor could publish its state changes via an AsyncStream or similar.
        // For simplicity, let's assume direct access for now, or a more sophisticated
        // observation pattern where the actor 'sends' updates to the view model.
        // For a true @Observable integration, the SpeechRecognitionService itself
        // could be an @Observable class *if* it didn't need actor isolation for
        // its internal mutable state, or the ViewModel could be a proxy.
        // A common pattern is for the actor to *send* updates to a non-actor @Observable view model.
    }

    @available(iOS 18.0, *)
    struct SpeechRecognitionView: View {
        @State private var viewModel = SpeechViewModel()

        var body: some View {
            VStack {
                Text(viewModel.currentTranscription)
                    .font(.title)
                    .padding()

                Button(viewModel.isRecognizing ? "Stop Speaking" : "Start Speaking") {
                    viewModel.toggleRecognition()
                }
                .buttonStyle(.borderedProminent)

                if let error = viewModel.recognitionError {
                    Text("Error: \(error.localizedDescription)")
                        .foregroundStyle(.red)
                }
            }
        }
    }
    