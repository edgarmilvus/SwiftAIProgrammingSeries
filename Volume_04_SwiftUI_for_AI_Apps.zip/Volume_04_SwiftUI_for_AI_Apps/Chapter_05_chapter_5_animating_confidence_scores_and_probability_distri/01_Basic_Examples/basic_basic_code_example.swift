
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Foundation // For Double.random(in:)

/// A SwiftUI view that displays and animates a simulated AI confidence score.
///
/// This view represents a basic component for showing how confident an AI model
/// is about its current prediction, such as understanding a voice command.
/// The confidence score is displayed as a percentage and a horizontal progress bar.
/// Changes to the confidence score are animated for a smoother user experience.
struct ConfidenceDisplayView: View {
    /// The current confidence score, ranging from 0.0 to 1.0.
    /// @State property wrapper makes this a source of truth for the view,
    /// and any changes will trigger a view update.
    @State private var confidence: Double = 0.75 // Initial simulated confidence

    /// The body of the SwiftUI view.
    var body: some View {
        VStack(spacing: 20) {
            Text("Voice Assistant Confidence")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.bottom, 10)

            // 1. Display the confidence score as text
            Text(String(format: "%.1f%% Confidence", confidence * 100))
                .font(.largeTitle)
                .fontWeight(.semibold)
                .foregroundColor(colorForConfidence(confidence)) // Dynamic text color
                .animation(.easeInOut(duration: 0.5), value: confidence) // Animate text color/size changes
                .id("confidenceText_\(confidence)") // Unique ID to force text re-render with animation

            // 2. Visual progress bar for confidence
            ZStack(alignment: .leading) {
                // Background of the progress bar
                Capsule()
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: 30)

                // Foreground (filled part) of the progress bar
                Capsule()
                    .fill(colorForConfidence(confidence)) // Dynamic bar color
                    .frame(width: max(30, CGFloat(confidence) * 300), height: 30) // Ensure min width for capsule shape
                    .animation(.easeInOut(duration: 0.7), value: confidence) // Animate width changes
            }
            .frame(width: 300) // Fixed width for the entire progress bar container
            .padding(.horizontal)

            Spacer()

            // 3. Button to simulate a new AI prediction
            Button {
                // Use withAnimation to smoothly transition the UI when 'confidence' changes.
                // SwiftUI automatically animates properties that are affected by the state change.
                withAnimation(.easeInOut(duration: 0.8)) {
                    self.confidence = Double.random(in: 0.0...1.0)
                }
            } label: {
                Label("Simulate New Prediction", systemImage: "arrow.clockwise.circle.fill")
                    .font(.headline)
                    .padding()
                    .background(Color.accentColor)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.bottom, 20)
        }
        .padding()
        .navigationTitle("AI Confidence")
    }

    /// Helper function to determine color based on confidence level.
    /// - Parameter score: The confidence score (0.0 to 1.0).
    /// - Returns: A `Color` representing the confidence level.
    private func colorForConfidence(_ score: Double) -> Color {
        if score > 0.8 {
            return .green
        } else if score > 0.5 {
            return .orange
        } else {
            return .red
        }
    }
}

/// The main entry point for the app, hosting our ConfidenceDisplayView.
struct ContentView: View {
    var body: some View {
        // A NavigationView is often used to provide a title bar and navigation capabilities.
        // For this simple example, it just frames our view nicely.
        NavigationView {
            ConfidenceDisplayView()
        }
    }
}

// MARK: - Preview Provider
/// Provides a preview of the `ContentView` in Xcode's canvas.
#Preview {
    ContentView()
}
