
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation

// @available(macOS 10.6, *) // Bookmark APIs are available since macOS 10.6
// The prompt specified iOS 18.0 for general Swift features.
// For macOS specific APIs, I'll use macOS availability.
// For Swift 6 features like 'Sendable', it's implicit.

/// An actor responsible for managing security-scoped file system access.
/// Ensures thread-safe operations for resolving, activating, and deactivating bookmarks.
@available(macOS 11.0, iOS 18.0, *) // Using macOS 11.0 for modern context, iOS 18.0 as per prompt
actor FileAccessManager {
    // A dictionary to hold active security-scoped URLs, mapping the original file identifier
    // (e.g., a path or UUID) to the security-scoped URL and its access count.
    private var activeAccesses: [URL: (securityScopedURL: URL, accessCount: Int)] = [:]
    private let bookmarkStorageKey = "com.aiagent.fileBookmarks"

    /// Persists bookmark data for a given URL.
    /// - Parameter url: The security-scoped URL obtained from user interaction.
    /// - Returns: The raw bookmark data.
    func createAndStoreBookmark(for url: URL) throws -> Data {
        let bookmarkData = try url.bookmarkData(options: .withSecurityScope,
                                                 includingResourceValuesForKeys: nil,
                                                 relativeTo: nil)
        
        // In a real app, you'd store this bookmarkData associated with a user-friendly name or identifier.
        // For simplicity, we'll just return it.
        // For persistent storage, you might save it to UserDefaults or a custom database.
        // Example: UserDefaults.standard.set(bookmarkData, forKey: "modelBookmark-\(url.lastPathComponent)")
        
        return bookmarkData
    }

    /// Resolves bookmark data back to a security-scoped URL and activates access.
    /// This method is reentrant and manages an internal access count.
    /// - Parameter bookmarkData: The raw bookmark data previously stored.
    /// - Returns: The security-scoped URL with active access.
    func resolveAndStartAccessing(bookmarkData: Data) async throws -> URL {
        var isStale = false
        let resolvedURL = try URL(resolvingBookmarkData: bookmarkData,
                                  options: .withSecurityScope,
                                  relativeTo: nil,
                                  bookmarkDataIsStale: &isStale)

        if isStale {
            // Handle stale bookmark: e.g., prompt user to re-select the file
            print("Bookmark is stale. User might need to re-select the file.")
            throw FileAccessError.staleBookmark
        }
        
        // Ensure only one active access per unique resolved URL
        if let existingAccess = activeAccesses[resolvedURL] {
            activeAccesses[resolvedURL] = (existingAccess.securityScopedURL, existingAccess.accessCount + 1)
            return existingAccess.securityScopedURL
        }

        guard resolvedURL.startAccessingSecurityScopedResource() else {
            throw FileAccessError.accessDenied
        }
        
        activeAccesses[resolvedURL] = (resolvedURL, 1)
        print("Started accessing security-scoped resource: \(resolvedURL.lastPathComponent)")
        return resolvedURL
    }

    /// Deactivates access to a security-scoped URL.
    /// Decrements the access count and stops access when count reaches zero.
    /// - Parameter securityScopedURL: The URL previously returned by `resolveAndStartAccessing`.
    func stopAccessing(securityScopedURL: URL) {
        guard let accessInfo = activeAccesses[securityScopedURL] else {
            print("Attempted to stop access for an inactive URL: \(securityScopedURL.lastPathComponent)")
            return
        }

        let newAccessCount = accessInfo.accessCount - 1
        if newAccessCount <= 0 {
            securityScopedURL.stopAccessingSecurityScopedResource()
            activeAccesses[securityScopedURL] = nil
            print("Stopped accessing security-scoped resource: \(securityScopedURL.lastPathComponent)")
        } else {
            activeAccesses[securityScopedURL] = (accessInfo.securityScopedURL, newAccessCount)
            print("Decremented access count for \(securityScopedURL.lastPathComponent) to \(newAccessCount)")
        }
    }
    
    enum FileAccessError: Error, LocalizedError {
        case staleBookmark
        case accessDenied
        case unknown(Error)
        
        var errorDescription: String? {
            switch self {
            case .staleBookmark: return "The bookmark is stale. The file may have moved or been deleted."
            case .accessDenied: return "Failed to gain security-scoped access to the resource."
            case .unknown(let error): return "An unknown error occurred: \(error.localizedDescription)"
            }
        }
    }
}
