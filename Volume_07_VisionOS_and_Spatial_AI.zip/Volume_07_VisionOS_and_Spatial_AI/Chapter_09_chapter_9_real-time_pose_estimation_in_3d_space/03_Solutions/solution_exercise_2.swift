
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import ARKit
import simd

@Observable
class BiometricMonitor {
    var wristDistanceCM: Float = 0.0
    var isTargetReached: Bool = false
    let thresholdMeters: Float = 1.5

    @MainActor
    func processFrame(anchor: ARBodyAnchor) {
        // 1. Identify the joint transforms
        guard let leftWristTransform = anchor.skeleton.modelTransform(for: .leftWrist),
              let rightWristTransform = anchor.skeleton.modelTransform(for: .rightWrist) else {
            return
        }

        // 2. Convert to world space positions
        let leftPos = simd_make_float3(anchor.transform * leftWristTransform.columns.3)
        let rightPos = simd_make_float3(anchor.transform * rightWristTransform.columns.3)

        // 3. Use SIMD for high-performance distance calculation
        let distanceMeters = simd_distance(leftPos, rightPos)

        // 4. Update UI state
        self.wristDistanceCM = distanceMeters * 100.0
        self.isTargetReached = distanceMeters >= thresholdMeters
    }
}

struct BiometricOverlay: View {
    var monitor: BiometricMonitor

    var body: some View {
        VStack {
            Text("Distance: \(String(format: "%.1f", monitor.wristDistanceCM)) cm")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(monitor.isTargetReached ? .green : .red)
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(15)
    }
}
