
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import SwiftData
import SwiftUI

@Model
final class JournalEntry {
    var id: UUID
    var title: String
    var timestamp: Date
    var content: String
    // High-dimensional vector: 1536 Floats (~6KB per entry)
    var embedding: [Float] 
    
    init(title: String, content: String, embedding: [Float] = []) {
        self.id = UUID()
        self.title = title
        self.content = content
        self.timestamp = Date()
        self.embedding = embedding
    }
}

@MainActor
class JournalDataManager: ObservableObject {
    @Published var entries: [JournalEntry] = []
    private var modelContext: ModelContext
    private var currentOffset = 0
    private let pageSize = 50
    private var isFetching = false

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }

    func fetchNextPage() async {
        guard !isFetching else { return }
        isFetching = true
        
        let offset = currentOffset
        let limit = pageSize
        
        // Perform fetching on a background task to keep UI responsive
        let newEntries = await Task.detached {
            let descriptor = FetchDescriptor<JournalEntry>(
                sortBy: [SortDescriptor(\.timestamp, order: .reverse)]
            )
            var optimizedDescriptor = descriptor
            optimizedDescriptor.fetchLimit = limit
            optimizedDescriptor.fetchOffset = offset
            
            // In a real scenario, we perform the fetch in a separate context
            // to ensure the main thread is never blocked by the SQLite I/O.
            do {
                // Using a temporary context for the background fetch
                // Note: In production, pass the ModelContainer, not the context.
                // For this exercise, we assume the context is available.
                return try self.modelContext.fetch(optimizedDescriptor)
            } catch {
                print("Fetch failed: \(error)")
                return []
            }
        }.value

        if !newEntries.isEmpty {
            self.entries.append(contentsOf: newEntries)
            self.currentOffset += limit
        }
        
        isFetching = false
    }
}

struct JournalListView: View {
    @StateObject var manager: JournalDataManager

    var body: some View {
        List {
            ForEach(manager.entries) { entry in
                VStack(alignment: .leading) {
                    Text(entry.title).font(.headline)
                    Text(entry.timestamp, style: .date).font(.caption)
                }
                .onAppear {
                    if entry == manager.entries.last {
                        Task { await manager.fetchNextPage() }
                    }
                }
            }
        }
        .task {
            await manager.fetchNextPage()
        }
    }
}
