
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct LedgerEntry: Codable, Sendable {
    let transactionID: String // Must be TXN-XXXXXX
    let amount: Decimal
    let currency: String      // Must be 3-letter ISO
    let timestamp: Date
}

@available(iOS 18.0, macOS 15.0, *)
enum ValidationError: Error {
    case invalidFormat(String)
    case businessLogicViolation(String)
}

@available(iOS 18.0, macOS 15.0, *)
actor ResilienceEngine {
    private let maxRetries = 3
    private let decoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }()

    private func callLLM(prompt: String, input: String) async throws -> String {
        // Simulated LLM behavior: First attempt fails, second attempt succeeds
        // This is to demonstrate the self-correction loop.
        try await Task.sleep(for: .seconds(1))
        
        // Simulate a failure on the first attempt (wrong ID format and currency length)
        if !input.contains("RETRY_TRIGGER") {
            return """
            {
                "transactionID": "BAD-ID-123",
                "amount": 150.50,
                "currency": "US-DOLLAR",
                "timestamp": "2025-01-01T12:00:00Z"
            }
            """
        } else {
            // Corrected version
            return """
            {
                "transactionID": "TXN-998877",
                "amount": 150.50,
                "currency": "USD",
                "timestamp": "2025-01-01T12:00:00Z"
            }
            """
        }
    }

    private func validate(_ entry: LedgerEntry) throws {
        // Regex for TXN-XXXXXX
        let idRegex = /^TXN-\d{6}$/
        if entry.transactionID.wholeMatch(of: idRegex) == nil {
            throw ValidationError.invalidFormat("transactionID must follow pattern TXN-XXXXXX")
        }
        
        if entry.currency.count != 3 {
            throw ValidationError.businessLogicViolation("currency must be a 3-letter ISO code")
        }
    }

    func ingestData(rawInput: String) async throws -> LedgerEntry {
        var currentInput = rawInput
        var lastError: Error?
        var lastMalformedJSON: String?

        for attempt in 1...maxRetries {
            print("Attempt \(attempt)...")
            
            let systemPrompt = "Extract ledger entry data into JSON. Schema: {transactionID: string, amount: number, currency: string, timestamp: ISO8601}."
            let rawResponse = try await callLLM(prompt: systemPrompt, input: currentInput)
            
            do {
                let data = Data(rawResponse.utf8)
                let entry = try decoder.decode(LedgerEntry.self, from: data)
                
                // If decoding succeeds, run business logic validation
                try validate(entry)
                
                // If we reach here, everything is perfect
                return entry
                
            } catch {
                // Capture error details for the next prompt
                lastError = error
                lastMalformedJSON = rawResponse
                
                // Construct the "Correction Prompt"
                let errorDescription = (error as? DecodingError)?.localizedDescription ?? error.localizedDescription
                currentInput = """
                Original Input: \(rawInput)
                Faulty JSON: \(rawResponse)
                Error encountered: \(errorDescription)
                
                Please fix the JSON to match the schema and validation rules.
                """
                // For simulation purposes, we trigger the "success" branch in the next call
                currentInput += " (RETRY_TRIGGER)"
            }
        }

        throw lastError ?? ValidationError.invalidFormat("Max retries reached")
    }
}
