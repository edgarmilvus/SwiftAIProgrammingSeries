
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Example AppIntent leveraging Apple Intelligence for summarization
@available(iOS 18.0, *)
struct SummarizeDocumentIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize Document"
    static var description = IntentDescription("Summarizes the content of a document using Apple Intelligence.")

    @Parameter(title: "Document Content")
    var documentContent: String

    @Parameter(title: "Summary Length", default: .medium)
    var summaryLength: SummaryLengthOption

    enum SummaryLengthOption: String, AppEnum {
        static var typeDisplayRepresentation: TypeDisplayRepresentation = "Summary Length"
        static var caseDisplayRepresentations: [Self: LocalizedStringResource] = [
            .short: "Short",
            .medium: "Medium",
            .long: "Long"
        ]
        case short, medium, long
    }

    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        // This is where the AI magic happens.
        // Imagine an LLMService that wraps Apple's on-device LLM APIs.
        let llmService = LLMService.shared // Assume a shared actor for LLM interaction

        // The actual call to the on-device LLM API
        let summary = try await llmService.generateSummary(
            from: documentContent,
            length: summaryLength
        )

        return .result(value: summary)
    }
}
