
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CoreML
import Vision
import UIKit // For UIImage and CVPixelBuffer conversion
import Foundation // For CFAbsoluteTimeGetCurrent

// Assume CustomSegmentationModel.mlmodel is added to the project.
// IMPORTANT: Replace 'CustomSegmentationModel' with your actual generated model class.

// MARK: - Exercise 4: Benchmarking Custom Core ML Models Across Compute Units

struct BenchmarkResult {
    let computeUnit: MLComputeUnits
    let averageInferenceTimeMs: Double
    let standardDeviationMs: Double
    let errorMessage: String?
    
    // CustomStringConvertible for easy printing
    var description: String {
        if let error = errorMessage {
            return "Compute Unit: \(computeUnit.description) - FAILED: \(error)"
        } else {
            return String(format: "Compute Unit: \(computeUnit.description), Avg Time: %.2f ms, Std Dev: %.2f ms",
                          averageInferenceTimeMs, standardDeviationMs)
        }
    }
}

func benchmarkModel<Model: MLModel>( // Generic function for any MLModel type
    modelClass: Model.Type, // Pass the type of your generated ML model class
    inputImage: UIImage,
    modelInputWidth: Int,
    modelInputHeight: Int,
    warmupRuns: Int = 10,
    measurementRuns: Int = 100
) -> [BenchmarkResult] {
    guard let inputPixelBuffer = inputImage.toCVPixelBuffer(width: modelInputWidth, height: modelInputHeight) else {
        fatalError("Failed to convert UIImage to CVPixelBuffer for benchmarking.")
    }

    let computeUnitsToTest: [MLComputeUnits] = [.cpuOnly, .cpuAndGPU, .cpuAndNeuralEngine, .all]
    var allResults: [BenchmarkResult] = []

    for unit in computeUnitsToTest {
        print("\n--- Benchmarking with \(unit.description) ---")
        var inferenceTimes: [Double] = []
        var errorMessage: String?

        do {
            let configuration = MLModelConfiguration()
            configuration.computeUnits = unit

            // Initialize the model using its generated class initializer
            let model = try modelClass.init(configuration: configuration)
            print("Model loaded successfully with \(unit.description).")

            // IMPORTANT: Create the input object for the model.
            // This part is highly dependent on your model's generated input type.
            // You might need to cast `model` to your specific type to access its input method.
            let modelInputProvider: MLFeatureProvider
            if let customModel = model as? CustomSegmentationModel { // Replace with your actual model class
                // Assuming CustomSegmentationModel has an initializer or method that takes CVPixelBuffer
                // This is a common pattern where the generated model class provides convenience methods.
                // If not, you'd create the input provider manually, e.g., CustomSegmentationModelInput(image: inputPixelBuffer)
                modelInputProvider = try customModel.prediction(from: inputPixelBuffer) // Placeholder: adapt this line
            } else {
                // Generic fallback if the model doesn't match a specific known type with a convenience method.
                // This assumes the model's primary input feature is named "image" and takes a CVPixelBuffer.
                // You might need to adjust this based on your model's actual input feature name.
                let imageFeature = try MLFeatureValue(cgImage: inputImage.cgImage!, options: [.imagePixelFormat: NSNumber(value: kCVPixelFormatType_32BGRA)])
                modelInputProvider = try MLDictionaryFeatureProvider(dictionary: ["image": imageFeature])
                print("Warning: Using generic MLFeatureProvider input. Adapt to specific model input type if needed.")
            }


            // Warm-up runs
            print("Performing \(warmupRuns) warm-up inferences...")
            for _ in 0..<warmupRuns {
                _ = try model.prediction(input: modelInputProvider)
            }

            // Measurement runs
            print("Performing \(measurementRuns) measurement inferences...")
            for _ in 0..<measurementRuns {
                let startTime = CFAbsoluteTimeGetCurrent()
                _ = try model.prediction(input: modelInputProvider)
                let endTime = CFAbsoluteTimeGetCurrent()
                inferenceTimes.append((endTime - startTime) * 1000) // Convert to milliseconds
            }

            let sum = inferenceTimes.reduce(0, +)
            let average = sum / Double(inferenceTimes.count)
            
            // Calculate standard deviation
            let sumOfSquaredDifferences = inferenceTimes.map { pow($0 - average, 2) }.reduce(0, +)
            let standardDeviation = sqrt(sumOfSquaredDifferences / Double(inferenceTimes.count))

            allResults.append(BenchmarkResult(computeUnit: unit,
                                             averageInferenceTimeMs: average,
                                             standardDeviationMs: standardDeviation,
                                             errorMessage: nil))

        } catch let error as MLModelError {
            if error.errorCode == MLModelError.modelIncompatibleWithComputeUnits.rawValue {
                errorMessage = "Model incompatible with \(unit.description) on this device."
            } else {
                errorMessage = "MLModelError (\(error.errorCode)): \(error.localizedDescription)"
            }
            print("Error: \(errorMessage!)")
            allResults.append(BenchmarkResult(computeUnit: unit,
                                             averageInferenceTimeMs: 0,
                                             standardDeviationMs: 0,
                                             errorMessage: errorMessage))
        } catch {
            errorMessage = "Generic error: \(error.localizedDescription)"
            print("Error: \(errorMessage!)")
            allResults.append(BenchmarkResult(computeUnit: unit,
                                             averageInferenceTimeMs: 0,
                                             standardDeviationMs: 0,
                                             errorMessage: errorMessage))
        }
    }
    return allResults
}

func printBenchmarkReport(results: [BenchmarkResult]) {
    print("\n==================================================")
    print("        Core ML Compute Unit Benchmark Report     ")
    print("==================================================")

    var bestResult: BenchmarkResult? = nil

    for result in results {
        print("\n\(result.description)")

        if result.errorMessage == nil && (bestResult == nil || (result.averageInferenceTimeMs < (bestResult?.averageInferenceTimeMs ?? .infinity) && result.averageInferenceTimeMs > 0)) {
            bestResult = result
        }
    }

    print("\n==================================================")
    if let best = bestResult, best.errorMessage == nil {
        print("Recommendation: For this model and device, \(best.computeUnit.description) appears to be the most efficient, with an average inference time of \(String(format: "%.2f", best.averageInferenceTimeMs)) ms.")
    } else {
        print("Could not determine a clear recommendation due to errors or insufficient data.")
    }
    print("==================================================")
}

// Example usage:
/*
// 1. Add CustomSegmentationModel.mlmodel to your project.
//    (This needs to be a custom model you've trained or obtained).
//    For demonstration purposes, if you don't have a custom model,
//    you can use ResNet50.mlmodel here as well, but adapt input/output.
// 2. Add a sample image named "sample_segmentation_input.jpg" to your project's assets.
if let sampleInputImage = UIImage(named: "sample_segmentation_input") {
    // Assuming your custom segmentation model expects 256x256 input
    let results = benchmarkModel(
        modelClass: CustomSegmentationModel.self, // IMPORTANT: Replace with your actual model class
        inputImage: sampleInputImage,
        modelInputWidth: 256,
        modelInputHeight: 256,
        warmupRuns: 10,
        measurementRuns: 100
    )
    printBenchmarkReport(results: results)
} else {
    print("Error: Could not load 'sample_segmentation_input.jpg'. Make sure it's in your assets.")
}
*/
