
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CoreML

func prepareActivitySensorInput(readings: [Double]) throws -> MLMultiArray {
    let sequenceLength = readings.count
    guard sequenceLength > 0 else {
        throw NSError(domain: "SensorInputError", code: 100, userInfo: [NSLocalizedDescriptionKey: "Input readings array cannot be empty."])
    }

    // 1. Determine the shape of the MLMultiArray based on the input 'readings'.
    let shape: [NSNumber] = [NSNumber(value: sequenceLength)]

    // 2. Initialize an MLMultiArray with the correct shape and .float32 data type.
    let multiArray = try MLMultiArray(shape: shape, dataType: .float32)

    // 3. Iterate through the 'readings' array, convert each Double to Float32,
    //    and assign it to the corresponding index in the MLMultiArray.
    for i in 0..<sequenceLength {
        multiArray[i] = NSNumber(value: Float(readings[i]))
    }

    return multiArray
}

// Example usage (for testing your implementation):
/*
let rawReadings: [Double] = [0.1, 0.5, 0.2, 0.8, 0.3]
do {
    let modelInput = try prepareActivitySensorInput(readings: rawReadings)
    print("Prepared MLMultiArray for activity sensor input:")
    print("Shape: \(modelInput.shape)")
    print("DataType: \(modelInput.dataType)")
    // You can print a few values to verify
    for i in 0..<modelInput.count {
        print("Value at index \(i): \(modelInput[i].floatValue)")
    }
} catch {
    print("Error preparing input: \(error)")
}
*/
