
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

// MARK: - Models (Sendable)

/// Represents a single message in the conversation.
/// Being a struct makes it Sendable by default.
struct ChatMessage: Sendable, Identifiable, Codable {
    let id: UUID
    let role: MessageRole
    let content: String
    
    enum MessageRole: String, Sendable, Codable {
        case user, assistant, system
    }
    
    init(id: UUID = UUID(), role: MessageRole, content: String) {
        self.id = id
        self.role = role
        self.content = content
    }
}

/// Represents a tool result used in RAG or Agentic workflows.
struct ToolResult: Sendable {
    let toolName: String
    let output: String
}

// MARK: - Service Layer (The Actor)

/// The AgentService is the "Chef." It manages the complex, 
/// non-deterministic state of the AI conversation.
actor AgentService {
    private var conversationHistory: [ChatMessage] = []
    private let modelName: String
    
    init(modelName: String = "gpt-4o") {
        self.modelName = modelName
    }
    
    /// Processes a user prompt using an agentic workflow.
    /// This method is isolated to the actor, protecting `conversationHistory`.
    func processPrompt(_ prompt: String) async throws -> [ChatMessage] {
        // 1. Add user message to history
        let userMsg = ChatMessage(role: .user, content: prompt)
        conversationHistory.append(userMsg)
        
        // 2. Simulate an Agentic Workflow: 
        // In a real app, this would involve calling OpenAI, 
        // potentially calling tools, and performing RAG.
        
        // Let's simulate a "Tool Call" using Structured Concurrency
        let toolResult = try await performParallelToolCalls()
        
        // 3. Simulate LLM generating a response based on tool results
        let aiResponseContent = "Based on my research (\(toolResult.toolName)), the answer is: \(toolResult.output)"
        let assistantMsg = ChatMessage(role: .assistant, content: aiResponseContent)
        
        conversationHistory.append(assistantMsg)
        
        return conversationHistory
    }
    
    /// Demonstrates Structured Concurrency within an Actor.
    /// We use a TaskGroup to perform multiple "searches" in parallel.
    private func performParallelToolCalls() async throws -> ToolResult {
        try await withThrowingTaskGroup(of: ToolResult.self) { group in
            // Task 1: Search Web
            group.addTask {
                // Simulate network latency
                try await Task.sleep(for: .seconds(1))
                return ToolResult(toolName: "WebSearch", output: "Current weather is sunny.")
            }
            
            // Task 2: Search Local Documents (RAG)
            group.addTask {
                try await Task.sleep(for: .seconds(0.5))
                return ToolResult(toolName: "LocalRAG", output: "User prefers sunny weather.")
            }
            
            // Collect the first successful result as a simplification
            guard let firstResult = try await group.next() else {
                throw NSError(domain: "AgentError", code: -1)
            }
            
            // Cancel remaining tasks in the group
            group.cancelAll()
            return firstResult
        }
    }
    
    func clearHistory() {
        conversationHistory.removeAll()
    }
}

// MARK: - ViewModel Layer (@Observable)

/// The ViewModel is the "Head Waiter." 
/// It lives on the @MainActor to ensure UI safety.
@Observable
@available(iOS 18.0, *)
@MainActor
final class ChatViewModel {
    // Published state for the SwiftUI View
    var messages: [ChatMessage] = []
    var isProcessing: Bool = false
    var errorMessage: String?
    
    // The dependency on the Actor
    private let agentService: AgentService
    
    init(agentService: AgentService) {
        self.agentService = agentService
    }
    
    /// The entry point for user interaction.
    func sendMessage(_ text: String) {
        guard !text.isEmpty else { return }
        
        // Optimistically add the user message to the UI
        let userMsg = ChatMessage(role: .user, content: text)
        messages.append(userMsg)
        
        isProcessing = true
        errorMessage = nil
        
        // Start an unstructured task to bridge the MainActor to the AgentService Actor.
        // We use Task here because the function itself is synchronous, 
        // but the work is asynchronous.
        Task {
            do {
                // Crossing the boundary to the Actor
                let updatedHistory = try await agentService.processPrompt(text)
                
                // Returning to the MainActor to update the UI
                self.messages = updatedHistory
                self.isProcessing = false
            } catch {
                self.errorMessage = "Failed to reach the AI: \(error.localizedDescription)"
                self.isProcessing = false
            }
        }
    }
    
    func clearChat() {
        Task {
            await agentService.clearHistory()
            messages.removeAll()
        }
    }
}
