
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.swift
// Description: Solution for Exercise 6
// ==========================================

import AppKit // For macOS development
import CoreML
import NaturalLanguage

// Assume EmailCategorizer.mlmodel has been added to the project
// and Xcode has automatically generated the EmailCategorizer class.

class EmailCategorizerViewController: NSViewController {
    // UI Elements
    private let emailTextView: NSTextView = {
        let textView = NSTextView()
        textView.font = NSFont.systemFont(ofSize: 16)
        textView.isRichText = false
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.textContainer?.widthTracksTextView = true
        textView.textContainerInset = NSSize(width: 5, height: 5)
        textView.layer?.borderColor = NSColor.lightGray.cgColor
        textView.layer?.borderWidth = 1.0
        textView.layer?.cornerRadius = 5.0
        return textView
    }()

    private let scrollView: NSScrollView = {
        let scrollView = NSScrollView()
        scrollView.hasVerticalScroller = true
        scrollView.autohidesScrollers = true
        scrollView.borderType = .noBorder
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        return scrollView
    }()

    private let categorizeButton: NSButton = {
        let button = NSButton(title: "Categorize Email", target: nil, action: nil)
        button.bezelStyle = .rounded
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let categoryLabel: NSTextField = {
        let textField = NSTextField(labelWithString: "Category: ")
        textField.font = NSFont.boldSystemFont(ofSize: 18)
        textField.isEditable = false
        textField.isSelectable = false
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()

    // Core ML Model instance
    private var emailClassifier: EmailCategorizer?

    // Common stop words for English
    private let stopWords: Set<String> = [
        "a", "an", "the", "and", "but", "or", "for", "nor", "on", "at", "to", "from", "by", "with",
        "in", "of", "is", "am", "are", "was", "were", "be", "been", "being", "have", "has", "had",
        "do", "does", "did", "not", "no", "don't", "can't", "won't", "shouldn't", "wouldn't",
        "couldn't", "i", "me", "my", "myself", "we", "our", "ours", "ourselves", "you", "your",
        "yours", "yourself", "yourselves", "he", "him", "his", "himself", "she", "her", "hers",
        "herself", "it", "its", "itself", "they", "them", "their", "theirs", "themselves", "what",
        "which", "who", "whom", "this", "that", "these", "those", "if", "then", "than", "as",
        "until", "while", "of", "at", "by", "for", "with", "about", "against", "between", "into",
        "through", "during", "before", "after", "above", "below", "to", "from", "up", "down", "in",
        "out", "on", "off", "over", "under", "again", "further", "then", "once", "here", "there",
        "when", "where", "why", "how", "all", "any", "both", "each", "few", "more", "most", "other",
        "some", "such", "no", "nor", "not", "only", "own", "same", "so", "than", "too", "very",
        "s", "t", "can", "will", "just", "don", "should", "now"
    ]

    override func loadView() {
        self.view = NSView()
        self.view.wantsLayer = true // Enable layer backing for custom borders/shadows
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadModel()
    }

    private func setupUI() {
        view.addSubview(scrollView)
        scrollView.documentView = emailTextView
        view.addSubview(categorizeButton)
        view.addSubview(categoryLabel)

        // Set button target and action
        categorizeButton.target = self
        categorizeButton.action = #selector(categorizeEmail)

        // Layout constraints
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            scrollView.heightAnchor.constraint(equalToConstant: 250),

            categorizeButton.topAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: 20),
            categorizeButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            categorizeButton.widthAnchor.constraint(equalToConstant: 200),
            categorizeButton.heightAnchor.constraint(equalToConstant: 40),

            categoryLabel.topAnchor.constraint(equalTo: categorizeButton.bottomAnchor, constant: 30),
            categoryLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            categoryLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }

    private func loadModel() {
        do {
            let config = MLModelConfiguration()
            self.emailClassifier = try EmailCategorizer(configuration: config)
            print("Core ML model 'EmailCategorizer' loaded successfully.")
        } catch {
            print("Error loading email categorizer model: \(error.localizedDescription)")
            categoryLabel.stringValue = "Error: Model failed to load."
        }
    }

    // MARK: - Preprocessing with NaturalLanguage
    private func preprocess(text: String) -> String {
        // 1. Normalization: Convert to lowercase
        let lowercasedText = text.lowercased()

        // 2. Tokenization
        let tokenizer = NLTokenizer(unit: .word)
        tokenizer.string = lowercasedText
        var tokens: [String] = []
        tokenizer.enumerateTokens(in: lowercasedText.startIndex..<lowercasedText.endIndex) { tokenRange, _ in
            tokens.append(String(lowercasedText[tokenRange]))
            return true
        }

        // 3. Lemmatization/Stemming (using NLTagger for lemmatization)
        let tagger = NLTagger(tagSchemes: [.lemma], options: .omitWhitespace)
        tagger.string = lowercasedText
        var lemmatizedTokens: [String] = []
        tagger.enumerateTags(in: lowercasedText.startIndex..<lowercasedText.endIndex, unit: .word, scheme: .lemma, options: .omitWhitespace) { tag, tokenRange in
            if let lemma = tag?.rawValue {
                lemmatizedTokens.append(lemma)
            } else {
                lemmatizedTokens.append(String(lowercasedText[tokenRange])) // Fallback to original token
            }
            return true
        }

        // For this example, let's use lemmatized tokens for further processing
        var processedTokens = lemmatizedTokens

        // 4. Stop Word Removal
        processedTokens = processedTokens.filter { !stopWords.contains($0) }

        // Rejoin tokens into a single string for the Core ML model
        return processedTokens.joined(separator: " ")
    }

    @objc private func categorizeEmail() {
        guard let emailContent = emailTextView.string, !emailContent.isEmpty else {
            categoryLabel.stringValue = "Category: Please enter email content."
            return
        }

        guard let classifier = emailClassifier else {
            categoryLabel.stringValue = "Category: Model not loaded, cannot categorize."
            return
        }

        // Perform preprocessing and prediction asynchronously
        Task {
            // Preprocessing can be CPU-intensive, run on a background thread
            let preprocessedText = await Task.detached {
                self.preprocess(text: emailContent)
            }.value

            do {
                let prediction = try await classifier.prediction(text: preprocessedText)
                // Update UI on the main actor
                await MainActor.run {
                    categoryLabel.stringValue = "Category: \(prediction.category.capitalized)"
                    // Optional: color-code categories
                    switch prediction.category {
                    case "work": categoryLabel.textColor = .systemBlue
                    case "personal": categoryLabel.textColor = .systemGreen
                    case "promotions": categoryLabel.textColor = .systemOrange
                    case "social": categoryLabel.textColor = .systemPurple
                    case "spam": categoryLabel.textColor = .systemRed
                    default: categoryLabel.textColor = .labelColor // Default macOS text color
                    }
                }
            } catch {
                await MainActor.run {
                    categoryLabel.stringValue = "Category Error: \(error.localizedDescription)"
                    categoryLabel.textColor = .systemRed
                }
                print("Error making email category prediction: \(error.localizedDescription)")
            }
        }
    }
}
