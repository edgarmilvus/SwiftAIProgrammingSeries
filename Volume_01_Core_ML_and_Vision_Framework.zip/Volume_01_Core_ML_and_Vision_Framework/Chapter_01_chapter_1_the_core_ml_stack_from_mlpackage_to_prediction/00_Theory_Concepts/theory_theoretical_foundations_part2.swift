
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor MLModelManager {
    private let model: MyImageClassifier

    init() {
        // Initialize the model with a configuration (e.g., to specify compute units)
        let config = MLModelConfiguration()
        config.computeUnits = .all // Use Neural Engine, GPU, CPU
        self.model = MyImageClassifier(configuration: config)
    }

    func classifyImage(_ pixelBuffer: CVPixelBuffer) async throws -> MyImageClassifierOutput {
        let input = MyImageClassifierInput(image: pixelBuffer)
        // Perform prediction asynchronously
        let output = try await Task.detached {
            return try self.model.prediction(input: input)
        }.value
        return output
    }
}

// Usage in a SwiftUI View (example)
@available(iOS 18.0, *)
@Observable
class ImageClassifierViewModel {
    private let modelManager = MLModelManager()
    var classificationResult: String?
    var isLoading = false

    func processImage(_ image: UIImage) async {
        isLoading = true
        defer { isLoading = false }

        // Convert UIImage to CVPixelBuffer (simplified for example)
        guard let pixelBuffer = image.toCVPixelBuffer() else { // toCVPixelBuffer is a hypothetical extension
            classificationResult = "Failed to convert image."
            return
        }

        do {
            let output = try await modelManager.classifyImage(pixelBuffer)
            classificationResult = output.classLabel
        } catch {
            classificationResult = "Error: \(error.localizedDescription)"
        }
    }
}
