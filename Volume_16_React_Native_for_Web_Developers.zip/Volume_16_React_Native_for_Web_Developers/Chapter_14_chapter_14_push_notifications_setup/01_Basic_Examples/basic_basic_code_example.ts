/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// PushNotificationSetup.tsx
// A self-contained React Native component for basic push notification handling.
// This is a "Hello World" example for device token registration and notification listening.
// For a SaaS app, this token would be sent to a secure backend server (e.g., via API call).

import React, { useEffect, useState } from 'react';
import { View, Text, Button, Alert, Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';

/**
 * Request permissions for push notifications.
 * On iOS, this shows a system prompt. On Android, it's granted by default but may require channels.
 * @returns {Promise<boolean>} - True if permissions are granted, false otherwise.
 */
const requestPermissions = async (): Promise<boolean> => {
  if (Platform.OS === 'android') {
    // Android requires notification channels for foreground notifications.
    await Notifications.setNotificationChannelAsync('default', {
      name: 'Default',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#FF231F7C',
    });
  }

  // Request permissions; on iOS, this triggers the native alert.
  const { status } = await Notifications.requestPermissionsAsync({
    ios: { allowAlert: true, allowBadge: true, allowSound: true },
  });

  return status === 'granted';
};

/**
 * Get the Expo push token for this device.
 * In production, send this token to your backend server for storage (e.g., in a users table).
 * Note: Expo push tokens are different from native FCM/APNs tokens; Expo handles routing.
 * @returns {Promise<string | null>} - The push token or null if not available.
 */
const getExpoPushToken = async (): Promise<string | null> => {
  if (!Device.isDevice) {
    // Push notifications don't work on simulators/emulators.
    console.warn('Push notifications only work on physical devices.');
    return null;
  }

  try {
    // This requires an Expo project ID; it's auto-detected in managed workflow.
    const projectId = 'your-expo-project-id'; // Replace with your actual project ID from app.json
    const token = await Notifications.getExpoPushTokenAsync({ projectId });
    console.log('Expo Push Token:', token.data);
    return token.data;
  } catch (error) {
    console.error('Failed to get push token:', error);
    return null;
  }
};

/**
 * Main React component for the push notification setup.
 * Handles permissions, token registration, and notification events.
 */
export default function PushNotificationSetup() {
  const [expoPushToken, setExpoPushToken] = useState<string | null>(null);
  const [permissionsGranted, setPermissionsGranted] = useState(false);

  /**
   * Effect hook to initialize notifications on component mount.
   * Sets up listeners for incoming notifications and foreground events.
   */
  useEffect(() => {
    // Check and request permissions on mount.
    const setupNotifications = async () => {
      const granted = await requestPermissions();
      setPermissionsGranted(granted);

      if (granted) {
        const token = await getExpoPushToken();
        setExpoPushToken(token);

        // In a SaaS app, you would now POST the token to your backend:
        // await fetch('https://your-saas-api.com/register-device', {
        //   method: 'POST',
        //   headers: { 'Content-Type': 'application/json' },
        //   body: JSON.stringify({ userId: 'user123', pushToken: token }),
        // });
      }
    };

    setupNotifications();

    // Listener for notifications received while the app is in the foreground.
    const foregroundSubscription = Notifications.addNotificationReceivedListener(notification => {
      console.log('Foreground notification:', notification);
      Alert.alert('New Alert!', notification.request.content.body || 'Notification received');
    });

    // Listener for when the user taps a notification (foreground or background).
    const responseSubscription = Notifications.addNotificationResponseReceivedListener(response => {
      console.log('User tapped notification:', response);
      // In a SaaS app, navigate to a specific screen (e.g., deep link to task details).
      // e.g., navigation.navigate('TaskDetails', { id: response.notification.request.content.data.taskId });
    });

    // Cleanup listeners on unmount.
    return () => {
      Notifications.removeNotificationSubscription(foregroundSubscription);
      Notifications.removeNotificationSubscription(responseSubscription);
    };
  }, []);

  // Manual trigger for testing (simulate a local notification).
  const triggerLocalNotification = async () => {
    if (!permissionsGranted) {
      Alert.alert('Error', 'Permissions not granted. Please enable notifications.');
      return;
    }

    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Test Notification',
        body: 'This is a local test from your SaaS app!',
        data: { taskId: '123' }, // Custom data for deep linking.
      },
      trigger: { seconds: 2 }, // Fire after 2 seconds.
    });
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
      <Text style={{ fontSize: 18, marginBottom: 10 }}>
        Push Notification Setup
      </Text>
      <Text style={{ fontSize: 14, color: 'gray', marginBottom: 20 }}>
        Permissions: {permissionsGranted ? 'Granted' : 'Not Granted'}
      </Text>
      <Text style={{ fontSize: 12, color: 'blue', marginBottom: 20 }}>
        Token: {expoPushToken ? expoPushToken.substring(0, 20) + '...' : 'Not retrieved'}
      </Text>
      <Button
        title="Request Permissions & Get Token"
        onPress={async () => {
          const granted = await requestPermissions();
          setPermissionsGranted(granted);
          if (granted) {
            const token = await getExpoPushToken();
            setExpoPushToken(token);
          }
        }}
      />
      <View style={{ height: 20 }} />
      <Button
        title="Trigger Test Notification"
        onPress={triggerLocalNotification}
      />
    </View>
  );
}
