/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { 
  View, 
  TextInput, 
  Text, 
  Platform, 
  Pressable, 
  TextInputProps 
} from 'react-native';
import { cn } from '@/lib/utils';

interface UniversalInputProps extends TextInputProps {
  label?: string;
  error?: string;
  isPassword?: boolean;
}

export const UniversalInput: React.FC<UniversalInputProps> = ({
  label,
  error,
  isPassword = false,
  ...props
}) => {
  const [showPassword, setShowPassword] = useState(false);

  // 1. Base Styling
  const baseInputClasses = "border p-2 rounded w-full text-base";
  
  // 2. Error State Logic
  const borderColor = error ? 'border-red-500' : 'border-gray-300';

  // 3. Platform Specific Styling
  // Web: Add focus rings. Mobile: Ensure transparent background.
  const platformClasses = Platform.select({
    web: "outline-none focus:ring-2 focus:ring-blue-500",
    default: "bg-transparent",
  });

  // 4. Combine all classes
  const inputClasses = cn(baseInputClasses, borderColor, platformClasses, props.className);

  // 5. Determine input type based on password toggle
  const secureEntry = isPassword && !showPassword;

  return (
    <View className="w-full mb-4">
      {label && <Text className="mb-1 text-sm font-medium text-gray-700">{label}</Text>}
      
      <View className="relative w-full">
        {Platform.OS === 'web' ? (
          // WEB IMPLEMENTATION
          <input
            type={secureEntry ? 'password' : 'text'}
            className={inputClasses}
            {...(props as any)} // Cast props for web compatibility
          />
        ) : (
          // NATIVE IMPLEMENTATION
          <TextInput
            secureTextEntry={secureEntry}
            className={inputClasses}
            {...props}
          />
        )}

        {/* Password Toggle Button */}
        {isPassword && (
          <Pressable
            onPress={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-2.5"
          >
            <Text className="text-gray-500 text-sm font-medium">
              {showPassword ? 'Hide' : 'Show'}
            </Text>
          </Pressable>
        )}
      </View>

      {/* Error Message */}
      {error && (
        <Text className="text-red-500 text-xs mt-1">{error}</Text>
      )}
    </View>
  );
};
