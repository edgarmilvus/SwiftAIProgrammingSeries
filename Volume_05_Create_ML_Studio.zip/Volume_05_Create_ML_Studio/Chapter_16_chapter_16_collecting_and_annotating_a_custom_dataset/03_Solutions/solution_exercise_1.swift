
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// This exercise is conceptual and does not require Swift code implementation.
// The solution outlines file system structure and data collection strategies.

/*
1.  **Dataset Root Directory:**
    `GardenPlantsDataset/`

2.  **Class-Specific Subdirectories:**
    Within `GardenPlantsDataset/`, create subdirectories for each plant type:
    `GardenPlantsDataset/Rose/`
    `GardenPlantsDataset/Lavender/`
    `GardenPlantsDataset/Sunflower/`
    `GardenPlantsDataset/TomatoPlant/`
    `GardenPlantsDataset/Basil/`
    `GardenPlantsDataset/Mint/`
    (Add more as needed for desired classification categories)

3.  **Image Naming Convention:**
    A clear and consistent naming convention helps in organization, debugging, and future expansion.
    Convention: `[plant_type]_[variant/context]_[sequence_number].[extension]`
    Examples:
    `rose_red_001.jpg`
    `rose_bud_002.png`
    `lavender_field_a_001.jpeg`
    `lavender_close_up_b_002.jpg`
    `sunflower_young_001.jpg`
    `sunflower_mature_002.png`
    `tomatoplant_young_001.jpg`
    `tomatoplant_fruiting_002.jpeg`

    -   `[plant_type]`: Matches the subdirectory name for consistency.
    -   `[variant/context]`: Optional, provides extra context (e.g., color, growth stage, environment) which can be useful for manual review or understanding dataset diversity.
    -   `[sequence_number]`: Ensures unique filenames within a directory.
    -   `[extension]`: Standard image file extensions (jpg, png, jpeg).

4.  **Data Collection Strategy:**

    *   **Methods/Sources:**
        1.  **Personal Photography:** Directly taking photos of plants in various gardens, nurseries, or public spaces. This offers high control over angles, lighting, and backgrounds.
        2.  **Web Scraping/Public Domain Image Databases:** Utilizing image search engines with specific filters for usage rights (e.g., Creative Commons, public domain) or specialized botanical image repositories. Careful review is needed to ensure image quality and accurate labeling.
        3.  **User Submissions (Internal Beta):** During early app development, invite a small group of beta testers (gardeners, plant enthusiasts) to submit photos through the app, explicitly collecting data for training. This provides real-world user perspectives and image conditions.

    *   **Class Imbalance Mitigation:**
        -   **Target Minimums:** Set a target minimum number of images per class (e.g., 500-1000 initial images per plant type).
        -   **Monitoring:** Regularly review the number of images in each class subdirectory during collection. Prioritize collecting more data for underrepresented classes.
        -   **Augmentation (Post-Collection):** While not part of initial collection, plan for data augmentation (rotation, cropping, flipping, color shifts) during model training to artificially expand smaller classes.

    *   **Handling Variations (Robustness):**
        -   **Lighting:** Collect images under diverse lighting conditions (bright sun, overcast, shade, indoor artificial light).
        -   **Angles/Perspectives:** Capture plants from multiple angles (top-down, side view, close-up of flowers/leaves, full plant view).
        -   **Backgrounds:** Include images with varied backgrounds (soil, grass, fences, other plants, clear sky) to prevent the model from overfitting to specific backgrounds.
        -   **Plant Maturity/Health:** Collect images of plants at different growth stages (young, mature, flowering, fruiting, even slightly wilted if relevant to identification).
        -   **Obstructions:** Include some images where parts of the plant are slightly obscured (e.g., by leaves, shadows, garden tools) to improve real-world performance.

5.  **Initial Annotation (Implicit):**
    The chosen directory structure inherently performs the initial annotation for Create ML's image classifier template. When Create ML is pointed to the `GardenPlantsDataset/` root directory, it automatically interprets each subdirectory name (e.g., `Rose`, `Lavender`) as a distinct class label, and all images within that subdirectory are treated as examples of that class. This simplifies the annotation process significantly for image classification tasks.
*/
