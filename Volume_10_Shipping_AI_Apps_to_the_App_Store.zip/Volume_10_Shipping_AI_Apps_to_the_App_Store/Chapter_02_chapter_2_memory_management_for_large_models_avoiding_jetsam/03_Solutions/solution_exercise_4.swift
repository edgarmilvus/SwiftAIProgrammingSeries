
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import UIKit
import Combine

enum EngineMode: Sendable {
    case highPerformance
    case memoryOptimized
}

enum EngineState: Sendable {
    case idle
    case swapping
    case active
}

actor AdaptiveAIEngine {
    private(set) var mode: EngineMode = .highPerformance
    private(set) var state: EngineState = .idle
    
    private var currentModel: String?
    private let modePublisher = PassthroughSubject<EngineMode, Never>()
    var modeUpdateStream: AsyncStream<EngineMode> {
        AsyncStream { continuation in
            let cancellable = modePublisher.sink { mode in
                continuation.yield(mode)
            }
            continuation.onTermination = { _ in cancellable.cancel() }
        }
    }

    init() {
        let physicalRAM = ProcessInfo.processInfo.physicalMemory
        // If RAM < 6GB, start in optimized mode
        if physicalRAM < 6 * 1024 * 1024 * 1024 {
            mode = .memoryOptimized
        }
        
        setupMemoryWarningListener()
    }

    private func setupMemoryWarningListener() {
        NotificationCenter.default.addObserver(
            forName: UIApplication.didReceiveMemoryWarningNotification,
            object: nil,
            queue: .main
        ) { _ in
            Task { [weak self] in
                await self?.handleEmergencySwap()
            }
        }
    }

    func performInference() async throws -> String {
        guard state == .active else {
            throw NSError(domain: "EngineError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Engine is busy or swapping"])
        }
        
        // Simulate inference
        try await Task.sleep(for: .seconds(1))
        return "Inference result from \(currentModel ?? "none")"
    }

    private func handleEmergencySwap() async {
        guard mode == .highPerformance else { return }
        
        print("⚠️ EMERGENCY: Memory pressure detected. Swapping to fallback model...")
        mode = .memoryOptimized
        modePublisher.send(.memoryOptimized)
        
        await performAtomicSwap()
    }

    private func performAtomicSwap() async {
        state = .swapping
        
        // 1. Deallocate current model
        currentModel = nil
        print("Deallocated large model. Cooling down...")
        
        // 2. Cool-down period: Allow the kernel to reclaim memory
        // This is critical to avoid hitting Jetsam during the swap itself.
        try? await Task.sleep(for: .seconds(2))
        
        // 3. Load fallback model in a detached task to avoid blocking the actor
        let fallbackLoadTask = Task.detached(priority: .high) {
            try await Task.sleep(for: .seconds(1)) // Simulate loading 1B model
            return "1B_Model_Weights"
        }
        
        do {
            let modelName = try await fallbackLoadTask.value
            self.currentModel = modelName
            self.state = .active
            print("✅ Successfully swapped to \(modelName)")
        } catch {
            self.state = .idle
            print("❌ Swap failed")
        }
    }
    
    func startEngine() async {
        state = .active
        currentModel = (mode == .highPerformance) ? "7B_Model_Weights" : "1B_Model_Weights"
    }
}
