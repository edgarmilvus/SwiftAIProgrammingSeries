
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import MLX
import MLXNN
import MLXOptimizers
import MLXRandom

// Ensure this code is available on platforms supporting MLX Swift
@available(iOS 18.0, macOS 15.0, *)
final class DocumentScannerService {

    // MARK: - Model Definitions

    /// Represents the frozen, pre-trained text encoder whose weights have been ported.
    /// In a real scenario, this would be a complex transformer model (e.g., BERT, RoBERTa).
    /// For demonstration, we simulate its output with a simple linear layer.
    /// Its parameters are loaded and then kept frozen.
    class PretrainedTextEncoder: MLXNN.Module {
        let outputProjection: MLXNN.Linear

        /// Initializes the encoder.
        /// - Parameters:
        ///   - inputDim: The dimensionality of the input token embeddings.
        ///   - outputDim: The dimensionality of the document embedding produced by the encoder.
        init(inputDim: Int, outputDim: Int) {
            self.outputProjection = MLXNN.Linear(inputDim, outputDim)
            super.init()
        }

        /// Simulates the forward pass of the encoder.
        /// - Parameter input: An MLXArray representing the aggregated input embeddings (e.g., from a pooling layer).
        /// - Returns: An MLXArray representing the document embedding.
        override func callAsFunction(_ input: MLXArray) -> MLXArray {
            // In a real encoder, this would involve multiple transformer layers,
            // attention mechanisms, and pooling. Here, we simplify to a projection.
            return outputProjection(input)
        }
    }

    /// The trainable classification head. This module is added on top of the frozen encoder
    /// and its parameters are updated during fine-tuning.
    class ClassificationHead: MLXNN.Module {
        let classifier: MLXNN.Linear

        /// Initializes the classification head.
        /// - Parameters:
        ///   - inputDim: The dimensionality of the document embedding from the encoder.
        ///   - numClasses: The number of distinct document classes.
        init(inputDim: Int, numClasses: Int) {
            self.classifier = MLXNN.Linear(inputDim, numClasses)
            super.init()
        }

        /// Performs the forward pass to classify the document embedding.
        /// - Parameter documentEmbedding: The MLXArray output from the `PretrainedTextEncoder`.
        /// - Returns: An MLXArray of logits for each class.
        override func callAsFunction(_ documentEmbedding: MLXArray) -> MLXArray {
            return classifier(documentEmbedding)
        }
    }

    /// The complete document classification model, combining the frozen encoder and the trainable head.
    class DocumentClassifierModel: MLXNN.Module {
        let encoder: PretrainedTextEncoder
        let classificationHead: ClassificationHead

        /// Initializes the full model.
        /// - Parameters:
        ///   - encoder: An instance of `PretrainedTextEncoder` with ported weights.
        ///   - classificationHead: An instance of `ClassificationHead` to be fine-tuned.
        init(encoder: PretrainedTextEncoder, classificationHead: ClassificationHead) {
            self.encoder = encoder
            self.classificationHead = classificationHead
            super.init()

            // IMPORTANT: Register the classification head's parameters as trainable.
            // The encoder's parameters are NOT registered here, effectively freezing them.
            self.register(module: classificationHead, name: "classificationHead")
        }

        /// Performs the forward pass of the entire model.
        /// - Parameter input: The input MLXArray for the encoder.
        /// - Returns: An MLXArray of logits from the classification head.
        override func callAsFunction(_ input: MLXArray) -> MLXArray {
            let documentEmbedding = encoder(input)
            return classificationHead(documentEmbedding)
        }
    }

    // MARK: - Service Properties

    private let encoderInputDim: Int = 768 // Common embedding dimension for BERT-like models
    private let documentEmbeddingDim: Int = 512 // Output dimension of our simulated encoder
    private let numClasses: Int = 5 // e.g., Invoice, Receipt, Contract, Report, Other

    private var documentClassifier: DocumentClassifierModel!
    private var optimizer: MLXOptimizers.Adam!

    /// Initializes the DocumentScannerService.
    /// This is where the ported weights would be loaded and the trainable head initialized.
    init() {
        do {
            // 1. Load the frozen, ported encoder weights.
            let pretrainedEncoder = try loadPortedEncoderWeights()

            // 2. Initialize the trainable classification head.
            let classificationHead = ClassificationHead(
                inputDim: documentEmbeddingDim,
                numClasses: numClasses
            )

            // 3. Assemble the full model.
            self.documentClassifier = DocumentClassifierModel(
                encoder: pretrainedEncoder,
                classificationHead: classificationHead
            )

            // 4. Initialize the optimizer, targeting only the classification head's parameters.
            // MLXNN.Module.parameters() will only return registered parameters.
            self.optimizer = MLXOptimizers.Adam(learningRate: 1e-4)

            print("DocumentScannerService initialized. Model ready for fine-tuning or inference.")
        } catch {
            fatalError("Failed to initialize DocumentScannerService: \(error.localizedDescription)")
        }
    }

    // MARK: - Core Logic

    /// 1. Simulates loading the ported weights for the `PretrainedTextEncoder`.
    /// In a real application, this would involve reading a `.safetensors` or similar file
    /// that was converted from a Hugging Face model.
    /// - Returns: An initialized `PretrainedTextEncoder` with loaded weights.
    /// - Throws: An error if loading fails.
    private func loadPortedEncoderWeights() throws -> PretrainedTextEncoder {
        print("Simulating loading of ported encoder weights...")
        let encoder = PretrainedTextEncoder(inputDim: encoderInputDim, outputDim: documentEmbeddingDim)

        // For demonstration, we'll initialize with random weights and then "freeze" them.
        // In reality, these would be loaded from a file.
        // MLX's `eval` ensures the lazy graph is computed, making parameters concrete.
        MLX.eval(encoder.parameters())
        print("Ported encoder weights simulated and loaded.")
        return encoder
    }

    /// 2. Defines the loss function for document classification.
    /// We use cross-entropy loss, a common choice for multi-class classification.
    /// - Parameters:
    ///   - model: The `DocumentClassifierModel` instance.
    ///   - input: The input MLXArray (document embeddings).
    ///   - target: The true class labels (MLXArray).
    /// - Returns: An MLXArray representing the scalar loss value.
    private func classificationLoss(model: DocumentClassifierModel, input: MLXArray, target: MLXArray) -> MLXArray {
        let logits = model(input)
        return MLX.crossEntropy(logits: logits, targets: target, reduction: .mean)
    }

    /// 3. Performs a single step of fine-tuning on the classification head.
    /// This function demonstrates MLX's `valueAndGradient` for efficient gradient computation.
    /// - Parameters:
    ///   - inputBatch: A batch of simulated document embeddings.
    ///   - targetBatch: A batch of corresponding true class labels.
    /// - Returns: The computed loss for the batch.
    @discardableResult
    func fineTuneClassificationHead(inputBatch: MLXArray, targetBatch: MLXArray) async throws -> Float {
        print("Starting fine-tuning step...")
        do {
            // MLX's functional transformation: compute loss and gradients in one go.
            // We specify `of: documentClassifier.classificationHead.parameters()`
            // to only compute gradients for the trainable head.
            let (loss, gradients) = await MLX.valueAndGradient(
                classificationLoss,
                of: documentClassifier.classificationHead.parameters(), // Only train the head!
                arg: documentClassifier,
                inputBatch,
                targetBatch
            )

            // MLX uses lazy evaluation: the computation graph for loss and gradients
            // is built here. It will only be executed when `eval` or `update` is called.

            // Apply gradients to update the classification head's parameters.
            let (updatedModelParameters, updatedOptimizerState) = optimizer.update(
                parameters: documentClassifier.classificationHead.parameters(),
                gradients: gradients,
                state: optimizer.state(for: documentClassifier.classificationHead.parameters())
            )

            // Update the model and optimizer state.
            documentClassifier.classificationHead.update(parameters: updatedModelParameters)
            optimizer.update(state: updatedOptimizerState, for: documentClassifier.classificationHead.parameters())

            // Force evaluation of the graph to get the concrete loss value.
            MLX.eval(loss, documentClassifier.parameters(), optimizer.state(for: documentClassifier.classificationHead.parameters()))

            let lossValue = loss.item(Float.self)
            print("Fine-tuning step completed. Loss: \(lossValue)")
            return lossValue

        } catch {
            print("Error during fine-tuning step: \(error.localizedDescription)")
            throw error
        }
    }

    /// 4. Performs document classification inference using the (potentially fine-tuned) model.
    /// This is an `async` function to simulate real-world background processing in an app.
    /// - Parameter documentInputEmbedding: An MLXArray representing the input embedding for a document.
    /// - Returns: The predicted class index.
    /// - Throws: An error if inference fails.
    func classifyDocument(documentInputEmbedding: MLXArray) async throws -> Int {
        print("Performing document classification inference...")
        do {
            // Ensure the model is in evaluation mode (though for this simple model, it doesn't change behavior).
            // For models with dropout/batchnorm, this is crucial.
            // MLX.noGrad { ... } is not strictly needed for inference, but good practice if you want to ensure
            // no gradient computation is accidentally triggered.
            let logits = documentClassifier(documentInputEmbedding)
            let probabilities = MLX.softmax(logits, axis: -1)
            let predictedClass = MLX.argmax(probabilities, axis: -1).item(Int.self)

            // Force evaluation for the concrete result.
            MLX.eval(predictedClass)

            print("Inference completed. Predicted class index: \(predictedClass)")
            return predictedClass
        } catch {
            print("Error during inference: \(error.localizedDescription)")
            throw error
        }
    }

    // MARK: - Utility for Demo Data

    /// Generates dummy input embeddings and target labels for demonstration.
    /// - Parameters:
    ///   - batchSize: The number of samples in the batch.
    ///   - inputDim: The dimensionality of each input embedding.
    ///   - numClasses: The total number of classes.
    /// - Returns: A tuple containing `(inputBatch, targetBatch)`.
    private func generateDummyData(batchSize: Int, inputDim: Int, numClasses: Int) -> (MLXArray, MLXArray) {
        let inputBatch = MLXRandom.uniform(low: 0.0, high: 1.0, shape: [batchSize, inputDim])
        let targetBatch = MLXRandom.randint(low: 0, high: numClasses, shape: [batchSize])
        return (inputBatch, targetBatch)
    }

    // MARK: - Example Usage in an App

    /// Simulates the lifecycle of the document scanner service within an app.
    func runDemo() async {
        print("\n--- Document Scanner Service Demo Started ---")
        do {
            // Simulate receiving OCR output (as an embedding)
            let (trainingInputs, trainingTargets) = generateDummyData(
                batchSize: 16,
                inputDim: encoderInputDim,
                numClasses: numClasses
            )

            // Fine-tune the classification head over a few epochs
            let numEpochs = 3
            for epoch in 0..<numEpochs {
                print("\nEpoch \(epoch + 1)/\(numEpochs)")
                _ = try await fineTuneClassificationHead(inputBatch: trainingInputs, targetBatch: trainingTargets)
                // In a real app, you'd iterate over a larger dataset.
            }

            // Simulate a new document coming in for classification
            let (inferenceInput, _) = generateDummyData(
                batchSize: 1,
                inputDim: encoderInputDim,
                numClasses: numClasses // numClasses is not used for inference input, but kept for consistency
            )
            let predictedClass = try await classifyDocument(documentInputEmbedding: inferenceInput)
            print("\nDocument classified as class: \(predictedClass)")

        } catch {
            print("Demo encountered an error: \(error.localizedDescription)")
        }
        print("\n--- Document Scanner Service Demo Finished ---")
    }
}

// MARK: - Application Entry Point

// Example of how to integrate this into an AppDelegate or SwiftUI App struct
@main
@available(iOS 18.0, macOS 15.0, *)
struct DocumentScannerApp {
    static func main() async {
        let service = DocumentScannerService()
        await service.runDemo()
    }
}
