
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import UIKit

/// Defines the available computational intensity modes for AI tasks.
enum InferencePolicy: Sendable {
    case highPerformance
    case balanced
    case powerSaver
}

/// An actor responsible for evaluating environmental factors to protect device health.
actor InferenceGuard {
    
    /// Evaluates the current thermal and battery status to return an appropriate policy.
    /// - Returns: An `InferencePolicy` optimized for current hardware conditions.
    func evaluatePolicy() async -> InferencePolicy {
        // Accessing ProcessInfo is safe within the actor
        let thermalState = ProcessInfo.processInfo.thermalState
        
        // Accessing UIDevice requires MainActor isolation. 
        // We fetch it via a Task to bridge the context.
        let batteryLevel = await MainActor.run {
            // Ensure battery monitoring is enabled to avoid -1.0
            if !UIDevice.current.isBatteryMonitoringEnabled {
                UIDevice.current.isBatteryMonitoringEnabled = true
            }
            return UIDevice.current.batteryLevel
        }
        
        // Logic: Battery < 15% or Thermal Critical -> Power Saver
        // Note: batteryLevel is -1.0 if monitoring is unavailable; we treat that as low power for safety.
        if thermalState == .critical || batteryLevel < 0.15 || batteryLevel < 0 {
            return .powerSaver
        }
        
        // Logic: Thermal Serious -> Balanced
        if thermalState == .serious {
            return .balanced
        }
        
        // Default: High Performance
        return .highPerformance
    }
    
    /// Simulates a heavy Core ML inference task.
    func performInference(mode: InferencePolicy) async {
        print("Starting inference in \(mode) mode...")
        
        let duration: UInt64
        switch mode {
        case .highPerformance:
            duration = 2 * 1_000_000_000 // 2 seconds
        case .balanced:
            duration = 1 * 1_000_000_000 // 1 second
        case .powerSaver:
            duration = 500_000_000       // 0.5 seconds
        }
        
        // Simulate work
        try? await Task.sleep(nanoseconds: duration)
        print("Inference completed in \(mode) mode.")
    }
}

// MARK: - Integration Example
@MainActor
func runInferenceWorkflow() async {
    let guardService = InferenceGuard()
    
    print("--- Requesting Super Resolution Task ---")
    
    // 1. Evaluate policy immediately before execution
    let policy = await guardService.evaluatePolicy()
    print("Policy decided: \(policy)")
    
    // 2. Execute the task with the determined policy
    await guardService.performInference(mode: policy)
}
