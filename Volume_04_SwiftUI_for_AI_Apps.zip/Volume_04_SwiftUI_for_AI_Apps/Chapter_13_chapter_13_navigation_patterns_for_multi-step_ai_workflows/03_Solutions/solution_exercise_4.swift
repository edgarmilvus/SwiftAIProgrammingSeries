
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI

// Mark the entire struct as available for iOS 18.0 and macOS 15.0
@available(iOS 18.0, macOS 15.0, *)
struct AIPredictionDashboardApp: App {
    var body: some Scene {
        WindowGroup {
            AIPredictionDashboardView()
        }
    }
}

// Model for an AI Task
struct AITask: Identifiable, Codable, Hashable {
    let id: String // Unique identifier for deep linking
    let name: String
    let description: String
    let predictionResult: String // Placeholder for AI result

    static let sampleTasks: [AITask] = [
        AITask(id: "sentiment-a", name: "Sentiment Analysis on Article A", description: "Analyzes public sentiment from a news article.", predictionResult: "Overall sentiment: Positive (92%)"),
        AITask(id: "object-b", name: "Object Detection on Image B", description: "Detects objects within a given image.", predictionResult: "Detected: Car (98%), Tree (95%), Road (90%)"),
        AITask(id: "forecast-q3", name: "Forecast for Q3 Sales", description: "Predicts sales figures for the third quarter.", predictionResult: "Predicted Q3 Sales: $1.2M ± 5%"),
        AITask(id: "translation-c", name: "Language Translation of Document C", description: "Translates a document from English to Spanish.", predictionResult: "Translation complete. (English -> Spanish)"),
        AITask(id: "recommendation-d", name: "Product Recommendation for User D", description: "Generates personalized product recommendations.", predictionResult: "Recommended: Product X, Product Y, Product Z")
    ]
}

@available(iOS 18.0, macOS 15.0, *)
struct AIPredictionDashboardView: View {
    @State private var selectedTaskID: AITask.ID? // For NavigationSplitView selection
    @State private var detailPath = NavigationPath() // For programmatic navigation in detail column

    var body: some View {
        NavigationSplitView {
            // Sidebar (Master View) - List of AI Tasks
            List(AITask.sampleTasks, selection: $selectedTaskID) { task in
                NavigationLink(task.name, value: task.id)
            }
            .navigationTitle("AI Tasks")
        } detail: {
            // Content View (Detail View)
            NavigationStack(path: $detailPath) { // Use NavigationStack in detail for deep link path
                if let selectedTaskID = selectedTaskID,
                   let task = AITask.sampleTasks.first(where: { $0.id == selectedTaskID }) {
                    TaskDetailView(task: task)
                } else {
                    Text("Select an AI task from the sidebar, or use a deep link.")
                        .font(.title2)
                        .foregroundColor(.secondary)
                }
            }
        }
        .onOpenURL { url in
            handleDeepLink(url)
        }
        .navigationSplitViewStyle(.forContent) // Or .prominent, .balanced, etc. depending on preference
    }

    private func handleDeepLink(_ url: URL) {
        // Expected URL format: myapp://prediction/TASK_ID
        guard url.scheme == "myapp",
              url.host == "prediction",
              let taskID = url.pathComponents.last,
              AITask.sampleTasks.contains(where: { $0.id == taskID }) else {
            print("Invalid deep link: \(url)")
            // Optionally navigate to a default view or show an error
            selectedTaskID = nil // Clear selection
            detailPath.removeAll() // Clear any existing detail path
            return
        }

        print("Handling deep link for task ID: \(taskID)")
        // Set the selection in the sidebar
        selectedTaskID = taskID
        // Clear and then append the task ID to the detail path to ensure it's the only item
        detailPath.removeAll()
        detailPath.append(taskID)
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct TaskDetailView: View {
    let task: AITask

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text(task.name)
                .font(.largeTitle)
                .padding(.bottom, 5)

            Text(task.description)
                .font(.headline)
                .foregroundColor(.secondary)

            Divider()

            Text("Prediction Result:")
                .font(.title2)

            Text(task.predictionResult)
                .font(.body)
                .padding()
                .background(Color.blue.opacity(0.1))
                .cornerRadius(8)
            
            Spacer()
        }
        .padding()
        .navigationTitle("Task Details")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// You would also need to configure your app's Info.plist
// to register the custom URL scheme "myapp".
// Example for Info.plist:
/*
<key>CFBundleURLTypes</key>
<array>
    <dict>
        <key>CFBundleURLSchemes</key>
        <array>
            <string>myapp</string>
        </array>
        <key>CFBundleURLName</key>
        <string>com.yourcompany.AIPredictionDashboard</string>
    </dict>
</array>
*/
