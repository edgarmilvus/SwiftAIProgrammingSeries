
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import UIKit
import WritingTools

@available(iOS 18.0, *)
@MainActor // Ensure UI updates are on the main actor
class NoteViewController: UIViewController, UITextViewDelegate {

    let textView = UITextView()
    private var currentSelectedRange: NSRange? // To store the range of text that triggered the menu

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupTextView()
        // Check availability early to decide if context menu item should be shown
        NotificationCenter.default.addObserver(self, selector: #selector(writingToolsAvailabilityChanged), name: WritingToolsService.availabilityDidChangeNotification, object: nil)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    private func setupTextView() {
        textView.delegate = self
        textView.font = UIFont.preferredFont(forTextStyle: .body)
        textView.textContainerInset = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.text = "This is an example note. You can select some text here to see rephrasing suggestions. Let's try to make this sentence sound better." // Example text

        view.addSubview(textView)
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])

        // Integrate with UIEditMenuInteraction for modern context menus
        textView.isUserInteractionEnabled = true
        textView.isEditable = true
    }

    @objc private func writingToolsAvailabilityChanged() {
        // This will trigger a menu update if the textView is currently focused and text is selected
        if textView.isFirstResponder && textView.selectedRange.length > 0 {
            textView.reloadInputViews() // Forces the menu to refresh
        }
    }

    // MARK: - UITextViewDelegate for Context Menu

    // This method is called when the edit menu is about to be shown.
    // We provide a custom menu item here.
    func textView(_ textView: UITextView, editMenuForTextIn range: NSRange, suggestedActions: [UIMenuElement]) -> UIMenu? {
        // Store the current selected range for later use
        currentSelectedRange = range

        // Check if Writing Tools are available and if text is actually selected
        guard WritingToolsService.shared.isAvailable, range.length > 0 else {
            return UIMenu(children: suggestedActions) // Return original menu if not available or no text selected
        }

        let selectedText = (textView.text as NSString).substring(with: range)

        let rephraseAction = UIAction(title: "Rephrase with AI", image: UIImage(systemName: "wand.and.stars")) { [weak self] _ in
            guard let self = self else { return }
            Task {
                await self.presentRephraseOptions(for: selectedText, in: range)
            }
        }

        // Create a new menu with our custom action and the suggested actions
        var actions = suggestedActions
        actions.insert(rephraseAction, at: 0) // Insert at the beginning for prominence

        return UIMenu(title: "", children: actions)
    }

    // MARK: - Writing Tools Integration

    func presentRephraseOptions(for selectedText: String, in range: NSRange) async {
        guard WritingToolsService.shared.isAvailable else {
            presentSimpleAlert(title: "Not Available", message: "Writing Tools are not available on this device.")
            return
        }

        do {
            let request = WritingToolsRephraseRequest(text: selectedText)
            let result = try await WritingToolsService.shared.rephrase(request)

            guard !result.suggestions.isEmpty else {
                presentSimpleAlert(title: "No Suggestions", message: "Writing Tools could not find any rephrasing suggestions for the selected text.")
                return
            }

            // Implement UI to display result.suggestions to the user
            let alertController = UIAlertController(title: "Rephrase Suggestions", message: nil, preferredStyle: .actionSheet)

            for suggestion in result.suggestions {
                let action = UIAlertAction(title: suggestion.text, style: .default) { [weak self] _ in
                    guard let self = self, let currentRange = self.currentSelectedRange else { return }
                    self.textView.replace(currentRange, withText: suggestion.text)
                    self.textView.selectedRange = NSRange(location: currentRange.location, length: suggestion.text.count) // Reselect the new text
                }
                alertController.addAction(action)
            }

            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)

            // For iPad, action sheets need a popover presentation source
            if let popoverController = alertController.popoverPresentationController {
                popoverController.sourceView = textView
                popoverController.sourceRect = textView.caretRect(for: textView.selectedTextRange!.start) // Position near selection
                popoverController.permittedArrowDirections = [.up, .down]
            }

            self.present(alertController, animated: true, completion: nil)

        } catch {
            presentSimpleAlert(title: "Error", message: "Error rephrasing text: \(error.localizedDescription)")
        }
    }

    private func presentSimpleAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
