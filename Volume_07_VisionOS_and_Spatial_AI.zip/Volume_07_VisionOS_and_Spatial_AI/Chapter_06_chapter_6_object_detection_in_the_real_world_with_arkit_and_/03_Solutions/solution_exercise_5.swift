
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import ARKit
import RealityKit
import Vision

/// The Shared State managed by an Actor to prevent data races between 
/// the high-frequency Render Loop and the low-frequency Vision Loop.
actor DetectionState {
    struct TrackedObject {
        var position: SIMD3<Float>
        var lastUpdated: TimeInterval
        var velocity: SIMD3<Float>
    }
    
    private(set) var objects: [String: TrackedObject] = [:]
    
    func updateObject(label: String, position: SIMD3<Float>, timestamp: TimeInterval) {
        if let existing = objects[label] {
            // Calculate velocity for Dead Reckoning: (pos2 - pos1) / dt
            let dt = Float(timestamp - existing.lastUpdated)
            let velocity = dt > 0 ? (position - existing.position) / dt : .zero
            objects[label] = TrackedObject(position: position, lastUpdated: timestamp, velocity: velocity)
        } else {
            objects[label] = TrackedObject(position: position, lastUpdated: timestamp, velocity: .zero)
        }
    }
    
    func getPredictedPosition(for label: String, currentTime: TimeInterval) -> SIMD3<Float>? {
        guard let obj = objects[label] else { return nil }
        let dt = Float(currentTime - obj.lastUpdated)
        // Dead Reckoning Formula: P_now = P_last + (Velocity * dt)
        return obj.position + (obj.velocity * dt)
    }
}

/// The Consumer: Runs on a background task to prevent blocking the UI.
class VisionConsumer {
    private let state: DetectionState
    private var isProcessing = false
    
    init(state: DetectionState) {
        self.state = state
    }
    
    func consume(pixelBuffer: CVPixelBuffer, frame: ARFrame, engine: ObjectDetectionEngine) {
        // Frame Dropping Logic: If we are still processing, skip this frame.
        guard !isProcessing else { return }
        
        isProcessing = true
        
        Task(priority: .high) {
            defer { isProcessing = false }
            
            do {
                let detections = try await engine.detect(in: pixelBuffer)
                let timestamp = frame.timestamp
                
                for detection in detections {
                    // In a real app, we'd project 2D to 3D here
                    // For this demo, we assume we have the 3D position
                    let dummyPos = SIMD3<Float>(0, 0, -0.5) 
                    await state.updateObject(label: detection.label, position: dummyPos, timestamp: timestamp)
                }
            } catch {
                print("Inference error: \(error)")
            }
        }
    }
}

/// The Producer/Renderer: Runs on the Main Actor at 60fps.
@MainActor
class ARRenderer {
    private let state: DetectionState
    private let arView: ARView
    private var labels: [String: ModelEntity] = [:]
    
    init(arView: ARView, state: DetectionState) {
        self.arView = arView
        self.state = state
    }
    
    func updateScene() {
        let currentTime = arView.session.currentFrame?.timestamp ?? 0
        
        Task {
            // We iterate through known labels and "predict" where they should be
            // This compensates for the 50-100ms inference lag.
            for label in labels.keys {
                if let predictedPos = await state.getPredictedPosition(for: label, currentTime: currentTime) {
                    labels[label]?.position = predictedPos
                }
            }
        }
    }
}
