
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Observation
import Combine

// MARK: - Domain Models

/// Represents the various states an Agent can inhabit during its lifecycle.
/// Using an enum with associated values allows the UI to react precisely to the agent's internal logic.
enum AgentState: Sendable, Equatable {
    case idle
    case thinking(thought: String)
    case callingTool(toolName: String, input: String)
    case streamingResponse(chunk: String)
    case completed(finalResponse: String)
    case failed(error: String)
}

/// A structured representation of a tool call requested by the LLM.
struct ToolCall: Sendable, Codable {
    let id: UUID
    let functionName: String
    let arguments: [String: String]
}

/// Errors specific to the Agentic workflow.
enum AgentError: Error, LocalizedError {
    case llmFailure(String)
    case toolExecutionError(String)
    case contextExhaustion
    case invalidToolCall

    var errorDescription: String? {
        switch self {
        case .llmFailure(let msg): return "LLM Error: \(msg)"
        case .toolExecutionError(let msg): return "Tool Error: \(msg)"
        case .contextExhaustion: return "The conversation history has become too large."
        case .invalidToolCall: return "The LLM requested a tool that does not exist."
        }
    }
}

// MARK: - Protocols

/// Defines the contract for an LLM provider. 
/// Decoupling this allows for easy switching between OpenAI, Anthropic, or local Llama models.
protocol LLMServiceProtocol: Actor {
    func generateResponse(prompt: String, history: [String]) async throws -> AsyncStream<AgentState>
}

/// Defines the contract for a tool that an agent can use.
protocol AgentTool: Sendable {
    var name: String { get }
    var description: String { get }
    func execute(arguments: [String: String]) async throws -> String
}

// MARK: - Services

/// The LLMService is an Actor to ensure that multiple concurrent requests 
/// do not corrupt the underlying connection state or session tokens.
@available(iOS 18.0, macOS 15.0, *)
actor OpenAIService: LLMServiceProtocol {
    private let apiKey: String
    
    init(apiKey: String) {
        self.apiKey = apiKey
    }

    /// Uses AsyncStream to stream the agent's reasoning and responses back to the caller.
    /// This is critical for perceived performance in AI applications.
    func generateResponse(prompt: String, history: [String]) async throws -> AsyncStream<AgentState> {
        return AsyncStream { continuation in
            Task {
                do {
                    // In a real implementation, this would call the OpenAI API.
                    // We simulate the 'Thinking' phase and the 'Streaming' phase.
                    
                    continuation.yield(.thinking(thought: "Analyzing the user request..."))
                    try await Task.sleep(for: .seconds(1))
                    
                    continuation.yield(.thinking(thought: "Searching internal knowledge base..."))
                    try await Task.sleep(for: .seconds(1))
                    
                    // Simulate a tool call detection
                    continuation.yield(.callingTool(toolName: "web_search", input: prompt))
                    try await Task.sleep(for: .seconds(1.5))
                    
                    // Simulate streaming text chunks
                    let responseText = "Based on my research, the answer is that Swift 6 concurrency is revolutionary."
                    let words = responseText.components(separatedBy: " ")
                    
                    for word in words {
                        continuation.yield(.streamingResponse(chunk: word + " "))
                        try await Task.sleep(for: .milliseconds(200))
                    }
                    
                    continuation.yield(.completed(finalResponse: responseText))
                    continuation.finish()
                    
                } catch {
                    continuation.yield(.failed(error: error.localizedDescription))
                    continuation.finish()
                }
            }
        }
    }
}

/// The ToolRegistry manages the set of tools available to the Agent.
/// It is an Actor to allow thread-safe registration and execution of tools.
@available(iOS 18.0, macOS 15.0, *)
actor ToolRegistry {
    private var tools: [String: any AgentTool] = [:]

    func register(_ tool: any AgentTool) {
        tools[tool.name] = tool
    }

    func executeTool(name: String, arguments: [String: String]) async throws -> String {
        guard let tool = tools[name] else {
            throw AgentError.invalidToolCall
        }
        return try await tool.execute(arguments: arguments)
    }
}

/// A concrete implementation of a Search Tool.
struct WebSearchTool: AgentTool {
    let name = "web_search"
    let description = "Searches the internet for real-time information."

    func execute(arguments: [String: String]) async throws -> String {
        let query = arguments["query"] ?? ""
        // Simulate network latency for a search
        try await Task.sleep(for: .seconds(2))
        return "Search results for '\(query)': Swift 6 introduces strict concurrency checks."
    }
}

// MARK: - The Agent (The Orchestrator)

/// The ResearchAgent is the heart of the application. 
/// It is an Actor to manage the complex, non-linear state transitions of the agentic loop.
@available(iOS 18.0, macOS 15.0, *)
actor ResearchAgent {
    private let llmService: any LLMServiceProtocol
    private let toolRegistry: ToolRegistry
    private var conversationHistory: [String] = []

    init(llmService: any LLMServiceProtocol, toolRegistry: ToolRegistry) {
        self.llmService = llmService
        self.toolRegistry = toolRegistry
    }

    /// The primary entry point for the user.
    /// It manages the entire lifecycle of a single user query.
    func run(query: String) async throws -> AsyncStream<AgentState> {
        conversationHistory.append("User: \(query)")
        
        // We return a stream that the ViewModel can consume to update the UI.
        return AsyncStream { continuation in
            Task {
                do {
                    let responseStream = try await llmService.generateResponse(
                        prompt: query, 
                        history: conversationHistory
                    )
                    
                    for await state in responseStream {
                        // Here, the Agent intercepts states to perform "Agentic" logic.
                        // For example, if the LLM says "I need to use a tool", the Agent
                        // intercepts that, executes the tool, and feeds the result back.
                        
                        switch state {
                        case .callingTool(let name, let input):
                            continuation.yield(.callingTool(toolName: name, input: input))
                            let observation = try await toolRegistry.executeTool(name: name, arguments: ["query": input])
                            // In a true loop, we would feed this observation back to the LLM.
                            // For this demonstration, we proceed to streaming.
                            conversationHistory.append("Observation: \(observation)")
                            
                        default:
                            continuation.yield(state)
                        }
                    }
                    continuation.finish()
                } catch {
                    continuation.yield(.failed(error: error.localizedDescription))
                    continuation.finish()
                }
            }
        }
    }
}

// MARK: - The ViewModel (The Bridge)

/// The ViewModel lives on the @MainActor to ensure all UI updates are thread-safe.
/// It observes the Agent's output and transforms it into a format the View can render.
@available(iOS 18.0, macOS 15.0, *)
@Observable
@MainActor
class ResearchViewModel {
    var currentStatus: String = "Ready"
    var chatHistory: [String] = []
    var isProcessing: Bool = false
    var currentResponse: String = ""
    
    private let agent: ResearchAgent

    init(agent: ResearchAgent) {
        self.agent = agent
    }

    func sendQuery(_ query: String) {
        isProcessing = true
        currentResponse = ""
        
        Task {
            do {
                let stream = try await agent.run(query: query)
                
                for await state in stream {
                    updateUI(with: state)
                }
                
                isProcessing = false
            } catch {
                currentStatus = "Error: \(error.localizedDescription)"
                isProcessing = false
            }
        }
    }

    private func updateUI(with state: AgentState) {
        switch state {
        case .idle:
            currentStatus = "Idle"
        case .thinking(let thought):
            currentStatus = "Thinking: \(thought)"
        case .callingTool(let tool, let input):
            currentStatus = "Using \(tool) for '\(input)'..."
        case .streamingResponse(let chunk):
            currentResponse += chunk
            currentStatus = "Responding..."
        case .completed(let final):
            currentResponse = final
            currentStatus = "Done"
            chatHistory.append("Assistant: \(final)")
        case .failed(let error):
            currentStatus = "Error: \(error)"
        }
    }
}
