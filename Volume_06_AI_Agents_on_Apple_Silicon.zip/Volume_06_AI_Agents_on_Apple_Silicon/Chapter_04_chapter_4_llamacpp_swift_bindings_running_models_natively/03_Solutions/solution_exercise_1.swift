
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation // For URL, String, Data, etc.

// MARK: - Mock LlamaKit Bindings (for demonstration purposes)
// In a real scenario, this would be provided by a Swift Package Manager dependency
// like 'LlamaKit' that wraps the llama.cpp C API.

// Define basic Llama.cpp parameter structs (simplified)
struct LlamaModelParams {
    var n_gpu_layers: Int = 0 // Number of layers to offload to GPU
    var vocab_only: Bool = false
    var use_mmap: Bool = true
    var use_mlock: Bool = false
    // ... other model parameters
}

struct LlamaContextParams {
    var n_ctx: UInt32 = 512 // Context window size
    var n_batch: UInt32 = 512 // Batch size for prompt processing
    var n_threads: UInt32 = 4 // Number of threads
    var n_threads_batch: UInt32 = 4 // Number of threads for batch processing
    var temp: Float = 0.8 // Temperature for sampling
    var top_p: Float = 0.95 // Top-p sampling
    var repeat_penalty: Float = 1.1 // Repeat penalty
    var freq_penalty: Float = 0.0 // Frequency penalty
    var presence_penalty: Float = 0.0 // Presence penalty
    var seed: UInt32 = 0 // Random seed (0 for random)
    var logits_all: Bool = false
    var embeddings: Bool = false
    // ... other context parameters
}

// Mock LlamaModel and LlamaContext to simulate the actual bindings
class LlamaModel {
    let modelPath: String
    var isLoaded: Bool = false

    init(path: String) {
        self.modelPath = path
        print("LlamaModel: Initializing with path \(path)")
    }

    func load(params: LlamaModelParams = LlamaModelParams()) throws {
        // Simulate file existence check. Replace with a real path for testing.
        // For this mock, we'll just pretend it exists.
        // In a real app, you'd check `FileManager.default.fileExists(atPath: modelPath)`
        // For demo, let's create a dummy file if it doesn't exist for the mock to "load"
        if !FileManager.default.fileExists(atPath: modelPath) {
            let dummyContent = "This is a dummy model file."
            do {
                try dummyContent.write(toFile: modelPath, atomically: true, encoding: .utf8)
                print("LlamaModel: Created dummy model file at \(modelPath)")
            } catch {
                throw LlamaError.modelNotFound(modelPath) // Or a more specific error
            }
        }

        // Simulate loading time
        Thread.sleep(forTimeInterval: 0.1)
        isLoaded = true
        print("LlamaModel: Loaded model from \(modelPath) with params: \(params)")
    }

    func tokenize(text: String, addBos: Bool, special: Bool = false) -> [Int32] {
        guard isLoaded else { return [] }
        // Simulate tokenization. Simple char-to-int mapping for demo.
        // In reality, this would use the model's tokenizer.
        print("LlamaModel: Tokenizing '\(text)' (addBos: \(addBos))")
        var tokens = text.utf8.map { Int32($0) }
        if addBos { tokens.insert(getBosToken(), at: 0) } // Simulate BOS token
        return tokens
    }

    func detokenize(tokens: [Int32]) -> String {
        guard isLoaded else { return "" }
        // Simulate detokenization. Simple int-to-char mapping for demo.
        let chars = tokens.compactMap { UnicodeScalar(UInt8($0)) }.map { Character($0) }
        let result = String(chars)
        print("LlamaModel: Detokenized \(tokens.count) tokens to '\(result)'")
        return result
    }

    func getVocabSize() -> Int {
        guard isLoaded else { return 0 }
        return 256 // ASCII range for demo
    }

    func getBosToken() -> Int32 { 1 }
    func getEosToken() -> Int32 { 2 } // Simulate EOS token
    func getNewlineToken() -> Int32 { 10 } // Simulate newline token

    deinit {
        print("LlamaModel: Deallocated model from \(modelPath)")
        // In a real scenario, this would involve calling `llama_free_model`
        do {
            try FileManager.default.removeItem(atPath: modelPath) // Clean up dummy file
            print("LlamaModel: Removed dummy model file at \(modelPath)")
        } catch {
            print("LlamaModel: Could not remove dummy model file: \(error)")
        }
    }
}

class LlamaContext {
    private let model: LlamaModel
    private var params: LlamaContextParams
    private var currentTokens: [Int32] = []
    private var isInitialized: Bool = false

    init(model: LlamaModel, params: LlamaContextParams = LlamaContextParams()) throws {
        self.model = model
        self.params = params
        try initialize()
    }

    private func initialize() throws {
        guard model.isLoaded else {
            throw LlamaError.modelNotLoaded
        }
        // Simulate context initialization
        Thread.sleep(forTimeInterval: 0.05)
        isInitialized = true
        print("LlamaContext: Initialized context with params: \(params)")
    }

    func reset() throws {
        guard model.isLoaded else {
            throw LlamaError.modelNotLoaded
        }
        print("LlamaContext: Resetting context.")
        currentTokens = []
        // Simulate re-initialization
        isInitialized = false
        try initialize()
    }

    func updateParams(newParams: LlamaContextParams) throws {
        self.params = newParams
        print("LlamaContext: Updating parameters and reinitializing context.")
        try reset() // Reinitialize context with new parameters
    }

    func feedPrompt(tokens: [Int32]) throws {
        guard isInitialized else { throw LlamaError.contextNotInitialized }
        guard tokens.count <= params.n_ctx else {
            throw LlamaError.contextWindowOverflow(tokens.count, Int(params.n_ctx))
        }
        print("LlamaContext: Feeding \(tokens.count) prompt tokens.")
        currentTokens.append(contentsOf: tokens)
        // Simulate prompt processing
        Thread.sleep(forTimeInterval: Double(tokens.count) * 0.0005)
    }

    func sampleNextToken() -> Int32 {
        guard isInitialized else { return -1 } // Invalid token
        guard !currentTokens.isEmpty else { return -1 }

        // Simulate sampling logic
        // For demo, just pick a random ASCII char or EOS
        let lastToken = currentTokens.last!
        var nextToken: Int32

        if currentTokens.count > 5 && Int.random(in: 0...100) < 5 { // 5% chance to end
            nextToken = model.getEosToken()
        } else if lastToken == Int32(Character(".").asciiValue!) { // Simple rule: after a dot, maybe space then capital
             nextToken = Int32(Character(" ").asciiValue!)
        } else if lastToken == Int32(Character(" ").asciiValue!) { // After space, maybe a random letter
            nextToken = Int32(Character("A").asciiValue! + UInt8.random(in: 0..<26))
        } else { // Otherwise, a random lowercase letter or space
            if Int.random(in: 0...10) < 8 { // 80% chance for a letter
                nextToken = Int32(Character("a").asciiValue! + UInt8.random(in: 0..<26))
            } else { // 20% chance for a space
                nextToken = Int32(Character(" ").asciiValue!)
            }
        }

        currentTokens.append(nextToken)
        // Ensure context window is respected (simple truncation for demo)
        if currentTokens.count > params.n_ctx {
            currentTokens.removeFirst(currentTokens.count - Int(params.n_ctx))
        }
        return nextToken
    }

    deinit {
        print("LlamaContext: Deallocated context.")
        // In a real scenario, this would involve calling `llama_free`
    }
}

// Custom Error types
enum LlamaError: Error, LocalizedError {
    case modelNotFound(String)
    case modelNotLoaded
    case contextNotInitialized
    case contextWindowOverflow(Int, Int) // (actual, max)
    case inferenceFailed(String)
    case invalidParameter(String)
    case generalError(String)

    var errorDescription: String? {
        switch self {
        case .modelNotFound(let path):
            return "Llama Error: Model file not found at \(path)"
        case .modelNotLoaded:
            return "Llama Error: Model is not loaded."
        case .contextNotInitialized:
            return "Llama Error: Context not initialized."
        case .contextWindowOverflow(let actual, let max):
            return "Llama Error: Prompt tokens (\(actual)) exceed context window size (\(max))."
        case .inferenceFailed(let msg):
            return "Llama Error: Inference failed: \(msg)"
        case .invalidParameter(let param):
            return "Llama Error: Invalid parameter value for \(param)."
        case .generalError(let msg):
            return "Llama Error: \(msg)"
        }
    }
}

// Extension to allow `async` sleep
extension Task where Success == Never, Failure == Never {
    static func sleep(seconds: Double) async throws {
        let duration = UInt64(seconds * 1_000_000_000)
        try await Task.sleep(nanoseconds: duration)
    }
}

// End of Mock LlamaKit Bindings
// -----------------------------------------------------------------------------

@main
struct LlamaCLI {
    static func main() async {
        // IMPORTANT: Replace with the actual path to your .gguf model file.
        // For this mock, a dummy file will be created/used at this path.
        let modelFileName = "dummy_model.gguf"
        let modelPath = FileManager.default.temporaryDirectory.appendingPathComponent(modelFileName).path

        let prompt = "What is the capital of France?"
        let maxNewTokens = 50 // Generate up to 50 new tokens

        var llamaModel: LlamaModel?
        var llamaContext: LlamaContext?

        do {
            // 1. Model Loading
            print("\n--- Loading Model ---")
            llamaModel = LlamaModel(path: modelPath)
            try llamaModel?.load() // Use default model parameters

            guard let model = llamaModel else {
                throw LlamaError.generalError("Failed to initialize LlamaModel.")
            }

            // 2. Context Initialization
            print("\n--- Initializing Context ---")
            var contextParams = LlamaContextParams()
            contextParams.n_ctx = 1024 // Example: Set a larger context window
            contextParams.n_threads = 6 // Example: Use 6 threads
            llamaContext = try LlamaContext(model: model, params: contextParams)

            guard let context = llamaContext else {
                throw LlamaError.generalError("Failed to initialize LlamaContext.")
            }

            // 3. Prompt Tokenization
            print("\n--- Tokenizing Prompt ---")
            let promptTokens = model.tokenize(text: prompt, addBos: true)
            guard !promptTokens.isEmpty else {
                throw LlamaError.inferenceFailed("Prompt tokenization resulted in empty tokens.")
            }

            // 4. Inference Execution
            print("\n--- Performing Inference ---")
            print("Prompt: \(prompt)")
            var generatedTokens: [Int32] = []
            var generatedText = ""

            // Feed the prompt into the context
            try context.feedPrompt(tokens: promptTokens)

            // Generate new tokens
            for i in 0..<maxNewTokens {
                let nextToken = context.sampleNextToken()

                if nextToken == model.getEosToken() {
                    print("\n[EOS] detected. Stopping generation.")
                    break
                }
                if nextToken == -1 { // Indicates an error or no more tokens
                    print("\n[Error] Invalid token generated. Stopping generation.")
                    break
                }

                generatedTokens.append(nextToken)
                let newText = model.detokenize(tokens: [nextToken])
                generatedText += newText
                // Optional: print token by token for real-time feel in CLI
                // print(newText, terminator: "")
                // fflush(stdout) // Ensure immediate print
                
                // Simulate processing time per token
                try await Task.sleep(seconds: 0.01)
            }
            print("\n--- Inference Complete ---")

            // 5. Output
            print("\n--- Generated Response ---")
            print("Response: \(generatedText)")

        } catch {
            print("\n--- Error ---")
            print("An error occurred: \(error.localizedDescription)")
        }

        // 6. Resource Cleanup (handled by ARC and deinit blocks in this Swift class structure)
        // Explicitly nil-ing them out to trigger deinit immediately for demonstration
        print("\n--- Cleaning up resources ---")
        llamaContext = nil
        llamaModel = nil
        print("Resources cleaned up.")
    }
}
