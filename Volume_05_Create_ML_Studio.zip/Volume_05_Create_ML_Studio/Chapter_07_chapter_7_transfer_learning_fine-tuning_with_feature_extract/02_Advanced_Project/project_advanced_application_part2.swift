
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreML
import Vision
import CreateML // Implicitly available in Xcode projects targeting macOS 10.15+ / iOS 13+

// MARK: - Error Handling

/// Custom error types for the document classification service.
enum DocumentClassifierError: Error, LocalizedError {
    case invalidTrainingData(String)
    case trainingFailed(Error)
    case modelCompilationFailed(Error)
    case modelLoadingFailed(Error)
    case classificationFailed(Error)
    case noModelAvailable
    case fileSystemError(String)
    case unsupportedImageFormat
    case imageProcessingFailed

    var errorDescription: String? {
        switch self {
        case .invalidTrainingData(let message):
            return "Invalid training data: \(message)"
        case .trainingFailed(let error):
            return "Model training failed: \(error.localizedDescription)"
        case .modelCompilationFailed(let error):
            return "Model compilation failed: \(error.localizedDescription)"
        case .modelLoadingFailed(let error):
            return "Failed to load Core ML model: \(error.localizedDescription)"
        case .classificationFailed(let error):
            return "Document classification failed: \(error.localizedDescription)"
        case .noModelAvailable:
            return "No classification model is currently available."
        case .fileSystemError(let message):
            return "File system error: \(message)"
        case .unsupportedImageFormat:
            return "The provided image format is not supported for classification."
        case .imageProcessingFailed:
            return "Failed to process the image for classification."
        }
    }
}

// MARK: - Data Structures

/// Represents the result of a document classification.
struct DocumentClassificationResult: Identifiable, Hashable {
    let id = UUID()
    let category: String
    let confidence: Double
}

// MARK: - Document Classifier Service

/// An actor responsible for managing document classification models,
/// including training new models using Create ML and performing predictions
/// with Core ML and Vision.
///
/// This service demonstrates an "Advanced Application" of transfer learning
/// by allowing on-device retraining and dynamic model updates based on new data,
/// simulating a scenario where a user might provide feedback or new categories
/// emerge.
@available(iOS 18.0, macOS 15.0, *) // Requires latest OS for Swift 6 features and Create ML capabilities
actor DocumentClassifierService {

    /// The currently loaded Core ML model for classification.
    private var currentModel: MLModel?
    /// The Vision request for performing classifications.
    private var classificationRequest: VNCoreMLRequest?

    /// Initializes the service, optionally loading an initial model.
    /// - Parameter initialModelURL: An optional URL to a pre-existing compiled Core ML model (.mlmodelc).
    init(initialModelURL: URL? = nil) {
        if let url = initialModelURL {
            Task {
                do {
                    try await loadModel(from: url)
                    print("Initialized DocumentClassifierService with model from: \(url.lastPathComponent)")
                } catch {
                    print("Failed to load initial model: \(error.localizedDescription)")
                }
            }
        }
    }

    // MARK: - Model Management

    /// Loads a Core ML model from a given URL and sets up the Vision classification request.
    /// - Parameter modelURL: The URL to the compiled Core ML model (.mlmodelc).
    /// - Throws: `DocumentClassifierError.modelLoadingFailed` if the model cannot be loaded or initialized.
    ///
    /// Logic Breakdown:
    /// 1. Create an `MLModel` instance from the provided URL.
    /// 2. Create a `VNCoreMLModel` from the `MLModel`.
    /// 3. Initialize a `VNCoreMLRequest` with the `VNCoreMLModel`.
    /// 4. Store the `MLModel` and `VNCoreMLRequest` for future use.
    private func loadModel(from modelURL: URL) throws {
        do {
            let model = try MLModel(contentsOf: modelURL)
            let visionModel = try VNCoreMLModel(for: model)
            let request = VNCoreMLRequest(model: visionModel) { request, error in
                // Handle potential errors during classification request execution if needed
                if let error = error {
                    print("Vision classification request failed: \(error.localizedDescription)")
                }
            }
            // Ensure the image analysis request crops the input image to match the model's input size.
            request.imageCropAndScaleOption = .centerCrop
            self.currentModel = model
            self.classificationRequest = request
            print("Successfully loaded model from \(modelURL.lastPathComponent)")
        } catch {
            throw DocumentClassifierError.modelLoadingFailed(error)
        }
    }

    /// Creates a temporary directory for Create ML training data.
    /// - Returns: The URL of the created directory.
    /// - Throws: `DocumentClassifierError.fileSystemError` if the directory cannot be created.
    private func createTrainingDataDirectory() throws -> URL {
        let fileManager = FileManager.default
        let tempDirectory = fileManager.temporaryDirectory.appendingPathComponent("CreateMLTrainingData", isDirectory: true)
        if fileManager.fileExists(atPath: tempDirectory.path) {
            try fileManager.removeItem(at: tempDirectory) // Clean up previous data
        }
        do {
            try fileManager.createDirectory(at: tempDirectory, withIntermediateDirectories: true, attributes: nil)
            return tempDirectory
        } catch {
            throw DocumentClassifierError.fileSystemError("Failed to create temporary training directory: \(error.localizedDescription)")
        }
    }

    /// **Advanced Application: On-Device Retraining/Fine-Tuning**
    ///
    /// Trains or updates the document classification model using new image data provided
    /// as a ZIP archive. This method leverages Create ML's `MLImageClassifierBuilder`
    /// to perform transfer learning (fine-tuning with feature extraction) on-device.
    ///
    /// The ZIP archive is expected to contain subdirectories, where each subdirectory
    /// represents a document category and contains images belonging to that category.
    /// Example: `training_data.zip` -> `Receipts/receipt1.jpg`, `Invoices/invoice1.png`.
    ///
    /// - Parameters:
    ///   - zipData: The `Data` of a ZIP archive containing categorized images for training.
    ///   - modelName: The desired name for the new Core ML model.
    /// - Returns: The URL to the newly compiled `.mlmodelc` file.
    /// - Throws: `DocumentClassifierError` if any step of the process fails.
    ///
    /// Logic Breakdown:
    /// 1. **Prepare Training Data:**
    ///    a. Create a temporary directory to host the unzipped data.
    ///    b. Save the `zipData` to a temporary ZIP file.
    ///    c. Unzip the archive into the temporary directory. (NOTE: This example simplifies the unzipping step;
    ///       a production app would use a robust library like `ZipFoundation`).
    ///    d. Load the unzipped directory as `MLImageClassifier.DataSource`.
    /// 2. **Configure Create ML Builder & Train the Model:**
    ///    a. Initialize `MLImageClassifier` with the training data. Create ML implicitly
    ///       uses transfer learning (feature extraction) by leveraging a pre-trained
    ///       convolutional base and training a new classification head.
    /// 3. **Save and Compile:**
    ///    a. Save the trained `MLImageClassifier` to a temporary `.mlmodel` file.
    ///    b. Compile the `.mlmodel` into a `.mlmodelc` (Core ML Model Compiled) for optimized
    ///       on-device inference. Store it in a persistent location (e.g., app's Application Support directory).
    /// 4. **Load New Model:**
    ///    a. Dynamically load the newly compiled `.mlmodelc` into the service.
    ///    b. Update `currentModel` and `classificationRequest` to use the new model.
    public func trainOrUpdateModel(zipData: Data, modelName: String = "DocumentClassifier") async throws -> URL {
        let fileManager = FileManager.default
        let tempTrainingDir = try createTrainingDataDirectory() // Root for all temporary training assets
        let tempZipURL = tempTrainingDir.appendingPathComponent("training_data.zip")

        // 1a & 1b. Save ZIP data to a temporary file
        do {
            try zipData.write(to: tempZipURL)
            print("Saved training ZIP to \(tempZipURL.lastPathComponent)")
        } catch {
            throw DocumentClassifierError.fileSystemError("Failed to save training ZIP data: \(error.localizedDescription)")
        }

        // 1c. Unzip the archive into a sub-directory within tempTrainingDir.
        // NOTE: This is a crucial placeholder. In a real app, you would use a robust unzipping
        // library (e.g., ZipFoundation) to extract `tempZipURL` to `unzippedTrainingDataRoot`.
        // The `unzippedTrainingDataRoot` should then contain subdirectories for each category.
        let unzippedTrainingDataRoot = tempTrainingDir.appendingPathComponent("unzipped_data", isDirectory: true)
        do {
            try fileManager.createDirectory(at: unzippedTrainingDataRoot, withIntermediateDirectories: true, attributes: nil)
            // MARK: - IMPORTANT: Placeholder for actual unzipping logic.
            // Example using ZipFoundation:
            // try Zip.unzipFile(tempZipURL, destination: unzippedTrainingDataRoot, overwrite: true)
            // For this example, we proceed assuming `unzippedTrainingDataRoot` is populated correctly.
            print("Placeholder: Unzipping 'training_data.zip' to '\(unzippedTrainingDataRoot.lastPathComponent)'.")
            print("In a real app, ensure this directory is populated with category subfolders and images.")
        } catch {
            throw DocumentClassifierError.fileSystemError("Failed to create unzipped data directory: \(error.localizedDescription)")
        }

        // 1d. Load the unzipped directory as MLImageClassifier.DataSource
        let trainingDataSource: MLImageClassifier.DataSource
        do {
            trainingDataSource = .labeledDirectories(at: unzippedTrainingDataRoot)
        } catch {
            throw DocumentClassifierError.invalidTrainingData("Failed to load training data from directory: \(error.localizedDescription)")
        }

        // 2. Configure Create ML Builder and Train the Model
        print("Starting model training (Create ML will use transfer learning)...")
        let classifier: MLImageClassifier
        do {
            // Create ML automatically handles the transfer learning setup (feature extraction
            // and training a new classification head) when initialized with image data.
            classifier = try await MLImageClassifier(trainingData: trainingDataSource)
            print("Model training completed successfully.")
        } catch {
            throw DocumentClassifierError.trainingFailed(error)
        }

        // 3a. Save the trained MLImageClassifier to a temporary .mlmodel file
        let tempMLModelURL = fileManager.temporaryDirectory.appendingPathComponent("\(modelName).mlmodel")
        do {
            try classifier.write(to: tempMLModelURL)
            print("Saved temporary .mlmodel to \(tempMLModelURL.lastPathComponent)")
        } catch {
            throw DocumentClassifierError.fileSystemError("Failed to save temporary .mlmodel: \(error.localizedDescription)")
        }

        // 3b. Compile the .mlmodel into a .mlmodelc
        let compiledModelURL: URL
        do {
            // The compilation target is typically the app's Application Support directory for persistence.
            let appSupportDirectory = try fileManager.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let modelsDirectory = appSupportDirectory.appendingPathComponent("CoreMLModels", isDirectory: true)
            try fileManager.createDirectory(at: modelsDirectory, withIntermediateDirectories: true, attributes: nil)
            
            // Compile the .mlmodel to .mlmodelc (Core ML Model Compiled)
            compiledModelURL = try MLModel.compileModel(at: tempMLModelURL, to: modelsDirectory)
            print("Compiled model saved to \(compiledModelURL.lastPathComponent)")
        } catch {
            throw DocumentClassifierError.modelCompilationFailed(error)
        }

        // 4. Load New Model
        do {
            try loadModel(from: compiledModelURL)
            print("Successfully loaded new trained model for predictions.")
        } catch {
            throw DocumentClassifierError.modelLoadingFailed(error)
        }

        // Clean up temporary files
        do {
            try fileManager.removeItem(at: tempTrainingDir)
            try fileManager.removeItem(at: tempMLModelURL)
            print("Cleaned up temporary training files.")
        } catch {
            print("Warning: Failed to clean up temporary training files: \(error.localizedDescription)")
        }

        return compiledModelURL
    }

    // MARK: - Prediction

    /// Classifies a given image using the currently loaded Core ML model.
    /// - Parameter image: The `CGImage` to classify.
    /// - Returns: An array of `DocumentClassificationResult` representing the top predictions.
    /// - Throws: `DocumentClassifierError` if no model is available or classification fails.
    ///
    /// Logic Breakdown:
    /// 1. Check if a model and classification request are available.
    /// 2. Create a `VNImageRequestHandler` for the input image.
    /// 3. Perform the `VNCoreMLRequest`.
    /// 4. Process the results, filtering for `VNClassificationObservation` and converting them
    ///    into `DocumentClassificationResult`.
    public func classifyDocument(image: CGImage) async throws -> [DocumentClassificationResult] {
        guard let request = classificationRequest else {
            throw DocumentClassifierError.noModelAvailable
        }

        let handler = VNImageRequestHandler(cgImage: image, options: [:])
        do {
            try handler.perform([request])
            guard let observations = request.results as? [VNClassificationObservation] else {
                return [] // No classification observations found
            }

            // Map Vision observations to our custom result type
            let results = observations.map { observation in
                DocumentClassificationResult(
                    category: observation.identifier,
                    confidence: Double(observation.confidence)
                )
            }
            return results
        } catch {
            throw DocumentClassifierError.classificationFailed(error)
        }
    }
}

// MARK: - Example Usage (Illustrative, would typically be in a ViewModel or App entry point)

/// Creates dummy training data structure (not a valid ZIP) for demonstration purposes.
/// In a real app, a proper ZIP library would be used to create an actual ZIP file.
/// This function simulates the *input* expected by `trainOrUpdateModel` in terms of structure.
func createDummyTrainingZipData() throws -> Data {
    let fileManager = FileManager.default
    let tempDir = fileManager.temporaryDirectory.appendingPathComponent("DummyTrainingData", isDirectory: true)
    let receiptsDir = tempDir.appendingPathComponent("unzipped_data").appendingPathComponent("Receipts", isDirectory: true)
    let invoicesDir = tempDir.appendingPathComponent("unzipped_data").appendingPathComponent("Invoices", isDirectory: true)

    if fileManager.fileExists(atPath: tempDir.path) {
        try fileManager.removeItem(at: tempDir)
    }
    // Create the structure that `trainOrUpdateModel`'s unzipping placeholder expects.
    try fileManager.createDirectory(at: receiptsDir, withIntermediateDirectories: true, attributes: nil)
    try fileManager.createDirectory(at: invoicesDir, withIntermediateDirectories: true, attributes: nil)

    // Create dummy image files (empty for brevity, but in reality, these would be actual images)
    let receipt1URL = receiptsDir.appendingPathComponent("receipt1.jpg")
    let invoice1URL = invoicesDir.appendingPathComponent("invoice1.png")
    "dummy_receipt_content".data(using: .utf8)?.write(to: receipt1URL)
    "dummy_invoice_content".data(using: .utf8)?.write(to: invoice1URL)

    print("Created dummy training data structure at \(receiptsDir.deletingLastPathComponent().deletingLastPathComponent().lastPathComponent)")
    
    // This is a placeholder. In a real application, you'd use a library like ZipFoundation
    // to create a proper ZIP archive from `tempDir.appendingPathComponent("unzipped_data")`.
    // For this example, we'll return some arbitrary data to simulate a ZIP, as the
    // `trainOrUpdateModel`'s unzipping step is also a placeholder.
    let dummyZipContent = "PK\u{3}\u{4}\u{14}\u{0}\u{0}\u{0}\u{8}\u{0}\u{27}\u{B2}\u{1}\u{7B}\u{7F}\u{A3}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}\u{0}dummy.txt".data(using: .ascii)!
    return dummyZipContent
}


/// Entry point for demonstrating the DocumentClassifierService.
@available(iOS 18.0, macOS 15.0, *)
func demonstrateDocumentClassifier() async {
    let service = DocumentClassifierService()

    // 1. Simulate initial training (or updating an existing model)
    print("\n--- Starting Model Training Demonstration ---")
    do {
        // Create dummy ZIP data for training (this simulates receiving a ZIP from a user)
        let trainingZipData = try createDummyTrainingZipData()
        
        // This call initiates the on-device transfer learning process.
        let newModelURL = try await service.trainOrUpdateModel(zipData: trainingZipData, modelName: "MyDocumentClassifier")
        print("New model trained and loaded from: \(newModelURL.lastPathComponent)")

        // 2. Simulate classification with a dummy image
        print("\n--- Starting Model Classification Demonstration ---")
        // Create a dummy CGImage (e.g., a blank image) to represent a scanned document.
        let imageSize = CGSize(width: 224, height: 224) // Typical input size for image classifiers
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        guard let context = CGContext(data: nil,
                                      width: Int(imageSize.width),
                                      height: Int(imageSize.height),
                                      bitsPerComponent: 8,
                                      bytesPerRow: 0,
                                      space: colorSpace,
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            print("Failed to create CGContext for dummy image.")
            return
        }
        context.setFillColor(CGColor(red: 0.8, green: 0.9, blue: 1.0, alpha: 1.0)) // Light blue background
        context.fill(CGRect(origin: .zero, size: imageSize))
        guard let dummyImage = context.makeImage() else {
            print("Failed to create dummy CGImage.")
            return
        }

        let classificationResults = try await service.classifyDocument(image: dummyImage)
        if classificationResults.isEmpty {
            print("No classifications returned for the dummy image.")
        } else {
            print("Classification Results for dummy image:")
            for result in classificationResults {
                print("  Category: \(result.category), Confidence: \(String(format: "%.2f", result.confidence * 100))%")
            }
        }
    } catch {
        print("Demonstration failed with error: \(error.localizedDescription)")
        if let docError = error as? DocumentClassifierError {
            print("Specific error type: \(docError)")
        }
    }
    print("\n--- Demonstration Complete ---")
}

// To run this demonstration in a Swift Playground or an app's entry point:
/*
Task {
    await demonstrateDocumentClassifier()
}
*/
