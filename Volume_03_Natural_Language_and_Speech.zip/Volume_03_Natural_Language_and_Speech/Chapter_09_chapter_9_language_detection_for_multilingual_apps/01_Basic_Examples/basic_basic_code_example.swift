
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import NaturalLanguage

/// A utility class for analyzing chat messages, specifically for language detection.
class ChatMessageAnalyzer {

    /// Detects the dominant language of a given text string.
    ///
    /// This function uses `NSLinguisticTagger` to perform a statistical analysis
    /// of the input text and determine its most likely language.
    ///
    /// - Parameter text: The string content of the message to analyze.
    /// - Returns: An `NLLanguage` enum value representing the detected language,
    ///            or `nil` if the language cannot be determined or is not supported.
    func detectLanguage(for text: String) -> NLLanguage? {
        // 1. Initialize NSLinguisticTagger:
        //    We create an instance of NSLinguisticTagger.
        //    The `tagSchemes` parameter specifies what kind of linguistic analysis
        //    we want to perform. Here, we're interested in `.language`.
        //    The `options` parameter can be used to fine-tune behavior, but for
        //    basic language detection, default options are usually sufficient.
        let tagger = NSLinguisticTagger(tagSchemes: [.language], options: 0)

        // 2. Set the string to be analyzed:
        //    We provide the text string to the tagger. This prepares the tagger
        //    for analysis.
        tagger.string = text

        // 3. Retrieve the dominant language:
        //    The `dominantLanguage` property of NSLinguisticTagger returns the
        //    language that the tagger has identified as most likely for the
        //    entire string. It returns an `NLLanguage` enum value, which is a
        //    standardized way to represent languages (e.g., .english, .spanish).
        //    It can return `nil` if the text is too short, ambiguous, or if
        //    the language is not recognized.
        return tagger.dominantLanguage
    }

    /// Provides a user-friendly description for a given language.
    /// - Parameter language: The `NLLanguage` enum value.
    /// - Returns: A localized string representing the language, or "Unknown" if nil.
    func localizedDescription(for language: NLLanguage?) -> String {
        guard let language = language else {
            return "Unknown"
        }
        // NLLanguage provides a convenient `localizedString(for:)` static method
        // to get a human-readable name for the language, respecting the current locale.
        return NLLanguage.localizedString(for: language)
    }
}

// MARK: - Main Application Entry Point for Demonstration

/// A simple structure to simulate our app's main execution flow.
/// This allows the example to be self-contained and runnable.
struct MultilingualChatApp {
    let analyzer = ChatMessageAnalyzer()

    /// Simulates receiving and processing chat messages.
    func run() {
        print("--- Simulating Chat Messages ---")

        let messages = [
            "Hello, how are you?",                      // English
            "Hola, ¿cómo estás?",                       // Spanish
            "Bonjour, comment ça va ?",                 // French
            "Guten Tag, wie geht es Ihnen?",            // German
            "こんにちは、お元気ですか？",             // Japanese
            "안녕하세요, 잘 지내세요?",                 // Korean
            "Привет, как дела?",                        // Russian
            "This is a short test.",                    // English (short)
            "...",                                      // Ambiguous/Too short
            "Ceci est un test en français.",            // French
            "Mixed language: Hello こんにちは"          // Mixed, might pick one dominant
        ]

        for (index, message) in messages.enumerated() {
            print("\n--- Message \(index + 1) ---")
            print("Original Message: \"\(message)\"")

            let detectedLanguage = analyzer.detectLanguage(for: message)
            let languageDescription = analyzer.localizedDescription(for: detectedLanguage)

            print("Detected Language: \(languageDescription) (\(detectedLanguage?.rawValue ?? "N/A"))")

            // Example of a hypothetical action based on language
            if detectedLanguage == .english {
                print("Action: Offering spell-check for English.")
            } else if detectedLanguage == .japanese {
                print("Action: Displaying furigana option.")
            } else if detectedLanguage == .nil { // NLLanguage.nil is not a valid case for comparison,
                                                 // it should be `detectedLanguage == nil`
                print("Action: Could not determine language, prompting user.")
            }
        }
    }
}

// To run this example in a Swift Playground or a command-line tool:
// Ensure NaturalLanguage framework is linked if building a full app.
// For a playground, simply run the code.
MultilingualChatApp().run()
