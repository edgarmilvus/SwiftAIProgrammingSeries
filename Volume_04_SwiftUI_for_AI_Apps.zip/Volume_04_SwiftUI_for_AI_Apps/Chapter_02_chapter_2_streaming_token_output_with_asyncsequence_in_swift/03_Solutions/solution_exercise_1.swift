
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Foundation

// MARK: - Mock AsyncSequence for Words

struct WordStream: AsyncSequence {
    typealias Element = String
    private let text: String
    private let delay: TimeInterval

    init(text: String, delay: TimeInterval = 0.1) {
        self.text = text
        self.delay = delay
    }

    func makeAsyncIterator() -> Iterator {
        Iterator(words: text.split(separator: " ").map(String.init), delay: delay)
    }

    struct Iterator: AsyncIteratorProtocol {
        private var words: [String]
        private let delay: TimeInterval

        init(words: [String], delay: TimeInterval) {
            self.words = words
            self.delay = delay
        }

        mutating func next() async throws -> String? {
            guard !words.isEmpty else { return nil }

            // Simulate delay
            try await Task.sleep(for: .seconds(delay))

            // Check for cancellation before emitting
            try Task.checkCancellation()

            return words.removeFirst()
        }
    }
}

// MARK: - SwiftUI View

struct SimpleStreamView: View {
    @State private var streamedText: String = ""
    @State private var currentStreamTask: Task<Void, Never>?

    var body: some View {
        VStack(spacing: 20) {
            Text("Streamed Output:")
                .font(.headline)

            Text(streamedText)
                .font(.body)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
                .animation(.easeOut(duration: 0.1), value: streamedText) // Smooth text update

            Button("Start Stream") {
                startStreaming()
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .navigationTitle("Simple Stream")
        .onDisappear {
            // Cancel the task if the view disappears
            currentStreamTask?.cancel()
        }
    }

    private func startStreaming() {
        // Cancel any previous active stream task
        currentStreamTask?.cancel()
        streamedText = "" // Clear previous text

        // Start a new task for streaming
        currentStreamTask = Task {
            let stream = WordStream(text: "The quick brown fox jumps over the lazy dog and then takes a nap.", delay: 0.1)
            do {
                for await word in stream {
                    // Update UI on the main actor
                    await MainActor.run {
                        self.streamedText += (self.streamedText.isEmpty ? "" : " ") + word
                    }
                }
            } catch {
                // Handle cancellation or other errors gracefully
                if Task.isCancelled {
                    print("Stream cancelled.")
                } else {
                    print("Stream error: \(error.localizedDescription)")
                }
            }
        }
    }
}
