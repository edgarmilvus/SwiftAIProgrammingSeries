
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CreateML
import Foundation

@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
func analyzeCriticalReviews(from dataTable: MLDataTable) {
    print("--- Analyzing Critical Reviews ---")
    print("Initial Data Table:")
    print(dataTable.head(3))
    print("Initial Row Count: \(dataTable.rowCount)\n")

    do {
        // 2. Filter Critical Reviews: Keep only reviews with rating 1 or 2.
        // MLDataColumn supports comparison operators.
        let criticalReviews = try dataTable.filter(dataTable["rating"] <= 2)
        print("Filtered for critical reviews (rating <= 2).")
        print("Critical Reviews Row Count: \(criticalReviews.rowCount)\n")
        
        // 3. Select Relevant Columns: Keep only 'review_text' and 'rating'.
        let relevantColumns = try criticalReviews.selecting(columns: ["review_text", "rating"])
        print("Selected 'review_text' and 'rating' columns.")
        
        // 4. Verification: Print total rows and first 3 rows of the result.
        print("Final Filtered and Selected Data Table Row Count: \(relevantColumns.rowCount)")
        print("\n--- Final Critical Reviews Data (First 3 Rows) ---")
        print(relevantColumns.head(3))
        
    } catch {
        print("Error analyzing critical reviews: \(error.localizedDescription)")
    }
}

// Helper function to create the initial MLDataTable for this exercise
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
func createInitialAppReviewsDataTable() throws -> MLDataTable {
    let csvContent = """
    review_id,user_id,rating,review_text,submission_date
    101,U001,5,"Great app, very useful!",2023-10-26
    102,U002,1,"Crashes frequently, needs bug fixes.",2023-10-25
    103,U003,4,"Good features, but UI is a bit clunky.",2023-10-24
    104,U004,5,"Best app in its category!",2023-10-26
    105,U005,2,"Disappointed, expected more.",2023-10-23
    """
    let tempDirectory = FileManager.default.temporaryDirectory
    let csvURL = tempDirectory.appendingPathComponent(UUID().uuidString).appendingPathExtension("csv")
    try csvContent.write(to: csvURL, atomically: true, encoding: .utf8)
    let dataTable = try MLDataTable(contentsOf: csvURL)
    try FileManager.default.removeItem(at: csvURL) // Clean up
    return dataTable
}

// Call the function to execute the exercise
/*
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
do {
    let initialTable = try createInitialAppReviewsDataTable()
    analyzeCriticalReviews(from: initialTable)
} catch {
    print("Failed to create initial data table: \(error.localizedDescription)")
}
*/
