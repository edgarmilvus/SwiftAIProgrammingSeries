
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import AVFoundation

// Re-using AudioInputManager from Exercise 1 (or a slightly modified version if needed)
// For this exercise, the AudioInputManager remains the same as in Exercise 1.

// MARK: - SwiftUI Waveform View with Customization

// Helper extension for conditional view modifiers, as provided in the prompt.
extension View {
    @ViewBuilder
    func `if`<Content: View>(_ condition: Bool, transform: (Self) -> Content) -> some View {
        if condition {
            transform(self)
        } else {
            self
        }
    }
}

@available(iOS 18.0, *)
struct CustomizableWaveformView: View {
    let samples: [Float]
    var lineColor: Color
    var lineWidth: CGFloat
    var isFilled: Bool
    var gradientFillStartColor: Color
    var gradientFillEndColor: Color

    var body: some View {
        GeometryReader { geometry in
            Path { path in
                guard !samples.isEmpty else { return }

                let width = geometry.size.width
                let height = geometry.size.height
                let midY = height / 2

                let maxAmplitude: Float = samples.max() ?? 1.0
                let verticalScale = (maxAmplitude > 0.01) ? (height / 2) / maxAmplitude : 0.0

                path.move(to: CGPoint(x: 0, y: midY))

                for i in 0..<samples.count {
                    let x = CGFloat(i) / CGFloat(samples.count - 1) * width
                    let y = midY - CGFloat(samples[i]) * verticalScale
                    path.addLine(to: CGPoint(x: x, y: y))
                }

                // If filled, close the path to form a shape for filling
                if isFilled {
                    path.addLine(to: CGPoint(x: width, y: midY))
                    path.addLine(to: CGPoint(x: 0, y: midY))
                    path.closeSubpath()
                }
            }
            .if(isFilled) { content in
                content.fill(LinearGradient(gradient: Gradient(colors: [gradientFillStartColor, gradientFillEndColor]), startPoint: .top, endPoint: .bottom))
            }
            .if(!isFilled) { content in
                content.stroke(lineColor, lineWidth: lineWidth)
            }
        }
        .frame(height: 100)
        .background(Color.black.opacity(0.8))
        .cornerRadius(8)
    }
}

// MARK: - Main Content View with Controls

@available(iOS 18.0, *)
struct ContentView_Exercise2: View { // Renamed to avoid conflict with Ex1's ContentView
    @StateObject private var audioManager = AudioInputManager()
    @State private var isRecording = false

    // State variables for customization
    @State private var lineColor: Color = .cyan
    @State private var lineWidth: CGFloat = 2.0
    @State private var isFilled: Bool = true
    @State private var gradientStartColor: Color = .cyan.opacity(0.8)
    @State private var gradientEndColor: Color = .purple.opacity(0.2)


    var body: some View {
        VStack {
            Text("Customizable Waveform")
                .font(.largeTitle)
                .padding()

            CustomizableWaveformView(
                samples: audioManager.waveformSamples,
                lineColor: lineColor,
                lineWidth: lineWidth,
                isFilled: isFilled,
                gradientFillStartColor: gradientStartColor,
                gradientFillEndColor: gradientEndColor
            )
            .padding()

            // MARK: - Customization Controls
            VStack(alignment: .leading, spacing: 15) {
                Toggle(isOn: $isFilled) {
                    Text("Filled Waveform")
                }

                if !isFilled {
                    ColorPicker("Line Color", selection: $lineColor)
                    HStack {
                        Text("Line Thickness: \(Int(lineWidth))")
                        Slider(value: $lineWidth, in: 1...10, step: 1) {
                            Text("Line Thickness")
                        } minimumValueLabel: {
                            Text("1")
                        } maximumValueLabel: {
                            Text("10")
                        }
                    }
                } else {
                    ColorPicker("Gradient Start Color", selection: $gradientStartColor)
                    ColorPicker("Gradient End Color", selection: $gradientEndColor)
                }
            }
            .padding()
            .background(Color.gray.opacity(0.2))
            .cornerRadius(10)
            .padding(.horizontal)

            Button(action: toggleRecording) {
                Label(isRecording ? "Stop Recording" : "Start Recording", systemImage: isRecording ? "stop.fill" : "mic.fill")
                    .font(.title2)
                    .padding()
                    .background(isRecording ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(15)
            }
            .padding()
        }
        .onAppear {
            // audioManager.start() // Optional: start automatically
        }
        .onDisappear {
            audioManager.stop()
        }
    }

    private func toggleRecording() {
        if isRecording {
            audioManager.stop()
        } else {
            audioManager.start()
        }
        isRecording.toggle()
    }
}
