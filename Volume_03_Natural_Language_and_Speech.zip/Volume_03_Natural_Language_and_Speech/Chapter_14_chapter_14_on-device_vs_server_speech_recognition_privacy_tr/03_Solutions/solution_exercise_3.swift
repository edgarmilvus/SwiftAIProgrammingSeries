
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import Speech
import AVFoundation

@available(iOS 18.0, *)
class LiveCaptioningViewController: UIViewController, SFSpeechRecognizerDelegate {

    // MARK: - UI Elements
    private let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Initializing..."
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let textView: UITextView = {
        let tv = UITextView()
        tv.font = .systemFont(ofSize: 18)
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8.0
        tv.isEditable = false
        tv.translatesAutoresizingMaskIntoConstraints = false
        return tv
    }()

    private let onDeviceButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Switch to On-Device", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .bold)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 8
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.systemBlue.cgColor
        return button
    }()

    private let serverButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Switch to Server-Based", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .bold)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 8
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.systemBlue.cgColor
        return button
    }()
    
    private let latencyIndicatorLabel: UILabel = {
        let label = UILabel()
        label.text = "Latency: N/A"
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 14, weight: .light)
        label.textColor = .secondaryLabel
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - Speech Recognition Properties
    private var currentSpeechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine() // Manages audio input and output
    private var currentLocale: Locale = Locale.current // Use device's current locale
    private var isRecording: Bool = false
    private var lastPartialResultTimestamp: Date?

    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        requestSpeechAuthorization()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        stopRecognition() // Ensure resources are cleaned up when view disappears
    }

    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Live Captioning"

        view.addSubview(statusLabel)
        view.addSubview(textView)
        view.addSubview(onDeviceButton)
        view.addSubview(serverButton)
        view.addSubview(latencyIndicatorLabel)

        onDeviceButton.addTarget(self, action: #selector(switchToOnDeviceMode), for: .touchUpInside)
        serverButton.addTarget(self, action: #selector(switchToServerMode), for: .touchUpInside)

        NSLayoutConstraint.activate([
            statusLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 30),

            textView.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 250),

            onDeviceButton.topAnchor.constraint(equalTo: textView.bottomAnchor, constant: 30),
            onDeviceButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            onDeviceButton.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant: -10),
            onDeviceButton.heightAnchor.constraint(equalToConstant: 50),

            serverButton.topAnchor.constraint(equalTo: textView.bottomAnchor, constant: 30),
            serverButton.leadingAnchor.constraint(equalTo: view.centerXAnchor, constant: 10),
            serverButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            serverButton.heightAnchor.constraint(equalToConstant: 50),
            
            latencyIndicatorLabel.topAnchor.constraint(equalTo: onDeviceButton.bottomAnchor, constant: 20),
            latencyIndicatorLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            latencyIndicatorLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            latencyIndicatorLabel.heightAnchor.constraint(equalToConstant: 20)
        ])
        
        updateModeButtons(isServerMode: true) // Default to server-based visually
    }

    // MARK: - Authorization
    private func requestSpeechAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation { [weak self] in
                guard let self = self else { return }
                switch authStatus {
                case .authorized:
                    self.statusLabel.text = "Ready. Tap a mode to start."
                    // Start with server-based recognition by default
                    self.setupAndStartRecognition(onDevice: false)
                case .denied, .restricted, .notDetermined:
                    self.statusLabel.text = "Speech Authorization Required"
                    self.onDeviceButton.isEnabled = false
                    self.serverButton.isEnabled = false
                @unknown default:
                    self.statusLabel.text = "Unknown Authorization Status"
                    self.onDeviceButton.isEnabled = false
                    self.serverButton.isEnabled = false
                }
            }
        }
    }

    // MARK: - Mode Switching Actions
    @objc private func switchToOnDeviceMode() {
        setupAndStartRecognition(onDevice: true)
    }

    @objc private func switchToServerMode() {
        setupAndStartRecognition(onDevice: false)
    }

    private func setupAndStartRecognition(onDevice: Bool) {
        // 1. Stop any existing recognition cleanly
        stopRecognition()

        // 2. Prepare for new recognizer
        var finalOnDeviceSetting = onDevice
        if onDevice && !SFSpeechRecognizer.onDeviceSupportedLocales.contains(currentLocale) {
            print("Warning: On-device recognition not available for \(currentLocale.identifier). Falling back to server-based.")
            // Inform user via UI
            let alert = UIAlertController(title: "On-Device Not Available",
                                          message: "On-device recognition is not supported for your current language (\(currentLocale.localizedString(forIdentifier: currentLocale.identifier) ?? currentLocale.identifier)). Using server-based instead.",
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
            finalOnDeviceSetting = false // Force server-based
        }

        currentSpeechRecognizer = SFSpeechRecognizer(locale: currentLocale, onDevice: finalOnDeviceSetting)
        currentSpeechRecognizer?.delegate = self
        
        guard let recognizer = currentSpeechRecognizer, recognizer.isAvailable else {
            OperationQueue.main.addOperation { [weak self] in
                self?.statusLabel.text = "Recognizer Unavailable for \(finalOnDeviceSetting ? "On-Device" : "Server-Based")"
                self?.onDeviceButton.isEnabled = false
                self?.serverButton.isEnabled = false
            }
            print("Failed to create or recognizer not available for mode: \(finalOnDeviceSetting ? "On-Device" : "Server").")
            return
        }

        // 3. Start new recognition task
        startRecording(with: recognizer, onDevice: finalOnDeviceSetting)
        
        OperationQueue.main.addOperation { [weak self] in
            self?.statusLabel.text = "Recording... (\(finalOnDeviceSetting ? "On-Device" : "Server-Based"))"
            self?.updateModeButtons(isServerMode: !finalOnDeviceSetting)
            self?.textView.text = "" // Clear previous caption
            self?.latencyIndicatorLabel.text = "Latency: N/A"
        }
        print("Switched to \(finalOnDeviceSetting ? "On-Device" : "Server-Based") recognition.")
    }

    private func startRecording(with recognizer: SFSpeechRecognizer, onDevice: Bool) {
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

            let inputNode = audioEngine.inputNode
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = recognitionRequest else { fatalError("Unable to create a SFSpeechAudioBufferRecognitionRequest object") }
            recognitionRequest.shouldReportPartialResults = true // Essential for live captioning

            recognitionTask = recognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
                guard let self = self else { return }
                OperationQueue.main.addOperation { // All UI updates on main thread
                    if let result = result {
                        self.textView.text = result.bestTranscription.formattedString
                        // Update latency indicator for perceived latency
                        if let lastTimestamp = self.lastPartialResultTimestamp {
                            let interval = Date().timeIntervalSince(lastTimestamp)
                            self.latencyIndicatorLabel.text = String(format: "Last update: %.2f sec ago", interval)
                        }
                        self.lastPartialResultTimestamp = Date()
                    }

                    if error != nil || (result?.isFinal ?? false) {
                        // For continuous captioning, we don't necessarily stop on final result,
                        // but rather handle errors or let the task continue.
                        // If an error occurs, we might want to restart the recognition or inform the user.
                        if let error = error {
                            print("Recognition error: \(error.localizedDescription)")
                            self.statusLabel.text = "Error: \(error.localizedDescription)"
                            self.stopRecognition() // Stop on error
                            // Attempt to restart or prompt user
                        } else if result?.isFinal ?? false {
                            // If a final result is received, and we want continuous recognition,
                            // we might restart the recognition task here if it truly ended.
                            // For SFSpeechAudioBufferRecognitionRequest, it often continues until endAudio() or cancel().
                            // For this scenario, we just let it continue unless an error occurs.
                        }
                    }
                }
            }

            let recordingFormat = inputNode.outputFormat(forBus: 0)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer: AVAudioPCMBuffer, when: AVAudioTime) in
                self.recognitionRequest?.append(buffer)
            }

            audioEngine.prepare()
            try audioEngine.start()
            isRecording = true
        } catch {
            print("Error starting audio engine: \(error.localizedDescription)")
            stopRecognition()
            OperationQueue.main.addOperation { [weak self] in
                self?.statusLabel.text = "Error starting audio: \(error.localizedDescription)"
            }
        }
    }

    private func stopRecognition() {
        guard isRecording else { return } // Only stop if currently recording
        
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0) // Remove the tap
        recognitionRequest?.endAudio() // Signal the request that no more audio will be appended
        recognitionTask?.cancel() // Cancel the task (or finish() if you want to wait for final result)
        recognitionTask = nil
        recognitionRequest = nil
        currentSpeechRecognizer = nil // Release the recognizer
        isRecording = false
        lastPartialResultTimestamp = nil

        OperationQueue.main.addOperation { [weak self] in
            self?.statusLabel.text = "Stopped. Select a mode to restart."
            self?.latencyIndicatorLabel.text = "Latency: N/A"
            self?.updateModeButtons(isServerMode: true) // Reset button highlight
        }
    }
    
    // MARK: - UI Helper
    private func updateModeButtons(isServerMode: Bool) {
        if isServerMode {
            serverButton.backgroundColor = .systemBlue.withAlphaComponent(0.2)
            serverButton.setTitleColor(.systemBlue, for: .normal)
            onDeviceButton.backgroundColor = .clear
            onDeviceButton.setTitleColor(.label, for: .normal)
        } else {
            onDeviceButton.backgroundColor = .systemGreen.withAlphaComponent(0.2)
            onDeviceButton.setTitleColor(.systemGreen, for: .normal)
            serverButton.backgroundColor = .clear
            serverButton.setTitleColor(.label, for: .normal)
        }
    }

    // MARK: - SFSpeechRecognizerDelegate
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        OperationQueue.main.addOperation { [weak self] in
            guard let self = self else { return }
            if available {
                // If recognizer becomes available, re-enable buttons
                self.onDeviceButton.isEnabled = true
                self.serverButton.isEnabled = true
                self.statusLabel.text = "Ready. Select a mode to start."
            } else {
                // If recognizer becomes unavailable, disable buttons and stop if active
                self.onDeviceButton.isEnabled = false
                self.serverButton.isEnabled = false
                self.statusLabel.text = "Recognizer Unavailable"
                self.stopRecognition()
            }
        }
    }
}
