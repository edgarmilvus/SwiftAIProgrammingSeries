
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import ARKit
import RealityKit
import Vision

@MainActor
class SmartLivingAssistant: NSObject, ARSessionDelegate, ObservableObject {
    private var arView: ARView?
    private var detectionTask: Task<Void, Never>?
    private var lastDetectedObject: VNRecognizedObjectObservation?
    
    // Threshold to prevent jitter
    private let confidenceThreshold: Float = 0.7
    private let distanceThreshold: Float = 5.0 // meters

    func setup(arView: ARView) {
        self.arView = arView
        arView.session.delegate = self
    }

    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        // Run detection on a background task to keep the render loop smooth
        detectionTask?.cancel()
        detectionTask = Task {
            await performObjectDetection(on: frame)
        }
    }

    private func performObjectDetection(on frame: ARFrame) async {
        let pixelBuffer = frame.capturedImage
        let request = VNCoreMLRequest(model: try! VNCoreMLModel(for: ObjectDetector().model)) { [weak self] request, error in
            guard let observations = request.results as? [VNRecognizedObjectObservation] else { return }
            await self?.processObservations(observations, in: frame)
        }
        
        // Vision works on normalized coordinates; ensure we use the correct orientation
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
        try? handler.perform([request])
    }

    private func processObservations(_ observations: [VNRecognizedObjectObservation], in frame: ARFrame) async {
        // Find the most confident object
        guard let topObservation = observations.first(where: { $0.confidence > confidenceThreshold }) else { return }
        
        // 1. Get center of 2D bounding box (Vision uses normalized 0.0 - 1.0)
        let center = CGPoint(x: topObservation.boundingBox.midX, y: topObservation.boundingBox.midY)
        
        // 2. Convert Vision coordinates to Viewport coordinates
        // Vision origin is bottom-left, ARKit/UIKit is top-left. 
        // We use the raycast from the center of the screen.
        guard let arView = arView else { return }
        
        // Convert normalized to screen space
        let screenPoint = CGPoint(x: center.x * Float(arView.bounds.width), 
                                  y: (1 - center.y) * Float(arView.bounds.height))

        // 3. Raycast to find 3D position
        let results = arView.raycast(from: screenPoint, allowing: .estimatedPlane, alignment: .any)
        
        if let firstResult = results.first {
            let worldTransform = firstResult.worldTransform
            let distance = simd_distance(firstResult.worldTransform.columns.3, frame.camera.transform.columns.3)
            
            // 4. Distance Constraint
            if distance < distanceThreshold {
                await anchorLabel(at: worldTransform, for: topObservation.labels.first?.identifier ?? "Object")
            }
        }
    }

    private func anchorLabel(at transform: simd_float4x4, for labelText: String) async {
        guard let arView = arView else { return }
        
        // Create an ARAnchor to ensure the object stays pinned to the real world
        let anchor = ARAnchor(name: labelText, transform: transform)
        arView.session.add(anchor: anchor)
        
        // In a real app, you'd use the session(_:didAdd:) delegate to attach the entity
        // For this exercise, we assume the RealityView/Delegate handles the attachment.
    }
}

// Helper to create the text entity
struct LabelEntityFactory {
    static func createTextEntity(text: String) -> ModelEntity {
        let mesh = MeshResource.generateText(text, extrusionDepth: 0.01, font: .systemFont(ofSize: 0.05))
        let material = SimpleMaterial(color: .white, isMetallic: false)
        let entity = ModelEntity(mesh: mesh, materials: [material])
        
        // Position 10cm above the anchor
        entity.position.y = 0.1 
        return entity
    }
}
