
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Observation // Required for @Observable

@available(iOS 17.0, *)
@Observable
class AudioEventDetector {
    var detectedLabel: String = "Listening..."
    var confidence: Double = 0.0
    var isDetecting: Bool = false
    var lastError: String?

    // This class would internally manage the AudioClassifier actor
    // and update its properties based on the actor's output.
    private var classifierActor: AudioClassifier?
    
    func startDetection(modelURL: URL) async {
        isDetecting = true
        lastError = nil
        do {
            classifierActor = try await AudioClassifier(modelURL: modelURL)
            // In a real app, the AudioClassifier actor would notify this detector
            // (e.g., via a delegate or async sequence) of new predictions.
            // For now, we'll just simulate updates.
            try classifierActor?.startAudioProcessing()
            
            // Simulate receiving updates from the actor
            for await (label, conf) in classifierActor!.predictionStream { // Hypothetical stream
                await MainActor.run {
                    self.detectedLabel = label
                    self.confidence = conf
                }
            }
        } catch {
            await MainActor.run {
                self.lastError = error.localizedDescription
                self.isDetecting = false
            }
        }
    }
    
    func stopDetection() async {
        await classifierActor?.stopAudioProcessing()
        await MainActor.run {
            isDetecting = false
            detectedLabel = "Stopped."
            confidence = 0.0
        }
    }
}

@available(iOS 17.0, *)
struct AudioDetectionView: View {
    @State private var detector = AudioEventDetector()
    @State private var modelURL: URL? // Loaded from bundle

    var body: some View {
        VStack {
            Text("Detected Event: \(detector.detectedLabel)")
                .font(.title)
            Text("Confidence: \(String(format: "%.2f", detector.confidence * 100))%")
                .font(.subheadline)
                .padding(.bottom)

            if detector.isDetecting {
                ProgressView()
                Button("Stop Detecting") {
                    Task { await detector.stopDetection() }
                }
            } else {
                Button("Start Detecting") {
                    Task {
                        // Ensure modelURL is loaded before starting
                        guard let url = Bundle.main.url(forResource: "MySoundClassifier", withExtension: "mlmodelc") else {
                            detector.lastError = "Model not found."
                            return
                        }
                        await detector.startDetection(modelURL: url)
                    }
                }
            }
            
            if let error = detector.lastError {
                Text("Error: \(error)")
                    .foregroundColor(.red)
            }
        }
        .padding()
    }
}
