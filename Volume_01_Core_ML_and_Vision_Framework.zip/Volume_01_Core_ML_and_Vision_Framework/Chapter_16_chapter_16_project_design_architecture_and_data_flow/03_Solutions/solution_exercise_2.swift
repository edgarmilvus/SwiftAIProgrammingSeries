
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

// MARK: - TextRecognitionService

import Vision
import UIKit

enum TextRecognitionError: Error, LocalizedError {
    case imageConversionFailed
    case visionRequestFailed(Error)
    case noTextDetected

    var errorDescription: String? {
        switch self {
        case .imageConversionFailed: return "Failed to convert image for text recognition."
        case .visionRequestFailed(let error): return "Vision text recognition failed: \(error.localizedDescription)"
        case .noTextDetected: return "No text was detected in the image."
        }
    }
}

class TextRecognitionService {

    @available(iOS 18.0, *)
    func recognizeText(in image: UIImage) async throws -> String {
        guard let cgImage = image.cgImage else {
            throw TextRecognitionError.imageConversionFailed
        }

        // Use withCheckedThrowingContinuation to bridge the callback-based Vision API to async/await
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNRecognizeTextRequest { request, error in
                if let error = error {
                    continuation.resume(throwing: TextRecognitionError.visionRequestFailed(error))
                    return
                }

                guard let observations = request.results as? [VNRecognizedTextObservation] else {
                    continuation.resume(throwing: TextRecognitionError.noTextDetected)
                    return
                }

                let recognizedText = observations.compactMap { observation in
                    // Get the top candidate for each observation.
                    guard let topCandidate = observation.topCandidates(1).first else { return nil }
                    return topCandidate.string
                }.joined(separator: "\n") // Join lines with newline

                if recognizedText.isEmpty {
                    continuation.resume(throwing: TextRecognitionError.noTextDetected)
                } else {
                    continuation.resume(returning: recognizedText)
                }
            }

            // Configure the request for accurate and robust text recognition
            request.recognitionLevel = .accurate // Use .accurate for better quality, .fast for speed
            request.usesLanguageCorrection = true // Improve results by using language models
            request.revision = VNRecognizeTextRequestRevision3 // Use the latest revision for best results

            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: TextRecognitionError.visionRequestFailed(error))
            }
        }
    }
}

// MARK: - ViewController Layer (Conceptual Implementation)

class DocumentScannerViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    let textRecognitionService = TextRecognitionService()
    
    // UI Outlets (simulated)
    let documentImageView = UIImageView()
    let recognizedTextView = UITextView()
    let activityIndicator = UIActivityIndicatorView(style: .large)
    let scanDocumentButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI() // Setup UI programmatically
    }
    
    // MARK: - UI Setup (Programmatic for example)
    private func setupUI() {
        view.backgroundColor = .white
        
        documentImageView.contentMode = .scaleAspectFit
        documentImageView.backgroundColor = .lightGray
        documentImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(documentImageView)
        
        recognizedTextView.isEditable = false
        recognizedTextView.font = UIFont.systemFont(ofSize: 16)
        recognizedTextView.layer.borderColor = UIColor.lightGray.cgColor
        recognizedTextView.layer.borderWidth = 1.0
        recognizedTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(recognizedTextView)
        
        activityIndicator.hidesWhenStopped = true
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(activityIndicator)
        
        scanDocumentButton.setTitle("Scan Document", for: .normal)
        scanDocumentButton.addTarget(self, action: #selector(scanDocumentTapped), for: .touchUpInside)
        scanDocumentButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scanDocumentButton)
        
        NSLayoutConstraint.activate([
            documentImageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            documentImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            documentImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            documentImageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.4),
            
            recognizedTextView.topAnchor.constraint(equalTo: documentImageView.bottomAnchor, constant: 20),
            recognizedTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            recognizedTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            recognizedTextView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.3),
            
            activityIndicator.centerXAnchor.constraint(equalTo: recognizedTextView.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: recognizedTextView.centerYAnchor),
            
            scanDocumentButton.topAnchor.constraint(equalTo: recognizedTextView.bottomAnchor, constant: 20),
            scanDocumentButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            scanDocumentButton.widthAnchor.constraint(equalToConstant: 200),
            scanDocumentButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    @objc func scanDocumentTapped(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary // Or .camera
        present(picker, animated: true)
    }

    // MARK: - UIImagePickerControllerDelegate
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        guard let image = info[.originalImage] as? UIImage else { return }

        documentImageView.image = image
        recognizedTextView.text = "Scanning for text..."
        activityIndicator.startAnimating()

        if #available(iOS 18.0, *) {
            Task { @MainActor in // Task is created on MainActor, so UI updates are safe
                do {
                    let recognizedText = try await textRecognitionService.recognizeText(in: image)
                    recognizedTextView.text = recognizedText
                } catch {
                    recognizedTextView.text = "Error recognizing text: \(error.localizedDescription)"
                    print("Error: \(error)")
                }
                activityIndicator.stopAnimating()
            }
        } else {
            recognizedTextView.text = "iOS 18.0 or later is required for this async operation."
            activityIndicator.stopAnimating()
        }
    }
}
