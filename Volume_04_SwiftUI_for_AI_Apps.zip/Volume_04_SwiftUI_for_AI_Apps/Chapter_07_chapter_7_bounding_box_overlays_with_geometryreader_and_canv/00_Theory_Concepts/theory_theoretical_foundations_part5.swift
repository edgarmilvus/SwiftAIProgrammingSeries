
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
struct AIAppView: View {
    @State private var inputImage: UIImage? = UIImage(named: "sample_image")
    @State private var aiViewModel = AIDetectionViewModel() // @Observable instance

    // Actor instance for AI model management
    @State private var aiModelManager = AIModelManager()

    var body: some View {
        VStack {
            if let inputImage {
                Image(uiImage: inputImage)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .overlay {
                        GeometryReader { geometry in
                            // Pass the actual rendered size of the image to the overlay
                            BoundingBoxOverlayView(
                                imageSize: geometry.size,
                                detections: aiViewModel.detections // Observe detections from ViewModel
                            )
                        }
                    }
                    .frame(maxHeight: 500) // Constrain image size for demonstration
            } else {
                Text("Loading image...")
            }

            Button("Run Object Detection") {
                Task {
                    guard let inputImage,
                          let pixelBuffer = inputImage.toCVPixelBuffer() else { return } // Helper to convert UIImage to CVPixelBuffer
                    
                    do {
                        // Call actor method to perform inference
                        let results = try await aiModelManager.performDetection(on: pixelBuffer)
                        // Update @Observable ViewModel on the main actor
                        await MainActor.run {
                            aiViewModel.detections = results
                        }
                    } catch {
                        print("AI inference failed: \(error)")
                    }
                }
            }
            .padding()
        }
    }
}

// Dummy extension for UIImage to CVPixelBuffer conversion for example
extension UIImage {
    func toCVPixelBuffer() -> CVPixelBuffer? {
        // Real implementation involves Core Graphics/ImageIO for conversion
        // This is a placeholder for demonstration
        print("Converting UIImage to CVPixelBuffer...")
        return nil // In a real app, return a valid CVPixelBuffer
    }
}
