
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import AppTrackingTransparency

struct StyleSelectorView: View {
    @Environment(PrivacyState.self) private var privacyState
    @State private var isPersonalizedModeEnabled = false
    
    var body: some View {
        List {
            Section("AI Generation Modes") {
                // Standard Mode: Always available
                Toggle("Standard Mode", isOn: .constant(true))
                    .disabled(true) // Core functionality is always on
                
                // Personalized Mode: Conditional availability
                HStack {
                    Toggle("Personalized Style Mode", isOn: $isPersonalizedModeEnabled)
                        .disabled(isPersonalizedUnavailable)
                    
                    if isPersonalizedUnavailable {
                        Image(systemName: "info.circle")
                            .foregroundColor(.secondary)
                            .help("Enable tracking in Settings to unlock personalized aesthetic adaptations.")
                    }
                }
            }
        }
        .navigationTitle("VisionaryGen")
    }
    
    private var isPersonalizedUnavailable: Bool {
        // If status is denied or restricted, the feature is unavailable
        let status = privacyState.authorizationStatus
        return status == .denied || status == .restricted
    }
}

// To handle the "Reactive Updates" requirement, we use the scenePhase in the Root View
// (as seen in Exercise 1) to ensure that when the user returns from Settings, 
// the PrivacyState is refreshed, and this View re-renders automatically.
