
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import ARKit
import RealityKit
import Vision
import Combine

// MARK: - Dependencies
/*
 To use this in a real project, ensure your Package.swift includes:
 .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
 (Though for this specific implementation, standard Apple frameworks suffice)
*/

/// Errors specific to the Spatial Detection Pipeline.
enum SpatialDetectionError: Error {
    case frameConversionFailed
    case inferenceTimeout
    case invalidCameraTransform
    case coordinateMappingError
}

/// A representation of a detected object in 3D space.
struct DetectedSpatialObject: Sendable {
    let id: UUID
    let label: String
    let confidence: Float
    let worldTransform: simd_float4x4
    let boundingBox3D: BoundingBox // Custom struct for 3D bounds
}

struct BoundingBox: Sendable {
    var min: SIMD3<Float>
    var max: SIMD3<Float>
}

// MARK: - Detection Actor

/// The `DetectionActor` is responsible for performing heavy Vision/CoreML inference.
/// By using an `actor`, we ensure that the heavy lifting of image processing 
/// never blocks the MainActor (UI/RealityKit).
@available(iOS 18.0, visionOS 2.0, *)
actor DetectionActor {
    
    private var isProcessing = false
    private let detectionRequest: VNDetectRectanglesRequest // Using Rectangles for demo; swap with CoreML for specific objects
    
    init() {
        // In a real app, you would load a .mlmodel here.
        self.detectionRequest = VNDetectRectanglesRequest()
    }
    
    /// Processes a single pixel buffer from the ARKit stream.
    /// - Parameter pixelBuffer: The raw image data from the camera.
    /// - Returns: An array of detected objects with their 2D metadata.
    /// - Throws: `SpatialDetectionError` if processing fails.
    func performInference(on pixelBuffer: CVPixelBuffer) async throws -> [VNRecognizedObjectObservation] {
        // Prevent overlapping requests to avoid CPU/GPU exhaustion (Backpressure)
        guard !isProcessing else { return [] }
        isProcessing = true
        
        defer { isProcessing = false }
        
        return try await withCheckedThrowingContinuation { continuation in
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
            
            do {
                try handler.perform([detectionRequest])
                let observations = detectionRequest.results as? [VNRecognizedObjectObservation] ?? []
                continuation.resume(returning: observations)
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
}

// MARK: - Spatial Transformer

/// A utility to bridge the gap between 2D Vision coordinates and 3D RealityKit coordinates.
struct SpatialTransformer {
    
    /// Maps a 2D normalized Vision bounding box to a 3D position in the ARWorld.
    /// - Parameters:
    ///   - observation: The Vision observation containing the 2D rect.
    ///   - frame: The current ARFrame to access camera intrinsics and extrinsics.
    /// - Returns: A 4x4 transform matrix representing the object's position in 3D.
    static func projectTo3D(
        observation: VNRecognizedObjectObservation,
        in frame: ARFrame
    ) throws -> simd_float4x4 {
        
        // 1. Get the center of the 2D bounding box
        let rect = observation.boundingBox
        let centerPoint = CGPoint(x: rect.midX, y: rect.midY)
        
        // 2. Convert normalized Vision coordinates (0-1, bottom-left origin)
        // to Viewport coordinates (0-width, 0-height, top-left origin).
        let viewportSize = CGSize(width: frame.camera.imageResolution.width, 
                                  height: frame.camera.imageResolution.height)
        
        // Vision (0,0 is bottom-left) -> UIKit/Metal (0,0 is top-left)
        let viewX = centerPoint.x * viewportSize.width
        let viewY = (1.0 - centerPoint.y) * viewportSize.height
        let screenPoint = CGPoint(x: viewX, y: viewY)
        
        // 3. Perform Raycasting or Unprojection
        // We use the camera's unprojectPoint to find a point in 3D space.
        // Since Vision gives us a 2D point, we need to provide a depth (z).
        // In a real-world app, we would use ARKit's Raycast to find the actual surface.
        
        let raycastQuery = frame.raycastQuery(from: screenPoint, 
                                              allowing: .estimatedPlane, 
                                              alignment: .any)
        
        guard let query = raycastQuery else {
            throw SpatialDetectionError.invalidCameraTransform
        }
        
        // Attempt to find the intersection with the real world
        let results = frame.raycast(query)
        
        if let firstResult = results.first {
            return firstResult.worldTransform
        } else {
            // Fallback: If no plane is detected, project a point at a fixed distance (e.g., 1 meter)
            // This prevents the app from crashing but indicates a loss of spatial depth.
            return try unprojectPointAtDepth(point: screenPoint, depth: 1.0, frame: frame)
        }
    }
    
    private static func unprojectPointAtDepth(point: CGPoint, depth: Float, frame: ARFrame) throws -> simd_float4x4 {
        // Implementation of manual unprojection using the camera's projection matrix
        // This is a simplified version of the math required for visionOS/ARKit
        let projectionMatrix = frame.camera.projectionMatrix(for: .landscapeRight, 
                                                            aspectRatio: 1.0, 
                                                            fieldOfView: 60)
        let viewMatrix = frame.camera.viewMatrix(for: .landscapeRight)
        
        // Convert screen point to Normalized Device Coordinates (NDC)
        let ndcX = (Float(point.x) / Float(frame.camera.imageResolution.width)) * 2.0 - 1.0
        let ndcY = (Float(point.y) / Float(frame.camera.imageResolution.height)) * 2.0 - 1.0
        
        // Create a point in NDC space
        let ndcPoint = SIMD4<Float>(ndcX, ndcY, -1.0, 1.0) // -1 is the near plane
        
        // Multiply by inverse projection and view matrices to get world space
        let invViewProj = (projectionMatrix * viewMatrix).inverse
        let worldPoint = invViewProj * ndcPoint
        
        let position = worldPoint.xyz / worldPoint.w
        
        // Construct a transform matrix from the position
        var transform = matrix_identity_float4x4
        transform.columns.3 = SIMD4<Float>(position.x, position.y, position.z, 1.0)
        return transform
    }
}

// MARK: - RealityKit Overlay Manager

/// The `OverlayManager` handles the lifecycle of 3D entities in the RealityKit scene.
/// It ensures that we reuse entities rather than constantly creating/destroying them,
/// which is critical for maintaining high performance.
@MainActor
class SpatialOverlayManager: ObservableObject {
    
    private var entityCache: [UUID: ModelEntity] = [:]
    private let scene: Scene
    
    init(scene: Scene) {
        self.scene = scene
    }
    
    /// Updates the scene with new detections.
    /// - Parameter detections: The list of objects projected into 3D space.
    func updateOverlays(with detections: [DetectedSpatialObject]) {
        let currentIDs = Set(detections.map { $0.id })
        
        // 1. Remove entities that are no longer detected
        for (id, entity) in entityCache where !currentIDs.contains(id) {
            entity.removeFromParent()
            entityCache.removeValue(forKey: id)
        }
        
        // 2. Update or Create entities
        for detection in detections {
            if let existingEntity = entityCache[detection.id] {
                // Smoothly interpolate to the new position (Temporal Smoothing)
                existingEntity.move(to: detection.worldTransform, 
                                   relativeTo: nil, 
                                   duration: 0.1, 
                                   timingFunction: .linear)
            } else {
                // Create a new visual representation (e.g., a glowing wireframe box)
                let newEntity = createBoundingBoxEntity(for: detection)
                newEntity.setTransformMatrix(detection.worldTransform, relativeTo: nil)
                
                // Add to a dedicated anchor in the scene
                let anchor = AnchorEntity(world: detection.worldTransform)
                anchor.addChild(newEntity)
                scene.addAnchor(anchor)
                
                entityCache[detection.id] = newEntity
            }
        }
    }
    
    private func createBoundingBoxEntity(for detection: DetectedSpatialObject) -> ModelEntity {
        let mesh = MeshResource.generateBox(size: 0.1) // 10cm box
        let material = UnlitMaterial(color: .cyan.withAlphaComponent(0.5))
        return ModelEntity(mesh: mesh, materials: [material])
    }
}

// MARK: - Main Application Component

/// The primary view controller/view that orchestrates the ARKit loop and the DetectionActor.
@available(iOS 18.0, visionOS 2.0, *)
struct SpatialAssistantView: View {
    
    @StateObject private var overlayManager: SpatialOverlayManager
    private let detectionActor = DetectionActor()
    
    // We use a Task to manage the long-running ARKit frame loop
    @State private var processingTask: Task<Void, Never>?
    
    init(scene: Scene) {
        _overlayManager = StateObject(wrappedValue: SpatialOverlayManager(scene: scene))
    }
    
    var body: some View {
        RealityView { content in
            // Initialization of the ARSession would happen here
        }
        .onAppear {
            startDetectionLoop()
        }
        .onDisappear {
            processingTask?.cancel()
        }
    }
    
    /// The core loop that connects ARKit frames to the Vision Actor.
    private func startDetectionLoop() {
        processingTask = Task {
            // In a real app, this would be an AsyncSequence of ARFrame objects
            // from an ARSession.
            let session = ARSession() 
            
            // Mocking the frame loop for architectural demonstration
            for await frame in session.framePublisher.values {
                guard !Task.isCancelled else { break }
                
                do {
                    // 1. Offload inference to the Actor
                    let observations = try await detectionActor.performInference(on: frame.capturedImage)
                    
                    // 2. Map 2D observations to 3D world transforms
                    let spatialObjects = try observations.compactMap { observation -> DetectedSpatialObject? in
                        let transform = try SpatialTransformer.projectTo3D(observation: observation, in: frame)
                        
                        return DetectedSpatialObject(
                            id: UUID(), // In practice, use a stable ID from the model
                            label: observation.labels.first?.identifier ?? "Unknown",
                            confidence: observation.confidence,
                            worldTransform: transform,
                            boundingBox3D: BoundingBox(min: .zero, max: .zero) // Simplified
                        )
                    }
                    
                    // 3. Update the RealityKit scene on the MainActor
                    await overlayManager.updateOverlays(with: spatialObjects)
                    
                } catch {
                    print("Detection Pipeline Error: \(error)")
                }
            }
        }
    }
}

// Helper for SIMD math
extension simd_float4x4 {
    var xyz: SIMD3<Float> {
        return SIMD3<Float>(columns.3.x, columns.3.y, columns.3.z)
    }
}

extension SIMD4 {
    var xyz: SIMD3<T> {
        return SIMD3<T>(x, y, z)
    }
}
