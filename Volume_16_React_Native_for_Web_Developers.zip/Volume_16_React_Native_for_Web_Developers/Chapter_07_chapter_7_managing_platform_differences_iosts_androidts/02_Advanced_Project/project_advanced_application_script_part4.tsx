/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.tsx
// Description: Advanced Application Script
// ==========================================

// File: app/dashboard/page.tsx (Next.js App Router)
import React, { Suspense } from 'react';
import { AnalyticsCard } from '../../components/AnalyticsCard';
import { AnalyticsData } from '../../components/AnalyticsCard.types';

// Mock Data Service
const fetchAnalyticsData = async (): Promise<AnalyticsData[]> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  return [
    { id: '1', label: 'Active Users', value: 12405, trend: 'up' },
    { id: '2', label: 'Churn Rate', value: 24, trend: 'down' },
    { id: '3', label: 'Session Duration', value: 450, trend: 'neutral' },
  ];
};

/**
 * Dashboard Page Component
 * Demonstrates the usage of the Universal Component with Suspense boundaries.
 */
export default async function DashboardPage() {
  const data = await fetchAnalyticsData();

  return (
    <main className="min-h-screen bg-gray-900 p-8 font-sans">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-6">Analytics Overview</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
          {/* 
            Suspense Boundary for Async Data Loading 
            While strictly not needed for this mock data (it's awaited), 
            it's crucial for streaming UI or RSC fetching strategies.
          */}
          <Suspense fallback={<div className="text-gray-400">Loading metrics...</div>}>
            {data.map((item) => (
              <AnalyticsCard 
                key={item.id} 
                data={item} 
                onPress={(id) => console.log('Pressed card:', id)} 
              />
            ))}
          </Suspense>
        </div>
      </div>
    </main>
  );
}
