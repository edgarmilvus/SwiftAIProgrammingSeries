
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

struct RecursiveCharacterSplitter {
    let maxChunkSize: Int
    let separators: [String]
    
    init(maxChunkSize: Int, separators: [String] = ["\n\n", "\n", ". ", " ", ""]) {
        self.maxChunkSize = maxChunkSize
        self.separators = separators
    }
    
    /// Recursively splits text into semantically cohesive chunks.
    func split(text: String) async -> [String] {
        // We wrap the recursive logic in a Task to ensure it can be called asynchronously
        // and doesn't block the caller's thread.
        return await Task.detached(priority: .userInitiated) {
            return self.recursiveSplit(text: text, separatorIndex: 0)
        }.value
    }
    
    private func recursiveSplit(text: String, separatorIndex: Int) -> [String] {
        // Base Case 1: Text is already small enough
        if text.count <= maxChunkSize {
            return [text.trimmingCharacters(in: .whitespacesAndNewlines)]
        }
        
        // Base Case 2: We've exhausted all separators
        guard separatorIndex < separators.count else {
            // If we can't split further, return the text truncated to prevent infinite growth
            // but we return it as a single chunk to avoid data loss.
            return [String(text.prefix(maxChunkSize))]
        }
        
        let separator = separators[separatorIndex]
        
        // If the separator is empty (the last fallback), we treat it as a character split
        if separator.isEmpty {
            return splitByCharacters(text: text)
        }
        
        // Split the text by the current separator
        let parts = text.components(separatedBy: separator)
        var finalChunks: [String] = []
        
        // This is the core recursive logic
        for part in parts {
            let trimmedPart = part.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmedPart.isEmpty { continue }
            
            if trimmedPart.count <= maxChunkSize {
                // If the part fits, add it (re-attaching the separator isn't strictly 
                // necessary for embeddings, but keeps context)
                finalChunks.append(trimmedPart)
            } else {
                // If the part is too big, recurse using the NEXT separator in the hierarchy
                let subChunks = recursiveSplit(text: trimmedPart, separatorIndex: separatorIndex + 1)
                finalChunks.append(contentsOf: subChunks)
            }
        }
        
        return finalChunks
    }
    
    private func splitByCharacters(text: String) -> [String] {
        // Fallback: split by individual characters if all else fails
        var result: [String] = []
        var current = ""
        for char in text {
            if current.count + 1 <= maxChunkSize {
                current.append(char)
            } else {
                result.append(current)
                current = String(char)
            }
        }
        if !current.isEmpty { result.append(current) }
        return result
    }
}
