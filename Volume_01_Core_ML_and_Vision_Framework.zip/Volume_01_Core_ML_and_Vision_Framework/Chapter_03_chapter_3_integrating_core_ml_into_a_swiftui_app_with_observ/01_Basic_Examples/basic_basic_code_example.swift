
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import PhotosUI // For PhotosPicker to select images
import CoreML   // For MLModel and MLModelConfiguration
import Vision   // For VNCoreMLModel, VNCoreMLRequest, and image processing
import UIKit    // For UIImage, CGImage, which PhotosPickerItem loads into

// MARK: - ImageClassifierViewModel

/// An observable view model responsible for handling image selection, Core ML model loading,
/// and performing image classification using the Vision framework.
///
/// This class leverages the new `@Observable` macro (available from iOS 17.0, but we target 18.0 for Swift 6 context)
/// for robust state management, automatically notifying SwiftUI views of changes to its properties.
@available(iOS 18.0, *) // Targeting iOS 18.0 for Swift 6 features and latest SDK context.
class ImageClassifierViewModel: Observable {
    
    // MARK: - Published Properties (automatically observed by SwiftUI with @Observable)
    
    /// The currently selected `PhotosPickerItem` from the Photos library.
    /// Changes to this property will trigger image loading and classification.
    var selectedImageItem: PhotosPickerItem? {
        didSet {
            // Using a didSet observer to automatically react to image selection changes.
            // We dispatch this to a Task on the MainActor because PhotosPickerItem loading
            // and subsequent UI updates need to happen on the main thread.
            Task { @MainActor in
                await processSelectedImageItem(selectedImageItem)
            }
        }
    }
    
    /// The `UIImage` representation of the currently selected image, displayed in the UI.
    var displayImage: UIImage?
    
    /// The classification result string to be displayed to the user.
    var classificationResult: String = "No image selected."
    
    /// A boolean indicating whether an image classification is currently in progress.
    var isLoading: Bool = false
    
    /// An optional error message to display if classification fails.
    var errorMessage: String?
    
    // MARK: - Private Properties
    
    /// The Core ML model wrapped in a `VNCoreMLModel` for use with the Vision framework.
    /// This allows Vision to handle image preprocessing (scaling, rotation, pixel format) automatically.
    private var coreMLModel: VNCoreMLModel?
    
    /// The Core ML request used to perform image classification.
    /// Initialized once the `coreMLModel` is loaded.
    private var classificationRequest: VNCoreMLRequest?
    
    // MARK: - Initialization
    
    /// Initializes the view model by loading the Core ML model.
    init() {
        loadCoreMLModel()
    }
    
    /// Loads the `ImageClassifier.mlmodel` into `VNCoreMLModel`.
    ///
    /// This method attempts to find the compiled Core ML model (`.mlmodelc`) within the app's bundle.
    /// If successful, it initializes `VNCoreMLModel` and `VNCoreMLRequest`.
    /// It's crucial to handle potential errors during model loading, as the app cannot function without it.
    private func loadCoreMLModel() {
        // 1. Locate the compiled Core ML model in the app bundle.
        // Xcode compiles .mlmodel into a .mlmodelc directory.
        guard let modelURL = Bundle.main.url(forResource: "ImageClassifier", withExtension: "mlmodelc") else {
            errorMessage = "Failed to find 'ImageClassifier.mlmodelc' in app bundle. Make sure you've added the .mlmodel file to your project and checked its target membership."
            print("Error: \(errorMessage!)")
            return
        }
        
        do {
            // 2. Configure the MLModel. This is where you can specify compute units.
            let modelConfiguration = MLModelConfiguration()
            // For optimal performance, consider setting computeUnits:
            // .all (default, lets system decide), .cpuOnly, .gpuAndNeuralEngine, .neuralEngine
            modelConfiguration.computeUnits = .all // Using .all for broad compatibility.
            
            // 3. Instantiate the MLModel from the compiled model URL with the configuration.
            let mlModel = try MLModel(contentsOf: modelURL, configuration: modelConfiguration)
            
            // 4. Wrap the MLModel in a VNCoreMLModel for Vision framework integration.
            // Vision significantly simplifies image preprocessing for Core ML.
            self.coreMLModel = try VNCoreMLModel(for: mlModel)
            
            // 5. Create a VNCoreMLRequest. This request will be executed by VNImageRequestHandler.
            // The completion block will be called when Vision finishes processing the image
            // and the Core ML model provides its predictions.
            self.classificationRequest = VNCoreMLRequest(model: self.coreMLModel!) { [weak self] request, error in
                self?.handleClassificationResult(request: request, error: error)
            }
            
            // 6. Optional: Configure the request to scale the image to fill the model's input size.
            // This is often a good default for classification models, ensuring the entire image
            // content is considered while maintaining aspect ratio.
            self.classificationRequest?.imageCropAndScaleOption = .centerCrop
            
            print("Core ML model 'ImageClassifier' loaded successfully.")
            
        } catch {
            // Handle any errors during model loading.
            errorMessage = "Failed to load Core ML model: \(error.localizedDescription)"
            print("Error loading Core ML model: \(error)")
        }
    }
    
    // MARK: - Image Processing and Classification
    
    /// Processes the selected `PhotosPickerItem`, loads the image data, and triggers classification.
    ///
    /// This function is marked `@MainActor` because `PhotosPickerItem`'s `loadTransferable`
    /// often involves UI-related tasks (like presenting a loading indicator) and its results
    /// will directly update UI-bound properties (`displayImage`, `isLoading`).
    ///
    /// - Parameter item: The `PhotosPickerItem` selected by the user.
    @MainActor
    private func processSelectedImageItem(_ item: PhotosPickerItem?) async {
        guard let item = item else {
            // If no item is selected (e.g., user cancels PhotosPicker), reset state.
            displayImage = nil
            classificationResult = "No image selected."
            errorMessage = nil
            return
        }
        
        // Indicate loading state and clear previous results/errors.
        isLoading = true
        errorMessage = nil
        classificationResult = "Classifying..."
        displayImage = nil // Clear previous image display
        
        do {
            // 1. Asynchronously load the image data from the PhotosPickerItem.
            // This uses the new `Transferable` protocol for efficient data transfer.
            guard let data = try await item.loadTransferable(type: Data.self) else {
                throw NSError(domain: "ImageClassifier", code: 1, userInfo: [NSLocalizedDescriptionKey: "Failed to load image data from PhotosPicker."])
            }
            
            // 2. Create a UIImage from the loaded data.
            guard let uiImage = UIImage(data: data) else {
                throw NSError(domain: "ImageClassifier", code: 2, userInfo: [NSLocalizedDescriptionKey: "Failed to create UIImage from loaded data."])
            }
            
            self.displayImage = uiImage // Update UI to show the selected image.
            
            // 3. Perform classification on a background thread to avoid blocking the UI.
            // The actual Vision request is synchronous on its calling thread, so it's
            // essential to move it off the main actor for responsiveness.
            await performClassification(image: uiImage)
            
        } catch {
            // Handle any errors during image loading or processing.
            errorMessage = "Failed to load image: \(error.localizedDescription)"
            isLoading = false
            classificationResult = "Error."
            print("Error processing image item: \(error)")
        }
    }
    
    /// Performs the actual Core ML classification using the Vision framework.
    ///
    /// This function uses `Task.detached` to ensure the Vision request runs on a background thread.
    /// The `VNCoreMLRequest`'s completion handler will then update the UI on the main actor.
    ///
    /// - Parameter image: The `UIImage` to classify.
    private func performClassification(image: UIImage) async {
        // Ensure the Core ML model and request are ready, and the image can be converted to CGImage.
        guard let classificationRequest = self.classificationRequest,
              let cgImage = image.cgImage else {
            // If prerequisites are not met, update UI with an error on the main actor.
            await MainActor.run {
                errorMessage = "Core ML model or image data not ready for classification."
                isLoading = false
                classificationResult = "Error."
            }
            return
        }
        
        // Use a detached Task to run the Vision request on a background thread.
        // This prevents the potentially long-running inference from blocking the main UI thread.
        Task.detached { [weak self] in
            // 1. Create a VNImageRequestHandler with the CGImage.
            // Vision handles the conversion from CGImage to CVPixelBuffer and other preprocessing.
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            do {
                // 2. Perform the classification request.
                try handler.perform([classificationRequest])
            } catch {
                // If the Vision request itself fails, update UI with error on the main actor.
                await MainActor.run {
                    self?.errorMessage = "Vision request failed: \(error.localizedDescription)"
                    self?.isLoading = false
                    self?.classificationResult = "Error."
                    print("Vision request error: \(error)")
                }
            }
        }
    }
    
    /// Handles the result of the `VNCoreMLRequest` once it completes.
    /// This method is called by the `VNCoreMLRequest`'s completion handler.
    ///
    /// This function is marked `@MainActor` because it directly updates properties
    /// that are observed by SwiftUI views, requiring main thread execution.
    ///
    /// - Parameters:
    ///   - request: The `VNRequest` that completed.
    ///   - error: An optional error if the request failed.
    @MainActor
    private func handleClassificationResult(request: VNRequest, error: Error?) {
        isLoading = false // Classification is complete, stop loading indicator.
        
        if let error = error {
            // If there was an error during classification, display it.
            errorMessage = "Classification failed: \(error.localizedDescription)"
            classificationResult = "Error."
            print("Classification error: \(error)")
            return
        }
        
        // 1. Extract classification observations from the request results.
        // Vision requests for classification return `VNClassificationObservation` objects.
        guard let observations = request.results as? [VNClassificationObservation] else {
            errorMessage = "No classification results found or unexpected result type."
            classificationResult = "Error."
            return
        }
        
        // 2. Sort observations by confidence in descending order and get the top one.
        // The `identifier` is the predicted label, and `confidence` is the probability.
        if let topClassification = observations.first { // Observations are usually sorted by confidence by default.
            // 3. Format the result for display: "Label (Confidence %)"
            classificationResult = "\(topClassification.identifier) (\(String(format: "%.2f", topClassification.confidence * 100))%)"
            errorMessage = nil // Clear any previous error if classification was successful.
            print("Classification successful: \(classificationResult)")
        } else {
            // If no classifications were found, provide a default message.
            classificationResult = "Could not classify image."
            errorMessage = nil
        }
    }
}

// MARK: - ContentView

/// The main SwiftUI view for the image classification application.
///
/// This view integrates `PhotosPicker` for image selection and displays the
/// classification results managed by `ImageClassifierViewModel`.
@available(iOS 18.0, *)
struct ContentView: View {
    
    /// The observable view model that manages the application's state and logic.
    /// `@State` is used here to own the view model's lifecycle within this view.
    /// Because `ImageClassifierViewModel` is `@Observable`, SwiftUI automatically
    /// observes its properties and re-renders the view when they change.
    @State private var viewModel = ImageClassifierViewModel()
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // MARK: - 1. Image Selection Button
                // PhotosPicker provides a system-standard way to select photos.
                PhotosPicker(selection: $viewModel.selectedImageItem, matching: .images) {
                    Label("Select Image", systemImage: "photo.on.rectangle.angled")
                        .font(.headline)
                        .padding()
                        .background(Color.accentColor)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.top)
                
                // MARK: - 2. Display Selected Image
                // Conditionally display the selected image or a placeholder.
                if let displayImage = viewModel.displayImage {
                    Image(uiImage: displayImage)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 300)
                        .cornerRadius(10)
                        .shadow(radius: 5)
                        .accessibilityLabel("Selected image for classification")
                } else {
                    Image(systemName: "photo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                        .foregroundColor(.gray)
                        .opacity(0.6)
                        .accessibilityLabel("No image selected icon")
                }
                
                // MARK: - 3. Loading Indicator
                // Show a progress view while classification is in progress.
                if viewModel.isLoading {
                    ProgressView("Classifying image...")
                        .progressViewStyle(.circular)
                        .padding()
                }
                
                // MARK: - 4. Display Classification Result
                // Show the classification result from the view model.
                Text(viewModel.classificationResult)
                    .font(.title2)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                    .accessibilityLabel("Classification result: \(viewModel.classificationResult)")
                
                // MARK: - 5. Display Error Message
                // Show any error messages in red.
                if let errorMessage = viewModel.errorMessage {
                    Text("Error: \(errorMessage)")
                        .foregroundColor(.red)
                        .font(.callout)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .accessibilityLabel("Error message: \(errorMessage)")
                }
                
                Spacer() // Pushes content to the top.
            }
            .navigationTitle("Core ML Image Classifier")
            .navigationBarTitleDisplayMode(.inline)
            .padding()
        }
    }
}

// MARK: - App Entry Point

/// The main entry point for the SwiftUI application.
/// This struct conforms to the `App` protocol and defines the app's structure.
@available(iOS 18.0, *)
@main
struct CoreMLVisionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView() // The main view of the application.
        }
    }
}
