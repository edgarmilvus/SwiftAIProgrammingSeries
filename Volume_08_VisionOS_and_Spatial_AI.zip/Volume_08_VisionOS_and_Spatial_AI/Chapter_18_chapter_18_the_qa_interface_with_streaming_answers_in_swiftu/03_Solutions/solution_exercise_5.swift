
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import Observation

struct Source: Identifiable, Hashable {
    let id: Int
    let title: String
    let snippet: String
}

struct Citation: Identifiable {
    let id = UUID()
    let sourceID: Int
    let range: Range<String.Index>
}

@Observable
@MainActor
class ResearchViewModel {
    var content: String = ""
    var sources: [Source] = [
        Source(id: 1, title: "Climate Report 2023", snippet: "Global temperatures are rising..."),
        Source(id: 2, title: "Oceanic Studies", snippet: "Sea levels have increased by...")
    ]
    var activeSourceID: Int? = nil
    
    func streamResponse() async {
        let rawStream = [
            "The earth is warming [1]. ",
            "Sea levels are rising [2]. ",
            "This is critical [1]."
        ]
        
        for chunk in rawStream {
            try? await Task.sleep(for: .milliseconds(800))
            content += chunk
        }
    }
}

struct CitationView: View {
    let text: String
    let sources: [Source]
    let onCitationTap: (Int) -> Void
    
    var body: some View {
        // In a production app, we would use AttributedString to make [n] clickable
        // Here we simulate the UI logic
        Text(text)
            .lineSpacing(4)
            .overlay(alignment: .topLeading) {
                // This is a simplified representation of how one would 
                // overlay clickable elements on a text stream.
            }
            .onTapGesture {
                // Simulated tap detection logic
                onCitationTap(1)
            }
    }
}

struct ResearchAssistantView: View {
    @State private var viewModel = ResearchViewModel()
    @State private var selectedSourceID: Int?

    var body: some View {
        NavigationStack {
            VStack {
                ScrollView {
                    CitationView(
                        text: viewModel.content,
                        sources: viewModel.sources,
                        onCitationTap: { id in
                            withAnimation { selectedSourceID = id }
                        }
                    )
                    .padding()
                }
                
                // Sources Drawer
                VStack(alignment: .leading) {
                    Text("Sources")
                        .font(.headline)
                        .padding(.horizontal)
                    
                    ScrollView {
                        ForEach(viewModel.sources) { source in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(source.title).font(.subheadline).bold()
                                    Text(source.snippet).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                if selectedSourceID == source.id {
                                    Image(systemName: "checkmark.circle.fill").foregroundColor(.blue)
                                }
                            }
                            .padding()
                            .background(selectedSourceID == source.id ? Color.blue.opacity(0.1) : Color.clear)
                            .cornerRadius(8)
                            .padding(.horizontal, 8)
                        }
                    }
                }
                .frame(height: 200)
                .background(.ultraThinMaterial)
            }
            .navigationTitle("Research AI")
            .task {
                await viewModel.streamResponse()
            }
            .sheet(isPresented: .constant(true)) {
                // This demonstrates the use of detents for the source drawer
                SourceDrawer(viewModel: viewModel, selectedID: $selectedSourceID)
            }
        }
    }
}

struct SourceDrawer: View {
    @Bindable var viewModel: ResearchViewModel
    @Binding var selectedID: Int?
    
    var body: some View {
        VStack {
            Capsule().frame(width: 40, height: 6).foregroundStyle(.secondary).padding(.top)
            List(viewModel.sources) { source in
                HStack {
                    VStack(alignment: .leading) {
                        Text(source.title).bold()
                        Text(source.snippet).font(.caption)
                    }
                }
                .listRowBackground(selectedID == source.id ? Color.blue.opacity(0.1) : Color.clear)
            }
        }
        .presentationDetents([.medium, .large])
    }
}
