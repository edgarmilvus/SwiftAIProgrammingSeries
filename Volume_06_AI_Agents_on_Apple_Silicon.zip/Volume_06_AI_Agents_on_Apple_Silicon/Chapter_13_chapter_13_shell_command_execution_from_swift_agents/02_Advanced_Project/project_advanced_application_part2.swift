
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation

// MARK: - 1. Error Definitions

/// Custom error type for shell command execution failures.
enum ShellCommandError: Error, LocalizedError {
    case commandNotFound(String)
    case executionFailed(command: String, exitCode: Int, stderr: String)
    case invalidOutput(command: String, output: String, reason: String)
    case encodingFailed(reason: String)
    case streamReadFailed(reason: String)
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .commandNotFound(let command):
            return "Command '\(command)' not found or not executable."
        case .executionFailed(let command, let exitCode, let stderr):
            return "Command '\(command)' failed with exit code \(exitCode). Error: \(stderr.trimmingCharacters(in: .whitespacesAndNewlines))"
        case .invalidOutput(let command, _, let reason):
            return "Failed to parse output for command '\(command)': \(reason)"
        case .encodingFailed(let reason):
            return "Failed to encode data: \(reason)"
        case .streamReadFailed(let reason):
            return "Failed to read from stream: \(reason)"
        case .unknown(let error):
            return "An unknown error occurred: \(error.localizedDescription)"
        }
    }
}

// MARK: - 2. Data Models for Ollama and System Resources

/// Represents an Ollama model.
struct OllamaModel: Codable, Identifiable {
    let name: String
    let modifiedAt: Date
    let size: Int64
    let digest: String
    let details: Details

    var id: String { name }

    struct Details: Codable {
        let parentModel: String?
        let format: String
        let family: String
        let families: [String]?
        let parameterSize: String
        let quantizationLevel: String
    }
}

/// Represents system resource usage.
struct SystemResources: Codable {
    let cpuUsagePercentage: Double
    let memoryUsageGB: Double
    let totalMemoryGB: Double
    let gpuInfo: String // Simplified for this example, could be a more complex struct
    let freeDiskSpaceGB: Double
}

// MARK: - 3. Utility for Shell Command Execution

/// A utility class for safely executing shell commands asynchronously.
/// This class handles process creation, input/output redirection, and error reporting.
@available(macOS 13.0, iOS 16.0, *) // Process.run() and async APIs require macOS 13+, iOS 16+
actor ShellCommandExecutor {

    /// Executes a shell command and captures its standard output and error.
    /// - Parameters:
    ///   - command: The path to the executable command (e.g., "/usr/bin/env").
    ///   - arguments: An array of string arguments for the command.
    ///   - environment: Optional dictionary of environment variables to set for the process.
    /// - Returns: A tuple containing the standard output string and the exit code.
    /// - Throws: `ShellCommandError` if the command fails to execute or returns a non-zero exit code.
    func execute(command: String, arguments: [String], environment: [String: String]? = nil) async throws -> (stdout: String, stderr: String, exitCode: Int) {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: command)
        process.arguments = arguments

        // Set environment variables if provided, otherwise inherit from current process
        if let environment = environment {
            process.environment = environment
        } else {
            process.environment = ProcessInfo.processInfo.environment
        }

        let outputPipe = Pipe()
        let errorPipe = Pipe()
        process.standardOutput = outputPipe
        process.standardError = errorPipe

        // FileHandle for reading output asynchronously
        let outputHandle = outputPipe.fileHandleForReading
        let errorHandle = errorPipe.fileHandleForReading

        var stdoutData = Data()
        var stderrData = Data()

        // Asynchronously read stdout and stderr
        let stdoutTask = Task {
            for try await data in outputHandle.bytes {
                stdoutData.append(data)
            }
        }

        let stderrTask = Task {
            for try await data in errorHandle.bytes {
                stderrData.append(data)
            }
        }

        do {
            // Start the process
            try process.run()

            // Wait for both output streams to finish reading
            _ = await stdoutTask.result
            _ = await stderrTask.result

            // Wait for the process to exit
            process.waitUntilExit()

            guard let stdout = String(data: stdoutData, encoding: .utf8) else {
                throw ShellCommandError.encodingFailed(reason: "Failed to decode stdout to UTF-8")
            }
            guard let stderr = String(data: stderrData, encoding: .utf8) else {
                throw ShellCommandError.encodingFailed(reason: "Failed to decode stderr to UTF-8")
            }

            let exitCode = Int(process.terminationStatus)

            guard exitCode == 0 else {
                throw ShellCommandError.executionFailed(command: command, exitCode: exitCode, stderr: stderr)
            }

            return (stdout, stderr, exitCode)

        } catch let error as ShellCommandError {
            throw error // Re-throw our custom errors
        } catch {
            // Check for common process errors
            if let posixError = error as? POSIXError, posixError.code == .EACCES || posixError.code == .ENOENT {
                throw ShellCommandError.commandNotFound(command)
            }
            throw ShellCommandError.unknown(error)
        }
    }

    /// Executes a shell command and streams its standard output and error.
    /// This is particularly useful for long-running commands that provide progress updates.
    /// - Parameters:
    ///   - command: The path to the executable command.
    ///   - arguments: An array of string arguments.
    ///   - environment: Optional dictionary of environment variables.
    /// - Returns: An `AsyncThrowingStream` that yields `(stdoutLine: String?, stderrLine: String?)` for each line.
    /// - Throws: `ShellCommandError` if the process fails to start.
    func executeStreaming(command: String, arguments: [String], environment: [String: String]? = nil) -> AsyncThrowingStream<(stdoutLine: String?, stderrLine: String?), Error> {
        return AsyncThrowingStream { continuation in
            let process = Process()
            process.executableURL = URL(fileURLWithPath: command)
            process.arguments = arguments
            process.environment = environment ?? ProcessInfo.processInfo.environment

            let outputPipe = Pipe()
            let errorPipe = Pipe()
            process.standardOutput = outputPipe
            process.standardError = errorPipe

            let outputHandle = outputPipe.fileHandleForReading
            let errorHandle = errorPipe.fileHandleForReading

            let stdoutTask = Task {
                for try await byte in outputHandle.bytes.lines {
                    continuation.yield((stdoutLine: byte, stderrLine: nil))
                }
            }

            let stderrTask = Task {
                for try await byte in errorHandle.bytes.lines {
                    continuation.yield((stdoutLine: nil, stderrLine: byte))
                }
            }

            Task {
                do {
                    try process.run()
                    process.waitUntilExit() // Wait for termination

                    // Ensure all output is processed before ending
                    _ = await stdoutTask.result
                    _ = await stderrTask.result

                    let exitCode = Int(process.terminationStatus)
                    if exitCode != 0 {
                        // Collect any remaining stderr for the error message
                        let remainingStderr = String(data: errorHandle.readDataToEndOfFile(), encoding: .utf8) ?? ""
                        continuation.finish(throwing: ShellCommandError.executionFailed(command: command, exitCode: exitCode, stderr: remainingStderr))
                    } else {
                        continuation.finish()
                    }
                } catch {
                    if let posixError = error as? POSIXError, posixError.code == .EACCES || posixError.code == .ENOENT {
                        continuation.finish(throwing: ShellCommandError.commandNotFound(command))
                    } else {
                        continuation.finish(throwing: ShellCommandError.unknown(error))
                    }
                }
            }
        }
    }

    /// Finds the full path to a command using the system's PATH environment variable.
    /// - Parameter commandName: The name of the command (e.g., "ollama").
    /// - Returns: The full path to the command, or `nil` if not found.
    func findCommandPath(commandName: String) -> String? {
        guard let path = ProcessInfo.processInfo.environment["PATH"] else { return nil }
        let pathComponents = path.split(separator: ":").map(String.init)

        for component in pathComponents {
            let potentialPath = URL(fileURLWithPath: component).appendingPathComponent(commandName).path
            if FileManager.default.isExecutableFile(atPath: potentialPath) {
                return potentialPath
            }
        }
        return nil
    }
}


// MARK: - 4. LocalLLMResourceManager: The AI Agent Component

/// Manages local LLM resources using the Ollama CLI and provides system insights.
/// This class acts as the AI agent's interface to system-level operations.
@available(macOS 13.0, iOS 16.0, *)
class LocalLLMResourceManager {
    private let shellExecutor: ShellCommandExecutor
    private var ollamaPath: String?

    init(shellExecutor: ShellCommandExecutor = ShellCommandExecutor()) {
        self.shellExecutor = shellExecutor
        // Attempt to find ollama path on initialization
        Task {
            self.ollamaPath = await shellExecutor.findCommandPath(commandName: "ollama")
        }
    }

    /// Verifies if the Ollama CLI tool is installed and accessible.
    /// - Returns: `true` if Ollama is found, `false` otherwise.
    func isOllamaInstalled() async -> Bool {
        if ollamaPath == nil {
            ollamaPath = await shellExecutor.findCommandPath(commandName: "ollama")
        }
        return ollamaPath != nil
    }

    /// Retrieves a list of installed Ollama models.
    /// - Returns: An array of `OllamaModel` objects.
    /// - Throws: `ShellCommandError` if Ollama is not found, execution fails, or output parsing fails.
    func listOllamaModels() async throws -> [OllamaModel] {
        guard let ollamaPath = await self.ollamaPath else {
            throw ShellCommandError.commandNotFound("ollama")
        }

        let (stdout, _, _) = try await shellExecutor.execute(command: ollamaPath, arguments: ["list", "--json"])

        guard let data = stdout.data(using: .utf8) else {
            throw ShellCommandError.encodingFailed(reason: "Failed to convert stdout to Data for JSON parsing.")
        }

        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601 // Ollama uses ISO 8601 for dates
        decoder.keyDecodingStrategy = .convertFromSnakeCase // Handle `modified_at` etc.

        do {
            let response = try decoder.decode([String: [OllamaModel]].self, from: data)
            guard let models = response["models"] else {
                throw ShellCommandError.invalidOutput(command: "ollama list", output: stdout, reason: "Missing 'models' key in JSON response.")
            }
            return models
        } catch {
            throw ShellCommandError.invalidOutput(command: "ollama list", output: stdout, reason: "JSON decoding failed: \(error.localizedDescription)")
        }
    }

    /// Initiates a download (pull) for an Ollama model and streams its progress.
    /// - Parameter modelName: The name of the model to download (e.g., "llama2").
    /// - Returns: An `AsyncThrowingStream` that yields progress messages (lines from stderr).
    /// - Throws: `ShellCommandError` if Ollama is not found or the pull command fails to start.
    func downloadOllamaModel(modelName: String) async throws -> AsyncThrowingStream<String, Error> {
        guard let ollamaPath = await self.ollamaPath else {
            throw ShellCommandError.commandNotFound("ollama")
        }

        let stream = shellExecutor.executeStreaming(command: ollamaPath, arguments: ["pull", modelName])

        return AsyncThrowingStream { continuation in
            Task {
                do {
                    for try await (stdoutLine, stderrLine) in stream {
                        // Ollama pull sends progress to stderr
                        if let line = stderrLine, !line.isEmpty {
                            continuation.yield(line)
                        } else if let line = stdoutLine, !line.isEmpty {
                            // Occasionally stdout might have some info too
                            continuation.yield(line)
                        }
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
        }
    }

    /// Retrieves system resource usage (CPU, Memory, Disk, GPU).
    /// This uses standard Unix commands (`sysctl`, `ps`, `df`) to gather information.
    /// - Returns: A `SystemResources` struct containing the gathered information.
    /// - Throws: `ShellCommandError` if any command fails or parsing is unsuccessful.
    func getSystemResourceUsage() async throws -> SystemResources {
        let cpuUsageTask = Task { try await getCPUUsage() }
        let memoryUsageTask = Task { try await getMemoryUsage() }
        let diskUsageTask = Task { try await getFreeDiskSpace() }
        let gpuInfoTask = Task { await getGPUInfo() } // This is best-effort and might not throw

        let cpuUsage = try await cpuUsageTask.value
        let (memoryUsageGB, totalMemoryGB) = try await memoryUsageTask.value
        let freeDiskSpaceGB = try await diskUsageTask.value
        let gpuInfo = await gpuInfoTask.value

        return SystemResources(
            cpuUsagePercentage: cpuUsage,
            memoryUsageGB: memoryUsageGB,
            totalMemoryGB: totalMemoryGB,
            gpuInfo: gpuInfo,
            freeDiskSpaceGB: freeDiskSpaceGB
        )
    }

    /// Helper to get CPU usage percentage.
    private func getCPUUsage() async throws -> Double {
        // Using 'sysctl -n kern.cp_time' and 'sysctl -n kern.cpu_time' for more detailed,
        // but often 'ps -eo %cpu' combined with averaging is simpler for a quick overview.
        // For a simple percentage, we'll use 'ps' and average the top processes.
        // This is a simplified approach; a more accurate one involves reading /proc/stat on Linux
        // or mach_host_self() on macOS.
        let (stdout, _, _) = try await shellExecutor.execute(command: "/bin/ps", arguments: ["-eo", "%cpu"])
        let lines = stdout.split(separator: "\n").dropFirst() // Drop header
        let totalCPU = lines.compactMap { Double($0.trimmingCharacters(in: .whitespacesAndNewlines)) }.reduce(0, +)
        return min(totalCPU, 100.0) // Cap at 100%
    }

    /// Helper to get memory usage in GB.
    private func getMemoryUsage() async throws -> (usedGB: Double, totalGB: Double) {
        // Using 'sysctl -n hw.memsize' for total memory and 'vm_stat' (or 'sysctl -n vm.stats.vm.v_active_count')
        // for active memory. For simplicity, we'll use 'sysctl' for total and calculate used.
        let (totalMemStr, _, _) = try await shellExecutor.execute(command: "/usr/sbin/sysctl", arguments: ["-n", "hw.memsize"])
        guard let totalMemBytes = Int64(totalMemStr.trimmingCharacters(in: .whitespacesAndNewlines)) else {
            throw ShellCommandError.invalidOutput(command: "sysctl hw.memsize", output: totalMemStr, reason: "Invalid total memory format.")
        }
        let totalMemGB = Double(totalMemBytes) / (1024 * 1024 * 1024)

        // Get free memory from vm_stat (macOS specific)
        let (vmStatOutput, _, _) = try await shellExecutor.execute(command: "/usr/bin/vm_stat", arguments: [])
        let pagesize = 4096.0 // macOS page size
        var freePages: Double = 0
        for line in vmStatOutput.split(separator: "\n") {
            if line.contains("Pages free:") {
                let components = line.split(separator: ":").map { $0.trimmingCharacters(in: .whitespaces) }
                if components.count == 2, let pages = Double(components[1]) {
                    freePages = pages
                    break
                }
            }
        }

        let freeMemGB = (freePages * pagesize) / (1024 * 1024 * 1024)
        let usedMemGB = totalMemGB - freeMemGB
        return (usedMemGB, totalMemGB)
    }

    /// Helper to get free disk space in GB.
    private func getFreeDiskSpace() async throws -> Double {
        let (stdout, _, _) = try await shellExecutor.execute(command: "/bin/df", arguments: ["-h", "/"])
        let lines = stdout.split(separator: "\n")
        guard lines.count > 1 else {
            throw ShellCommandError.invalidOutput(command: "df", output: stdout, reason: "Unexpected output format for df.")
        }
        let lastLine = String(lines.last ?? "")
        let components = lastLine.split(separator: " ").compactMap { String($0) }.filter { !$0.isEmpty }

        // Expected format: Filesystem Size Used Avail Capacity iused ifree %iused Mounted_on
        // We need the 'Avail' column, which is usually the 4th non-empty component (index 3)
        guard components.count >= 4, let availString = components[3].replacingOccurrences(of: "G", with: "") as? String else {
             throw ShellCommandError.invalidOutput(command: "df", output: stdout, reason: "Could not parse available disk space.")
        }

        // Handle 'T' for Terabytes, 'M' for Megabytes if needed. For simplicity, assume GB.
        if availString.hasSuffix("T") {
            if let value = Double(availString.dropLast()) { return value * 1024 }
        } else if availString.hasSuffix("M") {
            if let value = Double(availString.dropLast()) { return value / 1024 }
        } else if let value = Double(availString) {
            return value
        }
        throw ShellCommandError.invalidOutput(command: "df", output: stdout, reason: "Could not parse available disk space value.")
    }

    /// Helper to get GPU information. This is highly system-dependent.
    /// On macOS, `system_profiler SPDisplaysDataType` can provide details.
    private func getGPUInfo() async -> String {
        do {
            let (stdout, _, _) = try await shellExecutor.execute(command: "/usr/sbin/system_profiler", arguments: ["SPDisplaysDataType"])
            // Parse for relevant GPU info, e.g., "Chipset Model:", "VRAM (Total):"
            let lines = stdout.split(separator: "\n")
            var gpuDetails: [String] = []
            for line in lines {
                if line.contains("Chipset Model:") || line.contains("VRAM (Total):") {
                    gpuDetails.append(line.trimmingCharacters(in: .whitespaces))
                }
            }
            return gpuDetails.isEmpty ? "N/A" : gpuDetails.joined(separator: "; ")
        } catch {
            return "Error retrieving GPU info: \(error.localizedDescription)"
        }
    }
}

// MARK: - 5. Example Usage in an App Context

/// This would typically be part of a ViewModel or an ApplicationDelegate in a real app.
@available(macOS 13.0, iOS 16.0, *)
class LocalAIAppViewModel: ObservableObject {
    private let resourceManager = LocalLLMResourceManager()

    @Published var ollamaStatus: String = "Checking Ollama..."
    @Published var installedModels: [OllamaModel] = []
    @Published var downloadProgress: String = ""
    @Published var systemResources: SystemResources?
    @Published var errorMessage: String?

    func setupAgent() {
        Task {
            await checkOllamaInstallation()
            await loadInstalledModels()
            await refreshSystemResources()
        }
    }

    @MainActor
    private func checkOllamaInstallation() async {
        do {
            if await resourceManager.isOllamaInstalled() {
                ollamaStatus = "Ollama is installed and ready."
            } else {
                ollamaStatus = "Ollama not found. Please install it from ollama.com"
                errorMessage = "Ollama CLI tool not found."
            }
        }
    }

    @MainActor
    func loadInstalledModels() async {
        do {
            self.installedModels = try await resourceManager.listOllamaModels()
            errorMessage = nil
        } catch {
            errorMessage = "Failed to load Ollama models: \(error.localizedDescription)"
            self.installedModels = []
        }
    }

    @MainActor
    func downloadModel(name: String) async {
        downloadProgress = "Starting download for \(name)..."
        errorMessage = nil
        do {
            let stream = try await resourceManager.downloadOllamaModel(modelName: name)
            for try await line in stream {
                // Update UI with progress. In a real app, parse for percentage.
                downloadProgress = line
            }
            downloadProgress = "Download of \(name) complete!"
            await loadInstalledModels() // Refresh list after download
        } catch {
            errorMessage = "Failed to download \(name): \(error.localizedDescription)"
            downloadProgress = "Download failed."
        }
    }

    @MainActor
    func refreshSystemResources() async {
        do {
            self.systemResources = try await resourceManager.getSystemResourceUsage()
            errorMessage = nil
        } catch {
            errorMessage = "Failed to get system resources: \(error.localizedDescription)"
            self.systemResources = nil
        }
    }
}

// Example of how you might instantiate and use it (e.g., in a SwiftUI App struct)
/*
@main
struct LocalAIApp: App {
    @StateObject private var viewModel = LocalAIAppViewModel()

    init() {
        // Start agent setup when the app launches
        viewModel.setupAgent()
    }

    var body: some Scene {
        WindowGroup {
            // Your SwiftUI content, using viewModel.ollamaStatus, viewModel.installedModels, etc.
            VStack {
                Text(viewModel.ollamaStatus)
                if let resources = viewModel.systemResources {
                    Text("CPU: \(resources.cpuUsagePercentage, specifier: "%.1f")%")
                    Text("Memory: \(resources.memoryUsageGB, specifier: "%.2f")GB / \(resources.totalMemoryGB, specifier: "%.2f")GB")
                    Text("Disk Free: \(resources.freeDiskSpaceGB, specifier: "%.2f")GB")
                    Text("GPU: \(resources.gpuInfo)")
                }
                if let error = viewModel.errorMessage {
                    Text("Error: \(error)").foregroundColor(.red)
                }
                Button("Refresh Models") {
                    Task { await viewModel.loadInstalledModels() }
                }
                Button("Download Llama2") {
                    Task { await viewModel.downloadModel(name: "llama2") }
                }
                Text("Download Progress: \(viewModel.downloadProgress)")
            }
        }
    }
}
*/
