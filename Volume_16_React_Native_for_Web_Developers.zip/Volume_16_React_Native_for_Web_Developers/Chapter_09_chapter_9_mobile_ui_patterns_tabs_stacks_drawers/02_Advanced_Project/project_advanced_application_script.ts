/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Advanced Mobile UI Patterns Script
 * 
 * This script demonstrates a SaaS Dashboard application structure using
 * React Navigation patterns (Tabs, Stacks, Drawers). It is designed to
 * run in a Next.js environment but mimics the Expo/React Native architecture
 * for universal app development.
 * 
 * Key Concepts:
 * 1. TabNavigator: Top-level access to core features (Dashboard, Projects).
 * 2. StackNavigator: Hierarchical navigation for Project Details (push/pop).
 * 3. DrawerNavigator: Contextual overlay for Settings and Support Chat.
 * 4. useChat Integration: Headless AI inference within the Drawer context.
 */

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, TextInput, ScrollView } from 'react-native';

// --- MOCK IMPORTS FOR NEXT.JS ENVIRONMENT ---
// In a real Expo project, these would be actual React Navigation imports.
// For this script, we define interfaces to represent the navigation structure.

interface NavigationProps {
  navigation: any;
  route: any;
}

// --- DATA MODELS ---

type Project = {
  id: string;
  title: string;
  status: 'Active' | 'Completed';
  description: string;
};

// --- STATE MANAGEMENT & HEADLESS INFERENCE MOCK ---

/**
 * Simulates the Vercel AI SDK `useChat` hook.
 * Manages message history and streams responses.
 * In a real app, this would hook into an API route.
 */
const useMockChat = () => {
  const [messages, setMessages] = useState([
    { role: 'system', content: 'You are a helpful SaaS assistant.' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;
    
    // Add user message
    const userMsg = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    // Simulate Headless Inference (Server-side processing)
    setTimeout(() => {
      const response = { role: 'assistant', content: "I've analyzed your request. Based on your project status, I recommend updating the billing settings." };
      setMessages(prev => [...prev, response]);
      setIsLoading(false);
    }, 1500);
  };

  return { messages, input, setInput, sendMessage, isLoading };
};

// --- UI COMPONENTS ---

/**
 * Dashboard Screen (Tab 1)
 * Displays high-level metrics.
 */
const DashboardScreen = ({ navigation }: NavigationProps) => {
  return (
    <View className="flex-1 bg-gray-50 p-4">
      <Text className="text-2xl font-bold text-gray-800 mb-4">SaaS Dashboard</Text>
      <View className="bg-white p-4 rounded-lg shadow-sm mb-4">
        <Text className="text-sm text-gray-500">Total Revenue</Text>
        <Text className="text-3xl font-bold text-green-600">$12,450</Text>
      </View>
      <TouchableOpacity 
        onPress={() => navigation.navigate('Projects')}
        className="bg-blue-600 py-3 rounded-lg items-center mt-4"
      >
        <Text className="text-white font-semibold">View Projects</Text>
      </TouchableOpacity>
    </View>
  );
};

/**
 * Projects List Screen (Tab 2)
 * Displays a list of projects. Uses FlatList for performance.
 */
const ProjectsScreen = ({ navigation }: NavigationProps) => {
  const [projects] = useState<Project[]>([
    { id: '1', title: 'Mobile App Redesign', status: 'Active', description: 'Overhaul the UI for iOS and Android.' },
    { id: '2', title: 'Backend Migration', status: 'Completed', description: 'Move from Heroku to AWS.' },
    { id: '3', title: 'Marketing Campaign', status: 'Active', description: 'Q4 Social Media Push.' },
  ]);

  const renderItem = ({ item }: { item: Project }) => (
    <TouchableOpacity 
      onPress={() => navigation.navigate('ProjectDetails', { project: item })}
      className="bg-white p-4 mb-3 rounded-lg border border-gray-200 flex-row justify-between items-center"
    >
      <View>
        <Text className="font-semibold text-gray-800">{item.title}</Text>
        <Text className={`text-xs mt-1 ${item.status === 'Active' ? 'text-blue-600' : 'text-green-600'}`}>
          {item.status}
        </Text>
      </View>
      <Text className="text-gray-400">›</Text>
    </TouchableOpacity>
  );

  return (
    <View className="flex-1 bg-gray-50 p-4">
      <Text className="text-2xl font-bold text-gray-800 mb-4">Projects</Text>
      <FlatList 
        data={projects}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

/**
 * Project Details Screen (Stack)
 * Hierarchical child of Projects. Includes a button to open the Drawer.
 */
const ProjectDetailsScreen = ({ route, navigation }: NavigationProps) => {
  const { project } = route.params as { project: Project };

  return (
    <View className="flex-1 bg-white p-6">
      <Text className="text-3xl font-bold text-gray-900 mb-2">{project.title}</Text>
      <View className="mb-6">
        <Text className="text-gray-500 mb-2">Status: {project.status}</Text>
        <Text className="text-gray-700 leading-relaxed">{project.description}</Text>
      </View>
      
      <View className="border-t border-gray-100 pt-4 mt-4">
        <Text className="text-sm font-semibold text-gray-500 mb-2">ACTIONS</Text>
        <TouchableOpacity 
          onPress={() => navigation.openDrawer()} // Triggers the Drawer Navigator
          className="bg-purple-600 py-3 rounded-lg items-center"
        >
          <Text className="text-white font-semibold">Open Support Chat (Drawer)</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

/**
 * Settings Screen (Drawer Item)
 * Accessible via the Drawer Navigator.
 */
const SettingsScreen = () => {
  return (
    <View className="flex-1 bg-gray-50 p-6">
      <Text className="text-2xl font-bold text-gray-800 mb-6">Account Settings</Text>
      <View className="bg-white p-4 rounded-lg shadow-sm">
        <Text className="font-semibold mb-2">Notification Preferences</Text>
        <View className="flex-row items-center justify-between mb-4">
          <Text className="text-gray-600">Email Alerts</Text>
          <View className="w-12 h-6 bg-green-500 rounded-full" />
        </View>
        <View className="flex-row items-center justify-between">
          <Text className="text-gray-600">Push Notifications</Text>
          <View className="w-12 h-6 bg-gray-300 rounded-full" />
        </View>
      </View>
    </View>
  );
};

/**
 * Support Chat Screen (Drawer Item)
 * Integrates the `useMockChat` hook (Headless Inference).
 */
const SupportChatScreen = () => {
  const { messages, input, setInput, sendMessage, isLoading } = useMockChat();

  return (
    <View className="flex-1 bg-white">
      {/* Message List */}
      <ScrollView className="flex-1 p-4" contentContainerStyle={{ paddingBottom: 20 }}>
        {messages.map((msg, index) => (
          <View 
            key={index} 
            className={`p-3 mb-2 rounded-lg max-w-[80%] ${
              msg.role === 'user' 
                ? 'self-end bg-blue-600 text-white' 
                : 'self-start bg-gray-100 text-gray-800'
            }`}
          >
            <Text>{msg.content}</Text>
          </View>
        ))}
        {isLoading && (
          <Text className="text-gray-400 text-sm italic mt-2">AI is thinking...</Text>
        )}
      </ScrollView>

      {/* Input Area */}
      <View className="border-t border-gray-200 p-4 bg-gray-50">
        <View className="flex-row gap-2">
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder="Ask about your account..."
            className="flex-1 bg-white border border-gray-300 rounded-lg px-4 py-2"
          />
          <TouchableOpacity 
            onPress={sendMessage}
            disabled={isLoading}
            className="bg-blue-600 px-4 rounded-lg justify-center"
          >
            <Text className="text-white font-semibold">Send</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

// --- NAVIGATION CONTROLLERS (SIMULATED) ---

/**
 * Main App Component
 * Simulates the composition of Navigators.
 * In Expo, this would be defined in `app/_layout.tsx` or `App.tsx`.
 */
export default function SaaSApp() {
  // Simulating the active route state for the purpose of this script
  const [activeRoute, setActiveRoute] = useState('Dashboard');
  const [showDrawer, setShowDrawer] = useState(false);
  
  // Mock Navigation Object
  const mockNavigation = {
    navigate: (screen: string, params?: any) => {
      console.log(`Navigating to: ${screen}`, params || '');
      // Logic to switch screens would go here in a real app
    },
    openDrawer: () => setShowDrawer(true),
    closeDrawer: () => setShowDrawer(false),
  };

  // Helper to render current screen based on state
  const renderScreen = () => {
    if (activeRoute === 'Dashboard') return <DashboardScreen navigation={mockNavigation} route={{}} />;
    if (activeRoute === 'Projects') return <ProjectsScreen navigation={mockNavigation} route={{}} />;
    if (activeRoute === 'Settings') return <SettingsScreen />;
    if (activeRoute === 'Support') return <SupportChatScreen />;
    return <View><Text>Screen not found</Text></View>;
  };

  return (
    <View className="flex-1 bg-gray-100">
      {/* Main Content Area (Simulates Tab/Stack Container) */}
      <View className="flex-1">
        {renderScreen()}
      </View>

      {/* Bottom Tab Bar (Simulates TabNavigator) */}
      <View className="bg-white border-t border-gray-200 flex-row justify-around py-3 safe-area-bottom">
        {['Dashboard', 'Projects'].map((tab) => (
          <TouchableOpacity 
            key={tab} 
            onPress={() => {
              setActiveRoute(tab);
              setShowDrawer(false);
            }}
            className={`items-center px-4 ${activeRoute === tab ? 'text-blue-600' : 'text-gray-400'}`}
          >
            <Text className={`font-semibold ${activeRoute === tab ? 'text-blue-600' : 'text-gray-400'}`}>
              {tab}
            </Text>
          </TouchableOpacity>
        ))}
        {/* Drawer Trigger Button in Tab Bar */}
        <TouchableOpacity 
          onPress={() => setShowDrawer(true)}
          className="items-center px-4 text-purple-600"
        >
          <Text className="text-purple-600 font-semibold">Menu</Text>
        </TouchableOpacity>
      </View>

      {/* Drawer Overlay (Simulates DrawerNavigator) */}
      {showDrawer && (
        <View className="absolute inset-0 bg-black/50 z-10">
          <View className="absolute right-0 top-0 bottom-0 w-3/4 bg-white shadow-xl p-6">
            <View className="flex-row justify-between items-center mb-8">
              <Text className="text-xl font-bold">Menu</Text>
              <TouchableOpacity onPress={() => setShowDrawer(false)}>
                <Text className="text-gray-500 text-lg">✕</Text>
              </TouchableOpacity>
            </View>
            
            <View className="space-y-4">
              <TouchableOpacity 
                onPress={() => { setActiveRoute('Settings'); setShowDrawer(false); }}
                className="p-3 bg-gray-50 rounded-lg"
              >
                <Text className="text-lg font-semibold">Settings</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                onPress={() => { setActiveRoute('Support'); setShowDrawer(false); }}
                className="p-3 bg-purple-50 rounded-lg border border-purple-100"
              >
                <Text className="text-lg font-semibold text-purple-700">Support Chat (AI)</Text>
                <Text className="text-sm text-purple-500">Powered by Headless Inference</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    </View>
  );
}
