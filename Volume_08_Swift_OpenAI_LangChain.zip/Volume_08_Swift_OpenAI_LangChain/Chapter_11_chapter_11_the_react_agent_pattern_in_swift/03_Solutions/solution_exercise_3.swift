
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 18.0, *)
enum FinanceError: Error, LocalizedError {
    case accountNotFound(String)
    case insufficientFunds(required: Double)
    
    var errorDescription: String? {
        switch self {
        case .accountNotFound(let id): return "Error: Account ID '\(id)' not found."
        case .insufficientFunds(let amt): return "Error: Insufficient funds. Required: $\(amt)."
        }
    }
}

@available(iOS 18.0, *)
struct FinanceTool: Tool {
    let name = "transfer_funds"
    let description = "Transfers money. Requires 'from_id', 'to_id', and 'amount'."

    func execute(arguments: [String: AnySendable]) async throws -> String {
        guard let from = arguments["from_id"]?.asString(),
              let to = arguments["to_id"]?.asString(),
              let amount = arguments["amount"]?.asString().flatMap({ Double($0) }) else {
            throw ToolError.missingArgument("from_id, to_id, or amount")
        }

        // Simulate a failure for a specific "guessed" ID
        if from == "savings_123" {
            throw FinanceError.accountNotFound("savings_123")
        }
        
        if amount > 1000 {
            throw FinanceError.insufficientFunds(required: amount)
        }

        return "Success: Transferred $\(amount) from \(from) to \(to)."
    }
}

@available(iOS 18.0, *)
actor AgentLoop {
    private var history: [String] = []
    private let tool = FinanceTool()
    
    func run(userPrompt: String) async -> String {
        history.append("User: \(userPrompt)")
        history.append("System: If an observation contains an error, use that information to correct your next action.")
        
        // Step 1: Agent "guesses" an ID (Simulating LLM reasoning)
        // In a real loop, this would be a call to the LLM.
        let attempt1Args: [String: AnySendable] = [
            "from_id": AnySendable("savings_123"), 
            "to_id": AnySendable("checking_456"),
            "amount": AnySendable("50.0")
        ]
        
        return await executeStep(args: attempt1Args)
    }
    
    private func executeStep(args: [String: AnySendable]) async -> String {
        do {
            let result = try await tool.execute(arguments: args)
            history.append("Observation: \(result)")
            return result
        } catch {
            // THE KEY: Catch the error and convert it to an Observation
            let errorMsg = error.localizedDescription
            history.append("Observation: \(errorMsg)")
            
            print("🔄 Agent received error observation: \(errorMsg)")
            print("🔄 Agent is now re-thinking based on the error...")
            
            // Step 2: Agent "corrects" itself (Simulating LLM seeing the error)
            let correctedArgs: [String: AnySendable] = [
                "from_id": AnySendable("savings_999"), // The "correct" ID found via error
                "to_id": AnySendable("checking_456"),
                "amount": AnySendable("50.0")
            ]
            return await executeStep(args: correctedArgs)
        }
    }
}

// --- Test Case ---
@main
struct FinanceTest {
    static func main() async {
        let loop = AgentLoop()
        let finalResult = await loop.run(userPrompt: "Transfer $50 from my savings to my checking.")
        print("🏁 Final Result: \(finalResult)")
    }
}
