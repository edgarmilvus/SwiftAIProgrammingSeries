
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import NaturalLanguage

// Main app entry point (for a complete SwiftUI app)
@main
struct DocumentAnalyzerApp: App {
    var body: some Scene {
        WindowGroup {
            DocumentLanguageAnalyzerView()
        }
    }
}

struct DocumentLanguageAnalyzerView: View {
    // A long, mixed-language document string
    let documentText: String = """
    The Natural Language framework in iOS and macOS provides powerful on-device capabilities for understanding text. It can detect languages, tokenize text, tag parts of speech, and even perform sentiment analysis. This introduction focuses on language detection.

    Die Verarbeitung natürlicher Sprache (NLP) ist ein Teilgebiet der künstlichen Intelligenz, das sich mit der Interaktion zwischen Computern und menschlicher Sprache befasst. Es ermöglicht Computern, menschliche Sprache zu verstehen, zu interpretieren und zu generieren.

    El reconocimiento de idiomas es una de las características más fundamentales de este framework. Permite a las aplicaciones identificar el idioma principal de un texto, lo cual es útil para la localización, la traducción automática o la categorización de contenido.

    Bonjour à tous! J'espère que vous appréciez ces exercices pratiques. La détection de la langue est une étape cruciale pour de nombreuses applications multilingues.

    このフレームワークは、テキストを分析し、その言語を特定するための効率的な方法を提供します。これにより、開発者は国際的なユーザーベースに対応するアプリケーションを簡単に構築できます。
    """

    @State private var summary: [NLLanguage: Int] = [:]
    @State private var totalDeterminedSegments: Int = 0
    @State private var undeterminedSegments: Int = 0
    @State private var segmentedDocument: [String] = []

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 15) {
                Text("Document Language Summary")
                    .font(.largeTitle)
                    .padding(.bottom, 5)

                Text("Original Document (first 200 chars):")
                    .font(.headline)
                Text(documentText.prefix(200) + "...")
                    .font(.body)
                    .foregroundColor(.secondary)
                    .padding(.bottom, 10)

                Divider()

                Text("Language Distribution:")
                    .font(.title2)

                if summary.isEmpty && undeterminedSegments == 0 {
                    ProgressView("Analyzing document...")
                } else {
                    ForEach(summary.keys.sorted { languageDisplayName($0) < languageDisplayName($1) }, id: \.self) { language in
                        HStack {
                            Text(languageDisplayName(language))
                                .font(.headline)
                            Spacer()
                            Text("\(summary[language] ?? 0) segments (\(String(format: "%.1f%%", percentage(for: language))))")
                                .font(.body)
                        }
                    }
                    if undeterminedSegments > 0 {
                        HStack {
                            Text("Undetermined")
                                .font(.headline)
                            Spacer()
                            Text("\(undeterminedSegments) segments")
                                .font(.body)
                        }
                    }
                }
                Spacer()
            }
            .padding()
            .navigationTitle("Document Analysis")
        }
        .onAppear {
            analyzeDocument()
        }
    }

    // Helper to segment text using NLTokenizer
    private func segmentText(text: String, unit: NLTokenUnit) -> [String] {
        let tokenizer = NLTokenizer(unit: unit)
        tokenizer.string = text
        var segments: [String] = []
        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
            segments.append(String(text[tokenRange]))
            return true
        }
        return segments
    }

    // Perform the document analysis
    private func analyzeDocument() {
        // 1. Segmentation: Break down the document into sentences
        let segments = segmentText(text: documentText, unit: .sentence)
        self.segmentedDocument = segments // Store for potential debug/display

        var languageCounts: [NLLanguage: Int] = [:]
        var currentUndeterminedSegments: Int = 0

        // 2. Language Detection per Segment
        for segment in segments {
            let dominantLanguage = NLLanguageRecognizer.dominantLanguage(for: segment)
            if dominantLanguage == .undetermined {
                currentUndeterminedSegments += 1
            } else {
                languageCounts[dominantLanguage, default: 0] += 1
            }
        }

        // 3. Aggregation and Summary
        self.summary = languageCounts
        self.undeterminedSegments = currentUndeterminedSegments
        self.totalDeterminedSegments = languageCounts.values.reduce(0, +)
    }

    // Helper to calculate percentage for a given language
    private func percentage(for language: NLLanguage) -> Double {
        guard totalDeterminedSegments > 0 else { return 0.0 }
        let count = summary[language] ?? 0
        return (Double(count) / Double(totalDeterminedSegments)) * 100
    }

    // Helper function to get a localized display name for an NLLanguage
    private func languageDisplayName(_ language: NLLanguage) -> String {
        if language == .undetermined {
            return "Undetermined"
        }
        let locale = Locale(identifier: language.rawValue)
        return locale.localizedString(forLanguageCode: language.rawValue)?.capitalized ?? language.rawValue
    }
}

// MARK: - Preview Provider (for Xcode Canvas)
#Preview {
    DocumentLanguageAnalyzerView()
}
