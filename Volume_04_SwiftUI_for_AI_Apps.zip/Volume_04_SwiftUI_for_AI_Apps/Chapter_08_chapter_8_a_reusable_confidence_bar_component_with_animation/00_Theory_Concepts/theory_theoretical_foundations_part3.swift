
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    // This struct is implicitly Sendable because all its properties are value types
    // and themselves Sendable (String, Double).
    struct PredictionResult: Sendable {
        let label: String
        let confidence: Double
        let rawOutputProbabilities: [Double]
        // Add other immutable prediction details as needed
    }

    actor AIInferenceActor {
        private let model: AIModelPredicting

        init(model: AIModelPredicting) {
            self.model = model
        }

        /// Performs AI inference and returns a Sendable PredictionResult.
        func performFullPrediction(for input: MLFeatureProvider) async throws -> PredictionResult {
            do {
                let output = try await model.predict(input: input)
                guard let confidence = output.featureValue(for: "confidence")?.doubleValue,
                      let label = output.featureValue(for: "label")?.stringValue else {
                    throw AIInferenceError.missingConfidenceOutput
                }
                // In a real scenario, extract all relevant data from output
                let rawProbs = (output.featureValue(for: "probabilities")?.dictionaryValue as? [String: Double])?.values.map { $0 } ?? []

                return PredictionResult(label: label, confidence: confidence, rawOutputProbabilities: rawProbs)
            } catch {
                throw AIInferenceError.modelPredictionFailed(error)
            }
        }
    }

    // In the ViewModel:
    @available(iOS 17.0, *)
    @MainActor
    class AIAppViewModel: ObservableObject {
        @Published var currentPredictionState: AIModelPredictionState
        // ... other properties ...
        private let inferenceActor: AIInferenceActor

        init(model: AIModelPredicting) {
            self.inferenceActor = AIInferenceActor(model: model)
            self.currentPredictionState = AIModelPredictionState(predictionLabel: "Waiting...", confidenceScore: 0.0, modelOutput: [])
        }

        func requestFullPrediction(input: MLFeatureProvider) {
            isLoading = true
            errorMessage = nil
            Task {
                do {
                    let result = try await inferenceActor.performFullPrediction(for: input)
                    // The 'result' (PredictionResult) is Sendable and safely transferred
                    currentPredictionState.update(newConfidence: result.confidence, newLabel: result.label, newOutput: result.rawOutputProbabilities)
                } catch {
                    errorMessage = error.localizedDescription
                    print("Full prediction failed: \(error)")
                }
                isLoading = false
            }
        }
    }
    