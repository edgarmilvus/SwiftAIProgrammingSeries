
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreData
import NaturalLanguage
import Accelerate
import OSLog

// MARK: - Dependencies & Errors

/// Represents errors that can occur during semantic memory operations.
enum SemanticMemoryError: Error, LocalizedError {
    case embeddingGenerationFailed
    case persistenceFailure(Error)
    case vectorDimensionMismatch
    case noContextFound

    var errorDescription: String? {
        switch self {
        case .embeddingGenerationFailed: return "Failed to generate semantic vector from text."
        case .persistenceFailure(let error): return "Core Data error: \(error.localizedDescription)"
        case .vectorDimensionMismatch: return "The query vector does not match stored embedding dimensions."
        case .noContextFound: return "No relevant historical context was found."
        }
    }
}

/// A typealias representing a high-dimensional vector.
typealias EmbeddingVector = [Float]

// MARK: - Semantic Memory Actor

/// `SemanticMemoryActor` is the central orchestrator for AI-related persistence.
/// It uses the Swift 6 Actor model to ensure that all Core Data operations and 
/// heavy vector computations are isolated from the Main Actor, preventing UI hangs.
@available(iOS 18.0, *)
actor SemanticMemoryActor {
    
    private let container: NSPersistentCloudKitContainer
    private let logger = Logger(subsystem: "com.ai.app.memory", category: "SemanticEngine")
    private let embeddingModel = NLEmbedding.wordEmbedding(for: .english)
    
    /// Initializes the actor with a Core Data container.
    /// - Parameter container: The persistent container configured with CloudKit.
    init(container: NSPersistentCloudKitContainer) {
        self.container = container
    }

    /// Stores a new message and its corresponding semantic embedding.
    /// - Parameters:
    ///   - text: The raw string content of the message.
    ///   - role: The speaker role (e.g., "user" or "assistant").
    ///   - conversationID: The UUID of the parent conversation.
    /// - Throws: `SemanticMemoryError` if embedding or saving fails.
    func ingest(text: String, role: String, conversationID: UUID) async throws {
        logger.info("Ingesting new message: \(text.prefix(20))...")
        
        // 1. Generate Embedding
        guard let vector = try generateEmbedding(for: text) else {
            throw SemanticMemoryError.embeddingGenerationFailed
        }
        
        // 2. Perform Persistence on a background context
        let context = container.newBackgroundContext()
        
        // Ensure the context is configured for Swift 6 concurrency
        try await context.perform {
            let message = MessageEntity(context: context)
            message.id = UUID()
            message.text = text
            message.role = role
            message.timestamp = Date()
            message.conversationID = conversationID
            
            // Store the vector as Data for Core Data compatibility
            message.embeddingData = vector.toData()
            
            do {
                try context.save()
                self.logger.debug("Successfully persisted message and vector.")
            } catch {
                throw SemanticMemoryError.persistenceFailure(error)
            }
        }
    }

    /// Retrieves the most relevant historical messages based on a query string.
    /// - Parameters:
    ///   - query: The user's current input.
    ///   - limit: The maximum number of context snippets to return.
    /// - Returns: An array of relevant messages and their similarity scores.
    func retrieveContext(for query: String, limit: Int = 3) async throws -> [(text: String, score: Float)] {
        guard let queryVector = try generateEmbedding(for: query) else {
            throw SemanticMemoryError.embeddingGenerationFailed
        }
        
        let context = container.newBackgroundContext()
        
        return try await context.perform {
            let request: NSFetchRequest<MessageEntity> = MessageEntity.fetchRequest()
            // Optimization: In a real-world app, we might filter by date or conversation here.
            let allMessages = try context.fetch(request)
            
            // 3. Vector Search via Cosine Similarity
            // We map messages to (text, vector, score) tuples
            let scoredMessages = allMessages.compactMap { message -> (String, Float)? in
                guard let data = message.embeddingData,
                      let vector = data.toFloatArray() else { return nil }
                
                let similarity = self.cosineSimilarity(queryVector, vector)
                return (message.text ?? "", similarity)
            }
            
            // 4. Sort by highest similarity and return top K
            let sortedResults = scoredMessages
                .sorted { $0.1 > $1.1 }
                .prefix(limit)
            
            return Array(sortedResults)
        }
    }

    // MARK: - Private Mathematical Helpers

    /// Generates a vector representation of the input text using Apple's Natural Language framework.
    private func generateEmbedding(for text: String) throws -> EmbeddingVector? {
        guard let embedding = embeddingModel else { return nil }
        
        // We use the embedding for the entire string. 
        // For longer texts, one would typically chunk the text and average the vectors.
        return embedding.vector(for: text)
    }

    /// Performs high-performance Cosine Similarity using the Accelerate framework.
    /// Formula: (A · B) / (||A|| * ||B||)
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return 0.0 }
        
        var dotProduct: Float = 0.0
        var normA: Float = 0.0
        var normB: Float = 0.0
        
        // Use vDSP (Digital Signal Processing) from Accelerate for O(n) performance
        // This is significantly faster than a manual for-loop for large vectors.
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        vDSP_svesq(a, 1, &normA, vDSP_Length(a.count))
        vDSP_svesq(b, 1, &normB, vDSP_Length(b.count))
        
        let magnitude = sqrt(normA) * sqrt(normB)
        return magnitude > 0 ? dotProduct / magnitude : 0.0
    }
}

// MARK: - Data Extensions

extension Array where Element == Float {
    /// Converts a Float array to Data for Core Data storage.
    func toData() -> Data {
        return self.withUnsafeBufferPointer { Data(buffer: $0) }
    }
}

extension Data {
    /// Converts stored Data back into a Float array.
    func toFloatArray() -> [Float]? {
        guard self.count % MemoryLayout<Float>.size == 0 else { return nil }
        let count = self.count / MemoryLayout<Float>.size
        return self.withUnsafeBytes { Array($0.bindMemory(to: Float.self)) }
    }
}
