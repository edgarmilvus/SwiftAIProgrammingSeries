
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import BackgroundTasks
import UIKit // Needed for AppDelegate context

// MARK: - Background Task Manager

@available(iOS 18.0, *)
class BackgroundTaskManager {

    static let shared = BackgroundTaskManager()

    private let fineTuneIdentifier = "com.yourcompany.yourapp.modelFineTuneTask"
    private var currentFineTuningTask: Task<Void, Never>? // To allow cancellation

    private init() {} // Singleton

    // MARK: - Registration

    func registerModelFineTuningTask() {
        // Register on a background QoS queue for heavy processing
        BGTaskScheduler.shared.register(forTaskWithIdentifier: fineTuneIdentifier, onQueue: .global(qos: .background)) { task in
            guard let processingTask = task as? BGProcessingTask else {
                print("Error: Task is not a BGProcessingTask.")
                task.setTaskCompleted(success: false)
                return
            }
            self.handleModelFineTuning(task: processingTask)
        }
        print("Registered background model fine-tuning task: \(fineTuneIdentifier)")
    }

    // MARK: - Scheduling

    func scheduleModelFineTuning() {
        let request = BGProcessingTaskRequest(identifier: fineTuneIdentifier)
        request.requiresNetworkConnectivity = true // Needs Wi-Fi for data/updates
        request.requiresExternalPower = true      // Needs device charging
        // Schedule no earlier than 2 hours from now, giving system flexibility
        request.earliestBeginDate = Date(timeIntervalSinceNow: 60 * 60 * 2)

        do {
            try BGTaskScheduler.shared.submit(request)
            print("Scheduled background model fine-tuning request.")
        } catch {
            print("Could not schedule model fine-tuning: \(error.localizedDescription)")
        }
    }

    // MARK: - Task Handler

    private func handleModelFineTuning(task: BGProcessingTask) {
        print("Background model fine-tuning task started for \(task.identifier).")

        // Load saved progress
        var currentEpoch = UserDefaults.standard.integer(forKey: "modelFineTuneCurrentEpoch")
        let totalEpochs = 50 // Simulate 50 epochs of training

        currentFineTuningTask = Task {
            // Set an expiration handler to clean up and save progress if the task is terminated early.
            task.expirationHandler = {
                print("Model fine-tuning task expired for \(task.identifier). Saving progress at epoch \(currentEpoch).")
                UserDefaults.standard.set(currentEpoch, forKey: "modelFineTuneCurrentEpoch") // Save current progress
                self.currentFineTuningTask?.cancel() // Cancel the Swift Concurrency Task
                task.setTaskCompleted(success: false) // Mark as failed due to expiration
            }

            var success = true
            // Simulate fine-tuning epochs
            for epoch in currentEpoch..<totalEpochs {
                // Check for cancellation before starting work for the current epoch
                if Task.isCancelled || task.isCancelled {
                    print("Model fine-tuning task cancelled. Completed \(currentEpoch) epochs.")
                    success = false
                    break
                }

                print("Fine-tuning epoch \(epoch + 1)/\(totalEpochs)...")
                // Simulate computationally intensive work for one epoch
                await Task.sleep(for: .seconds(Double.random(in: 5...10)))

                // Simulate a small network check/download for new training data or updates
                let networkSuccess = await performSmallNetworkCheck()
                if !networkSuccess {
                    print("Network check failed during epoch \(epoch + 1). Aborting fine-tuning.")
                    success = false
                    break
                }

                currentEpoch = epoch + 1
                UserDefaults.standard.set(currentEpoch, forKey: "modelFineTuneCurrentEpoch") // Save progress after each epoch
            }

            // Ensure the task is marked complete only if not already expired
            if !Task.isCancelled && !task.isCancelled {
                print("Model fine-tuning completed for \(currentEpoch) epochs with success: \(success).")
                task.setTaskCompleted(success: success)
                if success {
                    UserDefaults.standard.set(0, forKey: "modelFineTuneCurrentEpoch") // Reset for next full fine-tuning cycle
                } else {
                    // If failed mid-way, progress is already saved by the loop/expiration handler
                    // Re-schedule for retry if desired, otherwise rely on manual trigger
                    self.scheduleModelFineTuning() // Retry later
                }
            } else {
                print("Model fine-tuning task for \(task.identifier) was cancelled externally (e.g., by expiration handler).")
                // Expiration handler already saved progress and set task.setTaskCompleted(success: false)
            }
            self.currentFineTuningTask = nil
            // Always reschedule for the next potential fine-tuning opportunity
            self.scheduleModelFineTuning()
        }
    }

    // MARK: - Simulated Network Check

    private func performSmallNetworkCheck() async -> Bool {
        let mockURL = URL(string: "https://mockapi.example.com/training_data_updates.json")!
        let successRate = 0.9 // 90% chance of success for network check

        do {
            // Simulate a quick network check
            try await Task.sleep(for: .seconds(Double.random(in: 1...2)))
            if Double.random(in: 0...1) < successRate {
                print("Small network check successful.")
                return true
            } else {
                print("Simulated small network check failed.")
                return false
            }
        } catch is URLError {
            print("URLError during small network check.")
            return false
        } catch {
            print("An unexpected error occurred during small network check: \(error.localizedDescription)")
            return false
        }
    }
}

// MARK: - AppDelegate Integration Example

// Extend AppDelegate to call the BackgroundTaskManager methods
/*
@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    let backgroundTaskManager = BackgroundTaskManager.shared

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        if #available(iOS 18.0, *) {
            backgroundTaskManager.registerModelFineTuningTask()
            // Schedule the fine-tuning task only if there's pending work or it's explicitly triggered.
            // For example, if UserDefaults.standard.integer(forKey: "modelFineTuneCurrentEpoch") > 0
            // or if the user enabled fine-tuning.
            backgroundTaskManager.scheduleModelFineTuning()
        } else {
            // Fallback for older iOS versions
        }
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        if #available(iOS 18.0, *) {
            // Reschedule when app goes to background, ensuring it runs when conditions are met
            backgroundTaskManager.scheduleModelFineTuning()
        }
    }
}
*/
