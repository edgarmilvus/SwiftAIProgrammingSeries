
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part9.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 17.0, *)
    struct DetectionView: View {
        @State var viewModel = ObjectDetectionViewModel()
        let inputImage: UIImage // The image to process

        var body: some View {
            GeometryReader { geometry in
                ZStack {
                    // 1. Display the image
                    Image(uiImage: inputImage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        // This overlay is crucial to get the *actual* frame of the image AFTER aspectRatio
                        .overlay {
                            // 2. Overlay bounding boxes and labels
                            ForEach(viewModel.detectedObjects) { object in
                                Rectangle()
                                    .stroke(object.color, lineWidth: 2)
                                    .frame(width: object.boundingBox.width, height: object.boundingBox.height)
                                    .offset(x: object.boundingBox.minX, y: object.boundingBox.minY)

                                Text("\(object.label) (\(Int(object.confidence * 100))%)")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                    .padding(4)
                                    .background(object.color.opacity(0.7))
                                    .cornerRadius(5)
                                    .offset(x: object.boundingBox.minX, y: object.boundingBox.minY - 20) // Position above box
                            }
                        }
                }
                .onAppear {
                    // Perform detection when the view appears
                    Task {
                        // Assuming you have a Core ML model instance
                        guard let mlModel = try? MyObjectDetector().model else { return }
                        let visionModel = try VNCoreMLModel(for: mlModel)

                        await viewModel.processImageAndDisplay(
                            image: inputImage.cgImage!,
                            model: visionModel
                        )
                        // After processing, update the view model's state with the results
                        viewModel.processObservations(
                            viewModel.detectedObjects, // This would be the actual observations from the async call
                            originalImageSize: inputImage.size,
                            viewSize: geometry.size
                        )
                    }
                }
            }
        }
    }
    