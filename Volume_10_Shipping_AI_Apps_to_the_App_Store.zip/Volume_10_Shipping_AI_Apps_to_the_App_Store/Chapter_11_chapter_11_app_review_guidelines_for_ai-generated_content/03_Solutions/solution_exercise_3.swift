
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 18.0, *)
struct Token: Sendable {
    let text: String
}

@available(iOS 18.0, *)
enum ModerationResult: Sendable {
    case safe(String)
    case unsafe(String) // Returns redacted version
}

@available(iOS 18.0, *)
actor ModerationActor {
    private let forbiddenWords = ["toxic", "malicious", "hateful"]
    
    func process(sentence: String) async -> ModerationResult {
        // Simulate network/AI moderation latency
        try? await Task.sleep(for: .milliseconds(500))
        
        let containsForbidden = forbiddenWords.contains { sentence.lowercased().contains($0) }
        
        if containsForbidden {
            let redacted = sentence.replacingOccurrences(of: "(toxic|malicious|hateful)", 
                                                        with: "[REDACTED]", 
                                                        options: .regularExpression, 
                                                        range: nil)
            return .unsafe(redacted)
        }
        return .safe(sentence)
    }
}

@available(iOS 18.0, *)
class ModerationMiddleware {
    private let moderator = ModerationActor()
    
    func moderate(tokenStream: AsyncStream<Token>) -> AsyncStream<String> {
        AsyncStream { continuation in
            Task {
                var buffer = ""
                
                for await token in tokenStream {
                    buffer += token.text
                    
                    // Check if we have a complete sentence (basic delimiter check)
                    if buffer.contains(where: { [".", "!", "?"].contains($0) }) {
                        let sentenceToProcess = buffer.trimmingCharacters(in: .whitespacesAndNewlines)
                        buffer = "" // Clear buffer for next sentence
                        
                        // Process sentence through actor
                        let result = await moderator.process(sentence: sentenceToProcess)
                        
                        switch result {
                        case .safe(let text):
                            continuation.yield(text + " ")
                        case .unsafe(let redacted):
                            continuation.yield(redacted + " ")
                        }
                    }
                }
                continuation.finish()
            }
        }
    }
}

// --- Simulation & UI ---

import SwiftUI

@available(iOS 18.0, *)
struct StreamTalkView: View {
    @State private var displayedText = ""
    private let middleware = ModerationMiddleware()
    
    var body: some View {
        VStack {
            ScrollView {
                Text(displayedText)
                    .font(.system(.body, design: .monospaced))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
            }
            .background(Color.black.opacity(0.05))
            
            Button("Start Live Stream") {
                startStreaming()
            }
            .buttonStyle(.borderedProminent)
            .padding()
        }
        .padding()
    }
    
    private func startStreaming() {
        displayedText = ""
        
        // 1. Create the raw token stream
        let (tokenStream, continuation) = AsyncStream.makeStream(of: Token.self)
        
        // 2. Connect the middleware
        let safeStream = middleware.moderate(tokenStream: tokenStream)
        
        // 3. Consume the safe stream
        Task {
            for await safeSentence in safeStream {
                displayedText += safeSentence
            }
        }
        
        // 4. Simulate AI producing tokens
        Task {
            let rawTokens = ["Hello", " there!", " This", " is", " a", " toxic", " sentence.", " Have", " a", " nice", " day!"]
            for word in rawTokens {
                try? await Task.sleep(for: .milliseconds(300))
                continuation.yield(Token(text: word))
            }
            continuation.finish()
        }
    }
}
