
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet for Swift Package Manager (if external dependencies were needed)
// For this example, we're using built-in SwiftUI and Foundation capabilities,
// so no external dependencies are strictly required.
// If we were to use a real HTTP client, it might look like this:
/*
import PackageDescription

let package = Package(
    name: "AIAppComponents",
    platforms: [
        .iOS(.v18),
        .macOS(.v15),
        .tvOS(.v18),
        .watchOS(.v11)
    ],
    products: [
        .library(
            name: "AIAppComponents",
            targets: ["AIAppComponents"]),
    ],
    dependencies: [
        // Example: If using a dedicated HTTP client for real API calls
        // .package(url: "https://github.com/swift-server/async-http-client.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "AIAppComponents",
            dependencies: [
                // "AsyncHTTPClient" // If added above
            ]),
        .testTarget(
            name: "AIAppComponentsTests",
            dependencies: ["AIAppComponents"]),
    ]
)
*/

import SwiftUI
import Foundation

// Ensure this code is only available on platforms supporting the features used (e.g., iOS 18 for Observable)
@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, *)
struct TokenStreamApp: App {
    var body: some Scene {
        WindowGroup {
            TokenStreamView()
        }
    }
}

/// Represents a single message in the chat, either from the user or the AI.
/// Conforms to `Identifiable` for use in `ForEach` and `ScrollViewReader`.
/// `Equatable` is used for efficient UI updates.
struct ChatMessage: Identifiable, Equatable {
    let id = UUID()
    let content: AttributedString // Using AttributedString for rich text, including Markdown
    let isUser: Bool
    let timestamp: Date
    var isStreaming: Bool = false // Indicates if this message is currently being streamed
    var isError: Bool = false // Indicates if there was an error generating this message
}

/// Protocol defining the capabilities of an AI service that streams tokens.
/// This abstraction allows swapping different LLM backends without changing the UI logic.
protocol LLMServiceProtocol {
    /// Streams a response for a given prompt.
    /// - Parameters:
    ///   - prompt: The user's input prompt.
    ///   - onToken: A closure called for each token received. This closure is `async throws`
    ///              to allow processing each token asynchronously and handling potential errors.
    /// - Throws: `LLMServiceError` if an error occurs during streaming.
    func streamResponse(prompt: String, onToken: @escaping (String) async throws -> Void) async throws
}

/// Custom error type for the LLM service.
/// Provides specific error cases and localized descriptions for better user feedback.
enum LLMServiceError: Error, LocalizedError {
    case networkError(Error)
    case apiError(String)
    case cancelled
    case unknown

    var errorDescription: String? {
        switch self {
        case .networkError(let error): return "Network error: \(error.localizedDescription)"
        case .apiError(let message): return "API error: \(message)"
        case .cancelled: return "Stream cancelled by user."
        case .unknown: return "An unknown error occurred."
        }
    }
}

/// A mock implementation of `LLMServiceProtocol` to simulate AI token streaming.
/// This class provides predefined responses and simulates network delays and errors.
class MockLLMService: LLMServiceProtocol {
    private let mockResponses: [String: String] = [
        "hello": "Hello there! How can I assist you today?",
        "tell me a story": "Once upon a time, in a digital realm far, far away, lived a SwiftUI app that loved to stream tokens. It was a happy app, always responsive and full of useful information. One day, a user asked it to tell a very long story. The app, being clever, streamed the story token by token, keeping the user engaged and the scroll view perfectly aligned. And so, the app lived happily ever after, serving its users with delightful, real-time AI experiences.",
        "what is swiftui": "SwiftUI is an innovative, declarative framework for building user interfaces across all Apple platforms. It allows developers to express their UI in a more intuitive and less verbose way compared to UIKit, leveraging Swift's powerful features like structs, protocols, and generics. With SwiftUI, you describe *what* your UI should look like, and the framework takes care of *how* to render it, making it ideal for reactive and data-driven applications, especially those integrating with AI models.",
        "error": "Simulating an error now...", // This will be followed by throwing an an error
        "markdown example": "Here's some **bold text** and *italic text*. You can also have `inline code` or a [link to Apple](https://www.apple.com).\n\n