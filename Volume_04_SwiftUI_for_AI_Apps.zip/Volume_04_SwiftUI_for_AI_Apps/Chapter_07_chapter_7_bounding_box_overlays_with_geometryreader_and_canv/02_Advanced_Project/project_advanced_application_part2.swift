
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import CoreGraphics // For CGRect
import Foundation   // For UUID

/// Represents a detected text block with its bounding box and content.
/// This struct holds the necessary data to render and interact with a detected region.
struct DetectedTextBlock: Identifiable, Equatable {
    let id = UUID()
    let boundingBox: CGRect // Normalized CGRect (0.0 to 1.0) from AI model
    let textContent: String // Simulated text content
    var confidence: Float = 1.0 // Confidence score from the AI model

    static func == (lhs: DetectedTextBlock, rhs: DetectedTextBlock) -> Bool {
        lhs.id == rhs.id
    }
}

/// Manages the state and logic for the document scanner view.
/// This ObservableObject handles AI processing, updates detected blocks, and manages selection.
@MainActor // Ensures all state updates happen on the main actor
class DocumentScannerViewModel: ObservableObject {
    /// The list of text blocks detected by the AI model.
    @Published var detectedBlocks: [DetectedTextBlock] = []
    /// The ID of the currently selected text block, if any.
    @Published var selectedBlockID: UUID?
    /// An error message to display to the user, if an error occurs during processing.
    @Published var errorMessage: String?

    /// Simulates AI processing of an image to detect text blocks.
    /// In a real application, this would involve `VNImageRequestHandler` and `VNRecognizeTextRequest`.
    /// - Parameter uiImage: The image to process.
    func processImage(uiImage: UIImage) async {
        errorMessage = nil
        // Simulate a delay for AI processing
        await Task.sleep(nanoseconds: 500_000_000) // 0.5 seconds

        // Clear previous detections
        detectedBlocks = []
        selectedBlockID = nil

        // --- Real-world Vision Integration (Conceptual) ---
        // let requestHandler = VNImageRequestHandler(cgImage: uiImage.cgImage!, options: [:])
        // let request = VNRecognizeTextRequest { [weak self] request, error in
        //     guard let self = self, let observations = request.results as? [VNTextObservation] else {
        //         self?.errorMessage = error?.localizedDescription ?? "Unknown Vision error."
        //         return
        //     }
        //     // Convert VNTextObservation bounding boxes (normalized) to DetectedTextBlock
        //     self.detectedBlocks = observations.map { observation in
        //         DetectedTextBlock(
        //             boundingBox: observation.boundingBox, // Already normalized
        //             textContent: "Detected Text: \(observation.topCandidates(1).first?.string ?? "N/A")",
        //             confidence: observation.confidence
        //         )
        //     }
        // }
        // request.recognitionLevel = .accurate
        // await Task {
        //     do {
        //         try requestHandler.perform([request])
        //     } catch {
        //         self.errorMessage = "Failed to perform text recognition: \(error.localizedDescription)"
        //     }
        // }
        // --- End Real-world Vision Integration ---

        // --- Simulated Detections for Demonstration ---
        // For demonstration, we'll create some sample bounding boxes.
        // These are normalized CGRects (origin and size are between 0.0 and 1.0).
        let simulatedBlocks: [DetectedTextBlock] = [
            DetectedTextBlock(boundingBox: CGRect(x: 0.1, y: 0.1, width: 0.4, height: 0.1), textContent: "Header Text", confidence: 0.95),
            DetectedTextBlock(boundingBox: CGRect(x: 0.1, y: 0.25, width: 0.7, height: 0.08), textContent: "Paragraph Line 1", confidence: 0.92),
            DetectedTextBlock(boundingBox: CGRect(x: 0.1, y: 0.35, width: 0.6, height: 0.08), textContent: "Paragraph Line 2", confidence: 0.91),
            DetectedTextBlock(boundingBox: CGRect(x: 0.5, y: 0.5, width: 0.3, height: 0.12), textContent: "Signature Area", confidence: 0.88),
            DetectedTextBlock(boundingBox: CGRect(x: 0.2, y: 0.7, width: 0.5, height: 0.1), textContent: "Footer Note", confidence: 0.85)
        ]
        self.detectedBlocks = simulatedBlocks
        // --- End Simulated Detections ---

        if detectedBlocks.isEmpty {
            errorMessage = "No text blocks detected."
        }
    }

    /// Toggles the selection state of a text block.
    /// - Parameter id: The UUID of the text block to select or deselect.
    func selectBlock(id: UUID) {
        if selectedBlockID == id {
            selectedBlockID = nil // Deselect if already selected
        } else {
            selectedBlockID = id // Select new block
        }
    }
}

/// A SwiftUI view responsible for drawing bounding box overlays using Canvas.
/// It uses GeometryReader to correctly scale normalized bounding boxes to the view's coordinate space.
struct BoundingBoxOverlayView: View {
    let detectedBlocks: [DetectedTextBlock]
    let selectedBlockID: UUID?
    let imageSize: CGSize // The actual size of the image being displayed

    /// The body of the BoundingBoxOverlayView.
    var body: some View {
        Canvas { context, size in
            // Iterate through each detected block and draw its bounding box.
            for block in detectedBlocks {
                // 1. Convert normalized bounding box to view coordinates.
                // Vision framework provides `boundingBox` with origin at bottom-left and normalized values.
                // SwiftUI's Canvas has origin at top-left.
                // We need to flip the y-coordinate and scale by the image's actual display size.
                let rectInView = CGRect(
                    x: block.boundingBox.origin.x * imageSize.width,
                    y: (1 - block.boundingBox.origin.y - block.boundingBox.height) * imageSize.height,
                    width: block.boundingBox.width * imageSize.width,
                    height: block.boundingBox.height * imageSize.height
                )

                let path = Path(rectInView)

                // Determine drawing style based on selection
                let isSelected = block.id == selectedBlockID
                let fillColor: Color = isSelected ? .blue.opacity(0.2) : .clear
                let strokeColor: Color = isSelected ? .blue : .red
                let lineWidth: CGFloat = isSelected ? 3 : 2

                // 2. Draw the bounding box.
                context.fill(path, with: .color(fillColor))
                context.stroke(path, with: .color(strokeColor), lineWidth: lineWidth)

                // Optionally, draw text content or confidence score.
                // For simplicity, we'll draw a label only for selected blocks.
                if isSelected {
                    let text = Text(block.textContent)
                        .font(.caption.bold())
                        .foregroundColor(.white)
                    // Create a symbol for the text to draw on Canvas
                    if let resolvedText = context.resolve(text) {
                        context.draw(resolvedText, at: CGPoint(x: rectInView.minX + 5, y: rectInView.minY + 5))
                    }
                }
            }
        }
    }
}

/// The main SwiftUI view for the document scanner application.
/// This view integrates the ViewModel, displays the image, and overlays the bounding boxes.
struct DocumentScannerView: View {
    @StateObject private var viewModel = DocumentScannerViewModel()
    @State private var documentImage: UIImage = UIImage(named: "sampleDocument") ?? UIImage() // Placeholder

    /// The body of the DocumentScannerView.
    var body: some View {
        NavigationView {
            VStack {
                // 1. Display the image and use GeometryReader to get its actual display size.
                GeometryReader { geometry in
                    Image(uiImage: documentImage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color.gray.opacity(0.1))
                        .overlay(
                            // 2. Overlay the BoundingBoxOverlayView on top of the image.
                            // Pass the detected blocks and the actual size of the image view.
                            BoundingBoxOverlayView(
                                detectedBlocks: viewModel.detectedBlocks,
                                selectedBlockID: viewModel.selectedBlockID,
                                imageSize: geometry.size // Crucial for coordinate conversion
                            )
                            // 3. Add tap gestures to individual bounding boxes for selection.
                            // We use a ZStack here to ensure tap targets are correctly registered.
                            // Each `Rectangle` acts as an invisible tap target.
                            .overlay(
                                ZStack {
                                    ForEach(viewModel.detectedBlocks) { block in
                                        let rectInView = CGRect(
                                            x: block.boundingBox.origin.x * geometry.size.width,
                                            y: (1 - block.boundingBox.origin.y - block.boundingBox.height) * geometry.size.height,
                                            width: block.boundingBox.width * geometry.size.width,
                                            height: block.boundingBox.height * geometry.size.height
                                        )
                                        Rectangle()
                                            .fill(Color.clear) // Make it invisible
                                            .contentShape(Rectangle()) // Define tap area
                                            .frame(width: rectInView.width, height: rectInView.height)
                                            .position(x: rectInView.midX, y: rectInView.midY)
                                            .onTapGesture {
                                                viewModel.selectBlock(id: block.id)
                                            }
                                    }
                                }
                            )
                        )
                }
                .aspectRatio(documentImage.size.width / documentImage.size.height, contentMode: .fit) // Maintain aspect ratio of the image
                .padding()

                // Display error messages
                if let errorMessage = viewModel.errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .padding(.horizontal)
                }

                // Action button to simulate processing
                Button("Process Document (Simulated AI)") {
                    Task {
                        await viewModel.processImage(uiImage: documentImage)
                    }
                }
                .buttonStyle(.borderedProminent)
                .padding(.bottom)
            }
            .navigationTitle("AI Document Scanner")
            .onAppear {
                // Load a sample image (ensure you have "sampleDocument.png" in your Assets.xcassets)
                // For a real app, this would be from camera or photo library.
                if UIImage(named: "sampleDocument") == nil {
                    print("ERROR: 'sampleDocument' image not found in assets. Please add one.")
                    // Create a dummy image if not found
                    UIGraphicsBeginImageContextWithOptions(CGSize(width: 400, height: 600), false, 0.0)
                    let context = UIGraphicsGetCurrentContext()!
                    UIColor.white.setFill()
                    context.fill(CGRect(x: 0, y: 0, width: 400, height: 600))
                    UIColor.black.setStroke()
                    context.stroke(CGRect(x: 50, y: 50, width: 300, height: 500), lineWidth: 2)
                    let text = "Sample Document\n(Placeholder)"
                    let font = UIFont.systemFont(ofSize: 24)
                    let attributes: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor.darkGray]
                    text.draw(at: CGPoint(x: 80, y: 250), withAttributes: attributes)
                    documentImage = UIGraphicsGetImageFromCurrentImageContext()!
                    UIGraphicsEndImageContext()
                }
            }
        }
    }
}

// Example usage in an App:
@main
struct AIDocumentScannerApp: App {
    var body: some Scene {
        WindowGroup {
            DocumentScannerView()
        }
    }
}
