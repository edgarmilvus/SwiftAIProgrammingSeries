
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import AppIntents
import Foundation

// 1. Define an Entity to represent the Time Range for the Intent
@available(iOS 18.0, *)
struct TimeRangeEntity: AppEntity {
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Time Range"
    
    let id: UUID
    var rangeDescription: String
    
    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(title: "\(rangeDescription)")
    }
    
    static var defaultQuery = TimeRangeQuery()
}

// 2. Create a Query to allow Siri to resolve the entity
@available(iOS 18.0, *)
struct TimeRangeQuery: EntityQuery {
    func entities(for identifiers: [UUID]) async throws -> [TimeRangeEntity] {
        // In a real app, this would fetch from a database
        return []
    }
    
    func suggestedEntities() async throws -> [TimeRangeEntity] {
        [
            TimeRangeEntity(id: UUID(), rangeDescription: "this week"),
            TimeRangeEntity(id: UUID(), rangeDescription: "yesterday"),
            TimeRangeEntity(id: UUID(), rangeDescription: "last month")
        ]
    }
}

// 3. Implement the AppIntent
@available(iOS 18.0, *)
struct SummarizeJournalEntriesIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize Journal Entries"
    static var description = IntentDescription("Summarizes your journal entries for a specific period.")

    // Parameterization using our custom Entity
    @Parameter(title: "Time Range")
    var timeRange: TimeRangeEntity

    // Asynchronous execution simulating on-device LLM
    @MainActor
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        // Simulate a delay for LLM processing
        try await Task.sleep(for: .seconds(2))
        
        let summary = "Based on your entries from \(timeRange.rangeDescription), your mood has been predominantly reflective and calm."
        
        // Return a result that Siri can speak or display
        return .result(value: summary)
    }
}
