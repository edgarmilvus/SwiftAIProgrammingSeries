
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

@available(iOS 18.0, *)
enum AgentEvent: Sendable {
    case thought(String)
    case content(String)
    case complete
}

@available(iOS 18.0, *)
actor AgentStreamManager {
    private let decoder = JSONDecoder()

    /// Transforms raw SSE chunks into a high-level AgentEvent stream.
    func transform(rawStream: AsyncThrowingStream<ChatCompletionChunk, Error>) -> AsyncStream<AgentEvent> {
        AsyncStream { continuation in
            Task {
                do {
                    for try await chunk in rawStream {
                        // In a real API, 'reasoning' and 'content' might be different fields
                        // Here we simulate by checking the delta content
                        if let thought = chunk.choices.first?.delta.content, thought.contains("THOUGHT:") {
                            let cleanThought = thought.replacingOccurrences(of: "THOUGHT:", with: "")
                            continuation.yield(.thought(cleanThought))
                        } else if let content = chunk.choices.first?.delta.content {
                            continuation.yield(.content(content))
                        }
                    }
                    continuation.yield(.complete)
                    continuation.finish()
                } catch {
                    continuation.finish()
                }
            }
        }
    }
}

@available(iOS 18.0, *)
@Observable
@MainActor
class AgentViewModel {
    var thoughtProcess: String = ""
    var finalResponse: String = ""
    var isComplete: Bool = false
    
    private let manager = AgentStreamManager()

    func runAgent(rawStream: AsyncThrowingStream<ChatCompletionChunk, Error>) async {
        // 1. Transform the low-level stream into a high-level semantic stream
        let eventStream = await manager.transform(rawStream: rawStream)
        
        // 2. Consume the semantic events
        for await event in eventStream {
            switch event {
            case .thought(let text):
                thoughtProcess += text
            case .content(let text):
                finalResponse += text
            case .complete:
                isComplete = true
            }
        }
    }
}

@available(iOS 18.0, *)
struct AgentView: View {
    @State private var viewModel = AgentViewModel()
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            if !viewModel.thoughtProcess.isEmpty {
                GroupBox("Thinking Process") {
                    Text(viewModel.thoughtProcess)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .italic()
                }
            }
            
            Text(viewModel.finalResponse)
                .font(.body)
            
            if !viewModel.isComplete && !viewModel.finalResponse.isEmpty {
                ProgressView()
            }
        }
        .padding()
    }
}
