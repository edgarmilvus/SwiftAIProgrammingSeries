
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import NaturalLanguage

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, visionOS 2.0, *)
@Observable // Use @Observable for modern SwiftUI apps
class SentimentViewModel {
    private let classifier: ConcurrentSentimentClassifier // Using the actor
    var inputText: String = "" {
        didSet {
            // Automatically trigger analysis when input text changes
            Task { await analyzeSentiment() }
        }
    }
    var predictedSentiment: String = "Neutral"
    var isLoading: Bool = false

    init() {
        do {
            self.classifier = try ConcurrentSentimentClassifier()
        } catch {
            fatalError("Failed to load sentiment classifier: \(error)")
        }
    }

    @MainActor
    func analyzeSentiment() async {
        guard !inputText.isEmpty else {
            predictedSentiment = "Neutral"; return
        }
        isLoading = true

        do {
            // Await the actor's method call. The actor handles its internal concurrency.
            let result = try await classifier.classifySentiment(for: inputText)
            predictedSentiment = result
            isLoading = false
        } catch {
            predictedSentiment = "Error: \(error.localizedDescription)"
            isLoading = false
        }
    }
}

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, visionOS 2.0, *)
struct SentimentView: View {
    @State var viewModel = SentimentViewModel() // Initialize the observable view model

    var body: some View {
        VStack {
            TextField("Enter text here...", text: $viewModel.inputText)
                .textFieldStyle(.roundedBorder)
                .padding()

            if viewModel.isLoading {
                ProgressView()
            } else {
                Text("Sentiment: \(viewModel.predictedSentiment)")
                    .font(.headline)
                    .padding()
            }
        }
    }
}
