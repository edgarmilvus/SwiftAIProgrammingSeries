
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 11.0, macOS 10.13, tvOS 11.0, watchOS 4.0, *)
func extractRankedKeywords(from text: String) -> [(keyword: String, frequency: Int)] {
    let stopWords: Set<String> = [
        "a", "an", "the", "is", "are", "was", "were", "and", "or", "but", "for", "nor", "so", "yet",
        "at", "by", "in", "of", "on", "to", "with", "from", "into", "during", "through", "above", "below",
        "up", "down", "out", "off", "over", "under", "again", "further", "then", "once", "here", "there",
        "when", "where", "why", "how", "all", "any", "both", "each", "few", "more", "most", "other", "some",
        "such", "no", "not", "only", "own", "same", "so", "than", "too", "very", "s", "t", "can", "will",
        "just", "don", "should", "now", "about", "this", "that", "it", "he", "she", "we", "they", "i", "you",
        "me", "him", "her", "us", "them", "my", "your", "his", "her", "its", "our", "their", "what", "which",
        "who", "whom", "whose", "if", "because", "as", "until", "while", "though", "although", "since", "before",
        "after", "while", "where", "when", "why", "how", "however", "therefore", "thus", "consequently",
        "meanwhile", "also", "many", "much", "much", "would", "could", "may", "might", "must", "these", "those"
    ]
    
    var keywordFrequencies: [String: Int] = [:]
    
    let tagger = NLTagger(tagSchemes: [.lexicalClass, .lemma])
    tagger.string = text
    
    let fullRange = text.startIndex..<text.endIndex
    
    tagger.enumerateTags(in: fullRange, unit: .word, scheme: .lexicalClass, options: [.omitWhitespace, .omitPunctuation]) { lexicalClassTag, tokenRange, stop in
        guard let lexicalClassTag = lexicalClassTag,
              let tokenRange = tokenRange else { return true }
        
        // 1. Check if the lexical class is a noun or adjective
        if lexicalClassTag == .noun || lexicalClassTag == .adjective || lexicalClassTag == .properNoun {
            // 2. Retrieve the lemma for the token
            let lemmaTag = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .lemma)?.0
            
            if let lemma = lemmaTag?.rawValue.lowercased() {
                // 3. Exclude common stop words
                if !stopWords.contains(lemma) {
                    // 4. Increment frequency
                    keywordFrequencies[lemma, default: 0] += 1
                }
            }
        }
        return true // Continue enumeration
    }
    
    // Convert to array of tuples and sort by frequency
    return keywordFrequencies.map { (keyword: $0.key, frequency: $0.value) }
                             .sorted { $0.frequency > $1.frequency }
}
