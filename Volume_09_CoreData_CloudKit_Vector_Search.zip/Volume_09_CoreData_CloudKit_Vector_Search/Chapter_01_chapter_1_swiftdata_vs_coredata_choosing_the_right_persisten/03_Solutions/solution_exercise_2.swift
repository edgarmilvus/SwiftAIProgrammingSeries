
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftData
import Foundation

@available(iOS 17.0, *)
@Model
final class Contact {
    var firstName: String
    var lastName: String
    var email: String
    var importanceScore: Double
    
    init(firstName: String, lastName: String, email: String, importanceScore: Double) {
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.importanceScore = importanceScore
    }
}

@available(iOS 17.0, *)
struct ContactFilteringEngine {
    
    /// Creates a type-safe predicate for filtering contacts.
    func makeContactPredicate(searchText: String, minScore: Double) -> Predicate<Contact> {
        // The #Predicate macro parses this closure at compile-time.
        return #Predicate<Contact> { contact in
            (contact.firstName.localizedStandardContains(searchText) || 
             contact.lastName.localizedStandardContains(searchText)) &&
            contact.importanceScore >= minScore
        }
    }
    
    /*
     TYPE SAFETY VERIFICATION:
     If I were to attempt the following:
     #Predicate<Contact> { contact in contact.phoneNumber == "555-1234" }
     
     The Swift compiler would throw an error: 
     "Value of type 'Contact' has no member 'phoneNumber'"
     
     This is impossible with NSPredicate(format: "phoneNumber == %@", ...), 
     which would only crash at runtime.
     */
}

/*
 COMPARISON ANALYSIS:
 
 1. Compile-Time Validation: NSPredicate uses string parsing. A typo in a property 
    name (e.g., "firtName") is a runtime crash. #Predicate uses the Swift compiler 
    to validate the expression tree against the actual properties of the Contact class.
 
 2. Expression Tree Translation: The #Predicate macro doesn't just run Swift code; 
    it transforms the logic into a specialized expression tree. This tree is then 
    translated by SwiftData into optimized SQL.
 
 3. Swift 6 Concurrency: Because Predicates are value-based and immutable, they 
    are inherently safer to pass across actor boundaries than complex, 
    mutable NSPredicate objects.
*/
