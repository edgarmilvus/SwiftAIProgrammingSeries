
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

import AVFoundation
import Speech
import NaturalLanguage
import Combine // For @Published and ObservableObject

/// Custom errors for speech recognition and NLP processing.
enum VoiceCommandError: Error, LocalizedError {
    case speechRecognizerNotAvailable
    case audioEngineSetupFailed(Error)
    case recognitionFailed(Error)
    case authorizationFailed
    case noAudioInput
    case commandParsingFailed(String)

    var errorDescription: String? {
        switch self {
        case .speechRecognizerNotAvailable:
            return "Speech recognition is not available on this device or locale."
        case .audioEngineSetupFailed(let error):
            return "Audio engine setup failed: \(error.localizedDescription)"
        case .recognitionFailed(let error):
            return "Speech recognition failed: \(error.localizedDescription)"
        case .authorizationFailed:
            return "Microphone or speech recognition authorization denied."
        case .noAudioInput:
            return "No audio input available."
        case .commandParsingFailed(let message):
            return "Failed to parse command: \(message)"
        }
    }
}

/// Manages speech recognition, natural language processing, and smart home action execution.
@available(iOS 18.0, *)
class VoiceCommandProcessor: NSObject, SFSpeechRecognizerDelegate, ObservableObject {

    // MARK: - Speech Recognition Properties

    /// The primary speech recognizer. Initialized for US English.
    private let speechRecognizer: SFSpeechRecognizer?
    /// Handles the audio input from the microphone.
    private var audioEngine: AVAudioEngine
    /// The request object that streams audio to the speech recognizer.
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    /// The task object that manages the speech recognition session.
    private var recognitionTask: SFSpeechRecognitionTask?
    /// A private queue for handling speech recognition tasks to avoid blocking the main thread.
    private let speechQueue = DispatchQueue(label: "com.example.VoiceCommandProcessor.speechQueue")

    // MARK: - Natural Language Processing Properties

    /// The Natural Language tagger for part-of-speech tagging.
    private let tagger: NLTagger
    /// The Natural Language tokenizer for breaking text into words.
    private let tokenizer: NLTokenizer

    // MARK: - Smart Home Integration

    /// The manager responsible for executing smart home actions.
    private let smartHomeManager: SmartHomeManaging

    // MARK: - UI State Properties

    /// Published property to inform UI about the current recognition status.
    @Published var isListening: Bool = false
    /// Published property for displaying partial or final recognized text.
    @Published var recognizedText: String = "Tap to start voice command."
    /// Published property for displaying the parsed command.
    @Published var parsedCommand: String = ""
    /// Published property for displaying any errors.
    @Published var errorMessage: String?

    // MARK: - Initialization

    /// Initializes the VoiceCommandProcessor.
    /// - Parameter smartHomeManager: An object conforming to `SmartHomeManaging` to execute commands.
    init(smartHomeManager: SmartHomeManaging) {
        self.smartHomeManager = smartHomeManager
        // Initialize speech recognizer for US English.
        self.speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        self.audioEngine = AVAudioEngine()
        self.tagger = NLTagger(tagSchemes: [.lexicalClass, .lemma])
        self.tokenizer = NLTokenizer(unit: .word)
        super.init()
        self.speechRecognizer?.delegate = self // Set self as the delegate for authorization changes.
    }

    // MARK: - Public Control Methods

    /// Starts the speech recognition process.
    /// - Throws: `VoiceCommandError` if setup or authorization fails.
    func startRecording() async throws {
        // Ensure only one recognition task is active at a time.
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }

        // 3. Handle Speech Recognition Authorization
        let authorizationStatus = await SFSpeechRecognizer.requestAuthorization()
        guard authorizationStatus == .authorized else {
            throw VoiceCommandError.authorizationFailed
        }

        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            throw VoiceCommandError.speechRecognizerNotAvailable
        }

        // Configure audio session for recording.
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            throw VoiceCommandError.audioEngineSetupFailed(error)
        }

        // Create a new recognition request.
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            throw VoiceCommandError.noAudioInput
        }
        recognitionRequest.shouldReportPartialResults = true // Enable partial results for real-time feedback.

        // Setup audio engine for microphone input.
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer) // Append audio buffers to the recognition request.
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            throw VoiceCommandError.audioEngineSetupFailed(error)
        }

        // 5. Process Speech Recognition Results
        // Start the recognition task on a background queue.
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            var isFinal = false
            if let result = result {
                self.recognizedText = result.bestTranscription.formattedString
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0) // Remove tap to prevent memory leaks.
                self.recognitionRequest = nil
                self.recognitionTask = nil
                self.isListening = false

                if let error = error {
                    self.errorMessage = VoiceCommandError.recognitionFailed(error).localizedDescription
                } else if isFinal {
                    // Process the final recognized text using NLP.
                    Task {
                        await self.processCommand(self.recognizedText)
                    }
                }
            }
        }

        isListening = true
        recognizedText = "Listening..."
        parsedCommand = ""
        errorMessage = nil
    }

    /// Stops the speech recognition process.
    func stopRecording() {
        audioEngine.stop()
        recognitionRequest?.endAudio()
        recognitionTask?.cancel() // Cancel the task if not already final.
        recognitionTask = nil
        recognitionRequest = nil
        isListening = false
        recognizedText = "Recognition stopped."
    }

    // MARK: - SFSpeechRecognizerDelegate

    /// Called when the availability of the speech recognizer changes.
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if !available {
            self.errorMessage = VoiceCommandError.speechRecognizerNotAvailable.localizedDescription
            stopRecording() // Stop if recognizer becomes unavailable.
        }
    }

    // MARK: - Natural Language Processing & Command Parsing

    /// Processes the recognized speech text to extract intent and entities.
    /// This method runs on a background thread using `Task`.
    /// - Parameter commandText: The raw text recognized by the speech engine.
    private func processCommand(_ commandText: String) async {
        guard !commandText.isEmpty else {
            await MainActor.run {
                self.parsedCommand = "No command recognized."
                self.errorMessage = nil
            }
            return
        }

        await MainActor.run {
            self.parsedCommand = "Processing: \"\(commandText)\"..."
        }

        do {
            // 6. Natural Language Processing (NLP) for Intent and Entity Extraction
            // Perform NLP on a background thread.
            let action = try await Task.detached(priority: .userInitiated) { [weak self] () -> SmartHomeAction in
                guard let self = self else { throw VoiceCommandError.commandParsingFailed("Processor deallocated.") }
                return try self.parseCommand(commandText)
            }.value

            await MainActor.run {
                self.parsedCommand = "Identified: \(action.description)"
            }

            // 8. Execute Smart Home Action
            let result = try await smartHomeManager.execute(action: action)
            await MainActor.run {
                self.parsedCommand = result
                self.errorMessage = nil
            }
        } catch let error as SmartHomeError {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
                self.parsedCommand = "Command failed."
            }
        } catch let error as VoiceCommandError {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
                self.parsedCommand = "Command parsing failed."
            }
        } catch {
            await MainActor.run {
                self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                self.parsedCommand = "Command failed."
            }
        }
    }

    /// Parses the raw command string into a `SmartHomeAction` using NLP.
    /// This is the core of the advanced application logic.
    /// - Parameter command: The recognized speech text.
    /// - Returns: A `SmartHomeAction` representing the user's intent.
    /// - Throws: `SmartHomeError.parsingError` if the command cannot be understood.
    private func parseCommand(_ command: String) throws -> SmartHomeAction {
        // Normalize the command for easier parsing (lowercase, trim whitespace).
        let normalizedCommand = command.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)

        tokenizer.string = normalizedCommand
        var tokens: [String] = []
        tokenizer.enumerateTokens(in: normalizedCommand.startIndex..<normalizedCommand.endIndex) { tokenRange, _ in
            tokens.append(String(normalizedCommand[tokenRange]))
            return true
        }

        // Apply NLTagger for part-of-speech tagging if more complex parsing is needed.
        // For this example, we'll use a simpler token-based matching combined with regex.
        // tagger.string = normalizedCommand
        // let tags = tagger.tags(in: normalizedCommand.startIndex..<normalizedCommand.endIndex, unit: .word, scheme: .lexicalClass, options: .omitWhitespace)

        // --- Custom Rule-Based Parsing ---

        // Helper to find a room in the command
        func findRoom(in tokens: [String]) -> SmartHomeRoom? {
            for room in SmartHomeRoom.allCases {
                if normalizedCommand.contains(room.rawValue.lowercased()) {
                    return room
                }
            }
            return nil
        }

        // Helper to extract a numerical value (integer or double) from a string
        func extractNumber(from text: String) -> Double? {
            // Look for numbers like "22", "twenty-two", "thirty percent", "halfway"
            let numberFormatter = NumberFormatter()
            numberFormatter.locale = Locale(identifier: "en-US") // Ensure consistent parsing

            if let number = numberFormatter.number(from: text)?.doubleValue {
                return number
            }

            // Handle "halfway"
            if text.contains("halfway") { return 0.5 }

            // Handle "X percent"
            if let match = text.firstMatch(of: /(\d+)\s*percent/) {
                if let percentage = Double(match.1) {
                    return percentage / 100.0
                }
            }
            // Handle "X degrees"
            if let match = text.firstMatch(of: /(\d+)\s*degrees?/) {
                if let temperature = Double(match.1) {
                    return temperature
                }
            }

            return nil
        }

        // --- Intent: Set Light ---
        if normalizedCommand.contains("turn") && normalizedCommand.contains("light") {
            let room = findRoom(in: tokens) ?? .all // Default to 'all' if no specific room.
            if normalizedCommand.contains("on") {
                return .setLight(room: room, on: true)
            } else if normalizedCommand.contains("off") {
                return .setLight(room: room, on: false)
            } else if normalizedCommand.contains("dim") || normalizedCommand.contains("brightness") {
                if let brightness = extractNumber(from: normalizedCommand) {
                    return .setLightBrightness(room: room, brightness: brightness)
                }
            }
        }

        // --- Intent: Set Thermostat ---
        if normalizedCommand.contains("set") && normalizedCommand.contains("thermostat") {
            let room = findRoom(in: tokens) ?? .livingRoom // Default room for thermostat
            if let temperature = extractNumber(from: normalizedCommand) {
                return .setThermostat(room: room, temperature: temperature)
            }
        }

        // --- Intent: Set Blinds ---
        if normalizedCommand.contains("open") || normalizedCommand.contains("close") && normalizedCommand.contains("blinds") {
            let room = findRoom(in: tokens) ?? .livingRoom // Default room for blinds
            if normalizedCommand.contains("open") && normalizedCommand.contains("halfway") {
                return .setBlinds(room: room, position: 0.5)
            } else if normalizedCommand.contains("open") && normalizedCommand.contains("fully") {
                 return .setBlinds(room: room, position: 1.0)
            } else if normalizedCommand.contains("close") && normalizedCommand.contains("fully") {
                return .setBlinds(room: room, position: 0.0)
            } else if normalizedCommand.contains("open") {
                if let position = extractNumber(from: normalizedCommand) { // e.g., "open blinds to 70 percent"
                    return .setBlinds(room: room, position: position)
                }
                return .setBlinds(room: room, position: 1.0) // Default to fully open if just "open"
            } else if normalizedCommand.contains("close") {
                return .setBlinds(room: room, position: 0.0) // Default to fully closed if just "close"
            }
        }

        // --- Intent: Query Temperature ---
        if normalizedCommand.contains("what's") && normalizedCommand.contains("temperature") {
            let room = findRoom(in: tokens) ?? .masterBedroom // Default room for temperature query
            return .queryTemperature(room: room)
        }

        // If no specific action is matched, return an unknown command.
        return .unknown(command: command)
    }
}
