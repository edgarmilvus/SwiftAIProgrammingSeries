
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Observation

@available(iOS 18.0, *)
enum ReportReason: String, CaseIterable, Identifiable, Sendable {
    case hateSpeech = "Hate Speech"
    case harassment = "Harassment"
    case misinformation = "Misinformation"
    case bias = "Bias"
    case other = "Other"
    
    var id: String { self.rawValue }
}

struct AIResponse: Identifiable, Sendable {
    let id: UUID
    let text: String
    var isReported: Bool = false
}

/// Actor ensures that multiple rapid report attempts are handled serially and safely.
actor ReportService {
    func submitReport(contentID: UUID, reason: ReportReason) async throws {
        // Simulate network latency
        try await Task.sleep(for: .seconds(1.5))
        print("Successfully reported \(contentID) for \(reason.rawValue)")
    }
}

@Observable
@MainActor
class ChatViewModel {
    var messages: [AIResponse] = [
        AIResponse(id: UUID(), text: "Hello! I am your AI assistant."),
        AIResponse(id: UUID(), text: "This is a potentially problematic response."),
        AIResponse(id: UUID(), text: "I can help you with coding.")
    ]
    
    private let reportService = ReportService()
    var isReporting = false
    
    func reportMessage(_ messageID: UUID, reason: ReportReason) {
        // 1. Optimistic UI: Immediately dim the message
        if let index = messages.firstIndex(where: { $0.id == messageID }) {
            messages[index].isReported = true
        }
        
        // 2. Detached Task for background network work
        Task {
            do {
                try await reportService.submitReport(contentID: messageID, reason: reason)
            } catch {
                print("Failed to report: \(error)")
                // Rollback UI if necessary in a real app
            }
        }
    }
}

struct ReportingView: View {
    let messageID: UUID
    let onReport: (ReportReason) -> Void
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            List(ReportReason.allCases) { reason in
                Button(reason.rawValue) {
                    onReport(reason)
                    dismiss()
                }
            }
            .navigationTitle("Report Content")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct ChatView: View {
    @State private var viewModel = ChatViewModel()
    @State private var selectedMessageID: UUID?
    
    var body: some View {
        NavigationStack {
            List(viewModel.messages) { message in
                HStack {
                    Text(message.text)
                        .opacity(message.isReported ? 0.4 : 1.0)
                        .italic(message.isReported)
                    
                    Spacer()
                    
                    if !message.isReported {
                        Button(action: { selectedMessageID = message.id }) {
                            Image(systemName: "flag")
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("ChatMind")
            .sheet(item: Binding(
                get: { selectedMessageID.map { IdentifiableID(id: $0) } },
                set: { selectedMessageID = $0?.id }
            )) { item in
                ReportingView(messageID: item.id) { reason in
                    viewModel.reportMessage(item.id, reason: reason)
                }
            }
        }
    }
}

// Helper for sheet identification
struct IdentifiableID: Identifiable {
    let id: UUID
}
