/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part6.ts
// Description: Advanced Application Script
// ==========================================

// packages/shared/hooks/useAnalytics.ts

import { useState, useEffect } from 'react';
import { fetchAnalyticsData } from '../api/client';
import { AnalyticsDataPoint, AnalyticsConfig } from '../types/analytics';

/**
 * @description A universal hook to fetch and manage analytics data.
 * It handles loading states, errors, and data refreshing.
 * 
 * @param config - Configuration object for the API.
 * @returns An object containing data, loading state, and error state.
 */
export const useAnalytics = (config: AnalyticsConfig) => {
  const [data, setData] = useState<AnalyticsDataPoint[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // The fetchAnalyticsData function works identically on Web and Native
        // because it uses the universal wrapper.
        const result = await fetchAnalyticsData(config);
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setIsLoading(false);
      }
    };

    loadData();

    // Optional: Setup polling if needed (using setInterval)
    // Note: In Next.js Server Components, useEffect doesn't run. 
    // This hook is designed for Client Components (Web) and Components (Native).
    if (config.refreshInterval) {
      const interval = setInterval(loadData, config.refreshInterval);
      return () => clearInterval(interval);
    }

  }, [config]);

  return { data, isLoading, error };
};
