
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import MLX

// Re-using TokenizerProtocol from Exercise 1
protocol TokenizerProtocol: Sendable {
    func tokenize(text: String) -> [Int]
    func detokenize(ids: [Int]) -> String
    var eosTokenID: Int { get }
}

// Re-using MockTokenizer from Exercise 1
class MockTokenizer: TokenizerProtocol {
    let vocab: [String: Int]
    let reverseVocab: [Int: String]
    let eosTokenID: Int

    init(vocab: [String: Int], eosTokenID: Int) {
        self.vocab = vocab
        self.reverseVocab = vocab.reduce(into: [:]) { $0[$1.value] = $1.key }
        self.eosTokenID = eosTokenID
    }

    func tokenize(text: String) -> [Int] {
        // More granular tokenization for code completion
        return text.map { String($0) }.compactMap { vocab[$0] }
    }

    func detokenize(ids: [Int]) -> String {
        return ids.compactMap { reverseVocab[$0] }.joined() // No spaces for code
    }
}

// MARK: - MLX Model Mock with KV Cache

// A conceptual representation of MLX's KV cache state.
// In a real MLX model, this would be a tuple of MLXArray (key, value) tensors for each attention layer.
typealias KVCacheState = [(MLXArray, MLXArray)]

protocol MLXCodeCompletionModelProtocol: Sendable {
    func generate(
        inputIDs: MLXArray,
        maxTokens: Int,
        temperature: Float,
        previousKVCache: KVCacheState?,
        tokenizer: TokenizerProtocol,
        startPosition: Int // New: indicates where new tokens start relative to previousKVCache
    ) async throws -> AsyncThrowingStream<(MLXArray, KVCacheState), Error> // Yields token and updated full cache
    var name: String { get }
}

class MockMLXCodeCompletionModel: MLXCodeCompletionModelProtocol {
    let name: String = "Mock-CodeLlama"
    let eosTokenID: Int

    init(eosTokenID: Int) {
        self.eosTokenID = eosTokenID
    }

    func generate(
        inputIDs: MLXArray,
        maxTokens: Int,
        temperature: Float,
        previousKVCache: KVCacheState?,
        tokenizer: TokenizerProtocol,
        startPosition: Int
    ) async throws -> AsyncThrowingStream<(MLXArray, KVCacheState), Error> {
        return AsyncThrowingStream { continuation in
            Task {
                let promptString = tokenizer.detokenize(ids: inputIDs.data.map { $0.item(Int.self)! })
                
                // Simulate different completions based on input
                let completions: [String: [String]] = [
                    "func": ["tion", " ", "my", "Function", "(", ")", " ", "{", "\n", "    ", "return", " ", "0", "\n", "}"],
                    "let": [" ", "my", "Var", " ", "=", " ", "10"],
                    "import": [" ", "Foundation"],
                    "class": [" ", "MyClass", " ", "{", "\n", "}"],
                    "if": [" ", "condition", " ", "{", "\n", "}"],
                    "pri": ["nt"]
                ]

                var responseTokens: [Int] = []
                if let matchedCompletion = completions.first(where: { promptString.lowercased().hasSuffix($0.key) }) {
                    responseTokens = tokenizer.tokenize(text: matchedCompletion.value.joined())
                } else {
                    // Default behavior if no specific match
                    responseTokens = tokenizer.tokenize(text: " ") // Just a space
                }
                
                // Simulate KV cache updates. For a mock, we'll just return a dummy cache.
                // In a real MLX model, the generate function would compute and return the new KV cache.
                var currentMockKVCache = previousKVCache ?? []
                // Append dummy cache entries for new tokens (conceptual)
                for _ in startPosition..<inputIDs.count + responseTokens.count {
                    currentMockKVCache.append((MLXArray(0), MLXArray(0))) // Dummy (key, value)
                }

                for tokenID in responseTokens {
                    try await Task.sleep(for: .milliseconds(20)) // Simulate low-latency token generation
                    continuation.yield((MLXArray(scalar: tokenID), currentMockKVCache))
                    // Update currentMockKVCache to reflect the state *after* this token
                    // (This is a simplified mock; real MLX would handle this internally)
                }
                
                try await Task.sleep(for: .milliseconds(20))
                continuation.yield((MLXArray(scalar: self.eosTokenID), currentMockKVCache))
                
                continuation.finish()
            }
        }
    }
}

// MARK: - Code Completion Engine Logic

enum CodeCompletionError: Error, LocalizedError {
    case modelNotLoaded
    case tokenizerNotLoaded
    case inferenceFailed(String)
    
    var errorDescription: String? {
        switch self {
        case .modelNotLoaded: return "Code completion model not loaded."
        case .tokenizerNotLoaded: return "Tokenizer not loaded."
        case .inferenceFailed(let msg): return "Code completion inference failed: \(msg)"
        }
    }
}

@available(macOS 14.0, *)
@Observable
class CodeCompletionEngine {
    private var model: (any MLXCodeCompletionModelProtocol)?
    private var tokenizer: (any TokenizerProtocol)?

    // State for KV cache management
    private var lastInputTokens: [Int] = []
    private var currentKVCacheState: KVCacheState? // The KV cache corresponding to `lastInputTokens`
    private var currentCompletionTask: Task<Void, Never>? // To cancel previous completion tasks

    var currentPrompt: String = "" {
        didSet {
            // Debounce input to avoid excessive computation
            debounceInput()
        }
    }
    var currentSuggestion: String = ""
    var isLoadingCompletion: Bool = false
    var errorMessage: String?

    init() {
        let mockVocab: [String: Int] = [
            "f": 1, "u": 2, "n": 3, "c": 4, "t": 5, "i": 6, "o": 7, "m": 8, "y": 9, "(": 10, ")": 11, "{": 12, "}": 13, "\n": 14, " ": 15, "l": 16, "e": 17, "v": 18, "a": 19, "r": 20, "=": 21, "1": 22, "0": 23, "I": 24, "F": 25, "d": 26, "c": 27, "p": 28, "r": 29, "n": 30, "s": 31, "C": 32, "H": 33, "s": 34, "i": 35, "o": 36, "d": 37,
            "<|eos|>": 1000
        ]
        let eosTokenID = mockVocab["<|eos|>"]!
        self.tokenizer = MockTokenizer(vocab: mockVocab, eosTokenID: eosTokenID)
        self.model = MockMLXCodeCompletionModel(eosTokenID: eosTokenID)
    }

    func loadModelAndTokenizer() async {
        isLoadingCompletion = true
        errorMessage = nil
        do {
            try await Task.sleep(for: .seconds(1))
            guard self.model != nil && self.tokenizer != nil else {
                throw CodeCompletionError.modelNotLoaded
            }
            print("Code completion model and tokenizer loaded.")
        } catch {
            errorMessage = error.localizedDescription
            print("Error loading model/tokenizer: \(error.localizedDescription)")
        }
        isLoadingCompletion = false
    }

    private func debounceInput() {
        currentCompletionTask?.cancel() // Cancel any previous pending task
        currentCompletionTask = Task.detached { [weak self] in
            guard let self = self else { return }
            do {
                try await Task.sleep(for: .milliseconds(100)) // Debounce time
                guard !Task.isCancelled else { return }
                await self.generateCompletionsInternal(for: self.currentPrompt)
            } catch {
                // Handle cancellation or other errors
                if Task.isCancelled {
                    print("Completion task cancelled.")
                } else {
                    await MainActor.run {
                        self.errorMessage = error.localizedDescription
                    }
                }
            }
        }
    }

    @MainActor
    private func generateCompletionsInternal(for inputCode: String) async {
        guard let model = self.model, let tokenizer = self.tokenizer else {
            self.errorMessage = CodeCompletionError.modelNotLoaded.localizedDescription
            return
        }

        isLoadingCompletion = true
        currentSuggestion = ""
        errorMessage = nil

        do {
            let newTokenIDs = tokenizer.tokenize(text: inputCode)
            
            // --- KV Cache Management Logic ---
            var kvCacheToUse: KVCacheState? = nil
            var startPositionForInference = 0 // Index in newTokenIDs where new inference starts

            if let previousCache = currentKVCacheState, !lastInputTokens.isEmpty {
                // Find the longest common prefix
                var commonPrefixLength = 0
                for i in 0..<min(lastInputTokens.count, newTokenIDs.count) {
                    if lastInputTokens[i] == newTokenIDs[i] {
                        commonPrefixLength += 1
                    } else {
                        break
                    }
                }
                
                if commonPrefixLength > 0 {
                    // Reuse KV cache for the common prefix.
                    // This is a conceptual snippet. In a real MLX model, the KV cache
                    // is typically a list of (key, value) tensors per layer.
                    // We'd need to slice or truncate these tensors to `commonPrefixLength`.
                    // The mock KV cache is just a dummy array for this example.
                    kvCacheToUse = previousCache.prefix(commonPrefixLength).map { $0 } // Truncate
                    startPositionForInference = commonPrefixLength
                    print("Reusing KV cache for prefix length: \(commonPrefixLength)")
                } else {
                    // No common prefix, recompute from scratch
                    print("No common prefix, recomputing KV cache.")
                }
            } else {
                print("No previous KV cache, starting from scratch.")
            }

            let inputMLXArray = MLXArray(newTokenIDs)
            
            let streamingTokensWithCache = try await model.generate(
                inputIDs: inputMLXArray,
                maxTokens: 50,
                temperature: 0.5,
                previousKVCache: kvCacheToUse,
                tokenizer: tokenizer,
                startPosition: startPositionForInference
            )
            
            var generatedText = ""
            var lastFullKVCache: KVCacheState? = nil

            for try await (tokenIDArray, updatedKVCache) in streamingTokensWithCache {
                guard !Task.isCancelled else {
                    print("Completion stream cancelled.")
                    isLoadingCompletion = false
                    return
                }
                
                guard let tokenID = tokenIDArray.item(Int.self) else { continue }
                if tokenID == tokenizer.eosTokenID { break }

                let newToken = tokenizer.detokenize(ids: [tokenID])
                generatedText += newToken
                
                await MainActor.run {
                    self.currentSuggestion = generatedText
                }
                
                lastFullKVCache = updatedKVCache // Capture the latest KV cache state
                
                // Heuristic for stopping completions (e.g., whitespace, punctuation, or full word)
                // For code, we might stop on ` ` `(` `{` `\n` or keywords
                if newToken == " " || newToken == "(" || newToken == "{" || newToken == "\n" {
                    break
                }
            }
            
            // Update the stored KV cache and input tokens for the next round
            self.lastInputTokens = newTokenIDs + tokenizer.tokenize(text: generatedText) // Full sequence
            self.currentKVCacheState = lastFullKVCache
            
            print("Completion finished for: '\(inputCode)' -> '\(currentSuggestion)'")

        } catch {
            if Task.isCancelled {
                print("Completion generation cancelled due to new input.")
            } else {
                errorMessage = CodeCompletionError.inferenceFailed(error.localizedDescription).localizedDescription
                print("Error generating completion: \(error.localizedDescription)")
            }
        }
        isLoadingCompletion = false
    }
}

// MARK: - Conceptual Usage

@available(macOS 14.0, *)
@MainActor
func runCodeCompletionExample() {
    let engine = CodeCompletionEngine()
    
    Task {
        await engine.loadModelAndTokenizer()
    }

    Task {
        try await Task.sleep(for: .seconds(2))
        print("\n--- Simulating Code Completion ---")
        
        print("\nUser types: f")
        engine.currentPrompt = "f"
        try await Task.sleep(for: .milliseconds(200)) // Simulate typing delay
        print("Suggestion: \(engine.currentSuggestion)")

        print("\nUser types: fu")
        engine.currentPrompt = "fu"
        try await Task.sleep(for: .milliseconds(200))
        print("Suggestion: \(engine.currentSuggestion)")

        print("\nUser types: func")
        engine.currentPrompt = "func"
        try await Task.sleep(for: .milliseconds(200))
        print("Suggestion: \(engine.currentSuggestion)")

        print("\nUser types: let")
        engine.currentPrompt = "let"
        try await Task.sleep(for: .milliseconds(500)) // Longer delay to see full completion
        print("Suggestion: \(engine.currentSuggestion)")
        
        print("\nUser types: let myVar = 1")
        engine.currentPrompt = "let myVar = 1"
        try await Task.sleep(for: .milliseconds(500))
        print("Suggestion: \(engine.currentSuggestion)")

        print("\nUser types: class")
        engine.currentPrompt = "class"
        try await Task.sleep(for: .milliseconds(500))
        print("Suggestion: \(engine.currentSuggestion)")

        print("\nUser types: pri")
        engine.currentPrompt = "pri"
        try await Task.sleep(for: .milliseconds(500))
        print("Suggestion: \(engine.currentSuggestion)")

        print("\nUser backspaces: pr") // Simulate backspace
        let originalPrompt = engine.currentPrompt
        engine.currentPrompt = String(originalPrompt.dropLast())
        try await Task.sleep(for: .milliseconds(500))
        print("Suggestion: \(engine.currentSuggestion)")
        
        print("\n--- Final State ---")
        print("Last input tokens count: \(engine.lastInputTokens.count)")
        print("KV Cache state (conceptual): \(engine.currentKVCacheState != nil ? "Available" : "Not Available")")
    }
}

// Call this to run the conceptual example
// runCodeCompletionExample()
