
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI

// 1. Data Model: Represents the specific instrument
struct FinancialInstrument: Hashable, Codable, Sendable {
    let id: UUID
    let name: String
    let symbol: String
}

// 2. State Management: Using @Observable (Swift 6 standard)
@Observable
@MainActor
class DashboardViewModel {
    var instruments: [FinancialInstrument] = [
        FinancialInstrument(id: UUID(), name: "Bitcoin", symbol: "BTC"),
        FinancialInstrument(id: UUID(), name: "S&P 500", symbol: "SPX"),
        FinancialInstrument(id: UUID(), name: "Gold", symbol: "XAU")
    ]
}

// 3. The Main Control Center Window
struct ControlCenterView: View {
    @State private var viewModel = DashboardViewModel()
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        NavigationStack {
            List(viewModel.instruments, id: \.id) { instrument in
                HStack {
                    Text(instrument.name)
                    Spacer()
                    Button("Monitor") {
                        // Spawning a window with a specific identifier and data
                        openWindow(id: "telemetry", value: instrument)
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
            .navigationTitle("QuantView Control")
        }
        .frame(width: 400, height: 500)
    }
}

// 4. The Telemetry Window (The spawned instance)
struct TelemetryView: View {
    let instrument: FinancialInstrument
    
    // State is local to this window instance, ensuring isolation
    @State private var timeInterval: String = "1m"

    var body: some View {
        VStack(spacing: 20) {
            Text("\(instrument.name) (\(instrument.symbol))")
                .font(.largeTitle)
            
            // Placeholder for a complex chart
            RoundedRectangle(cornerRadius: 12)
                .fill(.ultraThinMaterial)
                .overlay(Text("Real-time Chart Data").foregroundStyle(.secondary))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            Picker("Interval", selection: $timeInterval) {
                Text("1m").tag("1m")
                Text("5m").tag("5m")
                Text("1h").tag("1h")
            }
            .pickerStyle(.segmented)
            .padding()
        }
        .padding()
        // Setting a fixed aspect ratio via frame constraints
        .frame(width: 600, height: 337) // 16:9 ratio
    }
}

// 5. The App Entry Point
@main
struct QuantViewApp: App {
    var body: some Scene {
        // Primary Window
        WindowGroup {
            ControlCenterView()
        }

        // Parameterized WindowGroup for telemetry
        // The 'for' parameter allows passing the FinancialInstrument
        WindowGroup(id: "telemetry", for: FinancialInstrument.self) { $instrument in
            if let instrument = instrument {
                TelemetryView(instrument: instrument)
            }
        }
        .windowStyle(.plain) // High-density data display style
    }
}
