
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
/// Main application entry point for demonstration.
@main
struct MeetingAssistantApp {
    static func main() async {
        let llmService = MockLLMService()
        let processor = MeetingAssistantProcessor(llmService: llmService)

        // --- Test Case 1: Perfectly Valid JSON Output ---
        print("--- Running Test Case 1: Valid JSON ---")
        let validTranscript = "Meeting transcript for Q3 Product Strategy Review."
        do {
            let summary = try await processor.processMeetingTranscript(transcript: validTranscript)
            print("Parsed Meeting Title: \(summary.meetingTitle)")
            print("Summary: \(summary.summary)")
            print("Action Items (\(summary.actionItems.count)):")
            for item in summary.actionItems {
                print("- \(item.description) (Assigned to: \(item.assignedTo), Due: \(item.dueDate?.formatted(date: .numeric, time: .omitted) ?? "N/A"))")
            }
            print("Follow up required: \(summary.followUpRequired)\n")
        } catch {
            print("Error processing valid transcript: \(error.localizedDescription)\n")
        }

        // --- Test Case 2: Malformed Date and Alternate Key ('assignee') ---
        print("--- Running Test Case 2: Malformed Date & Alternate Key ---")
        let malformedDateTranscript = "Meeting transcript with malformed date."
        do {
            let summary = try await processor.processMeetingTranscript(transcript: malformedDateTranscript)
            print("Parsed Meeting Title: \(summary.meetingTitle)")
            print("Summary: \(summary.summary)")
            print("Action Items (\(summary.actionItems.count)):")
            for item in summary.actionItems {
                print("- \(item.description) (Assigned to: \(item.assignedTo), Due: \(item.dueDate?.formatted(date: .numeric, time: .omitted) ?? "N/A"))")
            }
            print("Follow up required: \(summary.followUpRequired)\n")
        } catch {
            print("Error processing malformed date transcript: \(error.localizedDescription)\n")
        }
        
        // --- Test Case 3: Alternate Top-Level Key ('title' instead of 'meetingTitle') ---
        print("--- Running Test Case 3: Alternate Top-Level Key ---")
        let alternateKeyTranscript = "Meeting transcript with missing key title."
        do {
            let summary = try await processor.processMeetingTranscript(transcript: alternateKeyTranscript)
            print("Parsed Meeting Title: \(summary.meetingTitle)")
            print("Summary: \(summary.summary)")
            print("Action Items (\(summary.actionItems.count)):")
            for item in summary.actionItems {
                print("- \(item.description) (Assigned to: \(item.assignedTo), Due: \(item.dueDate?.formatted(date: .numeric, time: .omitted) ?? "N/A"))")
            }
            print("Follow up required: \(summary.followUpRequired)\n")
        } catch {
            print("Error processing alternate key transcript: \(error.localizedDescription)\n")
        }

        // --- Test Case 4: LLM Returns Non-JSON Output (Error Handling) ---
        print("--- Running Test Case 4: Non-JSON Output ---")
        let errorTranscript = "Meeting transcript error simulation."
        do {
            _ = try await processor.processMeetingTranscript(transcript: errorTranscript)
        } catch {
            print("Successfully caught expected error for non-JSON output: \(error.localizedDescription)\n")
        }
    }
}
