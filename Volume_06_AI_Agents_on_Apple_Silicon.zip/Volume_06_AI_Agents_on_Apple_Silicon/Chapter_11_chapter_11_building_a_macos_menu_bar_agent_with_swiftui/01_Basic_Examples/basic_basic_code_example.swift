
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import AppKit // Required for NSApplication.shared.terminate

/// The main application entry point for our Quick AI Prompt Agent.
/// This struct conforms to the `App` protocol, defining the application's structure.
@main
struct QuickPromptAgentApp: App {
    // No explicit window group is defined, as this is primarily a menu bar app.
    // The content will be presented via MenuBarExtra.

    var body: some Scene {
        // 1. Define the MenuBarExtra: This is the core of our menu bar agent.
        // It specifies the text/icon to display in the menu bar and the content
        // to show when clicked.
        MenuBarExtra("QuickPrompt", systemImage: "sparkle.magnifyingglass") {
            // 2. Content View for the Menu Bar Extra:
            // This is the SwiftUI view that appears as a popover when the
            // menu bar item is clicked.
            PromptInputView()
        }
        // Optional: Hide the app from the Dock and Cmd+Tab switcher.
        // For a true menu bar agent, this is typically desired.
        // This setting is usually done in Info.plist (Application is agent (UIElement) = YES)
        // but can also be influenced programmatically for specific scenarios.
        // For this basic example, we rely on the Info.plist method for a clean agent.
    }
}

/// A SwiftUI view that provides an input field for prompts and displays the last submitted one.
/// It simulates an AI processing step to demonstrate async UI updates.
struct PromptInputView: View {
    /// The text currently entered in the prompt input field.
    @State private var promptText: String = ""
    /// Stores the last successfully submitted prompt.
    @State private var lastPrompt: String = "No prompt yet."
    /// A boolean to indicate if a prompt is currently being processed.
    @State private var isProcessing: Bool = false

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Quick AI Prompt Agent")
                .font(.headline)
                .padding(.bottom, 4)

            // 3. Prompt Input Field:
            // A TextField for the user to type their prompt.
            TextField("Type your prompt here...", text: $promptText)
                .textFieldStyle(.roundedBorder)
                .frame(width: 300) // Give it a fixed width for consistent popover size
                .autocorrectionDisabled() // Often desirable for code/commands

            // 4. Submit Button with Loading Indicator:
            // When clicked, it triggers an asynchronous processing task.
            Button {
                Task {
                    await processPrompt(promptText)
                }
            } label: {
                if isProcessing {
                    ProgressView() // Show a spinner during processing
                        .controlSize(.small)
                } else {
                    Text("Submit Prompt")
                }
            }
            .disabled(promptText.isEmpty || isProcessing) // Disable if empty or processing
            .buttonStyle(.borderedProminent) // Modern button style

            // 5. Display Last Prompt:
            // Shows the content of the last submitted prompt.
            Text("Last submitted: \(lastPrompt)")
                .font(.caption)
                .foregroundColor(.secondary)
                .padding(.top, 4)

            Divider() // Separator for visual clarity

            // 6. Quit Button:
            // Essential for menu bar apps that don't have a standard close button.
            Button("Quit QuickPrompt Agent") {
                NSApplication.shared.terminate(nil) // Terminates the application
            }
            .keyboardShortcut("q") // Allows quitting with Cmd+Q
            .buttonStyle(.plain) // Simple button style
        }
        .padding() // Add padding around the content
        .frame(minWidth: 350, minHeight: 180) // Ensure a reasonable popover size
    }

    /// Simulates an asynchronous prompt processing operation.
    /// In a real AI agent, this would involve calling an LLM or an inference engine.
    ///
    /// - Parameter prompt: The user's input prompt.
    @MainActor // 7. Crucial for updating UI after async work:
               // Ensures that state changes affecting the UI (like `isProcessing`,
               // `lastPrompt`, `promptText`) are performed on the main thread.
    private func processPrompt(_ prompt: String) async {
        isProcessing = true // Start processing, update UI to show spinner
        
        // Simulate an artificial delay for processing, like an LLM call.
        // In a real scenario, this would be where your llama.cpp or Ollama
        // inference call would happen.
        try? await Task.sleep(for: .seconds(1.5))

        // Update UI state once processing is complete.
        lastPrompt = prompt // Store the processed prompt
        promptText = ""     // Clear the input field
        isProcessing = false // End processing, hide spinner
    }
}
