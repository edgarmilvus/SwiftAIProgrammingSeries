
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import Foundation // In a real iOS 18 project, you would import Foundation.AI

// Reusing the MockAITextGenerator and AI alias from Exercise 1.
// In a real project, these would be defined once or imported from the framework.

enum WritingStyle: String, CaseIterable {
    case formal = "Formal"
    case casual = "Casual"
    case simplify = "Simplify Language"
    case elaborate = "Elaborate"
    case concise = "Make Concise"

    var systemImage: String {
        switch self {
        case .formal: return "person.text.rectangle"
        case .casual: return "hand.thumbsup"
        case .simplify: return "text.magnifyingglass"
        case .elaborate: return "text.badge.plus"
        case .concise: return "text.badge.minus"
        }
    }
    
    func prompt(for text: String) -> String {
        switch self {
        case .formal: return "Rewrite the following text in a formal and professional tone: '\(text)'"
        case .casual: return "Rewrite the following text in a casual and friendly tone: '\(text)'"
        case .simplify: return "Simplify the following text, making it much easier to understand for a general audience: '\(text)'"
        case .elaborate: return "Elaborate on the following text, adding more detail, context, and depth: '\(text)'"
        case .concise: return "Rewrite the following text to be as concise and to the point as possible, without losing essential meaning: '\(text)'"
        }
    }
}

class DynamicWritingStyleTransformerViewController: UIViewController, UITextViewDelegate {

    private lazy var textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = UIFont.preferredFont(forTextStyle: .body)
        tv.isEditable = true
        tv.isSelectable = true
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8.0
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        tv.text = "The nascent technological paradigm shift, characterized by the omnipresence of artificial intelligence and machine learning algorithms, portends a transformative impact on societal structures and economic frameworks. This profound evolution necessitates a re-evaluation of established methodologies and an adaptive posture towards emergent computational capabilities.\n\n(Select this text to transform its style.)"
        return tv
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Dynamic Style Transformer"
        view.backgroundColor = .systemBackground
        setupTextView()
    }

    private func setupTextView() {
        view.addSubview(textView)
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 300)
        ])
        textView.delegate = self
    }

    // MARK: - UITextViewDelegate

    @available(iOS 16.0, *)
    func textInput(_ textInput: UITextInput, menuElementsFor textRange: UITextRange, at point: CGPoint, sender: Any?) -> [UIMenuElement] {
        guard let textView = textInput as? UITextView else { return [] }

        guard let selectedText = textView.text(in: textRange), !selectedText.isEmpty else {
            return [] // No text selected
        }
        
        // Ensure the selection is not just a single character or too short for meaningful transformation
        if selectedText.count < 10 {
            return []
        }

        // Create UIAction elements for each writing style
        let styleActions: [UIAction] = WritingStyle.allCases.map { style in
            UIAction(title: style.rawValue, image: UIImage(systemName: style.systemImage)) { [weak self] _ in
                self?.transformTextStyle(for: selectedText, in: textRange, style: style)
            }
        }

        // Create a UIMenu to group the style transformation actions into a submenu
        let transformStyleMenu = UIMenu(
            title: "Transform Style",
            image: UIImage(systemName: "wand.and.stars"), // A magic wand icon
            children: styleActions
        )

        // Return the custom menu. You can combine it with default elements if desired.
        return [transformStyleMenu]
    }

    // MARK: - AI Integration

    private func transformTextStyle(for text: String, in textRange: UITextRange, style: WritingStyle) {
        // Feature availability check for iOS 18
        guard #available(iOS 18.0, *) else {
            self.showAlert(title: "Feature Unavailable", message: "This AI feature requires iOS 18 or later.")
            return
        }

        self.showLoadingAlert(message: "Transforming to \(style.rawValue)...")

        Task {
            do {
                let prompt = style.prompt(for: text) // Get the style-specific prompt
                let result = try await AI.TextGenerator.generate(prompt)
                
                DispatchQueue.main.async {
                    self.dismissLoadingAlert()
                    // Replace the selected text with the transformed version
                    self.textView.replace(textRange, withText: result.text)
                    // Optionally, keep the new text selected or move cursor
                    self.textView.selectedTextRange = nil
                }
            } catch {
                DispatchQueue.main.async {
                    self.dismissLoadingAlert()
                    self.showAlert(title: "Error", message: error.localizedDescription)
                }
            }
        }
    }

    // MARK: - UI Utility Functions (reused from Exercise 1)

    private var loadingAlert: UIAlertController?

    private func showLoadingAlert(message: String) {
        loadingAlert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        let indicator = UIActivityIndicatorView(style: .medium)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        loadingAlert?.view.addSubview(indicator)
        
        NSLayoutConstraint.activate([
            indicator.centerXAnchor.constraint(equalTo: loadingAlert!.view.centerXAnchor),
            indicator.centerYAnchor.constraint(equalTo: loadingAlert!.view.centerYAnchor, constant: 20)
        ])
        indicator.startAnimating()
        present(loadingAlert!, animated: true)
    }

    private func dismissLoadingAlert() {
        loadingAlert?.dismiss(animated: true)
        loadingAlert = nil
    }

    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
