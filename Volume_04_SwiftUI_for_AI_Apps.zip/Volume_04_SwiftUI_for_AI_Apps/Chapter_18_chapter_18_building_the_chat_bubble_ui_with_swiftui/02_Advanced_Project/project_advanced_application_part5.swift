
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

/// Represents a single message in the chat, which can consist of multiple content blocks.
/// This model is crucial for handling streaming updates where content arrives incrementally.
struct ChatMessage: Identifiable, Hashable {
    let id: UUID
    var content: [MessageContent] // A message can have multiple parts (e.g., text + tool call)
    let isUserMessage: Bool
    var isStreaming: Bool = false // True if the AI is currently generating this message
    
    // Initializer for user messages
    init(text: String, isUserMessage: Bool) {
        self.id = UUID()
        self.content = [.text(text)]
        self.isUserMessage = isUserMessage
    }
    
    // Initializer for AI messages (initially empty or with a placeholder)
    init(id: UUID, isUserMessage: Bool, isStreaming: Bool = false) {
        self.id = id
        self.content = []
        self.isUserMessage = isUserMessage
        self.isStreaming = isStreaming
    }
}
