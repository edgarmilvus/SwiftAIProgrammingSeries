/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// VectorSearchScreen.tsx
import React, { useState } from 'react';
import { View, TextInput, Button, FlatList, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { findSimilarVectors } from './database'; // Assume this is imported
import { VectorRecord } from './types';

// Mock function to simulate embedding generation
const mockGenerateEmbedding = (dimension: number = 384): number[] => {
  // Generate random floats between 0 and 1
  return Array.from({ length: dimension }, () => Math.random());
};

export default function VectorSearchScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Array<{ record: VectorRecord; similarity: number }>>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Note: In a real app, we would pass the database instance here
  // For this mock, we assume `findSimilarVectors` handles the DB connection internally
  const handleSearch = async () => {
    if (!searchQuery.trim()) return;

    setIsLoading(true);
    try {
      // 1. Generate the query vector
      const queryVector = mockGenerateEmbedding(384);
      
      // 2. Query the database
      // Assuming db instance is available globally or passed via context
      // For this exercise, we mock the call or assume a db instance exists
      const results = await findSimilarVectors(/* db */ null as any, queryVector, 5);
      
      setSearchResults(results);
    } catch (error) {
      console.error("Search failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    setSearchQuery('');
    setSearchResults([]);
  };

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Ask a question..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          onSubmitEditing={handleSearch}
        />
        <Button title="Search" onPress={handleSearch} disabled={isLoading} />
        <Button title="Clear" onPress={handleClear} color="gray" />
      </View>

      {isLoading && <ActivityIndicator size="large" color="#0000ff" style={styles.loader} />}

      <FlatList
        data={searchResults}
        keyExtractor={(item) => item.record.id!.toString()}
        renderItem={({ item }) => (
          <View style={styles.resultItem}>
            <Text style={styles.text}>{item.record.chunk_text}</Text>
            <Text style={styles.score}>
              Similarity: {item.similarity.toFixed(2)}
            </Text>
            <Text style={styles.meta}>
              Doc: {item.record.document_id} | Page: {item.record.page_number}
            </Text>
          </View>
        )}
        ListEmptyComponent={
          !isLoading && <Text style={styles.emptyText}>No results found. Try searching.</Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  inputContainer: { flexDirection: 'row', marginBottom: 16, alignItems: 'center' },
  input: { flex: 1, borderWidth: 1, borderColor: '#ccc', padding: 8, marginRight: 8 },
  loader: { marginVertical: 20 },
  resultItem: { padding: 12, borderBottomWidth: 1, borderBottomColor: '#eee' },
  text: { fontSize: 16, fontWeight: 'bold', marginBottom: 4 },
  score: { color: 'green', marginBottom: 2 },
  meta: { color: '#666', fontSize: 12 },
  emptyText: { textAlign: 'center', marginTop: 20, color: '#999' },
});
