
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

/// A simplified Transformer-based model for text summarization.
/// This model uses an embedding layer, positional encoding, a stack of Transformer blocks,
/// and a final linear layer to project to vocabulary size for token prediction.
@available(iOS 18.0, macOS 15.0, visionOS 2.0, *)
final class SummarizationModel: MLXNN.Module {
    let vocabSize: Int
    let dim: Int
    let maxSequenceLength: Int
    let numLayers: Int
    let numHeads: Int
    let mlpDim: Int

    let embedding: MLXNN.Embedding
    let positionalEncoding: MLXArray // Can be learned or fixed. For simplicity, fixed here.
    let transformerBlocks: [TransformerBlock]
    let outputProjection: MLXNN.Linear

    /// Initializes the summarization model.
    /// - Parameters:
    ///   - vocabSize: The size of the vocabulary.
    ///   - dim: The model dimension.
    ///   - maxSequenceLength: The maximum input sequence length.
    ///   - numLayers: The number of Transformer blocks to stack.
    ///   - numHeads: The number of attention heads per block.
    ///   - mlpDim: The inner dimension of the feed-forward network.
    init(vocabSize: Int, dim: Int, maxSequenceLength: Int, numLayers: Int, numHeads: Int, mlpDim: Int) {
        self.vocabSize = vocabSize
        self.dim = dim
        self.maxSequenceLength = maxSequenceLength
        self.numLayers = numLayers
        self.numHeads = numHeads
        self.mlpDim = mlpDim

        self.embedding = MLXNN.Embedding(outputDimensions: dim, vocabularySize: vocabSize)
        
        // Simplified fixed positional encoding.
        // In a real model, this would involve careful sinusoidal generation or a learned embedding.
        // For demonstration, we use a small random initialization.
        // MLXArray operations are performed on the GPU if available, leveraging Unified Memory
        // for efficient tensor creation and manipulation.
        self.positionalEncoding = MLX.random.normal(shape: [maxSequenceLength, dim], type: .float32) * 0.01 // Placeholder
        
        self.transformerBlocks = (0..<numLayers).map { _ in
            TransformerBlock(dim: dim, numHeads: numHeads, mlpDim: mlpDim)
        }
        self.outputProjection = MLXNN.Linear(inputFeatures: dim, outputFeatures: vocabSize)
        
        super.init()
    }

    /// Performs the forward pass of the summarization model.
    /// - Parameters:
    ///   - inputTokens: A tensor of input token IDs with shape `[batch_size, sequence_length]`.
    ///   - attentionMask: An optional attention mask, typically for padding or causal masking.
    /// - Returns: A tensor of logits with shape `[batch_size, sequence_length, vocab_size]`.
    override func callAsFunction(_ inputTokens: MLXArray, attentionMask: MLXArray? = nil) -> MLXArray {
        // Embed input tokens using the embedding layer.
        var x = embedding(inputTokens)
        
        // Add positional encoding to capture sequence order information.
        // We slice `positionalEncoding` to match the current input sequence length.
        let currentSequenceLength = inputTokens.shape[1]
        let peSlice = positionalEncoding[0..<currentSequenceLength]
        // Expand dimensions to broadcast positional encoding across the batch.
        x = x + peSlice.expandedDimensions(axis: 0)

        // Pass through the stack of Transformer blocks.
        for block in transformerBlocks {
            x = block(x, mask: attentionMask)
        }

        // Project the final Transformer output to the vocabulary size
        // to get logits for each possible next token.
        return outputProjection(x)
    }
}
