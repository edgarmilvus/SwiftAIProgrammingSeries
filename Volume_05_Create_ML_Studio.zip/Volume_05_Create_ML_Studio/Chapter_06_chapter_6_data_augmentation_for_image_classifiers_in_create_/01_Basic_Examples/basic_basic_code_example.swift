
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import CreateML
import Foundation
import AppKit // AppKit is used here for NSTemporaryDirectory and URL path handling,
               // suitable for a macOS-based Create ML training script.

// MARK: - Helper Structures and Functions

/// A simple structure to hold the URLs for training data, validation data, and the output model.
struct ImageDataPaths {
    let trainingDataURL: URL
    let validationDataURL: URL?
    let outputModelURL: URL
}

/// Simulates the setup of a directory structure with dummy image files.
/// In a real-world scenario, you would point Create ML to your actual dataset.
/// This function creates temporary folders like:
/// - /tmp/CreateMLAugmentationExample/TrainingData/cats/cat_1.png
/// - /tmp/CreateMLAugmentationExample/TrainingData/dogs/dog_1.png
/// - etc.
/// - /tmp/CreateMLAugmentationExample/ValidationData/cats/cat_val_1.png
/// - etc.
/// - /tmp/CreateMLAugmentationExample/OutputModels/AugmentedImageClassifier.mlmodel
/// - Parameters:
///   - baseURL: The base URL where the temporary data directories will be created.
/// - Returns: An `ImageDataPaths` struct containing the URLs to the created data directories and the expected model output path.
/// - Throws: An error if directory creation or file writing fails.
func setupDummyData(at baseURL: URL) throws -> ImageDataPaths {
    let trainingDir = baseURL.appendingPathComponent("TrainingData")
    let validationDir = baseURL.appendingPathComponent("ValidationData")
    let outputDir = baseURL.appendingPathComponent("OutputModels")

    let fileManager = FileManager.default

    // Clean up previous runs to ensure a fresh start
    try? fileManager.removeItem(at: trainingDir)
    try? fileManager.removeItem(at: validationDir)
    try? fileManager.removeItem(at: outputDir)

    // Create necessary directories
    try fileManager.createDirectory(at: trainingDir, withIntermediateDirectories: true, attributes: nil)
    try fileManager.createDirectory(at: validationDir, withIntermediateDirectories: true, attributes: nil)
    try fileManager.createDirectory(at: outputDir, withIntermediateDirectories: true, attributes: nil)

    // Define categories for our simulated animal classifier
    let categories = ["cats", "dogs", "birds"]

    // Simulate training data: create subdirectories and dummy image files
    for category in categories {
        let categoryTrainingDir = trainingDir.appendingPathComponent(category)
        try fileManager.createDirectory(at: categoryTrainingDir, withIntermediateDirectories: true, attributes: nil)
        // Create 5 dummy files per category for training.
        // In a real scenario, these would be actual image files (e.g., .jpg, .png).
        for i in 1...5 {
            let dummyFileName = "\(category)_\(i).png"
            let dummyFilePath = categoryTrainingDir.appendingPathComponent(dummyFileName)
            // Create a small, empty file. Create ML primarily checks for file existence and structure.
            // For actual image processing, these files would need valid image data.
            fileManager.createFile(atPath: dummyFilePath.path, contents: Data("dummy image data".utf8), attributes: nil)
        }
    }

    // Simulate validation data: create subdirectories and dummy image files
    for category in categories {
        let categoryValidationDir = validationDir.appendingPathComponent(category)
        try fileManager.createDirectory(at: categoryValidationDir, withIntermediateDirectories: true, attributes: nil)
        // Create 2 dummy files per category for validation.
        for i in 1...2 {
            let dummyFileName = "\(category)_val_\(i).png"
            let dummyFilePath = categoryValidationDir.appendingPathComponent(dummyFileName)
            fileManager.createFile(atPath: dummyFilePath.path, contents: Data("dummy image data".utf8), attributes: nil)
        }
    }

    print("✅ Dummy data setup complete at: \(baseURL.path)")
    return ImageDataPaths(trainingDataURL: trainingDir, validationDataURL: validationDir, outputModelURL: outputDir.appendingPathComponent("AugmentedImageClassifier.mlmodel"))
}


// MARK: - Main Training Function

/// Asynchronously trains an `MLImageClassifier` with specified data augmentation options.
/// This function demonstrates the core Create ML API for image classification with augmentation.
/// - Important: Create ML training is computationally intensive and should be run on a background thread
///              or asynchronously using Swift Concurrency (`Task`) to avoid blocking the UI in an app.
@available(macOS 10.15, *) // Create ML requires macOS 10.15 or later.
func trainImageClassifierWithAugmentation() async {
    print("🚀 Starting image classifier training with data augmentation...")

    do {
        // 1. Prepare Data Paths (Simulated for this example)
        // In a real application, `trainingDataURL`, `validationDataURL`, and `outputModelURL`
        // would point to your actual image datasets and desired output location.
        // We use a temporary directory for demonstration purposes.
        let temporaryDirectory = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("CreateMLAugmentationExample")
        let paths = try setupDummyData(at: temporaryDirectory)

        let trainingDataURL = paths.trainingDataURL
        let validationDataURL = paths.validationDataURL
        let outputModelURL = paths.outputModelURL

        // 2. Load Training Data Source
        /// `MLImageClassifier.DataSource.labeledDirectories(at:)` is the standard way to load image datasets
        /// where images are organized into subdirectories, with each subdirectory's name serving as the class label.
        let trainingDataSource = MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)
        print("📁 Loaded training data from: \(trainingDataURL.path)")

        // 3. Configure Data Augmentation Options
        /// This is the heart of data augmentation in Create ML. We create an `ImageAugmentationOptions` instance
        /// and specify various transformations. Create ML will apply these randomly and on-the-fly
        /// to the training images during each epoch. This significantly expands the effective size
        /// of your dataset and helps the model learn more robust, generalized features.
        let augmentationOptions = MLImageClassifier.DataSource.TrainingParameters.ImageAugmentationOptions(
            /// `horizontalFlip`: Randomly flips images left-to-right. Highly effective for many objects
            ///                   where left/right orientation doesn't change the object's identity (e.g., cats, cars).
            horizontalFlip: true,
            /// `verticalFlip`: Randomly flips images top-to-bottom. Use with caution; only suitable if
            ///                 vertical orientation is not semantically important (e.g., satellite imagery, abstract patterns).
            ///                 For most natural images (animals, faces), this would create unnatural examples.
            verticalFlip: false,
            /// `randomCrop`: Randomly crops a portion of the image.
            ///               `minScale` and `maxScale` define the range of the cropped area relative to the original image's area.
            ///               E.g., `minScale: 0.8, maxScale: 1.0` means the crop will cover 80% to 100% of the original image's area.
            ///               This simulates variations in object size or perspective, and helps the model focus on different parts.
            randomCrop: .init(minScale: 0.8, maxScale: 1.0),
            /// `randomScale`: Randomly scales the entire image.
            ///                `min` and `max` define the scaling factor (e.g., 0.9 means 90%, 1.1 means 110%).
            ///                This helps the model become invariant to object size variations.
            randomScale: .init(min: 0.9, max: 1.1),
            /// `randomRotation`: Randomly rotates the image by a maximum angle in degrees (positive or negative).
            ///                   E.g., `15.0` means rotation between -15 and +15 degrees.
            ///                   Useful for making the model robust to slight changes in object orientation.
            randomRotation: 15.0,
            /// `randomBrightness`: Randomly adjusts the brightness of the image.
            ///                     `min` and `max` are multipliers (e.g., 0.8 means 80% brightness, 1.2 means 120%).
            ///                     Helps the model perform well under varying lighting conditions.
            randomBrightness: .init(min: 0.8, max: 1.2),
            /// `randomExposure`: Randomly adjusts the exposure of the image. Similar to brightness but can affect
            ///                   highlights and shadows differently, mimicking different camera settings.
            randomExposure: .init(min: 0.8, max: 1.2),
            /// `randomSaturation`: Randomly adjusts the saturation (color intensity) of the image.
            ///                     Helps with variations in color vibrancy.
            randomSaturation: .init(min: 0.8, max: 1.2),
            /// `randomContrast`: Randomly adjusts the contrast of the image.
            ///                   Helps with variations in image sharpness and detail visibility.
            randomContrast: .init(min: 0.8, max: 1.2),
            /// `randomNoise`: Randomly adds Gaussian noise to the image.
            ///                The value is the standard deviation of the noise.
            ///                Can improve robustness against noisy inputs, like images from low-light cameras.
            randomNoise: 0.05,
            /// `randomColorInvert`: Randomly inverts the colors of the image.
            ///                      Generally not suitable for natural images unless there's a specific use case
            ///                      (e.g., classifying medical scans where color inversion might be a valid variant).
            randomColorInvert: false,
            /// `randomPerspective`: Randomly applies a perspective transformation (e.g., slight tilting).
            ///                      `maxShear` is the maximum proportion of shear.
            ///                      Helps the model recognize objects from slightly different viewpoints.
            randomPerspective: .init(maxShear: 0.1),
            /// `randomTranslate`: Randomly shifts (translates) the image horizontally and/or vertically.
            ///                    `maxFraction` is the maximum proportion of the image dimensions to shift.
            ///                    Helps the model become less sensitive to the exact position of an object in the frame.
            randomTranslate: .init(maxFraction: 0.1)
        )
        print("⚙️ Configured data augmentation options.")

        // 4. Configure Training Parameters with Augmentation
        /// We create `TrainingParameters` and embed our `augmentationOptions` within it.
        /// This tells Create ML to apply these augmentations during the training process.
        ///
        /// **How it works under the hood:** Create ML doesn't create permanent augmented files.
        /// Instead, during each training step (batch), it dynamically loads original images,
        /// applies a *random combination* of the enabled augmentations, and feeds these
        /// newly transformed images to the neural network. This ensures the model constantly
        /// sees fresh, varied data, preventing it from memorizing the exact training examples.
        let trainingParameters = MLImageClassifier.DataSource.TrainingParameters(
            /// `batchSize`: The number of images processed in one forward/backward pass.
            ///              Larger batches can speed up training but might require more memory.
            batchSize: 32,
            /// `epochs`: The number of times the entire training dataset (with augmentations)
            ///           is passed forward and backward through the neural network.
            ///           More epochs allow the model to learn more, but too many can lead to overfitting.
            epochs: 10,
            /// `imageAugmentationOptions`: Our custom augmentation configuration.
            imageAugmentationOptions: augmentationOptions,
            /// `validationDataSource`: An optional data source for evaluating the model's performance
            ///                         on unseen data during training. Crucial for detecting overfitting.
            ///                         **Important:** Validation data should NEVER be augmented to
            ///                         accurately reflect real-world performance.
            validationDataSource: validationDataURL.map { MLImageClassifier.DataSource.labeledDirectories(at: $0) }
        )
        print("📋 Configured training parameters, including data augmentation.")

        // 5. Create and Train the Image Classifier
        /// The `MLImageClassifier` initializer initiates the training process.
        /// This is an asynchronous operation, and its duration depends on the dataset size,
        /// complexity, and the chosen training parameters (epochs, batch size, augmentations).
        print("⏳ Training model... This may take a while depending on your data and hardware.")
        let classifier = try await MLImageClassifier(
            trainingData: trainingDataSource,
            parameters: trainingParameters
        )
        print("🎉 Model training complete!")

        // 6. Evaluate the Model (Optional but Highly Recommended)
        /// After training, it's good practice to evaluate the model's performance on the validation data.
        /// This gives an objective measure of how well the model generalizes to new, unseen images.
        if let validationDataURL = validationDataURL {
            let validationDataSource = MLImageClassifier.DataSource.labeledDirectories(at: validationDataURL)
            let evaluation = classifier.evaluation(on: validationDataSource)
            print("📊 Model evaluation on validation data:")
            print("  Classification Error: \(String(format: "%.2f%%", evaluation.classificationError * 100))")
            print("  Precision: \(String(format: "%.2f", evaluation.precisionRecall.precision))")
            print("  Recall: \(String(format: "%.2f", evaluation.precisionRecall.recall))")
            print("  F1-Score: \(String(format: "%.2f", evaluation.precisionRecall.f1Score))")
        }

        // 7. Save the Trained Model
        /// The trained model can be saved as an `.mlmodel` file. This file is a Core ML model
        /// that can be directly integrated into iOS, macOS, watchOS, or tvOS applications
        /// for efficient on-device inference.
        let metadata = MLModelMetadata(
            author: "Your Name",
            license: "MIT",
            description: "An image classifier for animals, trained with data augmentation for improved robustness.",
            version: "1.0"
        )
        try classifier.write(to: outputModelURL, metadata: metadata)
        print("💾 Model saved to: \(outputModelURL.path)")

        // Clean up the temporary dummy data created for this example.
        try FileManager.default.removeItem(at: temporaryDirectory)
        print("🗑️ Cleaned up temporary dummy data.")

    } catch {
        print("❌ Error during image classifier training: \(error.localizedDescription)")
    }
}

// MARK: - Entry Point

/// The `@main` attribute designates `CreateMLAugmentationExample` as the entry point
/// for a command-line tool or a simple macOS app.
/// We use `Task` to run the asynchronous training function.
@main
@available(macOS 10.15, *)
struct CreateMLAugmentationExample {
    static func main() {
        Task {
            await trainImageClassifierWithAugmentation()
            // Exit the program after the async task completes in a command-line tool.
            // In a GUI app, the app lifecycle manages this.
            exit(0)
        }
        // For command-line tools, `RunLoop.current.run()` keeps the process alive
        // until the async Task completes and calls `exit(0)`.
        RunLoop.current.run()
    }
}
