
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.swift
// Description: Theoretical Foundations
// ==========================================

import MLX

// A custom struct holding MLXArray data, designed to be Sendable
@available(iOS 18.0, *)
struct ModelInputData: Sendable {
    let features: MLXArray
    let metadata: String // String is also Sendable
}

@available(iOS 18.0, *)
actor DataProcessor {
    func process(_ data: ModelInputData) async -> MLXArray {
        // Perform some MLX operations on 'data.features'
        let processedFeatures = MLX.log(data.features + 1.0).eval()
        print("Processing metadata: \(data.metadata)")
        return processedFeatures
    }
}

@available(iOS 18.0, *)
func demonstrateSendable() async {
    let input = ModelInputData(features: MLXArray.randomUniform(low: 0, high: 1, [2, 2]), metadata: "Test batch 1")
    let processor = DataProcessor()

    // 'input' (containing MLXArray) can be safely passed to the actor
    let result = await processor.process(input)
    print("Processed result: \(result.asArray())")
}
