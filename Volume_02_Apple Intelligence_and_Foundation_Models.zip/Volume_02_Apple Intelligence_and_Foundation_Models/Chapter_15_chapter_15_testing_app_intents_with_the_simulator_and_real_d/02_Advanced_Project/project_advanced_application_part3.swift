
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, *)
extension Note: AppEntity {
    /// The unique identifier for this AppEntity.
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Note"

    /// The default display representation for an instance of a Note.
    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(title: "\(title)", subtitle: "\(content.prefix(50))...")
    }

    /// The query type for fetching Note entities.
    static var defaultQuery: NoteQuery = NoteQuery()

    /// A query class to fetch `Note` entities based on various criteria.
    /// This is crucial for Siri to be able to resolve a specific note.
    struct NoteQuery: EntityQuery {
        /// Resolves a single `Note` by its `id`.
        func entities(for identifiers: [Note.ID]) async throws -> [Note] {
            // In a real app, this would fetch from a persistent store.
            // For this example, we use the shared NoteStore.
            return identifiers.compactMap { NoteStore.shared.note(for: $0) }
        }

        /// Resolves `Note` entities based on a search term.
        /// This is how Siri can find notes when the user says "summarize my note about meeting minutes".
        func entities(matching query: String) async throws -> [Note] {
            return NoteStore.shared.searchNotes(matching: query)
        }

        /// Provides a list of all available `Note` entities.
        /// This is used when Siri needs to present a selection list to the user,
        /// e.g., "Which note would you like to summarize?".
        func suggestedEntities() async throws -> [Note] {
            return NoteStore.shared.notes
        }
    }
}
