
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation // For @Observable

@available(iOS 17.0, macOS 14.0, *)
@Observable
class AgentMonitor {
    var agentName: String
    var currentGoal: String
    var currentStep: Int = 0
    var lastAction: String = "Initializing..."
    var memoryLog: [String] = []
    var isRunning: Bool = false
    var isGoalAchieved: Bool = false

    init(agentName: String, goal: String) {
        self.agentName = agentName
        self.currentGoal = goal
    }

    // Agent can update this monitor
    func update(step: Int, action: String, memoryEntry: String, goalAchieved: Bool) {
        self.currentStep = step
        self.lastAction = action
        self.memoryLog.append(memoryEntry)
        self.isGoalAchieved = goalAchieved
    }

    func startMonitoring() {
        self.isRunning = true
    }

    func stopMonitoring() {
        self.isRunning = false
    }
}

// In a SwiftUI view:
/*
@available(iOS 17.0, macOS 14.0, *)
struct AgentView: View {
    @State private var monitor = AgentMonitor(agentName: "MyAgent", goal: "Solve problem X")

    var body: some View {
        VStack {
            Text("Agent: \(monitor.agentName)")
            Text("Goal: \(monitor.currentGoal)")
            Text("Step: \(monitor.currentStep)")
            Text("Last Action: \(monitor.lastAction)")
            ScrollView {
                ForEach(monitor.memoryLog, id: \.self) { entry in
                    Text(entry)
                }
            }
            if monitor.isGoalAchieved {
                Text("Goal Achieved!").font(.headline).foregroundColor(.green)
            }
        }
    }
}
*/
