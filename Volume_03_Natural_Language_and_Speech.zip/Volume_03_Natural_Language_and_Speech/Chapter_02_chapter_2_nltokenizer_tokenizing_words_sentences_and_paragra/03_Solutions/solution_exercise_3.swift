
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import NaturalLanguage

/// Generates an outline from a multi-paragraph text by extracting the first sentence of each paragraph.
///
/// - Parameter noteText: The input string representing the user's note.
/// - Returns: An array of strings, where each string is the first sentence of a paragraph.
func generateOutline(from noteText: String) -> [String] {
    var outlineSentences: [String] = []

    // Handle empty input text gracefully.
    guard !noteText.isEmpty else {
        return []
    }

    // MARK: - Step 1: Tokenize by Paragraph
    let paragraphTokenizer = NLTokenizer(unit: .paragraph)
    paragraphTokenizer.string = noteText

    // Enumerate through each paragraph in the entire note.
    paragraphTokenizer.enumerateTokens(in: noteText.startIndex..<noteText.endIndex, unit: .paragraph, using: { paragraphRange, _ in
        // Extract the substring for the current paragraph.
        let paragraphString = String(noteText[paragraphRange])

        // Consider edge cases: skip empty paragraphs (e.g., due to multiple newlines).
        // NLTokenizer might return ranges for what appear to be empty paragraphs if there are
        // consecutive paragraph separators. Trimming whitespace helps identify truly empty ones.
        let trimmedParagraph = paragraphString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedParagraph.isEmpty else {
            return true // Continue to the next paragraph
        }

        // MARK: - Step 2: Tokenize the Paragraph by Sentence to get the first one
        let sentenceTokenizer = NLTokenizer(unit: .sentence)
        sentenceTokenizer.string = paragraphString // Tokenize within the current paragraph's scope.

        // Use a flag to ensure we only capture the very first sentence.
        var firstSentenceFound = false
        sentenceTokenizer.enumerateTokens(in: paragraphString.startIndex..<paragraphString.endIndex, unit: .sentence, using: { sentenceRange, _ in
            if !firstSentenceFound {
                let firstSentence = String(paragraphString[sentenceRange])
                outlineSentences.append(firstSentence)
                firstSentenceFound = true
            }
            return false // Stop enumeration after finding the first sentence in this paragraph.
        })

        return true // Continue to the next paragraph in the main text.
    })

    return outlineSentences
}

// Example Input:
let note = """
Introduction to NLP. Natural Language Processing is a field of artificial intelligence. It focuses on the interaction between computers and human language.

Tokenization is a key step. This process breaks down text into smaller units. Words, sentences, and paragraphs are common tokens.

Sentiment analysis is another application. It determines the emotional tone of text. This helps in understanding user feedback.

This is a single-sentence paragraph.

Another paragraph with only one sentence!

And this is a paragraph
with a newline in the middle but still
one sentence.

    An indented paragraph. This is its second sentence.

A very short paragraph.
"""

let outline = generateOutline(from: note)
print("Generated Outline:")
outline.forEach { print("- \($0)") }
/* Expected Output (approximate, NLTokenizer can have subtle differences):
- Introduction to NLP.
- Tokenization is a key step.
- Sentiment analysis is another application.
- This is a single-sentence paragraph.
- Another paragraph with only one sentence!
- And this is a paragraph
with a newline in the middle but still
one sentence.
- An indented paragraph.
- A very short paragraph.
*/

let emptyNote = ""
let emptyOutline = generateOutline(from: emptyNote)
print("\nGenerated Outline for empty note: \(emptyOutline)")
// Expected: []

let singleParagraphNote = "This is a single paragraph with multiple sentences. It should only yield one outline item. Yes."
let singleParagraphOutline = generateOutline(from: singleParagraphNote)
print("\nGenerated Outline for single paragraph note:")
singleParagraphOutline.forEach { print("- \($0)") }
// Expected: ["This is a single paragraph with multiple sentences."]
