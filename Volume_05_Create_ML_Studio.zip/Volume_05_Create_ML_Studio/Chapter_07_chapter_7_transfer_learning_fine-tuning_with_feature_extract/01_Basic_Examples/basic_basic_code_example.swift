
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CreateML // Required for MLImageClassifier and related types
import CoreML // Required for MLModel

/// A utility function to find a specific directory in the current working directory.
/// This helps locate our training data regardless of where the script is run from.
/// - Parameter directoryName: The name of the directory to find (e.g., "PetImages").
/// - Returns: The URL to the directory if found, otherwise nil.
func findDirectory(named directoryName: String) -> URL? {
    let fileManager = FileManager.default
    let currentDirectoryURL = URL(fileURLWithPath: fileManager.currentDirectoryPath)

    // Check if the directory exists directly in the current path
    let targetURL = currentDirectoryURL.appendingPathComponent(directoryName, isDirectory: true)
    if fileManager.fileExists(atPath: targetURL.path) {
        return targetURL
    }

    // If not found, try looking up a few parent directories (e.g., for Xcode playgrounds)
    var searchURL: URL? = currentDirectoryURL
    for _ in 0..<5 { // Search up to 5 parent directories
        if let currentSearchURL = searchURL {
            let potentialTargetURL = currentSearchURL.appendingPathComponent(directoryName, isDirectory: true)
            if fileManager.fileExists(atPath: potentialTargetURL.path) {
                return potentialTargetURL
            }
            searchURL = currentSearchURL.deletingLastPathComponent()
        } else {
            break
        }
    }

    print("Error: Directory '\(directoryName)' not found in current path or parent directories.")
    return nil
}

/// Main function to perform image classification training using Create ML.
/// This function encapsulates the entire training, evaluation, and saving process.
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *) // Create ML availability
func trainPetImageClassifier() async {
    print("Starting Pet Image Classifier training...")

    // 1. Define paths for training data and output model.
    guard let trainingDataURL = findDirectory(named: "PetImages") else {
        print("Failed to find 'PetImages' directory. Please ensure it's set up correctly.")
        return
    }

    // Define where the trained model will be saved.
    // We'll save it to the user's desktop for easy access, or a temporary directory.
    let fileManager = FileManager.default
    let desktopURL = fileManager.urls(for: .desktopDirectory, in: .userDomainMask).first
    let outputModelURL = (desktopURL ?? fileManager.temporaryDirectory)
        .appendingPathComponent("PetClassifier.mlmodel")

    print("Training data source: \(trainingDataURL.path)")
    print("Output model will be saved to: \(outputModelURL.path)")

    do {
        // 2. Load training data.
        // MLImageClassifier.DataSource.labeledDirectories(at:) automatically infers
        // class labels from subfolder names (e.g., "Cat", "Dog").
        print("Loading training data...")
        let trainingData = try MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)
        print("Training data loaded. Found \(trainingData.count) images across \(trainingData.labels.count) classes: \(trainingData.labels.joined(separator: ", "))")

        // 3. Train the image classifier.
        // This is where Create ML implicitly performs transfer learning.
        // It uses a pre-trained model as a base and fine-tunes it for our specific classes.
        print("Training MLImageClassifier...")
        let classifier = try await MLImageClassifier(training: trainingData) { progress in
            // Optional: Monitor training progress
            print("Training Progress: \(progress.fractionCompleted * 100)%")
        }
        print("MLImageClassifier training complete.")

        // 4. Evaluate the trained model (optional but recommended).
        // We'll use the same training data for evaluation in this basic example.
        // In a real-world scenario, you'd use a separate validation/test set.
        print("Evaluating the trained model...")
        let evaluationMetrics = classifier.evaluation(on: trainingData)
        let classificationError = evaluationMetrics.classificationError
        let validationAccuracy = (1.0 - classificationError) * 100
        print("Model Evaluation:")
        print("  Classification Error: \(String(format: "%.2f%%", classificationError * 100))")
        print("  Validation Accuracy: \(String(format: "%.2f%%", validationAccuracy))")

        // 5. Save the trained model to disk.
        print("Saving the trained model to \(outputModelURL.path)...")
        try classifier.write(to: outputModelURL)
        print("Model saved successfully!")

        // 6. (Optional) Load and test the saved model.
        print("Loading the saved model for a quick test...")
        let compiledModelURL = try MLModel.compileModel(at: outputModelURL)
        let loadedModel = try MLModel(contentsOf: compiledModelURL)
        print("Model loaded successfully: \(loadedModel.modelDescription.metadata.shortDescription ?? "No description")")

        // You can now integrate this 'loadedModel' into your iOS/macOS app.

    } catch {
        print("Error during training or evaluation: \(error.localizedDescription)")
        if let mlError = error as? MLCError {
            print("Create ML Error Code: \(mlError.errorCode)")
            print("Create ML Error Domain: \(mlError.errorDomain)")
            print("Create ML Error User Info: \(mlError.userInfo)")
        }
    }
    print("Pet Image Classifier training finished.")
}

// Entry point for the script.
// We need to run the async function.
@main
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
struct MainApp {
    static func main() async {
        await trainPetImageClassifier()
    }
}
