
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
enum Mood: String, Codable, Sendable {
    case happy, anxious, neutral, sad, angry
}

@available(iOS 18.0, macOS 15.0, *)
struct JournalAnalysis: Codable, Sendable {
    let primaryMood: Mood
    let sentimentScore: Double
    let topics: [String]
    let summary: String
}

@available(iOS 18.0, macOS 15.0, *)
actor JournalAnalysisService {
    
    private func callLLM(prompt: String, input: String) async throws -> String {
        try await Task.sleep(for: .seconds(1))
        // Simulated response for a user writing about a stressful work day
        return """
        {
            "primaryMood": "anxious",
            "sentimentScore": -0.75,
            "topics": ["work", "deadlines", "stress"],
            "summary": "The user feels overwhelmed by upcoming work deadlines."
        }
        """
    }

    func analyze(entry: String) async throws -> JournalAnalysis {
        let systemPrompt = """
        Analyze the following journal entry. Return a JSON object.
        
        CONSTRAINTS:
        1. primaryMood must be one of: happy, anxious, neutral, sad, angry.
        2. sentimentScore must be a Double between -1.0 and 1.0.
        3. topics must be an array of strings. Identify all relevant themes.
        4. summary must be a single string, maximum 20 words.
        
        JSON SCHEMA:
        {
          "primaryMood": string,
          "sentimentScore": number,
          "topics": [string],
          "summary": string
        }
        """

        let rawResponse = try await callLLM(prompt: systemPrompt, input: entry)
        let data = Data(rawResponse.utf8)
        return try JSONDecoder().decode(JournalAnalysis.self, from: data)
    }
}
