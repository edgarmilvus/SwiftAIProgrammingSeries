
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Observation
import SwiftUI

// MARK: - Models

/// The schema that defines our structured output. 
/// This is the most critical part of the prompt engineering process.
/// The LLM must be told to adhere to this exact structure.
@available(iOS 18.0, *)
struct TravelItinerary: Codable, Sendable {
    let destination: String
    let totalEstimatedCost: Double
    let currency: String
    let dailyPlans: [DayPlan]
}

/// Represents a single day of travel within the itinerary.
@available(iOS 18.0, *)
struct DayPlan: Codable, Sendable {
    let dayNumber: Int
    let theme: String
    let activities: [Activity]
}

/// Represents a specific activity to perform.
@available(iOS 18.0, *)
struct Activity: Codable, Sendable {
    let time: String
    let location: String
    let description: String
    let cost: Double
}

// MARK: - Error Handling

/// Custom errors specific to the Structured Output workflow.
enum ItineraryError: Error, LocalizedError {
    case invalidResponse
    case decodingError(Error)
    case apiError(String)

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "The AI returned an empty or invalid response."
        case .decodingError(let error): return "Failed to parse AI response into Swift models: \(error.localizedDescription)"
        case .apiError(let msg): return "API Error: \(msg)"
        }
    }
}

// MARK: - Service Layer

/// A service responsible for communicating with the LLM.
/// It utilizes Swift 6 concurrency and ensures all network calls are isolated.
@available(iOS 18.0, *)
actor ItineraryAIService {
    private let apiKey: String
    private let endpoint = URL(string: "https://api.openai.com/v1/chat/completions")!

    init(apiKey: String) {
        self.apiKey = apiKey
    }

    /// Fetches a structured itinerary from the LLM.
    /// - Parameter userPrompt: The raw text input from the user.
    /// - Returns: A fully decoded `TravelItinerary` object.
    func fetchItinerary(from userPrompt: String) async throws -> TravelItinerary {
        // 1. Construct the System Prompt
        // This is where 'Prompt Engineering' happens. We explicitly define the JSON structure.
        let systemPrompt = """
        You are a professional travel planner. 
        Your task is to return a JSON object representing a travel itinerary.
        The JSON must strictly follow this schema:
        {
          "destination": "string",
          "totalEstimatedCost": number,
          "currency": "string",
          "dailyPlans": [
            {
              "dayNumber": number,
              "theme": "string",
              "activities": [
                { "time": "string", "location": "string", "description": "string", "cost": number }
              ]
            }
          ]
        }
        Do not include any conversational text, markdown formatting, or explanations. 
        Return ONLY the raw JSON.
        """

        // 2. Prepare the Request Body
        // We use 'response_format: { type: "json_object" }' to trigger OpenAI's JSON Mode.
        let requestBody: [String: Any] = [
            "model": "gpt-4o",
            "messages": [
                ["role": "system", "content": systemPrompt],
                ["role": "user", "content": userPrompt]
            ],
            "response_format": ["type": "json_object"] // CRITICAL: Forces JSON mode
        ]

        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.addValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: requestBody)

        // 3. Execute the Network Call
        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw ItineraryError.apiError("Server returned non-200 status.")
        }

        // 4. Parse the LLM's response wrapper
        // The LLM returns a ChatCompletion object, which contains a 'content' string.
        let completion = try JSONDecoder().decode(ChatCompletionResponse.self, from: data)
        
        guard let jsonString = completion.choices.first?.message.content,
              let jsonData = jsonString.data(using: .utf8) else {
            throw ItineraryError.invalidResponse
        }

        // 5. The "Magic" Step: Decode the JSON string into our Swift Model
        do {
            let itinerary = try JSONDecoder().decode(TravelItinerary.self, from: jsonData)
            return itinerary
        } catch {
            throw ItineraryError.decodingError(error)
        }
    }
}

/// Internal helper to decode the OpenAI API envelope.
struct ChatCompletionResponse: Codable {
    struct Choice: Codable {
        struct Message: Codable {
            let content: String
        }
        let message: Message
    }
    let choices: [Choice]
}

// MARK: - ViewModel Layer

/// The ViewModel manages the UI state. 
/// Using @Observable (iOS 17+) and @MainActor ensures thread-safe UI updates.
@available(iOS 18.0, *)
@Observable
@MainActor
class ItineraryViewModel {
    var itinerary: TravelItinerary?
    var isLoading = false
    var errorMessage: String?
    
    private let aiService: ItineraryAIService

    init(aiService: ItineraryAIService) {
        self.aiService = aiService
    }

    /// Initiates the planning process.
    func planTrip(query: String) async {
        isLoading = true
        errorMessage = nil
        
        do {
            // The service call is awaited. Because the service is an actor,
            // it handles its own synchronization.
            let result = try await aiService.fetchItinerary(from: query)
            self.itinerary = result
        } catch {
            self.errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
}

// MARK: - UI Layer

@available(iOS 18.0, *)
struct ItineraryView: View {
    @State private var viewModel: ItineraryViewModel
    @State private var userInput: String = ""

    init(apiKey: String) {
        let service = ItineraryAIService(apiKey: apiKey)
        _viewModel = State(initialValue: ItineraryViewModel(aiService: service))
    }

    var body: some View {
        NavigationStack {
            VStack {
                // Input Section
                HStack {
                    TextField("e.g., 3 days in Tokyo for foodies", text: $userInput)
                        .textFieldStyle(.roundedBorder)
                    
                    Button {
                        Task { await viewModel.planTrip(query: userInput) }
                    } label: {
                        if viewModel.isLoading {
                            ProgressView()
                        } else {
                            Image(systemName: "sparkles")
                        }
                    }
                    .disabled(viewModel.isLoading || userInput.isEmpty)
                }
                .padding()

                // Output Section
                if let error = viewModel.errorMessage {
                    ContentUnavailableView("Error", systemImage: "exclamationmark.triangle", description: Text(error))
                } else if let itinerary = viewModel.itinerary {
                    List {
                        Section("Destination: \(itinerary.destination)") {
                            Text("Estimated Budget: \(itinerary.totalEstimatedCost, format: .currency(code: itinerary.currency))")
                                .font(.headline)
                        }

                        ForEach(itinerary.dailyPlans, id: \.dayNumber) { day in
                            Section("Day \(day.dayNumber): \(day.theme)") {
                                ForEach(day.activities, id: \.time) { activity in
                                    VStack(alignment: .leading) {
                                        HStack {
                                            Text(activity.time)
                                                .font(.caption)
                                                .foregroundStyle(.secondary)
                                            Spacer()
                                            Text("$\(activity.cost, specifier: "%.2f")")
                                                .font(.caption.monospacedDigit())
                                        }
                                        Text(activity.location)
                                            .font(.subheadline).bold()
                                        Text(activity.description)
                                            .font(.caption)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    ContentUnavailableView("No Itinerary", systemImage: "map", description: Text("Enter a destination to begin."))
                }
            }
            .navigationTitle("AI Travel Planner")
        }
    }
}
