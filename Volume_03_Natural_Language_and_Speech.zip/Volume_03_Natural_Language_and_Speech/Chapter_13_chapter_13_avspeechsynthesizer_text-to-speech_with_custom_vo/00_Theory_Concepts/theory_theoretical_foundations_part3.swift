
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import AVFoundation
import Combine // For @Published in older SwiftUI patterns, or @Observable in iOS 17+

// @available(iOS 18.0, *) - For demonstration of modern concurrency features
@available(iOS 18.0, *)
@Observable // For SwiftUI integration in iOS 17+
final class SpeechManager: NSObject, AVSpeechSynthesizerDelegate {
    private let synthesizer = AVSpeechSynthesizer()
    var isSpeaking: Bool = false
    var currentUtterance: AVSpeechUtterance?
    var spokenWords: String = "" // For tracking progress

    // A continuation to bridge the delegate-based API to async/await
    private var currentContinuation: CheckedContinuation<Void, Error>?

    override init() {
        super.init()
        synthesizer.delegate = self
    }

    // MARK: - Public API

    /// Synthesizes speech for a given request asynchronously.
    func speak(request: SpeechRequest) async throws {
        // If already speaking, stop current speech before starting new one
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
            currentContinuation?.resume(throwing: CancellationError()) // Cancel previous async operation
            currentContinuation = nil
        }

        let utterance = AVSpeechUtterance(request: request)
        currentUtterance = utterance
        spokenWords = "" // Reset progress

        try await withCheckedThrowingContinuation { continuation in
            currentContinuation = continuation
            synthesizer.speak(utterance)
        }
    }

    /// Pauses the current speech.
    func pause() {
        if synthesizer.isSpeaking {
            synthesizer.pauseSpeaking(at: .word) // Pause after current word
        }
    }

    /// Continues paused speech.
    func `continue`() {
        if synthesizer.isPaused {
            synthesizer.continueSpeaking()
        }
    }

    /// Stops current speech immediately.
    func stop() {
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
            currentContinuation?.resume(throwing: CancellationError())
            currentContinuation = nil
        }
        currentUtterance = nil
        spokenWords = ""
    }

    // MARK: - AVSpeechSynthesizerDelegate

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        Task { @MainActor in
            self.isSpeaking = true
            print("Speech started for: \(utterance.speechString)")
        }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        Task { @MainActor in
            self.isSpeaking = false
            self.currentUtterance = nil
            self.spokenWords = ""
            print("Speech finished for: \(utterance.speechString)")
            currentContinuation?.resume()
            currentContinuation = nil
        }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didPause utterance: AVSpeechUtterance) {
        Task { @MainActor in
            self.isSpeaking = false // Or a separate `isPaused` state
            print("Speech paused for: \(utterance.speechString)")
        }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didContinue utterance: AVSpeechUtterance) {
        Task { @MainActor in
            self.isSpeaking = true
            print("Speech continued for: \(utterance.speechString)")
        }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        Task { @MainActor in
            self.isSpeaking = false
            self.currentUtterance = nil
            self.spokenWords = ""
            print("Speech cancelled for: \(utterance.speechString)")
            currentContinuation?.resume(throwing: CancellationError())
            currentContinuation = nil
        }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        Task { @MainActor in
            let word = (utterance.speechString as NSString).substring(with: characterRange)
            self.spokenWords = word
            // print("Will speak word: \(word)") // Can be chatty
        }
    }
}
