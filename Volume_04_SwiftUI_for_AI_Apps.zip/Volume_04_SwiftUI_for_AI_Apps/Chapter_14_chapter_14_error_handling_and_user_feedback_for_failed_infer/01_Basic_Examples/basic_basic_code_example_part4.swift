
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import UIKit // Required for UIImage

@available(iOS 17.0, *)
struct BasicErrorHandlingView: View {
    // The ViewModel is managed by the view's state.
    @State private var viewModel = PhotoOrganizerViewModel()
    // A placeholder image for demonstration.
    @State private var selectedImage: UIImage? = UIImage(systemName: "photo.fill")

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Spacer()

                // 1. Image Display (Placeholder)
                if let image = selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                        .cornerRadius(10)
                        .shadow(radius: 5)
                } else {
                    Image(systemName: "photo.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                        .foregroundColor(.gray)
                }

                // 2. Categorization Status Display
                Text("Status: \(viewModel.categorizedLabel)")
                    .font(.title2)
                    .fontWeight(.medium)
                    .padding()
                    .background(viewModel.activeError != nil ? Color.red.opacity(0.1) : Color.blue.opacity(0.1))
                    .cornerRadius(8)

                // 3. Loading Indicator
                if viewModel.isLoading {
                    ProgressView("Processing...")
                        .progressViewStyle(.circular)
                        .padding()
                }

                // 4. Action Buttons for various scenarios
                VStack(spacing: 15) {
                    Button("Categorize Successfully") {
                        Task {
                            viewModel.configureMockFailures(modelLoading: false, inputValidation: false, inference: false)
                            await viewModel.performCategorization(image: selectedImage ?? UIImage())
                        }
                    }
                    .buttonStyle(.borderedProminent)

                    Button("Simulate Model Loading Failure") {
                        Task {
                            viewModel.configureMockFailures(modelLoading: true)
                            await viewModel.performCategorization(image: selectedImage ?? UIImage())
                        }
                    }
                    .buttonStyle(.bordered)
                    .tint(.red)

                    Button("Simulate Invalid Input Failure") {
                        Task {
                            viewModel.configureMockFailures(inputValidation: true)
                            await viewModel.performCategorization(image: selectedImage ?? UIImage())
                        }
                    }
                    .buttonStyle(.bordered)
                    .tint(.orange)

                    Button("Simulate Inference Failure") {
                        Task {
                            viewModel.configureMockFailures(inference: true)
                            await viewModel.performCategorization(image: selectedImage ?? UIImage())
                        }
                    }
                    .buttonStyle(.bordered)
                    .tint(.purple)
                }
                .padding(.horizontal)

                Spacer()
            }
            .navigationTitle("Smart Photo Organizer")
            // 5. Error Alert Display
            .alert(item: $viewModel.activeError) { error in
                Alert(
                    title: Text("Categorization Error"),
                    message: Text(error.localizedDescription),
                    dismissButton: .default(Text("OK")) {
                        // Optional: Perform additional actions on dismiss
                        viewModel.activeError = nil // Clear the error
                    }
                )
            }
        }
    }
}

// MARK: - Preview Provider
@available(iOS 17.0, *)
#Preview {
    BasicErrorHandlingView()
}
