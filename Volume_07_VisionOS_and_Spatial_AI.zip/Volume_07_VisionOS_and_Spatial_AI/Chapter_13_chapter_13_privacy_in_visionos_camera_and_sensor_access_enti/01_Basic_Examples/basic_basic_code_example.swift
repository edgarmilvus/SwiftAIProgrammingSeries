
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import ARKit
import RealityKit

/// A specialized error type for handling spatial sensor failures.
enum SpatialError: Error, LocalizedError {
    case permissionDenied
    case sensorUnavailable
    case unexpected(Error)

    var errorDescription: String? {
        switch self {
        case .permissionDenied: return "User denied access to spatial sensors."
        case .sensorUnavailable: return "The spatial sensors are currently unavailable."
        case .unexpected(let error): return error.localizedDescription
        }
    }
}

/// An actor-isolated manager that handles the lifecycle of ARKit sessions.
/// Using `@MainActor` ensures all UI-related state updates happen on the main thread.
@MainActor
class SpatialAwarenessManager: ObservableObject {
    
    /// The current status of the spatial sensor session.
    @Published var isSessionRunning = false
    
    /// A published error message to display in the UI.
    @Published var errorMessage: String? = nil
    
    /// The ARKit session object that manages sensor data.
    /// In visionOS, this is the primary interface for spatial awareness.
    private var session = ARKitSession()
    
    /// The provider responsible for tracking the device's position and orientation in space.
    private var worldTracking: WorldTrackingProvider?

    /// Starts the spatial tracking session.
    /// This method handles the permission request and session initialization.
    ///
    /// - Throws: `SpatialError` if permission is denied or sensors fail.
    func startSpatialTracking() async throws {
        // 1. Check if we have authorization for world sensing.
        // In visionOS, this triggers the system privacy prompt if not already granted.
        let authorization = await ARKitSession.authorizationStatus(for: .worldSensing)
        
        guard authorization == .authorized else {
            throw SpatialError.permissionDenied
        }
        
        // 2. Initialize the World Tracking Provider.
        // This provider is what allows us to understand the user's movement in 3D space.
        worldTracking = WorldTrackingProvider()
        
        // 3. Start the session.
        // This is an asynchronous call that begins the sensor stream.
        do {
            try await session.run([worldTracking!])
            isSessionRunning = true
            errorMessage = nil
            print("Spatial session successfully started.")
        } catch {
            isSessionRunning = false
            throw SpatialError.unexpected(error)
        }
    }

    /// Stops the spatial tracking session and cleans up resources.
    func stopSpatialTracking() {
        // Stopping the session releases the sensor hardware,
        // allowing other apps to use it and preserving battery life.
        Task {
            await session.stop()
            isSessionRunning = false
            print("Spatial session stopped.")
        }
    }
}

/// A SwiftUI view that provides a user interface for controlling spatial sensing.
struct SpatialScannerView: View {
    @StateObject private var manager = SpatialAwarenessManager()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Spatial AI Controller")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            if let error = manager.errorMessage {
                Text(error)
                    .foregroundColor(.red)
                    .multilineTextAlignment(.center)
            }
            
            Circle()
                .fill(manager.isSessionRunning ? Color.green : Color.red)
                .frame(width: 20, height: 20)
            
            Text(manager.isSessionRunning ? "Sensors Active" : "Sensors Inactive")
                .font(.headline)
            
            HStack(spacing: 30) {
                Button(action: {
                    Task {
                        do {
                            try await manager.startSpatialTracking()
                        } catch {
                            manager.errorMessage = error.localizedDescription
                        }
                    }
                }) {
                    Label("Start", systemImage: "play.fill")
                }
                .buttonStyle(.borderedProminent)
                .disabled(manager.isSessionRunning)
                
                Button(action: {
                    manager.stopSpatialTracking()
                }) {
                    Label("Stop", systemImage: "stop.fill")
                }
                .buttonStyle(.bordered)
                .disabled(!manager.isSessionRunning)
            }
        }
        .padding()
        .frame(width: 400, height: 300)
    }
}

// MARK: - Preview
#Preview {
    SpatialScannerView()
}
