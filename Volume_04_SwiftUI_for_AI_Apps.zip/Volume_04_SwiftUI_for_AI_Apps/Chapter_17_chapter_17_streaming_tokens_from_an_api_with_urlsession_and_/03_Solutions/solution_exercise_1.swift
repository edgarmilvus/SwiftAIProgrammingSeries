
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Foundation

// Ensure the Python server from the problem description is running on port 8080
// with the path '/plain-text-stream'

struct BasicStreamedTextView: View {
    @State private var streamedMessage: String = ""
    @State private var errorMessage: String?
    @State private var isLoading: Bool = false

    private let streamURL = URL(string: "http://localhost:8080/plain-text-stream")!

    var body: some View {
        VStack {
            Text("AI Status Monitor")
                .font(.largeTitle)
                .padding()

            if isLoading {
                ProgressView()
                    .padding()
            }

            Text(streamedMessage)
                .font(.body)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
                .padding(.horizontal)

            if let errorMessage = errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .padding()
            }

            Spacer()

            Button("Start Streaming") {
                // Clear previous state and start a new stream
                streamedMessage = ""
                errorMessage = nil
                isLoading = true
                Task {
                    await fetchStreamedText()
                }
            }
            .padding()
            .buttonStyle(.borderedProminent)
            .disabled(isLoading)
        }
        .onAppear {
            // Automatically start streaming when the view appears
            // For this exercise, we'll let the button trigger it,
            // but for a real "monitor" you'd do it here.
            // streamedMessage = ""
            // errorMessage = nil
            // isLoading = true
            // Task {
            //     await fetchStreamedText()
            // }
        }
    }

    @MainActor
    private func fetchStreamedText() async {
        do {
            let (bytes, response) = try await URLSession.shared.bytes(for: URLRequest(url: streamURL))

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                errorMessage = "Server responded with an unexpected status code."
                isLoading = false
                return
            }

            // Iterate over the AsyncBytes sequence
            for await byte in bytes {
                // Convert the byte to a String and append it.
                // For single characters, Data([byte]) and String(data:encoding:) is fine.
                // For larger chunks, you might buffer bytes before decoding to avoid
                // partial multi-byte character issues, but for ASCII/UTF-8 single chars, it's okay.
                if let char = String(data: Data([byte]), encoding: .utf8) {
                    streamedMessage.append(char)
                }
                // Small delay to make the character-by-character update visible if desired,
                // otherwise UI updates will be very fast.
                // try? await Task.sleep(for: .milliseconds(10))
            }
            isLoading = false
            print("Stream finished successfully.")

        } catch URLError.notConnectedToInternet {
            errorMessage = "No internet connection."
            isLoading = false
        } catch URLError.cannotConnectToHost {
            errorMessage = "Could not connect to the server. Is the Python server running on \(streamURL.absoluteString)?"
            isLoading = false
        } catch {
            errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
            isLoading = false
        }
    }
}

// To preview or run in an app:
// @main
// struct StreamingApp: App {
//     var body: some Scene {
//         WindowGroup {
//             BasicStreamedTextView()
//         }
//     }
// }
