
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
import SwiftUI

// 1. Define a Protocol for LLM Parameters
protocol LLMParameters: Observable, Identifiable {
    var id: UUID { get }
    var name: String { get set } // e.g., "Creative Model", "Factual Model"
    var summary: String { get } // For display in parent view
}

// 2. Create Concrete Observable LLM Parameter Classes
@Observable
class CreativeModelParameters: LLMParameters {
    let id = UUID()
    var name: String = "Creative LLM"
    var temperature: Double = 0.8
    var topP: Double = 0.9
    var maxTokens: Int = 200

    var summary: String {
        "Temp: \(temperature, specifier: "%.1f"), Top P: \(topP, specifier: "%.1f"), Max Tokens: \(maxTokens)"
    }
}

@Observable
class FactualModelParameters: LLMParameters {
    let id = UUID()
    var name: String = "Factual LLM"
    var factualityWeight: Double = 0.95 // 0.0 (creative) to 1.0 (strict fact)
    var citationStyle: String = "APA"
    var strictnessLevel: Int = 3 // 1 (loose) to 5 (very strict)

    var summary: String {
        "Fact Weight: \(factualityWeight, specifier: "%.2f"), Style: \(citationStyle), Strictness: \(strictnessLevel)"
    }
}

// 3. Main AgentConfigurationView
@available(iOS 18.0, macOS 15.0, *)
struct AgentConfigurationView: View {
    // Store instances of all available model parameters.
    // Each instance is an @Observable class, so changes within them are observed.
    @State private var allModelParameters: [any LLMParameters] = [
        CreativeModelParameters(),
        FactualModelParameters()
    ]

    // Track the currently selected model by its name for the Picker.
    @State private var selectedModelName: String

    // The active parameter object that @Bindable will use.
    // This MUST be a reference to one of the objects in `allModelParameters`.
    // It's initialized with a placeholder and updated on appear/change.
    @State private var activeParameters: any LLMParameters

    init() {
        // Initialize with the name of the first model
        _selectedModelName = State(initialValue: "Creative LLM")
        // Initialize activeParameters with a dummy or the first actual instance.
        // It will be properly set in .onAppear.
        _activeParameters = State(initialValue: CreativeModelParameters())
    }

    var body: some View {
        VStack(spacing: 20) {
            Text("AI Agent Configuration")
                .font(.largeTitle)

            Picker("Select LLM Model", selection: $selectedModelName) {
                ForEach(allModelParameters, id: \.name) { params in
                    Text(params.name).tag(params.name)
                }
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)
            // When the selected model name changes, update `activeParameters`
            .onChange(of: selectedModelName) { oldValue, newValue in
                if let newParams = allModelParameters.first(where: { $0.name == newValue }) {
                    activeParameters = newParams
                }
            }
            // Initialize activeParameters correctly when the view appears
            .onAppear {
                if let initialParams = allModelParameters.first(where: { $0.name == selectedModelName }) {
                    activeParameters = initialParams
                }
            }

            Divider()

            Text("Current \(activeParameters.name) Parameters:")
                .font(.headline)
            Text(activeParameters.summary) // Display summary from the active model

            Divider()

            // 4. Child ModelParameterEditor View
            // Pass the active parameters using @Bindable
            ModelParameterEditor(parameters: activeParameters)
        }
        .padding()
    }
}

// 4. Child ModelParameterEditor View
@available(iOS 18.0, macOS 15.0, *)
struct ModelParameterEditor: View {
    // 5. Receive the activeParameters using @Bindable
    @Bindable var parameters: any LLMParameters

    var body: some View {
        VStack(spacing: 15) {
            Text("Edit \(parameters.name) Settings")
                .font(.subheadline)

            // Dynamically display controls based on the concrete type
            if let creative = parameters as? CreativeModelParameters {
                HStack {
                    Text("Temperature:")
                    Slider(value: $creative.temperature, in: 0.0...1.5, step: 0.1) {
                        Text("Temperature")
                    } minimumValueLabel: { Text("0.0") } maximumValueLabel: { Text("1.5") }
                    Text("\(creative.temperature, specifier: "%.1f")")
                }
                HStack {
                    Text("Top P:")
                    Slider(value: $creative.topP, in: 0.0...1.0, step: 0.05) {
                        Text("Top P")
                    } minimumValueLabel: { Text("0.0") } maximumValueLabel: { Text("1.0") }
                    Text("\(creative.topP, specifier: "%.2f")")
                }
                HStack {
                    Text("Max Tokens:")
                    Stepper(value: $creative.maxTokens, in: 10...500, step: 10) {
                        Text("\(creative.maxTokens)")
                    }
                }
            } else if let factual = parameters as? FactualModelParameters {
                HStack {
                    Text("Factuality Weight:")
                    Slider(value: $factual.factualityWeight, in: 0.0...1.0, step: 0.01) {
                        Text("Factuality Weight")
                    } minimumValueLabel: { Text("0.0") } maximumValueLabel: { Text("1.0") }
                    Text("\(factual.factualityWeight, specifier: "%.2f")")
                }
                Picker("Citation Style", selection: $factual.citationStyle) {
                    Text("APA").tag("APA")
                    Text("MLA").tag("MLA")
                    Text("Chicago").tag("Chicago")
                }
                HStack {
                    Text("Strictness Level:")
                    Stepper(value: $factual.strictnessLevel, in: 1...5) {
                        Text("\(factual.strictnessLevel)")
                    }
                }
            } else {
                Text("No editable parameters for this model type.")
            }
        }
        .padding()
        .background(Color.green.opacity(0.1))
        .cornerRadius(8)
    }
}
