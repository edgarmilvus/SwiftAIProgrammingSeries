
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

@available(iOS 18.0, *)
protocol LLMService: Sendable {
    func generateResponse(prompt: String) async throws -> String
}

final class CloudLLMService: LLMService {
    func generateResponse(prompt: String) async throws -> String {
        try await Task.sleep(for: .seconds(2))
        // Simulate a potential failure for testing failover
        if prompt.contains("fail_me") { throw NSError(domain: "CloudError", code: 500) }
        return "High-quality response from Cloud (GPT-4o)."
    }
}

final class LocalLLMService: LLMService {
    func generateResponse(prompt: String) async throws -> String {
        try await Task.sleep(for: .seconds(0.5))
        return "Fast response from Local Model (Llama 3)."
    }
}

actor LLMRouter: LLMService {
    private let flagProvider: FeatureFlagProvider
    private let cloudService: CloudLLMService
    private let localService: LocalLLMService
    
    init(flagProvider: FeatureFlagProvider) {
        self.flagProvider = flagProvider
        self.cloudService = CloudLLMService()
        self.localService = LocalLLMService()
    }
    
    func generateResponse(prompt: String) async throws -> String {
        let useCloud = await flagProvider.isEnabled(.useAdvancedReasoning)
        
        if useCloud {
            print("[Telemetry] Routing to: CloudLLMService")
            do {
                return try await cloudService.generateResponse(prompt: prompt)
            } catch {
                print("[Telemetry] Cloud failed. Attempting failover to Local...")
                return try await localService.generateResponse(prompt: prompt)
            }
        } else {
            print("[Telemetry] Routing to: LocalLLMService")
            return try await localService.generateResponse(prompt: prompt)
        }
    }
}
