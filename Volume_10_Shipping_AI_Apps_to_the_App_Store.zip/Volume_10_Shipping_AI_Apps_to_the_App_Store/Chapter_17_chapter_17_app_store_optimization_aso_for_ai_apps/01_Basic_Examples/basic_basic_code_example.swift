
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import CoreML
import Vision
import Observation

/// Represents the result of an AI analysis task.
/// Using a struct ensures value semantics, which is ideal for passing data across actor boundaries.
struct AIAnalysisResult: Sendable {
    let label: String
    let confidence: Float
}

/// An error type specific to our AI processing pipeline.
enum AIError: Error, LocalizedError {
    case modelLoadingFailed
    case analysisFailed
    case invalidImageData

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed: return "Failed to initialize the AI model."
        case .analysisFailed: return "The AI could not process the image."
        case .invalidImageData: return "The provided image data is invalid."
        }
    }
}

/// `AIModelActor` is a Swift 6 actor responsible for all heavy-duty machine learning work.
///
/// ### Why an Actor?
/// In AI apps, model inference is computationally expensive and can block the main thread.
/// By using an `actor`, we guarantee that all ML operations happen on a background thread,
/// providing a "smooth" user experience that prevents churn—directly impacting ASO through better reviews.
@available(iOS 18.0, *)
actor AIModelActor {
    
    /// The Vision request object used for image classification.
    private var classificationRequest: VNCoreMLRequest?

    init() throws {
        // In a real app, you would load your specific .mlmodel here.
        // For this example, we assume a standard MobileNet or ResNet model is available.
        try setupModel()
    }

    /// Initializes the CoreML model and the Vision request.
    /// This is done within the actor to ensure the model is loaded once and safely.
    private func setupModel() throws {
        // Placeholder for actual model loading:
        // let model = try VNCoreMLModel(for: MyClassifier().model)
        // classificationRequest = VNCoreMLRequest(model: model)
        
        // For demonstration, we simulate a successful setup.
        print("AI Model loaded onto Neural Engine.")
    }

    /// Performs image analysis on a provided image.
    ///
    /// - Parameter image: The `CGImage` to analyze.
    /// - Returns: An `AIAnalysisResult` containing the top classification.
    /// - Throws: `AIError` if the process fails.
    func analyze(image: CGImage) async throws -> AIAnalysisResult {
        // Simulate heavy computation delay
        try await Task.sleep(for: .seconds(1.5))
        
        // In a real implementation, you would execute the VNCoreMLRequest here:
        // let handler = VNImageRequestHandler(cgImage: image, options: [:])
        // try handler.perform([classificationRequest].compactMap { $0 })
        
        // Mocking the result for the purpose of this pedagogical example
        return AIAnalysisResult(label: "Natural Landscape", confidence: 0.98)
    }
}

/// `AIImageViewModel` manages the UI state and coordinates between the View and the Actor.
///
/// We use the `@Observable` macro (introduced in Swift 5.9/iOS 17) for modern, 
/// efficient state management that integrates seamlessly with SwiftUI.
@available(iOS 18.0, *)
@Observable
@MainActor
class AIImageViewModel {
    
    /// The current status of the AI processing.
    var status: String = "Ready to Analyze"
    
    /// The result of the last successful analysis.
    var result: AIAnalysisResult?
    
    /// Whether the UI should show a loading spinner.
    var isProcessing: Bool = false
    
    /// The error message if something goes wrong.
    var errorMessage: String?

    /// The actor that handles the heavy lifting. 
    /// It is marked as `private` to ensure all interactions go through the ViewModel.
    private var modelActor: AIModelActor?

    init() {
        Task {
            do {
                self.modelActor = try AIModelActor()
                self.status = "AI Engine Ready (On-Device)"
            } catch {
                self.errorMessage = "Failed to initialize AI: \(error.localizedDescription)"
            }
        }
    }

    /// The primary entry point for the UI to trigger an analysis.
    ///
    /// - Parameter image: The image selected by the user.
    func processImage(_ image: CGImage) async {
        guard let actor = modelActor else {
            errorMessage = "AI Model not initialized."
            return
        }

        isProcessing = true
        errorMessage = nil
        status = "Analyzing locally..."

        do {
            // We call the actor's method. This 'awaits' the result, 
            // but because it's an actor, it doesn't block the MainActor (UI).
            let analysis = try await actor.analyze(image: image)
            
            // Once the actor returns, we are back on the @MainActor context.
            self.result = analysis
            self.status = "Analysis Complete"
        } catch {
            self.errorMessage = error.localizedDescription
            self.status = "Analysis Failed"
        }

        isProcessing = false
    }
}

/// The SwiftUI view representing the user interface.
struct AIAnalyzerView: View {
    @State private var viewModel = AIImageViewModel()
    
    // Mock image for demonstration
    let mockImage = UIImage(systemName: "photo.fill")?.cgImage

    var body: some View {
        NavigationStack {
            VStack(spacing: 30) {
                // Result Display Area
                ZStack {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.secondary.opacity(0.1))
                        .frame(height: 300)
                    
                    if let result = viewModel.result {
                        VStack {
                            Text(result.label)
                                .font(.largeTitle)
                                .fontWeight(.bold)
                            Text("Confidence: \(Int(result.confidence * 100))%")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    } else {
                        Image(systemName: "sparkles")
                            .font(.system(size: 60))
                            .foregroundStyle(.blue.opacity(0.5))
                    }
                }
                .padding()

                // Status and Feedback
                VStack(spacing: 8) {
                    Text(viewModel.status)
                        .font(.headline)
                    
                    if let error = viewModel.errorMessage {
                        Text(error)
                            .font(.caption)
                            .foregroundStyle(.red)
                    }
                }

                // Action Button
                Button {
                    Task {
                        if let image = mockImage {
                            await viewModel.processImage(image)
                        }
                    }
                } label: {
                    if viewModel.isProcessing {
                        ProgressView()
                            .tint(.white)
                            .controlSize(.large)
                    } else {
                        Text("Analyze Image (On-Device)")
                            .fontWeight(.semibold)
                            .frame(maxWidth: .infinity)
                    }
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(viewModel.isProcessing)
                .padding(.horizontal)

                Spacer()
                
                // ASO Trust Signal: Explicitly stating privacy in the UI
                // This reinforces the "Private AI" promise made in the App Store.
                HStack {
                    Image(systemName: "lock.shield.fill")
                    Text("Privacy-First: No data leaves this device.")
                }
                .font(.caption2)
                .foregroundStyle(.secondary)
                .padding(.bottom)
            }
            .navigationTitle("AI Scanner")
        }
    }
}

#Preview {
    AIAnalyzerView()
}
