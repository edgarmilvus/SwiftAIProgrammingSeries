
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CoreData
import Accelerate // For vector operations (dot product, magnitude)

// MARK: - Core Data Model (Assumed to be defined in .xcdatamodeld)
// For a self-contained solution, we'll manually define NSManagedObject subclasses
// and use an in-memory Core Data store for demonstration.

// CDDocument Entity
@objc(CDDocument)
class CDDocument: NSManagedObject {
    @NSManaged var documentId: String
    @NSManaged var filename: String
    @NSManaged var originalURL: String
    @NSManaged var chunks: NSSet? // Relationship to CDDocumentChunk
}

// CDDocumentChunk Entity
@objc(CDDocumentChunk)
class CDDocumentChunk: NSManagedObject {
    @NSManaged var chunkId: String
    @NSManaged var content: String
    @NSManaged var embedding: Data // Store [Float] as Data
    @NSManaged var startIndex: Int32
    @NSManaged var endIndex: Int32
    @NSManaged var document: CDDocument? // Relationship back to CDDocument
}

// MARK: - DocumentChunk Structure (Extended for Core Data conversion)

/// Represents a semantically meaningful chunk of a document, now including an embedding.
struct DocumentChunk: Identifiable, CustomStringConvertible {
    let id: String
    let content: String
    let documentId: String
    let startIndex: Int
    let endIndex: Int
    var embedding: [Float]? // Optional embedding vector

    var description: String {
        return "Chunk(id: \(id), docId: \(documentId), start: \(startIndex), end: \(endIndex), content: \"\(content.prefix(50))...\", embedding: \(embedding != nil ? "present" : "nil"))"
    }

    // Convenience initializer from CDDocumentChunk
    init?(from cdChunk: CDDocumentChunk) {
        guard let embeddingData = cdChunk.embedding as Data? else { return nil }
        let embeddingFloats = embeddingData.withUnsafeBytes {
            Array($0.bindMemory(to: Float.self))
        }

        self.id = cdChunk.chunkId
        self.content = cdChunk.content
        self.documentId = cdChunk.document?.documentId ?? "unknown" // Link to parent document
        self.startIndex = Int(cdChunk.startIndex)
        self.endIndex = Int(cdChunk.endIndex)
        self.embedding = embeddingFloats
    }
}

// MARK: - LLMService Protocol and LlamaCppLLMService (Mock)

/// Protocol for services that can generate vector embeddings and text completions.
protocol LLMService: EmbeddingService { // EmbeddingService from Ex. 2
    func generateCompletion(prompt: String, maxTokens: Int) async throws -> String
}

/// A mock implementation of `LLMService` simulating `llama.cpp` or Ollama interactions.
/// In a real application, this would use actual Swift bindings or an HTTP client.
@available(iOS 18.0, macOS 14.0, *)
class LlamaCppLLMService: LLMService {
    let embeddingDimension: Int = 768
    let modelName: String = "mock-llama-model" // For logging/identification

    init() {
        print("LlamaCppLLMService initialized. (Mocking actual llama.cpp/Ollama calls)")
        // In a real scenario, you'd load the model here.
        // e.g., self.llamaContext = try LlamaCppContext(modelPath: "path/to/model.gguf")
    }

    func generateEmbedding(for text: String) async throws -> [Float] {
        // Simulate actual embedding generation latency
        try await Task.sleep(for: .milliseconds(100))
        // Return a random vector as a placeholder
        return (0..<embeddingDimension).map { _ in Float.random(in: -1.0...1.0) }
    }

    func generateCompletion(prompt: String, maxTokens: Int) async throws -> String {
        // Simulate LLM completion latency
        try await Task.sleep(for: .milliseconds(500))
        let response = "Mock LLM response to query: '\(prompt.prefix(100))...' (Context managed, max \(maxTokens) tokens)"
        return response
    }
}

// MARK: - CoreDataVectorStore Class

@available(iOS 18.0, macOS 14.0, *)
class CoreDataVectorStore {
    let persistentContainer: NSPersistentContainer
    private let modelName: String

    /// Initializes the Core Data stack.
    /// - Parameter modelName: The name of the Core Data model file (.xcdatamodeld).
    /// - Parameter inMemory: If true, uses an in-memory store; otherwise, a persistent file store.
    init(modelName: String, inMemory: Bool = true) {
        self.modelName = modelName
        // Manually create NSManagedObjectModel for self-contained solution
        let managedObjectModel = NSManagedObjectModel.mergedModel(from: [Bundle.main])!
        persistentContainer = NSPersistentContainer(name: modelName, managedObjectModel: managedObjectModel)

        if inMemory {
            // Use an in-memory store for testing and self-contained examples
            persistentContainer.persistentStoreDescriptions.first?.url = URL(fileURLWithPath: "/dev/null")
        }

        persistentContainer.loadPersistentStores { _, error in
            if let error = error {
                fatalError("Failed to load Core Data stack for \(modelName): \(error.localizedDescription)")
            }
            print("Core Data stack for \(modelName) loaded successfully. In-memory: \(inMemory)")
        }
    }

    /// Saves changes in the view context.
    private func saveContext() async throws {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                context.rollback()
                throw CoreDataStoreError.saveFailed(error.localizedDescription)
            }
        }
    }

    /// Saves a new document record.
    func saveDocument(id: String, filename: String, url: URL) async throws -> CDDocument {
        let context = persistentContainer.viewContext
        let cdDocument = CDDocument(context: context)
        cdDocument.documentId = id
        cdDocument.filename = filename
        cdDocument.originalURL = url.absoluteString
        try await saveContext()
        return cdDocument
    }

    /// Saves a new chunk record for a given document.
    func saveChunk(documentId: String, chunk: DocumentChunk, embedding: [Float]) async throws -> CDDocumentChunk {
        let context = persistentContainer.viewContext

        // Find the parent document
        let fetchRequest: NSFetchRequest<CDDocument> = CDDocument.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "documentId == %@", documentId)
        guard let cdDocument = try context.fetch(fetchRequest).first else {
            throw CoreDataStoreError.documentNotFound(documentId)
        }

        let cdChunk = CDDocumentChunk(context: context)
        cdChunk.chunkId = chunk.id
        cdChunk.content = chunk.content
        cdChunk.startIndex = Int32(chunk.startIndex)
        cdChunk.endIndex = Int32(chunk.endIndex)

        // Convert [Float] to Data for storage
        let embeddingData = Data(bytes: embedding, count: embedding.count * MemoryLayout<Float>.size)
        cdChunk.embedding = embeddingData

        cdChunk.document = cdDocument // Establish relationship
        cdDocument.addToChunks(cdChunk) // Add to relationship set

        try await saveContext()
        return cdChunk
    }

    /// Retrieves all chunk embeddings along with their content and IDs.
    func getAllChunkEmbeddings() async throws -> [(chunkId: String, embedding: [Float], content: String)] {
        let context = persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<CDDocumentChunk> = CDDocumentChunk.fetchRequest()

        let cdChunks = try context.fetch(fetchRequest)
        return cdChunks.compactMap { cdChunk in
            guard let embeddingData = cdChunk.embedding as Data? else { return nil }
            let embeddingFloats = embeddingData.withUnsafeBytes {
                Array($0.bindMemory(to: Float.self))
            }
            return (chunkId: cdChunk.chunkId, embedding: embeddingFloats, content: cdChunk.content)
        }
    }

    /// Retrieves a specific chunk by its ID.
    func getChunk(by id: String) async throws -> CDDocumentChunk? {
        let context = persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<CDDocumentChunk> = CDDocumentChunk.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "chunkId == %@", id)
        return try context.fetch(fetchRequest).first
    }

    enum CoreDataStoreError: Error, LocalizedError {
        case saveFailed(String)
        case documentNotFound(String)
        case fetchFailed(String)

        var errorDescription: String? {
            switch self {
            case .saveFailed(let msg): return "Failed to save Core Data context: \(msg)"
            case .documentNotFound(let id): return "Document with ID '\(id)' not found."
            case .fetchFailed(let msg): return "Failed to fetch from Core Data: \(msg)"
            }
        }
    }
}

// MARK: - PersistentRAGService Class

@available(iOS 18.0, macOS 14.0, *)
class PersistentRAGService {
    private let vectorStore: CoreDataVectorStore
    private let llmService: LLMService
    private let chunker: DocumentIndexer // Reusing chunking logic from Ex. 1

    init(vectorStore: CoreDataVectorStore, llmService: LLMService) {
        self.vectorStore = vectorStore
        self.llmService = llmService
        self.chunker = DocumentIndexer(embeddingService: llmService) // Pass LLMService as embedding service
    }

    /// Indexes a document, generates embeddings, and saves them to Core Data.
    func indexDocument(at url: URL) async throws {
        let documentId = url.lastPathComponent
        print("Indexing document: \(documentId)")

        // 1. Save the document metadata
        _ = try await vectorStore.saveDocument(id: documentId, filename: documentId, url: url)

        // 2. Chunk the document content and generate embeddings
        let chunks = try await chunker.indexDocument(at: url) // This already generates embeddings
        
        // 3. Save each chunk with its embedding to Core Data
        for chunk in chunks {
            guard let embedding = chunk.embedding else {
                print("Warning: Chunk \(chunk.id) had no embedding generated, skipping Core Data save.")
                continue
            }
            _ = try await vectorStore.saveChunk(documentId: documentId, chunk: chunk, embedding: embedding)
        }
        print("Finished indexing and saving \(chunks.count) chunks for \(documentId) to Core Data.")
    }

    /// Answers a query by retrieving relevant chunks from Core Data, managing context, and using the LLM.
    /// - Parameters:
    ///   - query: The user's question.
    ///   - maxContextTokens: The maximum number of tokens allowed for the context in the LLM prompt.
    /// - Returns: The LLM's generated answer.
    func answerQuery(query: String, maxContextTokens: Int) async throws -> String {
        print("Answering query: '\(query)' with max context tokens: \(maxContextTokens)")

        // 1. Generate embedding for the query
        let queryEmbedding = try await llmService.generateEmbedding(for: query)

        // 2. Retrieve all chunk embeddings from Core Data
        let allCDChunksData = try await vectorStore.getAllChunkEmbeddings()
        guard !allCDChunksData.isEmpty else {
            return "No documents indexed. Please index some documents first."
        }

        // Convert to DocumentChunk for easier processing and similarity calculation
        let allChunks = allCDChunksData.compactMap { data -> DocumentChunk? in
            var chunk = DocumentChunk(id: data.chunkId, content: data.content, documentId: "unknown", startIndex: 0, endIndex: 0) // documentId, startIndex, endIndex are placeholders here
            chunk.embedding = data.embedding
            return chunk
        }

        // 3. Perform cosine similarity search
        var scoredChunks: [(chunk: DocumentChunk, similarity: Float)] = []
        for chunk in allChunks {
            guard let chunkEmbedding = chunk.embedding else { continue } // Should not happen if getAllChunkEmbeddings is correct
            let similarity = DocumentIndexer.calculateCosineSimilarity(
                vectorA: queryEmbedding,
                vectorB: chunkEmbedding
            )
            scoredChunks.append((chunk: chunk, similarity: similarity))
        }

        // Sort by similarity in descending order
        scoredChunks.sort { $0.similarity > $1.similarity }

        // 4. Context Window Management
        var contextString = ""
        var currentContextTokens = estimateTokens(for: query) // Start with query tokens
        let contextPrefix = "Context:\n"
        let contextSuffix = "\n\nBased on the provided context, answer the following question: "
        
        // Account for LLM's own prompt structure and response generation
        let overheadTokens = estimateTokens(for: contextPrefix + contextSuffix)
        let availableTokensForChunks = maxContextTokens - currentContextTokens - overheadTokens - 50 // -50 for LLM response buffer

        if availableTokensForChunks <= 0 {
            print("Warning: Not enough tokens available for context chunks after accounting for query and prompt overhead.")
            return "Query is too long or context window is too small to provide meaningful context."
        }

        var addedChunkCount = 0
        for (chunk, _) in scoredChunks {
            let chunkTokens = estimateTokens(for: chunk.content)
            if currentContextTokens + chunkTokens < availableTokensForChunks {
                contextString += "- \(chunk.content)\n"
                currentContextTokens += chunkTokens
                addedChunkCount += 1
            } else {
                // Option B: Prioritize by similarity and drop less relevant chunks
                // For simplicity, we just stop adding once the limit is hit.
                // More advanced: truncate the last chunk if it almost fits.
                break
            }
        }
        print("Added \(addedChunkCount) chunks to context, total estimated context tokens: \(currentContextTokens)")

        // 5. Construct the final prompt for the LLM
        let finalPrompt = "\(contextPrefix)\(contextString)\(contextSuffix)\(query)"

        // 6. Call LLM for completion
        let llmResponse = try await llmService.generateCompletion(prompt: finalPrompt, maxTokens: maxContextTokens - currentContextTokens)
        return llmResponse
    }

    /// Helper to estimate tokens (simple char count / 4).
    /// In a real system, a proper tokenizer would be used.
    private func estimateTokens(for text: String) -> Int {
        return text.count / 4
    }
    
    enum PersistentRAGServiceError: Error, LocalizedError {
        case noChunksIndexed
        case llmError(String)
        case indexingError(String)
        
        var errorDescription: String? {
            switch self {
            case .noChunksIndexed: return "No chunks have been indexed in the vector store."
            case .llmError(let msg): return "LLM Service error: \(msg)"
            case .indexingError(let msg): return "Document indexing failed: \(msg)"
            }
        }
    }
}

// MARK: - Example Usage (for testing)

@available(iOS 18.0, macOS 14.0, *)
func runExercise3() async {
    print("\n--- Exercise 3: Persistent Local Vector Store with Core Data and Context Window Management ---")

    // 1. Setup Core Data and LLM services
    let coreDataStore = CoreDataVectorStore(modelName: "RAGModel", inMemory: true) // Using in-memory for testing
    let llmService = LlamaCppLLMService() // Mock LLM service
    let ragService = PersistentRAGService(vectorStore: coreDataStore, llmService: llmService)

    // 2. Create dummy text files
    let doc1Content = """
    Swift is a general-purpose, multi-paradigm, compiled programming language developed by Apple Inc. for iOS, iPadOS, macOS, watchOS, tvOS, Linux, and z/OS. Swift is designed to work with Apple's Cocoa and Cocoa Touch frameworks and the large body of existing Objective-C code written for Apple products.
    The language is intended to be safer, faster, and more modern than Objective-C. It was introduced at Apple's 2014 Worldwide Developers Conference (WWDC).
    """
    let doc2Content = """
    Machine learning (ML) is a field of artificial intelligence (AI) that uses statistical techniques to give computer systems the ability to "learn" from data, without being explicitly programmed. ML explores the study and construction of algorithms that can learn from and make predictions on data.
    Common applications include recommendation systems, image recognition, natural language processing (NLP), and medical diagnosis.
    """
    let doc3Content = """
    The history of artificial intelligence (AI) began in antiquity, with myths, stories and rumors of artificial beings endowed with intelligence or consciousness by master craftsmen. The seeds of modern AI were planted by classical philosophers who attempted to describe the process of human thinking as the mechanical manipulation of symbols.
    The field of AI research was founded at a workshop at Dartmouth College in 1956.
    """

    let filename1 = "swift_language.txt"
    let filename2 = "machine_learning.txt"
    let filename3 = "history_of_ai.txt"

    let fileURL1 = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(filename1)
    let fileURL2 = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(filename2)
    let fileURL3 = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(filename3)

    do {
        try doc1Content.write(to: fileURL1, atomically: true, encoding: .utf8)
        try doc2Content.write(to: fileURL2, atomically: true, encoding: .utf8)
        try doc3Content.write(to: fileURL3, atomically: true, encoding: .utf8)
        print("Dummy files created.")

        // 3. Index documents
        try await ragService.indexDocument(at: fileURL1)
        try await ragService.indexDocument(at: fileURL2)
        try await ragService.indexDocument(at: fileURL3)

        // 4. Answer queries with context management
        let maxLLMContextTokens = 500 // Simulate an LLM context window limit

        print("\n--- Query 1: Swift programming ---")
        let query1 = "When was Swift introduced and what are its key advantages?"
        let answer1 = try await ragService.answerQuery(query: query1, maxContextTokens: maxLLMContextTokens)
        print("LLM Answer: \(answer1)")

        print("\n--- Query 2: AI and ML applications ---")
        let query2 = "What are some common applications of machine learning and when was AI research founded?"
        let answer2 = try await ragService.answerQuery(query: query2, maxContextTokens: maxLLMContextTokens)
        print("LLM Answer: \(answer2)")
        
        print("\n--- Query 3: Short context window test ---")
        let query3 = "Tell me about Swift."
        let answer3 = try await ragService.answerQuery(query: query3, maxContextTokens: 100) // Smaller context
        print("LLM Answer: \(answer3)")


        // 5. Clean up dummy files
        try FileManager.default.removeItem(at: fileURL1)
        try FileManager.default.removeItem(at: fileURL2)
        try FileManager.default.removeItem(at: fileURL3)
        print("\nDummy files removed.")

    } catch {
        print("Error during Exercise 3: \(error.localizedDescription)")
    }
}

// To run this example in a playground or app:
// Task {
//     await runExercise3()
// }
