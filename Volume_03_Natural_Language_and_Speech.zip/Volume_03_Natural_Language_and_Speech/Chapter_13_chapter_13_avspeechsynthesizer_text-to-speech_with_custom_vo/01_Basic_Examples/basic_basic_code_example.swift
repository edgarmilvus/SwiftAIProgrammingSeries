
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import AVFoundation // Essential for speech synthesis

// MARK: - VoiceAssistant Class Definition

/// A simple voice assistant class that utilizes AVSpeechSynthesizer to convert text into spoken audio.
/// This class encapsulates the logic for text-to-speech, making it easy to integrate into various applications.
/// It's designed to be robust and handle basic speech synthesis operations.
@available(iOS 13.0, macOS 10.15, tvOS 13.0, watchOS 6.0, *) // AVSpeechSynthesizer is available much earlier (iOS 7.0),
                                                           // but we use a modern baseline for contemporary Swift 6 projects.
class VoiceAssistant {
    /// The core engine for speech synthesis.
    /// It's crucial to keep a strong reference to `AVSpeechSynthesizer`
    /// for the duration of speech. If this object is deallocated prematurely,
    /// any ongoing or pending speech will be interrupted or never start.
    private let synthesizer = AVSpeechSynthesizer()

    /// Initializes a new instance of the VoiceAssistant.
    /// For basic functionality, no specific setup is required during initialization.
    init() {
        // In a more advanced scenario, you might configure AVAudioSession here
        // to manage audio behavior (e.g., playing in the background, mixing with other audio).
        // For this basic example, we rely on the system's default audio session behavior.
    }

    /// Speaks the given text using a configurable voice and speech parameters.
    ///
    /// - Parameter text: The string of text to be spoken by the assistant.
    /// - Parameter language: An optional BCP-47 language code (e.g., "en-US", "fr-FR").
    ///                       If `nil`, the system's default voice for the current locale is used.
    /// - Parameter rate: The speed of speech. A value between `AVSpeechUtteranceMinimumSpeechRate`
    ///                   and `AVSpeechUtteranceMaximumSpeechRate`. Default is `AVSpeechUtteranceDefaultSpeechRate`.
    ///                   A value like 0.5 makes it slower, 0.75 is a good balance.
    /// - Parameter pitchMultiplier: The pitch of the voice. A value between 0.5 and 2.0. Default is 1.0.
    ///                            Less than 1.0 lowers the pitch, greater than 1.0 raises it.
    /// - Parameter volume: The volume of the speech. A value between 0.0 (silent) and 1.0 (full volume).
    ///                     Default is 1.0.
    func speak(
        _ text: String,
        language: String? = "en-US", // Default to US English for consistency
        rate: Float = 0.5,           // Slightly slower for better clarity
        pitchMultiplier: Float = 1.0, // Normal pitch
        volume: Float = 1.0          // Full volume
    ) {
        // 1. Create an AVSpeechUtterance:
        // This object is the fundamental unit of speech. It holds the text and
        // all the parameters that define how that text should be spoken.
        let utterance = AVSpeechUtterance(string: text)

        // 2. Configure the Utterance:
        // These properties allow for fine-grained control over the speech output,
        // making the assistant's voice more expressive and understandable.

        // Set the speech rate.
        // `AVSpeechUtteranceDefaultSpeechRate` is usually around 0.5 for English.
        // We clamp the provided rate to ensure it's within the valid range.
        utterance.rate = max(AVSpeechUtteranceMinimumSpeechRate, min(AVSpeechUtteranceMaximumSpeechRate, rate))

        // Set the pitch multiplier.
        // Clamped to the valid range [0.5, 2.0].
        utterance.pitchMultiplier = max(0.5, min(2.0, pitchMultiplier))

        // Set the volume.
        // Clamped to the valid range [0.0, 1.0].
        utterance.volume = max(0.0, min(1.0, volume))

        // Set the voice.
        // If a language is specified, we try to find a voice for that language.
        // If no specific voice is found or `language` is nil, the system will
        // automatically select the default voice for the current device's locale.
        if let languageCode = language, let specificVoice = AVSpeechSynthesisVoice(language: languageCode) {
            utterance.voice = specificVoice
        } else if language != nil {
            // This case handles when a specific language was requested but no matching voice was found.
            print("Warning: Specific voice for language '\(language ?? "unknown")' not found. Using system default.")
        }
        // If `language` is nil, `utterance.voice` remains nil, which defaults to the system voice.


        // 3. Initiate Speech:
        // The `speak` method tells the synthesizer to start processing and speaking the utterance.
        // The synthesizer manages the audio playback asynchronously.
        synthesizer.speak(utterance)
        print("Assistant speaking: \"\(text)\"")
    }

    /// Stops any ongoing speech synthesis immediately.
    ///
    /// - Parameter boundary: Specifies whether to stop at the current word or sentence boundary.
    ///                       `.immediate` stops instantly, `.word` waits for the current word to finish,
    ///                       `.sentence` waits for the current sentence to finish.
    func stopSpeaking(at boundary: AVSpeechBoundary = .immediate) {
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: boundary)
            print("Assistant stopped speaking.")
        }
    }

    /// Pauses any ongoing speech synthesis.
    /// Speech can be resumed later using `continueSpeaking()`.
    func pauseSpeaking() {
        if synthesizer.isSpeaking && !synthesizer.isPaused {
            // Pausing at `.word` boundary provides a more natural interruption.
            synthesizer.pauseSpeaking(at: .word)
            print("Assistant paused speaking.")
        }
    }

    /// Continues speech synthesis after a pause.
    func continueSpeaking() {
        if synthesizer.isPaused {
            synthesizer.continueSpeaking()
            print("Assistant continued speaking.")
        }
    }

    /// Checks if the assistant is currently speaking.
    var isSpeaking: Bool {
        return synthesizer.isSpeaking
    }

    /// Checks if the assistant is currently paused.
    var isPaused: Bool {
        return synthesizer.isPaused
    }
}

// MARK: - Simulation of Voice Assistant Interaction

/// This section demonstrates how the `VoiceAssistant` class can be used within an application.
/// We simulate user input and the assistant's spoken responses, including pausing and stopping.
/// This code block is designed to be run in a Swift Playground or a similar execution environment
/// where asynchronous operations and audio output are supported.

@available(iOS 13.0, macOS 10.15, tvOS 13.0, watchOS 6.0, *)
func simulateVoiceAssistantInteraction() async {
    print("--- Starting SwiftVoice Assistant Simulation ---")

    // 1. Initialize the Voice Assistant
    // In a real application, this instance would typically be managed by a ViewModel,
    // a dedicated service, or a UIViewController/NSViewController.
    let assistant = VoiceAssistant()

    // Helper to simulate speech duration for better demo flow
    func simulateSpeechDelay(text: String) async {
        // A rough estimate: 70 milliseconds per character for a typical speech rate.
        // This makes the simulation wait approximately as long as it takes to speak the text.
        let delayNanoseconds = UInt64(text.count * 70_000_000)
        await Task.sleep(nanoseconds: delayNanoseconds)
    }

    // 2. Simulate User Interaction and Assistant Responses

    // First interaction: Greeting
    print("\nUser: Hello, assistant!")
    let greeting = "Hello there! How can I help you today?"
    assistant.speak(greeting)
    await simulateSpeechDelay(text: greeting)

    // Second interaction: Asking a question with a different voice parameter
    print("\nUser: Can you tell me about the weather?")
    let weatherInfo = "I'm sorry, I don't have access to real-time weather data at the moment. Perhaps you could try a dedicated weather app?"
    assistant.speak(weatherInfo, rate: 0.6, pitchMultiplier: 1.1) // Slightly faster, higher pitch
    await simulateSpeechDelay(text: weatherInfo)

    // Third interaction: A longer message, demonstrating pause/continue/stop functionality
    print("\nUser: Tell me a long story.")
    let longStory = "Once upon a time, in a land far, far away, there lived a brave knight named Sir Reginald. He embarked on a perilous quest to find the legendary Crystal of Eldoria, which was said to hold immense power. His journey took him through enchanted forests, across treacherous mountains, and into the dark depths of the Dragon's Lair. Along the way, he encountered many magical creatures, some friendly, some fearsome. He faced challenges that tested his courage, his strength, and his wit. But with unwavering determination, Sir Reginald pressed on, always remembering the prophecy that foretold his destiny. His adventures were legendary, and his name was whispered with reverence throughout the realms for generations to come."
    assistant.speak(longStory)

    // Simulate user pausing the assistant mid-story
    print("\n(Simulating user pausing after a few seconds...)")
    await Task.sleep(nanoseconds: 5_000_000_000) // Wait 5 seconds
    assistant.pauseSpeaking()
    await Task.sleep(nanoseconds: 2_000_000_000) // Wait 2 seconds in paused state

    // Simulate user continuing the story
    print("\n(Simulating user continuing...)")
    assistant.continueSpeaking()
    await Task.sleep(nanoseconds: 5_000_000_000) // Let it speak for 5 more seconds

    // Simulate user stopping the story
    print("\n(Simulating user stopping the story...)")
    assistant.stopSpeaking()

    // Fourth interaction: Final farewell
    print("\nUser: Thank you!")
    let farewell = "You're most welcome! Have a great day."
    assistant.speak(farewell)
    await simulateSpeechDelay(text: farewell)

    print("\n--- SwiftVoice Assistant Simulation Ended ---")
}

// To run this code in a Swift Playground or a command-line tool:
// You need to call the async function. In a Playground, a Task block is suitable.
Task {
    await simulateVoiceAssistantInteraction()
}

// For Swift Playgrounds, this line is necessary to keep the Playground running
// long enough to complete all asynchronous tasks, including speech synthesis.
import PlaygroundSupport
PlaygroundSupport.PlaygroundPage.current.needsIndefiniteExecution = true
