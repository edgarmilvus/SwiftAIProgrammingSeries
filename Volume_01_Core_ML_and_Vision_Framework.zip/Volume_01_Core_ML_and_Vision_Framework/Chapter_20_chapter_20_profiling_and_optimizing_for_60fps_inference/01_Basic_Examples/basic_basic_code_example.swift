
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import CoreML
import Vision
import UIKit // For UIImage and related image processing
import Foundation // For CFAbsoluteTimeGetCurrent

/// A utility class to perform image classification using a Core ML model
/// and measure the inference time.
@available(iOS 13.0, macOS 10.15, *) // ResNet50 and Vision APIs are widely available
class ImageInferenceTimer {

    private let model: VNCoreMLModel
    private let request: VNCoreMLRequest

    /// Initializes the ImageInferenceTimer with a specified Core ML model.
    /// - Parameter modelName: The name of the Core ML model in your app bundle (e.g., "ResNet50").
    /// - Throws: An error if the model cannot be loaded or initialized.
    init(modelName: String) throws {
        // 1. Load the Core ML model
        // We assume the model is compiled and available in the app's main bundle.
        // For ResNet50, you can download it from Apple's Core ML Models page
        // or add it directly from Xcode's File -> Add Files to "Your Project" menu.
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            fatalError("Failed to find model \(modelName).mlmodelc in app bundle. Make sure it's added to your project and target.")
        }

        let compiledModel = try MLModel(contentsOf: modelURL)
        
        // 2. Create a VNCoreMLModel from the MLModel.
        // VNCoreMLModel wraps an MLModel for use with the Vision framework.
        self.model = try VNCoreMLModel(for: compiledModel)

        // 3. Create a VNCoreMLRequest.
        // This request will perform the classification using the loaded model.
        // We provide a completion handler to process the results asynchronously.
        self.request = VNCoreMLRequest(model: self.model) { [weak self] request, error in
            self?.processClassifications(for: request, error: error)
        }

        // Optional: Set up image crop and scale options.
        // This is crucial for performance and accuracy, as models expect specific input sizes.
        // VNImageCropAndScaleOption.centerCrop ensures the image is cropped to the model's
        // expected aspect ratio and then scaled, preserving the central content.
        self.request.imageCropAndScaleOption = .centerCrop
    }

    /// Performs image classification on the given UIImage and measures the inference time.
    /// - Parameter image: The UIImage to classify.
    /// - Returns: The time taken for the inference in milliseconds, or nil if an error occurred.
    @discardableResult
    func performInference(on image: UIImage) -> TimeInterval? {
        guard let cgImage = image.cgImage else {
            print("Failed to convert UIImage to CGImage.")
            return nil
        }

        // 4. Execute the inference request and measure its duration.
        // VNImageRequestHandler handles the image preprocessing and dispatches the
        // Core ML inference. It can take various image inputs (CGImage, CVPixelBuffer, URL, Data).
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        let startTime = CFAbsoluteTimeGetCurrent() // Mark the start time

        do {
            try handler.perform([request]) // Perform the Vision requests (including Core ML inference)
            let endTime = CFAbsoluteTimeGetCurrent() // Mark the end time
            let inferenceDuration = (endTime - startTime) * 1000 // Convert to milliseconds
            print("Inference completed in \(String(format: "%.2f", inferenceDuration)) ms")
            return inferenceDuration
        } catch {
            print("Failed to perform inference: \(error.localizedDescription)")
            return nil
        }
    }

    /// Processes the classification results from the VNCoreMLRequest.
    /// This method is called asynchronously by the Vision framework.
    /// - Parameters:
    ///   - request: The VNCoreMLRequest that completed.
    ///   - error: An optional error if the request failed.
    private func processClassifications(for request: VNRequest, error: Error?) {
        guard let classifications = request.results as? [VNClassificationObservation] else {
            print("Invalid classification results: \(error?.localizedDescription ?? "Unknown error")")
            return
        }

        // Sort the classifications by confidence in descending order
        let topClassifications = classifications.sorted { $0.confidence > $1.confidence }.prefix(5)

        print("Top 5 Classifications:")
        for (index, classification) in topClassifications.enumerated() {
            print("  \(index + 1). \(classification.identifier) (Confidence: \(String(format: "%.2f", classification.confidence * 100))%)")
        }
    }
}

// MARK: - Example Usage

// This extension provides a simple way to create a dummy UIImage for testing.
// In a real app, this would come from the camera, photo library, or a network request.
extension UIImage {
    /// Creates a solid color UIImage for testing purposes.
    static func solidColor(color: UIColor, size: CGSize) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        color.setFill()
        UIRectFill(CGRect(origin: .zero, size: size))
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
}

// Main execution block (e.g., in an AppDelegate, ViewController, or playground)
@main
@available(iOS 13.0, macOS 10.15, *)
struct InferenceApp {
    static func main() {
        // Ensure you have ResNet50.mlmodelc in your project bundle.
        // You can download it from developer.apple.com/machine-learning/models/
        // and drag it into your Xcode project. Xcode will automatically compile it to .mlmodelc.
        let modelName = "ResNet50"

        do {
            let timer = try ImageInferenceTimer(modelName: modelName)

            // Create a sample image (e.g., a red square) for demonstration.
            // In a real app, this would be a frame from a camera feed.
            guard let sampleImage = UIImage.solidColor(color: .red, size: CGSize(width: 224, height: 224)) else {
                fatalError("Could not create sample image.")
            }

            print("\n--- Performing Inference on Sample Image ---")
            timer.performInference(on: sampleImage)

            // Simulate a second inference to show consistency
            print("\n--- Performing Second Inference ---")
            timer.performInference(on: sampleImage)

            // Example of a larger image, which might incur more preprocessing time
            guard let largeImage = UIImage.solidColor(color: .blue, size: CGSize(width: 1920, height: 1080)) else {
                fatalError("Could not create large image.")
            }
            print("\n--- Performing Inference on Larger Image ---")
            timer.performInference(on: largeImage)


        } catch {
            print("Error initializing ImageInferenceTimer: \(error.localizedDescription)")
        }
    }
}
