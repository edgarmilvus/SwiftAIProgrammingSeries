
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CoreML
import Vision
import UIKit // For UIImage and CIImage

// MARK: - FloraClassifier App Core Logic

/// A utility class to manage and perform image classification using a Core ML model.
/// This class is designed to be thread-safe and efficient for on-device inference.
@available(iOS 18.0, *) // Requires latest iOS SDK for some async features and potentially newer Vision APIs
actor FloraClassifier {

    /// Represents the classification result, including the identified plant and its confidence.
    struct ClassificationResult: Identifiable {
        let id = UUID()
        let label: String
        let confidence: Float
    }

    private var coreMLModel: MLModel?
    private var visionCoreMLModel: VNCoreMLModel?

    /// Initializes the FloraClassifier by loading the Core ML model.
    /// - Parameter modelName: The name of the .mlmodelc file in the app bundle.
    /// - Throws: `FloraClassifierError` if the model cannot be loaded.
    init(modelName: String) async throws {
        // Step 1: Load the Core ML model with a specific configuration.
        // This is where we can specify compute units for optimization.
        let config = MLModelConfiguration()
        
        // CRITICAL FOR ON-DEVICE PERFORMANCE:
        // By default, Core ML attempts to use the most efficient compute unit.
        // For quantized models, the Neural Engine (if available) is often the fastest.
        // For models that are not Neural Engine compatible or for debugging, CPU_ONLY might be useful.
        // For general purpose, ALL is a good default, letting Core ML decide.
        // For specific optimization, consider .neuralEngine or .cpuAndGPU.
        config.computeUnits = .all // Core ML will intelligently choose the best available unit.
                                  // For a quantized model, this often means the Neural Engine.
        
        guard let url = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            throw FloraClassifierError.modelNotFound(name: modelName)
        }

        do {
            self.coreMLModel = try MLModel(contentsOf: url, configuration: config)
            self.visionCoreMLModel = try VNCoreMLModel(for: self.coreMLModel!)
            print("Successfully loaded Core ML model: \(modelName) with compute units: \(config.computeUnits)")
        } catch {
            print("Error loading Core ML model: \(error.localizedDescription)")
            throw FloraClassifierError.modelLoadingFailed(underlyingError: error)
        }
    }

    /// Performs image classification on a given `UIImage`.
    /// - Parameter image: The `UIImage` to classify.
    /// - Returns: An array of `ClassificationResult` sorted by confidence.
    /// - Throws: `FloraClassifierError` if classification fails or model is not loaded.
    func classifyImage(_ image: UIImage) async throws -> [ClassificationResult] {
        guard let visionCoreMLModel = self.visionCoreMLModel else {
            throw FloraClassifierError.modelNotInitialized
        }

        guard let ciImage = CIImage(image: image) else {
            throw FloraClassifierError.imageConversionFailed
        }

        return try await withCheckedThrowingContinuation { continuation in
            // Step 2: Create a Vision request for Core ML model inference.
            let request = VNCoreMLRequest(model: visionCoreMLModel) { request, error in
                if let error = error {
                    print("Vision request failed with error: \(error.localizedDescription)")
                    continuation.resume(throwing: FloraClassifierError.classificationFailed(underlyingError: error))
                    return
                }

                // Step 3: Process the classification results.
                guard let observations = request.results as? [VNClassificationObservation] else {
                    print("No classification observations found.")
                    continuation.resume(throwing: FloraClassifierError.noObservations)
                    return
                }

                let results = observations.map { observation in
                    ClassificationResult(label: observation.identifier, confidence: observation.confidence)
                }
                .sorted { $0.confidence > $1.confidence } // Sort by highest confidence first
                
                continuation.resume(returning: results)
            }

            // Optional: Configure image preprocessing.
            // For example, if your model expects a specific image orientation or aspect ratio.
            request.imageCropAndScaleOption = .centerCrop // Common for image classification models.

            // Step 4: Perform the Vision request on the image.
            let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])
            do {
                try handler.perform([request])
            } catch {
                print("Failed to perform Vision request: \(error.localizedDescription)")
                continuation.resume(throwing: FloraClassifierError.visionRequestFailed(underlyingError: error))
            }
        }
    }

    /// Custom error type for the FloraClassifier.
    enum FloraClassifierError: Error, LocalizedError {
        case modelNotFound(name: String)
        case modelLoadingFailed(underlyingError: Error)
        case modelNotInitialized
        case imageConversionFailed
        case classificationFailed(underlyingError: Error)
        case noObservations
        case visionRequestFailed(underlyingError: Error)

        var errorDescription: String? {
            switch self {
            case .modelNotFound(let name):
                return "Core ML model '\(name).mlmodelc' not found in the app bundle. Did you add it to the project?"
            case .modelLoadingFailed(let error):
                return "Failed to load Core ML model: \(error.localizedDescription)"
            case .modelNotInitialized:
                return "Core ML model is not initialized. Ensure 'init' completed successfully."
            case .imageConversionFailed:
                return "Failed to convert UIImage to CIImage for Vision processing."
            case .classificationFailed(let error):
                return "Image classification failed: \(error.localizedDescription)"
            case .noObservations:
                return "No classification observations were returned by the model."
            case .visionRequestFailed(let error):
                return "Vision image request failed: \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - Example Usage in an App (e.g., a ViewController or ViewModel)

/// This class simulates a part of a ViewController or ViewModel that uses the FloraClassifier.
@MainActor // UI updates must happen on the main actor.
@available(iOS 18.0, *)
class AppCoordinator {
    private var floraClassifier: FloraClassifier?
    
    // Placeholder for UI element that would display results
    var classificationText: String = "Loading classifier..." {
        didSet {
            print("UI Update: \(classificationText)")
            // In a real app, this would update a UILabel or SwiftUI Text view.
        }
    }

    init() {
        // Initialize the classifier asynchronously.
        Task {
            do {
                self.floraClassifier = try await FloraClassifier(modelName: "FloraClassifier")
                classificationText = "Classifier ready. Take a picture!"
            } catch {
                classificationText = "Error loading classifier: \(error.localizedDescription)"
            }
        }
    }

    /// Simulates taking a picture and classifying it.
    /// - Parameter image: The image captured by the user.
    func processCapturedImage(_ image: UIImage) {
        guard let classifier = floraClassifier else {
            classificationText = "Classifier not ready yet."
            return
        }

        classificationText = "Classifying image..."

        Task {
            do {
                let results = try await classifier.classifyImage(image)
                if let topResult = results.first {
                    classificationText = "Identified: \(topResult.label) (\(String(format: "%.2f%%", topResult.confidence * 100)))"
                } else {
                    classificationText = "Could not identify the plant."
                }
            } catch {
                classificationText = "Classification error: \(error.localizedDescription)"
            }
        }
    }
    
    // Example of how to trigger classification (e.g., from a button tap)
    func simulateImageCapture() {
        // In a real app, this would come from UIImagePickerController or Camera API.
        // For this example, let's create a dummy image.
        UIGraphicsBeginImageContextWithOptions(CGSize(width: 224, height: 224), false, 1.0)
        let context = UIGraphicsGetCurrentContext()!
        UIColor.green.setFill()
        context.fill(CGRect(x: 0, y: 0, width: 224, height: 224))
        // Add some "flower" like shapes for visual distinction
        UIColor.red.setFill()
        context.addEllipse(in: CGRect(x: 50, y: 50, width: 124, height: 124))
        context.fillPath()
        let dummyImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        processCapturedImage(dummyImage)
    }
}

// MARK: - How to Run This Example (e.g., in an AppDelegate or SwiftUI App)

/*
// In an iOS app's AppDelegate.swift (for UIKit) or a SwiftUI App struct:

@main
@available(iOS 18.0, *)
struct MyApp: App {
    let appCoordinator = AppCoordinator()

    var body: some Scene {
        WindowGroup {
            // In a SwiftUI app, you'd integrate appCoordinator into your View.
            // For a quick test, you can just call a method.
            ContentView(appCoordinator: appCoordinator)
                .onAppear {
                    // Simulate image capture after a short delay
                    Task {
                        try await Task.sleep(for: .seconds(2))
                        appCoordinator.simulateImageCapture()
                    }
                }
        }
    }
}

// Example SwiftUI ContentView
@available(iOS 18.0, *)
struct ContentView: View {
    @ObservedObject var appCoordinator: AppCoordinator // Use @ObservedObject for UIKit-style objects

    var body: some View {
        VStack {
            Text(appCoordinator.classificationText)
                .font(.title)
                .padding()
            Button("Classify Dummy Image") {
                appCoordinator.simulateImageCapture()
            }
        }
    }
}
*/

// For a quick playground test (requires a dummy FloraClassifier.mlmodelc in Resources):
// Make sure to drag a dummy "FloraClassifier.mlmodelc" into your project's Resources folder.
// You can create an empty directory named "FloraClassifier.mlmodelc" and drag it in for this test.
// The actual model won't load, but the error handling will be demonstrated.

/*
import PlaygroundSupport

@available(iOS 18.0, *)
Task {
    let appCoordinator = AppCoordinator()
    // Give it a moment to initialize
    try await Task.sleep(for: .seconds(1))
    appCoordinator.simulateImageCapture()
    // Keep the playground running to see async results
    PlaygroundPage.current.needsIndefiniteExecution = true
}
*/
