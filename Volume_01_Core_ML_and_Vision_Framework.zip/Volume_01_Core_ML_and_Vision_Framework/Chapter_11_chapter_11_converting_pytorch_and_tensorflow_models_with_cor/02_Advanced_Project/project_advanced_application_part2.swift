
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreML
import Vision
import UIKit // For UIImage, CGImage, and drawing context if needed
import CoreGraphics // For CGRect, CGSize

// MARK: - 1. Custom Errors for Document Analysis
/// Defines specific errors that can occur during document analysis.
@available(iOS 17.0, *)
enum DocumentAnalyzerError: Error, LocalizedError {
    case modelLoadingFailed(Error)
    case visionRequestFailed(Error)
    case invalidModelOutput(String)
    case imageProcessingFailed(String)
    case noObservationsFound
    case invalidBoundingBoxCoordinates

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let error):
            return "Failed to load the Core ML model: \(error.localizedDescription)"
        case .visionRequestFailed(let error):
            return "Vision request failed: \(error.localizedDescription)"
        case .invalidModelOutput(let detail):
            return "The Core ML model produced unexpected output: \(detail)"
        case .imageProcessingFailed(let detail):
            return "Image processing failed: \(detail)"
        case .noObservationsFound:
            return "No valid observations were found after inference and post-processing."
        case .invalidBoundingBoxCoordinates:
            return "Detected bounding box coordinates are invalid."
        }
    }
}

// MARK: - 2. Data Structure for Detected Objects
/// Represents a detected object with its bounding box, label, and confidence.
@available(iOS 17.0, *)
struct DetectedObject: Identifiable, Hashable {
    let id = UUID()
    let label: String
    let confidence: Float
    /// The bounding box in normalized coordinates (0.0 to 1.0) relative to the image.
    let boundingBox: CGRect
    /// The class index from the model's output.
    let classIndex: Int
}

// MARK: - 3. Document Analyzer Class
/// `DocumentAnalyzer` is responsible for loading a custom Core ML object detection model,
/// performing inference using Vision, and post-processing the raw model outputs
/// (bounding boxes, scores) to yield structured `DetectedObject` results.
@available(iOS 17.0, *)
class DocumentAnalyzer {
    private let modelName: String
    private let classLabels: [String]
    private let confidenceThreshold: Float
    private let iouThreshold: Float // Intersection Over Union for NMS

    private var visionCoreMLModel: VNCoreMLModel!
    private var visionCoreMLRequest: VNCoreMLRequest!

    /// Initializes the DocumentAnalyzer with the model name, class labels, and thresholds.
    /// - Parameters:
    ///   - modelName: The name of the .mlmodel file (e.g., "DocumentDetector").
    ///   - classLabels: An array of strings representing the class labels in order corresponding to model outputs.
    ///   - confidenceThreshold: The minimum confidence score for a detection to be considered valid.
    ///   - iouThreshold: The Intersection Over Union (IoU) threshold for Non-Maximum Suppression.
    init(modelName: String, classLabels: [String], confidenceThreshold: Float = 0.5, iouThreshold: Float = 0.45) {
        self.modelName = modelName
        self.classLabels = classLabels
        self.confidenceThreshold = confidenceThreshold
        self.iouThreshold = iouThreshold
    }

    /// Asynchronously loads the Core ML model and sets up the Vision request.
    /// This should be called once, typically during app startup or when the analyzer is first needed.
    func loadModel() async throws {
        // Under the Hood: Core ML model files are compiled into .mlmodelc directories
        // and loaded from the app bundle.
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            throw DocumentAnalyzerError.modelLoadingFailed(
                NSError(domain: "DocumentAnalyzer", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model \(modelName).mlmodelc not found in bundle."])
            )
        }

        do {
            let coreMLModel = try MLModel(contentsOf: modelURL)
            self.visionCoreMLModel = try VNCoreMLModel(for: coreMLModel)
            
            // Under the Hood: VNCoreMLRequest handles image scaling and pixel format conversion
            // to match the Core ML model's input requirements. It also manages the Core ML inference.
            self.visionCoreMLRequest = VNCoreMLRequest(model: self.visionCoreMLModel) { [weak self] request, error in
                // This completion handler is primarily for internal Vision processing.
                // We will handle the results and errors in the `analyzeDocument`'s await context.
                if let error = error {
                    print("Vision Core ML request encountered an error: \(error.localizedDescription)")
                }
            }
            // Configure the request for performance and accuracy
            self.visionCoreMLRequest.imageCropAndScaleOption = .scaleFit // Or .scaleFill, .centerCrop based on model training
            // Optional: If the model has flexible input shapes, Vision can optimize for that.
            // self.visionCoreMLRequest.usesFlexibleInputSizes = true // iOS 14+
            
            print("Core ML model '\(modelName)' loaded and Vision request configured successfully.")

        } catch {
            throw DocumentAnalyzerError.modelLoadingFailed(error)
        }
    }

    /// Analyzes a given image to detect document elements.
    /// - Parameter image: The `UIImage` to analyze.
    /// - Returns: An array of `DetectedObject` instances.
    /// - Throws: `DocumentAnalyzerError` if analysis fails at any stage.
    func analyzeDocument(image: UIImage) async throws -> [DetectedObject] {
        guard let cgImage = image.cgImage else {
            throw DocumentAnalyzerError.imageProcessingFailed("Could not get CGImage from UIImage.")
        }

        // 1. Ensure model is loaded
        guard visionCoreMLRequest != nil else {
            throw DocumentAnalyzerError.modelLoadingFailed(
                NSError(domain: "DocumentAnalyzer", code: 2, userInfo: [NSLocalizedDescriptionKey: "Model not loaded. Call loadModel() first."])
            )
        }
        
        // 2. Create Vision Request Handler
        // Under the Hood: VNImageRequestHandler prepares the input image for the Vision pipeline.
        // It handles image orientation, scaling, and pixel buffer creation.
        let handler = VNImageRequestHandler(cgImage: cgImage, orientation: image.imageOrientation.toCGImagePropertyOrientation())

        // 3. Perform Vision Request
        // Under the Hood: This is where Vision executes the Core ML model.
        // It's performed asynchronously and can be CPU/GPU intensive.
        return try await withCheckedThrowingContinuation { continuation in
            do {
                try handler.perform([visionCoreMLRequest])
                
                guard let observations = visionCoreMLRequest.results as? [VNCoreMLFeatureValueObservation] else {
                    throw DocumentAnalyzerError.invalidModelOutput("Expected VNCoreMLFeatureValueObservation results.")
                }

                // 4. Extract Raw Model Outputs (MLMultiArray)
                // Assuming the model outputs two MLMultiArray features: "raw_boxes" and "raw_scores"
                guard let rawBoxesMultiArray = observations.first(where: { $0.featureName == "raw_boxes" })?.featureValue?.multiArrayValue,
                      let rawScoresMultiArray = observations.first(where: { $0.featureName == "raw_scores" })?.featureValue?.multiArrayValue else {
                    throw DocumentAnalyzerError.invalidModelOutput("Missing 'raw_boxes' or 'raw_scores' MLMultiArray outputs.")
                }
                
                // Under the Hood: MLMultiArray provides direct access to the model's tensor outputs.
                // We need to interpret its shape and contents based on how the model was trained and converted.
                // Example: raw_boxes shape [N, 4] for (x, y, width, height) or (x1, y1, x2, y2)
                //          raw_scores shape [N, num_classes]
                
                let numDetections = rawBoxesMultiArray.shape[0].intValue // N
                let numClasses = rawScoresMultiArray.shape[1].intValue

                var candidateObjects: [(boundingBox: CGRect, confidence: Float, classIndex: Int)] = []

                for i in 0..<numDetections {
                    // Get raw bounding box (x, y, w, h) or (x1, y1, x2, y2)
                    // Assuming normalized coordinates (0.0 to 1.0)
                    let x = rawBoxesMultiArray[i * 4].floatValue
                    let y = rawBoxesMultiArray[i * 4 + 1].floatValue
                    let w = rawBoxesMultiArray[i * 4 + 2].floatValue
                    let h = rawBoxesMultiArray[i * 4 + 3].floatValue
                    
                    // Convert raw model output format (e.g., YOLO's center_x, center_y, width, height)
                    // to Vision's normalized top-left origin (minX, minY, width, height)
                    // Note: Core ML outputs are often normalized (0-1). Vision expects normalized coordinates
                    // with origin at bottom-left. We convert to UIKit's top-left for easier use.
                    let normalizedRect = CGRect(x: CGFloat(x), y: CGFloat(y), width: CGFloat(w), height: CGFloat(h))
                    
                    // Find the class with the highest score for this detection
                    var maxScore: Float = 0.0
                    var predictedClassIndex: Int = -1

                    for j in 0..<numClasses {
                        let score = rawScoresMultiArray[i * numClasses + j].floatValue
                        if score > maxScore {
                            maxScore = score
                            predictedClassIndex = j
                        }
                    }

                    // 5. Apply Confidence Thresholding
                    if maxScore >= confidenceThreshold && predictedClassIndex != -1 {
                        candidateObjects.append((boundingBox: normalizedRect, confidence: maxScore, classIndex: predictedClassIndex))
                    }
                }

                // 6. Perform Non-Maximum Suppression (NMS)
                let nmsResults = self.applyNMS(candidates: candidateObjects, iouThreshold: self.iouThreshold)
                
                // 7. Map to DetectedObject
                let detectedObjects = nmsResults.map { (bbox, confidence, classIndex) in
                    let label = self.classLabels[classIndex]
                    // Vision's normalized coordinates have origin at bottom-left.
                    // UIKit's normalized coordinates have origin at top-left.
                    // Convert Vision's Y (0=bottom, 1=top) to UIKit's Y (0=top, 1=bottom).
                    let uiKitBoundingBox = CGRect(
                        x: bbox.minX,
                        y: 1.0 - bbox.minY - bbox.height, // Flip Y-axis
                        width: bbox.width,
                        height: bbox.height
                    )
                    return DetectedObject(label: label, confidence: confidence, boundingBox: uiKitBoundingBox, classIndex: classIndex)
                }

                continuation.resume(returning: detectedObjects)

            } catch {
                continuation.resume(throwing: error)
            }
        }
    }

    // MARK: - Helper for Non-Maximum Suppression (NMS)
    /// Applies Non-Maximum Suppression to a list of candidate bounding boxes to remove redundant detections.
    /// - Parameters:
    ///   - candidates: An array of tuples containing bounding boxes, confidence scores, and class indices.
    ///   - iouThreshold: The Intersection Over Union (IoU) threshold. Detections with IoU above this are suppressed.
    /// - Returns: A filtered array of detections after NMS.
    private func applyNMS(candidates: [(boundingBox: CGRect, confidence: Float, classIndex: Int)], iouThreshold: Float) -> [(boundingBox: CGRect, confidence: Float, classIndex: Int)] {
        guard !candidates.isEmpty else { return [] }

        // Sort candidates by confidence score in descending order
        let sortedCandidates = candidates.sorted { $0.confidence > $1.confidence }
        var selectedDetections: [(boundingBox: CGRect, confidence: Float, classIndex: Int)] = []
        var suppressedIndices = Set<Int>()

        for i in 0..<sortedCandidates.count {
            if suppressedIndices.contains(i) {
                continue
            }

            let currentDetection = sortedCandidates[i]
            selectedDetections.append(currentDetection)
            
            for j in (i + 1)..<sortedCandidates.count {
                if suppressedIndices.contains(j) {
                    continue
                }

                let nextDetection = sortedCandidates[j]

                // Only apply NMS if they are of the same class
                if currentDetection.classIndex == nextDetection.classIndex {
                    let iou = calculateIoU(box1: currentDetection.boundingBox, box2: nextDetection.boundingBox)
                    if iou > iouThreshold {
                        suppressedIndices.insert(j)
                    }
                }
            }
        }
        return selectedDetections
    }

    // MARK: - Helper for Intersection Over Union (IoU) Calculation
    /// Calculates the Intersection Over Union (IoU) between two bounding boxes.
    /// - Parameters:
    ///   - box1: The first bounding box.
    ///   - box2: The second bounding box.
    /// - Returns: The IoU value (0.0 to 1.0).
    private func calculateIoU(box1: CGRect, box2: CGRect) -> Float {
        let intersectionRect = box1.intersection(box2)
        let intersectionArea = intersectionRect.width * intersectionRect.height

        let unionArea = (box1.width * box1.height) + (box2.width * box2.height) - intersectionArea

        guard unionArea > 0 else { return 0.0 } // Avoid division by zero

        return Float(intersectionArea / unionArea)
    }
}

// MARK: - UIImage Orientation Extension
/// Helper extension to convert UIImage.Orientation to CGImagePropertyOrientation.
@available(iOS 17.0, *)
extension UIImage.Orientation {
    func toCGImagePropertyOrientation() -> CGImagePropertyOrientation {
        switch self {
        case .up: return .up
        case .down: return .down
        case .left: return .left
        case .right: return .right
        case .upMirrored: return .upMirrored
        case .downMirrored: return .downMirrored
        case .leftMirrored: return .leftMirrored
        case .rightMirrored: return .rightMirrored
        @unknown default: return .up
        }
    }
}

// MARK: - Example Usage (within a ViewController or App entry point)
/*
// Assuming you have a Core ML model named "DocumentDetector.mlmodelc" in your app bundle.
// This model was converted from PyTorch/TensorFlow using `coremltools`
// and configured to output "raw_boxes" (MLMultiArray of shape [N, 4])
// and "raw_scores" (MLMultiArray of shape [N, num_classes]).

@available(iOS 17.0, *)
class DocumentScannerViewController: UIViewController {
    
    private var documentAnalyzer: DocumentAnalyzer!
    private let documentLabels = ["Signature", "Date_Field", "Invoice_Number", "Checkbox", "Text_Block"]
    
    private let imageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.backgroundColor = .systemGray6
        return iv
    }()
    
    private let analyzeButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Analyze Document", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        // Initialize the analyzer with your model's details
        documentAnalyzer = DocumentAnalyzer(
            modelName: "DocumentDetector", // Replace with your .mlmodelc name
            classLabels: documentLabels,
            confidenceThreshold: 0.6,
            iouThreshold: 0.3
        )
        
        // Load the model asynchronously on app startup
        Task {
            do {
                try await documentAnalyzer.loadModel()
                print("DocumentAnalyzer model ready.")
                analyzeButton.isEnabled = true
            } catch {
                print("Error loading document analyzer model: \(error.localizedDescription)")
                analyzeButton.isEnabled = false
            }
        }
    }
    
    private func setupUI() {
        view.backgroundColor = .systemBackground
        view.addSubview(imageView)
        view.addSubview(analyzeButton)
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.6),
            
            analyzeButton.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 40),
            analyzeButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            analyzeButton.widthAnchor.constraint(equalToConstant: 200),
            analyzeButton.heightAnchor.constraint(equalToConstant: 50)
        ])
        
        analyzeButton.addTarget(self, action: #selector(analyzeDocumentTapped), for: .touchUpInside)
        analyzeButton.isEnabled = false // Disable until model is loaded
        
        // Load a sample image (replace with actual image picker logic)
        if let sampleImage = UIImage(named: "sample_document") { // Make sure "sample_document.png" is in Assets.xcassets
            imageView.image = sampleImage
        } else {
            print("Sample document image not found.")
        }
    }
    
    @objc private func analyzeDocumentTapped() {
        guard let imageToAnalyze = imageView.image else {
            print("No image to analyze.")
            return
        }
        
        // Clear previous drawings
        imageView.subviews.forEach { $0.removeFromSuperview() }
        
        Task {
            print("Starting document analysis...")
            do {
                let detectedObjects = try await documentAnalyzer.analyzeDocument(image: imageToAnalyze)
                print("Analysis complete. Detected \(detectedObjects.count) objects.")
                
                // Display results on the UI
                drawBoundingBoxes(on: imageView, with: detectedObjects)
                
            } catch {
                print("Document analysis failed: \(error.localizedDescription)")
                // Show an alert to the user
                let alert = UIAlertController(title: "Analysis Error", message: error.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                present(alert, animated: true)
            }
        }
    }
    
    /// Draws bounding boxes and labels on the image view.
    private func drawBoundingBoxes(on imageView: UIImageView, with detections: [DetectedObject]) {
        guard let image = imageView.image else { return }
        
        let imageSize = image.size
        let viewSize = imageView.bounds.size
        
        // Calculate scaling factor and offset if contentMode is .scaleAspectFit
        let scaleX = viewSize.width / imageSize.width
        let scaleY = viewSize.height / imageSize.height
        let scale = min(scaleX, scaleY)
        
        let scaledImageWidth = imageSize.width * scale
        let scaledImageHeight = imageSize.height * scale
        
        let offsetX = (viewSize.width - scaledImageWidth) / 2
        let offsetY = (viewSize.height - scaledImageHeight) / 2
        
        for object in detections {
            // Convert normalized bounding box to image view coordinates
            let rect = object.boundingBox
            let x = rect.minX * scaledImageWidth + offsetX
            let y = rect.minY * scaledImageHeight + offsetY
            let width = rect.width * scaledImageWidth
            let height = rect.height * scaledImageHeight
            
            let boundingBoxView = UIView(frame: CGRect(x: x, y: y, width: width, height: height))
            boundingBoxView.layer.borderColor = UIColor.red.cgColor
            boundingBoxView.layer.borderWidth = 2
            boundingBoxView.backgroundColor = UIColor.red.withAlphaComponent(0.2)
            imageView.addSubview(boundingBoxView)
            
            let label = UILabel()
            label.text = "\(object.label) (\(String(format: "%.2f", object.confidence)))"
            label.textColor = .white
            label.backgroundColor = .red
            label.font = .systemFont(ofSize: 12, weight: .bold)
            label.sizeToFit()
            label.frame = CGRect(x: 0, y: -label.bounds.height, width: label.bounds.width, height: label.bounds.height)
            boundingBoxView.addSubview(label)
        }
    }
}
*/
