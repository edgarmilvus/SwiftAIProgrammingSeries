
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import NaturalLanguage // For NLModel
import CoreML         // For MLModel and MLModelError

// MARK: - ChatSentimentClassifier

/// A class responsible for classifying the sentiment of chat messages
/// using a custom Core ML model wrapped by NLModel.
@available(iOS 13.0, macOS 10.15, *) // NLModel is available from these versions
final class ChatSentimentClassifier {

    /// The NLModel instance that wraps our custom Core ML sentiment model.
    private var sentimentModel: NLModel?

    /// Initializes the sentiment classifier by loading the Core ML model.
    /// - Parameter modelName: The name of the Core ML model file (e.g., "SentimentClassifier").
    /// - Throws: `ChatSentimentClassifierError` if the model cannot be loaded.
    init(modelName: String) throws {
        do {
            // 1. Loading the Core ML Model using NLModel
            // NLModel provides a convenient way to load Core ML models
            // that are designed for text classification.
            // It automatically infers the input and output types for text tasks.
            self.sentimentModel = try NLModel(contentsOf: NLModel.urlForMLModel(withModel: modelName))
            print("Successfully loaded sentiment model: \(modelName)")
        } catch {
            // Handle potential errors during model loading.
            // This could be due to a missing model file, corrupted model, etc.
            print("Error loading sentiment model '\(modelName)': \(error.localizedDescription)")
            throw ChatSentimentClassifierError.modelLoadingFailed(error)
        }
    }

    /// Classifies the sentiment of a given chat message.
    /// - Parameter message: The chat message string to classify.
    /// - Returns: The predicted sentiment label (e.g., "positive", "negative", "neutral").
    /// - Throws: `ChatSentimentClassifierError` if the model is not loaded or prediction fails.
    func classifySentiment(for message: String) async throws -> String {
        guard let model = sentimentModel else {
            throw ChatSentimentClassifierError.modelNotLoaded
        }

        // 2. Performing Classification
        // NLModel's predictedLabel(for:) method makes it straightforward
        // to get the classification result for a given text input.
        // This method is synchronous for a single prediction.
        let predictedLabel = model.predictedLabel(for: message)

        guard let label = predictedLabel else {
            throw ChatSentimentClassifierError.predictionFailed("No label returned for message: \(message)")
        }

        return label
    }
}

// MARK: - ChatSentimentClassifierError

/// Custom error types for the ChatSentimentClassifier.
enum ChatSentimentClassifierError: Error, LocalizedError {
    case modelLoadingFailed(Error)
    case modelNotLoaded
    case predictionFailed(String)

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let error):
            return "Failed to load the sentiment Core ML model: \(error.localizedDescription)"
        case .modelNotLoaded:
            return "Sentiment model is not loaded or initialized."
        case .predictionFailed(let message):
            return "Sentiment prediction failed: \(message)"
        }
    }
}

// MARK: - Example Usage in an iOS/macOS App Context

/// A conceptual ViewModel or Controller that uses the sentiment classifier.
/// In a real app, this would update UI elements.
@available(iOS 13.0, macOS 10.15, *)
@MainActor // Ensure all UI-related updates happen on the main thread
class ChatViewControllerViewModel: ObservableObject {
    @Published var chatMessages: [(String, String?)] = [] // (message, sentiment)
    private var classifier: ChatSentimentClassifier?

    init() {
        // Initialize the classifier. This should ideally be done once.
        // If the model loading fails, we'll print an error and the classifier won't be available.
        do {
            classifier = try ChatSentimentClassifier(modelName: "SentimentClassifier")
            print("ChatSentimentClassifier initialized successfully.")
        } catch {
            print("Failed to initialize ChatSentimentClassifier: \(error.localizedDescription)")
            classifier = nil
        }
    }

    /// Simulates sending a new message and classifying its sentiment.
    /// - Parameter message: The user's input message.
    func sendMessage(_ message: String) async {
        // Add the message immediately, sentiment will be added later.
        chatMessages.append((message, nil))

        guard let classifier = classifier else {
            print("Classifier not available. Cannot classify sentiment.")
            return
        }

        do {
            // 3. Handling Asynchronous Operations and UI Updates
            // The classifySentiment method is async. After classification,
            // we update the UI, which must be on the MainActor.
            let sentiment = try await classifier.classifySentiment(for: message)

            // Find the last message and update its sentiment.
            if let index = chatMessages.lastIndex(where: { $0.0 == message && $0.1 == nil }) {
                chatMessages[index] = (message, sentiment)
            }
            print("Message: '\(message)' -> Sentiment: \(sentiment)")

        } catch {
            print("Error classifying sentiment for message '\(message)': \(error.localizedDescription)")
            // Optionally, update UI to show classification failed
            if let index = chatMessages.lastIndex(where: { $0.0 == message && $0.1 == nil }) {
                chatMessages[index] = (message, "Error")
            }
        }
    }
}

// MARK: - Main Application Entry Point (for demonstration)

// This would typically be in an AppDelegate or SwiftUI App struct
@main
@available(iOS 13.0, macOS 10.15, *)
struct SentimentAppDemo {
    static func main() async {
        print("Starting Sentiment App Demo...")

        let viewModel = ChatViewControllerViewModel()

        // Simulate some chat messages
        await viewModel.sendMessage("This is a fantastic product! I love it.")
        await Task.sleep(nanoseconds: 500_000_000) // Simulate delay
        await viewModel.sendMessage("The service was okay, nothing special.")
        await Task.sleep(nanoseconds: 500_000_000)
        await viewModel.sendMessage("I'm really disappointed with this feature.")
        await Task.sleep(nanoseconds: 500_000_000)
        await viewModel.sendMessage("Thanks for your help!")
        await Task.sleep(nanoseconds: 500_000_000)
        await viewModel.sendMessage("This is garbage.")

        await Task.sleep(nanoseconds: 2_000_000_000) // Give time for all messages to process

        print("\n--- All Chat Messages with Sentiments ---")
        await MainActor.run { // Ensure we access @Published properties on MainActor
            for (message, sentiment) in viewModel.chatMessages {
                print("Message: \"\(message)\" | Sentiment: \(sentiment ?? "N/A")")
            }
        }
    }
}

/*
To run this code:
1. Create a new Xcode project (e.g., iOS App or macOS App).
2. Drag your `SentimentClassifier.mlmodel` file into your Xcode project navigator.
   Make sure it's included in your app's target.
3. Replace the contents of your main Swift file (e.g., `ContentView.swift` for SwiftUI,
   or `main.swift` for a command-line tool, or `AppDelegate.swift`/`SceneDelegate.swift` for UIKit)
   with the code above.
4. If you're using a SwiftUI app, you might adapt the `ChatViewControllerViewModel`
   to be an `ObservableObject` and use it in a `View`. For this example, the `@main`
   struct `SentimentAppDemo` acts as a simple entry point.
*/
