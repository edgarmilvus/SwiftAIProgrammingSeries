
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import SwiftUI // For @Observable

// MARK: - 1. Custom Error Types

/// Defines custom errors specific to our chat API interactions.
enum ChatAPIError: Error, LocalizedError {
    case invalidURL
    case networkError(Error)
    case apiError(statusCode: Int, message: String?)
    case parsingError(String)
    case cancelled

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "The provided URL was invalid."
        case .networkError(let error):
            return "Network error: \(error.localizedDescription)"
        case .apiError(let statusCode, let message):
            return "API error \(statusCode): \(message ?? "No specific message.")"
        case .parsingError(let message):
            return "Data parsing error: \(message)"
        case .cancelled:
            return "Request was cancelled."
        }
    }
}

// MARK: - 2. Server-Sent Event (SSE) Data Structures

/// Represents a single Server-Sent Event.
///
/// SSE events typically consist of fields like `id`, `event`, `data`, and `retry`.
/// This struct focuses on the most common fields relevant for AI streaming.
struct SSEEvent {
    let id: String?
    let event: String? // e.g., "message", "error", "done"
    let data: String?  // The actual payload, often JSON or plain text
    let retry: Int?    // Reconnection time in milliseconds

    static let terminator = "[DONE]" // Common AI API signal for end of stream

    // Initializes an SSEEvent from a dictionary of field names to values.
    init(fields: [String: String]) {
        self.id = fields["id"]
        self.event = fields["event"]
        self.data = fields["data"]
        self.retry = fields["retry"].flatMap(Int.init)
    }
}

// MARK: - 3. SSE Parser Utility

/// A utility to parse raw `Data` chunks into structured `SSEEvent` objects.
///
/// This parser is stateful, accumulating partial lines across multiple `Data` chunks
/// until a complete SSE event is formed. It handles multi-line `data` fields
/// and the standard SSE field-value format.
struct SSEParser {
    private var buffer = Data()
    private var currentFields: [String: String] = [:]

    /// Processes a new chunk of data, yielding any complete SSE events found.
    /// - Parameter newData: The new `Data` chunk received from the network stream.
    /// - Returns: An `AsyncThrowingStream` of `SSEEvent`s.
    mutating func parse(newData: Data) -> AsyncThrowingStream<SSEEvent, Error> {
        return AsyncThrowingStream { continuation in
            buffer.append(newData)

            // SSE events are separated by two newline characters (\n\n or \r\n\r\n).
            // Lines within an event are separated by a single newline.
            // Each line is `field: value`.
            while let separatorRange = buffer.range(of: Data([0x0A, 0x0A])) { // Find \n\n
                let eventData = buffer.prefix(upTo: separatorRange.lowerBound)
                buffer.removeSubrange(..<separatorRange.upperBound) // Remove processed event data + separator

                if let eventString = String(data: eventData, encoding: .utf8) {
                    processEventString(eventString, continuation: continuation)
                } else {
                    continuation.yield(with: .failure(ChatAPIError.parsingError("Could not decode event string from data.")))
                }
            }
            // Handle remaining buffer if it ends without a double newline (partial event)
        }
    }

    /// Processes a single event string (e.g., "id:1\ndata:hello\n\n").
    private mutating func processEventString(_ eventString: String, continuation: AsyncThrowingStream<SSEEvent, Error>.Continuation) {
        let lines = eventString.split(separator: "\n", omittingEmptySubsequences: false)
        var eventFields: [String: String] = [:]

        for line in lines {
            // Lines starting with ':' are comments and should be ignored.
            if line.starts(with: ":") { continue }

            // Each line should be `field: value`.
            if let colonIndex = line.firstIndex(of: ":") {
                let field = String(line[..<colonIndex])
                // Value starts after the colon, trimming leading space if present.
                let valueStartIndex = line.index(after: colonIndex)
                let value = String(line[valueStartIndex...]).trimmingCharacters(in: .whitespacesAndNewlines)

                // Special handling for 'data' field: if multiple 'data' lines, concatenate with newline.
                if field == "data", let existingData = eventFields[field] {
                    eventFields[field] = existingData + "\n" + value
                } else {
                    eventFields[field] = value
                }
            } else if !line.isEmpty {
                // If a line contains no colon but is not empty, it's treated as a data field with no field name.
                // This is less common but allowed by SSE spec.
                if let existingData = eventFields["data"] {
                    eventFields["data"] = existingData + "\n" + String(line)
                } else {
                    eventFields["data"] = String(line)
                }
            }
        }

        if !eventFields.isEmpty {
            continuation.yield(SSEEvent(fields: eventFields))
        }
    }
}

// MARK: - 4. Chat Service

/// `ChatService` handles the network communication for streaming AI responses.
///
/// It uses `URLSession.shared.bytes(for:)` to get an `AsyncBytes` sequence,
/// then parses these bytes into `SSEEvent`s, and finally extracts relevant
/// tokens for the UI. It provides an `AsyncThrowingStream` for consumers.
@available(iOS 17.0, *) // @Observable is iOS 17+
class ChatService {
    private let apiURL: URL

    init(apiURL: URL) {
        self.apiURL = apiURL
    }

    /// Streams AI response tokens for a given query.
    ///
    /// - Parameter query: The user's input query.
    /// - Returns: An `AsyncThrowingStream` of `String` tokens.
    ///            The stream will emit individual tokens as they arrive.
    ///            It will complete when the AI response is finished or error out.
    func streamAIResponse(query: String) -> AsyncThrowingStream<String, Error> {
        AsyncThrowingStream { continuation in
            let task = Task {
                do {
                    guard let requestURL = URL(string: "v1/chat/completions", relativeTo: apiURL) else {
                        throw ChatAPIError.invalidURL
                    }

                    var request = URLRequest(url: requestURL)
                    request.httpMethod = "POST"
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    request.setValue("text/event-stream", forHTTPHeaderField: "Accept")
                    request.setValue("Bearer YOUR_API_KEY", forHTTPHeaderField: "Authorization") // IMPORTANT: Replace with your actual API key

                    // Example request body for a common AI chat API (e.g., OpenAI-like)
                    let requestBody: [String: Any] = [
                        "model": "gpt-4o-mini", // Or your preferred model
                        "messages": [
                            ["role": "user", "content": query]
                        ],
                        "stream": true // Crucial for SSE streaming
                    ]
                    request.httpBody = try JSONSerialization.data(withJSONObject: requestBody)

                    // Use URLSession's async bytes API to stream the response
                    let (bytes, response) = try await URLSession.shared.bytes(for: request)

                    guard let httpResponse = response as? HTTPURLResponse else {
                        throw ChatAPIError.networkError(URLError(.badServerResponse))
                    }

                    guard (200...299).contains(httpResponse.statusCode) else {
                        let errorData = try await bytes.reduce(Data()) { $0 + $1 }
                        let errorMessage = String(data: errorData, encoding: .utf8)
                        throw ChatAPIError.apiError(statusCode: httpResponse.statusCode, message: errorMessage)
                    }

                    var sseParser = SSEParser()

                    // Iterate over the incoming bytes asynchronously
                    for try await chunk in bytes {
                        // Check for cancellation at each chunk
                        try Task.checkCancellation()

                        // Parse the raw data chunk into SSEEvents
                        let eventStream = sseParser.parse(newData: chunk)
                        for try await event in eventStream {
                            // Only process 'data' events and extract the content
                            if event.event == nil || event.event == "message" || event.event == "chat.completion.chunk" { // Common event types
                                if let dataString = event.data {
                                    if dataString == SSEEvent.terminator {
                                        // End of stream signal
                                        continuation.finish()
                                        return
                                    }
                                    // Assuming dataString contains a JSON object with a 'content' field
                                    // This part is highly dependent on your specific AI API's SSE data format.
                                    // For OpenAI-like APIs, 'data' is a JSON string like {"choices":[{"delta":{"content":"token"}}]}
                                    if let jsonData = dataString.data(using: .utf8) {
                                        if let json = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
                                           let choices = json["choices"] as? [[String: Any]],
                                           let firstChoice = choices.first,
                                           let delta = firstChoice["delta"] as? [String: Any],
                                           let content = delta["content"] as? String {
                                            continuation.yield(content)
                                        }
                                    } else {
                                        // If it's not JSON, assume it's a plain text token
                                        continuation.yield(dataString)
                                    }
                                }
                            }
                        }
                    }
                    continuation.finish() // Stream finished naturally
                } catch is Swift.CancellationError {
                    continuation.finish(throwing: ChatAPIError.cancelled)
                } catch {
                    // Catch any other errors and pass them to the continuation
                    if let apiError = error as? ChatAPIError {
                        continuation.finish(throwing: apiError)
                    } else {
                        continuation.finish(throwing: ChatAPIError.networkError(error))
                    }
                }
            }
            // Provide a way to cancel the underlying task if the consumer of the stream cancels.
            continuation.onTermination = { @Sendable _ in
                task.cancel()
            }
        }
    }
}

// MARK: - 5. Chat View Model (for SwiftUI Integration)

/// `ChatViewModel` manages the UI state and orchestrates the streaming process.
///
/// It uses `@Observable` for seamless integration with SwiftUI views.
@available(iOS 17.0, *)
@Observable
class ChatViewModel {
    var chatHistory: [String] = []
    var currentInput: String = ""
    var isStreaming: Bool = false
    var errorMessage: String?

    private let chatService: ChatService
    private var streamingTask: Task<Void, Never>? // Holds the reference to the active streaming task

    init(apiURL: URL) {
        self.chatService = ChatService(apiURL: apiURL)
    }

    /// Sends the user's query to the AI and streams the response.
    func sendQuery() {
        guard !currentInput.isEmpty else { return }

        let userMessage = "You: \(currentInput)"
        chatHistory.append(userMessage)
        let queryToSend = currentInput
        currentInput = "" // Clear input field immediately
        errorMessage = nil
        isStreaming = true

        // Start a new AI message placeholder
        var aiResponseAccumulator = "AI: "
        chatHistory.append(aiResponseAccumulator) // Add placeholder to history

        streamingTask = Task {
            do {
                // `enumerated()` is used to get the index for updating `chatHistory` efficiently.
                for try await (index, token) in chatService.streamAIResponse(query: queryToSend).enumerated() {
                    // Check for cancellation within the UI update loop
                    try Task.checkCancellation()

                    // Update the last element of chatHistory with the new token
                    // This must be done on the main actor, as @Observable properties
                    // are typically accessed from the main actor.
                    await MainActor.run {
                        aiResponseAccumulator += token
                        if let lastIndex = chatHistory.indices.last, chatHistory[lastIndex].starts(with: "AI:") {
                            chatHistory[lastIndex] = aiResponseAccumulator
                        } else {
                            // Fallback if the placeholder was somehow removed or changed
                            chatHistory.append(aiResponseAccumulator)
                        }
                    }
                }
                await MainActor.run {
                    self.isStreaming = false
                }
            } catch let error as ChatAPIError {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isStreaming = false
                    // Append error message to chat history for user feedback
                    if let lastIndex = chatHistory.indices.last, chatHistory[lastIndex].starts(with: "AI:") {
                        chatHistory[lastIndex] += " (Error: \(error.localizedDescription))"
                    } else {
                        chatHistory.append("AI: (Error: \(error.localizedDescription))")
                    }
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                    self.isStreaming = false
                    if let lastIndex = chatHistory.indices.last, chatHistory[lastIndex].starts(with: "AI:") {
                        chatHistory[lastIndex] += " (Error: \(error.localizedDescription))"
                    } else {
                        chatHistory.append("AI: (Error: \(error.localizedDescription))")
                    }
                }
            }
        }
    }

    /// Cancels any ongoing streaming operation.
    func cancelStreaming() {
        streamingTask?.cancel()
        streamingTask = nil
        isStreaming = false
        errorMessage = "Streaming cancelled by user."
        // Optionally, remove the incomplete AI response or mark it as cancelled
        if let lastIndex = chatHistory.indices.last, chatHistory[lastIndex].starts(with: "AI:") {
            chatHistory[lastIndex] += " (Cancelled)"
        }
    }

    /// Clears the chat history and any error messages.
    func clearChat() {
        cancelStreaming()
        chatHistory.removeAll()
        errorMessage = nil
    }
}

// MARK: - 6. Conceptual SwiftUI View

/// A conceptual SwiftUI view demonstrating how to integrate the ChatViewModel.
///
/// This view would display the chat history, an input field for the user,
/// and buttons to send or cancel the AI request.
@available(iOS 17.0, *)
struct ChatView: View {
    @State private var viewModel = ChatViewModel(apiURL: URL(string: "https://api.openai.com/")!) // Replace with your actual API base URL

    var body: some View {
        VStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(viewModel.chatHistory, id: \.self) { message in
                        Text(message)
                            .padding(5)
                            .background(message.starts(with: "You:") ? Color.blue.opacity(0.2) : Color.gray.opacity(0.1))
                            .cornerRadius(8)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            }

            if let errorMessage = viewModel.errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .padding(.horizontal)
            }

            HStack {
                TextField("Type your message...", text: $viewModel.currentInput)
                    .textFieldStyle(.roundedBorder)
                    .disabled(viewModel.isStreaming)

                Button("Send") {
                    viewModel.sendQuery()
                }
                .disabled(viewModel.currentInput.isEmpty || viewModel.isStreaming)

                if viewModel.isStreaming {
                    Button("Cancel") {
                        viewModel.cancelStreaming()
                    }
                }
            }
            .padding()
        }
        .navigationTitle("AI Chat Assistant")
    }
}

// Preview Provider (for Xcode Previews)
@available(iOS 17.0, *)
#Preview {
    NavigationView {
        ChatView()
    }
}
