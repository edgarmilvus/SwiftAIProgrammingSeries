
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN
import Foundation // For Task

@available(iOS 18.0, *)
actor ModelActor {
    private var model: MyModel // Assume MyModel is defined as above
    private var optimizer: SGD // Assume an optimizer is defined

    init(model: MyModel, learningRate: Float) {
        self.model = model
        self.optimizer = SGD(learningRate: learningRate) // Initialize optimizer
    }

    // Asynchronous function for performing inference
    func performInference(input: MLXArray) async -> MLXArray {
        // This could involve network calls to load weights, or long computations
        // For MLX, eval() is often where the computation graph is materialized
        return await Task {
            let output = model(input)
            MLX.eval(output) // Explicitly evaluate the graph
            return output
        }.value
    }

    // Asynchronous function for a single training step
    func trainStep(input: MLXArray, target: MLXArray) async {
        await Task {
            let lossFn = { (model: MyModel) in
                lossFunction(model: model, input: input, target: target)
            }
            let (loss, gradients) = valueAndGradient(lossFn)(model)
            optimizer.update(model: model, gradients: gradients)
            MLX.eval(model.parameters(), loss, gradients) // Evaluate parameters, loss, and gradients
            print("Training Loss: \(loss.item())")
        }.value
    }
}

@available(iOS 18.0, *)
func startTrainingExample() {
    let initialModel = MyModel(inputFeatures: 10, hiddenFeatures: 20, outputFeatures: 1)
    let modelActor = ModelActor(model: initialModel, learningRate: 0.01)

    Task {
        for epoch in 1...10 {
            print("Epoch \(epoch)")
            let inputBatch = MLXArray.randomUniform([32, 10]) // Batch of 32 samples
            let targetBatch = MLXArray.randomUniform([32, 1])
            await modelActor.trainStep(input: inputBatch, target: targetBatch)
        }
        // After training, perform an inference
        let testInput = MLXArray.randomUniform([1, 10])
        let prediction = await modelActor.performInference(input: testInput)
        print("Final Prediction: \(prediction.item())")
    }
}
