
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import RealityKit

@available(visionOS 1.0, *)
enum SpatialZone: Equatable {
    case canvas
    case tool(ToolType)
    case none
}

enum ToolType: String, CaseIterable {
    case colorWheel, timeline, effects
}

@available(visionOS 1.0, *)
class LuminaWorkspaceManager: ObservableObject {
    @Published var activeZone: SpatialZone = .canvas
    
    // Simulated raycast logic
    func updateZone(hitEntityName: String?) {
        if hitEntityName == "Canvas" {
            activeZone = .canvas
        } else if let name = hitEntityName, let tool = ToolType(rawValue: name) {
            activeZone = .tool(tool)
        } else {
            activeZone = .none
        }
    }
}

@available(visionOS 1.0, *)
struct LuminaEditView: View {
    @StateObject private var workspace = LuminaWorkspaceManager()
    
    var body: some View {
        ZStack {
            // 1. The Canvas (Central)
            Rectangle()
                .fill(.black)
                .overlay(Text("VIDEO FEED").foregroundColor(.white))
                .frame(width: 600, height: 400)
                .name("Canvas") // For simulation
                .opacity(workspace.activeZone == .canvas ? 1.0 : 0.6)
                .scaleEffect(workspace.activeZone == .canvas ? 1.0 : 0.95)
            
            // 2. The Tools (Peripheral)
            HStack(spacing: 40) {
                ForEach(ToolType.allCases, id: \.self) { type in
                    ToolComponent(type: type, manager: workspace)
                }
            }
            .offset(x: workspace.activeZone == .canvas ? 400 : 0) // Move to periphery
            .animation(.spring(response: 0.6, dampingFraction: 0.8), value: workspace.activeZone)
        }
        .onTapGesture {
            // Simulation: Toggle between canvas and tools
            let mockHits = ["Canvas", "colorWheel", "timeline", "effects"]
            workspace.updateZone(hitEntityName: mockHits.randomElement())
        }
    }
}

@available(visionOS 1.0, *)
struct ToolComponent: View {
    let type: ToolType
    @ObservedObject var manager: LuminaWorkspaceManager
    
    private var isFocused: Bool {
        if case .tool(let focusedType) = manager.activeZone {
            return focusedType == type
        }
        return false
    }
    
    var body: some View {
        VStack {
            RoundedRectangle(cornerRadius: 15)
                .fill(.ultraThinMaterial)
                .frame(width: 120, height: 120)
                .overlay(Text(type.rawValue.capitalized).font(.caption))
                // Adaptive Visuals
                .opacity(isFocused ? 1.0 : 0.3)
                .scaleEffect(isFocused ? 1.2 : 1.0)
                .shadow(color: isFocused ? .blue.opacity(0.5) : .clear, radius: 20)
                // Adaptive Depth
                .offset(y: isFocused ? -20 : 0)
        }
        .animation(.spring(), value: isFocused)
    }
}
