
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Observation

/// An actor-based inference engine that ensures thread-safe access 
/// to the Core ML model and prevents data races during high-frequency inference.
@available(iOS 18.0, *)
actor AIInferenceEngine {
    private let model: MLModel
    private var isProcessing = false
    
    // Using @Observable to allow the UI to react to engine state
    // Note: The actor itself isn't @Observable, but it can provide 
    // updates to an @Observable state object.
    
    init(configuration: MLModelConfiguration) throws {
        // In a real scenario, this would load your specific compiled .mlmodelc
        self.model = try MLModel(contentsOf: URL(fileURLWithPath: "path_to_model.mlmodelc"), configuration: configuration)
    }
    
    /// Performs inference on a provided input.
    /// The use of `async` allows the caller to suspend without blocking a thread.
    func performInference(on input: MLFeatureProvider) async throws -> MLFeatureProvider {
        // Prevent overlapping inference requests if the hardware is saturated
        guard !isProcessing else {
            throw AIError.engineBusy
        }
        
        isProcessing = true
        
        // Defer ensures we reset the state regardless of success or failure
        defer { isProcessing = false }
        
        // The actual heavy lifting is handed off to the ANE/GPU by Core ML.
        // The Swift Task suspends here, freeing up the CPU thread.
        let output = try await model.prediction(from: input)
        
        return output
    }
}

enum AIError: Error {
    case engineBusy
}
