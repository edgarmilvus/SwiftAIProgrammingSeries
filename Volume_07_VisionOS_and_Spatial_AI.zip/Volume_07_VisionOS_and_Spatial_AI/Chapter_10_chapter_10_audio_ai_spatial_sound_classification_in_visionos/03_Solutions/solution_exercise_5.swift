
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import RealityKit
import Combine

enum EnvironmentType {
    case cafe
    case nature
    case unknown
}

@Observable
@MainActor
class EnvironmentManager {
    var currentType: EnvironmentType = .unknown
    
    /// Resolves multiple labels into a single environment type
    func resolveEnvironment(labels: [String: Float]) -> EnvironmentType {
        let birdScore = labels["bird"] ?? 0.0
        let windScore = labels["wind"] ?? 0.0
        let chatterScore = labels["chatter"] ?? 0.0
        
        if birdScore > 0.5 && windScore > 0.5 {
            return .nature
        } else if chatterScore > 0.5 {
            return .cafe
        }
        return .unknown
    }
}

struct ImmersiveSceneView: View {
    @State private var envManager = EnvironmentManager()
    @State private var forestEntities: [Entity] = []
    @State private var cafeEntities: [Entity] = []

    var body: some View {
        RealityView { content in
            // 1. Setup "Forest" (Green Spheres)
            for i in 0..<5 {
                let leaf = ModelEntity(mesh: .generateSphere(radius: 0.1), materials: [UnlitMaterial(color: .green)])
                leaf.position = [Float(i) * 0.3, 0, -1]
                content.add(leaf)
                forestEntities.append(leaf)
            }
            
            // 2. Setup "Cafe" (Brown Cubes)
            for i in 0..<5 {
                let table = ModelEntity(mesh: .generateBox(size: 0.2), materials: [UnlitMaterial(color: .brown)])
                table.position = [Float(i) * 0.3, 0, -1]
                content.add(table)
                cafeEntities.append(table)
            }
        } update: { content in
            // 3. Morphing Engine: Synchronize visual state with audio state
            performMorph(content: content)
        }
        .task {
            // Simulate multi-label detection: Nature
            try? await Task.sleep(for: .seconds(3))
            envManager.currentType = envManager.resolveEnvironment(labels: ["bird": 0.8, "wind": 0.7])
            
            // Simulate transition to Cafe
            try? await Task.sleep(for: .seconds(4))
            envManager.currentType = envManager.resolveEnvironment(labels: ["chatter": 0.9])
        }
    }
    
    @MainActor
    private func performMorph(content: RealityViewContent) {
        let targetType = envManager.currentType
        
        // Morph Forest
        for entity in forestEntities {
            let targetOpacity: Float = (targetType == .nature) ? 1.0 : 0.0
            updateOpacity(entity, to: targetOpacity)
        }
        
        // Morph Cafe
        for entity in cafeEntities {
            let targetOpacity: Float = (targetType == .cafe) ? 1.0 : 0.0
            updateOpacity(entity, to: targetOpacity)
        }
    }
    
    private func updateOpacity(_ entity: Entity, to opacity: Float) {
        guard let model = entity as? ModelEntity else { return }
        var material = UnlitMaterial()
        material.color = .init(tint: .white.withAlphaComponent(CGFloat(opacity)))
        model.model?.materials = [material]
    }
}
