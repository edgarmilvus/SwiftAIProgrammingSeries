
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
struct Document {
    let id: UUID
    let title: String
    let content: String
    var embedding: MLXArray? // Optional, will be populated
}

@available(iOS 18.0, macOS 15.0, *)
class DocumentStore {
    private var documents: [Document]
    private let embeddingModel: MLXNN.Module
    private let embeddingDimension: Int

    init(embeddingModel: MLXNN.Module, embeddingDimension: Int) {
        self.documents = []
        self.embeddingModel = embeddingModel
        self.embeddingDimension = embeddingDimension
    }

    func addDocument(document: Document) {
        var mutableDocument = document
        // Prepare dummy input for the embedding model.
        // The content of the MLXArray doesn't matter for DummyEmbeddingModel,
        // only its shape (batch size 1, sequence length 1).
        let dummyInput = document.content.toDummyMLXInput()
        
        // Generate embedding using the MLX model.
        // The model's callAsFunction returns an MLXArray.
        let embedding = embeddingModel(dummyInput)
        
        // Store the embedding in the document.
        mutableDocument.embedding = embedding
        self.documents.append(mutableDocument)
        print("Added document: '\(document.title)' with embedding.")
    }

    func search(query: String, topK: Int) -> [(Document, Float)] {
        guard !documents.isEmpty else {
            print("Document store is empty.")
            return []
        }

        // 1. Generate embedding for the query
        let queryDummyInput = query.toDummyMLXInput()
        let queryEmbedding = embeddingModel(queryDummyInput)
        
        // 2. Collect all document embeddings into a single MLXArray for efficient batch comparison
        // Filter out documents that might not have an embedding (though our addDocument ensures they do).
        let allDocumentEmbeddings = MLX.concatenate(
            documents.compactMap { $0.embedding },
            axis: 0 // Concatenate along the batch dimension
        )
        
        // Ensure queryEmbedding is 2D for consistent matmul with allDocumentEmbeddings
        let queryEmbedding2D = queryEmbedding.reshaped([1, embeddingDimension])

        // 3. Calculate cosine similarity between query and all documents
        // MLXArray.cosineSimilarity is optimized for this.
        let similarities = MLXArray.cosineSimilarity(a: queryEmbedding2D, b: allDocumentEmbeddings)
        
        // The similarities MLXArray will be [1, N] where N is the number of documents.
        // We need to convert it to a Swift array of Floats for sorting.
        // .flattened() converts [1, N] to [N]. .toFloatArray() converts MLXArray to Swift Array.
        let similarityScores = similarities.flattened().toFloatArray()

        // 4. Pair documents with their scores and sort
        let scoredDocuments = zip(documents, similarityScores).map { (doc, score) in
            (doc, score)
        }
        
        let sortedResults = scoredDocuments.sorted { $0.1 > $1.1 } // Sort descending by score

        // 5. Return topK results
        return Array(sortedResults.prefix(topK))
    }
}

// MARK: - Demonstration
@available(iOS 18.0, macOS 15.0, *)
func demonstrateBasicSearch() {
    print("\n--- Exercise 1: Basic Document Embedding and Similarity Search ---")
    let embeddingDimension = 384 // Common dimension for models like bge-small

    do {
        let model = try EmbeddingModelLoader.loadSentenceTransformerModel(embeddingDimension: embeddingDimension)
        let store = DocumentStore(embeddingModel: model, embeddingDimension: embeddingDimension)

        // Sample Documents
        let doc1 = Document(id: UUID(), title: "Swift Concurrency", content: "Swift 6 introduces powerful structured concurrency features like async/await and Actors for safe concurrent programming.")
        let doc2 = Document(id: UUID(), title: "Machine Learning with MLX", content: "MLX is a new machine learning framework optimized for Apple Silicon, leveraging its unified memory architecture for efficient on-device inference and training.")
        let doc3 = Document(id: UUID(), title: "iOS App Development", content: "Building iOS apps involves Xcode, SwiftUI or UIKit, and understanding Apple's Human Interface Guidelines.")
        let doc4 = Document(id: UUID(), title: "Python for Data Science", content: "Python is a popular language for data science, widely used with libraries like NumPy, Pandas, and Scikit-learn for data analysis and machine learning.")
        let doc5 = Document(id: UUID(), title: "SwiftUI Best Practices", content: "To build robust SwiftUI apps, focus on data flow, view modularity, and understanding the view lifecycle.")

        store.addDocument(document: doc1)
        store.addDocument(document: doc2)
        store.addDocument(document: doc3)
        store.addDocument(document: doc4)
        store.addDocument(document: doc5)
        
        // Perform a search
        let query = "Apple Silicon machine learning framework"
        print("\nSearching for: '\(query)'")
        let results = store.search(query: query, topK: 3)

        print("\nTop 3 search results:")
        for (document, score) in results {
            print(String(format: "- Title: '%@' (Score: %.4f)", document.title, score))
            // print("  Content: \(document.content.prefix(50))...")
        }
        
        let anotherQuery = "concurrent programming in iOS"
        print("\nSearching for: '\(anotherQuery)'")
        let anotherResults = store.search(query: anotherQuery, topK: 2)
        
        print("\nTop 2 search results:")
        for (document, score) in anotherResults {
            print(String(format: "- Title: '%@' (Score: %.4f)", document.title, score))
        }

    } catch {
        print("Error loading model: \(error)")
    }
}

// Call the demonstration function
// demonstrateBasicSearch() // Uncomment to run
