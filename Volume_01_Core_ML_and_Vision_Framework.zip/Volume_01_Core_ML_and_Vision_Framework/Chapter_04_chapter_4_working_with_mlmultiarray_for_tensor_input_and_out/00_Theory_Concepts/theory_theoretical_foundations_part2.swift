
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Foundation

@available(iOS 15.0, *)
actor TensorBuffer {
    private var currentInput: MLMultiArray?
    private var currentOutput: MLMultiArray?

    func updateInput(with multiArray: MLMultiArray) {
        // Perform a deep copy if the multiArray comes from an external, potentially mutable source
        // to ensure the actor's internal state is isolated.
        self.currentInput = try? MLMultiArray(dataPointer: multiArray.dataPointer,
                                              shape: multiArray.shape as [NSNumber],
                                              dataType: multiArray.dataType,
                                              strides: multiArray.strides as [NSNumber],
                                              deallocator: nil) // We own the copy now
    }

    func getInput() -> MLMultiArray? {
        // Return a copy to prevent external modification of the actor's internal state
        guard let input = currentInput else { return nil }
        return try? MLMultiArray(dataPointer: input.dataPointer,
                                 shape: input.shape as [NSNumber],
                                 dataType: input.dataType,
                                 strides: input.strides as [NSNumber],
                                 deallocator: nil)
    }

    func updateOutput(with multiArray: MLMultiArray) {
        self.currentOutput = try? MLMultiArray(dataPointer: multiArray.dataPointer,
                                               shape: multiArray.shape as [NSNumber],
                                               dataType: multiArray.dataType,
                                               strides: multiArray.strides as [NSNumber],
                                               deallocator: nil)
    }

    func getOutput() -> MLMultiArray? {
        guard let output = currentOutput else { return nil }
        return try? MLMultiArray(dataPointer: output.dataPointer,
                                 shape: output.shape as [NSNumber],
                                 dataType: output.dataType,
                                 strides: output.strides as [NSNumber],
                                 deallocator: nil)
    }
}

@available(iOS 15.0, *)
func exampleActorUsage() async {
    let buffer = TensorBuffer()

    // Task 1: Update input
    Task {
        let input = try MLMultiArray(shape: [1, 5] as [NSNumber], dataType: .float32)
        // Populate input...
        await buffer.updateInput(with: input)
        print("Input updated by Task 1")
    }

    // Task 2: Read input and update output (simulated inference)
    Task {
        await Task.sleep(for: .milliseconds(10)) // Simulate some delay
        if let input = await buffer.getInput() {
            print("Task 2 read input with shape: \(input.shape)")
            // Simulate processing
            let output = try MLMultiArray(shape: [1, 2] as [NSNumber], dataType: .float32)
            await buffer.updateOutput(with: output)
            print("Output updated by Task 2")
        }
    }
}
// runExample() // Call this from your app's entry point
