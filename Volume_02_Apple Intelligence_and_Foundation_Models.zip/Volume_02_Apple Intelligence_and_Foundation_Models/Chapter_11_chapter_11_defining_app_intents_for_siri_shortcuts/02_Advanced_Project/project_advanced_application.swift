
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AppIntents // Required for AppIntents framework

/// Represents a single note within the Smart Notes Pro application.
struct Note: Identifiable, Codable {
    let id: UUID
    var title: String
    var content: String
    var creationDate: Date

    init(id: UUID = UUID(), title: String, content: String, creationDate: Date = Date()) {
        self.id = id
        self.title = title
        self.content = content
        self.creationDate = creationDate
    }
}

/// Custom errors specific to our note management and AI operations.
enum SmartNotesError: Error, CustomLocalizedStringResourceConvertible {
    case noteNotFound(identifier: String)
    case summarizationFailed
    case invalidInput

    var localizedStringResource: LocalizedStringResource {
        switch self {
        case .noteNotFound(let identifier):
            return "Note with identifier '\(identifier)' could not be found."
        case .summarizationFailed:
            return "Failed to summarize the note. Please try again."
        case .invalidInput:
            return "Invalid input provided for the operation."
        }
    }
}

/// A singleton class to simulate a data store for notes.
/// In a real app, this would interact with Core Data, CloudKit, or a local database.
class NoteStore {
    static let shared = NoteStore() // Singleton instance

    private var notes: [UUID: Note] = [:]
    private let queue = DispatchQueue(label: "com.smartnotes.notestore", attributes: .concurrent)

    private init() {
        // Populate with some dummy data for demonstration
        let note1 = Note(title: "Meeting Minutes - Q3 Planning", content: """
            Attendees: John Doe, Jane Smith, Alex Chen.
            Agenda: Review Q2 performance, Q3 project proposals, Budget allocation.
            Key Decisions:
            - Project Alpha approved with increased budget.
            - Project Beta deferred to Q4.
            - Marketing campaign for Project Alpha to start next month.
            Action Items:
            - John to finalize Alpha budget.
            - Jane to draft Beta deferral notice.
            - Alex to prepare marketing brief.
            """)
        let note2 = Note(title: "Ideas for New Features", content: """
            1. Real-time collaboration on notes.
            2. Integration with Calendar for event-linked notes.
            3. Advanced search with AI-powered semantic understanding.
            4. Voice-to-text transcription for quick notes.
            5. Customizable templates for various note types.
            """)
        let note3 = Note(title: "Personal To-Do List", content: "Buy groceries, call dentist, finish Swift project, read new book.")

        notes[note1.id] = note1
        notes[note2.id] = note2
        notes[note3.id] = note3
    }

    /// Asynchronously fetches a note by its UUID.
    /// - Parameter id: The UUID of the note to fetch.
    /// - Returns: The `Note` if found.
    func fetchNote(by id: UUID) async -> Note? {
        await queue.async {
            self.notes[id]
        }
    }

    /// Asynchronously fetches a note by its title (case-insensitive, partial match).
    /// - Parameter title: The title or partial title of the note.
    /// - Returns: The first matching `Note` if found.
    func fetchNote(by title: String) async -> Note? {
        await queue.async {
            self.notes.values.first { note in
                note.title.localizedCaseInsensitiveContains(title)
            }
        }
    }
}

/// A service to simulate Apple Intelligence text analysis capabilities.
/// In a real iOS 18+ application, this would use frameworks like TextAnalyzer or other on-device LLM APIs.
class AIService {
    static let shared = AIService() // Singleton instance

    private init() {}

    /// Simulates summarizing text using an on-device LLM.
    /// - Parameter text: The input text to summarize.
    /// - Throws: `SmartNotesError.summarizationFailed` if the simulation fails.
    /// - Returns: A summarized version of the input text.
    func summarizeText(_ text: String) async throws -> String {
        // Simulate a network call or a heavy on-device LLM computation
        try await Task.sleep(for: .seconds(1.5)) // Simulate latency

        // Simple heuristic for simulation: take the first few sentences or a percentage
        guard !text.isEmpty else {
            throw SmartNotesError.summarizationFailed
        }

        let sentences = text.components(separatedBy: CharacterSet(charactersIn: ".!?")).filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        let summarySentenceCount = min(max(1, sentences.count / 3), 3) // Summarize to 1-3 sentences

        if summarySentenceCount == 0 {
            // Fallback for very short notes or notes that can't be split into sentences
            return "Summary: \(text.prefix(100))..."
        }

        let summary = sentences.prefix(summarySentenceCount).joined(separator: ". ") + "."
        return "AI Summary: \(summary)"
    }
}
