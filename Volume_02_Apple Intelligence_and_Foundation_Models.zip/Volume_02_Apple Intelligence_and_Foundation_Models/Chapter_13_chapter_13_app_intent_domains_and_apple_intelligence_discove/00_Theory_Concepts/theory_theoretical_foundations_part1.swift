
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    import Foundation
    import AppIntents // Requires iOS 18.0+

    @available(iOS 18.0, *)
    struct SummarizeDocumentIntent: AppIntent {
        static var title: LocalizedStringResource = "Summarize Document"
        static var description = IntentDescription("Summarizes the content of a document using an on-device LLM.")

        @Parameter(title: "Document Content")
        var content: String

        @Parameter(title: "Summary Length", default: .medium)
        var length: SummaryLength

        enum SummaryLength: String, AppEnum {
            static var typeDisplayRepresentation: TypeDisplayRepresentation = "Summary Length"
            static var caseDisplayRepresentations: [Self: DisplayRepresentation] = [
                .short: "Short",
                .medium: "Medium",
                .long: "Long"
            ]
            case short, medium, long
        }

        func perform() async throws -> some IntentResult {
            // Simulate fetching a document from a remote server (async operation)
            let documentText = try await fetchDocumentContent(from: content)

            // Simulate processing with an on-device LLM (async operation)
            let summary = try await generateSummary(for: documentText, length: length)

            return .result(value: summary, view: {
                // SwiftUI view to display the summary
                IntentResultView {
                    Text("Summary:")
                    Text(summary)
                        .font(.body)
                        .padding()
                }
            })
        }

        private func fetchDocumentContent(from content: String) async throws -> String {
            // In a real app, this might be a network request or file system access
            try await Task.sleep(for: .seconds(0.5)) // Simulate network delay
            return "This is the full content of the document that needs to be summarized. It contains various details about the topic, providing context and data points for the AI to process. The document aims to inform the reader about the intricacies of App Intent Domains and their role in Apple Intelligence, emphasizing privacy, performance, and seamless user experience. It also delves into how modern Swift concurrency features like async/await, actors, @Observable, and Sendable types are integral to building robust and safe AI-powered app extensions. The theoretical foundations are critical for understanding the practical implications."
        }

        private func generateSummary(for text: String, length: SummaryLength) async throws -> String {
            // This is where an on-device LLM API call would happen
            // For demonstration, we'll use a simple truncation
            try await Task.sleep(for: .seconds(1)) // Simulate LLM processing time

            let words = text.split(separator: " ")
            let summaryWords: ArraySlice<String.SubSequence>
            switch length {
            case .short:
                summaryWords = words.prefix(20)
            case .medium:
                summaryWords = words.prefix(40)
            case .long:
                summaryWords = words.prefix(60)
            }
            return summaryWords.joined(separator: " ") + "..."
        }
    }
    