
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

enum CircuitBreakerError: Error {
    case serviceUnavailable
}

actor CircuitBreaker {
    enum State {
        case closed    // Normal operation
        case open      // Service is down, failing fast
        case halfOpen  // Testing recovery
    }
    
    private var state: State = .closed
    private var consecutiveFailures = 0
    private let failureThreshold: Int
    private let resetTimeout: TimeInterval
    private var lastFailureTime: Date?

    init(failureThreshold: Int = 5, resetTimeout: TimeInterval = 60) {
        self.failureThreshold = failureThreshold
        self.resetTimeout = resetTimeout
    }

    func execute<T>(task: @escaping @Sendable () async throws -> T) async throws -> T {
        try await updateState()
        
        switch state {
        case .open:
            throw CircuitBreakerError.serviceUnavailable
            
        case .closed, .halfOpen:
            do {
                let result = try await task()
                await recordSuccess()
                return result
            } catch let error as LLMError where error.isRetryable {
                await recordFailure()
                throw error
            } catch {
                // Non-retryable errors don't trip the circuit
                throw error
            }
        }
    }

    private func updateState() {
        if state == .open, let lastFailure = lastFailureTime {
            if Date().timeIntervalSince(lastFailure) >= resetTimeout {
                print("Circuit Breaker: Transitioning to Half-Open")
                state = .halfOpen
            }
        }
    }

    private func recordSuccess() {
        if state == .halfOpen || consecutiveFailures > 0 {
            print("Circuit Breaker: Service recovered. Closing circuit.")
            state = .closed
            consecutiveFailures = 0
        }
    }

    private func recordFailure() {
        consecutiveFailures += 1
        lastFailureTime = Date()
        
        if consecutiveFailures >= failureThreshold {
            print("Circuit Breaker: Threshold reached. Opening circuit.")
            state = .open
        }
    }
}

// --- Integration Example ---

struct ResilientLLMClient {
    let circuitBreaker = CircuitBreaker()
    let retryHandler = LLMRetryHandler(strategy: BackoffStrategy(base: 1, maxDelay: 30, jitterFactor: 0.2))

    func request(prompt: String) async throws -> String {
        // The Flow: Request -> Circuit Breaker -> Retry Handler -> Network
        try await circuitBreaker.execute {
            try await retryHandler.execute(maxRetries: 2) {
                // Simulate actual network call
                print("Attempting network request...")
                throw LLMError.serviceUnavailable 
            }
        }
    }
}
