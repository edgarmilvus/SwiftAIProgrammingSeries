
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import CreateML
import CoreML // For MLModel and prediction input types
import Vision // For converting images to CVPixelBuffer

// MARK: - MLPetClassifier
/// A utility class to encapsulate the Create ML training and prediction logic.
@MainActor // Ensure UI updates and async operations are handled on the main actor
class MLPetClassifier: ObservableObject {
    @Published var trainingStatus: String = "Ready to train."
    @Published var predictionResult: String = "No prediction made."
    @Published var predictionConfidence: String = ""

    private var trainedModel: MLImageClassifier?

    /// Trains a new image classifier model using data from the specified URL.
    /// - Parameter trainingDataURL: The URL to the directory containing subdirectories of labeled images.
    /// - Parameter modelOutputURL: The URL where the trained .mlmodel file will be saved.
    /// - Throws: An error if training fails or data is invalid.
    func trainModel(trainingDataURL: URL, modelOutputURL: URL) async {
        trainingStatus = "Training started..."
        do {
            // 1. Load Training Data
            /// Create ML expects training data organized into subfolders, where each subfolder name
            /// represents a class label and contains images belonging to that class.
            /// `MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)`
            /// automatically parses this structure.
            let trainingDataSource = MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)

            // 2. Configure Training Parameters (Optional, using defaults here for simplicity)
            /// For more control, you can specify parameters like validation data,
            /// augmentation options, and feature extractor.
            let parameters = MLImageClassifier.ModelParameters() // Default parameters

            // 3. Train the Model
            /// The `train` static method is an async function that performs the actual training.
            /// It leverages transfer learning on a pre-trained convolutional neural network.
            /// The process can be time-consuming depending on the dataset size and hardware.
            let model = try await MLImageClassifier.train(
                trainingData: trainingDataSource,
                parameters: parameters
            )

            // 4. Evaluate the Model (Optional, but recommended for real apps)
            /// After training, you can evaluate the model's performance on a separate validation set
            /// to get metrics like accuracy. For simplicity, we skip this here.

            // 5. Save the Trained Model
            /// The trained model is an `MLImageClassifier` instance. To use it in a Core ML app,
            /// it needs to be exported as a `.mlmodel` file.
            try model.write(to: modelOutputURL)
            self.trainedModel = model // Keep a reference to the in-memory model

            trainingStatus = "Training complete! Model saved to: \(modelOutputURL.lastPathComponent)"
            print("Model saved to: \(modelOutputURL.path)")

        } catch {
            trainingStatus = "Training failed: \(error.localizedDescription)"
            print("Training error: \(error)")
        }
    }

    /// Loads a trained MLImageClassifier model from a specified URL.
    /// - Parameter modelURL: The URL to the .mlmodel file.
    /// - Throws: An error if the model cannot be loaded.
    func loadModel(from modelURL: URL) async throws {
        // 1. Compile the .mlmodel file
        /// Before a Core ML model can be used, it needs to be compiled into an `.mlmodelc` directory.
        /// `MLModel.compileModel(at:)` handles this.
        let compiledModelURL = try await MLModel.compileModel(at: modelURL)

        // 2. Load the compiled model
        /// `MLModel(contentsOf:)` loads the compiled model into memory.
        let coreMLModel = try MLModel(contentsOf: compiledModelURL)

        // 3. Cast to MLImageClassifier
        /// We know this is an image classifier, so we can cast it.
        guard let imageClassifier = try? MLImageClassifier(mlModel: coreMLModel) else {
            throw MLClassifierError.invalidModelType
        }
        self.trainedModel = imageClassifier
        trainingStatus = "Model loaded from: \(modelURL.lastPathComponent)"
    }

    /// Makes a prediction using the loaded model on a given image.
    /// - Parameter image: The `CGImage` to classify.
    /// - Throws: An error if no model is loaded or prediction fails.
    func predict(image: CGImage) async {
        guard let model = trainedModel else {
            predictionResult = "Error: Model not loaded."
            predictionConfidence = ""
            return
        }

        do {
            // 1. Prepare Image Input
            /// Core ML models typically expect `CVPixelBuffer` as input for images.
            /// `MLImageClassifier.ImageInput` can take a `CGImage` directly or `CVPixelBuffer`.
            let imageInput = MLImageClassifier.ImageInput(image: image)

            // 2. Make Prediction
            /// `prediction(from:)` performs the inference.
            let prediction = try model.prediction(from: imageInput)

            // 3. Interpret Results
            /// The prediction object contains the `label` (the predicted class)
            /// and `labelProbabilities` (confidence scores for each class).
            predictionResult = "Predicted: \(prediction.label)"
            if let confidence = prediction.labelProbabilities[prediction.label] {
                predictionConfidence = String(format: "Confidence: %.2f%%", confidence * 100)
            } else {
                predictionConfidence = ""
            }

        } catch {
            predictionResult = "Prediction failed: \(error.localizedDescription)"
            predictionConfidence = ""
            print("Prediction error: \(error)")
        }
    }
}

// MARK: - MLClassifierError
/// Custom error types for the classifier operations.
enum MLClassifierError: Error, LocalizedError {
    case invalidModelType
    case trainingDataNotFound
    case predictionInputInvalid

    var errorDescription: String? {
        switch self {
        case .invalidModelType: return "The loaded model is not an MLImageClassifier."
        case .trainingDataNotFound: return "Training data directory not found."
        case .predictionInputInvalid: return "Invalid input for prediction."
        }
    }
}

// MARK: - ContentView
/// The main SwiftUI view for the Pet Photo Classifier app.
struct ContentView: View {
    @StateObject private var classifier = MLPetClassifier()
    @State private var showingImagePicker = false
    @State private var inputImage: UIImage?

    // MARK: - Helper URLs
    /// Get the URL for the app's Documents directory where training data and models will be stored.
    private var documentsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }

    /// URL for the conceptual training data directory.
    /// You would need to manually place your 'Cat' and 'Dog' folders here.
    private var trainingDataURL: URL {
        documentsDirectory.appendingPathComponent("TrainingData")
    }

    /// URL where the trained model will be saved.
    private var modelOutputURL: URL {
        documentsDirectory.appendingPathComponent("PetClassifier.mlmodel")
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // MARK: - Training Section
                Text("ML Model Training")
                    .font(.headline)
                Text(classifier.trainingStatus)
                    .font(.subheadline)
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)

                Button("Train Pet Classifier Model") {
                    Task {
                        // In a real app, you'd ensure trainingDataURL exists and contains data.
                        // For this example, we'll assume it's set up correctly.
                        await classifier.trainModel(trainingDataURL: trainingDataURL, modelOutputURL: modelOutputURL)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(classifier.trainingStatus.contains("Training started")) // Prevent re-training mid-process

                Button("Load Existing Model") {
                    Task {
                        do {
                            try await classifier.loadModel(from: modelOutputURL)
                        } catch {
                            classifier.trainingStatus = "Failed to load model: \(error.localizedDescription)"
                        }
                    }
                }
                .buttonStyle(.bordered)
                .disabled(classifier.trainingStatus.contains("Training started"))

                Divider()

                // MARK: - Prediction Section
                Text("Image Classification")
                    .font(.headline)

                if let inputImage = inputImage {
                    Image(uiImage: inputImage)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                        .cornerRadius(10)
                } else {
                    Rectangle()
                        .fill(Color.gray.opacity(0.2))
                        .frame(width: 200, height: 200)
                        .cornerRadius(10)
                        .overlay(Text("No Image Selected"))
                }

                Text(classifier.predictionResult)
                    .font(.title2)
                    .fontWeight(.bold)
                Text(classifier.predictionConfidence)
                    .font(.subheadline)
                    .foregroundColor(.secondary)

                Button("Select Image & Predict") {
                    showingImagePicker = true
                }
                .buttonStyle(.borderedProminent)
                .disabled(classifier.trainingStatus.contains("Error") || classifier.trainingStatus.contains("Ready to train")) // Disable if no model is ready

            }
            .padding()
            .navigationTitle("Pet Classifier")
            .sheet(isPresented: $showingImagePicker) {
                ImagePicker(selectedImage: $inputImage) { selectedCGImage in
                    // Callback when an image is selected
                    Task {
                        if let cgImage = selectedCGImage {
                            await classifier.predict(image: cgImage)
                        } else {
                            classifier.predictionResult = "No image selected for prediction."
                            classifier.predictionConfidence = ""
                        }
                    }
                }
            }
        }
    }
}

// MARK: - ImagePicker
/// A simple wrapper for `UIImagePickerController` to select images from the photo library.
struct ImagePicker: UIViewControllerRepresentable {
    @Environment(\.presentationMode) var presentationMode
    @Binding var selectedImage: UIImage?
    var onImageSelected: (CGImage?) -> Void

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = .photoLibrary
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        var parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                parent.selectedImage = uiImage
                parent.onImageSelected(uiImage.cgImage)
            }
            parent.presentationMode.wrappedValue.dismiss()
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.presentationMode.wrappedValue.dismiss()
        }
    }
}

// MARK: - App Entry Point
/// The main entry point for the SwiftUI application.
@main
struct PetClassifierApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
