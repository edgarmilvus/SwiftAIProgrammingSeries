
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import AVFoundation // Required for audio capture and processing

// MARK: - 1. WaveformView: SwiftUI View for Drawing the Waveform

/// A SwiftUI `Shape` that draws a simple waveform based on an array of normalized amplitude samples.
///
/// This view takes an array of `Float` values, assumed to be normalized between 0 and 1,
/// and draws a path connecting these points, reflecting them around the center of the view
/// to simulate a typical audio waveform display.
struct WaveformView: View {
    var samples: [Float] // Normalized amplitude values (0.0 to 1.0)
    var color: Color = .blue
    var lineWidth: CGFloat = 2

    var body: some View {
        GeometryReader { geometry in
            Path { path in
                guard !samples.isEmpty else { return }

                let width = geometry.size.width
                let height = geometry.size.height
                let stepX = width / CGFloat(samples.count) // Calculate horizontal spacing for each sample

                // Start the path in the middle of the view (y-axis)
                // This creates a baseline for the waveform to expand from.
                path.move(to: CGPoint(x: 0, y: height / 2))

                // Iterate through samples and add lines to the path
                for i in 0..<samples.count {
                    let x = CGFloat(i) * stepX
                    let normalizedSample = samples[i] // Already normalized (0 to 1)

                    // Calculate the y-coordinate. We want the waveform to be centered.
                    // A sample of 0.0 (silence) should be at height/2.
                    // A sample of 1.0 (max amplitude) should go up to height (or down to 0).
                    // We'll draw from the center, so `normalizedSample * height / 2` gives the offset.
                    // Subtracting from `height / 2` makes it go upwards.
                    let y = height / 2 - (normalizedSample * height / 2)

                    path.addLine(to: CGPoint(x: x, y: y))
                }
            }
            .stroke(color, lineWidth: lineWidth) // Apply stroke color and width
            // Add a small animation for smoother updates as samples change
            .animation(.linear(duration: 0.05), value: samples)
        }
    }
}

// MARK: - 2. AudioRecorderViewModel: Manages Audio Capture and Data Processing

/// An `ObservableObject` responsible for managing microphone input, processing audio
/// buffers, and publishing normalized waveform data to the UI.
///
/// `@MainActor` ensures that all `@Published` properties and UI-related logic
/// are executed on the main thread, preventing UI freezes and ensuring thread safety
/// for SwiftUI updates.
@MainActor
class AudioRecorderViewModel: ObservableObject {
    /// The array of normalized amplitude samples for the waveform view.
    @Published var waveformSamples: [Float] = []
    /// Indicates whether the audio engine is currently recording.
    @Published var isRecording: Bool = false
    /// Indicates whether microphone permission has been granted.
    @Published var permissionGranted: Bool = false

    private var audioEngine: AVAudioEngine?
    /// The size of audio buffers to process at a time (in frames).
    /// A common size like 1024 frames is a good balance between latency and processing overhead.
    private let bufferSize: AVAudioFrameCount = 1024
    /// An internal buffer to accumulate raw audio samples before processing them for waveform points.
    private var audioSampleBuffer: [Float] = []
    /// The maximum number of waveform points to display, determining the "length" of the visible waveform.
    private let maxWaveformSamples: Int = 100

    /// Initializes the view model and immediately requests microphone permission.
    init() {
        requestMicrophonePermission()
    }

    /// Requests microphone access permission from the user.
    ///
    /// This is crucial for `AVFoundation` to access the device's microphone.
    /// The completion handler updates `permissionGranted` on the main thread.
    private func requestMicrophonePermission() {
        AVAudioApplication.requestRecordPermission { [weak self] granted in
            // Ensure UI updates (like `permissionGranted`) happen on the main thread.
            // Even though the class is @MainActor, this callback might originate from a background queue.
            DispatchQueue.main.async {
                self?.permissionGranted = granted
                if !granted {
                    print("Microphone permission denied.")
                }
            }
        }
    }

    /// Sets up and starts the `AVAudioEngine` for real-time audio input.
    ///
    /// - It creates an `AVAudioEngine`, gets the input node (microphone),
    ///   and installs a `tap` to receive audio buffers.
    /// - The `tap` callback is where raw audio data is received and processed.
    func startRecording() {
        guard permissionGranted else {
            print("Microphone permission not granted. Cannot start recording.")
            return
        }

        // Initialize a new audio engine.
        audioEngine = AVAudioEngine()
        guard let engine = audioEngine else { return }

        // Get the audio input node (microphone).
        let inputNode = engine.inputNode
        // Get the output format of the input node (e.g., sample rate, channel count).
        let format = inputNode.outputFormat(forBus: 0)

        // Install a tap on the input node's output bus.
        // This allows us to intercept and process audio buffers in real-time.
        inputNode.installTap(onBus: 0, bufferSize: bufferSize, format: format) { [weak self] buffer, time in
            guard let self = self else { return }

            // The tap callback runs on a high-priority internal audio thread.
            // It's critical to perform minimal work here and offload heavy processing.
            // More importantly, any UI updates MUST be dispatched to the main thread.
            // Using `Task { @MainActor in ... }` is the modern Swift concurrency way to do this.
            Task { @MainActor in
                // Ensure we have float channel data (most common for audio processing).
                guard let channelData = buffer.floatChannelData else { return }
                // Create an `UnsafeBufferPointer` to access the raw float samples efficiently.
                let samples = UnsafeBufferPointer(start: channelData[0], count: Int(buffer.frameLength))

                // Process the raw audio samples for waveform visualization.
                self.processAudioSamples(samples: Array(samples))
            }
        }

        // Start the audio engine. This begins the audio capture.
        do {
            try engine.start()
            isRecording = true
            print("Audio engine started.")
        } catch {
            print("Error starting audio engine: \(error.localizedDescription)")
            isRecording = false
        }
    }

    /// Stops the `AVAudioEngine` and cleans up resources.
    ///
    /// - It's important to stop the engine and remove the tap to release microphone resources.
    func stopRecording() {
        guard let engine = audioEngine else { return }
        engine.stop() // Stop the audio engine.
        engine.inputNode.removeTap(onBus: 0) // Remove the tap to prevent further callbacks.
        self.audioEngine = nil // Release the engine.
        isRecording = false
        waveformSamples = [] // Clear the displayed waveform.
        audioSampleBuffer = [] // Clear internal sample buffer.
        print("Audio engine stopped.")
    }

    /// Processes incoming raw audio samples to generate a single point for the waveform visualization.
    ///
    /// - Parameter samples: An array of raw audio samples (Floats, typically -1.0 to 1.0).
    ///
    /// For this basic example, we calculate the peak absolute amplitude within a segment
    /// of samples to represent a single point on the waveform.
    private func processAudioSamples(samples: [Float]) {
        // Add new samples to our internal buffer.
        audioSampleBuffer.append(contentsOf: samples)

        // Determine how many raw samples contribute to one waveform point.
        // Adjust `samplesPerPoint` to control the granularity/resolution of the waveform.
        // A smaller value means more frequent updates and a more detailed waveform.
        let samplesPerPoint = bufferSize / 4 // e.g., 1024 / 4 = 256 samples per point

        // If we have accumulated enough raw samples to generate a new waveform point:
        while audioSampleBuffer.count >= samplesPerPoint {
            // Take a segment of samples from the beginning of the buffer.
            let segment = audioSampleBuffer.prefix(Int(samplesPerPoint))
            // Remove these processed samples from the buffer.
            audioSampleBuffer.removeFirst(Int(samplesPerPoint))

            // Calculate the peak absolute amplitude within this segment.
            // `abs($0)` converts negative samples to positive, giving us the magnitude.
            let peakAmplitude = segment.map { abs($0) }.max() ?? 0.0

            // Normalize the amplitude to a 0-1 range.
            // `min(peakAmplitude, 1.0)` clamps values that might theoretically exceed 1.0 (though rare).
            let normalizedAmplitude = min(peakAmplitude, 1.0)

            // Add the new normalized amplitude point to our waveform history.
            waveformSamples.append(normalizedAmplitude)

            // Maintain a fixed number of waveform points to keep the display scrolling.
            if waveformSamples.count > maxWaveformSamples {
                waveformSamples.removeFirst() // Remove the oldest point.
            }
        }
    }
}

// MARK: - 3. ContentView: Main SwiftUI View

/// The main SwiftUI view that hosts the `WaveformView` and controls for recording.
///
/// It observes the `AudioRecorderViewModel` to update the UI based on recording state
/// and new waveform data.
struct ContentView: View {
    // `@StateObject` creates and manages the lifecycle of the `ViewModel`.
    @StateObject private var viewModel = AudioRecorderViewModel()

    var body: some View {
        VStack {
            Text("Live Audio Waveform")
                .font(.largeTitle)
                .padding()

            // Display the WaveformView, passing the samples from the ViewModel.
            WaveformView(samples: viewModel.waveformSamples)
                .frame(height: 150) // Fixed height for the waveform display
                .background(Color.gray.opacity(0.2)) // Subtle background
                .cornerRadius(10)
                .padding()

            HStack {
                // Toggle button for starting/stopping recording
                Button(action: {
                    if viewModel.isRecording {
                        viewModel.stopRecording()
                    } else {
                        viewModel.startRecording()
                    }
                }) {
                    Image(systemName: viewModel.isRecording ? "stop.circle.fill" : "record.circle.fill")
                        .font(.largeTitle)
                        .foregroundColor(viewModel.isRecording ? .red : .green)
                }
                // Disable the button if permission is not granted and not currently recording
                .disabled(!viewModel.permissionGranted && !viewModel.isRecording)

                Text(viewModel.isRecording ? "Recording..." : "Idle")
                    .font(.title2)
                    .padding(.leading)
            }
            .padding()

            // Display a message if microphone permission is not granted
            if !viewModel.permissionGranted {
                Text("Microphone permission required to record audio.")
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .onDisappear {
            // Ensure audio engine is stopped when the view disappears
            viewModel.stopRecording()
        }
    }
}

// MARK: - App Entry Point (for Xcode Previews and actual app)
// This is typically in your App.swift file for a standard SwiftUI app.
@main
struct WaveformApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
