/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// SERVER-SIDE: Next.js API Route
// File: pages/api/notifications/stream.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';

// In-memory map to store active connections (Production: use Redis Pub/Sub)
const activeConnections = new Map<string, NextApiResponse>();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session?.user?.id) {
    return res.status(401).end();
  }

  const userId = session.user.id;

  // SSE Headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  
  // Store connection
  activeConnections.set(userId, res);

  // Listen for client disconnect
  req.on('close', () => {
    console.log(`Connection closed for user ${userId}`);
    activeConnections.delete(userId);
    res.end();
  });

  // Simulate sending an initial event
  res.write(`event: notification_status\ndata: {"status": "connected"}\n\n`);
}

// Helper function to trigger updates (called from elsewhere in the app)
export function broadcastToUser(userId: string, data: any) {
  const res = activeConnections.get(userId);
  if (res) {
    res.write(`event: notification_status\ndata: ${JSON.stringify(data)}\n\n`);
  }
}

// CLIENT-SIDE: React Hook
// File: hooks/useNotificationStream.ts
import { useEffect, useState, useRef } from 'react';

export function useNotificationStream() {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const eventSourceRef = useRef<EventSource | null>(null);
  const retryCount = useRef(0);

  useEffect(() => {
    const connect = () => {
      const es = new EventSource('/api/notifications/stream');
      eventSourceRef.current = es;

      es.onopen = () => {
        setIsConnected(true);
        retryCount.current = 0; // Reset retry on successful connection
      };

      es.onmessage = (event) => {
        const data = JSON.parse(event.data);
        setNotifications((prev) => [...prev, data]);
      };

      es.onerror = () => {
        setIsConnected(false);
        es.close();
        
        // Exponential Backoff
        const timeout = Math.min(1000 * Math.pow(2, retryCount.current), 30000);
        retryCount.current += 1;
        setTimeout(connect, timeout);
      };
    };

    connect();

    return () => {
      eventSourceRef.current?.close();
    };
  }, []);

  return { notifications, isConnected };
}

// CLIENT-SIDE: Component
// File: components/NotificationStatusBadge.tsx
import { useNotificationStream } from '../hooks/useNotificationStream';

export const NotificationStatusBadge = ({ notificationId }: { notificationId: string }) => {
  const { notifications, isConnected } = useNotificationStream();
  
  // Find the status for this specific ID from the stream history
  const statusEvent = notifications.find(n => n.id === notificationId);
  const status = statusEvent ? statusEvent.status : 'pending';

  if (!isConnected) return <span>Connecting...</span>;

  return (
    <div className={`badge ${status}`}>
      Status: {status.toUpperCase()}
    </div>
  );
};
