
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
enum EmailPriority: String, Codable, Sendable {
    case low, medium, high
}

@available(iOS 18.0, macOS 15.0, *)
struct EmailMetadata: Codable, Sendable {
    let senderName: String
    let priority: EmailPriority
    let deadline: Date?
    let isUrgent: Bool
}

@available(iOS 18.0, macOS 15.0, *)
actor EmailParserService {
    private let decoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }()

    /// Simulates a call to an LLM provider (e.g., OpenAI)
    private func callLLM(with prompt: String, body: String) async throws -> String {
        // In a real app, this would be a URLSession call to the OpenAI API
        // with response_format: { "type": "json_object" }
        try await Task.sleep(for: .seconds(1)) 
        
        // Simulated successful JSON response based on common "messy" email inputs
        return """
        {
            "senderName": "Jane Doe",
            "priority": "high",
            "deadline": "2025-12-31T23:59:59Z",
            "isUrgent": true
        }
        """
    }

    func parse(emailBody: String) async throws -> EmailMetadata {
        let systemPrompt = """
        You are a specialized metadata extractor. 
        Your task is to extract information from email bodies into a valid JSON object.
        
        STRICT SCHEMA:
        {
          "senderName": string,
          "priority": "low" | "medium" | "high",
          "deadline": ISO8601 string (e.g., "YYYY-MM-DDTHH:MM:SSZ") or null,
          "isUrgent": boolean
        }
        
        Output ONLY the JSON object. Do not include conversational text.
        """

        let rawResponse = try await callLLM(with: systemPrompt, body: emailBody)
        
        guard let data = rawResponse.data(using: .utf8) else {
            throw DecodingError.dataCorrupted(.init(codingPath: [], debugDescription: "Invalid string encoding"))
        }

        return try decoder.decode(EmailMetadata.self, from: data)
    }
}

// Usage Example:
// let service = EmailParserService()
// let metadata = try await service.parse(emailBody: "Hey, it's Jane. Please finish the report by end of year!")
