
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import Accelerate

/// A minimized, non-identifiable representation of sensor data.
/// Conforms to Sendable to safely pass between concurrency domains.
struct SensorFeatureSet: Sendable {
    let mean: Double
    let standardDeviation: Double
    let peakFrequencyPlaceholder: Double
    let normalizedEnergy: Double
}

/// A service responsible for extracting features from raw signals.
final class SignalFeatureExtractor {
    
    // We keep a private reference to the raw data to demonstrate deallocation.
    private var rawData: [Double]?
    
    init(data: [Double]) {
        self.rawData = data
    }
    
    /// Processes the raw signal and returns a minimized feature set.
    /// - Returns: A `SensorFeatureSet` containing only statistical abstractions.
    func extractFeatures() -> SensorFeatureSet {
        guard let data = rawData, !data.isEmpty else {
            return SensorFeatureSet(mean: 0, standardDeviation: 0, peakFrequencyPlaceholder: 0, normalizedEnergy: 0)
        }
        
        let count = vDSP_Length(data.count)
        var mean = 0.0
        var stdDev = 0.0
        
        // 1. Calculate Mean using Accelerate (vDSP)
        vDSP_meanvD(data, 1, &mean, count)
        
        // 2. Calculate Standard Deviation using Accelerate
        // Formula: sqrt(mean(x^2) - mean(x)^2)
        var meanSquared = 0.0
        vDSP_meanvD(data, 1, &meanSquared, count) // This is actually mean of x, we need mean of x^2
        
        // Correct way to get StdDev with vDSP:
        var sumOfSquares = 0.0
        vDSP_svemgD(data, 1, &sumOfSquares, count) // This is sum of magnitudes, let's use the variance method
        
        // Using a more standard vDSP approach for variance:
        var variance = 0.0
        let meanCopy = mean
        // Subtract mean from every element
        var negativeMean = -meanCopy
        var centeredData = [Double](repeating: 0.0, count: data.count)
        vDSP_vsaddD(data, 1, &negativeMean, &centeredData, 1, count)
        // Sum of squares of centered data
        vDSP_svemgD(centeredData, 1, &sumOfSquares, count) // Not quite, let's use dot product for sum of squares
        var dotProduct = 0.0
        vDSP_dotprD(centeredData, 1, centeredData, 1, &dotProduct, count)
        variance = dotProduct / Double(data.count)
        stdDev = sqrt(variance)
        
        // 3. Calculate Normalized Energy (Sum of squares / count)
        let energy = dotProduct / Double(data.count)
        
        // 4. Placeholder for Peak Frequency (Simulating FFT result)
        let peakFreq = 440.0 // Placeholder
        
        // CRITICAL PRIVACY STEP: Deallocate the raw high-fidelity data immediately
        self.rawData = nil
        
        return SensorFeatureSet(
            mean: mean,
            standardDeviation: stdDev,
            peakFrequencyPlaceholder: peakFreq,
            normalizedEnergy: energy
        )
    }
    
    /// Verifies that the high-resolution data has been scrubbed from memory.
    func isMinimallyProcessed() -> Bool {
        return rawData == nil
    }
}

// MARK: - Example Usage
let rawSignal = (0..<1000).map { _ in Double.random(in: -1.0...1.0) }
let extractor = SignalFeatureExtractor(data: rawSignal)
let features = extractor.extractFeatures()

print("Extracted Mean: \(features.mean)")
print("Is Raw Data Cleared? \(extractor.isMinimallyProcessed())")
