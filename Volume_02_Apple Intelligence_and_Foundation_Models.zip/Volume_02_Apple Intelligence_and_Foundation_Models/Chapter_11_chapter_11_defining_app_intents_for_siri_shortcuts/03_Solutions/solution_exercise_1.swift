
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import AppIntents
import Foundation

// MARK: - Habit Logger Intent

@available(iOS 18.0, *)
struct LogHabitIntent: AppIntent {
    static var intentDisplayName: LocalizedStringResource = "Log Habit"
    static var description: LocalizedStringResource = "Logs a daily habit like drinking water or meditating."

    @Parameter(title: "Habit Name", description: "The name of the habit to log (e.g., 'Drink Water').")
    var habitName: String

    static var parameterSummary: some ParameterSummary {
        Summary("Log \((\.$habitName))")
    }

    func perform() async throws -> some IntentResult {
        // Simulate logging the habit to a data store or service
        print("Logged habit: \(habitName) at \(Date())")

        // In a real app, you might save this to Core Data, CloudKit, or a local database.
        // The result can include a dialog for the user in Shortcuts.
        return .result(
            dialog: "Logged '\(habitName)' successfully."
        )
    }
}

// MARK: - App Shortcuts Provider

@available(iOS 18.0, *)
struct MyHabitsAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: LogHabitIntent(),
            phrases: [
                "Log my \(.\$habitName) habit",
                "I \(.\$habitName) today",
                "Record \(.\$habitName)"
            ],
            shortTitle: "Log Habit",
            systemImageName: "checkmark.circle.fill"
        )
    }
}
