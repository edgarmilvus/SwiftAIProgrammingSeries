
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CreateML
import Foundation

@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
func processImageMetadataForSmartAlbums() throws {
    print("--- Processing Image Metadata for Smart Albums ---")

    // 1. Data Source: Assume image metadata as an array of dictionaries.
    let imageData: [[String: MLDataValueConvertible]] = [
        ["imageID": "img_001", "path": "/photos/vacation/img_001.jpg", "captureDate": Date(timeIntervalSinceReferenceDate: 631152000), "location": "Paris, France", "tags": ["Eiffel Tower", "City", "Landmark"], "resolution": "1920x1080"],
        ["imageID": "img_002", "path": "/photos/nature/img_002.jpg", "captureDate": Date(timeIntervalSinceReferenceDate: 631152000 + 86400 * 5), "location": "Alps, Switzerland", "tags": ["Mountains", "Nature"], "resolution": "3840x2160"],
        ["imageID": "img_003", "path": "/photos/pets/img_003.jpg", "captureDate": Date(timeIntervalSinceReferenceDate: 631152000 + 86400 * 10), "location": "Home, USA", "tags": ["Dog", "Pet"], "resolution": "1280x720"],
        ["imageID": "img_004", "path": "/photos/vacation/img_004.jpg", "captureDate": Date(timeIntervalSinceReferenceDate: 631152000 + 86400 * 2), "location": "Paris, France", "tags": ["Street", "Food"], "resolution": "1920x1080"],
        ["imageID": "img_005", "path": "/photos/events/img_005.jpg", "captureDate": Date(timeIntervalSinceReferenceDate: 631152000 + 86400 * 15), "location": "New York, USA", "tags": ["Concert", "Crowd"], "resolution": "2560x1440"],
        ["imageID": "img_006", "path": "/photos/nature/img_006.jpg", "captureDate": Date(timeIntervalSinceReferenceDate: 631152000 + 86400 * 20), "location": "Yosemite, USA", "tags": ["Mountains", "Forest"], "resolution": "3840x2160"]
    ]
    // Note: Date(timeIntervalSinceReferenceDate: 631152000) corresponds to roughly Jan 1, 2020 UTC.

    // 2. Load Data: Create an MLDataTable from this imageData array.
    var dataTable = try MLDataTable(dictionaryArray: imageData)
    print("Initial Data Table Row Count: \(dataTable.rowCount)")
    print("Initial Columns: \(dataTable.columnNames.joined(separator: ", "))\n")

    let calendar = Calendar.current

    // 3. Derived Temporal Features:
    //    a. captureYear
    try dataTable.addColumn(named: "captureYear", type: Int.self) { (row: MLDataRow) -> Int in
        let date = row["captureDate"] as! Date
        return calendar.component(.year, from: date)
    }
    print("Added 'captureYear' column.")

    //    b. captureMonth
    try dataTable.addColumn(named: "captureMonth", type: Int.self) { (row: MLDataRow) -> Int in
        let date = row["captureDate"] as! Date
        return calendar.component(.month, from: date)
    }
    print("Added 'captureMonth' column.")

    //    c. isWeekend
    try dataTable.addColumn(named: "isWeekend", type: Bool.self) { (row: MLDataRow) -> Bool in
        let date = row["captureDate"] as! Date
        let weekday = calendar.component(.weekday, from: date)
        return weekday == calendar.firstWeekday || weekday == calendar.firstWeekday + 6 // Sunday or Saturday
    }
    print("Added 'isWeekend' column.\n")

    // 4. Categorical Feature Expansion:
    //    a. hasEiffelTowerTag
    try dataTable.addColumn(named: "hasEiffelTowerTag", type: Bool.self) { (row: MLDataRow) -> Bool in
        let tags = row["tags"] as! [String]
        return tags.contains("Eiffel Tower")
    }
    print("Added 'hasEiffelTowerTag' column.")

    //    b. isHighResolution
    try dataTable.addColumn(named: "isHighResolution", type: Bool.self) { (row: MLDataRow) -> Bool in
        let resolution = row["resolution"] as! String
        return resolution == "3840x2160" // Check for 4K resolution
    }
    print("Added 'isHighResolution' column.\n")
    
    //    c. isNaturePhoto (needed for complex filtering)
    try dataTable.addColumn(named: "isNaturePhoto", type: Bool.self) { (row: MLDataRow) -> Bool in
        let tags = row["tags"] as! [String]
        return tags.contains("Mountains") || tags.contains("Nature") || tags.contains("Forest")
    }
    print("Added 'isNaturePhoto' column (for filtering).\n")

    // 5. Geographical Feature Extraction:
    //    a. country
    try dataTable.addColumn(named: "country", type: String.self) { (row: MLDataRow) -> String in
        let location = row["location"] as! String
        if let commaIndex = location.firstIndex(of: ",") {
            let countryString = String(location[location.index(after: commaIndex)...]).trimmingCharacters(in: .whitespaces)
            return countryString.isEmpty ? "Unknown" : countryString
        } else if location.contains("USA") { // Fallback for "Home, USA" or similar
            return "USA"
        } else if location.contains("Switzerland") {
            return "Switzerland"
        }
        return "Unknown"
    }
    print("Added 'country' column by parsing 'location'.\n")

    // 6. Complex Filtering for Smart Album ("Travel Highlights"):
    //    Condition 1: Captured in "France"
    //    Condition 2: (isNaturePhoto is true AND isHighResolution is true)
    let travelHighlightsAlbum = try dataTable.filter(
        (dataTable["country"] == "France") ||
        (dataTable["isNaturePhoto"] == true && dataTable["isHighResolution"] == true)
    )
    print("Filtered for 'Travel Highlights' smart album.")

    // 7. Verification:
    print("--- Transformed Data Table Details ---")
    print("Column Names: \(dataTable.columnNames.joined(separator: ", "))")
    print("Column Types:")
    for columnName in dataTable.columnNames {
        print("  - \(columnName): \(dataTable[columnName].dataType)")
    }

    print("\n--- 'Travel Highlights' Smart Album Data (First 5 Rows) ---")
    print("Total rows in smart album: \(travelHighlightsAlbum.rowCount)")
    print(travelHighlightsAlbum.head(5))
}

// Call the function to execute the exercise
/*
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
do {
    try processImageMetadataForSmartAlbums()
} catch {
    print("Error during image metadata processing: \(error.localizedDescription)")
}
*/
