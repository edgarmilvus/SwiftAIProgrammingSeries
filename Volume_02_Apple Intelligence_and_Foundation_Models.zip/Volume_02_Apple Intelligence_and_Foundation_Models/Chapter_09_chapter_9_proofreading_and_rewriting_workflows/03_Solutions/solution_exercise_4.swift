
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import NaturalLanguage
import AppKit

// Ensure macOS 15.0 availability for NLWritingTool
@available(macOS 15.0, *)
class ProWriterEditorViewController: NSViewController, NSTextViewDelegate {

    let scrollView = NSScrollView()
    let documentTextView = NSTextView()
    let seoKeywordField = NSTextField()
    let applyButton = NSButton(title: "Apply Refinement", target: nil, action: nil)
    let presetSegmentedControl = NSSegmentedControl()
    let progressIndicator = NSProgressIndicator()

    private let writingTool = NLWritingTool()

    override func loadView() {
        // Set up the view controller's view
        self.view = NSView()
        self.view.wantsLayer = true // Needed for background color
        self.view.layer?.backgroundColor = NSColor.windowBackgroundColor.cgColor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupEditor()
        setupSidebarControls()
        documentTextView.delegate = self
        
        // Initial text for demonstration
        documentTextView.string = """
        The current market conditions indicate a significant downturn. This phenomenon is primarily attributable to a confluence of global economic factors and localized inflationary pressures. It is imperative that stakeholders comprehend the multifaceted nature of these challenges.

        Furthermore, the company's Q3 performance was suboptimal. A detailed analysis reveals that the decline in revenue was largely due to decreased consumer spending and intensified competition within the digital services sector. Management is currently formulating a comprehensive strategy to mitigate these adverse effects and foster sustainable growth.

        This report endeavors to elucidate the complexities of the present financial landscape and propose actionable recommendations for navigating the turbulent waters ahead.
        """
        
        // Initial state check for button
        textViewDidChangeSelection(Notification(name: NSTextView.didChangeSelectionNotification))
    }

    private func setupEditor() {
        // MARK: - NSTextView Setup
        scrollView.hasVerticalScroller = true
        scrollView.autohidesScrollers = true
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        documentTextView.minSize = NSSize(width: 0, height: scrollView.contentSize.height)
        documentTextView.maxSize = NSSize(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude)
        documentTextView.isVerticallyResizable = true
        documentTextView.isHorizontallyResizable = false
        documentTextView.autoresizingMask = [.width, .height]
        documentTextView.textContainer?.widthTracksTextView = true
        documentTextView.font = NSFont.systemFont(ofSize: 14)
        documentTextView.isRichText = false // Plain text for simplicity
        scrollView.documentView = documentTextView
        view.addSubview(scrollView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            scrollView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            scrollView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.6) // Takes 60% of width
        ])
    }

    private func setupSidebarControls() {
        let sidebar = NSStackView()
        sidebar.translatesAutoresizingMaskIntoConstraints = false
        sidebar.orientation = .vertical
        sidebar.alignment = .leading
        sidebar.spacing = 15
        view.addSubview(sidebar)

        NSLayoutConstraint.activate([
            sidebar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            sidebar.leadingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: 20),
            sidebar.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            sidebar.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])

        // MARK: - Presets Segmented Control
        presetSegmentedControl.segmentStyle = .texturedRounded
        presetSegmentedControl.segmentCount = 5
        presetSegmentedControl.setLabel("Make More Concise", forSegment: 0)
        presetSegmentedControl.setLabel("Expand for Detail", forSegment: 1)
        presetSegmentedControl.setLabel("Rewrite for SEO", forSegment: 2)
        presetSegmentedControl.setLabel("Active Voice", forSegment: 3)
        presetSegmentedControl.setLabel("Simplify Language", forSegment: 4)
        presetSegmentedControl.selectedSegment = 0 // Default selection
        presetSegmentedControl.target = self
        presetSegmentedControl.action = #selector(presetChanged)
        sidebar.addArrangedSubview(NSTextField(labelWithString: "Refinement Presets:"))
        sidebar.addArrangedSubview(presetSegmentedControl)

        // MARK: - SEO Keyword Field
        let seoLabel = NSTextField(labelWithString: "SEO Keywords (for 'Rewrite for SEO'):")
        seoKeywordField.placeholderString = "e.g., market downturn, economic factors"
        seoKeywordField.translatesAutoresizingMaskIntoConstraints = false
        seoKeywordField.widthAnchor.constraint(equalToConstant: 250).isActive = true
        seoKeywordField.isEnabled = false // Initially disabled
        sidebar.addArrangedSubview(seoLabel)
        sidebar.addArrangedSubview(seoKeywordField)

        // MARK: - Apply Button
        applyButton.target = self
        applyButton.action = #selector(applyRefinementPreset)
        applyButton.isEnabled = false // Initially disabled
        sidebar.addArrangedSubview(applyButton)
        
        // MARK: - Progress Indicator
        progressIndicator.style = .spinning
        progressIndicator.controlSize = .small
        progressIndicator.translatesAutoresizingMaskIntoConstraints = false
        progressIndicator.isDisplayedWhenStopped = false
        sidebar.addArrangedSubview(progressIndicator)
    }
    
    @objc private func presetChanged(_ sender: NSSegmentedControl) {
        // Enable/disable SEO keyword field based on selected preset
        seoKeywordField.isEnabled = sender.selectedSegment == 2 // "Rewrite for SEO" is segment 2
        // Also re-evaluate apply button state
        textViewDidChangeSelection(Notification(name: NSTextView.didChangeSelectionNotification))
    }

    // MARK: - NSTextViewDelegate

    func textViewDidChangeSelection(_ notification: Notification) {
        let selectedRange = documentTextView.selectedRange()
        let hasSelection = selectedRange.length > 0
        
        applyButton.isEnabled = hasSelection

        // If "Rewrite for SEO" is selected, ensure keyword field is enabled
        seoKeywordField.isEnabled = presetSegmentedControl.selectedSegment == 2 && hasSelection
    }

    // MARK: - Refinement Action

    @IBAction func applyRefinementPreset(_ sender: NSButton) {
        guard let selectedRange = documentTextView.selectedRanges.first?.rangeValue,
              selectedRange.length > 0,
              let selectedText = documentTextView.string(in: selectedRange) else {
            showAlert(title: "No Selection", message: "Please select text to apply refinement.")
            return
        }

        let presetIndex = presetSegmentedControl.selectedSegment
        let presetType = presetSegmentedControl.label(forSegment: presetIndex) ?? ""
        let keywords = (presetType == "Rewrite for SEO") ? seoKeywordField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines) : ""

        if presetType == "Rewrite for SEO" && keywords.isEmpty {
            showAlert(title: "Missing Keywords", message: "Please enter keywords for SEO rewriting.")
            return
        }

        // Disable UI and show progress
        applyButton.isEnabled = false
        presetSegmentedControl.isEnabled = false
        seoKeywordField.isEnabled = false
        progressIndicator.startAnimation(nil)

        Task { @MainActor in // @MainActor ensures UI updates are on main thread
            await performRefinement(for: selectedText, presetType: presetType, keywords: keywords, range: selectedRange)
            
            // Re-enable UI and stop progress
            progressIndicator.stopAnimation(nil)
            presetSegmentedControl.isEnabled = true
            seoKeywordField.isEnabled = presetSegmentedControl.selectedSegment == 2 // Re-enable if SEO preset is active
            applyButton.isEnabled = true // Re-enable based on selection
            textViewDidChangeSelection(Notification(name: NSTextView.didChangeSelectionNotification))
        }
    }

    private func performRefinement(for text: String, presetType: String, keywords: String, range: NSRange) async {
        do {
            var options = NLWritingTool.Options()
            let prompt: String
            let revisedText: String

            switch presetType {
            case "Make More Concise":
                prompt = "Rewrite the following text to be significantly more concise, removing redundant phrases and focusing on the core message, without losing essential information. Keep it professional."
                revisedText = try await writingTool.rewrite(text, options: options, prompt: prompt)
            case "Expand for Detail":
                prompt = "Expand upon the following text, adding more detail, examples, and elaborations to provide a comprehensive understanding of the topic. Ensure coherence and flow."
                revisedText = try await writingTool.rewrite(text, options: options, prompt: prompt)
            case "Rewrite for SEO":
                prompt = "Rewrite the following text to be highly optimized for search engines, naturally incorporating the keywords '\(keywords)' throughout the content. Ensure readability and relevance."
                revisedText = try await writingTool.rewrite(text, options: options, prompt: prompt)
            case "Active Voice":
                prompt = "Rewrite the following text, converting all passive voice constructions into active voice to make the writing more direct, engaging, and authoritative."
                revisedText = try await writingTool.rewrite(text, options: options, prompt: prompt)
            case "Simplify Language":
                prompt = "Simplify the language of the following text, replacing complex vocabulary and intricate sentence structures with simpler alternatives suitable for a broader audience, while retaining the original meaning."
                revisedText = try await writingTool.rewrite(text, options: options, prompt: prompt)
            default:
                // Fallback or error
                throw NSError(domain: "ProWriterError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Unknown refinement preset."])
            }

            // Present 'text' (original) and 'revisedText' side-by-side in a review UI.
            await presentReviewAndApplyWindow(original: text, revised: revisedText, range: range)

        } catch {
            print("Error applying refinement: \(error.localizedDescription)")
            showAlert(title: "Refinement Error", message: error.localizedDescription)
        }
    }

    private func presentReviewAndApplyWindow(original: String, revised: String, range: NSRange) async {
        let windowController = ReviewWindowController(originalText: original, revisedText: revised)
        
        // Present as a sheet
        guard let window = view.window else { return }
        window.beginSheet(windowController.window!) { response in
            if response == .OK {
                // User accepted changes
                self.documentTextView.textStorage?.replaceCharacters(in: range, with: revised)
                // Optionally, move cursor to end of replaced text
                let newLocation = range.location + revised.utf16.count
                self.documentTextView.setSelectedRange(NSRange(location: newLocation, length: 0))
            }
        }
    }
    
    private func showAlert(title: String, message: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = message
        alert.alertStyle = .warning
        alert.runModal()
    }
}

// MARK: - Review Window Controller (for side-by-side comparison)

@available(macOS 15.0, *)
class ReviewWindowController: NSWindowController {
    
    convenience init(originalText: String, revisedText: String) {
        let window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 800, height: 600),
            styleMask: [.titled, .closable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.center()
        window.title = "Review Changes"
        self.init(window: window)
        
        let viewController = ReviewViewController(originalText: originalText, revisedText: revisedText)
        window.contentViewController = viewController
    }
}

@available(macOS 15.0, *)
class ReviewViewController: NSViewController {
    let originalTextView = NSTextView()
    let revisedTextView = NSTextView()
    let originalText: String
    let revisedText: String
    
    init(originalText: String, revisedText: String) {
        self.originalText = originalText
        self.revisedText = revisedText
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func loadView() {
        let view = NSView()
        self.view = view
        
        let splitView = NSSplitView()
        splitView.translatesAutoresizingMaskIntoConstraints = false
        splitView.isVertical = true
        view.addSubview(splitView)
        
        // Original Text View
        let originalScrollView = NSScrollView()
        originalScrollView.hasVerticalScroller = true
        originalScrollView.documentView = originalTextView
        originalTextView.isEditable = false
        originalTextView.string = originalText
        originalTextView.font = NSFont.systemFont(ofSize: 13)
        originalTextView.textColor = .secondaryLabel
        originalTextView.textContainerInset = NSSize(width: 5, height: 5)
        
        // Revised Text View
        let revisedScrollView = NSScrollView()
        revisedScrollView.hasVerticalScroller = true
        revisedScrollView.documentView = revisedTextView
        revisedTextView.isEditable = false
        revisedTextView.string = revisedText
        revisedTextView.font = NSFont.systemFont(ofSize: 13, weight: .medium)
        revisedTextView.textContainerInset = NSSize(width: 5, height: 5)
        
        splitView.addArrangedSubview(originalScrollView)
        splitView.addArrangedSubview(revisedScrollView)
        
        // Buttons
        let applyButton = NSButton(title: "Accept Changes", target: self, action: #selector(acceptChanges))
        let cancelButton = NSButton(title: "Cancel", target: self, action: #selector(cancelChanges))
        
        let buttonStack = NSStackView(views: [cancelButton, applyButton])
        buttonStack.translatesAutoresizingMaskIntoConstraints = false
        buttonStack.spacing = 10
        view.addSubview(buttonStack)
        
        NSLayoutConstraint.activate([
            splitView.topAnchor.constraint(equalTo: view.topAnchor, constant: 10),
            splitView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            splitView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
            splitView.bottomAnchor.constraint(equalTo: buttonStack.topAnchor, constant: -10),
            
            buttonStack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            buttonStack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -10)
        ])
    }
    
    @objc private func acceptChanges() {
        self.view.window?.sheetParent?.endSheet(self.view.window!, returnCode: .OK)
    }
    
    @objc private func cancelChanges() {
        self.view.window?.sheetParent?.endSheet(self.view.window!, returnCode: .cancel)
    }
}
