
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import CreateML
import Foundation

// Ensure CreateML APIs are available for the target platforms.
// CreateML is generally available from macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0.
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
/// Manages the training and prediction logic for the HomeSense energy predictor.
class HomeSenseEnergyPredictor {

    /// The trained MLLinearRegressor model. This property holds the model after successful training.
    private var energyPredictorModel: MLLinearRegressor?

    /// Trains a new MLLinearRegressor model using provided historical energy data.
    ///
    /// This function takes raw data, converts it into an `MLDataTable`, splits it into
    /// training and testing sets, and then trains the linear regression model.
    /// After training, it evaluates the model's performance on the testing data.
    ///
    /// - Parameters:
    ///   - data: A dictionary representing the dataset. Each key is a column name, and its value
    ///           is an array of `MLDataValue` representing the column's data. This simulates
    ///           data loaded from a CSV, JSON, or a database.
    ///   - targetColumn: The name of the column to predict (e.g., "EnergyConsumptionKWH").
    ///   - featureColumns: An array of column names to use as input features for prediction.
    /// - Throws: An `Error` if data processing or model training fails.
    func trainEnergyPredictor(data: [String: [MLDataValue]], targetColumn: String, featureColumns: [String]) throws {
        // 1. Create an MLDataTable from the dictionary.
        // MLDataTable is the primary data structure used by CreateML for model training.
        // It's similar to a spreadsheet or a database table.
        let dataTable = try MLDataTable(dictionary: data)

        // 2. Split the data into training and testing sets.
        // It's crucial to evaluate the model's performance on unseen data.
        // We use 80% for training and 20% for testing. 'seed' ensures reproducibility.
        let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 0)

        // 3. Initialize and train the MLLinearRegressor model.
        // We specify the 'trainingData', the 'targetColumn' (what we want to predict),
        // and the 'featureColumns' (the inputs used to make the prediction).
        print("Training MLLinearRegressor for target: '\(targetColumn)' with features: \(featureColumns)...")
        self.energyPredictorModel = try MLLinearRegressor(trainingData: trainingData,
                                                          targetColumn: targetColumn,
                                                          featureColumns: featureColumns)
        print("Model training complete.")

        // 4. Evaluate the model's performance on the testing data.
        // This step helps understand how well the model generalizes to new, unseen data.
        // For regression, common metrics include Root Mean Squared Error (RMSE) and Maximum Error.
        let metrics = self.energyPredictorModel?.evaluation(on: testingData, targetColumn: targetColumn)
        if let metrics = metrics {
            print("\nModel Evaluation Metrics:")
            print("Root Mean Squared Error (RMSE): \(String(format: "%.4f", metrics.rootMeanSquaredError))")
            print("Maximum Error: \(String(format: "%.4f", metrics.maximumError))")
            // Other metrics like R-squared can be accessed if needed via metrics.rSquared.
            // A lower RMSE indicates better fit; a lower Maximum Error indicates fewer large prediction errors.
        }
    }

    /// Predicts energy consumption for a new set of input features.
    ///
    /// This function takes a dictionary of features for a single instance, converts it
    /// into an `MLDataTable`, and then uses the trained model to make a prediction.
    ///
    /// - Parameters:
    ///   - features: A dictionary representing the input features for a single prediction.
    ///               Keys are feature column names, values are `MLDataValue`.
    /// - Returns: The predicted energy consumption as a `Double`, or `nil` if prediction fails or model is not trained.
    /// - Throws: An `Error` if the input features are invalid or prediction fails.
    func predictEnergyConsumption(features: [String: MLDataValue]) throws -> Double? {
        // Ensure the model has been trained before attempting to predict.
        guard let model = energyPredictorModel else {
            print("Error: Model not trained. Please train the model first.")
            return nil
        }

        // 1. Create an MLDataTable for the prediction input.
        // Even for a single prediction, CreateML expects an MLDataTable as input.
        // We transform the single-row dictionary into a format MLDataTable can consume.
        var predictionDataDict: [String: [MLDataValue]] = [:]
        for (key, value) in features {
            predictionDataDict[key] = [value] // Each feature becomes a column with a single value.
        }
        let predictionTable = try MLDataTable(dictionary: predictionDataDict)

        // 2. Make a prediction using the trained model.
        // The predictions method returns an MLDataTable containing the predicted values.
        let predictions = try model.predictions(from: predictionTable)

        // 3. Extract the predicted value.
        // For a single prediction, we expect one row in the predictions table.
        // The predicted value is found in the column named after the original target column.
        if let firstPrediction = predictions.rows.first,
           let predictedValue = firstPrediction[model.targetColumnName]?.doubleValue {
            return predictedValue
        } else {
            print("Error: Could not extract prediction from model output. Check target column name or data format.")
            return nil
        }
    }
}

// MARK: - Example Usage in an iOS/macOS App Context

// This class simulates a ViewModel that would interact with the UI in a real app.
// @MainActor ensures that any UI-related operations (though not explicit here) would
// be performed on the main thread, preventing common concurrency issues.
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
@MainActor
class HomeSenseAppViewModel: ObservableObject {

    private let predictor = HomeSenseEnergyPredictor()

    // Sample historical data for training.
    // In a real application, this data would typically be loaded from a persistent store
    // (e.g., Core Data, Realm, a backend API, or a local CSV file).
    private let historicalEnergyData: [String: [MLDataValue]] = [
        "OutsideTemperatureCelsius": [20.0, 22.0, 18.0, 25.0, 15.0, 21.0, 19.0, 23.0, 17.0, 20.0, 24.0, 16.0],
        "NumberOfOccupants": [2.0, 3.0, 2.0, 4.0, 1.0, 3.0, 2.0, 3.0, 2.0, 2.0, 4.0, 1.0],
        "DaylightHours": [14.0, 14.5, 13.0, 15.0, 12.0, 14.2, 13.5, 14.8, 12.5, 13.8, 15.2, 12.2],
        "EnergyConsumptionKWH": [15.5, 18.2, 14.0, 20.1, 12.8, 17.5, 14.9, 19.0, 13.5, 16.0, 21.0, 13.0] // Target column
    ]

    /// Simulates training the energy predictor model when the app launches or data updates.
    /// This operation is asynchronous as model training can be time-consuming.
    func setupAndTrainModel() {
        Task { // Use a Task to perform asynchronous work off the main thread.
            do {
                print("\n--- Starting Model Setup and Training ---")
                try predictor.trainEnergyPredictor(
                    data: historicalEnergyData,
                    targetColumn: "EnergyConsumptionKWH",
                    featureColumns: ["OutsideTemperatureCelsius", "NumberOfOccupants", "DaylightHours"]
                )
                print("--- Model Setup and Training Complete ---")
            } catch {
                print("Failed to train model: \(error.localizedDescription)")
            }
        }
    }

    /// Simulates making a prediction based on current conditions provided by sensors or user input.
    /// This operation is also asynchronous.
    func makeSamplePrediction() {
        Task {
            do {
                print("\n--- Making a Sample Prediction ---")
                let currentConditions: [String: MLDataValue] = [
                    "OutsideTemperatureCelsius": 21.5,
                    "NumberOfOccupants": 3.0,
                    "DaylightHours": 14.3
                ]
                if let predictedConsumption = try predictor.predictEnergyConsumption(features: currentConditions) {
                    print("Predicted Energy Consumption for today: \(String(format: "%.2f", predictedConsumption)) KWH")
                }
                print("--- Sample Prediction Complete ---")
            } catch {
                print("Failed to make prediction: \(error.localizedDescription)")
            }
        }
    }
}

// To run this example in a Playground or a simple command-line tool:
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
func runExample() {
    let viewModel = HomeSenseAppViewModel()
    viewModel.setupAndTrainModel()

    // In a real app, you'd use completion handlers, Combine publishers, or AsyncStream
    // to ensure prediction happens only after training is complete.
    // For this simple example, we introduce a delay.
    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
        viewModel.makeSamplePrediction()
    }
}

// Call the example function to execute.
// In a real app, this would be called from your AppDelegate or SceneDelegate's
// application(_:didFinishLaunchingWithOptions:) or scene(_:willConnectTo:options:).
if #available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *) {
    runExample()
} else {
    print("CreateML is not available on this OS version.")
}
