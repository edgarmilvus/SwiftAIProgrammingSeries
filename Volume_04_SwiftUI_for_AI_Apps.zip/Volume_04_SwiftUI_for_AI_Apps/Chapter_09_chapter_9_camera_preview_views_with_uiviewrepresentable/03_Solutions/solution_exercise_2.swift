
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import AVFoundation
import UIKit // Required for UIApplication.shared.open

@available(iOS 18.0, *)
struct CameraAccessView: View {
    @State private var cameraAuthorizationStatus: AVAuthorizationStatus = .notDetermined
    @State private var setupError: String? // To display errors during session setup

    var body: some View {
        Group {
            switch cameraAuthorizationStatus {
            case .authorized:
                // If authorized, display the CameraPreview from Exercise 1
                // We'll pass a binding to setupError to allow CameraPreview to report issues
                CameraPreviewWithErrorReporting(setupError: $setupError)
                    .overlay(
                        // Display setup errors on top of the preview if they occur
                        Group {
                            if let error = setupError {
                                Text("Camera Error: \(error)")
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.red.opacity(0.8))
                                    .cornerRadius(10)
                            }
                        }
                    )
            case .notDetermined:
                VStack {
                    ProgressView()
                    Text("Requesting Camera Access...")
                }
                .onAppear(perform: requestCameraPermission)
            case .denied, .restricted:
                VStack(spacing: 20) {
                    Image(systemName: "video.slash.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 80)
                        .foregroundColor(.gray)
                    Text("Camera access is required to use this feature.")
                        .font(.headline)
                        .multilineTextAlignment(.center)
                    Text("Please enable camera access in your device settings.")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)

                    Button("Open Settings") {
                        // Attempt to open the app's settings page
                        if let url = URL(string: UIApplication.openSettingsURLString) {
                            UIApplication.shared.open(url, options: [:], completionHandler: nil)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding()
            @unknown default:
                Text("Unknown camera authorization status.")
            }
        }
        .onAppear(perform: checkCameraPermissionStatus)
        // Observe when the app becomes active to re-check permissions,
        // in case the user changed them from settings while the app was in background.
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
            checkCameraPermissionStatus()
        }
    }

    // MARK: - Permission Handling

    private func checkCameraPermissionStatus() {
        DispatchQueue.main.async { // Ensure UI updates are on main thread
            self.cameraAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: .video)
        }
    }

    private func requestCameraPermission() {
        AVCaptureDevice.requestAccess(for: .video) { granted in
            // The completion handler is called on an arbitrary queue,
            // so dispatch UI updates back to the main thread.
            DispatchQueue.main.async {
                self.cameraAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: .video)
            }
        }
    }
}

// MARK: - Modified CameraPreview to report setup errors (for Exercise 2)

@available(iOS 18.0, *)
struct CameraPreviewWithErrorReporting: UIViewRepresentable {
    @Binding var setupError: String?
    private let session = AVCaptureSession()
    private var previewLayer: AVCaptureVideoPreviewLayer?

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        view.backgroundColor = .black

        DispatchQueue.global(qos: .userInitiated).async {
            self.setupSession(for: view)
        }

        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        if let layer = previewLayer {
            layer.frame = uiView.bounds
        }
    }

    private func setupSession(for view: UIView) {
        session.beginConfiguration()
        defer { session.commitConfiguration() }

        for input in session.inputs {
            session.removeInput(input)
        }

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            DispatchQueue.main.async { self.setupError = "No back camera available." }
            return
        }

        guard let videoDeviceInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            DispatchQueue.main.async { self.setupError = "Could not create camera input." }
            return
        }

        if session.canAddInput(videoDeviceInput) {
            session.addInput(videoDeviceInput)
        } else {
            DispatchQueue.main.async { self.setupError = "Could not add camera input to session." }
            return
        }

        let layer = AVCaptureVideoPreviewLayer(session: session)
        layer.videoGravity = .resizeAspectFill
        layer.frame = view.bounds

        DispatchQueue.main.async {
            self.previewLayer = layer
            view.layer.addSublayer(layer)
            self.setupError = nil // Clear any previous errors if setup succeeds
        }
    }

    func startSession() {
        DispatchQueue.global(qos: .userInitiated).async {
            if !self.session.isRunning {
                self.session.startRunning()
                print("AVCaptureSession started for CameraPreviewWithErrorReporting.")
            }
        }
    }

    func stopSession() {
        DispatchQueue.global(qos: .userInitiated).async {
            if self.session.isRunning {
                self.session.stopRunning()
                print("AVCaptureSession stopped for CameraPreviewWithErrorReporting.")
            }
        }
    }
}

// MARK: - SwiftUI Wrapper for Exercise 2

@available(iOS 18.0, *)
struct Exercise2WrapperView: View {
    var body: some View {
        CameraAccessView()
            .ignoresSafeArea()
    }
}
