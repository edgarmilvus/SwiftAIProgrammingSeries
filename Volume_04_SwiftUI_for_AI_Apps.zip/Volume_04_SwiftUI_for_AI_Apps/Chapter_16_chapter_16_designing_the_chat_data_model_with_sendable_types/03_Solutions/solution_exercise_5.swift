
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import os.lock // For demonstrating manual locking if needed, though not strictly part of the @unchecked Sendable contract.

// 1. Simulate a third-party, non-Sendable class
final class RichContentData {
    var contentString: String
    var internalState: [Int] // Mutable, not thread-safe without external synchronization
    
    init(contentString: String) {
        self.contentString = contentString
        self.internalState = []
        print("RichContentData: Initialized with content '\(contentString)'")
    }
    
    func updateState(value: Int) {
        internalState.append(value)
        print("RichContentData: State updated to \(internalState)")
    }
    
    func getCurrentContent() -> String {
        return "Content: \(contentString), state count: \(internalState.count)"
    }
    
    // This class is NOT Sendable because:
    // 1. It's a class (reference type), meaning multiple references can point to the same instance.
    // 2. It has mutable state (`contentString`, `internalState`) that is not protected by any internal synchronization mechanism.
    // 3. It does not explicitly conform to Sendable, and the compiler cannot infer it for classes without specific guarantees.
}

// 2. Design a SendableRichContentWrapper struct
struct SendableRichContentWrapper: @unchecked Sendable {
    // This wrapper holds a reference to the non-Sendable RichContentData instance.
    // By marking it @unchecked Sendable, we are telling the compiler:
    // "Trust me, I guarantee that any access to `richContent` through this wrapper
    // will be performed in a thread-safe manner, even though `RichContentData` itself is not Sendable."
    private let richContent: RichContentData
    
    // A lock to manually synchronize access to richContent.
    // This is the developer's responsibility when using @unchecked Sendable for mutable types.
    private let accessLock = OSAllocatedUnfairLock()

    init(richContent: RichContentData) {
        self.richContent = richContent
    }
    
    // Safe way to access the RichContentData's content (immutable access)
    func getContent() -> String {
        return accessLock.withLock {
            richContent.getCurrentContent()
        }
    }
    
    // Safe way to manipulate the RichContentData (mutable access)
    func updateRichContentState(value: Int) {
        accessLock.withLock {
            richContent.updateState(value: value)
        }
    }
    
    // If you need to expose the underlying non-Sendable object for specific actor-isolated operations,
    // you might provide a method to get it, but then the caller must ensure isolation.
    // This is generally discouraged for @unchecked Sendable types unless strictly necessary and carefully managed.
    // func getUnderlyingRichContent() -> RichContentData {
    //     return richContent // This would bypass the lock, making it unsafe if used concurrently
    // }
}

// Re-using Attachment enum from Exercise 2, now with a new case
enum Attachment: Sendable {
    case image(url: URL, thumbnailData: Data?)
    case video(url: URL, previewImageURL: URL?)
    case file(url: URL, filename: String, fileSize: Int)
    case richContent(SendableRichContentWrapper) // New case
    
    // Attachment remains Sendable because SendableRichContentWrapper is marked @unchecked Sendable,
    // and all other associated values are Sendable.
}

// Re-using ChatMessage (from Ex1, Ex2, Ex3)
struct ChatMessage: Identifiable, Sendable {
    let id: UUID
    let sender: User
    let content: String
    let timestamp: Date
    let attachment: Attachment? // Now can include rich content
}

// Example Usage in an Actor context
actor ContentProcessor {
    private var processedMessages: [ChatMessage] = []
    
    func processRichMessage(_ message: ChatMessage) {
        guard case .richContent(let wrapper) = message.attachment else {
            print("ContentProcessor: Message \(message.id) does not have rich content attachment.")
            return
        }
        
        // Accessing the rich content through the wrapper's synchronized methods
        let currentContent = wrapper.getContent()
        print("ContentProcessor: Processing rich content for message \(message.id). Initial: \(currentContent)")
        
        // Simulate an update
        wrapper.updateRichContentState(value: 100)
        let updatedContent = wrapper.getContent()
        print("ContentProcessor: Updated rich content for message \(message.id). Final: \(updatedContent)")
        
        processedMessages.append(message)
    }
    
    func getProcessedMessages() -> [ChatMessage] {
        return processedMessages
    }
}

// Demonstration
func demonstrateUncheckedSendable() async {
    let legacyRichData = RichContentData(contentString: "Important document details")
    
    // Create the Sendable wrapper
    let sendableWrapper = SendableRichContentWrapper(richContent: legacyRichData)
    
    let user = User(id: UUID(), name: "Charlie", avatarURL: nil)
    let richMessage = ChatMessage(
        id: UUID(),
        sender: user,
        content: "Please review the rich content.",
        timestamp: Date(),
        attachment: .richContent(sendableWrapper)
    )
    
    let processor = ContentProcessor()
    
    // Pass the richMessage (containing the @unchecked Sendable wrapper) to the actor.
    // The compiler allows this because SendableRichContentWrapper claims Sendable conformance.
    await processor.processRichMessage(richMessage)
    
    // Demonstrate concurrent access attempt (will be synchronized by the wrapper's lock)
    let anotherProcessor = ContentProcessor()
    
    // These two tasks will try to update the *same* underlying `legacyRichData` instance
    // through their respective `sendableWrapper` copies.
    // The `accessLock` inside `SendableRichContentWrapper` is critical here.
    async let task1 = Task {
        print("\nTask 1 starting update...")
        await anotherProcessor.processRichMessage(richMessage)
        print("Task 1 finished update.")
    }
    
    async let task2 = Task {
        print("Task 2 starting update...")
        await processor.processRichMessage(richMessage)
        print("Task 2 finished update.")
    }
    
    _ = await [task1.value, task2.value]
    
    print("\n--- Final state of original legacyRichData ---")
    print(legacyRichData.getCurrentContent()) // This shows the combined effect of updates
}

// Call to demonstrate
// Task { await demonstrateUncheckedSendable() }
