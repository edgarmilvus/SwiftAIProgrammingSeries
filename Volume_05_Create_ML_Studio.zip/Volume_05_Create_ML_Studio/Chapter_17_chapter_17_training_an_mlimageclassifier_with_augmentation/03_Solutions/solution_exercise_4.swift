
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

// MARK: - Gesture Definition & Data Collection Strategy Outline
/*
This section outlines the conceptual strategy for defining gestures and collecting data.
It is not executable code but crucial for the overall solution.

1.  **Gesture Definition:**
    *   Define 3-5 distinct, simple hand gestures:
        *   "Open Hand": Palm facing camera, fingers splayed.
        *   "Closed Fist": Fist facing camera.
        *   "Thumb Up": Thumb extended, other fingers curled.
        *   "Point": Index finger extended, other fingers curled.
        *   "Peace Sign": Index and middle fingers extended.
    *   Ensure gestures are visually distinct and can be performed easily by diverse users.

2.  **Data Collection Strategy:**
    *   **Video Capture:** Record short video clips (5-10 seconds) for each gesture. This is more efficient than individual photos.
    *   **User Variation:**
        *   Recruit diverse participants: varying skin tones, hand sizes, ages, genders.
        *   Instruct users to perform each gesture multiple times, with slight variations.
    *   **Environmental Variation:**
        *   **Lighting:** Record in bright sunlight, dim rooms, under fluorescent lights, with backlighting, and mixed lighting.
        *   **Backgrounds:** Record against plain walls, cluttered bookshelves, outdoor scenes, different colored surfaces.
    *   **Pose Variation:**
        *   **Rotation:** Users should rotate their hand slightly (e.g., -45 to +45 degrees yaw, pitch, roll).
        *   **Distance:** Vary distance from camera (e.g., arm's length, closer for larger view).
        *   **Partial Views:** Simulate partial occlusions by having users move their hand partially out of frame or behind a translucent object.
    *   **Video Frame Extraction:**
        *   From each video clip, extract frames at a rate of 5-10 frames per second (or more if movement is fast).
        *   Manually review and label extracted frames, ensuring accurate categorization. Discard blurry or poorly framed images.
    *   **Data Augmentation (Pre-processing):** Before feeding to Create ML, consider:
        *   **Occlusion Simulation:** Programmatically overlay semi-transparent shapes or small random images onto parts of the hand to simulate partial occlusions. This is hard to do reliably with Create ML's built-in options.
        *   **Background Replacement:** If hands are segmented, place them on synthetic backgrounds.
*/

// MARK: - Create ML Training (macOS Command Line Tool or Playground)
// This code runs on macOS for training the model.

import CreateML
import Foundation

// IMPORTANT: Replace these URLs with actual paths to your dataset.
let gestureTrainingDataURL = URL(fileURLWithPath: "/path/to/your/gestureTrainingDataDirectory")
let gestureValidationDataURL = URL(fileURLWithPath: "/path/to/your/gestureValidationDataDirectory")
let gestureOutputModelURL = URL(fileURLWithPath: "/path/to/save/GestureClassifier.mlmodel")

@available(macOS 14.0, *)
func trainGestureClassifier() async {
    print("Starting gesture classifier training...")
    do {
        let trainingData = try MLImageClassifier.DataSource.labeledDirectories(at: gestureTrainingDataURL)
        let validationData = try MLImageClassifier.DataSource.labeledDirectories(at: gestureValidationDataURL)

        // Domain-Specific Augmentation Pipeline for Gestures
        let builder = MLImageClassifier.Builder(trainingData: trainingData)
            .validationData(validationData)
            .maxEpochs(100) // More epochs for complex, varied data
            .batchSize(32)
            .learningRate(0.00005) // Very low learning rate for fine-tuning a robust base model
            .augmentationOptions([
                // Aggressive Geometric Augmentation
                .rotation(minimumAngle: -45, maximumAngle: 45), // Wide range for hand rotations
                .horizontalFlip, // Hands can be left/right, mirrored
                .verticalFlip,   // Hands might be inverted for some gestures
                .crop(minimumScale: 0.5, maximumScale: 1.0), // Simulate varying distances, partial views
                .scale(minimum: 0.6, maximum: 1.4), // Aggressive scaling
                .translation(minimum: -0.3, maximum: 0.3), // Shift hand around frame

                // Significant Color Jitter for diverse lighting/camera settings
                .color(hue: 0.2, saturation: 0.5, brightness: 0.4, contrast: 0.4),

                // Noise and Blur for real-world camera artifacts
                .gaussianNoise(standardDeviation: 0.1), // Realistic camera sensor noise
                .blur(radius: 2.0), // Simulate motion blur, out-of-focus
            ])
            .baseModel(.efficientNetB0) // Use a powerful base model for challenging tasks
            // .baseModel(.resnet50) // Another strong option

        print("Training gesture classifier...")
        let model = try builder.train()
        print("Model training complete.")

        // Model Robustness & Evaluation:
        // Beyond accuracy, analyze precision, recall, and F1-score per gesture.
        // Crucially, evaluate false positive/negative rates:
        // - False Positives: Model predicts a gesture when none is intended or a different one. (Annoying for accessibility)
        // - False Negatives: Model misses an intended gesture. (Frustrating for accessibility)
        // Strategies for class imbalance:
        // - Oversampling minority classes (duplicate images, or generate more synthetic data).
        // - Undersampling majority classes (remove images, but risk losing diversity).
        // - Using weighted loss functions during training (Create ML doesn't expose this directly,
        //   but it's a common technique in other ML frameworks).
        // - Focus on collecting more data for underrepresented gestures.

        let metadata = MLModelMetadata(
            author: "Your Name",
            shortDescription: "Real-time hand gesture recognizer for accessibility",
            version: "1.0",
            license: "MIT",
            additional: nil
        )
        try model.write(to: gestureOutputModelURL, metadata: metadata)
        print("Gesture classifier model saved to: \(gestureOutputModelURL.path)")

    } catch {
        print("Error during gesture classifier training: \(error.localizedDescription)")
    }
}

// MARK: - Real-time iOS Integration (SwiftUI with AVCaptureSession)
// This code would be part of an iOS SwiftUI application.

import SwiftUI
import AVFoundation
import Vision
import CoreML

enum GestureClassifierError: Error, LocalizedError {
    case cameraAccessDenied
    case modelLoadingFailed(String)
    case classificationError(String)

    var errorDescription: String? {
        switch self {
        case .cameraAccessDenied: return "Camera access denied. Please enable in Settings."
        case .modelLoadingFailed(let reason): return "Failed to load ML model: \(reason)"
        case .classificationError(let reason): return "Gesture classification error: \(reason)"
        }
    }
}

@MainActor
class CameraViewModel: NSObject, ObservableObject {
    @Published var recognizedGesture: String = "Detecting..."
    @Published var confidence: Float = 0.0
    @Published var cameraError: GestureClassifierError?

    var previewLayer: AVCaptureVideoPreviewLayer!
    private let captureSession = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let videoOutputQueue = DispatchQueue(label: "videoOutputQueue", qos: .userInitiated)

    private var visionModel: VNCoreMLModel?

    override init() {
        super.init()
        loadModel()
    }

    private func loadModel() {
        do {
            guard let modelURL = Bundle.main.url(forResource: "GestureClassifier", withExtension: "mlmodelc") else {
                throw GestureClassifierError.modelLoadingFailed("Model file not found.")
            }
            let coreMLModel = try MLModel(contentsOf: modelURL)
            self.visionModel = try VNCoreMLModel(for: coreMLModel)
        } catch {
            self.cameraError = GestureClassifierError.modelLoadingFailed(error.localizedDescription)
            print("Failed to load Core ML model: \(error.localizedDescription)")
        }
    }

    func setupCamera() {
        guard cameraError == nil else { return } // Don't proceed if model failed to load

        // Request camera access
        AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
            guard let self = self else { return }
            if granted {
                DispatchQueue.main.async {
                    self._setupCameraSession()
                }
            } else {
                DispatchQueue.main.async {
                    self.cameraError = .cameraAccessDenied
                }
            }
        }
    }

    private func _setupCameraSession() {
        captureSession.beginConfiguration()
        captureSession.sessionPreset = .vga640x480 // Good balance for performance and quality

        // Add input (front camera)
        guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front),
              let input = try? AVCaptureDeviceInput(device: camera) else {
            self.cameraError = .classificationError("Could not access front camera.")
            captureSession.commitConfiguration()
            return
        }
        if captureSession.canAddInput(input) {
            captureSession.addInput(input)
        } else {
            self.cameraError = .classificationError("Could not add camera input.")
            captureSession.commitConfiguration()
            return
        }

        // Add output (video frames for Vision)
        videoOutput.setSampleBufferDelegate(self, queue: videoOutputQueue)
        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        } else {
            self.cameraError = .classificationError("Could not add video output.")
            captureSession.commitConfiguration()
            return
        }

        // Ensure video orientation matches device orientation for Vision processing
        videoOutput.connection(with: .video)?.videoOrientation = .portrait // Assuming portrait UI
        videoOutput.connection(with: .video)?.isVideoMirrored = (camera.position == .front) // Mirror front camera

        captureSession.commitConfiguration()
        captureSession.startRunning()
    }

    func stopCamera() {
        captureSession.stopRunning()
    }
}

// MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
extension CameraViewModel: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer),
              let visionModel = visionModel else { return }

        let request = VNCoreMLRequest(model: visionModel) { [weak self] request, error in
            guard let self = self else { return }
            if let error = error {
                DispatchQueue.main.async {
                    self.cameraError = .classificationError(error.localizedDescription)
                    self.recognizedGesture = "Error"
                    self.confidence = 0.0
                }
                return
            }

            guard let results = request.results as? [VNClassificationObservation],
                  let topResult = results.first else {
                DispatchQueue.main.async {
                    self.recognizedGesture = "No Gesture"
                    self.confidence = 0.0
                }
                return
            }

            // Update UI on the main thread
            DispatchQueue.main.async {
                self.recognizedGesture = topResult.identifier
                self.confidence = topResult.confidence
            }
        }

        // Optimize Vision request for performance
        request.imageCropAndScaleOption = .centerCrop // Or .scaleFill, etc., match training
        // You can also specify the region of interest if you have a hand detection model first

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        do {
            try handler.perform([request])
        } catch {
            DispatchQueue.main.async {
                self.cameraError = .classificationError(error.localizedDescription)
                self.recognizedGesture = "Error"
                self.confidence = 0.0
            }
        }
    }
}

// MARK: - SwiftUI View for Camera Feed
struct CameraPreviewView: UIViewRepresentable {
    @ObservedObject var viewModel: CameraViewModel

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        viewModel.previewLayer = AVCaptureVideoPreviewLayer(session: viewModel.captureSession)
        viewModel.previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(viewModel.previewLayer)
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        viewModel.previewLayer.frame = uiView.bounds
    }
}

struct RealTimeGestureView: View {
    @StateObject private var viewModel = CameraViewModel()

    var body: some View {
        ZStack {
            // Camera feed
            CameraPreviewView(viewModel: viewModel)
                .ignoresSafeArea()

            VStack {
                Spacer()
                Text(viewModel.recognizedGesture)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .shadow(radius: 5)
                    .padding(.bottom, 5)
                Text(String(format: "Confidence: %.2f%%", viewModel.confidence * 100))
                    .font(.title2)
                    .foregroundColor(.white)
                    .shadow(radius: 5)
                    .padding(.bottom, 20)
            }
            .padding()

            if let error = viewModel.cameraError {
                VStack {
                    Text("Error: \(error.localizedDescription)")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.red.opacity(0.8))
                        .cornerRadius(10)
                    Button("Open Settings") {
                        if let url = URL(string: UIApplication.openSettingsURLString) {
                            UIApplication.shared.open(url)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                }
                .padding()
            }
        }
        .onAppear {
            viewModel.setupCamera()
        }
        .onDisappear {
            viewModel.stopCamera()
        }
    }
}

// To use in an iOS app:
// @main
// struct GestureRecognizerApp: App {
//     var body: some Scene {
//         WindowGroup {
//             RealTimeGestureView()
//         }
//     }
// }
