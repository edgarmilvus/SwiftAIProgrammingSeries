
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import UIKit
import Foundation // For TextRange

// Assume AIModel and WritingTools are available from previous chapters
// For demonstration, we'll use a placeholder AI model.
@available(iOS 18.0, *)
actor AIModel {
    func rephrase(text: String) async throws -> String {
        // Simulate an asynchronous AI operation
        try await Task.sleep(for: .seconds(1.5))
        print("AI: Rephrasing '\(text)'")
        return "Rephrased version of: \(text)"
    }

    func summarize(text: String) async throws -> String {
        try await Task.sleep(for: .seconds(2.0))
        print("AI: Summarizing '\(text)'")
        return "Summary of: \(text)"
    }
}

@available(iOS 18.0, *)
class IntelligentTextViewController: UIViewController, UITextViewDelegate {

    let textView = UITextView()
    let aiModel = AIModel() // Instance of our AI model actor

    override func viewDidLoad() {
        super.viewDidLoad()
        setupTextView()
    }

    func setupTextView() {
        textView.delegate = self
        textView.font = .preferredFont(forTextStyle: .body)
        textView.text = "The quick brown fox jumps over the lazy dog. This is a sample paragraph to demonstrate custom AI text actions."
        textView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textView)

        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }

    // MARK: - UITextViewDelegate for Custom AI Actions

    func textView(_ textView: UITextView, editMenuForTextRange textRange: UITextRange, suggestedActions actions: [UIMenuElement]) -> UIMenu? {

        guard let selectedText = textView.text(in: textRange), !selectedText.isEmpty else {
            return nil // No selection or empty selection, no custom actions
        }

        var customActions: [UIMenuElement] = []

        // 1. Rephrase Action
        let rephraseAction = UIAction(title: "Rephrase (AI)", image: UIImage(systemName: "arrow.triangle.2.circlepath")) { [weak self] _ in
            guard let self = self else { return }
            Task { @MainActor in // Ensure UI updates are on MainActor
                do {
                    // Call the AI model asynchronously
                    let rephrasedText = try await self.aiModel.rephrase(text: selectedText)
                    // Update the UITextView with the AI's result
                    if let currentSelectedRange = textView.selectedTextRange {
                        textView.replace(currentSelectedRange, withText: rephrasedText)
                    }
                } catch {
                    print("Error rephrasing text: \(error)")
                    // Present an alert to the user or log the error
                }
            }
        }
        customActions.append(rephraseAction)

        // 2. Summarize Action (only for longer texts)
        if selectedText.count > 50 { // Simple heuristic for summarization
            let summarizeAction = UIAction(title: "Summarize (AI)", image: UIImage(systemName: "text.alignleft")) { [weak self] _ in
                guard let self = self else { return }
                Task { @MainActor in
                    do {
                        let summarizedText = try await self.aiModel.summarize(text: selectedText)
                        // Replace the entire selection with the summary
                        if let currentSelectedRange = textView.selectedTextRange {
                            textView.replace(currentSelectedRange, withText: summarizedText)
                        }
                    } catch {
                        print("Error summarizing text: \(error)")
                    }
                }
            }
            customActions.append(summarizeAction)
        }

        // Group custom actions with system actions or create a new menu
        // For simplicity, we'll prepend our custom actions to the suggested ones.
        // A more complex scenario might involve UIMenu to categorize.
        let combinedActions = customActions + actions
        return UIMenu(children: combinedActions)
    }
}
