
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CreateML

// Define a global actor for managing MLDataTable operations
// This ensures all data processing happens in an isolated, serial context.
@globalActor actor DataProcessingActor {
    static let shared = DataProcessingActor()
}

@available(macOS 12.0, iOS 15.0, tvOS 15.0, watchOS 8.0, *)
@DataProcessingActor
class MLDataPipeline {
    private var currentDataTable: MLDataTable?

    func loadData(from url: URL) async throws {
        // Simulate I/O bound operation
        try await Task.sleep(for: .seconds(1))
        currentDataTable = try await MLDataTable(contentsOf: url)
        print("Data loaded on DataProcessingActor. Rows: \(currentDataTable?.rows.count ?? 0)")
    }

    func applyTransformation() async throws {
        guard let table = currentDataTable else {
            throw NSError(domain: "MLDataPipeline", code: 1, userInfo: [NSLocalizedDescriptionKey: "No data loaded."])
        }
        // Simulate a computationally intensive transformation
        try await Task.sleep(for: .seconds(0.5))

        // Example: Add a new column
        let transformedTable = try await table.mapColumns { (column: MLDataColumn<String>) -> String in
            return column.map { $0.uppercased() }
        } named: "UPPERCASE_TEXT"
        currentDataTable = transformedTable
        print("Transformation applied on DataProcessingActor. New column added.")
    }

    func getDataTable() -> MLDataTable? {
        // Since MLDataTable is a struct (value type), returning a copy is safe.
        // No need for 'nonisolated' as the actor is accessed directly.
        return currentDataTable
    }
}

// Usage example:
@available(macOS 12.0, iOS 15.0, tvOS 15.0, watchOS 8.0, *)
func runDataPipeline() async {
    let pipeline = DataProcessingActor.shared // Access the shared actor instance

    // Assume `jsonURL` points to a valid JSON file
    guard let jsonURL = Bundle.main.url(forResource: "another_data", withExtension: "json") else {
        print("JSON file not found.")
        return
    }

    do {
        print("Starting data pipeline...")
        await pipeline.loadData(from: jsonURL) // Call actor method
        await pipeline.applyTransformation() // Call another actor method

        if let finalTable = await pipeline.getDataTable() { // Access data from actor
            print("Final table columns: \(finalTable.columnNames)")
        }
    } catch {
        print("Pipeline error: \(error)")
    }
}
