
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import CreateML
import Foundation

// Ensure this code is run in an environment that supports Create ML,
// typically a macOS application or a Swift Playground on macOS.
// For iOS deployment, the trained model would be bundled with the app.
@available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *)
func trainAndEvaluateTextClassifier() async {
    print("Starting text classifier training and evaluation...")

    // 1. Prepare Synthetic Dataset
    /// Create an in-memory MLDataTable to simulate our training and testing data.
    /// For a real-world image classifier, this would involve loading image paths
    /// and their corresponding labels from directories or a CSV file.
    let rawData: [(text: String, label: String)] = [
        ("A photo of a cat playing with a ball.", "Animal"),
        ("A majestic mountain range at sunset.", "Landscape"),
        ("A selfie of a person smiling.", "Portrait"),
        ("An old vintage car parked on the street.", "Object"),
        ("A dog chasing a frisbee in the park.", "Animal"),
        ("The vast ocean under a clear sky.", "Landscape"),
        ("A group photo of friends laughing.", "Portrait"),
        ("A shiny new smartphone on a desk.", "Object"),
        ("Birds flying gracefully in the sky.", "Animal"),
        ("A vibrant cityscape at night.", "Landscape"),
        ("A close-up of a flower blooming.", "Object"),
        ("A baby's first steps.", "Portrait"),
        ("A squirrel gathering nuts.", "Animal"),
        ("The northern lights dancing.", "Landscape"),
        ("A delicious plate of pasta.", "Object"),
        ("A family reunion photo.", "Portrait"),
        ("A lion resting in the savanna.", "Animal"),
        ("A serene forest path.", "Landscape"),
        ("A pair of stylish shoes.", "Object"),
        ("Graduation ceremony picture.", "Portrait"),
        ("A curious fox in the snow.", "Animal"),
        ("Rolling hills and green fields.", "Landscape"),
        ("A classic wristwatch.", "Object"),
        ("Wedding day memories.", "Portrait"),
        ("A playful dolphin jumping.", "Animal"),
        ("Sunset over a calm lake.", "Landscape"),
        ("A modern coffee machine.", "Object"),
        ("Birthday party fun.", "Portrait"),
        ("A fluffy rabbit in a garden.", "Animal"),
        ("Snow-capped peaks.", "Landscape"),
        ("An antique vase.", "Object"),
        ("Team building event.", "Portrait")
    ]

    let dataTable = try! MLDataTable(dictionary: [
        "text": rawData.map { $0.text },
        "label": rawData.map { $0.label }
    ])

    print("Dataset created with \(dataTable.rows.count) entries.")

    // 2. Split Data into Training and Testing Sets
    /// Create ML provides convenient methods for splitting data.
    /// A common practice is 80% for training and 20% for testing.
    /// This split ensures that the model is evaluated on data it has never seen before.
    let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 0)
    print("Training data size: \(trainingData.rows.count)")
    print("Testing data size: \(testingData.rows.count)")

    // 3. Define Training Parameters (Hyperparameters)
    /// Hyperparameters control the training process. Here, we define `maxIterations`
    /// and how the validation data is handled.
    /// - `maxIterations`: Limits the number of training passes over the dataset.
    ///   A higher number might lead to better accuracy but risks overfitting and takes longer.
    /// - `validationDataSplit`: Create ML automatically reserves a portion of the
    ///   training data for internal validation during training. This helps monitor
    ///   performance and detect overfitting early.
    ///   Setting it to `0.1` means 10% of the `trainingData` will be used for validation.
    let parameters = MLTextClassifier.TrainingParameters(
        maxIterations: 50, // Example hyperparameter: number of training iterations
        validationDataSplit: 0.1, // Example hyperparameter: percentage of training data for internal validation
        augmentationOptions: [] // No augmentation for text, but relevant for image/sound
    )
    print("Training parameters defined: maxIterations=\(parameters.maxIterations), validationDataSplit=\(parameters.validationDataSplit)")

    // 4. Train the Text Classifier Model
    /// Create ML training is an asynchronous operation.
    /// The `progressHandler` can be used to update UI or log progress during long training sessions.
    var model: MLTextClassifier
    do {
        print("Training model...")
        model = try await MLTextClassifier.train(
            trainingData: trainingData,
            textColumn: "text",
            labelColumn: "label",
            parameters: parameters,
            progressHandler: { progress in
                // This handler is called periodically during training.
                // In a real app, you might update a progress bar here.
                print("Training Progress: \(Int(progress.fractionCompleted * 100))%")
            }
        )
        print("Model training completed successfully!")
    } catch {
        print("Error during model training: \(error.localizedDescription)")
        return
    }

    // 5. Evaluate the Model's Performance
    /// After training, it's crucial to evaluate the model on the *testing data*
    /// (data it has never seen) to get an unbiased estimate of its performance.
    /// The evaluation provides metrics like accuracy, precision, recall, and F1-score.
    let evaluation = model.evaluation(on: testingData, textColumn: "text", labelColumn: "label")

    print("\n--- Model Evaluation Results ---")
    print("Overall Accuracy: \(String(format: "%.2f", evaluation.accuracy * 100))%")
    print("Confusion Matrix:\n\(evaluation.confusionMatrix)")
    print("Per-Class Precision:\n\(evaluation.precisionRecallF1Score.precision)")
    print("Per-Class Recall:\n\(evaluation.precisionRecallF1Score.recall)")
    print("Per-Class F1-Score:\n\(evaluation.precisionRecallF1Score.f1Score)")

    // 6. (Optional) Save the Trained Model
    /// Once satisfied with the model, you can save it to a .mlmodel file.
    /// This file can then be bundled with your app for on-device inference.
    let saveURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("SmartPhotoClassifier.mlmodel")
    do {
        try model.write(to: saveURL)
        print("\nModel saved to: \(saveURL.path)")
        print("You can now drag this .mlmodel file into your Xcode project.")
    } catch {
        print("Error saving model: \(error.localizedDescription)")
    }
}

// Call the async function to start the process.
// In a real app, this might be triggered by a button tap or app launch.
// For a Playground, use Task.
if #available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 6.0, *) {
    Task {
        await trainAndEvaluateTextClassifier()
    }
} else {
    print("Create ML is not available on this OS version.")
}
