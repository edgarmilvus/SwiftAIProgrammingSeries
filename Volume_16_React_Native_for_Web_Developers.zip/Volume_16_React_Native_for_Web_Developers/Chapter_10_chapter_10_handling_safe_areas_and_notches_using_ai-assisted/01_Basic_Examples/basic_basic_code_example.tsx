/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { 
  SafeAreaView, 
  useSafeAreaInsets 
} from 'react-native-safe-area-context';

// 1. Define a TypeScript interface for the component props.
// We use Generics here to allow the component to accept standard View props
// while enforcing our specific styling constraints.
interface DashboardScreenProps {
  title: string;
  // Using a generic 'style' prop allows flexibility while maintaining type safety.
  containerStyle?: any; 
}

/**
 * DashboardScreen Component
 * 
 * A functional component that renders a dashboard layout respecting
 * device safe areas (notches, status bars, navigation bars).
 * 
 * @param {DashboardScreenProps} props - The component props.
 * @returns {JSX.Element} A rendered safe area view.
 */
export const DashboardScreen: React.FC<DashboardScreenProps> = ({ 
  title, 
  containerStyle 
}) => {
  // 2. Hook Usage: useSafeAreaInsets
  // This hook retrieves the safe area insets for the current device.
  // It returns an object: { top: number, bottom: number, left: number, right: number }
  const insets = useSafeAreaInsets();

  // 3. Dynamic Styling Logic
  // We construct a style object dynamically. This is crucial for handling
  // variable notch sizes across different iPhone models and Android devices.
  const dynamicStyles = StyleSheet.create({
    container: {
      // Apply the passed style, then override with safe area padding
      ...containerStyle,
      flex: 1,
      paddingTop: insets.top, // Pushes content below the notch/status bar
      paddingBottom: insets.bottom, // Pushes content above the nav bar/gesture area
      paddingLeft: insets.left,
      paddingRight: insets.right,
      backgroundColor: '#1e293b', // Slate-800
    },
    header: {
      padding: 16,
      borderBottomWidth: 1,
      borderBottomColor: '#334155',
    },
    content: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 20,
    },
    titleText: {
      fontSize: 24,
      fontWeight: 'bold',
      color: '#f1f5f9', // Slate-100
    },
    bodyText: {
      fontSize: 16,
      color: '#94a3b8', // Slate-400
      textAlign: 'center',
      marginTop: 10,
    },
  });

  return (
    // 4. SafeAreaView Wrapper
    // The SafeAreaView is a wrapper view that automatically applies padding
    // based on the system insets. It is often more reliable than manual
    // calculations on native platforms.
    <SafeAreaView style={dynamicStyles.container}>
      
      {/* Header Section */}
      <View style={dynamicStyles.header}>
        <Text style={dynamicStyles.titleText}>{title}</Text>
      </View>

      {/* Main Content Section */}
      <View style={dynamicStyles.content}>
        <Text style={dynamicStyles.titleText}>Welcome!</Text>
        <Text style={dynamicStyles.bodyText}>
          This content is safely tucked away from the notch and navigation bars.
          {'\n\n'}
          Current Insets:
          {'\nTop: '}{insets.top.toFixed(2)}
          {'\nBottom: '}{insets.bottom.toFixed(2)}
        </Text>
      </View>

    </SafeAreaView>
  );
};
