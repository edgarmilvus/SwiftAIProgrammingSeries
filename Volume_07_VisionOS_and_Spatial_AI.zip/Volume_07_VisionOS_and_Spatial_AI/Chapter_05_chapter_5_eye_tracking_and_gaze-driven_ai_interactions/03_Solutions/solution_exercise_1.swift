
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import RealityKit
import ARKit

/// A component to track the gaze-driven state of an entity.
struct GazeHighlightComponent: Component {
    var isHovered: Bool = false
    var currentScale: SIMD3<Float> = .one
    var currentEmissiveIntensity: Float = 0.0
}

@available(visionOS 1.0, *)
struct ReactiveEntityView: View {
    var body: some View {
        RealityView { content in
            // Create a Sphere
            let sphere = ModelEntity(mesh: .generateSphere(radius: 0.1), materials: [PhysicallyBasedMaterial()])
            sphere.name = "Sphere"
            sphere.components.set(CollisionComponent(shapes: [.generateSphere(radius: 0.1)]))
            sphere.components.set(GazeTargetComponent())
            sphere.components.set(GazeHighlightComponent())
            sphere.position = [0.3, 0, -0.5]
            content.add(sphere)
            
            // Create a Box
            let box = ModelEntity(mesh: .generateBox(size: 0.15), materials: [PhysicallyBasedMaterial()])
            box.name = "Box"
            box.components.set(CollisionComponent(shapes: [.generateBox(size: 0.15)]))
            box.components.set(GazeTargetComponent())
            box.components.set(GazeHighlightComponent())
            box.position = [-0.3, 0, -0.5]
            content.add(box)
            
            // Create a Cylinder
            let cylinder = ModelEntity(mesh: .generateCylinder(height: 0.2, radius: 0.05), materials: [PhysicallyBasedMaterial()])
            cylinder.name = "Cylinder"
            cylinder.components.set(CollisionComponent(shapes: [.generateCylinder(height: 0.2, radius: 0.05)]))
            cylinder.components.set(GazeTargetComponent())
            cylinder.components.set(GazeHighlightComponent())
            cylinder.position = [0, 0.3, -0.7]
            content.add(cylinder)
            
        } update: { content in
            // In a real production app, we use a System for per-frame updates.
            // For this exercise, we simulate the smoothing logic here.
            content.entities.forEach { entity in
                guard var highlight = entity.components[GazeHighlightComponent.self] as? GazeHighlightComponent,
                      var model = entity.components[ModelComponent.self] as? ModelComponent else { return }
                
                // Determine target states
                let targetScale: SIMD3<Float> = highlight.isHovered ? [1.05, 1.05, 1.05] : [1.0, 1.0, 1.0]
                let targetEmissive: Float = highlight.isHovered ? 1.0 : 0.0
                
                // Smooth Interpolation (Simple Low-Pass Filter logic)
                let lerpFactor: Float = 0.1
                highlight.currentScale = mix(highlight.currentScale, targetScale, t: lerpFactor)
                highlight.currentEmissiveIntensity = highlight.currentEmissiveIntensity + (targetEmissive - highlight.currentEmissiveIntensity) * lerpFactor
                
                // Apply Scale
                entity.scale = highlight.currentScale
                
                // Apply Material Update
                if var material = model.materials.first as? PhysicallyBasedMaterial {
                    material.emissiveColor = .init(color: .white, intensity: highlight.currentEmissiveIntensity)
                    model.materials = [material]
                    entity.components.set(model)
                }
                
                entity.components.set(highlight)
            }
        }
        .gesture(SpatialTapGesture().targetedToAnyEntity().onEnded { value in
            // This is a placeholder for gaze interaction logic. 
            // In visionOS, the system handles the raycast.
            // We simulate the 'isHovered' toggle for the demonstration.
            if var highlight = value.entity.components[GazeHighlightComponent.self] as? GazeHighlightComponent {
                highlight.isHovered.toggle()
                value.entity.components.set(highlight)
            }
        })
    }
}

// Helper function for linear interpolation
func mix<T: SIMDCompatible>(_ a: T, _ b: T, t: T.Scalar) -> T {
    return a + (b - a) * t
}

extension SIMD3 where Scalar == Float {
    static func mix(_ a: SIMD3<Float>, _ b: SIMD3<Float>, t: Float) -> SIMD3<Float> {
        return a + (b - a) * t
    }
}
