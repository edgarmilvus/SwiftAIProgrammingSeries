
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

// MARK: - Theoretical Models

/// Represents the immutable state of a single message in a conversation.
/// Conforms to Sendable to allow safe transfer between the Network Actor and the UI.
struct ChatMessage: Sendable, Identifiable, Codable {
    let id: UUID
    let role: MessageRole
    let content: String
    
    enum MessageRole: String, Sendable, Codable {
        case user
        case assistant
        case system
    }
}

/// The interface for any LLM provider (Claude, Gemini, etc.)
protocol GenerativeAIProvider: Sendable {
    /// Streams a response from the model.
    /// - Parameter messages: The current conversation history.
    /// - Returns: An AsyncSequence of strings representing the streaming tokens.
    func streamResponse(for messages: [ChatMessage]) async throws -> AsyncThrowingStream<String, Error>
}

// MARK: - The Orchestrator

/// The ChatSessionActor manages the "Source of Truth" for the conversation.
/// It ensures that the context window is updated atomically.
actor ChatSessionActor {
    private(set) var history: [ChatMessage] = []
    private let provider: any GenerativeAIProvider
    
    init(provider: any GenerativeAIProvider) {
        self.provider = provider
    }
    
    /// Adds a user message and returns a stream of assistant tokens.
    func processUserMessage(_ text: String) async throws -> AsyncThrowingStream<String, Error> {
        let userMsg = ChatMessage(id: UUID(), role: .user, content: text)
        history.append(userMsg)
        
        // We pass a copy of the history to the provider to ensure isolation.
        return try await provider.streamResponse(for: history)
    }
    
    /// This method would be called by the ViewModel as tokens arrive
    /// to finalize the assistant's message in the history.
    func appendAssistantToken(_ token: String, to messageID: UUID) {
        // Implementation for updating history with partial tokens
    }
}

// MARK: - The UI Bridge

@available(iOS 17.0, macOS 14.0, *)
@Observable
final class ChatViewModel: Sendable {
    // The UI observes this property.
    var messages: [ChatMessage] = []
    var isGenerating: Bool = false
    
    private let session: ChatSessionActor
    
    init(session: ChatSessionActor) {
        self.session = session
    }
    
    @MainActor
    func sendMessage(_ text: String) async {
        isGenerating = true
        
        // 1. Optimistically update UI with User Message
        let userMsg = ChatMessage(id: UUID(), role: .user, content: text)
        messages.append(userMsg)
        
        // 2. Create a placeholder for the Assistant's response
        let assistantMsgID = UUID()
        var assistantContent = ""
        messages.append(ChatMessage(id: assistantMsgID, role: .assistant, content: ""))
        
        do {
            // 3. Trigger the actor-isolated stream
            let stream = try await session.processUserMessage(text)
            
            // 4. Consume the stream
            for try await token in stream {
                assistantContent += token
                
                // 5. Update the UI on the MainActor
                // Note: In a real app, we'd update the specific message in the array.
                updateAssistantMessage(id: assistantMsgID, content: assistantContent)
            }
        } catch {
            print("Error streaming: \(error)")
        }
        
        isGenerating = false
    }
    
    @MainActor
    private func updateAssistantMessage(id: UUID, content: String) {
        if let index = messages.firstIndex(where: { $0.id == id }) {
            let updatedMsg = ChatMessage(id: id, role: .assistant, content: content)
            messages[index] = updatedMsg
        }
    }
}
