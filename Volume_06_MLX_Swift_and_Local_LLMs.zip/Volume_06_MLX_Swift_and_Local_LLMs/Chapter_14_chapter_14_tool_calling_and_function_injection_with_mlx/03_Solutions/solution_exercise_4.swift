
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import MLX // For context on MLX framework

@available(iOS 18.0, macOS 15.0, *)
struct LocalDocumentSearchTool {
    let name: String = "local_document_search"
    let description: String = "Searches through local documents for keywords and returns relevant text snippets. Requires `query: String`."

    private let mockDocumentContent: [String: [String]] = [
        "MLX Swift performance": [
            "MLX Swift leverages Apple Silicon's Unified Memory for unparalleled performance in local LLM inference and fine-tuning. This architecture minimizes data transfer overhead.",
            "Optimizing MLX models in Swift often involves careful tensor manipulation using MLXArray and understanding the lazy evaluation graph to maximize throughput.",
            "The functional transformation patterns like valueAndGradient in MLX are key for efficient model training and fine-tuning directly on device.",
            "Zero-copy data access between CPU and GPU is a fundamental benefit of Unified Memory, making MLX Swift ideal for high-performance machine learning tasks.",
            "When building custom inference engines, inheriting from MLXNN.Module provides a structured way to define model architectures."
        ],
        "Swift concurrency": [
            "Swift's async/await features simplify asynchronous programming, making it easier to manage complex operations in modern apps.",
            "Actors provide a safe way to handle shared mutable state in a concurrent environment, preventing data races.",
            "Structured concurrency helps manage the lifetime of asynchronous tasks and their error handling."
        ],
        "iOS UI development": [
            "SwiftUI offers a declarative approach to building user interfaces across all Apple platforms.",
            "UIKit remains powerful for highly customized or legacy iOS UI components.",
            "Understanding the view lifecycle is crucial for robust iOS app development."
        ]
    ]

    /// Simulates searching local documents for relevant snippets.
    /// - Parameter query: The search query.
    /// - Returns: An array of relevant text snippets.
    func searchDocuments(query: String) -> [String] {
        let lowercasedQuery = query.lowercased()
        var results: Set<String> = [] // Use Set for automatic deduplication

        // Prioritize exact topic matches
        for (topic, snippets) in mockDocumentContent {
            if topic.lowercased().contains(lowercasedQuery) {
                results.formUnion(snippets)
            }
        }
        
        // Then search within all snippets for keywords if no direct topic match or to augment
        if results.isEmpty { // Only search all snippets if no direct topic matches found
            for (_, snippets) in mockDocumentContent {
                for snippet in snippets {
                    if snippet.lowercased().contains(lowercasedQuery) {
                        results.insert(snippet)
                    }
                }
            }
        }

        // Limit results for realistic LLM context window management
        return Array(results).prefix(3).map { $0 }
    }
}

@available(iOS 18.0, macOS 15.0, *)
class DocumentAssistantDispatcher {
    private let documentSearchTool = LocalDocumentSearchTool()

    // MARK: - Decodable Structures for LLM Output Parsing

    /// Represents the arguments for the document search tool.
    struct SearchArguments: Decodable {
        let query: String
    }

    /// Represents a generic tool call structure from the LLM.
    struct ToolCall: Decodable {
        let name: String
        let arguments: SearchArguments // Specific to LocalDocumentSearchTool
    }

    /// Represents the overall LLM output containing a tool call.
    struct LLMOutput: Decodable {
        let tool_call: ToolCall
    }

    /// Handles a user query, potentially involving a tool call and subsequent summarization.
    /// - Parameter userQuery: The user's natural language query.
    /// - Returns: The assistant's response, which might be a tool execution result or a summary.
    func handleUserQuery(userQuery: String) -> String {
        // --- Step 1: Simulate LLM generating a tool call ---
        // In a real application, the MLX LLM would analyze `userQuery` and decide if a tool is needed.
        // For this exercise, we'll heuristically determine if a search tool call is implied.

        var simulatedLLMToolCallJson: String? = nil
        let lowercasedUserQuery = userQuery.lowercased()

        if lowercasedUserQuery.contains("summarize information about") ||
           lowercasedUserQuery.contains("find details on") ||
           lowercasedUserQuery.contains("search documents for") {

            // Extract a hypothetical search query from the user's intent
            let keywords = lowercasedUserQuery
                .replacingOccurrences(of: "summarize information about", with: "")
                .replacingOccurrences(of: "from my documents", with: "")
                .replacingOccurrences(of: "find details on", with: "")
                .replacingOccurrences(of: "search documents for", with: "")
                .trimmingCharacters(in: .whitespacesAndNewlines)

            if !keywords.isEmpty {
                simulatedLLMToolCallJson = """
                {
                  "tool_call": {
                    "name": "local_document_search",
                    "arguments": {
                      "query": "\(keywords)"
                    }
                  }
                }
                """
            }
        }

        // If no tool call JSON was generated, return a default LLM response.
        guard let toolCallJson = simulatedLLMToolCallJson,
              let jsonData = toolCallJson.data(using: .utf8) else {
            return "Assistant: I'm not sure how to respond to '\(userQuery)'. Can you be more specific or ask me to search your documents?"
        }

        do {
            let llmOutput = try JSONDecoder().decode(LLMOutput.self, from: jsonData)
            let toolCall = llmOutput.tool_call

            if toolCall.name == documentSearchTool.name {
                let query = toolCall.arguments.query
                let searchResults = documentSearchTool.searchDocuments(query: query)

                if searchResults.isEmpty {
                    return "Assistant: I couldn't find any relevant documents for '\(query)' in your local files."
                }

                // --- Step 2: Inject tool output back into LLM context for summarization ---
                // This simulates creating the prompt that the LLM would receive for the next turn.
                let formattedSearchResults = searchResults.map { "- \($0)" }.joined(separator: "\n")
                let injectedPromptForLLM = """
                User: \(userQuery)
                Tool Output (local_document_search results for "\(query)"):
                \(formattedSearchResults)

                Assistant: Based on the information found in your documents, here is a summary:
                """
                // print("\n--- LLM's Next Turn Prompt (Simulated) ---\n\(injectedPromptForLLM)\n----------------------------------------\n") // For debugging

                // In a real scenario, you'd feed `injectedPromptForLLM` to the MLX LLM
                // and it would generate the summary. For this exercise, we simulate the summary.
                let simulatedSummary = generateSimulatedSummary(from: searchResults, for: query)
                return injectedPromptForLLM + simulatedSummary

            } else {
                return "Assistant: I detected a tool call for an unknown tool: '\(toolCall.name)'."
            }
        } catch {
            return "Assistant: Error processing tool call: \(error.localizedDescription)"
        }
    }

    /// Simulates the LLM generating a summary based on the provided snippets.
    /// In a real application, this would be an actual MLX LLM inference call.
    private func generateSimulatedSummary(from snippets: [String], for query: String) -> String {
        if snippets.isEmpty {
            return "No specific details found for '\(query)' to summarize."
        }

        // A very basic, heuristic-based summary for the exercise,
        // mimicking what an LLM might do based on keywords.
        var summary = ""
        if query.lowercased().contains("mlx swift performance") {
            summary += "Your documents indicate that MLX Swift achieves high performance by leveraging Apple Silicon's Unified Memory, ensuring zero-copy data access and efficient tensor operations. It's optimized for local LLM inference and fine-tuning through lazy evaluation and `MLXArray` manipulation."
        } else if query.lowercased().contains("swift concurrency") {
            summary += "Your documents highlight that Swift's concurrency features, including async/await and Actors, simplify asynchronous programming and enhance thread safety, which are critical for robust modern applications."
        } else if query.lowercased().contains("ios ui development") {
            summary += "Your documents discuss that SwiftUI offers a declarative approach to UI development across Apple platforms, while UIKit remains valuable for highly customized or legacy iOS components."
        } else {
            summary += "Your documents contain information relevant to '\(query)'. Key points include: "
            summary += snippets.prefix(2).joined(separator: " ").trimmingCharacters(in: .whitespacesAndNewlines) // Just take first two for brevity
            if snippets.count > 2 {
                summary += " For more details, refer to the full text."
            }
        }
        return summary
    }
}

// Example Usage:
/*
@available(iOS 18.0, macOS 15.0, *)
func runDocumentAssistantExercise() {
    let dispatcher = DocumentAssistantDispatcher()

    // 1. User asks for MLX Swift performance summary
    let userQuery1 = "Summarize information about MLX Swift performance from my documents."
    print("User: \(userQuery1)")
    print(dispatcher.handleUserQuery(userQuery: userQuery1) + "\n")

    // 2. User asks for Swift concurrency details
    let userQuery2 = "Find details on Swift concurrency in my documents."
    print("User: \(userQuery2)")
    print(dispatcher.handleUserQuery(userQuery: userQuery2) + "\n")

    // 3. User asks for something not in documents (or no direct tool trigger)
    let userQuery3 = "Tell me a joke."
    print("User: \(userQuery3)")
    print(dispatcher.handleUserQuery(userQuery: userQuery3) + "\n")

    // 4. User asks for something that triggers search but yields no results
    let userQuery4 = "Summarize information about ancient alien technology from my documents."
    print("User: \(userQuery4)")
    print(dispatcher.handleUserQuery(userQuery: userQuery4) + "\n")

    // 5. User asks for iOS UI development details
    let userQuery5 = "Search documents for iOS UI development."
    print("User: \(userQuery5)")
    print(dispatcher.handleUserQuery(userQuery: userQuery5) + "\n")
}

// runDocumentAssistantExercise()
*/
