
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift snippet for MLX Swift
// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "MyMLXProject",
    platforms: [
        .macOS(.v14), .iOS(.v17), .visionOS(.v1) // Or specify iOS 18 for latest features
    ],
    products: [
        .library(
            name: "MyMLXProject",
            targets: ["MyMLXProject"]),
    ],
    dependencies: [
        .package(url: "https://github.com/ml-explore/mlx-swift.git", branch: "main") // Or a specific version
    ],
    targets: [
        .target(
            name: "MyMLXProject",
            dependencies: [
                .product(name: "MLX", package: "mlx-swift"),
                .product(name: "MLXNN", package: "mlx-swift")
            ]),
        .testTarget(
            name: "MyMLXProjectTests",
            dependencies: ["MyMLXProject"]),
    ]
)

// Example of a custom MLXNN.Module for an LLM block
@available(iOS 18.0, macOS 15.0, *) // Assuming features requiring newer OS versions
class TransformerBlock: MLXNN.Module {
    let selfAttention: MultiHeadAttention
    let feedForward: MLP
    let norm1: LayerNorm
    let norm2: LayerNorm

    init(embeddingSize: Int, numHeads: Int, ffHiddenSize: Int, dropout: Double) {
        self.selfAttention = MultiHeadAttention(embeddingSize: embeddingSize, numHeads: numHeads, dropout: dropout)
        self.feedForward = MLP(inputSize: embeddingSize, hiddenSize: ffHiddenSize, outputSize: embeddingSize, dropout: dropout)
        self.norm1 = LayerNorm(dimensions: [embeddingSize])
        self.norm2 = LayerNorm(dimensions: [embeddingSize])
        super.init() // Call super.init() after all properties are initialized
    }

    override func callAsFunction(_ x: MLXArray, mask: MLXArray? = nil) -> MLXArray {
        // Self-attention with residual connection
        var output = x + selfAttention(norm1(x), mask: mask)
        // Feed-forward with residual connection
        output = output + feedForward(norm2(output))
        return output
    }
}

// Simplified MultiHeadAttention (conceptually)
@available(iOS 18.0, macOS 15.0, *)
class MultiHeadAttention: MLXNN.Module {
    let queryProjection: LinearLayer
    let keyProjection: LinearLayer
    let valueProjection: LinearLayer
    let outputProjection: LinearLayer
    let numHeads: Int
    let headDim: Int
    let dropout: Double

    init(embeddingSize: Int, numHeads: Int, dropout: Double) {
        precondition(embeddingSize % numHeads == 0, "embeddingSize must be divisible by numHeads")
        self.numHeads = numHeads
        self.headDim = embeddingSize / numHeads
        self.dropout = dropout

        self.queryProjection = LinearLayer(inputSize: embeddingSize, outputSize: embeddingSize)
        self.keyProjection = LinearLayer(inputSize: embeddingSize, outputSize: embeddingSize)
        self.valueProjection = LinearLayer(inputSize: embeddingSize, outputSize: embeddingSize)
        self.outputProjection = LinearLayer(inputSize: embeddingSize, outputSize: embeddingSize)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray, mask: MLXArray? = nil) -> MLXArray {
        let batchSize = x.shape[0]
        let sequenceLength = x.shape[1]

        let q = queryProjection(x).reshaped([batchSize, sequenceLength, numHeads, headDim]).transposed(1, 2)
        let k = keyProjection(x).reshaped([batchSize, sequenceLength, numHeads, headDim]).transposed(1, 2)
        let v = valueProjection(x).reshaped([batchSize, sequenceLength, numHeads, headDim]).transposed(1, 2)

        // Scaled Dot-Product Attention
        let scores = matmul(q, k.transposed(2, 3)) / sqrt(Float(headDim))

        var attentionWeights = softmax(scores, axis: -1)
        if let mask = mask {
            attentionWeights = attentionWeights * mask // Apply mask
        }

        let output = matmul(attentionWeights, v).transposed(1, 2).reshaped([batchSize, sequenceLength, numHeads * headDim])
        return outputProjection(output)
    }
}

// MLXArray: The fundamental data structure for tensors.
// It represents multi-dimensional arrays and is the primary type for all MLX operations.
// Its operations are designed to be efficient and leverage Unified Memory.
let myTensor = MLXArray.ones([3, 4]) // Creates a 3x4 tensor of ones
let anotherTensor = MLXArray.randomUniform(low: 0, high: 1, [3, 4])
let result = myTensor + anotherTensor // This operation is added to the computation graph
