
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Foundation

@available(iOS 18.0, *)
actor MLModelManager {
    private var regressorModel: MLModel?
    private var classifierModel: MLModel?

    // Load models from disk or memory
    func loadRegressor(url: URL) async throws {
        self.regressorModel = try await MLModel.load(contentsOf: url)
        print("Regressor model loaded.")
    }

    func loadClassifier(url: URL) async throws {
        self.classifierModel = try await MLModel.load(contentsOf: url)
        print("Classifier model loaded.")
    }

    // Perform inference using the loaded regressor model
    func predictRegressor(input: MLDictionaryFeatureProvider) async throws -> MLFeatureProvider {
        guard let model = regressorModel else {
            throw ModelManagerError.modelNotLoaded
        }
        // Core ML's prediction is often synchronous, but we can wrap it in a Task
        // to ensure it runs off the main actor if called from a UI context,
        // or to allow for potential future async Core ML APIs.
        return try await Task {
            try model.prediction(from: input)
        }.value
    }

    // Perform inference using the loaded classifier model
    func predictClassifier(input: MLDictionaryFeatureProvider) async throws -> MLFeatureProvider {
        guard let model = classifierModel else {
            throw ModelManagerError.modelNotLoaded
        }
        return try await Task {
            try model.prediction(from: input)
        }.value
    }

    enum ModelManagerError: Error {
        case modelNotLoaded
    }
}

// Example usage
@available(iOS 18.0, *)
func demonstrateActorUsage() async {
    let manager = MLModelManager()
    let regressorURL = URL(fileURLWithPath: "path/to/your/Regressor.mlmodel") // Replace with actual path
    let classifierURL = URL(fileURLWithPath: "path/to/your/Classifier.mlmodel") // Replace with actual path

    do {
        // Load models (these operations are isolated to the actor)
        try await manager.loadRegressor(url: regressorURL)
        try await manager.loadClassifier(url: classifierURL)

        // Prepare input
        let regressorInput = try MLDictionaryFeatureProvider(dictionary: ["feature1": 7.0, "feature2": 70.0])
        let classifierInput = try MLDictionaryFeatureProvider(dictionary: ["petalLength": 3.0, "petalWidth": 1.0])

        // Perform predictions (these calls are also isolated to the actor)
        let regressorOutput = try await manager.predictRegressor(input: regressorInput)
        print("Regressor prediction output: \(regressorOutput)")

        let classifierOutput = try await manager.predictClassifier(input: classifierInput)
        print("Classifier prediction output: \(classifierOutput)")

    } catch {
        print("Error demonstrating actor usage: \(error)")
    }
}
