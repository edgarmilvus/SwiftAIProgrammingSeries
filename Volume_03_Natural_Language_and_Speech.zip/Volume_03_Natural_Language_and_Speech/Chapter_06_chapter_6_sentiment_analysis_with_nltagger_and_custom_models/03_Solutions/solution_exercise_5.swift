
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation // For CFAbsoluteTimeGetCurrent and Date
import NaturalLanguage // For NLTagger
import CoreML // Required for AppReviewClassifier from Exercise 3

// Re-using AppReviewClassifier from Exercise 3. Ensure it's available in the same module or copied here.
// For this exercise, you must have an 'AppReviewSentiment.mlmodel' added to your Xcode project,
// or the custom model parts will fail to initialize. You can create a dummy model using Create ML.

// NLTagger.TagScheme.sentimentScore and Core ML APIs are available from iOS 13.0, macOS 10.15.
// @available(iOS 18.0, macOS 15.0, *) is used here to align with the chapter's implied modern Swift 6 context.
@available(iOS 13.0, macOS 10.15, *)
struct SocialMediaSentimentProcessor {

    // 1. Data Generation
    /// Generates a specified number of sample social media posts with mixed sentiments.
    /// - Parameter count: The number of posts to generate.
    /// - Returns: An array of String representing social media posts.
    func generateSamplePosts(count: Int) -> [String] {
        let positivePhrases = ["I love this product!", "Absolutely fantastic!", "Highly recommend it.", "This is great news!", "So happy with the results.", "Best purchase ever!"]
        let negativePhrases = ["This is terrible.", "Very disappointed.", "Worst experience ever.", "Completely broken.", "I hate this update.", "Never buying again."]
        let neutralPhrases = ["It's okay.", "The item arrived.", "No strong feelings.", "It works.", "Just a regular day.", "Received as described."]
        let mixedPhrases = ["Good design, but slow.", "Great idea, poor execution.", "Mixed feelings.", "Some pros, some cons.", "Fast delivery, but wrong color."]

        var posts: [String] = []
        for i in 0..<count {
            let randomIndex = Int.random(in: 0..<4)
            var phrase: String
            switch randomIndex {
            case 0: phrase = positivePhrases.randomElement()!
            case 1: phrase = negativePhrases.randomElement()!
            case 2: phrase = neutralPhrases.randomElement()!
            case 3: phrase = mixedPhrases.randomElement()!
            default: phrase = "Default text."
            }
            posts.append("\(phrase) (Post \(i+1))") // Add index to make them unique and identifiable
        }
        return posts
    }

    // 2. Batch Processing Function (Serial)
    /// Processes an array of social media posts either with NLTagger or a custom Core ML model serially.
    /// - Parameters:
    ///   - posts: An array of post strings.
    ///   - useCustomModel: A boolean indicating whether to use the custom Core ML model.
    /// - Returns: An array of tuples containing the original post, its sentiment (Double for NLTagger, SentimentLabel for custom), and confidence (optional for NLTagger).
    func processPostsInBatch(posts: [String], useCustomModel: Bool) -> [(post: String, sentiment: Any, confidence: Double?)] {
        var results: [(post: String, sentiment: Any, confidence: Double?)] = []

        if useCustomModel {
            guard let customClassifier = AppReviewClassifier() else {
                print("Error: AppReviewClassifier not initialized. Skipping custom model serial processing.")
                return []
            }
            for post in posts {
                let (label, confidence) = customClassifier.classifyReview(text: post)
                results.append((post: post, sentiment: label, confidence: confidence))
            }
        } else {
            let tagger = NLTagger(tagSchemes: [.sentimentScore])
            for post in posts {
                tagger.string = post // NLTagger's string property is mutable and not thread-safe for concurrent modification
                let (sentimentTag, _) = tagger.tag(at: post.startIndex, unit: .document, scheme: .sentimentScore)
                let score = Double(sentimentTag?.rawValue ?? "0.0") ?? 0.0
                results.append((post: post, sentiment: score, confidence: nil))
            }
        }
        return results
    }

    // 4. Concurrency (Bonus): Batch Processing Function (Concurrent using TaskGroup)
    /// Processes an array of social media posts concurrently using Swift's TaskGroup.
    /// - Parameters:
    ///   - posts: An array of post strings.
    ///   - useCustomModel: A boolean indicating whether to use the custom Core ML model.
    /// - Returns: An array of tuples containing the original post, its sentiment, and confidence.
    func processPostsConcurrently(posts: [String], useCustomModel: Bool) async -> [(post: String, sentiment: Any, confidence: Double?)] {
        var results: [(post: String, sentiment: Any, confidence: Double?)] = []
        
        if useCustomModel {
            guard let customClassifier = AppReviewClassifier() else {
                print("Error: AppReviewClassifier not initialized for concurrent processing.")
                return []
            }
            
            // Use TaskGroup to run predictions in parallel.
            // Core ML models are generally thread-safe for concurrent predictions after being loaded.
            await withTaskGroup(of: (Int, (String, AppReviewClassifier.SentimentLabel, Double)).self) { group in
                for (index, post) in posts.enumerated() {
                    group.addTask {
                        let (label, confidence) = customClassifier.classifyReview(text: post)
                        return (index, (post, label, confidence))
                    }
                }
                
                // Collect results, preserving original order.
                var interimResults = Array<(Int, (String, AppReviewClassifier.SentimentLabel, Double))?>(repeating: nil, count: posts.count)
                for await (index, result) in group {
                    interimResults[index] = result
                }
                
                for i in 0..<posts.count {
                    if let result = interimResults[i] {
                        results.append((post: result.1.0, sentiment: result.1.1, confidence: result.1.2))
                    }
                }
            }
        } else {
            // NLTagger's 'string' property is not thread-safe for concurrent modification.
            // A common approach for concurrent NLTagger use is to create a new instance per task,
            // or use DispatchQueue.concurrentPerform which implicitly manages this.
            await withTaskGroup(of: (Int, (String, Double, Double?)).self) { group in
                for (index, post) in posts.enumerated() {
                    group.addTask {
                        let tagger = NLTagger(tagSchemes: [.sentimentScore]) // New instance per task for thread safety
                        tagger.string = post
                        let (sentimentTag, _) = tagger.tag(at: post.startIndex, unit: .document, scheme: .sentimentScore)
                        let score = Double(sentimentTag?.rawValue ?? "0.0") ?? 0.0
                        return (index, (post, score, nil))
                    }
                }
                
                // Collect results, preserving original order.
                var interimResults = Array<(Int, (String, Double, Double?))?>(repeating: nil, count: posts.count)
                for await (index, result) in group {
                    interimResults[index] = result
                }
                
                for i in 0..<posts.count {
                    if let result = interimResults[i] {
                        results.append((post: result.1.0, sentiment: result.1.1, confidence: result.1.2))
                    }
                }
            }
        }
        return results
    }
}

// Demonstration
@available(iOS 13.0, macOS 10.15, *)
func demonstrateBatchProcessing() async {
    let processor = SocialMediaSentimentProcessor()
    let numberOfPosts = 2000 // Adjust this number for different performance tests (e.g., 500, 2000, 5000)
    let posts = processor.generateSamplePosts(count: numberOfPosts)

    print("--- Batch Processing Sentiment Analysis (\(numberOfPosts) posts) ---")

    // 3. Performance Measurement: Serial Processing with Built-in NLTagger
    let startTimeNLTagger = CFAbsoluteTimeGetCurrent()
    let nlTaggerResults = processor.processPostsInBatch(posts: posts, useCustomModel: false)
    let timeElapsedNLTagger = CFAbsoluteTimeGetCurrent() - startTimeNLTagger
    print("\nBuilt-in NLTagger (Serial):")
    print("  Processed \(nlTaggerResults.count) posts in \(String(format: "%.4f", timeElapsedNLTagger)) seconds.")
    // Optional: print a few sample results
    // nlTaggerResults.prefix(3).forEach { print("    '\(String(describing: $0.post.prefix(30)))...': Score \(String(format: "%.2f", $0.sentiment as! Double))") }


    // 3. Performance Measurement: Serial Processing with Custom Core ML Model
    let startTimeCustomModel = CFAbsoluteTimeGetCurrent()
    let customModelResults = processor.processPostsInBatch(posts: posts, useCustomModel: true)
    let timeElapsedCustomModel = CFAbsoluteTimeGetCurrent() - startTimeCustomModel
    print("\nCustom Core ML Model (Serial):")
    print("  Processed \(customModelResults.count) posts in \(String(format: "%.4f", timeElapsedCustomModel)) seconds.")
    // Optional: print a few sample results
    // customModelResults.prefix(3).forEach { print("    '\(String(describing: $0.post.prefix(30)))...': Label \($0.sentiment as! AppReviewClassifier.SentimentLabel), Confidence \(String(format: "%.2f", $0.confidence ?? 0.0))") }


    // 4. Concurrency (Bonus): Performance Measurement with Concurrent Processing
    print("\n--- Concurrent Batch Processing (using TaskGroup) ---")
    
    // NLTagger Concurrent
    let startTimeNLTaggerConcurrent = CFAbsoluteTimeGetCurrent()
    let nlTaggerConcurrentResults = await processor.processPostsConcurrently(posts: posts, useCustomModel: false)
    let timeElapsedNLTaggerConcurrent = CFAbsoluteTimeGetCurrent() - startTimeNLTaggerConcurrent
    print("\nBuilt-in NLTagger (Concurrent):")
    print("  Processed \(nlTaggerConcurrentResults.count) posts in \(String(format: "%.4f", timeElapsedNLTaggerConcurrent)) seconds.")
    
    // Custom Model Concurrent
    let startTimeCustomModelConcurrent = CFAbsoluteTimeGetCurrent()
    let customModelConcurrentResults = await processor.processPostsConcurrently(posts: posts, useCustomModel: true)
    let timeElapsedCustomModelConcurrent = CFAbsoluteTimeGetCurrent() - startTimeCustomModelConcurrent
    print("\nCustom Core ML Model (Concurrent):")
    print("  Processed \(customModelConcurrentResults.count) posts in \(String(format: "%.4f", timeElapsedCustomModelConcurrent)) seconds.")


    // 5. Output and Discussion
    print("\n--- Discussion ---")
    print("Observed Performance for \(numberOfPosts) posts:")
    print("- Serial NLTagger:       \(String(format: "%.4f", timeElapsedNLTagger))s")
    print("- Serial Custom Model:   \(String(format: "%.4f", timeElapsedCustomModel))s")
    print("- Concurrent NLTagger:   \(String(format: "%.4f", timeElapsedNLTaggerConcurrent))s")
    print("- Concurrent Custom Model: \(String(format: "%.4f", timeElapsedCustomModelConcurrent))s")
    print("\n**Performance Observations:**")
    print("- **Serial vs. Concurrent:** Concurrent processing (using TaskGroup) generally shows significant performance improvements over serial processing, especially for CPU-bound tasks like text analysis. This is because it effectively utilizes multiple CPU cores available on modern devices.")
    print("- **NLTagger vs. Custom Model:** The relative performance between NLTagger and a custom Core ML model can vary. Core ML models are often highly optimized for on-device inference, leveraging the Neural Engine, which can make them very fast. NLTagger's built-in sentiment is also highly optimized. For simple, general sentiment, NLTagger might be slightly faster due to less overhead. For complex, larger custom models, Core ML's hardware acceleration might give it an edge.")
    print("\n**When to prefer one method over the other:**")
    print("- **Built-in NLTagger:** Ideal for general-purpose sentiment analysis when a generic model is sufficient, or when you need quick, low-overhead analysis without managing custom models. It's always available on device.")
    print("- **Custom Core ML Model:** Preferred when domain-specific accuracy is crucial (e.g., app-specific jargon, nuanced interpretations). It allows for fine-tuning sentiment to your specific data, potentially at the cost of a slightly larger app bundle and initial model loading time.")
    print("- **Concurrency:** Essential for batch processing large datasets to maintain app responsiveness and achieve faster overall processing times. Always consider concurrency for tasks that can be broken down into independent units.")
}

// To run the demonstration, call this async function:
/*
// Example of how to call this from a non-async context (e.g., in AppDelegate or a ViewController)
Task {
    await demonstrateBatchProcessing()
}
*/
