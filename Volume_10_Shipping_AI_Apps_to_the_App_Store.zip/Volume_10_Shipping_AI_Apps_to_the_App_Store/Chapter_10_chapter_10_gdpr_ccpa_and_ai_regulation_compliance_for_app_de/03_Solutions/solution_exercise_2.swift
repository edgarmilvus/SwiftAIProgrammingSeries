
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

@available(iOS 18.0, *)
struct TelemetryPayload: Sendable {
    let noisyRating: Double
    let modelVersion: String
    let timestamp: Date
}

@available(iOS 18.0, *)
struct DifferentialPrivacyEngine {
    /// The privacy budget (epsilon). Smaller = more privacy, more noise.
    let epsilon: Double 
    
    /// Adds Laplace noise to a value using Inverse Transform Sampling.
    /// - Parameter value: The true user rating (1-5)
    /// - Returns: A noisy rating
    func applyLaplaceNoise(to value: Double) -> Double {
        // The scale parameter (b) for Laplace distribution is 1/epsilon 
        // assuming sensitivity (delta f) of the rating is 1.
        let b = 1.0 / epsilon
        
        // 1. Generate a random number from a uniform distribution U(-0.5, 0.5)
        let u = Double.random(in: -0.5...0.5)
        
        // 2. Inverse Transform Sampling for Laplace Distribution:
        // Noise = -b * sgn(u) * ln(1 - 2|u|)
        let noise = -b * (u.sign == .minus ? -1.0 : 1.0) * log(1.0 - 2.0 * abs(u))
        
        // 3. Add noise to original value and clamp to a reasonable range (0-5)
        let noisyValue = value + noise
        return max(0, min(5, noisyValue))
    }
    
    /// Prepares a privacy-preserving payload in a detached task.
    func prepareTelemetry(rating: Double, modelVersion: String) async -> TelemetryPayload {
        // Use a detached task to ensure heavy math doesn't impact UI responsiveness
        return await Task.detached(priority: .background) {
            let noisy = self.applyLaplaceNoise(to: rating)
            return TelemetryPayload(
                noisyRating: noisy,
                modelVersion: modelVersion,
                timestamp: Date()
            )
        }.value
    }
}

// Usage Example:
// let engine = DifferentialPrivacyEngine(epsilon: 0.5) // High privacy
// let payload = await engine.prepareTelemetry(rating: 5.0, modelVersion: "Llama-3-8B")
