/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ==============================================================================
 * FILE: app/page.tsx
 * PURPOSE: The Dashboard Home (Index Route).
 *          Lists available projects for the user.
 *          Uses Server Component to fetch initial data.
 * ==============================================================================
 */
import Link from 'next/link';
import { db } from '@/lib/db'; // Hypothetical database client

// Simulated Data Fetching in Server Component
async function getProjects() {
  // In a real app, this would be an authenticated DB call
  // This runs on the server, so no JS is sent to the client for this logic
  await new Promise(resolve => setTimeout(resolve, 500)); // Simulate latency
  return [
    { id: 'proj-1', name: 'Project Alpha', status: 'Active' },
    { id: 'proj-2', name: 'Project Beta', status: 'Archived' },
  ];
}

export default async function DashboardHome() {
  const projects = await getProjects();

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Your Projects</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {projects.map((project) => (
          <div key={project.id} className="border rounded-lg p-4 hover:shadow-lg transition">
            <h3 className="font-semibold text-lg">{project.name}</h3>
            <p className="text-sm text-gray-500">Status: {project.status}</p>
            <div className="mt-4 flex gap-2">
              {/* 
                Standard Link: Navigates to full page route 
                Equivalent to <Link href="/projects/proj-1/dashboard" /> in Expo
              */}
              <Link 
                href={`/projects/${project.id}/dashboard`}
                className="bg-blue-600 text-white px-3 py-1 rounded text-sm"
              >
                View Dashboard
              </Link>
              
              {/* 
                Intercepting Link: Triggers the Modal route 
                Note the `@modal` in the href. This is a Next.js specific convention
                that maps to the `modal` slot in the root layout.
              */}
              <Link 
                href={`/projects/${project.id}/@modal/edit`}
                className="bg-gray-200 text-gray-800 px-3 py-1 rounded text-sm"
              >
                Quick Edit (Modal)
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
