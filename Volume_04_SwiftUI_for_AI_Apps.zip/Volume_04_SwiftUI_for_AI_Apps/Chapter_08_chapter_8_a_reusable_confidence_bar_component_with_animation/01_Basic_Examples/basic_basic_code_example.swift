
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI

// MARK: - 1. The Reusable ConfidenceBarView Component

/// A reusable SwiftUI view that displays a confidence level as an animated horizontal bar.
/// The confidence value should be between 0.0 and 1.0.
@available(iOS 18.0, *) // Targeting latest iOS SDK with Swift 6
struct ConfidenceBarView: View {
    // @Binding allows the parent view to control the confidence value.
    // Changes to `confidence` from the parent will automatically update this view.
    @Binding var confidence: Double

    // Customization properties for the bar's appearance.
    var barColor: Color = .blue
    var backgroundColor: Color = .gray.opacity(0.3)
    var height: CGFloat = 10
    var cornerRadius: CGFloat = 5

    var body: some View {
        // GeometryReader is used to determine the available width for the bar.
        // This makes the component flexible and adapt to its parent's layout.
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                // Background of the confidence bar.
                // This shows the full potential width (100%).
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(backgroundColor)
                    .frame(height: height)

                // Foreground of the confidence bar, representing the actual confidence level.
                // Its width is a percentage of the total width, determined by `confidence`.
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(barColor)
                    .frame(width: geometry.size.width * CGFloat(confidence), height: height)
                    // The .animation modifier ensures that changes to the 'width' (driven by 'confidence')
                    // are smoothly animated over time.
                    // .easeInOut provides a natural-looking acceleration and deceleration.
                    .animation(.easeInOut(duration: 0.5), value: confidence)
            }
        }
        // Set a fixed height for the GeometryReader itself, otherwise it might expand indefinitely.
        .frame(height: height)
    }
}

// MARK: - 2. Integrating into a Voice Assistant UI (ContentView)

/// A demonstration view simulating a voice assistant interface
/// that uses the ConfidenceBarView to show understanding confidence.
@available(iOS 18.0, *) // Targeting latest iOS SDK with Swift 6
struct ContentView: View {
    // @State holds the current confidence level for the voice assistant.
    // This value will be passed to the ConfidenceBarView.
    @State private var voiceUnderstandingConfidence: Double = 0.5

    // A simple array of predefined confidence levels to simulate different AI predictions.
    private let sampleConfidences: [Double] = [0.2, 0.95, 0.6, 0.88, 0.45, 0.72]
    @State private var currentSampleIndex: Int = 0

    var body: some View {
        VStack(spacing: 30) {
            Text("Voice Assistant")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 20)

            // Display current confidence value as text.
            Text("Understanding Confidence: \(voiceUnderstandingConfidence * 100, specifier: "%.1f")%")
                .font(.title2)
                .foregroundColor(.secondary)

            // The ConfidenceBarView in action.
            // We pass a binding to `voiceUnderstandingConfidence` so the bar can react to its changes.
            ConfidenceBarView(confidence: $voiceUnderstandingConfidence,
                              barColor: .green,
                              backgroundColor: .green.opacity(0.2),
                              height: 15,
                              cornerRadius: 7.5)
                .padding(.horizontal) // Add some padding around the bar itself.

            Spacer()

            // MARK: - UI Controls to Simulate AI Predictions

            // Slider to manually adjust confidence for testing.
            VStack(alignment: .leading) {
                Text("Manual Adjustment:")
                    .font(.headline)
                Slider(value: $voiceUnderstandingConfidence, in: 0.0...1.0) {
                    Text("Confidence")
                } minimumValueLabel: {
                    Text("0%")
                } maximumValueLabel: {
                    Text("100%")
                }
                .padding(.horizontal)
            }
            .padding(.bottom, 20)

            // Button to simulate a new AI prediction with a random confidence level.
            Button {
                // When the button is tapped, we update the confidence.
                // SwiftUI's `animation` modifier on `ConfidenceBarView` will handle the smooth transition.
                withAnimation { // Explicitly wrap state changes in `withAnimation` for more control,
                               // though the `.animation` modifier on the bar itself is sufficient here.
                    voiceUnderstandingConfidence = sampleConfidences[currentSampleIndex]
                    currentSampleIndex = (currentSampleIndex + 1) % sampleConfidences.count
                }
            } label: {
                Label("Simulate New Command", systemImage: "waveform.badge.magnifyingglass")
                    .font(.title2)
                    .padding()
                    .background(Color.accentColor)
                    .foregroundColor(.white)
                    .cornerRadius(15)
            }
            .padding(.bottom)

            Text("Tap to simulate AI processing a new command and updating its understanding confidence.")
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        .padding()
    }
}

// MARK: - 3. Preview Provider

@available(iOS 18.0, *)
#Preview {
    ContentView()
}
