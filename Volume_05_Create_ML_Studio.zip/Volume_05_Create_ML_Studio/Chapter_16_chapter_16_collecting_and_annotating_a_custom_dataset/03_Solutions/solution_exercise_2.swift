
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import AVFoundation // Requires linking AVFoundation.framework

// Ensure this class is available on a reasonable iOS version.
// Using iOS 17.0 for modern SwiftUI and AVFoundation features.
@available(iOS 17.0, *)
@Observable // Swift 6 equivalent of @Published for classes, or use @Published with ObservableObject
class AudioCollector: NSObject, AVAudioRecorderDelegate {
    var isRecording = false
    var selectedSoundClass: String = "DogBark" // Default class
    var audioRecorder: AVAudioRecorder?
    var recordingError: String?

    let soundClasses = ["DogBark", "CatMeow", "BirdChirp", "Other"]

    override init() {
        super.init()
        // Configure the audio session when the collector is initialized
        setupAudioSession()
    }

    private func setupAudioSession() {
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.record, mode: .default, options: [])
            try audioSession.setActive(true)
        } catch {
            print("Failed to set up audio session: \(error.localizedDescription)")
            recordingError = "Audio session setup failed: \(error.localizedDescription)"
        }
    }

    func startRecording() {
        recordingError = nil // Clear previous errors
        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
            guard let self = self else { return }

            if granted {
                self.setupAndStartRecorder()
            } else {
                print("Microphone permission not granted.")
                self.recordingError = "Microphone permission not granted. Please enable in Settings."
            }
        }
    }

    private func setupAndStartRecorder() {
        let fileManager = FileManager.default
        guard let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else {
            print("Could not find documents directory.")
            self.recordingError = "Could not find app's documents directory."
            return
        }

        let classDirectory = documentsDirectory.appendingPathComponent(selectedSoundClass, isDirectory: true)
        if !fileManager.fileExists(atPath: classDirectory.path) {
            do {
                try fileManager.createDirectory(at: classDirectory, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print("Error creating directory: \(error.localizedDescription)")
                self.recordingError = "Error creating directory: \(error.localizedDescription)"
                return
            }
        }

        let audioFilename = classDirectory.appendingPathComponent(UUID().uuidString + ".m4a")

        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 44100,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]

        do {
            audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
            audioRecorder?.delegate = self
            audioRecorder?.record()
            // UI updates must be on the main thread
            Task { @MainActor in
                self.isRecording = true
            }
            print("Started recording to: \(audioFilename.lastPathComponent)")
        } catch {
            print("Could not start recording: \(error.localizedDescription)")
            // UI updates must be on the main thread
            Task { @MainActor in
                self.recordingError = "Could not start recording: \(error.localizedDescription)"
            }
        }
    }

    func stopRecording() {
        audioRecorder?.stop()
        // UI updates must be on the main thread
        Task { @MainActor in
            self.isRecording = false
        }
        print("Stopped recording.")
    }

    // MARK: - AVAudioRecorderDelegate
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if !flag {
            print("Audio recording finished with an error.")
            Task { @MainActor in
                self.recordingError = "Audio recording finished with an error."
            }
        }
        audioRecorder = nil // Release the recorder
    }

    func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
        if let error = error {
            print("Audio recorder encoding error: \(error.localizedDescription)")
            Task { @MainActor in
                self.recordingError = "Audio recorder encoding error: \(error.localizedDescription)"
            }
        }
    }
}

// Basic SwiftUI View to demonstrate the AudioCollector
@available(iOS 17.0, *)
struct AudioCollectorView: View {
    @State private var audioCollector = AudioCollector() // Using @State for simplicity with @Observable

    var body: some View {
        VStack(spacing: 20) {
            Picker("Sound Class", selection: $audioCollector.selectedSoundClass) {
                ForEach(audioCollector.soundClasses, id: \.self) {
                    Text($0)
                }
            }
            .pickerStyle(.segmented)
            .padding()

            Button(action: audioCollector.isRecording ? audioCollector.stopRecording : audioCollector.startRecording) {
                Label(audioCollector.isRecording ? "Stop Recording" : "Start Recording",
                      systemImage: audioCollector.isRecording ? "stop.circle.fill" : "mic.circle.fill")
                    .font(.title2)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(audioCollector.isRecording ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(15)
            }
            .padding(.horizontal)

            Text(audioCollector.isRecording ? "Recording..." : "Ready to record")
                .font(.headline)
                .foregroundColor(audioCollector.isRecording ? .red : .primary)

            if let error = audioCollector.recordingError {
                Text("Error: \(error)")
                    .foregroundColor(.red)
                    .font(.caption)
                    .multilineTextAlignment(.center)
                    .padding()
            }
        }
        .navigationTitle("Record Pet Sounds")
        .onAppear {
            // Request permission on appear for a smoother UX, though also handled on button tap
            AVAudioSession.sharedInstance().requestRecordPermission { _ in }
        }
    }
}

// Example usage in an App struct (for context, not part of the solution file)
/*
@main
struct PetTranslatorApp: App {
    var body: some Scene {
        WindowGroup {
            AudioCollectorView()
        }
    }
}
*/
