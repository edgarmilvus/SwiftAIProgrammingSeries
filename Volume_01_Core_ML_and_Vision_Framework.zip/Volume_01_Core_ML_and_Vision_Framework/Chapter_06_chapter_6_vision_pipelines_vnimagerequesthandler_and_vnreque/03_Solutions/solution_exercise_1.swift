
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Vision
import CoreGraphics
import Foundation
import UIKit // For UIImage conversion in example usage

@available(iOS 18.0, macOS 15.0, *)
func classifyImageWithConfidenceFilter(imageURL: URL) {
    // 1. Create VNImageRequestHandler.
    // Use .init(url:options:) for local image files.
    let handler = VNImageRequestHandler(url: imageURL, options: [:])

    // 2. Create VNClassifyImageRequest.
    let request = VNClassifyImageRequest { request, error in
        // This completion handler is called once the Vision request has processed the image.
        if let error = error {
            print("Image classification error: \(error.localizedDescription)")
            return
        }

        // 3. Result Processing: Cast observations.
        guard let observations = request.results as? [VNClassificationObservation] else {
            print("No classification observations found.")
            return
        }

        // Sort by confidence in descending order.
        let sortedObservations = observations.sorted { $0.confidence > $1.confidence }

        // Filter for confidence > 0.75 and take the top 3.
        let filteredAndTop3 = sortedObservations
            .filter { $0.confidence > 0.75 }
            .prefix(3) // Limits to the first 3 elements

        if filteredAndTop3.isEmpty {
            print("No classifications met the confidence threshold of 75%.")
            return
        }

        print("Top 3 classifications (confidence > 75%) for \(imageURL.lastPathComponent):")
        for observation in filteredAndTop3 {
            // Print identifier and confidence, formatted as percentage.
            print("  - \(observation.identifier): \(String(format: "%.2f", observation.confidence * 100))%")
        }
    }

    // 4. Request Execution: Perform the request.
    // For VNImageRequestHandler initialized with a URL, perform(_:) is synchronous.
    // The completionHandler of the request itself is typically called on a background queue.
    do {
        try handler.perform([request])
    } catch {
        print("Failed to perform image classification request: \(error.localizedDescription)")
    }
}

// Example usage (assuming 'testImage.jpg' exists in your app bundle or a known path):
// To run this, you'd typically add a test image to your project's assets or bundle.
// For demonstration, let's simulate a URL.
// In a real app, you'd get this URL from Photos library or app bundle.

// Helper function to create a dummy image for testing if none is provided
func createTestImage(named: String) -> URL? {
    let size = CGSize(width: 200, height: 200)
    UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
    let context = UIGraphicsGetCurrentContext()!
    UIColor.red.setFill()
    context.fill(CGRect(x: 0, y: 0, width: size.width, height: size.height))
    let image = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()

    guard let data = image?.jpegData(compressionQuality: 0.8) else { return nil }
    let tempDir = FileManager.default.temporaryDirectory
    let fileURL = tempDir.appendingPathComponent(named)
    do {
        try data.write(to: fileURL)
        print("Created dummy image at: \(fileURL.path)")
        return fileURL
    } catch {
        print("Error creating dummy image: \(error.localizedDescription)")
        return nil
    }
}

// To run this example, ensure you have a "testImage.jpg" in your bundle,
// or uncomment the createTestImage call to generate a temporary one.
//
// if let imagePath = Bundle.main.url(forResource: "testImage", withExtension: "jpg") {
//      classifyImageWithConfidenceFilter(imageURL: imagePath)
// } else if let dummyImagePath = createTestImage(named: "dummyTestImage.jpg") {
//      classifyImageWithConfidenceFilter(imageURL: dummyImagePath)
// } else {
//      print("Error: testImage.jpg not found and dummy image creation failed.")
// }
