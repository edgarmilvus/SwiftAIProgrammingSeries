
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import NaturalLanguage
import UIKit
import Combine // For debouncing

// Ensure iOS 18.0 availability for NLGrammarChecker
@available(iOS 18.0, *)
class GrammarTextView: UITextView, UITextViewDelegate {

    private let grammarChecker = NLGrammarChecker()
    private var currentGrammarResults: [NLGrammarChecker.Result] = []
    private var textDidChangePublisher = PassthroughSubject<String, Never>()
    private var cancellables = Set<AnyCancellable>()

    // Custom attribute key for highlighting errors
    static let grammarErrorAttribute = NSAttributedString.Key("GrammarErrorAttribute")

    override init(frame: CGRect, textContainer: NSTextContainer?) {
        super.init(frame: frame, textContainer: textContainer)
        commonInit()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }

    private func commonInit() {
        self.delegate = self
        self.backgroundColor = .systemBackground
        self.font = UIFont.preferredFont(forTextStyle: .body)
        self.autocorrectionType = .no // We'll handle our own corrections
        self.spellCheckingType = .no // We'll handle our own corrections

        setupGrammarChecking()
        setupMenuInteraction()
    }

    private func setupGrammarChecking() {
        // Debounce text changes to avoid excessive grammar checking calls
        textDidChangePublisher
            .debounce(for: .milliseconds(500), scheduler: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.performGrammarCheck()
            }
            .store(in: &cancellables)
    }

    private func setupMenuInteraction() {
        // Enable custom menu items for this text view
        self.isUserInteractionEnabled = true
        self.isSelectable = true // Required for menu to appear

        // Register for menu notifications if needed for custom menu display,
        // but for modern iOS, `buildMenu` is preferred.
    }

    // MARK: - UITextViewDelegate

    func textViewDidChange(_ textView: UITextView) {
        // Publish text changes to the debounced publisher
        textDidChangePublisher.send(textView.text)
    }

    // This method is crucial for custom menu items to appear
    override func buildMenu(with builder: UIMenuBuilder) {
        super.buildMenu(with: builder)

        // Only add custom menus to the editing menu
        guard builder.menu.identifier == UIMenu.Identifier.init("com.apple.UIKit.EditMenu") else { return }

        // Check if there's a selection that corresponds to an error
        guard let selectedRange = self.selectedTextRange else { return }
        let nsSelectedRange = NSRange(selectedRange, in: self.textStorage.string)

        // Find if the selected range overlaps with any current grammar error
        let overlappingResults = currentGrammarResults.filter { result in
            return NSIntersectionRange(nsSelectedRange, result.range).length > 0
        }

        guard let firstErrorResult = overlappingResults.first else {
            // No error selected, don't add grammar suggestions
            return
        }

        // Fetch suggestions for the identified error
        Task { @MainActor in
            do {
                let suggestions = try await grammarChecker.suggestions(for: firstErrorResult)
                guard !suggestions.isEmpty else { return }

                let suggestionActions = suggestions.map { suggestion in
                    UIAction(title: suggestion.text) { [weak self] _ in
                        self?.applySuggestion(suggestion, for: firstErrorResult)
                    }
                }
                
                // Create a menu for suggestions
                let suggestionsMenu = UIMenu(title: "Grammar Suggestions", children: suggestionActions)
                builder.insertSibling(suggestionsMenu, afterMenu: .lookup) // Insert after 'Look Up'
            } catch {
                print("Error fetching suggestions: \(error.localizedDescription)")
            }
        }
    }

    // MARK: - Grammar Checking Logic

    private func performGrammarCheck() {
        let text = self.textStorage.string
        guard !text.isEmpty else {
            clearAllHighlights()
            currentGrammarResults = []
            return
        }

        Task { @MainActor in
            do {
                // Clear previous highlights before applying new ones
                clearAllHighlights()
                currentGrammarResults = []

                let fullRange = NSRange(location: 0, length: text.utf16.count)
                var results: [NLGrammarChecker.Result] = []

                // Enumerate results on a background queue to avoid blocking UI
                await withCheckedContinuation { continuation in
                    grammarChecker.enumerateResults(in: fullRange, options: []) { result in
                        results.append(result)
                        return true // Continue enumeration
                    }
                    continuation.resume()
                }

                currentGrammarResults = results
                applyHighlights(for: results)

            } catch {
                print("Error during grammar check: \(error.localizedDescription)")
            }
        }
    }

    private func applyHighlights(for results: [NLGrammarChecker.Result]) {
        let attributedString = NSMutableAttributedString(attributedString: self.attributedText)

        for result in results {
            // Apply a custom attribute for highlighting
            attributedString.addAttributes([
                .underlineStyle: NSUnderlineStyle.patternDot.rawValue | NSUnderlineStyle.single.rawValue,
                .underlineColor: UIColor.systemRed,
                GrammarTextView.grammarErrorAttribute: true // Mark with our custom attribute
            ], range: result.range)
        }
        self.attributedText = attributedString
    }

    private func clearAllHighlights() {
        let attributedString = NSMutableAttributedString(attributedString: self.attributedText)
        let fullRange = NSRange(location: 0, length: attributedString.length)

        // Remove our custom attribute
        attributedString.removeAttribute(.underlineStyle, range: fullRange)
        attributedString.removeAttribute(.underlineColor, range: fullRange)
        attributedString.removeAttribute(GrammarTextView.grammarErrorAttribute, range: fullRange)

        self.attributedText = attributedString
    }

    private func applySuggestion(_ suggestion: NLGrammarChecker.Suggestion, for result: NLGrammarChecker.Result) {
        let mutableText = NSMutableAttributedString(attributedString: self.attributedText)
        
        // Replace the erroneous range with the suggestion text
        mutableText.replaceCharacters(in: result.range, with: suggestion.text)
        
        // Update the text view and re-check grammar
        self.attributedText = mutableText
        self.selectedRange = NSRange(location: result.range.location + suggestion.text.utf16.count, length: 0) // Place cursor after correction
        performGrammarCheck() // Re-check the entire text
    }
}
