
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import OSLog

/// A simulated representation of a massive AI Model's weight tensors.
/// In a real-world scenario, this would be a `MLModel` or a custom buffer 
/// containing billions of parameters.
@available(iOS 18.0, *)
final class LargeModelWeights {
    /// We simulate a large memory footprint using a massive array of Floats.
    /// 100,000,000 Floats * 4 bytes = ~400MB of RAM.
    let weights: [Float]
    let modelID: String
    
    init(modelID: String, size: Int) {
        self.modelID = modelID
        // Allocating a large contiguous block of memory.
        self.weights = Array(repeating: 0.0, count: size)
        print("--- [Memory] Loaded model \(modelID). Estimated footprint: \(Double(size * 4) / 1_000_000) MB ---")
    }
    
    deinit {
        print("--- [Memory] Weights for \(modelID) are being deallocated from RAM ---")
    }
}

/// An Actor that manages the lifecycle of the AI Model.
/// Using an `actor` ensures that model loading and unloading are thread-safe
/// and prevents race conditions where one thread tries to use a model 
/// while another is purging it.
@available(iOS 18.0, *)
actor AIModelManager {
    private let logger = Logger(subsystem: "com.ai.app", category: "ModelManager")
    
    /// The heavy resource is held as an optional. 
    /// Setting this to `nil` is the key to avoiding Jetsam kills.
    private var activeWeights: LargeModelWeights?
    
    /// Checks if the model is currently resident in memory.
    var isModelLoaded: Bool {
        activeWeights != nil
    }

    /// Loads the model into memory.
    /// - Parameter modelID: The identifier for the model to load.
    /// - Throws: An error if the model is already loaded or loading fails.
    func loadModel(id: String) async throws {
        guard activeWeights == nil else {
            logger.warning("Attempted to load model, but a model is already resident.")
            return
        }
        
        logger.info("Starting model load: \(id)")
        
        // Simulate the latency of loading a large file from disk into RAM.
        try await Task.sleep(for: .seconds(2))
        
        // In a real app, this would be: self.activeWeights = try await MLModel.load(contentsOf: url)
        self.activeWeights = LargeModelWeights(modelID: id, size: 100_000_000)
        
        logger.info("Model \(id) successfully loaded.")
    }

    /// Performs inference using the loaded model.
    /// - Parameter input: The text or audio input for the AI.
    /// - Returns: A simulated response string.
    func runInference(input: String) async throws -> String {
        guard let weights = activeWeights else {
            logger.error("Inference failed: No model loaded.")
            throw NSError(domain: "AIError", code: 404, userInfo: [NSLocalizedDescriptionKey: "Model not loaded"])
        }
        
        logger.info("Running inference on model \(weights.modelID)...")
        
        // Simulate heavy computation.
        try await Task.sleep(for: .seconds(1))
        
        return "AI Response to '\(input)' using model \(weights.modelID)"
    }

    /// Explicitly purges the model from memory.
    /// This is the most critical function for preventing Jetsam kills.
    func unloadModel() {
        logger.info("Manually triggering model unload.")
        // By setting the reference to nil, the ARC (Automatic Reference Counting) 
        // count drops to zero, and the deinit of LargeModelWeights is called.
        activeWeights = nil
    }
}

/// The ViewModel that drives the UI (e.g., a Voice Assistant interface).
/// Marked with @MainActor to ensure all UI updates happen on the main thread.
@available(iOS 18.0, *)
@MainActor
class VoiceAssistantViewModel: ObservableObject {
    @Published var status: String = "Ready"
    @Published var response: String = ""
    @Published var isProcessing: Bool = false
    
    private let modelManager = AIModelManager()
    
    /// The primary workflow: Load -> Inference -> Unload.
    func performVoiceTask(query: String) async {
        isProcessing = true
        status = "Loading Model..."
        
        do {
            // 1. Load the heavy resources.
            try await modelManager.loadModel(id: "GPT-Lite-v1")
            
            // 2. Perform the task.
            status = "Thinking..."
            let result = try await modelManager.runInference(input: query)
            
            // 3. Update UI with results.
            self.response = result
            self.status = "Task Complete."
            
            // 4. CRITICAL: Purge the model immediately after use to free up RAM
            // for other app processes or to prevent Jetsam kills when the user 
            // switches to a different app.
            await modelManager.unloadModel()
            status = "Model Unloaded (Memory Freed)"
            
        } catch {
            status = "Error: \(error.localizedDescription)"
            print("Error: \(error)")
        }
        
        isProcessing = false
    }
}

// --- Execution Simulation ---
@available(iOS 18.0, *)
func runDemo() async {
    let viewModel = await VoiceAssistantViewModel()
    
    print("--- Starting AI Task ---")
    await viewModel.performVoiceTask(query: "What is the capital of France?")
    print("--- AI Task Finished ---")
}

// To run in a Swift Playground or Command Line Tool:
// await runDemo()
