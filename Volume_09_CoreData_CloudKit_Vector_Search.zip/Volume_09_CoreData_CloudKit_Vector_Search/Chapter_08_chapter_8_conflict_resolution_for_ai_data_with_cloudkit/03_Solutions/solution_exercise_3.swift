
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CoreData

/// Represents the result of a semantic reconciliation attempt.
enum ReconciliationResult {
    case clientWins
    case mergeAndReembed(mergedText: String)
    case manualResolutionRequired(conflictLogID: UUID)
}

final class SemanticReconciliationEngine: Sendable {
    
    // Thresholds for semantic similarity
    private let highSimilarityThreshold: Float = 0.95
    private let moderateSimilarityThreshold: Float = 0.70

    /// Calculates the Cosine Similarity between two high-dimensional vectors.
    /// This is marked nonisolated to allow it to run on any thread without actor hopping.
    nonisolated func calculateCosineSimilarity(_ vecA: [Float], _ vecB: [Float]) -> Float? {
        guard vecA.count == vecB.count, !vecA.isEmpty else { return nil }
        
        var dotProduct: Float = 0
        var magnitudeA: Float = 0
        var magnitudeB: Float = 0
        
        for i in 0..<vecA.count {
            dotProduct += vecA[i] * vecB[i]
            magnitudeA += vecA[i] * vecA[i]
            magnitudeB += vecB[i] * vecB[i]
        }
        
        let denominator = sqrt(magnitudeA) * sqrt(magnitudeB)
        return denominator == 0 ? 0 : dotProduct / denominator
    }

    /// Performs the semantic reconciliation logic.
    /// This is a heavy operation and should be called within a Task.
    func reconcile(
        clientText: String,
        clientEmbedding: Data,
        serverText: String,
        serverEmbedding: Data
    ) async -> ReconciliationResult {
        
        // 1. Convert Data to [Float]
        let clientVec = clientEmbedding.withUnsafeBytes { Array($0.bindMemory(to: Float.self)) }
        let serverVec = serverEmbedding.withUnsafeBytes { Array($0.bindMemory(to: Float.self)) }
        
        // 2. Calculate Similarity
        guard let similarity = calculateCosineSimilarity(clientVec, serverVec) else {
            // Dimensionality mismatch or error
            return .manualResolutionRequired(conflictLogID: UUID())
        }
        
        print("Semantic Similarity Score: \(similarity)")

        // 3. Decision Tree
        if similarity >= highSimilarityThreshold {
            // High similarity: Assume typos/punctuation. Client wins.
            return .clientWins
        } else if similarity >= moderateSimilarityThreshold {
            // Moderate similarity: Merge text and trigger re-embedding.
            let mergedText = performSyntacticMerge(clientText, serverText)
            return .mergeAndReembed(mergedText: mergedText)
        } else {
            // Low similarity: Semantic conflict.
            return .manualResolutionRequired(conflictLogID: UUID())
        }
    }

    private func performSyntacticMerge(_ text1: String, _ text2: String) -> String {
        // Simple implementation: combine with a newline. 
        // In production, use a Diff-Match-Patch library.
        return "\(text1)\n---\n\(text2)"
    }
}

// MARK: - Usage Example
/*
Task(priority: .background) {
    let engine = SemanticReconciliationEngine()
    let result = await engine.reconcile(
        clientText: "The quick brown fox.",
        clientEmbedding: clientData, 
        serverText: "A fast brown fox jumps.",
        serverEmbedding: serverData
    )
    
    switch result {
    case .clientWins:
        // Update local store with client version
    case .mergeAndReembed(let text):
        // 1. Update text
        // 2. Trigger LLM Embedding Task
    case .manualResolutionRequired(let id):
        // Create ConflictLog entry in Core Data
    }
}
*/
