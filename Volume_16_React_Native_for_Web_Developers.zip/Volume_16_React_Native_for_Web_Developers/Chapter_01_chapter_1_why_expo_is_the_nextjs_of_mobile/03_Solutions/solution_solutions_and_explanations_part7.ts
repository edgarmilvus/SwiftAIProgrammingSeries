/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/Calculator.tsx

import React, { useState, Suspense, lazy } from 'react';
import { View, Text, Button, StyleSheet, ActivityIndicator } from 'react-native';
import { add } from '../utils/math'; // Named import for tree-shaking

// DYNAMIC IMPORT (Code Splitting)
// We lazy load a heavy component or library. 
// In a real app, this might be a heavy charting library.
// Here we simulate it with a component.
const HeavyComponent = lazy(() => import('./HeavyComponent'));

export default function Calculator() {
  const [sum, setSum] = useState<number | null>(null);
  const [showHeavy, setShowHeavy] = useState(false);

  const handleAdd = () => {
    const result = add(5, 10); // Only 'add' is imported, 'subtract' is tree-shaken
    setSum(result);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculator (ESM Optimized)</Text>
      
      <Button title="Calculate 5 + 10" onPress={handleAdd} />
      {sum !== null && <Text style={styles.result}>Result: {sum}</Text>}

      <View style={styles.separator} />
      
      <Text style={styles.subtitle}>Code Splitting Demo</Text>
      <Button 
        title={showHeavy ? "Hide Heavy Component" : "Load Heavy Component"} 
        onPress={() => setShowHeavy(!showHeavy)} 
      />

      {/* Suspense handles the loading state of the dynamic import */}
      <Suspense fallback={<ActivityIndicator size="large" color="#0000ff" />}>
        {showHeavy && <HeavyComponent />}
      </Suspense>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  subtitle: { fontSize: 18, marginTop: 20, marginBottom: 10, textAlign: 'center' },
  result: { fontSize: 18, marginTop: 10, textAlign: 'center', color: 'green' },
  separator: { height: 1, backgroundColor: '#ccc', marginVertical: 20 },
});
