
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Vision
import CoreImage
import Foundation

@available(iOS 18.0, macOS 15.0, *)
func analyzeDocumentText(image: CIImage) async throws -> [String] {
    var recognizedTexts: [String] = []
    let textDetectionRequest = VNDetectTextRectanglesRequest()
    textDetectionRequest.reportCharacterBoxes = false // We only need the region, not individual characters

    // Use withCheckedThrowingContinuation to bridge the completion handler pattern to async/await
    return try await withCheckedThrowingContinuation { continuation in
        let handler = VNImageRequestHandler(ciImage: image, options: [:])
        do {
            try handler.perform([textDetectionRequest])

            guard let textObservations = textDetectionRequest.results as? [VNTextObservation],
                  !textObservations.isEmpty else {
                // No text regions detected, return empty array
                continuation.resume(returning: [])
                return
            }

            let recognitionGroup = DispatchGroup()
            let lock = NSLock() // For thread-safe access to recognizedTexts from multiple async operations

            for textObservation in textObservations {
                recognitionGroup.enter() // Indicate that a new recognition task is starting

                // Convert normalized bounding box to CIImage coordinates
                let imageSize = image.extent.size
                let boundingBox = textObservation.boundingBox
                // VNImageRectForNormalizedRect handles coordinate system conversion and image orientation
                let imageRect = VNImageRectForNormalizedRect(boundingBox, Int(imageSize.width), Int(imageSize.height))

                // Crop the original CIImage to the detected text region
                let croppedCIImage = image.cropped(to: imageRect)

                let recognizeTextRequest = VNRecognizeTextRequest { request, error in
                    defer { recognitionGroup.leave() } // Ensure group.leave() is called when this task finishes

                    if let error = error {
                        print("Text recognition error for region: \(error.localizedDescription)")
                        return
                    }

                    guard let recognizedTextObservations = request.results as? [VNRecognizedTextObservation],
                          let topCandidate = recognizedTextObservations.first?.topCandidates(1).first else {
                        return // No text recognized in this region
                    }

                    // Protect shared resource (recognizedTexts) with a lock
                    lock.lock()
                    recognizedTexts.append(topCandidate.string)
                    lock.unlock()
                }

                recognizeTextRequest.recognitionLevel = .accurate // Prioritize accuracy over speed
                recognizeTextRequest.recognitionLanguages = ["en-US"] // Specify languages for better accuracy

                // Create a new handler for the cropped image
                let croppedHandler = VNImageRequestHandler(ciImage: croppedCIImage, options: [:])
                do {
                    try croppedHandler.perform([recognizeTextRequest])
                } catch {
                    print("Error performing recognition on cropped image: \(error.localizedDescription)")
                    recognitionGroup.leave() // Ensure group.leave() is called even if perform fails
                }
            }

            // Notify when all recognition tasks in the group have completed
            recognitionGroup.notify(queue: .main) { // Use .main for continuation, or a dedicated background queue
                continuation.resume(returning: recognizedTexts)
            }

        } catch {
            // Error during the initial text detection request
            continuation.resume(throwing: error)
        }
    }
}

// Example Usage:
// func processDocumentImage() async {
//     // Create a dummy CIImage for testing if you don't have a real document image.
//     // In a real app, you'd load this from a file, Photo Library, or camera.
//     guard let url = Bundle.main.url(forResource: "sample_document", withExtension: "png"),
//           let documentCIImage = CIImage(contentsOf: url) else {
//         print("Error: Document image 'sample_document.png' not found or could not be loaded.")
//         return
//     }
//
//     print("Starting document analysis...")
//     do {
//         let extractedTexts = try await analyzeDocumentText(image: documentCIImage)
//         if extractedTexts.isEmpty {
//             print("No text was extracted from the document.")
//         } else {
//             print("Extracted Texts:")
//             for text in extractedTexts {
//                 print("- \(text)")
//             }
//         }
//     } catch {
//         print("Failed to analyze document: \(error.localizedDescription)")
//     }
// }
//
// // Call this from an async context, e.g., a Task in viewDidLoad or a button action
// Task {
//     await processDocumentImage()
// }
