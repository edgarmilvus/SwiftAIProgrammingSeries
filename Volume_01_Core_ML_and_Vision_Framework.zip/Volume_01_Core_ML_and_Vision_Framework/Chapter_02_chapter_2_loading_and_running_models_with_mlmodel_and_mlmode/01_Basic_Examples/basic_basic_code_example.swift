
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import CoreML
import UIKit // For UIImage, CGImage, CVPixelBuffer conversion on iOS.
import Accelerate // For image processing utilities if needed for CVPixelBuffer.

// MARK: - Core ML Model Interfaces (Simulated)

// In a real project, Xcode automatically generates Swift classes/structs
// for your .mlmodel file (e.g., "MyImageClassifier.mlmodel" would generate
// "MyImageClassifier.swift" with `MyImageClassifierInput` and `MyImageClassifierOutput`).
// For this example, we'll define simplified versions to illustrate the concept
// of MLFeatureProvider for input and output.

/// Represents the input features for our Core ML model.
/// Core ML models expect inputs to conform to `MLFeatureProvider`.
struct MyImageClassifierInput: MLFeatureProvider {
    /// The input image as a CVPixelBuffer.
    /// Most image classification models expect CVPixelBuffer.
    let image: CVPixelBuffer

    /// A set of strings representing the names of the input features.
    /// These names must match what the model expects (defined in the .mlmodel).
    var featureNames: Set<String> {
        return ["image"] // Assuming the input feature is named "image"
    }

    /// Retrieves the feature value for a given feature name.
    /// This method is called by Core ML when performing inference.
    func featureValue(for featureName: String) -> MLFeatureValue? {
        guard featureName == "image" else { return nil }
        return MLFeatureValue(pixelBuffer: image)
    }
}

/// Represents the output features from our Core ML model.
/// Core ML model outputs also conform to `MLFeatureProvider`.
struct MyImageClassifierOutput: MLFeatureProvider {
    /// The predicted class label (e.g., "cat", "dog").
    let classLabel: String
    /// The probabilities for each class, typically as a dictionary where keys are class names.
    let classLabelProbs: [String: Double]

    /// A set of strings representing the names of the output features.
    /// These names must match what the model produces.
    var featureNames: Set<String> {
        return ["classLabel", "classLabelProbs"] // Assuming these are the output feature names
    }

    /// Retrieves the feature value for a given feature name.
    func featureValue(for featureName: String) -> MLFeatureValue? {
        switch featureName {
        case "classLabel":
            return MLFeatureValue(string: classLabel)
        case "classLabelProbs":
            // MLFeatureValue expects [AnyHashable: NSNumber] for dictionary types.
            return try? MLFeatureValue(dictionary: classLabelProbs as [AnyHashable : NSNumber])
        default:
            return nil
        }
    }

    /// Initializes the output from an `MLFeatureProvider`.
    /// This convenience initializer helps parse the raw output into structured properties.
    init(features: MLFeatureProvider) throws {
        // Extract the classLabel feature. It's expected to be a String.
        self.classLabel = try features.featureValue(for: "classLabel")!.stringValue
        // Extract the classLabelProbs feature. It's expected to be a dictionary.
        // We force-cast to [String : Double] based on our model's expected output.
        self.classLabelProbs = try features.featureValue(for: "classLabelProbs")!.dictionaryValue as! [String : Double]
    }
}

// MARK: - Core ML Image Classifier Class

/// A simple Core ML image classifier demonstrating loading, configuring, and running models.
class CoreMLImageClassifier {

    /// The underlying Core ML model instance. This is typically loaded once and reused.
    private var model: MLModel

    /// Initializes the classifier with a specified Core ML model configuration.
    /// - Parameter config: The `MLModelConfiguration` to use for loading the model.
    /// - Throws: An error if the compiled model (`.mlmodelc`) cannot be found or loaded.
    init(config: MLModelConfiguration) throws {
        // 1. Load the compiled Core ML model.
        // When you add an `.mlmodel` file to your Xcode project, Xcode automatically
        // compiles it into an optimized `.mlmodelc` directory within your app's bundle.
        // It also generates a Swift class (e.g., `MyImageClassifier`) that provides
        // a convenient interface to this compiled model.
        // `MLModel(contentsOf:configuration:)` is the direct way to load the `.mlmodelc`.

        guard let modelURL = Bundle.main.url(forResource: "MyImageClassifier", withExtension: "mlmodelc") else {
            // This error typically means the `.mlmodel` file was not added to the target,
            // or its name is incorrect, preventing Xcode from compiling it into `.mlmodelc`.
            throw CoreMLError.modelNotFound
        }
        
        // The `configuration` parameter is crucial for customizing model execution.
        // It's where you specify compute units, parameters for model updates, etc.
        self.model = try MLModel(contentsOf: modelURL, configuration: config)
        print("Model loaded successfully from \(modelURL.lastPathComponent)")
    }

    /// Performs image classification asynchronously.
    /// This method is marked `async` because inference can be a long-running operation
    /// and should not block the main thread.
    /// - Parameter image: The `CGImage` to classify.
    /// - Returns: A tuple containing the predicted class label and its confidence.
    /// - Throws: An error if image conversion fails or model prediction fails.
    func classifyImage(image: CGImage) async throws -> (label: String, confidence: Double) {
        // 2. Prepare the input image for the model.
        // Core ML models, especially for vision tasks, are highly optimized for `CVPixelBuffer`.
        // We need to convert our `CGImage` to a `CVPixelBuffer` with specific dimensions
        // and pixel format that the model expects. These specifications are defined
        // in your `.mlmodel` file (and reflected in the generated Swift interface).
        let modelInputWidth = 224 // Example: common for many image models (e.g., MobileNet)
        let modelInputHeight = 224 // Example: common for many image models

        guard let pixelBuffer = ImageConverter.pixelBuffer(from: image,
                                                            width: modelInputWidth,
                                                            height: modelInputHeight,
                                                            pixelFormatType: kCVPixelFormatType_32BGRA, // A common format
                                                            colorSpace: CGColorSpaceCreateDeviceRGB(),
                                                            alphaInfo: .noneSkipFirst) else {
            throw CoreMLError.imageConversionFailed
        }

        // Create the input feature provider using our prepared `CVPixelBuffer`.
        let input = MyImageClassifierInput(image: pixelBuffer)

        // 3. Perform inference using the model.
        // The `prediction(from:)` method executes the model.
        // It takes an `MLFeatureProvider` (our input) and returns another `MLFeatureProvider` (the raw output).
        // Using `await` here ensures the UI remains responsive.
        let outputFeatures = try await model.prediction(from: input)

        // 4. Interpret the model's output.
        // The `outputFeatures` contains the raw results from the model.
        // We use our `MyImageClassifierOutput` struct to parse these raw features
        // into more convenient properties like `classLabel` and `classLabelProbs`.
        let output = try MyImageClassifierOutput(features: outputFeatures)

        // Find the most confident prediction from the class probabilities.
        guard let (predictedLabel, confidence) = output.classLabelProbs.max(by: { $0.value < $1.value }) else {
            throw CoreMLError.noPredictionOutput
        }

        return (predictedLabel, confidence)
    }

    /// An example function demonstrating how to set up and run the classifier.
    static func runExample() async {
        print("\n--- Core ML Image Classifier Example ---")

        // Define model configuration.
        // MLModelConfiguration is where you specify how Core ML should run the model.
        let config = MLModelConfiguration()

        // computeUnits: This is a critical setting for performance and power.
        // - .all (Default): Core ML dynamically chooses the best available hardware (Neural Engine, GPU, CPU).
        // - .cpuOnly: Forces execution on the CPU. Good for debugging or when other hardware is busy.
        // - .gpuOnly: Attempts to use the GPU. Requires a compatible device.
        // - .neuralEngine: Attempts to use the Apple Neural Engine. Requires an A11 Bionic chip or newer.
        // - .cpuAndGPU: Uses both CPU and GPU.
        config.computeUnits = .all // Let Core ML decide for optimal performance.

        do {
            // Initialize the classifier with the chosen configuration.
            // This loads the compiled model into memory.
            let classifier = try CoreMLImageClassifier(config: config)
            print("Model configured with compute units: \(config.computeUnits.description)")

            // Simulate an image input.
            // In a real app, this would come from a camera, photo library, or network.
            guard let dummyImage = UIImage(named: "sample_image")?.cgImage else {
                print("Error: Sample image 'sample_image.png' not found in assets.")
                print("Please add an image named 'sample_image.png' to your Assets.xcassets.")
                return
            }

            print("Classifying image...")
            // Perform the classification.
            let (label, confidence) = try await classifier.classifyImage(image: dummyImage)
            print("Classification Result: \(label) with confidence \(String(format: "%.2f", confidence * 100))%")

        } catch let error as CoreMLError {
            switch error {
            case .modelNotFound:
                print("Error: Core ML model 'MyImageClassifier.mlmodelc' not found in bundle.")
                print("Please ensure you have an '.mlmodel' file named 'MyImageClassifier' added to your Xcode project and target's 'Build Phases -> Copy Bundle Resources'.")
            case .imageConversionFailed:
                print("Error: Failed to convert image to CVPixelBuffer. Check image format or dimensions.")
            case .noPredictionOutput:
                print("Error: Model returned no prediction output or output could not be parsed.")
            }
        } catch {
            print("An unexpected error occurred: \(error.localizedDescription)")
        }

        print("--- Example End ---")
    }
}

/// Custom error types specific to our Core ML operations.
enum CoreMLError: Error, LocalizedError {
    case modelNotFound
    case imageConversionFailed
    case noPredictionOutput

    var errorDescription: String? {
        switch self {
        case .modelNotFound:
            return "The Core ML model could not be found in the app bundle."
        case .imageConversionFailed:
            return "Failed to convert the input image to the required CVPixelBuffer format."
        case .noPredictionOutput:
            return "The model did not produce a valid prediction output."
        }
    }
}

// MARK: - Image Conversion Helper

/// Utility for converting images to CVPixelBuffer, a common input format for Core ML vision models.
enum ImageConverter {

    /// Converts a `CGImage` to a `CVPixelBuffer` with specified dimensions and format.
    /// This is a crucial step as Core ML models often require `CVPixelBuffer` inputs.
    /// - Parameters:
    ///   - image: The `CGImage` to convert.
    ///   - width: The target width for the pixel buffer. Must match model input dimensions.
    ///   - height: The target height for the pixel buffer. Must match model input dimensions.
    ///   - pixelFormatType: The desired pixel format (e.g., `kCVPixelFormatType_32BGRA`). Must match model input.
    ///   - colorSpace: The color space for the pixel buffer (e.g., `CGColorSpaceCreateDeviceRGB()`).
    ///   - alphaInfo: The alpha information for the pixel buffer (e.g., `.noneSkipFirst`).
    /// - Returns: An optional `CVPixelBuffer` if conversion is successful.
    static func pixelBuffer(from image: CGImage,
                            width: Int,
                            height: Int,
                            pixelFormatType: OSType,
                            colorSpace: CGColorSpace,
                            alphaInfo: CGImageAlphaInfo) -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        // Options for CVPixelBuffer creation, ensuring compatibility with CGImage and CGBitmapContext.
        let options: [String: Any] = [
            kCVPixelBufferCGImageCompatibilityKey as String: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey as String: true,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:] // Enable IOSurface for potential GPU acceleration
        ]

        // Create the CVPixelBuffer.
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormatType,
                                         options as CFDictionary,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess, let buffer = pixelBuffer else {
            print("Failed to create CVPixelBuffer: \(status)")
            return nil
        }

        // Lock the base address to allow direct pixel manipulation.
        CVPixelBufferLockBaseAddress(buffer, .zero)
        let context = CGContext(data: CVPixelBufferGetBaseAddress(buffer),
                                width: width,
                                height: height,
                                bitsPerComponent: 8, // Assuming 8 bits per color component
                                bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
                                space: colorSpace,
                                bitmapInfo: alphaInfo.rawValue)

        guard let cgContext = context else {
            CVPixelBufferUnlockBaseAddress(buffer, .zero)
            print("Failed to create CGContext for CVPixelBuffer.")
            return nil
        }

        // Apply a transform to flip the image vertically if needed.
        // CGImage drawing often starts from bottom-left, while CVPixelBuffer might be top-left.
        cgContext.translateBy(x: 0, y: CGFloat(height))
        cgContext.scaleBy(x: 1, y: -1)

        // Draw the CGImage into the CVPixelBuffer's context.
        let rect = CGRect(x: 0, y: 0, width: width, height: height)
        cgContext.draw(image, in: rect)

        // Unlock the base address.
        CVPixelBufferUnlockBaseAddress(buffer, .zero)

        return buffer
    }
}

// MARK: - How to Run This Example

/*
To make this code runnable in an Xcode project (e.g., an iOS app or a macOS app):

1.  **Obtain a Core ML Model:** Download a pre-trained `.mlmodel` file (e.g., from Apple's Core ML Models page or convert one yourself using `coremltools`).
    *   **Example:** You could use `MobileNetV2.mlmodel` from Apple's site.
2.  **Add Model to Xcode:** Drag and drop the `.mlmodel` file into your Xcode project navigator. Ensure it's added to your app's target. Xcode will automatically compile it into a `.mlmodelc` and generate a Swift interface.
3.  **Rename Model (if necessary):** If your model isn't named `MyImageClassifier.mlmodel`, change the `forResource` parameter in `Bundle.main.url(forResource: "MyImageClassifier", ...)` to match your model's name.
4.  **Add a Sample Image:** Add an image (e.g., `sample_image.png` or `sample_image.jpg`) to your `Assets.xcassets` catalog in Xcode. Ensure its name is "sample_image". This image will be used for classification.
5.  **Call `runExample()`:** Invoke `await CoreMLImageClassifier.runExample()` from an asynchronous context in your app (e.g., a button action in a SwiftUI `View`, or within a `Task` block in a `UIViewController`'s `viewDidLoad`).

    