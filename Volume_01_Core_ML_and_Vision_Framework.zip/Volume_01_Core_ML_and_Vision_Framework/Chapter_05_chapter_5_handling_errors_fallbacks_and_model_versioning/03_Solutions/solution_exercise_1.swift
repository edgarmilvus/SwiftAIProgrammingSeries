
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CoreML
import Foundation
import UIKit // For UIAlertController example

@available(iOS 18.0, *)
class ImageClassifierService {
    private var model: MLModel?
    private(set) var isMLFeatureAvailable: Bool = false // Make settable only within the class

    init() {
        loadModel()
    }

    private func loadModel() {
        // Step 1: Simulate model unavailability for testing by providing a wrong name
        // let modelFileName = "NonExistentClassifier" // Uncomment to simulate missing file
        let modelFileName = "MyImageClassifier" // Assumes MyImageClassifier.mlmodelc exists

        guard let modelURL = Bundle.main.url(forResource: modelFileName, withExtension: "mlmodelc") else {
            print("Error: \(modelFileName).mlmodelc not found in bundle. ML feature will be unavailable.")
            self.isMLFeatureAvailable = false
            // Fallback: Inform user or disable UI
            // showUserAlert("Image classification model not found. Please reinstall the app.")
            return
        }

        do {
            let configuration = MLModelConfiguration()
            // Configure the model, e.g., for specific compute units
            // configuration.computeUnits = .all // Example: Use all available compute units

            self.model = try MLModel(contentsOf: modelURL, configuration: configuration)
            self.isMLFeatureAvailable = true
            print("MyImageClassifier model loaded successfully.")
        } catch let error as CoreMLError {
            print("Core ML Error during model loading: \(error.localizedDescription)")
            // Further introspection based on error type
            switch error.code { // Use .code for specific CoreMLError types
            case .modelLoadingFailed:
                print("Specific CoreMLError: Model loading failed (e.g., corruption, incompatible format).")
            case .modelTypeNotSupported:
                print("Specific CoreMLError: Model type not supported on this device/OS version.")
            case .modelCollectionNotFound:
                print("Specific CoreMLError: Model collection not found (relevant for deployable models).")
            case .modelCollectionDownloadFailed:
                print("Specific CoreMLError: Model collection download failed.")
            case .modelCollectionUpdateFailed:
                print("Specific CoreMLError: Model collection update failed.")
            case .modelCollectionRemoved:
                print("Specific CoreMLError: Model collection removed.")
            @unknown default:
                print("Specific CoreMLError: An unknown Core ML error occurred.")
            }
            self.isMLFeatureAvailable = false
            // Fallback: Implement your UI/logic here
            // showUserAlert("Image classification is currently unavailable due to a model error.")
        } catch {
            print("An unexpected error occurred during model loading: \(error.localizedDescription)")
            self.isMLFeatureAvailable = false
            // Fallback: Implement your UI/logic here
            // showUserAlert("Image classification encountered an unexpected issue.")
        }
    }

    // You might have a method like this to show an alert (requires a UIViewController context)
    /*
    private func showUserAlert(_ message: String) {
        // This would typically involve a UIViewController or a global alert presenter
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "Feature Unavailable", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            // To present, you need access to the current view controller, e.g.:
            // if let topViewController = UIApplication.shared.windows.first?.rootViewController {
            //     topViewController.present(alert, animated: true)
            // }
        }
    }
    */

    // Placeholder for a classification method
    func classifyImage(_ image: UIImage) -> String {
        guard isMLFeatureAvailable, let model = self.model else {
            return "Classification unavailable. Please check app settings."
        }
        // In a real scenario, you'd use the model for prediction:
        // let prediction = try? model.prediction(from: MLFeatureProvider)
        return "Classified result (placeholder using model version: \(model.modelDescription.metadata.versionString ?? "N/A"))"
    }
}

// Example of how to use this service (e.g., in an AppDelegate or ViewController)
/*
@available(iOS 18.0, *)
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    var classifierService: ImageClassifierService?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        classifierService = ImageClassifierService()

        if classifierService?.isMLFeatureAvailable == true {
            print("ML feature is ready to use!")
            // You can now call classifierService.classifyImage(...)
        } else {
            print("ML feature is not available. Using fallback logic.")
            // Display fallback UI or disable ML-dependent features
        }

        // To simulate a missing model:
        // 1. Create a dummy .mlmodel (e.g., by exporting any model from Xcode)
        // 2. Add it to your project, name it "MyImageClassifier.mlmodel"
        // 3. To simulate failure, temporarily rename it in the project navigator
        //    or change 'modelFileName' in loadModel() to something non-existent.

        return true
    }
}
*/
