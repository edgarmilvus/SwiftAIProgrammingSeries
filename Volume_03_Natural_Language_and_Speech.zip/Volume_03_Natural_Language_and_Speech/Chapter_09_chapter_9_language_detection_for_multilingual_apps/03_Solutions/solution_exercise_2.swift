
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import NaturalLanguage

class AdaptiveTextEditorViewController: UIViewController, UITextViewDelegate {

    private let textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = UIFont.systemFont(ofSize: 18)
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return tv
    }()

    private let languageLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.textAlignment = .center
        label.text = "Dominant Language: Unknown"
        label.numberOfLines = 0
        return label
    }()

    // MARK: - NLLanguageRecognizer instance for incremental processing
    private let languageRecognizer = NLLanguageRecognizer()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Adaptive Text Editor"
        view.backgroundColor = .systemBackground

        textView.delegate = self

        view.addSubview(textView)
        view.addSubview(languageLabel)

        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 250),

            languageLabel.topAnchor.constraint(equalTo: textView.bottomAnchor, constant: 30),
            languageLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            languageLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            languageLabel.heightAnchor.constraint(equalToConstant: 60)
        ])

        // Initial language detection for any pre-existing text or placeholder
        updateLanguageDisplay()
    }

    // MARK: - UITextViewDelegate

    // This delegate method is crucial for capturing incremental changes
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        // Construct the new string to be passed to the NLLanguageRecognizer.
        // This is important because NLLanguageRecognizer's processString(_:)
        // expects the *full* string to be processed, or a string representing *only*
        // the new text being inserted/deleted.
        // For simplicity and robustness with `processString(_:)`, we'll pass the full updated string.
        // A more complex approach could be to pass only `replacementText` if `range`
        // indicates an insertion, or handle deletions explicitly.
        // However, `processString(_:)` is designed to be efficient even with full strings
        // if the recognizer already has a state.
        
        let currentText = textView.text as NSString
        let newText = currentText.replacingCharacters(in: range, with: text)
        
        // Reset the recognizer if the text is being completely cleared
        if newText.isEmpty {
            languageRecognizer.reset()
            languageLabel.text = "Dominant Language: Unknown"
        } else {
            // Process the *entire* current text. NLLanguageRecognizer is smart enough
            // to update its internal state efficiently based on the new input,
            // even if you pass the full string again after a small change.
            // The key is to use the *same* NLLanguageRecognizer instance.
            languageRecognizer.processString(newText)
            updateLanguageDisplay()
        }
        
        return true // Allow the text change to happen
    }
    
    // Fallback for when text is set programmatically or if textView(_:shouldChangeTextIn:replacementText:)
    // is not sufficient (e.g., for paste operations that might bypass it in some contexts,
    // though it generally covers them).
    func textViewDidChange(_ textView: UITextView) {
        // This method is called *after* the text has changed.
        // We already handled changes in shouldChangeTextIn, but this ensures
        // the display is updated if something else triggers a text change.
        if textView.text.isEmpty {
            languageRecognizer.reset()
        } else {
            languageRecognizer.processString(textView.text)
        }
        updateLanguageDisplay()
    }


    private func updateLanguageDisplay() {
        if let dominantLanguage = languageRecognizer.dominantLanguage {
            let languageName = Locale.current.localizedString(forLanguageCode: dominantLanguage.rawValue) ?? dominantLanguage.rawValue
            languageLabel.text = "Dominant Language: \(languageName)"
        } else {
            languageLabel.text = "Dominant Language: Unknown"
        }
    }
}
