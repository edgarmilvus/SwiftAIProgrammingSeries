/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// components/GyroscopeWidget.tsx
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { Gyroscope, ThreeAxisMeasurement } from 'expo-sensors';

/**
 * @description A self-contained widget to display real-time gyroscope data.
 * @platform iOS, Android, Web (via Expo)
 * @context SaaS Dashboard Widget for user orientation analytics.
 */
export default function GyroscopeWidget() {
  // State to hold the current sensor data
  const [data, setData] = useState<ThreeAxisMeasurement>({
    x: 0,
    y: 0,
    z: 0,
  });

  // State to manage the subscription status
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Constants for sensor update interval (60 FPS)
  const UPDATE_INTERVAL_MS = 1000 / 60;

  /**
   * @description Subscribes to the gyroscope sensor updates.
   * This mimics an analytics event listener in a SaaS context.
   */
  const _subscribe = () => {
    // Check if sensor is available (primarily for Web environment checks)
    if (!Gyroscope.isAvailableAsync) {
      setErrorMsg('Gyroscope not available on this device.');
      return;
    }

    // Set the update interval (optional, defaults to ~60ms)
    Gyroscope.setUpdateInterval(UPDATE_INTERVAL_MS);

    // Add the listener
    const sub = Gyroscope.addListener((result: ThreeAxisMeasurement) => {
      setData(result);
    });

    setSubscription(sub);
  };

  /**
   * @description Unsubscribes from the sensor to save battery and resources.
   * Critical for mobile performance and preventing memory leaks.
   */
  const _unsubscribe = () => {
    if (subscription) {
      subscription.remove();
      setSubscription(null);
    }
  };

  // React Lifecycle: Manage subscription on mount/unmount
  useEffect(() => {
    // Auto-start the sensor for the demo
    _subscribe();

    // Cleanup function: Runs when component unmounts
    return () => {
      _unsubscribe();
    };
  }, []);

  // Web-specific Warning: Sensors require HTTPS or localhost
  // Expo Web uses a polyfill that simulates sensor data if hardware isn't available
  // or if the context is insecure (non-HTTPS).
  useEffect(() => {
    if (Platform.OS === 'web') {
      // Check if we are in a secure context
      if (!window.isSecureContext && location.protocol !== 'http://localhost:') {
        setErrorMsg('Warning: Sensors require HTTPS or localhost on Web.');
      }
    }
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Gyroscope Data Widget</Text>
      
      {/* Data Display */}
      <View style={styles.dataRow}>
        <Text style={styles.label}>X Axis:</Text>
        <Text style={styles.value}>{data.x.toFixed(4)}</Text>
      </View>
      <View style={styles.dataRow}>
        <Text style={styles.label}>Y Axis:</Text>
        <Text style={styles.value}>{data.y.toFixed(4)}</Text>
      </View>
      <View style={styles.dataRow}>
        <Text style={label}>Z Axis:</Text>
        <Text style={styles.value}>{data.z.toFixed(4)}</Text>
      </View>

      {/* Error/Warning Display */}
      {errorMsg && <Text style={styles.error}>{errorMsg}</Text>}

      {/* Controls */}
      <View style={styles.controls}>
        <button 
          onClick={_unsubscribe} 
          style={styles.button}
          disabled={!subscription}
        >
          Stop Stream
        </button>
        <button 
          onClick={_subscribe} 
          style={styles.button}
          disabled={!!subscription}
        >
          Start Stream
        </button>
      </View>
    </View>
  );
}

// Styles (Native + Web compatible)
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#ddd',
    maxWidth: 400,
    margin: 'auto',
  },
  header: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  dataRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
    padding: 8,
    backgroundColor: '#fff',
    borderRadius: 6,
  },
  label: {
    fontSize: 14,
    color: '#333',
    fontWeight: '600',
  },
  value: {
    fontSize: 14,
    fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace',
    color: '#007AFF',
  },
  error: {
    color: '#ff3b30',
    marginTop: 10,
    textAlign: 'center',
    fontSize: 12,
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },
  button: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    backgroundColor: '#007AFF',
    color: '#fff',
    border: 'none',
    borderRadius: 6,
    cursor: 'pointer',
  },
});
