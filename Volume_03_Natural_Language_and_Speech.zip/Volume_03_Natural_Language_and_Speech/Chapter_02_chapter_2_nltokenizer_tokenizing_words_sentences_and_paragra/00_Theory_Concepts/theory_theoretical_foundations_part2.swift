
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor TokenizationCache {
    private var cachedTokens: [String: [NSRange]] = [:]
    private let defaultUnit: NLTokenUnit

    init(defaultUnit: NLTokenUnit = .word) {
        self.defaultUnit = defaultUnit
    }

    func getTokens(for text: String) async -> [NSRange] {
        if let cached = cachedTokens[text] {
            return cached
        }

        // Tokenization is performed within the actor's isolated context or offloaded.
        // For heavy computation, it's best to offload it using Task.detached.
        let tokens = await Task.detached {
            let tokenizer = NLTokenizer(unit: self.defaultUnit) // NLTokenizer is not Sendable, so create per-task or per-actor instance.
            tokenizer.string = text
            var ranges: [NSRange] = []
            tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
                let nsRange = NSRange(tokenRange, in: text)
                ranges.append(nsRange)
                return true
            }
            return ranges
        }.value

        cachedTokens[text] = tokens // Update isolated state
        return tokens
    }

    func clearCache() {
        cachedTokens.removeAll()
    }
}

// Example usage
@available(iOS 18.0, *)
func demonstrateActorUsage() async {
    let cache = TokenizationCache(defaultUnit: .word)
    let text1 = "Apple's Natural Language framework is powerful. It enables on-device NLP."
    let text2 = "Swift concurrency makes async tasks easy."

    let tokens1 = await cache.getTokens(for: text1)
    print("Tokens for text1: \(tokens1.count)")

    let tokens2 = await cache.getTokens(for: text2)
    print("Tokens for text2: \(tokens2.count)")

    // Accessing again will use the cache
    let tokens1Again = await cache.getTokens(for: text1)
    print("Tokens for text1 (cached): \(tokens1Again.count)")
}
