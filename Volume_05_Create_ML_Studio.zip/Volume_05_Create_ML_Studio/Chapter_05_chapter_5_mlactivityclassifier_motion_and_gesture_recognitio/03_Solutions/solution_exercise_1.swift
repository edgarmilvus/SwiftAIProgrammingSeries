
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import CoreML
import CoreMotion // MLActivityClassifier implicitly uses CoreMotion

@available(iOS 18.0, *)
class ActivityMonitorViewController: UIViewController {

    let activityLabel: UILabel = {
        let label = UILabel()
        label.text = "Initializing..."
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 24, weight: .bold)
        label.numberOfLines = 0 // Allow multiple lines for error messages
        return label
    }()

    let startButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Monitoring", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18)
        return button
    }()

    let stopButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Stop Monitoring", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18)
        button.isEnabled = false // Initially disabled
        return button
    }()

    private var activityClassifier: MLActivityClassifier?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        setupActivityClassifier()
        setupButtonActions()
        setupNotifications()
    }

    private func setupUI() {
        view.addSubview(activityLabel)
        view.addSubview(startButton)
        view.addSubview(stopButton)

        activityLabel.translatesAutoresizingMaskIntoConstraints = false
        startButton.translatesAutoresizingMaskIntoConstraints = false
        stopButton.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            activityLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -50),
            activityLabel.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            activityLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 50), // Use greaterThan for multiline

            startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            startButton.topAnchor.constraint(equalTo: activityLabel.bottomAnchor, constant: 40),
            startButton.widthAnchor.constraint(equalToConstant: 200),
            startButton.heightAnchor.constraint(equalToConstant: 50),

            stopButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stopButton.topAnchor.constraint(equalTo: startButton.bottomAnchor, constant: 20),
            stopButton.widthAnchor.constraint(equalToConstant: 200),
            stopButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    private func setupActivityClassifier() {
        // MLActivityClassifier is available from iOS 18.0
        if MLActivityClassifier.isActivityMonitoringAvailable() {
            activityClassifier = MLActivityClassifier()
            activityLabel.text = "Ready to monitor."
        } else {
            activityLabel.text = "Activity monitoring not available on this device or iOS version."
            startButton.isEnabled = false
        }
    }

    private func setupButtonActions() {
        startButton.addTarget(self, action: #selector(startMonitoringTapped), for: .touchUpInside)
        stopButton.addTarget(self, action: #selector(stopMonitoringTapped), for: .touchUpInside)
    }

    private func setupNotifications() {
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(appWillResignActive),
                                               name: UIApplication.willResignActiveNotification,
                                               object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(appDidBecomeActive),
                                               name: UIApplication.didBecomeActiveNotification,
                                               object: nil)
    }

    @objc private func startMonitoringTapped() {
        guard let classifier = activityClassifier else {
            activityLabel.text = "Error: Classifier not initialized."
            return
        }

        classifier.startActivityUpdates(to: .main) { [weak self] (prediction, error) in
            guard let self = self else { return }

            if let error = error {
                DispatchQueue.main.async {
                    self.activityLabel.text = "Error monitoring: \(error.localizedDescription)"
                    print("MLActivityClassifier Error: \(error.localizedDescription)")
                    self.stopMonitoringInternal() // Stop on error
                }
                return
            }

            if let prediction = prediction {
                DispatchQueue.main.async {
                    self.activityLabel.text = "Current Activity: \(prediction.label.capitalized)"
                    print("Detected Activity: \(prediction.label) (Confidence: \(prediction.confidence))")
                }
            } else {
                DispatchQueue.main.async {
                    self.activityLabel.text = "Monitoring... (No prediction yet)"
                }
            }
        }

        startButton.isEnabled = false
        stopButton.isEnabled = true
        activityLabel.text = "Monitoring..."
        print("MLActivityClassifier started.")
    }

    @objc private func stopMonitoringTapped() {
        stopMonitoringInternal()
    }

    private func stopMonitoringInternal() {
        activityClassifier?.stopActivityUpdates()
        startButton.isEnabled = true
        stopButton.isEnabled = false
        activityLabel.text = "Monitoring stopped."
        print("MLActivityClassifier stopped.")
    }

    @objc private func appWillResignActive() {
        // Pause monitoring when app goes to background
        if stopButton.isEnabled { // Only if monitoring was active
            print("App resigning active, pausing monitoring.")
            activityClassifier?.stopActivityUpdates()
            DispatchQueue.main.async {
                self.activityLabel.text = "Monitoring paused (App in background)."
            }
        }
    }

    @objc private func appDidBecomeActive() {
        // Resume monitoring when app comes to foreground
        if !startButton.isEnabled && !stopButton.isEnabled { // If it was paused by backgrounding
            print("App becoming active, resuming monitoring.")
            startMonitoringTapped() // Re-initiate monitoring
        } else if !startButton.isEnabled { // If it was running before backgrounding
             // No need to restart if it was already running and not explicitly stopped by user
             // The startMonitoringTapped() call above will handle this if the state was "paused by background"
             // If the user had stopped it, startButton.isEnabled would be true.
             // This branch handles the case where it was active, went to background, and now returns.
             // The previous stopActivityUpdates() would have set activityLabel, so we should update it.
             DispatchQueue.main.async {
                 self.activityLabel.text = "Monitoring resumed."
             }
        }
    }

    deinit {
        activityClassifier?.stopActivityUpdates()
        NotificationCenter.default.removeObserver(self)
    }
}
