
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

// @available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
actor Agent {
    private var llmContext: LlamaContext // The LLM instance (from previous chapters)
    private var conversationHistory: [Message] = []
    private var toolRegistry: [String: (ToolCall) async throws -> String] = [:] // Map tool names to async functions

    init(llmContext: LlamaContext) {
        self.llmContext = llmContext
        self.registerDefaultTools()
    }

    private func registerDefaultTools() {
        toolRegistry["searchWeb"] = { [weak self] toolCall in
            guard let self = self else { throw AgentError.agentDeinitialized }
            let params = try toolCall.decodeParameters(as: ToolCall.SearchWebParameters.self)
            print("Executing searchWeb with query: \(params.query)")
            // Simulate async network call
            try await Task.sleep(for: .seconds(2))
            return "Search results for '\(params.query)': [Link to article]"
        }
        // ... other tool registrations
    }

    func processMessage(_ message: String) async throws -> String {
        conversationHistory.append(Message(role: .user, content: message))
        
        var currentPrompt = buildPromptFromHistory() // Method to format history for LLM
        
        while true {
            let llmOutput = try await llmContext.generate(prompt: currentPrompt) // LLM inference
            
            if let toolCall = try? JSONDecoder().decode(ToolCall.self, from: llmOutput.data(using: .utf8)!) {
                // LLM wants to call a tool
                guard let toolFunction = toolRegistry[toolCall.toolName] else {
                    throw AgentError.toolNotFound(toolCall.toolName)
                }
                
                let toolResult = try await toolFunction(toolCall)
                conversationHistory.append(Message(role: .tool, content: toolResult))
                currentPrompt = buildPromptFromHistory() // Update prompt with tool result
                // Loop continues with new context
            } else {
                // LLM produced a final textual response
                conversationHistory.append(Message(role: .assistant, content: llmOutput))
                return llmOutput
            }
        }
    }
    
    // ... helper methods
}

enum AgentError: Error {
    case toolNotFound(String)
    case agentDeinitialized
    // ... other errors
}
