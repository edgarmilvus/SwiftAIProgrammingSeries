
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct Ingredient: Codable, Sendable {
    let name: String
    let quantity: Double
    let unit: String
}

@available(iOS 18.0, macOS 15.0, *)
struct Recipe: Codable, Sendable {
    let title: String
    let servings: Int
    let ingredients: [Ingredient]
    let instructions: [String]
}

@available(iOS 18.0, macOS 15.0, *)
actor RecipeParser {
    
    private func callLLM(prompt: String, input: String) async throws -> String {
        try await Task.sleep(for: .seconds(1))
        // Simulated response for a messy blog snippet
        return """
        {
          "title": "Grandma's Famous Pancakes",
          "servings": 4,
          "ingredients": [
            {"name": "flour", "quantity": 250.0, "unit": "grams"},
            {"name": "milk", "quantity": 300.0, "unit": "milliliters"},
            {"name": "eggs", "quantity": 2.0, "unit": "pieces"}
          ],
          "instructions": ["Mix dry ingredients", "Add milk and eggs", "Fry on pan"]
        }
        """
    }

    func parseRecipe(from messyText: String) async throws -> Recipe {
        let systemPrompt = """
        You are a culinary data extractor. Convert messy blog text into structured JSON.
        
        UNIT NORMALIZATION RULE:
        Convert all measurements to metric (grams or milliliters) where possible. 
        If a unit cannot be converted, use a consistent string format.

        ### EXAMPLE 1
        Input: "I love making these! Just grab 2 cups of flour and a splash of milk. Serves 2 people."
        Output: {
          "title": "Quick Flour Mix",
          "servings": 2,
          "ingredients": [
            {"name": "flour", "quantity": 240.0, "unit": "grams"},
            {"name": "milk", "quantity": 30.0, "unit": "milliliters"}
          ],
          "instructions": ["Mix ingredients"]
        }

        ### EXAMPLE 2
        Input: "For my family of 4, use 500g of sugar and 1 cup of water."
        Output: {
          "title": "Sweet Base",
          "servings": 4,
          "ingredients": [
            {"name": "sugar", "quantity": 500.0, "unit": "grams"},
            {"name": "water", "quantity": 236.0, "unit": "milliliters"}
          ],
          "instructions": ["Combine sugar and water"]
        }

        ### TASK
        Convert the following text into the same JSON format.
        """

        let rawResponse = try await callLLM(prompt: systemPrompt, input: messyText)
        let data = Data(rawResponse.utf8)
        return try JSONDecoder().decode(Recipe.self, from: data)
    }
}
