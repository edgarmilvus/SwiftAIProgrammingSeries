
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import RealityKit
import ARKit

/// A smoothed value provider to handle tremors/jitter.
struct MovingAverageFilter {
    private var values: [Float] = []
    private let windowSize: Int

    init(windowSize: Int = 5) {
        self.windowSize = windowSize
    }

    mutating func add(_ value: Float) -> Float {
        values.append(value)
        if values.count > windowSize { values.removeFirst() }
        return values.reduce(0, +) / Float(values.count)
    }
}

@MainActor
class MagneticInteractionLayer: Entity, HasModel, HasCollision {
    private var filter = MovingAverageFilter(windowSize: 8)
    private var baseScale: SIMD3<Float> = [1, 1, 1]
    private var baseCollisionSize: Float = 0.1
    
    required init() {
        super.init()
        self.baseScale = self.scale
    }

    /// Called by the interaction loop to update the "magnetism"
    /// - Parameters:
    ///   - gazeDirection: The current gaze vector
    ///   - handVelocity: The velocity of the user's hand
    ///   - targetEntity: The entity being evaluated for intent
    func updateMagneticEffect(
        gazeDirection: SIMD3<Float>,
        handVelocity: Float,
        targetPosition: SIMD3<Float>,
        targetEntity: Entity
    ) {
        // 1. Calculate Vector to Target
        let vectorToTarget = normalize(targetPosition - gazeDirection)
        let dotProduct = dot(vectorToTarget, gazeDirection) // How aligned is gaze with target?
        
        // 2. Calculate Probability of Intent (Simplified)
        // High dot product + Low hand velocity (stability) = High intent
        let gazeAlignment = max(0, dotProduct)
        let stability = max(0, 1.0 - (handVelocity / 2.0)) 
        let probabilityOfIntent = gazeAlignment * stability
        
        // 3. Apply "Magnetic" Pull if threshold met
        if probabilityOfIntent > 0.7 {
            applyMagnetism(strength: probabilityOfIntent, target: targetEntity)
        } else {
            resetMagnetism(target: targetEntity)
        }
    }
    
    private func applyMagnetism(strength: Float, target: Entity) {
        // Visual Affordance: Scale up
        let targetScale = baseScale * (1.0 + (strength * 0.5))
        target.scale = targetScale
        
        // Interaction Affordance: Expand Collision Shape
        // This makes the "hit-box" larger, catching the user's gaze/pinch easily.
        if let model = target as? ModelEntity {
            let newSize = baseCollisionSize * (1.0 + strength)
            model.collision = CollisionComponent(shapes: [.generateSphere(radius: newSize)])
        }
    }
    
    private func resetMagnetism(target: Entity) {
        target.scale = baseScale
        // In a real app, we would restore the original collision shape here
    }
}

// MARK: - Simulation Logic
@MainActor
func runMagneticSimulation() async {
    let interactionLayer = MagneticInteractionLayer()
    let sphere = ModelEntity(mesh: .generateSphere(radius: 0.1), materials: [SimpleMaterial()])
    sphere.generateCollisionShapes(recursive: true)
    
    // Simulate a user with a tremor (jittery gaze)
    var gazeFilter = MovingAverageFilter(windowSize: 5)
    
    for _ in 0..<20 {
        let jitteryGazeX: Float = Float.random(in: -0.1...0.1)
        let smoothedGazeX = gazeFilter.add(jitteryGazeX)
        
        // Simulate gaze moving toward the sphere
        let simulatedGaze = SIMD3<Float>(smoothedGazeX, 0, -1)
        let simulatedHandVel: Float = 0.2 // Slow, intentional movement
        
        interactionLayer.updateMagneticEffect(
            gazeDirection: simulatedGaze,
            handVelocity: simulatedHandVel,
            targetPosition: [0, 0, -1],
            targetEntity: sphere
        )
        
        try? await Task.sleep(for: .milliseconds(33)) // ~30fps loop
    }
}
