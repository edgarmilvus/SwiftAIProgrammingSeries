
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import Combine // For @Published

// MARK: - 1. Suggestion Type

/// Represents a single AI-generated suggestion for text refinement.
/// Needs to be `Sendable` to be safely passed between actors (e.g., from AISuggestionEngineActor to MainActor).
struct Suggestion: Identifiable, Equatable, Sendable {
    let id = UUID()
    let range: Range<String.Index> // Range within the original text
    let text: String               // The suggested text or action
    let type: SuggestionType
    
    // For easier debugging
    var description: String {
        "[\(type)] '\(text)' at \(range.lowerBound.encodedOffset)-\(range.upperBound.encodedOffset)"
    }
}

enum SuggestionType: String, Equatable, Sendable {
    case grammar = "Grammar"
    case style = "Style"
    case summarization = "Summarization"
    case rephrase = "Rephrase"
}

// MARK: - 2. NoteEditorViewModel (MainActor)

@MainActor
class NoteEditorViewModel: ObservableObject {
    @Published var currentText: String = "" {
        didSet {
            // Only process if text actually changed to avoid infinite loops or redundant calls
            if oldValue != currentText {
                textDidChange(newText: currentText)
            }
        }
    }
    @Published var suggestions: [Suggestion] = []
    
    private let suggestionEngine: AISuggestionEngineActor
    private var textProcessingTask: Task<Void, Never>? // To hold the task for debouncing/cancellation

    init(suggestionEngine: AISuggestionEngineActor) {
        self.suggestionEngine = suggestionEngine
        print("NoteEditorViewModel initialized on MainActor.")
    }

    /// Called when the text in the editor changes.
    /// This method debounces AI processing requests.
    func textDidChange(newText: String) {
        print("[\(Thread.current.description)] ViewModel: Text did change. New text length: \(newText.count)")
        
        // Cancel any previous pending suggestion processing task
        textProcessingTask?.cancel()
        
        // Launch a new task to debounce the AI processing
        // This task will call the actor after a short delay
        textProcessingTask = Task {
            do {
                try await Task.sleep(for: .milliseconds(300)) // Debounce delay
                // Check for cancellation before proceeding to AI processing
                try Task.checkCancellation()
                
                print("[\(Thread.current.description)] ViewModel: Debounce complete, requesting suggestions from engine...")
                // Call the actor to process the text.
                // The actor will then call `updateSuggestions` back on the MainActor.
                await suggestionEngine.processTextForSuggestions(text: newText, viewModel: self)
            } catch is CancellationError {
                print("[\(Thread.current.description)] ViewModel: Previous suggestion processing task cancelled.")
            } catch {
                print("[\(Thread.current.description)] ViewModel: Error during debounce: \(error)")
            }
        }
    }
    
    /// Called by the `AISuggestionEngineActor` to update suggestions on the MainActor.
    /// This method is implicitly `@MainActor` because the class is `@MainActor`.
    func updateSuggestions(_ newSuggestions: [Suggestion]) {
        self.suggestions = newSuggestions
        print("[\(Thread.current.description)] ViewModel: Suggestions updated. Count: \(newSuggestions.count)")
        newSuggestions.forEach { print("  - \($0.description)") }
    }
}

// MARK: - 3. AISuggestionEngineActor (Custom Actor)

actor AISuggestionEngineActor {
    private var currentProcessingTask: Task<Void, Never>?
    
    init() {
        print("AISuggestionEngineActor initialized.")
    }

    /// Processes the given text to generate AI suggestions.
    /// Implements debouncing and communicates results back to the ViewModel.
    /// - Parameters:
    ///   - text: The text to process.
    ///   - viewModel: The `NoteEditorViewModel` to send suggestions back to.
    func processTextForSuggestions(text: String, viewModel: NoteEditorViewModel) async {
        // Cancel any previous AI processing task within the actor
        currentProcessingTask?.cancel()
        
        currentProcessingTask = Task {
            do {
                print("[\(Thread.current.description)] Engine: Starting AI processing task for text length \(text.count)...")
                
                // Simulate AI processing delay
                try await Task.sleep(for: .milliseconds(500))
                try Task.checkCancellation() // Check if cancelled during sleep
                
                // Simulate generating mock suggestions based on text content
                var generatedSuggestions: [Suggestion] = []
                if text.contains("grammar error") {
                    if let range = text.range(of: "grammar error") {
                        generatedSuggestions.append(Suggestion(range: range, text: "Consider 'grammatical error'", type: .grammar))
                    }
                }
                if text.count > 50 {
                    if let range = text.range(of: text.prefix(20)) {
                        generatedSuggestions.append(Suggestion(range: range, text: "Summarize this section", type: .summarization))
                    }
                }
                if text.contains("very good") {
                     if let range = text.range(of: "very good") {
                         generatedSuggestions.append(Suggestion(range: range, text: "Consider 'excellent' or 'superb'", type: .style))
                     }
                 }
                
                print("[\(Thread.current.description)] Engine: Finished generating \(generatedSuggestions.count) suggestions.")
                
                // Crucially, update the UI on the MainActor
                await viewModel.updateSuggestions(generatedSuggestions)
                
            } catch is CancellationError {
                print("[\(Thread.current.description)] Engine: AI processing task cancelled for text length \(text.count).")
            } catch {
                print("[\(Thread.current.description)] Engine: Error during AI processing: \(error)")
            }
        }
    }
}

// MARK: - Integration & Demonstration

@main
struct Exercise3 {
    static func main() async {
        print("--- Starting Real-time AI Writing Tools Engine Demonstration ---")

        let suggestionEngine = AISuggestionEngineActor()
        let viewModel = NoteEditorViewModel(suggestionEngine: suggestionEngine)

        // Simulate user typing
        print("\nSimulating user typing rapidly...")
        viewModel.currentText = "This is a short sentence."
        try? await Task.sleep(for: .milliseconds(100))
        viewModel.currentText = "This is a short sentence with a grammar error."
        try? await Task.sleep(for: .milliseconds(100))
        viewModel.currentText = "This is a short sentence with a grammar error. It is very good."
        try? await Task.sleep(for: .milliseconds(100))
        viewModel.currentText = "This is a short sentence with a grammar error. It is very good. And now I am typing a much longer paragraph to trigger summarization suggestions."
        try? await Task.sleep(for: .milliseconds(100))
        viewModel.currentText = "This is a short sentence with a grammar error. It is very good. And now I am typing a much longer paragraph to trigger summarization suggestions. The quick brown fox jumps over the lazy dog."
        
        // Wait for the last debounce and processing to complete
        print("\nWaiting for final AI processing to complete...")
        try? await Task.sleep(for: .seconds(2))
        
        print("\n--- Demonstration complete ---")
        print("Final text: '\(await viewModel.currentText)'")
        print("Final suggestions count: \(await viewModel.suggestions.count)")
    }
}
