
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_7.swift
// Description: Solution for Exercise 7
// ==========================================

import Foundation

// Reuse ChatMessage and Tokenizer protocol/MockTokenizer from Exercise 1
// Reuse calculateTokenCount from Exercise 1

class SlidingWindowMemory {
    private var messages: [ChatMessage] = [] // Internal storage for messages
    let tokenBudget: Int // Maximum allowed token count
    private let tokenizer: Tokenizer // Tokenizer instance for counting

    // Initializer to set up the memory with a budget and a tokenizer
    init(tokenBudget: Int, tokenizer: Tokenizer) {
        self.tokenBudget = tokenBudget
        self.tokenizer = tokenizer
    }

    // Adds a new message and truncates older messages if the budget is exceeded
    func addMessage(_ newMessage: ChatMessage) {
        messages.append(newMessage) // Always add the new message to the end (most recent)
        
        // Loop to remove oldest messages from the beginning (tail truncation)
        // until the total token count is within the budget or no messages are left.
        while calculateTokenCount(for: messages, using: tokenizer) > tokenBudget && !messages.isEmpty {
            messages.removeFirst() // Remove the oldest message
        }
        // Note: If a single newMessage itself exceeds the tokenBudget,
        // it will remain the only message in `messages` but `currentTokenCount()`
        // will still report a value greater than `tokenBudget`. This is an
        // expected behavior for this specific sliding window strategy.
    }

    // Returns the current list of messages within the sliding window
    func currentContext() -> [ChatMessage] {
        return messages // Return the current state of messages
    }

    // Returns the current total token count of messages in the window
    func currentTokenCount() -> Int {
        return calculateTokenCount(for: messages, using: tokenizer)
    }
}
