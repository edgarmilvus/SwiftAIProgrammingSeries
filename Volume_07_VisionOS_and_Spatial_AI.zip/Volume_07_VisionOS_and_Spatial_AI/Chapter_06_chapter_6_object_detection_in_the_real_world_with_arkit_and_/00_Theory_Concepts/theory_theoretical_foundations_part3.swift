
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import RealityKit
    import ARKit
    import Vision
    import CoreML

    @Observable // Makes this class observable for SwiftUI/RealityKit
    @available(iOS 18.0, *)
    class DetectedObjectsStore {
        struct DetectedObject: Identifiable {
            let id = UUID()
            let label: String
            let confidence: Float
            let worldTransform: Transform // 3D position and orientation
            let boundingBox2D: CGRect // 2D bounding box on screen
        }
        var currentDetections: [DetectedObject] = []

        // Method to update detections, called by the ObjectDetectionActor
        @MainActor
        func updateDetections(from observations: [VNRecognizedObjectObservation], for frame: ARFrame) {
            var newDetections: [DetectedObject] = []
            for observation in observations {
                guard let topLabel = observation.labels.first else { continue }

                // Example: Convert 2D bounding box to 3D world point
                // This is a simplified example, actual conversion is more complex
                // and might involve raycasting or depth data.
                let center2D = CGPoint(x: observation.boundingBox.midX, y: observation.boundingBox.midY)
                let screenPoint = frame.camera.projectPoint(
                    SIMD3<Float>(0,0,-1), // Example: a point 1m in front of camera
                    orientation: .portrait,
                    viewportSize: CGSize(width: 1, height: 1) // Normalized viewport
                ) // This is not the correct way to unproject, just an example placeholder

                // Placeholder for actual 2D to 3D conversion logic
                // In a real app, you'd unproject the bounding box corners or center
                // using ARFrame's camera intrinsics and potentially depth information.
                let estimated3DPosition = SIMD3<Float>(0,0,0) // Needs proper calculation

                newDetections.append(
                    DetectedObject(
                        label: topLabel.identifier,
                        confidence: topLabel.confidence,
                        worldTransform: Transform(translation: estimated3DPosition),
                        boundingBox2D: observation.boundingBox
                    )
                )
            }
            self.currentDetections = newDetections
        }
    }

    @available(iOS 18.0, *)
    struct ARObjectDetectionView: View {
        @State private var arSessionManager: ARSessionManager // Manages ARSession and ObjectDetectionActor
        @State private var detectedObjectsStore = DetectedObjectsStore()

        init() {
            _arSessionManager = State(initialValue: ARSessionManager(detectedObjectsStore: DetectedObjectsStore()))
        }

        var body: some View {
            RealityView { content in
                // Add initial entities to the scene
            } update: { content in
                // Update entities based on detectedObjectsStore.currentDetections
                for detected in detectedObjectsStore.currentDetections {
                    // Example: Add a text entity for each detected object
                    let text = ModelEntity(
                        mesh: .generateText(detected.label, extrusionDepth: 0.01, font: .systemFont(ofSize: 0.1)),
                        materials: [SimpleMaterial(color: .red, isMetallic: false)]
                    )
                    text.transform = detected.worldTransform
                    content.add(text)
                }
            }
            .onAppear {
                arSessionManager.startSession()
            }
            .onDisappear {
                arSessionManager.pauseSession()
            }
        }
    }

    @available(iOS 18.0, *)
    class ARSessionManager: NSObject, ARSessionDelegate {
        let session = ARSession()
        let objectDetectionActor: ObjectDetectionActor
        let detectedObjectsStore: DetectedObjectsStore

        init(detectedObjectsStore: DetectedObjectsStore) {
            self.detectedObjectsStore = detectedObjectsStore
            // Load your Core ML model here, e.g., from your app bundle
            guard let modelURL = Bundle.main.url(forResource: "YOLOv3Tiny", withExtension: "mlmodelc"),
                  let compiledModel = try? MLModel.compileModel(at: modelURL),
                  let mlModel = try? MLModel(contentsOf: compiledModel) else {
                fatalError("Failed to load Core ML model")
            }
            self.objectDetectionActor = try! ObjectDetectionActor(model: mlModel)
            super.init()
            session.delegate = self
        }

        func startSession() {
            let configuration = ARWorldTrackingConfiguration()
            session.run(configuration)
        }

        func pauseSession() {
            session.pause()
        }

        func session(_ session: ARSession, didUpdate frame: ARFrame) {
            Task {
                await objectDetectionActor.enqueueFrame(frame)
            }
            // The actor will process the frame and then update detectedObjectsStore
            // via a MainActor.run call.
        }
    }
    