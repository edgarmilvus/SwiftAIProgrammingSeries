
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import OpenAISwift // Hypothetical SDK

/// Represents the state of the Smart Home environment.
/// We use an `actor` to ensure that multiple concurrent tool calls 
/// do not cause data races when modifying device states.
@available(iOS 18.0, *)
actor SmartHomeManager {
    private var deviceStates: [String: Bool] = [
        "kitchen_lights": false,
        "living_room_lights": false
    ]

    /// Toggles the state of a specific device.
    /// - Parameters:
    ///   - deviceId: The unique identifier for the device.
    ///   - turnOn: A boolean indicating the desired state.
    /// - Returns: A string describing the result of the operation.
    func setDeviceState(deviceId: String, turnOn: Bool) -> String {
        guard deviceStates.keys.contains(deviceId) else {
            return "Error: Device '\(deviceId)' not found."
        }
        
        deviceStates[deviceId] = turnOn
        let stateString = turnOn ? "on" : "off"
        print("[Hardware] Setting \(deviceId) to \(stateString)")
        return "Successfully turned \(stateString) the \(deviceId)."
    }
}

/// A structure representing the definition of a tool that can be passed to the LLM.
/// This conforms to the OpenAI Tool schema requirements.
struct ToolDefinition: Codable, Sendable {
    let type: String = "function"
    let function: FunctionDetails

    struct FunctionDetails: Codable, Sendable {
        let name: String
        let description: String
        let parameters: JSONSchema
    }

    struct JSONSchema: Codable, Sendable {
        let type: String = "object"
        let properties: [String: Property]
        let required: [String]
    }

    struct Property: Codable, Sendable {
        let type: String
        let description: String
    }
}

/// The Orchestrator manages the interaction between the User, the LLM, and the Local Tools.
@available(iOS 18.0, *)
@MainActor
class VoiceAssistantOrchestrator: ObservableObject {
    private let smartHome = SmartHomeManager()
    private let openAIClient = OpenAISwiftClient(apiKey: "YOUR_API_KEY")
    
    /// The history of the conversation, required for context in multi-turn dialogues.
    @Published var conversationHistory: [ChatMessage] = []
    @Published var isProcessing: Bool = false

    /// Defines the available tools for the LLM.
    /// This is the "Manual" we provide to the AI.
    private var availableTools: [ToolDefinition] {
        [
            ToolDefinition(function: .init(
                name: "set_device_state",
                description: "Turns a smart home device on or off.",
                parameters: .init(
                    properties: [
                        "deviceId": .init(type: "string", description: "The ID of the device, e.g., 'kitchen_lights'"),
                        "turnOn": .init(type: "boolean", description: "True to turn on, false to turn off")
                    ],
                    required: ["deviceId", "turnOn"]
                )
            ))
        ]
    }

    /// Processes user input and manages the tool-calling loop.
    /// - Parameter userInput: The natural language string from the user.
    func processUserRequest(_ userInput: String) async {
        isProcessing = true
        
        // 1. Add user message to history
        let userMsg = ChatMessage(role: .user, content: userInput)
        conversationHistory.append(userMsg)

        do {
            // 2. Initial call to LLM
            try await runConversationLoop()
        } catch {
            print("Error in conversation loop: \(error)")
        }
        
        isProcessing = false
    }

    /// The core recursive loop that handles the "Think -> Act -> Observe" cycle.
    private func runConversationLoop() async throws {
        // 3. Request completion from LLM with tool definitions
        let response = try await openAIClient.chatCompletions(
            messages: conversationHistory,
            tools: availableTools
        )

        guard let message = response.choices.first?.message else { return }
        conversationHistory.append(message)

        // 4. Check if the LLM wants to call a tool
        if let toolCalls = message.toolCalls {
            for call in toolCalls {
                try await handleToolCall(call)
            }
            
            // 5. After executing tools, call the LLM again to summarize the results
            try await runConversationLoop()
        } else {
            // If no tool calls, the LLM has provided a final text response.
            // The UI will update automatically via @Published.
        }
    }

    /// Parses the tool call and executes the corresponding Swift code.
    private func handleToolCall(_ call: ToolCall) async throws {
        // In a real app, use a registry or a switch statement to map names to functions.
        if call.function.name == "set_device_state" {
            // Parse the arguments provided by the LLM
            let args = try JSONDecoder().decode(SetDeviceArguments.self, from: call.function.arguments)
            
            // 6. Execute the actual deterministic code on the Actor
            let result = await smartHome.setDeviceState(deviceId: args.deviceId, turnOn: args.turnOn)
            
            // 7. Feed the result back to the conversation history as a 'tool' role message
            let toolResultMessage = ChatMessage(
                role: .tool,
                content: result,
                toolCallId: call.id
            )
            conversationHistory.append(toolResultMessage)
        }
    }
}

/// Decodable structure for the arguments generated by the LLM.
struct SetDeviceArguments: Codable {
    let deviceId: String
    let turnOn: Bool
}
