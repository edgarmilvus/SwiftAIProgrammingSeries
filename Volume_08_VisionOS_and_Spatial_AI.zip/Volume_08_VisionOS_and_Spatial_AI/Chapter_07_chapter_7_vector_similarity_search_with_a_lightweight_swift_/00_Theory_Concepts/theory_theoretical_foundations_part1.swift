
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Accelerate

/// A representation of a high-dimensional vector optimized for SIMD operations.
/// We use @available(iOS 18.0, *) to leverage the latest concurrency and observation features.
@available(iOS 18.0, *)
public struct EmbeddingVector: Sendable, Identifiable {
    public let id: UUID
    public let values: [Float]
    public let dimension: Int

    public init(id: UUID = UUID(), values: [Float]) {
        self.id = id
        self.values = values
        self.dimension = values.count
    }
}

/// The core engine for performing similarity searches.
/// We use an 'actor' to ensure that the index remains thread-safe during 
/// concurrent insertions and queries.
@available(iOS 18.0, *)
public actor VectorIndex {
    private var storage: [EmbeddingVector] = []
    
    public init() {}

    /// Adds a new vector to the index.
    /// This is an isolated mutation, safe from data races.
    public func insert(_ vector: EmbeddingVector) {
        storage.append(vector)
    }

    /// Performs a Cosine Similarity search.
    /// This uses the Accelerate framework for hardware-accelerated math.
    public func search(query: EmbeddingVector, k: Int) async -> [EmbeddingVector] {
        // In a real-world implementation, we would use a more advanced 
        // indexing strategy (like HNSW). For this lightweight version,
        // we perform a highly optimized linear scan.
        
        let results = storage.map { candidate in
            let score = cosineSimilarity(query.values, candidate.values)
            return (candidate, score)
        }
        .sorted { $0.1 > $1.1 } // Sort by highest similarity
        .prefix(k)
        .map { $0.0 }

        return Array(results)
    }

    /// Mathematical implementation of Cosine Similarity using Accelerate.
    /// This is the "Under the Hood" part where we bypass standard loops
    /// for SIMD-accelerated BLAS operations.
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        guard a.count == b.count else { return 0 }
        
        // Dot Product: sum(a[i] * b[i])
        var dotProduct: Float = 0
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        
        // Magnitude of A: sqrt(sum(a[i]^2))
        var magnitudeA: Float = 0
        vDSP_svesq(a, 1, &magnitudeA, vDSP_Length(a.count))
        magnitudeA = sqrt(magnitudeA)
        
        // Magnitude of B: sqrt(sum(b[i]^2))
        var magnitudeB: Float = 0
        vDSP_svesq(b, 1, &magnitudeB, vDSP_Length(b.count))
        magnitudeB = sqrt(magnitudeB)
        
        guard magnitudeA > 0 && magnitudeB > 0 else { return 0 }
        
        return dotProduct / (magnitudeA * magnitudeB)
    }
}
