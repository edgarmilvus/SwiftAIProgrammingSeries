
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import OSLog
import MetricKit

/// Represents the various types of failures specific to AI inference.
/// Unlike standard crashes, these represent "Semantic Failures."
enum AIInferenceError: Error, Sendable {
    case modelLoadingFailed(reason: String)
    case latencyThresholdExceeded(duration: TimeInterval)
    case malformedResponse(details: String)
    case resourceExhaustion(memoryUsage: UInt64)
    case thermalThrottlingDetected
}

/// A metric snapshot representing the health of a specific AI model version.
struct InferenceMetric: Sendable {
    let modelVersion: String
    let latency: TimeInterval
    let memoryUsageBytes: UInt64
    let errorCount: Int
    let timestamp: Date
}

/// The `InferenceHealthMonitor` is a Swift 6 Actor responsible for 
/// aggregating telemetry data in a thread-safe manner.
/// Using an actor prevents data races when multiple concurrent inference 
/// tasks report metrics simultaneously.
@available(iOS 18.0, *)
actor InferenceHealthMonitor {
    private var metricsHistory: [InferenceMetric] = []
    private let maxHistoryItems = 100
    private let logger = Logger(subsystem: "com.ai.app.telemetry", category: "HealthMonitor")

    /// Records a new metric snapshot.
    /// - Parameter metric: The collected data from an inference session.
    func record(_ metric: InferenceMetric) {
        metricsHistory.append(metric)
        if metricsHistory.count > maxHistoryItems {
            metricsHistory.removeFirst()
        }
        logger.debug("Recorded metric for \(metric.modelVersion): \(metric.latency)s")
    }

    /// Calculates the error rate for a specific model version.
    /// - Parameter version: The model version string to analyze.
    /// - Returns: A percentage (0.0 - 1.0) of failed inferences.
    func errorRate(for version: String) -> Double {
        let versionMetrics = metricsHistory.filter { $0.modelVersion == version }
        guard !versionMetrics.isEmpty else { return 0.0 }
        
        let errors = versionMetrics.filter { $0.errorCount > 0 }.count
        return Double(errors) / Double(versionMetrics.count)
    }

    /// Calculates the average latency for a specific model version.
    /// - Parameter version: The model version string to analyze.
    /// - Returns: Average latency in seconds.
    func averageLatency(for version: String) -> TimeInterval {
        let versionMetrics = metricsHistory.filter { $0.modelVersion == version }
        guard !versionMetrics.isEmpty else { return 0.0 }
        
        let totalLatency = versionMetrics.reduce(0.0) { $0 + $1.latency }
        return totalLatency / Double(versionMetrics.count)
    }
}

/// Defines the configuration for a phased rollout.
struct RolloutConfiguration: Sendable {
    let canaryVersion: String
    let stableVersion: String
    let rolloutPercentage: Double // 0.0 to 1.0
    let errorThreshold: Double    // Max allowed error rate before rollback
    let latencyThreshold: TimeInterval // Max allowed avg latency
}

/// The `PhasedRolloutController` manages which model version a user should use
/// and monitors the health of the canary version to decide on rollbacks.
@available(iOS 18.0, *)
final class PhasedRolloutController: Sendable {
    private let config: RolloutConfiguration
    private let healthMonitor: InferenceHealthMonitor
    private let logger = Logger(subsystem: "com.ai.app.rollout", category: "Controller")
    
    // Using an Atomic-like pattern via a protected state if needed, 
    // but for this example, we rely on the configuration and monitor.
    
    init(config: RolloutConfiguration, healthMonitor: InferenceHealthMonitor) {
        self.config = config
        self.healthMonitor = healthMonitor
    }

    /// Determines which model version to serve to the current user.
    /// In a real app, this would involve a persistent identifier (e.g., UUID)
    /// to ensure a user doesn't flip-flop between versions.
    func selectModelVersion(for userID: UUID) -> String {
        // Deterministic rollout: use the hash of the userID to decide
        let hash = abs(userID.hashValue % 100)
        let threshold = config.rolloutPercentage * 100
        
        if Double(hash) < threshold {
            logger.info("User \(userID) assigned to Canary: \(self.config.canaryVersion)")
            return config.canaryVersion
        } else {
            logger.info("User \(userID) assigned to Stable: \(self.config.stableVersion)")
            return config.stableVersion
        }
    }

    /// Performs a health check on the canary version.
    /// If the canary version exceeds error or latency thresholds, 
    /// it signals that the rollout should be aborted.
    /// - Returns: A boolean indicating if the canary is healthy.
    func checkCanaryHealth() async -> Bool {
        let errorRate = await healthMonitor.errorRate(for: config.canaryVersion)
        let avgLatency = await healthMonitor.averageLatency(for: config.canaryVersion)
        
        logger.info("Health Check - Error Rate: \(errorRate), Avg Latency: \(avgLatency)s")
        
        if errorRate > config.errorThreshold {
            logger.critical("CRITICAL: Canary error rate \(errorRate) exceeded threshold!")
            return false
        }
        
        if avgLatency > config.latencyThreshold {
            logger.warning("WARNING: Canary latency \(avgLatency)s exceeded threshold!")
            return false
        }
        
        return true
    }
}

/// A high-level component representing an AI-powered feature (e.g., Voice Assistant).
@available(iOS 18.0, *)
class AIVoiceAssistant {
    private let rolloutController: PhasedRolloutController
    private let healthMonitor: InferenceHealthMonitor
    private let userID: UUID
    
    init(rolloutController: PhasedRolloutController, healthMonitor: InferenceHealthMonitor, userID: UUID) {
        self.rolloutController = rolloutController
        self.healthMonitor = healthMonitor
        self.userID = userID
    }
    
    /// Simulates an AI inference task.
    func processVoiceCommand(_ command: String) async throws -> String {
        let version = rolloutController.selectModelVersion(for: userID)
        let startTime = Date()
        
        // Check if we should perform an emergency rollback before starting
        let isHealthy = await rolloutController.checkCanaryHealth()
        let activeVersion = isHealthy ? version : "STABLE_FALLBACK"
        
        do {
            // Simulate AI Inference
            let response = try await performInference(command: command, modelVersion: activeVersion)
            
            // Record successful metric
            let duration = Date().timeIntervalSince(startTime)
            await healthMonitor.record(InferenceMetric(
                modelVersion: activeVersion,
                latency: duration,
                memoryUsageBytes: 500_000_000, // Mock 500MB
                errorCount: 0,
                timestamp: Date()
            ))
            
            return response
        } catch {
            // Record failure metric
            let duration = Date().timeIntervalSince(startTime)
            await healthMonitor.record(InferenceMetric(
                modelVersion: activeVersion,
                latency: duration,
                memoryUsageBytes: 500_000_000,
                errorCount: 1,
                timestamp: Date()
            ))
            throw error
        }
    }
    
    /// Private method simulating the actual Core ML or API call.
    private func performInference(command: String, modelVersion: String) async throws -> String {
        // Simulate network/compute latency
        try await Task.sleep(for: .seconds(Double.random(in: 0.5...2.0)))
        
        // Simulate a "Canary Failure" for demonstration purposes
        if modelVersion.contains("v1.1") && Double.random(in: 0...1) < 0.3 {
            throw AIInferenceError.malformedResponse(details: "LLM returned non-JSON output")
        }
        
        return "Processed '\(command)' using \(modelVersion)"
    }
}

// MARK: - Execution Simulation

@main
struct AIAppRunner {
    static func main() async {
        let monitor = InferenceHealthMonitor()
        let config = RolloutConfiguration(
            canaryVersion: "v1.1-canary",
            stableVersion: "v1.0-stable",
            rolloutPercentage: 0.5, // 50% rollout for testing
            errorThreshold: 0.15,   // 15% error rate max
            latencyThreshold: 1.5   // 1.5s avg latency max
        )
        
        let controller = PhasedRolloutController(config: config, healthMonitor: monitor)
        let userA = UUID()
        let assistant = AIVoiceAssistant(rolloutController: controller, healthMonitor: monitor, userID: userA)
        
        print("🚀 Starting AI Assistant Simulation...")
        
        // Simulate 20 user interactions to observe telemetry and rollback
        for i in 1...20 {
            print("\n--- Interaction \(i) ---")
            do {
                let response = try await assistant.processVoiceCommand("Hello, how are you?")
                print("✅ Response: \(response)")
            } catch {
                print("❌ Error: \(error)")
            }
            
            // Small delay between interactions
            try? await Task.sleep(for: .milliseconds(200))
        }
        
        print("\n--- Final Telemetry Report ---")
        let canaryErrorRate = await monitor.errorRate(for: "v1.1-canary")
        let stableErrorRate = await monitor.errorRate(for: "v1.0-stable")
        print("Canary Error Rate: \(canaryErrorRate * 100)%")
        print("Stable Error Rate: \(stableErrorRate * 100)%")
    }
}
