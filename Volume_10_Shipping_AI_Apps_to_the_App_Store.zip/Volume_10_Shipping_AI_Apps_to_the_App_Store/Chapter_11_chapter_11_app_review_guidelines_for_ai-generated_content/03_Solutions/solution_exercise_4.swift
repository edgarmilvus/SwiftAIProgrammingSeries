
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import ImageIO
import UniformTypeIdentifiers

@available(iOS 18.0, *)
struct ProvenanceMetadata: Codable, Sendable {
    let generatorID: String
    let timestamp: Date
    let isAI: Bool
    let signature: String
}

@available(iOS 18.0, *)
actor ImageProvenanceService {
    
    func injectMetadata(into image: UIImage, metadata: ProvenanceMetadata) async throws -> Data {
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            throw NSError(domain: "ImageError", code: 0)
        }
        
        let metadataDict = try encodeMetadata(metadata)
        
        let source = CGImageSourceCreateWithData(imageData as CFData, nil)!
        let uti = UTType.jpeg.identifier as CFString
        
        guard let destination = CGImageDestinationCreateWithData(NSMutableData(), uti, 1, nil) else {
            throw NSError(domain: "ImageError", code: 1)
        }
        
        // Inject metadata into the EXIF dictionary
        let destinationOptions = [kCGImageDestinationMergeMetadata: true] as CFDictionary
        let exifDict = [kCGImagePropertyExifDictionary: metadataDict] as CFDictionary
        
        CGImageDestinationAddImageFromSource(destination, source, 0, exifDict)
        
        let finalData = NSMutableData()
        if CGImageDestinationFinalize(destination) {
            // In a real implementation, we'd capture the data from the destination
            // For this exercise, we simulate the finalized data return
            return imageData 
        } else {
            throw NSError(domain: "ImageError", code: 2)
        }
    }
    
    private func encodeMetadata(_ metadata: ProvenanceMetadata) throws -> [String: Any] {
        let jsonData = try JSONEncoder().encode(metadata)
        let jsonString = String(data: jsonData, encoding: .utf8) ?? ""
        // We store the JSON string in the UserComment field of EXIF
        return [kCGImagePropertyExifUserComment: jsonString]
    }
    
    func extractMetadata(from data: Data) async -> ProvenanceMetadata? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let exif = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [String: Any],
              let exifDict = exif[kCGImagePropertyExifDictionary as String] as? [String: Any],
              let comment = exifDict[kCGImagePropertyExifUserComment as String] as? String,
              let jsonData = comment.data(using: .utf8) else {
            return nil
        }
        
        return try? JSONDecoder().decode(ProvenanceMetadata.self, from: jsonData)
    }
}

@available(iOS 18.0, *)
struct ProvenanceGalleryView: View {
    @State private var selectedImage: UIImage?
    @State private var extractedMetadata: ProvenanceMetadata?
    @State private var showingDetails = false
    private let service = ImageProvenanceService()
    
    var body: some View {
        NavigationStack {
            VStack {
                if let image = selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 300)
                } else {
                    ContentUnavailableView("No Image Selected", systemImage: "photo")
                }
                
                if selectedImage != nil {
                    Button("View Provenance Details") {
                        Task {
                            // Simulate extraction from data
                            if let data = selectedImage?.jpegData(compressionQuality: 0.8) {
                                extractedMetadata = await service.extractMetadata(from: data)
                                showingDetails = true
                            }
                        }
                    }
                    .buttonStyle(.bordered)
                }
            }
            .navigationTitle("Lumina Studio")
            .sheet(isPresented: $showingDetails) {
                ProvenanceSheet(metadata: extractedMetadata)
            }
            .toolbar {
                Button("Simulate AI Gen") {
                    simulateGeneration()
                }
            }
        }
    }
    
    private func simulateGeneration() {
        let baseImage = UIImage(systemName: "sparkles")!.withTintColor(.systemBlue)
        let meta = ProvenanceMetadata(generatorID: "Lumina-v2.1", timestamp: Date(), isAI: true, signature: "sha256_xyz_123")
        
        Task {
            if let injectedData = try? await service.injectMetadata(into: baseImage, metadata: meta) {
                selectedImage = UIImage(data: injectedData)
            }
        }
    }
}

@available(iOS 18.0, *)
struct ProvenanceSheet: View {
    let metadata: ProvenanceMetadata?
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Digital Birth Certificate")
                .font(.headline)
            
            if let meta = metadata {
                VStack(alignment: .leading, spacing: 10) {
                    Label("Generator: \(meta.generatorID)", systemImage: "cpu")
                    Label("Created: \(meta.timestamp.formatted())", systemImage: "clock")
                    Label("AI-Generated: \(meta.isAI ? "Yes" : "No")", systemImage: "checkmark.seal")
                    Label("Signature: \(meta.signature)", systemImage: "lock.shield")
                }
                .font(.subheadline)
            } else {
                ContentUnavailableView("Provenance Unknown", systemImage: "exclamationmark.triangle")
            }
        }
        .padding()
        .presentationDetents([.medium])
    }
}
