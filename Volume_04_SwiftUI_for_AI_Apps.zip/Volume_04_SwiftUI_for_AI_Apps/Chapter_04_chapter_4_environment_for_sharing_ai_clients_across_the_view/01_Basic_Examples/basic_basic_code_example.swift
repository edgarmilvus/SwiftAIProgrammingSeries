
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Foundation // For Task.sleep

// MARK: - 1. Define the AI Client Protocol and Implementation

/// A protocol defining the capabilities of our AI Chat Client.
/// This allows for easy swapping of implementations (e.g., mock, production, different AI models).
protocol AIChatClient: Sendable {
    /// Sends a message to the AI and returns its response.
    /// - Parameter message: The user's message.
    /// - Returns: The AI's generated response.
    func sendMessage(message: String) async throws -> String
}

/// A mock implementation of the AIChatClient for demonstration purposes.
/// It simulates network latency and provides a canned response.
@available(iOS 18.0, *)
final class MockAIChatClient: AIChatClient {
    /// Initializes a new mock AI chat client.
    init() {
        print("MockAIChatClient initialized.")
    }

    /// Simulates sending a message to an AI and receiving a response.
    /// Introduces a delay to mimic network latency.
    func sendMessage(message: String) async throws -> String {
        print("MockAIChatClient received message: '\(message)'")
        // Simulate network delay
        try await Task.sleep(for: .seconds(1.5))

        // Provide a simple, canned response
        return "Hello there! You said: '\(message)'. I'm a mock AI assistant."
    }
}

// MARK: - 2. Create a Custom EnvironmentKey

/// A custom EnvironmentKey to hold our AIChatClient.
/// The `defaultValue` is used if no client is explicitly provided in the environment.
/// For production apps, you might want `fatalError` here to ensure a client is always provided.
@available(iOS 18.0, *)
private struct AIChatClientKey: EnvironmentKey {
    static var defaultValue: any AIChatClient {
        // Provide a default mock client for convenience in development,
        // or a fatalError to ensure it's always explicitly provided.
        MockAIChatClient()
    }
}

// MARK: - 3. Extend EnvironmentValues to Access the Client

/// Extends SwiftUI's EnvironmentValues to provide an easy-to-use property
/// for accessing our AIChatClient.
@available(iOS 18.0, *)
extension EnvironmentValues {
    /// Accessor for the AIChatClient stored in the environment.
    var aiChatClient: any AIChatClient {
        get { self[AIChatClientKey.self] }
        set { self[AIChatClientKey.self] = newValue }
    }
}

// MARK: - 4. Define the Consumer View

/// A view that consumes the AIChatClient from the environment.
/// This represents a part of the UI that needs to interact with the AI.
@available(iOS 18.0, *)
struct ChatView: View {
    // Use @Environment to retrieve the AIChatClient instance.
    // SwiftUI automatically finds the closest provided instance in the hierarchy.
    @Environment(\.aiChatClient) private var aiClient

    @State private var messageInput: String = ""
    @State private var chatHistory: [String] = []
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?

    var body: some View {
        VStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(chatHistory, id: \.self) { message in
                        Text(message)
                            .padding(8)
                            .background(message.hasPrefix("You:") ? Color.blue.opacity(0.2) : Color.green.opacity(0.1))
                            .cornerRadius(10)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            }
            .background(Color.gray.opacity(0.05))
            .cornerRadius(10)
            .padding(.horizontal)

            if isLoading {
                ProgressView("AI is thinking...")
                    .padding()
            }

            if let errorMessage = errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundStyle(.red)
                    .padding()
            }

            HStack {
                TextField("Type your message...", text: $messageInput)
                    .textFieldStyle(.roundedBorder)
                    .padding(.vertical, 5)

                Button("Send") {
                    sendMessage()
                }
                .buttonStyle(.borderedProminent)
                .disabled(messageInput.isEmpty || isLoading)
            }
            .padding()
        }
        .navigationTitle("AI Chat")
    }

    /// Handles sending the message to the AI client and updating the chat history.
    private func sendMessage() {
        let userMessage = messageInput
        chatHistory.append("You: \(userMessage)")
        messageInput = ""
        errorMessage = nil
        isLoading = true

        Task {
            // Ensure UI updates happen on the main actor.
            // @MainActor is crucial when dealing with async operations that affect UI state.
            @MainActor in
            do {
                let aiResponse = try await aiClient.sendMessage(message: userMessage)
                chatHistory.append("AI: \(aiResponse)")
            } catch {
                errorMessage = error.localizedDescription
                print("Error sending message: \(error)")
            } finally {
                isLoading = false
            }
        }
    }
}

// MARK: - 5. Define the Root View that Provides the Client

/// The root view of our application, responsible for providing the AIChatClient
/// to its entire view hierarchy using the `.environment()` modifier.
@available(iOS 18.0, *)
struct ContentView: View {
    // Create a single instance of our AI client.
    // This instance will be shared across the entire hierarchy below this point.
    // For a real app, you might inject a production client here.
    private let chatClient: any AIChatClient = MockAIChatClient()

    var body: some View {
        NavigationView { // Use NavigationView for better navigation title display
            ChatView()
        }
        // Provide the chatClient to the environment.
        // Any descendant view can now access this specific instance.
        .environment(\.aiChatClient, chatClient)
    }
}

// MARK: - App Entry Point

@available(iOS 18.0, *)
@main
struct AIChatApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
