
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import NaturalLanguage

/// Errors related to privacy violations during the audit process.
enum PrivacyViolationError: Error, LocalizedError {
    case highRiskDataDetected(details: String)

    var errorDescription: String? {
        switch self {
        case .highRiskDataDetected(let details):
            return "Privacy Violation: \(details)"
        }
    }
}

/// Represents the risk level of a piece of data.
enum PrivacyRiskLevel: Sendable {
    case low
    case high(reason: String)
}

/// An actor that provides thread-safe logging of privacy audit events.
actor AuditLog {
    private var logs: [String] = []

    func record(input: String, risk: PrivacyRiskLevel, permitted: Bool) {
        let timestamp = Date().formatted(date: .abbreviated, time: .standard)
        let logEntry = "[\(timestamp)] Risk: \(risk) | Permitted: \(permitted) | Content: \(input.prefix(20))..."
        logs.append(logEntry)
        print("AUDIT LOG: \(logEntry)")
    }

    func getLogs() -> [String] { logs }
}

/// The engine responsible for scanning text for PII using NaturalLanguage.
@available(iOS 18.0, *)
struct PrivacyAuditEngine {
    private let logger: AuditLog

    init(logger: AuditLog) {
        self.logger = logger
    }

    /// Scans input for personal names, emails, or phone numbers.
    func analyze(input: String) async -> PrivacyRiskLevel {
        let tagger = NLTagger(tagSchemes: [.nameType])
        tagger.string = input

        var detectedEntities: [String] = []
        
        // Define the schemes we are looking for
        let schemes: [NLTag] = [.personalName, .emailAddress, .phoneNumber]

        tagger.enumerateTags(in: input.startIndex..<input.endIndex, unit: .word, scheme: .nameType, options: [.omitWhitespace, .omitPunctuation]) { tag, range in
            if let tag = tag, schemes.contains(tag) {
                detectedEntities.append(String(input[range]))
            }
            return true
        }

        if !detectedEntities.isEmpty {
            let reason = "Detected: \(detectedEntities.joined(separator: ", "))"
            await logger.record(input: input, risk: .high(reason: reason), permitted: false)
            return .high(reason: reason)
        }

        await logger.record(input: input, risk: .low, permitted: true)
        return .low
    }
}

/// A protocol representing a cloud-based AI provider.
protocol CloudProvider: Sendable {
    func sendToCloud(text: String) async throws -> String
}

/// A concrete implementation of a Cloud Provider that enforces privacy rules.
struct MockCloudProvider: CloudProvider {
    let auditor: PrivacyAuditEngine

    func sendToCloud(text: String) async throws -> String {
        let risk = await auditor.analyze(input: text)
        
        switch risk {
        case .high(let reason):
            throw PrivacyViolationError.highRiskDataDetected(details: reason)
        case .low:
            return "Cloud response to: \(text)"
        }
    }
}

// MARK: - Execution Example
@main
struct PrivacyApp {
    static func main() async {
        let logger = AuditLog()
        let auditor = PrivacyAuditEngine(logger: logger)
        let cloud = MockCloudProvider(auditor: auditor)

        let safeInput = "Hello, how is the weather today?"
        let riskyInput = "Contact me at john.doe@example.com or 555-0199"

        print("--- Testing Safe Input ---")
        do {
            let response = try await cloud.sendToCloud(text: safeInput)
            print("Success: \(response)")
        } catch {
            print("Error: \(error.localizedDescription)")
        }

        print("\n--- Testing Risky Input ---")
        do {
            let _ = try await cloud.sendToCloud(text: riskyInput)
        } catch {
            print("Caught Expected Error: \(error.localizedDescription)")
        }
    }
}
