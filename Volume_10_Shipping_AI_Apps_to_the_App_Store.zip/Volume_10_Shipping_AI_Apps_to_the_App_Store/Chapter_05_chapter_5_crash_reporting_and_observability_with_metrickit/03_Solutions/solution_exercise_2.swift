
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import MetricKit

/// A thread-safe, immutable report representing the energy impact of an AI workload.
struct EnergyReport: Sendable {
    let cpuTime: TimeInterval
    let dischargeCapacity: Double
    let resourceIntensityScore: Double
    let timestamp: Date
}

@available(iOS 18.0, *)
actor TelemetryManager: NSObject, MXMetricManagerDelegate {
    // ... (Previous implementation from Exercise 1) ...

    /// Analyzes the payload to produce a structured EnergyReport.
    private func analyzeEnergyImpact(from payload: MXMetricPayload) -> EnergyReport? {
        guard let cpuMetric = payload.cpuMetric,
              let batteryMetric = payload.batteryMetric else {
            return nil
        }
        
        let cpuTime = cpuMetric.cumulativeCPUUsage
        let discharge = batteryMetric.cumulativeDischargeCapacity
        
        // Heuristic: A higher score indicates higher energy cost per CPU second.
        // In a real scenario, we'd normalize this against the interval duration.
        let intensityScore = discharge / (cpuTime > 0 ? cpuTime : 1.0)
        
        // Threshold Logic
        if cpuTime > 10.0 { // Example: > 10 seconds of CPU time in one interval
            print("⚠️ High Resource Intensity Detected: Potential Thermal Throttling Risk.")
        }
        
        return EnergyReport(
            cpuTime: cpuTime,
            dischargeCapacity: discharge,
            resourceIntensityScore: intensityScore,
            timestamp: Date()
        )
    }

    // Updated didReceive to include analysis
    nonisolated func didReceive(_ payload: MXMetricPayload) {
        Task {
            await self.processPayload(payload)
            if let report = await self.analyzeEnergyImpact(from: payload) {
                await self.logEnergyReport(report)
            }
        }
    }

    private func logEnergyReport(_ report: EnergyReport) {
        print("📊 Energy Report: Score \(report.resourceIntensityScore), Discharge \(report.dischargeCapacity)mAh")
    }
    
    // Placeholder for previous methods to satisfy compiler
    private func processPayload(_ payload: MXMetricPayload) {}
}
