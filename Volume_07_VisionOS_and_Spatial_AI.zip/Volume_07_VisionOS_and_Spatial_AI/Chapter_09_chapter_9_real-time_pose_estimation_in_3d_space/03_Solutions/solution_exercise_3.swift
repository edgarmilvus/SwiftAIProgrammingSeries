
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import ARKit
import RealityKit
import simd

class SquatFormEngine {
    private var angleHistory: [Float] = []
    private let bufferSize = 10
    private let safeAngleRange: ClosedRange<Float> = 90.0...110.0

    /// Calculates angle at pivot using the dot product formula
    func calculateJointAngle(pivot: simd_float3, end1: simd_float3, end2: simd_float3) -> Float {
        // 1. Create vectors and normalize them
        let u = simd_normalize(end1 - pivot)
        let v = simd_normalize(end2 - pivot)

        // 2. Dot product: u · v = |u||v| cos(theta). Since normalized, |u| and |v| = 1.
        let dotProduct = simd_dot(u, v)
        
        // 3. Clamp dot product to avoid NaN from floating point errors in acos
        let clampedDot = max(-1.0, min(1.0, dotProduct))
        
        // 4. Convert radians to degrees
        return acos(clampedDot) * (180.0 / .pi)
    }

    func update(hip: simd_float3, knee: simd_float3, ankle: simd_float3) -> Bool {
        let currentAngle = calculateJointAngle(pivot: knee, end1: hip, end2: ankle)
        
        // 5. Temporal Smoothing: Moving Average Filter
        angleHistory.append(currentAngle)
        if angleHistory.count > bufferSize { angleHistory.removeFirst() }
        
        let smoothedAngle = angleHistory.reduce(0, +) / Float(angleHistory.count)
        
        // 6. Logic Gate: Is the form incorrect?
        return !safeAngleRange.contains(smoothedAngle)
    }
}

// Usage within a RealityKit system
@MainActor
func handleSquatFeedback(engine: SquatFormEngine, kneePosition: simd_float3, isIncorrect: Bool, scene: Scene) {
    // In a real implementation, you would find or create a ParticleEmitterComponent
    // and toggle its emission based on 'isIncorrect'
    if isIncorrect {
        print("⚠️ FORM WARNING: Knee angle out of bounds!")
        // triggerRedParticles(at: kneePosition)
    } else {
        // triggerGreenParticles(at: kneePosition)
    }
}
