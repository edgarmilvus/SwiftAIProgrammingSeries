
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import RoomPlan
import Observation

@Observable
@MainActor
class RoomCaptureManager: NSObject, RoomCaptureSessionDelegate {
    var isScanning = false
    var capturedRoom: CapturedRoom?
    var errorMessage: String?
    
    // The session must be managed on the @MainActor for UI synchronization
    private var session = RoomCaptureSession()
    
    override init() {
        super.init()
        session.delegate = self
    }
    
    func startSession() {
        // Check for LiDAR availability (implicitly handled by RoomPlan, 
        // but good practice to catch errors)
        session.run(configuration: RoomCaptureSession.Configuration())
        isScanning = true
        errorMessage = nil
    }
    
    func stopSession() {
        session.stop()
        isScanning = false
    }
    
    // MARK: - RoomCaptureSessionDelegate
    
    func captureSession(_ session: RoomCaptureSession, didCompleteWith room: CapturedRoom) {
        self.capturedRoom = room
        self.isScanning = false
        
        // Requirement: Print a summary of the room's contents
        let walls = room.elements.filter { $0.category == .wall }.count
        let windows = room.elements.filter { $0.category == .window }.count
        let doors = room.elements.filter { $0.category == .door }.count
        
        print("--- Scan Complete ---")
        print("Detected \(walls) walls, \(windows) windows, and \(doors) doors.")
        print("---------------------")
    }
    
    func captureSession(_ session: RoomCaptureSession, didFailWithError error: Error) {
        self.isScanning = false
        self.errorMessage = error.localizedDescription
        print("Capture Session Error: \(error.localizedDescription)")
    }
}

struct RoomCaptureViewContainer: UIViewRepresentable {
    let session: RoomCaptureSession
    
    func makeUIView(context: Context) -> RoomCaptureView {
        let view = RoomCaptureView(frame: .zero)
        view.session = session
        return view
    }
    
    func updateUIView(_ uiView: RoomCaptureView, context: Context) {}
}

struct BlueprintArchitectView: View {
    @State private var manager = RoomCaptureManager()
    
    var body: some View {
        ZStack {
            if manager.isScanning {
                RoomCaptureViewContainer(session: manager.session)
                    .ignoresSafeArea()
            } else {
                VStack(spacing: 20) {
                    Text("Blueprint Architect")
                        .font(.largeTitle)
                    
                    if let error = manager.errorMessage {
                        Text(error)
                            .foregroundColor(.red)
                    }
                    
                    Button(manager.capturedRoom != nil ? "New Scan" : "Start Scanning") {
                        if manager.capturedRoom != nil { manager.capturedRoom = nil }
                        manager.startSession()
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                }
            }
        }
        .animation(.default, value: manager.isScanning)
    }
}
