
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

// Example: Using an Actor for a Model Registry
import Foundation
import CreateML

@available(macOS 10.15, *)
struct ModelMetadata: Codable, Sendable { // Make it Sendable for actor isolation
    let version: Int
    let trainingDate: Date
    let accuracy: Double
    let modelPath: URL
    // ... other relevant metadata
}

@available(macOS 10.15, *)
actor ModelRegistry {
    private var registeredModels: [String: [ModelMetadata]] = [:] // Key: modelName, Value: list of versions
    private var currentBestModel: [String: ModelMetadata] = [:]

    func registerModel(name: String, metadata: ModelMetadata) {
        var modelsForName = registeredModels[name, default: []]
        modelsForName.append(metadata)
        registeredModels[name] = modelsForName.sorted { $0.version > $1.version } // Keep sorted by version

        // Update current best if this model is better
        if let currentBest = currentBestModel[name] {
            if metadata.accuracy > currentBest.accuracy {
                currentBestModel[name] = metadata
                print("New best model for \(name): Version \(metadata.version) with accuracy \(metadata.accuracy)")
            }
        } else {
            currentBestModel[name] = metadata
            print("First model registered for \(name): Version \(metadata.version) with accuracy \(metadata.accuracy)")
        }
    }

    func getLatestModel(name: String) -> ModelMetadata? {
        return registeredModels[name]?.first
    }

    func getCurrentBestModel(name: String) -> ModelMetadata? {
        return currentBestModel[name]
    }
    
    // Example of a shared state that needs actor protection
    func updateModelPath(name: String, version: Int, newPath: URL) {
        if var models = registeredModels[name] {
            if let index = models.firstIndex(where: { $0.version == version }) {
                var updatedMetadata = models[index]
                updatedMetadata = ModelMetadata(
                    version: updatedMetadata.version,
                    trainingDate: updatedMetadata.trainingDate,
                    accuracy: updatedMetadata.accuracy,
                    modelPath: newPath // Update the path
                )
                models[index] = updatedMetadata
                registeredModels[name] = models
                print("Updated path for model \(name) v\(version) to \(newPath.path)")
            }
        }
    }
}
