
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 18.0, macOS 15.0, *)
class SearchSuggester {
    private let catalog: [String]
    // Cache for pre-computed embeddings for catalog items
    private var catalogEmbeddings: [String: [Double]] = [:]
    private let embeddingModel: NLEmbedding?
    private let language: NLLanguage

    /// Initializes the SearchSuggester with a catalog of terms and pre-computes their embeddings.
    /// - Parameters:
    ///   - catalog: An array of strings representing the available suggestions (e.g., product categories).
    ///   - language: The natural language for the embedding model.
    init(catalog: [String], language: NLLanguage) {
        self.catalog = catalog
        self.language = language
        self.embeddingModel = NLEmbedding.wordEmbedding(for: language)

        if self.embeddingModel == nil {
            print("Warning: NLEmbedding word model not available for \(language.rawValue). Search suggestions will be limited.")
            return
        }

        // Pre-computation of catalog embeddings:
        // This is done during initialization to improve performance for subsequent search queries.
        for item in catalog {
            if let itemEmbedding = self.averageWordEmbedding(for: item) {
                self.catalogEmbeddings[item] = itemEmbedding
            } else {
                print("Could not generate embedding for catalog item: \(item)")
            }
        }
    }

    /// Generates an average word embedding for a given text (e.g., a search query or catalog item).
    /// This is a helper function, similar to Exercise 2.
    /// - Parameter text: The text to embed.
    /// - Returns: An array of Doubles representing the averaged embedding, or nil.
    private func averageWordEmbedding(for text: String) -> [Double]? {
        guard let embeddingModel = self.embeddingModel else { return nil }

        let tokenizer = NLTokenizer(unit: .word)
        tokenizer.string = text

        var sumEmbedding: [Double]? = nil
        var wordCount = 0

        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
            let word = String(text[tokenRange])
            if let currentWordEmbedding = embeddingModel.embedding(for: word) {
                if sumEmbedding == nil {
                    sumEmbedding = Array(repeating: 0.0, count: currentWordEmbedding.count)
                }
                for i in 0..<currentWordEmbedding.count {
                    sumEmbedding?[i] += currentWordEmbedding[i]
                }
                wordCount += 1
            }
            return true
        }

        guard let finalSumEmbedding = sumEmbedding, wordCount > 0 else { return nil }
        return finalSumEmbedding.map { $0 / Double(wordCount) }
    }

    /// Provides semantically related search suggestions for a given query.
    /// - Parameters:
    ///   - query: The user's search query.
    ///   - topN: The maximum number of suggestions to return.
    ///   - threshold: A minimum similarity score for a suggestion to be included.
    /// - Returns: An array of suggested terms, sorted by similarity in descending order.
    func suggest(for query: String, topN: Int, threshold: Double) -> [String] {
        guard let embeddingModel = self.embeddingModel else {
            print("Embedding model not available. Cannot provide suggestions.")
            return []
        }
        
        // Generate embedding for the user's query
        guard let queryEmbedding = self.averageWordEmbedding(for: query) else {
            print("Could not generate embedding for query: \(query)")
            return []
        }

        var suggestions: [(term: String, score: Double)] = []

        // Compare query embedding with all pre-computed catalog embeddings
        for (term, termEmbedding) in catalogEmbeddings {
            let score = embeddingModel.similarity(for: queryEmbedding, to: termEmbedding)
            if score >= threshold { // Filter by similarity threshold
                suggestions.append((term: term, score: score))
            }
        }

        // Sort by score (descending) and return the top N terms
        return suggestions.sorted { $0.score > $1.score }.prefix(topN).map { $0.term }
    }
}

// MARK: - Example Usage
@available(iOS 18.0, macOS 15.0, *)
func demonstrateSearchSuggester() {
    print("\n--- Exercise 3: Dynamic Search Suggestions ---")

    let productCatalog = [
        "running shoes", "athletic wear", "smartphones", "laptops", "headphones",
        "wireless earbuds", "kitchen appliances", "fitness trackers", "gaming consoles",
        "smart home devices", "digital cameras", "garden tools", "outdoor camping gear"
    ]

    let suggester = SearchSuggester(catalog: productCatalog, language: .english)

    let queries = [
        "footwear for exercise",
        "mobile phone",
        "listening to music",
        "cooking gadgets",
        "something for camping",
        "fast computer",
        "picture taking"
    ]

    for query in queries {
        let suggestions = suggester.suggest(for: query, topN: 3, threshold: 0.5)
        print("\nQuery: \"\(query)\"")
        if suggestions.isEmpty {
            print("  No relevant suggestions found.")
        } else {
            print("  Suggestions:")
            for (index, suggestion) in suggestions.enumerated() {
                // To show score, we'd need to re-calculate or store it with the suggestion.
                // For demonstration, let's re-calculate the top suggestion's score.
                let queryEmbedding = suggester.averageWordEmbedding(for: query)!
                let suggestionEmbedding = suggester.averageWordEmbedding(for: suggestion)!
                let score = suggester.embeddingModel!.similarity(for: queryEmbedding, to: suggestionEmbedding)
                print("    \(index + 1). \(suggestion) (Score: \(score, specifier: "%.4f"))")
            }
        }
    }
}

// Call the demonstration function
// demonstrateSearchSuggester()
