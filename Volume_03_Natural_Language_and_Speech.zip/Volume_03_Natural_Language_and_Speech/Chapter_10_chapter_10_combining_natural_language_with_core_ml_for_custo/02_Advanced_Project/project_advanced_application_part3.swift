
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
class DocumentScannerViewModel: ObservableObject {
    @Published var analysisResult: DocumentAnalysisResult?
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private var analysisService: DocumentAnalysisService?

    init() {
        do {
            self.analysisService = try DocumentAnalysisService()
        } catch {
            self.errorMessage = (error as? DocumentAnalysisError)?.errorDescription ?? error.localizedDescription
            print("Error initializing DocumentAnalysisService: \(self.errorMessage ?? "unknown")")
        }
    }

    /// Simulates scanning a document image and initiating the analysis.
    /// In a real app, `documentImage` would come from `UIImagePickerController` or `PHPickerViewController`.
    /// - Parameter documentImage: The `CGImage` representation of the scanned document.
    func scanDocument(documentImage: CGImage) {
        guard let service = analysisService else {
            errorMessage = "Document analysis service not initialized."
            return
        }

        isLoading = true
        errorMessage = nil
        analysisResult = nil

        Task {
            do {
                let result = try await service.analyzeDocument(image: documentImage)
                DispatchQueue.main.async {
                    self.analysisResult = result
                    self.isLoading = false
                }
            } catch {
                DispatchQueue.main.async {
                    self.errorMessage = (error as? DocumentAnalysisError)?.errorDescription ?? error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }

    /// Helper function to create a dummy image for demonstration purposes.
    /// In a real app, this would be a photo taken by the user.
    func createDummyImage() -> CGImage? {
        // This is a very basic way to get a CGImage from a string.
        // In a real app, you'd convert a UIImage or NSImage to CGImage.
        #if canImport(UIKit)
        if let image = UIImage(systemName: "doc.text.fill") { // Example system icon
            return image.cgImage
        }
        #elseif canImport(AppKit)
        if let image = NSImage(systemSymbolName: "doc.text.fill", accessibilityDescription: nil) {
            var rect = CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height)
            return image.cgImage(forProposedRect: &rect, context: nil, hints: nil)
        }
        #endif
        return nil
    }
}

// Example usage in an hypothetical SwiftUI View:
/*
import SwiftUI

@available(iOS 18.0, macOS 15.0, *)
struct DocumentScannerView: View {
    @StateObject private var viewModel = DocumentScannerViewModel()

    var body: some View {
        VStack {
            if viewModel.isLoading {
                ProgressView("Analyzing Document...")
            } else if let result = viewModel.analysisResult {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Document Type: \(result.documentType.rawValue)")
                        .font(.headline)
                    Text("Confidence: \(result.confidence ?? 0.0, specifier: "%.2f")")
                        .font(.subheadline)
                    Text("Extracted Text:")
                        .font(.subheadline)
                    Text(result.extractedText.prefix(200) + "...") // Show a preview
                        .font(.caption)
                        .lineLimit(5)
                    
                    if !result.detectedDates.isEmpty {
                        Text("Detected Dates:")
                            .font(.subheadline)
                        ForEach(result.detectedDates, id: \.self) { date in
                            Text(date, style: .date)
                        }
                    }
                    if !result.detectedAmounts.isEmpty {
                        Text("Detected Amounts:")
                            .font(.subheadline)
                        ForEach(result.detectedAmounts.sorted(), id: \.self) { amount in
                            Text(amount as NSNumber, formatter: Self.currencyFormatter)
                        }
                    }
                }
                .padding()
                .background(Color.green.opacity(0.1))
                .cornerRadius(8)
            } else if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
            }

            Button("Scan Document (Simulated)") {
                if let dummyImage = viewModel.createDummyImage() {
                    viewModel.scanDocument(documentImage: dummyImage)
                } else {
                    viewModel.errorMessage = "Could not create dummy image for simulation."
                }
            }
            .padding()
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
    
    // Formatter for displaying currency amounts
    private static let currencyFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current // Use current locale for currency symbol
        return formatter
    }()
}
*/
