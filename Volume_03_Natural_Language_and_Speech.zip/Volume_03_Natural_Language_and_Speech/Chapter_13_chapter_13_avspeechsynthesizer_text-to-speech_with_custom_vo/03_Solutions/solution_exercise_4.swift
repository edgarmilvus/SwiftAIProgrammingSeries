
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import AVFoundation

// MARK: - ContentReaderDelegate Protocol

protocol ContentReaderDelegate: AnyObject {
    /// Called when a new range of the original text is about to be spoken.
    /// - Parameters:
    ///   - reader: The ContentReader instance.
    ///   - globalRange: The NSRange of the text being spoken within the *original full content string*.
    ///   - utterance: The AVSpeechUtterance currently being processed.
    func contentReader(_ reader: ContentReader, willSpeakRange globalRange: NSRange, for utterance: AVSpeechUtterance)
    
    /// Called when the content reader finishes speaking all utterances.
    func contentReaderDidFinishReading(_ reader: ContentReader)
    
    /// Called when the content reader is stopped or cancelled.
    func contentReaderDidStopReading(_ reader: ContentReader)
}

// MARK: - ContentReader

class ContentReader: NSObject {
    private let synthesizer = AVSpeechSynthesizer()
    private var fullContent: String = ""
    private var segmentMap: [AVSpeechUtterance: NSRange] = [:] // Maps utterance to its global range in fullContent

    weak var delegate: ContentReaderDelegate?

    // Speech parameters for normal and emphasized text
    private let normalRate: Float = 0.5
    private let normalPitch: Float = 1.0
    private let emphasizedRate: Float = 0.4 // Slightly slower
    private let emphasizedPitch: Float = 1.2 // Slightly higher

    override init() {
        super.init()
        synthesizer.delegate = self
    }

    /// Starts reading the provided content, applying emphasis and providing highlight callbacks.
    /// - Parameter content: The full article content string, with `**...**` for emphasis.
    func startReading(_ content: String) {
        stopReading() // Ensure any previous reading is stopped and queue cleared

        self.fullContent = content
        self.segmentMap.removeAll()

        let segments = parseTextForEmphasis(content)
        
        if segments.isEmpty {
            print("No text segments to speak.")
            delegate?.contentReaderDidFinishReading(self)
            return
        }

        print("Starting to read content with \(segments.count) segments.")

        for segment in segments {
            let utterance: AVSpeechUtterance
            switch segment {
            case .normal(let text, let originalRange):
                utterance = AVSpeechUtterance(string: text)
                utterance.rate = normalRate
                utterance.pitchMultiplier = normalPitch
                self.segmentMap[utterance] = originalRange
            case .emphasized(let text, let originalRange):
                utterance = AVSpeechUtterance(string: text)
                utterance.rate = emphasizedRate
                utterance.pitchMultiplier = emphasizedPitch
                self.segmentMap[utterance] = originalRange
            }
            // Use a default voice, or allow customization (e.g., from SpeechManager)
            utterance.voice = AVSpeechSynthesisVoice(language: "en-US") ?? AVSpeechSynthesisVoice(language: nil)
            synthesizer.speak(utterance)
        }
    }

    /// Stops the current reading process and clears the synthesizer's queue.
    func stopReading() {
        if synthesizer.isSpeaking || synthesizer.isPaused {
            synthesizer.stopSpeaking(at: .immediate)
            print("Content reading stopped.")
        } else {
            print("No content reading active to stop.")
        }
        self.segmentMap.removeAll()
        self.fullContent = ""
    }

    // MARK: - Text Parsing for Emphasis

    /// Parses the input text into segments of normal and emphasized text.
    /// Emphasized text is enclosed in double asterisks `**...**`.
    ///
    /// - Parameter text: The input string.
    /// - Returns: An array of `TextSegment` with their original `NSRange` in the full text.
    private func parseTextForEmphasis(_ text: String) -> [TextSegment] {
        var segments: [TextSegment] = []
        var currentOffset = 0
        
        // Regex to find **text**
        let regex = try! NSRegularExpression(pattern: "\\*\\*(.*?)\\*\\*", options: [])
        let matches = regex.matches(in: text, options: [], range: NSRange(text.startIndex..., in: text))

        for match in matches {
            // Add normal text before the emphasized part
            if match.range.location > currentOffset {
                let range = NSRange(location: currentOffset, length: match.range.location - currentOffset)
                if let substring = text.substring(with: range) {
                    segments.append(.normal(substring, range))
                }
            }

            // Add emphasized text
            if let emphasizedContentRange = Range(match.range(at: 1), in: text) { // Group 1 is the content inside **
                let range = NSRange(emphasizedContentRange, in: text)
                segments.append(.emphasized(String(text[emphasizedContentRange]), range))
            }

            currentOffset = match.range.upperBound
        }

        // Add any remaining normal text after the last emphasized part
        if currentOffset < text.utf16.count {
            let range = NSRange(location: currentOffset, length: text.utf16.count - currentOffset)
            if let substring = text.substring(with: range) {
                segments.append(.normal(substring, range))
            }
        }
        return segments
    }
}

// MARK: - AVSpeechSynthesizerDelegate (Implementation for Exercise 4)

extension ContentReader: AVSpeechSynthesizerDelegate {
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        // Map the utterance's local range back to the global range in the full content string
        if let originalSegmentRange = segmentMap[utterance] {
            let globalRange = NSRange(location: originalSegmentRange.location + characterRange.location, length: characterRange.length)
            delegate?.contentReader(self, willSpeakRange: globalRange, for: utterance)
        }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        // Check if this was the last utterance in the queue
        if !synthesizer.isSpeaking && !synthesizer.isPaused {
            print("All content finished speaking.")
            delegate?.contentReaderDidFinishReading(self)
            self.segmentMap.removeAll()
            self.fullContent = ""
        }
    }
    
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        print("Content reading cancelled by user or interruption.")
        delegate?.contentReaderDidStopReading(self)
        self.segmentMap.removeAll()
        self.fullContent = ""
    }
}

// MARK: - Helper Types and Extensions

// Represents a segment of text with its original range
enum TextSegment {
    case normal(String, NSRange)
    case emphasized(String, NSRange)
}

// Helper extension for String to get substring by NSRange
extension String {
    func substring(with nsRange: NSRange) -> String? {
        guard let range = Range(nsRange, in: self) else { return nil }
        return String(self[range])
    }
}

// MARK: - Example Usage (Simulated UI Layer)

class MockUIHighlighter: ContentReaderDelegate {
    var fullText: String = ""

    func contentReader(_ reader: ContentReader, willSpeakRange globalRange: NSRange, for utterance: AVSpeechUtterance) {
        if let spokenWord = fullText.substring(with: globalRange) {
            // Simulate UI highlighting by printing the word with markers
            let prefix = fullText.prefix(globalRange.location)
            let suffix = fullText.suffix(fullText.utf16.count - (globalRange.location + globalRange.length))
            print("UI Highlight: \(prefix) [\(spokenWord)] \(suffix)")
            
            // Also log the utterance's properties for emphasis verification
            print("  -> Utterance: Rate=\(String(format: "%.2f", utterance.rate)), Pitch=\(String(format: "%.2f", utterance.pitchMultiplier))")
        }
    }
    
    func contentReaderDidFinishReading(_ reader: ContentReader) {
        print("\nMock UI: Reading complete.")
    }
    
    func contentReaderDidStopReading(_ reader: ContentReader) {
        print("\nMock UI: Reading stopped.")
    }
}

func demonstrateExercise4() {
    print("\n--- Exercise 4 Demonstration ---")
    let contentReader = ContentReader()
    let uiHighlighter = MockUIHighlighter()
    contentReader.delegate = uiHighlighter

    let articleContent = """
    This is a sample article. It contains some **important** information about **new features**.
    Please pay attention to the details. Some words will be spoken with **extra emphasis** for clarity.
    The goal is to provide a **dynamic and engaging** reading experience.
    """
    
    uiHighlighter.fullText = articleContent // Provide full text to mock UI for global range mapping

    print("\nStarting to read article content:")
    contentReader.startReading(articleContent)

    // Simulate stopping after a few seconds
    DispatchQueue.main.asyncAfter(deadline: .now() + 8.0) {
        print("\nSimulating user stopping the reading...")
        contentReader.stopReading()
        print("--- Exercise 4 Demonstration Complete ---")
    }
}

// Call the demonstration function to run the example
// demonstrateExercise4()
