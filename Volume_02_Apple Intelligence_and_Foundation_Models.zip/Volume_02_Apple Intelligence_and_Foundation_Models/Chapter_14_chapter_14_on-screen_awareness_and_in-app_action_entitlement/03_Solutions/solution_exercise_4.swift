
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import AppIntents
import Foundation // For Date and URL

// MARK: - Calendar Event Data Model (for context)
struct CalendarEvent {
    let id: UUID
    let title: String
    let startDate: Date
    let endDate: Date
    let location: String?
    let attendees: [String] // Array of email addresses
}

// MARK: - On-Screen Awareness Components

@available(iOS 18.0, *)
struct CalendarEventMetadata: Codable {
    let title: String
    let startDate: Date
    let endDate: Date
    let location: String?
    let attendees: [String] // Array of email addresses

    // Custom date encoding/decoding strategy for ISO8601
    private enum CodingKeys: String, CodingKey {
        case title, startDate, endDate, location, attendees
    }

    init(title: String, startDate: Date, endDate: Date, location: String?, attendees: [String]) {
        self.title = title
        self.startDate = startDate
        self.endDate = endDate
        self.location = location
        self.attendees = attendees
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.title = try container.decode(String.self, forKey: .title)
        self.location = try container.decodeIfPresent(String.self, forKey: .location)
        self.attendees = try container.decode([String].self, forKey: .attendees)

        let dateFormatter = ISO8601DateFormatter()
        dateFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]

        let startDateString = try container.decode(String.self, forKey: .startDate)
        guard let startDate = dateFormatter.date(from: startDateString) else {
            throw DecodingError.dataCorruptedError(forKey: .startDate, in: container, debugDescription: "Cannot decode start date")
        }
        self.startDate = startDate

        let endDateString = try container.decode(String.self, forKey: .endDate)
        guard let endDate = dateFormatter.date(from: endDateString) else {
            throw DecodingError.dataCorruptedError(forKey: .endDate, in: container, debugDescription: "Cannot decode end date")
        }
        self.endDate = endDate
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(title, forKey: .title)
        try container.encodeIfPresent(location, forKey: .location)
        try container.encode(attendees, forKey: .attendees)

        let dateFormatter = ISO8601DateFormatter()
        dateFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]

        try container.encode(dateFormatter.string(from: startDate), forKey: .startDate)
        try container.encode(dateFormatter.string(from: endDate), forKey: .endDate)
    }
}


@available(iOS 18.0, *)
class EventDetailViewController: UIViewController {
    var event: CalendarEvent! // Assume this is populated with the current event

    private let titleLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .largeTitle)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        return label
    }()

    private let timeLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .subheadline)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let locationLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .body)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        return label
    }()

    private let attendeesLabel: UILabel = {
        let label = UILabel()
        label.font = .preferredFont(forTextStyle: .body)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        return label
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Event Details"
        view.backgroundColor = .systemBackground

        // Simulate an event being loaded
        event = CalendarEvent(
            id: UUID(),
            title: "Project Sync Meeting",
            startDate: Date().addingTimeInterval(3600 * 24), // Tomorrow
            endDate: Date().addingTimeInterval(3600 * 24 + 3600), // Tomorrow + 1 hour
            location: "Conference Room A, 123 Main St, Anytown",
            attendees: ["alice@example.com", "bob@example.com", "charlie@example.com"]
        )

        setupUI()
        provideContentContext()
    }

    private func setupUI() {
        view.addSubview(titleLabel)
        view.addSubview(timeLabel)
        view.addSubview(locationLabel)
        view.addSubview(attendeesLabel)

        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            timeLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10),
            timeLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            timeLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            locationLabel.topAnchor.constraint(equalTo: timeLabel.bottomAnchor, constant: 10),
            locationLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            locationLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            attendeesLabel.topAnchor.constraint(equalTo: locationLabel.bottomAnchor, constant: 10),
            attendeesLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            attendeesLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])

        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .short
        titleLabel.text = event.title
        timeLabel.text = "\(dateFormatter.string(from: event.startDate)) - \(dateFormatter.string(from: event.endDate))"
        locationLabel.text = "Location: \(event.location ?? "N/A")"
        attendeesLabel.text = "Attendees: \(event.attendees.joined(separator: ", "))"
    }

    private func provideContentContext() {
        let metadata = CalendarEventMetadata(
            title: event.title,
            startDate: event.startDate,
            endDate: event.endDate,
            location: event.location,
            attendees: event.attendees
        )

        // Encode the metadata for UIContentContext
        guard let encodedMetadata = try? JSONEncoder().encode(metadata) else {
            print("Failed to encode CalendarEventMetadata.")
            return
        }

        let contentContext = UIContentContext(
            identifier: ContentIdentifier(rawValue: "calendar-event-\(event.id.uuidString)"),
            metadata: encodedMetadata,
            actions: [
                ContentAction(
                    identifier: ContentIdentifier(rawValue: "email-attendees"),
                    title: NSLocalizedString("Email Attendees", comment: "Action to email event attendees"),
                    // Parameter names should ideally match parameters in a corresponding AppIntent.
                    parameterValues: [
                        "recipients": event.attendees,
                        "subject": "Regarding: \(event.title)" // Pre-fill subject for convenience
                    ]
                ),
                ContentAction(
                    identifier: ContentIdentifier(rawValue: "get-directions"),
                    title: NSLocalizedString("Get Directions", comment: "Action to get directions to event location"),
                    parameterValues: [
                        // Parameter name "destination" would typically map to a location parameter in a directions intent.
                        "destination": event.location ?? "" // Provide location if available
                    ],
                    // Optionally, you can suggest a specific AppIntent type if you have one.
                    // This is a conceptual link to an AppIntent you would define for directions.
                    intentType: "GetDirectionsIntent"
                )
            ]
        )

        // Associate this contentContext with the main view of the event detail.
        // This makes the entire screen's content available to Apple Intelligence.
        self.view.contentContext = contentContext

        // Why this is important:
        // 1. Rich Context: By providing a comprehensive metadata struct, Apple Intelligence understands the full semantic meaning of the event.
        //    This allows it to answer complex queries like "When is my meeting with John?" or "Where is the 'Project Review' event?".
        // 2. Direct Actions: ContentActions allow Apple Intelligence to directly offer and trigger specific actions related to the on-screen content.
        //    - "Email Attendees": Could link to a `SendEmailIntent` (custom or system-provided) taking an array of recipients and a subject.
        //      Conceptual `SendEmailIntent` parameters: `recipients: [String]`, `subject: String?`, `body: String?`.
        //    - "Get Directions": Could link to a `GetDirectionsIntent` (either system-provided Maps intent or a custom one) taking a `destination: String` or `CLLocationCoordinate2D`.
        //      Conceptual `GetDirectionsIntent` parameters: `destination: String`, `transportType: TransportType`.
        // This creates a seamless user experience where the system intelligently anticipates and enables next steps based on what the user is currently viewing.
    }
}
