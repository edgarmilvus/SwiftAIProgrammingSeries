
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CreateML

@available(macOS 14.0, iOS 18.0, *)
struct SmartHomeData: Codable {
    let timestamp: Date // Assuming ISO 8601
    let indoorTempC: Double
    let outdoorTempC: Double
    let humidityPercent: Double
    let hvacStatus: String
    let lightSensorLux: Double
    let motionDetected: Bool
    let userPreferenceComfortLevel: Int
    let energyConsumptionKWH: Double // Target
}

@available(macOS 14.0, iOS 18.0, *)
func engineerHVACFeatures(csvURL: URL) throws -> MLDataTable {
    // Initial MLDataTable: Simulate loading from CSV
    let formatter = ISO8601DateFormatter()
    let homeData: [String: MLDataColumn] = [
        "timestamp": .init(array: [
            formatter.date(from: "2023-11-01T00:00:00Z")!,
            formatter.date(from: "2023-11-01T01:00:00Z")!,
            formatter.date(from: "2023-11-01T02:00:00Z")!,
            formatter.date(from: "2023-11-01T03:00:00Z")!,
            formatter.date(from: "2023-11-01T04:00:00Z")!,
            formatter.date(from: "2023-11-01T05:00:00Z")!,
            formatter.date(from: "2023-11-01T06:00:00Z")!
        ]),
        "indoorTempC": .init(array: [20.0, 20.1, 20.2, 20.0, 19.8, 19.5, 19.2]),
        "outdoorTempC": .init(array: [5.0, 4.5, 4.0, 3.5, 3.0, 2.5, 2.0]),
        "humidityPercent": .init(array: [40.0, 40.5, 41.0, 40.8, 41.2, 41.5, 41.3]),
        "hvacStatus": .init(array: ["Off", "Off", "Heating", "Heating", "Heating", "Off", "Off"]),
        "lightSensorLux": .init(array: [10.0, 8.0, 7.0, 6.0, 5.0, 20.0, 50.0]),
        "motionDetected": .init(array: [false, false, true, true, false, true, true]),
        "userPreferenceComfortLevel": .init(array: [3, 3, 4, 4, 3, 3, 4]),
        "energyConsumptionKWH": .init(array: [0.1, 0.1, 0.5, 0.8, 0.6, 0.2, 0.15]) // Target
    ]
    var dataTable = MLDataTable(dictionary: homeData)
    // Ensure dataTable is sorted by timestamp for lagged features
    dataTable = dataTable.sorted(by: "timestamp")

    // Helper function to create lagged columns
    func createLaggedColumn<T: MLDataValueConvertible & ExpressibleByFloatLiteral>(
        from column: MLDataColumn,
        lag: Int,
        fillValue: T
    ) -> MLDataColumn {
        let originalArray: [T?] = column.map { $0.flatMap { $0 as? T } }.array
        var laggedArray = Array<T?>(repeating: nil, count: lag) + originalArray.dropLast(lag)
        let finalLaggedArray: [T] = laggedArray.map { $0 ?? fillValue }
        return MLDataColumn(finalLaggedArray)
    }

    // 1. Time-Series Feature Extraction (Lagged Features)
    // Create features for values from 1 hour ago (_lag1) and 2 hours ago (_lag2).
    // Handle initial rows by filling with 0.0 (or mean/median of the column).
    dataTable["indoorTempC_lag1"] = createLaggedColumn(from: dataTable["indoorTempC"], lag: 1, fillValue: 0.0)
    dataTable["indoorTempC_lag2"] = createLaggedColumn(from: dataTable["indoorTempC"], lag: 2, fillValue: 0.0)
    dataTable["outdoorTempC_lag1"] = createLaggedColumn(from: dataTable["outdoorTempC"], lag: 1, fillValue: 0.0)
    dataTable["outdoorTempC_lag2"] = createLaggedColumn(from: dataTable["outdoorTempC"], lag: 2, fillValue: 0.0)
    dataTable["energyConsumptionKWH_lag1"] = createLaggedColumn(from: dataTable["energyConsumptionKWH"], lag: 1, fillValue: 0.0)
    dataTable["energyConsumptionKWH_lag2"] = createLaggedColumn(from: dataTable["energyConsumptionKWH"], lag: 2, fillValue: 0.0)

    // 2. Polynomial Features & Feature Crosses
    // Polynomial feature for outdoorTempC
    dataTable["outdoorTempC_squared"] = dataTable["outdoorTempC"] * dataTable["outdoorTempC"]

    // Feature cross between hvacStatus and outdoorTempC
    dataTable["heating_outdoorTempInteraction"] = dataTable.mapColumns { (row: MLDataRow) -> Double in
        if row["hvacStatus"]?.stringValue == "Heating" {
            return row["outdoorTempC"]?.doubleValue ?? 0.0
        } else {
            return 0.0
        }
    }
    dataTable["cooling_outdoorTempInteraction"] = dataTable.mapColumns { (row: MLDataRow) -> Double in
        if row["hvacStatus"]?.stringValue == "Cooling" {
            return row["outdoorTempC"]?.doubleValue ?? 0.0
        } else {
            return 0.0
        }
    }

    // 3. Cyclical Time Features
    let calendar = Calendar.current
    dataTable["hourOfDay"] = dataTable["timestamp"].map { (date: Date) -> Int in
        calendar.component(.hour, from: date)
    }
    dataTable["dayOfWeek"] = dataTable["timestamp"].map { (date: Date) -> Int in
        calendar.component(.weekday, from: date) // 1 for Sunday, 2 for Monday etc.
    }

    // Apply cyclical encoding to hourOfDay
    dataTable["hour_sin"] = dataTable["hourOfDay"].map { (hour: Int) -> Double in
        sin((Double(hour) / 24.0) * 2.0 * .pi)
    }
    dataTable["hour_cos"] = dataTable["hourOfDay"].map { (hour: Int) -> Double in
        cos((Double(hour) / 24.0) * 2.0 * .pi)
    }

    // 4. Conditional Feature Engineering
    // Temperature delta
    dataTable["tempDelta"] = dataTable["indoorTempC"] - dataTable["outdoorTempC"]

    // Binary feature: isNightTime (e.g., 22:00 to 06:00)
    dataTable["isNightTime"] = dataTable["hourOfDay"].map { (hour: Int) -> Bool in
        hour >= 22 || hour <= 6
    }

    // 5. Final MLDataTable
    // Assemble the final MLDataTable for training.
    let finalColumns = [
        "indoorTempC_lag1", "indoorTempC_lag2",
        "outdoorTempC_lag1", "outdoorTempC_lag2",
        "humidityPercent",
        "hvacStatus", // Create ML handles String columns
        "lightSensorLux",
        "motionDetected",
        "userPreferenceComfortLevel",
        "outdoorTempC_squared",
        "heating_outdoorTempInteraction",
        "cooling_outdoorTempInteraction",
        "dayOfWeek", // Can be used as categorical
        "hour_sin", "hour_cos",
        "tempDelta",
        "isNightTime",
        "energyConsumptionKWH_lag1", "energyConsumptionKWH_lag2", // Lagged target as feature
        "energyConsumptionKWH" // Current energy consumption as target
    ]
    dataTable = dataTable[finalColumns]

    return dataTable
}

// Example usage:
if #available(macOS 14.0, iOS 18.0, *) {
    do {
        let dummyURL = URL(fileURLWithDataRepresentation: Data(), relativeTo: nil)
        let preparedTable = try engineerHVACFeatures(csvURL: dummyURL)
        print("Prepared Smart Home Data Table:\n\(preparedTable.description)")
    } catch {
        print("Error preparing smart home data: \(error)")
    }
} else {
    print("CreateML features require macOS 14.0 / iOS 18.0 or later.")
}
