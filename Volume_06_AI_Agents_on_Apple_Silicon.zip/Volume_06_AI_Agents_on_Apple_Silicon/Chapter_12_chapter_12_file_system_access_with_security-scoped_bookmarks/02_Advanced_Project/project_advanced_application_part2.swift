
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AppKit // Required for NSOpenPanel on macOS
import UniformTypeIdentifiers // For file type declarations
// import OllamaKit // Uncomment if you have OllamaKit integrated via SPM

/// Errors specific to document processing and bookmark management.
enum DocumentProcessorError: Error, LocalizedError {
    case noBookmarkDataFound(key: String)
    case bookmarkCreationFailed(Error)
    case bookmarkResolutionFailed(Error)
    case directoryAccessDenied
    case invalidDirectoryURL
    case fileSystemAccessError(Error)
    case documentProcessingFailed(String)

    var errorDescription: String? {
        switch self {
        case .noBookmarkDataFound(let key):
            return "No security-scoped bookmark found for key: \(key)."
        case .bookmarkCreationFailed(let error):
            return "Failed to create security-scoped bookmark: \(error.localizedDescription)"
        case .bookmarkResolutionFailed(let error):
            return "Failed to resolve security-scoped bookmark: \(error.localizedDescription)"
        case .directoryAccessDenied:
            return "Access to the selected directory was denied."
        case .invalidDirectoryURL:
            return "The provided URL is not a valid directory."
        case .fileSystemAccessError(let error):
            return "File system access error: \(error.localizedDescription)"
        case .documentProcessingFailed(let reason):
            return "Document processing failed: \(reason)"
        }
    }
}

/// Manages document directories for AI processing using security-scoped bookmarks.
/// This class handles user selection of directories, persistence of access,
/// and provides methods to access and process documents within those directories.
@available(macOS 13.0, *) // NSOpenPanel and async/await for macOS
class DocumentProcessor: ObservableObject {
    // MARK: - Properties

    /// Key for storing the bookmark data in UserDefaults.
    private let bookmarkKey = "persistedDocumentDirectoryBookmark"

    /// The URL of the currently accessed document directory, if any.
    @Published private(set) var currentDocumentDirectory: URL?

    /// The bookmark data for the current directory, used for persistence.
    private var currentBookmarkData: Data?

    /// A private property to hold the active security-scoped URL after resolution
    /// and before `stopAccessingSecurityScopedResource` is called.
    private var activeSecurityScopedURL: URL?

    // MARK: - Initialization

    init() {
        // Attempt to load and resolve a previously saved bookmark on initialization.
        Task {
            await loadAndResolveBookmark()
        }
    }

    deinit {
        // Ensure we stop accessing any active security-scoped resource when the object is deallocated.
        stopAccessingCurrentDirectory()
    }

    // MARK: - Public Interface

    /// Presents an `NSOpenPanel` to allow the user to select a directory,
    /// then creates and persists a security-scoped bookmark for it.
    /// - Returns: The URL of the selected directory.
    /// - Throws: `DocumentProcessorError` if selection or bookmark creation fails.
    func selectAndBookmarkDocumentDirectory() async throws -> URL {
        return try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.main.async { // NSOpenPanel must be run on the main thread
                let openPanel = NSOpenPanel()
                openPanel.canChooseFiles = false
                openPanel.canChooseDirectories = true
                openPanel.allowsMultipleSelection = false
                openPanel.canResolveUbiquitousURLs = true
                openPanel.prompt = "Select Documents Folder for AI Analysis"

                if openPanel.runModal() == .OK, let url = openPanel.url {
                    // Stop accessing any previously active directory before starting a new one
                    self.stopAccessingCurrentDirectory()

                    do {
                        let bookmarkData = try url.bookmarkData(
                            options: .withSecurityScope,
                            includingResourceValuesForKeys: nil,
                            relativeTo: nil
                        )
                        UserDefaults.standard.set(bookmarkData, forKey: self.bookmarkKey)
                        self.currentBookmarkData = bookmarkData
                        self.currentDocumentDirectory = url // Store the original URL for display
                        print("Bookmark created and saved for: \(url.lastPathComponent)")
                        continuation.resume(returning: url)
                    } catch {
                        print("Error creating bookmark: \(error.localizedDescription)")
                        continuation.resume(throwing: DocumentProcessorError.bookmarkCreationFailed(error))
                    }
                } else {
                    print("User cancelled directory selection.")
                    continuation.resume(throwing: DocumentProcessorError.directoryAccessDenied)
                }
            }
        }
    }

    /// Loads a previously saved security-scoped bookmark from `UserDefaults`
    /// and attempts to resolve it to regain access to the directory.
    /// If successful, the `currentDocumentDirectory` property is updated.
    /// - Throws: `DocumentProcessorError` if no bookmark is found or resolution fails.
    func loadAndResolveBookmark() async {
        guard let storedBookmarkData = UserDefaults.standard.data(forKey: bookmarkKey) else {
            print("No stored bookmark data found.")
            await MainActor.run { self.currentDocumentDirectory = nil }
            return
        }

        do {
            var isStale = false
            let resolvedURL = try URL(
                resolvingBookmarkData: storedBookmarkData,
                options: .withSecurityScope,
                relativeTo: nil,
                bookmarkDataIsStale: &isStale
            )

            if isStale {
                print("Bookmark is stale, attempting to refresh...")
                // Optionally, recreate the bookmark if stale. This requires user interaction
                // if the original URL is no longer accessible or moved.
                // For this example, we'll just proceed with the resolved URL and advise re-selection.
                print("Bookmark was stale, consider prompting user to re-select directory.")
            }

            // Important: Start accessing the security-scoped resource.
            // This must be balanced with stopAccessingSecurityScopedResource().
            if resolvedURL.startAccessingSecurityScopedResource() {
                print("Successfully resolved and started accessing security-scoped resource: \(resolvedURL.lastPathComponent)")
                await MainActor.run {
                    self.activeSecurityScopedURL = resolvedURL // Keep track of the active URL
                    self.currentDocumentDirectory = resolvedURL
                }
            } else {
                print("Failed to start accessing security-scoped resource for: \(resolvedURL.lastPathComponent)")
                await MainActor.run { self.currentDocumentDirectory = nil }
                throw DocumentProcessorError.directoryAccessDenied
            }
        } catch {
            print("Error resolving bookmark: \(error.localizedDescription)")
            await MainActor.run { self.currentDocumentDirectory = nil }
        }
    }

    /// Stops accessing the currently active security-scoped resource.
    /// It's crucial to call this when access is no longer needed to release system resources.
    func stopAccessingCurrentDirectory() {
        if let url = activeSecurityScopedURL {
            url.stopAccessingSecurityScopedResource()
            print("Stopped accessing security-scoped resource for: \(url.lastPathComponent)")
            activeSecurityScopedURL = nil
            // Optionally, clear the currentDocumentDirectory if access is fully revoked.
            // For persistence, we might keep the URL for display but mark it as inactive.
        }
    }

    /// Initiates the AI processing pipeline for documents within the currently selected directory.
    /// This method demonstrates how to safely access files within the bookmarked directory.
    /// - Throws: `DocumentProcessorError` if no directory is selected, or processing fails.
    func processDocumentsWithAI() async throws {
        guard let directoryURL = currentDocumentDirectory else {
            throw DocumentProcessorError.invalidDirectoryURL
        }

        // Ensure we are accessing the security-scoped resource.
        // This check is important if `processDocumentsWithAI` is called independently
        // of `loadAndResolveBookmark` or `selectAndBookmarkDocumentDirectory`.
        // For robustness, we re-verify or re-initiate access.
        if activeSecurityScopedURL == nil || !activeSecurityScopedURL!.startAccessingSecurityScopedResource() {
             // Attempt to re-establish access if not already active or if it failed.
             // In a real app, you might want a more sophisticated re-access strategy or user prompt.
            print("Attempting to re-establish access for processing...")
            await loadAndResolveBookmark() // This will set activeSecurityScopedURL
            guard activeSecurityScopedURL != nil else {
                throw DocumentProcessorError.directoryAccessDenied
            }
        }

        defer {
            // Ensure access is stopped once processing is complete or an error occurs.
            stopAccessingCurrentDirectory()
        }

        do {
            let fileManager = FileManager.default
            let directoryContents = try fileManager.contentsOfDirectory(
                at: directoryURL,
                includingPropertiesForKeys: [.isRegularFileKey, .fileResourceTypeKey],
                options: [.skipsHiddenFiles]
            )

            print("Found \(directoryContents.count) items in \(directoryURL.lastPathComponent):")

            for fileURL in directoryContents {
                if fileURL.hasDirectoryPath { continue } // Skip subdirectories
                let fileName = fileURL.lastPathComponent
                let fileExtension = fileURL.pathExtension.lowercased()

                // Basic filtering for common document types
                let supportedExtensions = ["pdf", "txt", "md", "doc", "docx", "jpg", "png"]
                if supportedExtensions.contains(fileExtension) {
                    print("  - Processing document: \(fileName)")
                    // Simulate AI processing (e.g., calling OllamaKit)
                    try await mockAIDocumentProcessing(fileURL: fileURL)
                } else {
                    print("  - Skipping unsupported file: \(fileName)")
                }
            }
            print("AI document processing completed for directory: \(directoryURL.lastPathComponent)")

        } catch {
            throw DocumentProcessorError.fileSystemAccessError(error)
        }
    }

    // MARK: - Private Helpers

    /// Mock function to simulate AI document processing.
    /// In a real application, this would involve reading the file content,
    /// potentially performing OCR (for images/PDFs), and then sending the text
    /// to a local LLM via `OllamaKit` or `llama.cpp` bindings.
    /// - Parameter fileURL: The URL of the document to process.
    private func mockAIDocumentProcessing(fileURL: URL) async throws {
        // Example: Read file content (for text files)
        if fileURL.pathExtension.lowercased() == "txt" || fileURL.pathExtension.lowercased() == "md" {
            let content = try String(contentsOf: fileURL, encoding: .utf8)
            print("    [AI Mock] Read first 100 chars from \(fileURL.lastPathComponent): \(content.prefix(100))...")
            // Here, you would integrate with OllamaKit:
            // let ollama = OllamaKit()
            // let response = try await ollama.chat(model: "llama2", messages: [.user("Summarize this: \(content)")])
            // print("    [AI Mock] LLM Response: \(response.first?.content ?? "No response")")
        } else if fileURL.pathExtension.lowercased() == "pdf" {
            print("    [AI Mock] Simulating OCR/PDF parsing for \(fileURL.lastPathComponent)...")
            // For PDFs, you'd use PDFKit to extract text, then pass to LLM.
        } else if ["jpg", "png"].contains(fileURL.pathExtension.lowercased()) {
            print("    [AI Mock] Simulating image OCR for \(fileURL.lastPathComponent)...")
            // For images, you'd use Vision framework for OCR, then pass to LLM.
        }
        try await Task.sleep(for: .milliseconds(200)) // Simulate work
    }

    /// Clears the stored bookmark and resets the current directory.
    func clearBookmarkedDirectory() {
        stopAccessingCurrentDirectory()
        UserDefaults.standard.removeObject(forKey: bookmarkKey)
        currentBookmarkData = nil
        currentDocumentDirectory = nil
        print("Cleared bookmarked directory.")
    }
}
