
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import AppIntents
import Foundation // For UUID

// MARK: - Ingredient AppEntity
// Define your Ingredient struct here, conforming to AppEntity, Codable, and Identifiable.
// It should have properties like 'id' (e.g., String) and 'name'.
// Implement 'displayRepresentation' for AppEntity conformance.
@available(iOS 18.0, *)
struct Ingredient: AppEntity, Codable, Identifiable {
    var id: String // Using String for simplicity, UUID is also fine
    var name: String

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Ingredient"

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(stringLiteral: name)
    }
}

// MARK: - IngredientProvider
@available(iOS 18.0, *)
struct IngredientProvider: DynamicOptionsProvider {
    typealias Result = Ingredient // Use your Ingredient AppEntity

    // Simulate a large list of ingredients from a "backend"
    private let allIngredients: [Ingredient] = {
        var ingredients: [Ingredient] = []
        let commonIngredients = [
            "All-Purpose Flour", "Granulated Sugar", "Salt", "Baking Powder", "Baking Soda",
            "Eggs", "Milk", "Butter", "Vanilla Extract", "Olive Oil", "Garlic", "Onion",
            "Tomatoes", "Potatoes", "Carrots", "Chicken Breast", "Ground Beef", "Pasta",
            "Rice", "Cheddar Cheese", "Parmesan Cheese", "Spinach", "Mushrooms", "Bell Pepper",
            "Lemon", "Lime", "Honey", "Maple Syrup", "Soy Sauce", "Ginger", "Cinnamon",
            "Black Pepper", "Oregano", "Basil", "Thyme", "Rosemary", "Paprika", "Cumin",
            "Chili Powder", "Broccoli", "Cauliflower", "Zucchini", "Avocado", "Apples",
            "Bananas", "Berries", "Yogurt", "Coffee", "Tea", "Cocoa Powder", "Chocolate Chips",
            "Peanut Butter", "Almonds", "Walnuts", "Oats", "Bread", "Vinegar", "Mustard",
            "Ketchup", "Mayonnaise", "Hot Sauce", "Tofu", "Lentils", "Chickpeas", "Quinoa",
            "Sweet Potato", "Corn", "Green Beans", "Asparagus", "Salmon", "Shrimp", "Tuna",
            "Pork Loin", "Bacon", "Sausage", "Cream Cheese", "Sour Cream", "Heavy Cream",
            "White Wine", "Red Wine", "Beer", "Coconut Milk", "Curry Powder", "Turmeric"
        ]
        for name in commonIngredients {
            ingredients.append(Ingredient(id: name.lowercased().replacingOccurrences(of: " ", with: "-"), name: name))
        }
        return ingredients
    }()

    func suggestedOptions() async throws -> [Ingredient] {
        // Simulate network delay for initial fetch
        try await Task.sleep(for: .milliseconds(700))
        return allIngredients
    }

    func suggestedOptions(for searchTerm: String?) async throws -> [Ingredient] {
        // Simulate network delay for filtered suggestions
        // Shorter delay than full fetch as it's typically a faster API endpoint
        try await Task.sleep(for: .milliseconds(300))

        guard let searchTerm = searchTerm, !searchTerm.isEmpty else {
            return Array(allIngredients.prefix(20)) // Return a default subset if no search term
        }

        let lowercasedSearchTerm = searchTerm.lowercased()
        let filtered = allIngredients.filter {
            $0.name.lowercased().contains(lowercasedSearchTerm)
        }
        return Array(filtered.prefix(20)) // Limit suggestions for performance
    }

    func defaultOptions() async throws -> [Ingredient] {
        // Return a few common ingredients as defaults
        return Array(allIngredients.prefix(5))
    }

    func options(for identifiers: [Ingredient.ID]) async throws -> [Ingredient] {
        // Retrieve specific ingredients by their IDs from your full list.
        // Simulate a quick lookup from a local cache or specific API call
        try await Task.sleep(for: .milliseconds(100))
        return allIngredients.filter { identifiers.contains($0.id) }
    }
}

// MARK: - FindRecipeByIngredientIntent
@available(iOS 18.0, *)
struct FindRecipeByIngredientIntent: AppIntent {
    static var title: LocalizedStringResource = "Find Recipe by Ingredient"
    static var description: IntentDescription = "Searches for recipes containing a specific ingredient."

    @Parameter(title: "Ingredient", description: "The ingredient to search recipes for.", optionsProvider: IngredientProvider.self)
    var ingredient: Ingredient

    func perform() async throws -> some IntentResult {
        // Implement your logic here.
        // Print a message confirming the selected ingredient.
        print("Searching for recipes with \(ingredient.name).")
        
        // In a real app, you would navigate to a recipe search view or perform an API call.
        
        return .result(
            value: "Searching for recipes with \(ingredient.name)",
            view: IntentResultView {
                VStack(alignment: .leading) {
                    Text("Searching Recipes...")
                        .font(.headline)
                    Text("Ingredient: \(ingredient.name)")
                }
            }
        )
    }
}
