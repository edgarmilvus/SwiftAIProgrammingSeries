/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/shop/item/[id].tsx
import React, { useEffect, useState } from 'react';
import { 
  useLocalSearchParams, 
  useRouter, 
  Redirect, 
  Stack 
} from 'expo-router';
import { View, Text, ActivityIndicator, StyleSheet } from 'react-native';

// Type definition for search params
type SearchParams = {
  id: string;
};

// Mock Server Component / Data Fetching
async function fetchProductData(id: string) {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Mock validation logic
  if (id === '999') {
    return null; // Simulate not found
  }
  
  return {
    id: id,
    name: `Product ${id}`,
    price: 100 + parseInt(id),
    ref: 'twitter' // from query param
  };
}

export default function ProductDetail() {
  const router = useRouter();
  const params = useLocalSearchParams<SearchParams>();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      // 1. Validate ID is a number
      const id = params.id;
      if (!id || isNaN(Number(id))) {
        router.replace('/404');
        return;
      }

      // 2. Fetch Data
      const data = await fetchProductData(id);
      
      if (!data) {
        router.replace('/404');
        return;
      }

      setProduct(data);
      setLoading(false);
    };

    loadData();
  }, [params.id, router]);

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  if (!product) {
    // While redirecting or validating
    return null; 
  }

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ title: product.name }} />
      <Text style={styles.title}>{product.name}</Text>
      <Text style={styles.price}>Price: ${product.price}</Text>
      <Text style={styles.meta}>Ref: {params.ref}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  price: { fontSize: 18, color: 'green' },
  meta: { fontSize: 14, color: 'gray', marginTop: 10 }
});
