
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import Observation

/// 3. The ImplicitFeedbackEvent
struct ImplicitFeedbackEvent: Sendable {
    let originalText: String
    let editedText: String
    let timeElapsed: TimeInterval
}

/// 1. Create a TextEditorViewModel using the @Observable macro
@Observable
@MainActor
class TextEditorViewModel {
    var currentUserText: String = ""
    var originalAIOutput: String = ""
    var generationTimestamp: Date = Date()
    
    private let significanceThreshold = 0.10 // 10% change
    
    /// 2. Implement Change Detection
    func checkForCorrections() {
        let original = originalAIOutput
        let current = currentUserText
        let timestamp = generationTimestamp
        
        // Offload heavy computation to a background task to keep UI at 120Hz
        Task.detached(priority: .utility) {
            let delta = self.calculateDifferenceRatio(original, current)
            
            if delta > self.significanceThreshold {
                let event = ImplicitFeedbackEvent(
                    originalText: original,
                    editedText: current,
                    timeElapsed: Date().timeIntervalSince(timestamp)
                )
                await self.logImplicitFeedback(event)
            }
        }
    }
    
    private func calculateDifferenceRatio(_ s1: String, _ s2: String) -> Double {
        guard !s1.isEmpty else { return 0 }
        // Simple heuristic: character difference ratio
        let diff = abs(s1.count - s2.count)
        return Double(diff) / Double(s1.count)
    }
    
    private func logImplicitFeedback(_ event: ImplicitFeedbackEvent) async {
        // Simulate network logging
        print("⚠️ Negative Implicit Signal: User edited text. Delta detected.")
        print("Original: \(event.originalText) -> Edited: \(event.editedText)")
    }
}

struct QuickDraftView: View {
    @State private var viewModel = TextEditorViewModel()
    
    var body: some View {
        VStack {
            Text("AI Draft (Edit below)")
                .font(.caption)
            
            TextEditor(text: $viewModel.currentUserText)
                .onChange(of: viewModel.currentUserText) {
                    viewModel.checkForCorrections()
                }
                .onAppear {
                    // Simulate AI generating text
                    viewModel.originalAIOutput = "The weather is good today."
                    viewModel.currentUserText = viewModel.originalAIOutput
                    viewModel.generationTimestamp = Date()
                }
        }
        .padding()
    }
}
