
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import CoreData

/// Specific permissions for AI-driven features to ensure GDPR granularity.
enum AIProcessingPermission: String, CaseIterable, Sendable {
    case localInference = "local_inference"
    case cloudSynchronization = "cloud_sync"
    case semanticIndexing = "semantic_indexing"
}

/// An actor to ensure thread-safe access to user consent state and audit logging.
actor ConsentManager {
    private let userDefaults: UserDefaults
    private let container: NSPersistentContainer
    private let consentKey = "com.focusflow.ai.permissions"

    init(userDefaults: UserDefaults = .standard, container: NSPersistentContainer) {
        self.userDefaults = userDefaults
        self.container = container
    }

    /// Returns the current set of granted permissions.
    func isFeatureEnabled(_ permission: AIProcessingPermission) -> Bool {
        let savedPermissions = userDefaults.stringArray(forKey: consentKey) ?? []
        let activePermissions = savedPermissions.compactMap { AIProcessingPermission(rawValue: $0) }
        return activePermissions.contains(permission)
    }

    /// Updates a specific permission and logs the change in a local-only Core Data store.
    func updatePermission(_ permission: AIProcessingPermission, to granted: Bool) async throws {
        var currentPermissions = userDefaults.stringArray(forKey: consentKey) ?? []
        let permissionStrings = AIProcessingPermission.allCases.map { $0.rawValue }
        
        if granted {
            if !currentPermissions.contains(permission.rawValue) {
                currentPermissions.append(permission.rawValue)
            }
        } else {
            currentPermissions.removeAll { $0 == permission.rawValue }
        }
        
        userDefaults.set(currentPermissions, forKey: consentKey)
        
        // GDPR Requirement: Audit Log (Local-only, non-synced)
        try await logConsentChange(permission: permission, granted: granted)
    }

    private func logConsentChange(permission: AIProcessingPermission, granted: Bool) async throws {
        let context = container.newBackgroundContext()
        // Ensure the context is used within the actor's isolation or via perform
        try await context.perform {
            let entry = ConsentAuditEntry(context: context)
            entry.timestamp = Date()
            entry.permissionType = permission.rawValue
            entry.isGranted = granted
            
            try context.save()
            print("Audit Logged: \(permission.rawValue) changed to \(granted)")
        }
    }
}

/// Simulated Service to demonstrate integration.
struct CloudSyncService {
    let consentManager: ConsentManager

    func initiateSync() async {
        print("Attempting to initiate CloudKit Sync...")
        
        // Check for required permissions
        let canSync = await consentManager.isFeatureEnabled(.cloudSynchronization)
        let canIndex = await consentManager.isFeatureEnabled(.semanticIndexing)
        
        guard canSync && canIndex else {
            print("⚠️ SYNC ABORTED: Missing required AI privacy consents.")
            // In a real app, trigger a UI notification/delegate here
            return
        }
        
        print("✅ Syncing semantic embeddings to CloudKit...")
    }
}

// MARK: - Mock Core Data Entity
@objc(ConsentAuditEntry)
public class ConsentAuditEntry: NSManagedObject {
    @NSManaged public var timestamp: Date?
    @NSManaged public var permissionType: String?
    @NSManaged public var isGranted: Bool
}
