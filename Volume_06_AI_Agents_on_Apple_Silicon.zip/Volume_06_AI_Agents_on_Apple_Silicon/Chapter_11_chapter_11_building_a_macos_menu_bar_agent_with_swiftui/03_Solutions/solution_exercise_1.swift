
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// AppDelegate.swift
import Cocoa
import SwiftUI

class AppDelegate: NSObject, NSApplicationDelegate, NSPopoverDelegate {

    var statusItem: NSStatusItem!
    var popover: NSPopover!
    
    // This is the SwiftUI view that will be displayed in the popover
    // We pass a binding to a Bool that the SwiftUI view can toggle to dismiss the popover.
    private var isPopoverShownBinding: Binding<Bool> {
        Binding(
            get: { self.popover.isShown },
            set: { newValue in
                if !newValue {
                    self.popover.performClose(nil)
                }
            }
        )
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        // 1. Hide the main app window and dock icon
        NSApp.setActivationPolicy(.accessory) // .accessory hides the dock icon

        // 2. Create the NSStatusItem
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)

        if let button = statusItem.button {
            // Use an SF Symbol for the menu bar icon
            let config = NSImage.SymbolConfiguration(pointSize: 16, weight: .regular)
            button.image = NSImage(systemSymbolName: "brain.head.profile.fill", accessibilityDescription: "AI Agent")?
                .withSymbolConfiguration(config)
            button.action = #selector(togglePopover(_:))
            button.target = self
        }

        // 3. Create the NSPopover
        popover = NSPopover()
        popover.contentSize = NSSize(width: 240, height: 180)
        popover.behavior = .transient // Dismisses when clicking outside
        popover.delegate = self // Set delegate to handle popoverDidClose
        
        // 4. Attach a SwiftUI View to an NSHostingController
        // The RootView is our custom SwiftUI view for the popover content.
        // We pass the binding to allow the SwiftUI view to dismiss the popover.
        popover.contentViewController = NSHostingController(rootView: PopoverRootView(isPopoverShown: isPopoverShownBinding))
    }

    @objc func togglePopover(_ sender: AnyObject?) {
        if popover.isShown {
            popover.performClose(sender)
        } else {
            if let button = statusItem.button {
                popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
                // Bring the app to the front to ensure the popover gets focus
                NSApp.activate(ignoringOtherApps: true)
            }
        }
    }
    
    // MARK: - NSPopoverDelegate
    func popoverDidClose(_ notification: Notification) {
        // Optional: Perform any cleanup or state reset when popover closes
        print("Popover closed.")
    }
}

// SwiftUI View for the Popover Content
struct PopoverRootView: View {
    @Binding var isPopoverShown: Bool // Binding to dismiss the popover

    var body: some View {
        VStack {
            Text("Hello, AI Agent!")
                .font(.headline)
                .padding()

            Button("Dismiss") {
                isPopoverShown = false // Toggle the binding to dismiss the popover
            }
            .padding(.horizontal)
            .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}
