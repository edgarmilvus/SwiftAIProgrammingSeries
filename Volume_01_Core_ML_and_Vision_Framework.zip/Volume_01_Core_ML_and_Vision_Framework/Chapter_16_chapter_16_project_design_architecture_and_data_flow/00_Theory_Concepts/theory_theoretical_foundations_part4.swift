
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

@Observable @MainActor // ViewModel should generally be @MainActor for UI updates
class ImageClassificationViewModel {
    private let classifier: ImageClassifierService // The actor instance
    var classificationResult: String?
    var isLoading = false
    var errorMessage: String?
    var inputImage: UIImage? // The image chosen by the user

    init(classifier: ImageClassifierService) {
        self.classifier = classifier
    }

    func classifyCurrentInputImage() async {
        guard let image = inputImage, let pixelBuffer = image.toCVPixelBuffer() else {
            errorMessage = "No image or invalid image format."
            return
        }

        isLoading = true
        errorMessage = nil
        classificationResult = nil

        do {
            // Call the actor function, which runs off the main actor
            let results = try await classifier.performClassification(pixelBuffer: pixelBuffer)
            // Update @Observable properties on the main actor
            classificationResult = results.first // Assuming we only care about the top result for this example
        } catch {
            errorMessage = "Classification failed: \(error.localizedDescription)"
        }
        isLoading = false
    }
}

// Extension to convert UIImage to CVPixelBuffer (simplified)
extension UIImage {
    func toCVPixelBuffer() -> CVPixelBuffer? {
        // Detailed conversion logic (e.g., using Core Image or vImage) would go here.
        // This is a placeholder.
        return nil // Placeholder
    }
}
