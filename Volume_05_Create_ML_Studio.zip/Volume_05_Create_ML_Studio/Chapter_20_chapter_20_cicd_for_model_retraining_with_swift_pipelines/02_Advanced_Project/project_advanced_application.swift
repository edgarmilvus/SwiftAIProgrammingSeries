
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreML
import Combine // For potential future UI updates or reactive patterns.

// MARK: - 1. Model Metadata Structure

/// Represents the metadata for a Core ML model available remotely.
/// This structure allows the app to understand the model's version and where to download it from.
///
/// - `version`: A monotonically increasing version number for the model.
/// - `downloadURL`: The URL from which the model's archive (e.g., a .zip file) can be downloaded.
/// - `archiveFileName`: The expected file name for the downloaded archive, e.g., "DocumentClassifier_v2.zip".
/// - `modelDirectoryName`: The expected name of the .mlmodelc directory after unzipping,
///                         e.g., "DocumentClassifier_v2.mlmodelc".
struct ModelMetadata: Codable, Equatable {
    let version: Int
    let downloadURL: URL
    let archiveFileName: String
    let modelDirectoryName: String
}

// MARK: - 2. Custom Errors for Model Updates

/// Defines specific errors that can occur during the model update process.
enum ModelUpdateError: Error, LocalizedError {
    case invalidRemoteMetadataURL
    case failedToFetchMetadata(Error)
    case invalidMetadataResponse
    case noNewerModelAvailable(currentVersion: Int, latestRemoteVersion: Int)
    case downloadFailed(URLError) // Changed to URLError for clarity
    case fileSystemError(Error)
    case modelCompilationFailed(Error) // If downloaded model is not a valid .mlmodelc
    case modelLoadingFailed(Error)
    case invalidBundledModel
    case noActiveModelFound
    case unzippingFailed(Error)
    case missingModelDirectoryInArchive(String)

    var errorDescription: String? {
        switch self {
        case .invalidRemoteMetadataURL: return "The remote metadata URL is invalid."
        case .failedToFetchMetadata(let error): return "Failed to fetch remote model metadata: \(error.localizedDescription)"
        case .invalidMetadataResponse: return "The remote metadata response was invalid or malformed."
        case .noNewerModelAvailable(let current, let latest): return "No newer model available. Current: v\(current), Latest: v\(latest)."
        case .downloadFailed(let error): return "Failed to download the new model: \(error.localizedDescription)"
        case .fileSystemError(let error): return "File system error during model storage: \(error.localizedDescription)"
        case .modelCompilationFailed(let error): return "Failed to compile the downloaded model: \(error.localizedDescription)"
        case .modelLoadingFailed(let error): return "Failed to load the new Core ML model: \(error.localizedDescription)"
        case .invalidBundledModel: return "The initial bundled model could not be loaded."
        case .noActiveModelFound: return "No active Core ML model could be found or loaded."
        case .unzippingFailed(let error): return "Failed to unzip the downloaded model archive: \(error.localizedDescription)"
        case .missingModelDirectoryInArchive(let dirName): return "The unzipped archive did not contain the expected model directory: \(dirName)."
        }
    }
}

// MARK: - 3. Document Classifier Wrapper

/// A simple wrapper around `MLModel` to provide a consistent interface for document classification.
/// This class handles the actual prediction logic, abstracting away Core ML specifics.
@available(iOS 18.0, *) // Assuming this app targets modern iOS versions for Swift 6 concurrency features.
final class DocumentClassifier {
    private let model: MLModel
    let modelVersion: Int // Stores the version of the currently loaded model.
    let modelIdentifier: String // A unique identifier for the model, useful for debugging.

    /// Initializes the classifier with a compiled Core ML model.
    /// - Parameters:
    ///   - compiledModelURL: The URL to the compiled `.mlmodelc` directory.
    ///   - version: The version number associated with this model.
    /// - Throws: `ModelUpdateError.modelLoadingFailed` if the model cannot be loaded.
    init(compiledModelURL: URL, version: Int) throws {
        let configuration = MLModelConfiguration()
        self.model = try MLModel(contentsOf: compiledModelURL, configuration: configuration)
        self.modelVersion = version
        self.modelIdentifier = compiledModelURL.lastPathComponent
        print("DocumentClassifier initialized with model: \(self.modelIdentifier), version: \(version)")
    }

    /// Predicts the document type for a given input.
    /// - Parameter input: The input feature provider for the model (e.g., an image buffer).
    /// - Returns: A `MLFeatureProvider` containing the prediction results.
    /// - Throws: An error if prediction fails.
    func classify(input: MLFeatureProvider) throws -> MLFeatureProvider {
        return try model.prediction(from: input)
    }
}

// MARK: - 4. Model Update Manager (Core Logic)

/// Manages the lifecycle of Core ML models within the app, including checking for,
/// downloading, and activating updated models from a remote source.
/// This class acts as an `actor` to ensure thread-safe access to the active model
/// and related state during asynchronous operations.
@available(iOS 18.0, *)
actor ModelUpdateManager {
    // MARK: - Properties

    /// The URL to the remote endpoint providing model metadata.
    private let remoteMetadataURL: URL

    /// The directory where downloaded models will be stored locally.
    private let localModelsDirectory: URL

    /// The key used to store the active model's version in `UserDefaults`.
    private let activeModelVersionUserDefaultsKey = "activeDocumentClassifierModelVersion"

    /// The currently active `DocumentClassifier` instance.
    private(set) var activeClassifier: DocumentClassifier? {
        didSet {
            // This ensures that whenever activeClassifier is set, its version is stored.
            if let version = activeClassifier?.modelVersion {
                UserDefaults.standard.set(version, forKey: activeModelVersionUserDefaultsKey)
            }
        }
    }

    /// A `PassthroughSubject` to publish updates about the active model.
    /// Useful for UI components to react to model changes.
    let modelUpdatePublisher = PassthroughSubject<DocumentClassifier, Never>()

    // MARK: - Initialization

    /// Initializes the `ModelUpdateManager`.
    /// - Parameters:
    ///   - remoteMetadataURL: The URL pointing to the JSON metadata file on your server.
    ///   - appGroupIdentifier: Optional. An App Group identifier if models need to be shared
    ///                         across extensions or other apps in the same group.
    ///                         If `nil`, models are stored in the app's default documents directory.
    /// - Throws: `ModelUpdateError` if the initial bundled model cannot be loaded or
    ///           if the local models directory cannot be created.
    init(remoteMetadataURL: URL, appGroupIdentifier: String? = nil) throws {
        self.remoteMetadataURL = remoteMetadataURL

        // Determine the local storage directory for models.
        if let appGroupIdentifier = appGroupIdentifier,
           let groupURL = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupIdentifier) {
            self.localModelsDirectory = groupURL.appendingPathComponent("CoreMLModels", isDirectory: true)
        } else {
            self.localModelsDirectory = try FileManager.default.url(for: .documentDirectory,
                                                                    in: .userDomainMask,
                                                                    appropriateFor: nil,
                                                                    create: true)
                .appendingPathComponent("CoreMLModels", isDirectory: true)
        }

        // Ensure the local models directory exists.
        try FileManager.default.createDirectory(at: localModelsDirectory,
                                                withIntermediateDirectories: true,
                                                attributes: nil)

        // Load the initially bundled model. This is crucial for the app to function immediately.
        Task { // Use a Task to run async in init, but ensure properties are set first.
            do {
                try await loadBundledModel()
            } catch {
                print("Error loading bundled model on init: \(error.localizedDescription)")
                // In a production app, this might be a critical error requiring app termination or a fallback.
            }
        }
    }

    // MARK: - Public API for Model Updates

    /// Checks for a newer model version from the remote server and updates if available.
    /// This is the primary entry point for initiating a model update check.
    /// - Parameter forceUpdate: If `true`, forces a download even if the local version is the same.
    /// - Returns: `true` if a new model was successfully downloaded and activated, `false` otherwise.
    @discardableResult
    func checkForUpdates(forceUpdate: Bool = false) async throws -> Bool {
        print("Starting model update check...")
        do {
            let remoteMetadata = try await fetchRemoteModelMetadata()
            let currentLocalVersion = UserDefaults.standard.integer(forKey: activeModelVersionUserDefaultsKey)

            print("Remote model version: \(remoteMetadata.version), Local active model version: \(currentLocalVersion)")

            guard remoteMetadata.version > currentLocalVersion || forceUpdate else {
                throw ModelUpdateError.noNewerModelAvailable(currentVersion: currentLocalVersion, latestRemoteVersion: remoteMetadata.version)
            }

            print("Newer model (v\(remoteMetadata.version)) available. Downloading and processing...")
            let downloadedModelURL = try await downloadAndProcessModel(
                from: remoteMetadata.downloadURL,
                archiveFileName: remoteMetadata.archiveFileName,
                modelDirectoryName: remoteMetadata.modelDirectoryName
            )

            print("Downloaded and processed model to: \(downloadedModelURL.lastPathComponent). Activating...")
            try await activateModel(at: downloadedModelURL, version: remoteMetadata.version)

            print("Model successfully updated to v\(remoteMetadata.version).")
            return true
        } catch ModelUpdateError.noNewerModelAvailable {
            print("No newer model available. Current model is up to date.")
            return false
        } catch {
            print("Model update failed: \(error.localizedDescription)")
            throw error // Re-throw other errors for external handling.
        }
    }

    // MARK: - Private Helper Methods

    /// Loads the initial Core ML model that is bundled with the application.
    /// This ensures the app has a functional model even without an internet connection.
    private func loadBundledModel() async throws {
        // The bundled model is assumed to be named "DocumentClassifier.mlmodelc" and
        // located in the app's main bundle.
        guard let modelURL = Bundle.main.url(forResource: "DocumentClassifier", withExtension: "mlmodelc") else {
            throw ModelUpdateError.invalidBundledModel
        }
        // Assume bundled model is version 1 for initial setup.
        // In a real app, you might embed its version in its name or an associated plist.
        let bundledVersion = 1 // Example version for the bundled model.
        print("Loading bundled model: \(modelURL.lastPathComponent), version: \(bundledVersion)")
        try await activateModel(at: modelURL, version: bundledVersion)
    }

    /// Fetches the `ModelMetadata` from the remote server.
    /// - Returns: The `ModelMetadata` object if successful.
    /// - Throws: `ModelUpdateError` if fetching or decoding fails.
    private func fetchRemoteModelMetadata() async throws -> ModelMetadata {
        // Allows using a local file URL for metadata during testing/development.
        guard !remoteMetadataURL.isFileURL else {
            let data = try Data(contentsOf: remoteMetadataURL)
            let metadata = try JSONDecoder().decode(ModelMetadata.self, from: data)
            print("Fetched local metadata: \(metadata)")
            return metadata
        }

        let (data, response) = try await URLSession.shared.data(from: remoteMetadataURL)

        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw ModelUpdateError.failedToFetchMetadata(URLError(.badServerResponse))
        }

        let metadata = try JSONDecoder().decode(ModelMetadata.self, from: data)
        print("Fetched remote metadata: \(metadata)")
        return metadata
    }

    /// Downloads the Core ML model archive from the specified URL and processes it.
    /// This typically involves downloading a `.zip` file and then unzipping it to reveal
    /// the `.mlmodelc` directory.
    /// - Parameters:
    ///   - url: The remote URL of the model archive (e.g., a `.zip` file).
    ///   - archiveFileName: The expected file name of the downloaded archive.
    ///   - modelDirectoryName: The expected name of the `.mlmodelc` directory inside the archive.
    /// - Returns: The local URL of the unzipped `.mlmodelc` directory.
    /// - Throws: `ModelUpdateError` if download, file operations, or unzipping fails.
    private func downloadAndProcessModel(from url: URL, archiveFileName: String, modelDirectoryName: String) async throws -> URL {
        let temporaryArchiveURL = FileManager.default.temporaryDirectory.appendingPathComponent(archiveFileName)

        // Clean up any previous temporary archive.
        if FileManager.default.fileExists(atPath: temporaryArchiveURL.path) {
            try FileManager.default.removeItem(at: temporaryArchiveURL)
        }

        // 1. Download the archive (e.g., .zip file)
        let (tempDownloadedFileURL, response) = try await URLSession.shared.download(from: url)

        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw ModelUpdateError.downloadFailed(URLError(.badServerResponse))
        }

        // Move the downloaded temporary file to our own temporary location for processing.
        do {
            try FileManager.default.moveItem(at: tempDownloadedFileURL, to: temporaryArchiveURL)
            print("Downloaded archive to: \(temporaryArchiveURL.path)")
        } catch {
            throw ModelUpdateError.fileSystemError(error)
        }

        // 2. Unzip the archive.
        // IMPORTANT: For a real production app, you would use a robust unzipping library
        // like ZipFoundation (https://github.com/weichsel/ZipFoundation) or implement
        // custom unzipping logic (e.g., using libzip via C interop), as Swift's Foundation
        // does not provide built-in unzipping capabilities.
        //
        // For this pedagogical example, and to adhere to the "no external SPM" directive
        // while demonstrating the *concept* of unzipping, we will simulate the unzipping
        // by creating the expected model directory and removing the archive.
        // In a real app, the unzipped contents would populate this directory.

        let modelDestinationURL = localModelsDirectory.appendingPathComponent(modelDirectoryName, isDirectory: true)

        // Clean up any existing model directory at the destination before unzipping/creating the new one.
        if FileManager.default.fileExists(atPath: modelDestinationURL.path) {
            try FileManager.default.removeItem(at: modelDestinationURL)
        }

        do {
            // Simulate unzipping by creating the target directory.
            // In a real app, this is where ZipFoundation.unzipFile(at:to:) would be called
            // to extract the contents of `temporaryArchiveURL` into `modelDestinationURL`.
            try FileManager.default.createDirectory(at: modelDestinationURL, withIntermediateDirectories: true, attributes: nil)
            print("Simulated unzipping: Created model directory at \(modelDestinationURL.path)")

            // Clean up the downloaded archive after "unzipping".
            try FileManager.default.removeItem(at: temporaryArchiveURL)
        } catch {
            throw ModelUpdateError.unzippingFailed(error)
        }

        // Verify it's a valid compiled model directory (optional but good practice)
        guard FileManager.default.fileExists(atPath: modelDestinationURL.path) &&
              FileManager.default.isDirectory(at: modelDestinationURL) else {
            throw ModelUpdateError.modelCompilationFailed(NSError(domain: "ModelUpdateManager", code: 1, userInfo: [NSLocalizedDescriptionKey: "Processed item is not a valid compiled model directory."]))
        }

        return modelDestinationURL
    }

    /// Activates a new `DocumentClassifier` instance using the provided model URL and version.
    /// This involves loading the Core ML model and updating the `activeClassifier` property.
    /// - Parameters:
    ///   - modelURL: The local URL to the compiled `.mlmodelc` directory.
    ///   - version: The version number of the model being activated.
    /// - Throws: `ModelUpdateError` if the model cannot be loaded.
    private func activateModel(at modelURL: URL, version: Int) async throws {
        do {
            let newClassifier = try DocumentClassifier(compiledModelURL: modelURL, version: version)
            self.activeClassifier = newClassifier // Update the actor's state.
            // UserDefaults update is handled by the didSet of activeClassifier.
            modelUpdatePublisher.send(newClassifier) // Notify subscribers about the update.
            print("Activated new model v\(version) from \(modelURL.lastPathComponent)")
        } catch let coreMLError as NSError {
            // Core ML errors can be complex, wrap them for clarity.
            throw ModelUpdateError.modelLoadingFailed(coreMLError)
        } catch {
            throw ModelUpdateError.modelLoadingFailed(error)
        }
    }

    /// Cleans up older model versions from the local storage, keeping only the active one.
    /// This is an optional maintenance task to manage disk space.
    func cleanupOldModels() async throws {
        guard let activeClassifier = activeClassifier else {
            print("No active classifier to base cleanup on.")
            return
        }

        let activeModelIdentifier = activeClassifier.modelIdentifier
        print("Cleaning up old models. Keeping \(activeModelIdentifier)...")

        let contents = try FileManager.default.contentsOfDirectory(at: localModelsDirectory, includingPropertiesForKeys: nil)

        for itemURL in contents {
            // Remove any item in the local models directory that is not the currently active model.
            // This assumes model identifiers are unique and include version information.
            if itemURL.lastPathComponent != activeModelIdentifier {
                print("Removing old model: \(itemURL.lastPathComponent)")
                try FileManager.default.removeItem(at: itemURL)
            }
        }
        print("Old model cleanup complete.")
    }
}

// MARK: - Extension for FileManager to check if URL is directory
extension FileManager {
    /// Checks if a URL points to an existing directory.
    /// - Parameter url: The URL to check.
    /// - Returns: `true` if the URL points to a directory, `false` otherwise.
    func isDirectory(at url: URL) -> Bool {
        var isDir: ObjCBool = false
        return fileExists(atPath: url.path, isDirectory: &isDir) && isDir.boolValue
    }
}


// MARK: - 5. Example Usage in an App Delegate or Scene Delegate

// This section demonstrates how the ModelUpdateManager would be integrated
// into a real iOS application, typically within an AppDelegate or SceneDelegate,
// or as a singleton managed by an App-level ViewModel.

/// A mock `MLFeatureProvider` for demonstration purposes.
/// In a real app, this would come from an image, audio, or tabular data source.
struct MockImageFeatureProvider: MLFeatureProvider {
    let featureNames: Set<String> = ["image"] // Assuming the model expects an input named "image"

    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "image" {
            // In a real app, this would be an MLMultiArray or CVPixelBuffer from an image.
            // For this example, we return a dummy string value.
            return MLFeatureValue(string: "dummy_image_data")
        }
        return nil
    }
}

/// A mock `AppDelegate` or `SceneDelegate` context to demonstrate usage.
@available(iOS 18.0, *)
class AppDelegateMock: ObservableObject {
    var modelUpdateManager: ModelUpdateManager!
    private var cancellables = Set<AnyCancellable>()

    @Published var currentModelVersion: Int = 0
    @Published var classificationResult: String = "No classification yet."
    @Published var statusMessage: String = "Initializing..."

    init() {
        // --- IMPORTANT: Replace with your actual remote metadata URL ---
        // This URL would point to a JSON file on your server (e.g., S3, CloudFront, custom API)
        // that describes the latest model.
        //
        // For local testing, we'll create a dummy local metadata file pointing to a conceptual v2.
        let tempDir = FileManager.default.temporaryDirectory
        let dummyMetadataURL = tempDir.appendingPathComponent("model_metadata.json")
        createDummyLocalMetadataFile(at: dummyMetadataURL, version: 2, modelName: "DocumentClassifier_v2")

        do {
            // Initialize the manager with the remote (or dummy local) metadata URL.
            // Use a dummy app group for demonstration, or nil if not needed.
            modelUpdateManager = try ModelUpdateManager(remoteMetadataURL: dummyMetadataURL, appGroupIdentifier: "group.com.example.documentScanner")
            statusMessage = "Manager initialized. Loading bundled model..."

            // Subscribe to model updates to react to changes.
            modelUpdateManager.modelUpdatePublisher
                .sink { [weak self] classifier in
                    self?.currentModelVersion = classifier.modelVersion
                    self?.statusMessage = "Active model updated to v\(classifier.modelVersion) (\(classifier.modelIdentifier))"
                    print("App Delegate: Received model update notification. New version: \(classifier.modelVersion)")
                }
                .store(in: &cancellables)

            // Start a background task to check for updates periodically or on app launch.
            Task {
                // Ensure the bundled model is loaded first (handled in init, but good to ensure).
                await modelUpdateManager.activeClassifier // Accessing actor state.
                self.currentModelVersion = await modelUpdateManager.activeClassifier?.modelVersion ?? 0

                // Perform an initial check for updates after a short delay.
                try await Task.sleep(for: .seconds(2))
                do {
                    _ = try await modelUpdateManager.checkForUpdates()
                    // In a real app, you would schedule periodic checks using Timer or BackgroundTasks framework.
                } catch {
                    self.statusMessage = "Error checking for updates: \(error.localizedDescription)"
                }

                // Simulate a classification task with the potentially new model.
                await simulateClassification()
            }

        } catch {
            print("Failed to initialize ModelUpdateManager: \(error.localizedDescription)")
            statusMessage = "Initialization failed: \(error.localizedDescription)"
        }
    }

    /// Simulates a document classification using the currently active model.
    func simulateClassification() async {
        do {
            guard let classifier = await modelUpdateManager.activeClassifier else {
                throw ModelUpdateError.noActiveModelFound
            }

            let input = MockImageFeatureProvider() // Replace with actual image input.
            let output = try classifier.classify(input: input)

            // Assuming the model outputs a 'label' string.
            if let predictedLabel = output.featureValue(for: "label")?.stringValue {
                classificationResult = "Classified as: \(predictedLabel) (Model v\(classifier.modelVersion) - \(classifier.modelIdentifier))"
                print("Classification result: \(predictedLabel) (Model v\(classifier.modelVersion))")
            } else {
                classificationResult = "Classification successful, but no 'label' output found."
            }
        } catch {
            classificationResult = "Classification failed: \(error.localizedDescription)"
            print("Classification failed: \(error.localizedDescription)")
        }
    }

    /// Creates a dummy `model_metadata.json` file for local testing.
    /// In a real scenario, this would be served from a remote CDN/server.
    private func createDummyLocalMetadataFile(at url: URL, version: Int, modelName: String) {
        // Placeholder URL for the actual model archive download.
        // In a real CI/CD, this would be the URL to a .zip file on your CDN.
        let dummyModelDownloadURL = URL(string: "https://example.com/models/\(modelName).zip")!
        let metadata = ModelMetadata(
            version: version,
            downloadURL: dummyModelDownloadURL,
            archiveFileName: "\(modelName).zip",
            modelDirectoryName: "\(modelName).mlmodelc"
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        do {
            let data = try encoder.encode(metadata)
            try data.write(to: url)
            print("Dummy metadata file created/updated to v\(version) at: \(url.path)")
        } catch {
            print("Failed to create dummy metadata file: \(error.localizedDescription)")
        }
    }

    /// Simulates a scenario where a new model is "released" and the app checks again.
    func simulateNewModelReleaseAndCheck() async {
        statusMessage = "Simulating new model release..."
        let tempDir = FileManager.default.temporaryDirectory
        let dummyMetadataURL = tempDir.appendingPathComponent("model_metadata.json")

        // Create metadata for version 3
        createDummyLocalMetadataFile(at: dummyMetadataURL, version: 3, modelName: "DocumentClassifier_v3")

        statusMessage = "Dummy metadata updated to v3. Re-checking for updates..."

        // Now, trigger another check for updates
        do {
            try await Task.sleep(for: .seconds(1))
            _ = try await modelUpdateManager.checkForUpdates()
            await simulateClassification() // Classify with the potentially new model
        } catch {
            statusMessage = "Error simulating new model release: \(error.localizedDescription)"
            print("Failed to update dummy metadata or check for updates: \(error.localizedDescription)")
        }
    }
}

/*
// MARK: - Swift Package Manager Dependencies (if needed)
// This section would be part of your Package.swift file.
// For this example, we are using only built-in frameworks.

// Package.swift
// A Swift Package Manager manifest file for your project.

import PackageDescription

let package = Package(
    name: "DocumentScannerApp",
    platforms: [
        .iOS(.v18), // Targeting iOS 18 for Swift 6 features like Actors and improved concurrency
        .macOS(.v15),
        .watchOS(.v11),
        .tvOS(.v18)
    ],
    products: [
        .library(
            name: "DocumentScannerCore",
            targets: ["DocumentScannerCore"]),
    ],
    dependencies: [
        // For production-grade unzipping, you would typically add a dependency like ZipFoundation:
        // .package(url: "https://github.com/weichsel/ZipFoundation.git", .upToNextMajor(from: "0.9.0"))
        //
        // If your remote model storage requires specific client libraries (e.g., AWS S3 SDK):
        // .package(url: "https://github.com/awslabs/aws-sdk-swift", .upToNextMajor(from: "0.1.0"))
    ],
    targets: [
        .target(
            name: "DocumentScannerCore",
            dependencies: [
                // "ZipFoundation", // If using ZipFoundation for unzipping
                // "AWSS3", // If using AWS S3 for model storage
            ],
            // Core ML models are typically added as resources to the target.
            // For dynamic loading, they are downloaded, so not directly in bundle resources here.
            // However, the initial bundled model (e.g., v1) *must* be included.
            resources: [
                .process("DocumentClassifier.mlmodelc")
            ]
        ),
        .testTarget(
            name: "DocumentScannerCoreTests",
            dependencies: ["DocumentScannerCore"]),
    ]
)
*/



::: {style="text-align: center"}
![Integrating the compiled `DocumentClassifier.mlmodelc` Core ML model for document classification into a Swift package.](images/b5_c20_s3_diag1.png){width=80% caption="Integrating the compiled `DocumentClassifier.mlmodelc` Core ML model for document classification into a Swift package."}
:::


