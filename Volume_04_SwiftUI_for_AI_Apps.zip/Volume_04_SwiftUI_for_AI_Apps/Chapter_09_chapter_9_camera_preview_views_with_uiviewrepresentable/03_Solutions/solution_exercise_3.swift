
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import AVFoundation
import UIKit

// MARK: - CameraManager: Manages AVCaptureSession and camera controls

@available(iOS 18.0, *)
class CameraManager: NSObject, ObservableObject {
    @Published var currentCameraPosition: AVCaptureDevice.Position = .back
    @Published var isTorchOn: Bool = false
    @Published var isCameraAvailable: Bool = false
    @Published var canSwitchCamera: Bool = false
    @Published var canToggleTorch: Bool = false
    @Published var setupError: String?

    let session = AVCaptureSession()
    private var videoInput: AVCaptureDeviceInput?
    private var currentVideoDevice: AVCaptureDevice?

    override init() {
        super.init()
        // Start observing session runtime errors and interruptions
        NotificationCenter.default.addObserver(self, selector: #selector(sessionRuntimeError), name: .AVCaptureSessionRuntimeError, object: session)
        NotificationCenter.default.addObserver(self, selector: #selector(sessionWasInterrupted), name: .AVCaptureSessionWasInterrupted, object: session)
        NotificationCenter.default.addObserver(self, selector: #selector(sessionInterruptionEnded), name: .AVCaptureSessionInterruptionEnded, object: session)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
        stopSession()
    }

    // MARK: - Session Setup

    func setupSession() {
        DispatchQueue.global(qos: .userInitiated).async {
            // Check if session is already running or being configured
            guard !self.session.isRunning && self.session.inputs.isEmpty else { return }

            self.session.beginConfiguration()
            defer { self.session.commitConfiguration() }

            // Clear previous inputs
            for input in self.session.inputs {
                self.session.removeInput(input)
            }

            // Determine initial camera device based on currentCameraPosition
            guard let videoDevice = self.cameraDevice(for: self.currentCameraPosition) else {
                DispatchQueue.main.async {
                    self.setupError = "No camera available for position \(self.currentCameraPosition.rawValue)."
                    self.isCameraAvailable = false
                }
                return
            }

            self.currentVideoDevice = videoDevice

            // Create input
            guard let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
                DispatchQueue.main.async {
                    self.setupError = "Could not create AVCaptureDeviceInput."
                    self.isCameraAvailable = false
                }
                return
            }

            // Add input to session
            if self.session.canAddInput(videoInput) {
                self.session.addInput(videoInput)
                self.videoInput = videoInput
                DispatchQueue.main.async {
                    self.isCameraAvailable = true
                    self.updateControlAvailability()
                    self.setupError = nil // Clear any previous errors
                }
            } else {
                DispatchQueue.main.async {
                    self.setupError = "Could not add video input to session."
                    self.isCameraAvailable = false
                }
            }
        }
    }

    // MARK: - Session Lifecycle

    func startSession() {
        DispatchQueue.global(qos: .userInitiated).async {
            if !self.session.isRunning {
                self.session.startRunning()
                print("AVCaptureSession started.")
            }
        }
    }

    func stopSession() {
        DispatchQueue.global(qos: .userInitiated).async {
            if self.session.isRunning {
                self.session.stopRunning()
                print("AVCaptureSession stopped.")
            }
        }
    }

    // MARK: - Camera Switching

    func switchCamera() {
        DispatchQueue.global(qos: .userInitiated).async {
            guard self.canSwitchCamera else { return }

            self.session.beginConfiguration()
            defer { self.session.commitConfiguration() }

            // Determine new camera position
            let newPosition: AVCaptureDevice.Position = (self.currentCameraPosition == .back) ? .front : .back
            guard let newVideoDevice = self.cameraDevice(for: newPosition) else {
                DispatchQueue.main.async { self.setupError = "Could not find camera for position \(newPosition.rawValue)." }
                return
            }

            // Create new input
            guard let newVideoInput = try? AVCaptureDeviceInput(device: newVideoDevice) else {
                DispatchQueue.main.async { self.setupError = "Could not create input for new camera." }
                return
            }

            // Remove existing input
            if let currentInput = self.videoInput {
                self.session.removeInput(currentInput)
            }

            // Add new input
            if self.session.canAddInput(newVideoInput) {
                self.session.addInput(newVideoInput)
                self.videoInput = newVideoInput
                self.currentVideoDevice = newVideoDevice
                DispatchQueue.main.async {
                    self.currentCameraPosition = newPosition
                    self.updateControlAvailability()
                    self.setupError = nil
                }
            } else {
                DispatchQueue.main.async { self.setupError = "Could not add new video input to session." }
                // Re-add the old input if the new one failed
                if let currentInput = self.videoInput, self.session.canAddInput(currentInput) {
                    self.session.addInput(currentInput)
                }
            }
        }
    }

    private func cameraDevice(for position: AVCaptureDevice.Position) -> AVCaptureDevice? {
        // Prioritize built-in wide-angle camera
        if let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: position) {
            return device
        }
        // Fallback to any video device
        return AVCaptureDevice.default(for: .video)
    }

    // MARK: - Torch Control

    func toggleTorch() {
        DispatchQueue.global(qos: .userInitiated).async {
            guard let device = self.currentVideoDevice, device.hasTorch && device.isTorchAvailable else {
                DispatchQueue.main.async { self.setupError = "Torch not available or supported." }
                return
            }

            do {
                try device.lockForConfiguration()
                if device.torchMode == .on {
                    device.torchMode = .off
                    DispatchQueue.main.async { self.isTorchOn = false }
                } else {
                    try device.setTorchModeOn(level: 1.0) // 1.0 is max level
                    DispatchQueue.main.async { self.isTorchOn = true }
                }
                device.unlockForConfiguration()
            } catch {
                DispatchQueue.main.async { self.setupError = "Could not configure torch: \(error.localizedDescription)" }
            }
        }
    }

    // MARK: - Control Availability Update

    private func updateControlAvailability() {
        DispatchQueue.main.async {
            self.canSwitchCamera = AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInWideAngleCamera, .builtInDualCamera, .builtInTrueDepthCamera], mediaType: .video, position: .unspecified).devices.count > 1
            self.canToggleTorch = self.currentVideoDevice?.hasTorch ?? false
        }
    }

    // MARK: - Session Notifications

    @objc private func sessionRuntimeError(notification: Notification) {
        guard let error = notification.userInfo?[AVCaptureSessionErrorKey] as? AVError else { return }
        print("AVCaptureSession runtime error: \(error)")
        DispatchQueue.main.async { self.setupError = "Camera runtime error: \(error.localizedDescription)" }
    }

    @objc private func sessionWasInterrupted(notification: Notification) {
        print("AVCaptureSession was interrupted.")
        // You might want to update UI to indicate interruption
        DispatchQueue.main.async { self.setupError = "Camera session interrupted." }
    }

    @objc private func sessionInterruptionEnded(notification: Notification) {
        print("AVCaptureSession interruption ended.")
        // Resume UI state
        DispatchQueue.main.async { self.setupError = nil } // Clear interruption error
    }
}

// MARK: - CameraPreview for Exercise 3 (uses CameraManager's session)

@available(iOS 18.0, *)
struct CameraPreviewForControls: UIViewRepresentable {
    @ObservedObject var cameraManager: CameraManager
    private var previewLayer: AVCaptureVideoPreviewLayer?

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        view.backgroundColor = .black

        // The preview layer needs to be created on the main thread and linked to the session
        let layer = AVCaptureVideoPreviewLayer(session: cameraManager.session)
        layer.videoGravity = .resizeAspectFill
        layer.frame = view.bounds
        view.layer.addSublayer(layer)
        self.previewLayer = layer // Store reference

        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        // Update frame if view bounds change
        if let layer = previewLayer {
            layer.frame = uiView.bounds
            // Optionally update video orientation here if tracking device orientation
            // For this exercise, we focus on camera/flash control, orientation is in Ex4.
        }
    }
}

// MARK: - SwiftUI View with Camera Controls for Exercise 3

@available(iOS 18.0, *)
struct Exercise3WrapperView: View {
    @StateObject private var cameraManager = CameraManager()
    @State private var cameraAuthorizationStatus: AVAuthorizationStatus = .notDetermined

    var body: some View {
        Group {
            switch cameraAuthorizationStatus {
            case .authorized:
                ZStack {
                    // Camera preview fills the background
                    CameraPreviewForControls(cameraManager: cameraManager)
                        .ignoresSafeArea()

                    VStack {
                        Spacer() // Pushes controls to the bottom

                        if let error = cameraManager.setupError {
                            Text("Error: \(error)")
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.red.opacity(0.8))
                                .cornerRadius(10)
                                .padding(.bottom, 10)
                        }

                        HStack {
                            // Flash/Torch Control
                            Button {
                                cameraManager.toggleTorch()
                            } label: {
                                Image(systemName: cameraManager.isTorchOn ? "bolt.fill" : "bolt.slash.fill")
                                    .font(.title2)
                                    .padding()
                                    .background(cameraManager.isTorchOn ? Color.yellow.opacity(0.8) : Color.gray.opacity(0.6))
                                    .foregroundColor(.white)
                                    .clipShape(Circle())
                            }
                            .disabled(!cameraManager.canToggleTorch || !cameraManager.isCameraAvailable)
                            .opacity((!cameraManager.canToggleTorch || !cameraManager.isCameraAvailable) ? 0.5 : 1.0) // Dim if disabled


                            Spacer() // Pushes buttons apart

                            // Camera Switching Control
                            Button {
                                cameraManager.switchCamera()
                            } label: {
                                Image(systemName: "arrow.triangle.2.circlepath")
                                    .font(.title2)
                                    .padding()
                                    .background(Color.gray.opacity(0.6))
                                    .foregroundColor(.white)
                                    .clipShape(Circle())
                            }
                            .disabled(!cameraManager.canSwitchCamera || !cameraManager.isCameraAvailable)
                            .opacity((!cameraManager.canSwitchCamera || !cameraManager.isCameraAvailable) ? 0.5 : 1.0) // Dim if disabled
                        }
                        .padding()
                        .background(Color.black.opacity(0.3)) // Semi-transparent background for controls
                    }
                }
                .onAppear {
                    // Setup and start session when authorized and view appears
                    cameraManager.setupSession()
                    cameraManager.startSession()
                }
                .onDisappear {
                    cameraManager.stopSession()
                }

            case .notDetermined:
                VStack {
                    ProgressView()
                    Text("Requesting Camera Access...")
                }
                .onAppear(perform: requestCameraPermission)
            case .denied, .restricted:
                VStack(spacing: 20) {
                    Image(systemName: "video.slash.fill").resizable().scaledToFit().frame(width: 80, height: 80).foregroundColor(.gray)
                    Text("Camera access is required for document scanning.").font(.headline).multilineTextAlignment(.center)
                    Button("Open Settings") {
                        if let url = URL(string: UIApplication.openSettingsURLString) {
                            UIApplication.shared.open(url, options: [:], completionHandler: nil)
                        }
                    }.buttonStyle(.borderedProminent)
                }.padding()
            @unknown default:
                Text("Unknown camera authorization status.")
            }
        }
        .onAppear(perform: checkCameraPermissionStatus)
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
            checkCameraPermissionStatus()
        }
    }

    // MARK: - Permission Handling (Duplicated from Ex2 for self-containment)

    private func checkCameraPermissionStatus() {
        DispatchQueue.main.async {
            self.cameraAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: .video)
        }
    }

    private func requestCameraPermission() {
        AVCaptureDevice.requestAccess(for: .video) { granted in
            DispatchQueue.main.async {
                self.cameraAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: .video)
            }
        }
    }
}
