
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

@Observable // This would typically be on a data model or view model
@available(iOS 18.0, *)
class DocumentStore {
    static let shared = DocumentStore()
    var documents: [Document] = []

    struct Document: Identifiable, Hashable, Codable {
        let id = UUID()
        var title: String
        var content: String
    }

    init() {
        // Simulate loading documents
        documents = [
            Document(title: "Meeting Notes Q3", content: "Key decisions from Q3 meeting..."),
            Document(title: "Project Alpha Proposal", content: "Detailed proposal for Project Alpha...")
        ]
    }

    func addDocument(title: String, content: String) {
        documents.append(Document(title: title, content: content))
    }
}

@available(iOS 18.0, *)
struct SelectDocumentIntent: AppIntent {
    static var title: LocalizedStringResource = "Select Document"

    @Parameter(title: "Document")
    var selectedDocument: DocumentStore.Document?

    static var parameterEditor: some ParameterEditor {
        ParameterEditor(keyPath: \.$selectedDocument) {
            // Dynamic options for the document parameter
            // This closure is evaluated by the system to provide options
            // The system observes changes to DocumentStore.shared.documents
            // and updates the UI accordingly.
            DocumentStore.shared.documents.map { document in
                // Provide a custom display representation for each document
                // This is how the document appears in the Shortcuts app or Siri UI
                DynamicOption(id: document.id, title: document.title, subtitle: nil)
            }
        }
    }

    func perform() async throws -> some IntentResult {
        guard let document = selectedDocument else {
            return .failure("No document selected.")
        }
        return .result(dialog: "You selected: \(document.title)")
    }
}
