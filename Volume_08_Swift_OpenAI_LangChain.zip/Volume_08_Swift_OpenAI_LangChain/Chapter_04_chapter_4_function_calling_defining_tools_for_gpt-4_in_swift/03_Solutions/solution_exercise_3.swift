
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

/// A custom enum to handle polymorphic JSON values.
/// This allows us to decode a dictionary that contains various types.
enum JSONValue: Codable, Sendable {
    case string(String)
    case number(Double)
    case bool(Bool)
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let x = try? container.decode(String.self) { self = .string(x); return }
        if let x = try? container.decode(Double.self) { self = .number(x); return }
        if let x = try? container.decode(Bool.self) { self = .bool(x); return }
        throw DecodingError.typeMismatch(JSONValue.self, .init(codingPath: decoder.codingPath, debugDescription: "Unsupported JSON type"))
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .string(let x): try container.encode(x)
        case .number(let x): try container.encode(x)
        case .bool(let x): try container.encode(x)
        }
    }
}

struct DeviceConfig: Codable, Sendable {
    let deviceId: String
    let action: String
    let parameters: [String: JSONValue] // Polymorphic dictionary
    
    enum CodingKeys: String, CodingKey {
        case deviceId = "device_id"
        case action
        case parameters
    }
}

struct SceneConfig: Codable, Sendable {
    let sceneName: String
    let deviceConfigurations: [DeviceConfig]
    
    enum CodingKeys: String, CodingKey {
        case sceneName = "scene_name"
        case deviceConfigurations = "device_configurations"
    }
}

actor HomeState {
    private var deviceStates: [String: String] = [:]
    
    func apply(config: SceneConfig) throws {
        // Ambiguity Check
        let knownScenes = ["Movie", "Relax", "Away"]
        if !knownScenes.contains(config.sceneName) && config.deviceConfigurations.isEmpty {
            throw NSError(domain: "HomeSync", code: 400, userInfo: [NSLocalizedDescriptionKey: "Error: Ambiguous scene. Please specify devices or a known scene name (Movie, Relax, Away)."])
        }
        
        for dev in config.deviceConfigurations {
            deviceStates[dev.deviceId] = "Action: \(dev.action) with \(dev.parameters.count) params"
            print("🏠 Device \(dev.deviceId) updated to \(dev.action)")
        }
    }
}

struct HomeSceneDispatcher {
    let state: HomeState
    
    func dispatch(argumentsJSON: Data) async throws -> String {
        let decoder = JSONDecoder()
        let config = try decoder.decode(SceneConfig.self, from: argumentsJSON)
        
        try await state.apply(config: config)
        return "Scene '\(config.sceneName)' applied successfully."
    }
}

// --- Testing Complex Polymorphism ---
Task {
    let home = HomeState()
    let dispatcher = HomeSceneDispatcher(state: home)
    
    let complexInput = """
    {
        "scene_name": "Movie Night",
        "device_configurations": [
            {
                "device_id": "living_room_light_1",
                "action": "set_brightness",
                "parameters": { "brightness": 30 }
            },
            {
                "device_id": "main_thermostat",
                "action": "set_temperature",
                "parameters": { "temperature": 21.5, "mode": "eco" }
            }
        ]
    }
    """.data(using: .utf8)!
    
    do {
        let result = try await dispatcher.dispatch(argumentsJSON: complexInput)
        print("✅ \(result)")
    } catch {
        print("❌ \(error.localizedDescription)")
    }
}
