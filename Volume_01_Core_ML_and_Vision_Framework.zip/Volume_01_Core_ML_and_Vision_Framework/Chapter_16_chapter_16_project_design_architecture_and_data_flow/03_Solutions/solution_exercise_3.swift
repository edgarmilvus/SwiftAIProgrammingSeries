
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// MARK: - Model Layer

import CoreML
import Vision
import UIKit
import Combine
import PhotosUI // For PHPickerViewController

struct DetectedObject: Identifiable {
    let id = UUID() // For SwiftUI List/ForEach
    let boundingBox: CGRect // Normalized CGRect (0-1)
    let label: String
    let confidence: Float
}

struct ImageDetectionResult: Identifiable {
    let id = UUID()
    let originalImage: UIImage
    let detectedObjects: [DetectedObject]
    let processingTime: TimeInterval? // Optional: for performance metrics
    var annotatedImage: UIImage? // Add property to store the image with bounding boxes
}

enum ObjectDetectionError: Error, LocalizedError {
    case modelLoadingFailed(Error)
    case imageConversionFailed
    case predictionFailed(Error)
    case noObjectsDetected

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let error): return "Failed to load Core ML model: \(error.localizedDescription)"
        case .imageConversionFailed: return "Failed to convert image for detection."
        case .predictionFailed(let error): return "Object detection failed: \(error.localizedDescription)"
        case .noObjectsDetected: return "No objects were detected in the image."
        }
    }
}

// MARK: - ObjectDetectionService

class ObjectDetectionService {
    private let model: VNCoreMLModel

    init(modelName: String = "YOLOv3FP16") throws { // Assume YOLOv3FP16.mlmodelc is available
        guard let url = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            // Fallback to compile if .mlmodelc not found
            guard let mlmodelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodel") else {
                throw ObjectDetectionError.modelLoadingFailed(NSError(domain: "ObjectDetectionService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model file not found: \(modelName).mlmodel or \(modelName).mlmodelc"]))
            }
            let compiledURL = try MLModel.compileModel(at: mlmodelURL)
            let coreMLModel = try MLModel(contentsOf: compiledURL)
            self.model = try VNCoreMLModel(for: coreMLModel)
            return
        }
        let coreMLModel = try MLModel(contentsOf: url)
        self.model = try VNCoreMLModel(for: coreMLModel)
    }

    @available(iOS 18.0, *)
    func detectObjects(in image: UIImage) async throws -> [DetectedObject] {
        guard let cgImage = image.cgImage else {
            throw ObjectDetectionError.imageConversionFailed
        }

        return try await withCheckedThrowingContinuation { continuation in
            let request = VNCoreMLRequest(model: model) { request, error in
                if let error = error {
                    continuation.resume(throwing: ObjectDetectionError.predictionFailed(error))
                    return
                }

                guard let observations = request.results as? [VNRecognizedObjectObservation] else {
                    continuation.resume(returning: []) // No objects detected is not an error here, just an empty array
                    return
                }

                let detectedObjects = observations.map { observation in
                    // Vision bounding box is normalized (0-1) and origin is bottom-left.
                    // VNImageRectForNormalizedRect converts it to UIKit's absolute top-left origin.
                    let boundingBox = VNImageRectForNormalizedRect(observation.boundingBox,
                                                                   Int(image.size.width),
                                                                   Int(image.size.height))
                    let label = observation.labels.first?.identifier ?? "Unknown"
                    let confidence = observation.labels.first?.confidence ?? 0.0
                    return DetectedObject(boundingBox: boundingBox, label: label, confidence: confidence)
                }
                continuation.resume(returning: detectedObjects)
            }

            request.imageCropAndScaleOption = .scaleFit // Adjust as per model requirements (e.g., .scaleFill, .centerCrop)

            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: ObjectDetectionError.predictionFailed(error))
            }
        }
    }
}

// MARK: - DetectionCoordinator (ViewModel)

class DetectionCoordinator {
    private let objectDetectionService: ObjectDetectionService
    private var cancellables = Set<AnyCancellable>()

    // Publisher for individual results as they become available
    private let _detectionResults = PassthroughSubject<ImageDetectionResult, Error>()
    var detectionResults: AnyPublisher<ImageDetectionResult, Error> {
        _detectionResults.eraseToAnyPublisher()
    }

    // Publisher for overall loading state
    private let _isLoading = CurrentValueSubject<Bool, Never>(false)
    var isLoading: AnyPublisher<Bool, Never> {
        _isLoading.eraseToAnyPublisher()
    }

    // A reference to the TaskGroup to allow for external cancellation
    private var detectionTaskGroup: TaskGroup<Void>?

    init(objectDetectionService: ObjectDetectionService) {
        self.objectDetectionService = objectDetectionService
    }

    @available(iOS 18.0, *)
    func processImages(_ images: [UIImage]) {
        guard !_isLoading.value else {
            print("Detection already in progress. Ignoring new request.")
            return
        } // Prevent multiple concurrent runs
        _isLoading.send(true)

        // Launch a top-level Task that manages a TaskGroup for concurrent image processing
        Task {
            await withTaskGroup(of: Void.self) { group in
                self.detectionTaskGroup = group // Store group reference for cancellation

                for image in images {
                    // Check for cancellation before starting a new task
                    guard !Task.isCancelled else { break }

                    group.addTask { [weak self] in
                        guard let self = self else { return }
                        do {
                            let startTime = Date()
                            let detectedObjects = try await self.objectDetectionService.detectObjects(in: image)
                            let processingTime = Date().timeIntervalSince(startTime)
                            
                            // Annotate the image with bounding boxes
                            let annotatedImage = image.drawBoundingBoxes(objects: detectedObjects)

                            let result = ImageDetectionResult(
                                originalImage: image,
                                detectedObjects: detectedObjects,
                                processingTime: processingTime,
                                annotatedImage: annotatedImage
                            )
                            // Publish result on the main actor as soon as it's ready
                            await MainActor.run {
                                self._detectionResults.send(result)
                            }
                        } catch {
                            // If a single image fails, send an error but allow others to continue
                            print("Error processing image: \(error.localizedDescription)")
                            await MainActor.run {
                                self._detectionResults.send(completion: .failure(error))
                            }
                        }
                    }
                }
                await group.waitForAll() // Wait for all child tasks to complete
                
                // Signal completion of the entire batch
                await MainActor.run {
                    self._isLoading.send(false)
                    // Only send .finished if no errors occurred and not cancelled
                    if !Task.isCancelled {
                         self._detectionResults.send(completion: .finished)
                    }
                }
            }
            // Clear the group reference once all tasks are done or cancelled
            self.detectionTaskGroup = nil
        }
    }

    @available(iOS 18.0, *)
    func cancelAllDetections() {
        // Cancelling the TaskGroup will propagate cancellation to all its child tasks
        detectionTaskGroup?.cancelAll()
        print("All detection tasks cancelled.")
        _isLoading.send(false)
        // Send .finished to signal that the stream is closing due to cancellation
        _detectionResults.send(completion: .finished)
    }
}

// MARK: - UIImageView Extension (for drawing bounding boxes)
// This utility helps visualize the detected objects on the image.
extension UIImage {
    func drawBoundingBoxes(objects: [DetectedObject], scale: CGFloat = 1.0) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: self.size)
        let newImage = renderer.image { context in
            self.draw(at: .zero) // Draw the original image

            context.cgContext.setStrokeColor(UIColor.red.cgColor)
            context.cgContext.setLineWidth(2.0 / scale)
            context.cgContext.setFillColor(UIColor.red.withAlphaComponent(0.2).cgColor)

            for object in objects {
                // object.boundingBox is already in UIKit-compatible absolute coordinates
                let rect = object.boundingBox

                context.cgContext.addRect(rect)
                context.cgContext.drawPath(using: .fillStroke)

                // Draw label background
                let labelText = object.label
                let textFont = UIFont.systemFont(ofSize: 14.0 / scale)
                let paragraphStyle = NSMutableParagraphStyle()
                paragraphStyle.alignment = .center
                let textAttributes: [NSAttributedString.Key: Any] = [
                    .font: textFont,
                    .foregroundColor: UIColor.white,
                    .paragraphStyle: paragraphStyle
                ]
                let attributedText = NSAttributedString(string: labelText, attributes: textAttributes)
                
                let labelSize = attributedText.size()
                let labelRect = CGRect(x: rect.minX, y: rect.minY - labelSize.height, width: max(rect.width, labelSize.width + 8), height: labelSize.height + 4)
                
                // Draw a semi-transparent background for the label
                UIColor.red.withAlphaComponent(0.7).setFill()
                context.cgContext.fill(labelRect)
                
                // Draw the label text
                attributedText.draw(in: labelRect.insetBy(dx: 4, dy: 2))
            }
        }
        return newImage
    }
}

// MARK: - ViewController Layer (Conceptual Implementation)

class WildlifeSpotterViewController: UIViewController, PHPickerViewControllerDelegate {
    private var coordinator: DetectionCoordinator!
    private var cancellables = Set<AnyCancellable>()
    
    // UI Outlets (simulated)
    let selectImagesButton = UIButton(type: .system)
    let cancelButton = UIButton(type: .system)
    let activityIndicator = UIActivityIndicatorView(style: .large)
    let resultsStackView = UIStackView() // To display multiple image results
    let statusLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        do {
            let service = try ObjectDetectionService()
            coordinator = DetectionCoordinator(objectDetectionService: service)
            setupBindings()
        } catch {
            print("Failed to initialize ObjectDetectionService: \(error.localizedDescription)")
            statusLabel.text = "Error: \(error.localizedDescription)"
            statusLabel.textColor = .red
            selectImagesButton.isEnabled = false
        }
    }
    
    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .white
        
        selectImagesButton.setTitle("Select Images", for: .normal)
        selectImagesButton.addTarget(self, action: #selector(selectImagesTapped), for: .touchUpInside)
        selectImagesButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(selectImagesButton)
        
        cancelButton.setTitle("Cancel All", for: .normal)
        cancelButton.addTarget(self, action: #selector(cancelTapped), for: .touchUpInside)
        cancelButton.isEnabled = false // Disabled initially
        cancelButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(cancelButton)
        
        activityIndicator.hidesWhenStopped = true
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(activityIndicator)
        
        statusLabel.textAlignment = .center
        statusLabel.numberOfLines = 0
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(statusLabel)
        
        resultsStackView.axis = .vertical
        resultsStackView.spacing = 20
        resultsStackView.translatesAutoresizingMaskIntoConstraints = false
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(resultsStackView)
        view.addSubview(scrollView)
        
        NSLayoutConstraint.activate([
            selectImagesButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            selectImagesButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            
            cancelButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            cancelButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.topAnchor.constraint(equalTo: selectImagesButton.bottomAnchor, constant: 10),
            
            statusLabel.topAnchor.constraint(equalTo: activityIndicator.bottomAnchor, constant: 10),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            scrollView.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 20),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            
            resultsStackView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            resultsStackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            resultsStackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            resultsStackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            resultsStackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor) // Important for vertical scrolling
        ])
    }

    // MARK: - Combine Bindings
    private func setupBindings() {
        guard #available(iOS 18.0, *) else { return }

        coordinator.isLoading
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isLoading in
                isLoading ? self?.activityIndicator.startAnimating() : self?.activityIndicator.stopAnimating()
                self?.selectImagesButton.isEnabled = !isLoading
                self?.cancelButton.isEnabled = isLoading
                if !isLoading {
                    self?.statusLabel.text = "Ready to detect objects."
                }
            }
            .store(in: &cancellables)

        coordinator.detectionResults
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { [weak self] completion in
                switch completion {
                case .finished:
                    self?.statusLabel.text = "All images processed."
                    print("Detection stream finished.")
                case .failure(let error):
                    self?.statusLabel.text = "Error: \(error.localizedDescription)"
                    print("Detection stream failed with error: \(error)")
                }
            }, receiveValue: { [weak self] result in
                self?.addResultToUI(result: result)
            })
            .store(in: &cancellables)
    }
    
    // MARK: - UI Update Helpers
    private func addResultToUI(result: ImageDetectionResult) {
        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        
        let imageView = UIImageView(image: result.annotatedImage ?? result.originalImage)
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(imageView)
        
        let label = UILabel()
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 14)
        label.text = "Detected: \(result.detectedObjects.map { $0.label }.joined(separator: ", "))\n" +
                     "Time: \(String(format: "%.2f", result.processingTime ?? 0))s"
        label.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(label)
        
        resultsStackView.addArrangedSubview(containerView)
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: containerView.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
            imageView.heightAnchor.constraint(equalToConstant: 200), // Fixed height for display
            
            label.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 5),
            label.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
            label.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
            label.bottomAnchor.constraint(equalTo: containerView.bottomAnchor)
        ])
    }

    // MARK: - User Actions
    @objc func selectImagesTapped() {
        var configuration = PHPickerConfiguration()
        configuration.filter = .images
        configuration.selectionLimit = 0 // 0 for unlimited selection
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = self
        present(picker, animated: true)
        
        // Clear previous results
        resultsStackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        statusLabel.text = "Selecting images..."
    }
    
    @objc func cancelTapped() {
        if #available(iOS 18.0, *) {
            coordinator.cancelAllDetections()
            statusLabel.text = "Detection cancelled."
        }
    }

    // MARK: - PHPickerViewControllerDelegate
    @available(iOS 14, *)
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        
        guard #available(iOS 18.0, *) else {
            statusLabel.text = "iOS 18.0 or later is required for this async operation."
            return
        }

        guard !results.isEmpty else {
            statusLabel.text = "No images selected."
            return
        }

        statusLabel.text = "Loading images..."
        var images: [UIImage] = []
        let itemProviderLoadTasks = results.map { result in
            Task {
                if result.itemProvider.canLoadObject(ofClass: UIImage.self) {
                    return try await result.itemProvider.loadObject(ofClass: UIImage.self) as? UIImage
                }
                return nil
            }
        }
        
        Task { @MainActor in
            for task in itemProviderLoadTasks {
                if let image = await task.value {
                    images.append(image)
                }
            }
            
            if images.isEmpty {
                statusLabel.text = "Failed to load any images."
                return
            }
            
            statusLabel.text = "Processing \(images.count) images..."
            coordinator.processImages(images)
        }
    }
}
