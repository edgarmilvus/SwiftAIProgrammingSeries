
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation

// Represents a single item in our dataset that needs annotation
struct DatasetItem: Identifiable, Hashable, Sendable {
    let id: UUID
    let originalDataURL: URL // e.g., URL to an image file
    var label: String?       // The annotation
    var isAnnotated: Bool { label != nil }

    init(id: UUID = UUID(), originalDataURL: URL, label: String? = nil) {
        self.id = id
        self.originalDataURL = originalDataURL
        self.label = label
    }
}

@available(iOS 15.0, *)
actor AnnotationManager {
    private var items: [DatasetItem]
    private var categories: Set<String>

    init(initialItems: [DatasetItem] = []) {
        self.items = initialItems
        self.categories = Set(initialItems.compactMap { $0.label })
    }

    func addItem(_ item: DatasetItem) {
        items.append(item)
        if let label = item.label {
            categories.insert(label)
        }
    }

    func updateLabel(for itemID: UUID, newLabel: String) -> Bool {
        guard let index = items.firstIndex(where: { $0.id == itemID }) else {
            return false
        }
        items[index].label = newLabel
        categories.insert(newLabel)
        return true
    }

    func getUnannotatedItems() -> [DatasetItem] {
        return items.filter { !$0.isAnnotated }
    }

    func getCategories() -> [String] {
        return Array(categories).sorted()
    }

    func getDatasetSummary() -> String {
        let total = items.count
        let annotated = items.filter { $0.isAnnotated }.count
        return "Total items: \(total), Annotated: \(annotated), Categories: \(categories.count)"
    }

    // Example of saving annotations to disk (simplified)
    func saveAnnotations(to url: URL) async throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        let data = try encoder.encode(items)
        try data.write(to: url)
    }
}
