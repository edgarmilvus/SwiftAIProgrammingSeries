
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation // For TextGenerator and related types
import UIKit      // For UI elements

// Ensure the entire class is only compiled and available on iOS 18.0 and later.
@available(iOS 18.0, *)
class IdeaGeneratorViewController: UIViewController {

    // MARK: - UI Elements

    private lazy var topicInput: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Enter a topic (e.g., 'new app ideas')"
        textField.borderStyle = .roundedRect
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()

    private lazy var generateButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Generate Ideas", for: .normal)
        button.addTarget(self, action: #selector(generateIdeas), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private lazy var ideasOutputLabel: UILabel = {
        let label = UILabel()
        label.text = "Your ideas will appear here."
        label.numberOfLines = 0 // Allow multiple lines
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    // MARK: - UI Setup

    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Idea Generator"

        // Add UI elements to the view
        view.addSubview(topicInput)
        view.addSubview(generateButton)
        view.addSubview(ideasOutputLabel)

        // Set up constraints
        NSLayoutConstraint.activate([
            topicInput.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            topicInput.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            topicInput.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            topicInput.heightAnchor.constraint(equalToConstant: 44),

            generateButton.topAnchor.constraint(equalTo: topicInput.bottomAnchor, constant: 20),
            generateButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            generateButton.widthAnchor.constraint(equalToConstant: 180),
            generateButton.heightAnchor.constraint(equalToConstant: 50),

            ideasOutputLabel.topAnchor.constraint(equalTo: generateButton.bottomAnchor, constant: 40),
            ideasOutputLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            ideasOutputLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            ideasOutputLabel.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    // MARK: - Text Generation Logic

    @objc private func generateIdeas() {
        // Dismiss keyboard
        view.endEditing(true)

        guard let topic = topicInput.text, !topic.isEmpty else {
            presentAlert(title: "Input Required", message: "Please enter a topic to generate ideas.")
            return
        }

        // Indicate loading state
        ideasOutputLabel.text = "Generating ideas for '\(topic)'..."
        generateButton.isEnabled = false // Disable button during generation

        // Construct the TextGenerationRequest
        let request = TextGenerationRequest(
            prompt: "Generate 3 distinct, creative ideas for: \(topic)",
            options: .init(
                maximumTokenCount: 200, // Limit the output length
                temperature: 0.7        // Encourage creativity (0.0-1.0, higher is more creative)
            )
        )

        // Use Swift's structured concurrency (Task) to perform the asynchronous API call
        Task {
            do {
                let response = try await TextGenerator.shared.generate(request)
                // Update the UI with the generated text on the main actor
                await MainActor.run {
                    self.ideasOutputLabel.text = response.text
                }
            } catch {
                // Handle generation error
                await MainActor.run {
                    self.presentAlert(title: "Generation Failed", message: "Error: \(error.localizedDescription)")
                    self.ideasOutputLabel.text = "Failed to generate ideas."
                }
            }
            // Re-enable the button regardless of success or failure
            await MainActor.run {
                self.generateButton.isEnabled = true
            }
        }
    }

    // MARK: - Error Handling Helper

    private func presentAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
