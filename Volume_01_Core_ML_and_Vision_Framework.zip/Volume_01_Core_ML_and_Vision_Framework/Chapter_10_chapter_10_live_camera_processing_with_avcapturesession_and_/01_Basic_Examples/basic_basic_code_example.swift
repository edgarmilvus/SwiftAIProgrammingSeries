
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// MARK: - Swift Package Manager Dependencies (No external dependencies for this basic example)
// This example only uses built-in Apple frameworks.
// No 'Package.swift' snippet is required.

import UIKit
import AVFoundation
import Vision

/// A basic `UIViewController` that demonstrates live camera processing
/// to detect faces using `AVCaptureSession` and `Vision`.
@available(iOS 18.0, *) // Targeting latest iOS SDK features where applicable
final class LiveFaceDetectionViewController: UIViewController {

    // MARK: - AVCaptureSession Properties
    private let captureSession = AVCaptureSession()
    private var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    private let videoDataOutput = AVCaptureVideoDataOutput()
    private let videoDataOutputQueue = DispatchQueue(label: "videoDataOutputQueue", qos: .userInitiated)

    // MARK: - Vision Properties
    private var faceDetectionRequest: VNDetectFaceRectanglesRequest!

    // MARK: - UI Elements
    private let faceCountLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textColor = .white
        label.font = .preferredFont(forTextStyle: .headline)
        label.textAlignment = .center
        label.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        label.layer.cornerRadius = 8
        label.clipsToBounds = true
        label.text = "Faces: 0"
        return label
    }()

    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupVision()
        checkCameraPermissionsAndSetupSession()
        setupUI()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        videoPreviewLayer?.frame = view.bounds
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Start the capture session on a background queue to avoid blocking UI
        videoDataOutputQueue.async {
            self.captureSession.startRunning()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // Stop the capture session when the view disappears
        self.captureSession.stopRunning()
    }

    // MARK: - Setup Methods

    /// Configures the Vision framework requests.
    private func setupVision() {
        // Initialize the face detection request.
        // The completion handler will be called when Vision finishes processing a frame.
        faceDetectionRequest = VNDetectFaceRectanglesRequest { [weak self] request, error in
            guard let self = self else { return }

            if let error = error {
                print("Face detection error: \(error.localizedDescription)")
                return
            }

            // Process the results on the main actor as UI updates are needed.
            Task { @MainActor in
                self.processFaceDetectionResults(request.results)
            }
        }
    }

    /// Checks for camera permissions and, if granted, sets up the AVCaptureSession.
    private func checkCameraPermissionsAndSetupSession() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            // Permissions already granted, proceed with setup
            setupCameraSession()
        case .notDetermined:
            // Request permissions
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                guard let self = self else { return }
                if granted {
                    // Permissions granted, setup session on a background queue
                    self.videoDataOutputQueue.async {
                        self.setupCameraSession()
                    }
                } else {
                    // Permissions denied
                    print("Camera access denied.")
                    // Inform user to enable camera in settings
                    self.showPermissionAlert()
                }
            }
        case .denied, .restricted:
            // Permissions denied or restricted
            print("Camera access denied or restricted.")
            self.showPermissionAlert()
        @unknown default:
            fatalError("Unknown authorization status for video.")
        }
    }

    /// Sets up the `AVCaptureSession` for video capture.
    private func setupCameraSession() {
        captureSession.beginConfiguration()
        captureSession.sessionPreset = .hd1280x720 // Set a common resolution preset

        // 1. Add Video Input
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else { // Using front camera for selfies/face detection
            print("Failed to get video device.")
            captureSession.commitConfiguration()
            return
        }
        guard let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            print("Failed to create video device input.")
            captureSession.commitConfiguration()
            return
        }
        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            print("Could not add video input to the session.")
            captureSession.commitConfiguration()
            return
        }

        // 2. Add Video Output
        // Configure the video data output to deliver frames in a specific pixel format
        videoDataOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA)]
        // Discard late frames to maintain real-time performance
        videoDataOutput.alwaysDiscardsLateVideoFrames = true
        // Set the delegate and the dispatch queue for processing frames
        videoDataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)

        if captureSession.canAddOutput(videoDataOutput) {
            captureSession.addOutput(videoDataOutput)
        } else {
            print("Could not add video data output to the session.")
            captureSession.commitConfiguration()
            return
        }

        // 3. Configure Video Orientation for Output
        // Ensure the video output connection's orientation matches the device's orientation
        if let connection = videoDataOutput.connection(with: .video) {
            if connection.isVideoOrientationSupported {
                // Set to portrait by default, but in a real app, you'd observe device orientation changes
                connection.videoOrientation = .portrait
            }
            // Mirror the front camera feed horizontally
            if connection.isVideoMirroringSupported {
                connection.isVideoMirrored = true
            }
        }

        captureSession.commitConfiguration()

        // 4. Setup Preview Layer (on main thread)
        Task { @MainActor in
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            videoPreviewLayer.videoGravity = .resizeAspectFill
            videoPreviewLayer.frame = view.bounds
            view.layer.insertSublayer(videoPreviewLayer, at: 0) // Insert at bottom
        }
    }

    /// Sets up the user interface elements.
    private func setupUI() {
        view.addSubview(faceCountLabel)
        NSLayoutConstraint.activate([
            faceCountLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            faceCountLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            faceCountLabel.widthAnchor.constraint(equalToConstant: 120),
            faceCountLabel.heightAnchor.constraint(equalToConstant: 40)
        ])
    }

    /// Displays an alert if camera permissions are denied.
    private func showPermissionAlert() {
        Task { @MainActor in
            let alert = UIAlertController(
                title: "Camera Access Denied",
                message: "Please enable camera access for this app in Settings to use this feature.",
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            alert.addAction(UIAlertAction(title: "Settings", style: .default, handler: { _ in
                if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(settingsURL)
                }
            }))
            self.present(alert, animated: true)
        }
    }

    // MARK: - Vision Result Processing

    /// Processes the results from the `VNDetectFaceRectanglesRequest`.
    /// This method is called on the main actor because it updates the UI.
    /// - Parameter results: An array of `VNFaceObservation` objects.
    @MainActor
    private func processFaceDetectionResults(_ results: [Any]?) {
        guard let observations = results as? [VNFaceObservation] else {
            faceCountLabel.text = "Faces: 0"
            return
        }
        faceCountLabel.text = "Faces: \(observations.count)"
        // In a more advanced example, you would draw bounding boxes here.
    }
}

// MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

/// Extension to handle `AVCaptureVideoDataOutput` delegate methods.
@available(iOS 18.0, *)
extension LiveFaceDetectionViewController: AVCaptureVideoDataOutputSampleBufferDelegate {

    /// Called when a new video frame is available.
    /// This method is called on the `videoDataOutputQueue` background queue.
    /// - Parameters:
    ///   - output: The `AVCaptureVideoDataOutput` that produced the sample buffer.
    ///   - sampleBuffer: The `CMSampleBuffer` containing the video frame.
    ///   - connection: The `AVCaptureConnection` used to deliver the sample buffer.
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // 1. Get the CVPixelBuffer from the sample buffer
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            print("Failed to get CVPixelBuffer from sample buffer.")
            return
        }

        // 2. Create a VNImageRequestHandler with the CVPixelBuffer
        // The orientation needs to match the image data's orientation.
        // For a front camera with mirroring, it's often .leftMirrored or .rightMirrored.
        // For simplicity, we'll use .up for now, assuming Vision handles the internal transformation
        // for face detection, but for precise drawing, this is critical.
        let imageRequestHandler = VNImageRequestHandler(
            cvPixelBuffer: pixelBuffer,
            orientation: .up, // Assume upright for basic Vision processing
            options: [:]
        )

        // 3. Perform the Vision request
        do {
            try imageRequestHandler.perform([faceDetectionRequest])
        } catch {
            print("Failed to perform Vision request: \(error.localizedDescription)")
        }
    }

    /// Called when a sample buffer was dropped.
    /// This indicates that the processing is too slow to keep up with the frame rate.
    func captureOutput(_ output: AVCaptureOutput, didDrop sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // print("Dropped frame!") // Uncomment for debugging performance
    }
}
