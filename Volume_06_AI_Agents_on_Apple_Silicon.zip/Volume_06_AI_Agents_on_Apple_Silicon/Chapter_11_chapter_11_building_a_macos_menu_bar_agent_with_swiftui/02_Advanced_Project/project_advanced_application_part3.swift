
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

import Foundation

/// Custom errors specific to the Ollama API client.
enum OllamaClientError: Error, LocalizedError {
    case invalidURL
    case networkError(Error)
    case serverError(statusCode: Int, message: String?)
    case decodingError(Error)
    case invalidResponse

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid Ollama API URL configured."
        case .networkError(let error): return "Network error: \(error.localizedDescription)"
        case .serverError(let statusCode, let message): return "Ollama server error \(statusCode): \(message ?? "No message")"
        case .decodingError(let error): return "Failed to decode Ollama response: \(error.localizedDescription)"
        case .invalidResponse: return "Ollama server returned an invalid or empty response."
        }
    }
}

/// A protocol defining the interface for an Ollama inference service.
/// This allows for easy mocking and testing of the client.
protocol OllamaService {
    /// Performs an inference request to the Ollama server.
    /// - Parameters:
    ///   - prompt: The text prompt to send to the LLM.
    ///   - model: The name of the LLM model to use (e.g., "llama2", "mistral").
    ///   - options: Optional model-specific parameters.
    /// - Returns: The generated response from the LLM.
    /// - Throws: `OllamaClientError` if the request fails.
    func generate(prompt: String, model: String, options: [String: OllamaGenerateRequest.AnyEncodable]?) async throws -> OllamaGenerateResponse
}

/// Concrete implementation of `OllamaService` for interacting with a local Ollama instance.
class OllamaAPIClient: OllamaService {
    private let baseURL: URL
    private let urlSession: URLSession

    /// Initializes the Ollama API client.
    /// - Parameters:
    ///   - baseURLString: The base URL of your local Ollama instance (e.g., "http://localhost:11434").
    ///   - urlSession: The URLSession to use for network requests. Defaults to `URLSession.shared`.
    init(baseURLString: String, urlSession: URLSession = .shared) {
        guard let url = URL(string: baseURLString) else {
            fatalError("Invalid base URL for OllamaAPIClient: \(baseURLString)")
        }
        self.baseURL = url
        self.urlSession = urlSession
    }

    /// Performs an inference request to the Ollama server's `/api/generate` endpoint.
    /// - Throws: `OllamaClientError` for various failure scenarios.
    func generate(prompt: String, model: String, options: [String: OllamaGenerateRequest.AnyEncodable]?) async throws -> OllamaGenerateResponse {
        guard let generateURL = URL(string: "/api/generate", relativeTo: baseURL) else {
            throw OllamaClientError.invalidURL
        }

        var request = URLRequest(url: generateURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let ollamaRequest = OllamaGenerateRequest(model: model, prompt: prompt, options: options)
        do {
            let requestData = try JSONEncoder().encode(ollamaRequest)
            request.httpBody = requestData
        } catch {
            throw OllamaClientError.decodingError(error) // Error encoding request
        }

        // Perform the network request using Swift 6 concurrency
        let (data, response) = try await urlSession.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw OllamaClientError.invalidResponse
        }

        guard 200..<300 ~= httpResponse.statusCode else {
            // Attempt to decode a server error message if available
            let errorMessage = String(data: data, encoding: .utf8)
            throw OllamaClientError.serverError(statusCode: httpResponse.statusCode, message: errorMessage)
        }

        do {
            let decoder = JSONDecoder()
            // Ollama responses might contain snake_case, configure decoder if necessary
            // decoder.keyDecodingStrategy = .convertFromSnakeCase
            let ollamaResponse = try decoder.decode(OllamaGenerateResponse.self, from: data)
            return ollamaResponse
        } catch {
            throw OllamaClientError.decodingError(error) // Error decoding response
        }
    }
}
