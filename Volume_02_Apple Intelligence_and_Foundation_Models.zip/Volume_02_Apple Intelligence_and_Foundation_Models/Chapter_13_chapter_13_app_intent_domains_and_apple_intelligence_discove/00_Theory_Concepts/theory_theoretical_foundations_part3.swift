
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import AppIntents

    @Observable
    class DocumentProcessingStatus {
        var progress: Double = 0.0
        var message: String = "Starting..."
        var isComplete: Bool = false
        var result: String?
    }

    @available(iOS 18.0, *)
    struct ProcessDocumentWithProgressIntent: AppIntent {
        static var title: LocalizedStringResource = "Process Document with Progress"
        @Parameter(title: "Document Content")
        var content: String

        func perform() async throws -> some IntentResult {
            let status = DocumentProcessingStatus()

            // Pass status object to a background task or actor for updates
            Task {
                await processDocumentInBackground(content: content, status: status)
            }

            return .result(view: {
                IntentResultView {
                    VStack {
                        ProgressView(value: status.progress)
                            .progressViewStyle(.linear)
                        Text(status.message)
                        if status.isComplete, let result = status.result {
                            Text("Result: \(result)")
                        }
                    }
                }
            })
        }

        private func processDocumentInBackground(content: String, status: DocumentProcessingStatus) async {
            status.message = "Fetching content..."
            status.progress = 0.1
            try? await Task.sleep(for: .seconds(1))

            status.message = "Analyzing content with LLM..."
            status.progress = 0.5
            try? await Task.sleep(for: .seconds(2))

            status.message = "Generating summary..."
            status.progress = 0.8
            try? await Task.sleep(for: .seconds(1.5))

            status.result = "Summarized content for: \(content.prefix(20))..."
            status.message = "Complete!"
            status.progress = 1.0
            status.isComplete = true
        }
    }
    