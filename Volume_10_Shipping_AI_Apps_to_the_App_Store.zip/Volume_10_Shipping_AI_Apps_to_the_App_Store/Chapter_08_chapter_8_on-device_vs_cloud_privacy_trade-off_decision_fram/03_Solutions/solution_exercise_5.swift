
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import Observation
import SwiftUI

/// Represents the chosen execution path.
enum ExecutionStrategy: String, Sendable {
    case localHighRes = "Local High-Res"
    case cloudLightweight = "Cloud Lightweight"
    case abort = "System Overheated: Abort"
}

/// A state object that the UI observes to react to hardware changes.
@Observable
@MainActor
class OrchestratorState {
    var currentStrategy: ExecutionStrategy = .localHighRes
    var thermalStatus: String = "Nominal"
    var batteryLevel: Float = 1.0
}

/// The actor responsible for calculating the optimal strategy.
actor AdaptiveOrchestrator {
    
    func determineStrategy() -> ExecutionStrategy {
        let thermalState = ProcessInfo.processInfo.thermalState
        // In a real app, use UIDevice.current.batteryLevel (requires iOS)
        // Mocking battery for demonstration
        let mockBatteryLevel: Float = 0.15 

        switch thermalState {
        case .critical:
            return .abort
        case .serious:
            // If hot, even if battery is high, use cloud to save local compute
            return .cloudLightweight
        case .fair:
            // If battery is low, use cloud to save local compute
            return mockBatteryLevel < 0.2 ? .cloudLightweight : .localHighRes
        case .nominal:
            return mockBatteryLevel < 0.2 ? .cloudLightweight : .localHighRes
        @unknown default:
            return .localHighRes
        }
    }
}

/// A view-model that bridges the Actor and the Observable State.
@MainActor
class OrchestratorViewModel: ObservableObject {
    let state = OrchestratorState()
    private let orchestrator = AdaptiveOrchestrator()

    func updateMetrics() async {
        let newStrategy = await orchestrator.determineStrategy()
        
        // Update the @Observable state
        state.currentStrategy = newStrategy
        state.thermalStatus = "\(ProcessInfo.processInfo.thermalState)"
        
        // Update UI-bound properties
        state.batteryLevel = 0.15 // Mock update
    }
    
    func performAIAction() async {
        await updateMetrics()
        
        guard state.currentStrategy != .abort else {
            print("Action cancelled: Device is too hot.")
            return
        }
        
        print("Starting AI Task using: \(state.currentStrategy.rawValue)")
        // Logic to trigger the actual model...
    }
}

// MARK: - Execution Example
@main
struct AdaptiveApp {
    static func main() async {
        let viewModel = await OrchestratorViewModel()
        
        print("--- Initial State ---")
        await viewModel.performAIAction()
        
        print("\n--- Simulating System Load/Heat ---")
        // In a real app, this would be triggered by NotificationCenter 
        // observing ProcessInfo.thermalStateDidChangeNotification
        await viewModel.performAIAction()
    }
}
