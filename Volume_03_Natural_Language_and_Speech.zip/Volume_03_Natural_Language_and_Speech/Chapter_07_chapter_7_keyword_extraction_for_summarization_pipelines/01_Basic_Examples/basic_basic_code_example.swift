
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import NaturalLanguage
import Foundation // For String operations, Set, etc.

@available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
struct BasicKeywordExtractor {

    /// A simple set of common English stop words to filter out.
    /// In a real application, this list would be much more comprehensive and potentially language-specific.
    private let stopWords: Set<String> = [
        "a", "an", "the", "is", "are", "was", "were", "be", "be", "been", "being", "have", "has", "had", "do", "does", "did",
        "of", "in", "on", "at", "by", "for", "with", "from", "to", "and", "or", "but", "not", "it", "its", "he", "she",
        "we", "they", "you", "your", "this", "that", "these", "those", "can", "could", "would", "should", "will", "may",
        "might", "must", "as", "if", "then", "than", "so", "such", "up", "down", "out", "off", "about", "above", "below",
        "before", "after", "again", "further", "here", "there", "when", "where", "why", "how", "all", "any", "both",
        "each", "few", "more", "most", "other", "some", "such", "no", "nor", "only", "own", "same", "so", "too", "very",
        "s", "t", "can", "will", "just", "don", "should", "now", "get", "go", "make", "take", "come", "see", "know",
        "think", "look", "want", "use", "find", "give", "tell", "work", "call", "try", "ask", "need", "feel", "become",
        "leave", "put", "mean", "keep", "let", "begin", "seem", "help", "talk", "start", "show", "hear", "play", "run",
        "move", "like", "also", "much", "many", "even", "back", "away", "around", "through", "while", "into", "onto",
        "over", "under", "between", "among", "along", "across", "behind", "below", "beside", "beyond", "during",
        "except", "inside", "outside", "near", "past", "since", "until", "upon", "within", "without", "throughout",
        "rather", "instead", "although", "though", "unless", "whereas", "whatever", "whenever", "wherever", "whichever",
        "whoever", "whomever", "whosever", "himself", "herself", "itself", "myself", "ourselves", "themselves", "yourself",
        "yourselves", "another", "every", "everyone", "everything", "everywhere", "nobody", "nothing", "nowhere",
        "somebody", "someone", "something", "somewhere", "whatever", "whoever", "whomever", "whosever", "whichever",
        "wherever", "whenever", "however", "furthermore", "moreover", "therefore", "thus", "hence", "consequently",
        "accordingly", "meanwhile", "otherwise", "besides", "instead", "namely", "i.e.", "e.g.", "etc.", "etc",
        "dear", "sincerely", "regards", "best", "thanks", "hello", "hi", "goodbye", "please", "thank", "you",
        "welcome", "excuse", "pardon", "sorry", "indeed", "really", "very", "quite", "pretty", "rather", "too",
        "enough", "almost", "already", "always", "ever", "never", "often", "seldom", "sometimes", "usually",
        "hardly", "scarcely", "barely", "just", "only", "even", "still", "yet", "ever", "never", "always", "often",
        "seldom", "sometimes", "usually", "hardly", "scarcely", "barely", "just", "only", "even", "still", "yet",
        "who", "what", "when", "where", "why", "how", "which", "whom", "whose", "whereby", "wherein", "whereupon",
        "wherever", "whichever", "whoever", "whomever", "whosever", "whatever", "whenever", "wherever", "whichever",
        "whoever", "whomever", "whosever", "whatever", "whenever", "wherever", "whichever", "whoever", "whomever",
        "whosever", "whatever", "whenever", "wherever", "whichever", "whoever", "whomever", "whosever"
    ]


    /// Extracts keywords from a given text using NLTagger.
    ///
    /// This function processes the input text to identify important nouns and verbs,
    /// lemmatizes them, filters out common stop words, and then returns the
    /// most frequent terms as keywords.
    ///
    /// - Parameters:
    ///   - text: The input string from which to extract keywords.
    ///   - language: The language of the text. Defaults to `.english`.
    ///   - maxKeywords: The maximum number of top keywords to return. Defaults to 5.
    /// - Returns: An array of `(keyword: String, frequency: Int)` tuples, sorted by frequency in descending order.
    func extractKeywords(from text: String, language: NLLanguage = .english, maxKeywords: Int = 5) -> [(keyword: String, frequency: Int)] {
        // 1. Initialize NLTagger with desired tag schemes.
        // We use .lexicalClass to identify parts of speech (like nouns, verbs)
        // and .lemma to get the base form of words (e.g., "running" -> "run").
        let tagger = NLTagger(tagSchemes: [.lexicalClass, .lemma])
        tagger.string = text

        var keywordFrequencies: [String: Int] = [:]

        // 2. Iterate through tokens (words) in the text.
        // We specify the unit as .word and the scheme as .lexicalClass to get part-of-speech tags.
        // We also ask for .lemma to get the base form of the word.
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lexicalClass, options: [.omitWhitespace, .omitPunctuation]) { tag, tokenRange in
            guard let tag = tag else { return true } // Ensure a tag was found

            let word = String(text[tokenRange]).lowercased()

            // 3. Filter for relevant parts of speech (nouns and verbs).
            // These are typically the most content-rich words.
            if tag == .noun || tag == .verb {
                // 4. Get the lemma (base form) of the word.
                // This helps group variations of the same word (e.g., "run", "running", "ran" all become "run").
                let lemmaTag = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .lemma)?.0
                let keyword = lemmaTag?.rawValue.lowercased() ?? word

                // 5. Filter out stop words and short words.
                // Stop words are common words that don't carry much semantic meaning.
                // Short words (e.g., single letters) are usually not useful keywords.
                if !stopWords.contains(keyword) && keyword.count > 2 {
                    keywordFrequencies[keyword, default: 0] += 1
                }
            }
            return true // Continue enumeration
        }

        // 6. Sort keywords by frequency in descending order and take the top N.
        let sortedKeywords = keywordFrequencies.sorted { $0.value > $1.value }
                                               .prefix(maxKeywords)
                                               .map { (keyword: $0.key, frequency: $0.value) }

        return sortedKeywords
    }
}

// MARK: - Example Usage

// This code block demonstrates how to use the BasicKeywordExtractor.
// It simulates the text output from an OCR process in our "Smart Document Scanner" app.
if #available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *) {
    let documentText = """
    The quick brown fox jumps over the lazy dog. This document discusses the future of artificial intelligence
    and machine learning in software development. Many developers are learning Swift and exploring Apple's
    Core ML framework for on-device intelligence. The new neural engine capabilities are very impressive.
    Machine learning models can now run more efficiently than ever before. Developers should consider
    integrating these powerful tools into their applications to provide a better user experience.
    Learning new technologies like natural language processing is crucial for modern app development.
    """

    let extractor = BasicKeywordExtractor()
    let keywords = extractor.extractKeywords(from: documentText, maxKeywords: 7)

    print("--- Extracted Keywords for Document ---")
    if keywords.isEmpty {
        print("No significant keywords found.")
    } else {
        for (keyword, frequency) in keywords {
            print("'- \(keyword)' (Frequency: \(frequency))")
        }
    }

    print("\n--- Another Example: Meeting Notes ---")
    let meetingNotes = """
    Meeting agenda: Discuss project timelines, budget allocation, and team roles.
    Sarah will present the Q3 financial report. John needs to update the project plan
    and review the client feedback. We must ensure all team members are aligned.
    The next meeting is scheduled for Friday.
    """
    let meetingKeywords = extractor.extractKeywords(from: meetingNotes, maxKeywords: 5)
    if meetingKeywords.isEmpty {
        print("No significant keywords found.")
    } else {
        for (keyword, frequency) in meetingKeywords {
            print("'- \(keyword)' (Frequency: \(frequency))")
        }
    }
} else {
    print("BasicKeywordExtractor is not available on this OS version. Requires macOS 10.14+, iOS 12.0+, etc.")
}

