
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

    // Correct approach using async/await and @MainActor
    @MainActor
    func updateUIWithKeywords(keywords: [(keyword: String, frequency: Int)]) {
        // This function is guaranteed to run on the main thread
        let keywordString = keywords.map { $0.keyword }.joined(separator: ", ")
        // Assuming 'keywordLabel' is a UI element in a real app
        // keywordLabel.text = "Keywords: \(keywordString)"
        print("UI Updated with Keywords: \(keywordString)") // For console example
    }

    // Call from an async context, ensuring background work
    func processDocumentAsync(documentText: String) async {
        if #available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *) {
            let extractor = BasicKeywordExtractor()
            // Perform the potentially long-running task on a background thread
            let keywords = await Task.detached {
                extractor.extractKeywords(from: documentText, maxKeywords: 7)
            }.value

            // Update UI on the main actor
            await updateUIWithKeywords(keywords: keywords)
        }
    }

    // Example of how you might trigger this in an app (e.g., from a button tap)
    // Task { await processDocumentAsync(documentText: "Some very long text...") }
    