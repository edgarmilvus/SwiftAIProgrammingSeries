
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

// The notarization process is command-line based, not Swift code.
// However, the *result* impacts how your Swift app behaves on a user's machine.

// Conceptual command line steps:
// 1. Archive the app:
//    xcodebuild archive -scheme "MyAIApp" -destination "generic/platform=macOS" \
//      -archivePath "build/MyAIApp.xcarchive"
// 2. Export the archive for notarization:
//    xcodebuild -exportArchive -archivePath "build/MyAIApp.xcarchive" \
//      -exportPath "build/MyAIApp_Notarize" \
//      -exportOptionsPlist "ExportOptions.plist"
// 3. Upload to Apple's notarization service:
//    xcrun altool --notarize-app --primary-bundle-id "com.example.myaiapp" \
//      --username "your-apple-id" --password "your-app-specific-password" \
//      --file "build/MyAIApp_Notarize/MyAIApp.dmg"
// 4. Staple the notarization ticket:
//    xcrun stapler staple "build/MyAIApp_Notarize/MyAIApp.dmg"
