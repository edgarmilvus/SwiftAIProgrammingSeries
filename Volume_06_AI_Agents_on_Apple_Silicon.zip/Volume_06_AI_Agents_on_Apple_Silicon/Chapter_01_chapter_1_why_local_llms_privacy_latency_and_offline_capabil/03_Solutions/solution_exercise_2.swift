
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// Defines the interface for a local LLM inference engine.
@available(iOS 18.0, macOS 15.0, *)
protocol LLMInferenceEngine {
    /// Generates a response based on the given prompt.
    /// This method is asynchronous to simulate the time taken for actual LLM inference.
    /// - Parameter prompt: The input prompt for the LLM.
    /// - Returns: The generated response string.
    /// - Throws: An error if inference fails.
    func generateResponse(prompt: String) async throws -> String
}

/// A mock implementation of `LLMInferenceEngine` for simulating local LLM behavior.
/// This class demonstrates offline capability and configurable latency.
@available(iOS 18.0, macOS 15.0, *)
class MockLLMInferenceEngine: LLMInferenceEngine {
    // The duration to pause, simulating the time an LLM takes to process a prompt.
    private let simulatedLatency: Duration
    // A dictionary of predefined responses for specific keywords in prompts.
    private let predefinedResponses: [String: String]

    /// Initializes the mock engine with a simulated latency and predefined responses.
    /// - Parameters:
    ///   - simulatedLatency: The `Duration` to pause before returning a response.
    ///   - predefinedResponses: A dictionary mapping keywords in prompts to specific responses.
    init(simulatedLatency: Duration, predefinedResponses: [String: String] = [:]) {
        self.simulatedLatency = simulatedLatency
        self.predefinedResponses = predefinedResponses
    }

    /// Generates a response based on the given prompt, simulating local LLM inference.
    /// This method includes a configurable delay and returns a predefined or generic response.
    /// - Parameter prompt: The input prompt for the LLM.
    /// - Returns: The generated response string.
    /// - Throws: Currently, this mock doesn't throw specific errors but could be extended.
    func generateResponse(prompt: String) async throws -> String {
        let startTime = Date()
        print("Mock LLM: Simulating inference for prompt: '\(prompt)'...")

        // Simulate network/inference delay using Task.sleep.
        // This is a key part of simulating latency and demonstrating asynchronous behavior.
        try await Task.sleep(for: simulatedLatency)

        // Find a predefined response based on prompt keywords, or return a generic one.
        // This simulates the LLM's "thinking" process based on input.
        for (keyword, response) in predefinedResponses {
            if prompt.lowercased().contains(keyword.lowercased()) {
                let endTime = Date()
                let duration = endTime.timeIntervalSince(startTime)
                print("Mock LLM: Completed in \(String(format: "%.2f", duration)) seconds. Response: '\(response)'")
                return response
            }
        }

        let genericResponse = "This is a simulated response from your local AI. You asked about: '\(prompt)'."
        let endTime = Date()
        let duration = endTime.timeIntervalSince(startTime)
        print("Mock LLM: Completed in \(String(format: "%.2f", duration)) seconds. Response: '\(genericResponse)'")
        return genericResponse
    }
}

// MARK: - Conceptual Demonstration of Offline Use and Latency Measurement

@available(iOS 18.0, macOS 15.0, *)
class LLMAppCoordinator {
    let llmEngine: LLMInferenceEngine

    init(llmEngine: LLMInferenceEngine) {
        self.llmEngine = llmEngine
    }

    /// Simulates a user interaction requesting an LLM response.
    func requestLLMResponse(for prompt: String) {
        Task {
            let start = Date()
            do {
                let response = try await llmEngine.generateResponse(prompt: prompt)
                let end = Date()
                let latency = end.timeIntervalSince(start)
                print("Application received response: '\(response)'")
                print("Actual simulated latency for '\(prompt)': \(String(format: "%.2f", latency)) seconds.")
                // Update UI with response
            } catch {
                print("Application failed to get LLM response: \(error)")
                // Show error to user
            }
        }
    }

    // This method would be called from a UI event, e.g., a button tap or text field submission.
    func demonstrateUsage() {
        print("\n--- Demonstrating LLM Usage ---")

        // Example with predefined response
        requestLLMResponse(for: "Hello LLM, how are you?")

        // Example with generic response
        requestLLMResponse(for: "Suggest a quick dinner recipe.")

        // Example with another predefined response
        requestLLMResponse(for: "Tell me a joke.")

        print("--- All requests dispatched ---")
    }
}

/*
// To run this demonstration (e.g., in a Playground or main app):
@available(iOS 18.0, macOS 15.0, *)
let predefinedResponses: [String: String] = [
    "hello": "Hello there! How can I assist you today?",
    "joke": "Why don't scientists trust atoms? Because they make up everything!"
]

let mockLLM = MockLLMInferenceEngine(simulatedLatency: .seconds(2), predefinedResponses: predefinedResponses)
let coordinator = LLMAppCoordinator(llmEngine: mockLLM)
coordinator.demonstrateUsage()

// You'd typically need to keep the process alive in a Playground to see all async outputs.
// import PlaygroundSupport
// PlaygroundSupport.PlaygroundPage.current.needsIndefiniteExecution = true
*/
