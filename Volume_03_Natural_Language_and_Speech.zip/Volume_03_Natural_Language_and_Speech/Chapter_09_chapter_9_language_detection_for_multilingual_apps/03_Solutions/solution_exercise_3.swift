
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import NaturalLanguage

class SmartTranslationAssistantViewController: UIViewController, UITextViewDelegate {

    private let textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = UIFont.systemFont(ofSize: 18)
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return tv
    }()

    private let dominantLanguageLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 22)
        label.textAlignment = .center
        label.text = "Dominant Language: N/A"
        label.numberOfLines = 0
        return label
    }()

    private let hypothesesStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.spacing = 5
        stackView.alignment = .leading
        return stackView
    }()

    private let scrollView: UIScrollView = {
        let sv = UIScrollView()
        sv.translatesAutoresizingMaskIntoConstraints = false
        return sv
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Smart Translation Assistant"
        view.backgroundColor = .systemBackground

        textView.delegate = self

        view.addSubview(textView)
        view.addSubview(dominantLanguageLabel)
        view.addSubview(scrollView)
        scrollView.addSubview(hypothesesStackView)

        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 150),

            dominantLanguageLabel.topAnchor.constraint(equalTo: textView.bottomAnchor, constant: 20),
            dominantLanguageLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            dominantLanguageLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            dominantLanguageLabel.heightAnchor.constraint(equalToConstant: 60),

            scrollView.topAnchor.constraint(equalTo: dominantLanguageLabel.bottomAnchor, constant: 10),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            hypothesesStackView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            hypothesesStackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            hypothesesStackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            hypothesesStackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            hypothesesStackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor) // Important for vertical stack view in scroll view
        ])
    }

    // MARK: - UITextViewDelegate

    func textViewDidChange(_ textView: UITextView) {
        analyzeLanguageHypotheses(for: textView.text)
    }

    private func analyzeLanguageHypotheses(for text: String) {
        // Clear previous hypotheses
        hypothesesStackView.arrangedSubviews.forEach { $0.removeFromSuperview() }

        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            dominantLanguageLabel.text = "Dominant Language: N/A"
            addHypothesisLabel(text: "Start typing to see language hypotheses.")
            return
        }

        let recognizer = NLLanguageRecognizer()
        recognizer.processString(text) // Process the full string for analysis

        // Get language hypotheses, limiting to top 5
        let hypotheses = recognizer.languageHypotheses(withMaximum: 5)

        // Sort hypotheses by confidence in descending order
        let sortedHypotheses = hypotheses.sorted { $0.value > $1.value }

        if let dominant = sortedHypotheses.first {
            let dominantLanguageName = Locale.current.localizedString(forLanguageCode: dominant.key.rawValue) ?? dominant.key.rawValue
            dominantLanguageLabel.text = "Dominant Language: \(dominantLanguageName) (\(String(format: "%.1f%%", dominant.value * 100)))"

            // Add alternative hypotheses
            let alternativeHypotheses = sortedHypotheses.dropFirst() // Exclude the dominant one
            if !alternativeHypotheses.isEmpty {
                addHypothesisLabel(text: "Alternative Hypotheses:")
                for (language, confidence) in alternativeHypotheses {
                    let languageName = Locale.current.localizedString(forLanguageCode: language.rawValue) ?? language.rawValue
                    addHypothesisLabel(text: "- \(languageName): \(String(format: "%.1f%%", confidence * 100))")
                }
            } else {
                addHypothesisLabel(text: "No significant alternative languages detected.")
            }
        } else {
            dominantLanguageLabel.text = "Dominant Language: Unknown"
            addHypothesisLabel(text: "Could not determine language hypotheses.")
        }
    }

    private func addHypothesisLabel(text: String) {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.text = text
        label.numberOfLines = 0
        hypothesesStackView.addArrangedSubview(label)
    }
}
