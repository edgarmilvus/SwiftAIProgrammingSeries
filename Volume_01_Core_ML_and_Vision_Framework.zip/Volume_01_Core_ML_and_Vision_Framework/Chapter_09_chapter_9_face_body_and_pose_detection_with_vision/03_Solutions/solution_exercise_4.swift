
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import Vision
import CoreImage
import CoreGraphics

// MARK: - AIArtStudio
class AIArtStudio {

    private let ciContext = CIContext() // Re-use CIContext for performance

    /// Applies dynamic artistic effects to an image based on detected human poses.
    /// - Parameter image: The input UIImage to process.
    /// - Returns: A new UIImage with pose-based effects applied, or the original image if processing fails.
    func applyPoseBasedEffects(to image: UIImage) async -> UIImage {
        guard let cgImage = image.cgImage else {
            print("Failed to get CGImage from UIImage.")
            return image
        }

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        let request = VNDetectHumanBodyPoseRequest()

        do {
            try handler.perform([request])

            guard let observations = request.results as? [VNHumanBodyPoseObservation] else {
                print("No human body pose observations found.")
                return image
            }

            var ciImage = CIImage(cgImage: cgImage)

            for observation in observations {
                // 1. Pose Classification
                let poseType = classifyPose(observation: observation)
                print("Detected pose: \(poseType)")

                // 2. Get the body region for masking
                guard let bodyRegionMask = createBodyRegionMask(for: observation, imageSize: image.size) else {
                    print("Could not create body region mask.")
                    continue
                }
                
                // Convert the mask to CIImage, ensuring it's in the correct coordinate space
                let ciBodyRegionMask = CIImage(cgImage: bodyRegionMask.cgImage!)
                    .transformed(by: CGAffineTransform(scaleX: 1.0, y: -1.0).translatedBy(x: 0, y: ciImage.extent.height)) // Flip Y for CIImage

                // 3. Apply Conditional Visual Effects
                var effectFilter: CIFilter?

                switch poseType {
                case .standing:
                    // Apply a glow effect (blur + color adjustment)
                    let blurFilter = CIFilter(name: "CIGaussianBlur", parameters: [kCIInputImageKey: ciImage, kCIInputRadiusKey: 20])
                    let colorControlsFilter = CIFilter(name: "CIColorControls", parameters: [
                        kCIInputImageKey: blurFilter?.outputImage,
                        kCIInputSaturationKey: 1.5,
                        kCIInputBrightnessKey: 0.2,
                        kCIInputContrastKey: 1.1
                    ])
                    effectFilter = colorControlsFilter

                case .sitting:
                    // Apply a ripple distortion effect
                    let centerPoint = observation.boundingBox.midX * ciImage.extent.width
                    let rippleFilter = CIFilter(name: "CIRippleTransition", parameters: [
                        kCIInputImageKey: ciImage, // The "from" image
                        "inputTargetImage": ciImage, // The "to" image (we distort the same image)
                        "inputCenter": CIVector(x: centerPoint, y: observation.boundingBox.midY * ciImage.extent.height),
                        "inputExtent": CIVector(rect: ciImage.extent),
                        "inputWidth": 100, // Width of the ripple
                        "inputScale": 50,  // Scale of the ripple
                        "inputTime": 0.5   // Halfway through transition
                    ])
                    effectFilter = rippleFilter
                case .unknown:
                    // No specific effect for unknown poses
                    continue
                }

                guard let outputEffectImage = effectFilter?.outputImage else {
                    print("Failed to create effect image for \(poseType).")
                    continue
                }

                // Blend the effect only to the masked region
                // Use CIBlendWithMask to composite the original image, the effect, and the mask.
                // The effect image is the foreground, original is background, mask defines where foreground appears.
                let blendFilter = CIFilter(name: "CIBlendWithMask", parameters: [
                    kCIInputImageKey: outputEffectImage, // The effect to apply
                    kCIInputBackgroundImageKey: ciImage, // The original image (or current composite)
                    kCIInputMaskImageKey: ciBodyRegionMask // The mask
                ])
                
                // The output of blendFilter is the new current CIImage for the next iteration.
                if let blendedImage = blendFilter?.outputImage {
                    ciImage = blendedImage
                } else {
                    print("Failed to blend image with mask for \(poseType).")
                }
            }

            // Convert the final CIImage back to UIImage.
            guard let outputCGImage = ciContext.createCGImage(ciImage, from: ciImage.extent) else {
                print("Failed to convert CIImage to CGImage.")
                return image
            }
            return UIImage(cgImage: outputCGImage)

        } catch {
            print("Failed to perform Vision request: \(error)")
            return image
        }
    }

    // MARK: - Pose Classification
    enum PoseType: String {
        case standing
        case sitting
        case unknown
    }

    /// Classifies a human pose as standing or sitting based on relative joint positions.
    /// Vision Y-axis: 0.0 at bottom, 1.0 at top.
    /// - Parameter observation: The VNHumanBodyPoseObservation.
    /// - Returns: A PoseType (standing, sitting, or unknown).
    private func classifyPose(observation: VNHumanBodyPoseObservation) -> PoseType {
        guard let leftHip = try? observation.recognizedPoint(.leftHip),
              let rightHip = try? observation.recognizedPoint(.rightHip),
              let leftKnee = try? observation.recognizedPoint(.leftKnee),
              let rightKnee = try? observation.recognizedPoint(.rightKnee),
              leftHip.confidence > 0.5, rightHip.confidence > 0.5,
              leftKnee.confidence > 0.5, rightKnee.confidence > 0.5 else {
            return .unknown
        }

        let avgHipY = (leftHip.location.y + rightHip.location.y) / 2.0
        let avgKneeY = (leftKnee.location.y + rightKnee.location.y) / 2.0

        // Heuristic: If average hip Y is significantly higher than average knee Y,
        // the person is likely sitting (hips above knees on the image).
        // A small positive difference means hips are slightly above knees (sitting).
        // A negative difference means hips are below knees (standing).
        let yDifference = avgHipY - avgKneeY
        let sittingThreshold: CGFloat = 0.05 // Adjust this value based on experimentation

        if yDifference > sittingThreshold {
            return .sitting
        } else {
            return .standing
        }
    }

    // MARK: - Mask Generation
    /// Creates a UIImage mask for the detected human body region.
    /// This uses the bounding box for simplicity, but could be enhanced with joint paths.
    /// - Parameters:
    ///   - observation: The VNHumanBodyPoseObservation.
    ///   - imageSize: The size of the original image.
    /// - Returns: A UIImage representing the mask (white for body, black for background).
    private func createBodyRegionMask(for observation: VNHumanBodyPoseObservation, imageSize: CGSize) -> UIImage? {
        // Create a graphics renderer context.
        let renderer = UIGraphicsImageRenderer(size: imageSize)
        let maskImage = renderer.image { context in
            let cgContext = context.cgContext

            // Fill the entire context with black (transparent/background).
            cgContext.setFillColor(UIColor.black.cgColor)
            cgContext.fill(CGRect(x: 0, y: 0, width: imageSize.width, height: imageSize.height))

            // Convert Vision's normalized bounding box to UIKit's coordinate system.
            let boundingBox = observation.boundingBox
            let convertedBoundingBox = VNImageRectForNormalizedRect(boundingBox, Int(imageSize.width), Int(imageSize.height))

            // Draw a white rectangle for the body region (mask).
            cgContext.setFillColor(UIColor.white.cgColor)
            cgContext.fill(convertedBoundingBox)

            // Optional: For a more precise mask, you could draw paths using recognized points.
            // This would involve iterating through the points, converting them, and creating a CGPath.
            // For this exercise, the bounding box is a reasonable approximation.
        }
        return maskImage
    }
}

// MARK: - Example Usage (for iOS)
/*
// Assume you have a UIImage named `inputImage`
let inputImage = UIImage(named: "your_image_with_people")! // Replace with an actual image

Task {
    let artStudio = AIArtStudio()
    let artisticImage = await artStudio.applyPoseBasedEffects(to: inputImage)

    // Display `artisticImage` in a UIImageView or save it.
    // For example:
    // myImageView.image = artisticImage
}
*/
