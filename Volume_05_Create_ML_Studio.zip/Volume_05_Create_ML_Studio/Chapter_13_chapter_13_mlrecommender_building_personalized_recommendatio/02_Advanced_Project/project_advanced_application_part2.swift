
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreML // Provides MLRecommender and MLRecommenderBuilder

// MARK: - 1. Data Models

/// Represents a single podcast episode.
struct PodcastEpisode: Identifiable, Hashable, Codable {
    let id: String
    let title: String
    let description: String
    let genre: String
    let durationMinutes: Int
}

/// Represents a user's listening interaction with a podcast episode.
/// This data will be used to train the MLRecommender.
struct UserListenEvent: Identifiable, Codable {
    let id = UUID()
    let userID: String
    let episodeID: String
    let listenDurationPercentage: Double // e.g., 0.85 for 85% listened
    let timestamp: Date
}

// MARK: - 2. Mock Data Generation

/// A utility to generate synthetic data for demonstration purposes.
class MockPodcastDataGenerator {
    static let shared = MockPodcastDataGenerator()

    private init() {}

    /// Generates a set of mock podcast episodes.
    /// - Parameter count: The number of episodes to generate.
    /// - Returns: An array of `PodcastEpisode` objects.
    func generateMockEpisodes(count: Int = 50) -> [PodcastEpisode] {
        var episodes: [PodcastEpisode] = []
        let genres = ["Technology", "Comedy", "News", "True Crime", "Science", "History"]
        for i in 0..<count {
            let genre = genres.randomElement()!
            episodes.append(PodcastEpisode(
                id: "episode_\(i)",
                title: "The \(genre) Daily - Episode \(i + 1)",
                description: "An exciting episode about \(genre.lowercased()) and more.",
                genre: genre,
                durationMinutes: Int.random(in: 20...60)
            ))
        }
        return episodes
    }

    /// Generates mock user listening events for a given set of users and episodes.
    /// - Parameters:
    ///   - users: An array of user IDs.
    ///   - episodes: An array of `PodcastEpisode` objects.
    ///   - eventCountPerUser: The average number of listening events per user.
    /// - Returns: An array of `UserListenEvent` objects.
    func generateMockListenEvents(users: [String], episodes: [PodcastEpisode], eventCountPerUser: Int = 10) -> [UserListenEvent] {
        var events: [UserListenEvent] = []
        for user in users {
            for _ in 0..<Int.random(in: (eventCountPerUser - 3)...(eventCountPerUser + 3)) {
                guard let randomEpisode = episodes.randomElement() else { continue }
                let listenPercentage = Double.random(in: 0.1...1.0) // Users might listen partially or fully
                let timestamp = Date().addingTimeInterval(-Double.random(in: 0...(30 * 24 * 60 * 60))) // Within the last month
                events.append(UserListenEvent(
                    userID: user,
                    episodeID: randomEpisode.id,
                    listenDurationPercentage: listenPercentage,
                    timestamp: timestamp
                ))
            }
        }
        return events
    }
}

// MARK: - 3. PodcastRecommendationService Class

/// Custom errors for the recommendation service.
enum RecommendationServiceError: Error, LocalizedError {
    case modelNotLoaded
    case trainingFailed(Error)
    case recommendationFailed(Error)
    case invalidModelURL
    case noTrainingData
    case episodeNotFound(String)

    var errorDescription: String? {
        switch self {
        case .modelNotLoaded:
            return "The recommendation model has not been loaded or trained yet."
        case .trainingFailed(let error):
            return "Failed to train the MLRecommender model: \(error.localizedDescription)"
        case .recommendationFailed(let error):
            return "Failed to get recommendations: \(error.localizedDescription)"
        case .invalidModelURL:
            return "Invalid URL provided for saving/loading the model."
        case .noTrainingData:
            return "No training data available to build the recommender model."
        case .episodeNotFound(let id):
            return "Recommended episode with ID '\(id)' not found in the episode catalog."
        }
    }
}

/// A service for generating personalized podcast episode recommendations.
@available(macOS 15.0, iOS 18.0, tvOS 18.0, watchOS 11.0, *)
class PodcastRecommendationService {
    private var recommender: MLRecommender?
    private let modelURL: URL
    private var allEpisodes: [String: PodcastEpisode] = [:] // Catalog for quick lookup

    /// Initializes the recommendation service.
    /// - Parameter modelFileName: The name of the file to save/load the MLRecommender model.
    init(modelFileName: String = "PodcastRecommender.mlmodel") {
        // Use a temporary directory for the model file in a real app,
        // you might use Application Support directory for persistent storage.
        self.modelURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(modelFileName)
    }

    /// Loads a pre-trained MLRecommender model from disk, if available.
    /// This is useful for persistent models across app launches.
    /// - Throws: `RecommendationServiceError.modelNotLoaded` if the model cannot be loaded.
    func loadModel() async throws {
        guard FileManager.default.fileExists(atPath: modelURL.path) else {
            print("No existing model found at \(modelURL.path). Training will be required.")
            throw RecommendationServiceError.modelNotLoaded
        }
        do {
            self.recommender = try await MLRecommender(contentsOf: modelURL)
            print("Successfully loaded MLRecommender model from \(modelURL.path)")
        } catch {
            print("Failed to load existing MLRecommender model: \(error.localizedDescription)")
            throw RecommendationServiceError.modelNotLoaded
        }
    }

    /// Trains a new MLRecommender model using the provided listen events and episodes.
    /// This operation can be computationally intensive and should be run on a background thread.
    /// - Parameters:
    ///   - listenEvents: An array of `UserListenEvent` objects.
    ///   - episodes: A dictionary of all available `PodcastEpisode` objects, keyed by ID.
    /// - Throws: `RecommendationServiceError` if training fails or data is insufficient.
    func trainRecommender(listenEvents: [UserListenEvent], episodes: [String: PodcastEpisode]) async throws {
        guard !listenEvents.isEmpty else {
            throw RecommendationServiceError.noTrainingData
        }

        self.allEpisodes = episodes // Store for later lookup

        // Convert UserListenEvent to MLRecommender.RecommendationEntry
        // MLRecommender uses a rating system. We'll map listenDurationPercentage to a rating.
        // A higher percentage means a stronger positive interaction.
        let trainingEntries: [MLRecommender.RecommendationEntry] = listenEvents.map { event in
            // Map percentage to a 1-5 scale for better differentiation.
            // 0.1-0.2 -> 1, 0.2-0.4 -> 2, 0.4-0.6 -> 3, 0.6-0.8 -> 4, 0.8-1.0 -> 5
            let rating: Double
            if event.listenDurationPercentage >= 0.8 { rating = 5.0 }
            else if event.listenDurationPercentage >= 0.6 { rating = 4.0 }
            else if event.listenDurationPercentage >= 0.4 { rating = 3.0 }
            else if event.listenDurationPercentage >= 0.2 { rating = 2.0 }
            else { rating = 1.0 }

            return MLRecommender.RecommendationEntry(
                userID: event.userID,
                itemID: event.episodeID,
                rating: rating
            )
        }

        print("Starting MLRecommender training with \(trainingEntries.count) entries...")

        do {
            let builder = try MLRecommenderBuilder(trainingData: trainingEntries)
            let model = try await builder.build()
            
            // Save the trained model
            try model.write(to: modelURL)
            self.recommender = model
            print("Successfully trained and saved MLRecommender model to \(modelURL.path)")
        } catch {
            print("Error during MLRecommender training: \(error.localizedDescription)")
            throw RecommendationServiceError.trainingFailed(error)
        }
    }

    /// Fetches personalized podcast episode recommendations for a given user.
    /// - Parameters:
    ///   - userID: The ID of the user for whom to generate recommendations.
    ///   - count: The desired number of recommendations.
    ///   - userListenHistory: A set of episode IDs the user has already listened to, to exclude from recommendations.
    /// - Returns: An array of recommended `PodcastEpisode` objects.
    /// - Throws: `RecommendationServiceError` if the model is not loaded or recommendation fails.
    func getRecommendations(forUserID userID: String, count: Int, userListenHistory: Set<String>) async throws -> [PodcastEpisode] {
        guard let recommender = self.recommender else {
            throw RecommendationServiceError.modelNotLoaded
        }

        print("Fetching personalized recommendations for user \(userID)...")

        var recommendedEpisodeIDs: [String] = []
        do {
            // Use the recommender to get item recommendations for the user.
            // The `items` parameter can be used to provide context (e.g., "user liked this item, recommend similar").
            // For a user-based recommendation, we just provide the user ID.
            let recommendations = try await recommender.recommend(items: [], forUser: userID, count: count)
            
            // Extract item IDs and filter out already listened episodes
            recommendedEpisodeIDs = recommendations
                .map { $0.itemID }
                .filter { !userListenHistory.contains($0) }

            print("MLRecommender returned \(recommendations.count) raw recommendations, \(recommendedEpisodeIDs.count) after filtering.")

        } catch let mlError as MLRecommenderError {
            // Handle specific MLRecommender errors, e.g., if the user is new to the model.
            print("MLRecommender error for user \(userID): \(mlError.localizedDescription)")
            // Fallback will be triggered if recommendedEpisodeIDs is empty or insufficient.
        } catch {
            print("General error getting recommendations: \(error.localizedDescription)")
            throw RecommendationServiceError.recommendationFailed(error)
        }

        // Cold Start / Fallback Strategy:
        // If the recommender returns too few results (e.g., for a new user not in training data),
        // or if after filtering we don't have enough, supplement with "trending" (most popular) episodes.
        var finalRecommendations: [PodcastEpisode] = []
        if recommendedEpisodeIDs.count < count {
            print("Insufficient personalized recommendations. Supplementing with trending episodes.")
            
            // Simulate "trending" by picking random popular episodes not in history or already recommended.
            let trendingEpisodes = allEpisodes.values
                .filter { !userListenHistory.contains($0.id) && !recommendedEpisodeIDs.contains($0.id) }
                .shuffled() // In a real app, this would be based on actual popularity metrics.
                .prefix(count - recommendedEpisodeIDs.count)
                .map { $0.id }
            
            recommendedEpisodeIDs.append(contentsOf: trendingEpisodes)
        }
        
        // Map episode IDs back to full PodcastEpisode objects
        for episodeID in recommendedEpisodeIDs {
            if let episode = allEpisodes[episodeID] {
                finalRecommendations.append(episode)
            } else {
                print("Warning: Recommended episode ID '\(episodeID)' not found in catalog.")
                // Optionally, throw an error or log more aggressively
            }
        }
        
        // Ensure we don't return more than 'count' recommendations
        return Array(finalRecommendations.prefix(count))
    }
    
    /// Clears the loaded model and deletes the saved model file.
    func clearModel() throws {
        self.recommender = nil
        if FileManager.default.fileExists(atPath: modelURL.path) {
            try FileManager.default.removeItem(at: modelURL)
            print("Deleted MLRecommender model file at \(modelURL.path)")
        }
    }
}

// MARK: - 4. App Context Simulation (Main Execution)

/// A simple view model to simulate how an app might use the recommendation service.
@available(macOS 15.0, iOS 18.0, tvOS 18.0, watchOS 11.0, *)
class PodcastFeedViewModel: ObservableObject {
    @Published var recommendations: [PodcastEpisode] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let recommendationService: PodcastRecommendationService
    private let currentUser: String
    private var allEpisodes: [String: PodcastEpisode] = [:]
    private var userListenHistory: Set<String> = [] // Simulate user's listened episodes

    init(userID: String, service: PodcastRecommendationService) {
        self.currentUser = userID
        self.recommendationService = service
    }

    /// Initializes the service, potentially loads a model, or trains a new one.
    /// This might be called once on app launch.
    func setupService(users: [String], episodes: [PodcastEpisode], listenEvents: [UserListenEvent]) async {
        isLoading = true
        errorMessage = nil
        self.allEpisodes = Dictionary(uniqueKeysWithValues: episodes.map { ($0.id, $0) })
        
        // Simulate a user's listen history for filtering
        self.userListenHistory = Set(listenEvents.filter { $0.userID == currentUser }.map { $0.episodeID })

        do {
            // Try to load an existing model first
            try await recommendationService.loadModel()
        } catch RecommendationServiceError.modelNotLoaded {
            print("No existing model found, initiating training...")
            // If no model exists, train a new one
            do {
                try await recommendationService.trainRecommender(listenEvents: listenEvents, episodes: allEpisodes)
            } catch {
                errorMessage = "Failed to train recommendation model: \(error.localizedDescription)"
                print(errorMessage!)
            }
        } catch {
            errorMessage = "Failed to setup recommendation service: \(error.localizedDescription)"
            print(errorMessage!)
        }
        isLoading = false
    }

    /// Fetches recommendations for the current user.
    func fetchRecommendations(count: Int = 10) async {
        isLoading = true
        errorMessage = nil
        do {
            let fetchedRecommendations = try await recommendationService.getRecommendations(
                forUserID: currentUser,
                count: count,
                userListenHistory: userListenHistory
            )
            DispatchQueue.main.async {
                self.recommendations = fetchedRecommendations
                self.isLoading = false
                print("Displaying \(self.recommendations.count) recommendations for \(self.currentUser).")
            }
        } catch {
            DispatchQueue.main.async {
                self.errorMessage = "Failed to fetch recommendations: \(error.localizedDescription)"
                self.isLoading = false
                print(self.errorMessage!)
            }
        }
    }
}

// Main entry point for the simulation
@available(macOS 15.0, iOS 18.0, tvOS 18.0, watchOS 11.0, *)
@main
struct PodcastRecommenderApp {
    static func main() async {
        print("--- Podcast Discovery System Simulation ---")

        // 1. Generate Mock Data
        let mockUsers = (0..<100).map { "user_\($0)" }
        let mockEpisodes = MockPodcastDataGenerator.shared.generateMockEpisodes(count: 200)
        let mockListenEvents = MockPodcastDataGenerator.shared.generateMockListenEvents(
            users: mockUsers,
            episodes: mockEpisodes,
            eventCountPerUser: 15
        )
        print("Generated \(mockUsers.count) users, \(mockEpisodes.count) episodes, and \(mockListenEvents.count) listen events.")

        let targetUserID = "user_5" // User for whom we want recommendations
        let newUserID = "user_999" // A user not in the training data (cold start)

        let service = PodcastRecommendationService()
        let viewModelForTargetUser = PodcastFeedViewModel(userID: targetUserID, service: service)
        let viewModelForNewUser = PodcastFeedViewModel(userID: newUserID, service: service)

        // Ensure the model file is clean for a fresh run
        try? service.clearModel()

        // 2. Setup and Train the Recommendation Service (simulating app launch)
        print("\n--- Setting up service for target user (\(targetUserID)) ---")
        await viewModelForTargetUser.setupService(users: mockUsers, episodes: mockEpisodes, listenEvents: mockListenEvents)
        if let error = viewModelForTargetUser.errorMessage {
            print("Setup error: \(error)")
            return
        }

        // 3. Fetch Recommendations for Target User
        print("\n--- Fetching recommendations for \(targetUserID) ---")
        await viewModelForTargetUser.fetchRecommendations(count: 5)
        if let error = viewModelForTargetUser.errorMessage {
            print("Recommendation error: \(error)")
        } else {
            print("\nRecommended for \(targetUserID):")
            viewModelForTargetUser.recommendations.forEach { episode in
                print("- \(episode.title) (Genre: \(episode.genre))")
            }
        }

        // 4. Simulate Cold Start User
        print("\n--- Setting up service for new user (\(newUserID)) ---")
        // Note: The service itself is already trained. For a real cold start,
        // the user would not have listen events *in the training data*.
        // We'll simulate this by providing an ID not present in the training events.
        await viewModelForNewUser.setupService(users: mockUsers, episodes: mockEpisodes, listenEvents: mockListenEvents)
        if let error = viewModelForNewUser.errorMessage {
            print("Setup error for new user: \(error)")
        }

        print("\n--- Fetching recommendations for new user (\(newUserID)) (Cold Start Simulation) ---")
        await viewModelForNewUser.fetchRecommendations(count: 5)
        if let error = viewModelForNewUser.errorMessage {
            print("Recommendation error for new user: \(error)")
        } else {
            print("\nRecommended for new user (\(newUserID)):")
            viewModelForNewUser.recommendations.forEach { episode in
                print("- \(episode.title) (Genre: \(episode.genre))")
            }
            print("Notice how these might be more generic or 'trending' if the user had no listen history in the model.")
        }
        
        // 5. Clean up the model file
        try? service.clearModel()
        print("\n--- Simulation Complete ---")
    }
}
