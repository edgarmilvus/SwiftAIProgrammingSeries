
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import Observation // For @Observable

@available(visionOS 1.0, *)
@Observable
class SpatialInteractionModel {
    var userGazeTarget: DetectedSpatialObject? // What the user is currently looking at
    var availablePlacementSurfaces: [Transform] = [] // AI-detected flat surfaces
    var isAIActive: Bool = false // State of an AI processing pipeline

    func updateUserGaze(target: DetectedSpatialObject?) {
        self.userGazeTarget = target
        // SwiftUI views observing this will update
    }

    func updateSurfaces(newSurfaces: [Transform]) {
        self.availablePlacementSurfaces = newSurfaces
    }

    func toggleAIActivity() {
        self.isAIActive.toggle()
    }
}

// Example SwiftUI View reacting to changes
import SwiftUI
import RealityKit

@available(visionOS 1.0, *)
struct ImmersiveContent: View {
    @Environment(SpatialInteractionModel.self) private var interactionModel
    @State private var hoveredEntity: Entity?

    var body: some View {
        RealityView { content in
            // Setup initial RealityKit content
            let sphere = ModelEntity(mesh: .generateSphere(radius: 0.1), materials: [SimpleMaterial(color: .blue, isMetallic: false)])
            sphere.position = [-0.2, 0.1, -0.5]
            sphere.name = "Blue Sphere"
            content.add(sphere)
            
            let cube = ModelEntity(mesh: .generateBox(size: 0.1), materials: [SimpleMaterial(color: .red, isMetallic: false)])
            cube.position = [0.2, 0.1, -0.5]
            cube.name = "Red Cube"
            content.add(cube)
        } update: { content in
            // This block is implicitly run when @Observable properties change
            if let target = interactionModel.userGazeTarget {
                // Highlight the gazed object (simplified for example)
                if let entity = content.entities.first(where: { $0.name == target.name }) as? ModelEntity {
                    entity.model?.materials = [SimpleMaterial(color: .yellow, isMetallic: false)]
                }
            } else {
                // Reset materials if no target
                for entity in content.entities.compactMap({ $0 as? ModelEntity }) {
                    if entity.name == "Blue Sphere" {
                        entity.model?.materials = [SimpleMaterial(color: .blue, isMetallic: false)]
                    } else if entity.name == "Red Cube" {
                        entity.model?.materials = [SimpleMaterial(color: .red, isMetallic: false)]
                    }
                }
            }
            
            // Show AI activity status
            print("AI Activity Status: \(interactionModel.isAIActive ? "Active" : "Inactive")")
        }
        .onAppear {
            // Simulate AI detecting surfaces
            interactionModel.updateSurfaces(newSurfaces: [
                .init(translation: [0, -0.3, -1]), // A floor surface
                .init(translation: [0, 0.5, -1.5]) // A wall surface
            ])
            // Simulate AI detecting gaze
            Task { @MainActor in
                try await Task.sleep(for: .seconds(2))
                interactionModel.updateUserGaze(target: DetectedSpatialObject(id: UUID(), name: "Blue Sphere", transform: .identity, confidence: 1.0, timestamp: Date()))
                try await Task.sleep(for: .seconds(2))
                interactionModel.updateUserGaze(target: nil)
            }
        }
    }
}
