
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CloudKit
import OSLog

/// Represents the various errors that can occur during CloudKit operations.
/// Using a specialized enum allows for granular error handling and UI feedback.
enum CloudKitError: LocalizedError {
    case recordNotFound
    case permissionDenied
    case sharingFailed(String)
    case networkError(Error)
    case zoneCreationFailed
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .recordNotFound: return "The requested research note could not be found."
        case .permissionDenied: return "You do not have permission to access this shared content."
        case .sharingFailed(let msg): return "Failed to share: \(msg)"
        case .networkError(let err): return "Network error: \(err.localizedDescription)"
        case .zoneCreationFailed: return "Could not initialize the private custom zone."
        case .unknown(let err): return "An unexpected error occurred: \(err.localizedDescription)"
        }
    }
}

/// A model representing a Research Note in the OmniScholar ecosystem.
/// Conforms to Sendable to ensure safety across concurrency boundaries.
struct ResearchNote: Sendable, Identifiable {
    let id: CKRecord.ID
    let title: String
    let content: String
    let author: String
    let isPublic: Bool
    
    /// Converts a CKRecord back into a domain-specific ResearchNote.
    init?(record: CKRecord) {
        guard let title = record["title"] as? String,
              let content = record["content"] as? String,
              let author = record["author"] as? String else {
            return nil
        }
        self.id = record.recordID
        self.title = title
        self.content = content
        self.author = author
        self.isPublic = record.recordID.zoneID.zoneName == CKRecordZone.default().zoneID.zoneName
    }
}

/// The central actor responsible for managing all CloudKit database interactions.
/// Using an `actor` ensures that all database operations are serialized, 
/// preventing race conditions when multiple UI components trigger syncs.
@available(iOS 18.0, *)
actor CloudKitManager {
    
    private let container = CKContainer.default()
    private let privateDB: CKDatabase
    private let publicDB: CKDatabase
    private let sharedDB: CKDatabase
    private let logger = Logger(subsystem: "com.omnischolar.app", category: "CloudKit")
    
    // The custom zone is required for CKShare functionality.
    private let customZoneID = CKRecordZone.ID(zoneName: "ResearchZone", ownerName: CKCurrentUserDefaultName)

    init() {
        self.privateDB = container.privateCloudDatabase
        self.publicDB = container.publicCloudDatabase
        self.sharedDB = container.sharedCloudDatabase
    }

    /// Prepares the environment by creating the custom zone in the private database.
    /// This must be called before any sharing operations.
    func initializeSchema() async throws {
        let zone = CKRecordZone(zoneID: customZoneID)
        do {
            try await privateDB.save(zone)
            logger.info("Successfully initialized custom CKRecordZone.")
        } catch {
            logger.error("Failed to initialize zone: \(error.localizedDescription)")
            throw CloudKitError.zoneCreationFailed
        }
    }

    // MARK: - Private Database Operations

    /// Saves a new research note to the user's private custom zone.
    /// - Parameter note: The domain model to save.
    /// - Returns: The saved CKRecord.ID.
    func savePrivateNote(title: String, content: String) async throws -> CKRecord.ID {
        let recordID = CKRecord.ID(recordName: UUID().uuidString, zoneID: customZoneID)
        let record = CKRecord(recordType: "ResearchNote", recordID: recordID)
        
        record["title"] = title as CKRecordValue
        record["content"] = content as CKRecordValue
        record["author"] = "Current User" as CKRecordValue
        
        do {
            let savedRecord = try await privateDB.save(record)
            logger.info("Saved private note: \(savedRecord.recordID.recordName)")
            return savedRecord.recordID
        } catch {
            throw CloudKitError.networkError(error)
        }
    }

    // MARK: - Sharing Operations

    /// Creates a CKShare for a specific record, enabling collaboration.
    /// - Parameter recordID: The ID of the record in the private zone to share.
    /// - Returns: The CKShare object which can be used with UICloudSharingController.
    func createShare(for recordID: CKRecord.ID) async throws -> CKShare {
        // 1. Fetch the original record from the private database
        let record = try await privateDB.record(for: recordID)
        
        // 2. Initialize the CKShare object
        let share = CKShare(rootRecord: record)
        share[CKShare.SystemFieldKey.title] = "Collaborative Research: \(record["title"] as? String ?? "Untitled")" as CKRecordValue
        
        // 3. Save both the record and the share simultaneously using a transaction
        let operation = CKModifyRecordsOperation(recordsToSave: [record, share], recordIDsToDelete: nil)
        operation.savePolicy = .ifServerRecordUnchanged
        
        return try await withCheckedThrowingContinuation { continuation in
            operation.modifyRecordsResultBlock = { result in
                switch result {
                case .success:
                    continuation.resume(returning: share)
                case .failure(let error):
                    continuation.resume(throwing: CloudKitError.sharingFailed(error.localizedDescription))
                }
            }
            privateDB.add(operation)
        }
    }

    // MARK: - Shared Database Operations

    /// Fetches all notes that have been shared with the user.
    /// These reside in the `sharedCloudDatabase`.
    func fetchSharedNotes() async throws -> [ResearchNote] {
        // Note: In a real app, you would use CKFetchRecordZoneChangesOperation 
        // for efficient incremental syncing. For this example, we use a query.
        let query = CKQuery(recordType: "ResearchNote", predicate: NSPredicate(value: true))
        
        do {
            // Fetching from the shared database
            let (results, _) = try await sharedDB.records(matching: query)
            
            return results.compactMap { (_, result) in
                switch result {
                case .success(let record):
                    return ResearchNote(record: record)
                case .failure:
                    return nil
                }
            }
        } catch {
            throw CloudKitError.networkError(error)
        }
    }

    // MARK: - Public Database Operations

    /// "Publishes" a private note to the public database.
    /// This creates a *new* record in the Public Database to ensure the original remains private.
    /// - Parameter privateRecordID: The ID of the private record to replicate.
    func publishToPublic(privateRecordID: CKRecord.ID) async throws {
        // 1. Fetch the private record
        let privateRecord = try await privateDB.record(for: privateRecordID)
        
        // 2. Create a new record for the Public Database
        // Public records must live in the default zone.
        let publicRecord = CKRecord(recordType: "ResearchNote", recordID: CKRecord.ID(recordName: privateRecord.recordID.recordName))
        
        publicRecord["title"] = privateRecord["title"]
        publicRecord["content"] = privateRecord["content"]
        publicRecord["author"] = privateRecord["author"]
        
        // 3. Save to the public database
        do {
            try await publicDB.save(publicRecord)
            logger.info("Successfully published note to the global commons.")
        } catch {
            throw CloudKitError.unknown(error)
        }
    }
}
