
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

struct OllamaModel: Identifiable, CustomStringConvertible {
    let id = UUID() // For SwiftUI List compatibility
    let name: String
    let size: String
    let digest: String
    let lastModified: String

    var description: String {
        "Name: \(name), Size: \(size), Digest: \(digest), Last Modified: \(lastModified)"
    }
}

enum OllamaError: Error, LocalizedError {
    case commandNotFound(path: String)
    case executionFailed(status: Int, stderr: String)
    case outputParsingFailed(output: String)
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .commandNotFound(let path):
            return "Ollama command not found at '\(path)'. Is Ollama installed and in your PATH? Try specifying the full path."
        case .executionFailed(let status, let stderr):
            return "Ollama command failed with exit status \(status).\nError: \(stderr)"
        case .outputParsingFailed:
            return "Failed to parse Ollama model list output."
        case .unknown(let error):
            return "An unknown error occurred: \(error.localizedDescription)"
        }
    }
}

func getOllamaModels(ollamaExecutablePath: URL? = nil) async throws -> [OllamaModel] {
    let process = Process()
    let stdoutPipe = Pipe()
    let stderrPipe = Pipe()

    process.standardOutput = stdoutPipe
    process.standardError = stderrPipe

    // Determine Ollama executable path
    let defaultOllamaPath = "/usr/local/bin/ollama" // Common path for Homebrew/manual installs
    let executableURL: URL
    if let customPath = ollamaExecutablePath {
        executableURL = customPath
    } else {
        // Attempt to find Ollama in common locations or rely on PATH
        if FileManager.default.fileExists(atPath: defaultOllamaPath) {
            executableURL = URL(fileURLWithPath: defaultOllamaPath)
        } else {
            // Fallback to searching PATH, which Process does if executableURL is just "ollama"
            // However, for robustness, it's better to provide a full path.
            // For this example, we'll try the default path first, then rely on PATH if not found.
            // In a real app, you might use 'which ollama' or let the user configure.
            executableURL = URL(fileURLWithPath: "ollama") // Process will search PATH
        }
    }
    
    process.executableURL = executableURL
    process.arguments = ["list"]

    do {
        try process.run()
    } catch {
        // Catch errors like executable not found before even running
        if let posixError = error as? POSIXError, posixError.code == .ENOENT {
            throw OllamaError.commandNotFound(path: executableURL.path)
        }
        throw OllamaError.unknown(error)
    }

    // Await process termination
    process.waitUntilExit()

    let stdoutData = stdoutPipe.fileHandleForReading.readDataToEndOfFile()
    let stderrData = stderrPipe.fileHandleForReading.readDataToEndOfFile()

    let stdout = String(data: stdoutData, encoding: .utf8) ?? ""
    let stderr = String(data: stderrData, encoding: .utf8) ?? ""

    guard process.terminationStatus == 0 else {
        throw OllamaError.executionFailed(status: Int(process.terminationStatus), stderr: stderr.isEmpty ? "No specific error output." : stderr)
    }

    // Parse the output
    // Example output format:
    // NAME             ID           SIZE     MODIFIED       
    // llama2:latest    e00b41981078 3.8 GB   2 weeks ago    
    // mistral:latest   e2a0ad697961 4.1 GB   2 weeks ago    
    let lines = stdout.split(separator: "\n").map { String($0) }
    guard lines.count > 1 else { // Expect at least a header and one model
        if stdout.contains("no models found") {
            return [] // No models installed
        }
        throw OllamaError.outputParsingFailed(output: stdout)
    }

    var models: [OllamaModel] = []
    // Skip header line
    for line in lines.dropFirst() {
        // Split by whitespace, but handle multiple spaces as single delimiter
        let components = line.split(whereSeparator: \.isWhitespace).map { String($0) }
        
        // Basic validation for expected number of components
        // NAME, ID, SIZE, MODIFIED_COUNT, MODIFIED_UNIT, MODIFIED_AGO
        // e.g., "llama2:latest", "e00b41981078", "3.8", "GB", "2", "weeks", "ago"
        // This is a bit fragile, a regex might be more robust for complex date strings.
        // For simplicity, we'll assume a consistent 4-part structure for NAME, ID, SIZE+UNIT, MODIFIED_STRING
        
        // Let's refine parsing for the common 'ollama list' output:
        // NAME             ID           SIZE     MODIFIED
        // llama2:latest    e00b41981078 3.8 GB   2 weeks ago
        // The 'SIZE' and 'MODIFIED' columns can contain spaces.
        // A more robust approach would be to find the column delimiters or use regex.
        // For now, let's assume fixed column widths or a simple split works for typical output.
        // A better heuristic is to find the first few tokens, then combine the rest.

        if components.count >= 4 {
            let name = components[0]
            let digest = components[1]
            let size = components[2] + (components.count > 3 && components[3].uppercased().hasSuffix("B") ? " " + components[3] : "") // e.g., "3.8 GB"
            
            // The remaining components form the 'last modified' string
            let modifiedStartIndex = components.count > 3 && components[3].uppercased().hasSuffix("B") ? 4 : 3
            let lastModified = components.dropFirst(modifiedStartIndex).joined(separator: " ")
            
            models.append(OllamaModel(name: name, size: size, digest: digest, lastModified: lastModified))
        } else if components.count >= 3 { // Fallback for simpler size/modified if no unit
             let name = components[0]
             let digest = components[1]
             let size = components[2]
             let lastModified = components.dropFirst(3).joined(separator: " ") // Empty if no more components
             models.append(OllamaModel(name: name, size: size, digest: digest, lastModified: lastModified))
        } else {
             // Log or handle lines that don't fit the expected format
             print("Warning: Skipping malformed Ollama list line: \(line)")
        }
    }

    return models
}

// Example Usage:
/*
Task {
    do {
        let models = try await getOllamaModels()
        if models.isEmpty {
            print("No Ollama models found.")
        } else {
            print("Found Ollama Models:")
            for model in models {
                print("- \(model)")
            }
        }
    } catch {
        if let ollamaError = error as? OllamaError {
            print("Ollama Error: \(ollamaError.localizedDescription)")
        } else {
            print("An unexpected error occurred: \(error.localizedDescription)")
        }
    }
}
*/
