
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct Email {
    let id: String // Unique identifier for the email
    let sender: String
    let subject: String
    let body: String
    let timestamp: Date
    var isRead: Bool
    // Add other relevant email properties as needed, e.g., attachments, flags
}

@available(iOS 18.0, macOS 15.0, *)
enum EmailCategory: String, CaseIterable, CustomStringConvertible {
    case primary = "Primary"
    case promotions = "Promotions"
    case social = "Social"
    case updates = "Updates"
    case spam = "Spam"
    case uncategorized = "Uncategorized" // For cases where on-device logic can't decide
    
    var description: String {
        return self.rawValue
    }
}

@available(iOS 18.0, macOS 15.0, *)
class EmailCategorizer {
    // This class represents the ON-DEVICE component of the Smart Mailbox Categorization.
    // It uses local rules and a simulated on-device ML model for categorization.
    // No email content leaves the device during this process.

    /// Categorizes an email using on-device intelligence (rules and mock ML).
    /// This method performs all processing locally on the user's device.
    ///
    /// - Parameter email: The email to categorize.
    /// - Returns: The predicted category for the email.
    func categorize(email: Email) -> EmailCategory {
        // --- ON-DEVICE PROCESSING BEGINS ---
        // All checks and decisions in this function are made using only local data.

        let lowercasedSubject = email.subject.lowercased()
        let lowercasedBody = email.body.lowercased()
        let lowercasedSender = email.sender.lowercased()

        // 1. User-defined rules / Known contacts (highest priority, most private)
        // In a real app, this would check against a local database of user rules.
        if lowercasedSender.contains("myboss.com") || lowercasedSender.contains("family.com") {
            return .primary
        }

        // 2. Simple on-device ML mock (keyword matching for demonstration)
        // In a real scenario, this would be a Foundation.ML text classifier or a Core ML model.
        // The model would be trained on sanitized/generalized data and downloaded to the device.

        // Promotions detection
        if lowercasedSubject.contains("sale") || lowercasedSubject.contains("discount") ||
           lowercasedBody.contains("coupon") || lowercasedBody.contains("promo code") ||
           lowercasedSender.contains("marketing") || lowercasedSender.contains("newsletter") {
            return .promotions
        }

        // Social notifications
        if lowercasedSender.contains("facebook.com") || lowercasedSender.contains("twitter.com") ||
           lowercasedSender.contains("linkedin.com") || lowercasedSubject.contains("notification") ||
           lowercasedBody.contains("liked your post") || lowercasedBody.contains("commented on") {
            return .social
        }

        // Updates/Notifications (e.g., from apps, services)
        if lowercasedSubject.contains("update") || lowercasedSubject.contains("alert") ||
           lowercasedBody.contains("new version available") || lowercasedSender.contains("noreply") ||
           lowercasedSender.contains("appstore.com") || lowercasedBody.contains("service announcement") {
            return .updates
        }
        
        // Basic Spam detection (can be augmented by PCC)
        if lowercasedSubject.contains("viagra") || lowercasedBody.contains("free money") ||
           lowercasedSender.contains("spam.ru") {
            return .spam
        }

        // 3. Default or mark as uncategorized if no clear on-device rule matches
        // This is where a real system might generate privacy-preserving signals for PCC.
        return .primary // Default to primary if no other rules match with high confidence
        // --- ON-DEVICE PROCESSING ENDS ---
    }
}

// Example Usage:
@available(iOS 18.0, macOS 15.0, *)
func demonstrateEmailCategorization() {
    let categorizer = EmailCategorizer()

    print("--- Exercise 3: Smart Mailbox Categorization (On-Device) ---")

    let email1 = Email(id: "e001", sender: "newsletter@shopgreat.com", subject: "Flash Sale! 50% Off Everything!", body: "Don't miss our incredible discounts this week...", timestamp: Date(), isRead: false)
    print("Email 1: '\(email1.subject)' -> Category: \(categorizer.categorize(email: email1).description)")

    let email2 = Email(id: "e002", sender: "security@mybank.com", subject: "Important Security Alert", body: "Your account activity requires review...", timestamp: Date(), isRead: false)
    print("Email 2: '\(email2.subject)' -> Category: \(categorizer.categorize(email: email2).description)")

    let email3 = Email(id: "e003", sender: "notifications@facebook.com", subject: "Someone liked your post!", body: "John Doe liked your photo...", timestamp: Date(), isRead: false)
    print("Email 3: '\(email3.subject)' -> Category: \(categorizer.categorize(email: email3).description)")

    let email4 = Email(id: "e004", sender: "support@myapp.com", subject: "New Version of MyApp Available!", body: "We've just released MyApp 2.0 with exciting new features.", timestamp: Date(), isRead: false)
    print("Email 4: '\(email4.subject)' -> Category: \(categorizer.categorize(email: email4).description)")

    let email5 = Email(id: "e005", sender: "friend@family.com", subject: "Dinner plans tonight?", body: "Are you free for dinner at 7 PM?", timestamp: Date(), isRead: false)
    print("Email 5: '\(email5.subject)' -> Category: \(categorizer.categorize(email: email5).description)")

    let email6 = Email(id: "e006", sender: "cheap-pills@spam.ru", subject: "GET RICH QUICK!!!", body: "Click here for amazing deals on medications.", timestamp: Date(), isRead: false)
    print("Email 6: '\(email6.subject)' -> Category: \(categorizer.categorize(email: email6).description)")
    print("-------------------------------------------------------------------\n")
}

// To run this example in a playground or application:
// demonstrateEmailCategorization()
