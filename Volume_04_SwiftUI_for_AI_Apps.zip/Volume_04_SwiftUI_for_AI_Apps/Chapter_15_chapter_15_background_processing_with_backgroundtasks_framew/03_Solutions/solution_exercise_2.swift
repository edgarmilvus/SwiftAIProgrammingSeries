
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import BackgroundTasks
import UIKit // Needed for AppDelegate context

// MARK: - Background Task Manager

@available(iOS 18.0, *)
class BackgroundTaskManager {

    static let shared = BackgroundTaskManager()

    private let processingTaskIdentifier = "com.yourcompany.yourapp.embeddingProcessingTask"
    private var currentProcessingTask: Task<Void, Never>? // To allow cancellation

    private init() {} // Singleton

    // MARK: - Registration

    func registerEmbeddingProcessingTask() {
        // Register on a background queue as this is a CPU-intensive task
        BGTaskScheduler.shared.register(forTaskWithIdentifier: processingTaskIdentifier, onQueue: .global(qos: .userInitiated)) { task in
            guard let processingTask = task as? BGProcessingTask else {
                print("Error: Task is not a BGProcessingTask.")
                task.setTaskCompleted(success: false)
                return
            }
            self.handleEmbeddingProcessing(task: processingTask)
        }
        print("Registered background processing task: \(processingTaskIdentifier)")
    }

    // MARK: - Scheduling

    func scheduleEmbeddingProcessing() {
        let request = BGProcessingTaskRequest(identifier: processingTaskIdentifier)
        request.requiresNetworkConnectivity = false // No network needed
        request.requiresExternalPower = false      // No external power needed
        // Request to run no earlier than 5 minutes from now.
        request.earliestBeginDate = Date(timeIntervalSinceNow: 60 * 5)

        do {
            try BGTaskScheduler.shared.submit(request)
            print("Scheduled background embedding processing request.")
        } catch {
            print("Could not schedule embedding processing: \(error.localizedDescription)")
        }
    }

    // MARK: - Task Handler

    private func handleEmbeddingProcessing(task: BGProcessingTask) {
        print("Background embedding processing task started for \(task.identifier).")

        // Store the current task for potential cancellation
        currentProcessingTask = Task {
            // Set an expiration handler to clean up if the system terminates the task early.
            task.expirationHandler = {
                print("Background embedding processing task expired for \(task.identifier). Cancelling ongoing operations.")
                self.currentProcessingTask?.cancel() // Cancel the Swift Concurrency Task
                task.setTaskCompleted(success: false) // Mark as failed due to expiration
            }

            let totalDocuments = 10
            var processedCount = UserDefaults.standard.integer(forKey: "embeddingProcessingProgress") // Load saved progress

            var success = true
            for i in processedCount..<totalDocuments {
                // Check for cancellation before processing each document
                if Task.isCancelled || task.isCancelled { // Check both Swift Task and BGTask cancellation
                    print("Embedding processing task cancelled or expired, processed \(processedCount) documents.")
                    success = false
                    break
                }

                print("Processing document \(i + 1)/\(totalDocuments)...")
                // Simulate computationally intensive work
                await Task.sleep(for: .seconds(Double.random(in: 1...3)))
                processedCount = i + 1
                UserDefaults.standard.set(processedCount, forKey: "embeddingProcessingProgress") // Save progress
            }

            // Ensure the task is marked complete only if not already expired
            if !Task.isCancelled && !task.isCancelled {
                print("Background embedding processing task for \(task.identifier) completed with success: \(success).")
                task.setTaskCompleted(success: success)
                if success {
                    UserDefaults.standard.set(0, forKey: "embeddingProcessingProgress") // Reset progress on full completion
                }
            } else {
                print("Background embedding processing task for \(task.identifier) was cancelled externally (e.g., by expiration handler).")
                task.setTaskCompleted(success: false) // Mark as failed if cancelled
            }
            self.currentProcessingTask = nil // Clear reference
            // Re-schedule if there's still work to do, or if it's a periodic task.
            // For this scenario, we might only reschedule if there are new documents.
            // For simplicity, we'll always reschedule, but a real app would check for pending work.
            self.scheduleEmbeddingProcessing()
        }
    }
}

// MARK: - AppDelegate Integration Example

// Extend AppDelegate to call the BackgroundTaskManager methods
/*
@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    let backgroundTaskManager = BackgroundTaskManager.shared

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        if #available(iOS 18.0, *) {
            backgroundTaskManager.registerEmbeddingProcessingTask()
            // Schedule if there's pending work from a previous session, or if it's a periodic task.
            // For this example, we'll schedule it once initially.
            // In a real app, you'd check if UserDefaults.standard.integer(forKey: "embeddingProcessingProgress") > 0
            // or if a new document was added.
            backgroundTaskManager.scheduleEmbeddingProcessing()
        } else {
            // Fallback for older iOS versions if needed
        }
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        if #available(iOS 18.0, *) {
            // Re-schedule if there might be pending work
            backgroundTaskManager.scheduleEmbeddingProcessing()
        }
    }
}
*/
