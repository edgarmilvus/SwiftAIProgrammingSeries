
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Vision
import CoreML
import Network
import OSLog

// MARK: - Domain Models

/// Represents the sensitivity level of the data being processed.
/// This is the primary driver for the privacy decision engine.
enum DataSensitivity: Int, Comparable, Sendable {
    case publicInformation = 0
    case personalInformation = 1
    case highlySensitive = 2 // e.g., Medical, Financial, Legal

    static func < (lhs: DataSensitivity, rhs: DataSensitivity) -> Bool {
        lhs.rawValue < rhs.rawValue
    }
}

/// Errors specific to the Hybrid AI Pipeline.
enum AIProcessingError: Error, LocalizedError {
    case insufficientPrivacyClearance
    case networkUnavailable
    case modelFailure(String)
    case dataCorruption
    
    var errorDescription: String? {
        switch self {
        case .insufficientPrivacyClearance: return "Data sensitivity exceeds allowed cloud processing limits."
        case .networkUnavailable: return "Cloud processing requested but network is unavailable."
        case .modelFailure(let msg): return "AI Model Error: \(msg)"
        case .dataCorruption: return "The input data could not be parsed."
        }
    }
}

/// The result of an intelligence task, regardless of where it was processed.
struct IntelligenceResult: Sendable {
    let text: String
    let metadata: [String: String]
    let processedOnDevice: Bool
    let confidence: Float
}

// MARK: - Processing Strategies

/// A protocol defining the requirements for an AI processing provider.
/// Using a protocol allows us to swap On-Device and Cloud implementations seamlessly.
protocol AIProcessingProvider: Sendable {
    func process(image: CGImage, sensitivity: DataSensitivity) async throws -> IntelligenceResult
}

/// Implementation of On-Device processing using Apple's Vision and CoreML.
/// This leverages the Apple Neural Engine (ANE) for maximum privacy and efficiency.
@available(iOS 18.0, *)
final class LocalVisionProcessor: AIProcessingProvider {
    private let logger = Logger(subsystem: "com.ai.app", category: "OnDevice")
    
    func process(image: CGImage, sensitivity: DataSensitivity) async throws -> IntelligenceResult {
        logger.info("Starting on-device OCR and NLP processing.")
        
        // In a real implementation, we would use VNRecognizeTextRequest
        // and a local CoreML model for entity extraction.
        return try await Task.detached(priority: .userInitiated) {
            // Simulate heavy Neural Engine workload
            try await Task.sleep(for: .seconds(1.5))
            
            // Mocking the extraction logic
            let mockText = "Extracted text from local ANE"
            return IntelligenceResult(
                text: mockText,
                metadata: ["engine": "Apple Neural Engine"],
                processedOnDevice: true,
                confidence: 0.98
            )
        }.value
    }
}

/// Implementation of Cloud-based processing for high-complexity tasks.
/// This uses a secure TLS-encrypted endpoint to reach an LLM.
@available(iOS 18.0, *)
final class RemoteIntelligenceProcessor: AIProcessingProvider {
    private let logger = Logger(subsystem: "com.ai.app", category: "Cloud")
    private let endpoint = URL(string: "https://api.secure-ai-provider.com/v1/analyze")!

    func process(image: CGImage, sensitivity: DataSensitivity) async throws -> IntelligenceResult {
        logger.info("Routing request to secure cloud endpoint.")
        
        // In production, we would convert the image to a compressed JPEG/WebP
        // and perform a multipart POST request.
        let (data, response) = try await URLSession.shared.data(from: endpoint)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw AIProcessingError.modelFailure("Cloud service returned non-200 status.")
        }
        
        // Mocking the decoding of LLM response
        return IntelligenceResult(
            text: "Deep LLM Analysis: This document contains...",
            metadata: ["engine": "Cloud-LLM-GPT4"],
            processedOnDevice: false,
            confidence: 0.94
        )
    }
}

// MARK: - The Orchestrator

/// The `PrivacyDecisionEngine` is the brain of the application.
/// It is implemented as an `actor` to ensure that state changes (like network status
/// or user privacy settings) are handled safely across multiple concurrent tasks.
@available(iOS 18.0, *)
actor PrivacyDecisionEngine {
    private let localProcessor: LocalVisionProcessor
    private let remoteProcessor: RemoteIntelligenceProcessor
    private let monitor = NWPathMonitor()
    private var isNetworkAvailable: Bool = false
    
    /// User-defined preference: Should we ever use the cloud?
    private var allowCloudProcessing: Bool = true
    
    private let logger = Logger(subsystem: "com.ai.app", category: "Orchestrator")

    init(local: LocalVisionProcessor, remote: RemoteIntelligenceProcessor) {
        self.localProcessor = local
        self.remoteProcessor = remote
        
        // Start monitoring network connectivity
        monitor.pathUpdateHandler = { [weak self] path in
            Task { [weak self] in
                await self?.updateNetworkStatus(path.status == .satisfied)
            }
        }
        monitor.start(queue: DispatchQueue.global(qos: .background))
    }
    
    private func updateNetworkStatus(_ available: Bool) {
        self.isNetworkAvailable = available
        logger.info("Network status updated: \(available ? "Connected" : "Disconnected")")
    }
    
    /// Allows the user to toggle privacy settings at runtime.
    func setCloudPreference(allowed: Bool) {
        self.allowCloudProcessing = allowed
    }

    /// The primary entry point for processing intelligence requests.
    /// This function implements the core decision logic.
    ///
    /// - Parameters:
    ///   - image: The input image to process.
    ///   - sensitivity: The calculated sensitivity of the data.
    /// - Returns: An `IntelligenceResult` containing the processed information.
    /// - Throws: `AIProcessingError` if the decision cannot be fulfilled.
    func processIntelligence(for image: CGImage, sensitivity: DataSensitivity) async throws -> IntelligenceResult {
        logger.info("Received intelligence request. Sensitivity: \(sensitivity.rawValue)")

        // 1. Mandatory On-Device Check: High Sensitivity
        // If data is highly sensitive, we NEVER send it to the cloud, 
        // regardless of network or user preference.
        if sensitivity == .highlySensitive {
            logger.info("High sensitivity detected. Forcing on-device processing.")
            return try await localProcessor.process(image: image, sensitivity: sensitivity)
        }

        // 2. User Preference Check
        // If the user has explicitly opted out of cloud processing.
        if !allowCloudProcessing {
            logger.info("Cloud processing disabled by user. Forcing on-device.")
            return try await localProcessor.process(image: image, sensitivity: sensitivity)
        }

        // 3. Capability vs. Connectivity Check
        // If we have network and the data is low/medium sensitivity, 
        // we attempt cloud processing for higher intelligence.
        if isNetworkAvailable {
            do {
                // We attempt cloud processing first for better accuracy on non-sensitive data
                return try await remoteProcessor.process(image: image, sensitivity: sensitivity)
            } catch {
                logger.error("Cloud processing failed: \(error.localizedDescription). Falling back to local.")
                // Fallback mechanism: If cloud fails, try local as a safety net.
                return try await localProcessor.process(image: image, sensitivity: sensitivity)
            }
        } else {
            // 4. Offline Fallback
            logger.info("Network unavailable. Falling back to local processing.")
            return try await localProcessor.process(image: image, sensitivity: sensitivity)
        }
    }
}

// MARK: - Usage Example (View Model Context)

@available(iOS 18.0, *)
@MainActor
class DocumentScannerViewModel: ObservableObject {
    @Published var resultText: String = ""
    @Published var isProcessing: Bool = false
    @Published var errorMessage: String?
    
    private let engine: PrivacyDecisionEngine
    
    init(engine: PrivacyDecisionEngine) {
        self.engine = engine
    }
    
    func handleDocumentScan(image: CGImage, sensitivity: DataSensitivity) {
        isProcessing = true
        errorMessage = nil
        
        Task {
            do {
                let result = try await engine.processIntelligence(for: image, sensitivity: sensitivity)
                self.resultText = result.text
                self.isProcessing = false
            } catch {
                self.errorMessage = error.localizedDescription
                self.isProcessing = false
            }
        }
    }
}
