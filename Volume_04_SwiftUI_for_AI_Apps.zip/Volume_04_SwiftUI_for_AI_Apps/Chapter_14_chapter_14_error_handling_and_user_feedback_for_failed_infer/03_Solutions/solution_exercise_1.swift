
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import UIKit // For UIImage in the context of the classifier
import SwiftUI

// ImageClassifierError.swift
enum ImageClassifierError: LocalizedError, Identifiable {
    case invalidInput(description: String)
    case modelUnavailable(reason: String)
    case inferenceFailed(underlyingError: Error) // More generic catch-all

    // Conformance to Identifiable for SwiftUI's .alert(isPresented:error:actions:)
    var id: String {
        switch self {
        case .invalidInput(let description): return "invalidInput-\(description.hashValue)"
        case .modelUnavailable(let reason): return "modelUnavailable-\(reason.hashValue)"
        case .inferenceFailed(let underlyingError): return "inferenceFailed-\(underlyingError.localizedDescription.hashValue)"
        }
    }

    var errorDescription: String? {
        switch self {
        case .invalidInput(let description):
            return "The image provided is not suitable for classification. \(description)"
        case .modelUnavailable(let reason):
            return "The image classification model is currently unavailable. \(reason)"
        case .inferenceFailed(let underlyingError):
            // Present a more user-friendly message for generic errors
            return "Image classification failed: An unexpected error occurred. Please try again. (Details: \(underlyingError.localizedDescription))"
        }
    }
}

// ImageClassifier.swift
@available(iOS 18.0, *)
class ImageClassifier {
    func classifyImage(_ image: UIImage) async throws -> String {
        // Simulate a delay for inference
        try await Task.sleep(for: .seconds(1.5))

        // Simulate different error conditions
        let randomNumber = Int.random(in: 0...100)
        if randomNumber < 30 { // 30% chance of invalid input
            throw ImageClassifierError.invalidInput(description: "Image dimensions (width: \(image.size.width), height: \(image.size.height)) are incorrect.")
        } else if randomNumber < 40 { // 10% chance of model unavailable
            throw ImageClassifierError.modelUnavailable(reason: "Model file corrupted or not found.")
        } else if randomNumber < 45 { // 5% chance of a generic underlying error
            // Simulate a non-ImageClassifierError to test generic catch
            throw NSError(domain: "com.example.ImageClassifier", code: 1001, userInfo: [NSLocalizedDescriptionKey: "Internal model processing error."])
        }
        
        // Simulate successful classification
        return "Successfully classified image as 'Cat'."
    }
}

// ImageClassificationView.swift
@available(iOS 18.0, *)
struct ImageClassificationView: View {
    @State private var classificationResult: String?
    @State private var isLoading: Bool = false
    @State private var encounteredError: ImageClassifierError?
    @State private var showingAlert: Bool = false

    private let classifier = ImageClassifier()

    var body: some View {
        VStack {
            if isLoading {
                ProgressView("Classifying image...")
            } else if let result = classificationResult {
                Text("Result: \(result)")
                    .font(.headline)
                    .padding()
            } else {
                Text("Tap 'Classify' to start.")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .padding()
            }

            Button("Classify Random Image") {
                Task { @MainActor in // Ensure UI updates are on the main actor
                    isLoading = true
                    classificationResult = nil
                    encounteredError = nil // Clear previous error
                    
                    // Simulate a random image for demonstration
                    // In a real app, this would come from a Photo Picker or Camera
                    let dummyImage = UIImage(systemName: "photo") ?? UIImage() // Fallback for simulator/preview
                    if dummyImage.size == .zero { // Ensure a non-zero size for the dummy
                        // Create a small dummy image if systemName fails or gives zero size
                        UIGraphicsBeginImageContextWithOptions(CGSize(width: 100, height: 100), false, 1.0)
                        UIColor.lightGray.setFill()
                        UIRectFill(CGRect(x: 0, y: 0, width: 100, height: 100))
                        let img = UIGraphicsGetImageFromCurrentImageContext()
                        UIGraphicsEndImageContextContext()
                        let finalImage = img ?? UIImage()
                        
                        // Perform classification with the created image
                        await performClassification(with: finalImage)
                    } else {
                        await performClassification(with: dummyImage)
                    }
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(isLoading)
        }
        .padding()
        // Using the .alert(isPresented:error:actions:) modifier for a clean error presentation
        .alert(isPresented: $showingAlert, error: encounteredError) { _ in
            Button("OK") {
                // Optionally log the error or perform other cleanup
            }
        } message: { error in
            Text(error.localizedDescription)
        }
    }
    
    @MainActor
    private func performClassification(with image: UIImage) async {
        do {
            let result = try await classifier.classifyImage(image)
            classificationResult = result
        } catch let classifierError as ImageClassifierError {
            encounteredError = classifierError
            showingAlert = true
        } catch {
            // Catch any other unexpected errors and wrap them in our custom error type
            encounteredError = .inferenceFailed(underlyingError: error)
            showingAlert = true
        }
        isLoading = false
    }
}

// App Entry Point (for preview/testing)
@available(iOS 18.0, *)
struct ImageClassificationView_Previews: PreviewProvider {
    static var previews: some View {
        ImageClassificationView()
    }
}
