
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
func performLongRunningInference() async throws -> String {
    // Simulate a long-running AI inference
    for i in 0..<100 {
        // Crucially, check for cancellation at appropriate points
        if Task.isCancelled {
            print("Inference task cancelled at step \(i)")
            // Perform any necessary cleanup before throwing
            throw CancellationError() // Or return an empty result, depending on context
        }

        // Simulate a computationally intensive step
        try await Task.sleep(for: .milliseconds(50))
        print("Processing inference step \(i)...")
    }
    return "Inference Result"
}

@available(iOS 18.0, *)
func demonstrateCancellation() async {
    let inferenceTask = Task {
        do {
            let result = try await performLongRunningInference()
            print("Inference completed: \(result)")
        } catch is CancellationError {
            print("Inference explicitly caught cancellation.")
        } catch {
            print("Inference failed with error: \(error)")
        }
    }

    // Let it run for a bit, then cancel
    try? await Task.sleep(for: .milliseconds(200))
    print("Cancelling inference task...")
    inferenceTask.cancel()

    // Wait for the task to finish (or be cancelled)
    await inferenceTask.value
}
