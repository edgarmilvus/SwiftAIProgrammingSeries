
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CoreData
import CloudKit
import SwiftUI

// MARK: - Data Model Definitions (Conceptual)
/*
 NOTE: In a real project, these entities (Conversation and ChatMessage) 
 are defined in a .xcdatamodeld file. 
 
 Entity: Conversation
 - id: UUID
 - title: String
 - lastUpdated: Date
 
 Entity: ChatMessage
 - id: UUID
 - text: String
 - timestamp: Date
 - isAIResponse: Bool
 - conversation: Conversation (Relationship: One-to-Many)
*/

/// A singleton controller that manages the Core Data stack and CloudKit synchronization.
/// This class is marked as `@MainActor` to ensure that any UI-bound data 
/// fetching or context management happens on the main thread.
@available(iOS 18.0, *)
@MainActor
final class PersistenceController {
    /// The shared instance used throughout the app.
    static let shared = PersistenceController()

    /// The persistent container that handles both local storage and CloudKit syncing.
    let container: NSPersistentCloudKitContainer

    /// Private initializer to enforce singleton pattern.
    private init() {
        // 1. Initialize the container with the name of your .xcdatamodeld file.
        container = NSPersistentCloudKitContainer(name: "AIChatModel")

        // 2. Configure the Persistent Store Description.
        guard let description = container.persistentStoreDescriptions.first else {
            fatalError("Failed to retrieve a persistent store description.")
        }

        // 3. Enable CloudKit Synchronization.
        // This tells Core Data to mirror the local SQLite store to the user's private CloudKit database.
        description.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)
        
        // CloudKit requires that all attributes in the model be either optional 
        // or have default values to prevent sync conflicts.
        description.cloudKitContainerOptions = NSPersistentCloudKitContainerOptions(
            containerIdentifier: "iCloud.com.yourdomain.AIChatApp"
        )

        // 4. Set up History Tracking.
        // History tracking is REQUIRED for NSPersistentCloudKitContainer to 
        // process changes that happen on other devices.
        description.setOption(true as NSNumber, forKey: NSPersistentHistoryTrackingKey)

        // 5. Load the persistent stores.
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                // In a real-world app, handle this gracefully (e.g., alert the user).
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }

        // 6. Configure the view context for automatic UI updates.
        // This ensures that when CloudKit pushes new data from the cloud, 
        // the managed object context automatically merges those changes.
        container.viewContext.automaticallyMergesChangesFromParent = true
        
        // Set the merge policy to favor the in-memory changes over the store 
        // in case of local conflicts during a sync cycle.
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
    }

    /// Creates a new conversation entity in the context.
    /// - Parameter title: The initial title of the AI chat session.
    /// - Returns: A successfully saved Conversation object.
    func createConversation(title: String) {
        let context = container.viewContext
        let newConversation = Conversation(context: context)
        newConversation.id = UUID()
        newConversation.title = title
        newConversation.lastUpdated = Date()

        saveContext()
    }

    /// Persists changes in the view context to the underlying store.
    private func saveContext() {
        let context = container.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                print("Error saving context: \(nserror), \(nserror.userInfo)")
            }
        }
    }
}

// MARK: - ViewModel Layer

/// A ViewModel that manages the state of the Chat Interface.
/// It uses the `@Observable` macro (introduced in Swift 5.9/iOS 17) 
/// to provide efficient, fine-grained UI updates.
@available(iOS 18.0, *)
@Observable
final class ChatViewModel {
    /// The list of conversations fetched from Core Data.
    var conversations: [Conversation] = []
    
    /// The persistence controller instance.
    private let persistenceController: PersistenceController

    init(persistenceController: PersistenceController = .shared) {
        self.persistenceController = persistenceController
        fetchConversations()
    }

    /// Fetches all conversations from the managed object context.
    /// This is called on the @MainActor to ensure thread safety with the UI.
    func fetchConversations() {
        let request: NSFetchRequest<Conversation> = Conversation.fetchRequest()
        // Sort by most recently updated to keep active chats at the top.
        request.sortDescriptors = [NSSortDescriptor(keyPath: \Conversation.lastUpdated, ascending: false)]

        do {
            // We perform the fetch on the viewContext, which is already on the MainActor.
            self.conversations = try persistenceController.container.viewContext.fetch(request)
        } catch {
            print("Failed to fetch conversations: \(error)")
        }
    }

    /// Adds a new message to a specific conversation.
    /// - Parameters:
    ///   - conversation: The conversation to append the message to.
    ///   - text: The user's input text.
    ///   - isAI: Boolean indicating if the message is from the AI.
    func addMessage(to conversation: Conversation, text: String, isAI: Bool) {
        let context = persistenceController.container.viewContext
        let newMessage = ChatMessage(context: context)
        newMessage.id = UUID()
        newMessage.text = text
        newMessage.timestamp = Date()
        newMessage.isAIResponse = isAI
        newMessage.conversation = conversation
        
        // Update the parent conversation's timestamp to trigger a re-sort.
        conversation.lastUpdated = Date()

        do {
            try context.save()
        } catch {
            print("Failed to save message: \(error)")
        }
    }
}

// MARK: - UI Layer

/// The main entry point for the Chat Interface.
@available(iOS 18.0, *)
struct ChatListView: View {
    @State private var viewModel = ChatViewModel()
    @State private var showingNewChatSheet = false
    @State private var newChatTitle = ""

    var body: some View {
        NavigationStack {
            List(viewModel.conversations) { conversation in
                NavigationLink(value: conversation) {
                    VStack(alignment: .leading) {
                        Text(conversation.title ?? "Untitled Chat")
                            .font(.headline)
                        Text(conversation.lastUpdated?.formatted() ?? "")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("AI Memories")
            .navigationDestination(for: Conversation.self) { conversation in
                MessageListView(conversation: conversation, viewModel: viewModel)
            }
            .toolbar {
                Button(action: { showingNewChatSheet = true }) {
                    Image(systemName: "plus.bubble")
                }
            }
            .sheet(isPresented: $showingNewChatSheet) {
                NavigationStack {
                    Form {
                        TextField("Chat Title", text: $newChatTitle)
                    }
                    .navigationTitle("New Conversation")
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Create") {
                                viewModel.createConversation(title: newChatTitle)
                                viewModel.fetchConversations() // Refresh list
                                showingNewChatSheet = false
                                newChatTitle = ""
                            }
                        }
                    }
                }
            }
            // Observe changes from CloudKit.
            // In a production app, you would listen for .NSPersistentStoreRemoteChangeNotification
            // and trigger a re-fetch or rely on automaticallyMergesChangesFromParent.
            .onReceive(NotificationCenter.default.publisher(for: .NSManagedObjectContextDidSave)) { _ in
                viewModel.fetchConversations()
            }
        }
    }
}

/// A view displaying the messages within a single conversation.
@available(iOS 18.0, *)
struct MessageListView: View {
    let conversation: Conversation
    let viewModel: ChatViewModel
    @State private var inputText = ""

    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                List {
                    // Accessing the relationship: conversation.messages
                    let messages = (conversation.messages?.allObjects as? [ChatMessage])?.sorted { 
                        $0.timestamp ?? Date() < $1.timestamp ?? Date() 
                    } ?? []

                    ForEach(messages) { message in
                        MessageBubble(message: message)
                    }
                }
            }

            HStack {
                TextField("Ask AI...", text: $inputText)
                    .textFieldStyle(.roundedBorder)
                
                Button("Send") {
                    sendMessage()
                }
                .disabled(inputText.isEmpty)
            }
            .padding()
        }
        .navigationTitle(conversation.title ?? "Chat")
    }

    private func sendMessage() {
        let userText = inputText
        inputText = ""
        
        // 1. Save User Message
        viewModel.addMessage(to: conversation, text: userText, isAI: false)
        
        // 2. Simulate AI Response (In real app, this calls an LLM API)
        Task {
            // Simulate network latency
            try? await Task.sleep(for: .seconds(1.5))
            
            await MainActor.run {
                viewModel.addMessage(to: conversation, text: "I am your synchronized AI memory. I remember you said: \(userText)", isAI: true)
            }
        }
    }
}

/// A simple view for rendering individual message bubbles.
@available(iOS 18.0, *)
struct MessageBubble: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.isAIResponse { Spacer() }
            
            Text(message.text ?? "")
                .padding(10)
                .background(message.isAIResponse ? Color.blue.opacity(0.2) : Color.gray.opacity(0.2))
                .cornerRadius(10)
            
            if !message.isAIResponse { Spacer() }
        }
        .listRowSeparator(.hidden)
    }
}
