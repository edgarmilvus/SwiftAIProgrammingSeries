
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part8.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
@Observable
class AIResultViewModel {
    var currentText: String = "Input your text..."
    var sentimentScore: Double?
    var classificationLabel: String?
    var isProcessing: Bool = false

    private let textProcessor = TextProcessor() // From async/await example

    @MainActor // Ensure UI updates are on the main actor
    func analyzeText(_ text: String) async {
        isProcessing = true
        sentimentScore = nil
        classificationLabel = nil
        currentText = text

        let result = await textProcessor.processTextAsync(text) // This is an async call to an actor
        // Parse the result string from TextProcessor for sentiment
        if let range = result.range(of: "Sentiment score for '.*': (.*)", options: .regularExpression) {
            let scoreString = result[range].replacingOccurrences(of: "Sentiment score for '.*': ", with: "", options: .regularExpression)
            sentimentScore = Double(scoreString)
        }
        // In a real app, you'd have separate properties for different results
        // For classification, you'd call a classification function here.
        // classificationLabel = await modelManager.classify(text)
        isProcessing = false
    }
}

// Usage in a SwiftUI View
/*
@available(iOS 18.0, *)
struct AIOutputView: View {
    @State var viewModel = AIResultViewModel()
    @State private var inputText: String = ""

    var body: some View {
        VStack {
            TextField("Enter text here", text: $inputText)
                .textFieldStyle(.roundedBorder)
                .padding()

            Button("Analyze") {
                Task {
                    await viewModel.analyzeText(inputText)
                }
            }
            .disabled(viewModel.isProcessing)

            if viewModel.isProcessing {
                ProgressView()
            } else {
                Text("Text: \(viewModel.currentText)")
                if let score = viewModel.sentimentScore {
                    Text("Sentiment: \(String(format: "%.2f", score))")
                        .foregroundColor(score > 0 ? .green : (score < 0 ? .red : .gray))
                }
                if let label = viewModel.classificationLabel {
                    Text("Category: \(label)")
                }
            }
        }
        .padding()
    }
}
*/
