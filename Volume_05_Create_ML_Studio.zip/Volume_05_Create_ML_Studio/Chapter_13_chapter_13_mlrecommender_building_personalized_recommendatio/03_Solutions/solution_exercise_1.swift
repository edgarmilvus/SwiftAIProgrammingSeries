
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import CreateML
import CoreML

// MARK: - Data Generation Helper

// Helper function to create a simulated interaction dataset
func generateProductInteractionData() -> [[String: String]] {
    var data: [[String: String]] = []
    let users = (1...20).map { "user\($0)" } // 20 users
    let products = (1...50).map { "product\($0)" } // 50 products

    // Simulate various users interacting with products
    for user in users {
        // Each user interacts with 5-15 random products
        let numInteractions = Int.random(in: 5...15)
        var interactedProducts: Set<String> = []
        while interactedProducts.count < numInteractions {
            let product = products.randomElement()!
            if !interactedProducts.contains(product) {
                data.append(["userID": user, "productID": product])
                interactedProducts.insert(product)
            }
        }
    }

    // Add some common interactions to create similarity
    let popularProducts = ["product1", "product2", "product3", "product4", "product5"]
    for user in users.shuffled().prefix(10) { // 10 users interact with popular products
        for product in popularProducts.shuffled().prefix(Int.random(in: 2...4)) {
            data.append(["userID": user, "productID": product])
        }
    }
    // Add specific co-occurrences for testing item-to-item
    data.append(["userID": "userA", "productID": "productX"])
    data.append(["userID": "userA", "productID": "productY"]) // productX and productY are similar
    data.append(["userID": "userB", "productID": "productX"])
    data.append(["userID": "userB", "productID": "productY"])
    data.append(["userID": "userC", "productID": "productX"])
    data.append(["userID": "userC", "productID": "productZ"]) // productX and productZ are somewhat similar

    return data
}

// MARK: - Model Training and Saving

func trainAndSaveItemToItemModel(data: [[String: String]], modelName: String = "ProductRecommender") throws -> URL {
    let dataTable = try MLDataTable(dictionary: [
        "userID": data.map { $0["userID"]! },
        "productID": data.map { $0["productID"]! }
    ])

    print("Training MLRecommender model...")
    let recommender = try MLRecommenderBuilder(trainingData: dataTable,
                                               userIdentifierColumn: "userID",
                                               itemIdentifierColumn: "productID")
    
    let fileManager = FileManager.default
    let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
    let modelURL = documentsDirectory.appendingPathComponent("\(modelName).mlmodel")

    try recommender.write(to: modelURL)
    print("Model trained and saved to: \(modelURL.lastPathComponent)")
    return modelURL
}

// MARK: - App Integration Logic

/// Loads a pre-trained MLRecommender model and provides item-to-item recommendations.
class ProductRecommendationEngine {
    private var recommender: MLRecommender?
    private let modelURL: URL

    init(modelURL: URL) {
        self.modelURL = modelURL
        loadModel()
    }

    private func loadModel() {
        do {
            // Compile the .mlmodel file for use
            let compiledModelURL = try MLModel.compileModel(at: modelURL)
            self.recommender = try MLRecommender(contentsOf: compiledModelURL)
            print("Product recommender model loaded successfully.")
        } catch {
            print("Error loading product recommender model: \(error)")
            self.recommender = nil
        }
    }

    /// Returns a list of product IDs similar to the given product.
    /// - Parameters:
    ///   - productID: The ID of the product for which to find similar items.
    ///   - count: The maximum number of similar products to return.
    /// - Returns: An array of product IDs. Returns an empty array if the model is not loaded or
    ///            if no recommendations are found for the given product.
    func getSimilarProducts(for productID: String, count: Int) -> [String] {
        guard let recommender = recommender else {
            print("Model not loaded. Cannot provide recommendations.")
            return []
        }

        do {
            let recommendations = try recommender.recommendations(forItems: [productID], k: count)
            // The output is an MLDataTable, extract the 'productID' column
            let recommendedProductIDs = recommendations["productID"]
                .map { $0.map { $0.stringValue ?? "" } } ?? []
            
            // Filter out the input product itself if it appears in recommendations
            return recommendedProductIDs.filter { $0 != productID }

        } catch {
            print("Error getting similar products for \(productID): \(error)")
            // Cold start for items: if MLRecommender can't find similar items
            // (e.g., productID is new or has no interactions), it will throw an error
            // or return an empty result.
            return []
        }
    }
}

// MARK: - Example Usage

func runExercise1() {
    print("--- Running Exercise 1: More Like This ---")

    // 1. Data Preparation
    let interactionData = generateProductInteractionData()
    print("Generated \(interactionData.count) interaction records.")

    do {
        // 2. Model Training and Saving
        let modelPath = try trainAndSaveItemToItemModel(data: interactionData)

        // 3. Integration into App Logic
        let recommendationEngine = ProductRecommendationEngine(modelURL: modelPath)

        let targetProduct1 = "productX"
        let similarProducts1 = recommendationEngine.getSimilarProducts(for: targetProduct1, count: 5)
        print("\nSimilar to \(targetProduct1): \(similarProducts1)") // Expect productY, productZ

        let targetProduct2 = "product1" // A popular product
        let similarProducts2 = recommendationEngine.getSimilarProducts(for: targetProduct2, count: 3)
        print("Similar to \(targetProduct2): \(similarProducts2)")

        let targetProduct3 = "product99" // A cold start product (not in training data)
        let similarProducts3 = recommendationEngine.getSimilarProducts(for: targetProduct3, count: 5)
        print("Similar to \(targetProduct3) (cold start): \(similarProducts3)") // Expect empty

    } catch {
        print("An error occurred during Exercise 1: \(error)")
    }
    print("--- Exercise 1 Finished ---\n")
}

// Call the function to run the exercise
runExercise1()
