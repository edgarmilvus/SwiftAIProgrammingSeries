
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
func runInferenceExample() async {
    let agent = LLMAgent()
    do {
        // Awaiting model loading without blocking the main thread
        await agent.loadModel(from: "/path/to/my/model.gguf")

        // Awaiting token generation, processing tokens as they arrive
        print("User: Tell me a fun fact.")
        var fullResponse = ""
        for await token in try await agent.generate(prompt: "Tell me a fun fact.", maxTokens: 10) {
            print(token, terminator: "") // Print tokens as they stream
            fullResponse += token
        }
        print("\nFull Response: \(fullResponse)")

        // Awaiting model unload
        await agent.unloadModel()
    } catch {
        print("Error during inference: \(error)")
    }
}

// Example usage (e.g., from a SwiftUI View or an App Delegate)
@available(iOS 18.0, macOS 15.0, *)
@main
struct LLMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .task { // Use .task modifier for async operations in SwiftUI
                    await runInferenceExample()
                }
        }
    }
}
