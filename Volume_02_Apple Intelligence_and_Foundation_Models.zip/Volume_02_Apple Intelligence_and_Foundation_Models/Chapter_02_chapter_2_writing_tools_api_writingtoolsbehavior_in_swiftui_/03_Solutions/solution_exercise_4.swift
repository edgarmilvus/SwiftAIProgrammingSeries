
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI

@available(iOS 18.0, *)
struct BugReportFormView: View {
    @State private var bugTitle: String = ""
    @State private var bugDescription: String = ""
    @State private var stepsToReproduce: String = ""
    @State private var expectedResult: String = ""
    @State private var actualResult: String = ""

    var body: some View {
        NavigationView {
            Form {
                Section("Bug Details") {
                    // Implement TextEditor for Bug Title here.
                    // Apply writingToolsBehavior(.automatic).
                    // Using TextEditor for title to allow multi-line if needed, mirroring the prompt's focus.
                    TextEditor(text: $bugTitle)
                        .frame(minHeight: 40, maxHeight: 80) // Allow some multi-line for title
                        .overlay(alignment: .topLeading) {
                            if bugTitle.isEmpty {
                                Text("Bug Title (e.g., 'App crashes on launch')")
                                    .foregroundStyle(.placeholder)
                                    .padding(.horizontal, 5)
                                    .padding(.vertical, 8)
                            }
                        }
                        .writingToolsBehavior(.automatic) // Standard automatic assistance

                    // Implement TextEditor for Description here.
                    // Apply writingToolsBehavior with .document scope.
                    TextEditor(text: $bugDescription)
                        .frame(minHeight: 150)
                        .overlay(alignment: .topLeading) {
                            if bugDescription.isEmpty {
                                Text("Describe the bug in detail...")
                                    .foregroundStyle(.placeholder)
                                    .padding(.horizontal, 5)
                                    .padding(.vertical, 8)
                            }
                        }
                        .writingToolsBehavior(.init(.document)) // Comprehensive, general document assistance

                    // Implement TextEditor for Steps to Reproduce here.
                    // Apply writingToolsBehavior(.automatic) and reflect on its suitability.
                    TextEditor(text: $stepsToReproduce)
                        .frame(minHeight: 100)
                        .overlay(alignment: .topLeading) {
                            if stepsToReproduce.isEmpty {
                                Text("Provide clear, numbered steps to reproduce...")
                                    .foregroundStyle(.placeholder)
                                    .padding(.horizontal, 5)
                                    .padding(.vertical, 8)
                            }
                        }
                        .writingToolsBehavior(.automatic) // Automatic, suitable for factual steps

                }

                Section("Impact & Resolution") {
                    TextEditor(text: $expectedResult)
                        .frame(minHeight: 80)
                        .overlay(alignment: .topLeading) {
                            if expectedResult.isEmpty {
                                Text("What was the expected behavior?")
                                    .foregroundStyle(.placeholder)
                                    .padding(.horizontal, 5)
                                    .padding(.vertical, 8)
                            }
                        }
                        .writingToolsBehavior(.automatic) // Default for other fields

                    TextEditor(text: $actualResult)
                        .frame(minHeight: 80)
                        .overlay(alignment: .topLeading) {
                            if actualResult.isEmpty {
                                Text("What actually happened?")
                                    .foregroundStyle(.placeholder)
                                    .padding(.horizontal, 5)
                                    .padding(.vertical, 8)
                            }
                        }
                        .writingToolsBehavior(.automatic) // Default for other fields
                }
            }
            .navigationTitle("New Bug Report")
        }
    }
}

// Preview Provider (optional, for development convenience)
@available(iOS 18.0, *)
#Preview {
    BugReportFormView()
}
