
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

/// Represents the types of errors we expect from the OpenAI API architecture.
/// Mapping HTTP status codes to domain-specific errors is critical for UX.
enum OpenAIError: Error, LocalizedError {
    case unauthorized // 401
    case rateLimitExceeded // 429
    case serverError // 500
    case decodingError
    
    var errorDescription: String? {
        switch self {
        case .unauthorized: return "Invalid API Key. Please check your settings."
        case .rateLimitExceeded: return "Too many requests. Please wait a moment."
        case .serverError: return "OpenAI is currently experiencing issues."
        case .decodingError: return "Failed to parse the response from the server."
        }
    }
}

/// A thread-safe actor responsible for managing the API communication.
/// By using an actor, we ensure that the 'apiKey' and 'requestCount' 
/// are protected from concurrent access.
@available(iOS 18.0, macOS 15.0, *)
actor OpenAIClient {
    private let apiKey: String
    private let session: URLSession
    
    // In a real-world scenario, we would track TPM/RPM here to 
    // implement local rate-limiting before even hitting the network.
    private var lastRequestTime: Date?

    init(apiKey: String, session: URLSession = .shared) {
        self.apiKey = apiKey
        self.session = session
    }

    /// Performs a chat completion request.
    /// This demonstrates the 'stateless' nature: we must pass the entire 'messages' array.
    func completeChat(messages: [[String: String]]) async throws -> String {
        let url = URL(string: "https://api.openai.com/v1/chat/completions")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "model": "gpt-4o",
            "messages": messages
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw OpenAIError.serverError
        }
        
        // Handle the architectural constraints (Rate Limits/Auth)
        switch httpResponse.statusCode {
        case 200:
            return try parseResponse(data)
        case 401:
            throw OpenAIError.unauthorized
        case 429:
            throw OpenAIError.rateLimitExceeded
        default:
            throw OpenAIError.serverError
        }
    }
    
    private func parseResponse(_ data: Data) throws -> String {
        // In a production app, use Decodable models.
        // This is a simplified representation.
        let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        let choices = json?["choices"] as? [[String: Any]]
        let message = choices?.first?["message"] as? [String: Any]
        return message?["content"] as? String ?? ""
    }
}

/// The ViewModel acts as the bridge between the Actor and the SwiftUI View.
/// It uses @Observable to allow the UI to react to the 'isProcessing' and 'response' states.
@available(iOS 18.0, macOS 15.0, *)
@Observable
final class ChatViewModel {
    var messages: [[String: String]] = []
    var responseText: String = ""
    var isProcessing: Bool = false
    var errorMessage: String?
    
    private let client: OpenAIClient
    
    init(client: OpenAIClient) {
        self.client = client
    }
    
    /// This method is called from the UI (MainActor).
    /// It manages the 'State' that the stateless API requires.
    @MainActor
    func sendMessage(_ userText: String) async {
        isProcessing = true
        errorMessage = nil
        
        // 1. Update local state (The 'Source of Truth')
        let userMessage = ["role": "user", "content": userText]
        messages.append(userMessage)
        
        do {
            // 2. Send the entire history to maintain context (Statelessness)
            let reply = try await client.completeChat(messages: messages)
            
            // 3. Update local state with the assistant's response
            let assistantMessage = ["role": "assistant", "content": reply]
            messages.append(assistantMessage)
            responseText = reply
            
        } catch let error as OpenAIError {
            self.errorMessage = error.localizedDescription
        } catch {
            self.errorMessage = "An unexpected error occurred."
        }
        
        isProcessing = false
    }
}
