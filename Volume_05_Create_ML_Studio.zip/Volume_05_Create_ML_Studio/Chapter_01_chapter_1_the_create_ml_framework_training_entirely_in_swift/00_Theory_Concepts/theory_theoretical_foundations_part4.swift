
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

// Example of Sendable types in the context of ML:

struct TrainingConfiguration: Sendable {
    let learningRate: Double
    let batchSize: Int
    let epochs: Int
    let modelType: String // e.g., "ImageClassifier"
}

// A custom class that needs to be Sendable (requires careful design)
// For simple data, structs are often preferred.
final class TrainingDatasetReference: @unchecked Sendable { // @unchecked Sendable if you guarantee thread safety manually
    private let dataURL: URL // Immutable
    private var internalCache: [String: Any]? // Mutable, but access must be synchronized

    init(dataURL: URL) {
        self.dataURL = dataURL
    }

    // Example of synchronized access if this were a mutable class
    // This is generally handled better by actors or structs.
    // In most Create ML scenarios, you'd pass data by value or use a FileWrapper.
}

// The MLTrainingData, MLModel, and TrainingMetrics structs used above
// are implicitly Sendable because they are structs containing Sendable types.
struct MLTrainingData: Sendable {}
struct MLModel: Sendable {}
struct TrainingMetrics: Sendable {
    var epoch: Int
    var loss: Double
    var accuracy: Double
}
