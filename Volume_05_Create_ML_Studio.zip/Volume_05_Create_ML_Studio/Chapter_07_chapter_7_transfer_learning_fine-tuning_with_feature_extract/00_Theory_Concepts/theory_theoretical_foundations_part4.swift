
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Vision

// Example of a custom struct holding image data that is Sendable
struct InferenceInput: Sendable {
    let imageBuffer: CVImageBuffer // CVImageBuffer is Sendable
    let uniqueID: UUID
}

// Hypothetical scenario where a custom feature provider is needed
// If MLFeatureProvider was a custom class, it would need to be Sendable or immutable.
// For Core ML's built-in MLFeatureProvider types (MLImage, MLMultiArray), they are generally safe.

@available(iOS 18.0, *)
actor ImageProcessor {
    func processAndSend(input: InferenceInput) async throws -> MLFeatureProvider {
        // Perform some preprocessing on the imageBuffer
        // ...
        return try await performInference(processedInput: input)
    }

    // Assume this is another async function that takes a Sendable input
    private func performInference(processedInput: InferenceInput) async throws -> MLFeatureProvider {
        // ... use Core ML model
        let modelURL = Bundle.main.url(forResource: "MyFineTunedModel", withExtension: "mlmodelc")!
        let model = try MLModel(contentsOf: modelURL)
        let mlImage = MLImage(cvPixelBuffer: processedInput.imageBuffer)
        return try await model.prediction(from: mlImage)
    }
}

// Package.swift snippet (illustrative for a hypothetical ML training library)
/*
// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "MyMLKit",
    platforms: [
        .iOS(.v17),
        .macOS(.v14)
    ],
    products: [
        .library(
            name: "MyMLKit",
            targets: ["MyMLKit"]),
    ],
    dependencies: [
        // No direct CreateML or CoreML dependency for a framework,
        // as they are system frameworks. But if you had a custom
        // ML library, it might depend on other Swift packages.
    ],
    targets: [
        .target(
            name: "MyMLKit",
            dependencies: []),
        .testTarget(
            name: "MyMLKitTests",
            dependencies: ["MyMLKit"]),
    ]
)
*/
