
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CoreML
import AVFoundation // Required for audio recording/playback, though not directly used in the model inference part here.

// Ensure your generated Core ML model class (e.g., 'PetMonitoringSoundClassifier')
// is added to your project and replace 'PetMonitoringSoundClassifier' below.
// The @available attribute is kept as provided in the exercise.
@available(iOS 18.0, *)
class PetSoundClassifier {

    // Your generated MLSoundClassifier model. It's a subclass of MLModel.
    private var model: MLModel?

    /// Initializes the classifier with the name of the Core ML model.
    /// - Parameter modelName: The name of the .mlmodelc file (without extension) in the app bundle.
    init?(modelName: String) {
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            print("Error: Model \(modelName).mlmodelc not found in bundle.")
            return nil
        }
        do {
            self.model = try MLModel(contentsOf: modelURL)
        } catch {
            print("Error loading Core ML model: \(error)")
            return nil
        }
    }

    /// Classifies an audio file at the given URL asynchronously.
    /// - Parameters:
    ///   - audioURL: The URL of the audio file to classify.
    ///   - completion: A closure to be called with the classification result or an error.
    func classifyAudio(at audioURL: URL, completion: @escaping (Result<String, Error>) -> Void) {
        // Cast the generic MLModel to your specific generated sound classifier class.
        // This allows access to its specific prediction method.
        guard let soundClassifier = self.model as? PetMonitoringSoundClassifier else {
            completion(.failure(SoundClassificationError.modelTypeMismatch))
            return
        }

        // Perform the prediction on a background queue as it can be a lengthy, synchronous operation.
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                // The generated MLSoundClassifier model typically has a prediction method
                // that takes an audio file URL directly.
                let prediction = try soundClassifier.prediction(audioFile: audioURL)
                
                let className = prediction.label // The predicted class label (e.g., "dog_bark")
                // Get the confidence for the predicted label.
                let confidence = prediction.labelProbabilities[className] ?? 0.0

                completion(.success("\(className) (Confidence: \(String(format: "%.2f", confidence * 100))%)"))
            } catch {
                completion(.failure(error))
            }
        }
    }

    // Custom error types for better error handling.
    enum SoundClassificationError: Error, LocalizedError {
        case modelTypeMismatch
        // Add other errors as needed, e.g., invalidAudioFormat, audioProcessingFailed

        var errorDescription: String? {
            switch self {
            case .modelTypeMismatch: return "The loaded Core ML model is not of the expected Sound Classifier type."
            }
        }
    }
}

// Example of how you might use AVAudioRecorder to get an audio URL:
// This part is illustrative and not part of the required solution for model integration,
// but demonstrates how to obtain the audioURL.
/*
import AVFoundation

class AudioRecorderManager: NSObject, AVAudioRecorderDelegate {
    var audioRecorder: AVAudioRecorder?
    var audioURL: URL?
    var recordingCompletion: ((Result<URL, Error>) -> Void)?

    func startRecording() throws {
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record, mode: .default, options: [])
        try audioSession.setActive(true)

        let settings: [String: Any] = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 44100,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]

        let documentPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        self.audioURL = documentPath.appendingPathComponent("recording.m4a")

        audioRecorder = try AVAudioRecorder(url: audioURL!, settings: settings)
        audioRecorder?.delegate = self
        audioRecorder?.record()
    }

    func stopRecording(completion: @escaping (Result<URL, Error>) -> Void) {
        self.recordingCompletion = completion
        audioRecorder?.stop()
        try? AVAudioSession.sharedInstance().setActive(false)
    }

    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if flag, let url = audioURL {
            recordingCompletion?(.success(url))
        } else {
            recordingCompletion?(.failure(NSError(domain: "AudioRecording", code: -1, userInfo: [NSLocalizedDescriptionKey: "Audio recording failed."])))
        }
        recordingCompletion = nil
    }

    func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
        recordingCompletion?(.failure(error ?? NSError(domain: "AudioRecording", code: -2, userInfo: [NSLocalizedDescriptionKey: "Audio encoding error."])))
        recordingCompletion = nil
    }
}
*/
