
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Speech
import AVFoundation // For AVAudioEngine

// Using @available for Swift 6 context, assuming iOS 18.0 / macOS 15.0
@available(iOS 18.0, macOS 15.0, *)
class VoiceNoteTaker: NSObject, SFSpeechRecognizerDelegate {

    private let speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine: AVAudioEngine
    
    // Simulate a UITextView/NSTextView by storing and printing
    private var currentNoteText: String = "" {
        didSet {
            print("Current Note: \"\(currentNoteText)\"")
        }
    }

    override init() {
        self.audioEngine = AVAudioEngine()
        self.speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        
        super.init()
        
        self.speechRecognizer?.delegate = self
        
        // Request speech recognition authorization
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation {
                switch authStatus {
                case .authorized:
                    print("Speech recognition authorized.")
                case .denied, .restricted, .notDetermined:
                    print("Speech recognition authorization denied, restricted, or not determined.")
                    // Inform user or disable UI
                @unknown default:
                    print("Unknown speech recognition authorization status.")
                }
            }
        }
    }

    // Call this method to start listening for notes
    func startRecording() throws {
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            throw VoiceNoteError.recognizerUnavailable
        }
        
        // Cancel the previous task if it's running
        recognitionTask?.cancel()
        self.recognitionTask = nil
        
        // Configure the audio session for speech
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            throw VoiceNoteError.audioSessionSetupFailed(error)
        }
        
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            throw VoiceNoteError.recognitionRequestFailed
        }
        
        recognitionRequest.shouldReportPartialResults = true // Enable real-time transcription
        
        // Start the recognition task
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
            var isFinal = false
            
            if let result = result {
                self.currentNoteText = result.bestTranscription.formattedString
                isFinal = result.isFinal
            }
            
            if error != nil || isFinal {
                // Stop audio engine and clean up
                self.audioEngine.stop()
                self.audioEngine.inputNode.removeTap(onBus: 0)
                self.recognitionRequest = nil
                self.recognitionTask = nil
                
                if let finalResult = result {
                    self.processFinalNote(finalResult.bestTranscription.formattedString)
                } else if let error = error {
                    print("Speech recognition error: \(error.localizedDescription)")
                    self.currentNoteText = "" // Clear on error
                }
            }
        }
        
        // Configure audio input
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        try audioEngine.start()
        print("\n--- Listening for note... ---")
        currentNoteText = "" // Clear text at start of new recording
    }
    
    // Call this method to stop recording explicitly (e.g., from a button tap)
    func stopRecording() {
        audioEngine.stop()
        recognitionRequest?.endAudio()
        recognitionTask?.cancel() // Cancel ongoing task if any
        print("--- Recording stopped manually ---")
    }

    private func processFinalNote(_ finalText: String) {
        let lowercasedText = finalText.lowercased()
        
        if lowercasedText.contains("save") {
            print("\n>>> Action: Note saved! <<<")
            currentNoteText = "" // Simulate clearing the text view
        } else if lowercasedText.contains("cancel") || lowercasedText.contains("discard") {
            print("\n>>> Action: Note discarded! <<<")
            currentNoteText = "" // Simulate clearing the text view
        } else {
            print("\n>>> Action: Note finalized. No explicit save/discard command. Content: \"\(finalText)\" <<<")
            // Optionally, you might auto-save or prompt the user here.
        }
        print("----------------------------------\n")
    }

    // MARK: - SFSpeechRecognizerDelegate
    
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            print("Speech recognition available.")
        } else {
            print("Speech recognition unavailable. Please check internet connection or device settings.")
            stopRecording() // Stop if it becomes unavailable during recording
        }
    }
    
    // Custom error type for better error handling
    enum VoiceNoteError: Error, LocalizedError {
        case recognizerUnavailable
        case audioSessionSetupFailed(Error)
        case recognitionRequestFailed
        
        var errorDescription: String? {
            switch self {
            case .recognizerUnavailable:
                return "Speech recognizer is not available for the current locale or not authorized."
            case .audioSessionSetupFailed(let error):
                return "Failed to set up audio session: \(error.localizedDescription)"
            case .recognitionRequestFailed:
                return "Unable to create SFSpeechAudioBufferRecognitionRequest."
            }
        }
    }
}

/*
// Example Usage (in an AppDelegate, SceneDelegate, or main function):
@available(iOS 18.0, macOS 15.0, *)
let noteTaker = VoiceNoteTaker()

// To start recording:
DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
    do {
        try noteTaker.startRecording()
        print("Speak now to dictate your note and say 'save' or 'discard'.")
    } catch {
        print("Failed to start recording: \(error.localizedDescription)")
    }
}

// To stop recording (e.g., after 10 seconds for demonstration):
DispatchQueue.main.asyncAfter(deadline: .now() + 12) {
    noteTaker.stopRecording()
    print("Demo recording session ended.")
}

// Keep the program running for a bit to allow async operations
RunLoop.current.run(until: Date(timeIntervalSinceNow: 15))
*/
