
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import UIKit // For UIImage, UIDevice, UIApplication
import SwiftUI

// DreamWeaverError.swift
enum DreamWeaverError: LocalizedError, Identifiable, Codable {
    case invalidPrompt(reason: String)
    case quotaExceeded(resetTime: Date?)
    case modelUnavailable
    case insufficientFunds
    case unsupportedFeature(featureName: String)
    case networkError(String) // Simplified for Codable, real Error needs wrapping
    case unknownBackendError(code: Int, message: String?)
    case clientSideValidationFailed(field: String, details: String)
    case genericClientError(message: String) // Catch-all for client-side issues not explicitly defined

    // For Identifiable conformance
    var id: String {
        switch self {
        case .invalidPrompt: return "invalidPrompt"
        case .quotaExceeded: return "quotaExceeded"
        case .modelUnavailable: return "modelUnavailable"
        case .insufficientFunds: return "insufficientFunds"
        case .unsupportedFeature: return "unsupportedFeature"
        case .networkError: return "networkError"
        case .unknownBackendError: return "unknownBackendError"
        case .clientSideValidationFailed: return "clientSideValidationFailed"
        case .genericClientError: return "genericClientError"
        }
    }

    var errorDescription: String? {
        switch self {
        case .invalidPrompt(let reason):
            return "Your prompt could not be processed. \(reason) Please revise your request."
        case .quotaExceeded(let resetTime):
            if let time = resetTime {
                let formatter = DateFormatter()
                formatter.dateStyle = .short
                formatter.timeStyle = .short
                return "You've exceeded your daily generation quota. Please try again after \(formatter.string(from: time))."
            } else {
                return "You've exceeded your generation quota. Please try again later or upgrade your plan."
            }
        case .modelUnavailable:
            return "The AI art model is currently unavailable or overloaded. Please try again in a few minutes."
        case .insufficientFunds:
            return "Your account balance is too low to generate art. Please add more funds."
        case .unsupportedFeature(let feature):
            return "The feature '\(feature)' is not available with your current plan or in your region."
        case .networkError(let message):
            return "A network error occurred: \(message). Please check your internet connection."
        case .unknownBackendError(let code, let message):
            return "An unexpected server error occurred (Code: \(code)). \(message ?? "Please contact support if this persists.")"
        case .clientSideValidationFailed(let field, let details):
            return "Validation failed for \(field): \(details)"
        case .genericClientError(let message):
            return "An application error occurred: \(message)"
        }
    }
    
    // Coding Keys for Codable conformance
    enum CodingKeys: String, CodingKey {
        case type, reason, resetTime, featureName, statusCode, message, field, details
    }

    // Custom initializer for Codable
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let type = try container.decode(String.self, forKey: .type)
        switch type {
        case "invalidPrompt":
            let reason = try container.decode(String.self, forKey: .reason)
            self = .invalidPrompt(reason: reason)
        case "quotaExceeded":
            let resetTime = try container.decodeIfPresent(Date.self, forKey: .resetTime)
            self = .quotaExceeded(resetTime: resetTime)
        case "modelUnavailable":
            self = .modelUnavailable
        case "insufficientFunds":
            self = .insufficientFunds
        case "unsupportedFeature":
            let featureName = try container.decode(String.self, forKey: .featureName)
            self = .unsupportedFeature(featureName: featureName)
        case "networkError":
            let message = try container.decode(String.self, forKey: .message)
            self = .networkError(message)
        case "unknownBackendError":
            let code = try container.decode(Int.self, forKey: .statusCode)
            let message = try container.decodeIfPresent(String.self, forKey: .message)
            self = .unknownBackendError(code: code, message: message)
        case "clientSideValidationFailed":
            let field = try container.decode(String.self, forKey: .field)
            let details = try container.decode(String.self, forKey: .details)
            self = .clientSideValidationFailed(field: field, details: details)
        case "genericClientError":
            let message = try container.decode(String.self, forKey: .message)
            self = .genericClientError(message: message)
        default:
            throw DecodingError.dataCorruptedError(forKey: .type, in: container, debugDescription: "Unknown error type: \(type)")
        }
    }

    // Custom encoder for Codable
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        switch self {
        case .invalidPrompt(let reason):
            try container.encode("invalidPrompt", forKey: .type)
            try container.encode(reason, forKey: .reason)
        case .quotaExceeded(let resetTime):
            try container.encode("quotaExceeded", forKey: .type)
            try container.encodeIfPresent(resetTime, forKey: .resetTime)
        case .modelUnavailable:
            try container.encode("modelUnavailable", forKey: .type)
        case .insufficientFunds:
            try container.encode("insufficientFunds", forKey: .type)
        case .unsupportedFeature(let featureName):
            try container.encode("unsupportedFeature", forKey: .type)
            try container.encode(featureName, forKey: .featureName)
        case .networkError(let message):
            try container.encode("networkError", forKey: .type)
            try container.encode(message, forKey: .message)
        case .unknownBackendError(let code, let message):
            try container.encode("unknownBackendError", forKey: .type)
            try container.encode(code, forKey: .statusCode)
            try container.encodeIfPresent(message, forKey: .message)
        case .clientSideValidationFailed(let field, let details):
            try container.encode("clientSideValidationFailed", forKey: .type)
            try container.encode(field, forKey: .field)
            try container.encode(details, forKey: .details)
        case .genericClientError(let message):
            try container.encode("genericClientError", forKey: .type)
            try container.encode(message, forKey: .message)
        }
    }
}

// DiagnosticReport.swift
struct DiagnosticReport: Codable {
    let errorType: String
    let errorMessage: String
    let timestamp: Date
    let appVersion: String
    let osVersion: String
    let deviceModel: String
    let context: String?

    init(error: DreamWeaverError, context: String? = nil) {
        self.errorType = error.id
        self.errorMessage = error.localizedDescription
        self.timestamp = Date()
        self.appVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "Unknown"
        self.osVersion = UIDevice.current.systemVersion // For iOS
        self.deviceModel = UIDevice.current.model // For iOS
        self.context = context
    }

    func toJsonString() -> String? {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        encoder.dateEncodingStrategy = .iso8601
        do {
            let data = try encoder.encode(self)
            return String(data: data, encoding: .utf8)
        } catch {
            print("Failed to encode DiagnosticReport: \(error)")
            return nil
        }
    }
}

// ArtSettings.swift (Dummy struct for prompt)
struct ArtSettings {
    var width: Int
    var height: Int
    var style: String
}

// DreamWeaverService.swift
@available(iOS 18.0, *)
class DreamWeaverService {
    func generateArt(prompt: String, settings: ArtSettings) async throws -> UIImage {
        try await Task.sleep(for: .seconds(2)) // Simulate network delay

        // Simulate client-side validation
        if settings.width > 2048 || settings.height > 2048 {
            throw DreamWeaverError.clientSideValidationFailed(field: "resolution", details: "Maximum resolution for your current plan is 2048x2048. Please reduce image size.")
        }
        if prompt.lowercased().contains("forbidden") {
            throw DreamWeaverError.invalidPrompt(reason: "Your prompt contains forbidden keywords.")
        }
        if prompt.count < 10 {
            throw DreamWeaverError.invalidPrompt(reason: "Prompt is too short. Please provide more details.")
        }

        let randomFailure = Int.random(in: 0...100)
        if randomFailure < 15 { // 15% chance of quota exceeded
            let resetTime = Date().addingTimeInterval(Double.random(in: 3600...86400)) // 1 hour to 24 hours
            throw DreamWeaverError.quotaExceeded(resetTime: resetTime)
        } else if randomFailure < 25 { // 10% chance of model unavailable
            throw DreamWeaverError.modelUnavailable
        } else if randomFailure < 30 { // 5% chance of insufficient funds
            throw DreamWeaverError.insufficientFunds
        } else if randomFailure < 35 { // 5% chance of network error
            throw DreamWeaverError.networkError("The server could not be reached. Ensure you have an internet connection.")
        } else if randomFailure < 40 { // 5% chance of unsupported feature
            throw DreamWeaverError.unsupportedFeature(featureName: "High-Resolution Upscaling")
        } else if randomFailure < 45 { // 5% chance of unknown backend error
            throw DreamWeaverError.unknownBackendError(code: 500, message: "Internal server processing error.")
        }

        // Simulate successful image generation
        // Using a system icon as a placeholder for the generated art
        return UIImage(systemName: "photo.fill") ?? UIImage()
    }
}

// ErrorDisplayView.swift
@available(iOS 18.0, *)
struct ErrorDisplayView: View {
    let error: DreamWeaverError
    @Environment(\.dismiss) var dismiss // To dismiss the sheet

    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.largeTitle)
                .foregroundColor(.red)

            Text("Oops! Something went wrong.")
                .font(.title2)
                .fontWeight(.bold)

            Text(error.localizedDescription)
                .font(.body)
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            VStack(spacing: 10) {
                actionButtons(for: error)
                
                Button("Report Issue") {
                    let report = DiagnosticReport(error: error, context: "Art Generation")
                    if let json = report.toJsonString() {
                        print("--- Diagnostic Report ---")
                        print(json)
                        print("-------------------------")
                        // In a real app, send this JSON to a telemetry service
                    }
                    dismiss() // Dismiss the error view after reporting
                }
                .buttonStyle(.bordered)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 10)
        .padding(.horizontal, 20)
    }

    @ViewBuilder
    private func actionButtons(for error: DreamWeaverError) -> some View {
        switch error {
        case .invalidPrompt:
            Button("Review Prompt Guidelines") {
                if let url = URL(string: "https://www.dreamweaver.com/guidelines") {
                    UIApplication.shared.open(url)
                }
                dismiss()
            }
            .buttonStyle(.bordered)
        case .quotaExceeded:
            Button("Upgrade Plan") {
                if let url = URL(string: "https://www.dreamweaver.com/pricing") {
                    UIApplication.shared.open(url)
                }
                dismiss()
            }
            .buttonStyle(.borderedProminent)
        case .insufficientFunds:
            Button("Add Funds to Account") {
                if let url = URL(string: "https://www.dreamweaver.com/account/billing") {
                    UIApplication.shared.open(url)
                }
                dismiss()
            }
            .buttonStyle(.borderedProminent)
        case .modelUnavailable, .networkError:
            Button("Try Again") {
                // This dismisses the sheet, allowing the parent view to potentially retry
                dismiss()
            }
            .buttonStyle(.borderedProminent)
        case .unsupportedFeature(let featureName):
            Button("Learn About Plans") {
                if let url = URL(string: "https://www.dreamweaver.com/features/\(featureName.lowercased().replacingOccurrences(of: " ", with: "-"))") {
                    UIApplication.shared.open(url)
                }
                dismiss()
            }
            .buttonStyle(.bordered)
        case .clientSideValidationFailed:
            Button("Adjust Settings") {
                // This dismisses the sheet, user can then adjust prompt/settings
                dismiss()
            }
            .buttonStyle(.bordered)
        case .unknownBackendError, .genericClientError:
            // No specific action, just reporting
            EmptyView()
        }
    }
}

// DreamWeaverAppView.swift
@available(iOS 18.0, *)
struct DreamWeaverAppView: View {
    @State private var prompt: String = "A majestic dragon flying over a futuristic city"
    @State private var artSettings = ArtSettings(width: 1024, height: 1024, style: "Fantasy")
    @State private var generatedImage: UIImage?
    @State private var isLoading: Bool = false
    @State private var showingError: Bool = false
    @State private var currentError: DreamWeaverError?

    private let service = DreamWeaverService()

    var body: some View {
        VStack(spacing: 20) {
            TextEditor(text: $prompt)
                .frame(height: 100)
                .border(Color.gray.opacity(0.5), width: 1)
                .padding(.horizontal)
                .overlay(
                    Group {
                        if prompt.isEmpty {
                            Text("Enter your creative prompt...")
                                .foregroundColor(.gray)
                                .padding(.leading, 5)
                                .allowsHitTesting(false)
                        }
                    }, alignment: .topLeading
                )

            HStack {
                Text("Width: \(artSettings.width)px")
                Slider(value: Binding(get: { Double(artSettings.width) }, set: { artSettings.width = Int($0) }), in: 512...2048, step: 256)
            }
            HStack {
                Text("Height: \(artSettings.height)px")
                Slider(value: Binding(get: { Double(artSettings.height) }, set: { artSettings.height = Int($0) }), in: 512...2048, step: 256)
            }
            .padding(.horizontal)

            Button("Generate Art") {
                generateArt()
            }
            .buttonStyle(.borderedProminent)
            .disabled(isLoading || prompt.isEmpty)

            if isLoading {
                ProgressView("Generating masterpiece...")
            } else if let image = generatedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 300)
                    .cornerRadius(10)
            } else {
                Text("Your generated art will appear here.")
                    .foregroundColor(.gray)
                    .padding()
            }
        }
        .padding()
        .navigationTitle("DreamWeaver AI Art")
        .sheet(isPresented: $showingError) {
            if let error = currentError {
                ErrorDisplayView(error: error)
            }
        }
    }

    @MainActor
    private func generateArt() {
        isLoading = true
        generatedImage = nil
        currentError = nil
        showingError = false

        Task {
            do {
                let image = try await service.generateArt(prompt: prompt, settings: artSettings)
                generatedImage = image
            } catch let dwError as DreamWeaverError {
                currentError = dwError
                showingError = true
            } catch {
                // Catch any other unexpected errors and wrap them
                currentError = .genericClientError(message: error.localizedDescription)
                showingError = true
            }
            isLoading = false
        }
    }
}

// App Entry Point (for preview/testing)
@available(iOS 18.0, *)
struct DreamWeaverAppView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            DreamWeaverAppView()
        }
    }
}
