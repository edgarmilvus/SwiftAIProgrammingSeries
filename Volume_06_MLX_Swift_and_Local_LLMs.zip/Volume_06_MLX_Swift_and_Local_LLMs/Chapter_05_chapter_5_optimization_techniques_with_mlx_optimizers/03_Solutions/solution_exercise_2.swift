
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

// Package.swift snippet for MLX Swift dependency
// dependencies: [
//     .package(url: "https://github.com/ml-explore/mlx-swift.git", from: "0.0.1")
// ]

import MLX
import MLXNN // For MLXNN.Module, MLXNN.Linear

@available(iOS 18.0, macOS 15.0, *)
func exercise2_spamClassification() {
    let featureDim = 8 // Number of features per message (e.g., length, suspicious words count)

    // 1. Define a Logistic Regression Model
    class SpamClassifier: MLXNN.Module {
        let linear: MLXNN.Linear // Transforms input features to a single logit

        init(inputFeatures: Int) {
            self.linear = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: 1)
            super.init()
        }

        // Forward pass: input -> linear transformation -> sigmoid activation
        func callAsFunction(_ input: MLXArray) -> MLXArray {
            // Sigmoid squashes the output to a probability between 0 and 1
            return sigmoid(linear(input))
        }
    }

    // 2. Generate Synthetic Data
    func generateSyntheticSpamData(
        numSamples: Int, featureDim: Int, spamRatio: Float = 0.3
    ) -> (MLXArray, MLXArray) {
        var allFeatures: [MLXArray] = []
        var allLabels: [MLXArray] = []

        for _ in 0..<numSamples {
            let isSpam = Float.random(in: 0...1) < spamRatio
            var features: [Float] = []
            for _ in 0..<featureDim {
                // Generate features. Spam messages tend to have higher feature values.
                let base = isSpam ? Float.random(in: 0.5...1.0) : Float.random(in: 0.0...0.5)
                let noise = Float.random(in: -0.1...0.1)
                features.append(base + noise)
            }
            allFeatures.append(MLXArray(features, dtype: .float32))
            allLabels.append(MLXArray(isSpam ? 1.0 : 0.0, dtype: .float32))
        }

        // Stack individual feature/label arrays into single MLXArrays
        let features = MLXArray.stack(allFeatures)
        let labels = MLXArray.stack(allLabels).reshaped([numSamples, 1]) // Ensure labels are column vector
        return (features, labels)
    }

    let numSamples = 200
    let (inputs, targets) = generateSyntheticSpamData(numSamples: numSamples, featureDim: featureDim)

    // 3. Define the Loss Function (Binary Cross-Entropy)
    func binaryCrossEntropyLoss(predictions: MLXArray, targets: MLXArray) -> MLXArray {
        // Clamp predictions to a small epsilon to prevent log(0) which results in NaN/Infinity
        let epsilon: Float = 1e-7
        let clampedPredictions = maximum(predictions, epsilon)
        let oneMinusClampedPredictions = maximum(1.0 - predictions, epsilon)

        // BCE formula: -(target * log(prediction) + (1 - target) * log(1 - prediction))
        let loss = -(targets * log(clampedPredictions) + (1.0 - targets) * log(oneMinusClampedPredictions))
        return loss.mean() // Return the mean loss across all samples
    }

    // 4. Implement the Training Loop
    let model = SpamClassifier(inputFeatures: featureDim)
    let learningRate: Float = 0.005
    let optimizer = MLXOptimizers.Adam(learningRate: learningRate) // Using Adam optimizer
    let numEpochs = 500

    print("Initial Model Weights (first 5 of linear layer): \(model.linear.weight.flattened().take(5))")

    for epoch in 0..<numEpochs {
        // Compute loss and gradients using valueAndGradient
        let (loss, gradients) = valueAndGradient(model: model) { model in
            let predictions = model(inputs) // Forward pass to get probabilities
            return binaryCrossEntropyLoss(predictions: predictions, targets: targets)
        }

        // Update model parameters using the Adam optimizer
        optimizer.update(model: model, gradients: gradients)

        if epoch % 50 == 0 {
            print("Epoch \(epoch), Loss: \(loss.item(Float.self)!)")
        }
    }

    print("\nFinal Model Weights (first 5 of linear layer): \(model.linear.weight.flattened().take(5))")

    // 5. Evaluate
    let testInputs = MLXArray.random([10, featureDim], stream: .current, dtype: .float32) // New synthetic inputs
    let testPredictions = model(testInputs) // Get probability predictions
    let binaryPredictions = (testPredictions > 0.5).asType(.float32) // Convert probabilities to binary (0 or 1) using a 0.5 threshold

    print("\nTest Inputs (first 2 samples): \n\(testInputs.take(2, axis: 0))")
    print("Test Probabilities (first 2 samples): \n\(testPredictions.take(2, axis: 0))")
    print("Binary Predictions (first 2 samples): \n\(binaryPredictions.take(2, axis: 0))")
}
