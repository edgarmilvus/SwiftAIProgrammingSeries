/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// hooks/useUniversalChat.ts
import { useState, useCallback } from 'react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export function useUniversalChat(apiUrl: string) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (text: string) => {
    setInput(text);
  };

  const handleSubmit = useCallback(async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', content: input };
    const newMessages = [...messages, userMessage];
    
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
      // Note: In a real React Native app, you might need a fetch polyfill 
      // or use axios for better stream handling if standard fetch lacks support.
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: newMessages }),
      });

      if (!response.ok) throw new Error('Network response was not ok');

      // For streaming support in React Native, we read the body as text
      // (Simulating stream accumulation for this exercise)
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          accumulatedText += decoder.decode(value, { stream: true });
          
          // Update state incrementally to simulate streaming
          setMessages([
            ...newMessages,
            { role: 'assistant', content: accumulatedText }
          ]);
        }
      } else {
        // Fallback for non-streaming
        const text = await response.text();
        setMessages([...newMessages, { role: 'assistant', content: text }]);
      }
    } catch (error) {
      console.error('Error:', error);
      setMessages([
        ...newMessages,
        { role: 'assistant', content: 'Sorry, I encountered an error.' }
      ]);
    } finally {
      setIsLoading(false);
    }
  }, [input, messages, isLoading, apiUrl]);

  return {
    messages,
    input,
    handleInputChange,
    handleSubmit,
    isLoading,
  };
}

// screens/ChatScreen.tsx
import React from 'react';
import { 
  View, TextInput, FlatList, Text, KeyboardAvoidingView, 
  Platform, TouchableOpacity, ActivityIndicator, SafeAreaView 
} from 'react-native';
import { useUniversalChat } from '../hooks/useUniversalChat';

export default function ChatScreen() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = 
    useUniversalChat('/api/chat'); // Point to your backend API

  const renderMessage = ({ item }: { item: { role: string; content: string } }) => (
    <View className={`p-3 my-1 rounded-lg mx-2 max-w-[80%] ${item.role === 'user' ? 'bg-blue-100 self-end' : 'bg-gray-100 self-start'}`}>
      <Text className="text-sm">{item.content}</Text>
    </View>
  );

  return (
    <SafeAreaView className="flex-1 bg-white">
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
        keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 0}
      >
        <FlatList
          data={messages}
          renderItem={renderMessage}
          keyExtractor={(item, index) => index.toString()}
          contentContainerStyle={{ paddingBottom: 20 }}
        />
        
        <View className="flex-row p-3 border-t border-gray-200 bg-white items-center">
          <TextInput
            value={input}
            onChangeText={handleInputChange}
            placeholder="Type a message..."
            className="flex-1 bg-gray-100 rounded-full px-4 py-2 text-base"
            onSubmitEditing={handleSubmit}
            returnKeyType="send"
          />
          <TouchableOpacity 
            onPress={handleSubmit} 
            disabled={isLoading}
            className="ml-2 bg-blue-500 rounded-full p-3 disabled:opacity-50"
          >
            {isLoading ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Text className="text-white font-bold">Send</Text>
            )}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
