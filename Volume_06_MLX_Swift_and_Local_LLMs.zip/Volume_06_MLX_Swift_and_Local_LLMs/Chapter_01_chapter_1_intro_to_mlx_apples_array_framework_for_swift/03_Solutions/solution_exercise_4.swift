
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

@available(iOS 18.0, macOS 14.0, *)
import MLX

// 1. Implement sigmoid function
/// Computes the sigmoid activation function: 1 / (1 + exp(-x)).
/// - Parameter x: An MLXArray input.
/// - Returns: An MLXArray with sigmoid applied element-wise.
func sigmoid(_ x: MLXArray) -> MLXArray {
    // Ensure input is float for consistent type operations
    let floatX = x.astype(Float.self)
    return 1.0 / (1.0 + exp(-floatX))
}

// 2. Implement swish function
/// Computes the Swish (SiLU) activation function: x * sigmoid(x).
/// - Parameter x: An MLXArray input.
/// - Returns: An MLXArray with Swish applied element-wise.
func swish(_ x: MLXArray) -> MLXArray {
    // Ensure input is float for consistent type operations
    let floatX = x.astype(Float.self)
    return floatX * sigmoid(floatX)
}

// Example usage:
let input = MLXArray([-2.0, -1.0, 0.0, 1.0, 2.0])

print("Input:", input.eval())

// 3. Compute value and gradient
// valueAndGradient can be used with any function that takes MLXArray(s) and returns MLXArray.
let (output, gradient) = valueAndGradient(swish)(input)

print("\nSwish Output:", output.eval())
print("Swish Gradient:", gradient.eval())

// For verification, let's manually calculate the gradient for one point, e.g., x=0
// f(x) = x * sigmoid(x)
// f'(x) = sigmoid(x) + x * sigmoid(x) * (1 - sigmoid(x))
// At x = 0:
// sigmoid(0) = 0.5
// f'(0) = 0.5 + 0 * 0.5 * (1 - 0.5) = 0.5
// This matches the computed gradient for input[2] (0.0) which is 0.5.
