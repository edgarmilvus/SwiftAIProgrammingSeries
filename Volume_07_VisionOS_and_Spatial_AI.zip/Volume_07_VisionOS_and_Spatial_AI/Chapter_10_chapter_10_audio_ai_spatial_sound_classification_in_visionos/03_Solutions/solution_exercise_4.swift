
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import RealityKit
import Combine

enum EnvironmentState {
    case calm
    case distracted
    case alert
}

@Observable
@MainActor
class FocusManager {
    var currentState: EnvironmentState = .calm
    private var distractionScore: Float = 0.0
    private var debounceTask: Task<Void, Never>?
    
    // Thresholds
    private let distractionThreshold: Float = 0.6
    private let alertThreshold: Float = 0.9
    
    /// Called by the Audio Service when a sound is detected
    func processSound(label: String, confidence: Float) {
        // 1. Calculate Distraction Score (Simplified logic)
        let isDistraction = ["drilling", "siren", "shout"].contains(label)
        let score = isDistraction ? confidence : 0.0
        
        // 2. Implement Debouncing
        // We only change state if the sound is sustained
        debounceTask?.cancel()
        
        debounceTask = Task {
            // Wait for 1.5 seconds of "sustained" noise
            try? await Task.sleep(for: .seconds(1.5))
            
            if Task.isCancelled { return }
            
            updateState(with: score)
        }
    }
    
    private func updateState(with score: Float) {
        if score > alertThreshold {
            currentState = .alert
        } else if score > distractionThreshold {
            currentState = .distracted
        } else {
            currentState = .calm
        }
    }
}

struct WorkspaceView: View {
    @State private var focusManager = FocusManager()
    
    var body: some View {
        RealityView { content in
            // Setup virtual windows/planes
            let window = ModelEntity(mesh: .generatePlane(width: 0.5, height: 0.3), 
                                   materials: [SimpleMaterial(color: .white.withAlphaComponent(1.0), isMetallic: false)])
            window.name = "VirtualWindow"
            content.add(window)
        } update: { content in
            // 3. Visual Layer: Smoothly interpolate based on state
            if let window = content.entities.first(where: { $0.name == "VirtualWindow" }) as? ModelEntity {
                let targetOpacity: Float = {
                    switch focusManager.currentState {
                    case .calm: return 1.0
                    case .distracted: return 0.6
                    case .alert: return 0.3
                    }
                }()
                
                // Smoothly transition opacity
                // Note: In RealityKit, we modify the material's opacity
                var material = SimpleMaterial()
                material.color = .init(tint: .white.withAlphaComponent(CGFloat(targetOpacity)))
                window.model?.materials = [material]
            }
        }
        .task {
            // Simulate noise for testing
            try? await Task.sleep(for: .seconds(5))
            focusManager.processSound(label: "drilling", confidence: 0.95)
        }
    }
}
