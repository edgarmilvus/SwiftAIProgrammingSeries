/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part7.tsx
// Description: Advanced Application Script
// ==========================================

// apps/web/app/dashboard/page.tsx (Client Component)

'use client'; // Marks this as a Client Component for Next.js App Router

import React from 'react';
import { useAnalytics } from '@shared/hooks/useAnalytics';
import { AnalyticsDisplay } from '@shared/components/AnalyticsDisplay';

// Mock Configuration
const ANALYTICS_CONFIG = {
  apiEndpoint: 'https://api.saas-app.com/v1/analytics/live',
  apiKey: process.env.NEXT_PUBLIC_API_KEY || 'demo-key-web',
  refreshInterval: 5000, // Refresh every 5 seconds
};

/**
 * @description The Dashboard page for the Web App.
 * It imports the shared hook and the platform-specific display component.
 */
export default function DashboardPage() {
  const { data, isLoading, error } = useAnalytics(ANALYTICS_CONFIG);

  if (isLoading) return <div style={{ padding: 20 }}>Loading Analytics...</div>;
  if (error) return <div style={{ padding: 20, color: 'red' }}>Error: {error}</div>;

  return (
    <div>
      <h1>SaaS Dashboard</h1>
      {/* 
        This component automatically resolves to AnalyticsDisplay.web.tsx 
        due to Next.js/Expo bundler resolution logic.
      */}
      <AnalyticsDisplay data={data} />
    </div>
  );
}
