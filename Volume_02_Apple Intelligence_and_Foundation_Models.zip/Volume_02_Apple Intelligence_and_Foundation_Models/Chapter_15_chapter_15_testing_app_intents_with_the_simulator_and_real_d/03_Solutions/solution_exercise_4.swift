
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import AppIntents
import SwiftUI // For ObservableObject and @Published
import Foundation // For UUID, Date, etc.

// MARK: - Mock Photo Models and Library

struct Photo: Identifiable, Codable, Hashable {
    let id: UUID
    var filename: String
    var dateTaken: Date
    var albums: [String] // Albums this photo belongs to
    var tags: [String] // Simulated AI-derived tags
}

class PhotoLibrary: ObservableObject {
    static let shared = PhotoLibrary() // Singleton

    @Published var photos: [Photo] {
        didSet { savePhotos() }
    }
    @Published var albums: Set<String> {
        didSet { saveAlbums() }
    }

    private init() {
        self.photos = loadPhotos()
        self.albums = loadAlbums()

        if photos.isEmpty {
            // Populate with some initial data
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"

            let photo1Date = dateFormatter.date(from: "2023-01-15")!
            photos.append(Photo(id: UUID(), filename: "vacation_beach.jpg", dateTaken: photo1Date, albums: ["Vacation 2023"], tags: ["beach", "ocean", "sunset", "water"]))

            let photo2Date = dateFormatter.date(from: "2023-02-20")!
            photos.append(Photo(id: UUID(), filename: "dog_park.jpg", dateTaken: photo2Date, albums: ["Pets"], tags: ["dog", "park", "running", "animal"]))

            let photo3Date = dateFormatter.date(from: "2023-03-10")!
            photos.append(Photo(id: UUID(), filename: "birthday_party.jpg", dateTaken: photo3Date, albums: ["Events"], tags: ["birthday", "cake", "party", "friends", "food"]))

            let photo4Date = dateFormatter.date(from: "2023-03-12")!
            photos.append(Photo(id: UUID(), filename: "mountain_hike.jpg", dateTaken: photo4Date, albums: ["Hiking"], tags: ["mountain", "hike", "nature", "landscape"]))

            let photo5Date = dateFormatter.date(from: "2023-03-18")!
            photos.append(Photo(id: UUID(), filename: "cat_sleeping.png", dateTaken: photo5Date, albums: ["Pets"], tags: ["cat", "sleeping", "animal"]))

            let photo6Date = dateFormatter.date(from: "2023-04-05")!
            photos.append(Photo(id: UUID(), filename: "city_skyline.jpeg", dateTaken: photo6Date, albums: ["Travel"], tags: ["city", "skyline", "buildings", "urban"]))

            albums = ["Vacation 2023", "Pets", "Events", "Hiking", "Travel"]
        }
    }

    // MARK: - Persistence Helpers
    private func savePhotos() {
        if let encoded = try? JSONEncoder().encode(photos) {
            UserDefaults.standard.set(encoded, forKey: "smartGalleryPhotos")
        }
    }
    private func loadPhotos() -> [Photo] {
        if let data = UserDefaults.standard.data(forKey: "smartGalleryPhotos"),
           let decoded = try? JSONDecoder().decode([Photo].self, from: data) {
            return decoded
        }
        return []
    }
    private func saveAlbums() {
        UserDefaults.standard.set(Array(albums), forKey: "smartGalleryAlbums")
    }
    private func loadAlbums() -> Set<String> {
        if let albumsArray = UserDefaults.standard.stringArray(forKey: "smartGalleryAlbums") {
            return Set(albumsArray)
        }
        return []
    }

    // MARK: - Photo Operations
    func addPhotosToAlbum(photoIDs: [UUID], albumName: String) {
        var updatedPhotos = photos // Work on a mutable copy
        for id in photoIDs {
            if let index = updatedPhotos.firstIndex(where: { $0.id == id }) {
                if !updatedPhotos[index].albums.contains(albumName) {
                    updatedPhotos[index].albums.append(albumName)
                }
            }
        }
        self.photos = updatedPhotos // Assign back to trigger @Published
        self.albums.insert(albumName)
    }

    func getPhotos(from startDate: Date, to endDate: Date) -> [Photo] {
        // Normalize dates to start/end of day for broader range matching
        let calendar = Calendar.current
        let startOfDay = calendar.startOfDay(for: startDate)
        let endOfDay = calendar.date(byAdding: .day, value: 1, to: calendar.startOfDay(for: endDate))!

        return photos.filter { photo in
            photo.dateTaken >= startOfDay && photo.dateTaken < endOfDay
        }
    }

    func findPhotos(with objectConcept: String) -> [Photo] {
        // Simulate AI analysis: In a real app, this would use Vision framework
        // combined with on-device intelligence (like Apple Intelligence APIs)
        // to detect objects/scenes within images.
        // For this exercise, we'll do a simple case-insensitive tag or filename match.
        let lowercasedConcept = objectConcept.lowercased()
        return photos.filter { photo in
            photo.tags.contains(where: { $0.lowercased().contains(lowercasedConcept) }) ||
            photo.filename.lowercased().contains(lowercasedConcept)
        }
    }

    func photo(for id: UUID) -> Photo? {
        photos.first(where: { $0.id == id })
    }
}

// MARK: - App Entity for Photo

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct PhotoEntity: AppEntity {
    let id: UUID
    let filename: String
    let dateTaken: Date
    let albums: [String]

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Photo"
    static var defaultQuery = PhotoQuery()

    var displayRepresentation: DisplayRepresentation {
        let albumString = albums.isEmpty ? "No Album" : albums.joined(separator: ", ")
        return DisplayRepresentation(
            title: "\(filename)",
            subtitle: "Taken on \(dateTaken.formatted(date: .abbreviated, time: .omitted)) • Albums: \(albumString)",
            image: DisplayRepresentation.Image("photo", in: .system, variableValue: 0) // SF Symbol for photo
        )
    }

    // Initialize from Photo model
    init(photo: Photo) {
        self.id = photo.id
        self.filename = photo.filename
        self.dateTaken = photo.dateTaken
        self.albums = photo.albums
    }
}

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct PhotoQuery: EntityQuery {
    func entities(for identifiers: [PhotoEntity.ID]) async throws -> [PhotoEntity] {
        let photoLibrary = PhotoLibrary.shared
        return identifiers.compactMap { id in
            photoLibrary.photo(for: id).map { PhotoEntity(photo: $0) }
        }
    }

    // No suggestedEntities() needed as photos are not directly selected as parameters in this exercise.
    // If they were, this would provide recent or favorite photos.
}

// MARK: - App Intents

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct OrganizePhotosByDateIntent: AppIntent {
    static var title: LocalizedStringResource = "Organize Photos by Date"
    static var description = IntentDescription("Moves photos taken within a specific date range into a new album in SmartGallery.")

    @Parameter(title: "Start Date", description: "The beginning of the date range.")
    var startDate: Date

    @Parameter(title: "End Date", description: "The end of the date range.")
    var endDate: Date

    @Parameter(title: "Album Name", description: "The name of the album to move photos into.")
    var albumName: String

    // Parameter validation to ensure endDate is not before startDate
    func validate() throws {
        let calendar = Calendar.current
        let startOfDayForStartDate = calendar.startOfDay(for: startDate)
        let startOfDayForEndDate = calendar.startOfDay(for: endDate)

        if startOfDayForEndDate < startOfDayForStartDate {
            throw IntentError.validationError(
                "End Date cannot be before Start Date.",
                errorDescription: "The end date (\(endDate.formatted(date: .abbreviated, time: .omitted))) must be on or after the start date (\(startDate.formatted(date: .abbreviated, time: .omitted)))."
            )
        }
        
        guard !albumName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw IntentError.validationError("Album name cannot be empty.")
        }
    }

    func perform() async throws -> some IntentResult {
        // Validation is already handled by validate(), but can be re-checked here if needed.
        // For robustness, ensure validation is called or logic is duplicated.
        // In this case, `validate()` is automatically called before `perform()`.

        let photosInRange = PhotoLibrary.shared.getPhotos(from: startDate, to: endDate)

        guard !photosInRange.isEmpty else {
            return .result(dialog: "No photos found between \(startDate.formatted(date: .abbreviated, time: .omitted)) and \(endDate.formatted(date: .abbreviated, time: .omitted)). No album created.")
        }

        let photoIDs = photosInRange.map { $0.id }
        PhotoLibrary.shared.addPhotosToAlbum(photoIDs: photoIDs, albumName: albumName)

        let photoTitles = photosInRange.map { $0.filename }.joined(separator: ", ")
        return .result(dialog: "Moved \(photosInRange.count) photos to album '\(albumName)': \(photoTitles).")
    }
}

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct FindPhotosWithObjectIntent: AppIntent {
    static var title: LocalizedStringResource = "Find Photos with Object"
    static var description = IntentDescription("Finds photos containing a specific object or concept using SmartGallery's AI capabilities.")

    @Parameter(title: "Object or Concept", description: "The object or concept to search for in photos (e.g., 'dogs', 'mountains', 'birthday cake').")
    var objectConcept: String

    func perform() async throws -> some IntentResult {
        // Simulate AI analysis:
        // In a real app, this would involve integrating with:
        // 1. PhotoKit: To access the user's photo library.
        // 2. Vision Framework: For on-device object and scene detection (e.g., VNRecognizeObjectsRequest).
        // 3. Natural Language Framework / Apple Intelligence APIs: To understand natural language queries
        //    and potentially translate them into Vision framework parameters or search terms.
        //    For example, "photos with dogs" -> Vision framework's dog detection model.
        //    Or "photos from my birthday party" -> Contextual search based on date, location, and detected objects.

        let foundPhotos = PhotoLibrary.shared.findPhotos(with: objectConcept)

        guard !foundPhotos.isEmpty else {
            return .result(dialog: "No photos found matching '\(objectConcept)'.")
        }

        // Map internal Photo models to PhotoEntity for structured results
        let photoEntities = foundPhotos.map { PhotoEntity(photo: $0) }

        let dialog = "Found \(foundPhotos.count) photos matching '\(objectConcept)'. Check them out!"
        return .result(dialog: dialog, entities: photoEntities)
    }
}

// MARK: - AppIntent Extension (for discoverability)

@available(iOS 18.0, macOS 15.0, watchOS 11.0, *)
struct SmartGalleryAppIntents: AppIntentExtension {
    static var appName: LocalizedStringResource = "SmartGallery"
    static var category: IntentCategory = .mediaAndPhotos
}
