/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// app/layout.tsx (App Router)
import { Inter } from 'next/font/google';
import './globals.css';

// 1. Configure font loading strategy
// 'display: swap' ensures text is visible immediately (fallback font) 
// while the custom font loads, preventing invisible text (FOIT).
const inter = Inter({ 
  subsets: ['latin'],
  display: 'swap', 
});

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        {/* 2. Add resource hints for critical external assets */}
        {/* Preconnect to external CDN (e.g., for analytics or images) */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        
        {/* Preload critical hero image if it's not directly imported by a component 
            (e.g., loaded via CSS background or external URL) */}
        <link rel="preload" href="/hero-banner.webp" as="image" type="image/webp" />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  );
}

// components/Hero.tsx
import Image from 'next/image';

export function Hero() {
  return (
    <div style={{ position: 'relative', height: '500px' }}>
      {/* 3. Optimize critical image */}
      {/* 'priority' attribute is crucial for LCP images. It preloads the image 
          and loads it with high priority. 'fill' allows the image to fill the parent container. */}
      <Image 
        src="/hero-banner.webp" 
        alt="Hero" 
        priority 
        fill 
        sizes="100vw"
        style={{ objectFit: 'cover' }}
      />
    </div>
  );
}
