
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

// MARK: - Data Structures

struct CryingPrediction {
    let actualIsCrying: Bool // True if baby was actually crying
    let cryingProbability: Double // Model's output probability for 'crying'
}

// Reusing EmailCategory for binary classification labels, adapting 'spam' to 'crying'
enum CryingClassification: String, CaseIterable {
    case crying = "Crying"
    case notCrying = "Not Crying"
}

// Reusing ConfusionMatrix struct from Exercise 1, it's generic enough
// struct ConfusionMatrix { ... } // Defined in Exercise 1

// MARK: - Core Functions

/// Classifies predictions based on a probability threshold.
/// - Parameters:
///   - predictions: An array of CryingPrediction instances with probabilities.
///   - threshold: The probability threshold (inclusive) for classifying as 'crying'.
/// - Returns: An array of CryingPredictionWithClassification, ready for confusion matrix calculation.
func classifyByThreshold(predictions: [CryingPrediction], threshold: Double) -> [EmailPrediction] {
    return predictions.map { p in
        let predictedCategory: CryingClassification = (p.cryingProbability >= threshold) ? .crying : .notCrying
        let actualCategory: CryingClassification = p.actualIsCrying ? .crying : .notCrying
        // Map to EmailPrediction for reuse of calculateConfusionMatrix
        return EmailPrediction(actual: (actualCategory == .crying ? .spam : .notSpam),
                               predicted: (predictedCategory == .crying ? .spam : .notSpam))
    }
}

// Reusing calculateConfusionMatrix, calculatePrecision, calculateRecall from Exercise 1.
// They are designed to work with a positive class (e.g., .spam), so we'll map .crying to .spam.
// func calculateConfusionMatrix(predictions: [EmailPrediction], forPositiveClass positiveClass: EmailCategory) -> ConfusionMatrix { ... }
// func calculatePrecision(confusionMatrix: ConfusionMatrix) -> Double { ... }
// func calculateRecall(confusionMatrix: ConfusionMatrix) -> Double { ... }

// MARK: - Simulation and Reporting

// 2. Simulate Model Output
var cryingPredictions: [CryingPrediction] = []

// Scenario: actualIsCrying = true
// High probability (True Positive candidates)
cryingPredictions.append(CryingPrediction(actualIsCrying: true, cryingProbability: 0.95))
cryingPredictions.append(CryingPrediction(actualIsCrying: true, cryingProbability: 0.88))
cryingPredictions.append(CryingPrediction(actualIsCrying: true, cryingProbability: 0.82))
cryingPredictions.append(CryingPrediction(actualIsCrying: true, cryingProbability: 0.75))
// Medium probability (might be FN if threshold is high)
cryingPredictions.append(CryingPrediction(actualIsCrying: true, cryingProbability: 0.60))
cryingPredictions.append(CryingPrediction(actualIsCrying: true, cryingProbability: 0.55))
// Low probability (False Negative candidates)
cryingPredictions.append(CryingPrediction(actualIsCrying: true, cryingProbability: 0.40))
cryingPredictions.append(CryingPrediction(actualIsCrying: true, cryingProbability: 0.35))
cryingPredictions.append(CryingPrediction(actualIsCrying: true, cryingProbability: 0.20))

// Scenario: actualIsCrying = false
// High probability (False Positive candidates if threshold is low)
cryingPredictions.append(CryingPrediction(actualIsCrying: false, cryingProbability: 0.70)) // Misclassified
cryingPredictions.append(CryingPrediction(actualIsCrying: false, cryingProbability: 0.65)) // Misclassified
cryingPredictions.append(CryingPrediction(actualIsCrying: false, cryingProbability: 0.58)) // Misclassified
// Medium probability
cryingPredictions.append(CryingPrediction(actualIsCrying: false, cryingProbability: 0.45))
cryingPredictions.append(CryingPrediction(actualIsCrying: false, cryingProbability: 0.30))
// Low probability (True Negative candidates)
cryingPredictions.append(CryingPrediction(actualIsCrying: false, cryingProbability: 0.15))
cryingPredictions.append(CryingPrediction(actualIsCrying: false, cryingProbability: 0.05))
cryingPredictions.append(CryingPrediction(actualIsCrying: false, cryingProbability: 0.10))
cryingPredictions.append(CryingPrediction(actualIsCrying: false, cryingProbability: 0.25))

cryingPredictions.shuffle() // Mix the data

print("--- Baby Crying Detector: Adjustable Sensitivity ---")
print("Total Recordings: \(cryingPredictions.count)\n")

// 5. Simulate Sensitivity Adjustment
let thresholds: [Double] = [0.3, 0.5, 0.7]
let positiveClassForMetrics = EmailCategory.spam // Mapping CryingClassification.crying to EmailCategory.spam

for threshold in thresholds {
    print(String(repeating: "=", count: 40))
    print(String(format: "Evaluating with Threshold: %.2f", threshold))
    print(String(repeating: "=", count: 40))

    // 3. Implement Threshold-Based Classification
    let classifiedPredictions = classifyByThreshold(predictions: cryingPredictions, threshold: threshold)

    // 4. Calculate Metrics for a Given Threshold
    let confusionMatrix = calculateConfusionMatrix(predictions: classifiedPredictions, forPositiveClass: positiveClassForMetrics)
    confusionMatrix.describe()

    let precision = calculatePrecision(confusionMatrix: confusionMatrix)
    let recall = calculateRecall(confusionMatrix: confusionMatrix)

    print(String(format: "Precision (for 'Crying'): %.4f", precision))
    print(String(format: "Recall (for 'Crying'):    %.4f", recall))
    print("\nPractical Implications for a Parent:")

    if threshold == 0.3 {
        print("- **High Sensitivity (Threshold 0.3):**")
        print("  - The model is very eager to detect crying. A low probability is enough to trigger an alert.")
        print(String(format: "  - High Recall (%.2f): Most actual crying events will be caught. Parents are less likely to miss their baby crying.", recall))
        print(String(format: "  - Lower Precision (%.2f): More false alarms (non-crying sounds flagged as crying). This might lead to parents frequently checking the app for no reason, causing frustration.", precision))
    } else if threshold == 0.5 {
        print("- **Default Sensitivity (Threshold 0.5):**")
        print("  - A balanced approach. Alerts are triggered when the model is reasonably confident.")
        print(String(format: "  - Balanced Precision (%.2f) and Recall (%.2f): A good trade-off between catching crying and minimizing false alarms.", precision, recall))
        print("  - This is often a good starting point for a general-purpose model.")
    } else if threshold == 0.7 {
        print("- **Low Sensitivity (Threshold 0.7):**")
        print("  - The model needs high confidence to trigger an alert. Only very clear crying sounds will be flagged.")
        print(String(format: "  - High Precision (%.2f): When an alert occurs, it's very likely to be actual crying. Fewer false alarms.", precision))
        print(String(format: "  - Lower Recall (%.2f): The model might miss some actual crying events, especially softer or shorter ones. Parents might not be alerted when their baby is crying.", recall))
    }
    print("\n")
}

// 6. Discuss Trade-offs
print("--- Trade-offs and Recommendation ---")
print("The results clearly demonstrate the **precision-recall trade-off**.")
print("A lower threshold (higher sensitivity) leads to higher recall but lower precision (more true crying caught, but more false alarms).")
print("A higher threshold (lower sensitivity) leads to higher precision but lower recall (fewer false alarms, but more true crying missed).")
print("\nFor a baby crying detector:")
print("- **Risks of high sensitivity (low threshold):** Constant false alarms can lead to 'alert fatigue', where parents start ignoring notifications, potentially missing actual crying. It's disruptive.")
print("- **Risks of low sensitivity (high threshold):** Missing actual crying events is a critical failure for a baby monitor, defeating its primary purpose. This is generally more severe.")
print("\n**Recommendation:**")
print("A default threshold of **0.5** often strikes a good balance for many applications. However, for a baby monitor, missing crying (low recall) is a more serious issue than a few false alarms (low precision). Therefore, a slightly lower default threshold (e.g., **0.4 or 0.5**) might be preferable to prioritize recall, ensuring parents are alerted to most crying events.")
print("The adjustable slider is an excellent feature, allowing parents to customize based on their environment and preferences (e.g., a light sleeper might prefer higher precision to avoid being woken unnecessarily, while a parent in another room might prefer higher recall).")

