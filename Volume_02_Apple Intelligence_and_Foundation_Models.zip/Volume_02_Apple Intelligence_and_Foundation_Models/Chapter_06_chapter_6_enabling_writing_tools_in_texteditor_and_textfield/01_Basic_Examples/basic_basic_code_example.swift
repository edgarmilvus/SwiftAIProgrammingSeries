
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Foundation // Included for general text handling context, though not strictly needed for this basic example.

/// A simple SwiftUI view demonstrating the automatic enablement of Apple Intelligence Writing Tools
/// within a `TextEditor` component on iOS 18 and later.
///
/// This example simulates a basic note-taking interface where a user can type text.
/// On compatible devices running iOS 18+, the system automatically provides access
/// to Writing Tools (like Rewrite, Proofread, Summarize, etc.) via the standard
/// text selection context menu.
@available(iOS 18.0, *) // Apple Intelligence features require iOS 18.0 or later
struct NoteTakingView: View {
    /// The text content of our note, bound to the `TextEditor`.
    /// Initial text includes a hint for the user to interact with Writing Tools.
    @State private var noteContent: String = "Start typing your note here. Select some text to see the Writing Tools in action! For example, try selecting this entire sentence and then tap 'Show More' in the context menu."

    var body: some View {
        NavigationView { // Provides a navigation bar for a title.
            VStack { // Arranges subviews vertically.
                // Title for the note-taking app.
                Text("My Smart Notebook")
                    .font(.largeTitle)
                    .padding(.bottom)

                // 1. The TextEditor component: This is the core of our example.
                // SwiftUI's TextEditor automatically integrates with Apple Intelligence
                // Writing Tools on iOS 18+ without any special modifiers or code.
                TextEditor(text: $noteContent) // Binds the TextEditor's content to our @State variable.
                    .font(.body) // Sets the font for the text within the editor.
                    .padding() // Adds internal padding to the text editor content.
                    .border(Color.gray, width: 0.5) // Adds a subtle border for visual clarity of the input area.
                    .frame(minHeight: 200, maxHeight: .infinity) // Sets a minimum height and allows it to expand.
                    .background(Color.white) // Sets the background color of the editor itself.
                    .cornerRadius(8) // Rounds the corners of the editor.
                    .shadow(radius: 2) // Adds a subtle shadow for depth.
                    .padding(.horizontal) // Adds horizontal padding around the editor.

                Spacer() // Pushes content to the top, allowing the editor to expand.

                // Hint for the user on how to access the Writing Tools.
                Text("Hint: Select text in the editor to reveal Writing Tools in the context menu.")
                    .font(.caption) // Smaller font for the hint.
                    .foregroundColor(.secondary) // Muted color for the hint text.
                    .padding() // Adds padding around the hint text.
            }
            .navigationTitle("Notes") // Sets the title in the navigation bar.
            .navigationBarTitleDisplayMode(.inline) // Displays the title inline in the navigation bar.
            .background(Color.groupTableViewBackground.ignoresSafeArea()) // Sets a common system background color.
        }
    }
}

// MARK: - App Entry Point (for preview and basic app structure)

/// The main App structure for this example.
///
/// This provides a simple wrapper to host our `NoteTakingView` for demonstration purposes.
@available(iOS 18.0, *)
@main
struct WritingToolsApp: App {
    var body: some Scene {
        WindowGroup { // Creates a window to display our view hierarchy.
            NoteTakingView() // The initial view displayed when the app launches.
        }
    }
}

// MARK: - Preview Provider (for Xcode Canvas)

/// Provides a preview of `NoteTakingView` in Xcode's canvas.
///
/// This allows developers to see the UI without running on a device or simulator.
/// Note that Writing Tools functionality itself requires a compatible runtime (iOS 18+ device/simulator).
#Preview {
    if #available(iOS 18.0, *) {
        NoteTakingView()
    } else {
        // Fallback for older iOS versions if running the preview in an incompatible environment.
        // The @available annotation on the struct itself generally prevents compilation issues.
        Text("Writing Tools require iOS 18.0 or later for full functionality.")
    }
}
