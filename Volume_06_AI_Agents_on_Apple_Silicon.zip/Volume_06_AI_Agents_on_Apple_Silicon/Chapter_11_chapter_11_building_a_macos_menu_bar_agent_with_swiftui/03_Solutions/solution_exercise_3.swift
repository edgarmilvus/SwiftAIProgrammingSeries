
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// PopoverRootView.swift (Updated)
import SwiftUI

struct PopoverRootView: View {
    @Binding var isPopoverShown: Bool // Binding to dismiss the popover

    // State variables for interactive elements
    @State private var inputText: String = ""
    @State private var displayedText: String = "No text displayed yet."
    @State private var isDarkMode: Bool = false

    var body: some View {
        VStack(spacing: 15) {
            Text("Interactive AI Agent")
                .font(.headline)
                .padding(.bottom, 5)

            // 1. TextField for user input
            TextField("Enter text here...", text: $inputText)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
                .frame(width: 220) // Constrain width for better layout

            // 2. Button to display text
            Button("Show Text") {
                displayedText = inputText
                inputText = "" // Clear TextField after showing text
            }
            .padding(.horizontal)
            .buttonStyle(.borderedProminent)
            // Disable button if text field is empty
            .disabled(inputText.isEmpty)

            // Display the entered text
            Text(displayedText)
                .font(.subheadline)
                .italic()
                .padding(.vertical, 5)
                .frame(maxWidth: .infinity, alignment: .leading) // Align left

            // 3. Toggle for Dark Mode
            Toggle(isOn: $isDarkMode) {
                Text("Dark Mode")
            }
            .toggleStyle(.switch)
            .padding(.horizontal)
            .frame(width: 220, alignment: .leading) // Constrain width and align left

            Spacer() // Pushes content to the top
            
            Button("Dismiss") {
                isPopoverShown = false
            }
            .buttonStyle(.bordered)
            .tint(isDarkMode ? .white : .accentColor) // Adjust tint based on mode
        }
        .padding()
        .frame(width: 260, height: 280) // Adjust popover size
        // 4. Dynamic background and foreground color based on isDarkMode
        .background(isDarkMode ? Color.black.opacity(0.9) : Color.white)
        .foregroundColor(isDarkMode ? Color.white : Color.black)
        .cornerRadius(10) // Optional: Add rounded corners to the popover content
    }
}
