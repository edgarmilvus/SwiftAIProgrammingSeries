
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

    import MLX
    import MLXNN
    import MLXOptimizers
    import Foundation // For logging and basic types

    /// A simple neural network module designed to enhance text patches.
    /// It takes a flattened patch of noisy pixels and outputs a flattened patch of cleaned pixels.
    /// This model inherits from `MLXNN.Module`, which is the base class for all neural network modules
    /// in MLX Swift, providing parameter management and the ability to be differentiated.
    @available(iOS 18.0, macOS 15.0, *) // Using modern Swift features and MLX
    final class TextEnhancementModel: MLXNN.Module, @unchecked Sendable {
        let linear1: MLXNN.Linear
        let linear2: MLXNN.Linear
        let inputSize: Int
        let outputSize: Int

        /// Initializes the text enhancement model.
        /// - Parameters:
        ///   - inputSize: The number of features in the input (e.g., flattened pixel count of a patch).
        ///   - hiddenSize: The number of neurons in the hidden layer.
        ///   - outputSize: The number of features in the output (e.g., flattened pixel count of the cleaned patch).
        init(inputSize: Int, hiddenSize: Int, outputSize: Int) {
            self.inputSize = inputSize
            self.outputSize = outputSize
            self.linear1 = MLXNN.Linear(inputSize: inputSize, outputSize: hiddenSize)
            self.linear2 = MLXNN.Linear(inputSize: hiddenSize, outputSize: outputSize)
            super.init() // Call the superclass initializer
        }

        /// Defines the forward pass of the model.
        /// - Parameter x: The input `MLXArray` representing a batch of noisy text patches.
        /// - Returns: An `MLXArray` representing the model's prediction for cleaned text patches.
        override func callAsFunction(_ x: MLXArray) -> MLXArray {
            // First linear layer with ReLU activation
            let h = MLXNN.relu(linear1(x))
            // Second linear layer, outputting the final cleaned patch
            return linear2(h)
        }
    }
    