
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

struct Candidate: Sendable {
    let id: UUID
    let text: String
    var score: Double
}

actor SearchOrchestrator {
    
    /// Simulates the first stage: Fast Hybrid Retrieval
    private func fetchCandidates() async -> [Candidate] {
        try? await Task.sleep(nanoseconds: 50_000_000) // 50ms
        return [
            Candidate(id: UUID(), text: "The impact of microplastics on oceans.", score: 0.5),
            Candidate(id: UUID(), text: "How to bake a cake.", score: 0.2),
            Candidate(id: UUID(), text: "A study on marine biology consequences.", score: 0.4),
            Candidate(id: UUID(), text: "Swift programming tutorials.", score: 0.3)
        ]
    }
    
    /// Simulates the second stage: Heavy Cross-Encoder Re-ranking
    private func reRank(candidates: [Candidate]) async -> [Candidate] {
        // Simulate high-latency model inference
        try? await Task.sleep(nanoseconds: 500_000_000) // 500ms
        
        let triggers = ["impact", "consequence", "study", "result"]
        
        return candidates.map { candidate in
            var updatedCandidate = candidate
            let lowerText = candidate.text.lowercased()
            
            // If the text contains a contextual trigger, boost the score
            if triggers.contains(where: { lowerText.contains($0) }) {
                updatedCandidate.score += 0.5
            }
            return updatedCandidate
        }.sorted { $0.score > $1.score }
    }
    
    /// Orchestrates the two-stage pipeline and yields results via AsyncStream.
    func search(query: String) -> AsyncStream<String> {
        AsyncStream { continuation in
            Task {
                continuation.yield("Stage 1: Retrieving candidates...")
                let candidates = await fetchCandidates()
                
                continuation.yield("Stage 2: Re-ranking with Cross-Encoder...")
                let ranked = await reRank(candidates: candidates)
                
                continuation.yield("Search Complete. Top result: \(ranked.first?.text ?? "None")")
                
                // Yield the actual ranked data (in a real app, you'd yield [Candidate])
                for item in ranked {
                    continuation.yield("Result: [Score: \(String(format: "%.2f", item.score))] \(item.text)")
                }
                
                continuation.finish()
            }
        }
    }
}

// MARK: - Example Usage
@main
struct JournalistProApp {
    static func main() async {
        let orchestrator = SearchOrchestrator()
        let stream = orchestrator.search(query: "microplastics impact")
        
        print("Starting Search Pipeline...\n")
        for await status in stream {
            print(status)
        }
    }
}
