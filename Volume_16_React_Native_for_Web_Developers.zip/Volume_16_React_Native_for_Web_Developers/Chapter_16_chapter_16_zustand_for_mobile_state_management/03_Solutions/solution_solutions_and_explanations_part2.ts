/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// middleware.ts
import { StateCreator, StoreMutatorIdentifier } from 'zustand';

// 1. Define the Analytics Helper
const sendAnalytics = async (action: string, payload: any) => {
  try {
    // Mock API endpoint
    await fetch('https://mock-api.example.com/analytics', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action,
        payload,
        timestamp: new Date().toISOString(),
      }),
    });
    console.log(`[Analytics] Sent event: ${action}`);
  } catch (error) {
    console.error('[Analytics] Failed to send event:', error);
  }
};

// 2. Define the Middleware Type
type LoggerWithAnalytics = <
  T extends object,
  Mps extends [StoreMutatorIdentifier, unknown][] = [],
  Mcs extends [StoreMutatorIdentifier, unknown][] = []
>(
  initializer: StateCreator<T, Mps, Mcs>
) => StateCreator<T, Mps, Mcs>;

// 3. Implement the Middleware
const loggerWithAnalyticsImpl: LoggerWithAnalytics = (config) => (set, get, api) => {
  // Wrap the original set function
  return config(
    (args) => {
      const previousState = get().state; // Capture previous state (if available via api)
      // Note: In standard Zustand, capturing previous state strictly inside middleware 
      // requires accessing api.getState() before the update.
      
      console.groupCollapsed('[Zustand Middleware] Action Dispatched');
      console.log('Previous State:', previousState || get()); // Log current state before update
      console.log('Payload:', args);
      
      // Trigger the actual state update
      set(args);
      
      console.log('New State:', get());
      console.groupEnd();

      // Trigger Analytics
      // We extract the action name if possible, or generic "State Update"
      const actionName = typeof args === 'function' ? 'Function' : (args as any).type || 'State Update';
      sendAnalytics(actionName, args);
    },
    get,
    api
  );
};

// 4. Apply to a Sample Store (Counter)
import { create } from 'zustand';

interface CounterState {
  count: number;
  increment: () => void;
  decrement: () => void;
}

export const useCounterStore = create<CounterState>()(
  // Cast the middleware to the correct type to avoid TS errors
  loggerWithAnalyticsImpl((set) => ({
    count: 0,
    increment: () => set((state) => ({ count: state.count + 1 })),
    decrement: () => set((state) => ({ count: state.count - 1 })),
  }))
);
