
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

// This class simulates the main application logic, integrating the MLXSummarizer.
// It would typically be part of an AppDelegate, a SwiftUI App struct, or a ViewController.
@available(iOS 18.0, macOS 15.0, visionOS 2.0, *)
class LocalChatAssistantApp {
    let summarizer: MLXSummarizer
    let modelSaveURL: URL

    init() {
        // Initialize the summarizer with desired model parameters.
        // Using smaller dimensions for faster demonstration.
        self.summarizer = MLXSummarizer(maxSequenceLength: 128, modelDim: 64, numLayers: 1, numHeads: 2, mlpDim: 128)
        
        // Define a URL for saving/loading the model parameters.
        // In a real app, this would be in the Application Support directory or a secure container.
        if let docsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            self.modelSaveURL = docsURL.appendingPathComponent("summarization_model.safetensors")
        } else {
            fatalError("Could not find document directory for model saving.")
        }
    }

    /// Simulates the lifecycle of a local chat assistant within an Apple app.
    /// This demonstrates loading a model, performing inference, and a brief fine-tuning step.
    /// It uses Swift's `async/await` for managing asynchronous operations.
    func run() async {
        print("--- Local Chat Assistant Initializing ---")
        
        // 1. Load or initialize the model.
        // We attempt to load a previously saved model first. If it fails (e.g., first run),
        // a new model is initialized with random weights.
        do {
            print("Attempting to load model from: \(modelSaveURL.lastPathComponent)")
            try await summarizer.loadModel(from: modelSaveURL)
        } catch {
            print("Error loading model: \(error.localizedDescription). Initializing a new model instead.")
            do {
                try await summarizer.loadModel(from: nil) // Initialize a fresh model
            } catch {
                print("FATAL: Could not initialize model: \(error.localizedDescription)")
                return
            }
        }
        
        // 2. Perform summarization inference.
        let longText = """
        Apple Inc. is an American multinational technology company headquartered in Cupertino, California.
        Apple is the largest technology company by revenue (totaling US$383 billion in 2023) and, as of June 2024,
        is the world's most valuable company. As of 2023, Apple is the world's largest technology company by revenue
        and the world's second-largest manufacturer of mobile phones, after Samsung.
        It is one of the Big Five American information technology companies, alongside Alphabet (Google), Amazon, Meta (Facebook), and Microsoft.

        Apple was founded by Steve Jobs, Steve Wozniak, and Ronald Wayne in April 1976 to develop and sell Wozniak's Apple I personal computer.
        It was incorporated as Apple Computer, Inc. in January 1977, and sales of its computers, including the Apple II, grew rapidly.
        It went public in 1980 to instant financial success. The company developed computers with graphical user interfaces,
        such as the original Macintosh, which was introduced in 1984. By 1985, Jobs had departed Apple to found NeXT,
        while Wozniak had also resigned from the company.
        """
        
        print("\n--- Performing Summarization ---")
        print("Original Text:\n\(longText.prefix(150))...")
        do {
            let summary = try await summarizer.summarize(text: longText)
            print("Summary:\n\(summary)")
        } catch {
            print("Error during summarization: \(error.localizedDescription)")
        }
        
        // 3. (Optional) Simulate a fine-tuning step.
        // This demonstrates how `valueAndGradient` would be used in a training loop.
        print("\n--- Simulating Fine-tuning Step ---")
        let trainingData: [String: String] = [
            "Apple Inc. is a tech giant. It makes iPhones, Macs, and offers services. Founded by Jobs and Wozniak.": "Apple is a tech company known for iPhones and Macs, founded by Jobs and Wozniak.",
            "The quick brown fox jumps over the lazy dog.": "Fox jumps over dog." // Example to expand tokenizer vocab
        ]
        
        do {
            let loss = try await summarizer.fineTune(data: trainingData)
            print("Fine-tuning completed with loss: \(loss)")
        } catch {
            print("Error during fine-tuning: \(error.localizedDescription)")
        }
        
        // 4. Save the (potentially fine-tuned) model.
        print("\n--- Saving Model ---")
        do {
            try summarizer.saveModel(to: modelSaveURL)
        } catch {
            print("Error saving model: \(error.localizedDescription)")
        }

        print("\n--- Local Chat Assistant Finished ---")
    }
}

// MARK: - Main execution (for a command-line tool or app entry point)

// This conditional compilation ensures the main entry point is only active
// when building an executable, not a library.
#if canImport(SwiftUI) || canImport(UIKit) || canImport(AppKit)
// In a real application, you would typically integrate `LocalChatAssistantApp`
// into your `@main App` struct (SwiftUI) or `AppDelegate` (UIKit/AppKit).
/* Example for SwiftUI:
 @main
 struct MyApp: App {
     let assistant = LocalChatAssistantApp()
     var body: some Scene {
         WindowGroup {
             ContentView()
                 .task { // Use .task to run async code when view appears
                     await assistant.run()
                 }
         }
     }
 }
 */
#else
// For a simple command-line execution or playground, we call `main()` directly.
// Ensure this code is run on an Apple Silicon device with MLX Swift installed.
@available(iOS 18.0, macOS 15.0, visionOS 2.0, *)
func main() async {
    let app = LocalChatAssistantApp()
    await app.run()
}

// Call the main function, checking for availability.
if #available(iOS 18.0, macOS 15.0, visionOS 2.0, *) {
    await main()
} else {
    print("This application requires iOS 18.0+, macOS 15.0+, or visionOS 2.0+ to run MLX Swift.")
}
#endif
