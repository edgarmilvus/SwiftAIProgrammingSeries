
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 18.0, *)
protocol SemanticProvider: Sendable {
    func generateEmbedding(for text: String) async throws -> [Float]
}

@available(iOS 18.0, *)
class MockEmbeddingService: SemanticProvider {
    func generateEmbedding(for text: String) async throws -> [Float] {
        // Simulate network latency
        try await Task.sleep(for: .milliseconds(500))
        // Return a deterministic "fake" vector based on text length for testing
        return Array(repeating: Float(text.count) / 100.0, count: 128)
    }
}

@available(iOS 18.0, *)
class ContextualRecallEngine: @unchecked Sendable {
    private let provider: SemanticProvider
    private let store: VectorStore
    private var searchTask: Task<[Document], Error>?
    
    init(provider: SemanticProvider, store: VectorStore) {
        self.provider = provider
        self.store = store
    }
    
    /// Fetches related entries with debouncing logic.
    func fetchRelatedEntries(for currentText: String) async throws -> [Document] {
        // 1. Debouncing: Cancel the previous search task if the user is still typing
        searchTask?.cancel()
        
        // 2. Create a new task for the current keystroke
        let newTask = Task { [provider, store] () -> [Document] in
            // Implement the debounce delay (300ms)
            try await Task.sleep(for: .milliseconds(300))
            
            // Check for cancellation after the sleep
            try Task.checkCancellation()
            
            // 3. Generate embedding (Off the Main Actor)
            let queryVector = try await provider.generateEmbedding(for: currentText)
            
            // Check for cancellation before the expensive search
            try Task.checkCancellation()
            
            // 4. Perform the search
            return store.search(queryVector: queryVector, limit: 3)
        }
        
        self.searchTask = newTask
        
        // Wait for the task to complete and return results
        return try await newTask.value
    }
}

// MARK: - Simulation of Real-Time Typing
@available(iOS 18.0, *)
func simulateTyping() async {
    let engine = ContextualRecallEngine(provider: MockEmbeddingService(), store: VectorStore())
    let inputs = ["H", "He", "Hel", "Hell", "Hello"]
    
    print("Starting typing simulation...")
    
    for input in inputs {
        print("User typed: '\(input)'")
        Task {
            do {
                let results = try await engine.fetchRelatedEntries(for: input)
                if !results.isEmpty {
                    print("✅ Suggestions found for '\(input)': \(results.map { $0.text })")
                }
            } catch is CancellationError {
                // Expected when user types quickly
            } catch {
                print("❌ Error: \(error)")
            }
        }
        // Simulate rapid typing (100ms between keys)
        try? await Task.sleep(for: .milliseconds(100))
    }
}

Task {
    await simulateTyping()
}
