/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: services/notificationService.ts
import { Expo, ExpoPushMessage } from 'expo-server-sdk';
import prisma from '../lib/prisma';

const expo = new Expo();

// 1. Payload Builder
export function buildNotificationPayload(event: {
  type: string;
  data: any;
  title: string;
  body: string;
}): ExpoPushMessage {
  // Standardize the payload for Expo
  return {
    to: 'placeholder_token', // Will be replaced in the sender
    sound: 'default',
    title: event.title,
    body: event.body,
    data: {
      ...event.data,
      type: event.type,
    },
    // Use tags for categorization if configured on the device
    tags: [{ name: 'category', value: event.type }],
  };
}

// 2. Sender Service
export async function sendPushNotification(userId: string, payloadTemplate: Omit<ExpoPushMessage, 'to'>) {
  // Query DB for tokens
  const tokens = await prisma.pushToken.findMany({
    where: { userId: userId },
    select: { token: true },
  });

  if (tokens.length === 0) return;

  // Filter out invalid Expo tokens
  const validTokens = tokens.map(t => t.token).filter(token => Expo.isExpoPushToken(token));

  // Chunking is required by Expo to handle large batches
  const chunks = expo.chunkPushNotifications(
    validTokens.map(token => ({
      ...payloadTemplate,
      to: token,
    }))
  );

  // 3. Event Loop Awareness
  // Even though we are iterating chunks, the `expo.sendPushNotificationsAsync` 
  // is an asynchronous I/O operation (network request). 
  // Node.js does not block here; it initiates the request and moves on to the next task 
  // in the event loop, handling the response later via callbacks/promises.
  const ticketChunks = await Promise.all(
    chunks.map(chunk => expo.sendPushNotificationsAsync(chunk))
  );

  // Handle errors (e.g., invalid tokens)
  for (const chunk of ticketChunks) {
    for (const ticket of chunk) {
      if (ticket.status === 'error') {
        if (ticket.message === 'DeviceNotRegistered') {
          // Remove invalid token from DB
          const invalidToken = ticket.request?.[0]?.to;
          if (invalidToken) {
            await prisma.pushToken.deleteMany({
              where: { token: invalidToken },
            });
          }
        }
      }
    }
  }
}

// Interactive Challenge: Notification Queue Concept
// File: workers/notificationWorker.ts (using BullMQ)
import { Worker } from 'bullmq';
import { sendPushNotification } from './notificationService';

const worker = new Worker('notifications', async job => {
  const { userId, payload } = job.data;
  await sendPushNotification(userId, payload);
}, { connection: { host: 'localhost', port: 6379 } });
