
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// No external Swift Package Manager dependencies are strictly required for Core ML and Vision
// as they are part of the Apple SDKs. However, PhotosUI is needed for PhotosPicker.
// If you were to include this in a Package.swift, it would look like this:
//
// import PackageDescription
//
// let package = Package(
//     name: "SmartPhotoTagger",
//     platforms: [
//         .iOS(.v18), // Requires iOS 18.0 for @Observable and PhotosPicker features
//     ],
//     products: [
//         .library(
//             name: "SmartPhotoTagger",
//             targets: ["SmartPhotoTagger"]),
//     ],
//     targets: [
//         .target(
//             name: "SmartPhotoTagger",
//             // No explicit dependencies needed for Core ML, Vision, PhotosUI as they are system frameworks.
//             // If you had a custom Swift package for common utilities, it would go here.
//             // dependencies: [.product(name: "SomeUtilityPackage", package: "SomeUtilityRepo")],
//             resources: [
//                 // If your .mlmodelc was not directly in the main app bundle but in a package,
//                 // you might specify it here, but typically it's included in the main app target.
//                 // .process("Resources/YourModel.mlmodelc")
//             ]
//         ),
//     ]
// )

import Foundation
import CoreML
import Vision
import UIKit // For UIImage
import PhotosUI // For PhotosPickerItem
import SwiftUI // For @Observable and Image

// MARK: - 1. Define Custom Errors for Robust Handling

/// Custom errors specific to the image classification process.
/// Conforms to `LocalizedError` for user-friendly descriptions and `Identifiable` for SwiftUI display.
enum ImageClassifierError: Error, LocalizedError, Identifiable {
    case modelLoadingFailed(underlyingError: Error)
    case imageProcessingFailed(description: String)
    case inferenceFailed(description: String)
    case noResultsFound
    case cancelled
    case unknown

    /// Unique ID for `Identifiable` conformance, useful for error alerts in SwiftUI.
    var id: String {
        self.localizedDescription
    }

    /// Provides a user-friendly description of the error.
    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let error):
            return "Failed to load Core ML model: \(error.localizedDescription)"
        case .imageProcessingFailed(let description):
            return "Failed to process image: \(description)"
        case .inferenceFailed(let description):
            return "Core ML inference failed: \(description)"
        case .noResultsFound:
            return "No classification results were found for this image."
        case .cancelled:
            return "Image processing was cancelled."
        case .unknown:
            return "An unknown error occurred during classification."
        }
    }
}

// MARK: - 2. Data Structure for Classification Results

/// Represents a single classification result for a processed image.
/// Conforms to `Identifiable` for easy use in SwiftUI lists.
struct ClassificationResult: Identifiable {
    let id = UUID() // Unique identifier for SwiftUI's ForEach
    let originalImage: UIImage // Storing the original UIImage for display
    let label: String
    let confidence: Double
}

// MARK: - 3. The Core ML & Vision Service (@Observable Class)

/// `ImageClassifierService` is an `@Observable` class responsible for
/// loading the Core ML model, processing selected images, performing inference,
/// and managing the state of classification results.
///
/// It leverages Swift 6 concurrency (`async/await`, `TaskGroup`) for efficient,
/// non-blocking processing of multiple images.
///
/// `@available(iOS 18.0, *)` ensures this class is used only on platforms
/// where `@Observable` and `PhotosPickerItem` features are available.
@available(iOS 18.0, *)
@Observable
final class ImageClassifierService {
    // MARK: - Public State Properties

    /// An array of classification results, updated as images are processed.
    /// Changes to this array will automatically trigger UI updates in SwiftUI views observing this service.
    var results: [ClassificationResult] = []

    /// Indicates whether the service is currently busy processing images.
    /// Useful for displaying loading indicators.
    var isLoading: Bool = false

    /// Stores any error that occurred during the classification process.
    /// Useful for displaying error messages to the user.
    var error: ImageClassifierError?

    // MARK: - Private Model Properties

    /// The raw Core ML model instance, loaded once.
    private var mlModel: MLModel?

    /// The Vision model wrapper for Core ML, providing convenience for image input.
    private var visionModel: VNCoreMLModel?

    /// The desired input image size for the Core ML model.
    /// This property MUST match the input dimensions expected by your specific `.mlmodelc` file.
    /// For many common image classification models (like ResNet, SqueezeNet), it's 224x224 pixels.
    private let modelInputSize: CGSize = CGSize(width: 224, height: 224)

    // MARK: - Initialization

    /// Initializes the service and attempts to load the Core ML model asynchronously.
    /// Model loading is performed in a `Task` to avoid blocking the initializer.
    init() {
        Task {
            await loadModel()
        }
    }

    // MARK: - Public Methods

    /// Processes an array of `PhotosPickerItem` asynchronously.
    /// This method uses `TaskGroup` to process multiple images concurrently,
    /// ensuring the UI remains responsive and leveraging device resources efficiently.
    ///
    /// - Parameter photos: An array of `PhotosPickerItem` selected by the user.
    func classifyImages(photos: [PhotosPickerItem]) async {
        // 3.1. Reset state and indicate loading to the UI.
        // All UI-related state updates must happen on the MainActor.
        await MainActor.run {
            self.isLoading = true
            self.error = nil
            self.results = [] // Clear previous results to show fresh batch
        }

        // Ensure the model is loaded before proceeding with classification.
        // If `loadModel()` failed, `visionModel` will be nil.
        guard let visionModel = self.visionModel else {
            await MainActor.run {
                // If model loading failed earlier, propagate that error, or set a generic one.
                self.error = self.error ?? .modelLoadingFailed(underlyingError: ImageClassifierError.unknown)
                self.isLoading = false
            }
            return
        }

        do {
            // 3.2. Use TaskGroup for concurrent processing.
            // A `TaskGroup` allows us to create multiple child tasks that run in parallel.
            // This is ideal for processing a batch of independent items (like multiple images).
            try await withThrowingTaskGroup(of: ClassificationResult?.self) { group in
                for item in photos {
                    group.addTask {
                        // Each item is processed in its own async task.
                        // This allows images to be loaded, preprocessed, and classified concurrently.
                        do {
                            return try await self.processSingleImage(item, with: visionModel)
                        } catch {
                            // Catch errors for individual images. This prevents one failing image
                            // from stopping the entire batch processing.
                            print("Error processing image: \(error.localizedDescription)")
                            // Optionally, capture individual image errors for detailed feedback
                            // or return nil to simply skip this image.
                            return nil
                        }
                    }
                }

                // 3.3. Collect results from the TaskGroup as they complete.
                for await result in group {
                    if let result = result {
                        await MainActor.run {
                            // Update the observable results array on the main actor.
                            // This will trigger immediate UI updates in SwiftUI for each completed image.
                            self.results.append(result)
                        }
                    }
                }
            }
        } catch {
            // Handle any errors that might escape the TaskGroup (e.g., if a task throws an unhandled error).
            await MainActor.run {
                self.error = error as? ImageClassifierError ?? .unknown
            }
        }

        // 3.4. Finalize loading state.
        await MainActor.run {
            self.isLoading = false
        }
    }

    // MARK: - Private Helper Methods

    /// Loads the Core ML model (`.mlmodelc`) from the app bundle.
    /// This is an asynchronous operation as model loading can be resource-intensive.
    private func loadModel() async {
        // Avoid reloading the model if it's already present.
        guard self.mlModel == nil || self.visionModel == nil else {
            return
        }

        do {
            // Attempt to find the compiled Core ML model in the app bundle.
            // IMPORTANT: Replace "YourImageClassifier" with the actual name of your .mlmodelc file.
            // The .mlmodelc file is generated by Xcode when you add an .mlmodel to your project.
            guard let modelURL = Bundle.main.url(forResource: "YourImageClassifier", withExtension: "mlmodelc") else {
                throw ImageClassifierError.modelLoadingFailed(underlyingError: NSError(domain: "ImageClassifierService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model 'YourImageClassifier.mlmodelc' not found in bundle. Make sure it's added to your project and target."]))
            }

            // Create an MLModel instance from the URL.
            // MLModel is the lowest-level Core ML object.
            let model = try MLModel(contentsOf: modelURL)
            self.mlModel = model

            // Create a VNCoreMLModel from the MLModel.
            // VNCoreMLModel wraps the MLModel for use with the Vision framework,
            // simplifying image input and output for common tasks like classification.
            self.visionModel = try VNCoreMLModel(for: model)
            print("Core ML model loaded successfully.")

        } catch {
            await MainActor.run {
                self.error = .modelLoadingFailed(underlyingError: error)
                print("Error loading Core ML model: \(error.localizedDescription)")
            }
        }
    }

    /// Processes a single `PhotosPickerItem` to perform classification.
    /// This method is designed to be called from within a `TaskGroup` or as a standalone task.
    ///
    /// - Parameters:
    ///   - item: The `PhotosPickerItem` representing the selected image.
    ///   - visionModel: The `VNCoreMLModel` to use for inference.
    /// - Returns: A `ClassificationResult` if successful.
    /// - Throws: `ImageClassifierError` if any step in the process fails.
    private func processSingleImage(_ item: PhotosPickerItem, with visionModel: VNCoreMLModel) async throws -> ClassificationResult {
        // 3.2.1. Load image data from PhotosPickerItem.
        // `loadTransferable` is an async operation that fetches the image data.
        guard let data = try await item.loadTransferable(type: Data.self) else {
            // This can happen if the user cancels the selection or if the data is somehow unavailable.
            throw ImageClassifierError.imageProcessingFailed(description: "Failed to load image data from PhotosPickerItem.")
        }
        guard let uiImage = UIImage(data: data) else {
            throw ImageClassifierError.imageProcessingFailed(description: "Failed to create UIImage from loaded data.")
        }

        // 3.2.2. Prepare image for Core ML (convert UIImage to CVPixelBuffer).
        // Core ML models typically require CVPixelBuffer input in a specific format and size.
        guard let pixelBuffer = prepareImageForModel(uiImage: uiImage) else {
            throw ImageClassifierError.imageProcessingFailed(description: "Failed to convert UIImage to CVPixelBuffer for model input.")
        }

        // 3.2.3. Perform Core ML inference using Vision framework.
        // VNCoreMLRequest handles the interaction with the Core ML model.
        let request = VNCoreMLRequest(model: visionModel) { request, error in
            // This completion handler is called by Vision framework on an arbitrary background queue.
            // We're handling results and errors in the main async flow after `handler.perform`.
            if let error = error {
                print("Vision request failed with error in completion: \(error.localizedDescription)")
            }
        }

        // Configure the request to scale the image appropriately to match the model's input.
        // `VNImageCropAndScaleOption.centerCrop` is a common strategy for image classification models.
        request.imageCropAndScaleOption = .centerCrop

        // Create a Vision image request handler.
        // This handler manages the image source (CVPixelBuffer) and executes Vision requests.
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])

        do {
            // Perform the Vision request synchronously on the current background task.
            // This is where the actual Core ML inference happens.
            try handler.perform([request])
        } catch {
            throw ImageClassifierError.inferenceFailed(description: "Vision request execution failed: \(error.localizedDescription)")
        }

        // 3.2.4. Extract and process results from the Vision request.
        // We expect `VNClassificationObservation` for image classification models.
        guard let observations = request.results as? [VNClassificationObservation],
              let topResult = observations.first else {
            throw ImageClassifierError.noResultsFound
        }

        let label = topResult.identifier
        let confidence = Double(topResult.confidence)

        // Return the structured classification result.
        return ClassificationResult(originalImage: uiImage, label: label, confidence: confidence)
    }

    /// Converts a `UIImage` into a `CVPixelBuffer` suitable for Core ML input.
    /// This involves scaling, cropping, and converting to a specific pixel format.
    ///
    /// - Parameter uiImage: The input `UIImage` to be converted.
    /// - Returns: An optional `CVPixelBuffer` or `nil` if conversion fails.
    private func prepareImageForModel(uiImage: UIImage) -> CVPixelBuffer? {
        // Ensure the image can be converted to CGImage, which is needed for Core Graphics.
        guard let cgImage = uiImage.cgImage else {
            print("Failed to get CGImage from UIImage.")
            return nil
        }

        // Determine the target size for the CVPixelBuffer based on the model's input requirements.
        let width = Int(modelInputSize.width)
        let height = Int(modelInputSize.height)

        // Define pixel buffer attributes.
        // `kCVPixelFormatType_32BGRA` is a common pixel format for Core ML image inputs.
        // It represents 4 bytes per pixel (Blue, Green, Red, Alpha).
        let attributes: [NSObject: AnyObject] = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue, // Allows drawing CGImage into it
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue, // Allows creating a CGContext from it
            kCVPixelBufferPixelFormatTypeKey: kCVPixelFormatType_32BGRA, // The required pixel format
            kCVPixelBufferWidthKey: width as AnyObject,
            kCVPixelBufferHeightKey: height as AnyObject,
            kCVPixelBufferIOSurfacePropertiesKey: [:] as AnyObject // For potential Metal/GPU optimizations
        ]

        var pixelBuffer: CVPixelBuffer?
        // Create the CVPixelBuffer with specified dimensions and attributes.
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         kCVPixelFormatType_32BGRA,
                                         attributes as CFDictionary,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess, let finalPixelBuffer = pixelBuffer else {
            print("Failed to create CVPixelBuffer with status: \(status)")
            return nil
        }

        // Lock the pixel buffer's base address to gain access to its memory for writing.
        CVPixelBufferLockBaseAddress(finalPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
        guard let pixelData = CVPixelBufferGetBaseAddress(finalPixelBuffer) else {
            print("Failed to get base address of CVPixelBuffer.")
            CVPixelBufferUnlockBaseAddress(finalPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
            return nil
        }

        // Create a Core Graphics context to draw the image into the pixel buffer.
        // This handles scaling and cropping the image to fit the model's input size.
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        guard let context = CGContext(data: pixelData,
                                      width: width,
                                      height: height,
                                      bitsPerComponent: 8, // 8 bits per color component (R, G, B, A)
                                      bytesPerRow: CVPixelBufferGetBytesPerRow(finalPixelBuffer),
                                      space: rgbColorSpace,
                                      bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue) else { // BGRA format
            print("Failed to create CGContext for CVPixelBuffer.")
            CVPixelBufferUnlockBaseAddress(finalPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
            return nil
        }

        // Draw the image into the context, applying scaling and center-cropping.
        // This ensures the image fits the model's input dimensions while preserving aspect ratio.
        let originalWidth = CGFloat(cgImage.width)
        let originalHeight = CGFloat(cgImage.height)
        let targetAspectRatio = modelInputSize.width / modelInputSize.height
        let originalAspectRatio = originalWidth / originalHeight

        var drawRect: CGRect
        if originalAspectRatio > targetAspectRatio {
            // Original image is wider than the target aspect ratio, crop horizontally.
            let scaledHeight = modelInputSize.height
            let scaledWidth = originalWidth * (scaledHeight / originalHeight)
            let xOffset = (modelInputSize.width - scaledWidth) / 2.0
            drawRect = CGRect(x: xOffset, y: 0, width: scaledWidth, height: scaledHeight)
        } else {
            // Original image is taller than the target aspect ratio, crop vertically.
            let scaledWidth = modelInputSize.width
            let scaledHeight = originalHeight * (scaledWidth / originalWidth)
            let yOffset = (modelInputSize.height - scaledHeight) / 2.0
            drawRect = CGRect(x: 0, y: yOffset, width: scaledWidth, height: scaledHeight)
        }

        // Flip the context vertically for drawing if needed (CGImage origin is bottom-left, CVPixelBuffer is top-left)
        context.translateBy(x: 0, y: modelInputSize.height)
        context.scaleBy(x: 1.0, y: -1.0)

        // Draw the CGImage into the context, which writes it into the CVPixelBuffer's memory.
        context.draw(cgImage, in: drawRect)

        // Unlock the pixel buffer.
        CVPixelBufferUnlockBaseAddress(finalPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))

        return finalPixelBuffer
    }
}

// MARK: - 4. SwiftUI View Integration (Example Usage)

/// A sample SwiftUI view demonstrating how to use the `ImageClassifierService`.
/// This view allows users to pick multiple photos, which are then classified
/// by the service, and the results are displayed in a grid.
///
/// `@available(iOS 18.0, *)` ensures this view is used only on platforms
/// where `@Observable` and `PhotosPicker` features are available.
@available(iOS 18.0, *)
struct SmartPhotoTaggerView: View {
    /// The observable service that handles Core ML logic and state.
    /// `@State` is used here to own the instance of the observable object,
    /// ensuring its lifecycle is managed by the view.
    @State private var classifierService = ImageClassifierService()

    /// State for the PhotosPicker selection.
    /// `[PhotosPickerItem]` allows selecting multiple images from the photo library.
    @State private var selectedPhotos: [PhotosPickerItem] = []

    var body: some View {
        NavigationView {
            VStack {
                // 4.1. PhotosPicker for image selection.
                // This allows the user to pick one or more images.
                PhotosPicker(
                    selection: $selectedPhotos, // Binds to the array of selected items
                    matching: .images, // Filters to only show image assets
                    photoLibrary: .shared() // Uses the default shared photo library
                ) {
                    Label("Select Photos to Tag", systemImage: "photo.stack.fill")
                        .font(.headline)
                        .padding()
                        .background(Color.accentColor)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()
                // Observe changes to `selectedPhotos` and trigger classification.
                // `onChange` is a powerful modifier for reacting to state changes.
                .onChange(of: selectedPhotos) { newPhotos in
                    // When new photos are selected, start the classification process.
                    // This is an async operation, so we launch a Task to handle it.
                    Task {
                        await classifierService.classifyImages(photos: newPhotos)
                    }
                }

                // 4.2. Loading Indicator.
                // Display a progress view while images are being classified.
                if classifierService.isLoading {
                    ProgressView("Classifying images...")
                        .padding()
                }

                // 4.3. Error Display.
                // Show any errors that occurred during the classification process.
                if let error = classifierService.error {
                    Text("Error: \(error.localizedDescription)")
                        .foregroundColor(.red)
                        .padding()
                }

                // 4.4. Display Classification Results.
                // A scrollable grid to show the original image and its classification tag.
                ScrollView {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 10)], spacing: 10) {
                        ForEach(classifierService.results) { result in
                            VStack(alignment: .leading) {
                                // Display the original image.
                                Image(uiImage: result.originalImage)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 100, maxHeight: 150)
                                    .cornerRadius(8)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                                    )
                                // Display the predicted label (capitalized for better presentation).
                                Text(result.label.capitalized)
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .lineLimit(1) // Prevent long labels from breaking layout
                                // Display the confidence score.
                                Text(String(format: "Confidence: %.2f%%", result.confidence * 100))
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                            .padding(5)
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 2)
                        }
                    }
                    .padding()
                }

                Spacer() // Pushes content to the top
            }
            .navigationTitle("Smart Photo Tagger")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
