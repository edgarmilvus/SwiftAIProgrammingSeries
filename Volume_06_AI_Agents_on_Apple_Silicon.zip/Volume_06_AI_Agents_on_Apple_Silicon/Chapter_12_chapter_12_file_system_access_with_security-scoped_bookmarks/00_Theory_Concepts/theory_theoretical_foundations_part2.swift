
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(macOS 11.0, iOS 18.0, *)
extension FileAccessManager {
    /// Reads data from a security-scoped URL.
    /// This method internally manages the access lifecycle (start/stop).
    /// - Parameter bookmarkData: The bookmark data for the file to read.
    /// - Returns: The contents of the file as Data.
    func readData(from bookmarkData: Data) async throws -> Data {
        let securityScopedURL = try await resolveAndStartAccessing(bookmarkData: bookmarkData)
        defer { stopAccessing(securityScopedURL: securityScopedURL) } // Ensure access is stopped
        
        let data = try Data(contentsOf: securityScopedURL)
        return data
    }
    
    /// Enumerates the contents of a security-scoped directory.
    /// This method internally manages the access lifecycle (start/stop).
    /// - Parameter bookmarkData: The bookmark data for the directory to enumerate.
    /// - Returns: An array of URLs representing the directory's contents.
    func enumerateDirectoryContents(from bookmarkData: Data) async throws -> [URL] {
        let securityScopedURL = try await resolveAndStartAccessing(bookmarkData: bookmarkData)
        defer { stopAccessing(securityScopedURL: securityScopedURL) }
        
        let fileManager = FileManager.default
        let contents = try fileManager.contentsOfDirectory(at: securityScopedURL, includingPropertiesForKeys: nil)
        return contents
    }
}

// Example usage within an AI Agent component:
@available(macOS 11.0, iOS 18.0, *)
class LLMDataLoader {
    private let fileAccessManager = FileAccessManager()
    private var llmBookmarkData: Data? // Stored bookmark data for the LLM

    func loadLLMModel() async throws -> String { // Returns a dummy string for simplicity
        guard let bookmarkData = llmBookmarkData else {
            throw FileAccessManager.FileAccessError.accessDenied // Or a more specific error
        }
        
        print("Attempting to load LLM model...")
        let modelData = try await fileAccessManager.readData(from: bookmarkData)
        print("Successfully read \(modelData.count) bytes for the LLM model.")
        
        // In a real scenario, you'd parse modelData and load your LLM
        // let model = try LLMModel(data: modelData)
        // return model
        
        return "LLM Model loaded successfully from \(modelData.count) bytes."
    }
    
    func setLLMModelBookmark(data: Data) {
        self.llmBookmarkData = data
        print("LLM Model bookmark data set.")
    }
}
