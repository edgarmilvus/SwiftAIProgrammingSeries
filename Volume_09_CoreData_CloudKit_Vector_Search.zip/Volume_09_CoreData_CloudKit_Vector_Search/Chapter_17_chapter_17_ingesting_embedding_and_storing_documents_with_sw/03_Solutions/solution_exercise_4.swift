
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import SwiftData

@Model
final class Note {
    var content: String
    var embedding: [Float]?
    
    init(content: String, embedding: [Float]? = nil) {
        self.content = content
        self.embedding = embedding
    }
}

@ModelActor
final class DuplicateDetectionActor {
    private let embeddingService: EmbeddingService
    
    init(modelContainer: ModelContainer, embeddingService: EmbeddingService) {
        self.modelExecutor = DefaultSerialModelExecutor(modelContext: ModelContext(modelContainer))
        self.embeddingService = embeddingService
    }
    
    func findSimilarNotes(to newNoteContent: String) async throws -> [Note] {
        guard let queryVector = embeddingService.generateEmbedding(for: newNoteContent) else {
            return []
        }
        
        let descriptor = FetchDescriptor<Note>()
        let allNotes = try modelContext.fetch(descriptor)
        
        // Filter by similarity threshold > 0.85
        let similarNotes = allNotes.filter { note in
            guard let noteEmbedding = note.embedding else { return false }
            return noteEmbedding.cosineSimilarity(to: queryVector) > 0.85
        }
        
        return similarNotes
    }
}

@MainActor
class NoteViewModel: ObservableObject {
    @Published var duplicateSuggestions: [Note] = []
    private var detectionTask: Task<Void, Never>?
    
    let container: ModelContainer
    let embeddingService: EmbeddingService
    
    init(container: ModelContainer, embeddingService: EmbeddingService) {
        self.container = container
        self.embeddingService = embeddingService
    }
    
    /// Called by the SwiftUI View on every keystroke (debounced)
    func textDidChange(newText: String) {
        // Conceptually: Debouncing logic
        // We cancel the previous task if the user is still typing
        detectionTask?.cancel()
        
        detectionTask = Task {
            // Small delay to simulate debouncing (wait for user to pause typing)
            try? await Task.sleep(for: .milliseconds(500))
            
            if Task.isCancelled { return }
            
            let actor = DuplicateDetectionActor(modelContainer: container, embeddingService: embeddingService)
            
            do {
                let results = try await actor.findSimilarNotes(to: newText)
                self.duplicateSuggestions = results
            } catch {
                print("Detection failed: \(error)")
            }
        }
    }
}
