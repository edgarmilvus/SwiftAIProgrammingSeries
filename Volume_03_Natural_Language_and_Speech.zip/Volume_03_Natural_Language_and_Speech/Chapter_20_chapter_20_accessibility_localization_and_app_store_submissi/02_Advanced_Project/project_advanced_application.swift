
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Speech
import NaturalLanguage
import AVFoundation // For audio recording
import Combine // For ObservableObject and @Published

// MARK: - 1. Custom Errors

/// Custom error types for the voice journaling manager, providing localized descriptions.
enum VoiceJournalError: Error, LocalizedError {
    case authorizationFailed(String)
    case audioEngineSetupFailed(String)
    case speechRecognitionFailed(String)
    case noAudioInput
    case sentimentAnalysisFailed(String)
    case invalidLocale(String)
    case recognizerUnavailable

    var errorDescription: String? {
        switch self {
        case .authorizationFailed(let reason):
            return NSLocalizedString("Speech recognition authorization failed: \(reason)", comment: "Authorization error")
        case .audioEngineSetupFailed(let reason):
            return NSLocalizedString("Audio engine setup failed: \(reason)", comment: "Audio engine error")
        case .speechRecognitionFailed(let reason):
            return NSLocalizedString("Speech recognition failed: \(reason)", comment: "Speech recognition error")
        case .noAudioInput:
            return NSLocalizedString("No audio input detected. Please ensure your microphone is working.", comment: "No audio input error")
        case .sentimentAnalysisFailed(let reason):
            return NSLocalizedString("Sentiment analysis failed: \(reason)", comment: "Sentiment analysis error")
        case .invalidLocale(let localeIdentifier):
            return NSLocalizedString("Invalid or unsupported locale for speech recognition: \(localeIdentifier)", comment: "Locale error")
        case .recognizerUnavailable:
            return NSLocalizedString("Speech recognizer is currently unavailable. Please check your device settings or network connection.", comment: "Recognizer unavailable error")
        }
    }
}

// MARK: - 2. Journal Entry Data Model

/// Represents a single journal entry, encapsulating the transcribed text,
/// its analyzed sentiment, and the creation timestamp.
struct JournalEntry: Identifiable, Codable {
    let id: UUID
    let timestamp: Date
    let text: String
    let sentiment: String // e.g., "Positive", "Negative", "Neutral"
    let sentimentScore: Double? // A numerical score, typically -1.0 to 1.0

    init(id: UUID = UUID(), timestamp: Date = Date(), text: String, sentiment: String, sentimentScore: Double? = nil) {
        self.id = id
        self.timestamp = timestamp
        self.text = text
        self.sentiment = sentiment
        self.sentimentScore = sentimentScore
    }
}

// MARK: - 3. Voice Journal Manager

/// `VoiceJournalManager` orchestrates speech recognition, transcription,
/// and sentiment analysis for voice journal entries.
///
/// It leverages Apple's `Speech` and `NaturalLanguage` frameworks,
/// demonstrating modern Swift 6 concurrency (`async/await`)
/// and robust error handling. It's designed to be integrated
/// with SwiftUI using `ObservableObject` and `@Published` properties.
@available(iOS 17.0, macOS 14.0, tvOS 17.0, watchOS 10.0, *) // SFSpeechRecognizer.supportedLocales is iOS 17+
class VoiceJournalManager: ObservableObject {
    // MARK: - Properties

    /// The speech recognizer instance, configured for a specific locale.
    /// It's optional because it might not be available for the requested locale.
    private var speechRecognizer: SFSpeechRecognizer?

    /// The recognition request that feeds audio data to the speech recognizer.
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?

    /// The recognition task that manages the speech recognition process.
    private var recognitionTask: SFSpeechRecognitionTask?

    /// The audio engine used to capture and process audio input from the microphone.
    private let audioEngine = AVAudioEngine()

    /// The locale used for speech recognition. This is crucial for localization.
    private let locale: Locale

    /// The NLTagger instance configured for sentiment analysis.
    /// `NLTagger` with the `.sentiment` tag scheme provides a numerical sentiment score.
    private let sentimentTagger = NLTagger(tagSchemes: [.sentiment])

    /// Published property indicating whether the manager is currently recording.
    /// Useful for UI updates (e.g., showing a recording indicator).
    @Published public private(set) var isRecording = false

    /// Published property providing real-time transcription updates.
    /// This allows the UI to show partial results as the user speaks.
    @Published public private(set) var currentTranscription: String = ""

    // MARK: - Initialization

    /// Initializes the `VoiceJournalManager` with a specified locale.
    ///
    /// - Parameter locale: The desired locale for speech recognition. Defaults to `Locale.current`.
    /// - Throws: `VoiceJournalError.invalidLocale` if the provided locale is not supported
    ///           by `SFSpeechRecognizer`.
    init(locale: Locale = Locale.current) throws {
        // Validate if the speech recognizer supports the given locale.
        guard SFSpeechRecognizer.supportedLocales().contains(where: { $0.identifier == locale.identifier }) else {
            throw VoiceJournalError.invalidLocale(locale.identifier)
        }
        self.locale = locale
        self.speechRecognizer = SFSpeechRecognizer(locale: locale)
        self.speechRecognizer?.delegate = self // Set delegate to monitor availability changes

        // Ensure the recognizer is available before proceeding.
        guard speechRecognizer?.isAvailable ?? false else {
            throw VoiceJournalError.recognizerUnavailable
        }

        // Initialize NLTagger's string property to prevent potential issues if accessed before analysis.
        sentimentTagger.string = ""
    }

    // MARK: - Authorization

    /// Requests necessary permissions for speech recognition and microphone usage.
    ///
    /// This is an `async` function and should be awaited. It's a prerequisite
    /// before any recording can begin.
    ///
    /// - Throws: `VoiceJournalError.authorizationFailed` if any required permission is denied
    ///           or if the speech recognizer becomes unavailable.
    public func requestAuthorization() async throws {
        // 1. Request microphone access.
        let audioPermissionStatus = await AVCaptureDevice.requestAccess(for: .audio)
        guard audioPermissionStatus else {
            throw VoiceJournalError.authorizationFailed("Microphone access denied by user.")
        }

        // 2. Request speech recognition access.
        let speechPermissionStatus = await SFSpeechRecognizer.requestAuthorization()
        switch speechPermissionStatus {
        case .authorized:
            // 3. Check if the speech recognizer is available for the specified locale.
            // This check is important as availability can change (e.g., no network for server-side recognition).
            guard speechRecognizer?.isAvailable ?? false else {
                throw VoiceJournalError.authorizationFailed("Speech recognizer is not available for locale \(locale.identifier).")
            }
            print("Speech recognition authorized and available.")
        case .denied:
            throw VoiceJournalError.authorizationFailed("User denied speech recognition authorization.")
        case .restricted:
            throw VoiceJournalError.authorizationFailed("Speech recognition restricted on this device (e.g., parental controls).")
        case .notDetermined:
            throw VoiceJournalError.authorizationFailed("Speech recognition authorization not determined.")
        @unknown default:
            throw VoiceJournalError.authorizationFailed("Unknown speech recognition authorization status.")
        }
    }

    // MARK: - Speech Recognition Lifecycle

    /// Starts the speech recognition process, capturing audio from the microphone.
    ///
    /// This method configures the audio session, sets up the `AVAudioEngine`,
    /// and initiates an `SFSpeechRecognitionTask`. Partial results are published
    /// via `currentTranscription`.
    ///
    /// - Throws: `VoiceJournalError` if there's an issue with audio setup or starting recognition.
    public func startRecording() async throws {
        // 1. Cancel any existing recognition task to ensure a clean start.
        recognitionTask?.cancel()
        self.recognitionTask = nil
        self.currentTranscription = ""
        self.isRecording = true

        do {
            // 2. Configure the audio session for recording.
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

            // 3. Create a new recognition request.
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = recognitionRequest else {
                throw VoiceJournalError.speechRecognitionFailed("Unable to create SFSpeechAudioBufferRecognitionRequest object.")
            }
            recognitionRequest.shouldReportPartialResults = true // Enable real-time transcription updates.

            // 4. Create and start the recognition task.
            // The completion handler processes results and errors.
            recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
                guard let self = self else { return }

                var isFinal = false
                if let result = result {
                    // Update the published currentTranscription for UI feedback.
                    self.currentTranscription = result.bestTranscription.formattedString
                    isFinal = result.isFinal
                }

                // If an error occurs or the recognition is final, stop recording and clean up.
                if error != nil || isFinal {
                    self.stopAudioEngineAndCleanup()
                    self.isRecording = false
                }
            }

            // 5. Install an audio tap on the input node to feed audio to the recognition request.
            let inputNode = audioEngine.inputNode
            let recordingFormat = inputNode.outputFormat(forBus: 0)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer: AVAudioPCMBuffer, when: AVAudioTime) in
                self.recognitionRequest?.append(buffer)
            }

            // 6. Prepare and start the audio engine.
            audioEngine.prepare()
            try audioEngine.start()

            print("Audio engine started. Recording...")
        } catch let error as VoiceJournalError {
            self.isRecording = false
            throw error // Re-throw custom errors.
        } catch {
            self.isRecording = false
            throw VoiceJournalError.audioEngineSetupFailed("Failed to start audio engine: \(error.localizedDescription)")
        }
    }

    /// Stops the current speech recognition process and returns the final transcribed text.
    ///
    /// This method gracefully stops the `AVAudioEngine` and awaits the final result
    /// from the `SFSpeechRecognitionTask`.
    ///
    /// - Returns: The final, complete transcribed text.
    /// - Throws: `VoiceJournalError.speechRecognitionFailed` if an error occurred during recognition.
    public func stopRecording() async throws -> String {
        guard isRecording else {
            // If not recording, return current transcription or an empty string.
            // This prevents issues if stopRecording is called redundantly.
            return currentTranscription
        }

        // 1. Stop the audio engine and end the recognition request.
        stopAudioEngineAndCleanup()
        isRecording = false // Set immediately to update UI.

        // 2. Await the final result from the recognition task.
        // `withCheckedContinuation` is used to bridge the callback-based `SFSpeechRecognitionTask`
        // completion into modern `async/await` syntax.
        return await withCheckedContinuation { continuation in
            var finalTranscription = self.currentTranscription // Capture current transcription as a fallback.

            // If there's an active recognition task, wait for its result.
            if let task = recognitionTask {
                Task {
                    do {
                        let result = try await task.result() // Await the final result.
                        finalTranscription = result.bestTranscription.formattedString
                        continuation.resume(returning: finalTranscription)
                    } catch {
                        // If the task fails, resume with an error.
                        continuation.resume(throwing: VoiceJournalError.speechRecognitionFailed("Failed to get final transcription: \(error.localizedDescription)"))
                    }
                }
            } else {
                // If no task was active, resume with the last known transcription.
                continuation.resume(returning: finalTranscription)
            }
            // Clear currentTranscription for the next recording.
            self.currentTranscription = ""
        }
    }

    /// Helper method to stop the audio engine and clean up recognition resources.
    private func stopAudioEngineAndCleanup() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0) // Remove the tap to stop feeding audio.
        recognitionRequest?.endAudio() // Signal the end of audio input.
        recognitionRequest = nil // Release the request.
        // The recognitionTask is implicitly released when its completion handler is called,
        // or explicitly set to nil after awaiting its result in stopRecording.
    }

    // MARK: - Natural Language Processing (Sentiment Analysis)

    /// Performs sentiment analysis on the given text using `NLTagger`.
    ///
    /// `NLTagger` with the `.sentiment` tag scheme provides a sentiment score
    /// ranging from -1.0 (very negative) to 1.0 (very positive).
    ///
    /// - Parameter text: The text string to be analyzed for sentiment.
    /// - Returns: A tuple containing a descriptive sentiment string ("Positive", "Negative", "Neutral")
    ///            and the raw numerical sentiment score (Double?), or nil if analysis fails.
    public func analyzeSentiment(text: String) -> (sentiment: String, score: Double?) {
        guard !text.isEmpty else { return ("Neutral", 0.0) }

        // Set the string for the NLTagger.
        sentimentTagger.string = text
        // Get the sentiment tag for the entire text (paragraph unit).
        let (sentimentTag, _) = sentimentTagger.tag(at: text.startIndex, unit: .paragraph, scheme: .sentiment)

        if let sentimentTag = sentimentTag, let score = Double(sentimentTag.rawValue) {
            let sentimentDescription: String
            // Define thresholds for categorizing sentiment. These can be tuned.
            if score > 0.3 {
                sentimentDescription = "Positive"
            } else if score < -0.3 {
                sentimentDescription = "Negative"
            } else {
                sentimentDescription = "Neutral"
            }
            return (sentimentDescription, score)
        } else {
            // Fallback if sentiment analysis fails (e.g., unsupported language, no sentiment detected).
            print("Warning: Could not perform sentiment analysis for text: \"\(text)\"")
            return ("Neutral", nil)
        }
    }
}

// MARK: - SFSpeechRecognizerDelegate Extension

/// Extension to conform to `SFSpeechRecognizerDelegate`.
/// This delegate allows monitoring the availability of the speech recognizer,
/// which can change due to network conditions or system settings.
@available(iOS 17.0, macOS 14.0, tvOS 17.0, watchOS 10.0, *)
extension VoiceJournalManager: SFSpeechRecognizerDelegate {
    /// Called when the availability of the speech recognizer changes.
    ///
    /// - Parameters:
    ///   - speechRecognizer: The recognizer whose availability changed.
    ///   - available: A boolean indicating if the recognizer is currently available.
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if !available {
            print("Speech recognizer for locale \(speechRecognizer.locale.identifier) is no longer available.")
            // In a real app, you might want to inform the user or disable recording UI.
            // For this example, we'll just log the change.
            if isRecording {
                // Attempt to stop recording if it was in progress, but the recognizer became unavailable.
                Task {
                    _ = try? await stopRecording()
                    await MainActor.run {
                        self.isRecording = false
                        self.currentTranscription = ""
                    }
                }
            }
        } else {
            print("Speech recognizer for locale \(speechRecognizer.locale.identifier) is now available.")
        }
    }
}

// MARK: - 4. Example Usage in an App Context (e.g., SwiftUI ViewModel)

/// A `ViewModel` class for a hypothetical "Mindful Journal" SwiftUI application.
/// It acts as an intermediary between the UI and the `VoiceJournalManager`,
/// managing app state and handling user interactions.
@available(iOS 17.0, macOS 14.0, tvOS 17.0, watchOS 10.0, *)
class JournalViewModel: ObservableObject {
    /// Published array of `JournalEntry` objects, representing the user's journal.
    @Published var journalEntries: [JournalEntry] = []
    /// Published flag indicating if an asynchronous operation is in progress (e.g., recording, processing).
    @Published var isLoading = false
    /// Published string for displaying error messages to the user.
    @Published var errorMessage: String?
    /// Published string for showing the real-time transcription to the user.
    @Published var currentTranscription: String = ""
    /// Published flag indicating if the manager is currently recording.
    @Published var isRecording: Bool = false

    /// The instance of `VoiceJournalManager` responsible for core speech and NLP logic.
    private var voiceJournalManager: VoiceJournalManager! // Force unwrap after successful init, handled in init.
    /// A `Cancellable` set to manage Combine subscriptions.
    private var cancellables = Set<AnyCancellable>()

    init() {
        do {
            // Initialize VoiceJournalManager with the device's current locale.
            // For a localized app, this could be driven by user settings or app configuration.
            self.voiceJournalManager = try VoiceJournalManager(locale: Locale.current)

            // Subscribe to published properties from VoiceJournalManager to update ViewModel's own published properties.
            voiceJournalManager.$currentTranscription
                .assign(to: &$currentTranscription)
                .store(in: &cancellables)

            voiceJournalManager.$isRecording
                .assign(to: &$isRecording)
                .store(in: &cancellables)

        } catch {
            // Handle initialization errors, typically by displaying them to the user.
            self.errorMessage = error.localizedDescription
            print("Failed to initialize VoiceJournalManager: \(error.localizedDescription)")
        }
    }

    /// Requests necessary audio and speech recognition permissions from the user.
    /// This should be called early in the app lifecycle, e.g., on first launch.
    func requestPermissions() async {
        isLoading = true
        errorMessage = nil
        do {
            try await voiceJournalManager.requestAuthorization()
            print("Permissions granted.")
        } catch {
            errorMessage = error.localizedDescription
            print("Permission error: \(error.localizedDescription)")
        }
        isLoading = false
    }

    /// Initiates a new voice journal entry recording.
    ///
    /// It starts the `VoiceJournalManager`'s recording process. Errors during startup
    /// are caught and displayed.
    func startJournalEntry() {
        guard voiceJournalManager != nil else {
            errorMessage = "Journal manager not initialized."
            return
        }
        errorMessage = nil
        isLoading = true
        // Use a Task to run the async startRecording method.
        Task {
            do {
                try await voiceJournalManager.startRecording()
                print("Recording started.")
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    print("Error starting recording: \(error.localizedDescription)")
                    self.isLoading = false
                }
            }
        }
    }

    /// Stops the current recording, transcribes the speech, performs sentiment analysis,
    /// and saves the resulting `JournalEntry`.
    ///
    /// This method is `async` as it awaits the final transcription.
    func stopJournalEntry() {
        guard voiceJournalManager != nil, voiceJournalManager.isRecording else {
            errorMessage = "Not currently recording."
            return
        }
        isLoading = true
        // Use a Task to run the async stopRecording and subsequent processing.
        Task {
            do {
                let transcribedText = try await voiceJournalManager.stopRecording()
                print("Recording stopped. Transcribed text: \(transcribedText)")

                // Ensure there's actual speech before processing.
                guard !transcribedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                    await MainActor.run {
                        self.errorMessage = "No speech detected or transcribed."
                        self.isLoading = false
                    }
                    return
                }

                // Perform sentiment analysis on the transcribed text.
                let (sentiment, score) = voiceJournalManager.analyzeSentiment(text: transcribedText)
                let newEntry = JournalEntry(text: transcribedText, sentiment: sentiment, sentimentScore: score)

                // Update UI on the main actor.
                await MainActor.run {
                    self.journalEntries.append(newEntry)
                    self.isLoading = false
                    self.errorMessage = nil
                    print("Journal entry saved: \(newEntry.text) [Sentiment: \(newEntry.sentiment)]")
                }
            } catch {
                // Handle errors during stopping or processing.
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                    print("Error stopping recording or processing entry: \(error.localizedDescription)")
                }
            }
        }
    }
}

// MARK: - 5. Example Usage (Simulated Main App Flow)

/// This `main` struct simulates the lifecycle and interaction with the `JournalViewModel`
/// in a console-based environment, demonstrating the component's functionality.
@available(iOS 17.0, macOS 14.0, tvOS 17.0, watchOS 10.0, *)
@main
struct VoiceJournalApp {
    static func main() async {
        let viewModel = JournalViewModel()

        print("--- Voice Journal App Simulation ---")

        // 1. Request permissions (essential first step)
        print("\nRequesting permissions...")
        await viewModel.requestPermissions()
        if let error = viewModel.errorMessage {
            print("Permission error: \(error)")
            return // Exit if permissions are not granted.
        }

        // 2. Simulate starting a recording for a positive entry.
        print("\nSimulating start recording for a positive entry...")
        viewModel.startJournalEntry()

        // Give some time for "speech" and partial results.
        try? await Task.sleep(for: .seconds(2))
        await MainActor.run {
            viewModel.currentTranscription = "This is a test entry, and I feel quite happy about it."
            print("Partial transcription: \(viewModel.currentTranscription)")
        }
        try? await Task.sleep(for: .seconds(2))

        // 3. Simulate stopping a recording and processing the entry.
        print("\nSimulating stop recording and processing entry...")
        await viewModel.stopJournalEntry()

        // Output results for the first entry.
        if let error = viewModel.errorMessage {
            print("Error during journaling: \(error)")
        } else {
            print("\n--- Journal Entries (After 1st Entry) ---")
            for entry in viewModel.journalEntries {
                print("[\(entry.timestamp.formatted())] Text: \"\(entry.text)\" | Sentiment: \(entry.sentiment) (\(entry.sentimentScore ?? 0.0, format: .number.precision(.fractionLength(2))))")
            }
        }

        // 4. Simulate another entry, this time a negative one.
        print("\nSimulating another entry (a negative one)...")
        viewModel.startJournalEntry()
        try? await Task.sleep(for: .seconds(2))
        await MainActor.run {
            viewModel.currentTranscription = "I'm really frustrated with the current situation, it's quite annoying."
            print("Partial transcription: \(viewModel.currentTranscription)")
        }
        try? await Task.sleep(for: .seconds(2))
        await viewModel.stopJournalEntry()

        // Output results for all entries.
        if let error = viewModel.errorMessage {
            print("Error during journaling: \(error)")
        } else {
            print("\n--- Updated Journal Entries (After 2nd Entry) ---")
            for entry in viewModel.journalEntries {
                print("[\(entry.timestamp.formatted())] Text: \"\(entry.text)\" | Sentiment: \(entry.sentiment) (\(entry.sentimentScore ?? 0.0, format: .number.precision(.fractionLength(2))))")
            }
        }

        // 5. Simulate an empty entry (no speech).
        print("\nSimulating an empty entry (no speech detected)...")
        viewModel.startJournalEntry()
        try? await Task.sleep(for: .seconds(3)) // User speaks nothing
        await viewModel.stopJournalEntry()
        if let error = viewModel.errorMessage {
            print("Error during journaling (empty entry): \(error)")
        } else {
            print("Empty entry processed. No new entry added.")
        }


        print("\n--- End of Simulation ---")
    }
}
