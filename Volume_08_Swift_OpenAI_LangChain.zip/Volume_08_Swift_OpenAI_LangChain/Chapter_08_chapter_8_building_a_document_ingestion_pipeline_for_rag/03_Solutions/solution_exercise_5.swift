
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import PDFKit

struct EnrichedChunk: Sendable {
    let text: String
    let metadata: [String: String]
}

@available(iOS 18.0, macOS 15.0, *)
struct PDFMetadataExtractor {
    
    func extractMetadata(from url: URL) -> [String: String] {
        guard let document = PDFDocument(url: url) else { return [:] }
        
        let attributes = document.documentAttributes
        var metadata: [String: String] = [:]
        
        // Map PDFKit attributes to a clean dictionary
        if let title = attributes?[PDFDocumentAttribute.titleAttribute] as? String {
            metadata["title"] = title
        }
        if let author = attributes?[PDFDocumentAttribute.authorAttribute] as? String {
            metadata["author"] = author
        }
        if let creationDate = attributes?[PDFDocumentAttribute.creationDateAttribute] as? Date {
            metadata["creationDate"] = ISO8601DateFormatter().string(from: creationDate)
        }
        
        // Fallback for missing metadata
        if metadata.isEmpty {
            metadata["title"] = "Unknown Title"
            metadata["author"] = "Unknown Author"
        }
        
        return metadata
    }
}

@available(iOS 18.0, macOS 15.0, *)
actor MetadataEnrichedLoader {
    private let extractor = PDFMetadataExtractor()
    private let splitter = RecursiveTextSplitter(maxChunkSize: 1000, overlap: 100)

    func loadAndEnrich(url: URL) async throws -> [EnrichedChunk] {
        // 1. Extract Metadata
        let metadata = extractor.extractMetadata(from: url)
        
        // 2. Load PDF Document
        guard let document = PDFDocument(url: url) else {
            throw LoaderError.fileNotFound
        }
        
        // 3. Extract all text from all pages
        var fullText = ""
        for i in 0..<document.pageCount {
            if let page = document.page(at: i) {
                fullText += page.string ?? "" + "\n"
            }
        }
        
        // 4. Split text into chunks
        let rawChunks = await splitter.split(text: fullText)
        
        // 5. Enrich each chunk with the metadata
        return rawChunks.map { chunkText in
            EnrichedChunk(
                text: chunkText,
                metadata: metadata
            )
        }
    }
}
