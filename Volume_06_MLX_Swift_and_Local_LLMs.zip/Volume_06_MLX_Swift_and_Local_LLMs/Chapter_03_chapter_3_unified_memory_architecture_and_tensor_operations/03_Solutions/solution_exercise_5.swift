
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import MLX

@available(iOS 18.0, macOS 15.0, *)
func meanAbsoluteError(predictions: MLXArray, targets: MLXArray) -> MLXArray {
    precondition(predictions.shape == targets.shape, "Predictions and targets must have the same shape.")

    // 1. Calculate the difference: predictions - targets
    let differences = predictions - targets

    // 2. Take the absolute value of the differences: |predictions - targets|
    let absoluteDifferences = MLX.abs(differences)

    // 3. Compute the mean of the absolute differences
    let maeLoss = MLX.mean(absoluteDifferences)

    return maeLoss
}

@available(iOS 18.0, macOS 15.0, *)
func demonstrateMAELossAndGradient() {
    print("--- MAE Loss and Gradient Demonstration ---")
    let batchSize = 10
    let numOutputs = 1 // For simple regression, typically one output per sample

    // Generate sample predictions (these are what we want to take gradients with respect to)
    let predictions = MLXArray.random(
        low: 0.0, high: 10.0,
        shape: [batchSize, numOutputs],
        dtype: .float32,
        requiresGrad: true // Crucial for gradient computation with respect to predictions
    )
    print("Predictions MLXArray created with shape: \(predictions.shape), requiresGrad: \(predictions.requiresGrad)")

    // Generate sample target values (targets do not need gradients)
    let targets = MLXArray.random(
        low: 0.0, high: 10.0,
        shape: [batchSize, numOutputs],
        dtype: .float32
    )
    print("Targets MLXArray created with shape: \(targets.shape), requiresGrad: \(targets.requiresGrad)")

    // Define the function for valueAndGradient.
    // This closure takes the predictions (which is our 'x' for gradient computation)
    // and returns the scalar MAE loss.
    let computeLoss = { (preds: MLXArray) -> MLXArray in
        return meanAbsoluteError(predictions: preds, targets: targets)
    }

    // Compute the loss and its gradient with respect to predictions
    // argnums: 0 specifies that we want the gradient with respect to the first argument of the closure (preds)
    let (maeLossValue, gradientOfLoss) = MLX.valueAndGradient(computeLoss, argnums: 0)(predictions)

    print("\nMean Absolute Error (MAE) Loss: \(maeLossValue.item())")
    print("Gradient of MAE Loss with respect to Predictions Shape: \(gradientOfLoss.shape)")
    print("Gradient of MAE Loss with respect to Predictions (first 5 elements):")
    // Evaluate the gradient MLXArray to get its data
    let gradData = gradientOfLoss.flattened().data.map { $0.floatValue }
    print(gradData.prefix(5))

    // For MAE, the gradient of |x| is sign(x).
    // Let's manually verify for a few elements:
    print("\nManual gradient check for first 3 elements:")
    for i in 0..<min(3, batchSize) {
        let pred = predictions[i, 0].item()
        let target = targets[i, 0].item()
        let diff = pred - target
        let expectedGrad: Float = diff > 0 ? 1.0 : (diff < 0 ? -1.0 : 0.0) // Subgradient at 0
        let actualGrad = gradientOfLoss[i, 0].item()
        print("  Pred: \(pred), Target: \(target), Diff: \(diff), Expected Grad: \(expectedGrad), Actual Grad: \(actualGrad)")
    }
}

// Example usage:
// demonstrateMAELossAndGradient()
