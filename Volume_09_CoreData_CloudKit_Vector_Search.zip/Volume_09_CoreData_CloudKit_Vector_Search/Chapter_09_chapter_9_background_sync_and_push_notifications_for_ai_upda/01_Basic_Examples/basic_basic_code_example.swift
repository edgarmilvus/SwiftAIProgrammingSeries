
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import UserNotifications
import CoreData
import BackgroundTasks
import CloudKit

// MARK: - Models

/// Represents the metadata received via a silent push notification
/// to trigger an AI-related update.
struct AIUpdatePayload: Codable, Sendable {
    let updateID: UUID
    let type: UpdateType
    let timestamp: Date

    enum UpdateType: String, Codable, Sendable {
        case newEmbedding    // A new vector was generated for a document
        case modelUpdate     // A new local MLModel is available
        case knowledgeGraph  // The semantic relationship map has changed
    }
}

// MARK: - Sync Engine

/// The `SyncEngine` is an actor responsible for handling all background 
/// synchronization logic. Using an `actor` ensures that our background 
/// synchronization processes are thread-safe and do not cause data races 
/// with the main UI thread when updating Core Data.
@available(iOS 18.0, *)
actor SyncEngine {
    
    /// The shared instance of the sync engine.
    static let shared = SyncEngine()
    
    /// A private initializer to enforce singleton pattern.
    private init() {}

    /// Performs the actual synchronization of AI assets.
    /// - Parameter payload: The decoded payload from the push notification.
    /// - Returns: A boolean indicating if the sync was successful.
    func performSync(with payload: AIUpdatePayload) async -> Bool {
        print("🚀 Starting background sync for type: \(payload.type)")
        
        // Simulate network latency for fetching high-dimensional vectors
        // In a real app, this would be a URLSession call to your backend.
        try? await Task.sleep(for: .seconds(3))
        
        do {
            switch payload.type {
            case .newEmbedding:
                try await fetchAndStoreNewEmbeddings()
            case .modelUpdate:
                try await downloadNewMLModel()
            case .knowledgeGraph:
                try await rebuildLocalVectorIndex()
            }
            
            print("✅ Sync completed successfully for \(payload.updateID)")
            return true
        } catch {
            print("❌ Sync failed: \(error.localizedDescription)")
            return false
        }
    }

    private func fetchAndStoreNewEmbeddings() async throws {
        // Logic to fetch new vector data from CloudKit or a REST API
        // and insert it into the Core Data managed object context.
        print("📥 Fetching new semantic embeddings...")
    }

    private func downloadNewMLModel() async throws {
        // Logic to download a new .mlmodelc file and update the local inference engine.
        print("📦 Downloading updated MLModel...")
    }

    private func rebuildLocalVectorIndex() async throws {
        // Logic to re-index local text into vectors using CoreML/Accelerate.
        print("🔄 Rebuilding local vector search index...")
    }
}

// MARK: - Notification Manager

/// `NotificationManager` handles the registration and permission 
/// lifecycle for remote notifications.
@available(iOS 18.0, *)
@MainActor
class NotificationManager: NSObject, UNUserNotificationCenterDelegate {
    
    static let shared = NotificationManager()
    
    private override init() {
        super.init()
    }

    /// Requests permission from the user to receive notifications.
    /// Note: For silent pushes, we don't necessarily need user permission 
    /// for the 'alert', but the app must be registered with APNs.
    func requestPermissions() async {
        let center = UNUserNotificationCenter.current()
        do {
            let granted = try await center.requestAuthorization(options: [.alert, .sound, .badge])
            if granted {
                print("🔔 Notification permissions granted.")
                await registerForRemoteNotifications()
            }
        } catch {
            print("❌ Failed to request notification permissions: \(error)")
        }
    }

    /// Registers the device with Apple Push Notification service (APNs).
    private func registerForRemoteNotifications() async {
        // This must be called from the MainActor as it interacts with UIApplication.
        // In a real app, this is typically called in AppDelegate.
        print("📡 Registering for remote notifications...")
    }
}

// MARK: - App Delegate / Entry Point

@main
struct AuraAIApp: App {
    // In SwiftUI, the AppDelegate is attached via @UIApplicationDelegateAdaptor
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

@available(iOS 18.0, *)
class AppDelegate: NSObject, UIApplicationDelegate {
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        print("🌱 Aura AI App Started")
        
        // Register background task identifiers
        BGTaskScheduler.shared.register(forTaskWithIdentifier: "com.aura.ai.sync", using: nil) { task in
            self.handleAppRefresh(task: task as! BGAppRefreshTask)
        }
        
        return true
    }

    /// This is the critical entry point for Silent Push Notifications.
    /// When a push with `content-available: 1` arrives, this method is called.
    func application(_ application: UIApplication, 
                     didReceiveRemoteNotification userInfo: [AnyHashable : Any], 
                     fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        
        print("📩 Received silent push notification: \(userInfo)")

        // 1. Parse the payload
        guard let data = try? JSONSerialization.data(withJSONObject: userInfo),
              let payload = try? JSONDecoder().decode(AIUpdatePayload.self, from: data) else {
            completionHandler(.failed)
            return
        }

        // 2. Hand off to the SyncEngine (an Actor) to perform work off the main thread
        Task {
            let success = await SyncEngine.shared.performSync(with: payload)
            
            // 3. Inform the OS of the result so it can manage battery/resource budgets
            if success {
                completionHandler(.newData)
            } else {
                completionHandler(.failed)
            }
        }
    }

    /// Fallback mechanism: If a push is missed, the OS may trigger a standard background fetch.
    private func handleAppRefresh(task: BGAppRefreshTask) {
        // Schedule a new background task to ensure continuity
        scheduleNextBackgroundSync()

        let newTask = Task {
            // Perform a generic sync check
            let dummyPayload = AIUpdatePayload(updateID: UUID(), type: .knowledgeGraph, timestamp: Date())
            let success = await SyncEngine.shared.performSync(with: dummyPayload)
            return success
        }

        task.expirationHandler = {
            // If the OS decides to kill the task, stop the work immediately
            newTask.cancel()
        }

        Task {
            let success = await newTask.value
            task.setTaskCompleted(success: success)
        }
    }

    private func scheduleNextBackgroundSync() {
        let request = BGAppRefreshTaskRequest(identifier: "com.aura.ai.sync")
        request.earliestBeginDate = Date(timeIntervalSinceNow: 15 * 60) // 15 minutes from now
        try? BGTaskScheduler.shared.submit(request)
    }
}
