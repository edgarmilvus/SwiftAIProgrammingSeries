
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import UIKit // For UI-related types like UIView, UIViewController, CGRect
import OnScreenAwareness // Conceptual framework import

// MARK: - Conceptual OnScreenAwareness Framework APIs

/// @available(iOS 18.0, *)
/// A conceptual protocol that defines the capabilities of an object that can provide
/// a snapshot of its currently displayed on-screen content to the Apple Intelligence system.
/// Real-world content providers might be UIKit views, SwiftUI views, or custom renderers.
protocol OnScreenContentProvider: AnyObject {
    /// Provides a snapshot of the content currently visible on screen.
    /// - Returns: An `OnScreenContentSnapshot` containing the content and its metadata,
    ///            or `nil` if no relevant content is currently available.
    func currentContentSnapshot() -> OnScreenContentSnapshot?
}

/// @available(iOS 18.0, *)
/// A conceptual protocol for delegates that receive and handle actions suggested by
/// the Apple Intelligence system based on the app's provided on-screen content.
protocol OnScreenAwarenessDelegate: AnyObject {
    /// Called when the Apple Intelligence system suggests an action for the app to perform.
    /// - Parameters:
    ///   - manager: The `OnScreenAwarenessManager` instance.
    ///   - action: The `OnScreenAction` suggested by the system.
    ///   - contentIdentifier: An identifier for the content that the action pertains to.
    func onScreenAwarenessManager(_ manager: OnScreenAwarenessManager,
                                  didReceive action: OnScreenAction,
                                  forContentWithIdentifier contentIdentifier: String) async -> OnScreenActionResult
}

/// @available(iOS 18.0, *)
/// Represents a snapshot of content displayed on screen.
/// This could include text, images, or other UI elements along with their bounding boxes.
struct OnScreenContentSnapshot: Identifiable {
    let id: String // Unique identifier for this content snapshot
    let textContent: String?
    let imageContent: UIImage? // Conceptual: could be a data representation or reference
    let boundingBox: CGRect // The frame of the content within the screen coordinates
    let contentRects: [CGRect]? // Optional: more granular bounding boxes for sub-elements (e.g., words)
    let semanticTags: Set<String>? // Optional: e.g., "document", "chat_message", "email_body"

    /// Initializer for a text-based content snapshot.
    init(id: String, textContent: String, boundingBox: CGRect, contentRects: [CGRect]? = nil, semanticTags: Set<String>? = nil) {
        self.id = id
        self.textContent = textContent
        self.imageContent = nil
        self.boundingBox = boundingBox
        self.contentRects = contentRects
        self.semanticTags = semanticTags
    }

    /// Initializer for an image-based content snapshot.
    init(id: String, imageContent: UIImage, boundingBox: CGRect, semanticTags: Set<String>? = nil) {
        self.id = id
        self.textContent = nil
        self.imageContent = imageContent
        self.boundingBox = boundingBox
        self.semanticTags = semanticTags
    }
}

/// @available(iOS 18.0, *)
/// Represents an action suggested by the Apple Intelligence system.
/// The action `type` would determine how the app should interpret and execute it.
struct OnScreenAction {
    enum ActionType: String, Codable {
        case summarizeDocument
        case extractEntities
        case translateText
        case createEvent
        case customAppAction // For app-specific actions
    }

    let type: ActionType
    let parameters: [String: AnyCodable] // Parameters needed to execute the action (e.g., target language)
    let userFacingTitle: String // Title to display to the user (e.g., "Summarize")
}

/// @available(iOS 18.0, *)
/// Represents the result of an action execution.
enum OnScreenActionResult {
    case success
    case failure(Error)
    case notHandled // If the app chooses not to handle this specific action
}

/// @available(iOS 18.0, *)
/// A type-erased wrapper for `Any` to allow `OnScreenAction.parameters` to hold diverse types.
/// In a real scenario, `Codable` or specific serialization would be used.
struct AnyCodable: Codable {
    let value: Any

    init(_ value: Any) {
        self.value = value
    }

    // Simplified Codable conformance for demonstration.
    // Real implementation would require more robust handling of different types.
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let string = try? container.decode(String.self) {
            value = string
        } else if let int = try? container.decode(Int.self) {
            value = int
        } else if let bool = try? container.decode(Bool.self) {
            value = bool
        } else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Unsupported type for AnyCodable")
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        if let string = value as? String {
            try container.encode(string)
        } else if let int = value as? Int {
            try container.encode(int)
        } else if let bool = value as? Bool {
            try container.encode(bool)
        } else {
            throw EncodingError.invalidValue(value, .init(codingPath: encoder.codingPath, debugDescription: "Unsupported type for AnyCodable"))
        }
    }
}


/// @available(iOS 18.0, *)
/// The central manager for interacting with the Apple Intelligence On-Screen Awareness system.
/// This is typically a singleton that coordinates content provision and action reception.
class OnScreenAwarenessManager {
    static let shared = OnScreenAwarenessManager() // Singleton instance

    private var currentContentProvider: OnScreenContentProvider?
    private weak var delegate: OnScreenAwarenessDelegate?

    private init() {
        // Initialize internal state, potentially register with system services
        print("OnScreenAwarenessManager initialized.")
    }

    /// Registers a content provider that the manager will query for on-screen content.
    /// Only one active content provider is typically supported at a time for a given app.
    /// - Parameter provider: The object (e.g., a UIViewController) that can supply
    ///                       `OnScreenContentSnapshot` instances.
    func registerContentProvider(_ provider: OnScreenContentProvider) {
        self.currentContentProvider = provider
        print("Registered content provider: \(type(of: provider))")
        // In a real system, this would trigger the system to start observing the provider
        // or poll it for content.
        simulateContentPolling() // Simulate content polling
    }

    /// Unregisters the current content provider.
    func unregisterContentProvider() {
        self.currentContentProvider = nil
        print("Unregistered content provider.")
    }

    /// Sets the delegate to receive action suggestions from the system.
    /// - Parameter delegate: The object that will handle `OnScreenAction` instances.
    func setDelegate(_ delegate: OnScreenAwarenessDelegate) {
        self.delegate = delegate
        print("Set OnScreenAwarenessDelegate: \(type(of: delegate))")
    }

    /// Simulates the system polling for content from the registered provider.
    /// In a real system, this would be triggered by OS events (e.g., app becoming active,
    /// content changing, user invoking AI features).
    private func simulateContentPolling() {
        // Simulate a delay for system processing
        DispatchQueue.global().asyncAfter(deadline: .now() + 2.0) { [weak self] in
            guard let self = self, let provider = self.currentContentProvider else { return }

            if let snapshot = provider.currentContentSnapshot() {
                print("OnScreenAwarenessManager: Received content snapshot (ID: \(snapshot.id)) from provider.")
                // In a real system, this snapshot would be sent to the AI engine for analysis.
                self.simulateActionSuggestion(for: snapshot)
            } else {
                print("OnScreenAwarenessManager: Content provider returned nil snapshot.")
            }
        }
    }

    /// Simulates the AI system generating an action and sending it to the delegate.
    private func simulateActionSuggestion(for snapshot: OnScreenContentSnapshot) {
        guard let delegate = self.delegate, let text = snapshot.textContent else { return }

        // Based on the content, simulate a relevant action.
        let action: OnScreenAction
        if text.contains("meeting") || text.contains("event") {
            action = OnScreenAction(type: .createEvent,
                                    parameters: ["title": AnyCodable("Meeting with John"), "date": AnyCodable("Tomorrow")],
                                    userFacingTitle: "Create Calendar Event")
        } else if text.count > 100 {
            action = OnScreenAction(type: .summarizeDocument,
                                    parameters: ["maxLength": AnyCodable(50)],
                                    userFacingTitle: "Summarize Document")
        } else {
            action = OnScreenAction(type: .extractEntities,
                                    parameters: [:],
                                    userFacingTitle: "Extract Key Information")
        }

        print("OnScreenAwarenessManager: Simulating action suggestion: '\(action.userFacingTitle)'")

        // Dispatch to the main actor as UI updates might be needed after action execution.
        Task { @MainActor in
            let result = await delegate.onScreenAwarenessManager(self, didReceive: action, forContentWithIdentifier: snapshot.id)
            print("OnScreenAwarenessManager: Delegate handled action with result: \(result)")
        }
    }
}

// MARK: - App-Specific Implementation

/// @available(iOS 18.0, *)
/// A simple UIViewController that displays document text and acts as an
/// `OnScreenContentProvider` and `OnScreenAwarenessDelegate`.
class DocumentViewerController: UIViewController, OnScreenContentProvider, OnScreenAwarenessDelegate {

    private let documentTextView: UITextView = {
        let textView = UITextView()
        textView.isEditable = false
        textView.font = UIFont.preferredFont(forTextStyle: .body)
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.backgroundColor = .systemBackground
        textView.layer.cornerRadius = 8
        textView.layer.borderColor = UIColor.systemGray3.cgColor
        textView.layer.borderWidth = 1
        textView.textContainerInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        return textView
    }()

    private let documentContent: String

    /// Initializes the document viewer with specific text content.
    init(documentContent: String) {
        self.documentContent = documentContent
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGroupedBackground
        title = "My Document"

        setupUI()
        documentTextView.text = documentContent

        // 1. Register as content provider and delegate
        OnScreenAwarenessManager.shared.registerContentProvider(self)
        OnScreenAwarenessManager.shared.setDelegate(self)

        print("DocumentViewerController: viewDidLoad completed. Ready for On-Screen Awareness.")
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Ensure content snapshot reflects correct bounding box after layout
        // In a real app, this might be more dynamic based on scroll position, etc.
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        // 5. Unregister when content is no longer visible or relevant
        OnScreenAwarenessManager.shared.unregisterContentProvider()
        // Note: Delegate might also be unset if the controller is being deallocated.
    }

    private func setupUI() {
        view.addSubview(documentTextView)
        NSLayoutConstraint.activate([
            documentTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            documentTextView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            documentTextView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            documentTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    // MARK: - OnScreenContentProvider Conformance

    /// /// @available(iOS 18.0, *)
    /// Provides the current text content of the document viewer as an `OnScreenContentSnapshot`.
    func currentContentSnapshot() -> OnScreenContentSnapshot? {
        guard let window = view.window else { return nil }

        // Calculate the bounding box of the text view in screen coordinates
        let boundingBoxInWindow = documentTextView.convert(documentTextView.bounds, to: window)
        let boundingBoxInScreen = window.convert(boundingBoxInWindow, to: window.screen.coordinateSpace)

        // Generate a unique ID for this content instance.
        // In a real app, this might be tied to a document ID or view hierarchy.
        let contentId = "document-\(self.hashValue)-\(UUID().uuidString)"

        print("DocumentViewerController: Generating content snapshot for ID: \(contentId)")
        return OnScreenContentSnapshot(
            id: contentId,
            textContent: documentTextView.text,
            boundingBox: boundingBoxInScreen,
            semanticTags: ["document", "text_content"]
        )
    }

    // MARK: - OnScreenAwarenessDelegate Conformance

    /// /// @available(iOS 18.0, *)
    /// Handles incoming `OnScreenAction` suggestions from the `OnScreenAwarenessManager`.
    /// This method is marked `async` because action execution might involve asynchronous operations.
    /// It's also marked `@MainActor` as UI updates are often required after an action.
    @MainActor
    func onScreenAwarenessManager(_ manager: OnScreenAwarenessManager,
                                  didReceive action: OnScreenAction,
                                  forContentWithIdentifier contentIdentifier: String) async -> OnScreenActionResult {
        print("DocumentViewerController: Received action: '\(action.userFacingTitle)' for content ID: \(contentIdentifier)")

        // 4. Perform the action based on its type
        switch action.type {
        case .summarizeDocument:
            await performSummarization(action.parameters)
            return .success
        case .extractEntities:
            await performEntityExtraction(action.parameters)
            return .success
        case .createEvent:
            await performCreateEvent(action.parameters)
            return .success
        case .translateText:
            await performTranslation(action.parameters)
            return .success
        case .customAppAction:
            print("DocumentViewerController: Received custom app action.")
            return .notHandled // Example of not handling a generic custom action
        }
    }

    // MARK: - Action Execution Logic (Simulated)

    /// Simulates summarizing the document content.
    private func performSummarization(_ parameters: [String: AnyCodable]) async {
        let maxLength = (parameters["maxLength"]?.value as? Int) ?? 100
        print("    -> DocumentViewerController: Simulating summarization up to \(maxLength) characters...")
        // In a real app, this would involve calling a local or remote LLM,
        // then updating the UI with the summary or showing an alert.
        try? await Task.sleep(for: .seconds(1)) // Simulate work
        let summary = String(documentContent.prefix(maxLength)) + "..."
        showAlert(title: "Summary", message: summary)
    }

    /// Simulates extracting entities from the document.
    private func performEntityExtraction(_ parameters: [String: AnyCodable]) async {
        print("    -> DocumentViewerController: Simulating entity extraction...")
        try? await Task.sleep(for: .seconds(0.8)) // Simulate work
        let entities = ["John Doe", "Apple Park", "WWDC 2024"] // Placeholder
        showAlert(title: "Extracted Entities", message: entities.joined(separator: ", "))
    }

    /// Simulates creating a calendar event.
    private func performCreateEvent(_ parameters: [String: AnyCodable]) async {
        let title = (parameters["title"]?.value as? String) ?? "New Event"
        let date = (parameters["date"]?.value as? String) ?? "Today"
        print("    -> DocumentViewerController: Simulating creating event: '\(title)' on \(date)...")
        try? await Task.sleep(for: .seconds(1.2)) // Simulate work
        showAlert(title: "Event Created", message: "Event '\(title)' added to Calendar for \(date).")
    }

    /// Simulates translating the document text.
    private func performTranslation(_ parameters: [String: AnyCodable]) async {
        let targetLanguage = (parameters["targetLanguage"]?.value as? String) ?? "Spanish"
        print("    -> DocumentViewerController: Simulating translation to \(targetLanguage)...")
        try? await Task.sleep(for: .seconds(1.5)) // Simulate work
        let translatedText = "Este es un documento de ejemplo." // Placeholder
        showAlert(title: "Translated Text (\(targetLanguage))", message: translatedText)
    }

    /// Helper to show an alert.
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

// MARK: - Application Entry Point (for demonstration)

/// @available(iOS 18.0, *)
/// Entry point for the application.
/// In a real app, this would be part of `SceneDelegate` or `AppDelegate`.
@main
@available(iOS 18.0, *)
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow(frame: UIScreen.main.bounds)
        let sampleDocument = """
        Meeting Minutes - Project Alpha Kick-off

        Date: October 26, 2024
        Time: 10:00 AM - 11:00 AM PDT
        Location: Virtual (Zoom)

        Attendees:
        - John Doe (Project Lead)
        - Jane Smith (Engineering)
        - Mike Johnson (Product)

        Agenda:
        1. Introduction to Project Alpha goals and scope.
        2. Review of initial requirements and technical challenges.
        3. Discussion on timeline and key milestones.
        4. Action items and next steps.

        Key Decisions:
        - The primary goal is to launch the MVP by Q1 2025.
        - John Doe will coordinate with the design team for UI/UX mockups.
        - Jane Smith will investigate the feasibility of integrating the new ML model.

        Action Items:
        - John Doe: Schedule follow-up meeting with design. (Due: Nov 1, 2024)
        - Jane Smith: Provide initial technical assessment report. (Due: Nov 8, 2024)
        - Mike Johnson: Finalize product requirements document. (Due: Nov 15, 2024)

        Next Meeting: November 10, 2024, 10:00 AM PDT.
        """

        let documentViewer = DocumentViewerController(documentContent: sampleDocument)
        let navigationController = UINavigationController(rootViewController: documentViewer)
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()

        return true
    }
}
