
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import MLXNN // MLXNN is typically part of the mlx-swift package

    @available(iOS 18.0, *)
    class Linear: MLXNN.Module {
        let weight: MLXArray
        let bias: MLXArray?

        init(inputSize: Int, outputSize: Int, bias: Bool = true) {
            self.weight = MLXArray.randomUniform([outputSize, inputSize])
            self.bias = bias ? MLXArray.zeros([outputSize]) : nil
            super.init() // Call super.init() for Module
        }

        func callAsFunction(_ input: MLXArray) -> MLXArray {
            var output = input.matmul(weight.T) // .T for transpose
            if let bias = bias {
                output = output + bias
            }
            return output
        }
    }

    @available(iOS 18.0, *)
    func demonstrateModule() {
        let linearLayer = Linear(inputSize: 10, outputSize: 5)
        let input = MLXArray.randomUniform([1, 10]) // Batch size 1, 10 features
        
        let output = linearLayer(input) // Invokes callAsFunction
        output.eval()
        
        print("Input shape: \(input.shape)") // Input shape: [1, 10]
        print("Output shape: \(output.shape)") // Output shape: [1, 5]
    }
    // demonstrateModule()
    