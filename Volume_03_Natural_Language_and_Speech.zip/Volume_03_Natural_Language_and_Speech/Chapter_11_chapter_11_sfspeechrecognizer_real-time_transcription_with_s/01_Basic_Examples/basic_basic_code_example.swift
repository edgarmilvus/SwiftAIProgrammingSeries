
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Speech
import AVFoundation

// CRITICAL CONTEXT: This is a basic example for SFSpeechRecognizer.
// It demonstrates real-time transcription of live audio input from the device's microphone.

/// A simple class demonstrating how to use SFSpeechRecognizer for real-time speech-to-text transcription.
/// This class manages audio recording, speech recognition requests, and task lifecycle.
///
/// - Important: This class requires 'NSSpeechRecognitionUsageDescription' and 'NSMicrophoneUsageDescription'
///   keys to be present in your app's Info.plist file.
@available(iOS 13.0, *) // SFSpeechRecognizer is available earlier, but async/await requires iOS 13+
class RealTimeSpeechRecognizer: ObservableObject { // Conforming to ObservableObject for easy integration with SwiftUI.

    // MARK: - Properties

    /// The primary speech recognizer object.
    /// It's typically a singleton, meaning you generally create one instance and reuse it.
    private let speechRecognizer: SFSpeechRecognizer?

    /// The recognition request object. This is where we feed audio buffers to the recognizer.
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?

    /// The recognition task object. Manages the lifecycle of a single recognition session.
    private var recognitionTask: SFSpeechRecognitionTask?

    /// The audio engine responsible for capturing audio from the microphone and processing it.
    private let audioEngine = AVAudioEngine()

    /// Published property to hold the transcribed text. Updates to this property will automatically
    /// trigger UI updates in SwiftUI views that observe this object.
    @Published var transcribedText: String = ""

    /// Published property to indicate if the speech recognition process is currently active.
    @Published var isRecognizing: Bool = false

    /// Published property to hold any error messages that occur during the recognition process.
    @Published var errorMessage: String?

    // MARK: - Initialization

    /// Initializes the speech recognizer.
    ///
    /// Sets the locale for the speech recognizer. If `nil`, the device's current locale is used.
    /// Checks for recognizer availability and sets an initial error message if it's unavailable.
    init() {
        // 1. Initialize the SFSpeechRecognizer with a specific locale.
        // Using "en-US" explicitly ensures consistency, but `nil` uses the device's default locale.
        speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))

        // 2. Perform an initial check for the availability of the speech recognizer.
        // It might be unavailable if the locale is not supported, the device lacks resources,
        // or due to other system constraints.
        guard speechRecognizer?.isAvailable == true else {
            errorMessage = "Speech recognizer is not available for the selected locale or device."
            return
        }

        // Optional: You can set a delegate (e.g., `speechRecognizer?.delegate = self`)
        // if you need to observe changes in the recognizer's availability (`SFSpeechRecognizerDelegate`).
        // For this basic example, we rely on direct checks and task results.
    }

    // MARK: - Authorization

    /// Requests authorization for both speech recognition and microphone access.
    ///
    /// This method is asynchronous and **must** be called before attempting to start any recognition.
    /// It handles presenting system prompts to the user for both `SFSpeechRecognizer` and
    /// `AVAudioSession` (microphone) permissions.
    /// The `errorMessage` published property is updated based on the authorization outcomes.
    func requestAuthorization() async {
        // 1. Request speech recognition authorization.
        // This will present a system prompt to the user the first time your app requests it.
        let speechAuthStatus = await SFSpeechRecognizer.requestAuthorization()

        // 2. Request microphone authorization via AVAudioSession.
        // This also presents a system prompt if microphone access hasn't been granted yet.
        let audioSession = AVAudioSession.sharedInstance()
        var micAuthStatus: AVAudioSession.RecordPermission = .denied
        do {
            micAuthStatus = audioSession.recordPermission
            // If permission is undetermined, explicitly request it.
            if micAuthStatus == .undetermined {
                await audioSession.requestRecordPermission()
                micAuthStatus = audioSession.recordPermission // Re-check status after request
            }
        }

        // 3. IMPORTANT: All UI updates (including updates to `@Published` properties)
        // MUST be performed on the main actor to ensure thread safety and prevent UI glitches or crashes.
        await MainActor.run {
            switch (speechAuthStatus, micAuthStatus) {
            case (.authorized, .granted):
                self.errorMessage = nil // Clear any previous error if all permissions are granted
            case (.denied, _):
                self.errorMessage = "Speech recognition authorization denied. Please enable in Settings."
            case (.restricted, _):
                self.errorMessage = "Speech recognition restricted on this device (e.g., parental controls)."
            case (.notDetermined, _):
                self.errorMessage = "Speech recognition not yet authorized. Please try again."
            case (_, .denied):
                self.errorMessage = "Microphone access denied. Please enable in Settings."
            case (_, .undetermined):
                self.errorMessage = "Microphone access not yet authorized. Please try again."
            case (_, .granted): // Fallback for cases where speechAuthStatus isn't .authorized but mic is granted
                self.errorMessage = "Speech recognition authorization required."
            @unknown default: // Handle any future, unknown authorization statuses gracefully.
                self.errorMessage = "An unknown authorization status occurred."
            }
        }
    }

    // MARK: - Recognition Control

    /// Starts the real-time speech recognition process.
    ///
    /// This method performs the following sequence of operations:
    /// 1. Stops any existing recognition tasks to ensure a clean start.
    /// 2. Configures and activates the `AVAudioSession` specifically for audio recording.
    /// 3. Creates a new `SFSpeechAudioBufferRecognitionRequest` to queue audio data.
    /// 4. Configures the `AVAudioEngine` to capture microphone input and continuously append it to the request.
    /// 5. Initiates an `SFSpeechRecognitionTask` to process the incoming audio and deliver transcription results.
    /// 6. Prepares and starts the `AVAudioEngine`.
    ///
    /// - Throws: A `SpeechRecognizerError` if any step of the audio or speech recognition setup fails.
    func startRecording() throws {
        // 1. Ensure a clean slate: Cancel any previous recognition task if it's still active.
        recognitionTask?.cancel()
        recognitionTask = nil

        // Guard against starting if the speech recognizer is not available.
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            throw SpeechRecognizerError.recognizerUnavailable
        }

        // 2. Configure and activate the audio session for recording.
        // - `.record` category is essential for microphone input.
        // - `.measurement` mode is suitable for speech processing, prioritizing raw audio.
        // - `.duckOthers` option allows other background audio to continue at a lower volume.
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            throw SpeechRecognizerError.audioSessionSetupFailed(error)
        }

        // 3. Create a new recognition request.
        // This object will serve as the buffer for audio data streamed from the microphone.
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            throw SpeechRecognizerError.recognitionRequestCreationFailed
        }

        // `shouldReportPartialResults` is crucial for real-time user feedback.
        // When true, the recognizer provides interim transcription results as the user speaks,
        // which can be immediately displayed and updated in the UI.
        recognitionRequest.shouldReportPartialResults = true

        // 4. Set up the audio engine and tap its microphone input node.
        // Get the default microphone input node from the audio engine.
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0) // Get the recording format.

        // Install a tap on the input node's output to capture audio buffers.
        // - `onBus: 0` typically refers to the main output bus.
        // - `bufferSize: 1024` specifies the number of audio frames per buffer.
        // The provided block is called repeatedly with new audio data from the microphone.
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            // Append the captured audio buffer to the recognition request.
            // This is the continuous stream of audio data fed to the speech recognizer.
            self.recognitionRequest?.append(buffer)
        }

        // 5. Create and start the speech recognition task.
        // This task takes the audio from the request and performs the actual speech-to-text conversion.
        // The completion handler is called with `SFSpeechRecognitionResult` objects and/or errors.
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
            // IMPORTANT: The completion handler for `recognitionTask` might be called on a background thread.
            // All UI updates (including updates to `@Published` properties) must happen on the main actor.
            @MainActor in
            if let result = result {
                // Update the transcribed text with the `bestTranscription`, which is the most likely transcription.
                // `formattedString` provides a nicely formatted text string.
                self.transcribedText = result.bestTranscription.formattedString
                self.errorMessage = nil // Clear any previous error if results are coming in successfully
            }

            if let error = error {
                self.errorMessage = "Recognition error: \(error.localizedDescription)"
                self.stopRecording() // Stop recording immediately if a significant error occurs
            }

            // `isFinal` indicates that the recognition task has completed its processing
            // for a segment of speech or the entire session (e.g., user stopped speaking, timeout).
            if result?.isFinal == true {
                // Perform necessary cleanup once the task is finalized.
                self.isRecognizing = false
                self.recognitionRequest = nil
                self.recognitionTask = nil
                self.audioEngine.stop()
                self.audioEngine.inputNode.removeTap(onBus: 0) // Crucial: Remove the tap to release resources!
                try? AVAudioSession.sharedInstance().setActive(false) // Deactivate audio session
            }
        }

        // 6. Prepare and start the audio engine.
        // `prepare()` allocates necessary audio resources. `start()` begins audio processing.
        audioEngine.prepare()
        do {
            try audioEngine.start()
            // Update UI on the main actor after the audio engine successfully starts.
            await MainActor.run {
                self.isRecognizing = true
                self.transcribedText = "" // Clear any previous text for a fresh recording session
                self.errorMessage = nil
            }
        } catch {
            // If the engine fails to start, clean up the tap and propagate the error.
            inputNode.removeTap(onBus: 0)
            throw SpeechRecognizerError.audioEngineStartFailed(error)
        }
    }

    /// Stops the real-time speech recognition process and cleans up all associated resources.
    ///
    /// This method performs the following cleanup operations:
    /// 1. Stops the `AVAudioEngine` and removes its input tap to prevent resource leaks.
    /// 2. Signals the `SFSpeechAudioBufferRecognitionRequest` that no more audio will be appended.
    /// 3. Cancels the `SFSpeechRecognitionTask` if it's still active.
    /// 4. Deactivates the `AVAudioSession` to release microphone hardware access.
    func stopRecording() {
        // Stop the audio engine and remove the tap. This is crucial to prevent memory leaks
        // and ensure the microphone is released properly.
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)

        // Signal the recognition request that audio input has ended.
        recognitionRequest?.endAudio()
        recognitionRequest = nil

        // Cancel the recognition task if it's still running or pending.
        recognitionTask?.cancel()
        recognitionTask = nil

        // Deactivate the audio session to release microphone resources and allow other apps to use it.
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
        }

        // IMPORTANT: All UI updates must be performed on the main actor.
        @MainActor in
        self.isRecognizing = false
    }

    /// Custom error types for speech recognition operations, providing localized descriptions.
    enum SpeechRecognizerError: Error, LocalizedError {
        case recognizerUnavailable
        case audioSessionSetupFailed(Error)
        case recognitionRequestCreationFailed
        case audioEngineStartFailed(Error)

        /// Provides a user-friendly, localized description for each error case.
        var errorDescription: String? {
            switch self {
            case .recognizerUnavailable:
                return "Speech recognizer is not available for this locale or device."
            case .audioSessionSetupFailed(let error):
                return "Failed to set up audio session: \(error.localizedDescription)"
            case .recognitionRequestCreationFailed:
                return "Failed to create speech recognition request."
            case .audioEngineStartFailed(let error):
                return "Failed to start audio engine: \(error.localizedDescription)"
            }
        }
    }
}
