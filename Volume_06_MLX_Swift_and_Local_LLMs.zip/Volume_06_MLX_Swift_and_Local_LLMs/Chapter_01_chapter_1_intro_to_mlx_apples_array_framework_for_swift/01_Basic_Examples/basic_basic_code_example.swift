
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// Package.swift snippet for MLX-Swift dependency
// This is added to your Package.swift file under dependencies:
/*
dependencies: [
    .package(url: "https://github.com/ml-explore/mlx-swift.git", from: "0.1.0") // Or the latest version
],
targets: [
    .executableTarget(
        name: "HealthMonitorApp",
        dependencies: [
            .product(name: "MLX", package: "mlx-swift"),
            .product(name: "MLXNN", package: "mlx-swift")
        ]
    )
]
*/

import MLX
import MLXNN // For defining simple neural network modules

// Ensure the code runs on iOS 18.0+ or macOS 15.0+ as MLX-Swift often targets recent SDKs.
@available(iOS 18.0, macOS 15.0, *)
struct HealthMonitorProcessor {

    /// A very basic module demonstrating MLXNN.Module for a learnable scaling factor.
    /// In a real ML model, this would be a layer with many parameters.
    struct SimpleScaler: MLXNN.Module {
        /// The learnable scaling parameter. Declaring it as `var` and an `MLXArray`
        /// with `requiresGrad = true` makes it discoverable by MLX's autograd system.
        var scale: MLXArray

        /// Initializes the scaler with an initial scaling factor.
        /// - Parameter initialScale: The starting value for the scaling factor.
        init(initialScale: Float) {
            // Parameters that we want to optimize (learn) must have requiresGrad set to true.
            self.scale = MLXArray(initialScale, requiresGrad: true)
            // It's good practice to register parameters, though MLXNN.Module often handles this implicitly
            // for directly declared MLXArray properties.
            register(parameter: scale)
        }

        /// The forward pass of the module. Takes an input `MLXArray` and applies the scaling.
        /// - Parameter input: The sensor data to be scaled.
        /// - Returns: The scaled sensor data.
        func callAsFunction(_ input: MLXArray) -> MLXArray {
            return input * scale
        }
    }

    /// Processes a batch of sensor data using a simple, learnable scaler.
    /// - Parameters:
    ///   - rawSensorData: An array of raw sensor readings (e.g., heart rate, temperature).
    ///   - targetScaledValue: A target value we ideally want the scaled data to approach,
    ///                        used for demonstrating gradient computation.
    ///   - currentScaler: The `SimpleScaler` module instance with its current `scale` parameter.
    /// - Returns: A tuple containing the scaled data, the loss value, and the gradient of the loss
    ///            with respect to the `scale` parameter.
    func processSensorData(
        rawSensorData: [Float],
        targetScaledValue: Float,
        currentScaler: SimpleScaler
    ) -> (scaledData: [Float], loss: Float, gradientOfScale: Float) {

        // 1. Create MLXArray from Swift native types
        // This is the entry point for bringing your data into the MLX ecosystem.
        // MLXArray holds the data and metadata (shape, dtype, device).
        let inputData = MLXArray(rawSensorData)
        print("1. Raw sensor data (MLXArray):\n\(inputData)")
        print("   Shape: \(inputData.shape), Data Type: \(inputData.dtype)\n")

        let target = MLXArray(targetScaledValue)
        print("   Target scaled value (MLXArray):\n\(target)\n")

        // 2. Perform a basic operation using the SimpleScaler module
        // This demonstrates how an MLXNN.Module encapsulates operations and parameters.
        let scaledDataMLX = currentScaler(inputData)
        print("2. Scaled data (MLXArray, before explicit eval):\n\(scaledDataMLX)")
        // At this point, `scaledDataMLX` is a node in the computation graph.
        // No actual multiplication has happened yet due to lazy evaluation.
        print("   (Note: Actual computation is lazy, graph is built)\n")

        // 3. Define a simple loss function
        // This function will be used by `valueAndGradient` to compute the loss and its derivatives.
        // We're using a Mean Squared Error (MSE) loss here.
        let lossFn = { (scaler: SimpleScaler) -> MLXArray in
            let prediction = scaler(inputData)
            let error = prediction - target
            let mseLoss = (error * error).mean() // Element-wise square, then mean
            return mseLoss
        }

        // 4. Compute the loss value and its gradient using `valueAndGradient`
        // This is a core functional transformation in MLX. It takes a function (our lossFn)
        // and returns both the function's output (the loss) and the gradients of that output
        // with respect to the *trainable parameters* of the inputs (our 'scaler' module).
        let (loss, gradients) = valueAndGradient(lossFn)(currentScaler)

        // 5. Evaluate the computation graph to get concrete values
        // `eval()` forces the execution of all pending operations in the graph up to this point.
        // Without `eval()`, `loss` and `gradients` would still be symbolic MLXArray objects.
        eval(loss, gradients)

        print("3. Loss value after evaluation: \(loss.item(Float.self))\n")

        // 6. Extract the gradient for our 'scale' parameter
        // The `gradients` dictionary holds gradients for each learnable parameter.
        // The key corresponds to the path to the parameter within the module (e.g., "scale").
        guard let scaleGradient = gradients["scale"] else {
            fatalError("Gradient for 'scale' parameter not found.")
        }
        print("4. Gradient of loss with respect to 'scale': \(scaleGradient.item(Float.self))\n")

        // 7. Convert MLXArray results back to native Swift types for app use
        // `toArray(Float.self)` performs the final evaluation and conversion.
        let finalScaledData = scaledDataMLX.toArray(Float.self)
        print("5. Final scaled data (Swift Array):\n\(finalScaledData)\n")

        return (finalScaledData, loss.item(Float.self), scaleGradient.item(Float.self))
    }
}

// MARK: - Main Execution Block

@available(iOS 18.0, macOS 15.0, *)
func runHealthMonitorExample() {
    print("--- Health Monitor App: Sensor Data Preprocessing with MLX ---")

    let processor = HealthMonitorProcessor()

    // Initialize our simple scaler with a starting factor
    var myScaler = HealthMonitorProcessor.SimpleScaler(initialScale: 0.5)
    print("Initial scaler value: \(myScaler.scale.item(Float.self))\n")

    let rawReadings: [Float] = [72.5, 75.0, 68.2, 80.1, 71.9] // Example heart rate readings
    let desiredTarget: Float = 1.0 // We want to scale readings to approach 1.0 (e.g., normalized)

    // Run the processing pipeline
    let (scaled, currentLoss, grad) = processor.processSensorData(
        rawSensorData: rawReadings,
        targetScaledValue: desiredTarget,
        currentScaler: myScaler
    )

    print("--- Summary ---")
    print("Processed Data: \(scaled)")
    print("Current Loss: \(currentLoss)")
    print("Gradient of Scale: \(grad)")

    // In a real training loop, you would now update `myScaler.scale` using the gradient:
    // myScaler.scale = myScaler.scale - learningRate * grad
    // For this example, we just demonstrate the computation.
}

// Call the example function
if #available(iOS 18.0, macOS 15.0, *) {
    runHealthMonitorExample()
} else {
    print("MLX-Swift example requires iOS 18.0+ or macOS 15.0+.")
}
