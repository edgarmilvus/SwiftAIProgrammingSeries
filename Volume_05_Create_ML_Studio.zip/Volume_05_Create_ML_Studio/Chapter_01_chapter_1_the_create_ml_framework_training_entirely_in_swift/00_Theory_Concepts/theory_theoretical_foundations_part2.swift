
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift snippet (hypothetical, for Create ML)
// dependencies: [
//     .package(name: "CreateML", majorVersion: 1)
// ]

import Foundation
// import CreateML // Assuming CreateML provides these types

// Placeholder types for demonstration
struct MLTrainingData: Sendable {}
struct MLModel: Sendable {}
struct TrainingMetrics: Sendable {
    var epoch: Int
    var loss: Double
    var accuracy: Double
}

@available(iOS 18.0, macOS 15.0, *)
actor MLTrainer {
    private var currentModel: MLModel?
    private var trainingProgress: Double = 0.0
    private var latestMetrics: TrainingMetrics?

    // Internal state, only accessible via actor methods

    func startTraining(data: MLTrainingData) async throws {
        print("Trainer: Preparing for training...")
        self.trainingProgress = 0.0
        self.latestMetrics = nil

        // Simulate Create ML training process
        for epoch in 1...5 {
            print("Trainer: Starting epoch \(epoch)...")
            try await Task.sleep(for: .seconds(2)) // Simulate epoch work

            // Update internal state safely
            self.trainingProgress = Double(epoch) / 5.0
            self.latestMetrics = TrainingMetrics(
                epoch: epoch,
                loss: 1.0 / Double(epoch), // Simulate decreasing loss
                accuracy: Double(epoch) * 0.2 // Simulate increasing accuracy
            )
            print("Trainer: Epoch \(epoch) complete. Progress: \(self.trainingProgress * 100)%")
        }

        self.currentModel = MLModel() // Placeholder for a trained model
        print("Trainer: Training finished. Model ready.")
    }

    func getTrainingProgress() -> Double {
        return trainingProgress
    }

    func getLatestMetrics() -> TrainingMetrics? {
        return latestMetrics
    }

    func getTrainedModel() -> MLModel? {
        return currentModel
    }
}

// Usage:
@available(iOS 18.0, macOS 15.0, *)
func demonstrateActorUsage() {
    let trainer = MLTrainer()
    Task {
        do {
            // Start training in the background
            let trainingTask = Task {
                try await trainer.startTraining(data: MLTrainingData())
            }

            // Periodically check progress from another task/thread
            while await trainer.getTrainingProgress() < 1.0 {
                let progress = await trainer.getTrainingProgress()
                let metrics = await trainer.getLatestMetrics()
                print("App: Current progress: \(progress * 100)%")
                if let metrics = metrics {
                    print("App: Metrics - Epoch: \(metrics.epoch), Loss: \(String(format: "%.2f", metrics.loss)), Accuracy: \(String(format: "%.2f", metrics.accuracy))")
                }
                try await Task.sleep(for: .seconds(1))
            }

            // Wait for training to complete
            _ = await trainingTask.result

            if let model = await trainer.getTrainedModel() {
                print("App: Final model retrieved: \(model)")
            }
        } catch {
            print("App: Error during training: \(error)")
        }
    }
}
