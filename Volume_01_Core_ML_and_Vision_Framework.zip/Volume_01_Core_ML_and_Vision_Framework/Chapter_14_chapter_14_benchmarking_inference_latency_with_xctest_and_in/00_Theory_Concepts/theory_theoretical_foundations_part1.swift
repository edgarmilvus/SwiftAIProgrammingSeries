
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import XCTest
import CoreML
import Vision

@available(iOS 18.0, *)
final class InferencePerformanceTests: XCTestCase {

    // Assume 'myModel' is an initialized Core ML model instance
    // and 'sampleImageBuffer' is a CVPixelBuffer ready for inference.
    var myModel: MyImageClassifier! // Replace with your actual model class
    var sampleImageBuffer: CVPixelBuffer!

    override func setUpWithError() throws {
        super.setUpWithError()
        // Load your Core ML model here
        let config = MLModelConfiguration()
        myModel = try MyImageClassifier(configuration: config)

        // Prepare a sample CVPixelBuffer for consistent input
        // (Details of image loading and conversion omitted for brevity,
        // but this would typically involve loading an image from resources
        // and converting it to CVPixelBuffer format suitable for your model).
        sampleImageBuffer = createSampleCVPixelBuffer() // A helper function you'd implement
    }

    override func tearDownWithError() throws {
        myModel = nil
        sampleImageBuffer = nil
        super.tearDownWithError()
    }

    func testImageClassificationLatency() throws {
        // This is a reference to a concept explained in a previous chapter:
        // Core ML's MLFeatureProvider for input/output.
        let modelInput = MyImageClassifierInput(image: sampleImageBuffer)

        measure {
            // Perform the Core ML inference within the measure block
            _ = try! myModel.prediction(input: modelInput)
        }
    }

    func testVisionClassificationLatency() throws {
        // Example using Vision framework for a higher-level task
        let request = VNCoreMLRequest(model: try VNCoreMLModel(for: myModel.model)) { request, error in
            // Handle results or errors (not relevant for latency measurement itself)
        }
        request.imageCropAndScaleOption = .centerCrop

        measure {
            let handler = VNImageRequestHandler(cvPixelBuffer: sampleImageBuffer, options: [:])
            try! handler.perform([request])
        }
    }

    private func createSampleCVPixelBuffer() -> CVPixelBuffer {
        // Placeholder for creating a CVPixelBuffer.
        // In a real scenario, you'd load a test image and convert it.
        let width = 224
        let height = 224
        var pixelBuffer: CVPixelBuffer?
        let attributes = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferPixelFormatTypeKey: kCVPixelFormatType_32BGRA
        ] as CFDictionary

        CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA, attributes, &pixelBuffer)
        return pixelBuffer!
    }
}
