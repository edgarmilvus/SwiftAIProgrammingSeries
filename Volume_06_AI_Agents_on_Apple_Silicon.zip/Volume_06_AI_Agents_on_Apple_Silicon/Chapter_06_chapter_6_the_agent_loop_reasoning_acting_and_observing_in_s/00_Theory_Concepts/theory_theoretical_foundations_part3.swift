
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import Observation
import SwiftUI // For @State, @Environment, etc.

// Data model representing the agent's current status, suitable for UI display
@available(iOS 17.0, macOS 14.0, *)
@Observable
class AgentStatus {
    var currentPhase: String = "Idle"
    var lastThought: String = ""
    var lastAction: String = ""
    var lastObservation: String = ""
    var memorySnapshot: [String] = []
    var isRunning: Bool = false
}

// A wrapper or facade that interacts with the Agent actor and updates the Observable status
@available(iOS 17.0, macOS 14.0, *)
class AgentCoordinator {
    let agent: Agent // Reference to our agent actor
    let status: AgentStatus // Observable status object
    
    init(agent: Agent, status: AgentStatus) {
        self.agent = agent
        self.status = status
    }

    func startAgentLoop(initialPrompt: String) async throws {
        status.isRunning = true
        status.currentPhase = "Starting..."
        
        do {
            var currentPrompt = initialPrompt
            for iteration in 0..<5 { // Simplified loop
                status.currentPhase = "Reasoning (Iteration \(iteration + 1))"
                status.lastThought = "Thinking about: \(currentPrompt)"
                let llmOutput = try await agent.reason(prompt: currentPrompt)
                status.lastThought = llmOutput

                guard let action = agent.parseLLMOutputToAction(llmOutput) else {
                    status.currentPhase = "Stopped: No valid action."
                    break
                }

                status.currentPhase = "Acting (Iteration \(iteration + 1))"
                status.lastAction = "Executing: \(action)"
                let toolResult = try await agent.act(action: action)
                status.lastAction = "Result: \(toolResult)"

                status.currentPhase = "Observing (Iteration \(iteration + 1))"
                let observation = agent.processToolResultForObservation(toolResult)
                await agent.observe(feedback: observation) // Call actor method
                status.lastObservation = observation
                
                // Update memory snapshot for UI (requires a nonisolated method on Agent)
                status.memorySnapshot = await agent.getMemorySnapshot() // Assuming Agent has this nonisolated method

                currentPrompt = "Based on: '\(observation)', what next?"
            }
        } catch {
            status.currentPhase = "Error: \(error.localizedDescription)"
        }
        status.isRunning = false
    }
}

// Example SwiftUI View consuming the AgentStatus
@available(iOS 17.0, macOS 14.0, *)
struct AgentView: View {
    @State private var agentStatus = AgentStatus()
    @State private var agentCoordinator: AgentCoordinator?
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Agent Status: \(agentStatus.currentPhase)")
                .font(.headline)
            Text("Last Thought: \(agentStatus.lastThought)")
            Text("Last Action: \(agentStatus.lastAction)")
            Text("Last Observation: \(agentStatus.lastObservation)")
            
            Divider()
            
            Text("Memory:")
            ForEach(agentStatus.memorySnapshot, id: \.self) { item in
                Text("- \(item)")
            }

            Button("Start Agent") {
                if agentCoordinator == nil {
                    // Initialize LLMClient and ToolRegistry (from previous chapters)
                    let mockLLMClient = MockLLMClient() // Assume a concrete implementation
                    let mockToolRegistry = MockToolRegistry() // Assume a concrete implementation
                    let agentActor = Agent(llmClient: mockLLMClient, toolRegistry: mockToolRegistry)
                    agentCoordinator = AgentCoordinator(agent: agentActor, status: agentStatus)
                }
                
                Task {
                    await agentCoordinator?.startAgentLoop(initialPrompt: "Find the current weather in San Francisco.")
                }
            }
            .disabled(agentStatus.isRunning)
        }
        .padding()
    }
}
