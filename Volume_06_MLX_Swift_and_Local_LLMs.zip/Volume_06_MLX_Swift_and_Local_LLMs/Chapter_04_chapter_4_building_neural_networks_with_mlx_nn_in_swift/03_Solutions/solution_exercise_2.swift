
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import MLX
import MLXNN

// 1. Define an MLPClassifier Module
class MLPClassifier: MLXNN.Module {
    let inputLayer: MLXNN.Linear
    let hiddenLayer1: MLXNN.Linear
    let hiddenLayer2: MLXNN.Linear
    let outputLayer: MLXNN.Linear
    let activation: MLXNN.ReLU // Using ReLU activation

    init(inputFeatures: Int, hiddenDim1: Int, hiddenDim2: Int, outputClasses: Int) {
        self.inputLayer = MLXNN.Linear(inputSize: inputFeatures, outputSize: hiddenDim1)
        self.hiddenLayer1 = MLXNN.Linear(inputSize: hiddenDim1, outputSize: hiddenDim2)
        self.hiddenLayer2 = MLXNN.Linear(inputSize: hiddenDim2, outputSize: hiddenDim2) // Another hidden layer
        self.outputLayer = MLXNN.Linear(inputSize: hiddenDim2, outputSize: outputClasses)
        self.activation = MLXNN.ReLU()
        super.init()
    }

    // Implement callAsFunction to chain layers and activations
    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // Input -> Hidden1 -> ReLU
        let h1 = activation(inputLayer(x))
        // Hidden1 -> Hidden2 -> ReLU
        let h2 = activation(hiddenLayer1(h1))
        // Hidden2 -> Hidden3 -> ReLU
        let h3 = activation(hiddenLayer2(h2))
        // Hidden3 -> Output (logits)
        return outputLayer(h3)
    }
}

// Main execution block
print("\n--- Exercise 2: Multi-Layer Perceptron for User Churn Prediction ---")

// 2. Generate Synthetic User Data
let numFeatures = 3 // e.g., daysSinceLastLogin, premiumFeaturesUsed, totalSessionsLastMonth
let batchSize = 4   // Simulating a batch of 4 users

// Example data for 4 users, 3 features each
// User 1: [10, 2, 50] (low activity)
// User 2: [1, 8, 200] (high activity)
// User 3: [25, 1, 30] (very low activity)
// User 4: [5, 5, 150] (moderate activity)
let syntheticUserData: [Float] = [
    10.0, 2.0, 50.0,
    1.0, 8.2, 200.0,
    25.0, 1.1, 30.0,
    5.0, 5.5, 150.0
]
let x_batch = MLXArray(syntheticUserData, shape: [batchSize, numFeatures], type: .float32)

// Instantiate the MLPClassifier
let inputFeatures = numFeatures
let hiddenDim1 = 64
let hiddenDim2 = 32
let outputClasses = 2 // 0: Low Churn Risk, 1: High Churn Risk

let mlpModel = MLPClassifier(inputFeatures: inputFeatures, hiddenDim1: hiddenDim1, hiddenDim2: hiddenDim2, outputClasses: outputClasses)

// 3. Perform a Forward Pass and Interpret Output
let logits = mlpModel(x_batch)

print("\nSynthetic User Data (batch_size: \(batchSize), num_features: \(numFeatures)):")
print(x_batch.description) // MLXArray description is useful for multi-dimensional arrays

print("\nModel Output (Logits - raw scores for each class):")
print(logits.description)

print("\nInterpreting the Output (Logits):")
print("The output is an MLXArray of shape (\(batchSize), \(outputClasses)).")
print("Each row corresponds to a user in the batch, and each column represents the raw score (logit) for a specific class (e.g., 'Low Churn Risk' and 'High Churn Risk').")
print("For example, for User 1 (first row of logits), if the first value is -0.5 and the second is 1.2, it means the model predicts 'High Churn Risk' (class 1) with a higher score.")
print("To get probabilities, a Softmax function would typically be applied to these logits.")
print("For classification, the class with the highest logit for each user is the model's prediction.")

// Example of how one might get predicted classes (without Softmax for simplicity, just argmax)
let predictedClasses = MLX.argmax(logits, axis: 1)
print("\nPredicted classes (based on highest logit, without Softmax):")
print(predictedClasses.description)
