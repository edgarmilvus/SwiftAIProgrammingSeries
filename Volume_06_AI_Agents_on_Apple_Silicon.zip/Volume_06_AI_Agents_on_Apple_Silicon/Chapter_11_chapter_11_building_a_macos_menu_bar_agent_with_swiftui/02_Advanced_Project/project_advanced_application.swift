
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift
// This snippet describes a hypothetical Swift Package Manager manifest
// for a project that utilizes an Ollama client library.

import PackageDescription

let package = Package(
    name: "CodeExplainerAgent",
    platforms: [
        .macOS(.v14) // Targeting macOS 14 (Sonoma) or newer for modern APIs
    ],
    products: [
        .library(
            name: "CodeExplainerAgent",
            targets: ["CodeExplainerAgent"]),
    ],
    dependencies: [
        // Hypothetical dependency for interacting with the Ollama API.
        // In a real project, this would point to a public repository
        // or a local path to your Ollama client implementation.
        .package(url: "https://github.com/your-org/OllamaKit.git", from: "1.0.0"),
        // Or, if building a custom client, no external dependency needed here.
    ],
    targets: [
        .target(
            name: "CodeExplainerAgent",
            dependencies: [
                .product(name: "OllamaKit", package: "OllamaKit") // Link to the hypothetical OllamaKit
            ]),
        .testTarget(
            name: "CodeExplainerAgentTests",
            dependencies: ["CodeExplainerAgent"]),
    ]
)
