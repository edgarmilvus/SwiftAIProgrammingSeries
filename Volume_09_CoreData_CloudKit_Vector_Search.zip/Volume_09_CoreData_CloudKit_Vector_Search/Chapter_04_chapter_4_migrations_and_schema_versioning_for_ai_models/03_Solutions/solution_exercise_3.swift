
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CoreData
import Foundation

// 1. The AI Service (Actor for thread-safety)
actor EmbeddingService {
    static let shared = EmbeddingService()
    
    func generateEmbedding(for text: String) async -> [Float] {
        // Simulate heavy transformer computation
        try? await Task.sleep(for: .milliseconds(100))
        // Return a mock 1536-dimensional vector
        return Array(repeating: Float.random(in: -1...1), count: 1536)
    }
}

// 2. The Custom Migration Policy
class VectorReembeddingPolicy: NSEntityMigrationPolicy {
    
    override func createDestinationInstances(forSource sInstance: NSManagedObject, 
                                           in mapping: NSEntityMapping, 
                                           manager: NSMigrationManager) throws {
        
        let destContext = manager.destinationContext
        let destDocument = NSEntityDescription.insertNewObject(forEntityName: mapping.destinationEntityName!, 
                                                              into: destContext)
        
        // Transfer content
        let content = sInstance.value(forKey: "content") as? String ?? ""
        destDocument.setValue(content, forKey: "content")
        
        // 3. The Bridge: Bridging Sync Migration to Async AI Service
        // Since NSEntityMigrationPolicy is synchronous, we must block or use a semaphore.
        // NOTE: In production, a "Lazy Migration" is preferred over this blocking approach.
        let semaphore = DispatchSemaphore(value: 0)
        var newVector: [Float]?
        
        Task {
            newVector = await EmbeddingService.shared.generateEmbedding(for: content)
            semaphore.signal()
        }
        
        _ = semaphore.wait(timeout: .distantFuture)
        
        if let vector = newVector {
            // Convert [Float] to Data for storage
            let data = vector.withUnsafeBytes { Data($0) }
            destDocument.setValue(data, forKey: "vector")
        }
        
        manager.associate(sourceInstance: sInstance, withDestinationInstance: destDocument, for: mapping)
    }
}
