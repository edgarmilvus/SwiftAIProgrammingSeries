
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

// swift-tools-version:6.0
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "SmartPhotoCategorizer",
    platforms: [
        .iOS(.v18), // Requires iOS 18.0 for MLImageClassifier.ModelParameters.ImageAugmentationOptions
        .macOS(.v15) // Requires macOS 15.0 for MLImageClassifier.ModelParameters.ImageAugmentationOptions
    ],
    products: [
        .library(
            name: "SmartPhotoCategorizer",
            targets: ["SmartPhotoCategorizer"]),
    ],
    dependencies: [
        // Example of external dependencies that might be used in a real app:
        // .package(url: "https://github.com/apple/swift-log.git", from: "1.0.0"), // For structured logging
        // .package(url: "https://github.com/onevcat/Kingfisher.git", from: "7.0.0"), // For image loading/caching
    ],
    targets: [
        .target(
            name: "SmartPhotoCategorizer",
            dependencies: [
                // If using swift-log: .product(name: "Logging", package: "swift-log")
            ],
            // CoreML and CreateML are system frameworks, no explicit dependency declaration needed here.
            // For UIKit/AppKit, if used in a module, they are linked via the platform settings.
            swiftSettings: [
                .enableExperimentalFeature("StrictConcurrency") // Swift 6 concurrency enforcement
            ]
        ),
        .testTarget(
            name: "SmartPhotoCategorizerTests",
            dependencies: ["SmartPhotoCategorizer"]),
    ]
)
