
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

    // DocInsightCore/DocumentModel.swift
    import Foundation
    import SwiftData

    /// Represents a scanned document in the DocInsight app.
    @available(iOS 18.0, *)
    @Model
    final class Document {
        @Attribute(.unique) var id: UUID
        var title: String
        var originalText: String
        var summary: String?
        // Storing complex types like ExtractedEntity requires them to be Codable
        // and often uses @Relationship or Transformable for SwiftData.
        // For simplicity, we make ExtractedEntity Codable and rely on SwiftData's
        // default handling for Codable structs in arrays.
        var extractedEntities: [ExtractedEntity]
        var creationDate: Date
        var imageUrl: URL? // URL to the original scanned image

        init(id: UUID = UUID(), title: String, originalText: String, imageUrl: URL? = nil) {
            self.id = id
            self.title = title
            self.originalText = originalText
            self.extractedEntities = []
            self.creationDate = .now
            self.imageUrl = imageUrl
        }
    }

    /// Represents an entity extracted from the document text.
    /// Made `Codable` and `Hashable` for storage in `SwiftData` and collection manipulation.
    @available(iOS 18.0, *)
    struct ExtractedEntity: Codable, Hashable {
        enum EntityType: String, Codable {
            case person
            case organization
            case location
            case date
            case money
            case url
            case phoneNumber
            case custom // For entities identified by LLM or advanced models
        }

        let type: EntityType
        let value: String
        let range: Range<String.Index>? // Optional: for highlighting in UI, not persisted directly by SwiftData for String.Index
                                        // In a real app, this might be stored as NSRange or start/end integers.
    }
    