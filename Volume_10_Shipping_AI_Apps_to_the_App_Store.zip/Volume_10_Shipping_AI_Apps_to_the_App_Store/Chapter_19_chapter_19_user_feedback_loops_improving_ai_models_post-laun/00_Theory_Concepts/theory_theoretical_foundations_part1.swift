
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

/// Represents the type of feedback captured from the user.
enum FeedbackType: Sendable, Codable {
    case explicit(rating: Int)
    case correction(original: String, corrected: String)
    case implicit(action: ImplicitAction)
    
    enum ImplicitAction: Sendable, Codable {
        case dwellTime(seconds: Double)
        case undoPerformed
        case substitution(original: String, substituted: String)
    }
}

/// A data packet representing a single feedback event.
/// Conforms to Sendable to allow safe transfer between actors.
struct FeedbackPacket: Sendable, Codable, Identifiable {
    let id: UUID
    let timestamp: Date
    let modelIdentifier: String
    let inputContext: String
    let feedback: FeedbackType
    
    init(modelIdentifier: String, inputContext: String, feedback: FeedbackType) {
        self.id = UUID()
        self.timestamp = Date()
        self.modelIdentifier = modelIdentifier
        self.inputContext = inputContext
        self.feedback = feedback
    }
}

/// The FeedbackCollector actor manages the local buffer of feedback.
/// It ensures that high-frequency updates from various threads do not cause data races.
actor FeedbackCollector {
    private var buffer: [FeedbackPacket] = []
    private let maxBufferSize = 100
    
    /// Adds a new packet to the buffer.
    /// Because this is an actor, this method is isolated and thread-safe.
    func collect(_ packet: FeedbackPacket) {
        buffer.append(packet)
        print("Collected feedback: \(packet.id). Buffer size: \(buffer.count)")
        
        if buffer.count >= maxBufferSize {
            // In a real app, we would trigger an upload task here.
            Task {
                await flush()
            }
        }
    }
    
    /// Flushes the current buffer to persistent storage or a remote server.
    func flush() async {
        guard !buffer.isEmpty else { return }
        
        let packetsToUpload = buffer
        buffer.removeAll()
        
        print("Flushing \(packetsToUpload.count) packets to the cloud...")
        // Implementation of network upload would go here.
        // await networkService.upload(packetsToUpload)
    }
    
    func getBufferSize() -> Int {
        return buffer.count
    }
}

/// A UI-facing observer that monitors the health of the feedback loop.
/// Uses the @Observable macro (iOS 17+) to allow SwiftUI views to react to telemetry changes.
@Observable
@available(iOS 18.0, *)
final class FeedbackMonitor {
    private(set) var totalPacketsCollected: Int = 0
    private let collector: FeedbackCollector
    
    init(collector: FeedbackCollector) {
        self.collector = collector
    }
    
    /// A non-isolated method to bridge the Actor-based collector to the MainActor-based UI.
    @MainActor
    func recordFeedback(modelId: String, context: String, type: FeedbackType) async {
        let packet = FeedbackPacket(modelIdentifier: modelId, inputContext: context, feedback: type)
        
        // We 'await' the actor to ensure safe handoff.
        await collector.collect(packet)
        
        // Update the UI-bound state.
        totalPacketsCollected += 1
    }
}
