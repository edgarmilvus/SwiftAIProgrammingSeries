
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_9.swift
// Description: Solution for Exercise 9
// ==========================================

// ClipboardCodeExplainerView.swift
import SwiftUI

struct ClipboardCodeExplainerView: View {
    @Binding var isPopoverShown: Bool
    @Binding var isCodeDetectedInClipboard: Bool // From AppDelegate
    @Binding var clipboardContent: String // From AppDelegate

    @StateObject private var llamaService = LlamaService() // Reusing LlamaService
    
    @State private var userEditedPrompt: String = "" // For user to edit/confirm code
    @State private var explanation: String = ""
    @State private var isDarkMode: Bool = false // Kept for consistency

    var body: some View {
        VStack(spacing: 15) {
            Text("Clipboard Code Explainer")
                .font(.headline)
                .padding(.bottom, 5)

            // LLM Model Loading Status
            if llamaService.isLoadingModel {
                ProgressView("Loading LLM model...")
                    .progressViewStyle(.circular)
                    .padding(.vertical, 10)
            } else if llamaService.llama == nil {
                Text("LLM model not loaded.")
                    .foregroundColor(.red)
                    .font(.caption)
                    .padding(.vertical, 10)
                Button("Try Load Model") {
                    llamaService.loadModel()
                }
                .buttonStyle(.bordered)
            } else {
                // Detected Code Display / Edit
                Text("Detected Code:")
                    .font(.subheadline)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                TextEditor(text: $userEditedPrompt)
                    .font(.caption)
                    .frame(height: 100)
                    .overlay(RoundedRectangle(cornerRadius: 5).stroke(Color.gray.opacity(0.3), lineWidth: 1))
                    .padding(.horizontal, -4) // Adjust padding for TextEditor
                
                HStack {
                    Button("Paste from Clipboard") {
                        userEditedPrompt = clipboardContent // Paste current clipboard content
                    }
                    .buttonStyle(.bordered)
                    .disabled(clipboardContent.isEmpty)

                    Spacer()

                    Button("Explain Code") {
                        explainCode()
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(userEditedPrompt.isEmpty || llamaService.isGenerating)
                }

                // LLM Explanation Area
                Text("Explanation:")
                    .font(.subheadline)
                    .frame(maxWidth: .infinity, alignment: .leading)

                ScrollView {
                    if llamaService.isGenerating {
                        ProgressView()
                            .progressViewStyle(.circular)
                            .padding()
                    } else if explanation.isEmpty {
                        Text("Explanation will appear here...")
                            .font(.caption)
                            .foregroundColor(.gray)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(8)
                    } else {
                        Text(explanation)
                            .font(.caption)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(8)
                    }
                }
                .frame(maxHeight: 150)
                .border(Color.gray.opacity(0.3), width: 1)
                .cornerRadius(5)
                .padding(.horizontal, -4) // Adjust padding for ScrollView

                // Optional: Copy Explanation Button
                if !explanation.isEmpty && !llamaService.isGenerating {
                    Button("Copy Explanation") {
                        NSPasteboard.general.clearContents()
                        NSPasteboard.general.setString(explanation, forType: .string)
                    }
                    .buttonStyle(.bordered)
                    .padding(.vertical, 5)
                }
                
                // Optional: Stop Generation Button
                if llamaService.isGenerating {
                    Button("Stop Generation") {
                        llamaService.stopGeneration()
                    }
                    .buttonStyle(.bordered)
                    .tint(.red)
                }
            }
            
            // Toggle for Dark Mode
            Toggle(isOn: $isDarkMode) {
                Text("Dark Mode")
            }
            .toggleStyle(.switch)
            .padding(.horizontal)
            .frame(width: 220, alignment: .leading)
            .padding(.top, 5)

            Spacer()

            Button("Dismiss") {
                isPopoverShown = false
            }
            .buttonStyle(.bordered)
            .tint(isDarkMode ? .white : .accentColor)
        }
        .padding()
        .frame(width: 320, height: 500)
        .background(isDarkMode ? Color.black.opacity(0.9) : Color.white)
        .foregroundColor(isDarkMode ? Color.white : Color.black)
        .cornerRadius(10)
        .onAppear {
            // Load LLM model on appear
            if llamaService.llama == nil && !llamaService.isLoadingModel {
                llamaService.loadModel()
            }
            // Initialize userEditedPrompt with current clipboard content
            userEditedPrompt = clipboardContent
            explanation = "" // Clear previous explanation
            llamaService.currentResponse = "" // Clear LLM service response
        }
        .onChange(of: clipboardContent) { newContent in
            // Update userEditedPrompt when clipboard content changes externally
            if !llamaService.isGenerating { // Only update if not actively explaining
                userEditedPrompt = newContent
                explanation = "" // Clear explanation if clipboard changes
                llamaService.currentResponse = ""
            }
        }
        // Error Alert
        .alert("LLM Error", isPresented: $llamaService.showingErrorAlert, presenting: llamaService.errorMessage) { errorMessage in
            Button("OK") { llamaService.showingErrorAlert = false }
        } message: { errorMessage in
            Text(errorMessage)
        }
    }
    
    private func explainCode() {
        explanation = "" // Clear previous explanation
        llamaService.currentResponse = "" // Clear LLM service response for streaming
        
        let prompt = """
        Explain the following code snippet concisely, highlighting its purpose, key components, and potential improvements. If it's not code, state that.
        
        