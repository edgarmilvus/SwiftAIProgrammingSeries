/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useEffect, useCallback } from 'react';
import * as LocalAuthentication from 'expo-local-authentication';

// --- TYPE DEFINITIONS ---

/**
 * Represents the security state of the application session.
 * 'LOCKED': Sensitive data is encrypted; biometric check is required to view.
 * 'UNLOCKED': Biometrics verified; data is accessible in memory.
 * 'ERROR': Hardware or permission error occurred.
 */
type AuthState = 'LOCKED' | 'UNLOCKED' | 'ERROR' | 'CHECKING';

/**
 * Configuration object for biometric authentication.
 */
interface BiometricConfig {
  allowDeviceCredentials?: boolean; // Fallback to PIN/Pattern/Password
  disableDeviceFallback?: boolean;  // strictly biometrics only
  cancelLabel?: string;             // Text for the cancel button (iOS)
}

// --- MOCK ENCRYPTED DATA STORE ---

// In a real app, this would come from a secure store (e.g., SecureStore, Keychain)
// or an encrypted database connection.
const MOCK_ENCRYPTED_VAULT = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."; 
const MOCK_API_KEY = "sk_live_51Mz...";

/**
 * Simulates the decryption of sensitive data using the result of a biometric auth.
 * In a production environment, this key would be stored in a secure enclave 
 * or the device's Keychain/Keystore, accessible only after biometric verification.
 */
const decryptSensitiveData = (authResult: LocalAuthentication.AuthenticationResult): string => {
  if (!authResult.success) {
    throw new Error("Authentication failed. Cannot decrypt data.");
  }
  // Simulate decryption logic
  return `Decrypted Data: ${MOCK_API_KEY}`;
};

// --- COMPONENT LOGIC ---

export default function BiometricVault() {
  const [authState, setAuthState] = useState<AuthState>('CHECKING');
  const [sensitiveData, setSensitiveData] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hardwareInfo, setHardwareInfo] = useState({
    isAvailable: false,
    isEnrolled: false,
    supportedTypes: [] as LocalAuthentication.AuthenticationType[],
  });

  /**
   * Step 1: Hardware Detection & Permission Check
   * 
   * Why: We must verify that the device has biometric hardware and the user has enrolled
   * a biometric method before attempting authentication. This prevents UI errors 
   * and allows us to fallback to password auth on web or unsupported devices.
   */
  const checkHardwareCapabilities = useCallback(async () => {
    try {
      // 1. Check if biometric hardware exists
      const compatible = await LocalAuthentication.hasHardwareAsync();
      
      if (!compatible) {
        setAuthState('ERROR');
        setError("No biometric hardware detected. Falling back to password.");
        return;
      }

      // 2. Check if biometrics are enrolled on the device
      const enrolled = await LocalAuthentication.isEnrolledAsync();
      
      // 3. Get supported types (FaceID vs TouchID)
      const types = await LocalAuthentication.supportedAuthenticationTypesAsync();

      setHardwareInfo({
        isAvailable: compatible,
        isEnrolled: enrolled,
        supportedTypes: types,
      });

      if (!enrolled) {
        setAuthState('ERROR');
        setError("No biometrics enrolled on this device.");
      } else {
        setAuthState('LOCKED');
      }
    } catch (err) {
      console.error("Hardware check failed:", err);
      setAuthState('ERROR');
      setError("Failed to initialize biometric security.");
    }
  }, []);

  /**
   * Step 2: The Authentication Trigger
   * 
   * Why: This function initiates the native biometric prompt.
   * It uses asynchronous tool handling (await) to pause execution until 
   * the user interacts with the native OS prompt.
   * 
   * How: We pass a configuration object to customize the prompt message 
   * and fallback behavior.
   */
  const authenticate = useCallback(async () => {
    if (!hardwareInfo.isAvailable || !hardwareInfo.isEnrolled) return;

    setAuthState('CHECKING');
    setError(null);

    const config: BiometricConfig = {
      allowDeviceCredentials: true, // Allow PIN/Pattern if biometrics fail
      disableDeviceFallback: false,
      cancelLabel: "Use Password",
    };

    try {
      // Trigger the native biometric prompt
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: "Unlock Secure Vault",
        fallbackLabel: config.allowDeviceCredentials ? "Use Passcode" : undefined,
        disableDeviceFallback: config.disableDeviceFallback,
      });

      handleAuthenticationResult(result);
    } catch (err) {
      setAuthState('ERROR');
      setError("Authentication process interrupted.");
    }
  }, [hardwareInfo]);

  /**
   * Step 3: Result Handling & State Management
   * 
   * Why: Centralizing result logic ensures consistent state updates 
   * regardless of whether the user succeeded or cancelled the prompt.
   */
  const handleAuthenticationResult = (result: LocalAuthentication.AuthenticationResult) => {
    if (result.success) {
      try {
        // Decrypt the data using the authentication context
        const decrypted = decryptSensitiveData(result);
        setSensitiveData(decrypted);
        setAuthState('UNLOCKED');
      } catch (decErr) {
        setAuthState('ERROR');
        setError("Failed to decrypt data after auth.");
      }
    } else {
      setAuthState('LOCKED');
      // result.error gives specific codes (e.g., 'user_cancel', 'failed')
      setError(`Authentication failed: ${result.error || 'Unknown error'}. Please try again.`);
    }
  };

  /**
   * Step 4: Session Locking (Manual)
   * 
   * Why: In a high-security SaaS app, users should be able to manually lock 
   * the vault without logging out.
   */
  const lockVault = () => {
    setSensitiveData(null);
    setAuthState('LOCKED');
    setError(null);
  };

  // Initialize hardware check on component mount
  useEffect(() => {
    checkHardwareCapabilities();
  }, [checkHardwareCapabilities]);

  // --- RENDER LOGIC ---

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded-xl shadow-lg border border-gray-200 font-sans">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-800">Secure Biometric Vault</h2>
        <span className={`px-2 py-1 rounded text-xs font-semibold ${
          authState === 'UNLOCKED' ? 'bg-green-100 text-green-800' : 
          authState === 'LOCKED' ? 'bg-red-100 text-red-800' : 
          'bg-gray-100 text-gray-800'
        }`}>
          {authState}
        </span>
      </div>

      {/* Hardware Info & Status */}
      <div className="mb-4 text-sm text-gray-600">
        <p>Supported Types: {hardwareInfo.supportedTypes.map(t => 
          t === LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION ? 'FaceID' : 'TouchID'
        ).join(', ') || 'None'}</p>
      </div>

      {/* Conditional Rendering based on Auth State */}
      
      {authState === 'ERROR' && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded text-sm">
          {error}
        </div>
      )}

      {authState === 'LOCKED' && (
        <div className="space-y-4">
          <div className="p-4 bg-gray-50 border border-dashed border-gray-300 rounded text-center">
            <p className="text-gray-500 italic">🔒 Vault is locked. Sensitive data is hidden.</p>
          </div>
          <button 
            onClick={authenticate}
            disabled={!hardwareInfo.isAvailable}
            className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded transition-colors disabled:opacity-50"
          >
            Unlock with Biometrics
          </button>
          <button 
            onClick={() => alert("Fallback to Password Modal")}
            className="w-full py-2 px-4 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium rounded transition-colors"
          >
            Use Password Instead
          </button>
        </div>
      )}

      {authState === 'UNLOCKED' && (
        <div className="space-y-4">
          <div className="p-4 bg-green-50 border border-green-200 rounded">
            <p className="text-green-800 font-semibold mb-2">✅ Vault Unlocked</p>
            <div className="bg-black text-green-400 p-3 rounded font-mono text-xs break-all">
              {sensitiveData}
            </div>
          </div>
          <button 
            onClick={lockVault}
            className="w-full py-2 px-4 bg-gray-600 hover:bg-gray-700 text-white font-medium rounded transition-colors"
          >
            Lock Vault
          </button>
        </div>
      )}

      {authState === 'CHECKING' && (
        <div className="text-center py-4 text-gray-500">
          Checking security hardware...
        </div>
      )}
    </div>
  );
}
