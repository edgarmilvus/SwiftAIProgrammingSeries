
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Vision
import Foundation // For UUID

@available(iOS 18.0, *)
actor FaceTracker {
    private var trackedFaces: [UUID: VNFaceObservation] = [:]
    private var lastUpdateTime: Date = .distantPast

    func updateFaces(_ newObservations: [VNFaceObservation]) {
        // Simple logic: replace all tracked faces for this example
        // In a real app, you'd perform association/tracking logic
        var currentFaces: [UUID: VNFaceObservation] = [:]
        for obs in newObservations {
            // For simplicity, assign a new UUID. In a real tracker, you'd try to match existing faces.
            currentFaces[UUID()] = obs
        }
        trackedFaces = currentFaces
        lastUpdateTime = Date()
        print("Updated tracked faces. Total: \(trackedFaces.count)")
    }

    func currentFaces() -> [VNFaceObservation] {
        return Array(trackedFaces.values)
    }

    func getLastUpdateTime() -> Date {
        return lastUpdateTime
    }
}

// Example usage
@available(iOS 18.0, *)
func processAndTrack(processor: VisionProcessor, tracker: FaceTracker, image: CIImage) async {
    do {
        let observations = try await processor.processImage(ciImage: image)
        let faceObservations = observations.compactMap { $0 as? VNFaceObservation }

        // Send face observations to the actor for thread-safe state update
        await tracker.updateFaces(faceObservations)

        // Retrieve current faces from the actor
        let currentTrackedFaces = await tracker.currentFaces()
        print("Current tracked faces from actor: \(currentTrackedFaces.count)")

    } catch {
        print("Error during processing or tracking: \(error)")
    }
}
