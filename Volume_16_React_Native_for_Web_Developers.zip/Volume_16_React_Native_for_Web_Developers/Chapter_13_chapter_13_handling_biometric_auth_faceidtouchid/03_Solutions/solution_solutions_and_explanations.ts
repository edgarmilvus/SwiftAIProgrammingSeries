/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// useBiometricAuth.ts
import * as LocalAuthentication from 'expo-local-authentication';
import { useState, useCallback } from 'react';
import { Platform } from 'react-native';
import { BiometricAuthState, BiometricType } from './types';

export const useBiometricAuth = () => {
  const [state, setState] = useState<BiometricAuthState>({
    isSupported: false,
    biometricType: null,
    error: null,
    isLoading: false,
  });

  const checkCapabilities = useCallback(async () => {
    setState((prev) => ({ ...prev, isLoading: true, error: null }));

    try {
      // 1. Check Hardware Availability
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      if (!hasHardware) {
        throw new Error('This device does not support biometric authentication.');
      }

      // 2. Check Enrolled Biometrics
      const isEnrolled = await LocalAuthentication.isEnrolledAsync();
      if (!isEnrolled) {
        throw new Error('No biometrics are enrolled on this device.');
      }

      // 3. Determine Biometric Type
      const types = await LocalAuthentication.supportedAuthenticationTypesAsync();
      let detectedType: BiometricType = null;

      if (Platform.OS === 'ios') {
        // iOS: 1 = TouchID, 2 = FaceID
        if (types.includes(LocalAuthentication.AuthenticationType.FACE)) {
          detectedType = 'face';
        } else if (types.includes(LocalAuthentication.AuthenticationType.FINGERPRINT)) {
          detectedType = 'face'; // On older iPhones, TouchID is often mapped to generic 'face' or 'fingerprint' depending on preference, but strictly:
          detectedType = 'fingerprint'; 
        }
      } else {
        // Android usually implies Fingerprint/Face depending on hardware, but API returns generic types
        // We map to fingerprint for Android as the standard default unless FaceID specific hardware is detected (rare in generic API)
        detectedType = 'fingerprint';
      }

      // 4. Permission Handling (Android Only)
      if (Platform.OS === 'android') {
        const { granted } = await LocalAuthentication.requestPermissionsAsync();
        if (!granted) {
          throw new Error('Permission to use biometrics was denied.');
        }
      }

      setState({
        isSupported: true,
        biometricType: detectedType,
        error: null,
        isLoading: false,
      });

    } catch (err: any) {
      setState({
        isSupported: false,
        biometricType: null,
        error: err.message || 'An unknown error occurred during capability check.',
        isLoading: false,
      });
    }
  }, []);

  return { ...state, checkCapabilities };
};
