
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct Ingredient: Codable {
    let name: String
    let quantity: Double
    let unit: String
}

@available(iOS 18.0, macOS 15.0, *)
struct Recipe: Codable {
    let name: String
    let description: String
    let instructions: [String]
    let ingredients: [Ingredient]
}

@available(iOS 18.0, macOS 15.0, *)
func solveExercise3() {
    print("\n--- Exercise 3: Recipe Ingredient Breakdown ---")

    let decoder = JSONDecoder()

    // Simulate LLM Output 1: Valid Recipe
    let jsonString1 = """
    {
      "name": "Simple Tomato Pasta",
      "description": "A quick and delicious pasta dish.",
      "instructions": [
        "Boil water for pasta.",
        "Sauté garlic and tomatoes.",
        "Combine cooked pasta with sauce."
      ],
      "ingredients": [
        {
          "name": "Pasta",
          "quantity": 250.0,
          "unit": "grams"
        },
        {
          "name": "Canned Tomatoes",
          "quantity": 400.0,
          "unit": "grams"
        },
        {
          "name": "Garlic",
          "quantity": 2.0,
          "unit": "cloves"
        },
        {
          "name": "Olive Oil",
          "quantity": 2.0,
          "unit": "tablespoons"
        }
      ]
    }
    """

    // Simulate LLM Output 2: Recipe with a malformed ingredient (missing quantity, which is not optional)
    let jsonString2 = """
    {
      "name": "Invalid Recipe",
      "description": "This recipe has a bad ingredient.",
      "instructions": ["Just try it."],
      "ingredients": [
        {
          "name": "Water",
          "quantity": 100.0,
          "unit": "ml"
        },
        {
          "name": "Bad Ingredient",
          "unit": "pieces"
        }
      ]
    }
    """

    // Decoding Logic for jsonString1
    print("\nAttempting to decode Recipe 1 (valid):")
    if let jsonData = jsonString1.data(using: .utf8) {
        do {
            let recipe = try decoder.decode(Recipe.self, from: jsonData)
            print("Successfully decoded Recipe 1:")
            print("  Name: \(recipe.name)")
            print("  Description: \(recipe.description)")
            print("  Instructions Count: \(recipe.instructions.count)")
            print("  Ingredients:")
            for ingredient in recipe.ingredients {
                print("    - \(ingredient.name): \(ingredient.quantity) \(ingredient.unit)")
            }
        } catch {
            print("Error decoding Recipe 1: \(error.localizedDescription)")
        }
    } else {
        print("Failed to convert JSON string 1 to Data.")
    }

    // Decoding Logic for jsonString2 (malformed nested ingredient)
    print("\nAttempting to decode Recipe 2 (with malformed ingredient):")
    if let jsonData = jsonString2.data(using: .utf8) {
        do {
            let recipe = try decoder.decode(Recipe.self, from: jsonData)
            print("Successfully decoded Recipe 2 (unexpected!):")
            print("  Name: \(recipe.name)")
        } catch let decodingError as DecodingError {
            print("Error decoding Recipe 2 (expected due to malformed ingredient): \(decodingError.localizedDescription)")
            switch decodingError {
            case .typeMismatch(let type, let context):
                print("  Type Mismatch: Expected \(type) but found different type at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            case .valueNotFound(let type, let context):
                print("  Value Not Found: Expected \(type) but value was missing at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            case .keyNotFound(let key, let context):
                print("  Key Not Found: Key '\(key.stringValue)' was missing at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            case .dataCorrupted(let context):
                print("  Data Corrupted: \(context.debugDescription) at \(context.codingPath.map { $0.stringValue }.joined(separator: "."))")
            @unknown default:
                print("  An unknown decoding error occurred.")
            }
            print("  Implication: The entire Recipe decoding failed because one required nested Ingredient property was missing.")
        } catch {
            print("Generic error decoding Recipe 2: \(error.localizedDescription)")
        }
    } else {
        print("Failed to convert JSON string 2 to Data.")
    }
}

// Uncomment to run Exercise 3
// solveExercise3()
