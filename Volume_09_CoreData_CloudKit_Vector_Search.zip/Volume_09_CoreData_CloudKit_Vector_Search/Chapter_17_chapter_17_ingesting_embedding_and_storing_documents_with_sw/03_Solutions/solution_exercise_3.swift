
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import SwiftData

extension Array where Element == Float {
    /// Calculates the dot product of two vectors.
    func dotProduct(_ other: [Float]) -> Float {
        guard self.count == other.count else { return 0 }
        return zip(self, other).map(*).reduce(0, +)
    }
    
    /// Calculates the Euclidean norm (magnitude) of the vector.
    var magnitude: Float {
        sqrt(self.map { $0 * $0 }.reduce(0, +))
    }
    
    /// Calculates the Cosine Similarity between two vectors.
    func cosineSimilarity(to other: [Float]) -> Float {
        let dot = self.dotProduct(other)
        let magA = self.magnitude
        let magB = other.magnitude
        
        guard magA > 0 && magB > 0 else { return 0 }
        return dot / (magA * magB)
    }
}

final class SemanticSearchEngine {
    private let modelContext: ModelContext
    private let embeddingService: EmbeddingService
    
    init(modelContext: ModelContext, embeddingService: EmbeddingService) {
        self.modelContext = modelContext
        self.embeddingService = embeddingService
    }
    
    func search(query: String, limit: Int) async throws -> [ResearchDocument] {
        // 1. Convert query to vector
        guard let queryVector = embeddingService.generateEmbedding(for: query) else {
            return []
        }
        
        // 2. Fetch all documents (Brute force approach)
        let descriptor = FetchDescriptor<ResearchDocument>()
        let allDocuments = try modelContext.fetch(descriptor)
        
        // 3. Calculate similarity and sort
        let scoredDocuments = allDocuments.compactMap { doc -> (ResearchDocument, Float)? in
            guard let docEmbedding = doc.embedding else { return nil }
            let similarity = docEmbedding.cosineSimilarity(to: queryVector)
            return (doc, similarity)
        }
        
        // 4. Sort by similarity descending and return top results
        let sortedResults = scoredDocuments
            .sorted { $0.1 > $1.1 }
            .prefix(limit)
            .map { $0.0 }
        
        return Array(sortedResults)
    }
}
