
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

/// A service class responsible for transcribing an audio file and performing sentiment analysis on the resulting text.
@available(iOS 17.0, macOS 14.0, *) // SFSpeechRecognizer features used are generally available, but good practice to specify.
class VoiceJournalEntryProcessor {

    private let speechRecognizer: SFSpeechRecognizer?
    private let locale: Locale

    /// Initializes the processor with an optional locale. Uses the device's current locale by default.
    /// - Parameter locale: The locale to use for speech recognition. Defaults to `Locale.current`.
    init(locale: Locale = Locale.current) {
        self.locale = locale
        self.speechRecognizer = SFSpeechRecognizer(locale: locale)
    }

    /// Requests necessary permissions for speech recognition and microphone access.
    /// This should ideally be called before starting any recording or transcription.
    /// - Throws: `VoiceJournalError.permissionDenied` if any permission is not granted.
    func requestPermissions() async throws {
        // Request Speech Recognition permission: Essential for SFSpeechRecognizer.
        let speechStatus = await SFSpeechRecognizer.requestAuthorization()
        guard speechStatus == .authorized else {
            throw VoiceJournalError.permissionDenied("Speech Recognition")
        }

        // Request Microphone permission: While this component processes pre-recorded files,
        // in a full Voice Journal app, recording would precede this, thus microphone permission is vital.
        let audioSession = AVAudioSession.sharedInstance()
        var audioStatus: AVAudioSession.RecordPermission = .undetermined
        await withCheckedContinuation { continuation in
            audioSession.requestRecordPermission { granted in
                audioStatus = granted ? .granted : .denied
                continuation.resume()
            }
        }
        guard audioStatus == .granted else {
            throw VoiceJournalError.permissionDenied("Microphone")
        }
    }

    /// Transcribes an audio file and performs sentiment analysis on the transcription.
    /// This is the primary entry point for processing a voice note.
    /// - Parameter audioFileURL: The URL of the audio file to process.
    /// - Returns: A `VoiceJournalAnalysisResult` containing the transcription and sentiment.
    /// - Throws: `VoiceJournalError` if transcription or analysis fails, or if permissions are not granted.
    func transcribeAndAnalyze(audioFileURL: URL) async throws -> VoiceJournalAnalysisResult {
        // 1. Validate Speech Recognizer availability: Ensure the device supports the requested locale.
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            throw VoiceJournalError.speechRecognitionUnavailable
        }

        // 2. Transcribe the audio file: Delegates to a private helper method for clarity.
        let transcription = try await self.transcribeAudio(fileURL: audioFileURL)

        // 3. Perform sentiment analysis on the transcribed text: Asynchronously analyze the emotional tone.
        let sentimentScore = await self.analyzeSentiment(for: transcription)
        let sentimentDescription: String
        if let score = sentimentScore {
            // Re-use the formatting logic from the result struct for consistency.
            sentimentDescription = VoiceJournalAnalysisResult(audioFileURL: audioFileURL, transcription: transcription, sentimentScore: score, sentimentDescription: "").formattedSentiment
        } else {
            sentimentDescription = "Could not analyze sentiment."
        }

        // 4. Return the combined result: A comprehensive object for the UI or further processing.
        return VoiceJournalAnalysisResult(
            audioFileURL: audioFileURL,
            transcription: transcription,
            sentimentScore: sentimentScore,
            sentimentDescription: sentimentDescription
        )
    }

    /// Internal helper to perform speech recognition on an audio file.
    /// It uses `SFSpeechURLRecognitionRequest` for processing pre-recorded audio.
    /// - Parameter fileURL: The URL of the audio file.
    /// - Returns: The transcribed text.
    /// - Throws: `VoiceJournalError` if transcription fails.
    private func transcribeAudio(fileURL: URL) async throws -> String {
        // `withCheckedThrowingContinuation` bridges the callback-based `SFSpeechRecognizer` API
        // to modern Swift `async/await` syntax, allowing structured error propagation.
        return try await withCheckedThrowingContinuation { continuation in
            guard let speechRecognizer = speechRecognizer else {
                continuation.resume(throwing: VoiceJournalError.speechRecognitionUnavailable)
                return
            }

            // `SFSpeechURLRecognitionRequest` is used for transcribing audio from a file URL.
            let recognitionRequest = SFSpeechURLRecognitionRequest(url: fileURL)
            recognitionRequest.shouldReportPartialResults = false // For file-based transcription, we often only need the final result.

            // Pre-check file existence to provide a more specific error.
            let fileManager = FileManager.default
            guard fileManager.fileExists(atPath: fileURL.path) else {
                continuation.resume(throwing: VoiceJournalError.audioFileLoadFailed(fileURL))
                return
            }

            // Start the recognition task. The closure will be called with results or errors.
            let task = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
                if let error = error {
                    continuation.resume(throwing: VoiceJournalError.transcriptionFailed(error))
                    return
                }

                guard let result = result else {
                    continuation.resume(throwing: VoiceJournalError.transcriptionFailed(nil))
                    return
                }

                // We only care about the final, most accurate transcription.
                if result.isFinal {
                    continuation.resume(returning: result.bestTranscription.formattedString)
                }
            }
            // In a real app, you might keep a reference to `task` to allow cancellation.
        }
    }

    /// Internal helper to perform sentiment analysis on a given text using `NaturalLanguage` framework.
    /// `NLTagger` is a powerful tool for various NLP tasks, including sentiment analysis.
    /// - Parameter text: The text to analyze.
    /// - Returns: A `Double` representing the sentiment score (-1.0 to 1.0), or `nil` if analysis fails.
    private func analyzeSentiment(for text: String) async -> Double? {
        guard !text.isEmpty else { return nil }

        // Initialize NLTagger with the `.sentimentScore` tag scheme.
        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = text // Assign the text to be analyzed.

        // Perform the tagging. For sentiment, we typically tag the entire document.
        // The sentiment score is returned as an `NLTag`.
        let (sentiment, _) = tagger.tag(at: text.startIndex, unit: .document, scheme: .sentimentScore)
        
        // Convert the `NLTag` raw value (which is a string) to a `Double`.
        // Sentiment score ranges from -1.0 (most negative) to 1.0 (most positive).
        return sentiment?.rawValue.doubleValue
    }
}
