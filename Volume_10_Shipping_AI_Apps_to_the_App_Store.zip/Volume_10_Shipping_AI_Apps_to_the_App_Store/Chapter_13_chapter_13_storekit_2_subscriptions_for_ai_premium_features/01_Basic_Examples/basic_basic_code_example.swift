
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import StoreKit
import Observation

/// An error type specific to the SubscriptionManager to provide clear feedback to the UI.
enum SubscriptionError: Error, LocalizedError {
    case productNotFound
    case purchaseFailed(String)
    case unknownError
    
    var errorDescription: String? {
        switch self {
        case .productNotFound: return "The requested AI premium plan could not be found."
        case .purchaseFailed(let message): return "Purchase failed: \(message)"
        case .unknownError: return "An unexpected error occurred."
        }
    }
}

/// `SubscriptionManager` is an `@Observable` class that manages the lifecycle of In-App Purchases.
/// It uses Swift 6 concurrency patterns to ensure thread safety and UI responsiveness.
///
/// @available(iOS 18.0, *)
@available(iOS 18.0, *)
@MainActor
class SubscriptionManager: ObservableObject {
    
    /// The list of products fetched from Apple's servers (e.g., "Monthly AI Pro", "Yearly AI Unlimited").
    @Published private(set) var availableProducts: [Product] = []
    
    /// A boolean indicating whether the user currently has access to premium AI features.
    @Published private(set) var isPremium: Bool = false
    
    /// A boolean indicating if the manager is currently performing a network operation.
    @Published private(set) var isLoading: Bool = false
    
    /// A reference to the task that listens for transaction updates in the background.
    /// Keeping this reference prevents the task from being deallocated.
    private var transactionUpdateTask: Task<Void, Never>?

    init() {
        // We start listening for transactions immediately upon initialization.
        transactionUpdateTask = listenForTransactions()
        
        // Initial check to see if the user is already premium.
        Task {
            await updateSubscriptionStatus()
        }
    }
    
    deinit {
        // Cancel the listener task when the manager is destroyed.
        transactionUpdateTask?.cancel()
    }

    // MARK: - Public API

    /// Fetches the available subscription products from App Store Connect.
    /// This should be called when the user navigates to the Paywall.
    func fetchProducts() async {
        isLoading = true
        defer { isLoading = false }
        
        // In a real app, these IDs match the Product IDs set in App Store Connect.
        let productIDs = ["com.lumina.ai.monthly_pro", "com.lumina.ai.yearly_unlimited"]
        
        do {
            // StoreKit 2's modern way to fetch products.
            let fetchedProducts = try await Product.products(for: productIDs)
            // Sort products by price or type if necessary.
            self.availableProducts = fetchedProducts.sorted(by: { $0.price < $1.price })
        } catch {
            print("Failed to fetch products: \(error)")
        }
    }

    /// Initiates the purchase flow for a specific product.
    /// - Parameter product: The `Product` object selected by the user.
    func purchase(_ product: Product) async throws {
        isLoading = true
        defer { isLoading = false }
        
        let result = try await product.purchase()
        
        switch result {
        case .success(let verification):
            // Verify the transaction using StoreKit's built-in JWS verification.
            let transaction = try checkVerified(verification)
            
            // Update the local premium status.
            await updateSubscriptionStatus()
            
            // Always finish the transaction to tell Apple the app has handled it.
            await transaction.finish()
            
        case .userCancelled:
            // User dismissed the purchase sheet. No error thrown, just exit.
            break
            
        case .pending:
            // Transaction is pending (e.g., "Ask to Buy" for children).
            // The listener will handle the eventual success/failure.
            break
            
        @unknown default:
            throw SubscriptionError.unknownError
        }
    }

    /// Returns the current entitlement status.
    /// This is used to gate AI features like "High-Fidelity Voice" or "Unlimited GPT-4 Access".
    func updateSubscriptionStatus() async {
        var hasPremium = false
        
        // Iterate through all current entitlements (active subscriptions).
        for await result in Transaction.currentEntitlements {
            do {
                let transaction = try checkVerified(result)
                
                // Check if the transaction is for a premium product.
                // In a real app, you might check specific product IDs.
                if transaction.revocationDate == nil {
                    hasPremium = true
                }
            } catch {
                print("Transaction verification failed: \(error)")
            }
        }
        
        self.isPremium = hasPremium
    }

    // MARK: - Private Helpers

    /// A background task that continuously listens for new transactions.
    /// This handles renewals, cancellations, and purchases made on other devices.
    private func listenForTransactions() -> Task<Void, Never> {
        Task.detached(priority: .background) {
            // The Transaction.updates stream provides a continuous flow of new transactions.
            for await result in Transaction.updates {
                // We must jump back to the @MainActor to update the UI-bound properties.
                await self.handleTransactionUpdate(result)
            }
        }
    }

    /// Processes an incoming transaction update from the background stream.
    private func handleTransactionUpdate(_ result: VerificationResult<Transaction>) async {
        do {
            let transaction = try checkVerified(result)
            await updateSubscriptionStatus()
            await transaction.finish()
        } catch {
            print("Failed to handle background transaction: \(error)")
        }
    }

    /// Validates the JWS (JSON Web Signature) provided by StoreKit.
    /// - Parameter result: The verification result from a purchase or update.
    /// - Returns: A verified `Transaction`.
    /// - Throws: `StoreKitError.verificationError` if the transaction is fraudulent.
    private func checkVerified<T>(_ result: VerificationResult<T>) throws -> T {
        switch result {
        case .unverified(let transaction):
            // The transaction failed cryptographic verification.
            // In a production AI app, you should NEVER grant features on an unverified transaction.
            print("Transaction unverified: \(transaction)")
            throw StoreKitError.verificationError
        case .verified(let safe):
            // The transaction is cryptographically sound.
            return safe
        }
    }
}

// MARK: - Usage Example in a SwiftUI View

@available(iOS 18.0, *)
struct PaywallView: View {
    @State private var manager = SubscriptionManager()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Lumina AI Premium")
                .font(.largeTitle.bold())
            
            Text("Unlock unlimited GPT-4o queries and ultra-realistic voice synthesis.")
                .multilineTextAlignment(.center)
                .padding()

            if manager.isLoading {
                ProgressView()
            } else {
                ForEach(manager.availableProducts, id: \.id) { product in
                    Button(action: {
                        Task {
                            try? await manager.purchase(product)
                        }
                    }) {
                        HStack {
                            Text(product.displayName)
                            Spacer()
                            Text(product.displayPrice)
                        }
                        .padding()
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(10)
                    }
                }
            }
            
            if manager.isPremium {
                Text("✅ You are a Premium Member")
                    .foregroundColor(.green)
                    .bold()
            }
        }
        .padding()
        .task {
            // Fetch products when the view appears.
            await manager.fetchProducts()
        }
    }
}
