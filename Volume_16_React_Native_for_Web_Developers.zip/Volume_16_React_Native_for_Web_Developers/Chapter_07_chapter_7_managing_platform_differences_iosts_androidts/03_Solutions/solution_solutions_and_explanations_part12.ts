/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.ts
// Description: Solutions and Explanations
// ==========================================

digraph MetroResolution {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color=lightblue];

    // Start Node
    ImportRequest [label="Import Request:\nimport SmartButton from './SmartButton'", shape=ellipse, color=lightgrey];

    // Decision Nodes
    CheckIOS [label="Check for\nSmartButton.ios.tsx?"];
    CheckAndroid [label="Check for\nSmartButton.android.tsx?"];
    CheckGeneric [label="Check for\nSmartButton.tsx?"];

    // Result Nodes
    LoadIOS [label="Load SmartButton.ios.tsx", shape=doubleoctagon, color=lightgreen];
    LoadAndroid [label="Load SmartButton.android.tsx", shape=doubleoctagon, color=lightgreen];
    LoadGeneric [label="Load SmartButton.tsx", shape=doubleoctagon, color=lightgreen];
    Error [label="Module Not Found\nError", shape=doubleoctagon, color=salmon];

    // Logic Flow
    ImportRequest -> CheckIOS;

    // Branch 1: iOS
    CheckIOS -> LoadIOS [label="Platform is iOS"];
    CheckIOS -> CheckAndroid [label="Platform is NOT iOS"];

    // Branch 2: Android
    CheckAndroid -> LoadAndroid [label="Platform is Android"];
    CheckAndroid -> CheckGeneric [label="Platform is NOT Android"];

    // Branch 3: Generic Fallback
    CheckGeneric -> LoadGeneric [label="File exists"];
    CheckGeneric -> Error [label="File missing"];
}
