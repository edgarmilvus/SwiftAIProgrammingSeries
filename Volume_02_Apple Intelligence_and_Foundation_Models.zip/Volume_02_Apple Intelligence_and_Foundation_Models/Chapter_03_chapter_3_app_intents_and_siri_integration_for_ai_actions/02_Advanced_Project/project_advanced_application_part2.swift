
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AppIntents // Requires iOS 18.0 for full App Intents capabilities
import CoreTransferable // For potential future transfer types, though not strictly used here

// MARK: - 1. Journal Entry Data Model

/// Represents the possible categories for a journal entry, determined by AI.
enum JournalCategory: String, AppEnum, Codable, CaseIterable {
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Journal Category"
    static var allCases: [JournalCategory] = [.task, .observation, .idea, .reflection, .uncategorized]

    case task = "Task"
    case observation = "Observation"
    case idea = "Idea"
    case reflection = "Reflection"
    case uncategorized = "Uncategorized"

    var displayRepresentation: DisplayRepresentation {
        switch self {
        case .task: return DisplayRepresentation(stringLiteral: "Task")
        case .observation: return DisplayRepresentation(stringLiteral: "Observation")
        case .idea: return DisplayRepresentation(stringLiteral: "Idea")
        case .reflection: return DisplayRepresentation(stringLiteral: "Reflection")
        case .uncategorized: return DisplayRepresentation(stringLiteral: "Uncategorized")
        }
    }

    /// Provides a user-friendly description for each category.
    var description: String {
        switch self {
        case .task: return "Something to do or remember."
        case .observation: return "A note about something seen or experienced."
        case .idea: return "A new concept or thought to explore."
        case .reflection: return "A personal thought or feeling."
        case .uncategorized: return "Could not determine a specific category."
        }
    }
}

/// Represents a single journal entry in the JournalFlow app.
struct JournalEntry: Identifiable, Codable {
    let id: UUID
    let text: String
    let timestamp: Date
    let category: JournalCategory
    let suggestedAction: String? // Action suggested by AI, e.g., "Add to Reminders"
    let entities: [String] // Key entities extracted by AI

    init(id: UUID = UUID(), text: String, timestamp: Date = Date(), category: JournalCategory, suggestedAction: String? = nil, entities: [String] = []) {
        self.id = id
        self.text = text
        self.timestamp = timestamp
        self.category = category
        self.suggestedAction = suggestedAction
        self.entities = entities
    }
}

// MARK: - 2. Journal Data Store

/// Manages the persistence of journal entries.
/// In a real app, this would interact with Core Data, Realm, or CloudKit.
/// For this example, we use an in-memory store.
actor JournalStore {
    static let shared = JournalStore() // Singleton instance
    private var entries: [JournalEntry] = []

    private init() {
        // In a real app, load from persistence here
    }

    /// Adds a new journal entry to the store.
    /// - Parameter entry: The `JournalEntry` to add.
    func addEntry(_ entry: JournalEntry) async {
        entries.append(entry)
        print("JournalFlow: Added entry: '\(entry.text)' (Category: \(entry.category.rawValue))")
        // In a real app, save to disk here.
    }

    /// Retrieves all journal entries.
    /// - Returns: An array of `JournalEntry`.
    func getAllEntries() async -> [JournalEntry] {
        return entries
    }

    /// Clears all journal entries from the store.
    func clearAllEntries() async {
        entries.removeAll()
        print("JournalFlow: All entries cleared.")
    }
}

// MARK: - 3. Simulate Apple Intelligence (AIProcessor)

/// A mock AI processor that simulates Apple Intelligence capabilities.
/// In a real iOS 18 app, this would interact with `Foundation.TextUnderstanding`,
/// `CoreML`, or other Apple Intelligence APIs.
@available(iOS 18.0, *)
enum AIProcessor {

    /// Custom error types for AI processing.
    enum AIProcessorError: Error, CustomStringConvertible {
        case classificationFailed
        case entityExtractionFailed
        case actionSuggestionFailed
        case unavailable

        var description: String {
            switch self {
            case .classificationFailed: return "Failed to classify the journal entry."
            case .entityExtractionFailed: return "Failed to extract key entities."
            case .actionSuggestionFailed: return "Failed to suggest an action."
            case .unavailable: return "Apple Intelligence features are currently unavailable."
            }
        }
    }

    /// Simulates classifying text into a `JournalCategory`.
    /// - Parameter text: The input text to classify.
    /// - Returns: The predicted `JournalCategory`.
    /// - Throws: `AIProcessorError` if classification fails.
    static func classify(text: String) async throws -> JournalCategory {
        // Simulate network/on-device model latency
        try await Task.sleep(for: .milliseconds(300))

        // This is where you would integrate with Apple Intelligence APIs.
        // Example (conceptual, actual API might differ):
        /*
        guard let understanding = try await TextUnderstanding.shared.understand(text) else {
            throw AIProcessorError.classificationFailed
        }
        if understanding.contains(.task) { return .task }
        if understanding.contains(.observation) { return .observation }
        // ... more sophisticated logic
        */

        // Simple keyword-based simulation for demonstration:
        if text.lowercased().contains("remember to") || text.lowercased().contains("need to") || text.lowercased().contains("buy") {
            return .task
        } else if text.lowercased().contains("saw a") || text.lowercased().contains("experienced") || text.lowercased().contains("felt") {
            return .observation
        } else if text.lowercased().contains("what if") || text.lowercased().contains("idea for") || text.lowercased().contains("concept") {
            return .idea
        } else if text.lowercased().contains("i think") || text.lowercased().contains("i feel") || text.lowercased().contains("pondering") {
            return .reflection
        } else {
            return .uncategorized
        }
    }

    /// Simulates extracting key entities from text.
    /// - Parameter text: The input text.
    /// - Returns: An array of extracted entity strings.
    /// - Throws: `AIProcessorError` if extraction fails.
    static func extractEntities(text: String) async throws -> [String] {
        try await Task.sleep(for: .milliseconds(200))

        // Conceptual integration:
        /*
        guard let entities = try await TextUnderstanding.shared.extractEntities(from: text, types: [.person, .location, .organization, .event, .product]) else {
            throw AIProcessorError.entityExtractionFailed
        }
        return entities.map { $0.text }
        */

        // Simple simulation:
        var extracted: [String] = []
        if text.lowercased().contains("milk") { extracted.append("milk") }
        if text.lowercased().contains("groceries") { extracted.append("groceries") }
        if text.lowercased().contains("hawk") { extracted.append("red-tailed hawk") }
        if text.lowercased().contains("sunset") { extracted.append("sunset") }
        return extracted.isEmpty ? ["general"] : extracted // Return a default if nothing specific
    }

    /// Simulates suggesting an action based on the AI-determined category and text.
    /// - Parameters:
    ///   - category: The `JournalCategory` of the entry.
    ///   - text: The original journal entry text.
    /// - Returns: A human-readable suggested action.
    /// - Throws: `AIProcessorError` if action suggestion fails.
    static func suggestAction(for category: JournalCategory, text: String) async throws -> String {
        try await Task.sleep(for: .milliseconds(150))

        switch category {
        case .task:
            if text.lowercased().contains("tomorrow") || text.lowercased().contains("next week") {
                return "Add to Reminders with a due date?"
            }
            return "Add to your tasks list?"
        case .observation:
            return "Tag with extracted entities or locations?"
        case .idea:
            return "Add to your 'Ideas' board?"
        case .reflection:
            return "Mark as a private reflection?"
        case .uncategorized:
            return "Review and manually categorize?"
        }
    }
}

// MARK: - 4. LogJournalEntryIntent Definition

/// Defines the App Intent for logging a journal entry with intelligent processing.
@available(iOS 18.0, *)
struct LogJournalEntryIntent: AppIntent {
    static var title: LocalizedStringResource = "Log Journal Entry"
    static var description = IntentDescription("Intelligently logs a new entry to your JournalFlow app, categorizing it with AI and suggesting actions.")
    static var openAppWhenRun: Bool = false // Don't open the app unless necessary

    /// The text content of the journal entry provided by the user (e.g., via Siri).
    @Parameter(title: "Thought", description: "The thought or observation to log.")
    var thoughtText: String

    /// Defines the custom errors this intent can throw.
    enum IntentError: Swift.Error, CustomLocalizedStringResourceConvertible {
        case aiProcessingFailed(String)
        case persistenceFailed
        case userCancelled

        var localizedStringResource: LocalizedStringResource {
            switch self {
            case .aiProcessingFailed(let message): return "AI processing failed: \(message)"
            case .persistenceFailed: return "Failed to save journal entry."
            case .userCancelled: return "Journal entry logging cancelled by user."
            }
        }
    }

    /// The main execution logic for the App Intent.
    func perform() async throws -> some IntentResult & ProvidesDialog {
        print("JournalFlow Intent: Received thought: '\(thoughtText)'")

        // 1. Initial AI Processing: Classify and Extract Entities
        let category: JournalCategory
        let entities: [String]
        let suggestedAction: String

        do {
            category = try await AIProcessor.classify(text: thoughtText)
            entities = try await AIProcessor.extractEntities(text: thoughtText)
            suggestedAction = try await AIProcessor.suggestAction(for: category, text: thoughtText)
        } catch let error as AIProcessor.AIProcessorError {
            throw IntentError.aiProcessingFailed(error.description)
        } catch {
            throw IntentError.aiProcessingFailed("An unexpected error occurred during AI processing: \(error.localizedDescription)")
        }

        print("JournalFlow Intent: AI classified as '\(category.rawValue)' with entities: \(entities.joined(separator: ", "))")
        print("JournalFlow Intent: AI suggested action: '\(suggestedAction)'")

        // 2. Present Confirmation Dialog via Siri
        // This is a key advanced feature, allowing interactive decision-making.
        let confirmationResult = try await requestConfirmation(
            confirmationDialog("I've categorized your thought as a \(category.rawValue). \(suggestedAction)") {
                // Primary action: Confirm and save
                IntentConfirmationAction("Confirm and Log") {
                    // This block is executed if the user confirms.
                    // Create the journal entry with AI-derived data.
                    let newEntry = JournalEntry(
                        text: thoughtText,
                        category: category,
                        suggestedAction: suggestedAction,
                        entities: entities
                    )
                    do {
                        await JournalStore.shared.addEntry(newEntry)
                        print("JournalFlow Intent: Entry saved successfully.")
                        return .result(dialog: "Successfully logged your \(category.rawValue) entry: '\(thoughtText)'.")
                    } catch {
                        throw IntentError.persistenceFailed
                    }
                }
                // Secondary action: Log without special action
                IntentConfirmationAction("Just Log It") {
                    let newEntry = JournalEntry(
                        text: thoughtText,
                        category: category,
                        suggestedAction: nil, // User chose not to take the suggested action
                        entities: entities
                    )
                    do {
                        await JournalStore.shared.addEntry(newEntry)
                        print("JournalFlow Intent: Entry saved without suggested action.")
                        return .result(dialog: "Logged your \(category.rawValue) entry: '\(thoughtText)'.")
                    } catch {
                        throw IntentError.persistenceFailed
                    }
                }
                // Tertiary action: Cancel
                CancelAction("Cancel") {
                    print("JournalFlow Intent: User cancelled logging.")
                    throw IntentError.userCancelled
                }
            }
        )

        // The result of the confirmation dialog is handled within the actions above.
        // If an action completes, it returns an IntentResult.
        // If an action throws, it propagates the error.
        return confirmationResult
    }
}

// MARK: - AppIntents Extension (for the entire app)

/// The main entry point for all App Intents provided by the JournalFlow app.
@available(iOS 18.0, *)
struct JournalFlowAppIntents: AppIntentsExtension {
    static var intents: [AppIntent.Type] {
        [
            LogJournalEntryIntent.self,
            // Add other App Intents here as your app grows
        ]
    }

    static var widgets: [AppIntentWidgetConfiguration] {
        [] // No widgets for this example
    }
}
