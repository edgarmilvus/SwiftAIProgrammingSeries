
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.swift
// Description: Theoretical Foundations
// ==========================================

// @available(iOS 18.0, *)
struct InferenceView: View {
    @State private var viewModel: InferenceViewModel<CoreMLInferenceClient>

    init(client: CoreMLInferenceClient) {
        _viewModel = State(initialValue: InferenceViewModel(client: client))
    }

    var body: some View {
        VStack {
            if viewModel.isLoading {
                ProgressView("Inferring...")
            } else if let output = viewModel.lastOutput {
                Text("Prediction: \(String(describing: output))")
                    .foregroundColor(.green)
            } else if let error = viewModel.lastError {
                VStack {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundColor(.red)
                        .font(.largeTitle)
                    Text("Inference Failed!")
                        .font(.headline)
                    Text(error.errorDescription ?? "An unknown error occurred.")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).fill(Color.red.opacity(0.1)))
            }

            Button("Run Inference") {
                Task {
                    // Assuming some input is available
                    let dummyInput = MLMultiArray(shape: [1, 28, 28], dataType: .double) // Example
                    await viewModel.performInference(input: dummyInput)
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(viewModel.isLoading)
        }
    }
}
