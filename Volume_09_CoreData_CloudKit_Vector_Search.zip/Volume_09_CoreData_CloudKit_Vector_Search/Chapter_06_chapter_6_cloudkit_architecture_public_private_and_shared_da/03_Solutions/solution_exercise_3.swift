
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CloudKit

@available(iOS 18.0, *)
actor CollaborationEngine {
    private let container: CKContainer
    private let privateDB: CKDatabase
    private let sharedDB: CKDatabase

    init(container: CKContainer) {
        self.container = container
        self.privateDB = container.privateCloudDatabase
        self.sharedDB = container.sharedCloudDatabase
    }

    func prepareShare(for projectRecord: CKRecord) async throws -> (CKShare, CKRecord) {
        // A CKShare must be associated with a root record
        let share = CKShare(rootRecord: projectRecord)
        share[CKShare.SystemFieldKey.title] = "Research Project: \(projectRecord["name"] as? String ?? "New Project")" as CKRecordValue
        
        // We must save both the record and the share in one atomic operation
        let operation = CKModifyRecordsOperation(recordsToSave: [projectRecord, share], recordIDsToDelete: nil)
        operation.savePolicy = .ifServerRecordUnchanged
        
        return try await withCheckedThrowingContinuation { continuation in
            operation.modifyRecordsResultBlock = { result in
                switch result {
                case .success:
                    continuation.resume(returning: (share, projectRecord))
                case .failure(let error):
                    continuation.resume(throwing: error)
                }
            }
            privateDB.add(operation)
        }
    }

    func inviteUser(to share: CKShare, email: String) async throws -> CKShare {
        // In a real app, you'd use CKFetchShareParticipantsOperation to find the user
        // For this exercise, we simulate adding a participant via lookup
        let lookupInfo = CKUserIdentity.LookupInfo(emailAddress: email)
        let participant = try await container.userIdentityLookupInfo(for: lookupInfo) // Simplified for example
        
        // Note: In practice, you fetch the identity first, then create the participant
        // This is a conceptual implementation of the participant adding step
        let newParticipant = CKShare.Participant(userIdentity: participant)
        newParticipant.permission = .readWrite
        newParticipant.role = .editor
        
        share.addParticipant(newParticipant)
        
        // Save the updated share
        try await privateDB.save(share)
        return share
    }

    func acceptShare(metadata: CKShare.Metadata) async throws {
        let operation = CKAcceptSharesOperation(shareMetadatas: [metadata])
        
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            operation.acceptSharesResultBlock = { result in
                switch result {
                case .success:
                    continuation.resume()
                case .failure(let error):
                    continuation.resume(throwing: error)
                }
            }
            container.add(operation)
        }
    }
}
