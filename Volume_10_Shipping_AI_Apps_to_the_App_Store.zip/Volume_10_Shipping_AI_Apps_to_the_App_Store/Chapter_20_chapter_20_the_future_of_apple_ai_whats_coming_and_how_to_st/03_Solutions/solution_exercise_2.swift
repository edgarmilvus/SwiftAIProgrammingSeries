
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

// 1. Define the abstraction for AI processing
protocol InferenceEngine: Sendable {
    func process(text: String) async throws -> String
}

// 2. Local Implementation (On-Device)
struct OnDeviceEngine: InferenceEngine {
    func process(text: String) async throws -> String {
        // Simulate local CoreML / NaturalLanguage processing
        return "[Local AI] Categorized: \(text.prefix(10))..."
    }
}

// 3. Cloud Implementation (Private Cloud Compute)
struct SecureCloudEngine: InferenceEngine {
    func process(text: String) async throws -> String {
        // Simulate a secure, encrypted call to Apple's PCC
        return "[PCC AI] Complex Analysis: Analysis complete."
    }
}

// 4. The Privacy-Aware Manager using an Actor
actor PrivacyAwareInferenceManager {
    private let localEngine = OnDeviceEngine()
    private let cloudEngine = SecureCloudEngine()
    
    // Sensitive keywords that trigger the "Local-Only" policy
    private let sensitiveKeywords = ["SSN", "Account Number", "Balance", "Password"]
    
    func processDocument(_ text: String) async throws -> String {
        let isSensitive = sensitiveKeywords.contains { keyword in
            text.localizedCaseInsensitiveContains(keyword)
        }
        
        if isSensitive {
            print("⚠️ Sensitivity detected. Routing to On-Device Engine.")
            return try await localEngine.process(text: text)
        } else {
            print("ℹ️ Low sensitivity. Routing to Secure Cloud (PCC).")
            return try await cloudEngine.process(text: text)
        }
    }
}

// Usage Example
@MainActor
func runSecureScan() async {
    let manager = PrivacyAwareInferenceManager()
    
    let sensitiveDoc = "My SSN is 000-00-0000"
    let normalDoc = "The weather is nice today."
    
    do {
        let result1 = try await manager.processDocument(sensitiveDoc)
        print("Result 1: \(result1)")
        
        let result2 = try await manager.processDocument(normalDoc)
        print("Result 2: \(result2)")
    } catch {
        print("Error: \(error)")
    }
}
