/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// database.ts
import { VectorRecord } from './types';
import * as SQLite from 'expo-sqlite';

/**
 * Optimized search using a "Bucketing" strategy.
 * 1. Identify the document_id that likely contains the answer (e.g., via keyword match or random selection for this exercise).
 * 2. Filter vectors by that document_id.
 * 3. Calculate Cosine Similarity only on the filtered subset.
 */
export async function findSimilarVectorsOptimized(
  db: SQLite.SQLiteDatabase,
  queryVector: number[],
  targetDocumentId: string,
  limit: number = 5
): Promise<Array<{ record: VectorRecord; similarity: number }>> {
  // We filter by document_id first to reduce the search space (The "Bucket")
  const query = `SELECT * FROM document_vectors WHERE document_id = ?`;

  return new Promise((resolve, reject) => {
    db.transaction((tx) => {
      tx.executeSql(
        query,
        [targetDocumentId],
        (_, { rows }) => {
          const results: Array<{ record: VectorRecord; similarity: number }> = [];
          
          // Perform Cosine Similarity calculation in TypeScript on the subset
          for (let i = 0; i < rows.length; i++) {
            const item = rows.item(i);
            const storedVector: number[] = JSON.parse(item.embedding);
            
            if (storedVector.length !== queryVector.length) continue;

            // Dot Product
            let dotProduct = 0;
            for (let j = 0; j < queryVector.length; j++) {
              dotProduct += queryVector[j] * storedVector[j];
            }

            // Norms
            const queryNorm = Math.sqrt(queryVector.reduce((sum, val) => sum + val * val, 0));
            const storedNorm = Math.sqrt(storedVector.reduce((sum, val) => sum + val * val, 0));

            if (queryNorm === 0 || storedNorm === 0) continue;

            const similarity = dotProduct / (queryNorm * storedNorm);

            results.push({
              record: {
                ...item,
                embedding: storedVector
              },
              similarity
            });
          }

          // Sort and limit
          results.sort((a, b) => b.similarity - a.similarity);
          resolve(results.slice(0, limit));
        },
        (_, error) => {
          reject(error);
          return true;
        }
      );
    });
  });
}
