
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import SwiftData
import Observation

// MARK: - Theoretical Implementation of an AI Memory Model

/// An example of a semantic memory unit.
/// In an AI context, this represents a single 'thought' or 'observation' 
/// that the agent can retrieve later via vector similarity.
@available(iOS 18.0, *)
@Model
final class SemanticMemory {
    // The raw text content of the memory
    var content: String
    
    // The timestamp of when this memory was formed
    var timestamp: Date
    
    // The vector embedding (simplified as an array of Floats)
    // In a real-world RAG implementation, this would be used for 
    // Cosine Similarity calculations.
    @Attribute(.externalStorage) var embedding: [Float]
    
    init(content: String, embedding: [Float]) {
        self.content = content
        self.timestamp = Date()
        self.embedding = embedding
    }
}

// MARK: - The Actor-Based Processing Pattern

/// This actor represents our 'Background Intelligence Worker'.
/// It leverages Swift 6's ModelActor to perform heavy lifting (like embedding generation)
/// without blocking the UI.
@available(iOS 18.0, *)
@ModelActor
actor MemoryIngestionActor {
    /// Processes raw text into a persistent SemanticMemory object.
    /// This demonstrates the 'Why' of SwiftData: safe, background-isolated persistence.
    func ingest(text: String, vector: [Float]) throws {
        // The 'modelContext' is automatically provided by the @ModelActor macro
        let newMemory = SemanticMemory(content: text, embedding: vector)
        
        // We perform the insertion within the actor's isolated context
        modelContext.insert(newMemory)
        
        // Persistence is handled via the container associated with this actor
        try modelContext.save()
        
        print("Successfully ingested memory: \(text.prefix(20))...")
    }
}
