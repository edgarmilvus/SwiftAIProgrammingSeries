
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// @available(iOS 18.0, *) // General availability for SwiftUI for AI Apps
enum InferenceError: Error, LocalizedError, Sendable {
    case modelLoadingFailed(reason: String)
    case invalidInput(description: String)
    case inferenceFailed(underlyingError: Error?)
    case remoteServiceError(statusCode: Int, message: String?)
    case cancelled
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let reason):
            return "Failed to load AI model: \(reason)"
        case .invalidInput(let description):
            return "Invalid input for AI inference: \(description)"
        case .inferenceFailed(let underlyingError):
            let detail = underlyingError?.localizedDescription ?? "unknown reason"
            return "AI inference computation failed: \(detail)"
        case .remoteServiceError(let statusCode, let message):
            return "Remote AI service error (\(statusCode)): \(message ?? "No details")"
        case .cancelled:
            return "AI inference was cancelled."
        case .unknown(let error):
            return "An unexpected error occurred: \(error.localizedDescription)"
        }
    }
}
