
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CoreData
import NaturalLanguage
import Accelerate

actor SemanticSearchEngine {
    private let container: NSPersistentContainer
    private let embeddingModel = NLEmbedding.wordEmbedding(for: .english)

    init(container: NSPersistentContainer) {
        self.container = container
    }

    /// Generates a vector embedding for a given string using NaturalLanguage framework.
    func generateEmbedding(for text: String) async throws -> [Float] {
        guard let embedding = embeddingModel,
              let vector = embedding.vector(for: text) else {
            throw NSError(domain: "EmbeddingError", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to generate embedding"])
        }
        return vector
    }

    /// Stores the embedding in the Node entity.
    func storeEmbedding(for nodeID: NSManagedObjectID, embedding: [Float]) async throws {
        let context = container.newBackgroundContext()
        try await context.perform {
            let node = context.object(with: nodeID) as! Node
            // Convert [Float] to Data for Core Data storage
            node.embedding = Data(buffer: UnsafeBufferPointer(start: embedding, count: embedding.count))
            try context.save()
        }
    }

    /// Performs high-performance similarity search using the Accelerate framework.
    func searchSimilarNodes(to queryText: String, limit: Int) async throws -> [Node] {
        let queryVector = try await generateEmbedding(for: queryText)
        let queryDim = queryVector.count
        
        let context = container.newBackgroundContext()
        
        // 1. Fetch all nodes with embeddings
        let request: NSFetchRequest<Node> = NSFetchRequest(entityName: "Node")
        request.predicate = NSPredicate(format: "embedding != nil")
        
        let allNodes = try context.fetch(request)
        
        // 2. Perform Similarity Calculation
        // We use a struct to keep track of scores during the batch process
        struct ScoredNode {
            let node: Node
            let score: Float
        }
        
        var scoredNodes: [ScoredNode] = []

        for node in allNodes {
            guard let data = node.embedding,
                  let vector = data.withUnsafeBytes({ $0.bindMemory(to: Float.self).baseAddress }) else {
                continue
            }
            
            let nodeVector = Array(UnsafeBufferPointer(start: vector, count: queryDim))
            
            // 3. Accelerate: Cosine Similarity = (A · B) / (||A|| * ||B||)
            // Dot Product
            var dotProduct: Float = 0
            vDSP_dotpr(queryVector, 1, nodeVector, 1, &dotProduct, vDSP_Length(queryDim))
            
            // Magnitudes
            var queryMagSq: Float = 0
            vDSP_svesq(queryVector, 1, &queryMagSq, vDSP_Length(queryDim))
            
            var nodeMagSq: Float = 0
            vDSP_svesq(nodeVector, 1, &nodeMagSq, vDSP_Length(queryDim))
            
            let similarity = dotProduct / (sqrt(queryMagSq) * sqrt(nodeMagSq))
            scoredNodes.append(ScoredNode(node: node, score: similarity))
        }

        // 4. Sort and return top results
        let sorted = scoredNodes.sorted { $0.score > $1.score }
        let topResults = sorted.prefix(limit).map { $0.node }
        
        // We must return objects from the context we used, or pass IDs back to the main thread.
        // For this example, we return the objects, but in production, return NSManagedObjectID.
        return topResults
    }
}

// Helper to convert Data to [Float] safely
extension Data {
    init(buffer: UnsafeBufferPointer<Float>) {
        self = buffer.baseAddress!.withMemoryRebound(to: UInt8.self, capacity: buffer.count * MemoryLayout<Float>.size) {
            Data(bytes: $0, count: buffer.count * MemoryLayout<Float>.size)
        }
    }
}
