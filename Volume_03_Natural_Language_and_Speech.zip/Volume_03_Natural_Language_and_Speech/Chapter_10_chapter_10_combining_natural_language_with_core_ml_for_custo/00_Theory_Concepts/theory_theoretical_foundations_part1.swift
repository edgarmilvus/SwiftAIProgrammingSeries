
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    import NaturalLanguage
    import CoreML

    @available(iOS 18.0, *)
    class CustomTextClassifier {
        private var model: NLModel?

        init() {
            // Model loading can be asynchronous
        }

        func loadModel(named modelName: String) async throws {
            // Assume 'modelName.mlmodel' is bundled in the app
            guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodel") else {
                throw NSError(domain: "CustomTextClassifier", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model not found"])
            }
            self.model = try await NLModel.load(mlModel: modelURL) // Asynchronous model loading
        }

        func classify(text: String) async throws -> String {
            guard let model = self.model else {
                throw NSError(domain: "CustomTextClassifier", code: 2, userInfo: [NSLocalizedDescriptionKey: "Model not loaded"])
            }
            // Inference is also asynchronous
            let prediction = try await model.predictedLabel(for: text)
            return prediction
        }
    }

    @available(iOS 18.0, *)
    func performClassification() async {
        let classifier = CustomTextClassifier()
        do {
            try await classifier.loadModel(named: "MyCustomSentimentModel")
            let text = "This product is absolutely fantastic and works perfectly!"
            let sentiment = try await classifier.classify(text: text)
            print("Text: '\(text)' -> Sentiment: \(sentiment)")
        } catch {
            print("Error during classification: \(error.localizedDescription)")
        }
    }
    