
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CreateML

@available(macOS 14.0, iOS 18.0, *)
struct SongInteraction: Codable {
    let songID: String
    let userID: String
    let genre: String
    let tempoBPM: Double
    let acousticness: Double
    let danceability: Double
    let energy: Double
    let loudnessDB: Double
    let valence: Double
    let artistPopularityScore: Int
    let userActivityContext: String
    let songPlayCountLastMonth: Int
    let userSkipRateForArtist: Double
    let moodCompatibilityScore: Double // Target
}

@available(macOS 14.0, iOS 18.0, *)
func engineerPlaylistFeatures(csvURL: URL) throws -> MLDataTable {
    // Initial MLDataTable: Simulate loading from CSV
    let songData: [String: MLDataColumn] = [
        "songID": .init(array: ["S001", "S002", "S003", "S004", "S005"]),
        "userID": .init(array: ["U001", "U001", "U002", "U003", "U002"]),
        "genre": .init(array: ["Pop", "Rock", "Electronic", "Pop", "Classical"]),
        "tempoBPM": .init(array: [120.0, 90.0, 135.0, 110.0, 60.0]),
        "acousticness": .init(array: [0.1, 0.8, 0.05, 0.3, 0.9]),
        "danceability": .init(array: [0.7, 0.4, 0.9, 0.6, 0.2]),
        "energy": .init(array: [0.8, 0.3, 0.95, 0.7, 0.1]),
        "loudnessDB": .init(array: [-5.0, -12.0, -3.0, -7.0, -20.0]),
        "valence": .init(array: [0.9, 0.2, 0.8, 0.7, 0.1]),
        "artistPopularityScore": .init(array: [80, 50, 95, 70, 30]),
        "userActivityContext": .init(array: ["Workout", "Relax", "Workout", "Commute", "Focus"]),
        "songPlayCountLastMonth": .init(array: [15, 2, 25, 8, 1]),
        "userSkipRateForArtist": .init(array: [0.1, 0.5, 0.05, 0.2, 0.8]),
        "moodCompatibilityScore": .init(array: [0.9, 0.3, 0.95, 0.6, 0.2]) // Target
    ]
    var dataTable = MLDataTable(dictionary: songData)

    // 1. High-Cardinality Feature Handling
    // 'genre': Create ML handles String columns as categorical. If many genres, it creates a sparse representation.
    // 'songID', 'userID': Too high cardinality for direct use as features in a typical tabular model.
    // For this exercise, we'll remove them. In a more advanced system, these might be used for embeddings
    // or aggregated features (e.g., user's average tempo preference).
    // We will exclude them in the final column selection.

    // 2. Polynomial Features
    // Create squared terms for tempoBPM and loudnessDB.
    dataTable["tempoBPM_squared"] = dataTable["tempoBPM"] * dataTable["tempoBPM"]
    dataTable["loudnessDB_squared"] = dataTable["loudnessDB"] * dataTable["loudnessDB"]

    // 3. Interaction Features
    // Design two interaction features combining song attributes with userActivityContext.
    // a) Danceability when user activity is "Workout"
    dataTable["workout_danceability"] = dataTable.mapColumns { (row: MLDataRow) -> Double in
        if row["userActivityContext"]?.stringValue == "Workout" {
            return row["danceability"]?.doubleValue ?? 0.0
        } else {
            return 0.0
        }
    }
    // b) Energy when user activity is "Focus"
    dataTable["focus_energy"] = dataTable.mapColumns { (row: MLDataRow) -> Double in
        if row["userActivityContext"]?.stringValue == "Focus" {
            return row["energy"]?.doubleValue ?? 0.0
        } else {
            return 0.0
        }
    }

    // 4. Cyclical Feature Encoding (Conceptual, assuming 'hourOfDay' was available)
    // For demonstration, let's add a dummy 'hourOfDay' column.
    dataTable["hourOfDay"] = MLDataColumn(array: [14, 9, 18, 11, 7]) // Example hours
    dataTable["hour_sin"] = dataTable["hourOfDay"].map { (hour: Int) -> Double in
        sin((Double(hour) / 24.0) * 2.0 * .pi)
    }
    dataTable["hour_cos"] = dataTable["hourOfDay"].map { (hour: Int) -> Double in
        cos((Double(hour) / 24.0) * 2.0 * .pi)
    }

    // 5. Handling Skewed Distributions
    // Apply log transformation to songPlayCountLastMonth. Add 1 to handle zero values.
    dataTable["log_songPlayCount"] = dataTable["songPlayCountLastMonth"].map { (count: Int) -> Double in
        log(Double(count) + 1.0)
    }

    // 6. Final MLDataTable
    // Select all engineered features and the target, excluding original raw features that were transformed
    // and high-cardinality IDs.
    let finalColumns = [
        "genre", // Handled by Create ML
        "tempoBPM", "tempoBPM_squared", // Original and polynomial
        "acousticness",
        "danceability",
        "energy",
        "loudnessDB", "loudnessDB_squared", // Original and polynomial
        "valence",
        "artistPopularityScore",
        "userActivityContext", // Handled by Create ML
        "userSkipRateForArtist",
        "workout_danceability", // Interaction feature
        "focus_energy", // Interaction feature
        "hour_sin", "hour_cos", // Cyclical time features
        "log_songPlayCount", // Transformed skewed feature
        "moodCompatibilityScore" // Target
    ]
    dataTable = dataTable[finalColumns]

    return dataTable
}

// Example usage:
if #available(macOS 14.0, iOS 18.0, *) {
    do {
        let dummyURL = URL(fileURLWithDataRepresentation: Data(), relativeTo: nil)
        let preparedTable = try engineerPlaylistFeatures(csvURL: dummyURL)
        print("Prepared Music Playlist Data Table:\n\(preparedTable.description)")
    } catch {
        print("Error preparing music playlist data: \(error)")
    }
} else {
    print("CreateML features require macOS 14.0 / iOS 18.0 or later.")
}
