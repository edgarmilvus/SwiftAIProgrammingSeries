
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import MLX

@available(iOS 18.0, macOS 15.0, *)
func calculateCustomLoss(parameter: MLXArray, targetValue: MLXArray) -> MLXArray {
    // 1. Define a Custom Loss Function
    // Loss: (parameter - targetValue)^4 + 0.1 * parameter^2
    let difference = parameter - targetValue
    let term1 = pow(difference, MLXArray(4.0)) // (param - target)^4
    let term2 = MLXArray(0.1) * pow(parameter, MLXArray(2.0)) // 0.1 * param^2 (regularization-like term)
    return term1 + term2
}

@available(iOS 18.0, macOS 15.0, *)
func demonstrateGradientCalculation() {
    let initialParameter = MLXArray(1.5) // Example initial parameter
    let observedTarget = MLXArray(2.0)    // Example target value

    print("Initial Parameter: \(initialParameter.item())")
    print("Observed Target: \(observedTarget.item())")

    // 2. Use valueAndGradient
    // valueAndGradient takes a function (MLXArray, MLXArray) -> MLXArray
    // and returns a new function (MLXArray, MLXArray) -> (MLXArray, MLXArray)
    // where the first MLXArray in the tuple is the value, and the second is the gradient
    // with respect to the *first* argument of the original function.
    let (loss, gradient) = valueAndGradient(calculateCustomLoss)(initialParameter, observedTarget)

    // 3. Demonstrate Lazy Evaluation
    // At this point, when `valueAndGradient` is called, MLX does not immediately perform
    // the numerical computations. Instead, it constructs a computation graph (or "trace")
    // that represents the operations needed to calculate both the loss and its gradient.
    // The `loss` and `gradient` variables are MLXArray instances that act as symbolic
    // handles to nodes in this graph.
    //
    // The actual computation on the underlying hardware (e.g., GPU on Apple Silicon)
    // is deferred. It only occurs when the value of `loss` or `gradient` is explicitly
    // requested, for example, by calling `.item()`, `.value`, or when printing the
    // MLXArray, or when it's involved in an operation that requires its concrete value.
    // This lazy evaluation is a key performance feature of MLX, allowing it to optimize
    // the entire graph before execution and avoid unnecessary intermediate computations.

    // 4. Print Results
    // Accessing .item() here forces the computation graph to execute.
    print("Calculated Loss: \(loss.item())")
    print("Calculated Gradient (w.r.t. parameter): \(gradient.item())")
}

// To run this, you would call:
// demonstrateGradientCalculation()
