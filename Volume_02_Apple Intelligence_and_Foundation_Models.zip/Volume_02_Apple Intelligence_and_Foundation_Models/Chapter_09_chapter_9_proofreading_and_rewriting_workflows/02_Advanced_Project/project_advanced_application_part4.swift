
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

    /// `DocumentRefinementService` manages the document content and orchestrates
    /// text refinement operations using Apple Intelligence.
    /// It provides methods to initiate a refinement, and then to apply the suggested changes.
    @available(iOS 18.0, *)
    class DocumentRefinementService: ObservableObject { // ObservableObject for potential SwiftUI integration
        @Published var documentContent: String // The mutable content of our document
        @Published var lastRefinementResult: TextRefinementResult? // Stores the last result for review/application

        private let textProcessor: TextProcessor // The core Apple Intelligence API for text operations

        /// Initializes the service with an initial document content.
        /// - Parameter initialContent: The starting text for the document.
        init(initialContent: String = "") {
            self.documentContent = initialContent
            self.textProcessor = TextProcessor() // Initialize TextProcessor
        }

        /// Initiates an asynchronous text refinement operation on a specified range of the document.
        /// - Parameters:
        ///   - range: The `NSRange` within `documentContent` to apply the refinement to.
        ///   - action: The `TextRefinementAction` to perform (e.g., proofread, summarize).
        /// - Returns: A `TextRefinementResult` containing the original and suggested text.
        /// - Throws: `DocumentRefinementError` if the range is invalid, no text is selected,
        ///           or the Intelligence service encounters an error.
        func initiateRefinement(in nsRange: NSRange, action: TextRefinementAction) async throws -> TextRefinementResult {
            guard let range = Range(nsRange, in: documentContent) else {
                throw DocumentRefinementError.invalidRange
            }

            let selectedText = String(documentContent[range])
            guard !selectedText.isEmpty else {
                throw DocumentRefinementError.noTextSelected
            }

            do {
                // Perform the text refinement using Apple Intelligence's TextProcessor.
                // This is an asynchronous operation, leveraging Swift's async/await.
                let suggestedText = try await textProcessor.refineText(
                    selectedText,
                    refinement: action.textRefinement
                )

                let result = TextRefinementResult(
                    originalText: selectedText,
                    suggestedText: suggestedText,
                    originalRange: range,
                    action: action
                )
                DispatchQueue.main.async {
                    self.lastRefinementResult = result // Update published property on main thread
                }
                return result
            } catch let error as TextProcessorError {
                // Specific error handling for TextProcessor errors
                print("TextProcessor Error: \(error.localizedDescription)")
                throw DocumentRefinementError.refinementFailed(error.localizedDescription)
            } catch {
                // General error handling for any other issues
                print("Unknown Intelligence Service Error: \(error.localizedDescription)")
                throw DocumentRefinementError.intelligenceServiceUnavailable(error)
            }
        }

        /// Applies the suggested changes from a `TextRefinementResult` to the `documentContent`.
        /// - Parameter result: The `TextRefinementResult` object containing the changes to apply.
        func applyRefinement(_ result: TextRefinementResult) {
            // Replace the original text segment with the suggested text.
            documentContent.replaceSubrange(result.originalRange, with: result.suggestedText)
            DispatchQueue.main.async {
                self.lastRefinementResult = nil // Clear the last result after application
            }
            print("Refinement applied: '\(result.originalText)' -> '\(result.suggestedText)'")
        }

        /// Resets the document content to an empty string.
        func clearDocument() {
            documentContent = ""
            lastRefinementResult = nil
        }
    }
    