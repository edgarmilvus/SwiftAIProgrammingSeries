
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

/// A manager responsible for the atomic persistence of the HNSW graph.
final class PersistentHNSWManager: Sendable {
    
    struct GraphHeader: Codable {
        let version: Int32
        let dimension: Int32
        let vectorCount: Int32
        let layerCount: Int32
    }

    /// Saves the graph components to a file using an atomic write.
    func save(
        header: GraphHeader,
        vectors: [Float],
        edges: [[Int]],
        to url: URL
    ) throws {
        let fileManager = FileManager.default
        let tempURL = url.appendingPathExtension("tmp")
        
        // 1. Encode Header
        let headerData = try JSONEncoder().encode(header)
        
        // 2. Prepare Data Buffer
        var totalSize = headerData.count + (vectors.count * MemoryLayout<Float>.size) + (edges.count * MemoryLayout<Int>.size)
        // Note: For simplicity in this exercise, we assume fixed-size edge lists. 
        // In production, edges would be stored as a flattened array with an offset table.
        
        var combinedData = Data()
        combinedData.append(headerData)
        
        // Append Vectors as raw bytes
        vectors.withUnsafeBytes { combinedData.append(contentsOf: $0) }
        
        // Append Edges (Flattened)
        let flattenedEdges = edges.flatMap { $0 }
        flattenedEdges.withUnsafeBytes { combinedData.append(contentsOf: $0) }
        
        // 3. Atomic Write
        try combinedData.write(to: tempURL, options: .atomic)
        try fileManager.replaceItemAt(url, withItemAt: tempURL)
    }

    /// Loads the graph using memory mapping to allow the OS to manage RAM.
    func loadMappedVectors(from url: URL, count: Int, dimension: Int) throws -> [Float] {
        // Use .mappedIfSafe to invoke mmap()
        let data = try Data(contentsOf: url, options: .mappedIfSafe)
        
        // Calculate offset where vector data begins (skipping header)
        // In a real implementation, the header size would be parsed dynamically.
        let headerSize = 128 // Hypothetical fixed header size for demonstration
        let vectorOffset = headerSize
        
        return data.withUnsafeBytes { buffer in
            let floatPtr = buffer.baseAddress!.advanced(by: vectorOffset).assumingMemoryBound(to: Float.self)
            let vectorArray = Array(UnsafeBufferPointer(start: floatPtr, count: count * dimension))
            return vectorArray
        }
    }
}

// MARK: - Usage Implementation
@available(iOS 18.0, *)
func demonstratePersistence() throws {
    let manager = PersistentHNSWManager()
    let url = FileManager.default.temporaryDirectory.appendingPathComponent("graph.hnsw")
    
    let header = PersistentHNSWManager.GraphHeader(version: 1, dimension: 3, vectorCount: 2, layerCount: 1)
    let vectors: [Float] = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6]
    let edges: [[Int]] = [[1], [0]]
    
    try manager.save(header: header, vectors: vectors, edges: edges, to: url)
    print("Graph saved to \(url.path)")
    
    let loadedVectors = try manager.loadMappedVectors(from: url, count: 2, dimension: 3)
    print("Loaded vectors: \(loadedVectors)")
}
