
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import CoreData
import CloudKit
import Combine

@available(iOS 18.0, *)
actor SemanticSyncEngine {
    let container: NSPersistentCloudKitContainer
    let vectorContext: NSManagedObjectContext
    
    // A stream to notify the UI/Search Engine to re-index
    private let reindexSubject = PassthroughSubject<Void, Never>()
    var reindexPublisher: AnyPublisher<Void, Never> { reindexSubject.eraseToAnyPublisher() }

    init(container: NSPersistentCloudKitContainer) {
        self.container = container
        // Create a background context specifically for heavy vector processing
        self.vectorContext = container.newBackgroundContext()
        self.vectorContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
    }
    
    /// Observes CloudKit remote changes and triggers re-indexing.
    func startObservingRemoteChanges() {
        NotificationCenter.default.addObserver(
            forName: .NSPersistentStoreRemoteChange,
            object: container.persistentStoreCoordinator,
            queue: .main
        ) { [weak self] _ in
            Task { [weak self] in
                await self?.handleRemoteChange()
            }
        }
    }
    
    private func handleRemoteChange() async {
        print("Remote change detected. Preparing re-index...")
        // In a real app, we would use NSPersistentHistoryToken to only 
        // process the changes that occurred since the last sync.
        reindexSubject.send()
    }

    /// Converts a high-dimensional vector [Float] into a Data blob for CloudKit storage.
    /// This avoids the overhead of breaking vectors into multiple CKRecord attributes.
    func serializeVector(_ vector: [Float]) -> Data {
        return vector.withUnsafeBytes { Data($0) }
    }

    /// Converts a Data blob back into a [Float] vector.
    func deserializeVector(_ data: Data) -> [Float] {
        return data.withUnsafeBytes { buffer in
            Array(buffer.bindMemory(to: Float.self))
        }
    }
    
    /// Processes a new note and its embedding in the background.
    func processAndSaveNote(text: String, vector: [Float]) async throws {
        try await vectorContext.perform {
            let note = NoteEntity(context: self.vectorContext)
            note.text = text
            note.timestamp = Date()
            
            // Store the vector as a Data blob to stay within the 1MB CKRecord limit
            // A 1536-dim vector is only ~6KB, well within limits.
            note.vectorBlob = self.serializeVector(vector)
            
            try self.vectorContext.save()
        }
    }
}

// Note: NoteEntity is a placeholder for a Core Data Managed Object
// with attributes: text (String), timestamp (Date), vectorBlob (Data).
