
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI

// Define the steps as Codable and Hashable for NavigationPath
enum WizardStep: Codable, Hashable {
    case modelSelection
    case dataSourceConfig
    case parameterTuning
    case reviewAndDeploy
}

// Observable object to hold wizard state across steps
@Observable
class ModelConfiguration: Codable, Hashable {
    var selectedModel: String?
    var selectedDataSource: String?
    var temperature: Double = 0.5
    var maxTokens: Int = 128
    var learningRate: Double = 0.001

    // Conform to Hashable and Codable for NavigationPath
    func hash(into hasher: inout Hasher) {
        hasher.combine(selectedModel)
        hasher.combine(selectedDataSource)
        hasher.combine(temperature)
        hasher.combine(maxTokens)
        hasher.combine(learningRate)
    }

    static func == (lhs: ModelConfiguration, rhs: ModelConfiguration) -> Bool {
        lhs.selectedModel == rhs.selectedModel &&
        lhs.selectedDataSource == rhs.selectedDataSource &&
        lhs.temperature == rhs.temperature &&
        lhs.maxTokens == rhs.maxTokens &&
        lhs.learningRate == rhs.learningRate
    }

    // Codable conformance
    enum CodingKeys: String, CodingKey {
        case selectedModel, selectedDataSource, temperature, maxTokens, learningRate
    }

    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        selectedModel = try container.decodeIfPresent(String.self, forKey: .selectedModel)
        selectedDataSource = try container.decodeIfPresent(String.self, forKey: .selectedDataSource)
        temperature = try container.decode(Double.self, forKey: .temperature)
        maxTokens = try container.decode(Int.self, forKey: .maxTokens)
        learningRate = try container.decode(Double.self, forKey: .learningRate)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(selectedModel, forKey: .selectedModel)
        try container.encodeIfPresent(selectedDataSource, forKey: .selectedDataSource)
        try container.encode(temperature, forKey: .temperature)
        try container.encode(maxTokens, forKey: .maxTokens)
        try container.encode(learningRate, forKey: .learningRate)
    }

    init() {} // Default initializer for new configurations
}

struct AIModelStudioApp: App {
    var body: some Scene {
        WindowGroup {
            DashboardView()
        }
    }
}

struct DashboardView: View {
    @State private var showWizard = false

    var body: some View {
        VStack {
            Spacer()
            Text("AI Model Studio Dashboard")
                .font(.largeTitle)
                .padding()
            Button("Configure New Model") {
                showWizard = true
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            Spacer()
        }
        .fullScreenCover(isPresented: $showWizard) {
            ModelConfigWizardView(isShowingWizard: $showWizard)
        }
    }
}

struct ModelConfigWizardView: View {
    @Binding var isShowingWizard: Bool
    @State private var path = NavigationPath()
    @State private var config = ModelConfiguration() // State for the wizard's configuration
    @State private var showDeployAlert = false

    var body: some View {
        NavigationStack(path: $path) {
            ModelSelectionStep(config: config)
                .navigationTitle("Step 1: Model Selection")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("Cancel") {
                            isShowingWizard = false
                        }
                    }
                }
                .navigationDestination(for: WizardStep.self) { step in
                    switch step {
                    case .modelSelection:
                        ModelSelectionStep(config: config)
                    case .dataSourceConfig:
                        DataSourceConfigStep(config: config)
                    case .parameterTuning:
                        ParameterTuningStep(config: config)
                    case .reviewAndDeploy:
                        ReviewAndDeployStep(config: config, path: $path, showDeployAlert: $showDeployAlert)
                    }
                }
        }
        .alert("Model Deployment", isPresented: $showDeployAlert) {
            Button("OK") {
                // After deployment confirmed, dismiss the wizard
                isShowingWizard = false
            }
        } message: {
            Text("Model '\(config.selectedModel ?? "Unknown")' is deploying with your settings.")
        }
    }
}

// MARK: - Wizard Steps

struct ModelSelectionStep: View {
    @Bindable var config: ModelConfiguration // Use @Bindable for Observable object
    @Environment(\.path) private var path // Access NavigationPath from environment

    let models = ["GPT-4", "Stable Diffusion", "Custom Vision Model"]

    var body: some View {
        VStack(spacing: 20) {
            Picker("Select Base Model", selection: $config.selectedModel) {
                Text("None").tag(String?.none) // Optional selection
                ForEach(models, id: \.self) { model in
                    Text(model).tag(model as String?)
                }
            }
            .pickerStyle(.inline)
            .padding()

            Spacer()

            Button("Next") {
                path.append(WizardStep.dataSourceConfig)
            }
            .buttonStyle(.borderedProminent)
            .disabled(config.selectedModel == nil)
        }
        .navigationTitle("Step 1: Model Selection")
    }
}

struct DataSourceConfigStep: View {
    @Bindable var config: ModelConfiguration
    @Environment(\.path) private var path

    let dataSources = ["Upload CSV", "Connect to Database", "Use Pre-trained Dataset"]

    var body: some View {
        VStack(spacing: 20) {
            Text("Configure Data Source for \(config.selectedModel ?? "your model")")
                .font(.headline)
                .multilineTextAlignment(.center)
                .padding()

            Picker("Select Data Source", selection: $config.selectedDataSource) {
                Text("None").tag(String?.none)
                ForEach(dataSources, id: \.self) { source in
                    Text(source).tag(source as String?)
                }
            }
            .pickerStyle(.inline)
            .padding()

            Spacer()

            Button("Next") {
                path.append(WizardStep.parameterTuning)
            }
            .buttonStyle(.borderedProminent)
            .disabled(config.selectedDataSource == nil)
        }
        .navigationTitle("Step 2: Data Source")
    }
}

struct ParameterTuningStep: View {
    @Bindable var config: ModelConfiguration
    @Environment(\.path) private var path

    var body: some View {
        VStack(spacing: 30) {
            Text("Tune Parameters for \(config.selectedModel ?? "your model")")
                .font(.headline)
                .multilineTextAlignment(.center)
                .padding()

            VStack(alignment: .leading) {
                Text("Temperature: \(config.temperature, format: .number.precision(.fractionLength(2)))")
                Slider(value: $config.temperature, in: 0.0...1.0, step: 0.01)
            }

            VStack(alignment: .leading) {
                Text("Max Tokens: \(config.maxTokens)")
                Slider(value: Binding(get: { Double(config.maxTokens) }, set: { config.maxTokens = Int($0) }),
                       in: 16...512, step: 16)
            }

            VStack(alignment: .leading) {
                Text("Learning Rate: \(config.learningRate, format: .number.precision(.fractionLength(3)))")
                Slider(value: $config.learningRate, in: 0.0001...0.01, step: 0.0001)
            }
            .padding(.horizontal)

            Spacer()

            Button("Next") {
                // Basic validation for parameters (e.g., within range, already handled by slider)
                path.append(WizardStep.reviewAndDeploy)
            }
            .buttonStyle(.borderedProminent)
        }
        .navigationTitle("Step 3: Parameters")
    }
}

struct ReviewAndDeployStep: View {
    @Bindable var config: ModelConfiguration
    @Binding var path: NavigationPath // Direct binding to path for programmatic pop
    @Binding var showDeployAlert: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Review Configuration")
                .font(.largeTitle)
                .padding(.bottom, 10)

            Group {
                Text("**Model:** \(config.selectedModel ?? "N/A")")
                Text("**Data Source:** \(config.selectedDataSource ?? "N/A")")
                Text("**Temperature:** \(config.temperature, format: .number.precision(.fractionLength(2)))")
                Text("**Max Tokens:** \(config.maxTokens)")
                Text("**Learning Rate:** \(config.learningRate, format: .number.precision(.fractionLength(4)))")
            }
            .font(.body)

            Spacer()

            Button("Deploy Model") {
                // Simulate deployment process
                print("Deploying model with config: \(config)")
                path.removeAll() // Pop entire wizard stack
                showDeployAlert = true // Show confirmation alert
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .frame(maxWidth: .infinity)
        }
        .padding()
        .navigationTitle("Step 4: Review & Deploy")
    }
}
