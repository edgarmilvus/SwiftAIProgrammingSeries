
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

    // MARK: - Training Function

    /// Asynchronously trains the AdaptiveContrastModule using synthetic data.
    /// Demonstrates MLX's valueAndGradient for efficient loss and gradient computation.
    /// - Parameters:
    ///   - model: The AdaptiveContrastModule instance to train.
    ///   - numEpochs: The number of training iterations.
    ///   - learningRate: The step size for parameter updates.
    ///   - batchSize: The number of samples per training batch.
    ///   - patchSize: The size of each image patch.
    /// - Throws: MLXEnhancementError if training fails.
    @available(iOS 18.0, macOS 15.0, *) // Concurrency features often require newer OS versions
    func trainModel(
        model: AdaptiveContrastModule,
        numEpochs: Int,
        learningRate: Float,
        batchSize: Int,
        patchSize: Int
    ) async throws {
        print("\nStarting model training...")

        // Optimizer: Stochastic Gradient Descent (SGD) is a common choice.
        // It updates parameters in the direction opposite to the gradient.
        let optimizer = MLXNN.Optimizers.SGD(learningRate: learningRate)

        // Set the model to training mode. This can affect layers like BatchNorm or Dropout,
        // though our simple module doesn't have them. It's good practice.
        model.train()

        for epoch in 0..<numEpochs {
            // Generate a fresh batch of synthetic data for each epoch or iteration
            // In a real app, you'd load actual data.
            let (inputs, targets) = generateSyntheticData(batchSize: batchSize, patchSize: patchSize)

            // CRITICAL MLX PATTERN: valueAndGradient
            // This function takes a closure that computes a scalar loss
            // and returns a tuple containing the loss value and a dictionary of gradients
            // for the specified parameters. It's highly optimized for this task.
            let lossAndGrad = MLX.valueAndGradient(model.parameters()) { params in
                // Create a temporary model from the current parameters for gradient computation.
                // This ensures gradients are computed against the parameters at this specific point.
                let tempModel = try! model.update(parameters: params)
                let predictions = tempModel(inputs)
                return mseLoss(predictions: predictions, targets: targets)
            }

            let loss = lossAndGrad.value
            let gradients = lossAndGrad.gradients

            // Apply gradients to update model parameters using the optimizer.
            // The optimizer updates `model.parameters()` in place.
            optimizer.update(model: model, gradients: gradients)

            // Print progress. The `.item()` call forces lazy evaluation of the loss.
            print("Epoch \(epoch + 1)/\(numEpochs), Loss: \(loss.item())")

            // Basic check for divergence
            if loss.item().isNaN || loss.item().isInfinite {
                throw MLXEnhancementError.trainingFailed("Loss diverged to NaN or Infinite.")
            }
        }
        print("Training complete.")
    }
    