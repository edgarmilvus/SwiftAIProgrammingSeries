
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import AVFoundation
import Vision
import CoreML

// MARK: - Dummy Core ML Model Class (Assumed Auto-Generated)
// Similar to previous exercises, this is a placeholder.
@available(iOS 11.0, *)
class MyRecyclingClassifierInput : MLFeatureProvider {
    var featureNames: Set<String> { return ["image"] }
    private let image: CVPixelBuffer
    init(image: CVPixelBuffer) { self.image = image }
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "image" { return MLFeatureValue(pixelBuffer: image) }
        return nil
    }
}

@available(iOS 11.0, *)
class MyRecyclingClassifierOutput : MLFeatureProvider {
    var featureNames: Set<String> { return ["classLabelProbs", "classLabel"] }
    private let classLabelProbs: [String : Double]
    private let classLabel: String
    init(classLabelProbs: [String : Double], classLabel: String) {
        self.classLabelProbs = classLabelProbs
        self.classLabel = classLabel
    }
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "classLabelProbs" { return MLFeatureValue(dictionary: classLabelProbs as [String : NSNumber]) }
        if featureName == "classLabel" { return MLFeatureValue(string: classLabel) }
        return nil
    }
}

@available(iOS 11.0, *)
class MyRecyclingClassifier {
    var model: MLModel

    init() {
        // Dummy model for compilation purposes.
        // Simulate some common recycling items.
        class DummyMLModel: MLModel {
            override func prediction(from input: MLFeatureProvider, options: MLPredictionOptions) throws -> MLFeatureProvider {
                // In a real scenario, the model would analyze the input image.
                // Here, we'll just cycle through some predictions for demonstration.
                let classes = ["Recyclable Plastic", "Cardboard", "Glass", "Non-Recyclable"]
                let randomClass = classes.randomElement()!
                
                var probs: [String: Double] = [:]
                for cls in classes {
                    probs[cls] = (cls == randomClass) ? 0.9 + Double.random(in: -0.05...0.05) : Double.random(in: 0.01...0.03)
                }
                
                // Normalize probabilities
                let sumProbs = probs.values.reduce(0, +)
                probs = probs.mapValues { $0 / sumProbs }
                
                return MyRecyclingClassifierOutput(classLabelProbs: probs, classLabel: randomClass)
            }
        }
        self.model = DummyMLModel()
    }

    convenience init(configuration: MLModelConfiguration) throws {
        self.init() // Simplified for dummy model
    }
    
    // The actual prediction method would be generated, e.g.:
    func prediction(image: CVPixelBuffer) throws -> MyRecyclingClassifierOutput {
        // For dummy, just return a fixed output that cycles
        let classes = ["Recyclable Plastic", "Cardboard", "Glass", "Non-Recyclable"]
        let randomClass = classes.randomElement()!
        
        var probs: [String: Double] = [:]
        for cls in classes {
            probs[cls] = (cls == randomClass) ? 0.9 + Double.random(in: -0.05...0.05) : Double.random(in: 0.01...0.03)
        }
        let sumProbs = probs.values.reduce(0, +)
        probs = probs.mapValues { $0 / sumProbs }
        
        return MyRecyclingClassifierOutput(classLabelProbs: probs, classLabel: randomClass)
    }
}

// MARK: - CameraFeedProcessor (from snippet, expanded)
@available(iOS 11.0, *)
class CameraFeedProcessor: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {

    private let visionSequenceHandler = VNSequenceRequestHandler()
    private var coreMLRequest: VNCoreMLRequest?
    
    // Delegate to communicate results back to UI
    weak var delegate: RealtimeClassificationDelegate?

    // Dedicated queue for Vision requests to avoid blocking the main thread
    private let visionProcessingQueue = DispatchQueue(label: "com.app.visionProcessingQueue", qos: .userInitiated)

    override init() {
        super.init()
        setupCoreMLModel()
    }

    private func setupCoreMLModel() {
        do {
            let configuration = MLModelConfiguration()
            // Performance Consideration:
            // .all: Uses all available compute units (CPU, GPU, Neural Engine). Generally fastest.
            // .cpuAndGPU: Uses CPU and GPU.
            // .cpuOnly: Uses only CPU. Slower, but can be useful for debugging or specific scenarios.
            // For real-time, .all is usually preferred.
            configuration.computeUnits = .all
            
            // Optional: preferredMetalDevice can be set if you have multiple GPUs,
            // but usually the system default is sufficient.
            // if let metalDevice = MTLCreateSystemDefaultDevice() {
            //     configuration.preferredMetalDevice = metalDevice
            // }

            let model = try MyRecyclingClassifier(configuration: configuration).model
            let visionModel = try VNCoreMLModel(for: model)
            
            coreMLRequest = VNCoreMLRequest(model: visionModel) { [weak self] request, error in
                self?.processObservations(for: request, error: error)
            }
            coreMLRequest?.imageCropAndScaleOption = .centerCrop // Or .scaleFit, .scaleFill based on model training
        } catch {
            print("Failed to load Core ML model: \(error)")
        }
    }

    // AVCaptureVideoDataOutputSampleBufferDelegate method
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer),
              let request = coreMLRequest else { return }

        // Get the orientation of the image buffer
        // This is crucial for Vision to correctly interpret the image.
        // For a typical back camera in portrait orientation, it's .right.
        let orientation = self.imageOrientation(from: connection)

        // Perform Vision request on the dedicated background queue
        visionProcessingQueue.async {
            do {
                try self.visionSequenceHandler.perform([request], on: pixelBuffer, orientation: orientation)
            } catch {
                print("Failed to perform Vision request: \(error)")
            }
        }
    }

    private func processObservations(for request: VNRequest, error: Error?) {
        // This method is called on the 'visionProcessingQueue' where the request was performed.
        // All UI updates must be dispatched to the main thread.
        guard let observations = request.results as? [VNClassificationObservation] else {
            print("No classification observations: \(error?.localizedDescription ?? "Unknown error")")
            DispatchQueue.main.async {
                self.delegate?.didUpdateClassification(label: "No Detection", confidence: 0)
            }
            return
        }

        if let topObservation = observations.first {
            let identifier = topObservation.identifier
            let confidence = topObservation.confidence

            DispatchQueue.main.async {
                // Inform the delegate (ViewController) to update UI
                self.delegate?.didUpdateClassification(label: identifier, confidence: confidence)
            }
        } else {
            DispatchQueue.main.async {
                self.delegate?.didUpdateClassification(label: "No Object", confidence: 0)
            }
        }
    }
    
    // Helper to get correct image orientation for Vision from AVCaptureConnection
    private func imageOrientation(from connection: AVCaptureConnection) -> CGImagePropertyOrientation {
        let currentDeviceOrientation = UIDevice.current.orientation
        let videoOrientation = connection.videoOrientation
        
        switch (currentDeviceOrientation, videoOrientation) {
        case (.portrait, .portrait): return .right
        case (.portraitUpsideDown, .portraitUpsideDown): return .left
        case (.landscapeLeft, .landscapeLeft): return .up
        case (.landscapeRight, .landscapeRight): return .down
        // Default or other cases
        default: return .right // Assume portrait right for back camera
        }
    }
}

// MARK: - RealtimeClassificationDelegate Protocol
protocol RealtimeClassificationDelegate: AnyObject {
    func didUpdateClassification(label: String, confidence: Float)
}

// MARK: - ViewController Implementation
class RealtimeClassificationViewController: UIViewController, RealtimeClassificationDelegate {

    private let previewView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .black
        return view
    }()

    private let predictionLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        label.textColor = .white
        label.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        label.text = "Waiting for Camera..."
        label.numberOfLines = 0
        return label
    }()

    private var captureSession: AVCaptureSession?
    private var previewLayer: AVCaptureVideoPreviewLayer?
    private let cameraFeedProcessor = CameraFeedProcessor()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        cameraFeedProcessor.delegate = self
        checkCameraPermissionsAndSetup()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = previewView.bounds
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        captureSession?.stopRunning() // Stop session when view disappears
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground
        view.addSubview(previewView)
        view.addSubview(predictionLabel)

        NSLayoutConstraint.activate([
            previewView.topAnchor.constraint(equalTo: view.topAnchor),
            previewView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            previewView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            previewView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            predictionLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            predictionLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            predictionLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            predictionLabel.heightAnchor.constraint(equalToConstant: 80)
        ])
    }

    private func checkCameraPermissionsAndSetup() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            setupCameraSession()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                guard let self = self else { return }
                if granted {
                    DispatchQueue.main.async {
                        self.setupCameraSession()
                    }
                } else {
                    DispatchQueue.main.async {
                        self.predictionLabel.text = "Camera access denied."
                    }
                }
            }
        case .denied, .restricted:
            predictionLabel.text = "Camera access denied. Please enable in Settings."
        @unknown default:
            predictionLabel.text = "Unknown camera authorization status."
        }
    }

    private func setupCameraSession() {
        captureSession = AVCaptureSession()
        guard let captureSession = captureSession else { return }

        // 2. Camera Setup: Configure AVCaptureSession
        captureSession.beginConfiguration()

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            print("Could not create video input.")
            captureSession.commitConfiguration()
            return
        }

        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        }

        let videoOutput = AVCaptureVideoDataOutput()
        // Set the pixel format to something Vision can work with, like BGRA
        videoOutput.setSampleBufferDelegate(cameraFeedProcessor, queue: cameraFeedProcessor.visionProcessingQueue) // Process on background queue
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        }

        // Set desired video orientation for the output connection
        if let connection = videoOutput.connection(with: .video) {
            connection.videoOrientation = .portrait
            // Optional: Set video stabilization
            if connection.isVideoStabilizationSupported {
                connection.preferredVideoStabilizationMode = .standard
            }
        }

        captureSession.commitConfiguration()

        // Setup preview layer
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer?.videoGravity = .resizeAspectFill
        previewView.layer.addSublayer(previewLayer!)

        // Start the session on a background queue
        DispatchQueue.global(qos: .userInitiated).async {
            captureSession.startRunning()
        }
    }
    
    // MARK: - RealtimeClassificationDelegate
    func didUpdateClassification(label: String, confidence: Float) {
        // This method is always called on the main thread by CameraFeedProcessor
        predictionLabel.text = "\(label) (\(String(format: "%.1f%%", confidence * 100)))"
    }
}
