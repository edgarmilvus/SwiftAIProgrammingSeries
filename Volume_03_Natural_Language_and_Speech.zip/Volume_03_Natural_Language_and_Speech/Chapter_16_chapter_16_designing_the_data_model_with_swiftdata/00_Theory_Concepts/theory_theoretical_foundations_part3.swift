
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

// Example of a SwiftData model for storing NLP sentiment analysis results
@available(iOS 18.0, *)
@Model
final class SentimentAnalysisResult {
    var text: String
    var score: Double // e.g., -1.0 to 1.0
    var category: SentimentCategory
    var timestamp: Date

    init(text: String, score: Double, category: SentimentCategory, timestamp: Date) {
        self.text = text
        self.score = score
        self.category = category
        self.timestamp = timestamp
    }
}

@available(iOS 18.0, *)
enum SentimentCategory: String, Codable { // Codable for potential future use or complex types
    case positive
    case negative
    case neutral
    case mixed
}

// An actor to handle AI processing and data saving in the background
@available(iOS 18.0, *)
actor AIServiceManager {
    private let modelContext: ModelContext // Each actor can have its own isolated context

    init(modelContainer: ModelContainer) {
        // Create a new ModelContext for this actor's isolated use
        self.modelContext = ModelContext(modelContainer)
    }

    // Function to process text using an NLP framework and save the result
    func processAndSaveSentiment(for text: String) async throws {
        // Simulate AI processing (e.g., using NLTagger.sentiment(for:) from a previous chapter)
        // In a real app, this would involve actual NLP framework calls
        print("[\(Self.self)] Processing text for sentiment: '\(text)'")
        
        let simulatedScore = Double.random(in: -1.0...1.0)
        let simulatedCategory: SentimentCategory
        if simulatedScore > 0.3 {
            simulatedCategory = .positive
        } else if simulatedScore < -0.3 {
            simulatedCategory = .negative
        } else {
            simulatedCategory = .neutral
        }

        let newResult = SentimentAnalysisResult(text: text, score: simulatedScore, category: simulatedCategory, timestamp: Date())
        modelContext.insert(newResult)
        
        // Saving is an async operation and should be awaited
        try await modelContext.save()
        print("[\(Self.self)] Saved sentiment result for: '\(text)' (Score: \(simulatedScore), Category: \(simulatedCategory))")
    }
    
    // Example of how to use this from a UI context (e.g., a button action)
    @MainActor
    static func exampleUsage(with container: ModelContainer) async {
        let aiManager = AIServiceManager(modelContainer: container)
        
        Task { // Detach from MainActor to call actor method
            do {
                try await aiManager.processAndSaveSentiment(for: "This is a fantastic book!")
                try await aiManager.processAndSaveSentiment(for: "I am feeling quite neutral about this.")
                try await aiManager.processAndSaveSentiment(for: "What a terrible experience.")
            } catch {
                print("Error processing sentiment: \(error)")
            }
        }
    }
}
