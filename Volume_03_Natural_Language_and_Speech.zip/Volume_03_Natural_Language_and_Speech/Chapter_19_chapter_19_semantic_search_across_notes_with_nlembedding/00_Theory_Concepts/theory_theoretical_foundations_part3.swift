
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import NaturalLanguage
import Foundation // For Task

@available(iOS 18.0, *)
class SemanticSearchManager {
    let embeddingGenerator = NLEmbedding.document

    func performSemanticSearch(query: String, notes: [String]) async throws -> [String] {
        // Generate embedding for the query asynchronously
        let queryEmbedding = try await embeddingGenerator.embedding(for: query)

        var similarityScores: [(note: String, score: Float)] = []

        // Process notes concurrently using a TaskGroup for efficiency
        await withTaskGroup(of: (String, Float?).self) { group in
            for note in notes {
                group.addTask {
                    do {
                        let noteEmbedding = try await self.embeddingGenerator.embedding(for: note)
                        let score = noteEmbedding.cosineSimilarity(with: queryEmbedding)
                        return (note, score)
                    } catch {
                        print("Error generating embedding for note: \(error)")
                        return (note, nil)
                    }
                }
            }

            for await (note, score) in group {
                if let score = score {
                    similarityScores.append((note: note, score: score))
                }
            }
        }

        // Sort notes by similarity score in descending order
        let sortedResults = similarityScores.sorted { $0.score > $1.score }.map { $0.note }
        return sortedResults
    }
}
