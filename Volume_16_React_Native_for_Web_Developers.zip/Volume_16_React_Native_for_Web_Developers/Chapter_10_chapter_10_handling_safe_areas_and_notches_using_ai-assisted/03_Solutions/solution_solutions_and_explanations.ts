/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import React, { ReactNode } from 'react';
import { View, ViewStyle } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

// Define the expected shape of the safe area insets object
type SafeAreaInsets = {
  top: number;
  bottom: number;
  left: number;
  right: number;
};

/**
 * Type guard function to validate if an unknown object conforms to the SafeAreaInsets shape.
 * @param obj - The object to validate.
 * @returns True if the object has the required number properties, false otherwise.
 */
export function isSafeAreaInsets(obj: unknown): obj is SafeAreaInsets {
  return (
    typeof obj === 'object' &&
    obj !== null &&
    'top' in obj && typeof (obj as any).top === 'number' &&
    'bottom' in obj && typeof (obj as any).bottom === 'number' &&
    'left' in obj && typeof (obj as any).left === 'number' &&
    'right' in obj && typeof (obj as any).right === 'number'
  );
}

interface SafeAreaTopViewProps {
  children: ReactNode;
  style?: ViewStyle;
}

/**
 * A foundational layout component that ensures content is never obscured by the
 * device's top status bar or notch.
 */
export const SafeAreaTopView: React.FC<SafeAreaTopViewProps> = ({ children, style }) => {
  const insets = useSafeAreaInsets();

  // Example usage of the type guard (conceptual, as useSafeAreaInsets always returns valid object)
  // In a real-world scenario, this might be used if reading from an async storage or external source.
  if (!isSafeAreaInsets(insets)) {
    // Fallback or error handling if the object structure was unexpected
    console.warn('Invalid insets object received.');
    return <View style={style}>{children}</View>;
  }

  const containerStyle: ViewStyle = {
    paddingTop: insets.top,
    flex: 1, // Ensures the view takes up available space
  };

  return (
    <View style={[{ backgroundColor: 'white' }, containerStyle, style]}>
      {children}
    </View>
  );
};
