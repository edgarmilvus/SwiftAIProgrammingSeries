
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
import MLX
import MLXNN

// Define a simple LLM-like layer (e.g., a feed-forward block)
class SimpleLLMBlock: MLXNN.Module {
    let linear1: MLXNN.Linear
    let linear2: MLXNN.Linear
    let norm: MLXNN.LayerNorm

    init(inputFeatures: Int, hiddenFeatures: Int) {
        self.linear1 = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: hiddenFeatures)
        self.linear2 = MLXNN.Linear(inputFeatures: hiddenFeatures, outputFeatures: inputFeatures)
        self.norm = MLXNN.LayerNorm(dimensions: [inputFeatures])
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        var x = input
        x = norm(x)
        x = linear1(x)
        x = MLXNN.gelu(x)
        x = linear2(x)
        return x + input // Residual connection
    }
}

// Implement this function to quantize model weights
func quantize(model: SimpleLLMBlock, to bits: Int) -> SimpleLLMBlock {
    guard bits == 8 else {
        fatalError("Only 8-bit simulated quantization is implemented for this exercise.")
    }

    // Create a new model instance to hold quantized weights
    let quantizedModel = SimpleLLMBlock(inputFeatures: model.linear1.inputFeatures,
                                        hiddenFeatures: model.linear1.outputFeatures)

    var quantizedParameters: [String: MLXArray] = [:]

    // Iterate through parameters and apply simulated quantization
    for (name, param) in model.parameters() {
        // We only quantize weight matrices for linear layers, biases are typically kept at full precision
        // or quantized differently. For simplicity, we'll quantize all MLXArray parameters here.
        // In a real scenario, you'd be more selective.

        // Check if it's a weight tensor (not bias or normalization parameters)
        // For this exercise, let's just quantize all `MLXArray` parameters.
        // The main goal is to demonstrate `Float16` usage for memory reduction.
        
        // For 8-bit quantization:
        // 1. Find the absolute max value (scale) for the weight tensor.
        let scale = MLX.max(MLX.abs(param))
        
        // Avoid division by zero if scale is very small
        let effectiveScale = MLX.maximum(scale, MLXArray(0.0001))

        // 2. Scale weights to [-127, 127] range for 8-bit signed int representation
        let scaledWeights = param / effectiveScale * MLXArray(127.0)
        
        // 3. Round to nearest integer
        let roundedWeights = MLX.round(scaledWeights)
        
        // 4. Convert back to float (e.g., Float16) and store, re-applying the scale.
        // This is a common way to simulate integer quantization using floating point types.
        let quantizedWeight = roundedWeights / MLXArray(127.0) * effectiveScale
        
        // Convert to Float16 to demonstrate memory reduction
        quantizedParameters[name] = quantizedWeight.astype(.float16)
    }

    // Load the quantized parameters into the new model instance
    quantizedModel.load(parameters: quantizedParameters)
    return quantizedModel
}

// Helper to estimate memory
@available(iOS 18.0, macOS 15.0, *)
func estimateMemoryFootprint(model: MLXNN.Module) -> Int {
    return model.parameters().values.reduce(0) { $0 + $1.nbytes }
}

// Example usage structure:
@available(iOS 18.0, macOS 15.0, *)
func exercise2Example() {
    print("--- Exercise 2: Dynamic Quantization for On-Device LLM ---")

    let inputFeatures = 512
    let hiddenFeatures = 2048
    let batchSize = 1
    let sequenceLength = 128

    // Full precision model (Float32 is default for MLXArray unless specified)
    print("Instantiating full precision model...")
    let fullPrecisionModel = SimpleLLMBlock(inputFeatures: inputFeatures, hiddenFeatures: hiddenFeatures)
    let fullPrecisionMemory = estimateMemoryFootprint(model: fullPrecisionModel)
    print("Full precision model memory: \(Double(fullPrecisionMemory) / (1024 * 1024)) MB")

    // Quantize to 8-bit (simulated)
    print("Quantizing model to 8-bit (simulated)...")
    let quantizedModel = quantize(model: fullPrecisionModel, to: 8)
    let quantizedMemory = estimateMemoryFootprint(model: quantizedModel)
    print("Quantized model memory: \(Double(quantizedMemory) / (1024 * 1024)) MB")
    print("Memory reduction: \((Double(fullPrecisionMemory - quantizedMemory) / fullPrecisionMemory * 100).formatted(.number.precision(.fractionLength(2))))%")


    // Dummy input for inference
    let dummyInput = MLXArray.randomUniform(low: -1, high: 1, shape: [batchSize, sequenceLength, inputFeatures]) // Batch, SequenceLength, Features

    // Perform inference and observe
    print("Performing inference with full precision model...")
    let startTimeFull = Date()
    let fullPrecisionOutput = fullPrecisionModel(dummyInput)
    let endTimeFull = Date()
    print("Full precision inference time: \(endTimeFull.timeIntervalSince(startTimeFull).formatted(.number.precision(.fractionLength(4)))) s")


    print("Performing inference with quantized model...")
    let startTimeQuant = Date()
    let quantizedOutput = quantizedModel(dummyInput)
    let endTimeQuant = Date()
    print("Quantized inference time: \(endTimeQuant.timeIntervalSince(startTimeQuant).formatted(.number.precision(.fractionLength(4)))) s")

    // Compare outputs (e.g., using L2 norm of difference)
    let difference = MLX.mean(MLX.square(fullPrecisionOutput - quantizedOutput)).item(Float.self)
    print("Mean squared difference between outputs: \(difference.formatted(.number.precision(.fractionLength(6))))")
    print("--- End Exercise 2 ---")
}

// Call the example function to run the exercise
// exercise2Example() // Uncomment to run
