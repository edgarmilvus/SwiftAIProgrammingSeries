
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI

@available(iOS 18.0, macOS 15.0, *)
struct MailComposerView: View {
    @State private var subject: String = ""
    @State private var bodyText: String = "Dear team, I am writing to inform you about a new project initiative. We need to discuss the next steps soon."

    // A computed property to dynamically determine the WritingToolsConfiguration
    private var bodyWritingToolsConfiguration: WritingToolsConfiguration {
        if subject.lowercased().hasPrefix("urgent:") {
            // When urgent, disable summarization and simplification
            return WritingToolsConfiguration.default.excluding(.summarize, .simplify)
        } else {
            // Otherwise, enable all default tools
            return .default
        }
    }

    var body: some View {
        VStack {
            TextField("Subject", text: $subject)
                .padding()
                .border(Color.gray.opacity(0.5))
                .accessibilityLabel("Email Subject")

            TextEditor(text: $bodyText)
                // Apply the conditional writingTools modifier using the computed property
                .writingTools(bodyWritingToolsConfiguration)
                .border(Color.gray.opacity(0.5))
                .padding()
                .accessibilityLabel("Email Body")
        }
        .padding()
        .navigationTitle("New Message")
    }
}
