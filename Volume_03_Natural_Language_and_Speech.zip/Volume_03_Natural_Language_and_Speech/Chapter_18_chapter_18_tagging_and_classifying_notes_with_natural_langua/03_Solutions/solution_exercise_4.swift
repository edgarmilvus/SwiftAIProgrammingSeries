
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import NaturalLanguage

enum Sentiment: String, CustomStringConvertible {
    case positive, neutral, negative
    var description: String { self.rawValue.capitalized }
}

func analyzeFeedbackAndPrioritize(feedbackNote: String) -> (sentiment: Sentiment, priorityTag: String?) {
    // 1. Sentiment Analysis
    let tagger = NLTagger(tagSchemes: [.sentimentScore])
    tagger.string = feedbackNote

    // Get the sentiment score for the entire document range
    // NLTagger returns a tag (NLTag) which can be converted to a Float score.
    let (tag, _) = tagger.tag(at: feedbackNote.startIndex, unit: .document, scheme: .sentimentScore)
    let sentimentScore = tag?.sentimentScore ?? 0.0 // Default to neutral if no score is returned

    // 2. Sentiment Classification
    var classifiedSentiment: Sentiment
    let positiveThreshold: Float = 0.2
    let negativeThreshold: Float = -0.2

    if sentimentScore > positiveThreshold {
        classifiedSentiment = .positive
    } else if sentimentScore < negativeThreshold {
        classifiedSentiment = .negative
    } else {
        classifiedSentiment = .neutral
    }

    // 3. Priority Tagging
    var priorityTag: String? = nil
    if classifiedSentiment == .negative {
        let criticalKeywords = ["crash", "bug", "freeze", "data loss", "unusable", "broken", "error", "not working"]
        
        // Check if any critical keyword is present in the note
        if criticalKeywords.contains(where: { feedbackNote.localizedStandardContains($0) }) {
            priorityTag = "Urgent"
        }
    }

    return (sentiment: classifiedSentiment, priorityTag: priorityTag)
}

// Example Usage (for testing your implementation)
/*
let note1 = "The new update is fantastic! Everything works perfectly and the new features are great."
let (sentiment1, tag1) = analyzeFeedbackAndPrioritize(feedbackNote: note1)
print("Note 1: Sentiment: \(sentiment1), Priority: \(tag1 ?? "None")") // Expected: Positive, None

let note2 = "The app keeps crashing every time I try to save a document, it's completely unusable!"
let (sentiment2, tag2) = analyzeFeedbackAndPrioritize(feedbackNote: note2)
print("Note 2: Sentiment: \(sentiment2), Priority: \(tag2 ?? "None")") // Expected: Negative, Urgent

let note3 = "I noticed a minor bug in the settings menu, but it's not critical. It's just a small visual glitch."
let (sentiment3, tag3) = analyzeFeedbackAndPrioritize(feedbackNote: note3)
print("Note 3: Sentiment: \(sentiment3), Priority: \(tag3 ?? "None")") // Expected: Negative, None (score might be less negative due to "minor" and "small visual glitch")

let note4 = "The new color scheme is okay, I guess. Nothing groundbreaking."
let (sentiment4, tag4) = analyzeFeedbackAndPrioritize(feedbackNote: note4)
print("Note 4: Sentiment: \(sentiment4), Priority: \(tag4 ?? "None")") // Expected: Neutral, None

let note5 = "The latest release introduced a severe data loss issue. This is completely broken!"
let (sentiment5, tag5) = analyzeFeedbackAndPrioritize(feedbackNote: note5)
print("Note 5: Sentiment: \(sentiment5), Priority: \(tag5 ?? "None")") // Expected: Negative, Urgent

let note6 = "This app is terrible, it's full of bugs and constantly crashes."
let (sentiment6, tag6) = analyzeFeedbackAndPrioritize(feedbackNote: note6)
print("Note 6: Sentiment: \(sentiment6), Priority: \(tag6 ?? "None")") // Expected: Negative, Urgent
*/
