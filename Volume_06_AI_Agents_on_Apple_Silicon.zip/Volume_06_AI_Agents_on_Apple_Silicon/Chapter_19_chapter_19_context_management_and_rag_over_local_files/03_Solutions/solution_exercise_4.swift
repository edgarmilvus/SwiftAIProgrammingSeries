
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import Accelerate // For vector operations (dot product, magnitude)

// MARK: - Note Representation

/// Represents a user's note with its content and modification timestamp.
struct Note: Identifiable, Equatable {
    let id: String
    var content: String
    var lastModified: Date = Date() // Useful for change detection

    static func == (lhs: Note, rhs: Note) -> Bool {
        return lhs.id == rhs.id && lhs.content == rhs.content
    }
}

// MARK: - DocumentChunk Structure (Reused from Exercise 2/3)

/// Represents a semantically meaningful chunk of a document, now including an embedding.
struct DocumentChunk: Identifiable, CustomStringConvertible {
    let id: String
    let content: String
    let documentId: String // Will be the Note.id
    let startIndex: Int
    let endIndex: Int
    var embedding: [Float]? // Optional embedding vector

    var description: String {
        return "Chunk(id: \(id), docId: \(documentId), start: \(startIndex), end: \(endIndex), content: \"\(content.prefix(50))...\", embedding: \(embedding != nil ? "present" : "nil"))"
    }
}

// MARK: - EmbeddingService & LLMService (Reused from Exercise 3)

// Assuming EmbeddingService and LLMService protocols, and LlamaCppLLMService class
// are defined as in Exercise 3. For a self-contained solution, they are included here:

/// Protocol for services that can generate vector embeddings for text.
protocol EmbeddingService {
    func generateEmbedding(for text: String) async throws -> [Float]
}

/// Protocol for services that can generate vector embeddings and text completions.
protocol LLMService: EmbeddingService {
    func generateCompletion(prompt: String, maxTokens: Int) async throws -> String
}

/// A mock implementation of `LLMService` simulating `llama.cpp` or Ollama interactions.
@available(iOS 18.0, macOS 14.0, *)
class LlamaCppLLMService: LLMService {
    let embeddingDimension: Int = 768
    let modelName: String = "mock-llama-model"

    init() { /* ... */ } // Same as Ex. 3
    func generateEmbedding(for text: String) async throws -> [Float] {
        try await Task.sleep(for: .milliseconds(100))
        return (0..<embeddingDimension).map { _ in Float.random(in: -1.0...1.0) }
    }
    func generateCompletion(prompt: String, maxTokens: Int) async throws -> String {
        try await Task.sleep(for: .milliseconds(500))
        let response = "Mock LLM response to query: '\(prompt.prefix(100))...' (Context managed, max \(maxTokens) tokens)"
        return response
    }
}

// MARK: - NoteRAGService Class

@available(iOS 18.0, macOS 14.0, *)
class NoteRAGService {
    private let llmService: LLMService
    private let maxLLMContextTokens: Int

    private var currentNote: Note?
    // In-memory store for the current note's chunks, keyed by chunk ID.
    private var indexedChunks: [String: DocumentChunk] = [:]
    private var lastIndexedContentHash: Int? // To detect content changes efficiently

    init(llmService: LLMService, maxLLMContextTokens: Int) {
        self.llmService = llmService
        self.maxLLMContextTokens = maxLLMContextTokens
        print("NoteRAGService initialized with max context tokens: \(maxLLMContextTokens)")
    }

    /// Loads a note, re-indexing and embedding its content if it has changed.
    /// - Parameter note: The `Note` object to load.
    func loadNote(_ note: Note) async throws {
        let currentContentHash = note.content.hashValue
        // Check if the note is the same and its content hasn't changed.
        if currentNote?.id == note.id && lastIndexedContentHash == currentContentHash {
            print("Note content unchanged, skipping re-indexing for note ID: \(note.id).")
            return
        }

        print("Note content changed or new note loaded. Re-indexing note ID: \(note.id)")
        self.currentNote = note
        self.indexedChunks.removeAll() // Clear previous note's chunks
        self.lastIndexedContentHash = currentContentHash

        // Simple chunking strategy: split by paragraphs (newlines)
        let lines = note.content.components(separatedBy: .newlines)
        var currentOffset = 0
        var chunkIndex = 0

        for line in lines {
            let trimmedLine = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if !trimmedLine.isEmpty {
                let chunkId = "\(note.id)-\(chunkIndex)"
                let embedding = try await llmService.generateEmbedding(for: trimmedLine)

                var newChunk = DocumentChunk(
                    id: chunkId,
                    content: trimmedLine,
                    documentId: note.id,
                    startIndex: currentOffset,
                    endIndex: currentOffset + trimmedLine.count - 1
                )
                newChunk.embedding = embedding
                indexedChunks[chunkId] = newChunk
                chunkIndex += 1
            }
            currentOffset += line.count + 1 // +1 for newline
        }
        print("Re-indexed \(indexedChunks.count) chunks for note ID: \(note.id)")
    }

    /// Answers a question based on the currently loaded note's content, managing context aggressively.
    /// - Parameter question: The user's question.
    /// - Returns: The LLM's generated answer.
    /// - Throws: `NoteRAGServiceError` if no note is loaded or other issues occur.
    func askQuestion(question: String) async throws -> String {
        guard let note = currentNote else {
            throw NoteRAGServiceError.noNoteLoaded
        }
        guard !indexedChunks.isEmpty else {
            throw NoteRAGServiceError.emptyNoteOrNoChunks(noteId: note.id)
        }
        print("Asking question for note ID: \(note.id)")

        // 1. Generate embedding for the question
        let questionEmbedding = try await llmService.generateEmbedding(for: question)

        // 2. Retrieve relevant chunks from in-memory store using cosine similarity
        var scoredChunks: [(chunk: DocumentChunk, similarity: Float)] = []
        for chunk in indexedChunks.values {
            guard let chunkEmbedding = chunk.embedding else {
                print("Warning: Chunk \(chunk.id) has no embedding, skipping.")
                continue
            }
            let similarity = DocumentIndexer.calculateCosineSimilarity( // Reusing static helper
                vectorA: questionEmbedding,
                vectorB: chunkEmbedding
            )
            scoredChunks.append((chunk: chunk, similarity: similarity))
        }

        // Sort by similarity in descending order
        scoredChunks.sort { $0.similarity > $1.similarity }

        // 3. Aggressive Context Window Management
        var contextString = ""
        var currentContextTokens = estimateTokens(for: question) // Start with question tokens
        let contextPrefix = "Context from your note:\n"
        let contextSuffix = "\n\nBased on the context, answer the following question: "
        
        // Account for LLM's own prompt structure and response generation
        let overheadTokens = estimateTokens(for: contextPrefix + contextSuffix)
        let availableTokensForChunks = maxLLMContextTokens - currentContextTokens - overheadTokens - 50 // -50 for LLM response buffer

        if availableTokensForChunks <= 0 {
            print("Warning: Not enough tokens available for context chunks after accounting for question and prompt overhead. Available: \(availableTokensForChunks)")
            return "Your question is too long or the LLM's context window is too small to provide meaningful context."
        }

        var addedChunkCount = 0
        for (chunk, _) in scoredChunks {
            let chunkTokens = estimateTokens(for: chunk.content)
            if currentContextTokens + chunkTokens < availableTokensForChunks {
                contextString += "- \(chunk.content)\n"
                currentContextTokens += chunkTokens
                addedChunkCount += 1
            } else {
                // Option B: Prioritize by similarity and drop less relevant chunks.
                // For a "Smart Note Assistant", fitting as much relevant context is key.
                // If a chunk is too large to fit entirely, a more advanced approach might truncate it.
                print("Stopping context addition: next chunk would exceed token limit (\(currentContextTokens) + \(chunkTokens) > \(availableTokensForChunks))")
                break
            }
        }
        print("Added \(addedChunkCount) chunks to context, total estimated context tokens: \(currentContextTokens)")

        if addedChunkCount == 0 && !indexedChunks.isEmpty {
            print("No relevant chunks could be added to context. Perhaps the note is too long for the context window or chunks are too large.")
            // Consider a fallback or specific error message here
        }

        // 4. Construct the final prompt for the LLM
        let finalPrompt = "\(contextPrefix)\(contextString)\(contextSuffix)\(question)"

        // 5. Call LLM for completion
        let llmResponse = try await llmService.generateCompletion(prompt: finalPrompt, maxTokens: maxLLMContextTokens - currentContextTokens)
        return llmResponse
    }

    /// Helper to estimate tokens (simple char count / 4).
    private func estimateTokens(for text: String) -> Int {
        return text.count / 4
    }

    // Cosine similarity function (reused from Exercise 2)
    static func calculateCosineSimilarity(vectorA: [Float], vectorB: [Float]) -> Float {
        guard vectorA.count == vectorB.count else {
            fatalError("Vectors must have the same dimension for cosine similarity calculation.")
        }
        guard !vectorA.isEmpty else { return 0.0 }

        let dotProduct = cblas_sdot(Int32(vectorA.count), vectorA, 1, vectorB, 1)
        let magnitudeA = sqrt(cblas_snrm2(Int32(vectorA.count), vectorA, 1))
        let magnitudeB = sqrt(cblas_snrm2(Int32(vectorB.count), vectorB, 1))

        if magnitudeA == 0 || magnitudeB == 0 {
            return 0.0
        }
        return dotProduct / (magnitudeA * magnitudeB)
    }

    enum NoteRAGServiceError: Error, LocalizedError {
        case noNoteLoaded
        case emptyNoteOrNoChunks(noteId: String)
        case llmError(String)
        case indexingError(String)
        case contextOverflow(String)

        var errorDescription: String? {
            switch self {
            case .noNoteLoaded: return "No note has been loaded into the assistant."
            case .emptyNoteOrNoChunks(let id): return "Note '\(id)' is empty or contains no valid chunks for indexing."
            case .llmError(let msg): return "LLM Service error: \(msg)"
            case .indexingError(let msg): return "Error during note indexing: \(msg)"
            case .contextOverflow(let msg): return "Context window overflow: \(msg)"
            }
        }
    }
}

// MARK: - Example Usage (for testing)

@available(iOS 18.0, macOS 14.0, *)
func runExercise4() async {
    print("\n--- Exercise 4: Feature Request: 'Smart Note Assistant' ---")

    let llmService = LlamaCppLLMService()
    let maxNoteContextTokens = 300 // Simulate a smaller context window for a note assistant

    let noteRAGService = NoteRAGService(llmService: llmService, maxLLMContextTokens: maxNoteContextTokens)

    // 1. Initial Note Load
    var myNote = Note(id: "note-123", content: """
    Meeting notes from Project X kickoff:
    Attendees: Alice, Bob, Charlie.
    Goal: Launch new feature Y by end of Q3.
    Action items:
    - Alice: Research user feedback on current feature Z.
    - Bob: Draft initial technical spec for feature Y.
    - Charlie: Prepare presentation for executive review next month.
    Risks: Potential delays in API integration.
    """)
    
    do {
        try await noteRAGService.loadNote(myNote)

        // 2. Ask a question about the note
        let question1 = "What are the action items for Bob and Charlie?"
        print("\nQuestion: \(question1)")
        let answer1 = try await noteRAGService.askQuestion(question: question1)
        print("Assistant: \(answer1)")

        // 3. Simulate note content change and re-indexing
        print("\n--- Simulating Note Content Change ---")
        myNote.content += "\n\nUpdate: API integration risk is now mitigated by using a new service."
        myNote.lastModified = Date() // Update timestamp

        try await noteRAGService.loadNote(myNote) // Should re-index

        // 4. Ask another question, now with updated context
        let question2 = "What was the latest update regarding risks?"
        print("\nQuestion: \(question2)")
        let answer2 = try await noteRAGService.askQuestion(question: question2)
        print("Assistant: \(answer2)")

        // 5. Test with a very long note that might exceed context
        print("\n--- Testing with a longer note ---")
        let longNoteContent = (0..<50).map { "This is a very long line of content for the note, line number \($0). It helps to test context window management and chunking strategies." }.joined(separator: "\n")
        var longNote = Note(id: "long-note-456", content: longNoteContent)
        try await noteRAGService.loadNote(longNote)

        let question3 = "Summarize the key points of this long note."
        print("\nQuestion: \(question3)")
        let answer3 = try await noteRAGService.askQuestion(question: question3)
        print("Assistant: \(answer3)")
        
        // 6. Test with an empty note
        print("\n--- Testing with an empty note ---")
        let emptyNote = Note(id: "empty-note-789", content: "")
        do {
            try await noteRAGService.loadNote(emptyNote)
            _ = try await noteRAGService.askQuestion(question: "What's in this note?")
        } catch NoteRAGServiceError.emptyNoteOrNoChunks(let noteId) {
            print("Caught expected error for empty note: \(noteId)")
        } catch {
            print("Caught unexpected error for empty note: \(error.localizedDescription)")
        }

    } catch {
        print("Error during Exercise 4: \(error.localizedDescription)")
    }
}

// To run this example in a playground or app:
// Task {
//     await runExercise4()
// }
