
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift (No external dependencies for AppIntents and core frameworks)
// AppIntents is a built-in framework in iOS 18+.
// Foundation, SwiftUI, and other core frameworks are also built-in.
// For a real-world Apple Intelligence integration, you might implicitly depend
// on specific frameworks like 'CoreML' or higher-level AI frameworks
// that Apple provides, but these are typically available by default
// or imported directly within the source file.
/*
import PackageDescription

let package = Package(
    name: "SmartNotesAppIntents",
    platforms: [
        .iOS(.v18), // App Intents and Apple Intelligence features are iOS 18+
        .macOS(.v15)
    ],
    products: [
        .library(
            name: "SmartNotesAppIntents",
            targets: ["SmartNotesAppIntents"]),
    ],
    targets: [
        .target(
            name: "SmartNotesAppIntents",
            dependencies: []), // No external dependencies for this example
        .testTarget(
            name: "SmartNotesAppIntentsTests",
            dependencies: ["SmartNotesAppIntents"]),
    ]
)
*/
