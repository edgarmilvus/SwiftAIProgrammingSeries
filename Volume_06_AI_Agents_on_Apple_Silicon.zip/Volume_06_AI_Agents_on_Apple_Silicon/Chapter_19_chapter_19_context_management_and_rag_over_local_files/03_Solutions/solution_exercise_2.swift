
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import Accelerate // For vector operations (dot product, magnitude)

// MARK: - DocumentChunk Structure (Updated from Exercise 1)

/// Represents a semantically meaningful chunk of a document, now including an embedding.
struct DocumentChunk: Identifiable, CustomStringConvertible {
    let id: String
    let content: String
    let documentId: String
    let startIndex: Int
    let endIndex: Int
    var embedding: [Float]? // New: Optional embedding vector

    var description: String {
        return "Chunk(id: \(id), docId: \(documentId), start: \(startIndex), end: \(endIndex), content: \"\(content.prefix(50))...\", embedding: \(embedding != nil ? "present" : "nil"))"
    }
}

// MARK: - EmbeddingService Protocol and Mock Implementation

/// Protocol for services that can generate vector embeddings for text.
protocol EmbeddingService {
    func generateEmbedding(for text: String) async throws -> [Float]
}

/// A mock implementation of `EmbeddingService` that returns random float vectors.
class MockEmbeddingService: EmbeddingService {
    let embeddingDimension: Int // Fixed size for the simulated embedding vectors

    init(embeddingDimension: Int = 768) {
        self.embeddingDimension = embeddingDimension
    }

    /// Simulates generating an embedding by returning a random float array.
    /// In a real scenario, this would call an actual embedding model (e.g., Ollama, llama.cpp).
    func generateEmbedding(for text: String) async throws -> [Float] {
        // Simulate network/model latency
        try await Task.sleep(for: .milliseconds(50))
        // Generate a random vector of the specified dimension
        return (0..<embeddingDimension).map { _ in Float.random(in: -1.0...1.0) }
    }
}

// MARK: - DocumentIndexer Class (Updated from Exercise 1)

@available(macOS 14.0, *)
class DocumentIndexer {
    private var indexedChunks: [String: [DocumentChunk]] = [:]
    private let embeddingService: EmbeddingService // New: Dependency injection for embedding service

    init(embeddingService: EmbeddingService) {
        self.embeddingService = embeddingService
    }

    /// Indexes a document, now also generating and storing embeddings for each chunk.
    func indexDocument(at url: URL) async throws -> [DocumentChunk] {
        let documentId = url.lastPathComponent
        var currentOffset = 0
        var chunks: [DocumentChunk] = []
        var chunkIndex = 0

        for try await line in url.lines {
            let trimmedLine = line.trimmingCharacters(in: .whitespacesAndNewlines)

            if !trimmedLine.isEmpty {
                let id = _generateChunkId(for: trimmedLine, documentId: documentId, index: chunkIndex)
                // Generate embedding for the chunk content
                let embedding = try await embeddingService.generateEmbedding(for: trimmedLine)

                var newChunk = DocumentChunk(
                    id: id,
                    content: trimmedLine,
                    documentId: documentId,
                    startIndex: currentOffset,
                    endIndex: currentOffset + trimmedLine.count - 1
                )
                newChunk.embedding = embedding // Assign the generated embedding
                chunks.append(newChunk)
                chunkIndex += 1
            }
            currentOffset += line.count + 1
        }

        indexedChunks[documentId] = chunks
        print("Indexed \(chunks.count) chunks with embeddings for document: \(documentId)")
        return chunks
    }

    /// Generates a unique identifier for a document chunk.
    private func _generateChunkId(for chunkContent: String, documentId: String, index: Int) -> String {
        return "\(documentId)-\(index)"
    }

    /// Retrieves all indexed chunks for a given document ID.
    func getChunks(for documentId: String) -> [DocumentChunk]? {
        return indexedChunks[documentId]
    }

    /// Retrieves all indexed chunks across all documents.
    func getAllChunks() -> [DocumentChunk] {
        return indexedChunks.values.flatMap { $0 }
    }

    /// Calculates the cosine similarity between two float vectors.
    /// - Returns: A float value between -1.0 and 1.0, where 1.0 is perfect similarity.
    static func calculateCosineSimilarity(vectorA: [Float], vectorB: [Float]) -> Float {
        guard vectorA.count == vectorB.count else {
            fatalError("Vectors must have the same dimension for cosine similarity calculation.")
        }
        guard !vectorA.isEmpty else { return 0.0 } // Handle empty vectors

        // Calculate dot product
        let dotProduct = cblas_sdot(Int32(vectorA.count), vectorA, 1, vectorB, 1)

        // Calculate magnitudes (L2 norms)
        let magnitudeA = sqrt(cblas_snrm2(Int32(vectorA.count), vectorA, 1))
        let magnitudeB = sqrt(cblas_snrm2(Int32(vectorB.count), vectorB, 1))

        // Handle division by zero if either magnitude is zero
        if magnitudeA == 0 || magnitudeB == 0 {
            return 0.0
        }

        return dotProduct / (magnitudeA * magnitudeB)
    }

    /// Retrieves the top-K most relevant document chunks for a given query.
    /// - Parameters:
    ///   - query: The user's query string.
    ///   - topK: The number of top relevant chunks to return.
    /// - Returns: An array of `DocumentChunk`s sorted by relevance (highest similarity first).
    /// - Throws: An error if embedding generation fails or no chunks are indexed.
    func retrieveRelevantChunks(for query: String, topK: Int) async throws -> [DocumentChunk] {
        guard !indexedChunks.isEmpty else {
            print("No documents indexed yet.")
            return []
        }

        // 1. Generate embedding for the query
        let queryEmbedding = try await embeddingService.generateEmbedding(for: query)

        // 2. Iterate through all indexed chunks and calculate cosine similarity
        var scoredChunks: [(chunk: DocumentChunk, similarity: Float)] = []
        for chunk in getAllChunks() {
            guard let chunkEmbedding = chunk.embedding else {
                print("Warning: Chunk \(chunk.id) has no embedding, skipping.")
                continue
            }
            let similarity = DocumentIndexer.calculateCosineSimilarity(
                vectorA: queryEmbedding,
                vectorB: chunkEmbedding
            )
            scoredChunks.append((chunk: chunk, similarity: similarity))
        }

        // 3. Sort chunks by similarity in descending order
        scoredChunks.sort { $0.similarity > $1.similarity }

        // 4. Return the topK most similar chunks
        return scoredChunks.prefix(topK).map { $0.chunk }
    }
}

// MARK: - Example Usage (for testing)

@available(macOS 14.0, *)
func runExercise2() async {
    print("\n--- Exercise 2: Implementing Basic RAG Retrieval with Cosine Similarity ---")

    let embeddingService = MockEmbeddingService(embeddingDimension: 768)
    let indexer = DocumentIndexer(embeddingService: embeddingService)

    // Create a dummy text file for indexing
    let fileContent = """
    The quick brown fox jumps over the lazy dog. This is a classic pangram.
    Swift is a powerful and intuitive programming language developed by Apple.
    Machine learning models often use vector embeddings to represent text.
    RAG systems combine retrieval with generation for better answers.
    Artificial intelligence is a rapidly advancing field.
    Dogs are known for their loyalty and companionship.
    """
    let filename = "rag_document.txt"
    let fileURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(filename)

    do {
        try fileContent.write(to: fileURL, atomically: true, encoding: .utf8)
        print("Dummy file created at: \(fileURL.path)")

        // Index the document, now generating embeddings
        _ = try await indexer.indexDocument(at: fileURL)

        // Perform a retrieval query
        let query = "Tell me about programming languages and AI."
        let topK = 3
        print("\nQuery: \"\(query)\"")
        let relevantChunks = try await indexer.retrieveRelevantChunks(for: query, topK: topK)

        print("\nTop \(topK) relevant chunks:")
        for (index, chunk) in relevantChunks.enumerated() {
            print("  \(index + 1). Document: \(chunk.documentId), Chunk ID: \(chunk.id)")
            print("     Content: \"\(chunk.content)\"")
            // In a real RAG, you'd also show the similarity score
        }

        let query2 = "What do you know about canines?"
        print("\nQuery: \"\(query2)\"")
        let relevantChunks2 = try await indexer.retrieveRelevantChunks(for: query2, topK: 1)
        print("\nTop 1 relevant chunk for query 2:")
        for (index, chunk) in relevantChunks2.enumerated() {
            print("  \(index + 1). Document: \(chunk.documentId), Chunk ID: \(chunk.id)")
            print("     Content: \"\(chunk.content)\"")
        }


        // Clean up the dummy file
        try FileManager.default.removeItem(at: fileURL)
        print("\nDummy file removed.")

    } catch {
        print("Error during Exercise 2: \(error.localizedDescription)")
    }
}

// To run this example in a playground or app:
// Task {
//     await runExercise2()
// }
