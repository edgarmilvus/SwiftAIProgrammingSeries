
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import AVFoundation
import CoreML
import Combine // For ObservableObject and @Published

// Assume PetSoundClassifier.mlmodel is added to the project.
// You would generate this from Create ML with "Dog Bark", "Cat Meow", "Background Noise" classes.
// The input is typically a 1-second audio segment at 16kHz, mono, Float32.
// For this example, let's assume the model expects an MLMultiArray of shape [1, 16000].

// MARK: - Core ML Model Wrapper

struct PetSoundClassifierInput {
    let input: MLMultiArray
}

struct PetSoundClassifierOutput {
    let label: String
    let labelProbability: [String : Double]
}

final class PetSoundClassifierModel {
    private let model: PetSoundClassifier
    private let modelInputLength: Int = 16000 // e.g., 1 second * 16000 samples/sec

    init() throws {
        let configuration = MLModelConfiguration()
        self.model = try PetSoundClassifier(configuration: configuration)
    }

    func predict(input: PetSoundClassifierInput) throws -> PetSoundClassifierOutput {
        let prediction = try model.prediction(input: input.input)
        return PetSoundClassifierOutput(label: prediction.label, labelProbability: prediction.labelProbability)
    }
    
    // Helper to get the expected input format for the model
    var expectedSampleRate: Double {
        // Assume 16kHz based on common MLSoundClassifier models
        return 16000.0
    }
}

// MARK: - Audio Processing & Classification Service

class AudioClassifierService: ObservableObject {
    @Published var currentPrediction: (label: String, confidence: Double)?
    @Published var permissionGranted: Bool = false
    @Published var isRecording: Bool = false
    @Published var errorMessage: String?

    private let audioEngine = AVAudioEngine()
    private var classifier: PetSoundClassifierModel?
    private let audioProcessingQueue = DispatchQueue(label: "com.example.audioProcessingQueue", qos: .userInitiated)
    
    // Buffer to accumulate audio for classification
    private var audioBuffer: AVAudioPCMBuffer?
    private let bufferCapacity: AVAudioFrameCount // Capacity for one model input (e.g., 1 second)

    init() {
        do {
            classifier = try PetSoundClassifierModel()
            // Calculate buffer capacity based on model's expected input length and sample rate
            bufferCapacity = AVAudioFrameCount(classifier!.modelInputLength)
            audioBuffer = AVAudioPCMBuffer(pcmFormat: classifier!.audioFormat, frameCapacity: bufferCapacity)
            audioBuffer?.frameLength = 0 // Start empty
        } catch {
            errorMessage = "Failed to load ML model: \(error.localizedDescription)"
            print("Error loading model: \(error)")
        }
    }

    func requestMicrophonePermission() async {
        let status = AVCaptureDevice.authorizationStatus(for: .audio)
        switch status {
        case .authorized:
            permissionGranted = true
        case .notDetermined:
            await AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                DispatchQueue.main.async {
                    self?.permissionGranted = granted
                    if !granted {
                        self?.errorMessage = "Microphone permission denied. Please enable it in Settings."
                    }
                }
            }
        case .denied, .restricted:
            permissionGranted = false
            errorMessage = "Microphone permission denied. Please enable it in Settings."
        @unknown default:
            permissionGranted = false
            errorMessage = "Unknown microphone permission status."
        }
    }

    func startMonitoring() {
        guard permissionGranted, classifier != nil else {
            errorMessage = "Microphone permission not granted or model not loaded."
            return
        }

        let inputNode = audioEngine.inputNode
        let bus = 0 // Default input bus
        
        // Configure the input format to match the model's expected sample rate and channel count
        let inputFormat = inputNode.inputFormat(forBus: bus)
        let outputFormat = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: classifier!.expectedSampleRate, channels: 1, interleaved: false)!

        if inputFormat.sampleRate != outputFormat.sampleRate || inputFormat.channelCount != outputFormat.channelCount {
            // Attempt to convert format if necessary
            audioEngine.attach(AVAudioMixerNode()) // Attach a mixer to handle format conversion
            let mixer = audioEngine.mainMixerNode
            audioEngine.connect(inputNode, to: mixer, format: inputFormat)
            audioEngine.connect(mixer, to: audioEngine.outputNode, format: outputFormat) // This isn't strictly needed for input tap, but sets up mixer
            
            inputNode.installTap(onBus: bus, bufferSize: AVAudioFrameCount(outputFormat.sampleRate / 10), format: outputFormat) { [weak self] buffer, time in
                self?.processAudioBuffer(buffer: buffer)
            }
        } else {
            inputNode.installTap(onBus: bus, bufferSize: AVAudioFrameCount(inputFormat.sampleRate / 10), format: inputFormat) { [weak self] buffer, time in
                self?.processAudioBuffer(buffer: buffer)
            }
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
            isRecording = true
            errorMessage = nil
        } catch {
            errorMessage = "Error starting audio engine: \(error.localizedDescription)"
            print("Error starting audio engine: \(error)")
        }
    }

    func stopMonitoring() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        isRecording = false
        audioBuffer?.frameLength = 0 // Clear buffer on stop
        currentPrediction = nil
    }

    private func processAudioBuffer(buffer: AVAudioPCMBuffer) {
        audioProcessingQueue.async { [weak self] in
            guard let self = self, let classifier = self.classifier else { return }

            // Append incoming buffer to our accumulator
            self.audioBuffer?.append(buffer, startingFrame: 0, frameCount: buffer.frameLength)

            // If we have enough data for a full model input, classify it
            if let currentBuffer = self.audioBuffer, currentBuffer.frameLength >= self.bufferCapacity {
                // Create MLMultiArray from the accumulated buffer
                guard let multiArray = currentBuffer.toMLMultiArray(
                    modelInputLength: classifier.modelInputLength,
                    targetSampleRate: classifier.expectedSampleRate
                ) else {
                    print("Failed to convert buffer to MLMultiArray.")
                    // Reset buffer even if conversion fails to avoid infinite loop on bad data
                    currentBuffer.frameLength = 0
                    return
                }

                do {
                    let prediction = try classifier.predict(input: PetSoundClassifierInput(input: multiArray))
                    DispatchQueue.main.async {
                        if let confidence = prediction.labelProbability[prediction.label] {
                            self.currentPrediction = (label: prediction.label, confidence: confidence)
                        }
                    }
                } catch {
                    print("Error during prediction: \(error)")
                }
                
                // Reset buffer for the next classification window
                currentBuffer.frameLength = 0
            }
        }
    }
}

// MARK: - Helper Extension for AVAudioPCMBuffer to MLMultiArray Conversion
extension AVAudioPCMBuffer {
    /// Converts an AVAudioPCMBuffer to an MLMultiArray suitable for MLSoundClassifier.
    /// - Parameters:
    ///   - modelInputLength: The expected number of samples for the model's input.
    ///   - targetSampleRate: The sample rate the model expects (e.g., 16000 Hz).
    /// - Returns: An MLMultiArray, or nil if conversion fails or buffer is too short.
    func toMLMultiArray(modelInputLength: Int, targetSampleRate: Double) -> MLMultiArray? {
        guard let floatChannelData = floatChannelData else {
            print("Buffer does not contain float channel data.")
            return nil
        }

        // Ensure the buffer has enough frames for the target sample rate
        // and that it's mono.
        guard format.channelCount == 1 else {
            print("Buffer must be mono. Has \(format.channelCount) channels.")
            return nil
        }

        // For simplicity, assume the input format matches the target.
        // In a real app, you'd use AVAudioConverter for robust resampling.
        guard format.sampleRate == targetSampleRate else {
            print("Buffer sample rate \(format.sampleRate) does not match target \(targetSampleRate). Resampling needed.")
            return nil
        }

        let frameCount = Int(frameLength)
        guard frameCount >= modelInputLength else {
            // Not enough audio data for a full prediction window
            return nil
        }

        do {
            let multiArray = try MLMultiArray(shape: [1, NSNumber(value: modelInputLength)], dataType: .float32)
            let bufferPointer = UnsafeMutableBufferPointer(start: floatChannelData[0], count: frameCount)

            // Copy the required number of samples
            for i in 0..<modelInputLength {
                multiArray[i] = NSNumber(value: bufferPointer[i])
            }
            return multiArray
        } catch {
            print("Failed to create MLMultiArray: \(error)")
            return nil
        }
    }
    
    // Helper to get the expected audio format for the model (mono, Float32, 16kHz)
    var audioFormat: AVAudioFormat {
        return AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: 16000, channels: 1, interleaved: false)!
    }
}


// MARK: - SwiftUI View

struct PetMonitorView: View {
    @StateObject private var audioClassifier = AudioClassifierService()

    var body: some View {
        VStack {
            Text("Pet Monitor")
                .font(.largeTitle)
                .padding()

            if let errorMessage = audioClassifier.errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }

            if audioClassifier.permissionGranted {
                Text(audioClassifier.isRecording ? "Monitoring Pet Sounds..." : "Ready to Monitor")
                    .font(.headline)
                    .padding()

                Button(action: {
                    if audioClassifier.isRecording {
                        audioClassifier.stopMonitoring()
                    } else {
                        audioClassifier.startMonitoring()
                    }
                }) {
                    Text(audioClassifier.isRecording ? "Stop Monitoring" : "Start Monitoring")
                        .font(.title2)
                        .padding()
                        .background(audioClassifier.isRecording ? Color.red : Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()

                if let prediction = audioClassifier.currentPrediction {
                    VStack {
                        Text("Detected: \(prediction.label)")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(prediction.label == "Dog Bark" ? .orange : (prediction.label == "Cat Meow" ? .purple : .gray))
                        Text(String(format: "Confidence: %.2f%%", prediction.confidence * 100))
                            .font(.body)
                            .foregroundColor(.secondary)
                    }
                    .padding()
                    .animation(.easeInOut, value: prediction.label)
                } else {
                    Text("No sound detected yet.")
                        .font(.title2)
                        .foregroundColor(.gray)
                        .padding()
                }
            } else {
                Text("Microphone access is required to monitor pet sounds.")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding()
                Button("Request Microphone Access") {
                    Task {
                        await audioClassifier.requestMicrophonePermission()
                    }
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
        }
        .onAppear {
            Task {
                await audioClassifier.requestMicrophonePermission()
            }
        }
        .padding()
    }
}

// MARK: - App Entry Point (for iOS)
/*
@main
struct PetMonitorApp: App {
    var body: some Scene {
        WindowGroup {
            PetMonitorView()
        }
    }
}
*/

// MARK: - App Entry Point (for macOS)
/*
// For macOS, you'd use NSApplicationDelegate and NSWindow, or a similar SwiftUI App structure.
// The core logic in AudioClassifierService and PetMonitorView remains the same.
@main
struct PetMonitorMacOSApp: App {
    var body: some Scene {
        WindowGroup {
            PetMonitorView()
                .frame(minWidth: 400, minHeight: 300) // Adjust window size for macOS
        }
    }
}
*/
