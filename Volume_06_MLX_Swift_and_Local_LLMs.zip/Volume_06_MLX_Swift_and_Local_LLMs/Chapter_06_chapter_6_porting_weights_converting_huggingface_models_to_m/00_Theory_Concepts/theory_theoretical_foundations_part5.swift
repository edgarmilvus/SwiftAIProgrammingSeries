
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import MLX
import MLXNN

@available(iOS 18.0, *)
@Observable class ConversionViewModel {
    var status: String = "Waiting to start..."
    var progress: Double = 0.0
    var errorMessage: String?
    var isConverting: Bool = false

    private let manager = ModelConversionManager() // Instantiate our actor

    func startConversion(modelName: String, sourceURL: URL) async {
        isConverting = true
        errorMessage = nil
        do {
            // Observe the actor's state changes
            for await _ in manager.$currentProgress.values { // Example, if actor properties were @Published
                // For a simple actor, we'd poll or use a callback mechanism
                self.progress = await manager.getProgress()
                self.status = await manager.getStatus()
            }
            // A simpler approach for this example: direct calls and updates
            _ = try await manager.convertAndCacheModel(modelName: modelName, sourceURL: sourceURL)
            self.status = await manager.getStatus()
            self.progress = await manager.getProgress()
        } catch {
            self.errorMessage = "Conversion failed: \(error.localizedDescription)"
            self.status = "Error!"
        }
        isConverting = false
    }
}

// Example SwiftUI View (conceptual)
/*
@available(iOS 18.0, *)
struct ConversionView: View {
    @State private var viewModel = ConversionViewModel()
    let modelSourceURL = URL(string: "https://example.com/model_weights.safetensors")!

    var body: some View {
        VStack {
            ProgressView(value: viewModel.progress) {
                Text(viewModel.status)
            }
            .padding()

            if let error = viewModel.errorMessage {
                Text(error)
                    .foregroundColor(.red)
            }

            Button("Start Conversion") {
                Task {
                    await viewModel.startConversion(modelName: "MyLLM", sourceURL: modelSourceURL)
                }
            }
            .disabled(viewModel.isConverting)
        }
    }
}
*/
