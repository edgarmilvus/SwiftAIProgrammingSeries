
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import Foundation

// MARK: - Ollama API Response Structures (re-used from Exercise 1)

/// Represents a single streaming chunk from Ollama's /api/generate endpoint.
struct OllamaStreamingResponse: Decodable {
    let model: String?
    let createdAt: String?
    let response: String? // The actual token generated
    let done: Bool
    // Optional metrics from Ollama, useful for deeper analysis if needed
    let totalDuration: Int?
    let loadDuration: Int?
    let promptEvalCount: Int?
    let promptEvalDuration: Int?
    let evalCount: Int?
    let evalDuration: Int?
}

// MARK: - Model and Result Definitions

/// Enum to represent the LLM models available for comparison.
enum LLMModel: String, CaseIterable, Identifiable {
    case llama3 = "llama3:8b-instruct"
    case phi3 = "phi-3:mini"
    case mistral = "mistral:7b-instruct"

    var id: String { rawValue } // Conformance to Identifiable for SwiftUI Pickers/ForEach
    var displayName: String {
        switch self {
        case .llama3: return "Llama 3 (8B Instruct)"
        case .phi3: return "Phi-3 (Mini)"
        case .mistral: return "Mistral (7B Instruct)"
        }
    }
}

/// Struct to hold the performance and output results for a single model.
struct SummaryResult: Identifiable {
    let id = UUID() // Unique ID for SwiftUI ForEach
    let model: LLMModel
    var summary: String = "No summary generated yet."
    var inferenceTime: TimeInterval? // In seconds
    var tokensGenerated: Int?
    var tps: Double? // Tokens Per Second
    var errorMessage: String?
    var isLoading: Bool = false
}

// MARK: - Main SwiftUI Application

@main
struct ModelComparisonApp: App {
    var body: some Scene {
        WindowGroup {
            ModelComparisonView()
        }
    }
}

// MARK: - ModelComparisonView

struct ModelComparisonView: View {
    @State private var inputText: String = "Paste your article here for summarization. For example, a news article, a research paper abstract, or a long email. The longer the text, the more pronounced the performance differences between models might be."
    @State private var selectedModel: LLMModel = .phi3
    @State private var results: [LLMModel: SummaryResult] = [:]

    // Ollama server details
    private let ollamaHost = "localhost"
    private let ollamaPort = 11434

    var body: some View {
        VStack(spacing: 15) {
            Text("LLM Summarization Comparison")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 10)

            // Input TextEditor
            TextEditor(text: $inputText)
                .font(.body)
                .frame(minHeight: 150, maxHeight: 300)
                .border(Color.gray.opacity(0.3), width: 1)
                .cornerRadius(5)
                .padding(.horizontal)
                .overlay(
                    Group {
                        if inputText.isEmpty {
                            Text("Paste your article here...")
                                .foregroundColor(.gray)
                                .padding(.horizontal, 20)
                                .padding(.vertical, 8)
                        }
                    }, alignment: .topLeading
                )

            // Model Selection and Summarize Button
            HStack {
                Picker("Select Model", selection: $selectedModel) {
                    ForEach(LLMModel.allCases) { model in
                        Text(model.displayName).tag(model)
                    }
                }
                .pickerStyle(.menu)
                .frame(width: 250)

                Spacer()

                Button(action: {
                    Task {
                        await summarizeArticle(for: selectedModel)
                    }
                }) {
                    Label("Summarize", systemImage: "text.book.closed.fill")
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || results[selectedModel]?.isLoading == true)
            }
            .padding(.horizontal)

            // Results Display Area
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    ForEach(LLMModel.allCases) { model in
                        if let result = results[model] {
                            SummaryResultView(result: result)
                                .padding(.bottom, 10)
                        } else {
                            // Placeholder for models not yet summarized or initialized
                            VStack(alignment: .leading) {
                                Text("\(model.displayName) (No data)")
                                    .font(.headline)
                                    .foregroundColor(.gray)
                                Divider()
                            }
                            .padding(.bottom, 10)
                        }
                    }
                }
                .padding(.horizontal)
            }
        }
        .padding()
        .frame(minWidth: 700, minHeight: 600)
        // Initialize results for all models on app launch
        .onAppear {
            for model in LLMModel.allCases {
                results[model] = SummaryResult(model: model)
            }
        }
    }

    /// Sends the article to the specified Ollama model for summarization.
    private func summarizeArticle(for model: LLMModel) async {
        // Update UI state for loading
        await MainActor.run {
            results[model]?.isLoading = true
            results[model]?.errorMessage = nil
            results[model]?.summary = "Generating summary..."
            results[model]?.inferenceTime = nil
            results[model]?.tokensGenerated = nil
            results[model]?.tps = nil
        }

        do {
            guard let url = URL(string: "http://\(ollamaHost):\(ollamaPort)/api/generate") else {
                throw URLError(.badURL)
            }

            let prompt = "Summarize the following article concisely and clearly:\n\n\(inputText)"
            let requestBody: [String: Any] = [
                "model": model.rawValue,
                "prompt": prompt,
                "stream": true
            ]
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody)

            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = jsonData

            let startTime = Date() // Start timing inference

            let (asyncBytes, response) = try await URLSession.shared.bytes(for: request)

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                let statusCode = (response as? HTTPURLResponse)?.statusCode ?? -1
                let responseData = String(data: try await Data(asyncBytes), encoding: .utf8) ?? "No data"
                throw URLError(.badServerResponse, userInfo: [
                    NSLocalizedDescriptionKey: "Server returned status \(statusCode). Response: \(responseData)"
                ])
            }

            var generatedSummary = ""
            var tokenCount = 0

            for try await line in asyncBytes.lines {
                guard let data = line.data(using: .utf8) else { continue }
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase

                let streamingResponse = try decoder.decode(OllamaStreamingResponse.self, from: data)

                await MainActor.run {
                    if let responseText = streamingResponse.response, !responseText.isEmpty {
                        generatedSummary += responseText
                        tokenCount += 1
                        results[model]?.summary = generatedSummary // Update summary incrementally
                    }
                    if streamingResponse.done {
                        // Finalize metrics
                        let endTime = Date()
                        let inferenceDuration = endTime.timeIntervalSince(startTime)
                        let calculatedTPS = inferenceDuration > 0 ? Double(tokenCount) / inferenceDuration : 0.0

                        results[model]?.inferenceTime = inferenceDuration
                        results[model]?.tokensGenerated = tokenCount
                        results[model]?.tps = calculatedTPS
                        results[model]?.isLoading = false
                    }
                }
            }
        } catch {
            await MainActor.run {
                results[model]?.isLoading = false
                if let urlError = error as? URLError {
                    results[model]?.errorMessage = "Network error: \(urlError.localizedDescription). Is Ollama running and model '\(model.rawValue)' downloaded? Check `http://localhost:11434`."
                } else if let decodingError = error as? DecodingError {
                    results[model]?.errorMessage = "Data decoding error: \(decodingError.localizedDescription)"
                } else {
                    results[model]?.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                }
                results[model]?.summary = "Error generating summary."
                print("Error for \(model.rawValue): \(error)")
            }
        }
    }
}

// MARK: - Helper View for displaying a single model's results

struct SummaryResultView: View {
    let result: SummaryResult

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(result.model.displayName)
                    .font(.headline)
                if result.isLoading {
                    ProgressView()
                        .controlSize(.small)
                }
                Spacer()
            }
            
            if let errorMessage = result.errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .font(.caption)
            } else {
                Group {
                    if let inferenceTime = result.inferenceTime,
                       let tokensGenerated = result.tokensGenerated,
                       let tps = result.tps {
                        Text("Inference Time: \(String(format: "%.2f", inferenceTime))s")
                        Text("Tokens Generated: \(tokensGenerated)")
                        Text("Tokens/Second: \(String(format: "%.2f", tps))")
                    } else if result.isLoading {
                        Text("Metrics will appear after generation.")
                            .font(.caption)
                            .foregroundColor(.gray)
                    } else {
                        Text("Click 'Summarize' to generate.")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
                .font(.subheadline)
                .foregroundColor(.secondary)

                Text("Summary:")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .padding(.top, 5)

                Text(result.summary)
                    .textSelection(.enabled)
                    .font(.body)
                    .padding(8)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.blue.opacity(0.05))
                    .cornerRadius(5)
            }
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}
