
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// MARK: - Package.swift Dependencies
/*
// To be used in a Swift Package Manager project
let package = Package(
    name: "DocumentAI",
    platforms: [.macOS(.v15), .iOS(.v18)],
    dependencies: [
        .package(url: "https://github.com/openai/openai-swift", from: "1.0.0")
    ],
    targets: [
        .target(
            name: "DocumentAI",
            dependencies: [.product(name: "OpenAI", package: "openai-swift")]
        )
    ]
)
*/

import Foundation
import PDFKit
import NaturalLanguage
import OpenAI // Hypothetical high-level wrapper

/// Represents a single, semantically coherent unit of text extracted from a document.
/// Conforms to `Sendable` to ensure safe transfer across concurrency domains.
struct DocumentChunk: Sendable, Identifiable {
    let id: UUID
    let text: String
    let pageNumber: Int
    let metadata: [String: String]
    let embedding: [Float]?
    
    init(text: String, pageNumber: Int, metadata: [String: String] = [:], embedding: [Float]? = nil) {
        self.id = UUID()
        self.text = text
        self.pageNumber = pageNumber
        self.metadata = metadata
        self.embedding = embedding
    }
}

/// Errors specific to the PDF Ingestion and Embedding pipeline.
enum IngestionError: Error, LocalizedError {
    case pdfLoadingFailed
    case textExtractionFailed
    case chunkingError(String)
    case embeddingGenerationFailed(Error)
    
    var errorDescription: String? {
        switch self {
        case .pdfLoadingFailed: return "The PDF file could not be loaded."
        case .textExtractionFailed: return "Failed to extract text from the PDF pages."
        case .chunkingError(let msg): return "Chunking failed: \(msg)"
        case .embeddingGenerationFailed(let err): return "Embedding error: \(err.localizedDescription)"
        }
    }
}

/// A protocol defining the strategy for breaking down large text bodies into manageable chunks.
protocol ChunkingStrategy: Sendable {
    /// Splits the provided text into an array of semantic chunks.
    /// - Parameters:
    ///   - text: The raw text to be chunked.
    ///   - maxTokens: The maximum allowed size for a single chunk (to fit LLM context windows).
    /// - Returns: An array of processed text segments.
    func chunk(text: String, maxTokens: Int) async throws -> [String]
}

/// An advanced chunker that uses Apple's `NaturalLanguage` framework to respect sentence boundaries.
/// This prevents the "fragmented thought" problem common in character-based splitting.
struct SemanticSentenceChunker: ChunkingStrategy {
    let overlapTokens: Int
    
    init(overlapTokens: Int = 50) {
        self.overlapTokens = overlapTokens
    }
    
    func chunk(text: String, maxTokens: Int) async throws -> [String] {
        let tokenizer = NLTokenizer(unit: .sentence)
        tokenizer.string = text
        
        var chunks: [String] = []
        var currentChunkBuffer: [String] = []
        var currentTokenCount = 0
        
        // Iterate through sentence boundaries identified by the NLP model
        tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { range, _ in
            let sentence = String(text[range])
            let sentenceTokens = sentence.split(separator: " ").count // Simplified token count
            
            // If adding this sentence exceeds the limit, flush the buffer
            if currentTokenCount + sentenceTokens > maxTokens && !currentChunkBuffer.isEmpty {
                chunks.append(currentChunkBuffer.joined(separator: " "))
                
                // Implement sliding window overlap: 
                // Keep the last few sentences to maintain context for the next chunk
                let overlapCount = min(currentChunkBuffer.count, 2) 
                currentChunkBuffer = Array(currentChunkBuffer.suffix(overlapCount))
                currentTokenCount = currentChunkBuffer.reduce(0) { $0 + $1.split(separator: " ").count }
            }
            
            currentChunkBuffer.append(sentence)
            currentTokenCount += sentenceTokens
            return true
        }
        
        // Flush remaining buffer
        if !currentChunkBuffer.isEmpty {
            chunks.append(currentChunkBuffer.joined(separator: " "))
        }
        
        return chunks
    }
}

/// An Actor that orchestrates the ingestion process. 
/// Using an `actor` ensures that the state of the ingestion (progress, partially processed chunks) 
/// is protected from data races during high-concurrency operations.
@available(iOS 18.0, macOS 15.0, *)
actor PDFIngestionEngine {
    private let chunker: ChunkingStrategy
    private let maxTokensPerChunk: Int
    private let embeddingClient: EmbeddingProvider // Abstracted API client
    
    /// Tracks the progress of the current ingestion task.
    private(set) var progress: Double = 0.0
    
    init(chunker: ChunkingStrategy = SemanticSentenceChunker(), 
         maxTokensPerChunk: Int = 512,
         embeddingClient: EmbeddingProvider) {
        self.chunker = chunker
        self.maxTokensPerChunk = maxTokensPerChunk
        self.embeddingClient = embeddingClient
    }
    
    /// Processes a PDF file from a URL and returns a collection of enriched chunks.
    /// - Parameter url: The local file URL of the PDF.
    /// - Returns: An array of `DocumentChunk` containing text, metadata, and embeddings.
    func process(url: URL) async throws -> [DocumentChunk] {
        guard let document = PDFDocument(url: url) else {
            throw IngestionError.pdfLoadingFailed
        }
        
        let totalPages = document.pageCount
        var allEnrichedChunks: [DocumentChunk] = []
        
        // Process pages in parallel using a TaskGroup for maximum performance
        try await withThrowingTaskGroup(of: [DocumentChunk].self) { group in
            for pageIndex in 0..<totalPages {
                group.addTask {
                    return try await self.processPage(document.page(at: pageIndex), index: pageIndex)
                }
            }
            
            for try await pageChunks in group {
                allEnrichedChunks.append(contentsOf: pageChunks)
            }
        }
        
        // Sort chunks by page number to maintain document order
        allEnrichedChunks.sort { $0.pageNumber < $1.pageNumber }
        self.progress = 1.0
        return allEnrichedChunks
    }
    
    /// Internal method to process a single page.
    /// - Parameters:
    ///   - page: The PDFPage object.
    ///   - index: The 0-based index of the page.
    /// - Returns: An array of enriched chunks for that specific page.
    private func processPage(_ page: PDFPage?, index: Int) async throws -> [DocumentChunk] {
        guard let page = page, let pageText = page.string, !pageText.isEmpty else {
            return []
        }
        
        // 1. Perform Semantic Chunking
        let textSegments = try await chunker.chunk(text: pageText, maxTokens: maxTokensPerChunk)
        
        var pageChunks: [DocumentChunk] = []
        
        // 2. Generate Embeddings for each segment
        for segment in textSegments {
            // Call the external LLM API for embedding generation
            let vector = try await embeddingClient.generateEmbedding(for: segment)
            
            let chunk = DocumentChunk(
                text: segment,
                pageNumber: index + 1,
                metadata: ["source": "PDF_Ingestion_Engine"],
                embedding: vector
            )
            pageChunks.append(chunk)
        }
        
        return pageChunks
    }
}

/// Protocol for an embedding service to allow for easy mocking during Unit Tests.
protocol EmbeddingProvider: Sendable {
    func generateEmbedding(for text: String) async throws -> [Float]
}

/// A production implementation of an Embedding Service using OpenAI's API.
struct OpenAIEmbeddingService: EmbeddingProvider {
    let apiKey: String
    let model: String = "text-embedding-3-small"
    
    func generateEmbedding(for text: String) async throws -> [Float] {
        // In a real implementation, this would be an URLSession call to:
        // https://api.openai.com/v1/embeddings
        
        // Simulating network latency and API response
        try await Task.sleep(for: .milliseconds(150))
        
        // Mocking a 1536-dimensional vector
        return (0..<1536).map { _ in Float.random(in: -1...1) }
    }
}

// MARK: - Usage Example (App Component)

@MainActor
class DocumentAuditorViewModel: ObservableObject {
    @Published var isProcessing = false
    @Published var processedChunks: [DocumentChunk] = []
    @Published var errorMessage: String?
    
    private let engine: PDFIngestionEngine
    
    init(embeddingService: EmbeddingProvider) {
        self.engine = PDFIngestionEngine(embeddingClient: embeddingService)
    }
    
    func ingestDocument(at url: URL) async {
        isProcessing = true
        errorMessage = nil
        
        do {
            // The heavy lifting happens on the PDFIngestionEngine actor,
            // keeping the MainActor (UI) responsive.
            let chunks = try await engine.process(url: url)
            self.processedChunks = chunks
        } catch {
            self.errorMessage = error.localizedDescription
        }
        
        isProcessing = false
    }
}
