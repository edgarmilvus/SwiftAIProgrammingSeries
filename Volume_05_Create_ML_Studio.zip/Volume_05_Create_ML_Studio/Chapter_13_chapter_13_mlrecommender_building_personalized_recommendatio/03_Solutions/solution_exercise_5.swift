
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import CreateML
import CoreML

// MARK: - Data Models

struct UserProfile {
    let userID: String
    let interests: [String]
    let location: String
    let signupDate: Date
}

struct PostMetadata {
    let postID: String
    let topicTags: [String]
    let creationDate: Date
    let authorID: String
    var likes: Int // Simulate popularity
}

struct UserPostInteraction: Codable {
    let userID: String
    let postID: String
    let interactionType: String // e.g., "like", "share", "view"
    let timestamp: Date
}

// MARK: - Data Generation and Management

class ConnectSphereDataManager {
    var userProfiles: [String: UserProfile] = [:]
    var postMetadata: [String: PostMetadata] = [:]
    var userPostInteractions: [UserPostInteraction] = []

    private let users = (1...20).map { "user\($0)" }
    private let topics = ["Tech", "Sports", "Politics", "Art", "Food", "Travel"]
    private let locations = ["NY", "LA", "CHI", "MIA"]

    init() {
        generateInitialData()
    }

    private func generateInitialData() {
        // Generate User Profiles
        for user in users {
            let numInterests = Int.random(in: 1...3)
            let userInterests = topics.shuffled().prefix(numInterests).map { $0 }
            let location = locations.randomElement()!
            let signupDate = Date().addingTimeInterval(-Double.random(in: 0...(30 * 24 * 3600))) // Up to 30 days ago
            userProfiles[user] = UserProfile(userID: user, interests: userInterests, location: location, signupDate: signupDate)
        }
        userProfiles["newUser1"] = UserProfile(userID: "newUser1", interests: ["Tech", "Sports"], location: "SF", signupDate: Date()) // A new user with interests
        userProfiles["newUser2"] = UserProfile(userID: "newUser2", interests: [], location: "BOS", signupDate: Date()) // A new user without interests

        // Generate Post Metadata
        for i in 1...50 { // 50 posts
            let postID = "post\(i)"
            let numTags = Int.random(in: 1...2)
            let postTags = topics.shuffled().prefix(numTags).map { $0 }
            let creationDate = Date().addingTimeInterval(-Double.random(in: 0...(20 * 24 * 3600))) // Up to 20 days ago
            let author = users.randomElement()!
            let likes = Int.random(in: 5...500) // Simulate varying popularity
            postMetadata[postID] = PostMetadata(postID: postID, topicTags: postTags, creationDate: creationDate, authorID: author, likes: likes)
        }
        postMetadata["newPost1"] = PostMetadata(postID: "newPost1", topicTags: ["Tech", "AI"], creationDate: Date(), authorID: "user1", likes: 0) // A brand new post
        postMetadata["newPost2"] = PostMetadata(postID: "newPost2", topicTags: ["Food"], creationDate: Date().addingTimeInterval(-1000), authorID: "user5", likes: 0) // Another new post

        // Generate User-Post Interactions
        for user in users {
            let numInteractions = Int.random(in: 10...30)
            for _ in 0..<numInteractions {
                if let post = postMetadata.values.randomElement() {
                    let interactionType = ["like", "share", "view"].randomElement()!
                    let timestamp = Date().addingTimeInterval(-Double.random(in: 0...(15 * 24 * 3600)))
                    userPostInteractions.append(UserPostInteraction(userID: user, postID: post.postID, interactionType: interactionType, timestamp: timestamp))
                    // Simulate like count update
                    if interactionType == "like" {
                        postMetadata[post.postID]?.likes += 1
                    }
                }
            }
        }
    }

    func getInteractionsAsMLDataTable() throws -> MLDataTable {
        let userIDs = userPostInteractions.map { $0.userID }
        let postIDs = userPostInteractions.map { $0.postID }
        let interactionTypes = userPostInteractions.map { $0.interactionType }

        // For MLRecommender, we'll use a simplified implicit feedback: just the presence of interaction
        return try MLDataTable(dictionary: [
            "userID": userIDs,
            "postID": postIDs,
            "interactionType": interactionTypes // This column is present but not used as rating for implicit
        ])
    }

    func getUserInteractionCount(for userID: String) -> Int {
        return userPostInteractions.filter { $0.userID == userID }.count
    }

    func getPopularPosts(count: Int, excluding: Set<String> = []) -> [String] {
        return postMetadata.values
            .filter { !excluding.contains($0.postID) }
            .sorted { $0.likes > $1.likes }
            .prefix(count)
            .map { $0.postID }
    }

    func getPostsByInterests(interests: [String], count: Int, excluding: Set<String> = []) -> [String] {
        guard !interests.isEmpty else { return [] }
        return postMetadata.values
            .filter { !excluding.contains($0.postID) && !$0.topicTags.intersection(Set(interests)).isEmpty }
            .sorted { $0.creationDate > $1.creationDate } // Newest within interests
            .prefix(count)
            .map { $0.postID }
    }

    func getNewestPosts(count: Int, excluding: Set<String> = []) -> [String] {
        return postMetadata.values
            .filter { !excluding.contains($0.postID) }
            .sorted { $0.creationDate > $1.creationDate }
            .prefix(count)
            .map { $0.postID }
    }

    func getRandomPosts(count: Int, excluding: Set<String> = []) -> [String] {
        return postMetadata.values
            .filter { !excluding.contains($0.postID) }
            .shuffled()
            .prefix(count)
            .map { $0.postID }
    }
}

// MARK: - Recommendation Engine

@available(iOS 18.0, macOS 15.0, *)
class ConnectSphereRecommender {
    private var recommender: MLRecommender?
    private let dataManager: ConnectSphereDataManager
    private let modelURL: URL
    private let minInteractionsForMLRecommender = 5 // Threshold for MLRecommender eligibility

    init(dataManager: ConnectSphereDataManager) {
        self.dataManager = dataManager
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        self.modelURL = documentsDirectory.appendingPathComponent("ConnectSphereRecommender.mlmodel")
        
        // Train and load model on initialization
        Task {
            do {
                try await trainAndLoadModel()
            } catch {
                print("Failed to train/load MLRecommender: \(error)")
            }
        }
    }

    private func trainAndLoadModel() async throws {
        print("Training MLRecommender model...")
        let dataTable = try dataManager.getInteractionsAsMLDataTable()
        let builder = MLRecommenderBuilder(trainingData: dataTable,
                                           userIdentifierColumn: "userID",
                                           itemIdentifierColumn: "postID") // Implicit feedback model
        let newModel = try builder.build()
        try newModel.write(to: modelURL)
        print("MLRecommender model trained and saved.")

        let compiledModelURL = try MLModel.compileModel(at: modelURL)
        self.recommender = try MLRecommender(contentsOf: compiledModelURL)
        print("MLRecommender model loaded successfully.")
    }

    /// Generates a personalized "Discover" feed, handling cold start for users and items.
    func getDiscoverFeed(for userID: String, count: Int = 10) async -> [String] {
        var recommendedPosts: Set<String> = []
        let userInteractionsCount = dataManager.getUserInteractionCount(for: userID)
        let userProfile = dataManager.userProfiles[userID]
        
        print("\n--- Generating Discover Feed for \(userID) (Interactions: \(userInteractionsCount)) ---")

        // 1. MLRecommender (Primary Source for established users)
        if userInteractionsCount >= minInteractionsForMLRecommender, let mlRecommender = recommender {
            do {
                print("User \(userID) has enough history. Querying MLRecommender...")
                let mlRecommendations = try mlRecommender.recommendations(forUsers: [userID], k: count * 2) // Fetch more
                let postIDs = mlRecommendations["postID"].map { $0.map { $0.stringValue ?? "" } } ?? []
                recommendedPosts.formUnion(postIDs)
                print("MLRecommender suggested \(postIDs.count) posts.")
            } catch {
                print("MLRecommender failed for \(userID): \(error.localizedDescription). Falling back.")
            }
        } else {
            print("User \(userID) is new or MLRecommender not ready. Applying cold start strategies.")
        }

        // Filter out posts the user has already interacted with (if available)
        let interactedPosts = Set(dataManager.userPostInteractions.filter { $0.userID == userID }.map { $0.postID })
        recommendedPosts.subtract(interactedPosts)

        // 2. Cold Start Logic (New Users & Fallbacks)
        var fallbackPosts: [String] = []
        
        // Priority 1: Content-based (initial interests)
        if let interests = userProfile?.interests, !interests.isEmpty {
            let postsByInterests = dataManager.getPostsByInterests(interests: interests, count: count, excluding: recommendedPosts)
            fallbackPosts.append(contentsOf: postsByInterests)
            print("Added \(postsByInterests.count) posts based on interests.")
        }
        
        // Priority 2: Popularity-based
        if recommendedPosts.count + fallbackPosts.count < count {
            let popularPosts = dataManager.getPopularPosts(count: count, excluding: recommendedPosts.union(fallbackPosts))
            fallbackPosts.append(contentsOf: popularPosts)
            print("Added \(popularPosts.count) popular posts.")
        }

        // Priority 3: Newest Posts (for fresh content)
        if recommendedPosts.count + fallbackPosts.count < count {
            let newestPosts = dataManager.getNewestPosts(count: count, excluding: recommendedPosts.union(fallbackPosts))
            fallbackPosts.append(contentsOf: newestPosts)
            print("Added \(newestPosts.count) newest posts.")
        }
        
        // Priority 4: Random (as a last resort)
        if recommendedPosts.count + fallbackPosts.count < count {
            let randomPosts = dataManager.getRandomPosts(count: count, excluding: recommendedPosts.union(fallbackPosts))
            fallbackPosts.append(contentsOf: randomPosts)
            print("Added \(randomPosts.count) random posts.")
        }
        
        // Blend MLRecommender and fallback posts, prioritizing MLRecommender results
        var finalFeed = Array(recommendedPosts) // MLRecommender results first
        finalFeed.append(contentsOf: fallbackPosts.filter { !finalFeed.contains($0) }) // Add unique fallbacks

        // 3. Cold Start Logic (New Items/Posts) - Blending
        // Ensure new posts get exposure, even if MLRecommender doesn't pick them up yet.
        let numNewArrivalsToBlend = min(count / 3, 3) // e.g., 30% of total, max 3
        if numNewArrivalsToBlend > 0 {
            let newArrivals = dataManager.getNewestPosts(count: numNewArrivalsToBlend, excluding: Set(finalFeed))
            if !newArrivals.isEmpty {
                print("Blending in \(newArrivals.count) new arrival posts.")
                finalFeed.insert(contentsOf: newArrivals, at: 0) // Insert at beginning for visibility
            }
        }

        // Deduplicate and trim to desired count
        let finalUniqueFeed = Array(Set(finalFeed)).prefix(count)
        return Array(finalUniqueFeed)
    }
}

// MARK: - Example Usage

func runExercise4() async {
    print("--- Running Exercise 4: Cold Start Strategies ---")

    let dataManager = ConnectSphereDataManager()
    let recommenderEngine = ConnectSphereRecommender(dataManager: dataManager)

    // Give some time for the model to train and load
    try? await Task.sleep(for: .seconds(2))

    // Test Case 1: Existing User (enough history)
    let existingUser = dataManager.userProfiles.keys.first { dataManager.getUserInteractionCount(for: $0)! >= recommenderEngine.minInteractionsForMLRecommender } ?? "user1"
    let feedForExistingUser = await recommenderEngine.getDiscoverFeed(for: existingUser, count: 5)
    print("Discover Feed for existing user \(existingUser): \(feedForExistingUser)\n")

    // Test Case 2: New User with Interests (cold start)
    let newUserWithInterests = "newUser1"
    let feedForNewUserWithInterests = await recommenderEngine.getDiscoverFeed(for: newUserWithInterests, count: 5)
    print("Discover Feed for new user (with interests) \(newUserWithInterests): \(feedForNewUserWithInterests)\n")

    // Test Case 3: New User without Interests (more severe cold start)
    let newUserWithoutInterests = "newUser2"
    let feedForNewUserWithoutInterests = await recommenderEngine.getDiscoverFeed(for: newUserWithoutInterests, count: 5)
    print("Discover Feed for new user (no interests) \(newUserWithoutInterests): \(feedForNewUserWithoutInterests)\n")

    print("--- Exercise 4 Finished ---\n")
}

// Call the async function to run the exercise
Task {
    await runExercise4()
}
