
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import Combine // For PassthroughSubject to simulate UI updates

// MARK: - Simulated AI Model

/// Simulates a generative AI model that streams tokens.
/// This AsyncSequence is cooperatively cancellable.
func generateTokens(prompt: String) async throws -> AsyncStream<String> {
    print("AI Generator: Starting token generation for prompt: '\(prompt)'")
    let words = prompt.split(separator: " ").map(String.init)
    
    return AsyncStream { continuation in
        // A detached task to run the generation logic.
        // This task will respect cancellation requests from the AsyncStream's consumer.
        Task {
            do {
                var currentTokenIndex = 0
                while currentTokenIndex < words.count * 2 { // Generate more tokens than just the input words
                    try Task.checkCancellation() // Check for cancellation before each token
                    
                    let token: String
                    if currentTokenIndex < words.count {
                        token = words[currentTokenIndex] + " "
                    } else {
                        // Simulate generating new content
                        let generatedWords = ["and", "then", "it", "said", "hello", "world", "swift", "concurrency", "is", "great"]
                        token = generatedWords[currentTokenIndex % generatedWords.count] + " "
                    }
                    
                    continuation.yield(token)
                    print("AI Generator: Yielded token: '\(token.trimmingCharacters(in: .whitespacesAndNewlines))'")
                    
                    let delay = Double.random(in: 0.05...0.2) // Simulate real-time streaming delay
                    try await Task.sleep(for: .milliseconds(Int(delay * 1000)))
                    
                    currentTokenIndex += 1
                }
                continuation.finish()
                print("AI Generator: Finished generating tokens.")
            } catch is CancellationError {
                print("AI Generator: Token generation was cancelled.")
                continuation.finish() // Ensure stream finishes on cancellation
            } catch {
                print("AI Generator: Token generation failed with error: \(error.localizedDescription)")
                continuation.finish(throwing: error) // Finish with error
            }
        }
    }
}

// MARK: - Chat Manager Class

/// A class (or actor) to manage the chat interactions and token generation.
/// It handles dynamic cancellation of ongoing generations.
class ChatManager {
    // Using PassthroughSubject to simulate UI updates, similar to @Published in SwiftUI
    let receivedTokens = PassthroughSubject<String, Never>()
    let generationStatus = PassthroughSubject<String, Never>()
    
    private var currentGenerationTask: Task<Void, Never>?
    
    func sendMessage(prompt: String) {
        // 1. If a previous generation is active, cancel it immediately.
        if let activeTask = currentGenerationTask {
            print("Chat Manager: Cancelling previous generation for new prompt: '\(prompt)'")
            activeTask.cancel()
        }
        
        generationStatus.send("Generating...")
        
        // 2. Start a new Task for the token generation.
        currentGenerationTask = Task {
            do {
                let tokenStream = try await generateTokens(prompt: prompt)
                var fullResponse = ""
                
                // Iterate over the AsyncStream to receive tokens
                for try await token in tokenStream {
                    // Check for cancellation *within* the loop, as the stream itself is cancellable.
                    // This is redundant if `generateTokens` is robustly cancellable, but good practice
                    // if the stream source might not check frequently.
                    try Task.checkCancellation()
                    
                    fullResponse += token
                    receivedTokens.send(token) // Notify UI of new token
                }
                
                // If we reach here, the stream finished naturally
                generationStatus.send("Finished: \(fullResponse.prefix(50))...")
                print("Chat Manager: Generation completed for prompt: '\(prompt)'")
            } catch is CancellationError {
                generationStatus.send("Cancelled.")
                print("Chat Manager: Generation for prompt: '\(prompt)' was cancelled.")
            } catch {
                generationStatus.send("Error: \(error.localizedDescription)")
                print("Chat Manager: Generation for prompt: '\(prompt)' failed: \(error.localizedDescription)")
            }
            // Clear the task reference once it's finished (or cancelled/failed)
            self.currentGenerationTask = nil
        }
    }
    
    func stopGenerating() {
        guard let activeTask = currentGenerationTask else {
            print("Chat Manager: No active generation to stop.")
            return
        }
        print("Chat Manager: 'Stop Generating' tapped. Cancelling current generation.")
        activeTask.cancel()
    }
    
    deinit {
        currentGenerationTask?.cancel()
    }
}

// MARK: - Demonstration

func demonstrateRealtimeChat() async {
    let chatManager = ChatManager()
    
    // Subscribe to updates (simulating a SwiftUI View's @ObservedObject)
    let tokenCancellable = chatManager.receivedTokens.sink { token in
        print("UI Display: Received token: '\(token.trimmingCharacters(in: .whitespacesAndNewlines))'")
    }
    let statusCancellable = chatManager.generationStatus.sink { status in
        print("UI Status: \(status)")
    }
    
    print("--- Scenario 1: Single prompt, finishes naturally ---")
    chatManager.sendMessage(prompt: "Tell me a short story about a brave knight and a dragon")
    await Task.sleep(for: .seconds(3)) // Let it generate for a bit
    print("\n")
    
    print("--- Scenario 2: New prompt cancels previous one ---")
    chatManager.sendMessage(prompt: "Describe the process of photosynthesis in simple terms.")
    await Task.sleep(for: .milliseconds(500)) // Let it start
    chatManager.sendMessage(prompt: "What is the capital of France?") // New prompt, cancels previous
    await Task.sleep(for: .seconds(2)) // Let the new one run
    print("\n")
    
    print("--- Scenario 3: User explicitly stops generation ---")
    chatManager.sendMessage(prompt: "Write a poem about the beauty of the ocean and its creatures.")
    await Task.sleep(for: .seconds(1)) // Let it generate for a bit
    chatManager.stopGenerating()
    await Task.sleep(for: .seconds(1)) // Give time for cancellation
    print("\n")
    
    print("--- Scenario 4: Stop when no generation is active ---")
    chatManager.stopGenerating()
    print("\n")
    
    // Clean up Combine subscriptions
    tokenCancellable.cancel()
    statusCancellable.cancel()
}

// Run the demonstration
await demonstrateRealtimeChat()
