
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import Accelerate

struct Note: Identifiable, Sendable {
    let id: UUID
    let content: String
    let embedding: [Float]
}

actor NoteStore {
    private var notes: [Note] = []
    private let similarityThreshold: Float = 0.7
    
    func add(note: Note) {
        notes.append(note)
    }
    
    /// Searches for notes similar to the query embedding.
    func search(queryEmbedding: [Float], limit: Int) async -> [Note] {
        // Use TaskGroup to parallelize the similarity calculations
        let scoredNotes: [(note: Note, score: Float)] = await withTaskGroup(of: (Note, Float)?.self) { group in
            for note in notes {
                group.addTask {
                    let score = self.cosineSimilarity(query: queryEmbedding, target: note.embedding)
                    // Optimization: Apply threshold immediately
                    if score >= self.similarityThreshold {
                        return (note, score)
                    }
                    return nil
                }
            }
            
            var results: [(Note, Float)] = []
            for await result in group {
                if let validResult = result {
                    results.append(validResult)
                }
            }
            return results
        }
        
        // Sort by score descending and take top K
        return scoredNotes
            .sorted { $0.score > $1.score }
            .prefix(limit)
            .map { $0.note }
    }
    
    /// Batch search for multiple query vectors.
    func batchSearch(queries: [[Float]], limit: Int) async -> [[Note]] {
        await withTaskGroup(of: [Note].self) { group in
            for query in queries {
                group.addTask {
                    await self.search(queryEmbedding: query, limit: limit)
                }
            }
            
            var allResults: [[Note]] = []
            for await result in group {
                allResults.append(result)
            }
            return allResults
        }
    }
    
    // Internal math helper (reusing logic from Exercise 1)
    private func cosineSimilarity(query: [Float], target: [Float]) -> Float {
        guard query.count == target.count, !query.isEmpty else { return 0 }
        let n = vDSP_Length(query.count)
        var dot: Float = 0
        vDSP_dotpr(query, 1, target, 1, &dot, n)
        
        var sumSqQ: Float = 0
        var sumSqT: Float = 0
        vDSP_dotpr(query, 1, query, 1, &sumSqQ, n)
        vDSP_dotpr(target, 1, target, 1, &sumSqT, n)
        
        let mag = sqrt(sumSqQ) * sqrt(sumSqT)
        return mag > 0 ? dot / mag : 0
    }
}
