
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import MLX
import MLXNN

// 1. Define CustomConvolutionFilter Module
class CustomConvolutionFilter: MLXNN.Module {
    let kernel: MLXNN.Parameter
    let bias: MLXNN.Parameter
    let inputChannels: Int
    let outputChannels: Int
    let kernelSize: Int

    init(inputChannels: Int, outputChannels: Int, kernelSize: Int) {
        self.inputChannels = inputChannels
        self.outputChannels = outputChannels
        self.kernelSize = kernelSize

        // Initialize a sharpening kernel: [[0, -1, 0], [-1, 5, -1], [0, -1, 0]]
        // Reshape it to (outputChannels, inputChannels, kernelSize, kernelSize)
        // For simplicity, let's assume inputChannels and outputChannels are 1 for this example.
        // If they were > 1, you'd replicate/expand this kernel appropriately.
        // Or, for a truly custom filter learning scenario, initialize randomly.
        let sharpeningKernelData: [Float] = [
             0, -1,  0,
            -1,  5, -1,
             0, -1,  0
        ]
        let initialKernel = MLXArray(sharpeningKernelData, type: .float32)
            .reshape([1, 1, kernelSize, kernelSize]) // (out_c, in_c, kH, kW)

        // If outputChannels > 1 or inputChannels > 1, you'd need to expand or repeat this kernel
        // For this exercise, we'll stick to 1 input and 1 output channel for the sharpening kernel.
        // If inputChannels != 1 or outputChannels != 1, we'd need to adjust the initialKernel.
        // For demonstration, let's ensure it matches the expected dimensions by broadcasting or repeating.
        var finalKernel: MLXArray
        if outputChannels == 1 && inputChannels == 1 {
            finalKernel = initialKernel
        } else {
            // For a general case, if you want to use this kernel across all channels:
            // This is a simplification; a real learned kernel would have these dimensions.
            // For a fixed kernel, you might apply it to each input channel independently
            // and sum, or apply it to all input channels for each output channel.
            // For this exercise, we'll assume a single channel kernel being applied.
            // Let's create a placeholder if dimensions don't match the simple sharpening kernel.
            print("Warning: Initializing a generic kernel as fixed sharpening for non-1x1 channels is a simplification.")
            finalKernel = MLXArray.zeros([outputChannels, inputChannels, kernelSize, kernelSize], type: .float32)
            // Example: Set the center of the kernel to 1 for a pass-through effect, or a random init
            // For this exercise, we'll keep it simple and assume 1-channel operation for the specific kernel.
            // If the problem implies a single sharpening kernel, it's usually applied to grayscale or each channel separately.
            // Let's adjust the `init` to assume `inputChannels` and `outputChannels` are 1 for the fixed kernel.
            // Or, for a more general case, initialize a random kernel.
            // For the purpose of 'custom filter layer' with a specific kernel, let's assume 1-channel for the example.
            // If `inputChannels` or `outputChannels` are greater than 1, we'd need to adjust `initialKernel` to match.
            // For a sharpening kernel, often you apply the same kernel to all input channels and sum them for each output channel.
            // For simplicity, let's assume input and output channels are 1 for the specific sharpening kernel example.
            // If they are not, we will initialize a generic identity-like kernel.
            if inputChannels == 1 && outputChannels == 1 {
                finalKernel = initialKernel
            } else {
                // Initialize a generic kernel if dimensions don't match the simple sharpening one.
                // This would typically be random for a trainable filter.
                // For a fixed filter, you'd design it for the specific channel count.
                finalKernel = MLXArray.ones([outputChannels, inputChannels, kernelSize, kernelSize], type: .float32) / MLXArray(Float(kernelSize * kernelSize)) // Box blur like
                print("Note: Initializing a generic box blur like kernel because input/output channels are not 1.")
            }
        }

        self.kernel = MLXNN.Parameter(finalKernel)
        self.bias = MLXNN.Parameter(MLXArray.zeros([outputChannels], type: .float32))
        super.init()
    }

    // Implement callAsFunction for the forward pass
    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // x is (batch, channels, height, width) for conv2d in MLX
        // kernel is (output_channels, input_channels, kernel_height, kernel_width)

        // Perform 2D convolution
        // padding: .same ensures output size is same as input size (for stride 1)
        // stride: 1 means the kernel moves one pixel at a time
        let convOutput = MLX.conv2d(x, weight: kernel.array, padding: .same, stride: 1)

        // Add bias to the output. Bias is typically added per output channel.
        // MLX will broadcast the bias across the batch, height, and width dimensions.
        return convOutput + bias.array.reshaped([1, outputChannels, 1, 1])
    }
}

// Main execution block
print("\n--- Exercise 3: Custom Image Filter Layer ---")

// 2. Generate Synthetic Image Data
// (batch, channels, height, width)
let batchSize = 1
let inputChannels = 1 // Grayscale image
let imageHeight = 10
let imageWidth = 10

// Create a simple 10x10 grayscale image with some features (e.g., a square)
var imageData = Array(repeating: Float(0.0), count: batchSize * inputChannels * imageHeight * imageWidth)
// Draw a white square in the middle
for h in 3..<7 {
    for w in 3..<7 {
        imageData[h * imageWidth + w] = 1.0
    }
}
let syntheticImage = MLXArray(imageData, shape: [batchSize, inputChannels, imageHeight, imageWidth], type: .float32)

print("\nOriginal Synthetic Image (10x10, grayscale):")
print(syntheticImage.description)

// 3. Perform a Forward Pass and Discuss Unified Memory
let kernelSize = 3
let outputChannels = 1 // Output is also grayscale for a simple filter

// Instantiate the custom filter
let customFilter = CustomConvolutionFilter(inputChannels: inputChannels, outputChannels: outputChannels, kernelSize: kernelSize)

// Perform a forward pass
let filteredImage = customFilter(syntheticImage)

print("\nFiltered Image Shape:")
print(filteredImage.shape) // Should be [1, 1, 10, 10]

print("\nFiltered Image Content (first 5x5 pixels):")
// To print a portion, we need to convert to Swift array and then format
if let filteredSwiftArray = filteredImage.asArray(Float.self) {
    let flatArray = filteredSwiftArray.flattened()
    for h in 0..<5 {
        var row = ""
        for w in 0..<5 {
            let index = h * imageWidth + w
            if index < flatArray.count {
                row += String(format: "%.2f ", flatArray[index])
            }
        }
        print(row)
    }
}


print("\nDiscussion on MLX's Unified Memory Benefits:")
print("MLX, especially on Apple Silicon, leverages Unified Memory architecture.")
print("This means the CPU, GPU, and Neural Engine share the *same physical memory*.")
print("Traditional architectures require explicit data copies between CPU RAM and GPU VRAM, which is a significant bottleneck for performance and power consumption.")
print("With Unified Memory, MLX operations can access data directly from memory, regardless of which processor initiated or needs the data. This is known as the 'zero-copy' advantage.")
print("For this custom convolution layer, when the `syntheticImage` MLXArray (created on CPU) is passed to `customFilter` and processed on the GPU/Neural Engine, there's no need to copy the entire image tensor.")
print("The compute unit can directly access the image data from the shared memory, reducing latency, improving throughput, and significantly lowering power consumption.")
print("This benefit is crucial for image processing and neural networks, where large tensors are frequently moved and transformed, making MLX highly efficient on Apple hardware.")
