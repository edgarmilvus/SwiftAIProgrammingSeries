
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import RealityKit
import ARKit // Potentially used for ARSession management or advanced scene understanding
import Vision // For conceptual AI integration (e.g., gaze, gesture, object detection)

/// Defines the types of immersive spaces our application can manage.
/// Each type corresponds to a distinct spatial experience or level of immersion.
enum ImmersiveSpaceType: String, CaseIterable, Identifiable {
    case mixedReviewSpace = "MixedReviewSpace" // Default, less intrusive 3D content, allows passthrough
    case fullDetailSpace = "FullDetailSpace"   // Highly immersive, focused 3D content, blocks passthrough
    case collaborativeWhiteboard = "CollaborativeWhiteboard" // A shared 2D/3D workspace, typically mixed

    var id: String { self.rawValue }

    /// Provides the appropriate immersion style for each space type.
    /// This is crucial for visionOS to correctly manage the environment.
    var immersionStyle: ImmersionStyle {
        switch self {
        case .mixedReviewSpace: return .mixed
        case .fullDetailSpace: return .full
        case .collaborativeWhiteboard: return .mixed
        }
    }
}

/// Defines the types of standard windows (volumes) our application can manage.
/// These are typically used for 2D UI, controls, or contextual information that
/// floats within the shared space or an immersive space.
enum AppWindowType: String, CaseIterable, Identifiable {
    case mainControls = "MainControls"       // Primary app controls and navigation
    case aiFeedbackVolume = "AIFeedbackVolume" // Volume for AI-generated messages/data
    case modelProperties = "ModelProperties"   // Displaying properties of a selected 3D model part

    var id: String { self.rawValue }
}

/// Represents the various contexts or intents detected by the AI assistant.
/// These contexts act as triggers, driving the dynamic management of spaces and volumes.
/// In a real application, these would come from Vision framework analysis (gaze, gesture),
/// Natural Language Processing (voice commands), or other sensor data.
enum SpatialAIContext {
    case initialLaunch
    case userFocusOnDetail(modelPartId: String) // AI detects user intently viewing a specific model part
    case userRequestsOverview
    case userWantsCollaboration
    case aiSuggestsAnnotation(location: SIMD3<Float>, message: String) // AI suggests placing an annotation
    case userCommand(command: String) // Placeholder for processing explicit voice/gesture commands
}

/// Errors that can occur during spatial environment management.
/// Provides specific, localized descriptions for better debugging and user feedback.
enum SpatialManagerError: Error, LocalizedError {
    case coordinatorNotInitialized
    case spaceAlreadyOpen(spaceType: ImmersiveSpaceType)
    case spaceNotOpen(spaceType: ImmersiveSpaceType)
    case windowAlreadyOpen(windowType: AppWindowType)
    case windowNotOpen(windowType: AppWindowType)
    case failedToOpenSpace(spaceType: ImmersiveSpaceType, underlyingError: Error?)
    case failedToDismissSpace(spaceType: ImmersiveSpaceType, underlyingError: Error?)
    case failedToOpenWindow(windowType: AppWindowType, underlyingError: Error?)
    case failedToDismissWindow(windowType: AppWindowType, underlyingError: Error?)

    var errorDescription: String? {
        switch self {
        case .coordinatorNotInitialized: return "SpatialReviewCoordinator environment actions not set up."
        case .spaceAlreadyOpen(let type): return "Immersive space '\(type.rawValue)' is already open."
        case .spaceNotOpen(let type): return "Immersive space '\(type.rawValue)' is not currently open."
        case .windowAlreadyOpen(let type): return "Window '\(type.rawValue)' is already open."
        case .windowNotOpen(let type): return "Window '\(type.rawValue)' is not currently open."
        case .failedToOpenSpace(let type, let error): return "Failed to open immersive space '\(type.rawValue)'. Error: \(error?.localizedDescription ?? "Unknown")."
        case .failedToDismissSpace(let type, let error): return "Failed to dismiss immersive space '\(type.rawValue)'. Error: \(error?.localizedDescription ?? "Unknown")."
        case .failedToOpenWindow(let type, let error): return "Failed to open window '\(type.rawValue)'. Error: \(error?.localizedDescription ?? "Unknown")."
        case .failedToDismissWindow(let type, let error): return "Failed to dismiss window '\(type.rawValue)'. Error: \(error?.localizedDescription ?? "Unknown")."
        }
    }
}

/// `SpatialReviewCoordinator` is a singleton-like class responsible for orchestrating
/// the opening, closing, and management of various immersive spaces and windows
/// within the Spatial Design Review application. It acts as the central hub for
/// dynamic spatial environment changes, often driven by AI insights or user actions.
@available(visionOS 1.0, *)
class SpatialReviewCoordinator: ObservableObject {
    // MARK: - Environment Actions
    // These closures are injected from the SwiftUI environment and allow the coordinator
    // to programmatically control windows and immersive spaces. This pattern decouples
    // the coordinator from SwiftUI's @Environment property wrappers, making it more
    // modular and testable.
    private var openWindow: OpenWindowAction?
    private var dismissWindow: DismissWindowAction?
    private var openImmersiveSpace: OpenImmersiveSpaceAction?
    private var dismissImmersiveSpace: DismissImmersiveSpaceAction?

    /// Sets up the environment actions from SwiftUI. This method must be called from a View
    /// that has access to the `@Environment` variables.
    /// - Parameters:
    ///   - openWindow: The action to open a new window.
    ///   - dismissWindow: The action to dismiss an existing window.
    ///   - openImmersiveSpace: The action to open a new immersive space.
    ///   - dismissImmersiveSpace: The action to dismiss an existing immersive space.
    func setup(openWindow: OpenWindowAction, dismissWindow: DismissWindowAction,
               openImmersiveSpace: OpenImmersiveSpaceAction, dismissImmersiveSpace: DismissImmersiveSpaceAction) {
        self.openWindow = openWindow
        self.dismissWindow = dismissWindow
        self.openImmersiveSpace = openImmersiveSpace
        self.dismissImmersiveSpace = dismissImmersiveSpace
    }

    // MARK: - State Management
    /// `@Published` properties to track the currently active immersive spaces and windows.
    /// These allow SwiftUI views to react to changes in the spatial environment.
    @Published private(set) var activeImmersiveSpaces: Set<ImmersiveSpaceType> = []
    @Published private(set) var activeWindows: Set<AppWindowType> = []

    // MARK: - Core Logic: AI-Driven Spatial Context Changes

    /// Responds to AI-detected contexts or explicit user commands to dynamically
    /// adjust the application's spatial environment. This is the central control point
    /// for managing immersive spaces and windows based on application state and user intent.
    /// - Parameter context: The `SpatialAIContext` describing the current situation or request.
    /// - Throws: `SpatialManagerError` if an operation fails (e.g., a space cannot be opened).
    func requestSpatialContextChange(context: SpatialAIContext) async throws {
        // Ensure all environment actions are initialized before proceeding.
        guard let openImmersiveSpace = self.openImmersiveSpace,
              let dismissImmersiveSpace = self.dismissImmersiveSpace,
              let openWindow = self.openWindow,
              let dismissWindow = self.dismissWindow else {
            throw SpatialManagerError.coordinatorNotInitialized
        }

        switch context {
        case .initialLaunch:
            // On initial app launch, establish the default spatial environment.
            print("AI Context: Initial Launch detected. Opening default spaces.")
            try await openSpace(type: .mixedReviewSpace, openImmersiveSpace: openImmersiveSpace)
            try await openAppWindow(type: .mainControls, openWindow: openWindow)

        case .userFocusOnDetail(let modelPartId):
            // AI detects the user intently focusing on a specific part of the 3D model.
            // Transition to a full immersive space for detailed inspection.
            print("AI Context: User focus on detail '\(modelPartId)' detected. Transitioning to full immersion.")
            // Dismiss any existing immersive spaces to ensure a clean transition and avoid conflicts.
            try await dismissAllImmersiveSpaces(dismissImmersiveSpace: dismissImmersiveSpace)
            // Open the highly immersive detail space, potentially passing the focused model part ID.
            try await openSpace(type: .fullDetailSpace, openImmersiveSpace: openImmersiveSpace, value: modelPartId)
            // Open a contextual volume to display properties relevant to the focused model part.
            try await openAppWindow(type: .modelProperties, openWindow: openWindow, value: modelPartId)
            // Dismiss other non-essential windows, like main controls, if they would obscure the detailed view.
            try await dismissAppWindow(type: .mainControls, dismissWindow: dismissWindow)

        case .userRequestsOverview:
            // User explicitly requests a broader overview or a less intense view of the model.
            print("AI Context: User requests overview. Returning to mixed reality.")
            try await dismissAllImmersiveSpaces(dismissImmersiveSpace: dismissImmersiveSpace)
            try await openSpace(type: .mixedReviewSpace, openImmersiveSpace: openImmersiveSpace)
            // Ensure main controls are visible again for general navigation.
            try await openAppWindow(type: .mainControls, openWindow: openWindow)
            // Dismiss detail-specific windows that are no longer relevant in an overview.
            try await dismissAppWindow(type: .modelProperties, dismissWindow: dismissWindow)
            try await dismissAppWindow(type: .aiFeedbackVolume, dismissWindow: dismissWindow)

        case .userWantsCollaboration:
            // User initiates a collaborative session, prompting a shift to a shared workspace.
            print("AI Context: User wants collaboration. Opening collaborative whiteboard.")
            try await dismissAllImmersiveSpaces(dismissImmersiveSpace: dismissImmersiveSpace)
            try await openSpace(type: .collaborativeWhiteboard, openImmersiveSpace: openImmersiveSpace)
            // Keep main controls visible or open collaboration-specific tools.
            try await openAppWindow(type: .mainControls, openWindow: openWindow)

        case .aiSuggestsAnnotation(let location, let message):
            // AI suggests placing an annotation in the current spatial context.
            // This might trigger a temporary volume or an in-world RealityKit entity.
            print("AI Context: AI suggests annotation at \(location): \(message)")
            // For this example, we'll open a feedback volume. In a full app,
            // this could involve RealityKit to place a 3D annotation at `location`.
            try await openAppWindow(type: .aiFeedbackVolume, openWindow: openWindow, value: message)
            // The `location` could be used to strategically position the volume or a RealityKit entity.

        case .userCommand(let command):
            // Handle various user voice/gesture commands, interpreted by the AI.
            print("AI Context: User command received: '\(command)'")
            // This block demonstrates how specific commands can map to spatial actions.
            if command.lowercased().contains("hide controls") {
                try await dismissAppWindow(type: .mainControls, dismissWindow: dismissWindow)
            } else if command.lowercased().contains("show feedback") {
                try await openAppWindow(type: .aiFeedbackVolume, openWindow: openWindow, value: "AI Feedback: Command Processed.")
            } else if command.lowercased().contains("show overview") {
                try await requestSpatialContextChange(context: .userRequestsOverview)
            }
        }
    }

    // MARK: - Helper Methods for Space and Window Management

    /// Attempts to open a specific immersive space.
    /// Utilizes `openImmersiveSpace` from the environment and updates internal state.
    /// - Parameters:
    ///   - type: The `ImmersiveSpaceType` to open.
    ///   - openImmersiveSpace: The environment action to open an immersive space.
    ///   - value: An optional `Hashable & Sendable` value to pass to the immersive space.
    /// - Throws: `SpatialManagerError` if the space is already open or fails to open.
    private func openSpace(type: ImmersiveSpaceType, openImmersiveSpace: OpenImmersiveSpaceAction, value: (some Hashable & Sendable)? = nil) async throws {
        guard !activeImmersiveSpaces.contains(type) else {
            print("Warning: Attempted to open already active immersive space: \(type.rawValue)")
            throw SpatialManagerError.spaceAlreadyOpen(spaceType: type)
        }
        print("Attempting to open immersive space: \(type.rawValue) with style \(type.immersionStyle)")
        do {
            let result = await openImmersiveSpace(id: type.rawValue, value: value)
            if result == .opened {
                // Update UI-related state on the MainActor.
                await MainActor.run {
                    activeImmersiveSpaces.insert(type)
                    print("Successfully opened immersive space: \(type.rawValue)")
                }
            } else {
                // If the system returns .unsupported or .error, treat it as a failure.
                throw SpatialManagerError.failedToOpenSpace(spaceType: type, underlyingError: nil)
            }
        } catch {
            print("Error opening immersive space \(type.rawValue): \(error.localizedDescription)")
            throw SpatialManagerError.failedToOpenSpace(spaceType: type, underlyingError: error)
        }
    }

    /// Attempts to dismiss a specific immersive space.
    /// Utilizes `dismissImmersiveSpace` from the environment and updates internal state.
    /// - Parameters:
    ///   - type: The `ImmersiveSpaceType` to dismiss.
    ///   - dismissImmersiveSpace: The environment action to dismiss an immersive space.
    /// - Throws: `SpatialManagerError` if the space is not open or fails to dismiss.
    private func dismissSpace(type: ImmersiveSpaceType, dismissImmersiveSpace: DismissImmersiveSpaceAction) async throws {
        guard activeImmersiveSpaces.contains(type) else {
            print("Warning: Attempted to dismiss inactive immersive space: \(type.rawValue)")
            throw SpatialManagerError.spaceNotOpen(spaceType: type)
        }
        print("Attempting to dismiss immersive space: \(type.rawValue)")
        do {
            let result = await dismissImmersiveSpace(id: type.rawValue)
            if result == .dismissed {
                // Update UI-related state on the MainActor.
                await MainActor.run {
                    activeImmersiveSpaces.remove(type)
                    print("Successfully dismissed immersive space: \(type.rawValue)")
                }
            } else {
                // If the system returns .error, treat it as a failure.
                throw SpatialManagerError.failedToDismissSpace(spaceType: type, underlyingError: nil)
            }
        } catch {
            print("Error dismissing immersive space \(type.rawValue): \(error.localizedDescription)")
            throw SpatialManagerError.failedToDismissSpace(spaceType: type, underlyingError: error)
        }
    }

    /// Iterates through and dismisses all currently active immersive spaces.
    /// - Parameter dismissImmersiveSpace: The environment action to dismiss immersive spaces.
    private func dismissAllImmersiveSpaces(dismissImmersiveSpace: DismissImmersiveSpaceAction) async throws {
        // Create a copy to iterate, as the set will be modified during dismissal.
        for spaceType in activeImmersiveSpaces {
            try await dismissSpace(type: spaceType, dismissImmersiveSpace: dismissImmersiveSpace)
        }
    }

    /// Attempts to open a specific application window (volume).
    /// Utilizes `openWindow` from the environment and updates internal state.
    /// - Parameters:
    ///   - type: The `AppWindowType` to open.
    ///   - openWindow: The environment action to open a window.
    ///   - value: An optional `Hashable & Sendable` value to pass to the window.
    /// - Throws: `SpatialManagerError` if the window is already open or fails to open.
    private func openAppWindow(type: AppWindowType, openWindow: OpenWindowAction, value: (some Hashable & Sendable)? = nil) async throws {
        guard !activeWindows.contains(type) else {
            print("Warning: Attempted to open already active window: \(type.rawValue)")
            throw SpatialManagerError.windowAlreadyOpen(windowType: type)
        }
        print("Attempting to open window: \(type.rawValue)")
        // `openWindow` is synchronous and doesn't return a success/failure status directly.
        // We assume success unless an error is thrown internally (less common for `openWindow`).
        do {
            openWindow(id: type.rawValue, value: value)
            await MainActor.run {
                activeWindows.insert(type)
                print("Successfully requested window open: \(type.rawValue)")
            }
        } catch {
            print("Error opening window \(type.rawValue): \(error.localizedDescription)")
            throw SpatialManagerError.failedToOpenWindow(windowType: type, underlyingError: error)
        }
    }

    /// Attempts to dismiss a specific application window (volume).
    /// Utilizes `dismissWindow` from the environment and updates internal state.
    /// - Parameters:
    ///   - type: The `AppWindowType` to dismiss.
    ///   - dismissWindow: The environment action to dismiss a window.
    /// - Throws: `SpatialManagerError` if the window is not open or fails to dismiss.
    private func dismissAppWindow(type: AppWindowType, dismissWindow: DismissWindowAction) async throws {
        guard activeWindows.contains(type) else {
            print("Warning: Attempted to dismiss inactive window: \(type.rawValue)")
            throw SpatialManagerError.windowNotOpen(windowType: type)
        }
        print("Attempting to dismiss window: \(type.rawValue)")
        // `dismissWindow` is synchronous and doesn't return a success/failure status directly.
        do {
            dismissWindow(id: type.rawValue)
            await MainActor.run {
                activeWindows.remove(type)
                print("Successfully requested window dismiss: \(type.rawValue)")
            }
        } catch {
            print("Error dismissing window \(type.rawValue): \(error.localizedDescription)")
            throw SpatialManagerError.failedToDismissWindow(windowType: type, underlyingError: error)
        }
    }

    /// Iterates through and dismisses all currently active application windows.
    /// - Parameter dismissWindow: The environment action to dismiss windows.
    private func dismissAllWindows(dismissWindow: DismissWindowAction) async throws {
        // Create a copy to iterate, as the set will be modified during dismissal.
        for windowType in activeWindows {
            try await dismissAppWindow(type: windowType, dismissWindow: dismissWindow)
        }
    }

    /// Dismisses all active spaces and windows managed by the coordinator.
    /// This provides a clean slate for the application's spatial environment.
    func dismissAllActiveSpatialElements() async throws {
        guard let dismissImmersiveSpace = self.dismissImmersiveSpace,
              let dismissWindow = self.dismissWindow else {
            throw SpatialManagerError.coordinatorNotInitialized
        }
        print("Dismissing all active spatial elements...")
        try await dismissAllImmersiveSpaces(dismissImmersiveSpace: dismissImmersiveSpace)
        try await dismissAllWindows(dismissWindow: dismissWindow)
        print("All active spatial elements dismissed.")
    }
}

// MARK: - Conceptual SwiftUI App Structure (for context)

/// This is a conceptual representation of how the `SpatialReviewCoordinator`
/// would be integrated into a SwiftUI `App` structure for visionOS.
/// It shows how different spaces and windows are declared and how the coordinator
/// receives the necessary environment actions.
@available(visionOS 1.0, *)
struct SpatialDesignReviewApp: App {
    // The coordinator is a `@StateObject` to ensure its lifecycle is managed by the App
    // and it persists across view updates.
    @StateObject private var coordinator = SpatialReviewCoordinator()

    // Environment actions are injected into the App's body to be passed to the coordinator.
    @Environment(\.openWindow) private var openWindow
    @Environment(\.dismissWindow) private var dismissWindow
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace

    var body: some Scene {
        // MARK: - Main Window Group
        // This is the default window that appears when the app launches.
        // It's crucial for initializing the coordinator and providing a basic UI.
        WindowGroup(id: AppWindowType.mainControls.rawValue) {
            ContentView()
                .environmentObject(coordinator) // Make coordinator available to child views
                .onAppear {
                    // Initialize the coordinator with the environment actions.
                    coordinator.setup(openWindow: openWindow, dismissWindow: dismissWindow,
                                      openImmersiveSpace: openImmersiveSpace, dismissImmersiveSpace: dismissImmersiveSpace)
                    // Simulate the initial AI context on app launch to set up the default environment.
                    Task {
                        do {
                            try await coordinator.requestSpatialContextChange(context: .initialLaunch)
                        } catch {
                            print("Error during initial launch context change: \(error.localizedDescription)")
                        }
                    }
                }
        }
        .windowStyle(.volumetric) // Example: a 3D volume for controls, allowing placement in space

        // MARK: - AI Feedback Volume
        // A dedicated window group for displaying AI-generated feedback or data.
        WindowGroup(id: AppWindowType.aiFeedbackVolume.rawValue, for: String.self) { message in
            AIFeedbackView(message: message.wrappedValue ?? "No AI Feedback")
                .environmentObject(coordinator)
        }
        .windowStyle(.volumetric) // AI feedback could be a small floating volume

        // MARK: - Model Properties Volume
        // A window group to display detailed properties of a selected 3D model part.
        WindowGroup(id: AppWindowType.modelProperties.rawValue, for: String.self) { modelPartId in
            ModelPropertiesView(modelPartId: modelPartId.wrappedValue ?? "Unknown Part")
                .environmentObject(coordinator)
        }
        .windowStyle(.volumetric)

        // MARK: - Immersive Spaces
        // Declaration of different immersive spaces the app can transition into.
        // Each space corresponds to an `ImmersiveSpaceType` and defines its unique content.

        // Mixed Reality Review Space: For general model inspection with passthrough.
        ImmersiveSpace(id: ImmersiveSpaceType.mixedReviewSpace.rawValue) {
            MixedReviewSpaceView()
                .environmentObject(coordinator)
        }
        // The immersionStyle must match the style defined in the ImmersiveSpaceType enum
        // and be explicitly set here for the system to understand its behavior.
        .immersionStyle(selection: .constant(.mixed), in: .mixed)

        // Full Immersion Detail Space: For focused, high-fidelity inspection of details, blocking passthrough.
        ImmersiveSpace(id: ImmersiveSpaceType.fullDetailSpace.rawValue) {
            FullDetailSpaceView()
                .environmentObject(coordinator)
        }
        .immersionStyle(selection: .constant(.full), in: .full)

        // Collaborative Whiteboard Space: A shared space for drawing, notes, etc., typically mixed.
        ImmersiveSpace(id: ImmersiveSpaceType.collaborativeWhiteboard.rawValue) {
            CollaborativeWhiteboardView()
                .environmentObject(coordinator)
        }
        .immersionStyle(selection: .constant(.mixed), in: .mixed)
    }
}

// MARK: - Conceptual Views (for context)

/// A placeholder for the main content view, demonstrating how to trigger AI contexts
/// via simulated user actions (buttons). In a real app, these would come from
/// actual AI detection or complex user interactions.
@available(visionOS 1.0, *)
struct ContentView: View {
    @EnvironmentObject var coordinator: SpatialReviewCoordinator

    var body: some View {
        VStack {
            Text("Spatial Design Review Controls")
                .font(.largeTitle)
                .padding()

            // Display current active spaces and windows for debugging/feedback.
            Text("Active Immersive Spaces: \(coordinator.activeImmersiveSpaces.map { $0.rawValue }.joined(separator: ", "))")
                .font(.caption)
            Text("Active Windows: \(coordinator.activeWindows.map { $0.rawValue }.joined(separator: ", "))")
                .font(.caption)

            Spacer()

            Button("Simulate AI: Focus on Structural Beam") {
                Task {
                    do {
                        try await coordinator.requestSpatialContextChange(context: .userFocusOnDetail(modelPartId: "StructuralBeam-001"))
                    } catch {
                        print("Failed to simulate AI focus: \(error.localizedDescription)")
                    }
                }
            }
            .padding()
            .buttonStyle(.borderedProminent)

            Button("Simulate AI: User Requests Overview") {
                Task {
                    do {
                        try await coordinator.requestSpatialContextChange(context: .userRequestsOverview)
                    } catch {
                        print("Failed to simulate AI overview request: \(error.localizedDescription)")
                    }
                }
            }
            .padding()
            .buttonStyle(.bordered)

            Button("Simulate AI: User Wants Collaboration") {
                Task {
                    do {
                        try await coordinator.requestSpatialContextChange(context: .userWantsCollaboration)
                    } catch {
                        print("Failed to simulate AI collaboration request: \(error.localizedDescription)")
                    }
                }
            }
            .padding()
            .buttonStyle(.bordered)

            Button("Simulate AI: Suggest Annotation (AI Feedback)") {
                Task {
                    do {
                        try await coordinator.requestSpatialContextChange(context: .aiSuggestsAnnotation(location: [1, 0, -2], message: "Potential stress point detected here."))
                    } catch {
                        print("Failed to simulate AI annotation suggestion: \(error.localizedDescription)")
                    }
                }
            }
            .padding()
            .buttonStyle(.bordered)

            Button("Simulate AI: Voice Command 'Hide Controls'") {
                Task {
                    do {
                        try await coordinator.requestSpatialContextChange(context: .userCommand(command: "Hide Controls"))
                    } catch {
                        print("Failed to simulate AI command: \(error.localizedDescription)")
                    }
                }
            }
            .padding()
            .buttonStyle(.bordered)

            Spacer()

            Button("Dismiss All Spatial Elements") {
                Task {
                    do {
                        try await coordinator.dismissAllActiveSpatialElements()
                    } catch {
                        print("Failed to dismiss all spatial elements: \(error.localizedDescription)")
                    }
                }
            }
            .padding()
            .buttonStyle(.borderedProminent)
            .tint(.red)
        }
        .frame(width: 450, height: 700) // Example frame for a volumetric window
        .glassBackgroundEffect()
    }
}

/// A placeholder view for the Mixed Reality Review Space.
/// In a real application, this would load and display 3D models using RealityKit.
@available(visionOS 1.0, *)
struct MixedReviewSpaceView: View {
    var body: some View {
        RealityView { content in
            // Load and display a general 3D model for review.
            // Replace "ArchitecturalModel" with your actual Reality Composer Pro asset.
            if let entity = try? await Entity(named: "ArchitecturalModel", in: realityKitContentBundle) {
                content.add(entity)
            } else {
                let textEntity = ModelEntity(mesh: .generateText("Mixed Review Space", extrusionDepth: 0.05), materials: [SimpleMaterial(color: .white)])
                textEntity.position = [-1, 1.5, -2]
                content.add(textEntity)
            }
        }
        .onAppear { print("MixedReviewSpaceView appeared") }
        .onDisappear { print("MixedReviewSpaceView disappeared") }
    }
}

/// A placeholder view for the Full Immersion Detail Space.
/// This space would display high-fidelity models or specific components for close inspection.
@available(visionOS 1.0, *)
struct FullDetailSpaceView: View {
    var body: some View {
        RealityView { content in
            // Load a highly detailed 3D model or a specific part of it.
            // Potentially add ARKit/RealityKit elements for stress visualization, material properties, etc.
            if let entity = try? await Entity(named: "StructuralBeamDetail", in: realityKitContentBundle) {
                content.add(entity)
            } else {
                let textEntity = ModelEntity(mesh: .generateText("Full Detail Space (Structural Beam)", extrusionDepth: 0.05), materials: [SimpleMaterial(color: .white)])
                textEntity.position = [-1.5, 1.5, -2]
                content.add(textEntity)
            }
        }
        .onAppear { print("FullDetailSpaceView appeared") }
        .onDisappear { print("FullDetailSpaceView disappeared") }
    }
}

/// A placeholder view for a Collaborative Whiteboard Space.
/// This would be an environment where multiple users can interact, draw, and share ideas.
@available(visionOS 1.0, *)
struct CollaborativeWhiteboardView: View {
    var body: some View {
        ZStack {
            // A shared 2D/3D whiteboard environment.
            Text("Collaborative Whiteboard Active")
                .font(.extraLargeTitle)
                .padding()
            // Integrate drawing tools, shared cursors, sticky notes, etc.
        }
        .onAppear { print("CollaborativeWhiteboardView appeared") }
        .onDisappear { print("CollaborativeWhiteboardView disappeared") }
    }
}

/// A view for displaying AI-generated feedback messages in a volumetric window.
@available(visionOS 1.0, *)
struct AIFeedbackView: View {
    let message: String
    var body: some View {
        Text("AI Feedback: \(message)")
            .font(.title2)
            .padding()
            .frame(width: 300, height: 150)
            .background(.ultraThinMaterial)
            .cornerRadius(20)
            .onAppear { print("AIFeedbackView appeared with message: \(message)") }
            .onDisappear { print("AIFeedbackView disappeared") }
    }
}

/// A view for displaying detailed properties of a selected 3D model part in a volumetric window.
@available(visionOS 1.0, *)
struct ModelPropertiesView: View {
    let modelPartId: String
    var body: some View {
        VStack(alignment: .leading) {
            Text("Properties for: \(modelPartId)")
                .font(.title2)
                .padding(.bottom, 5)
            Divider()
            Text("Material: Steel Alloy (Grade A)")
            Text("Stress Tolerance: 500 MPa")
            Text("Last Inspection: 2023-10-26 (Passed)")
            Text("Manufacturer: Acme Structures Inc.")
            // More detailed properties could be loaded dynamically.
        }
        .padding()
        .frame(width: 350, height: 200)
        .background(.regularMaterial)
        .cornerRadius(20)
        .onAppear { print("ModelPropertiesView appeared for: \(modelPartId)") }
        .onDisappear { print("ModelPropertiesView disappeared for: \(modelPartId)") }
    }
}

// MARK: - RealityKit Content Bundle Placeholder
// In a real visionOS project, this bundle would be generated by Xcode
// for Reality Composer Pro assets. For this conceptual example, it's a placeholder.
// You would typically use `Bundle.module` for Swift Packages or `Bundle.main`
// if assets are directly in the main app target.
let realityKitContentBundle: Bundle? = nil // Or Bundle.main
