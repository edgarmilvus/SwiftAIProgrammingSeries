
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import RealityKit
import Observation

// MARK: - 1. Domain Model (Single Source of Truth)
@Observable
@MainActor
final class LampModel {
    var color: Color = .yellow
    var intensity: Float = 1.0
    var isSwitchedOn: Bool = true
}

// MARK: - 2. RealityKit Component
struct LampComponent: Component {
    var color: UIColor
    var intensity: Float
    var isOn: Bool
}

// MARK: - 3. Synchronization Engine (The Bridge)
@MainActor
final class SceneCoordinator {
    private var lampEntity: Entity?
    private var model: LampModel
    
    init(model: LampModel) {
        self.model = model
    }
    
    func setup(entity: Entity) {
        self.lampEntity = entity
        updateEntity() // Initial sync
    }
    
    /// This method is called whenever the model changes.
    /// It translates declarative state into imperative RealityKit commands.
    func updateEntity() {
        guard let entity = lampEntity else { return }
        
        // 1. Update the Component (for ECS logic)
        let newComponent = LampComponent(
            color: UIColor(model.color),
            intensity: model.intensity,
            isOn: model.isSwitchedOn
        )
        entity.components.set(newComponent)
        
        // 2. Update the Visuals (Material/Light)
        if let modelEntity = entity as? ModelEntity {
            var material = UnlitMaterial(color: model.color.uiColor)
            modelEntity.model?.materials = [material]
        }
        
        if let lightEntity = entity.findEntity(named: "LampLight") as? PointLight {
            lightEntity.light.intensity = model.intensity * 1000
            lightEntity.isEnabled = model.isSwitchedOn
        }
    }
}

// Helper to convert SwiftUI Color to UIColor
extension Color {
    var uiColor: UIColor {
        UIColor(self)
    }
}

// MARK: - 4. View Implementation
struct SmartHomeView: View {
    @State private var lampModel = LampModel()
    @State private var coordinator: SceneCoordinator?
    
    var body: some View {
        NavigationSplitView {
            // 2D Control Sidebar
            VStack(spacing: 20) {
                Toggle("Power", isOn: $lampModel.isSwitchedOn)
                
                Slider(value: $lampModel.intensity, in: 0...2)
                    .padding()
                
                ColorPicker("Lamp Color", selection: $lampModel.color)
            }
            .padding()
            .onChange(of: lampModel.color) { coordinator?.updateEntity() }
            .onChange(of: lampModel.intensity) { coordinator?.updateEntity() }
            .onChange(of: lampModel.isSwitchedOn) { coordinator?.updateEntity() }
            
        } detail: {
            // 3D RealityView
            RealityView { content in
                let lamp = ModelEntity(mesh: .generateSphere(radius: 0.1))
                lamp.name = "Lamp"
                
                let light = PointLight()
                light.name = "LampLight"
                let lightEntity = Entity()
                lightEntity.name = "LampLight"
                lightEntity.addChild(light)
                lamp.addChild(lightEntity)
                
                content.add(lamp)
                
                // Initialize Coordinator
                let coord = SceneCoordinator(model: lampModel)
                coord.setup(entity: lamp)
                self.coordinator = coord
            }
        }
    }
}
