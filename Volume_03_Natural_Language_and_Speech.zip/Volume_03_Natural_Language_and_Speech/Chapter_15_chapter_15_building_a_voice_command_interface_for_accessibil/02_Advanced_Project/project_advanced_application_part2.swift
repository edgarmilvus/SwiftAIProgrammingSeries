
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import NaturalLanguage // For NL concepts, though not directly used in SmartHomeAction itself.

// MARK: - 1. Define Smart Home Actions and Manager

/// Represents the various rooms in a smart home.
enum SmartHomeRoom: String, CaseIterable, Codable {
    case livingRoom = "Living Room"
    case kitchen = "Kitchen"
    case bedroom = "Bedroom"
    case masterBedroom = "Master Bedroom"
    case hallway = "Hallway"
    case all = "All" // For commands like "turn off all lights"

    /// Provides a user-friendly description.
    var description: String {
        return self.rawValue
    }
}

/// Represents the types of devices that can be controlled.
enum SmartHomeDeviceType: String, CaseIterable, Codable {
    case light = "Light"
    case thermostat = "Thermostat"
    case blinds = "Blinds"
    case speaker = "Speaker"
    case fan = "Fan"
    // Add more device types as needed
}

/// Defines a specific action that can be performed in the smart home.
enum SmartHomeAction: CustomStringConvertible, Equatable {
    case setLight(room: SmartHomeRoom, on: Bool)
    case setLightBrightness(room: SmartHomeRoom, brightness: Double) // 0.0 to 1.0
    case setThermostat(room: SmartHomeRoom, temperature: Double)
    case setBlinds(room: SmartHomeRoom, position: Double) // 0.0 (closed) to 1.0 (open)
    case queryTemperature(room: SmartHomeRoom)
    case unknown(command: String)

    /// A human-readable description of the action.
    var description: String {
        switch self {
        case .setLight(let room, let on):
            return "Set \(room.description) lights \(on ? "on" : "off")."
        case .setLightBrightness(let room, let brightness):
            return "Set \(room.description) lights to \(Int(brightness * 100))% brightness."
        case .setThermostat(let room, let temperature):
            return "Set \(room.description) thermostat to \(temperature)°C."
        case .setBlinds(let room, let position):
            return "Set \(room.description) blinds to \(Int(position * 100))% open."
        case .queryTemperature(let room):
            return "Query temperature in \(room.description)."
        case .unknown(let command):
            return "Unknown command: '\(command)'."
        }
    }
}

/// Protocol defining the interface for interacting with smart home devices.
/// This allows for mocking or using different device integrations.
protocol SmartHomeManaging: Actor {
    func execute(action: SmartHomeAction) async throws -> String
}

/// A mock implementation of `SmartHomeManaging` for demonstration purposes.
/// In a real app, this would interact with actual smart home APIs (e.g., HomeKit, custom server).
@available(iOS 18.0, *)
actor MockSmartHomeManager: SmartHomeManaging {
    private var deviceStates: [SmartHomeRoom: [SmartHomeDeviceType: Any]] = [
        .livingRoom: [.light: false, .thermostat: 20.0, .blinds: 0.0],
        .kitchen: [.light: false, .blinds: 0.0],
        .bedroom: [.light: false],
        .masterBedroom: [.thermostat: 21.0]
    ]

    /// Executes a given smart home action.
    /// - Parameter action: The `SmartHomeAction` to execute.
    /// - Returns: A string confirming the action or providing query results.
    /// - Throws: `SmartHomeError` if the action cannot be performed.
    func execute(action: SmartHomeAction) async throws -> String {
        // Simulate network delay or device interaction
        try await Task.sleep(for: .milliseconds(500))

        switch action {
        case .setLight(let room, let on):
            if var roomState = deviceStates[room] {
                roomState[.light] = on
                deviceStates[room] = roomState
                return "Successfully turned \(room.description) lights \(on ? "on" : "off")."
            } else {
                throw SmartHomeError.deviceNotFound(room: room, type: .light)
            }
        case .setLightBrightness(let room, let brightness):
            if var roomState = deviceStates[room], roomState[.light] != nil {
                // Assume setting brightness also implies turning on if off
                roomState[.light] = true
                deviceStates[room] = roomState
                return "Successfully set \(room.description) lights brightness to \(Int(brightness * 100))%."
            } else {
                throw SmartHomeError.deviceNotFound(room: room, type: .light)
            }
        case .setThermostat(let room, let temperature):
            if var roomState = deviceStates[room], roomState[.thermostat] != nil {
                roomState[.thermostat] = temperature
                deviceStates[room] = roomState
                return "Successfully set \(room.description) thermostat to \(temperature)°C."
            } else {
                throw SmartHomeError.deviceNotFound(room: room, type: .thermostat)
            }
        case .setBlinds(let room, let position):
            if var roomState = deviceStates[room], roomState[.blinds] != nil {
                roomState[.blinds] = position
                deviceStates[room] = roomState
                return "Successfully set \(room.description) blinds to \(Int(position * 100))% open."
            } else {
                throw SmartHomeError.deviceNotFound(room: room, type: .blinds)
            }
        case .queryTemperature(let room):
            if let roomState = deviceStates[room], let temp = roomState[.thermostat] as? Double {
                return "The temperature in the \(room.description) is \(temp)°C."
            } else {
                throw SmartHomeError.deviceNotFound(room: room, type: .thermostat)
            }
        case .unknown(let command):
            return "Could not understand command: '\(command)'."
        }
    }
}

/// Custom error types for the Smart Home system.
enum SmartHomeError: Error, LocalizedError {
    case deviceNotFound(room: SmartHomeRoom, type: SmartHomeDeviceType)
    case invalidCommand(String)
    case parsingError(String)

    var errorDescription: String? {
        switch self {
        case .deviceNotFound(let room, let type):
            return "Error: \(type.rawValue) not found in \(room.rawValue)."
        case .invalidCommand(let command):
            return "Error: Invalid command received: \(command)."
        case .parsingError(let message):
            return "Error parsing command: \(message)."
        }
    }
}
