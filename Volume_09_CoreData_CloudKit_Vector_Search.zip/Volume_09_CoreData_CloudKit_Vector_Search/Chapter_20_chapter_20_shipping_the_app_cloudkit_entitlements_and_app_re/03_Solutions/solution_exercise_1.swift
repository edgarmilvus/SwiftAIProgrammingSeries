
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import CoreData
import CloudKit

@available(iOS 18.0, *)
actor CloudKitManager {
    /// The specific CloudKit container identifier defined in the Apple Developer Portal.
    /// Using a constant prevents "stringly-typed" errors and ensures environment consistency.
    private let containerIdentifier = "iCloud.com.lexisearch.knowledgebase"
    
    private let modelName = "LexiSearchModel"
    
    /// The persistent container instance.
    private(set) var persistentContainer: NSPersistentCloudKitContainer?

    /// Initializes and configures the CloudKit-enabled persistent container.
    func setupContainer() async throws {
        let container = NSPersistentCloudKitContainer(name: modelName)
        
        // 1. Access the persistent store descriptions
        guard let description = container.persistentStoreDescriptions.first else {
            throw CloudKitError.missingStoreDescription
        }
        
        // 2. Configure CloudKit Container Options
        // We explicitly provide the identifier to avoid falling back to the default App ID container.
        let cloudKitOptions = NSPersistentCloudKitContainerOptions(containerIdentifier: containerIdentifier)
        description.cloudKitContainerOptions = cloudKitOptions
        
        // 3. Ensure we are targeting the Private Database
        // NSPersistentCloudKitContainer handles the mapping to the private database by default
        // when using the standard configuration, but we ensure the description is set.
        description.setOption(true as NSNumber, forKey: NSPersistentHistoryTrackingKey)
        description.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)

        // 4. Load the stores using modern concurrency
        try await container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                // In a real app, log this to a non-sensitive telemetry service
                print("Unresolved error \(error), \(error.userInfo)")
            }
        }
        
        self.persistentContainer = container
        print("Successfully initialized CloudKit container: \(containerIdentifier)")
    }
}

enum CloudKitError: Error {
    case missingStoreDescription
}
