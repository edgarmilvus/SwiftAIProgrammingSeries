
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

// Example of a custom error for the simulated models
enum GeneratorError: Error, LocalizedError {
    case serviceUnavailable
    case invalidPrompt
    case unknown(Error)
    case timeout

    var errorDescription: String? {
        switch self {
        case .serviceUnavailable: return "AI service is currently unavailable."
        case .invalidPrompt: return "The provided prompt is invalid."
        case .unknown(let error): return "An unknown error occurred: \(error.localizedDescription)"
        case .timeout: return "AI service timed out."
        }
    }
}

// Example structure for the aggregated content
struct GeneratedContent: Identifiable, Hashable {
    let id = UUID()
    let prompt: String
    let summary: String
    let keywords: [String]
    let imageDescription: String
}

// 1. Define Specialized AI Model Simulators
// These are non-isolated functions, simulating external services that the actor calls.
// Using @available(iOS 18.0, *) as they are top-level async functions in a script.
@available(iOS 18.0, *)
func simulateSummarizer(prompt: String) async throws -> String {
    print("Summarizer: Starting for '\(prompt.prefix(20))...'")
    try await Task.sleep(for: .seconds(Double.random(in: 1.0...2.5))) // Simulate latency

    if prompt.lowercased().contains("error summary") {
        throw GeneratorError.serviceUnavailable // Simulate specific error
    }
    if Bool.random(in: 0...100) < 5 { // 5% chance of random failure
        throw GeneratorError.timeout
    }

    print("Summarizer: Finished for '\(prompt.prefix(20))...'")
    return "A concise summary of: \(prompt). This is a short, attention-grabbing tweet-like statement."
}

@available(iOS 18.0, *)
func simulateEntityExtractor(prompt: String) async throws -> [String] {
    print("EntityExtractor: Starting for '\(prompt.prefix(20))...'")
    try await Task.sleep(for: .seconds(Double.random(in: 0.8...2.0))) // Simulate latency

    if prompt.lowercased().contains("error entity") {
        throw GeneratorError.invalidPrompt // Simulate specific error
    }
    if Bool.random(in: 0...100) < 5 { // 5% chance of random failure
        throw GeneratorError.serviceUnavailable
    }

    let words = prompt.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }
    let keywords = Array(Set(words.filter { $0.count > 3 }.map { $0.lowercased() })).prefix(3)
    print("EntityExtractor: Finished for '\(prompt.prefix(20))...'")
    return Array(keywords)
}

@available(iOS 18.0, *)
func simulateImageDescriber(prompt: String) async throws -> String {
    print("ImageDescriber: Starting for '\(prompt.prefix(20))...'")
    try await Task.sleep(for: .seconds(Double.random(in: 1.5...3.0))) // Simulate latency

    if prompt.lowercased().contains("error image") {
        throw GeneratorError.timeout // Simulate specific error
    }
    if Bool.random(in: 0...100) < 5 { // 5% chance of random failure
        throw GeneratorError.unknown(URLError(.cannotConnectToHost))
    }

    print("ImageDescriber: Finished for '\(prompt.prefix(20))...'")
    return "An artistic representation of the key themes from: \(prompt), focusing on vibrant colors and dynamic composition."
}

// 2. Define ContentGenerator Actor
@available(iOS 18.0, *)
actor ContentGenerator {
    // No mutable state specific to the generator, it acts as an orchestrator.
    // If it needed to cache results or manage rate limits, it would have private state.

    init() {
        print("ContentGenerator initialized.")
    }

    // 3. Implement generateContent
    func generateContent(for prompt: String) async throws -> GeneratedContent {
        print("\nContentGenerator: Starting multi-modal generation for prompt: '\(prompt)'")

        // Use TaskGroup to execute the AI model simulators concurrently
        return try await withThrowingTaskGroup(of: (String, Any).self) { group in
            group.addTask { ("summary", try await simulateSummarizer(prompt: prompt)) }
            group.addTask { ("keywords", try await simulateEntityExtractor(prompt: prompt)) }
            group.addTask { ("imageDescription", try await simulateImageDescriber(prompt: prompt)) }

            var summary: String?
            var keywords: [String]?
            var imageDescription: String?

            // Collect results from all tasks
            for try await (key, value) in group {
                switch key {
                case "summary":
                    summary = value as? String
                case "keywords":
                    keywords = value as? [String]
                case "imageDescription":
                    imageDescription = value as? String
                default:
                    break
                }
            }

            // Ensure all required components are present
            guard let finalSummary = summary,
                  let finalKeywords = keywords,
                  let finalImageDescription = imageDescription else {
                // This scenario implies a programming error or unexpected type casting failure
                // A more robust solution might handle partial success or specific missing components
                throw GeneratorError.unknown(NSError(domain: "ContentGenerator", code: 1, userInfo: [NSLocalizedDescriptionKey: "Failed to collect all content components."]))
            }

            print("ContentGenerator: All components generated for prompt: '\(prompt)'")
            return GeneratedContent(prompt: prompt, summary: finalSummary, keywords: finalKeywords, imageDescription: finalImageDescription)
        }
    }
}

// 4. Demonstrate Usage and Error Handling
@main
@available(iOS 18.0, *)
struct MultiModalApp {
    static func main() async {
        let generator = ContentGenerator()

        print("\n--- Demonstrating Multi-Modal Content Generation ---")

        // Scenario 1: Successful generation
        Task {
            let prompt1 = "Develop a blog post idea about the benefits of Swift concurrency for app development."
            do {
                let content = try await generator.generateContent(for: prompt1)
                print("\nUI: Successfully generated content for prompt 1 (ID: \(content.id.uuidString.prefix(8))):")
                print("  Summary: \(content.summary)")
                print("  Keywords: \(content.keywords.joined(separator: ", "))")
                print("  Image Description: \(content.imageDescription)")
            } catch {
                print("\nUI: Error generating content for prompt 1: \(error.localizedDescription)")
            }
        }

        // Scenario 2: Generation with a simulated error in summarizer
        Task {
            try await Task.sleep(for: .milliseconds(200)) // Slight delay to interleave
            let prompt2 = "Create content about error summary handling in Swift concurrency."
            do {
                let content = try await generator.generateContent(for: prompt2)
                print("\nUI: Successfully generated content for prompt 2 (ID: \(content.id.uuidString.prefix(8))):")
                print("  Summary: \(content.summary)")
                print("  Keywords: \(content.keywords.joined(separator: ", "))")
                print("  Image Description: \(content.imageDescription)")
            } catch {
                print("\nUI: Error generating content for prompt 2: \(error.localizedDescription)")
            }
        }

        // Scenario 3: Another successful generation
        Task {
            try await Task.sleep(for: .milliseconds(400)) // Slight delay to interleave
            let prompt3 = "Explore the future of AI in content creation and its ethical implications."
            do {
                let content = try await generator.generateContent(for: prompt3)
                print("\nUI: Successfully generated content for prompt 3 (ID: \(content.id.uuidString.prefix(8))):")
                print("  Summary: \(content.summary)")
                print("  Keywords: \(content.keywords.joined(separator: ", "))")
                print("  Image Description: \(content.imageDescription)")
            } catch {
                print("\nUI: Error generating content for prompt 3: \(error.localizedDescription)")
            }
        }

        // Keep the main task alive long enough for all async tasks to complete
        try? await Task.sleep(for: .seconds(10))
        print("\n--- All multi-modal content generation tasks initiated. ---")
    }
}
