
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import Foundation // For exp, sqrt, pi

// Define a custom Shape for the Gaussian curve
@available(iOS 18.0, macOS 15.0, *)
struct GaussianCurve: Shape {
    var mean: Double
    var standardDeviation: Double

    // Implement Animatable for smooth transitions
    var animatableData: AnimatablePair<Double, Double> {
        get { AnimatablePair(mean, standardDeviation) }
        set {
            mean = newValue.first
            standardDeviation = newValue.second
        }
    }

    func path(in rect: CGRect) -> Path {
        var path = Path()

        // Ensure standard deviation is positive to avoid division by zero or invalid calculations
        guard standardDeviation > 0 else { return path }

        // Number of points to sample for drawing the curve
        let numPoints = 200 // Increased points for smoother curve
        
        // Define the range for x values to draw the curve.
        // A common practice is to draw from mean - 4*stdDev to mean + 4*stdDev
        // as most of the probability mass (>99.99%) lies within this range.
        let minXValue = mean - 4 * standardDeviation
        let maxXValue = mean + 4 * standardDeviation
        let valueRange = maxXValue - minXValue

        // Calculate the scaling factor for the y-axis (probability density)
        // The maximum height of the Gaussian curve is at x = mean: f(mean) = 1 / (σ * sqrt(2π))
        let maxPDFValue = 1 / (standardDeviation * sqrt(2 * .pi))
        
        // Iterate through points to draw the curve
        for i in 0..<numPoints {
            let normalizedX = Double(i) / Double(numPoints - 1) // 0...1
            let xValue = minXValue + normalizedX * valueRange // Map to actual x-value range
            
            // Calculate PDF value for xValue using the Gaussian formula
            let exponent = -pow(xValue - mean, 2) / (2 * pow(standardDeviation, 2))
            let pdfValue = (1 / (standardDeviation * sqrt(2 * .pi))) * exp(exponent)

            // Map xValue to rect.width and pdfValue to rect.height
            let xPos = (xValue - minXValue) / valueRange * rect.width
            // Invert y-axis for drawing: 0 is top, rect.height is bottom.
            // We want high PDF values to be higher on the screen (lower y-coordinate).
            let yPos = rect.height - (pdfValue / maxPDFValue) * rect.height

            if i == 0 {
                path.move(to: CGPoint(x: xPos, y: yPos))
            } else {
                path.addLine(to: CGPoint(x: xPos, y: yPos))
            }
        }
        
        // Optional: To fill the area under the curve, close the path to the bottom of the rect.
        // path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
        // path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
        // path.closeSubpath()
        
        return path
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct GaussianDistributionView: View {
    @State private var mean: Double = 0.0
    @State private var standardDeviation: Double = 1.0

    var body: some View {
        VStack(spacing: 20) {
            Text("Gaussian Probability Distribution")
                .font(.headline)
            
            ZStack {
                // Background grid/axes (simplified for visual context)
                Rectangle()
                    .stroke(Color.gray.opacity(0.2), lineWidth: 0.5)
                
                // Custom Gaussian Curve
                GaussianCurve(mean: mean, standardDeviation: standardDeviation)
                    .stroke(Color.blue, lineWidth: 2) // Stroke the curve
                    // .fill(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.4), Color.clear]), startPoint: .top, endPoint: .bottom)) // Optional: Fill area
                    .frame(width: 280, height: 180) // Defined drawing frame
                
                // X-axis and Y-axis labels
                Text("Value")
                    .font(.caption)
                    .offset(y: 100) // Position below the graph
                
                Text("Probability Density")
                    .font(.caption)
                    .rotationEffect(.degrees(-90))
                    .offset(x: -160) // Position to the left of the graph
            }
            .frame(width: 300, height: 200) // Overall ZStack frame
            
            VStack(spacing: 15) {
                HStack {
                    Text("Mean:")
                        .frame(width: 70, alignment: .leading)
                    Slider(value: $mean, in: -3.0...3.0, step: 0.1) {
                        Text("Mean")
                    } minimumValueLabel: {
                        Text("-3.0")
                    } maximumValueLabel: {
                        Text("3.0")
                    }
                    Text("\(mean, format: .number.precision(.fractionLength(2)))")
                        .frame(width: 50, alignment: .trailing)
                }
                
                HStack {
                    Text("Std Dev:")
                        .frame(width: 70, alignment: .leading)
                    Slider(value: $standardDeviation, in: 0.1...2.0, step: 0.05) {
                        Text("Standard Deviation")
                    } minimumValueLabel: {
                        Text("0.1")
                    } maximumValueLabel: {
                        Text("2.0")
                    }
                    Text("\(standardDeviation, format: .number.precision(.fractionLength(2)))")
                        .frame(width: 50, alignment: .trailing)
                }
            }
            .padding(.horizontal)
        }
        .padding()
        .onAppear {
            // Simulate updates
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                withAnimation(.easeInOut(duration: 1.5)) {
                    mean = 1.5
                    standardDeviation = 0.7
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                withAnimation(.easeInOut(duration: 1.5)) {
                    mean = -0.5
                    standardDeviation = 1.8
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
                withAnimation(.easeInOut(duration: 1.5)) {
                    mean = 0.0
                    standardDeviation = 0.5
                }
            }
        }
    }
}
