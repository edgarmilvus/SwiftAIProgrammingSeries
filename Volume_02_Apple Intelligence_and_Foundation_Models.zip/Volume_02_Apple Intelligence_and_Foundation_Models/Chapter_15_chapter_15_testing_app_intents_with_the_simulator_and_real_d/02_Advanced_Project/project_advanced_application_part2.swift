
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AppIntents // Required for AppIntents framework
import SwiftUI // For @AppStorage and other UI-related elements if needed

/// Represents a single note in the Smart Notes application.
/// Conforms to `Identifiable` for easy management and `Codable` for persistence.
struct Note: Identifiable, Codable {
    let id: UUID
    var title: String
    var content: String
    var creationDate: Date

    init(id: UUID = UUID(), title: String, content: String, creationDate: Date = Date()) {
        self.id = id
        self.title = title
        self.content = content
        self.creationDate = creationDate
    }
}

/// A simple in-memory store for managing notes.
/// In a real app, this would interact with Core Data, SwiftData, or a backend.
/// Uses `UserDefaults` for basic persistence across app launches for demonstration.
class NoteStore: ObservableObject {
    static let shared = NoteStore() // Singleton instance

    @Published var notes: [Note] {
        didSet {
            // Persist notes whenever they change
            if let encoded = try? JSONEncoder().encode(notes) {
                UserDefaults.standard.set(encoded, forKey: "notes")
            }
        }
    }

    private init() {
        // Load notes from UserDefaults on initialization
        if let savedNotesData = UserDefaults.standard.data(forKey: "notes"),
           let decodedNotes = try? JSONDecoder().decode([Note].self, from: savedNotesData) {
            self.notes = decodedNotes.sorted(by: { $0.creationDate > $1.creationDate })
        } else {
            // Pre-populate with some sample notes if none exist
            self.notes = [
                Note(title: "Meeting Minutes", content: "Discussed Q3 performance, new marketing strategy, and budget allocation for next year. John will follow up on the budget. Sarah to prepare marketing materials."),
                Note(title: "Ideas for New Feature", content: "Implement real-time collaboration. Add AI-powered content generation. Improve search functionality with natural language queries."),
                Note(title: "Grocery List", content: "Milk, Eggs, Bread, Apples, Coffee, Cereal, Spinach, Chicken Breast.")
            ].sorted(by: { $0.creationDate > $1.creationDate })
        }
    }

    /// Adds a new note to the store.
    func addNote(_ note: Note) {
        notes.append(note)
        notes.sort(by: { $0.creationDate > $1.creationDate }) // Keep notes sorted by date
    }

    /// Retrieves a note by its UUID.
    func note(for id: UUID) -> Note? {
        notes.first(where: { $0.id == id })
    }

    /// Retrieves the most recent note.
    func mostRecentNote() -> Note? {
        notes.first
    }

    /// Retrieves notes matching a search term in title or content.
    func searchNotes(matching query: String) -> [Note] {
        notes.filter { note in
            note.title.localizedCaseInsensitiveContains(query) ||
            note.content.localizedCaseInsensitiveContains(query)
        }
    }
}
