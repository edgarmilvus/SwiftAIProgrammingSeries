
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

    import Foundation
    import NaturalLanguage // For some text processing capabilities, though AI takes over much of this.

    /// Represents a document that has been scanned and potentially processed by AI.
    struct Document: Identifiable, Hashable {
        let id = UUID()
        let rawText: String
        var summary: String?
        var keywords: [String]?
        var processingError: DocumentProcessingError?
        var status: DocumentStatus = .pending

        enum DocumentStatus: String {
            case pending = "Pending"
            case processing = "Processing"
            case processed = "Processed"
            case failed = "Failed"
        }
    }

    /// Custom errors specific to document processing and AI operations.
    enum DocumentProcessingError: Error, LocalizedError {
        case emptyDocument
        case aiServiceUnavailable
        case aiProcessingFailed(reason: String)
        case documentNotFound(id: UUID)
        case invalidInput(details: String)

        var errorDescription: String? {
            switch self {
            case .emptyDocument:
                return "The document contains no text and cannot be processed."
            case .aiServiceUnavailable:
                return "The Apple Intelligence service is currently unavailable."
            case .aiProcessingFailed(let reason):
                return "AI processing failed: \(reason)"
            case .documentNotFound(let id):
                return "Document with ID \(id) not found."
            case .invalidInput(let details):
                return "Invalid input provided: \(details)"
            }
        }
    }
    