
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CoreData
import SwiftData
import Foundation

// --- LEGACY MOCK (Simulating Core Data) ---
// In a real app, this would be an NSManagedObject generated from an .xcdatamodeld
class LogEntry: NSObject {
    let id: UUID
    let message: String
    init(id: UUID, message: String) { self.id = id; self.message = message }
}

// --- MODERN SWIFTDATA MODEL ---
@available(iOS 17.0, *)
@Model
final class Insight {
    var content: String
    var timestamp: Date
    // The "Soft Link": We store the UUID of the Core Data object
    var legacyLogEntryID: UUID 
    
    init(content: String, timestamp: Date, legacyLogEntryID: UUID) {
        self.content = content
        self.timestamp = timestamp
        self.legacyLogEntryID = legacyLogEntryID
    }
}

// --- HYBRID PERSISTENCE MANAGER ---
@available(iOS 17.0, *)
actor PersistenceManager {
    private let coreDataContainer: NSPersistentContainer
    private let swiftDataContainer: ModelContainer
    
    enum PersistenceError: Error {
        case containerInitializationFailed
        case logEntryNotFound
    }
    
    init() throws {
        // 1. Initialize Legacy Core Data
        // Note: In production, you'd point to your actual .xcdatamodeld
        coreDataContainer = NSPersistentContainer(name: "LegacyLogs")
        // For this exercise, we assume the container is setup correctly
        
        // 2. Initialize SwiftData
        let schema = Schema([Insight.self])
        let config = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
        do {
            swiftDataContainer = try ModelContainer(for: schema, configurations: [config])
        } catch {
            throw PersistenceError.containerInitializationFailed
        }
    }
    
    /// Performs a background fetch from Core Data and creates a SwiftData Insight
    func bridgeLogToInsight(logID: UUID) async throws {
        // Simulate Core Data Background Fetch
        let legacyLog = try await fetchLegacyLog(id: logID)
        
        // Perform SwiftData write on the actor's isolated context
        let context = ModelContext(swiftDataContainer)
        let newInsight = Insight(
            content: "AI Analysis of: \(legacyLog.message)",
            timestamp: Date(),
            legacyLogEntryID: logID
        )
        
        context.insert(newInsight)
        try context.save()
        print("Successfully bridged Log \(logID) to SwiftData Insight.")
    }
    
    // Simulated Core Data fetch logic
    private func fetchLegacyLog(id: UUID) async throws -> LogEntry {
        // In reality, this would use coreDataContainer.performBackgroundTask
        try await Task.sleep(for: .milliseconds(100)) // Simulate I/O
        return LogEntry(id: id, message: "Legacy system log message")
    }
}
