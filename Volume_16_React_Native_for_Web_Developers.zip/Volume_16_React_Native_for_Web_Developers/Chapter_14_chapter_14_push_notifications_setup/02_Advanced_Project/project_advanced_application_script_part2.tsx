/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/NotificationStream.tsx
'use client';

import { useEffect, useState } from 'react';

interface StreamMessage {
  type: string;
  content: string;
  timestamp: number;
}

export default function NotificationStream() {
  const [logs, setLogs] = useState<string[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);

  const startStream = () => {
    setIsStreaming(true);
    setLogs([]);
    
    // Establish connection to the server-side API
    const eventSource = new EventSource('/api/notifications/stream');

    eventSource.onmessage = (event) => {
      try {
        const data: StreamMessage = JSON.parse(event.data);
        
        // Update UI state immediately as tokens arrive
        setLogs((prev) => [...prev, data.content]);
      } catch (error) {
        console.error("Error parsing stream data", error);
      }
    };

    eventSource.onerror = () => {
      // Handle stream closure or errors
      eventSource.close();
      setIsStreaming(false);
    };
  };

  return (
    <div className="p-6 border rounded-lg shadow-sm">
      <h2 className="text-xl font-bold mb-4">Real-Time AI Assistant</h2>
      <button 
        onClick={startStream}
        disabled={isStreaming}
        className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50"
      >
        {isStreaming ? 'Generating...' : 'Start Analysis'}
      </button>
      
      <div className="mt-4 p-4 bg-gray-50 rounded min-h-[150px] font-mono text-sm whitespace-pre-wrap">
        {logs.join('')}
        {isStreaming && <span className="animate-pulse">|</span>}
      </div>
    </div>
  );
}
