
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

// Package.swift (Illustrative - actual Apple Intelligence frameworks are built-in)
// This section is purely illustrative to show how a dependency *might* be declared
// if Apple Intelligence was a separate Swift Package. In reality, it's part of the SDK.
/*
// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "AISummarizerApp",
    platforms: [
        .iOS(.v18), // Requires iOS 18.0 or later for Apple Intelligence features
        .macOS(.v15) // Requires macOS 15.0 or later
    ],
    products: [
        .executable(name: "AISummarizerApp", targets: ["AISummarizerApp"])
    ],
    dependencies: [
        // In a real scenario, Apple Intelligence frameworks are part of the SDK.
        // This is a placeholder for conceptual understanding.
        // .package(name: "AppleIntelligenceKit", path: "../AppleIntelligenceKit")
    ],
    targets: [
        .executableTarget(
            name: "AISummarizerApp",
            dependencies: [
                // .product(name: "AppleIntelligenceKit", package: "AppleIntelligenceKit")
            ]
        )
    ]
)
*/

import SwiftUI
import Foundation // For basic types like String

// MARK: - Hypothetical Apple Intelligence Framework Integration

/// A mock class representing an on-device AI summarization service.
/// In a real Apple Intelligence app, this would wrap actual framework APIs
/// like those for on-device LLMs or Writing Tools.
@available(iOS 18.0, macOS 15.0, *)
class AISummarizer {
    /// Simulates an asynchronous call to an on-device LLM for summarization.
    /// This method would interact with Apple Intelligence APIs to process text locally.
    /// - Parameter text: The input text to be summarized.
    /// - Returns: A summarized version of the input text.
    /// - Throws: An `AISummarizerError` if summarization fails.
    func summarize(text: String) async throws -> String {
        // Simulate network/processing delay for an on-device LLM operation.
        // Real Apple Intelligence APIs would have specific completion handlers or async methods.
        try await Task.sleep(for: .seconds(1.5))

        // Basic validation for demonstration purposes
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw AISummarizerError.emptyInput
        }

        // Simulate a very basic summarization logic.
        // In reality, the LLM would perform complex natural language processing.
        if text.count > 100 {
            let words = text.split(separator: " ")
            let summaryWords = words.prefix(words.count / 3) // Take roughly one-third of words
            return summaryWords.joined(separator: " ") + "... (AI Summary)"
        } else if text.count > 30 {
            return text + " (Short AI Summary)"
        } else {
            return "Too short to summarize effectively. (AI Hint)"
        }
    }

    /// Custom error types for the AI summarizer.
    enum AISummarizerError: Error, LocalizedError {
        case emptyInput
        case summarizationFailed(String)

        var errorDescription: String? {
            switch self {
            case .emptyInput:
                return "Input text cannot be empty for summarization."
            case .summarizationFailed(let message):
                return "Summarization failed: \(message)"
            }
        }
    }
}

// MARK: - SwiftUI Application View

/// The main view for our AI summarizer application.
/// It allows users to input text and get an AI-generated summary.
@available(iOS 18.0, macOS 15.0, *)
struct AISummarizerView: View {
    // MARK: - State Properties

    /// The text entered by the user.
    @State private var inputText: String = "Apple Intelligence is a personal intelligence system that combines the power of generative models with your personal context to deliver incredibly useful and relevant intelligence. It is deeply integrated into iOS 18, iPadOS 18, and macOS Sequoia, and is built from the ground up to protect your privacy. It understands your personal context, taking action for you across apps, and simplifies and accelerates everyday tasks."

    /// The summary generated by the AI.
    @State private var summaryText: String = "Tap 'Summarize' to get an AI summary."

    /// Controls the loading state of the summarization process.
    @State private var isLoading: Bool = false

    /// Stores any error that occurs during summarization.
    @State private var errorMessage: String?

    // MARK: - Dependencies

    /// An instance of our hypothetical AI summarizer service.
    private let aiSummarizer = AISummarizer()

    // MARK: - View Body

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("AI Note Summarizer")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                // MARK: Input Text Editor

                TextEditor(text: $inputText)
                    .frame(height: 150)
                    .padding()
                    .background(Color(.systemBackground))
                    .cornerRadius(8)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                    )
                    .padding(.horizontal)
                    .accessibilityLabel("Input text for summarization")
                    .accessibilityHint("Enter your notes or text here to get an AI summary.")

                // MARK: Summarize Button

                Button {
                    // Start the asynchronous summarization process
                    summarizeContent()
                } label: {
                    if isLoading {
                        ProgressView()
                            .progressViewStyle(.circular)
                            .tint(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue.opacity(0.7))
                            .cornerRadius(10)
                    } else {
                        Text("Summarize with AI")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                }
                .disabled(isLoading) // Disable button while loading
                .padding(.horizontal)
                .accessibilityLabel("Summarize content with AI")
                .accessibilityHint("Taps this button to get an AI-generated summary of your input text.")

                // MARK: Output Summary Display

                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("AI Summary:")
                            .font(.headline)
                            .fontWeight(.medium)
                        Text(summaryText)
                            .font(.body)
                            .foregroundColor(.primary)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                            )
                    }
                }
                .padding(.horizontal)
                .accessibilityLabel("AI generated summary")
                .accessibilityValue(summaryText)

                Spacer()
            }
            .navigationTitle("AI Summarizer")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Error", isPresented: .constant(errorMessage != nil)) {
                Button("OK") { errorMessage = nil }
            } message: {
                Text(errorMessage ?? "An unknown error occurred.")
            }
        }
    }

    // MARK: - Action Methods

    /// Initiates the summarization process using the `AISummarizer`.
    /// This method is marked `@MainActor` because it updates `@State` properties,
    /// which directly affect the UI.
    @MainActor
    private func summarizeContent() {
        isLoading = true // Show loading indicator
        errorMessage = nil // Clear previous errors

        // Use a Task to perform the asynchronous AI operation.
        // This allows the UI to remain responsive.
        Task {
            do {
                // Call the hypothetical AI summarizer.
                // This is where a real Apple Intelligence API call would go.
                let result = try await aiSummarizer.summarize(text: inputText)

                // Update UI state on the MainActor.
                // This is implicitly handled by the @MainActor context of the function,
                // but explicitly calling `await MainActor.run` is good practice
                // if this were called from a non-MainActor context.
                summaryText = result
            } catch {
                // Handle errors and display them to the user.
                errorMessage = error.localizedDescription
                summaryText = "Error: Could not generate summary."
            }
            // Ensure loading indicator is hidden regardless of success or failure.
            isLoading = false
        }
    }
}

// MARK: - App Entry Point

/// The main entry point for the SwiftUI application.
@available(iOS 18.0, macOS 15.0, *)
@main
struct AISummarizerApp: App {
    var body: some Scene {
        WindowGroup {
            AISummarizerView()
        }
    }
}
