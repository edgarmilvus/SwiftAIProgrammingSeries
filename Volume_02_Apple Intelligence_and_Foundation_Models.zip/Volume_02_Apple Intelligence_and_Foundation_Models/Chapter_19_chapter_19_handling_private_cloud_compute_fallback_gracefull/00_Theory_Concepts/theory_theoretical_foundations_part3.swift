
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import AppleIntelligence

@Observable
@available(iOS 18.0, *)
class AIViewModel {
    var isLoading: Bool = false
    var aiResultText: String?
    var statusMessage: String?
    var currentPCCStatus: PCCState = .unknown // Observed property
    var errorMessage: String?

    private let orchestrator: AIOrchestrator // Injected dependency
    private let pccMonitor: PCCStatusMonitor // Injected dependency

    init(orchestrator: AIOrchestrator, pccMonitor: PCCStatusMonitor) {
        self.orchestrator = orchestrator
        self.pccMonitor = pccMonitor
        // Start monitoring PCC status immediately
        Task { await updatePCCStatus() }
    }

    @MainActor // Ensure UI updates are on the main actor
    func updatePCCStatus() async {
        currentPCCStatus = await pccMonitor.currentPCCState()
        // Potentially set a status message based on PCC state
        switch currentPCCStatus {
        case .available:
            statusMessage = "Private Cloud Compute is available."
        case .unavailable(let reason):
            statusMessage = "PCC unavailable: \(reason). Local fallback may be used."
        case .restrictedByUser:
            statusMessage = "PCC restricted by user settings. Using local AI."
        case .networkUnavailable:
            statusMessage = "Network unavailable. PCC cannot be reached."
        case .unknown:
            statusMessage = "Checking PCC status..."
        }
    }

    @MainActor
    func generateContent(prompt: String) async {
        isLoading = true
        errorMessage = nil
        aiResultText = nil
        statusMessage = "Generating content..."

        do {
            let result = try await orchestrator.performAIAction(input: prompt)
            aiResultText = result.text
            statusMessage = "Content generated successfully via \(result.source)."
        } catch {
            errorMessage = (error as? AIError)?.localizedDescription ?? "An unexpected error occurred."
            statusMessage = "Failed to generate content."
        }
        isLoading = false
        await updatePCCStatus() // Re-check status after operation
    }
}

// SwiftUI View example
@available(iOS 18.0, *)
struct AIContentView: View {
    @State private var prompt: String = ""
    @State private var viewModel: AIViewModel // Initialized elsewhere, e.g., EnvironmentObject

    var body: some View {
        VStack {
            TextField("Enter prompt", text: $prompt)
                .textFieldStyle(.roundedBorder)
            Button("Generate") {
                Task { await viewModel.generateContent(prompt: prompt) }
            }
            .disabled(viewModel.isLoading)

            if viewModel.isLoading {
                ProgressView()
            } else if let result = viewModel.aiResultText {
                Text(result)
                    .padding()
            } else if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
            }
            Text("Status: \(viewModel.statusMessage ?? "Idle")")
                .font(.caption)
                .foregroundColor(.gray)
        }
        .padding()
    }
}
