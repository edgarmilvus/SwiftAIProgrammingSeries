
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import UIKit // For UIImage and CGImage
import CoreML
import Vision

/// A service class responsible for performing image classification using Vision and Core ML.
/// It encapsulates the model loading and prediction logic, separating it from UI concerns.
@available(iOS 13.0, *) // MobileNetV2 requires iOS 13+
class ImageClassifierService {

    /// The Core ML model that Vision will use for classification.
    /// This is loaded once during initialization to avoid repeated loading overhead.
    private var coreMLModel: VNCoreMLModel

    /// Initializes the service by loading the MobileNetV2 Core ML model.
    /// - Throws: An error if the model cannot be loaded or initialized.
    init() throws {
        // Step 1: Load the Core ML model.
        // We use the pre-trained MobileNetV2 model provided by Apple's Core ML tools.
        // In a real app, you would drag your .mlmodel file into your project and
        // Xcode automatically generates a Swift class for it (e.g., MobileNetV2).
        // For this example, we assume 'MobileNetV2.mlmodel' has been added to the project.
        // Xcode will then generate the `MobileNetV2` Swift class.
        let config = MLModelConfiguration()
        // Optional: Configure compute units for performance/power.
        // config.computeUnits = .all // Default, uses best available (Neural Engine, GPU, CPU)
        // config.computeUnits = .cpuOnly
        // config.computeUnits = .gpuOnly
        // config.computeUnits = .neuralEngine // Use if strong preference for Neural Engine

        let model = try MobileNetV2(configuration: config) // This line assumes MobileNetV2.mlmodel is in the project.
        self.coreMLModel = try VNCoreMLModel(for: model.model)
        print("MobileNetV2 Core ML model loaded successfully.")
    }

    /// Performs image classification on a given `CGImage`.
    /// - Parameters:
    ///   - image: The `CGImage` to classify.
    ///   - completion: A closure called with the classification results or an error.
    ///                 It receives an array of `VNClassificationObservation` or an `Error`.
    func classifyImage(_ image: CGImage, completion: @escaping (Result<[VNClassificationObservation], Error>) -> Void) {
        // Step 2: Create a Vision request for our Core ML model.
        // The VNCoreMLRequest takes the VNCoreMLModel and a completion handler.
        let request = VNCoreMLRequest(model: coreMLModel) { [weak self] request, error in
            // Ensure self is still alive and handle potential errors.
            guard self != nil else { return }

            if let error = error {
                print("Vision classification error: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }

            // Step 3: Process the results.
            // The results of a VNCoreMLRequest are typically an array of VNClassificationObservation.
            guard let observations = request.results as? [VNClassificationObservation] else {
                let error = NSError(domain: "ImageClassifierService", code: 0, userInfo: [NSLocalizedDescriptionKey: "Unexpected result type from VNCoreMLRequest."])
                completion(.failure(error))
                return
            }

            // Sort observations by confidence in descending order.
            let sortedObservations = observations.sorted { $0.confidence > $1.confidence }
            completion(.success(sortedObservations))
        }

        // Optional: Configure the request for better performance or specific behavior.
        // For example, you can specify the desired image crop and scale options.
        // MobileNetV2 expects a 224x224 input image. Vision handles scaling and cropping.
        request.imageCropAndScaleOption = .centerCrop

        // Step 4: Create a Vision request handler.
        // VNImageRequestHandler is responsible for performing requests on a single image.
        // It can take a CGImage, CIImage, CVPixelBuffer, or URL.
        let handler = VNImageRequestHandler(cgImage: image)

        // Step 5: Perform the request asynchronously.
        // This is an asynchronous operation, so it won't block the main thread.
        // Errors during the perform operation are caught here.
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try handler.perform([request])
            } catch {
                print("Failed to perform Vision request: \(error.localizedDescription)")
                completion(.failure(error))
            }
        }
    }
}

// MARK: - Simulating App Usage

/// This extension provides a convenient way to get a sample UIImage for demonstration.
extension UIImage {
    /// Creates a UIImage from a color and size.
    static func image(color: UIColor, size: CGSize) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        color.setFill()
        UIRectFill(CGRect(origin: .zero, size: size))
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image ?? UIImage()
    }
}

/// A simple function to simulate the flow in a Photo Analyzer app.
/// This function would typically be called from a ViewController or App Delegate.
@available(iOS 13.0, *)
func runPhotoAnalyzerSimulation() {
    print("--- Starting Photo Analyzer Simulation ---")

    // Step A: Instantiate our image classifier service.
    // This should ideally happen once, e.g., when the app starts or a view controller loads.
    let classifierService: ImageClassifierService
    do {
        classifierService = try ImageClassifierService()
        print("ImageClassifierService initialized successfully.")
    } catch {
        print("Failed to initialize ImageClassifierService: \(error.localizedDescription)")
        return
    }

    // Step B: Get a sample image.
    // In a real app, this would come from a UIImagePickerController or AVCaptureSession.
    // For MobileNetV2, a 224x224 image is typical. Let's use a green image for variety.
    guard let sampleCGImage = UIImage.image(color: .green, size: CGSize(width: 224, height: 224)).cgImage else {
        print("Failed to get CGImage from sample UIImage.")
        return
    }
    print("Sample image prepared (224x224 green image).")

    // Step C: Perform classification.
    // The completion handler will be called when the classification is done.
    classifierService.classifyImage(sampleCGImage) { result in
        // Step D: Handle the results on the main thread for UI updates.
        // Although we're just printing, in a real app, this is where you'd update labels, image views, etc.
        DispatchQueue.main.async {
            switch result {
            case .success(let observations):
                if let topObservation = observations.first {
                    print("\n--- Classification Result ---")
                    print("Top Prediction: \(topObservation.identifier) with confidence: \(String(format: "%.2f", topObservation.confidence * 100))%")
                    print("All Observations (Top 5):")
                    for obs in observations.prefix(5) { // Print top 5 for demonstration
                        print("- \(obs.identifier) (\(String(format: "%.2f", obs.confidence * 100))%)")
                    }
                } else {
                    print("No classifications found.")
                }
            case .failure(let error):
                print("\n--- Classification Failed ---")
                print("Error: \(error.localizedDescription)")
            }
            print("\n--- Photo Analyzer Simulation Ended ---")
        }
    }
}

// To run the simulation in an Xcode Playground:
// 1. Download MobileNetV2.mlmodel from Apple's Core ML Models page (developer.apple.com/machine-learning/models/).
// 2. Drag the MobileNetV2.mlmodel file into your Playground's "Resources" folder.
// 3. Ensure the Playground is set to run iOS 13.0 or later.
// 4. Uncomment the line below to execute the simulation.
//
// If running in a real app target:
// 1. Drag MobileNetV2.mlmodel into your project, ensuring it's added to your app target.
// 2. Call `runPhotoAnalyzerSimulation()` from an appropriate lifecycle method (e.g., `viewDidLoad`).

// runPhotoAnalyzerSimulation()
