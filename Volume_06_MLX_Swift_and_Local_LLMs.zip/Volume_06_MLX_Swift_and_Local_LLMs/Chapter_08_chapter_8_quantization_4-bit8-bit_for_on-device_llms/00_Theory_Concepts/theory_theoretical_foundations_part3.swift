
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI

    @available(iOS 18.0, macOS 15.0, *)
    @Observable class LLMViewModel {
        private let modelLoader = LLMModelLoader() // Our actor
        var isLoadingModel: Bool = false
        var isGenerating: Bool = false
        var currentPrompt: String = ""
        var generatedText: String = "Waiting for prompt..."
        var errorMessage: String?

        func loadModel() async {
            isLoadingModel = true
            errorMessage = nil
            do {
                try await modelLoader.loadModel(from: "quantized_model.mlx") // Placeholder path
            } catch {
                errorMessage = "Failed to load model: \(error.localizedDescription)"
            }
            isLoadingModel = false
        }

        func generateResponse() async {
            guard !currentPrompt.isEmpty else { return }
            isGenerating = true
            errorMessage = nil
            do {
                let response = try await modelLoader.generateResponse(prompt: currentPrompt)
                generatedText = response
            } catch {
                errorMessage = "Failed to generate response: \(error.localizedDescription)"
            }
            isGenerating = false
        }
    }

    @available(iOS 18.0, macOS 15.0, *)
    struct LLMView: View {
        @State var viewModel = LLMViewModel()

        var body: some View {
            VStack {
                Text("Quantized LLM Demo")
                    .font(.largeTitle)
                
                if viewModel.isLoadingModel {
                    ProgressView("Loading Model...")
                } else if let error = viewModel.errorMessage {
                    Text(error)
                        .foregroundStyle(.red)
                } else {
                    TextField("Enter your prompt", text: $viewModel.currentPrompt)
                        .textFieldStyle(.roundedBorder)
                        .padding()

                    Button("Generate") {
                        Task { await viewModel.generateResponse() }
                    }
                    .disabled(viewModel.isGenerating || viewModel.currentPrompt.isEmpty)

                    if viewModel.isGenerating {
                        ProgressView("Generating...")
                    } else {
                        ScrollView {
                            Text(viewModel.generatedText)
                                .padding()
                        }
                    }
                }
            }
            .onAppear {
                Task { await viewModel.loadModel() }
            }
            .padding()
        }
    }
    