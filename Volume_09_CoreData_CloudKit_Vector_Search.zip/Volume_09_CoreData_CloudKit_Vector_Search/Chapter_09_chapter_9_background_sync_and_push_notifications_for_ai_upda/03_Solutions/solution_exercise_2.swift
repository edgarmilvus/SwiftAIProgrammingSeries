
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import BackgroundTasks
import OSLog

class VectorReindexer {
    static let shared = VectorReindexer()
    private let logger = Logger(subsystem: "com.lumina.notes", category: "Reindexing")
    private let taskIdentifier = "com.lumina.notes.reindex-vectors"

    func registerTasks() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: taskIdentifier, using: nil) { task in
            self.handleReindexingTask(task: task as! BGProcessingTask)
        }
    }

    func scheduleReindexing() {
        let request = BGProcessingTaskRequest(identifier: taskIdentifier)
        // Requirement: Only run when charging to protect battery
        request.requiresExternalPower = true
        // Requirement: Local processing, so network isn't strictly required
        request.requiresNetworkConnectivity = false
        
        do {
            try BGTaskScheduler.shared.submit(request)
            logger.info("Reindexing task scheduled.")
        } catch {
            logger.error("Failed to schedule reindexing: \(error.localizedDescription)")
        }
    }

    private func handleReindexingTask(task: BGProcessingTask) {
        // Handle system-initiated expiration
        task.expirationHandler = {
            self.logger.warning("Reindexing task expired. Saving progress...")
            // In a real app, you would set a flag in Core Data to resume from this batch
        }

        Task {
            await performBatchReindexing(task: task)
        }
    }

    private func performBatchReindexing(task: BGProcessingTask) async {
        let notesToProcess = await fetchUnindexedNotes() // Assume this fetches IDs
        let batchSize = 10
        
        for i in stride(from: 0, to: notesToProcess.count, by: batchSize) {
            // Check for cancellation/expiration before starting a new batch
            if Task.isCancelled { break }
            
            let end = min(i + batchSize, notesToProcess.count)
            let batch = notesToProcess[i..<end]
            
            await processBatch(batch)
            
            logger.info("Processed batch \(i) to \(end)")
        }
        
        task.setTaskCompleted(success: !Task.isCancelled)
    }

    private func fetchUnindexedNotes() async -> [String] {
        // Mock implementation: returns a list of note IDs
        return (1...100).map { "note_\($0)" }
    }

    private func processBatch(_ batch: ArraySlice<String>) async {
        // Simulate heavy CoreML embedding generation
        for noteID in batch {
            try? await Task.sleep(for: .milliseconds(100)) 
            print("Generated embedding for \(noteID)")
        }
    }
}
