
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import UIKit

@available(iOS 18.0, *)
struct GeminiVisionService {
    private let apiKey: String
    private let modelName = "gemini-1.5-flash"
    private let endpoint: URL

    init(apiKey: String) {
        self.apiKey = apiKey
        self.endpoint = URL(string: "https://generativelanguage.googleapis.com/v1beta/models/\(modelName):generateContent")!
    }

    // MARK: - Models
    struct GeminiRequest: Codable, Sendable {
        let contents: [Content]
    }

    struct Content: Codable, Sendable {
        let parts: [Part]
    }

    struct Part: Codable, Sendable {
        let text: String?
        let inlineData: InlineData?

        enum CodingKeys: String, CodingKey {
            case text
            case inlineData = "inline_data"
        }
    }

    struct InlineData: Codable, Sendable {
        let mimeType: String
        let data: String

        enum CodingKeys: String, CodingKey {
            case mimeType = "mime_type"
            case data
        }
    }

    struct GeminiResponse: Codable, Sendable {
        struct Candidate: Codable, Sendable {
            struct Content: Codable, Sendable {
                struct Part: Codable, Sendable {
                    let text: String
                }
                let parts: [Part]
            }
            let content: Content
        }
        let candidates: [Candidate]
    }

    // MARK: - Logic

    func identifyIngredients(image: UIImage, prompt: String) async throws -> String {
        // 1. Downsample and compress image to prevent memory pressure (Jetsam)
        guard let compressedData = downsample(image: image, quality: 0.75) else {
            throw NSError(domain: "ImageError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to process image"])
        }

        let base64String = compressedData.base64EncodedString()

        // 2. Construct Multi-modal Request
        let textPart = Part(text: prompt, inlineData: nil)
        let imagePart = Part(text: nil, inlineData: InlineData(mimeType: "image/jpeg", data: base64String))
        
        let requestBody = GeminiRequest(contents: [
            Content(parts: [textPart, imagePart])
        ])

        // 3. Network Execution
        var urlRequest = URLRequest(url: endpoint)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.url?.appendPathComponent("?key=\(apiKey)") // Gemini uses query param for key
        urlRequest.httpBody = try JSONEncoder().encode(requestBody)

        let (data, response) = try await URLSession.shared.data(for: urlRequest)

        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw NSError(domain: "NetworkError", code: -1, userInfo: [NSLocalizedDescriptionKey: "API Request Failed"])
        }

        // 4. Decode response
        let decoded = try JSONDecoder().decode(GeminiResponse.self, from: data)
        return decoded.candidates.first?.content.parts.first?.text ?? "No response found."
    }

    private func downsample(image: UIImage, quality: CGFloat) -> Data? {
        // In a production app, we would use CGImageSource to downsample 
        // without loading the full image into memory.
        // For this exercise, we use the standard UIKit compression.
        return image.jpegData(compressionQuality: quality)
    }
}
