
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import MLX
import MLXNN
import MLXOptimizers // For more sophisticated optimizers

// Ensure this code is only compiled for platforms supporting MLX Swift
@available(iOS 18.0, macOS 15.0, *)
enum DocumentClassificationError: Error, LocalizedError {
    case modelNotTrained
    case invalidInputFeatures(String)
    case predictionFailed(String)
    case trainingFailed(String)

    var errorDescription: String? {
        switch self {
        case .modelNotTrained:
            return "The document classification model has not been trained or loaded."
        case .invalidInputFeatures(let message):
            return "Invalid input features provided: \(message)"
        case .predictionFailed(let message):
            return "Document classification prediction failed: \(message)"
        case .trainingFailed(let message):
            return "Model training failed: \(message)"
        }
    }
}

/// Represents a single training example for document classification.
/// Features would typically be embeddings extracted from the document image or text.
struct DocumentTrainingData {
    let features: MLXArray // e.g., a 768-dimensional embedding vector
    let label: Int        // The target class index (0 for receipt, 1 for invoice, etc.)
}

/// 1. Custom Document Classifier Model (MLXNN.Module)
///
/// This class defines a simple Multi-Layer Perceptron (MLP) for document classification.
/// It inherits from `MLXNN.Module`, allowing MLX to track its parameters and
/// compute gradients during training.
final class DocumentClassifier: MLXNN.Module {
    let layer1: MLXNN.Linear
    let layer2: MLXNN.Linear
    let layer3: MLXNN.Linear // Output layer for classification

    /// Initializes the document classifier with specified input and output dimensions.
    /// - Parameters:
    ///   - inputDim: The dimensionality of the input feature vector (e.g., 768 for an embedding).
    ///   - hiddenDim: The dimensionality of the hidden layers.
    ///   - numClasses: The number of distinct document classes to predict.
    init(inputDim: Int, hiddenDim: Int, numClasses: Int) {
        self.layer1 = MLXNN.Linear(inputDim, hiddenDim)
        self.layer2 = MLXNN.Linear(hiddenDim, hiddenDim)
        self.layer3 = MLXNN.Linear(hiddenDim, numClasses)
        super.init() // Call super.init() after all properties are initialized
    }

    /// Performs the forward pass of the neural network.
    /// - Parameter x: An `MLXArray` representing the input features.
    /// - Returns: An `MLXArray` of raw logits before softmax.
    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        var output = MLX.relu(layer1(x))
        output = MLX.relu(layer2(output))
        return layer3(output) // Returns logits
    }
}

/// 2. Loss Function for Classification
///
/// This static function computes the cross-entropy loss, a common loss
/// for multi-class classification problems. It takes raw logits and
/// target class indices.
enum ClassificationLoss {
    /// Computes the sparse categorical cross-entropy loss.
    /// - Parameters:
    ///   - logits: The raw output of the model before softmax.
    ///   - targets: An `MLXArray` of integer class labels.
    /// - Returns: An `MLXArray` representing the scalar loss value.
    static func crossEntropy(logits: MLXArray, targets: MLXArray) -> MLXArray {
        // MLX.losses.crossEntropy is available for convenience
        // For demonstration, let's show a manual calculation for pedagogical depth:
        // log_softmax = logits - MLX.logsumexp(logits, axis: -1, keepdims: true)
        // one_hot_targets = MLX.oneHot(targets, numClasses: logits.shape.last!)
        // return -MLX.sum(one_hot_targets * log_softmax, axis: -1).mean()
        
        // Using the built-in MLX loss function for robustness and efficiency.
        // MLX.losses.crossEntropy expects logits and integer targets.
        MLX.losses.crossEntropy(logits: logits, targets: targets, reduction: .mean)
    }
}

/// 3. Document Classifier Trainer
///
/// This class encapsulates the training logic for the DocumentClassifier.
/// It demonstrates the use of `valueAndGradient` for functional differentiation
/// and `MLX.eval` for triggering lazy computations.
final class DocumentClassifierTrainer {
    private var model: DocumentClassifier
    private var optimizer: MLXOptimizers.Adam

    /// Initializes the trainer with a new model instance.
    /// - Parameter inputDim: The input feature dimension.
    /// - Parameter hiddenDim: The hidden layer dimension.
    /// - Parameter numClasses: The number of output classes.
    init(inputDim: Int, hiddenDim: Int, numClasses: Int) {
        self.model = DocumentClassifier(inputDim: inputDim, hiddenDim: hiddenDim, numClasses: numClasses)
        // Initialize an Adam optimizer. MLXOptimizers offers various choices.
        self.optimizer = MLXOptimizers.Adam(model.parameters(), learningRate: 0.001)
    }

    /// Retrieves the currently trained model.
    /// - Returns: The `DocumentClassifier` instance.
    func getModel() -> DocumentClassifier {
        return model
    }

    /// Asynchronously trains the document classifier model.
    /// - Parameters:
    ///   - trainingData: An array of `DocumentTrainingData` examples.
    ///   - epochs: The number of training epochs.
    ///   - batchSize: The number of samples per training batch.
    ///   - progressHandler: An optional closure to report training progress.
    func train(
        trainingData: [DocumentTrainingData],
        epochs: Int,
        batchSize: Int,
        progressHandler: ((Int, Float) -> Void)? = nil
    ) async throws {
        guard !trainingData.isEmpty else {
            throw DocumentClassificationError.trainingFailed("No training data provided.")
        }

        let numBatches = (trainingData.count + batchSize - 1) / batchSize

        // Define the loss and gradient computation function.
        // `valueAndGradient` is a core functional transformation in MLX.
        // It takes a function (here, `computeLoss`) and returns a new function
        // that computes both the result of the original function AND its gradients
        // with respect to the specified parameters (model.parameters()).
        let lossAndGradientFn = MLX.valueAndGradient(model: model) { (model: DocumentClassifier, features: MLXArray, labels: MLXArray) -> MLXArray in
            let logits = model(features)
            return ClassificationLoss.crossEntropy(logits: logits, targets: labels)
        }

        for epoch in 0..<epochs {
            var epochLoss: Float = 0.0
            for i in 0..<numBatches {
                let startIndex = i * batchSize
                let endIndex = min(startIndex + batchSize, trainingData.count)
                let batch = Array(trainingData[startIndex..<endIndex])

                // Prepare batch data as MLXArrays
                let batchFeatures = MLXArray(batch.map { $0.features.asArray(Float.self) }, dtype: .float32)
                let batchLabels = MLXArray(batch.map { $0.label }, dtype: .int32)

                // Perform forward pass and backward pass (gradient computation).
                // This is where MLX's lazy evaluation builds the computation graph.
                let (loss, gradients) = lossAndGradientFn(model, batchFeatures, batchLabels)

                // Trigger the computation graph evaluation.
                // Until MLX.eval is called, the operations are merely defined.
                // This is the 'Under the Hood' detail of lazy evaluation.
                MLX.eval(model, optimizer.state, loss, gradients)

                // Update model parameters using the optimizer and computed gradients.
                optimizer.update(model, gradients)

                epochLoss += loss.item() as! Float
            }
            let averageEpochLoss = epochLoss / Float(numBatches)
            print("Epoch \(epoch + 1)/\(epochs), Loss: \(averageEpochLoss)")
            progressHandler?(epoch + 1, averageEpochLoss)
        }
        print("Training complete.")
    }
}

/// 4. Document Inference Engine
///
/// This class provides the functionality to classify documents using a trained model.
final class DocumentInferenceEngine {
    private var model: DocumentClassifier?
    private let numClasses: Int
    private let classLabels: [String]

    /// Initializes the inference engine.
    /// - Parameters:
    ///   - numClasses: The expected number of output classes.
    ///   - classLabels: An array of human-readable labels corresponding to class indices.
    init(numClasses: Int, classLabels: [String]) {
        self.numClasses = numClasses
        self.classLabels = classLabels
        precondition(classLabels.count == numClasses, "Number of class labels must match numClasses.")
    }

    /// Loads a pre-trained or newly trained model into the engine.
    /// - Parameter trainedModel: The `DocumentClassifier` instance ready for inference.
    func loadModel(_ trainedModel: DocumentClassifier) {
        self.model = trainedModel
        // Set model to evaluation mode if MLXNN.Module had explicit modes (not strictly necessary for simple MLXNN.Module)
        // trainedModel.eval()
    }

    /// Asynchronously classifies a document based on its feature vector.
    /// - Parameter features: An `MLXArray` representing the document's features.
    /// - Returns: A tuple containing the predicted class label and its confidence score.
    /// - Throws: `DocumentClassificationError` if the model is not trained or prediction fails.
    func classify(features: MLXArray) async throws -> (label: String, confidence: Float) {
        guard let model = model else {
            throw DocumentClassificationError.modelNotTrained
        }
        guard features.shape.count == 1 else { // Expecting a single feature vector [inputDim]
            throw DocumentClassificationError.invalidInputFeatures("Expected a 1D feature vector, got \(features.shape.count)D.")
        }

        // Perform forward pass to get logits.
        let logits = model(features)

        // Apply softmax to get probabilities.
        let probabilities = MLX.softmax(logits, axis: -1)

        // Trigger MLX computation for probabilities.
        MLX.eval(probabilities)

        // Find the class with the highest probability.
        let (maxProb, maxIndex) = MLX.max(probabilities, axis: -1)

        // Extract results from MLXArray to Swift native types.
        guard let confidence = maxProb.item() as? Float,
              let predictedClassIndex = maxIndex.item() as? Int else {
            throw DocumentClassificationError.predictionFailed("Could not extract prediction results.")
        }

        guard predictedClassIndex >= 0 && predictedClassIndex < classLabels.count else {
            throw DocumentClassificationError.predictionFailed("Predicted class index out of bounds: \(predictedClassIndex)")
        }

        let predictedLabel = classLabels[predictedClassIndex]
        return (label: predictedLabel, confidence: confidence)
    }
}

/// 5. App Integration Context: DocumentScannerViewModel
///
/// This class demonstrates how the MLX Swift components would be integrated
/// into an iOS application's ViewModel, handling UI updates and asynchronous operations.
@MainActor // Ensure all UI updates happen on the main actor
final class DocumentScannerViewModel: ObservableObject {
    @Published var classificationResult: String = "No document classified."
    @Published var isTraining: Bool = false
    @Published var trainingProgress: Float = 0.0
    @Published var trainingLoss: Float = 0.0
    @Published var errorMessage: String?

    private let inputFeatureDimension = 768 // Example: from a pre-trained vision transformer
    private let hiddenLayerDimension = 256
    private let numDocumentClasses = 4
    private let documentClassLabels = ["Receipt", "Invoice", "Contract", "Other"]

    private var trainer: DocumentClassifierTrainer!
    private var inferenceEngine: DocumentInferenceEngine!

    init() {
        // Initialize trainer and inference engine on app launch or as needed
        self.trainer = DocumentClassifierTrainer(
            inputDim: inputFeatureDimension,
            hiddenDim: hiddenLayerDimension,
            numClasses: numDocumentClasses
        )
        self.inferenceEngine = DocumentInferenceEngine(
            numClasses: numDocumentClasses,
            classLabels: documentClassLabels
        )
    }

    /// Simulates loading and training the model. In a real app, this might
    /// happen once on first launch or when new training data becomes available.
    func loadAndTrainModel() {
        guard !isTraining else { return }
        isTraining = true
        errorMessage = nil
        trainingProgress = 0.0
        trainingLoss = 0.0

        // Simulate some dummy training data
        let dummyTrainingData: [DocumentTrainingData] = (0..<100).map { i in
            // Generate random features for demonstration.
            // In a real app, these would come from document processing.
            let features = MLXArray.random(inputFeatureDimension)
            let label = i % numDocumentClasses // Cycle through labels
            return DocumentTrainingData(features: features, label: label)
        }

        Task {
            do {
                print("Starting model training...")
                try await trainer.train(
                    trainingData: dummyTrainingData,
                    epochs: 10,
                    batchSize: 16
                ) { [weak self] epoch, loss in
                    // Update UI on main actor
                    self?.trainingProgress = Float(epoch) / 10.0
                    self?.trainingLoss = loss
                    print("UI update: Epoch \(epoch), Loss: \(loss)")
                }
                // Once training is complete, load the trained model into the inference engine
                inferenceEngine.loadModel(trainer.getModel())
                print("Model training complete and loaded for inference.")
            } catch {
                errorMessage = "Training failed: \(error.localizedDescription)"
                print("Error during training: \(error)")
            }
            isTraining = false
        }
    }

    /// Simulates classifying a scanned document.
    /// In a real app, `documentFeatures` would come from image analysis.
    func classifyScannedDocument() {
        guard !isTraining else {
            errorMessage = "Please wait, model is currently training."
            return
        }
        errorMessage = nil
        classificationResult = "Classifying..."

        // Simulate a document's feature vector (e.g., from an image embedding model)
        let sampleFeatures = MLXArray.random(inputFeatureDimension)

        Task {
            do {
                let (label, confidence) = try await inferenceEngine.classify(features: sampleFeatures)
                classificationResult = "Predicted: \(label) (Confidence: \(String(format: "%.2f", confidence * 100))%)"
                print("Classification result: \(classificationResult)")
            } catch {
                errorMessage = "Classification failed: \(error.localizedDescription)"
                print("Error during classification: \(error)")
            }
        }
    }
}

// --- Example Usage (for demonstration, typically in a SwiftUI View) ---
/*
 @available(iOS 18.0, *)
 struct DocumentScannerView: View {
     @StateObject private var viewModel = DocumentScannerViewModel()

     var body: some View {
         VStack(spacing: 20) {
             Text("Document Classification")
                 .font(.largeTitle)

             if viewModel.isTraining {
                 ProgressView(value: viewModel.trainingProgress) {
                     Text("Training Model...")
                 }
                 Text("Current Loss: \(String(format: "%.4f", viewModel.trainingLoss))")
             } else {
                 Button("Train Model (Simulated)") {
                     viewModel.loadAndTrainModel()
                 }
                 .buttonStyle(.borderedProminent)
             }

             Divider()

             Button("Classify Sample Document") {
                 viewModel.classifyScannedDocument()
             }
             .buttonStyle(.borderedProminent)
             .disabled(viewModel.isTraining)

             Text(viewModel.classificationResult)
                 .font(.headline)
                 .padding()

             if let errorMessage = viewModel.errorMessage {
                 Text("Error: \(errorMessage)")
                     .foregroundColor(.red)
                     .padding()
             }
         }
         .padding()
     }
 }
 */
