
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI

struct SmartScrollView<Content: View>: View {
    let content: Content
    @State private var isAtBottom = true
    
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    
    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                content
                    .background(
                        GeometryReader { geo in
                            Color.clear.preference(key: ScrollOffsetKey.self, value: geo.frame(in: .named("scroll")).minY)
                        }
                    )
            }
            .coordinateSpace(name: "scroll")
            .onPreferenceChange(ScrollOffsetKey.self) { offset in
                // Simple heuristic: if offset is near 0, we are at the top.
                // In a real app, we'd compare content height vs scroll view height.
                // For this exercise, we assume the user is "at bottom" if they haven't scrolled up significantly.
                isAtBottom = offset > -10 
            }
            .onChange(of: isAtBottom) { _, atBottom in
                if atBottom {
                    // Logic to trigger scroll would go here
                }
            }
            .onPreferenceChange(ScrollOffsetKey.self) { _ in
                // This is a placeholder for the actual scroll logic
            }
            .modifier(AutoScrollModifier(isAtBottom: $isAtBottom, proxy: proxy))
        }
    }
}

struct ScrollOffsetKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

struct AutoScrollModifier: ViewModifier {
    @Binding var isAtBottom: Bool
    var proxy: ScrollViewProxy
    
    func body(content: Content) -> some View {
        content
    }
}

// Simplified implementation for the exercise context
struct ProChatView: View {
    @State private var assistantText = ""
    @State private var isAtBottom = true
    let lastMessageID = UUID()

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack {
                    ForEach(0..<10) { i in
                        Text("History Message \(i)").padding().frame(maxWidth: .infinity)
                    }
                    
                    VStack(alignment: .leading) {
                        Text(assistantText)
                            .markdownStyle() // Custom modifier
                            .id(lastMessageID)
                    }
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(10)
                }
            }
            // Detect if user is near bottom using iOS 18's new API
            .onScrollGeometryChange(for: CGFloat.self) { geo in
                geo.contentOffset.y + geo.containerSize.height - geo.contentSize.height
            } action: { offset in
                // If offset is > 50, user has scrolled up
                isAtBottom = offset < 50
            }
            .onChange(of: assistantText) {
                if isAtBottom {
                    withAnimation {
                        proxy.scrollTo(lastMessageID, anchor: .bottom)
                    }
                }
            }
        }
        .onAppear {
            simulateMarkdownStream()
        }
    }
    
    func simulateMarkdownStream() {
        Task {
            let words = ["# Hello\n", "This is **bold** and *italic*. ", "