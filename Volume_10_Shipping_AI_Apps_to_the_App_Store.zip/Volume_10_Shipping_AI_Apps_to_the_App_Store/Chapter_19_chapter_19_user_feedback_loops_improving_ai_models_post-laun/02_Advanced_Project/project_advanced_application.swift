
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import OSLog
import Combine

// MARK: - Dependencies

/// Mocking a Swift Package Manager dependency for Telemetry.
/// In a real app, this might be a custom SDK or a Firebase/Amplitude integration.
/// package swift-telemetry-sdk { version: "1.0.0" }
protocol TelemetryProvider: Sendable {
    func upload(batch: [FeedbackPayload]) async throws
}

// MARK: - Models

/// Represents the specific type of feedback captured.
/// Conforming to `Sendable` is critical for Swift 6 concurrency.
enum FeedbackType: String, Codable, Sendable {
    /// Explicit: User clicked a rating button.
    case explicitRating
    /// Explicit: User manually corrected the AI output.
    case manualCorrection
    /// Implicit: User copied the text.
    case copyAction
    /// Implicit: User deleted a significant portion of the text.
    case highDeletionRate
    /// Implicit: User spent a significant amount of time reading.
    case dwellTimeHigh
}

/// The core data structure representing a single feedback event.
struct FeedbackPayload: Codable, Sendable {
    let id: UUID
    let timestamp: Date
    let promptID: String
    let modelIdentifier: String
    let feedbackType: FeedbackType
    let metadata: [String: String] // e.g., ["char_count": "150", "edit_distance": "0.4"]
    
    init(promptID: String, modelID: String, type: FeedbackType, metadata: [String: String] = [:]) {
        self.id = UUID()
        self.timestamp = Date()
        self.promptID = promptID
        self.modelIdentifier = modelID
        self.feedbackType = type
        self.metadata = metadata
    }
}

/// Errors specific to the Feedback Orchestration process.
enum FeedbackError: Error, LocalizedError {
    case storageFailure
    case privacyViolation(String)
    case uploadFailed(underlying: Error)
    
    var errorDescription: String? {
        switch self {
        case .storageFailure: return "Failed to persist feedback locally."
        case .privacyViolation(let reason): return "Privacy check failed: \(reason)"
        case .uploadFailed(let err): return "Telemetry upload failed: \(err.localizedDescription)"
        }
    }
}

// MARK: - The Orchestrator

/// `AIFeedbackOrchestrator` is the central authority for managing AI feedback loops.
/// It uses the `actor` model to ensure that high-frequency implicit events 
/// (like keystrokes or scrolling) do not cause data races when updating the local buffer.
///
/// @available(iOS 18.0, *)
@available(iOS 18.0, *)
actor AIFeedbackOrchestrator {
    
    private let logger = Logger(subsystem: "com.ai.app", category: "FeedbackOrchestrator")
    private let telemetryProvider: TelemetryProvider
    
    /// Internal buffer to batch feedback events before uploading.
    /// Batching is crucial for battery life and network efficiency.
    private var feedbackBuffer: [FeedbackPayload] = []
    
    /// The threshold for triggering an automatic upload.
    private let batchThreshold = 10
    
    /// The maximum time to wait before forcing an upload of the current buffer.
    private let maxWaitInterval: TimeInterval = 300 // 5 minutes
    
    private var lastUploadDate: Date = Date()
    
    init(telemetryProvider: TelemetryProvider) {
        self.telemetryProvider = telemetryProvider
    }
    
    /// Records a new feedback event.
    /// - Parameters:
    ///   - type: The nature of the feedback (Explicit or Implicit).
    ///   - promptID: The unique identifier for the AI interaction.
    ///   - modelID: The version of the model that produced the output.
    ///   - metadata: Additional context (e.g., character counts, time elapsed).
    func recordFeedback(
        type: FeedbackType,
        promptID: String,
        modelID: String,
        metadata: [String: String] = [:]
    ) async throws {
        
        // 1. Privacy Guard: Ensure no PII (Personally Identifiable Information) is in metadata.
        // In a production app, this would involve regex scrubbing or a dedicated privacy service.
        try validatePrivacyCompliance(metadata)
        
        let payload = FeedbackPayload(
            promptID: promptID,
            modelID: modelID,
            type: type,
            metadata: metadata
        )
        
        logger.debug("Recording feedback: \(type.rawValue) for prompt: \(promptID)")
        
        feedbackBuffer.append(payload)
        
        // 2. Check if we should trigger a batch upload.
        if feedbackBuffer.count >= batchThreshold || Date().timeIntervalSince(lastUploadDate) > maxWaitInterval {
            try await flushBuffer()
        }
    }
    
    /// Validates that the metadata doesn't contain sensitive patterns.
    private func validatePrivacyCompliance(_ metadata: [String: String]) throws {
        for (key, value) in metadata {
            // Example: Simple check for email-like patterns in metadata.
            if value.contains("@") {
                throw FeedbackError.privacyViolation("Potential PII detected in metadata key: \(key)")
            }
        }
    }
    
    /// Transfers the current buffer to the telemetry provider and clears the buffer.
    func flushBuffer() async throws {
        guard !feedbackBuffer.isEmpty else { return }
        
        let batchToUpload = feedbackBuffer
        logger.info("Attempting to upload batch of \(batchToUpload.count) events.")
        
        do {
            try await telemetryProvider.upload(batch: batchToUpload)
            // Only clear the buffer if the upload was successful.
            feedbackBuffer.removeAll()
            lastUploadDate = Date()
            logger.info("Successfully flushed feedback buffer.")
        } catch {
            logger.error("Failed to upload feedback batch: \(error.localizedDescription)")
            // We do NOT clear the buffer here, so we can retry on the next attempt.
            throw FeedbackError.uploadFailed(underlying: error)
        }
    }
}

// MARK: - High-Level Manager (UI Layer Interface)

/// `AIFeedbackManager` is a thread-safe wrapper used by the SwiftUI views.
/// It abstracts the complexities of the `actor` and provides a simple API.
@available(iOS 18.0, *)
@MainActor
final class AIFeedbackManager: ObservableObject {
    
    private let orchestrator: AIFeedbackOrchestrator
    
    init(orchestrator: AIFeedbackOrchestrator) {
        self.orchestrator = orchestrator
    }
    
    /// Called when a user clicks a 'Thumbs Up' or 'Thumbs Down' button.
    func submitExplicitRating(promptID: String, modelID: String, isPositive: Bool) {
        Task {
            do {
                try await orchestrator.recordFeedback(
                    type: .explicitRating,
                    promptID: promptID,
                    modelID: modelID,
                    metadata: ["rating": isPositive ? "positive" : "negative"]
                )
            } catch {
                print("Failed to submit rating: \(error)")
            }
        }
    }
    
    /// Called when the user edits the AI-generated text.
    /// This is highly valuable for RLHF.
    func submitCorrection(promptID: String, modelID: String, editDistance: Double) {
        Task {
            do {
                try await orchestrator.recordFeedback(
                    type: .manualCorrection,
                    promptID: promptID,
                    modelID: modelID,
                    metadata: ["edit_distance": String(format: "%.2f", editDistance)]
                )
            } catch {
                print("Failed to submit correction: \(error)")
            }
        }
    }
    
    /// Monitors the user's interaction with the text editor to capture implicit signals.
    /// This would be called by a `TextEditor` or `TextView` delegate.
    func trackImplicitBehavior(promptID: String, modelID: String, behavior: FeedbackType, metadata: [String: String] = [:]) {
        Task {
            try? await orchestrator.recordFeedback(
                type: behavior,
                promptID: promptID,
                modelID: modelID,
                metadata: metadata
            )
        }
    }
}

// MARK: - Real-World Usage Example

/// A mock implementation of the Telemetry Provider for demonstration.
struct MockTelemetryService: TelemetryProvider {
    func upload(batch: [FeedbackPayload]) async throws {
        // Simulate network latency
        try await Task.sleep(for: .seconds(1))
        print("🚀 [Network] Successfully uploaded \(batch.count) feedback events to the cloud.")
    }
}

@available(iOS 18.0, *)
struct AIAppDemo {
    static func run() async {
        let telemetry = MockTelemetryService()
        let orchestrator = AIFeedbackOrchestrator(telemetryProvider: telemetry)
        let manager = AIFeedbackManager(orchestrator: orchestrator)
        
        let currentPromptID = "prompt_abc_123"
        let currentModelID = "gpt-4o-mini-v1"
        
        print("--- Starting AI Interaction Simulation ---")
        
        // 1. Simulate Explicit Feedback (User clicks Thumbs Up)
        print("Action: User clicks Thumbs Up")
        manager.submitExplicitRating(promptID: currentPromptID, modelID: currentModelID, isPositive: true)
        
        // 2. Simulate Implicit Feedback (User copies the text)
        print("Action: User copies the generated text")
        manager.trackImplicitBehavior(promptID: currentPromptID, modelID: currentModelID, behavior: .copyAction)
        
        // 3. Simulate High-Value Implicit Feedback (User deletes most of the text)
        print("Action: User deletes 80% of the text (High Deletion Rate)")
        manager.trackImplicitBehavior(
            promptID: currentPromptID, 
            modelID: currentModelID, 
            behavior: .highDeletionRate, 
            metadata: ["deletion_percent": "80"]
        )
        
        // 4. Simulate Manual Correction (The "Gold Standard")
        print("Action: User manually edits the text")
        manager.submitCorrection(promptID: currentPromptID, modelID: currentModelID, editDistance: 0.35)
        
        // 5. Simulate more events to trigger the batch threshold
        print("Action: Simulating rapid interactions to trigger batch upload...")
        for i in 1...8 {
            manager.trackImplicitBehavior(
                promptID: "prompt_\(i)", 
                modelID: currentModelID, 
                behavior: .dwellTimeHigh, 
                metadata: ["index": "\(i)"]
            )
        }
        
        // Allow time for the background tasks to complete in this demo
        try? await Task.sleep(for: .seconds(3))
        print("--- Simulation Complete ---")
    }
}
