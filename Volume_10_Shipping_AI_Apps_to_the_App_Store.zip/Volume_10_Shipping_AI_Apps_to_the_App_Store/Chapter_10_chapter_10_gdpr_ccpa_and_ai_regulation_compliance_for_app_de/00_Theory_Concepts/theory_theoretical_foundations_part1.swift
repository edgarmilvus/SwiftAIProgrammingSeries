
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

/// Represents the sensitivity level of the data being processed.
enum DataSensitivity: Comparable {
    case publicInformation
    case userContext // Non-identifiable but personal
    case highlySensitive // PII, medical, or financial data
}

/// A protocol defining the requirements for any data passed to an AI model.
/// Leveraging 'Sendable' ensures that data can safely move across concurrency boundaries
/// only if it has been properly sanitized.
protocol SanitizedInput: Sendable {
    var content: String { get }
    var sensitivity: DataSensitivity { get }
}

/// A concrete implementation of sanitized data.
struct AIInput: SanitizedInput {
    let content: String
    let sensitivity: DataSensitivity
}

/// The PrivacyBoundary actor acts as the 'Gatekeeper'. 
/// It is responsible for ensuring that highly sensitive data never leaves 
/// the local device context unless explicit permission is granted.
@available(iOS 18.0, *)
actor PrivacyBoundary {
    private var userConsentGranted: Bool = false
    
    /// Updates the consent state based on user interaction.
    func updateConsent(granted: Bool) {
        self.userConsentGranted = granted
    }
    
    /// Processes input by determining the appropriate inference route.
    /// This implements the 'Data Minimization' and 'Purpose Limitation' principles.
    func processInference(input: AIInput) async throws -> String {
        switch input.sensitivity {
        case .highlySensitive:
            // Principle: Data Minimization & On-Device Processing
            // We force local inference for highly sensitive data.
            return try await performLocalInference(input.content)
            
        case .userContext:
            // Principle: Transparency & Consent
            if userConsentGranted {
                return try await performCloudInference(input.content)
            } else {
                return try await performLocalInference(input.content)
            }
            
        case .publicInformation:
            return try await performCloudInference(input.content)
        }
    }
    
    private func performLocalInference(_ text: String) async throws -> String {
        // In a real app, this would call Core ML or Apple Intelligence.
        // This keeps the data within the app's local sandbox.
        return "[Local Response to: \(text)]"
    }
    
    private func performCloudInference(_ text: String) async throws -> String {
        // This represents a call to a remote LLM (e.g., OpenAI).
        // Compliance requires that 'text' has been stripped of PII before this point.
        return "[Cloud Response to: \(text)]"
    }
}

/// The ViewModel uses @Observable to bridge the UI and the PrivacyBoundary.
@available(iOS 18.0, *)
@Observable
class AIViewModel {
    var userInput: String = ""
    var response: String = ""
    var isConsentGranted: Bool = false {
        didSet {
            // Sync the UI state with the Actor's internal state.
            Task { await privacyBoundary.updateConsent(granted: isConsentGranted) }
        }
    }
    
    private let privacyBoundary = PrivacyBoundary()
    
    func generateResponse() async {
        let input = AIInput(content: userInput, sensitivity: .userContext)
        
        do {
            // The 'async' call here respects the non-blocking nature of 
            // modern privacy-preserving architectures.
            self.response = try await privacyBoundary.processInference(input: input)
        } catch {
            self.response = "Error: \(error.localizedDescription)"
        }
    }
}
