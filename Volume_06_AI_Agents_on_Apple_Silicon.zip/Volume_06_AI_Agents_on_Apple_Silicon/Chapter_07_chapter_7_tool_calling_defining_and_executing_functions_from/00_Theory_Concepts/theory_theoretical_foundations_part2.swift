
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation

// MARK: - Tool Definition

/// A protocol for defining tools that an LLM can call.
/// Conformance to Sendable is crucial for passing tool definitions across actor boundaries.
protocol LLMTool: Sendable {
    var name: String { get }
    var description: String { get }
    var schema: ToolSchema { get } // Represents the input parameters
}

/// A generic representation of a tool's input schema.
/// This would typically be a Codable struct that can be converted to JSON Schema.
struct ToolSchema: Codable, Sendable {
    let properties: [String: PropertySchema]
    let required: [String]

    struct PropertySchema: Codable, Sendable {
        let type: String // e.g., "string", "number", "boolean", "object", "array"
        let description: String?
        let `enum`: [String]? // For string enums
        // Add more JSON Schema features as needed (e.g., items for arrays, properties for objects)
    }
}

// Example Tool: Get Current Weather
struct GetWeatherTool: LLMTool {
    let name: String = "get_current_weather"
    let description: String = "Get the current weather for a specified location."
    let schema: ToolSchema = ToolSchema(
        properties: [
            "location": .init(type: "string", description: "The city and state, e.g., San Francisco, CA"),
            "unit": .init(type: "string", description: "The unit of temperature, e.g., 'celsius' or 'fahrenheit'", enum: ["celsius", "fahrenheit"])
        ],
        required: ["location"]
    )
}

// MARK: - LLM Output Representation

/// Represents a structured call to a tool from the LLM.
/// Must be Sendable to be passed between concurrent contexts.
struct ToolCall: Codable, Sendable {
    let name: String
    let arguments: [String: JSONValue] // Using a custom JSONValue enum for type safety with `Any`
}

/// A flexible enum to represent JSON values, ensuring Sendable conformance.
/// This avoids `[String: Any]` which is not Sendable by default.
enum JSONValue: Codable, Sendable {
    case string(String)
    case int(Int)
    case double(Double)
    case bool(Bool)
    case object([String: JSONValue])
    case array([JSONValue])
    case null

    // Codable conformance for JSONValue
    // ... (implementation omitted for brevity, but would involve custom init(from:) and encode(to:))
}

/// Represents the LLM's full response, which could be a tool call or a final message.
struct LLMResponse: Codable, Sendable {
    let text: String?
    let toolCall: ToolCall?
}

// MARK: - Tool Execution

/// An actor to safely manage the execution of tools.
/// Using an actor ensures that tool execution and state updates are serialized.
@available(iOS 17.0, macOS 14.0, *)
actor ToolExecutor {
    private let availableTools: [String: (([String: JSONValue]) async throws -> String)]

    init(tools: [LLMTool]) {
        var toolMap: [String: (([String: JSONValue]) async throws -> String)] = [:]
        // In a real framework, you'd register actual Swift functions here,
        // mapping them to the LLMTool definitions.
        // For demonstration, we'll use a simple closure.

        for tool in tools {
            if tool.name == "get_current_weather" {
                toolMap[tool.name] = { args in
                    guard case let .string(location) = args["location"] else {
                        throw ToolExecutionError.invalidArguments("Missing or invalid location.")
                    }
                    let unit = (args["unit"] == .string("celsius")) ? "celsius" : "fahrenheit"
                    print("Executing get_current_weather for \(location) in \(unit)")
                    // Simulate an async network call
                    try await Task.sleep(for: .seconds(1))
                    return "The current weather in \(location) is 72°\(unit == "celsius" ? "C" : "F") and sunny."
                }
            }
            // ... register other tools
        }
        self.availableTools = toolMap
    }

    /// Executes a tool identified by its name and arguments.
    /// Uses async/await for non-blocking execution.
    func executeTool(name: String, arguments: [String: JSONValue]) async throws -> String {
        guard let toolFunction = availableTools[name] else {
            throw ToolExecutionError.toolNotFound(name)
        }
        // In a real scenario, you'd perform schema validation here before calling the function
        return try await toolFunction(arguments)
    }

    enum ToolExecutionError: Error, Sendable {
        case toolNotFound(String)
        case invalidArguments(String)
        case executionFailed(String)
    }
}

// MARK: - Agent Orchestration

/// An observable class to manage the overall agent session,
/// suitable for binding to SwiftUI views.
@available(iOS 17.0, macOS 14.0, *)
@Observable
class AgentSession {
    var currentStatus: String = "Idle"
    var conversationHistory: [String] = []
    var lastToolResult: String?
    var error: Error?

    private let llmService: LLMService // Assume an LLMService exists from previous chapters
    private let toolExecutor: ToolExecutor

    init(llmService: LLMService, toolExecutor: ToolExecutor) {
        self.llmService = llmService
        self.toolExecutor = toolExecutor
    }

    /// Runs a single step of the agent's reasoning and action loop.
    func runAgentStep(prompt: String, availableTools: [LLMTool]) async {
        currentStatus = "Thinking..."
        conversationHistory.append("User: \(prompt)")

        do {
            // 1. Call LLM with tool definitions
            let llmResponse = try await llmService.generate(
                prompt: prompt,
                toolDefinitions: availableTools.map { $0.schema } // Pass schemas to LLM
            )

            if let toolCall = llmResponse.toolCall {
                // 2. LLM wants to call a tool
                currentStatus = "Executing Tool: \(toolCall.name)..."
                conversationHistory.append("Agent: Calling tool '\(toolCall.name)' with args \(toolCall.arguments)")

                // Execute the tool using the actor
                let result = try await toolExecutor.executeTool(
                    name: toolCall.name,
                    arguments: toolCall.arguments
                )
                lastToolResult = result
                conversationHistory.append("Tool Result: \(result)")

                // 3. Feed tool result back to LLM for final response
                currentStatus = "Thinking (with tool result)..."
                let finalLlmResponse = try await llmService.generate(
                    prompt: "Based on the original request and the tool result '\(result)', provide a final answer.",
                    toolDefinitions: availableTools.map { $0.schema } // Still provide tools, in case LLM wants to chain
                )
                if let finalText = finalLlmResponse.text {
                    conversationHistory.append("Agent: \(finalText)")
                } else {
                    conversationHistory.append("Agent: Received unexpected LLM response after tool execution.")
                }
            } else if let text = llmResponse.text {
                // 4. LLM provided a direct response
                conversationHistory.append("Agent: \(text)")
            } else {
                conversationHistory.append("Agent: Received empty response from LLM.")
            }
            currentStatus = "Idle"
            self.error = nil
        } catch {
            self.error = error
            currentStatus = "Error"
            conversationHistory.append("Agent Error: \(error.localizedDescription)")
        }
    }
}

// Dummy LLMService for demonstration (would interact with Ollama/llama.cpp)
@available(iOS 17.0, macOS 14.0, *)
class LLMService: Sendable {
    func generate(prompt: String, toolDefinitions: [ToolSchema]) async throws -> LLMResponse {
        // Simulate LLM deciding to call a tool or respond directly
        if prompt.lowercased().contains("weather") && prompt.lowercased().contains("san francisco") {
            return LLMResponse(
                text: nil,
                toolCall: ToolCall(
                    name: "get_current_weather",
                    arguments: ["location": .string("San Francisco, CA"), "unit": .string("fahrenheit")]
                )
            )
        } else {
            return LLMResponse(text: "I understand. How else can I assist you?", toolCall: nil)
        }
    }
}
