
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CoreML
import SwiftUI
import Combine

/// Represents the intensity levels available for our AI workload.
/// As the device heats up, we move from .high to .low.
enum AIWorkloadIntensity: Sendable, CaseIterable {
    case high      // Maximum batch size, high-precision models
    case medium    // Reduced batch size, balanced precision
    case low       // Minimal background tasks, low-precision/quantized models
    case paused    // Stop all non-essential AI tasks immediately
}

/// An actor responsible for monitoring the physical thermal state of the device.
/// Using an actor ensures that thermal state updates are synchronized and thread-safe.
@available(iOS 18.0, *)
actor ThermalStateMonitor {
    
    /// A stream that emits the current thermal state whenever it changes.
    /// This uses Swift 6 Concurrency to bridge the older NotificationCenter pattern.
    private let (stream, continuation) = AsyncStream<ProcessInfo.ThermalState>.makeStream()
    
    /// The current observed thermal state.
    private(set) var currentThermalState: ProcessInfo.ThermalState = .nominal

    init() {
        // Observe the system notification for thermal changes
        NotificationCenter.default.addObserver(
            forName: ProcessInfo.thermalStateDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { [weak self] in
                await self?.updateState()
            }
        }
    }

    /// Updates the internal state and pushes the new state into the AsyncStream.
    private func updateState() {
        let newState = ProcessInfo.processInfo.thermalState
        self.currentThermalState = newState
        continuation.yield(newState)
    }

    /// Provides an asynchronous sequence of thermal state changes.
    func thermalStateStream() -> AsyncStream<ProcessInfo.ThermalState> {
        return stream
    }
    
    /// Maps the system's thermal state to our application's workload intensity.
    /// This is the "brain" of our proactive throttling logic.
    func determineRequiredIntensity() -> AIWorkloadIntensity {
        switch currentThermalState {
        case .nominal:
            return .high
        case .fair:
            return .medium
        case .serious:
            return .low
        case .critical:
            return .paused
        @unknown default:
            return .low
        }
    }
}

/// The central coordinator for AI tasks. It manages the lifecycle of background
/// AI processing and adjusts its behavior based on thermal feedback.
@available(iOS 18.0, *)
actor AIWorkloadManager {
    
    private let thermalMonitor: ThermalStateMonitor
    private var currentIntensity: AIWorkloadIntensity = .high
    private var isProcessing = false
    
    /// Used to signal the background loop to stop or slow down.
    private var continuation: Task<Void, Never>.Continuation?

    init(monitor: ThermalStateMonitor) {
        self.thermalMonitor = monitor
    }

    /// Starts the background AI processing loop.
    /// - Parameter taskDescription: A label for the background work.
    func startBackgroundProcessing(taskDescription: String) {
        guard !isProcessing else { return }
        isProcessing = true
        
        print("🚀 Starting AI Task: \(taskDescription)")

        // Create a long-running task that listens for thermal changes
        let processingTask = Task { [weak self] in
            await self?.runProcessingLoop()
        }
        
        self.continuation = processingTask
    }

    /// The core loop that performs AI work. It checks the intensity before every "inference".
    private func runProcessingLoop() async {
        while !Task.isCancelled {
            // 1. Check the current intensity required by the thermal state
            let requiredIntensity = await thermalMonitor.determineRequiredIntensity()
            self.currentIntensity = requiredIntensity

            // 2. Handle the 'paused' state immediately
            if currentIntensity == .paused {
                print("⚠️ Thermal Critical: Pausing AI Workload.")
                try? await Task.sleep(for: .seconds(5)) // Wait before retrying
                continue
            }

            // 3. Perform the simulated AI inference
            await performInference(at: currentIntensity)

            // 4. Dynamic Throttling: Adjust the delay between tasks based on intensity
            let delay = calculateDelay(for: currentIntensity)
            try? await Task.sleep(for: .seconds(delay))
        }
    }

    /// Simulates a heavy Core ML inference task.
    /// In a real app, this is where `model.prediction(from:)` would be called.
    private func performInference(at intensity: AIWorkloadIntensity) async {
        print("🧠 Performing AI Inference at intensity: \(intensity)")
        
        // Simulate compute time: High intensity takes longer (more work),
        // but we simulate the "cost" of the work here.
        let computeTime: UInt64 = {
            switch intensity {
            case .high: return 1_000_000_000 // 1 second of heavy work
            case .medium: return 500_000_000 // 0.5 seconds
            case .low: return 100_000_000    // 0.1 seconds (lightweight model)
            case .paused: return 0
            }
        }()

        // Simulate the ANE/GPU workload
        try? await Task.sleep(nanoseconds: computeTime)
    }

    /// Calculates how long the system should rest between AI tasks.
    private func calculateDelay(for intensity: AIWorkloadIntensity) -> Double {
        switch intensity {
        case .high: return 0.5    // Rapid fire
        case .medium: return 2.0  // Moderate interval
        case .low: return 5.0     // Long interval to allow cooling
        case .paused: return 10.0 // Very long interval
        }
    }

    func stop() {
        isProcessing = false
        continuation?.cancel()
        print("🛑 AI Workload Stopped.")
    }
}

/// The ViewModel that bridges our AI logic to the SwiftUI View.
/// Marked with @MainActor to ensure all UI updates happen on the main thread.
@available(iOS 18.0, *)
@MainActor
class DocumentScannerViewModel: ObservableObject {
    @Published var statusMessage: String = "Ready to scan"
    @Published var isScanning: Bool = false
    
    private let thermalMonitor = ThermalStateMonitor()
    private var workloadManager: AIWorkloadManager?

    func toggleScanning() {
        if isScanning {
            stopScanning()
        } else {
            startScanning()
        }
    }

    private func startScanning() {
        isScanning = true
        statusMessage = "Scanning and enhancing documents..."
        
        // Initialize the manager with the monitor
        let manager = AIWorkloadManager(monitor: thermalMonitor)
        self.workloadManager = manager
        
        Task {
            await manager.startBackgroundProcessing(taskDescription: "Document Enhancement Engine")
            await monitorThermalChanges()
        }
    }

    private func stopScanning() {
        isScanning = false
        statusMessage = "Scan complete."
        Task {
            await workloadManager?.stop()
        }
    }

    /// Listens to the thermal monitor and updates the UI so the user knows why performance might change.
    private func monitorThermalChanges() async {
        let stream = await thermalMonitor.thermalStateStream()
        
        for await state in stream {
            // Update UI based on thermal state
            switch state {
            case .nominal:
                statusMessage = "Scanning (Optimal Performance)"
            case .fair:
                statusMessage = "Scanning (Balanced Mode)"
            case .serious:
                statusMessage = "Scanning (Low Power Mode - Device Warm)"
            case .critical:
                statusMessage = "Scanning Paused (Device Overheating!)"
            @unknown default:
                break
            }
        }
    }
}

/// A simple SwiftUI view to demonstrate the interaction.
@available(iOS 18.0, *)
struct DocumentScannerView: View {
    @StateObject private var viewModel = DocumentScannerViewModel()

    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: viewModel.isScanning ? "doc.text.magnifyingglass" : "doc.text")
                .font(.system(size: 80))
                .foregroundColor(viewModel.isScanning ? .blue : .gray)
                .symbolEffect(.bounce, value: viewModel.isScanning)

            Text(viewModel.statusMessage)
                .font(.headline)
                .multilineTextAlignment(.center)
                .padding()

            Button(action: {
                viewModel.toggleScanning()
            }) {
                Text(viewModel.isScanning ? "Stop Scanning" : "Start AI Scanning")
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(viewModel.isScanning ? Color.red : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }
            .padding(.horizontal)
        }
        .padding()
    }
}
