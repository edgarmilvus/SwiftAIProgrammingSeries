
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import GroupActivities
import Observation

@Observable
@MainActor
final class SpatialSessionManager {
    enum SessionStatus: Equatable {
        case idle
        case connecting
        case active(participantCount: Int)
        case ended
    }
    
    private(set) var status: SessionStatus = .idle
    private var sessionTask: Task<Void, Never>?
    
    /// Starts observing a GroupSession.
    func monitor(session: GroupSession<MoodBoardActivity>) {
        status = .connecting
        
        // Cancel any existing monitoring task
        sessionTask?.cancel()
        
        sessionTask = Task {
            // The session provides an AsyncSequence of events.
            // We iterate over this sequence to react to joins/leaves/ends.
            for await event in session.events {
                updateStatus(for: session)
            }
            
            // If the loop ends, the session has concluded.
            status = .ended
        }
    }
    
    private func updateStatus(for session: GroupSession<MoodBoardActivity>) {
        // We must ensure UI updates happen on the MainActor.
        // Since the class is @MainActor, this is implicit.
        let count = session.participants.count
        if count > 0 {
            status = .active(participantCount: count)
        } else {
            status = .ended
        }
    }
    
    func stop() {
        sessionTask?.cancel()
        status = .idle
    }
}

struct SessionStatusView: View {
    let manager: SpatialSessionManager
    
    var body: some View {
        Group {
            switch manager.status {
            case .idle:
                Text("Ready to start")
                    .foregroundStyle(.secondary)
            case .connecting:
                ProgressView("Connecting to session...")
            case .active(let count):
                HStack {
                    Circle().fill(.green).frame(width: 10, height: 10)
                    Text("Active: \(count) Participant\(count == 1 ? "" : "s")")
                }
                .padding()
                .background(.ultraThinMaterial, in: Capsule())
            case .ended:
                Text("Session Ended")
                    .foregroundStyle(.red)
            }
        }
        .animation(.default, value: manager.status)
    }
}
