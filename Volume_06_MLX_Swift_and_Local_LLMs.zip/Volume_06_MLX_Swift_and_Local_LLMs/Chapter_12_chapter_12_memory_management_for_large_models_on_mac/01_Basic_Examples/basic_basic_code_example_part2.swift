
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import MLX
import MLXNN // For defining neural network modules

// Ensure the code is available for the target platforms
@available(iOS 17.0, macOS 14.0, *)
class MLXMemoryManagementExample {

    /// A simple neural network module to extract features from an input.
    /// This module contains a single linear layer that transforms an input
    /// of `inputFeatures` dimensions into an output of `outputFeatures` dimensions.
    class FeatureExtractor: MLXNN.Module {
        let linear: MLXNN.Linear

        /// Initializes the feature extractor.
        /// - Parameters:
        ///   - inputFeatures: The number of input dimensions.
        ///   - outputFeatures: The number of output dimensions (the feature vector size).
        override init() {
            // MLXNN.Module requires an empty initializer,
            // then we can configure it.
            // This is a common pattern in MLX Swift.
            self.linear = MLXNN.Linear(inputFeatures: 1024, outputFeatures: 128)
            super.init()
            // Register the linear layer as a submodule.
            // This allows MLX to automatically track its parameters for training/saving.
            self.register(linear: linear)
        }

        /// The forward pass of the feature extractor.
        /// - Parameter input: An MLXArray representing the input data (e.g., pre-processed image data).
        /// - Returns: An MLXArray representing the extracted features.
        func callAsFunction(_ input: MLXArray) -> MLXArray {
            // Apply the linear transformation.
            // MLX operations are lazy; this operation is added to the computation graph
            // but not executed immediately.
            return linear(input)
        }
    }

    /// Runs the basic memory management example for MLX.
    func runExample() {
        print("--- MLX Swift Basic Memory Management Example ---")

        // 1. Initialize the Feature Extractor model
        // The model's weights (for the linear layer) are initialized as MLXArrays.
        // On Apple Silicon, these weights reside in Unified Memory.
        let featureExtractor = FeatureExtractor()
        print("\n1. Initialized FeatureExtractor model.")
        print("   Model parameters (weights, biases) are MLXArrays, residing in Unified Memory.")

        // 2. Create dummy input data (e.g., pre-processed image data)
        // Let's simulate a batch of 4 images, each with 1024 input features.
        // This MLXArray also allocates its data directly in Unified Memory.
        let batchSize = 4
        let inputFeatures = 1024
        let dummyInput = MLXArray.randomUniform(low: 0, high: 1, shape: [batchSize, inputFeatures])
        print("\n2. Created dummy input data (MLXArray) of shape \(dummyInput.shape).")
        print("   This data also resides in Unified Memory, avoiding CPU-GPU copies.")
        print("   Input data device: \(dummyInput.device)") // Will likely be 'cpu' by default, but unified memory is still used.

        // 3. Perform a forward pass
        // This operation builds the computation graph.
        // MLX uses lazy evaluation: the actual computation on the data
        // does not happen until the result is explicitly requested (e.g., via .eval() or accessing its value).
        print("\n3. Performing forward pass (lazy evaluation)...")
        let extractedFeatures = featureExtractor(dummyInput)
        print("   Computation graph for feature extraction has been built.")
        print("   Output MLXArray created (shape: \(extractedFeatures.shape)).")
        print("   Actual computation has NOT happened yet.")

        // 4. Force evaluation to trigger computation
        // Calling .eval() on an MLXArray forces all pending operations in its computation graph
        // to execute on the specified device (default is CPU/unified memory).
        print("\n4. Forcing evaluation to trigger computation...")
        extractedFeatures.eval()
        print("   Computation completed. Features are now available.")
        print("   First extracted feature vector (first 5 elements): \(extractedFeatures[0, 0..<5].description)")

        // 5. Demonstrate the functional transformation pattern (optional for basic, but key to MLX)
        // MLX's functional API allows for powerful transformations like computing gradients.
        // While not strictly "memory management," it shows how MLX builds and uses graphs
        // efficiently, which is foundational to its memory model.
        print("\n\n5. Demonstrating functional transformation (valueAndGradient) for memory efficiency...")

        /// A simple loss function for demonstration.
        /// This would typically compare model output to a target.
        func simpleLoss(model: FeatureExtractor, input: MLXArray) -> MLXArray {
            let output = model(input)
            // L2 norm of the output as a dummy loss
            return MLX.mean(MLX.square(output))
        }

        // `valueAndGradient` computes both the loss value and its gradient
        // with respect to the model's parameters in one efficient pass.
        // This reuses the computation graph and memory efficiently.
        print("   Computing loss and gradients for the feature extractor...")
        let (loss, gradients) = MLX.valueAndGradient(featureExtractor, simpleLoss)(featureExtractor, dummyInput)

        // Evaluate the loss and gradients
        loss.eval()
        gradients.eval()

        print("   Loss value: \(loss.item())")
        print("   Gradients computed for \(gradients.count) parameters.")
        if let firstParamGradient = gradients.values.first {
            print("   First parameter gradient shape: \(firstParamGradient.shape)")
        }
        print("   This process efficiently reuses the computation graph and memory for both forward and backward passes.")

        print("\n--- Example Finished ---")
    }
}

// Entry point for the executable
if #available(iOS 17.0, macOS 14.0, *) {
    let example = MLXMemoryManagementExample()
    example.runExample()
} else {
    print("MLX Swift requires iOS 17.0 / macOS 14.0 or later.")
}
