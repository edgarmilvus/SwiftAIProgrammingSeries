
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import AppKit
import Foundation // For CFAbsoluteTimeGetCurrent()

// Assume LlamaKit bindings (LlamaModel, LlamaContext, LlamaModelParams, LlamaContextParams, LlamaError)
// as defined in Exercise 1 are available in the project.
// For this solution, the mock LlamaKit definitions from Exercise 1 are implicitly included.

// MARK: - Parameter Tuning Manager (ViewModel)

@MainActor
class ParameterTuningManager: ObservableObject {
    private var llamaModel: LlamaModel?
    private var llamaContext: LlamaContext?
    private let modelPath: String // Path to the GGUF model
    
    // Published parameters, directly bound to UI controls
    @Published var nCtx: UInt32 = 512 { didSet { if oldValue != nCtx { updateContextParams() } } }
    @Published var nGpuLayers: Int = 0 { didSet { if oldValue != nGpuLayers { updateModelAndContextParams() } } }
    @Published var nThreads: UInt32 = 4 { didSet { if oldValue != nThreads { updateContextParams() } } }
    @Published var temperature: Float = 0.8 { didSet { if oldValue != temperature { updateContextParams() } } }
    @Published var topP: Float = 0.95 { didSet { if oldValue != topP { updateContextParams() } } }
    @Published var repeatPenalty: Float = 1.1 { didSet { if oldValue != repeatPenalty { updateContextParams() } } }
    
    @Published var currentPrompt: String = "Explain the concept of neural networks."
    @Published var generatedResponse: String = ""
    @Published var tokensPerSecond: String = "N/A"
    @Published var isGenerating: Bool = false
    @Published var errorMessage: String?
    
    private var currentInferenceTask: Task<Void, Never>? // To manage cancellation

    init(modelPath: String) {
        self.modelPath = modelPath
    }

    // Initial load of model and context
    func loadModelAndContext() async {
        isGenerating = true // Indicate loading state
        errorMessage = nil
        generatedResponse = "Loading model and context...\n"

        do {
            llamaModel = LlamaModel(path: modelPath)
            try llamaModel?.load()
            
            guard let model = llamaModel else {
                throw LlamaError.generalError("Failed to initialize LlamaModel.")
            }

            // Initial context setup
            var contextParams = LlamaContextParams()
            contextParams.n_ctx = nCtx
            contextParams.n_threads = nThreads
            contextParams.temp = temperature
            contextParams.top_p = topP
            contextParams.repeat_penalty = repeatPenalty

            llamaContext = try LlamaContext(model: model, params: contextParams)
            
            generatedResponse = "Model loaded and context initialized. Ready for generation.\n"
            print("ParameterTuningManager: Initial model and context ready.")
        } catch {
            errorMessage = error.localizedDescription
            generatedResponse = "Error: \(error.localizedDescription)\n"
            print("ParameterTuningManager: Error loading model/context: \(error.localizedDescription)")
        }
        isGenerating = false
    }
    
    // Updates context parameters and reinitializes context if needed
    private func updateContextParams() {
        guard let model = llamaModel else { return }
        
        // Cancel any ongoing generation to prevent conflicts
        currentInferenceTask?.cancel()
        currentInferenceTask = nil

        do {
            var newParams = LlamaContextParams()
            newParams.n_ctx = nCtx
            newParams.n_threads = nThreads
            newParams.temp = temperature
            newParams.top_p = topP
            newParams.repeat_penalty = repeatPenalty
            
            // If context exists, update its parameters. Otherwise, create new.
            if let context = llamaContext {
                try context.updateParams(newParams: newParams)
            } else {
                llamaContext = try LlamaContext(model: model, params: newParams)
            }
            print("ParameterTuningManager: Context parameters updated.")
            generatedResponse = "Context reinitialized with new parameters.\n"
        } catch {
            errorMessage = error.localizedDescription
            generatedResponse = "Error updating context: \(error.localizedDescription)\n"
            print("ParameterTuningManager: Error updating context: \(error.localizedDescription)")
        }
    }
    
    // Updates model and context parameters and reloads both (for n_gpu_layers)
    private func updateModelAndContextParams() {
        guard let model = llamaModel else { return }
        
        // Cancel any ongoing generation
        currentInferenceTask?.cancel()
        currentInferenceTask = nil

        // For n_gpu_layers, we typically need to reload the model entirely
        // or at least re-create the context with new model parameters.
        // For this mock, we'll simulate a full reload.
        llamaContext = nil // Deallocate context first
        llamaModel = nil   // Deallocate model

        Task { @MainActor in
            await loadModelAndContext() // Reload with new parameters
            print("ParameterTuningManager: Model and context reloaded due to n_gpu_layers change.")
            generatedResponse = "Model and context reloaded with new parameters.\n"
        }
    }

    func generateResponse() async {
        guard let model = llamaModel, let context = llamaContext, !isGenerating else {
            if isGenerating { errorMessage = "Already generating." }
            return
        }

        currentInferenceTask?.cancel() // Cancel any previous task if still running
        currentInferenceTask = Task { @MainActor in
            isGenerating = true
            errorMessage = nil
            generatedResponse = "Generating...\n"
            tokensPerSecond = "N/A"

            do {
                try context.reset() // Clear context for fresh generation
                let promptTokens = model.tokenize(text: currentPrompt, addBos: true)
                try context.feedPrompt(tokens: promptTokens)

                var responseText = ""
                var generatedTokensCount = 0
                let maxTokensToGenerate = 100 // Limit for this exercise

                let startTime = CFAbsoluteTimeGetCurrent()

                for _ in 0..<maxTokensToGenerate {
                    try Task.checkCancellation() // Allow cancellation during generation

                    let nextToken = context.sampleNextToken()

                    if nextToken == model.getEosToken() {
                        print("ParameterTuningManager: [EOS] detected.")
                        break
                    }
                    if nextToken == -1 {
                        throw LlamaError.inferenceFailed("Invalid token generated.")
                    }

                    let newText = model.detokenize(tokens: [nextToken])
                    responseText += newText
                    generatedTokensCount += 1

                    // Append incrementally to UI
                    generatedResponse = currentPrompt + "\n" + responseText
                    
                    // Simulate processing time
                    try await Task.sleep(seconds: 0.01)
                }

                let endTime = CFAbsoluteTimeGetCurrent()
                let elapsedTime = endTime - startTime

                if generatedTokensCount > 0 && elapsedTime > 0 {
                    let tps = Double(generatedTokensCount) / elapsedTime
                    tokensPerSecond = String(format: "%.2f t/s", tps)
                } else {
                    tokensPerSecond = "0.00 t/s"
                }
                
                print("ParameterTuningManager: Generation complete. Tokens: \(generatedTokensCount), Time: \(elapsedTime)s, TPS: \(tokensPerSecond)")

            } catch is LlamaError {
                errorMessage = "LLM Error: \(error.localizedDescription)"
                generatedResponse += "\n[Error: \(error.localizedDescription)]\n"
            } catch is CancellationError {
                generatedResponse += "\n[Generation cancelled]\n"
                print("ParameterTuningManager: Inference task cancelled.")
            } catch {
                errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                generatedResponse += "\n[Error: \(error.localizedDescription)]\n"
            }
            isGenerating = false
        }
    }
    
    deinit {
        print("ParameterTuningManager: Deallocating.")
        currentInferenceTask?.cancel()
        llamaContext = nil
        llamaModel = nil
    }
}

// MARK: - macOS AppKit UI

class ParameterTuningViewController: NSViewController {
    // UI Outlets
    var nCtxSlider: NSSlider!
    var nCtxLabel: NSTextField!
    var nGpuLayersSlider: NSSlider!
    var nGpuLayersLabel: NSTextField!
    var nThreadsSlider: NSSlider!
    var nThreadsLabel: NSTextField!
    var temperatureSlider: NSSlider!
    var temperatureLabel: NSTextField!
    var topPSlider: NSSlider!
    var topPLabel: NSTextField!
    var repeatPenaltySlider: NSSlider!
    var repeatPenaltyLabel: NSTextField!

    var promptTextField: NSTextField!
    var generateButton: NSButton!
    var responseTextView: NSTextView!
    var tokensPerSecondLabel: NSTextField!
    var scrollView: NSScrollView!

    private let manager: ParameterTuningManager
    private var cancellables = Set<AnyCancellable>()

    init(manager: ParameterTuningManager) {
        self.manager = manager
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        // IMPORTANT: Replace with the actual path to your .gguf model file.
        // For this mock, a dummy file will be created/used at this path.
        let modelFileName = "dummy_model.gguf"
        let modelPath = FileManager.default.temporaryDirectory.appendingPathComponent(modelFileName).path
        self.manager = ParameterTuningManager(modelPath: modelPath)
        super.init(coder: coder)
    }

    override func loadView() {
        self.view = NSView(frame: NSRect(x: 0, y: 0, width: 800, height: 700))
        self.view.autoresizesSubviews = true
        setupUI()
        bindViewModel()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        Task {
            await manager.loadModelAndContext()
        }
    }

    private func setupUI() {
        let contentView = self.view
        var currentY: CGFloat = contentView.frame.height - 30
        let padding: CGFloat = 20
        let controlWidth: CGFloat = 150
        let labelWidth: CGFloat = 100
        let sliderWidth: CGFloat = 250
        let rowHeight: CGFloat = 25

        func addLabel(_ text: String, to view: NSView, y: inout CGFloat) -> NSTextField {
            let label = NSTextField(labelWithString: text)
            label.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(label)
            NSLayoutConstraint.activate([
                label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
                label.topAnchor.constraint(equalTo: view.topAnchor, constant: y),
                label.widthAnchor.constraint(equalToConstant: labelWidth),
                label.heightAnchor.constraint(equalToConstant: rowHeight)
            ])
            return label
        }

        func addSlider(min: Double, max: Double, initial: Double, step: Double, to view: NSView, y: inout CGFloat, target: Any, action: Selector) -> NSSlider {
            let slider = NSSlider(value: initial, minValue: min, maxValue: max, target: target, action: action)
            slider.translatesAutoresizingMaskIntoConstraints = false
            slider.controlSize = .small
            slider.sliderType = .linear
            slider.isContinuous = true
            slider.doubleValue = initial
            slider.numberOfTickMarks = Int((max - min) / step) + 1
            slider.allowsTickMarkValuesOnly = false
            view.addSubview(slider)
            NSLayoutConstraint.activate([
                slider.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding + labelWidth + 10),
                slider.topAnchor.constraint(equalTo: view.topAnchor, constant: y),
                slider.widthAnchor.constraint(equalToConstant: sliderWidth),
                slider.heightAnchor.constraint(equalToConstant: rowHeight)
            ])
            return slider
        }
        
        func addValueLabel(to view: NSView, y: inout CGFloat) -> NSTextField {
            let label = NSTextField(labelWithString: "0")
            label.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(label)
            NSLayoutConstraint.activate([
                label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding + labelWidth + 10 + sliderWidth + 10),
                label.topAnchor.constraint(equalTo: view.topAnchor, constant: y),
                label.widthAnchor.constraint(equalToConstant: controlWidth - sliderWidth - 10 - labelWidth - 10),
                label.heightAnchor.constraint(equalToConstant: rowHeight)
            ])
            return label
        }

        // Parameter Controls
        currentY = 20 // Start from top

        nCtxLabel = addLabel("Context Size:", to: contentView, y: &currentY)
        nCtxSlider = addSlider(min: 128, max: 4096, initial: Double(manager.nCtx), step: 128, to: contentView, y: &currentY, target: self, action: #selector(nCtxChanged(_:)))
        currentY += rowHeight + 5

        nGpuLayersLabel = addLabel("GPU Layers:", to: contentView, y: &currentY)
        nGpuLayersSlider = addSlider(min: 0, max: 32, initial: Double(manager.nGpuLayers), step: 1, to: contentView, y: &currentY, target: self, action: #selector(nGpuLayersChanged(_:)))
        currentY += rowHeight + 5

        nThreadsLabel = addLabel("Threads:", to: contentView, y: &currentY)
        nThreadsSlider = addSlider(min: 1, max: 12, initial: Double(manager.nThreads), step: 1, to: contentView, y: &currentY, target: self, action: #selector(nThreadsChanged(_:)))
        currentY += rowHeight + 5

        temperatureLabel = addLabel("Temperature:", to: contentView, y: &currentY)
        temperatureSlider = addSlider(min: 0.0, max: 2.0, initial: Double(manager.temperature), step: 0.05, to: contentView, y: &currentY, target: self, action: #selector(temperatureChanged(_:)))
        currentY += rowHeight + 5

        topPLabel = addLabel("Top P:", to: contentView, y: &currentY)
        topPSlider = addSlider(min: 0.0, max: 1.0, initial: Double(manager.topP), step: 0.01, to: contentView, y: &currentY, target: self, action: #selector(topPChanged(_:)))
        currentY += rowHeight + 5
        
        repeatPenaltyLabel = addLabel("Repeat Penalty:", to: contentView, y: &currentY)
        repeatPenaltySlider = addSlider(min: 1.0, max: 2.0, initial: Double(manager.repeatPenalty), step: 0.05, to: contentView, y: &currentY, target: self, action: #selector(repeatPenaltyChanged(_:)))
        currentY += rowHeight + 15
        
        // Prompt Input
        let promptLabel = NSTextField(labelWithString: "Prompt:")
        promptLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(promptLabel)
        NSLayoutConstraint.activate([
            promptLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding),
            promptLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: currentY),
            promptLabel.widthAnchor.constraint(equalToConstant: labelWidth),
            promptLabel.heightAnchor.constraint(equalToConstant: rowHeight)
        ])
        
        promptTextField = NSTextField()
        promptTextField.translatesAutoresizingMaskIntoConstraints = false
        promptTextField.placeholderString = "Enter your prompt here..."
        promptTextField.stringValue = manager.currentPrompt
        contentView.addSubview(promptTextField)
        NSLayoutConstraint.activate([
            promptTextField.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding + labelWidth + 10),
            promptTextField.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -padding),
            promptTextField.topAnchor.constraint(equalTo: contentView.topAnchor, constant: currentY),
            promptTextField.heightAnchor.constraint(equalToConstant: rowHeight)
        ])
        currentY += rowHeight + 10

        // Generate Button
        generateButton = NSButton(title: "Generate", target: self, action: #selector(generateText(_:)))
        generateButton.translatesAutoresizingMaskIntoConstraints = false
        generateButton.bezelStyle = .rounded
        contentView.addSubview(generateButton)
        NSLayoutConstraint.activate([
            generateButton.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding),
            generateButton.topAnchor.constraint(equalTo: contentView.topAnchor, constant: currentY),
            generateButton.widthAnchor.constraint(equalToConstant: 100),
            generateButton.heightAnchor.constraint(equalToConstant: 30)
        ])
        
        // Tokens per second label
        tokensPerSecondLabel = NSTextField(labelWithString: "Tokens/sec: N/A")
        tokensPerSecondLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(tokensPerSecondLabel)
        NSLayoutConstraint.activate([
            tokensPerSecondLabel.leadingAnchor.constraint(equalTo: generateButton.trailingAnchor, constant: 20),
            tokensPerSecondLabel.centerYAnchor.constraint(equalTo: generateButton.centerYAnchor),
            tokensPerSecondLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -padding),
            tokensPerSecondLabel.heightAnchor.constraint(equalToConstant: rowHeight)
        ])
        currentY += 30 + 10

        // Response Text View
        scrollView = NSScrollView()
        scrollView.hasVerticalScroller = true
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(scrollView)

        responseTextView = NSTextView()
        responseTextView.isEditable = false
        responseTextView.isSelectable = true
        responseTextView.textContainerInset = NSSize(width: 5, height: 5)
        responseTextView.font = NSFont.monospacedSystemFont(ofSize: 13, weight: .regular)
        scrollView.documentView = responseTextView
        
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: currentY),
            scrollView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding),
            scrollView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -padding),
            scrollView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -padding)
        ])
    }

    private func bindViewModel() {
        // Bind sliders to manager properties
        nCtxSlider.publisher(for: \.doubleValue)
            .map { UInt32($0) }
            .debounce(for: .milliseconds(100), scheduler: DispatchQueue.main) // Debounce for performance
            .assign(to: \.nCtx, on: manager)
            .store(in: &cancellables)
        
        nGpuLayersSlider.publisher(for: \.doubleValue)
            .map { Int($0) }
            .debounce(for: .milliseconds(100), scheduler: DispatchQueue.main)
            .assign(to: \.nGpuLayers, on: manager)
            .store(in: &cancellables)

        nThreadsSlider.publisher(for: \.doubleValue)
            .map { UInt32($0) }
            .debounce(for: .milliseconds(100), scheduler: DispatchQueue.main)
            .assign(to: \.nThreads, on: manager)
            .store(in: &cancellables)

        temperatureSlider.publisher(for: \.doubleValue)
            .map { Float($0) }
            .debounce(for: .milliseconds(100), scheduler: DispatchQueue.main)
            .assign(to: \.temperature, on: manager)
            .store(in: &cancellables)

        topPSlider.publisher(for: \.doubleValue)
            .map { Float($0) }
            .debounce(for: .milliseconds(100), scheduler: DispatchQueue.main)
            .assign(to: \.topP, on: manager)
            .store(in: &cancellables)
            
        repeatPenaltySlider.publisher(for: \.doubleValue)
            .map { Float($0) }
            .debounce(for: .milliseconds(100), scheduler: DispatchQueue.main)
            .assign(to: \.repeatPenalty, on: manager)
            .store(in: &cancellables)

        // Bind manager properties to UI labels
        manager.$nCtx
            .receive(on: DispatchQueue.main)
            .sink { [weak self] value in self?.nCtxLabel.stringValue = "Context Size: \(value)" }
            .store(in: &cancellables)
        manager.$nGpuLayers
            .receive(on: DispatchQueue.main)
            .sink { [weak self] value in self?.nGpuLayersLabel.stringValue = "GPU Layers: \(value)" }
            .store(in: &cancellables)
        manager.$nThreads
            .receive(on: DispatchQueue.main)
            .sink { [weak self] value in self?.nThreadsLabel.stringValue = "Threads: \(value)" }
            .store(in: &cancellables)
        manager.$temperature
            .receive(on: DispatchQueue.main)
            .sink { [weak self] value in self?.temperatureLabel.stringValue = String(format: "Temperature: %.2f", value) }
            .store(in: &cancellables)
        manager.$topP
            .receive(on: DispatchQueue.main)
            .sink { [weak self] value in self?.topPLabel.stringValue = String(format: "Top P: %.2f", value) }
            .store(in: &cancellables)
        manager.$repeatPenalty
            .receive(on: DispatchQueue.main)
            .sink { [weak self] value in self?.repeatPenaltyLabel.stringValue = String(format: "Repeat Penalty: %.2f", value) }
            .store(in: &cancellables)

        // Bind prompt text field
        promptTextField.textPublisher
            .assign(to: \.currentPrompt, on: manager)
            .store(in: &cancellables)

        // Bind response text view and performance metrics
        manager.$generatedResponse
            .receive(on: DispatchQueue.main)
            .sink { [weak self] response in
                self?.responseTextView.string = response
                self?.responseTextView.scrollToEndOfDocument(nil)
            }
            .store(in: &cancellables)

        manager.$tokensPerSecond
            .receive(on: DispatchQueue.main)
            .sink { [weak self] tps in self?.tokensPerSecondLabel.stringValue = "Tokens/sec: \(tps)" }
            .store(in: &cancellables)

        // Bind generation state to UI elements
        manager.$isGenerating
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isGenerating in
                self?.generateButton.isEnabled = !isGenerating
                // Disable sliders while generating to prevent mid-inference reloads
                self?.nCtxSlider.isEnabled = !isGenerating
                self?.nGpuLayersSlider.isEnabled = !isGenerating
                self?.nThreadsSlider.isEnabled = !isGenerating
                self?.temperatureSlider.isEnabled = !isGenerating
                self?.topPSlider.isEnabled = !isGenerating
                self?.repeatPenaltySlider.isEnabled = !isGenerating
                self?.promptTextField.isEnabled = !isGenerating
            }
            .store(in: &cancellables)
        
        // Observe error messages
        manager.$errorMessage
            .receive(on: DispatchQueue.main)
            .sink { [weak self] errorMessage in
                if let message = errorMessage {
                    let alert = NSAlert()
                    alert.messageText = "Error"
                    alert.informativeText = message
                    alert.alertStyle = .critical
                    alert.runModal()
                }
            }
            .store(in: &cancellables)
    }

    // MARK: - UI Actions
    @objc private func nCtxChanged(_ sender: NSSlider) { manager.nCtx = UInt32(sender.doubleValue) }
    @objc private func nGpuLayersChanged(_ sender: NSSlider) { manager.nGpuLayers = Int(sender.doubleValue) }
    @objc private func nThreadsChanged(_ sender: NSSlider) { manager.nThreads = UInt32(sender.doubleValue) }
    @objc private func temperatureChanged(_ sender: NSSlider) { manager.temperature = Float(sender.doubleValue) }
    @objc private func topPChanged(_ sender: NSSlider) { manager.topP = Float(sender.doubleValue) }
    @objc private func repeatPenaltyChanged(_ sender: NSSlider) { manager.repeatPenalty = Float(sender.doubleValue) }

    @IBAction func generateText(_ sender: NSButton) {
        // Update prompt in manager before generating
        manager.currentPrompt = promptTextField.stringValue
        Task {
            await manager.generateResponse()
        }
    }
}

// MARK: - Helper for NSTextField Publisher

extension NSTextField {
    var textPublisher: AnyPublisher<String, Never> {
        NotificationCenter.default.publisher(for: NSTextField.textDidChangeNotification, object: self)
            .compactMap { $0.object as? NSTextField }
            .map { $0.stringValue }
            .eraseToAnyPublisher()
    }
}

// MARK: - App Delegate for macOS

@main
class AppDelegate: NSObject, NSApplicationDelegate {
    var window: NSWindow!
    var viewController: ParameterTuningViewController!

    func applicationDidFinishLaunching(_ notification: Notification) {
        let modelFileName = "dummy_model.gguf"
        let modelPath = FileManager.default.temporaryDirectory.appendingPathComponent(modelFileName).path
        let manager = ParameterTuningManager(modelPath: modelPath)
        
        viewController = ParameterTuningViewController(manager: manager)
        
        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 800, height: 700),
            styleMask: [.titled, .closable, .resizable, .miniaturizable],
            backing: .buffered,
            defer: false
        )
        window.center()
        window.title = "Llama.cpp Parameter Tuner"
        window.contentViewController = viewController
        window.makeKeyAndOrderFront(nil)
        
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
    }
    
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }
}
