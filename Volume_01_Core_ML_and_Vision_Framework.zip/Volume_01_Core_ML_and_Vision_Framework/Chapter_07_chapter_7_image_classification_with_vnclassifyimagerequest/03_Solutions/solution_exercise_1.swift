
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import Vision
import PhotosUI // For modern photo picker on iOS 14+

class ImageClassificationViewController: UIViewController {

    private let imageView = UIImageView()
    private let selectImageButton = UIButton(type: .system)
    private let resultsLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        // Image View Setup
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .systemGray5
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)

        // Select Image Button Setup
        selectImageButton.setTitle("Select Image", for: .normal)
        selectImageButton.addTarget(self, action: #selector(selectImageTapped), for: .touchUpInside)
        selectImageButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(selectImageButton)

        // Results Label Setup
        resultsLabel.text = "No image selected."
        resultsLabel.numberOfLines = 0
        resultsLabel.textAlignment = .center
        resultsLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(resultsLabel)

        // Constraints
        NSLayoutConstraint.activate([
            selectImageButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            selectImageButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            imageView.topAnchor.constraint(equalTo: selectImageButton.bottomAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.4), // 40% of view height

            resultsLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            resultsLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultsLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            resultsLabel.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    @objc private func selectImageTapped() {
        // Use PHPickerViewController for iOS 14+ for a more modern experience
        if #available(iOS 14, *) {
            var configuration = PHPickerConfiguration()
            configuration.filter = .images
            configuration.selectionLimit = 1 // Only allow selecting one image
            let picker = PHPickerViewController(configuration: configuration)
            picker.delegate = self
            present(picker, animated: true)
        } else {
            // Fallback to UIImagePickerController for older iOS versions
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .photoLibrary
            present(picker, animated: true)
        }
    }

    private func classifyImage(_ image: UIImage) {
        // Ensure the image can be converted to CGImage
        guard let cgImage = image.cgImage else {
            DispatchQueue.main.async {
                self.resultsLabel.text = "Error: Could not convert image for Vision processing."
            }
            return
        }

        // Create a Vision request handler for the image
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        // Create a classification request
        let request = VNClassifyImageRequest { [weak self] request, error in
            guard let self = self else { return }

            DispatchQueue.main.async {
                if let error = error {
                    self.resultsLabel.text = "Vision error: \(error.localizedDescription)"
                    print("Vision request failed with error: \(error)")
                    return
                }

                guard let observations = request.results as? [VNClassificationObservation], !observations.isEmpty else {
                    self.resultsLabel.text = "No classifications found."
                    return
                }

                // Format the top 3 results
                let topResults = observations.prefix(3)
                let resultsText = topResults.map { observation in
                    let confidencePercentage = String(format: "%.2f%%", observation.confidence * 100)
                    return "\(observation.identifier) (\(confidencePercentage))"
                }.joined(separator: "\n")

                self.resultsLabel.text = "Top Classifications:\n\(resultsText)"
            }
        }

        // Configure the request to limit results to the top 3
        request.resultsLimit = 3

        // Perform the Vision request on a background queue
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try handler.perform([request])
            } catch {
                DispatchQueue.main.async {
                    self.resultsLabel.text = "Failed to perform Vision request: \(error.localizedDescription)"
                    print("Failed to perform Vision request: \(error)")
                }
            }
        }
    }
}

// MARK: - UIImagePickerControllerDelegate & UINavigationControllerDelegate (for iOS < 14)
extension ImageClassificationViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true) {
            if let selectedImage = info[.originalImage] as? UIImage {
                self.imageView.image = selectedImage
                self.resultsLabel.text = "Classifying image..."
                self.classifyImage(selectedImage)
            } else {
                self.resultsLabel.text = "No image selected or image could not be loaded."
            }
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
        resultsLabel.text = "Image selection cancelled."
    }
}

// MARK: - PHPickerViewControllerDelegate (for iOS 14+)
@available(iOS 14, *)
extension ImageClassificationViewController: PHPickerViewControllerDelegate {
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true) {
            guard let result = results.first else {
                self.resultsLabel.text = "Image selection cancelled."
                return
            }

            // Load the image from the item provider
            result.itemProvider.loadObject(ofClass: UIImage.self) { [weak self] (object, error) in
                guard let self = self else { return }

                DispatchQueue.main.async {
                    if let error = error {
                        self.resultsLabel.text = "Error loading image: \(error.localizedDescription)"
                        print("Error loading image from picker: \(error)")
                        return
                    }

                    guard let selectedImage = object as? UIImage else {
                        self.resultsLabel.text = "Could not load selected image."
                        return
                    }

                    self.imageView.image = selectedImage
                    self.resultsLabel.text = "Classifying image..."
                    self.classifyImage(selectedImage)
                }
            }
        }
    }
}
