
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import ARKit
import RealityKit
import Combine
import simd

@MainActor
class DesignAssistantManager: ObservableObject {
    private var selectedEntities: Set<Entity> = []
    private var handTrajectory: [SIMD3<Float>] = []
    private var lastClapTime: Date = .distantPast
    
    // 1. Sculpt Gesture: Pinch and Twist
    func updateSculpt(entity: Entity, handAnchor: HandAnchor) {
        // Use the hand's orientation quaternion for natural rotation
        let handRotation = handAnchor.orientation
        // Map hand rotation to the entity's Y-axis
        let rotationY = simd_quatf(angle: handRotation.angle, axis: [0, 1, 0])
        entity.orientation = rotationY
    }
    
    // 2. Semantic Sweep: Selection via Trajectory
    func processSweep(currentHandPos: SIMD3<Float>, scene: Scene) {
        handTrajectory.append(currentHandPos)
        // Keep only last 0.5 seconds (approx 30-45 frames)
        if handTrajectory.count > 45 { handTrajectory.removeFirst() }
        
        // Define sweep volume (Simplified as a sphere around the trajectory)
        for point in handTrajectory {
            let entities = scene.entities(at: point) // Hypothetical spatial query
            for entity in entities {
                if entity.components.has(SemanticComponent.self) {
                    selectedEntities.insert(entity)
                }
            }
        }
    }
    
    // 3. Optimize Intent: Clapping
    func detectClap(leftHand: HandAnchor?, rightHand: HandAnchor?) -> Bool {
        guard let left = leftHand, let right = rightHand else { return false }
        
        let distance = simd_distance(left.anchorPose.position, right.anchorPose.position)
        
        // Detect rapid approach and separation
        if distance < 0.1 {
            let now = Date()
            if now.timeIntervalSince(lastClapTime) > 1.0 { // Debounce
                lastClapTime = now
                return true
            }
        }
        return false
    }
    
    // 4. AI Optimization Engine
    func runOptimization(scene: Scene) async {
        let currentPositions = selectedEntities.map { ($0, $0.position) }
        
        // Use TaskGroup for parallel animations
        await withTaskGroup(of: Void.self) { group in
            for (entity, _) in currentPositions {
                group.addTask {
                    // Simulate AI calculating new optimal position
                    let optimizedPos = SIMD3<Float>(Float.random(in: -1...1), 0, Float.random(in: -1...1))
                    
                    // Animate to new position
                    await entity.move(to: Transform(translation: optimizedPos), 
                                    relativeTo: nil, 
                                    duration: 2.0)
                }
            }
        }
    }
}
