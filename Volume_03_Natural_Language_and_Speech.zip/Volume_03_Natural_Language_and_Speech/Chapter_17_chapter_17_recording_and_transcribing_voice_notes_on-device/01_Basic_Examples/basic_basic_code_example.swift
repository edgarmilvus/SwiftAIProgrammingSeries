
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Speech
import AVFoundation
import Foundation // For Error

/// A class responsible for recording audio and transcribing it into text on-device.
/// This class leverages Apple's Speech and AVFoundation frameworks to provide
/// a robust, privacy-preserving, and efficient voice transcription solution.
@MainActor // Ensure all UI-related updates and state changes happen on the main actor
class VoiceNoteTranscriber: NSObject, SFSpeechRecognizerDelegate, ObservableObject {

    // MARK: - Published Properties
    /// The current transcription result, updated in real-time.
    @Published var recognizedText: String = ""
    /// Indicates whether the transcriber is currently recording and transcribing.
    @Published var isTranscribing: Bool = false
    /// Any error that occurred during the transcription process.
    @Published var error: Error?

    // MARK: - Private Properties
    private let speechRecognizer: SFSpeechRecognizer?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine() // Manages audio input and output

    /// Initializes a new VoiceNoteTranscriber instance.
    /// It attempts to initialize an `SFSpeechRecognizer` for the current locale,
    /// explicitly enabling on-device recognition if supported.
    override init() {
        // Initialize with the default locale.
        // For specific language, e.g., SFSpeechRecognizer(locale: Locale(identifier: "es-ES"))
        // Note: Not all locales support on-device recognition.
        speechRecognizer = SFSpeechRecognizer()

        super.init()

        // Crucially, check if on-device recognition is available and set it.
        // This ensures transcription happens locally without sending audio to Apple servers.
        if let recognizer = speechRecognizer, recognizer.supportsOnDeviceRecognition {
            recognizer.delegate = self
            // While `supportsOnDeviceRecognition` indicates capability,
            // the `recognitionRequest` is where you explicitly set `requiresOnDeviceRecognition`.
            // We'll set it in `startTranscribing()`.
        } else {
            error = VoiceNoteTranscriberError.recognizerNotAvailable
            print("Speech recognizer not available or does not support on-device recognition for this locale.")
        }
    }

    // MARK: - Authorization

    /// Requests authorization from the user for speech recognition and microphone access.
    /// This must be called before starting transcription.
    /// - Returns: `true` if authorization is granted, `false` otherwise.
    func requestAuthorization() async -> Bool {
        // Request Speech Recognition authorization
        let speechAuthStatus = await SFSpeechRecognizer.requestAuthorization()
        
        // Request Microphone access authorization
        let microphoneAuthStatus = await AVCaptureDevice.requestAccess(for: .audio)

        let isAuthorized = speechAuthStatus == .authorized && microphoneAuthStatus
        if !isAuthorized {
            self.error = VoiceNoteTranscriberError.notAuthorized
            print("Speech recognition or microphone access not authorized.")
        }
        return isAuthorized
    }

    // MARK: - Transcription Control

    /// Starts the audio recording and speech transcription process.
    /// - Throws: `VoiceNoteTranscriberError` if authorization is not granted,
    ///           or if the audio engine fails to start.
    func startTranscribing() throws {
        // 1. Pre-flight checks: Ensure recognizer is available and authorized.
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            throw VoiceNoteTranscriberError.recognizerNotAvailable
        }

        guard SFSpeechRecognizer.authorizationStatus() == .authorized else {
            throw VoiceNoteTranscriberError.notAuthorized
        }

        // 2. Cancel any previous recognition task to start fresh.
        recognitionTask?.cancel()
        recognitionTask = nil

        // 3. Configure the audio session for recording.
        // This prepares the device's audio hardware for input.
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            self.error = error
            throw VoiceNoteTranscriberError.audioSessionSetupFailed(error)
        }

        // 4. Create a new recognition request.
        // SFSpeechAudioBufferRecognitionRequest is used for live audio streaming.
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            throw VoiceNoteTranscriberError.recognitionRequestFailed
        }

        // Crucial for on-device recognition:
        // This property *must* be set to true to ensure transcription happens locally.
        recognitionRequest.requiresOnDeviceRecognition = true
        // Set to true to receive intermediate results as the user speaks, providing a real-time feel.
        recognitionRequest.shouldReportPartialResults = true

        // 5. Start the recognition task.
        // This task manages the actual speech recognition process.
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return } // Avoid retain cycles

            var isFinal = false

            if let result = result {
                // Update the published property with the latest transcription.
                self.recognizedText = result.bestTranscription.formattedString
                isFinal = result.isFinal
            }

            if let error = error {
                // If an error occurs, stop transcription and report it.
                self.stopTranscribing()
                self.error = error
                print("Speech recognition error: \(error.localizedDescription)")
            }

            if isFinal {
                // If the result is final, the task is complete, so stop recording.
                self.stopTranscribing()
            }
        }

        // 6. Configure the audio engine to provide audio input to the recognition request.
        // This sets up a tap on the microphone's audio stream.
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            // Append each audio buffer to the recognition request.
            self.recognitionRequest?.append(buffer)
        }

        // 7. Prepare and start the audio engine.
        // This begins the audio recording process.
        audioEngine.prepare()
        do {
            try audioEngine.start()
            isTranscribing = true
            recognizedText = "" // Clear previous text for a new session
            error = nil // Clear previous error
            print("Audio engine started. Transcribing...")
        } catch {
            // If the audio engine fails to start, clean up and report the error.
            self.stopTranscribing()
            self.error = error
            throw VoiceNoteTranscriberError.audioEngineStartFailed(error)
        }
    }

    /// Stops the audio recording and speech transcription process.
    /// This cleans up all resources associated with the transcription session.
    func stopTranscribing() {
        // Stop the audio engine and remove the tap.
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)

        // Signal the recognition request that no more audio will be appended.
        recognitionRequest?.endAudio()
        // Cancel the recognition task if it's still running.
        recognitionTask?.cancel()

        // Release references to tasks and requests.
        recognitionTask = nil
        recognitionRequest = nil

        isTranscribing = false
        print("Transcription stopped.")

        // Deactivate the audio session to free up hardware resources.
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            self.error = error
            print("Error deactivating audio session: \(error.localizedDescription)")
        }
    }

    // MARK: - SFSpeechRecognizerDelegate

    /// Called when the availability of the speech recognizer changes.
    /// For example, if network connectivity changes (for server-based recognition)
    /// or a language model becomes available/unavailable (for on-device).
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if !available {
            self.error = VoiceNoteTranscriberError.recognizerUnavailable
            print("Speech recognizer availability changed: Not available.")
            if isTranscribing {
                stopTranscribing() // Stop if recognizer becomes unavailable during transcription
            }
        } else {
            print("Speech recognizer availability changed: Available.")
            // Clear error if it was related to unavailability
            if case VoiceNoteTranscriberError.recognizerUnavailable = error {
                self.error = nil
            }
        }
    }

    // MARK: - Error Handling

    /// Custom error types for the VoiceNoteTranscriber.
    enum VoiceNoteTranscriberError: LocalizedError {
        case recognizerNotAvailable
        case recognizerUnavailable
        case notAuthorized
        case audioSessionSetupFailed(Error)
        case recognitionRequestFailed
        case audioEngineStartFailed(Error)

        var errorDescription: String? {
            switch self {
            case .recognizerNotAvailable:
                return "Speech recognizer is not available for this device or locale, or does not support on-device recognition."
            case .recognizerUnavailable:
                return "Speech recognizer is temporarily unavailable."
            case .notAuthorized:
                return "Microphone or Speech Recognition authorization was denied. Please enable it in Settings > Privacy & Security."
            case .audioSessionSetupFailed(let error):
                return "Failed to set up audio session: \(error.localizedDescription)"
            case .recognitionRequestFailed:
                return "Failed to create speech recognition request."
            case .audioEngineStartFailed(let error):
                return "Failed to start audio engine: \(error.localizedDescription)"
            }
        }
    }
}
