
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import GroupActivities
import RealityKit
import ARKit
import Combine

// MARK: - Dependencies

/// Package.swift equivalent requirements:
/// - RealityKit (Built-in)
/// - GroupActivities (Built-in)
/// - SwiftUI (Built-in)

// MARK: - Models

/// Represents the spatial state of an object that needs to be synchronized.
/// Conforms to `Codable` for transmission and `Sendable` for Swift 6 concurrency safety.
struct SpatialTransformUpdate: Codable, Sendable {
    let entityIdentifier: UUID
    let position: SIMD3<Float>
    let orientation: simd_quatf
    let scale: SIMD3<Float>
    let timestamp: Date
    
    /// Custom encoding for simd types which aren't natively Codable in all environments
    enum CodingKeys: String, CodingKey {
        case entityIdentifier, position, orientation, scale, timestamp
    }
    
    init(entityIdentifier: UUID, position: SIMD3<Float>, orientation: simd_quatf, scale: SIMD3<Float>, timestamp: Date = .now) {
        self.entityIdentifier = entityIdentifier
        self.position = position
        self.orientation = orientation
        self.scale = scale
        self.timestamp = timestamp
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        entityIdentifier = try container.decode(UUID.self, forKey: .entityIdentifier)
        
        // Decode Position
        let posArray = try container.decode([Float].self, forKey: .position)
        position = SIMD3<Float>(posArray[0], posArray[1], posArray[2])
        
        // Decode Orientation (Quaternion)
        let quatArray = try container.decode([Float].self, forKey: .orientation)
        orientation = simd_quatf(ix: quatArray[0], iy: quatArray[1], iz: quatArray[2], r: quatArray[3])
        
        // Decode Scale
        let scaleArray = try container.decode([Float].self, forKey: .scale)
        scale = SIMD3<Float>(scaleArray[0], scaleArray[1], scaleArray[2])
        
        timestamp = try container.decode(Date.self, forKey: .timestamp)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(entityIdentifier, forKey: .entityIdentifier)
        try container.encode([position.x, position.y, position.z], forKey: .position)
        try container.encode([orientation.vector.x, orientation.vector.y, orientation.vector.z, orientation.vector.w], forKey: .orientation)
        try container.encode([scale.x, scale.y, scale.z], forKey: .scale)
        try container.encode(timestamp, forKey: .timestamp)
    }
}

// MARK: - Group Activity Definition

/// The unique activity type that identifies our collaborative session.
struct SpatialCollaborationActivity: GroupActivity {
    static let activityIdentifier = "com.spatialarchitect.collaboration"
    
    var metadata: GroupActivityMetadata {
        let metadata = GroupActivityMetadata()
        metadata.title = "Collaborative Design Session"
        metadata.type = .generic
        return metadata
    }
}

// MARK: - Error Handling

enum SpatialSyncError: Error, LocalizedError {
    case sessionNotEstablished
    case encodingFailed
    case decodingFailed
    case transmissionError(String)
    
    var errorDescription: String? {
        switch self {
        case .sessionNotEstablished: return "No active SharePlay session found."
        case .encodingFailed: return "Failed to encode spatial data."
        case .decodingFailed: return "Failed to decode incoming spatial data."
        case .transmissionError(let msg): return "Transmission error: \(msg)"
        }
    }
}

// MARK: - Core Synchronization Actor

/// The `SpatialSyncManager` is the heart of the synchronization engine.
/// It is an `actor` to ensure that all state mutations (updating entity positions)
/// are serialized, preventing data races in a multi-threaded visionOS environment.
@available(visionOS 2.0, *)
actor SpatialSyncManager: NSObject {
    
    /// The active session provided by GroupActivities
    private var session: GroupSession<SpatialCollaborationActivity>?
    
    /// A dictionary of local entities being managed, keyed by their unique ID.
    private var managedEntities: [UUID: Entity] = [:]
    
    /// A closure to notify the UI or RealityKit view of updates.
    /// In a production app, this might be a Combine publisher or an AsyncStream.
    var onUpdateReceived: (@Sendable (SpatialTransformUpdate) -> Void)?

    /// Initializes the manager and sets up the session listener.
    init(session: GroupSession<SpatialCollaborationActivity>) {
        self.session = session
        super.init()
    }
    
    /// Registers an entity to be tracked and synchronized.
    /// - Parameter entity: The RealityKit entity to track.
    /// - Parameter id: A unique identifier for the entity.
    func registerEntity(_ entity: Entity, id: UUID) {
        managedEntities[id] = entity
    }

    /// Broadcasts a transform update to all participants in the SharePlay session.
    /// - Parameter update: The new spatial state.
    func broadcastUpdate(_ update: SpatialTransformUpdate) async throws {
        guard let session = session, !session.isGroupSessionEnded else {
            throw SpatialSyncError.sessionNotEstablished
        }
        
        do {
            let data = try JSONEncoder().encode(update)
            try await session.send(data)
        } catch {
            throw SpatialSyncError.transmissionError(error.localizedDescription)
        }
    }
    
    /// Handles incoming data packets from the GroupSession.
    /// This is called when the session receives a new message.
    func handleIncomingData(_ data: Data) {
        do {
            let update = try JSONDecoder().decode(SpatialTransformUpdate.self, from: data)
            
            // Apply the update to the local entity if it exists.
            if let entity = managedEntities[update.entityIdentifier] {
                // We switch back to the MainActor for RealityKit transform updates
                // as RealityKit entities are not Sendable and must be modified on the main thread.
                Task { @MainActor in
                    applyTransform(update, to: entity)
                }
            }
            
            // Notify listeners of the update
            onUpdateReceived?(update)
            
        } catch {
            print("Failed to decode spatial update: \(error)")
        }
    }
    
    @MainActor
    private func applyTransform(_ update: SpatialTransformUpdate, to entity: Entity) {
        // Smooth interpolation (Lerp) would be implemented here in a real app.
        // For this example, we perform an immediate transform application.
        entity.position = update.position
        entity.orientation = update.orientation
        entity.scale = update.scale
    }
    
    /// Starts listening to the session's data stream.
    func startListening() async {
        guard let session = session else { return }
        
        // We use an AsyncSequence to process incoming messages.
        // This is the modern Swift 6 way to handle continuous data streams.
        for await message in session.messages {
            // Note: In a real implementation, we would check the message type.
            // For simplicity, we assume all messages are our SpatialTransformUpdate.
            handleIncomingData(message)
        }
    }
}

// MARK: - RealityKit Integration Component

/// A view modifier or controller that bridges the SpatialSyncManager with the RealityKit scene.
@available(visionOS 2.0, *)
@MainActor
class SpatialExperienceController: ObservableObject {
    
    @Published var syncManager: SpatialSyncManager?
    private var cancellables = Set<AnyCancellable>()
    
    /// The root entity of our shared scene.
    let sceneRoot = Entity()
    
    /// Creates a new session and initializes the manager.
    func setupSession(session: GroupSession<SpatialCollaborationActivity>) async {
        let manager = SpatialSyncManager(session: session)
        self.syncManager = manager
        
        // Start the listening loop in a detached task to avoid blocking the main thread.
        Task {
            await manager.startListening()
        }
        
        print("Spatial Session Established.")
    }
    
    /// Called when a user interacts with an object (e.g., via a gesture).
    func handleEntityInteraction(entity: Entity, id: UUID, newTransform: SpatialTransformUpdate) {
        Task {
            // 1. Update local entity immediately for zero-latency feedback (Optimistic UI).
            entity.position = newTransform.position
            entity.orientation = newTransform.orientation
            
            // 2. Broadcast to others.
            try? await syncManager?.broadcastUpdate(newTransform)
        }
    }
}

// MARK: - SwiftUI Interface

@available(visionOS 2.0, *)
struct CollaborativeSpatialView: View {
    @StateObject private var controller = SpatialExperienceController()
    @State private var isSessionActive = false
    
    var body: some View {
        RealityView { content in
            // Setup the initial shared scene.
            let box = ModelEntity(mesh: .generateBox(size: 0.2), materials: [SimpleMaterial(color: .blue, isMetallic: true)])
            let id = UUID()
            box.name = id.uuidString
            
            // In a real app, we'd store this ID in a registry.
            content.add(box)
            controller.sceneRoot.addChild(box)
        }
        .overlay(alignment: .bottom) {
            if !isSessionActive {
                Button("Start Collaborative Session") {
                    startSession()
                }
                .buttonStyle(.borderedProminent)
                .padding()
            } else {
                Text("Connected to SharePlay")
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(10)
            }
        }
    }
    
    private func startSession() {
        Task {
            do {
                let activity = SpatialCollaborationActivity()
                try await activity.activate()
                // In a real app, the user would accept the invitation via FaceTime.
                // Here we simulate the session being established.
                isSessionActive = true
            } catch {
                print("Failed to activate activity: \(error)")
            }
        }
    }
}
