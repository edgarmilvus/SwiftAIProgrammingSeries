
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
class ChatViewModel: ObservableObject {
    private let llmEngine = LLMInferenceActor() // Create an instance of our actor
    @Published var currentResponse: String = ""
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    init() {
        // Load model on actor initialization, or lazily when needed
        Task {
            do {
                try await llmEngine.loadModel(path: "/path/to/your/model.gguf")
            } catch {
                await MainActor.run {
                    self.errorMessage = "Failed to load LLM model: \(error.localizedDescription)"
                }
            }
        }
    }

    func sendPrompt(_ text: String) {
        isLoading = true
        errorMessage = nil
        currentResponse = "" // Clear previous response
        let prompt = Prompt(text: text, temperature: 0.7, maxTokens: 256)

        Task {
            do {
                // Await the actor's response without blocking the UI
                let response = try await llmEngine.generate(prompt: prompt)
                await MainActor.run {
                    // Update UI on the main actor after inference is complete
                    self.currentResponse = response.generatedText
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "LLM inference failed: \(error.localizedDescription)"
                    self.isLoading = false
                }
            }
        }
    }
}
