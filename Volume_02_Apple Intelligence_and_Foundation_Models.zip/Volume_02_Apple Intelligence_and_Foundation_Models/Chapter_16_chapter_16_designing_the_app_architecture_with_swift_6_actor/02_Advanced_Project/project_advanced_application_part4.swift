
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

    @available(iOS 18.0, *)
    actor DocumentProcessorActor {
        private var processedDocuments: [UUID: Document] = [:]
        private let aiService: AIService

        /// Initializes the document processor with an AI service instance.
        /// - Parameter aiService: The instance of `AIService` to use for AI operations.
        init(aiService: AIService) {
            self.aiService = aiService
        }

        /// Adds a new document to the processor's collection.
        /// - Parameter rawText: The raw text content of the document.
        /// - Returns: The newly created `Document` instance.
        func addDocument(rawText: String) -> Document {
            let newDocument = Document(rawText: rawText, status: .pending)
            processedDocuments[newDocument.id] = newDocument
            print("Added document: \(newDocument.id)")
            return newDocument
        }

        /// Processes a document using the AI service. This method updates the document's state
        /// within the actor's isolated context, ensuring thread safety.
        /// - Parameter documentId: The ID of the document to process.
        /// - Throws: `DocumentProcessingError.documentNotFound` if the document doesn't exist.
        func processDocument(documentId: UUID) async {
            guard var document = processedDocuments[documentId] else {
                print("Error: Document with ID \(documentId) not found for processing.")
                // Not throwing here, but rather updating the state with an error if possible,
                // or logging. For a UI, we'd notify.
                return
            }

            print("Starting AI processing for document: \(document.id)")
            document.status = .processing
            processedDocuments[document.id] = document // Update status in isolated state

            do {
                async let summary = aiService.summarize(text: document.rawText)
                async let keywords = aiService.extractKeywords(text: document.rawText)

                let (retrievedSummary, retrievedKeywords) = try await (summary, keywords)

                document.summary = retrievedSummary
                document.keywords = retrievedKeywords
                document.status = .processed
                document.processingError = nil
                print("Successfully processed document: \(document.id)")

            } catch let error as DocumentProcessingError {
                document.status = .failed
                document.processingError = error
                print("Failed to process document \(document.id): \(error.localizedDescription)")
            } catch {
                document.status = .failed
                document.processingError = .aiProcessingFailed(reason: error.localizedDescription)
                print("An unexpected error occurred for document \(document.id): \(error.localizedDescription)")
            }

            processedDocuments[document.id] = document // Final state update
        }

        /// Retrieves a document by its ID from the actor's isolated state.
        /// - Parameter id: The ID of the document.
        /// - Returns: The `Document` instance, or `nil` if not found.
        func getDocument(id: UUID) -> Document? {
            return processedDocuments[id]
        }

        /// Retrieves all currently managed documents.
        /// - Returns: An array of all `Document` instances.
        func getAllDocuments() -> [Document] {
            return Array(processedDocuments.values)
        }
    }
    