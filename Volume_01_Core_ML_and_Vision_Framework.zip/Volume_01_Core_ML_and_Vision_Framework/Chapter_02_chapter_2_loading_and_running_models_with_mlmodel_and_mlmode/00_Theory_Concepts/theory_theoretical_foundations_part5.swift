
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Foundation

// Define an actor to encapsulate model loading and prediction
@available(iOS 13.0, *)
actor ModelActor {
    private var model: MLModel?
    private let modelName: String
    private let modelConfiguration: MLModelConfiguration

    init(modelName: String, configuration: MLModelConfiguration = MLModelConfiguration()) {
        self.modelName = modelName
        self.modelConfiguration = configuration
    }

    // Internal method to load the model, ensuring it's only loaded once or safely reloaded.
    private func loadModel() throws -> MLModel {
        if let existingModel = model {
            return existingModel
        }

        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodelc") else {
            fatalError("Failed to find model bundle for \(modelName).mlmodelc")
        }
        let newModel = try MLModel(contentsOf: modelURL, configuration: modelConfiguration)
        self.model = newModel
        return newModel
    }

    // Public asynchronous method for prediction
    func predict(input: MLFeatureProvider) async throws -> MLFeatureProvider {
        let loadedModel = try loadModel() // Accessing internal state is safe within the actor

        // Prediction itself is often thread-safe for a given instance,
        // but encapsulating it within the actor ensures the model instance
        // is properly loaded and managed.
        return try await loadedModel.prediction(from: input)
    }
}

// Example usage:
@available(iOS 13.0, *)
func setupAndRunModelActor() async throws {
    let config = MLModelConfiguration()
    config.computeUnits = .all

    let classifierActor = ModelActor(modelName: "MyImageClassifier", configuration: config)

    // In a real app, you'd prepare a proper MLFeatureProvider.
    let dummyInput = try MLDictionaryFeatureProvider(dictionary: ["image": "dummy"]) // Placeholder

    // Multiple tasks can call predict, the actor will serialize access.
    let _ = await Task {
        try await classifierActor.predict(input: dummyInput)
    }.value

    let _ = await Task {
        try await classifierActor.predict(input: dummyInput)
    }.value
}
