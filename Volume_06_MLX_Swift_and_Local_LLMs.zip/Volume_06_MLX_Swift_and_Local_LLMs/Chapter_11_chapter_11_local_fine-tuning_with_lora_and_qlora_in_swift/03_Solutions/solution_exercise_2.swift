
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import MLX
import MLXNN
import MLXOptimizers
import Foundation

// MARK: - 1. QLoRALinear Module (Conceptually Quantized Base Weights)

@available(iOS 18.0, macOS 15.0, *)
final class QLoRALinear: MLXNN.Module {
    // In a true QLoRA setup, `baseLinear.weight` would be stored as a quantized MLXArray
    // (e.g., MLXArray<UInt8> for 4-bit quantization) and dequantized on-the-fly.
    // For this exercise, we keep it as a regular MLXNN.Linear for code simplicity,
    // but conceptually, its weights are treated as 'quantized and frozen'.
    let baseLinear: MLXNN.Linear
    let loraA: MLXNN.Linear // LoRA adapters remain in full precision (e.g., Float32)
    let loraB: MLXNN.Linear // LoRA adapters remain in full precision (e.g., Float32)
    let scale: Float

    init(inputFeatures: Int, outputFeatures: Int, rank: Int, scale: Float = 1.0) {
        // Initialize the base linear layer. Conceptually, its weights are quantized and frozen.
        self.baseLinear = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
        // LoRA adapters are initialized in full precision.
        self.loraA = MLXNN.Linear(inputFeatures: inputFeatures, outputFeatures: rank, bias: false)
        self.loraB = MLXNN.Linear(inputFeatures: rank, outputFeatures: outputFeatures, bias: false)
        self.scale = scale
        super.init()

        // Pedagogical Note:
        // In a full QLoRA implementation, `self.baseLinear.weight` would be replaced
        // with an MLXArray stored in a quantized data type (e.g., .uint8 or .int8).
        // The MLX framework provides `MLX.quantize` and `MLX.dequantize` functions
        // to handle the actual quantization and dequantization of weights.
        // During fine-tuning, these quantized weights are never updated.
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        // Conceptual Dequantization:
        // Here, `baseLinear(x)` implicitly represents the process where the
        // conceptually quantized `baseLinear.weight` is dequantized to full
        // precision (e.g., Float16/Float32) *just before* the matrix multiplication
        // with `x`. This dequantization happens on-the-fly and is optimized.
        let baseOutput = baseLinear(x)

        // LoRA adapters operate in full precision, as their weights are trained.
        let delta = loraB(loraA(x)) * scale
        return baseOutput + delta
    }

    // Still, only LoRA adapter parameters are exposed for training.
    override var parameters: [MLXArray] {
        return loraA.parameters + loraB.parameters
    }
}

// MARK: - 2. QLoRA-Adapted Classifier

@available(iOS 18.0, macOS 15.0, *)
final class QLoRASentimentClassifier: MLXNN.Module {
    let qloraLinear1: QLoRALinear
    let relu: MLXNN.ReLU
    let qloraLinear2: QLoRALinear

    init(inputFeatures: Int, hiddenFeatures: Int, outputFeatures: Int, rank: Int) {
        // Instantiate our QLoRALinear layers.
        self.qloraLinear1 = QLoRALinear(inputFeatures: inputFeatures, outputFeatures: hiddenFeatures, rank: rank)
        self.relu = MLXNN.ReLU()
        self.qloraLinear2 = QLoRALinear(inputFeatures: hiddenFeatures, outputFeatures: outputFeatures, rank: rank)
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        return qloraLinear2(relu(qloraLinear1(x)))
    }
}

// MARK: - Training Loop and Execution

@available(iOS 18.0, macOS 15.0, *)
func runExercise2() {
    let inputFeatures = 128
    let hiddenFeatures = 64
    let outputFeatures = 2
    let loraRank = 8
    let learningRate: Float = 1e-3
    let batchSize = 32
    let numSteps = 100

    // 1. Instantiate the QLoRA-adapted model
    let model = QLoRASentimentClassifier(
        inputFeatures: inputFeatures,
        hiddenFeatures: hiddenFeatures,
        outputFeatures: outputFeatures,
        rank: loraRank
    )

    // 2. Optimizer for LoRA parameters only
    let optimizer = MLXNN.Optimizers.AdamW(learningRate: learningRate)

    // 3. Training Loop
    print("Starting QLoRA fine-tuning...")
    for step in 0..<numSteps {
        // Generate synthetic data
        let x = MLXArray.randomUniform(low: 0, high: 1, [batchSize, inputFeatures])
        let y = MLXArray.randomUniform(low: 0, high: 2, [batchSize], type: .int32)

        let lossFn = { (model: QLoRASentimentClassifier, x: MLXArray, y: MLXArray) -> MLXArray in
            let logits = model(x)
            return MLXNN.Loss.crossEntropy(predictions: logits, targets: y)
        }

        let (loss, gradients) = MLX.valueAndGradient(model: model, lossFn, x, y)
        optimizer.update(model: model, gradients: gradients)

        let currentLoss = loss.item(Float.self)
        if step % 10 == 0 {
            print("Step \(step), Loss: \(currentLoss)")
        }
    }
    print("QLoRA fine-tuning complete.")

    // Conceptual discussion of memory benefits:
    print("\n--- Conceptual Memory Benefit of QLoRA ---")
    print("In this QLoRA setup, the base model's weights (e.g., within `qloraLinear1.baseLinear`) are conceptually stored in a quantized format (e.g., 4-bit integers like `UInt8`).")
    print("This means the vast majority of the model's parameters consume significantly less memory, typically 4x less than `Float32` and 2x less than `Float16`.")
    print("For instance, a 7B parameter model stored in 4-bit quantized format would occupy only ~3.5GB of RAM, compared to ~14GB for `Float32`.")
    print("Apple's Unified Memory allows the CPU and GPU to directly access this memory-efficient quantized data without costly transfers,")
    print("enabling much larger models to be loaded and fine-tuned on-device, even on devices with limited RAM.")
    print("The LoRA adapters (`loraA`, `loraB`) remain in full precision (`Float16` or `Float32`) and are trainable, ensuring high adaptation quality while being small enough not to negate the memory savings.")
    print("The dequantization happens on-the-fly during the forward pass, just before computation, without needing to store the full-precision weights permanently.")
    print("This makes QLoRA a powerful technique for local, private, and efficient fine-tuning of large models on Apple Silicon.")
}

// Call the function to run the exercise
// runExercise2()
