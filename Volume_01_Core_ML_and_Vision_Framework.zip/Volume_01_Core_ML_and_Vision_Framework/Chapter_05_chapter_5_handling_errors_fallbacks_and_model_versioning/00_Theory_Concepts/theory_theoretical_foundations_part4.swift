
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor ModelLoader {
    private var activeModel: MLModel?
    private var activeVisionModel: VNCoreMLModel?

    func loadAndConfigureModel(primaryURL: URL, fallbackURL: URL) async throws {
        let config = MLModelConfiguration()
        config.computeUnits = .all

        do {
            // Try loading primary model asynchronously
            let model = try await MLModel.load(contentsOf: primaryURL, configuration: config)
            self.activeModel = model
            self.activeVisionModel = try VNCoreMLModel(for: model)
            print("Primary model loaded via async/await.")
        } catch {
            print("Primary model failed, attempting fallback: \(error.localizedDescription)")
            do {
                // If primary fails, try fallback
                let fallbackModel = try await MLModel.load(contentsOf: fallbackURL, configuration: config)
                self.activeModel = fallbackModel
                self.activeVisionModel = try VNCoreMLModel(for: fallbackModel)
                print("Fallback model loaded via async/await.")
            } catch {
                print("Both primary and fallback models failed: \(error.localizedDescription)")
                throw CoreMLError.modelLoadingFailed
            }
        }
    }

    func performInference(pixelBuffer: CVPixelBuffer) async throws -> [VNClassificationObservation] {
        guard let visionModel = activeVisionModel else {
            throw CoreMLError.predictionFailed // Model not loaded
        }
        // Offload Vision request to a background queue to not block the actor or main thread
        return try await Task.detached {
            let request = VNCoreMLRequest(model: visionModel)
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            try handler.perform([request])
            guard let observations = request.results as? [VNClassificationObservation] else {
                throw VisionError.requestFailed
            }
            return observations
        }.value
    }
}
