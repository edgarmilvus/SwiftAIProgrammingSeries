
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

/// Represents the various failure modes of an AI-powered application.
/// Conforms to Sendable to ensure safe transfer across concurrency boundaries.
enum AIError: Error, Sendable {
    case inferenceTimeout(duration: TimeInterval)
    case guardrailViolation(reason: String)
    case modelMemoryExhaustion
    case semanticDrift(confidenceScore: Double)
}

/// The health status of the AI engine, observable by the UI.
@Observable
final class AIHealthMonitor {
    var currentStatus: HealthStatus = .healthy
    var lastError: AIError?
    
    enum HealthStatus {
        case healthy
        case degraded
        case critical
    }
}

/// The TelemetryActor is the central, isolated authority for all error reporting.
/// It prevents data races when multiple concurrent inference tasks fail.
actor TelemetryActor {
    private var errorLog: [AIError] = []
    private let maxLogSize = 100
    
    /// Records an error and returns true if the error rate exceeds a threshold.
    /// This allows the app to trigger a "degraded" state.
    func record(_ error: AIError) -> Bool {
        errorLog.append(error)
        if errorLog.count > maxLogSize {
            errorLog.removeFirst()
        }
        
        // Logic to determine if the error rate is too high
        return checkThreshold()
    }
    
    private func checkThreshold() -> Bool {
        // In a real implementation, this would analyze the frequency of errors
        // within a specific time window (e.g., sliding window algorithm).
        return errorLog.count > 10 
    }
    
    func getLogs() -> [AIError] {
        return errorLog
    }
}

/// A high-level manager that coordinates between the Actor (data) 
/// and the @Observable class (UI).
@available(iOS 18.0, *)
@MainActor
final class AIServiceManager {
    private let telemetry = TelemetryActor()
    private let healthMonitor = AIHealthMonitor()
    
    // Expose the monitor for SwiftUI views to observe
    var healthMonitor: AIHealthMonitor { healthMonitor }
    
    /// Performs inference with integrated monitoring.
    func performInference(prompt: String) async throws -> String {
        do {
            // Simulate inference logic
            return try await simulateInference(prompt: prompt)
        } catch let error as AIError {
            // 1. Record the error in the isolated Actor
            let isThresholdExceeded = await telemetry.record(error)
            
            // 2. Update the Observable state on the MainActor for the UI
            healthMonitor.lastError = error
            if isThresholdExceeded {
                healthMonitor.currentStatus = .degraded
            }
            
            throw error
        } catch {
            // Handle non-AI specific errors
            throw error
        }
    }
    
    private func simulateInference(prompt: String) async throws -> String {
        // Simulate a potential timeout or guardrail violation
        try await Task.sleep(for: .seconds(1))
        
        if prompt.contains("malicious") {
            throw AIError.guardrailViolation(reason: "Safety filter triggered")
        }
        
        return "Generated response for: \(prompt)"
    }
}
