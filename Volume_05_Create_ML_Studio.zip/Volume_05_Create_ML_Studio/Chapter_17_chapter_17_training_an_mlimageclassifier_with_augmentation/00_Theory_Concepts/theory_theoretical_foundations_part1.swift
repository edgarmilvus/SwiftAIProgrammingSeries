
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    import CreateML
    import Foundation

    @available(iOS 18.0, macOS 15.0, *) // Create ML features often align with OS releases
    class ImageClassifierTrainer {
        enum TrainingError: Error {
            case invalidDataSource
            case trainingFailed(String)
            case modelExportFailed(String)
        }

        func trainModel(from trainingDataURL: URL, validationDataURL: URL? = nil, parameters: MLImageClassifier.ModelParameters) async throws -> MLImageClassifier {
            // This entire process can be long-running and should be offloaded.
            // async/await makes this sequence clear and non-blocking.
            print("Starting image classifier training...")

            guard trainingDataURL.isFileURL else {
                throw TrainingError.invalidDataSource
            }

            do {
                // Load training data - potentially a long I/O operation
                let trainingData = try await MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)
                let validationData: MLImageClassifier.DataSource?
                if let validationURL = validationDataURL {
                    validationData = try await MLImageClassifier.DataSource.labeledDirectories(at: validationURL)
                } else {
                    validationData = nil // Create ML will automatically split if no validation data is provided
                }

                // Initialize and train the classifier
                // The 'progressHandler' closure is where we'd typically update UI via @MainActor
                let classifier = try await MLImageClassifier(
                    trainingData: trainingData,
                    parameters: parameters,
                    progressHandler: { progress in
                        // This closure might be called on a background thread by Create ML.
                        // If updating UI, it must dispatch to @MainActor.
                        Task { @MainActor in
                            print("Training Progress: \(progress.fractionCompleted * 100)%")
                            // Update an @Observable model here
                        }
                    }
                )

                print("Training completed. Evaluating model...")
                let evaluation = classifier.evaluation(on: trainingData) // Evaluate on training data for example
                print("Model accuracy: \(evaluation.accuracy)")

                return classifier

            } catch let error as MLImageClassifier.TrainingError {
                throw TrainingError.trainingFailed("Create ML Training Error: \(error.localizedDescription)")
            } catch {
                throw TrainingError.trainingFailed("An unexpected error occurred during training: \(error.localizedDescription)")
            }
        }

        func exportModel(_ model: MLImageClassifier, to destinationURL: URL) async throws {
            print("Exporting model...")
            do {
                try await model.write(to: destinationURL)
                print("Model exported successfully to \(destinationURL.path)")
            } catch {
                throw TrainingError.modelExportFailed("Failed to export model: \(error.localizedDescription)")
            }
        }
    }

    // Example usage in a SwiftUI View or ViewModel
    /*
    @available(iOS 18.0, macOS 15.0, *)
    func startTraining() async {
        let trainer = ImageClassifierTrainer()
        let trainingDataURL = URL(fileURLWithPath: "/path/to/my/training/data")
        let outputModelURL = URL(fileURLWithPath: "/path/to/save/my/model.mlmodel")

        let params = MLImageClassifier.ModelParameters(
            maxIterations: 20,
            augmentation: .all, // Using all available augmentations
            validationDataCollection: .automatic
        )

        do {
            let trainedModel = try await trainer.trainModel(from: trainingDataURL, parameters: params)
            try await trainer.exportModel(trainedModel, to: outputModelURL)
        } catch {
            print("Training failed: \(error)")
        }
    }
    */
    