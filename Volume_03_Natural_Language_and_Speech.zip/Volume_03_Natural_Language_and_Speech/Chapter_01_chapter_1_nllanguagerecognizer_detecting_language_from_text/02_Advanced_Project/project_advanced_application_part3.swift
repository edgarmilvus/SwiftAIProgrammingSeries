
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

/// A service responsible for detecting the dominant language of chat messages.
@available(iOS 18.0, *) // Marking for modern Swift concurrency context
class LanguageDetectionService {

    private let recognizer: NLLanguageRecognizer

    /// Initializes the language detection service.
    init() {
        self.recognizer = NLLanguageRecognizer()
    }

    /// Detects the dominant language for a given text.
    ///
    /// - Parameter text: The input string for language recognition.
    /// - Returns: The detected NLLanguage.
    /// - Throws: `ChatLanguageError` if the text is empty or recognition fails.
    private func detectDominantLanguage(for text: String) async throws -> NLLanguage? {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw ChatLanguageError.emptyMessage
        }

        // NLLanguageRecognizer is generally fast, but for very long texts or
        // a large batch, it's good practice to make it async.
        // It returns nil if no dominant language can be determined.
        return await Task {
            self.recognizer.processString(text)
            // We can also get confidence scores for multiple languages if needed:
            // let hypotheses = self.recognizer.languageHypotheses(withMaximum: 3)
            // For this example, we stick to the dominant one.
            return self.recognizer.dominantLanguage
        }.value
    }

    /// Processes an array of chat messages concurrently to detect their languages.
    ///
    /// This method uses `TaskGroup` to efficiently run multiple language detection tasks
    /// in parallel, improving performance for batches of messages.
    ///
    /// - Parameter messages: An array of `ChatMessage` objects to process.
    /// - Returns: An array of `RecognizedChatMessage` objects with detected languages.
    func processMessages(_ messages: [ChatMessage]) async -> [RecognizedChatMessage] {
        guard !messages.isEmpty else { return [] }

        var recognizedMessages: [RecognizedChatMessage] = []

        // Use a TaskGroup to process messages concurrently.
        // This is crucial for performance when dealing with many messages,
        // as language recognition, though fast, can add up.
        await withTaskGroup(of: (UUID, NLLanguage?, Double?).self) { group in
            for message in messages {
                group.addTask {
                    do {
                        // The NLLanguageRecognizer instance is NOT thread-safe for concurrent modification
                        // (e.g., calling processString on the same instance from multiple threads simultaneously).
                        // However, creating a new NLLanguageRecognizer for each task or using a thread-local
                        // instance is a common pattern. For short-lived tasks like this, the overhead of
                        // creating a new recognizer per task is minimal and ensures thread safety.
                        let taskRecognizer = NLLanguageRecognizer()
                        taskRecognizer.processString(message.text)
                        
                        // For dominantLanguage, confidence is implicitly high if one is returned.
                        // For more granular confidence, one would use languageHypotheses.
                        let dominantLanguage = taskRecognizer.dominantLanguage
                        
                        // If we wanted a confidence score for the dominant language, it's not directly
                        // exposed by `dominantLanguage`. We'd have to get all hypotheses and filter.
                        // For simplicity, we'll assume a high confidence if a language is found.
                        // Let's simulate a confidence score for demonstration purposes.
                        let confidence = (dominantLanguage != nil && !message.text.isEmpty) ? 0.95 : nil
                        
                        return (message.id, dominantLanguage, confidence)
                    } catch {
                        print("Error detecting language for message ID \(message.id): \(error.localizedDescription)")
                        return (message.id, nil, nil) // Return nil language on error
                    }
                }
            }

            // Collect results as they complete
            var results: [UUID: (NLLanguage?, Double?)] = [:]
            for await (id, language, confidence) in group {
                results[id] = (language, confidence)
            }

            // Reconstruct the ordered list of recognized messages
            for message in messages {
                if let (language, confidence) = results[message.id] {
                    recognizedMessages.append(RecognizedChatMessage(from: message, recognizedLanguage: language, confidenceScore: confidence))
                } else {
                    // Fallback if a task somehow failed to return a result (unlikely with current implementation)
                    recognizedMessages.append(RecognizedChatMessage(from: message, recognizedLanguage: nil, confidenceScore: nil))
                }
            }
        }
        return recognizedMessages
    }
}
