
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import RealityKit
import ARKit
import simd

class AccessoryManager {
    private var watchEntity: ModelEntity?
    private let wristOffset = simd_float3(0, 0.05, 0) // Shift slightly up the arm

    func loadAccessory() async throws {
        // Load a simple cylinder to represent a watch
        let mesh = MeshResource.generateCylinder(height: 0.02, radius: 0.015)
        let material = SimpleMaterial(color: .gold, isMetallic: true)
        watchEntity = ModelEntity(mesh: mesh, materials: [material])
    }

    @MainActor
    func updateAccessoryTransform(anchor: ARBodyAnchor, in scene: Scene) {
        guard let watch = watchEntity else { return }
        
        // 1. Get the specific joint transform (contains position AND rotation)
        guard let wristTransform = anchor.skeleton.modelTransform(for: .leftWrist) else { return }
        
        // 2. Convert to world space
        let worldWristTransform = anchor.transform * wristTransform
        
        // 3. Apply the transform to the watch
        // We use the full 4x4 matrix to preserve the orientation (quaternion)
        watch.transform = Transform(matrix: worldWristTransform)
        
        // 4. Apply Offset
        // We must transform the offset by the wrist's rotation so it moves WITH the arm
        let rotationMatrix = simd_matrix3x3(worldWristTransform)
        let rotatedOffset = rotationMatrix * wristOffset
        watch.position += rotatedOffset
    }
}
