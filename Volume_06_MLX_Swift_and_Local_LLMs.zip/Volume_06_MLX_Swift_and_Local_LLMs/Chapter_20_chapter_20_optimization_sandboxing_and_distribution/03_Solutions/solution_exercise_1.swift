
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import MLX
import MLXNN
import CoreGraphics
import Foundation // For URL, Data

@available(iOS 18.0, macOS 14.0, *)
final class MyPlaceholderClassifier: MLXNN.Module {
    let conv1: MLXNN.Conv2d
    let linearOut: MLXNN.Linear
    let numClasses: Int

    init(inputChannels: Int = 3, targetImageSize: Int = 224, numClasses: Int = 1000) {
        self.numClasses = numClasses
        // Simulate a simple feature extractor
        // Input: [batch, H, W, C] -> Output: [batch, C', H', W']
        self.conv1 = MLXNN.Conv2d(inputChannels, 64, kernelSize: 3, padding: 1, channelLast: true)
        // After convolution, flatten and project to num_classes
        // Assuming a single conv layer that might reduce dimensions or keep them,
        // then flatten. For simplicity, we'll assume the output of conv1
        // can be flattened to a fixed size for the linear layer.
        // A more realistic model would have pooling layers.
        // Here, we'll just project from a dummy flattened size.
        let dummyFlattenedSize = 64 * (targetImageSize / 2) * (targetImageSize / 2) // Example if we had a pooling layer
        self.linearOut = MLXNN.Linear(64 * targetImageSize * targetImageSize, numClasses) // Simplified: direct flatten after conv
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Input: [batch_size, height, width, channels]
        var x = MLX.relu(conv1(input))
        // Flatten for the linear layer. MLXArray.flatten() flattens from the first non-batch dimension.
        // If input is [B, H, W, C], flatten() makes [B, H*W*C]
        x = x.flatten(start: 1) // Flatten all dimensions after batch
        let logits = linearOut(x)
        return logits // [batch_size, num_classes]
    }
}

@available(iOS 18.0, macOS 14.0, *)
class ImageClassifierService {
    private let model: MyPlaceholderClassifier
    private let targetImageSize: Int = 224
    private let means: [Float] = [0.485, 0.456, 0.406] // ImageNet means
    private let stds: [Float] = [0.229, 0.224, 0.225]   // ImageNet stds

    init() {
        self.model = MyPlaceholderClassifier(targetImageSize: targetImageSize)
        // In a real scenario, model weights would be loaded here:
        // let weights = try! MLX.load(url: Bundle.main.url(forResource: "my_model", withExtension: "safetensors")!)
        // model.update(parameters: weights)
    }

    /// Converts a CGImage to an MLXArray, preprocesses it, and performs inference.
    /// - Parameter image: The CGImage to process. Assumed to be already resized to targetImageSize x targetImageSize.
    /// - Returns: An MLXArray containing the raw output logits from the model.
    func preprocessAndInfer(image: CGImage) throws -> MLXArray {
        // 1. Convert CGImage to raw pixel data (Float, normalized 0-1)
        guard let pixelData = image.toPixelData(targetWidth: targetImageSize, targetHeight: targetImageSize) else {
            throw ImageProcessingError.pixelDataConversionFailed
        }

        // 2. Convert pixel data into an MLXArray
        // Shape: [height, width, channels]
        let imageArray = MLXArray(
            pixelData,
            shape: [targetImageSize, targetImageSize, 3],
            type: .float32
        )

        // 3. Apply channel-wise normalization (mean/std)
        // The MLXArray needs to be broadcastable with mean/std arrays.
        // Reshape means/stds to [1, 1, 3] for broadcastable subtraction/division.
        let meanArray = MLXArray(means, shape: [1, 1, 3], type: .float32)
        let stdArray = MLXArray(stds, shape: [1, 1, 3], type: .float32)

        let normalizedImage = (imageArray - meanArray) / stdArray

        // 4. Add batch dimension: [1, height, width, channels]
        let batchedImage = normalizedImage.expandedDimensions(axis: 0)

        // 5. Perform inference using the model
        let logits = model(batchedImage)

        // 6. Force computation and return the output logits
        MLX.eval(logits)
        return logits
    }
}

// MARK: - Helper for CGImage to Pixel Data Conversion

enum ImageProcessingError: Error, LocalizedError {
    case pixelDataConversionFailed
    case unsupportedImageFormat(String)
    case imageResizingRequired(String)

    var errorDescription: String? {
        switch self {
        case .pixelDataConversionFailed: return "Failed to convert CGImage to pixel data."
        case .unsupportedImageFormat(let msg): return "Unsupported image format: \(msg)"
        case .imageResizingRequired(let msg): return "Image resizing is required: \(msg)"
        }
    }
}

@available(iOS 18.0, macOS 14.0, *)
extension CGImage {
    /// Extracts pixel data from a CGImage, converts to Float, and normalizes to [0, 1].
    /// This function assumes the CGImage is already the `targetWidth` x `targetHeight`.
    /// In a real application, you would use `CoreGraphics` or `vImage` for resizing.
    func toPixelData(targetWidth: Int, targetHeight: Int) -> [Float]? {
        guard let dataProvider = dataProvider, let data = dataProvider.data else { return nil }
        let pixelData = CFDataGetBytePtr(data)

        let bytesPerPixel = bitsPerPixel / 8
        let bytesPerRow = bytesPerRow
        let width = self.width
        let height = self.height

        guard width == targetWidth && height == targetHeight else {
            // In a real app, you'd resize here. For this exercise, we assume it's pre-resized.
            print("Warning: CGImage size (\(width)x\(height)) does not match target size (\(targetWidth)x\(targetHeight)). Assuming pre-resized input for MLX conversion.")
            // throw ImageProcessingError.imageResizingRequired("Expected \(targetWidth)x\(targetHeight), got \(width)x\(height).")
        }

        // We expect an RGBA or ARGB format, 8 bits per component.
        // For simplicity, we'll extract RGB and convert to Float [0, 1].
        // This handles cases where the image might be grayscale or other formats
        // by just taking the first 3 components if available.
        // A robust solution would check bitmapInfo and colorSpace.
        guard bitsPerComponent == 8 else {
            print("Unsupported image format: Expected 8-bit components.")
            return nil
        }

        var floatPixels = [Float](repeating: 0, count: targetWidth * targetHeight * 3) // RGB

        for y in 0..<targetHeight {
            for x in 0..<targetWidth {
                let pixelOffset = y * bytesPerRow + x * bytesPerPixel
                let r = Float(pixelData[pixelOffset]) / 255.0
                let g = Float(pixelData[pixelOffset + 1]) / 255.0
                let b = Float(pixelData[pixelOffset + 2]) / 255.0

                let outputIndex = (y * targetWidth + x) * 3
                floatPixels[outputIndex] = r
                floatPixels[outputIndex + 1] = g
                floatPixels[outputIndex + 2] = b
            }
        }
        return floatPixels
    }
}

// Example Usage (requires a CGImage, e.g., from UIImage/NSImage in a real app)
/*
#if canImport(AppKit)
import AppKit // For NSImage
#elseif canImport(UIKit)
import UIKit // For UIImage
#endif

@available(iOS 18.0, macOS 14.0, *)
func runImageClassificationExample() {
    // Create a dummy CGImage (e.g., a solid color image)
    let width = 224
    let height = 224
    let bytesPerPixel = 4 // RGBA
    let bytesPerRow = width * bytesPerPixel
    let colorSpace = CGColorSpaceCreateDeviceRGB()
    var rawData = [UInt8](repeating: 0, count: height * bytesPerRow)

    // Fill with a red color for demonstration
    for y in 0..<height {
        for x in 0..<width {
            let offset = (y * bytesPerRow) + x * bytesPerPixel
            rawData[offset] = 255   // R
            rawData[offset + 1] = 0 // G
            rawData[offset + 2] = 0 // B
            rawData[offset + 3] = 255 // A
        }
    }

    guard let data = CFDataCreate(nil, rawData, rawData.count) else {
        print("Failed to create CFData for dummy image.")
        return
    }

    guard let dataProvider = CGDataProvider(data: data) else {
        print("Failed to create CGDataProvider for dummy image.")
        return
    }

    guard let dummyCGImage = CGImage(
        width: width,
        height: height,
        bitsPerComponent: 8,
        bitsPerPixel: 32,
        bytesPerRow: bytesPerRow,
        space: colorSpace,
        bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
        provider: dataProvider,
        decode: nil,
        shouldInterpolate: true,
        intent: .defaultIntent
    ) else {
        print("Failed to create dummy CGImage.")
        return
    }

    let service = ImageClassifierService()
    do {
        let logits = try service.preprocessAndInfer(image: dummyCGImage)
        print("Inference successful. Output logits shape: \(logits.shape)")
        // print("Sample logits: \(logits.flatten().data(as: Float.self)!.prefix(5))")
    } catch {
        print("Error during image inference: \(error.localizedDescription)")
    }
}

// Call the example function if you're in an environment that supports it
// runImageClassificationExample()
*/
