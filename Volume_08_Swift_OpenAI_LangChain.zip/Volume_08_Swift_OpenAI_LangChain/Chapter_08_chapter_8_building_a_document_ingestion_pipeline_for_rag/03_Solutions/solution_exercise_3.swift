
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct RecursiveTextSplitter: Sendable {
    let separators: [String] = ["\n\n", "\n", " ", ""]
    let maxChunkSize: Int
    let overlap: Int

    init(maxChunkSize: Int, overlap: Int) {
        self.maxChunkSize = maxChunkSize
        self.overlap = overlap
    }

    func split(text: String) async -> [String] {
        // Step 1: Perform the recursive hierarchical splitting
        let baseChunks = recursiveSplit(text: text, separatorIndex: 0)
        
        // Step 2: Apply the overlap logic to the resulting atomic chunks
        return applyOverlap(to: baseChunks)
    }

    private func recursiveSplit(text: String, separatorIndex: Int) -> [String] {
        // Base case: text is already small enough
        if text.count <= maxChunkSize {
            return [text]
        }
        
        // Base case: we've run out of separators, must split by character
        guard separatorIndex < separators.count else {
            return [String(text.prefix(maxChunkSize))]
        }
        
        let separator = separators[separatorIndex]
        
        // If separator is empty, we can't split by it
        if separator.isEmpty {
            return [text]
        }
        
        // Split the text by the current separator
        // Note: This is a simplified split. In production, we'd use a more 
        // sophisticated regex to keep the separators or handle edge cases.
        let parts = text.components(separatedBy: separator)
        var result: [String] = []
        
        for part in parts {
            if part.count <= maxChunkSize {
                result.append(part)
            } else {
                // Recursively split this part with the NEXT separator in the hierarchy
                let subChunks = recursiveSplit(text: part, separatorIndex: separatorIndex + 1)
                result.append(contentsOf: subChunks)
            }
        }
        
        // Re-insert separators if they weren't the empty string
        // (This is a simplification for the exercise logic)
        return result.filter { !$0.isEmpty }
    }

    private func applyOverlap(to chunks: [String]) -> [String] {
        guard chunks.count > 1 else { return chunks }
        var enrichedChunks: [String] = []
        
        for i in 0..<chunks.count {
            var currentChunk = chunks[i]
            
            // If not the first chunk, prepend the overlap from the previous chunk
            if i > 0 {
                let previousChunk = chunks[i-1]
                let overlapSize = min(overlap, previousChunk.count)
                let overlapText = String(previousChunk.suffix(overlapSize))
                currentChunk = overlapText + " " + currentChunk
            }
            
            enrichedChunks.append(currentChunk)
        }
        
        return enrichedChunks
    }
}
