
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import RealityKit
    import CoreML // Assuming Core ML inference results

    // Represents a bounding box and confidence from an object detection model
    struct ObjectDetectionComponent: Component, Codable {
        var boundingBox: SIMD4<Float> // x, y, width, height (normalized or scene-relative)
        var label: String
        var confidence: Float
        var timestamp: TimeInterval // When the detection occurred

        init(boundingBox: SIMD4<Float>, label: String, confidence: Float) {
            self.boundingBox = boundingBox
            self.label = label
            self.confidence = confidence
            self.timestamp = Date().timeIntervalSince1970
        }
    }

    // Represents the estimated pose of a detected human
    struct HumanPoseComponent: Component, Codable {
        // Example: Array of 2D or 3D joint positions
        var jointPositions: [String: SIMD3<Float>]
        var confidence: Float
        var timestamp: TimeInterval

        init(jointPositions: [String : SIMD3<Float>], confidence: Float) {
            self.jointPositions = jointPositions
            self.confidence = confidence
            self.timestamp = Date().timeIntervalSince1970
        }
    }

    @available(iOS 18.0, *)
    func attachAIComponents(to entity: Entity, detection: ObjectDetectionComponent, pose: HumanPoseComponent? = nil) {
        entity.components.set(detection)
        if let pose = pose {
            entity.components.set(pose)
        }
    }
    