
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
actor ModelConversionManager {
    private var currentProgress: Double = 0.0
    private var statusMessage: String = "Idle"
    private var convertedModels: [String: [String: MLXArray]] = [:] // Cache

    let portingService = WeightPortingService()

    func getProgress() -> Double { currentProgress }
    func getStatus() -> String { statusMessage }

    private func update(progress: Double, status: String) {
        self.currentProgress = progress
        self.statusMessage = status
        print("Manager Status: \(status) - Progress: \(Int(progress * 100))%")
    }

    func convertAndCacheModel(modelName: String, sourceURL: URL) async throws -> [String: MLXArray] {
        if let cached = convertedModels[modelName] {
            await update(progress: 1.0, status: "\(modelName) loaded from cache.")
            return cached
        }

        await update(progress: 0.1, status: "Downloading \(modelName)...")
        let rawData = try await portingService.downloadWeights(from: sourceURL)

        await update(progress: 0.5, status: "Converting \(modelName) weights...")
        let mlxWeights = try await portingService.convertHuggingFaceWeightsToMLX(data: rawData)

        await update(progress: 0.9, status: "Saving \(modelName) to cache...")
        convertedModels[modelName] = mlxWeights // Store in actor's isolated state
        // In a real app, you might also save to disk here.

        await update(progress: 1.0, status: "\(modelName) conversion complete and cached.")
        return mlxWeights
    }
}
