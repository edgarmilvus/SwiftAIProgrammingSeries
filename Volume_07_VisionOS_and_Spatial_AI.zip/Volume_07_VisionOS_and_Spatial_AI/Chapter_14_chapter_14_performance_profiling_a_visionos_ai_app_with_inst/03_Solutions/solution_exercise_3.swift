
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import CoreML
import Vision

@available(visionOS 1.0, *)
class GestureRecognitionService {
    var model: VNCoreMLModel?

    init() {
        // --- THE FLAW: Default/GPU Configuration ---
        // Using .all allows the system to pick the GPU, which causes 
        // contention with RealityKit's rendering loop.
        let config = MLModelConfiguration()
        config.computeUnits = .all // Change this to .cpuAndNeuralEngine for the fix
        
        // Mock loading logic (In a real app, you'd load your actual .mlmodel)
        do {
            // For the sake of this exercise, we assume 'HandGestureModel' exists
            // let model = try HandGestureModel(configuration: config)
            // self.model = try VNCoreMLModel(for: model.model)
            print("Model loaded with compute units: \(config.computeUnits.rawValue)")
        } catch {
            print("Failed to load model: \(error)")
        }
    }
    
    func performInference() {
        // Simulate high-frequency inference
        // In a real app, this would be called inside a SceneUpdate loop
    }
}

@available(visionOS 1.0, *)
struct GestureControlView: View {
    @State private var service = GestureRecognitionService()
    @State private var rotation: Float = 0

    var body: some View {
        RealityView { content in
            let box = ModelEntity(mesh: .generateBox(size: 0.3), materials: [SimpleMaterial(color: .orange, isMetallic: true)])
            box.name = "spinner"
            content.add(box)
        }
        .onAppear {
            // High-frequency "Inference" simulation
            Timer.scheduledTimer(withTimeInterval: 0.016, repeats: true) { _ in
                service.performInference()
                rotation += 0.05
            }
        }
        // Visual "Frame Rate Monitor": A rotating box
        // If the GPU is busy with AI, this rotation will stutter.
    }
}
