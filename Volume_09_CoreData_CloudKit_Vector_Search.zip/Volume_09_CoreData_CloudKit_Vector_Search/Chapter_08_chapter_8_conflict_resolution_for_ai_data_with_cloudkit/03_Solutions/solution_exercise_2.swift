
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CloudKit
import Foundation

/// Manages chat synchronization and conflict resolution.
/// Using an actor ensures that multiple sync attempts are serialized.
actor ChatSyncService {
    
    enum SyncError: Error {
        case conflictDetected
    }

    /// Simulates a CloudKit upload that fails due to a version mismatch.
    func performSync(clientRecord: CKRecord) async throws {
        print("Attempting to sync record: \(clientRecord.recordID)")
        
        // Simulate a scenario where the server has changed since we last fetched
        // In a real app, this error is caught in the catch block of a CKModifyRecordsOperation
        let mockError = simulateServerConflictError(clientRecord: clientRecord)
        
        if let error = mockError as? CKError, error.code == .serverRecordChanged {
            print("Conflict detected! Initiating three-way merge...")
            try await resolveConflict(error: error)
        } else {
            print("Sync successful.")
        }
    }

    private func resolveConflict(error: CKError) async throws {
        // Extract the triad from the error userInfo
        guard let ancestor = error.userInfo[CKRecordChangedErrorAncestorRecordKey] as? CKRecord,
              let server = error.userInfo[CKRecordChangedErrorServerRecordKey] as? CKRecord,
              let client = error.userInfo[CKRecordChangedErrorClientRecordKey] as? CKRecord else {
            throw error
        }

        let resolvedRecord = resolveChatConflict(ancestor: ancestor, server: server, client: client)
        
        // In a real implementation, you would now attempt to re-upload the 'resolvedRecord'
        print("Resolved Record Text: \(resolvedRecord["messageText"] as? String ?? "")")
    }

    /// The Three-Way Merge Engine
    private func resolveChatConflict(ancestor: CKRecord, server: CKRecord, client: CKRecord) -> CKRecord {
        // Handle Deletion: If the server record was deleted, respect the deletion.
        // (Note: In actual CloudKit, a deleted record might be represented by the absence of the record)
        
        let resolvedRecord = server.copy() as! CKRecord
        let ancestorText = ancestor["messageText"] as? String ?? ""
        let serverText = server["messageText"] as? String ?? ""
        let clientText = client["messageText"] as? String ?? ""

        // Check if client changed the text relative to the ancestor
        let clientChanged = clientText != ancestorText
        // Check if server changed the text relative to the ancestor
        let serverChanged = serverText != ancestorText

        if clientChanged && !serverChanged {
            // Client made a change, server did not. Apply client change.
            resolvedRecord["messageText"] = clientText
        } else if clientChanged && serverChanged {
            // BOTH changed. Implement "Text Append" strategy to preserve context.
            // We treat empty strings as valid changes (not just nil).
            let mergedText = "\(serverText)\n[Conflict Resolved]: \(clientText)"
            resolvedRecord["messageText"] = mergedText
        } else {
            // Neither changed or only server changed (already handled by using server as base)
            resolvedRecord["messageText"] = serverText
        }

        return resolvedRecord
    }

    // MARK: - Mocking Helpers
    private func simulateServerConflictError(clientRecord: CKRecord) -> Error? {
        let ancestor = CKRecord(recordType: "ChatMessage")
        ancestor["messageText"] = "Hello"
        
        let server = CKRecord(recordType: "ChatMessage")
        server["messageText"] = "Hello from iPad"
        
        let client = CKRecord(recordType: "ChatMessage")
        client["messageText"] = "Hello from iPhone"
        
        let userInfo: [AnyHashable: Any] = [
            CKRecordChangedErrorAncestorRecordKey: ancestor,
            CKRecordChangedErrorServerRecordKey: server,
            CKRecordChangedErrorClientRecordKey: client
        ]
        
        return CKError(.serverRecordChanged, userInfo: userInfo)
    }
}
