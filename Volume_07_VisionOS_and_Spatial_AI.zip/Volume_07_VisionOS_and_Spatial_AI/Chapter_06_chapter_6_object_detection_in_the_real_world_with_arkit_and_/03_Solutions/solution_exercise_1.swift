
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import Vision
import CoreML
import CoreVideo

/// Represents a detected object with its metadata.
struct DetectionResult: Sendable {
    let label: String
    let confidence: Float
    /// Bounding box in UIKit coordinates (top-left origin, 0.0 to 1.0)
    let boundingBox: CGRect
}

/// An actor to ensure thread-safe processing of vision requests.
actor ObjectDetectionEngine {
    private var detectionRequest: VNCoreMLRequest?
    
    init(model: VNCoreMLModel) throws {
        // Initialize the request with the provided model
        self.detectionRequest = VNCoreMLRequest(model: model)
        self.detectionRequest?.imageCropAndScaleOption = .scaleFill
    }
    
    /// Performs inference on a pixel buffer.
    /// - Parameter pixelBuffer: The camera frame.
    /// - Returns: An array of detected objects.
    func detect(in pixelBuffer: CVPixelBuffer) async throws -> [DetectionResult] {
        guard let request = detectionRequest else {
            throw NSError(domain: "ObjectDetectionEngine", code: 1, userInfo: [NSLocalizedDescriptionKey: "Request not initialized"])
        }
        
        return try await withCheckedThrowingContinuation { continuation in
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            
            do {
                try handler.perform([request])
                
                // Extract observations from the request
                let observations = request.results as? [VNRecognizedObjectObservation] ?? []
                
                let results = observations.map { observation in
                    // Vision uses bottom-left origin. 
                    // We convert to top-left (UIKit/SwiftUI) origin.
                    let visionBox = observation.boundingBox
                    let convertedBox = CGRect(
                        x: visionBox.origin.x,
                        y: 1.0 - (visionBox.origin.y + visionBox.size.height),
                        width: visionBox.size.width,
                        height: visionBox.size.height
                    )
                    
                    let topLabel = observation.labels.first?.identifier ?? "Unknown"
                    let confidence = observation.labels.first?.confidence ?? 0.0
                    
                    return DetectionResult(
                        label: topLabel,
                        confidence: confidence,
                        boundingBox: convertedBox
                    )
                }
                
                continuation.resume(returning: results)
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
}
