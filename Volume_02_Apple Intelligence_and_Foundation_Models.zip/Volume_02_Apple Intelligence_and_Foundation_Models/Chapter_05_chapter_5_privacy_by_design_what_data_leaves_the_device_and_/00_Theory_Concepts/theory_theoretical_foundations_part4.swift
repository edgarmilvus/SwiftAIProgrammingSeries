
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation

// A struct representing a user's query with additional context.
// By being a value type with Sendable properties, it is implicitly Sendable.
// If it contained reference types, those would also need to be Sendable or protected.
struct AIQueryContext: Sendable {
    let rawPrompt: String
    let documentID: UUID? // Contextual ID, not necessarily sensitive itself
    let userLocale: Locale

    // Example of a sensitive field that might need special handling or redaction
    // before being sent off-device, even if the struct itself is Sendable.
    var sensitiveMetadata: String? = nil

    // A method to create a privacy-preserving version for potential PCC transfer
    func forPrivateCloudCompute() -> AIQueryContext {
        // Redact or remove highly sensitive data that isn't strictly necessary for PCC.
        // The Intelligence framework handles the actual encryption, but the app
        // can perform initial sanitization.
        var pccContext = self
        pccContext.sensitiveMetadata = nil // Example: remove sensitive app-specific metadata
        return pccContext
    }
}

@available(iOS 18.0, *)
actor DataIngestor {
    func acceptQuery(_ query: AIQueryContext) async {
        // The query is Sendable, so it can be safely passed to this actor.
        print("Received query for processing: \(query.rawPrompt.prefix(30))...")

        // Decide if PCC is needed based on query complexity or other factors
        let requiresPCC = query.rawPrompt.count > 1000

        if requiresPCC {
            let pccSafeQuery = query.forPrivateCloudCompute()
            // Here, the Intelligence framework would take `pccSafeQuery`
            // and handle its secure, encrypted transmission to PCC.
            print("Preparing PCC-safe query: \(pccSafeQuery.rawPrompt.prefix(30))...")
            // Simulate PCC processing
            try? await Task.sleep(for: .seconds(1))
            print("PCC processing simulated for complex query.")
        } else {
            // Process on-device
            print("Processing on-device for standard query.")
        }
    }
}
