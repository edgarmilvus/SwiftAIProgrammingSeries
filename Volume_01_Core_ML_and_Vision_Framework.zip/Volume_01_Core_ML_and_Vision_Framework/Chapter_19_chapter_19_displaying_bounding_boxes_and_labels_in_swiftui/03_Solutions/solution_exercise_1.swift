
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import CoreGraphics // For CGRect
import Foundation   // For UUID

// MARK: - Mock Data Structures & Helper

/// Represents a mock object detection result, mimicking `VNRecognizedObjectObservation`.
struct DetectionResult: Identifiable {
    let id: UUID
    var boundingBox: CGRect // Normalized 0-1, bottom-left origin (Vision-style)
    var label: String
    var confidence: Double // 0.0 - 1.0 (for future exercises)

    init(boundingBox: CGRect, label: String, confidence: Double = 1.0) {
        self.id = UUID()
        self.boundingBox = boundingBox
        self.label = label
        self.confidence = confidence
    }
}

extension CGRect {
    /// Converts a Vision framework's normalized bounding box (origin bottom-left)
    /// to a SwiftUI/UIKit point-based CGRect (origin top-left) within a given image size.
    /// - Parameters:
    ///   - normalizedRect: The bounding box from Vision, normalized (0-1).
    ///   - imageSize: The actual displayed size of the image in points.
    /// - Returns: A CGRect suitable for SwiftUI/UIKit drawing.
    static func visionToSwiftUIRect(normalizedRect: CGRect, imageSize: CGSize) -> CGRect {
        let x = normalizedRect.origin.x * imageSize.width
        let width = normalizedRect.size.width * imageSize.width
        
        // Vision's y-origin is bottom-left. SwiftUI/UIKit's is top-left.
        // Convert y from bottom-left to top-left.
        let y = (1 - normalizedRect.origin.y - normalizedRect.size.height) * imageSize.height
        let height = normalizedRect.size.height * imageSize.height
        
        return CGRect(x: x, y: y, width: width, height: height)
    }
}

// MARK: - Reusable Bounding Box Overlay View (for all exercises)

/// A reusable SwiftUI view to draw a bounding box and its label.
struct BoundingBoxOverlay: View {
    let id: UUID
    let swiftUIRect: CGRect // Already converted to SwiftUI coordinates
    let label: String
    let confidence: Double // 0.0 - 1.0
    let containerSize: CGSize // The size of the parent container (e.g., image)

    // Styling properties (for future exercises)
    var isSelected: Bool = false
    var displayConfidence: Bool = false
    var strokeColor: Color = .blue
    var labelPlacementPreference: LabelPlacementPreference = .auto

    enum LabelPlacementPreference {
        case auto // Try inside, then above
        case alwaysAbove
        case alwaysInside
    }

    // Calculated properties for rendering
    private var labelText: String {
        displayConfidence ?
            "\(label) (\(Int(confidence * 100))%)" :
            label
    }

    private var isLowConfidence: Bool {
        confidence < 0.7
    }

    var body: some View {
        // Bounding Box
        Rectangle()
            .stroke(
                isSelected ? .green : strokeColor, // Exercise 3: Selected color
                style: StrokeStyle(
                    lineWidth: isSelected ? 3 : (isLowConfidence ? 1 : 2), // Exercise 3: Thicker when selected, Exercise 2: low confidence dashed
                    dash: isLowConfidence ? [5, 5] : [] // Exercise 2: Dashed for low confidence
                )
            )
            .frame(width: swiftUIRect.width, height: swiftUIRect.height)
            .offset(x: swiftUIRect.origin.x, y: swiftUIRect.origin.y)

        // Label
        labelView
            .position(labelPosition)
    }

    // MARK: - Label Placement Logic (Exercise 2)

    private var labelPosition: CGPoint {
        let labelSize = estimatedLabelSize(text: labelText)
        
        var targetX = swiftUIRect.midX
        var targetY: CGFloat

        let shouldPlaceInside: Bool
        switch labelPlacementPreference {
        case .alwaysInside:
            shouldPlaceInside = true
        case .alwaysAbove:
            shouldPlaceInside = false
        case .auto:
            // Check if label fits horizontally inside the box (with padding)
            let labelFitsHorizontally = labelSize.width < swiftUIRect.width - 10
            // Check if box is tall enough for label (with padding)
            let boxTallEnough = swiftUIRect.height > labelSize.height + 10
            
            shouldPlaceInside = labelFitsHorizontally && boxTallEnough
        }

        if shouldPlaceInside {
            targetY = swiftUIRect.minY + labelSize.height / 2 + 5 // 5pt padding from top of box
        } else {
            targetY = swiftUIRect.minY - labelSize.height / 2 - 5 // 5pt padding above box
        }

        // Ensure label doesn't go out of overall container bounds (Exercise 2)
        if targetY - labelSize.height / 2 < 0 { // Too high
            targetY = labelSize.height / 2 + 2 // Push down from container top
        }
        if targetY + labelSize.height / 2 > containerSize.height { // Too low
            targetY = containerSize.height - labelSize.height / 2 - 2 // Pull up from container bottom
        }

        return CGPoint(x: targetX, y: targetY)
    }

    /// A heuristic to estimate the size of the Text view.
    /// For precise measurements, a custom `Layout` or UIKit integration would be needed.
    private func estimatedLabelSize(text: String) -> CGSize {
        let font = UIFont.systemFont(ofSize: 12) // Matches .caption font
        let attributes = [NSAttributedString.Key.font: font]
        let size = (text as NSString).size(withAttributes: attributes)
        return CGSize(width: size.width + 10, height: size.height + 5) // Add padding
    }

    private var labelView: some View {
        Text(labelText)
            .font(.caption)
            .padding(.horizontal, 5)
            .padding(.vertical, 2)
            .background(Color.black.opacity(0.7))
            .foregroundColor(.white)
            .cornerRadius(5)
    }
}

// MARK: - Exercise 1 Solution View

struct Exercise1View: View {
    // Mock dataset of detection results
    let detections: [DetectionResult] = [
        .init(boundingBox: CGRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4), label: "Cat", confidence: 0.98),
        .init(boundingBox: CGRect(x: 0.5, y: 0.6, width: 0.2, height: 0.3), label: "Dog", confidence: 0.85),
        .init(boundingBox: CGRect(x: 0.05, y: 0.8, width: 0.15, height: 0.1), label: "Bird", confidence: 0.72),
        .init(boundingBox: CGRect(x: 0.7, y: 0.1, width: 0.25, height: 0.2), label: "Car", confidence: 0.91)
    ]

    var body: some View {
        VStack {
            Text("Exercise 1: Basic Bounding Box Overlay")
                .font(.headline)
                .padding()

            GeometryReader { geometry in
                // Ensure the image scales to fit and takes available space
                Image("sample_image") // <--- IMPORTANT: Add "sample_image.jpg" to your asset catalog
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .overlay(
                        // Overlay detections on top of the image
                        ZStack {
                            ForEach(detections) { detection in
                                // Convert Vision's normalized CGRect to SwiftUI's point-based CGRect
                                let swiftUIRect = CGRect.visionToSwiftUIRect(
                                    normalizedRect: detection.boundingBox,
                                    imageSize: geometry.size
                                )
                                
                                BoundingBoxOverlay(
                                    id: detection.id,
                                    swiftUIRect: swiftUIRect,
                                    label: detection.label,
                                    confidence: detection.confidence,
                                    containerSize: geometry.size,
                                    strokeColor: .blue, // Distinct stroke color
                                    displayConfidence: false, // Not required for Ex1
                                    labelPlacementPreference: .alwaysAbove // Simple placement for Ex1
                                )
                            }
                        }
                    )
            }
            .padding()
        }
    }
}

// Preview Provider
struct Exercise1View_Previews: PreviewProvider {
    static var previews: some View {
        Exercise1View()
    }
}
