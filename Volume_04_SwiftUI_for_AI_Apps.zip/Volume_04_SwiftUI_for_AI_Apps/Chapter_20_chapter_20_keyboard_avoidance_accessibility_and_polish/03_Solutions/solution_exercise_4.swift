
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI

// A simple model for a line of code
struct CodeLine: Identifiable, Equatable {
    let id = UUID()
    let content: String
}

struct AICodeStreamView: View {
    @State private var codeLines: [CodeLine] = []
    @State private var userPrompt: String = ""
    @FocusState private var isInputActive: Bool
    @State private var isGenerating: Bool = false

    // Simulated AI code generation lines
    private let simulatedCode: [String] = [
        "func generateGreeting(name: String) -> String {",
        "    let hour = Calendar.current.component(.hour, from: Date())",
        "    var greeting: String",
        "",
        "    switch hour {",
        "    case 6..<12:",
        "        greeting = \"Good morning\"",
        "    case 12..<18:",
        "        greeting = \"Good afternoon\"",
        "    default:",
        "        greeting = \"Good evening\"",
        "    }",
        "",
        "    return \"\\(greeting), \\(name)!\"",
        "}"
    ]

    var body: some View {
        VStack {
            // AI Code Display Area
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 2) {
                        ForEach(codeLines) { line in
                            Text(line.content)
                                .font(.system(.body, design: .monospaced)) // Monospaced font for code
                                .padding(.horizontal, 4)
                                .id(line.id) // Needed for ScrollViewReader
                                .transition(.opacity.combined(with: .slide)) // Subtle animation for new lines
                                // MARK: - Live Accessibility
                                // Announce new code lines politely without interrupting user input.
                                .accessibilityLiveRegion(.polite)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 8)
                }
                .onAppear {
                    // Store the proxy for later use
                    self.scrollViewProxy = proxy
                }
                .onChange(of: codeLines.count) { _ in
                    // Scroll to bottom when new lines are added
                    // Using DispatchQueue.main.async to ensure layout updates before scrolling
                    if let lastLine = codeLines.last {
                        DispatchQueue.main.async {
                            proxy.scrollTo(lastLine.id, anchor: .bottom)
                        }
                    }
                }
            }

            // User Input TextField
            HStack {
                TextField("Type your prompt...", text: $userPrompt)
                    .textFieldStyle(.roundedBorder)
                    .focused($isInputActive)
                    .padding(.vertical, 8)
                    .submitLabel(.go)
                    .onSubmit(startCodeGeneration)

                Button {
                    startCodeGeneration()
                } label: {
                    if isGenerating {
                        ProgressView()
                    } else {
                        Text("Generate")
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(isGenerating)
            }
            .padding([.horizontal, .bottom])
        }
        // MARK: - Keyboard Avoidance
        .ignoresSafeArea(.keyboard, edges: .bottom)
        .safeAreaInset(edge: .bottom) {
            Color.clear.frame(height: 0) // Placeholder for keyboard height
        }
        .navigationTitle("AI Code Assistant")
    }

    // Reference to ScrollViewProxy to use outside its closure
    @State private var scrollViewProxy: ScrollViewProxy?

    private func startCodeGeneration() {
        guard !isGenerating else { return }
        isGenerating = true
        codeLines = [] // Clear previous code
        userPrompt = "" // Clear user prompt

        Task { // Use a Task for asynchronous simulation
            for (index, line) in simulatedCode.enumerated() {
                await Task.sleep(nanoseconds: UInt64(0.1 * Double(NSEC_PER_SEC))) // Simulate streaming delay
                await MainActor.run { // Ensure UI update on main actor
                    codeLines.append(CodeLine(content: line))
                }
                // Optionally scroll immediately after adding each line if needed,
                // but onChange(of: codeLines.count) handles it already.
            }
            await MainActor.run {
                isGenerating = false
            }
        }
    }
}

// Preview Provider
struct AICodeStreamView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AICodeStreamView()
        }
    }
}
