
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import CoreData

@available(iOS 18.0, *)
class EmbeddingChunk: NSManagedObject {
    @NSManaged var sequenceIndex: Int16
    @NSManaged var chunkData: Data
    @NSManaged var parentMessageID: UUID
}

@available(iOS 18.0, *)
actor ChunkingManager {
    private let chunkSize = 1024 // 1KB chunks for CloudKit safety
    private let context: NSManagedObjectContext

    init(context: NSManagedObjectContext) {
        self.context = context
    }

    /// Splits a large vector into multiple Chunk entities.
    func chunkAndStore(vector: [Float], for messageID: UUID) async throws {
        let fullData = vector.withUnsafeBytes { Data($0) }
        let totalBytes = fullData.count
        var offset = 0
        var index: Int16 = 0

        try await context.perform {
            while offset < totalBytes {
                let remaining = totalBytes - offset
                let currentChunkSize = min(remaining, self.chunkSize)
                let subdata = fullData.subdata(in: offset..<(offset + currentChunkSize))
                
                let chunk = EmbeddingChunk(context: self.context)
                chunk.sequenceIndex = index
                chunk.chunkData = subdata
                chunk.parentMessageID = messageID
                
                offset += currentChunkSize
                index += 1
            }
            try self.context.save()
        }
    }

    /// Reconstructs the original [Float] vector from chunks.
    func reconstructVector(for messageID: UUID) async throws -> [Float] {
        return try await context.perform {
            let request: NSFetchRequest<EmbeddingChunk> = NSFetchRequest(entityName: "EmbeddingChunk")
            request.predicate = NSPredicate(format: "parentMessageID == %@", messageID as CVarArg)
            request.sortDescriptors = [NSSortDescriptor(keyPath: \EmbeddingChunk.sequenceIndex, ascending: true)]
            
            let chunks = try self.context.fetch(request)
            
            // Verify all chunks arrived (Basic integrity check)
            // In a real app, you'd compare expected vs actual count
            
            var combinedData = Data()
            for chunk in chunks {
                combinedData.append(chunk.chunkData)
            }
            
            return combinedData.withUnsafeBytes { buffer in
                Array(buffer.bindMemory(to: Float.self))
            }
        }
    }
}
