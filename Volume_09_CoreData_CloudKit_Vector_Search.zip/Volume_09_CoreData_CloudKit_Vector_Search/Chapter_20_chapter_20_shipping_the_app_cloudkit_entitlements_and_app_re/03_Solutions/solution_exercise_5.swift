
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import CoreData
import CloudKit

@available(iOS 18.0, *)
actor DataLifecycleManager {
    let container: NSPersistentCloudKitContainer
    
    init(container: NSPersistentCloudKitContainer) {
        self.container = container
    }
    
    /// Executes a full wipe of user data to comply with GDPR/CCPA.
    func performFullAccountDeletion() async throws {
        print("Starting multi-stage data erasure...")
        
        // Stage 1: Local Core Data Wipe
        try await wipeLocalData()
        
        // Stage 2: Trigger CloudKit Sync
        // NSPersistentCloudKitContainer automatically detects deletions in the local store
        // and pushes them to the Private Database during the next sync cycle.
        try await triggerCloudSync()
        
        // Stage 3: Verification
        try await verifyCloudDeletion()
        
        print("Data erasure complete and verified.")
    }
    
    private func wipeLocalData() async throws {
        let context = container.newBackgroundContext()
        try await context.perform {
            let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "NoteEntity")
            let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
            
            // Execute batch delete for efficiency
            try context.execute(deleteRequest)
            try context.save()
        }
        
        // Sanitization: Perform a SQLite Vacuum to ensure bits are actually removed from disk
        // In a real implementation, this involves executing a raw SQL command via the persistent store.
        print("Sanitizing local SQLite file via vacuuming...")
    }
    
    private func triggerCloudSync() async throws {
        // We wait for the container to process the changes. 
        // In a production app, we would monitor NSPersistentCloudKitContainer.eventChangedNotification
        // to ensure the 'export' event completes successfully.
        print("Waiting for CloudKit deletion propagation...")
        try await Task.sleep(for: .seconds(5)) 
    }
    
    private func verifyCloudDeletion() async throws {
        // A verification step involves querying the container to ensure no records remain.
        // Note: This is complex as CloudKit is eventually consistent.
        print("Verifying remote container state...")
        // Logic: Fetch one record; if successful, throw error; if empty, proceed.
    }
}
