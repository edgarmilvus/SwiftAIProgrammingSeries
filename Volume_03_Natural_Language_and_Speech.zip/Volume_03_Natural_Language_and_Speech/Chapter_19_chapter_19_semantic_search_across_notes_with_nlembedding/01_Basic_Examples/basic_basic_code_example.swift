
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import NaturalLanguage // Required for NLEmbedding and related NLP functionalities
import Foundation      // Required for String and other basic types

/// A utility class to manage the generation of text embeddings for notes.
/// This class encapsulates the logic for interacting with NLEmbedding.
@available(iOS 12.0, macOS 10.14, *) // NLEmbedding is available from these versions
class NotesEmbeddingManager {

    // MARK: - Properties

    /// The NLEmbedding instance for sentence-level embeddings in English.
    /// This instance is loaded once and reused for efficiency.
    private let sentenceEmbedding: NLEmbedding?

    // MARK: - Initialization

    /// Initializes the manager and attempts to load the English sentence embedding model.
    /// - Important: Model loading can fail if the language is not supported or resources are unavailable.
    init() {
        // Attempt to load the pre-trained English sentence embedding model.
        // This model is optimized for processing sentences and short phrases.
        self.sentenceEmbedding = NLEmbedding.sentenceEmbedding(for: .english)

        // Provide feedback if the model failed to load.
        if sentenceEmbedding == nil {
            print("❌ Error: Failed to load English sentence embedding model. Semantic search will not be available.")
        } else {
            print("✅ NLEmbedding model for English sentences loaded successfully.")
        }
    }

    // MARK: - Public Methods

    /// Generates an embedding vector for a given piece of text (e.g., a note's content).
    /// - Parameter text: The string content for which to generate the embedding.
    /// - Returns: An array of Doubles representing the embedding vector, or nil if the model is not loaded or embedding fails.
    func generateEmbedding(for text: String) -> [Double]? {
        // Ensure the embedding model was successfully loaded.
        guard let embedding = self.sentenceEmbedding else {
            print("⚠️ Cannot generate embedding: NLEmbedding model is not available.")
            return nil
        }

        // Use the loaded embedding model to get the vector for the provided text.
        // The `vector(for:)` method performs the conversion from text to numbers.
        if let vector = embedding.vector(for: text) {
            print("Generated embedding vector for: \"\(text.prefix(50))...\"")
            return vector
        } else {
            print("❌ Failed to generate embedding vector for text: \"\(text.prefix(50))...\"")
            return nil
        }
    }

    /// Calculates the cosine similarity between two embedding vectors.
    /// Cosine similarity measures the cosine of the angle between two vectors.
    /// A value of 1 indicates identical direction (most similar), -1 indicates opposite direction (least similar).
    /// - Parameters:
    ///   - vector1: The first embedding vector.
    ///   - vector2: The second embedding vector.
    /// - Returns: A Double representing the cosine similarity, or nil if vectors have different dimensions.
    func cosineSimilarity(between vector1: [Double], and vector2: [Double]) -> Double? {
        guard vector1.count == vector2.count, !vector1.isEmpty else {
            print("⚠️ Cannot calculate similarity: Vectors must have the same non-zero dimension.")
            return nil
        }

        let dotProduct = zip(vector1, vector2).map(*).reduce(0, +)
        let magnitude1 = sqrt(vector1.map { $0 * $0 }.reduce(0, +))
        let magnitude2 = sqrt(vector2.map { $0 * $0 }.reduce(0, +))

        guard magnitude1 != 0 && magnitude2 != 0 else {
            print("⚠️ Cannot calculate similarity: One or both vectors have zero magnitude.")
            return nil
        }

        return dotProduct / (magnitude1 * magnitude2)
    }
}

// MARK: - Example Usage in an iOS/macOS Application

/// Simulates a simple Notes application flow to demonstrate NLEmbedding.
@MainActor // Ensure UI updates and main thread operations are handled correctly
@available(iOS 12.0, macOS 10.14, *)
func demonstrateNLEmbeddingForNotes() async {
    print("\n--- Starting NLEmbedding Demonstration for Notes ---")

    // 1. Initialize the NotesEmbeddingManager.
    // This will attempt to load the NLEmbedding model upon creation.
    let embeddingManager = NotesEmbeddingManager()

    // 2. Define some sample notes that a user might create.
    let note1Content = "Plan a trip to the mountains next summer, don't forget hiking boots and a tent."
    let note2Content = "I need to buy new trekking shoes for my upcoming camping adventure in the Alps."
    let note3Content = "Remember to pick up groceries: milk, eggs, bread, and some fresh fruit."
    let note4Content = "Explore the new coffee shop downtown, they have excellent espresso."
    let note5Content = "A quick reminder: schedule a meeting with the project team for next Tuesday."

    // 3. Generate embeddings for each note.
    // In a real app, these embeddings would likely be stored alongside the note content
    // in a database (e.g., Core Data, Realm, or a custom file format).
    print("\n--- Generating Embeddings for Sample Notes ---")
    let note1Embedding = embeddingManager.generateEmbedding(for: note1Content)
    let note2Embedding = embeddingManager.generateEmbedding(for: note2Content)
    let note3Embedding = embeddingManager.generateEmbedding(for: note3Content)
    let note4Embedding = embeddingManager.generateEmbedding(for: note4Content)
    let note5Embedding = embeddingManager.generateEmbedding(for: note5Content)

    // 4. Display the results (e.g., the first few elements of the vector and its dimension).
    if let embed = note1Embedding {
        print("\nNote 1 Embedding (first 5 elements): \(Array(embed.prefix(5)))...")
        print("Note 1 Vector Dimension: \(embed.count)") // NLEmbedding typically produces 50-dimensional vectors for words/sentences.
    }

    // 5. Demonstrate semantic similarity using cosine similarity.
    // We expect note1 and note2 to be highly similar, and note1 and note3 to be dissimilar.
    print("\n--- Calculating Semantic Similarities ---")

    // Similarity between two mountain/hiking-related notes
    if let e1 = note1Embedding, let e2 = note2Embedding,
       let similarity = embeddingManager.cosineSimilarity(between: e1, and: e2) {
        print("Similarity between Note 1 ('\(note1Content.prefix(20))...') and Note 2 ('\(note2Content.prefix(20))...'): \(String(format: "%.4f", similarity))") // Expected: High similarity (e.g., > 0.7)
    }

    // Similarity between a mountain/hiking note and a grocery list note
    if let e1 = note1Embedding, let e3 = note3Embedding,
       let similarity = embeddingManager.cosineSimilarity(between: e1, and: e3) {
        print("Similarity between Note 1 ('\(note1Content.prefix(20))...') and Note 3 ('\(note3Content.prefix(20))...'): \(String(format: "%.4f", similarity))") // Expected: Low similarity (e.g., < 0.3)
    }

    // Similarity between a coffee note and a meeting reminder
    if let e4 = note4Embedding, let e5 = note5Embedding,
       let similarity = embeddingManager.cosineSimilarity(between: e4, and: e5) {
        print("Similarity between Note 4 ('\(note4Content.prefix(20))...') and Note 5 ('\(note5Content.prefix(20))...'): \(String(format: "%.4f", similarity))") // Expected: Low similarity
    }

    print("\n--- NLEmbedding Demonstration Complete ---")
}

// To run this example, you would call `demonstrateNLEmbeddingForNotes()`
// from an appropriate entry point in your app, e.g., in an `@main` App struct
// or a ViewController's `viewDidLoad`.
// For a quick test in a Playground or an async context:
// Task {
//     await demonstrateNLEmbeddingForNotes()
// }
