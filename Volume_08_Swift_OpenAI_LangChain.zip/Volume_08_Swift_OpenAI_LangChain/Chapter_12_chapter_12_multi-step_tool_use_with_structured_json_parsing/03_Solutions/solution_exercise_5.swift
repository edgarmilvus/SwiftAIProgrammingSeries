
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

enum ToolError: Error, Sendable {
    case columnNotFound(String)
    case invalidQuery(String)
}

struct ToolResult: Sendable {
    let content: String
    let isError: Bool
}

actor DataAnalystAgent {
    private var history: [ChatMessage] = []
    private var retryCount = 0
    private let maxRetries = 3

    // Mock Tools
    private func getCSVHeader() async -> String {
        return "Columns: [id, transaction_date, amount, cat_id]"
    }

    private func queryCSV(query: String) async -> ToolResult {
        // Simulate a common LLM mistake: using 'category_name' instead of 'cat_id'
        if query.contains("category_name") {
            return ToolResult(content: "Error: Column 'category_name' not found. Valid columns: [id, transaction_date, amount, cat_id]", isError: true)
        }
        return ToolResult(content: "Average volume: 500.00", isError: false)
    }

    func performAnalysis(userQuery: String) async -> String {
        history.append(ChatMessage(role: .user, content: userQuery))
        
        while retryCount < maxRetries {
            print("🔄 Attempt \(retryCount + 1)...")
            
            // 1. Simulate LLM deciding to query (with error)
            // In a real app, this is the LLM's actual response
            let currentQuery = retryCount == 0 ? "SELECT amount FROM csv WHERE category_name = 'Retail'" : "SELECT amount FROM csv WHERE cat_id = 'Retail'"
            
            print("🤖 LLM attempts query: \(currentQuery)")
            let result = await queryCSV(query: currentQuery)
            
            if !result.isError {
                return "Analysis Complete: \(result.content)"
            } else {
                // 2. THE SELF-CORRECTION STEP
                print("⚠️ Tool Error detected: \(result.content)")
                
                // Append the error to history so the LLM "sees" it
                history.append(ChatMessage(role: .tool, content: result.content))
                
                // 3. Simulate LLM seeing error and calling getCSVHeader
                if retryCount == 0 {
                    print("🤖 LLM realizes mistake. Calling getCSVHeader()...")
                    let header = await getCSVHeader()
                    history.append(ChatMessage(role: .tool, content: header))
                }
                
                retryCount += 1
            }
        }
        
        return "I'm sorry, I couldn't complete the analysis after \(maxRetries) attempts."
    }
}

@main
struct DataAnalystApp {
    static func main() async {
        let agent = DataAnalystAgent()
        let result = await agent.performAnalysis(userQuery: "What is the average volume for Retail?")
        print("\n🏁 Final Result: \(result)")
    }
}
