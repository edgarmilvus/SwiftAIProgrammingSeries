
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

/// A mock AI model kit that simulates streaming AI responses.
/// In a real application, this would be an actual SDK or network client interacting with an AI service.
class MockAIModelKit {
    enum AIError: Error, LocalizedError {
        case networkError
        case modelFailure
        case unknown

        var errorDescription: String? {
            switch self {
            case .networkError: return "Network connection failed. Please check your internet."
            case .modelFailure: return "The AI model encountered an error. Please try again."
            case .unknown: return "An unexpected error occurred."
            }
        }
    }

    /// Simulates streaming an AI response for a given prompt.
    /// - Parameter prompt: The user's input prompt.
    /// - Returns: An `AsyncThrowingStream` of `String` tokens.
    func streamResponse(for prompt: String) -> AsyncThrowingStream<String, Error> {
        AsyncThrowingStream { continuation in
            Task {
                // Simulate network delay
                try await Task.sleep(for: .milliseconds(300))

                // Simulate a potential error
                if prompt.lowercased().contains("error") {
                    continuation.finish(throwing: AIError.modelFailure)
                    return
                }

                let fullResponse = "Hello there! I am an AI assistant. I can help you with various tasks. For example, I can answer questions, summarize text, or generate creative content. How can I assist you today?"
                let words = fullResponse.split(separator: " ")

                for (index, word) in words.enumerated() {
                    // Simulate token generation delay
                    try await Task.sleep(for: .milliseconds(50 + Int.random(in: 0...50)))
                    continuation.yield(String(word) + (index == words.count - 1 ? "" : " "))
                }
                continuation.finish()
            }
        }
    }
}
