
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

    import MLX
    import MLXNN // For Module, Conv2d, ReLU, MaxPool2d, Linear, Flatten
    import MLXOptimizers // For Adam or SGD

    @available(macOS 14.0, iOS 17.0, visionOS 1.0, *)
    /// Orchestrates the document scanning and feature extraction process.
    /// Manages model loading, inference, and potential fine-tuning.
    class DocumentScannerProcessor {
        private var featureExtractor: DocumentFeatureExtractor
        // In a real app, you might load weights from a file here
        // For this example, we'll initialize with random weights.
        private let inputPatchSize: (height: Int, width: Int) = (32, 32) // Example input patch size

        /// Initializes the processor with a new feature extractor model.
        init() {
            self.featureExtractor = DocumentFeatureExtractor()
            // Important: Call `eval()` on the model parameters to ensure they are materialized
            // and placed on the desired device (CPU by default, or GPU if specified).
            // This is part of MLX's lazy evaluation.
            self.featureExtractor.eval()
            print("DocumentFeatureExtractor initialized and parameters evaluated.")
        }

        /// Simulates converting an image patch into an MLXArray.
        /// In a real app, this would involve `CoreGraphics` or `CoreVideo` to `MLXArray` conversion.
        /// - Parameter pixelData: A flat array of pixel values (e.g., grayscale 0-255).
        /// - Returns: An `MLXArray` representing the image patch, ready for model input.
        ///           Shape: `[batch_size, channels, height, width]`.
        private func preprocessImagePatch(pixelData: [Float]) throws -> MLXArray {
            guard pixelData.count == inputPatchSize.height * inputPatchSize.width else {
                throw ProcessingError.invalidInputDimensions(
                    "Expected \(inputPatchSize.height * inputPatchSize.width) pixels, got \(pixelData.count)"
                )
            }
            // Create a 1-channel (grayscale) image MLXArray.
            // MLX uses NCHW format: [batch, channels, height, width]
            let imageArray = MLXArray(pixelData, [1, 1, inputPatchSize.height, inputPatchSize.width])
            // MLXArray directly uses Unified Memory. No explicit copy to GPU is needed.
            return imageArray
        }

        /// Extracts features from a simulated document image patch.
        /// - Parameter imagePatchData: Raw pixel data of the image patch.
        /// - Returns: An `MLXArray` representing the extracted feature vector.
        /// - Throws: `ProcessingError` if input is invalid or MLX operation fails.
        func extractFeatures(from imagePatchData: [Float]) async throws -> MLXArray {
            print("Starting feature extraction...")
            let inputMLXArray = try preprocessImagePatch(pixelData: imagePatchData)

            // Perform inference. This triggers the lazy evaluation of the graph.
            let features = featureExtractor(inputMLXArray)
            
            // Explicitly evaluate the features to ensure computation completes and
            // the result is materialized. This is often good practice at the end
            // of a processing step, especially if you need to read the data back
            // to CPU or use it in subsequent non-MLX operations.
            features.eval()
            print("Feature extraction complete. Feature vector shape: \(features.shape)")
            return features
        }

        /// Demonstrates a hypothetical fine-tuning step using `valueAndGradient`.
        /// In a real scenario, `targetFeatures` would come from a labeled dataset.
        /// - Parameters:
        ///   - imagePatchData: The input image patch data.
        ///   - targetFeatures: The desired (ground truth) feature vector for the input.
        /// - Returns: The calculated loss value.
        /// - Throws: `ProcessingError` if input is invalid or MLX operation fails.
        func fineTuneStep(imagePatchData: [Float], targetFeatures: MLXArray) async throws -> Float {
            print("Starting hypothetical fine-tuning step...")
            let inputMLXArray = try preprocessImagePatch(pixelData: imagePatchData)

            // Define a simple Mean Squared Error (MSE) loss function.
            // This function takes the model and input, computes output, and compares to target.
            let loss_fn = { (model: DocumentFeatureExtractor, input: MLXArray, target: MLXArray) -> MLXArray in
                let predictedFeatures = model(input)
                // MSE Loss: sum((predicted - target)^2) / num_elements
                return MLX.mean(MLX.square(predictedFeatures - target))
            }

            // Use MLX's valueAndGradient to compute loss and gradients automatically.
            // This is where MLX's automatic differentiation shines.
            let (loss, gradients) = MLX.valueAndGradient(featureExtractor, loss_fn)(featureExtractor, inputMLXArray, targetFeatures)
            
            // Evaluate the loss and gradients.
            loss.eval()
            gradients.eval()

            print("Hypothetical fine-tuning step complete. Loss: \(loss.item())")
            
            // In a real training loop, you would then apply these gradients
            // using an optimizer (e.g., Adam, SGD) to update the model's weights.
            // Example (conceptual):
            // let optimizer = MLXOptimizers.Adam(learningRate: 0.001)
            // featureExtractor = optimizer.update(featureExtractor, gradients)
            // featureExtractor.eval() // Re-evaluate model parameters after update

            return loss.item()
        }
    }

    /// Custom error types for the document processing.
    enum ProcessingError: Error, CustomStringConvertible {
        case invalidInputDimensions(String)
        case mlxOperationFailed(String)
        case unknownError(String)

        var description: String {
            switch self {
            case .invalidInputDimensions(let message): return "Invalid Input Dimensions: \(message)"
            case .mlxOperationFailed(let message): return "MLX Operation Failed: \(message)"
            case .unknownError(let message): return "Unknown Processing Error: \(message)"
            }
        }
    }
    