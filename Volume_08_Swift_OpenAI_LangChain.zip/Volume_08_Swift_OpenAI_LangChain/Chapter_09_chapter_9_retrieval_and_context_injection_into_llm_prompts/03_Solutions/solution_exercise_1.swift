
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import Accelerate

enum SearchError: Error {
    case dimensionMismatch
    case emptyQuery
}

@available(iOS 18.0, *)
struct Note: Identifiable, Codable {
    let id: UUID
    let content: String
    let embedding: [Float]
}

protocol EmbeddingProvider {
    func generateEmbedding(for text: String) async throws -> [Float]
}

@available(iOS 18.0, *)
class SemanticSearchEngine {
    private let embeddingProvider: EmbeddingProvider
    
    init(embeddingProvider: EmbeddingProvider) {
        self.embeddingProvider = embeddingProvider
    }
    
    /// Calculates cosine similarity using Accelerate framework for high performance.
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) throws -> Float {
        guard a.count == b.count else { throw SearchError.dimensionMismatch }
        guard !a.isEmpty else { return 0 }
        
        // Use Accelerate (vDSP) for high-performance vector math
        var dotProduct: Float = 0
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        
        var sumSqA: Float = 0
        vDSP_svesq(a, 1, &sumSqA, vDSP_Length(a.count))
        
        var sumSqB: Float = 0
        vDSP_svesq(b, 1, &sumSqB, vDSP_Length(b.count))
        
        let magnitudeA = sqrt(sumSqA)
        let magnitudeB = sqrt(sumSqB)
        
        guard magnitudeA > 0 && magnitudeB > 0 else { return 0 }
        
        return dotProduct / (magnitudeA * magnitudeB)
    }
    
    func findMostSimilar(
        query: String, 
        in notes: [Note], 
        limit: Int = 3, 
        threshold: Float = 0.7
    ) async throws -> [(note: Note, score: Float)] {
        guard !query.isEmpty else { throw SearchError.emptyQuery }
        
        // 1. Generate embedding for the query
        let queryEmbedding = try await embeddingProvider.generateEmbedding(for: query)
        
        // 2. Calculate similarity for all notes
        var results: [(note: Note, score: Float)] = []
        
        for note in notes {
            let score = try cosineSimilarity(queryEmbedding, note.embedding)
            // Bonus: Implement threshold filtering
            if score >= threshold {
                results.append((note: note, score: score))
            }
        }
        
        // 3. Sort by score descending and return top results
        return results.sorted { $0.score > $1.score }.prefix(limit).map { $0 }
    }
}
