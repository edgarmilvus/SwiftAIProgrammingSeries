
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

/// A SwiftUI view representing a single chat bubble, capable of displaying
/// either plain text or an interactive AI tool call suggestion.
@available(iOS 17.0, *)
struct StreamingChatBubbleView: View {
    let content: MessageContent
    let isUserMessage: Bool
    let isStreaming: Bool // Indicates if the message is still being generated
    var onAcceptToolCall: ((ToolCallSuggestion) -> Void)?
    var onDeclineToolCall: ((ToolCallSuggestion) -> Void)?
    
    private var alignment: HorizontalAlignment {
        isUserMessage ? .trailing : .leading
    }
    
    private var backgroundColor: Color {
        isUserMessage ? .blue : .gray.opacity(0.2)
    }
    
    private var foregroundColor: Color {
        isUserMessage ? .white : .primary
    }

    var body: some View {
        HStack {
            if isUserMessage { Spacer() }
            
            VStack(alignment: alignment, spacing: 4) {
                switch content {
                case .text(let text):
                    Text(text)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(backgroundColor)
                        .foregroundColor(foregroundColor)
                        .cornerRadius(16)
                        .fixedSize(horizontal: false, vertical: true) // Allow text to wrap
                    
                case .toolCallSuggestion(let suggestion):
                    toolCallCard(suggestion: suggestion)
                }
                
                // Show a streaming indicator for AI messages that are still being generated
                if !isUserMessage && isStreaming {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .scaleEffect(0.7)
                        .padding(.top, 4)
                }
            }
            .frame(maxWidth: .infinity, alignment: Alignment(horizontal: alignment, vertical: .center))
            
            if !isUserMessage { Spacer() }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 2)
    }
    
    /// Renders a card for an AI tool call suggestion, including action buttons.
    /// - Parameter suggestion: The `ToolCallSuggestion` to display.
    @ViewBuilder
    private func toolCallCard(suggestion: ToolCallSuggestion) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("AI Suggestion: \(suggestion.name.replacingOccurrences(of: "_", with: " ").capitalized)")
                .font(.headline)
                .foregroundColor(.accentColor)
            
            Text(suggestion.description)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            if !suggestion.parameters.isEmpty {
                VStack(alignment: .leading) {
                    Text("Parameters:")
                        .font(.caption)
                        .fontWeight(.bold)
                    ForEach(suggestion.parameters.sorted(by: <), id: \.key) { key, value in
                        Text("• \(key): \(value)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            HStack {
                Button("Accept") {
                    onAcceptToolCall?(suggestion)
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                
                Button("Decline") {
                    onDeclineToolCall?(suggestion)
                }
                .buttonStyle(.bordered)
                .tint(.red)
            }
            .padding(.top, 4)
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.gray.opacity(0.1))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(Color.accentColor, lineWidth: 1)
                )
        )
        .fixedSize(horizontal: false, vertical: true)
        .frame(maxWidth: 300, alignment: .leading) // Limit width for card
    }
}
