/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * FILE: hooks/useAssetTracker.ts
 * DESCRIPTION: A comprehensive hook managing GPS location tracking and Gyroscope 
 *              data to monitor asset stability and environmental context.
 * CONTEXT: SaaS Logistics Dashboard - Asset Integrity Module.
 */

import { useState, useEffect, useRef, useCallback } from 'react';

// --- Types & Interfaces ---

interface GeoLocation {
  latitude: number;
  longitude: number;
  accuracy: number; // GPS accuracy in meters
  timestamp: number;
}

interface GyroData {
  x: number; // Rotation around X-axis (pitch)
  y: number; // Rotation around Y-axis (yaw)
  z: number; // Rotation around Z-axis (roll)
  timestamp: number;
}

interface AssetState {
  location: GeoLocation | null;
  orientation: GyroData | null;
  isStable: boolean; // Is the asset stationary/shaking?
  status: 'IDLE' | 'TRACKING' | 'ERROR';
  shakeIntensity: number; // Calculated magnitude of movement
}

// --- Mock Sensor Adapters (For Web/Next.js Compatibility) ---
// In a real Expo app, we would import { Gyroscope } from 'expo-sensors'.
// Here, we simulate the API to allow testing in a browser environment.

class MockGyroscope {
  private static listeners: ((data: GyroData) => void)[] = [];
  private static intervalId: NodeJS.Timeout | null = null;

  static addListener(callback: (data: GyroData) => void) {
    this.listeners.push(callback);
  }

  static removeAllListeners() {
    this.listeners = [];
    if (this.intervalId) clearInterval(this.intervalId);
  }

  static async setUpdateInterval(ms: number) {
    if (this.intervalId) clearInterval(this.intervalId);
    // Simulate noise and movement
    this.intervalId = setInterval(() => {
      const data: GyroData = {
        x: (Math.random() - 0.5) * 2, // Random value between -1 and 1
        y: (Math.random() - 0.5) * 2,
        z: (Math.random() - 0.5) * 2,
        timestamp: Date.now(),
      };
      this.listeners.forEach(cb => cb(data));
    }, ms);
  }
}

class MockGeolocation {
  static watchPosition(
    successCallback: (pos: GeoLocation) => void,
    errorCallback: (err: any) => void
  ): number {
    // Simulate movement in a circular path
    let angle = 0;
    const interval = setInterval(() => {
      angle += 0.01;
      const radius = 0.001; // Small radius for simulation
      const lat = 40.7128 + radius * Math.cos(angle);
      const lng = -74.0060 + radius * Math.sin(angle);
      
      successCallback({
        latitude: lat,
        longitude: lng,
        accuracy: 5 + Math.random() * 5,
        timestamp: Date.now(),
      });
    }, 1000);

    return setInterval(() => {}, 10000); // Return ID (simplified)
  }

  static clearWatch(id: number) {
    clearInterval(id);
  }
}

// --- The Core Logic ---

/**
 * Calculates the magnitude (intensity) of movement based on gyro data.
 * Formula: sqrt(x^2 + y^2 + z^2)
 * @param {GyroData} data - The raw sensor reading.
 * @returns {number} - The scalar magnitude of rotation.
 */
const calculateShakeIntensity = (data: GyroData): number => {
  return Math.sqrt(data.x ** 2 + data.y ** 2 + data.z ** 2);
};

/**
 * Custom Hook: useAssetTracker
 * Manages the dual-stream data ingestion (GPS + Gyro) and derives state.
 */
export const useAssetTracker = (assetId: string) => {
  const [state, setState] = useState<AssetState>({
    location: null,
    orientation: null,
    isStable: true,
    status: 'IDLE',
    shakeIntensity: 0,
  });

  // Use refs to track intervals/IDs without triggering re-renders
  const gyroListenerId = useRef<number | null>(null);
  const geoWatchId = useRef<number | null>(null);

  /**
   * Starts the sensor streams.
   * Encapsulated in useCallback to prevent recreation on every render.
   */
  const startTracking = useCallback(() => {
    setState(prev => ({ ...prev, status: 'TRACKING' }));

    // 1. Initialize Gyroscope (Stability Monitoring)
    // We set a high update interval (e.g., 100ms) for web simulation performance.
    MockGyroscope.setUpdateInterval(100);
    MockGyroscope.addListener((data) => {
      setState(prev => {
        const intensity = calculateShakeIntensity(data);
        // Threshold: 0.5 is arbitrary for simulation. 
        // In production, this requires calibration based on hardware.
        const isStable = intensity < 0.5; 
        
        return {
          ...prev,
          orientation: data,
          shakeIntensity: intensity,
          isStable,
        };
      });
    });

    // 2. Initialize Geolocation (Position Tracking)
    // WatchPosition provides continuous updates.
    const watchId = MockGeolocation.watchPosition(
      (geoData) => {
        setState(prev => ({
          ...prev,
          location: geoData,
        }));
      },
      (err) => {
        console.error("GPS Error:", err);
        setState(prev => ({ ...prev, status: 'ERROR' }));
      }
    );
    geoWatchId.current = watchId;

  }, [assetId]);

  /**
   * Stops all sensor streams and cleans up resources.
   * Crucial for preventing memory leaks in Single Page Applications (SPAs).
   */
  const stopTracking = useCallback(() => {
    MockGyroscope.removeAllListeners();
    if (geoWatchId.current !== null) {
      MockGeolocation.clearWatch(geoWatchId.current);
    }
    setState(prev => ({ ...prev, status: 'IDLE' }));
  }, []);

  // Effect: Lifecycle Management
  useEffect(() => {
    // Auto-start if needed, or leave manual control via UI
    // startTracking(); 

    // Cleanup on unmount
    return () => {
      stopTracking();
    };
  }, [startTracking, stopTracking]);

  return {
    state,
    actions: {
      startTracking,
      stopTracking,
    },
  };
};

/**
 * COMPONENT: AssetTrackerDashboard
 * A Next.js Server Component (or Client Component) consuming the hook.
 * Displays real-time telemetry and alerts.
 */
export const AssetTrackerDashboard = ({ assetId }: { assetId: string }) => {
  const { state, actions } = useAssetTracker(assetId);

  return (
    <div className="p-6 bg-slate-900 text-white rounded-lg font-mono max-w-md mx-auto">
      <div className="flex justify-between items-center mb-4 border-b border-slate-700 pb-2">
        <h2 className="text-xl font-bold text-cyan-400">Asset: {assetId}</h2>
        <span 
          className={`px-2 py-1 rounded text-xs font-bold ${
            state.status === 'TRACKING' ? 'bg-green-500/20 text-green-400' : 'bg-slate-700 text-slate-300'
          }`}
        >
          {state.status}
        </span>
      </div>

      {/* --- GPS Section --- */}
      <div className="mb-4">
        <h3 className="text-sm uppercase tracking-wider text-slate-400 mb-2">Geolocation</h3>
        {state.location ? (
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <span className="text-slate-500">Lat:</span> <br />
              {state.location.latitude.toFixed(6)}
            </div>
            <div>
              <span className="text-slate-500">Lng:</span> <br />
              {state.location.longitude.toFixed(6)}
            </div>
            <div className="col-span-2">
              <span className="text-slate-500">Accuracy:</span> ±{state.location.accuracy.toFixed(1)}m
            </div>
          </div>
        ) : (
          <p className="text-slate-500 italic">Waiting for GPS signal...</p>
        )}
      </div>

      {/* --- Gyroscope Section --- */}
      <div className="mb-4 border-t border-slate-800 pt-4">
        <h3 className="text-sm uppercase tracking-wider text-slate-400 mb-2">Stability Monitor</h3>
        <div className="flex items-center gap-4">
          {/* Visual Indicator for Stability */}
          <div className={`w-4 h-4 rounded-full transition-colors duration-200 ${
            state.isStable ? 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.6)]' : 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.6)] animate-pulse'
          }`} />
          <span className="text-lg font-semibold">
            {state.isStable ? 'STABLE' : 'UNSTABLE / SHAKING'}
          </span>
        </div>
        
        <div className="mt-2 text-xs text-slate-400">
          Intensity: {state.shakeIntensity.toFixed(4)} G-force
        </div>

        {/* Raw Data (Collapsed for readability) */}
        <details className="mt-2 text-xs text-slate-500">
          <summary>Raw Gyro Data</summary>
          <pre className="mt-1 p-2 bg-slate-800 rounded overflow-x-auto">
            {JSON.stringify(state.orientation, null, 2)}
          </pre>
        </details>
      </div>

      {/* --- Controls --- */}
      <div className="flex gap-2 mt-6">
        <button 
          onClick={actions.startTracking}
          disabled={state.status === 'TRACKING'}
          className="flex-1 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 rounded font-bold transition-colors"
        >
          Start Tracking
        </button>
        <button 
          onClick={actions.stopTracking}
          disabled={state.status === 'IDLE'}
          className="flex-1 py-2 bg-slate-700 hover:bg-slate-600 disabled:opacity-50 rounded font-bold transition-colors"
        >
          Stop
        </button>
      </div>
    </div>
  );
};
