
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI

@available(iOS 18.0, *)
struct StreamingSearchView: View {
    @State private var query: String = ""
    @State private var results: [SearchResult] = []
    @State private var isStreaming: Bool = false
    
    // Keep track of the current search task to cancel it if query changes
    @State private var searchTask: Task<Void, Never>?

    var body: some View {
        NavigationStack {
            List(results) { result in
                Text(result.title)
            }
            .navigationTitle("Live Semantic Search")
            .searchable(text: $query)
            .onChange(of: query) { oldValue, newValue in
                searchTask?.cancel() // Stop the previous stream
                searchTask = Task {
                    await performStreamingSearch(for: newValue)
                }
            }
            .overlay {
                if isStreaming && results.isEmpty {
                    ProgressView("Initializing Stream...")
                }
            }
        }
    }

    @MainActor
    private func performStreamingSearch(for query: String) async {
        guard !query.isEmpty else {
            results = []
            isStreaming = false
            return
        }
        
        results = []
        isStreaming = true
        
        let service = SearchStreamingService()
        let stream = service.streamResults(for: query)
        
        // Consume the stream as batches arrive
        for await newBatch in stream {
            // Check for cancellation within the loop
            if Task.isCancelled { break }
            self.results.append(contentsOf: newBatch)
        }
        
        isStreaming = false
    }
}

@available(iOS 18.0, *)
class SearchStreamingService {
    func streamResults(for query: String) -> AsyncStream<[SearchResult]> {
        AsyncStream { continuation in
            let task = Task {
                // Simulate Batch 1: Instant matches
                try? await Task.sleep(for: .milliseconds(500))
                if Task.isCancelled { return }
                continuation.yield([
                    SearchResult(id: UUID(), title: "Top Match for \(query)", similarityScore: 0.99)
                ])
                
                // Simulate Batch 2: Slightly slower computation
                try? await Task.sleep(for: .milliseconds(1000))
                if Task.isCancelled { return }
                continuation.yield([
                    SearchResult(id: UUID(), title: "Secondary Match", similarityScore: 0.85),
                    SearchResult(id: UUID(), title: "Related Concept", similarityScore: 0.82)
                ])
                
                // Simulate Batch 3: Deep scan results
                try? await Task.sleep(for: .milliseconds(1500))
                if Task.isCancelled { return }
                continuation.yield([
                    SearchResult(id: UUID(), title: "Deep Search Result", similarityScore: 0.70)
                ])
                
                continuation.finish()
            }
            
            // Crucial: If the consumer (the View) cancels the task, 
            // we must stop the producer (the Service).
            continuation.onTermination = { _ in
                task.cancel()
            }
        }
    }
}
