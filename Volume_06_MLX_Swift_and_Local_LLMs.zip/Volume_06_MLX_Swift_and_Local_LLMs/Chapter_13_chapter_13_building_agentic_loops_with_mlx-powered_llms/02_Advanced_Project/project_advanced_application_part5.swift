
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

// MARK: - Application Entry Point (Simulated)

/// Main function to run our document extraction agent.
@available(iOS 18.0, macOS 14.0, *)
func runDocumentExtractionApp() async {
    print("🚀 Starting Document Extraction Agent...")

    // 1. Initialize the MLX LLM Inference Engine
    let llmEngine = MLXLLMInferenceEngine(modelPath: "path/to/your/mlx/model")

    // 2. Initialize the Document Data Extractor Agent
    let agent = DocumentDataExtractorAgent(llmEngine: llmEngine, maxIterations: 3)

    // --- Scenario 1: Successful Extraction (first try) ---
    let documentText1 = """
    Invoice from: Acme Corp
    123 Main St, Anytown, USA
    Date: 2023-10-26
    Items: Widget A (x1) - $50.00, Gadget B (x2) - $73.45
    Total Amount Due: $123.45
    """
    print("\n--- Processing Document 1 (Expected: Success) ---")
    do {
        let extractedData = try await agent.extractData(from: documentText1)
        print("\n🎉 Final Extracted Data (Doc 1):\nVendor: \(extractedData.vendor)\nTotal: \(extractedData.totalAmount)\nDate: \(extractedData.invoiceDate)")
    } catch {
        print("\n❌ Failed to extract data from Document 1: \(error.localizedDescription)")
    }

    // --- Scenario 2: Extraction requiring one correction (missing totalAmount initially) ---
    let documentText2 = """
    Receipt: Global Solutions Inc.
    Project Alpha
    Date of Service: 2023-09-15
    Description: Consulting services
    Amount: 543.21 USD
    """
    print("\n--- Processing Document 2 (Expected: Correction needed) ---")
    do {
        let extractedData = try await agent.extractData(from: documentText2)
        print("\n🎉 Final Extracted Data (Doc 2):\nVendor: \(extractedData.vendor)\nTotal: \(extractedData.totalAmount)\nDate: \(extractedData.invoiceDate)")
    } catch {
        print("\n❌ Failed to extract data from Document 2: \(error.localizedDescription)")
    }

    // --- Scenario 3: Extraction that might fail after max iterations (e.g., very ambiguous text or persistent LLM error) ---
    let documentText3 = """
    This is just some random text without clear invoice details.
    Perhaps a meeting note from a company called "Innovate Tech"
    on 2024-01-01. No specific amount mentioned.
    """
    print("\n--- Processing Document 3 (Expected: Max Iterations Reached) ---")
    do {
        let extractedData = try await agent.extractData(from: documentText3)
        print("\n🎉 Final Extracted Data (Doc 3):\nVendor: \(extractedData.vendor)\nTotal: \(extractedData.totalAmount)\nDate: \(extractedData.invoiceDate)")
    } catch {
        print("\n❌ Failed to extract data from Document 3: \(error.localizedDescription)")
    }
}

// To run this in a SwiftPM executable target, you would call:
// await runDocumentExtractionApp()
// Or in an iOS app:
// Task {
//     await runDocumentExtractionApp()
// }
