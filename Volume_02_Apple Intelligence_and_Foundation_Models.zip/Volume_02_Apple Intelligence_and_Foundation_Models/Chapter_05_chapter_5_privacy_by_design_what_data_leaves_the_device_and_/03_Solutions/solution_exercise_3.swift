
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import AppIntents
import Foundation
import SwiftUI // For IntentView and AppEntity display

// 1. Define TaskItem and a privacy-preserving version for summary intent
struct TaskItem: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var description: String // Could be long and detailed, potentially sensitive
    var dueDate: Date
    var priority: Int
    var notes: String // Potentially highly sensitive, should NEVER leave device

    // A stripped-down version for AppIntent parameters, excluding sensitive data.
    // This is the version that could potentially be sent to PCC if needed,
    // after further anonymization by the system.
    struct SummaryEligibleTask: Identifiable, Codable, AppEntity, Hashable {
        let id: UUID
        var title: String
        var dueDate: Date
        var priority: Int

        // AppEntity requirements for display in Siri/Shortcuts UI
        static var typeDisplayRepresentation: TypeDisplayRepresentation = "Task for Summary"
        var displayRepresentation: DisplayRepresentation {
            DisplayRepresentation(
                title: "\(title)",
                subtitle: "Due: \(dueDate.formatted(date: .abbreviated, time: .omitted)), Priority: \(priority)"
            )
        }

        // Required for AppEntity. This points to the query provider.
        static var defaultQuery: TaskItemSummaryQuery = TaskItemSummaryQuery()
    }

    // Convert to summary-eligible form, explicitly omitting sensitive data.
    func toSummaryEligibleTask() -> SummaryEligibleTask {
        return SummaryEligibleTask(id: self.id, title: self.title, dueDate: self.dueDate, priority: self.priority)
    }
}

// AppEntity Query for TaskItem.SummaryEligibleTask (required for AppEntity)
@available(iOS 18.0, macOS 15.0, *)
struct TaskItemSummaryQuery: EntityQuery {
    // Mock data store for this exercise. In a real app, this would fetch from Core Data, Realm, etc.
    private static var allMockTasks: [TaskItem] = [
        TaskItem(id: UUID(), title: "Write Chapter 5 Exercises", description: "Draft 4-5 exercises focusing on privacy. This is a crucial client project.", dueDate: Date().addingTimeInterval(86400*2), priority: 1, notes: "Client project, very confidential details regarding unreleased product features."),
        TaskItem(id: UUID(), title: "Review Pull Request", description: "Check code changes for feature X, specifically security implications.", dueDate: Date().addingTimeInterval(86400*3), priority: 2, notes: "Internal team only, proprietary algorithm."),
        TaskItem(id: UUID(), title: "Prepare Presentation for Q3", description: "Outline slides for Q3 review, focusing on financial performance.", dueDate: Date().addingTimeInterval(86400*5), priority: 1, notes: "Contains sensitive financial projections and market analysis."),
        TaskItem(id: UUID(), title: "Book Flight to London", description: "Research best flights for October conference, personal travel.", dueDate: Date().addingTimeInterval(86400*7), priority: 3, notes: "Personal travel plans, passport details."),
        TaskItem(id: UUID(), title: "Follow up with Marketing", description: "Discuss campaign launch strategy and budget allocation.", dueDate: Date().addingTimeInterval(86400*1), priority: 2, notes: "Strategy details are proprietary and highly competitive."),
        TaskItem(id: UUID(), title: "Schedule Team Building Event", description: "Organize a fun team outing for morale boost.", dueDate: Date().addingTimeInterval(86400*10), priority: 3, notes: "Budget for team events."),
        TaskItem(id: UUID(), title: "Research New AI Models", description: "Explore the latest advancements in on-device LLMs.", dueDate: Date().addingTimeInterval(86400*14), priority: 1, notes: "Future product strategy research.")
    ]

    func entities(for identifiers: [TaskItem.SummaryEligibleTask.ID]) async throws -> [TaskItem.SummaryEligibleTask] {
        return Self.allMockTasks
            .filter { identifiers.contains($0.id) }
            .map { $0.toSummaryEligibleTask() }
    }

    func suggestedEntities() async throws -> [TaskItem.SummaryEligibleTask] {
        // Provide some sample entities for Siri suggestions
        return Self.allMockTasks.prefix(3).map { $0.toSummaryEligibleTask() }
    }

    func entities(matching string: String) async throws -> [TaskItem.SummaryEligibleTask] {
        // Implement search logic if needed for Siri/Shortcuts to find tasks by name
        return Self.allMockTasks
            .filter { $0.title.localizedCaseInsensitiveContains(string) }
            .map { $0.toSummaryEligibleTask() }
    }
}


// 2. Define SummarizeTasksIntent
@available(iOS 18.0, macOS 15.0, *)
struct SummarizeTasksIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize My Tasks"
    static var description = IntentDescription(
        "Generates a summary of selected tasks, prioritizing on-device processing and strict privacy for sensitive data.",
        category: .productivity
    )

    // Crucially, the @Parameter only accepts the privacy-eligible version of TaskItem.
    // This ensures sensitive data (like 'description' or 'notes' from the original TaskItem)
    // is never exposed to the intent, and thus cannot leave the device.
    @Parameter(
        title: "Tasks to Summarize",
        description: "The tasks to include in the summary. Only non-sensitive details are exposed for privacy.",
        requestValueDialog: "Which tasks would you like to summarize?"
    )
    var tasks: [TaskItem.SummaryEligibleTask]

    init() {}
    init(tasks: [TaskItem.SummaryEligibleTask]) {
        self.tasks = tasks
    }

    func perform() async throws -> some IntentResult {
        guard !tasks.isEmpty else {
            return .result(value: "No tasks provided for summary.")
        }

        let taskCount = tasks.count
        var summaryText: String
        var processingLocation: String
        var privacyNotes: String = ""

        // Prepare input for the LLM using only the privacy-eligible data
        let taskDescriptionsForLLM = tasks.map { task in
            "- \(task.title) (Due: \(task.dueDate.formatted(date: .abbreviated, time: .omitted)), Priority: \(task.priority))"
        }.joined(separator: "\n")

        // 3. Implement the Intent Handler
        // Conditional logic for on-device vs. potential PCC
        let onDeviceThreshold = 3 // Example threshold for on-device processing
        if taskCount <= onDeviceThreshold {
            // Use a local Foundation model for summarization
            processingLocation = "on-device using local Foundation model"
            print("Processing \(taskCount) tasks \(processingLocation). No data leaves the device.")

            // --- Conceptual Local LLM Call ---
            // In a real scenario, you'd integrate with Foundation.LLM here.
            // For this exercise, we simulate the output.
            /*
            let llm = LLM.textGeneration()
            let prompt = "Summarize the following tasks concisely:\n\(taskDescriptionsForLLM)"
            let result = try await llm.generate(prompt)
            summaryText = result.first?.text ?? "Could not generate summary."
            */
            summaryText = "On-device summary of \(taskCount) tasks:\n\(taskDescriptionsForLLM)\n\nKey takeaways: Focus on high-priority items due soon. All processing local."
            privacyNotes = "All task data remained on your device for this summary."

        } else {
            // This is where PCC *might* be considered by the system for more complex tasks.
            // We have already ensured that only privacy-preserving data is available to this intent.
            processingLocation = "potentially via Private Cloud Compute (PCC) by system decision"
            print("Processing \(taskCount) tasks. This number of tasks (\(taskCount) > \(onDeviceThreshold)) *could* lead the system to consider PCC for enhanced summarization.")
            print("CRITICAL PRIVACY NOTE: Only the 'SummaryEligibleTask' data (ID, title, due date, priority) is available to this intent.")
            print("Sensitive fields like 'notes' or full 'description' from the original TaskItem are NEVER passed to the intent, thus ensuring they cannot leave the device, even if PCC is used.")
            print("The system would handle PCC invocation, ensuring cryptographic protections, no logging, and ephemeral sessions.")

            // --- Conceptual PCC-assisted LLM Call ---
            // For this exercise, we simulate the output.
            summaryText = "Cloud-assisted (simulated) summary of \(taskCount) complex tasks:\n\(taskDescriptionsForLLM)\n\nComprehensive summary: Multiple high-priority tasks across various dates. Prioritize based on dependencies and upcoming deadlines."
            privacyNotes = "For complex tasks, the system *might* leverage Private Cloud Compute (PCC). However, only cryptographically protected, anonymized, non-sensitive data (title, due date, priority) would be processed, and never sensitive details like full descriptions or notes. Your privacy remains paramount."
        }

        return .result(
            value: summaryText,
            view: IntentView {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Task Summary (\(processingLocation)):")
                        .font(.headline)
                    Text(summaryText)
                        .font(.body)
                    Text(privacyNotes)
                        .font(.caption)
                        .foregroundColor(.gray)
                        .padding(.top, 5)
                }
                .padding()
            }
        )
    }
}
