
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    // Package.swift snippet for visionOS
    // dependencies: [
    //     .package(name: "swift-collections", url: "https://github.com/apple/swift-collections", from: "1.0.0")
    // ]
    import ARKit
    import Vision
    import CoreML
    import Collections // For Deque, if managing a frame queue

    // An actor to encapsulate the object detection logic and state
    @available(iOS 18.0, *)
    actor ObjectDetectionActor {
        private let visionSequenceHandler = VNSequenceRequestHandler()
        private let coreMLRequest: VNCoreMLRequest
        private var frameQueue: Deque<ARFrame> = [] // Example: Queue frames if processing takes longer than frame rate
        private var isProcessing = false

        init(model: MLModel) throws {
            let visionModel = try VNCoreMLModel(for: model)
            self.coreMLRequest = VNCoreMLRequest(model: visionModel)
            self.coreMLRequest.imageCropAndScaleOption = .centerCrop
        }

        func enqueueFrame(_ frame: ARFrame) {
            frameQueue.append(frame)
            // Kick off processing if not already busy
            if !isProcessing {
                Task { await processNextFrame() }
            }
        }

        private func processNextFrame() async {
            guard !isProcessing, let frame = frameQueue.popFirst() else { return }
            isProcessing = true

            defer { // Ensure isProcessing is reset and next frame is processed
                isProcessing = false
                Task { await processNextFrame() }
            }

            guard let pixelBuffer = frame.capturedImage else { return }

            do {
                try visionSequenceHandler.perform([coreMLRequest], on: pixelBuffer)
                if let observations = coreMLRequest.results as? [VNRecognizedObjectObservation] {
                    // Safely pass results to the main actor for AR scene updates
                    await MainActor.run {
                        // This closure runs on the main actor
                        // Convert 2D observations to 3D world coordinates using 'frame' data
                        // Update RealityKit entities or ARSCNView nodes
                        print("Actor detected \(observations.count) objects.")
                        // Example: Publish results via an @Observable property
                    }
                }
            } catch {
                print("Vision request failed in actor: \(error)")
            }
        }
    }
    