
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

enum MarketMetric: String, Codable, CaseIterable, Sendable {
    case price, volume, volatility, movingAverage = "moving_average"
}

enum Granularity: String, Codable, CaseIterable, Sendable {
    case daily, hourly, minutely
}

struct MarketDataPoint: Codable, Sendable {
    let timestamp: Date
    let value: Double
}

struct MarketDataResult: Codable, Sendable {
    let symbols: [String]
    let metric: String
    let data: [MarketDataPoint]
    let summary: String
}

actor MarketDataService {
    func fetch(symbols: [String], metric: String, timeframe: Int, granularity: String) async throws -> MarketDataResult {
        // 1. Strict Validation of Metric
        guard let validMetric = MarketMetric(rawValue: metric) else {
            let available = MarketMetric.allCases.map { $0.rawValue }.joined(separator: ", ")
            throw NSError(domain: "QuantView", code: 422, userInfo: [NSLocalizedDescriptionKey: "Invalid metric '\(metric)'. Available metrics are: \(available)."])
        }
        
        // 2. Strict Validation of Granularity
        guard let _ = Granularity(rawValue: granularity) else {
            throw NSError(domain: "QuantView", code: 422, userInfo: [NSLocalizedDescriptionKey: "Invalid granularity. Use: daily, hourly, or minutely."])
        }
        
        // Mocking data generation
        let mockData = [
            MarketDataPoint(timestamp: Date(), value: 150.0),
            MarketDataPoint(timestamp: Date().addingTimeInterval(-86400), value: 145.0)
        ]
        
        return MarketDataResult(
            symbols: symbols,
            metric: validMetric.rawValue,
            data: mockData,
            summary: "The \(validMetric.rawValue) for \(symbols.joined(separator: " and ")) shows a steady trend over \(timeframe) days."
        )
    }
}

struct QuantViewDispatcher {
    let service: MarketDataService
    
    func dispatch(argumentsJSON: Data) async throws -> String {
        struct Args: Codable {
            let symbols: [String]
            let metric: String
            let timeframe_days: Int
            let granularity: String
        }
        
        let args = try JSONDecoder().decode(Args.self, from: argumentsJSON)
        let result = try await service.fetch(
            symbols: args.symbols,
            metric: args.metric,
            timeframe: args.timeframe_days,
            granularity: args.granularity
        )
        
        let resultData = try JSONEncoder().encode(result)
        return String(data: resultData, encoding: .utf8) ?? "{}"
    }
}

// --- Testing the Error-Correction Loop ---
Task {
    let service = MarketDataService()
    let dispatcher = QuantViewDispatcher(service: service)
    
    // Scenario: User asks for "sentiment" (which isn't supported)
    let badInput = """
    {
        "symbols": ["AAPL", "TSLA"],
        "metric": "sentiment",
        "timeframe_days": 30,
        "granularity": "daily"
    }
    """.data(using: .utf8)!
    
    print("--- Attempt 1: Invalid Metric ---")
    do {
        let response = try await dispatcher.dispatch(argumentsJSON: badInput)
        print("Response: \(response)")
    } catch {
        print("LLM Error Received: \(error.localizedDescription)")
        print("--- LLM is now correcting itself... ---")
        
        // Simulated LLM correction
        let correctedInput = """
        {
            "symbols": ["AAPL", "TSLA"],
            "metric": "volatility",
            "timeframe_days": 30,
            "granularity": "daily"
        }
        """.data(using: .utf8)!
        
        let correctedResponse = try await dispatcher.dispatch(argumentsJSON: correctedInput)
        print("Attempt 2 (Corrected) Response: \(correctedResponse)")
    }
}
