
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import AVFoundation

@available(iOS 18.0, *)
func listAvailableVoices() {
    print("Available AVSpeechSynthesis Voices:")
    for voice in AVSpeechSynthesisVoice.speechVoices() {
        print("- \(voice.name) (\(voice.identifier)) - Language: \(voice.language), Quality: \(voice.quality.description)")
        // Voice quality can be .default, .compact, .premium
    }

    // Get the current language code for the device
    print("\nCurrent device language code: \(AVSpeechSynthesisVoice.currentLanguageCode())")

    // Find a voice for a specific language
    if let frenchVoice = AVSpeechSynthesisVoice(language: "fr-FR") {
        print("\nFound a French voice: \(frenchVoice.name)")
    } else {
        print("\nNo French voice found.")
    }

    // Find a voice by identifier (e.g., a specific Siri voice)
    let siriVoiceIdentifier = "com.apple.ttsbundle.siri_female_en-US_premium"
    if let siriVoice = AVSpeechSynthesisVoice(identifier: siriVoiceIdentifier) {
        print("Found Siri Premium voice: \(siriVoice.name)")
    } else {
        print("Siri Premium voice not found or not downloaded.")
    }
}

@available(iOS 18.0, *)
extension AVSpeechSynthesisVoice.Quality: CustomStringConvertible {
    public var description: String {
        switch self {
        case .default: return "Default"
        case .compact: return "Compact"
        case .premium: return "Premium"
        @unknown default: return "Unknown"
        }
    }
}
