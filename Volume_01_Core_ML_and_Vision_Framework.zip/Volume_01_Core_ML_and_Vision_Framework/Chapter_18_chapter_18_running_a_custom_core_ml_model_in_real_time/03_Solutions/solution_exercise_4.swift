
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import AVFoundation
import Vision
import CoreML

// MARK: - Dummy Core ML Model Class (Assumed Auto-Generated)
// Placeholder for the auto-generated PantryItemDetector.mlmodel class.
@available(iOS 11.0, *)
class PantryItemDetectorInput : MLFeatureProvider {
    var featureNames: Set<String> { return ["image"] }
    private let image: CVPixelBuffer
    init(image: CVPixelBuffer) { self.image = image }
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "image" { return MLFeatureValue(pixelBuffer: image) }
        return nil
    }
}

@available(iOS 11.0, *)
class PantryItemDetectorOutput : MLFeatureProvider {
    var featureNames: Set<String> { return ["coordinates", "labels", "confidence"] } // Example output names
    private let coordinates: MLMultiArray
    private let labels: MLMultiArray
    private let confidence: MLMultiArray

    init(coordinates: MLMultiArray, labels: MLMultiArray, confidence: MLMultiArray) {
        self.coordinates = coordinates
        self.labels = labels
        self.confidence = confidence
    }

    func featureValue(for featureName: String) -> MLFeatureValue? {
        if featureName == "coordinates" { return MLFeatureValue(multiArray: coordinates) }
        if featureName == "labels" { return MLFeatureValue(multiArray: labels) }
        if featureName == "confidence" { return MLFeatureValue(multiArray: confidence) }
        return nil
    }
}

@available(iOS 11.0, *)
class PantryItemDetector {
    var model: MLModel

    init() {
        // Dummy model for compilation purposes.
        // Simulates detection of a few pantry items.
        class DummyMLModel: MLModel {
            override func prediction(from input: MLFeatureProvider, options: MLPredictionOptions) throws -> MLFeatureProvider {
                let classes = ["cereal box", "milk carton", "canned soup", "pasta bag"]
                
                // Simulate 2-3 random detections per frame
                let numDetections = Int.random(in: 1...3)
                var detectedCoords: [Float] = []
                var detectedLabels: [String] = []
                var detectedConfidences: [Float] = []
                
                for _ in 0..<numDetections {
                    // Random bounding box
                    let x = Float.random(in: 0.1...0.7)
                    let y = Float.random(in: 0.1...0.7)
                    let width = Float.random(in: 0.1...0.3)
                    let height = Float.random(in: 0.1...0.3)
                    detectedCoords.append(contentsOf: [x, y, width, height])
                    
                    // Random label and confidence
                    let randomClass = classes.randomElement()!
                    detectedLabels.append(randomClass)
                    detectedConfidences.append(Float.random(in: 0.7...0.95))
                }
                
                let coordinates = try MLMultiArray(shape: [NSNumber(value: numDetections), 4], dataType: .float32)
                for (i, coord) in detectedCoords.enumerated() { coordinates[i] = NSNumber(value: coord) }
                
                let labels = try MLMultiArray(shape: [NSNumber(value: numDetections), 1], dataType: .string)
                for (i, label) in detectedLabels.enumerated() { labels[i] = label as NSString }
                
                let confidence = try MLMultiArray(shape: [NSNumber(value: numDetections), 1], dataType: .float32)
                for (i, conf) in detectedConfidences.enumerated() { confidence[i] = NSNumber(value: conf) }

                return PantryItemDetectorOutput(coordinates: coordinates, labels: labels, confidence: confidence)
            }
        }
        self.model = DummyMLModel()
    }

    convenience init(configuration: MLModelConfiguration) throws {
        self.init() // Simplified for dummy model
    }
    
    func prediction(image: CVPixelBuffer) throws -> PantryItemDetectorOutput {
        // For dummy, just return a fixed output that cycles
        let classes = ["cereal box", "milk carton", "canned soup", "pasta bag"]
        let numDetections = Int.random(in: 1...3)
        var detectedCoords: [Float] = []
        var detectedLabels: [String] = []
        var detectedConfidences: [Float] = []
        
        for _ in 0..<numDetections {
            let x = Float.random(in: 0.1...0.7)
            let y = Float.random(in: 0.1...0.7)
            let width = Float.random(in: 0.1...0.3)
            let height = Float.random(in: 0.1...0.3)
            detectedCoords.append(contentsOf: [x, y, width, height])
            
            let randomClass = classes.randomElement()!
            detectedLabels.append(randomClass)
            detectedConfidences.append(Float.random(in: 0.7...0.95))
        }
        
        let coordinates = try MLMultiArray(shape: [NSNumber(value: numDetections), 4], dataType: .float32)
        for (i, coord) in detectedCoords.enumerated() { coordinates[i] = NSNumber(value: coord) }
        
        let labels = try MLMultiArray(shape: [NSNumber(value: numDetections), 1], dataType: .string)
        for (i, label) in detectedLabels.enumerated() { labels[i] = label as NSString }
        
        let confidence = try MLMultiArray(shape: [NSNumber(value: numDetections), 1], dataType: .float32)
        for (i, conf) in detectedConfidences.enumerated() { confidence[i] = NSNumber(value: conf) }

        return PantryItemDetectorOutput(coordinates: coordinates, labels: labels, confidence: confidence)
    }
}

// MARK: - RealtimeObjectDetectionDelegate Protocol
protocol RealtimeObjectDetectionDelegate: AnyObject {
    func didDetectObjects(observations: [VNClassificationObservation], boundingBoxes: [CGRect])
}

// MARK: - CameraFeedObjectProcessor
@available(iOS 11.0, *)
class CameraFeedObjectProcessor: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {

    private let visionSequenceHandler = VNSequenceRequestHandler()
    private var coreMLRequest: VNCoreMLRequest?
    
    weak var delegate: RealtimeObjectDetectionDelegate?
    
    private let visionProcessingQueue = DispatchQueue(label: "com.app.objectDetectionProcessingQueue", qos: .userInitiated)

    override init() {
        super.init()
        setupCoreMLModel()
    }

    private func setupCoreMLModel() {
        do {
            let configuration = MLModelConfiguration()
            configuration.computeUnits = .all // Use all available compute units for performance

            let model = try PantryItemDetector(configuration: configuration).model
            let visionModel = try VNCoreMLModel(for: model)
            
            coreMLRequest = VNCoreMLRequest(model: visionModel) { [weak self] request, error in
                self?.processObservations(for: request, error: error)
            }
            coreMLRequest?.imageCropAndScaleOption = .scaleFit // Often suitable for object detection
        } catch {
            print("Failed to load Core ML model: \(error)")
        }
    }

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer),
              let request = coreMLRequest else { return }

        let orientation = self.imageOrientation(from: connection)

        visionProcessingQueue.async {
            do {
                try self.visionSequenceHandler.perform([request], on: pixelBuffer, orientation: orientation)
            } catch {
                print("Failed to perform Vision request: \(error)")
            }
        }
    }

    private func processObservations(for request: VNRequest, error: Error?) {
        guard let observations = request.results as? [VNDetectedObjectObservation] else {
            print("No object detection observations: \(error?.localizedDescription ?? "Unknown error")")
            DispatchQueue.main.async {
                self.delegate?.didDetectObjects(observations: [], boundingBoxes: [])
            }
            return
        }
        
        // Extract classification and bounding box for each detected object
        let classificationObservations: [VNClassificationObservation] = observations.compactMap { $0.labels.first }
        let boundingBoxes: [CGRect] = observations.map { $0.boundingBox }

        DispatchQueue.main.async {
            self.delegate?.didDetectObjects(observations: classificationObservations, boundingBoxes: boundingBoxes)
        }
    }
    
    private func imageOrientation(from connection: AVCaptureConnection) -> CGImagePropertyOrientation {
        let currentDeviceOrientation = UIDevice.current.orientation
        let videoOrientation = connection.videoOrientation
        
        switch (currentDeviceOrientation, videoOrientation) {
        case (.portrait, .portrait): return .right
        case (.portraitUpsideDown, .portraitUpsideDown): return .left
        case (.landscapeLeft, .landscapeLeft): return .up
        case (.landscapeRight, .landscapeRight): return .down
        default: return .right
        }
    }
}

// MARK: - ViewController Implementation
class RealtimeObjectDetectionViewController: UIViewController, RealtimeObjectDetectionDelegate {

    private let previewView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .black
        return view
    }()

    private let selectedObjectLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        label.textColor = .white
        label.backgroundColor = UIColor.darkGray.withAlphaComponent(0.8)
        label.text = "Tap an object to select"
        label.numberOfLines = 0
        return label
    }()

    private var captureSession: AVCaptureSession?
    private var previewLayer: AVCaptureVideoPreviewLayer?
    private let cameraFeedProcessor = CameraFeedObjectProcessor()

    // State for overlays and selections
    private var currentDetectionLayers: [CAShapeLayer] = []
    private var currentDetectionLabels: [CATextLayer] = []
    private var currentObservations: [VNClassificationObservation] = []
    private var currentBoundingBoxes: [CGRect] = [] // Vision normalized coords
    private var selectedLayer: CAShapeLayer?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        cameraFeedProcessor.delegate = self
        checkCameraPermissionsAndSetup()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        previewView.addGestureRecognizer(tapGesture)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = previewView.bounds
        // Re-draw overlays if layout changes, to ensure correct positioning
        if !currentObservations.isEmpty {
            drawDetectionOverlays(observations: currentObservations, boundingBoxes: currentBoundingBoxes)
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        captureSession?.stopRunning()
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground
        view.addSubview(previewView)
        view.addSubview(selectedObjectLabel)

        NSLayoutConstraint.activate([
            previewView.topAnchor.constraint(equalTo: view.topAnchor),
            previewView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            previewView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            previewView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            selectedObjectLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            selectedObjectLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            selectedObjectLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            selectedObjectLabel.heightAnchor.constraint(equalToConstant: 80)
        ])
    }
    
    private func checkCameraPermissionsAndSetup() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            setupCameraSession()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                guard let self = self else { return }
                if granted {
                    DispatchQueue.main.async { self.setupCameraSession() }
                } else {
                    DispatchQueue.main.async { self.selectedObjectLabel.text = "Camera access denied." }
                }
            }
        case .denied, .restricted:
            selectedObjectLabel.text = "Camera access denied. Please enable in Settings."
        @unknown default:
            selectedObjectLabel.text = "Unknown camera authorization status."
        }
    }

    private func setupCameraSession() {
        captureSession = AVCaptureSession()
        guard let captureSession = captureSession else { return }

        captureSession.beginConfiguration()

        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            print("Could not create video input.")
            captureSession.commitConfiguration()
            return
        }

        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        }

        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(cameraFeedProcessor, queue: cameraFeedProcessor.visionProcessingQueue)
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

        if captureSession.canAddOutput(videoOutput) {
            captureSession.addOutput(videoOutput)
        }

        if let connection = videoOutput.connection(with: .video) {
            connection.videoOrientation = .portrait
            if connection.isVideoStabilizationSupported {
                connection.preferredVideoStabilizationMode = .standard
            }
        }

        captureSession.commitConfiguration()

        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer?.videoGravity = .resizeAspectFill
        previewView.layer.addSublayer(previewLayer!)

        DispatchQueue.global(qos: .userInitiated).async {
            captureSession.startRunning()
        }
    }
    
    // MARK: - RealtimeObjectDetectionDelegate
    func didDetectObjects(observations: [VNClassificationObservation], boundingBoxes: [CGRect]) {
        // Store the latest detections
        self.currentObservations = observations
        self.currentBoundingBoxes = boundingBoxes
        
        // Clear old overlays and draw new ones
        clearDetectionOverlays()
        drawDetectionOverlays(observations: observations, boundingBoxes: boundingBoxes)
    }

    private func clearDetectionOverlays() {
        for layer in currentDetectionLayers {
            layer.removeFromSuperlayer()
        }
        for layer in currentDetectionLabels {
            layer.removeFromSuperlayer()
        }
        currentDetectionLayers.removeAll()
        currentDetectionLabels.removeAll()
        selectedLayer = nil // Clear selection
        selectedObjectLabel.text = "Tap an object to select"
    }
    
    private func drawDetectionOverlays(observations: [VNClassificationObservation], boundingBoxes: [CGRect]) {
        guard let previewLayer = previewLayer else { return }
        
        for (index, observation) in observations.enumerated() {
            let visionRect = boundingBoxes[index]
            let convertedRect = previewLayer.layerRectConverted(fromMetadataOutputRect: visionRect)

            // Bounding Box Layer
            let boxLayer = CAShapeLayer()
            boxLayer.frame = convertedRect
            boxLayer.borderColor = UIColor.green.cgColor
            boxLayer.borderWidth = 2.0
            boxLayer.cornerRadius = 5.0
            previewView.layer.addSublayer(boxLayer)
            currentDetectionLayers.append(boxLayer)

            // Label Layer
            let labelText = "\(observation.identifier) (\(String(format: "%.0f%%", observation.confidence * 100)))"
            let textLayer = CATextLayer()
            textLayer.string = labelText
            textLayer.font = UIFont.systemFont(ofSize: 14, weight: .bold)
            textLayer.fontSize = 14
            textLayer.foregroundColor = UIColor.white.cgColor
            textLayer.backgroundColor = UIColor.green.withAlphaComponent(0.7).cgColor
            textLayer.alignmentMode = .center
            textLayer.contentsScale = UIScreen.main.scale

            let textHeight: CGFloat = 20
            textLayer.frame = CGRect(x: convertedRect.minX, y: convertedRect.minY - textHeight - 5, width: convertedRect.width, height: textHeight)
            previewView.layer.addSublayer(textLayer)
            currentDetectionLabels.append(textLayer)
        }
    }
    
    // MARK: - Tap Gesture Handling
    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        let tapLocation = gesture.location(in: previewView)
        
        // Clear previous selection highlight
        selectedLayer?.borderColor = UIColor.green.cgColor
        selectedLayer?.borderWidth = 2.0
        selectedLayer = nil
        selectedObjectLabel.text = "Tap an object to select"

        // Convert tap location from view coordinates to Vision normalized coordinates
        // This is the inverse of layerRectConverted(fromMetadataOutputRect:)
        guard let previewLayer = previewLayer else { return }
        let normalizedTapPoint = previewLayer.metadataOutputRectConverted(fromLayerPoint: tapLocation)

        // Perform hit-testing
        for (index, visionRect) in currentBoundingBoxes.enumerated() {
            // Vision's boundingBox is origin bottom-left. Contains check works directly.
            if visionRect.contains(normalizedTapPoint) {
                // Found a hit! Highlight the corresponding layer
                if index < currentDetectionLayers.count {
                    let tappedBoxLayer = currentDetectionLayers[index]
                    tappedBoxLayer.borderColor = UIColor.yellow.cgColor
                    tappedBoxLayer.borderWidth = 4.0
                    selectedLayer = tappedBoxLayer
                    
                    // Display details
                    if index < currentObservations.count {
                        let observation = currentObservations[index]
                        let labelText = "\(observation.identifier) (\(String(format: "%.1f%%", observation.confidence * 100)))"
                        selectedObjectLabel.text = "Selected: \(labelText)"
                    }
                    return // Only select the first hit
                }
            }
        }
    }
}
