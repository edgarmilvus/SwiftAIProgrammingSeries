
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

// MARK: - Generic Prediction Output

// A simple example for classification output. Could be extended for object detection, segmentation, etc.
struct PredictionOutput {
    let label: String
    let confidence: Float
    let metadata: [String: Any]? // For additional model-specific data
}

// MARK: - MLPredictor Protocol

protocol MLPredictor {
    var id: String { get }
    var name: String { get }
    var description: String { get } // User-friendly description

    @available(iOS 18.0, *)
    func predict(image: CVPixelBuffer) async throws -> [PredictionOutput]
}

enum PredictorError: Error, LocalizedError {
    case modelLoadingFailed(String)
    case imagePreprocessingFailed
    case predictionFailed(Error)
    case invalidModelOutput(String) // Added more context for invalid output
    case predictorNotReady

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let name): return "Failed to load model: \(name)."
        case .imagePreprocessingFailed: return "Failed to preprocess image for prediction."
        case .predictionFailed(let error): return "Prediction failed: \(error.localizedDescription)"
        case .invalidModelOutput(let details): return "Model produced unexpected output format: \(details)."
        case .predictorNotReady: return "Predictor is not ready or active."
        }
    }
}

// MARK: - Concrete CoreMLPredictor

import CoreML
import Vision
import UIKit // For UIImage conversion to CVPixelBuffer (re-use from Exercise 1)

class CoreMLPredictor: MLPredictor {
    let id: String
    let name: String
    let description: String
    private let modelURL: URL
    private var coreMLModel: VNCoreMLModel? // Store VNCoreMLModel for Vision requests

    init(id: String, name: String, description: String, modelURL: URL) {
        self.id = id
        self.name = name
        self.description = description
        self.modelURL = modelURL
    }

    // Lazy load and compile the model when first needed, or explicitly load
    @available(iOS 18.0, *)
    private func loadModel() async throws {
        guard coreMLModel == nil else { return } // Model already loaded

        do {
            let mlModel: MLModel
            if modelURL.pathExtension == "mlmodel" {
                // Dynamically compile if .mlmodel is provided
                let compiledURL = try MLModel.compileModel(at: modelURL)
                mlModel = try MLModel(contentsOf: compiledURL)
            } else if modelURL.pathExtension == "mlmodelc" {
                // Load directly if .mlmodelc is provided
                mlModel = try MLModel(contentsOf: modelURL)
            } else {
                throw PredictorError.modelLoadingFailed("Invalid model file extension for \(modelURL.lastPathComponent)")
            }
            self.coreMLModel = try VNCoreMLModel(for: mlModel)
        } catch {
            throw PredictorError.modelLoadingFailed("\(name) - \(error.localizedDescription)")
        }
    }

    @available(iOS 18.0, *)
    func predict(image pixelBuffer: CVPixelBuffer) async throws -> [PredictionOutput] {
        try await loadModel() // Ensure model is loaded before prediction

        guard let coreMLModel = self.coreMLModel else {
            throw PredictorError.predictorNotReady
        }

        return try await withCheckedThrowingContinuation { continuation in
            let request = VNCoreMLRequest(model: coreMLModel) { request, error in
                if let error = error {
                    continuation.resume(throwing: PredictorError.predictionFailed(error))
                    return
                }

                // Generic parsing for classification output
                if let observations = request.results as? [VNClassificationObservation],
                   let bestResult = observations.first {
                    let output = PredictionOutput(label: bestResult.identifier, confidence: bestResult.confidence, metadata: nil)
                    continuation.resume(returning: [output])
                }
                // TODO: Extend to handle VNRecognizedObjectObservation, VNSegmentationObservation etc.
                // This would involve type checking `request.results` and parsing accordingly.
                // For this exercise, we focus on classification.
                else {
                    continuation.resume(throwing: PredictorError.invalidModelOutput("No classification observations found or unexpected type."))
                }
            }
            request.imageCropAndScaleOption = .centerCrop // Or model-specific option, e.g., .scaleFill

            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: PredictorError.predictionFailed(error))
            }
        }
    }
}

// MARK: - MLModelProvider Protocol and Concrete Implementation

protocol MLModelProvider {
    @available(iOS 18.0, *)
    func availablePredictors() async -> [any MLPredictor] // Use 'any' for existential types
}

class LocalBundleMLModelProvider: MLModelProvider {
    @available(iOS 18.0, *)
    func availablePredictors() async -> [any MLPredictor] {
        var predictors: [any MLPredictor] = []
        
        // Scan for .mlmodelc files in the bundle
        if let urls = Bundle.main.urls(forResourcesWithExtension: "mlmodelc", subdirectory: nil) {
            for url in urls {
                let modelName = url.deletingPathExtension().lastPathComponent
                // In a real app, you'd load metadata from a sidecar file or parse from the model directly
                let predictor = CoreMLPredictor(id: UUID().uuidString,
                                                name: modelName.replacingOccurrences(of: "_", with: " ").capitalized,
                                                description: "A Core ML model for \(modelName) classification.",
                                                modelURL: url)
                predictors.append(predictor)
            }
        }
        
        // Also look for .mlmodel files to allow dynamic compilation
        if let urls = Bundle.main.urls(forResourcesWithExtension: "mlmodel", subdirectory: nil) {
            for url in urls {
                let modelName = url.deletingPathExtension().lastPathComponent
                let predictor = CoreMLPredictor(id: UUID().uuidString,
                                                name: "Compilable \(modelName.replacingOccurrences(of: "_", with: " ").capitalized)",
                                                description: "A Core ML model for \(modelName) classification (will be compiled on first use).",
                                                modelURL: url)
                predictors.append(predictor)
            }
        }
        return predictors
    }
}

// MARK: - PredictionCoordinator

import Combine

class PredictionCoordinator {
    private let modelProvider: any MLModelProvider // Dependency Injection
    private var activePredictor: (any MLPredictor)?

    // Publisher for available predictors (optional, for dynamic UI updates)
    private let _availablePredictors = CurrentValueSubject<[any MLPredictor], Never>([])
    var availablePredictors: AnyPublisher<[any MLPredictor], Never> {
        _availablePredictors.eraseToAnyPublisher()
    }
    
    // Publisher for the currently active predictor's name
    private let _activePredictorName = CurrentValueSubject<String?, Never>(nil)
    var activePredictorName: AnyPublisher<String?, Never> {
        _activePredictorName.eraseToAnyPublisher()
    }

    init(modelProvider: any MLModelProvider) {
        self.modelProvider = modelProvider
        if #available(iOS 18.0, *) {
            Task { @MainActor in // Ensure updates to _availablePredictors are on MainActor
                await loadAvailablePredictors()
            }
        }
    }

    @available(iOS 18.0, *)
    private func loadAvailablePredictors() async {
        let predictors = await modelProvider.availablePredictors()
        _availablePredictors.send(predictors)
        // Optionally set the first one as active by default
        if let firstPredictor = predictors.first {
            setActivePredictor(id: firstPredictor.id)
        }
    }

    @available(iOS 18.0, *)
    func setActivePredictor(id: String) {
        self.activePredictor = _availablePredictors.value.first(where: { $0.id == id })
        _activePredictorName.send(self.activePredictor?.name)
        print("Active predictor set to: \(self.activePredictor?.name ?? "None")")
    }

    @available(iOS 18.0, *)
    func performPrediction(on image: UIImage) async throws -> [PredictionOutput] {
        guard let predictor = activePredictor else {
            throw PredictorError.predictorNotReady
        }
        // Re-use UIImage.toCVPixelBuffer() extension from Exercise 1
        guard let pixelBuffer = image.toCVPixelBuffer() else {
            throw PredictorError.imagePreprocessingFailed
        }
        return try await predictor.predict(image: pixelBuffer)
    }
}

// MARK: - ViewController Layer (Conceptual Implementation)

import PhotosUI

class SmartPhotoAlbumViewController: UIViewController, PHPickerViewControllerDelegate {
    private var coordinator: PredictionCoordinator!
    private var cancellables = Set<AnyCancellable>()
    
    // UI Outlets (simulated)
    let imageView = UIImageView()
    let predictionResultLabel = UILabel()
    let activeModelLabel = UILabel()
    let selectImageButton = UIButton(type: .system)
    let selectModelButton = UIButton(type: .system)
    let activityIndicator = UIActivityIndicatorView(style: .large)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        // Dependency Injection for MLModelProvider
        let modelProvider = LocalBundleMLModelProvider()
        coordinator = PredictionCoordinator(modelProvider: modelProvider)
        setupBindings()
    }
    
    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .white
        
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .lightGray
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)
        
        predictionResultLabel.textAlignment = .center
        predictionResultLabel.numberOfLines = 0
        predictionResultLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(predictionResultLabel)
        
        activeModelLabel.textAlignment = .center
        activeModelLabel.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
        activeModelLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(activeModelLabel)
        
        activityIndicator.hidesWhenStopped = true
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(activityIndicator)
        
        selectImageButton.setTitle("Select Image", for: .normal)
        selectImageButton.addTarget(self, action: #selector(selectImageTapped), for: .touchUpInside)
        selectImageButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(selectImageButton)
        
        selectModelButton.setTitle("Select Model", for: .normal)
        selectModelButton.addTarget(self, action: #selector(selectModelTapped), for: .touchUpInside)
        selectModelButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(selectModelButton)
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.4),
            
            activeModelLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 10),
            activeModelLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            activeModelLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            predictionResultLabel.topAnchor.constraint(equalTo: activeModelLabel.bottomAnchor, constant: 10),
            predictionResultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            predictionResultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            activityIndicator.centerXAnchor.constraint(equalTo: predictionResultLabel.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: predictionResultLabel.centerYAnchor),
            
            selectImageButton.topAnchor.constraint(equalTo: predictionResultLabel.bottomAnchor, constant: 20),
            selectImageButton.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: -80),
            selectImageButton.widthAnchor.constraint(equalToConstant: 150),
            selectImageButton.heightAnchor.constraint(equalToConstant: 44),
            
            selectModelButton.topAnchor.constraint(equalTo: predictionResultLabel.bottomAnchor, constant: 20),
            selectModelButton.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 80),
            selectModelButton.widthAnchor.constraint(equalToConstant: 150),
            selectModelButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }
    
    // MARK: - Combine Bindings
    private func setupBindings() {
        guard #available(iOS 18.0, *) else { return }
        
        coordinator.availablePredictors
            .receive(on: DispatchQueue.main)
            .sink { [weak self] predictors in
                print("Available predictors loaded: \(predictors.map { $0.name })")
                self?.selectModelButton.isEnabled = !predictors.isEmpty
            }
            .store(in: &cancellables)
        
        coordinator.activePredictorName
            .receive(on: DispatchQueue.main)
            .sink { [weak self] name in
                self?.activeModelLabel.text = "Active Model: \(name ?? "None Selected")"
            }
            .store(in: &cancellables)
    }

    // MARK: - User Actions
    @objc func selectImageTapped() {
        var configuration = PHPickerConfiguration()
        configuration.filter = .images
        configuration.selectionLimit = 1
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = self
        present(picker, animated: true)
    }
    
    @objc func selectModelTapped() {
        guard #available(iOS 18.0, *) else { return }
        
        let availablePredictors = coordinator._availablePredictors.value // Access subject directly for current value
        guard !availablePredictors.isEmpty else {
            let alert = UIAlertController(title: "No Models Available", message: "Please ensure Core ML models are included in the app bundle.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
            return
        }
        
        let actionSheet = UIAlertController(title: "Select Model", message: nil, preferredStyle: .actionSheet)
        for predictor in availablePredictors {
            actionSheet.addAction(UIAlertAction(title: predictor.name, style: .default, handler: { [weak self] _ in
                self?.coordinator.setActivePredictor(id: predictor.id)
            }))
        }
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(actionSheet, animated: true)
    }

    // MARK: - PHPickerViewControllerDelegate
    @available(iOS 14, *)
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        
        guard #available(iOS 18.0, *) else {
            predictionResultLabel.text = "iOS 18.0 or later is required for this async operation."
            return
        }

        guard let result = results.first else {
            predictionResultLabel.text = "No image selected."
            return
        }

        activityIndicator.startAnimating()
        predictionResultLabel.text = "Loading image..."
        
        result.itemProvider.loadObject(ofClass: UIImage.self) { [weak self] (object, error) in
            DispatchQueue.main.async { // Ensure UI updates are on main thread
                guard let self = self else { return }
                self.activityIndicator.stopAnimating()
                
                if let error = error {
                    self.predictionResultLabel.text = "Error loading image: \(error.localizedDescription)"
                    self.imageView.image = nil
                    return
                }
                
                guard let image = object as? UIImage else {
                    self.predictionResultLabel.text = "Failed to get image."
                    self.imageView.image = nil
                    return
                }
                
                self.imageView.image = image
                self.predictionResultLabel.text = "Performing prediction..."
                
                Task { @MainActor in // Perform prediction on MainActor
                    do {
                        let predictions = try await self.coordinator.performPrediction(on: image)
                        if let firstPrediction = predictions.first {
                            self.predictionResultLabel.text = "Predicted: \(firstPrediction.label) (\(String(format: "%.2f%%", firstPrediction.confidence * 100)))"
                            self.predictionResultLabel.textColor = .systemGreen
                        } else {
                            self.predictionResultLabel.text = "No predictions found."
                            self.predictionResultLabel.textColor = .orange
                        }
                    } catch {
                        self.predictionResultLabel.text = "Prediction Error: \(error.localizedDescription)"
                        self.predictionResultLabel.textColor = .red
                    }
                }
            }
        }
    }
}
