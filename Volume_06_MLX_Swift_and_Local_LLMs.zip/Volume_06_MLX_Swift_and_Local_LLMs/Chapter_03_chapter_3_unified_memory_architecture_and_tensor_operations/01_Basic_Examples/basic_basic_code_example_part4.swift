
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.swift
// Description: Basic Code Example
// ==========================================

// Continuation of the example in the same file or a new one.

@available(iOS 17.0, macOS 14.0, *)
extension BasicMLXExample {

    /// Defines a simple Mean Squared Error (MSE) loss function.
    /// - Parameters:
    ///   - predictions: The model's output logits.
    ///   - targets: The true target labels (one-hot encoded or integer indices).
    /// - Returns: The calculated MSE loss as an `MLXArray`.
    func meanSquaredErrorLoss(predictions: MLXArray, targets: MLXArray) -> MLXArray {
        // Assuming targets are one-hot encoded for simplicity here.
        // For classification, crossEntropy is more common, but MSE demonstrates the concept.
        return mean(square(predictions - targets))
    }

    func runGradientExample() {
        print("\n--- MLX Gradient Example: valueAndGradient ---")

        let inputFeatures = 5
        let outputIntents = 3

        let model = VoiceIntentClassifier(inputFeatures: inputFeatures, outputIntents: outputIntents)

        // Generate dummy input and target for training
        let audioFeaturesSwift: [Float] = [0.1, 0.5, 0.2, 0.8, 0.3]
        let inputTensor = MLXArray(audioFeaturesSwift, [1, inputFeatures])

        // Simulate a target: "Play Music" (index 0)
        let targetSwift: [Float] = [1.0, 0.0, 0.0] // One-hot encoded
        let targetTensor = MLXArray(targetSwift, [1, outputIntents])

        // 6. Using `valueAndGradient`
        // This function takes a function (our loss function) and the parameters
        // for which gradients are desired. It returns the computed value (loss)
        // and a dictionary of gradients.
        print("\n6. Computing Loss and Gradients with `valueAndGradient`:")

        // Define a closure for the loss computation that captures `inputTensor` and `targetTensor`
        let lossFn = { (model: VoiceIntentClassifier, input: MLXArray, target: MLXArray) -> MLXArray in
            let predictions = model(input)
            return self.meanSquaredErrorLoss(predictions: predictions, targets: target)
        }

        // Call valueAndGradient, specifying the model parameters for which we want gradients.
        // The parameters are automatically managed by MLXNN.Module.
        let (loss, gradients) = valueAndGradient(lossFn)(model, inputTensor, targetTensor)

        // Both `loss` and `gradients` are still lazy computations.
        // We need to `eval()` them to trigger the actual computation of the graph.
        eval(loss, gradients) // Evaluate both the loss and all gradients

        print("\n   Calculated Loss: \(loss)")
        print("   Calculated Gradients:")
        for (key, value) in gradients {
            print("     \(key): \(value)")
        }

        print("\n   Reiterating Lazy Evaluation:")
        print("   `valueAndGradient` constructs a complex computation graph for both forward (loss) and backward (gradients) passes.")
        print("   The graph is only executed when `eval()` is called on the resulting `loss` and `gradients` MLXArrays.")
        print("   This allows MLX to optimize the entire process, including memory allocation and kernel scheduling, before execution.")
    }
}

// To run this gradient example:
/*
if #available(iOS 17.0, macOS 14.0, *) {
    let example = BasicMLXExample()
    example.runBasicExample()
    example.runModelExample()
    example.runGradientExample() // Call the new gradient example
} else {
    print("MLX requires iOS 17.0+ or macOS 14.0+.")
}
*/
