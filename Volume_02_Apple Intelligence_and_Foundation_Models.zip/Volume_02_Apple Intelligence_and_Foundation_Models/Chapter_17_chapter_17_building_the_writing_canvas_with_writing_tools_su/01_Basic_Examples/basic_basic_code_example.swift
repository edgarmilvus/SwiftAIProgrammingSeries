
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import UIKit
import Foundation // Included for general utility, though not strictly necessary for this minimal example.

// MARK: - 1. Class Definition and Availability

/// A `UIViewController` that simulates a chat message composer.
///
/// This example demonstrates the integration of Apple Intelligence Writing Tools
/// into a standard `UITextView`, allowing users to leverage system-provided AI
/// capabilities for text enhancement directly within the text input area.
@available(iOS 18.0, *) // Writing Tools APIs are available from iOS 18.0 onwards.
class ChatComposerViewController: UIViewController {

    // MARK: - 2. UI Elements Setup

    /// The `UITextView` where the user composes their chat message.
    /// This is the primary component that will gain Writing Tools capabilities.
    private lazy var messageTextView: UITextView = {
        let textView = UITextView()
        textView.font = UIFont.preferredFont(forTextStyle: .body)
        textView.layer.borderColor = UIColor.systemGray3.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 8.0
        textView.textContainerInset = UIEdgeInsets(top: 12, left: 8, bottom: 12, right: 8)
        textView.translatesAutoresizingMaskIntoConstraints = false

        // CRITICAL: Enable Writing Tools for this text view.
        // This single property is the primary way to opt-in a UITextView
        // to receive Apple Intelligence Writing Tools suggestions and actions.
        // When true, the system will automatically augment the text editing
        // context menu with options like "Rewrite", "Proofread", etc.
        textView.isWritingToolsEnabled = true

        // For demonstration, let's pre-fill some text to easily trigger Writing Tools
        // when interacting with the text view after it appears.
        textView.text = "Hey there! I'm really looking forward to our meeting next week. I wanted to discuss the new project proposal and some exciting ideas I have. Let me know if you have any questions."
        textView.textColor = .label // Set to normal text color since it's pre-filled

        // Set delegate to handle optional placeholder behavior (see extension below).
        textView.delegate = self

        return textView
    }()

    /// A simple button to simulate sending the message.
    /// Its primary purpose here is to provide context for the `messageTextView`.
    private lazy var sendButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Send Message", for: .normal)
        button.titleLabel?.font = UIFont.preferredFont(forTextStyle: .headline)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(sendMessage), for: .touchUpInside)
        return button
    }()

    // MARK: - 3. View Lifecycle and Layout

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "AI Chat Composer"

        // 3.1: Add the message text view to the view hierarchy.
        // This makes the text view visible and interactive within our view controller.
        view.addSubview(messageTextView)

        // 3.2: Add the send button to the view hierarchy.
        view.addSubview(sendButton)

        // 3.3: Set up Auto Layout constraints for the UI elements.
        // This defines the size and position of our text view and button on the screen.
        setupConstraints()
    }

    /// Configures the Auto Layout constraints for the `messageTextView` and `sendButton`.
    /// This ensures the UI elements are properly positioned and sized across different device orientations and sizes.
    private func setupConstraints() {
        NSLayoutConstraint.activate([
            // Constraints for the messageTextView:
            // Pin to the top safe area, with padding.
            messageTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            // Pin to leading and trailing safe areas, with padding.
            messageTextView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 16),
            messageTextView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -16),
            // Give it a fixed height for simplicity in this example.
            messageTextView.heightAnchor.constraint(equalToConstant: 200),

            // Constraints for the sendButton:
            // Position below the messageTextView, with padding.
            sendButton.topAnchor.constraint(equalTo: messageTextView.bottomAnchor, constant: 20),
            // Center horizontally in the view.
            sendButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            // Give it a fixed width and height.
            sendButton.widthAnchor.constraint(equalToConstant: 180),
            sendButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    // MARK: - 4. User Actions

    /// Handles the "Send Message" button tap.
    /// In a real application, this method would typically send the message content
    /// to a chat server or process it further. Here, it simply prints the message
    /// to the console for demonstration purposes.
    @objc private func sendMessage() {
        print("Message Sent: \(messageTextView.text ?? "Empty Message")")
        // In a production app, you might clear the text view after sending:
        // messageTextView.text = ""
    }
}

// MARK: - 5. UITextViewDelegate for Optional Placeholder Behavior

/// An extension to `ChatComposerViewController` to conform to `UITextViewDelegate`.
/// This is an optional but good practice for handling placeholder text behavior
/// in `UITextView`, making the user experience more intuitive.
@available(iOS 18.0, *)
extension ChatComposerViewController: UITextViewDelegate {

    /// Called when the text view begins editing.
    /// If the current text is the placeholder, it clears it and sets the text color
    /// to the standard label color, preparing for user input.
    func textViewDidBeginEditing(_ textView: UITextView) {
        // This specific check is for a more advanced placeholder pattern where
        // the placeholder text is initially set as the actual `text` property.
        // For this example, we pre-fill actual content, so this part isn't strictly
        // needed unless we wanted to revert to a placeholder if the pre-filled text
        // was deleted by the user.
        // If we had an empty textView initially with placeholder logic:
        /*
        if textView.textColor == .placeholderText {
            textView.text = nil
            textView.textColor = .label
        }
        */
    }

    /// Called when the text view finishes editing.
    /// If the text view is empty after editing, it restores the placeholder text
    /// and sets its color to indicate it's a placeholder.
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Type your message here..."
            textView.textColor = .placeholderText
        }
    }
}

// MARK: - How to Test This Code

// To run this code:
// 1. Create a new Xcode project (e.g., using the "App" template for iOS).
// 2. Ensure your project's deployment target is set to iOS 18.0 or later.
// 3. Replace the content of your `ViewController.swift` (if using a UIKit App delegate)
//    or create a new file and set it as the root view controller.
//    For `SceneDelegate.swift` based projects, modify the `scene(_:willConnectTo:options:)` method:
/*
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        let window = UIWindow(windowScene: windowScene)
        window.rootViewController = ChatComposerViewController() // Set your custom VC here
        self.window = window
        window.makeKeyAndVisible()
    }
*/
// 4. Build and run the app on an iOS 18.0 simulator or a compatible device.
//    (Note: Full Apple Intelligence features require specific hardware, e.g., A17 Pro or M-series chips,
//    but the API and UI integration should be visible on iOS 18.0 simulators for development).
// 5. Once the app is running, long-press on the text within the `messageTextView`.
//    You should see the standard text editing menu augmented with new options
//    like "Rewrite", "Proofread", and potentially others, demonstrating Writing Tools in action.
