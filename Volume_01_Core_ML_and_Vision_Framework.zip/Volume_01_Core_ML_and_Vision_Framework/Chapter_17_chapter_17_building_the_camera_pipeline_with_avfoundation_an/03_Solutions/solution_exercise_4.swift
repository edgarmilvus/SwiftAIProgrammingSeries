
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import AVFoundation
import Vision

// MARK: - DocumentStabilityTracker
class DocumentStabilityTracker {
    private var lastObservedRectangle: VNRectangleObservation?
    private var lastObservationTime: TimeInterval = 0
    private let stabilityThreshold: TimeInterval = 1.5 // seconds
    private let positionTolerance: CGFloat = 0.05 // % difference for position/size
    private let minOverlap: CGFloat = 0.9 // IoU for similarity

    var isDocumentStable: Bool = false
    var stableRectangle: VNRectangleObservation?

    func update(with newRectangle: VNRectangleObservation?, currentTime: TimeInterval) {
        guard let newRect = newRectangle else {
            // No rectangle detected, reset stability
            reset()
            return
        }

        if let lastRect = lastObservedRectangle {
            let iou = self.iou(lastRect.boundingBox, newRect.boundingBox)
            let centerDiffX = abs(lastRect.boundingBox.midX - newRect.boundingBox.midX)
            let centerDiffY = abs(lastRect.boundingBox.midY - newRect.boundingBox.midY)
            let sizeDiffWidth = abs(lastRect.boundingBox.width - newRect.boundingBox.width)
            let sizeDiffHeight = abs(lastRect.boundingBox.height - newRect.boundingBox.height)

            // Check for significant overlap and minimal change in position/size
            if iou > minOverlap &&
               centerDiffX < positionTolerance && centerDiffY < positionTolerance &&
               sizeDiffWidth < positionTolerance && sizeDiffHeight < positionTolerance {

                if !isDocumentStable && (currentTime - lastObservationTime) > stabilityThreshold {
                    isDocumentStable = true
                    stableRectangle = newRect // Store the stable rectangle
                }
            } else {
                // Rectangle changed significantly, reset stability count
                isDocumentStable = false
                stableRectangle = nil
                lastObservationTime = currentTime
            }
        } else {
            // First rectangle detected, start tracking time
            lastObservationTime = currentTime
            isDocumentStable = false
            stableRectangle = nil
        }
        lastObservedRectangle = newRect
    }

    func reset() {
        lastObservedRectangle = nil
        lastObservationTime = 0
        isDocumentStable = false
        stableRectangle = nil
    }

    // Intersection over Union helper
    private func iou(_ rect1: CGRect, _ rect2: CGRect) -> CGFloat {
        let intersection = rect1.intersection(rect2)
        let union = rect1.union(rect2)
        if union.width == 0 || union.height == 0 { return 0 }
        return (intersection.width * intersection.height) / (union.width * union.height)
    }
}

class DocumentScannerViewController: UIViewController {

    private var captureSession: AVCaptureSession!
    private var previewLayer: AVCaptureVideoPreviewLayer!
    private var videoDataOutput: AVCaptureVideoDataOutput!
    private let videoDataOutputQueue = DispatchQueue(label: "VideoDataOutput", qos: .userInitiated)

    private var rectangleDetectionRequest: VNDetectRectangleRequest!
    private var textRecognitionRequest: VNRecognizeTextRequest!

    private var documentOverlayLayers: [CAShapeLayer] = []
    private var textOverlayLayers: [CAShapeLayer] = []
    private var stabilityTracker = DocumentStabilityTracker()
    private var stabilityLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
        setupVision()
        setupUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !captureSession.isRunning {
            videoDataOutputQueue.async {
                self.captureSession.startRunning()
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession.isRunning {
            videoDataOutputQueue.async {
                self.captureSession.stopRunning()
            }
        }
        clearAllOverlays()
        stabilityTracker.reset()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer.frame = view.bounds
        DispatchQueue.main.async {
            self.clearAllOverlays() // Clear overlays if layout changes
        }
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .hd1920x1080

        guard let backCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Unable to access back camera.")
            return
        }

        do {
            let input = try AVCaptureDeviceInput(device: backCamera)
            if captureSession.canAddInput(input) {
                captureSession.addInput(input)
            }

            videoDataOutput = AVCaptureVideoDataOutput()
            videoDataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
            videoDataOutput.alwaysDiscardsLateVideoFrames = true
            videoDataOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

            if captureSession.canAddOutput(videoDataOutput) {
                captureSession.addOutput(videoDataOutput)
            }

            if let connection = videoDataOutput.connection(with: .video), connection.isVideoOrientationSupported {
                connection.videoOrientation = .portrait
            }

            previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            previewLayer.videoGravity = .resizeAspectFill
            previewLayer.frame = view.bounds
            view.layer.addSublayer(previewLayer)

        } catch {
            print("Error setting up camera input: \(error.localizedDescription)")
        }
    }

    private func setupVision() {
        rectangleDetectionRequest = VNDetectRectangleRequest()
        // Configure to detect only one large rectangle (the document)
        rectangleDetectionRequest.maximumObservations = 1
        rectangleDetectionRequest.minimumAspectRatio = 0.5 // Documents are usually not extremely wide/tall
        rectangleDetectionRequest.maximumAspectRatio = 2.0
        rectangleDetectionRequest.quadratureTolerance = 10 // How much distortion is allowed

        textRecognitionRequest = VNRecognizeTextRequest()
        textRecognitionRequest.recognitionLevel = .fast // Prioritize speed over accuracy
        textRecognitionRequest.usesLanguageCorrection = false // Faster without language correction
        // textRecognitionRequest.revision = VNRecognizeTextRequest.Revision.2 // For better performance on newer OS

        // Combine requests for concurrent execution
        textRecognitionRequest.recognitionPoints = nil // Don't need individual character boxes for this scenario
    }

    private func setupUI() {
        stabilityLabel = UILabel()
        stabilityLabel.translatesAutoresizingMaskIntoConstraints = false
        stabilityLabel.textColor = .white
        stabilityLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        stabilityLabel.textAlignment = .center
        stabilityLabel.numberOfLines = 1
        stabilityLabel.shadowColor = .black
        stabilityLabel.shadowOffset = CGSize(width: 1, height: 1)
        stabilityLabel.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        stabilityLabel.layer.cornerRadius = 8
        stabilityLabel.clipsToBounds = true
        stabilityLabel.text = "Searching for document..."
        view.addSubview(stabilityLabel)

        NSLayoutConstraint.activate([
            stabilityLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stabilityLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            stabilityLabel.widthAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.widthAnchor, constant: -40),
            stabilityLabel.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    private func clearAllOverlays() {
        for layer in documentOverlayLayers { layer.removeFromSuperlayer() }
        documentOverlayLayers.removeAll()
        for layer in textOverlayLayers { layer.removeFromSuperlayer() }
        textOverlayLayers.removeAll()
    }

    private func drawRectangleOverlay(observation: VNRectangleObservation, isStable: Bool) -> CAShapeLayer {
        let rect = observation.boundingBox(in: previewLayer)
        let layer = CAShapeLayer()
        layer.path = UIBezierPath(rect: rect).cgPath
        layer.strokeColor = isStable ? UIColor.green.cgColor : UIColor.blue.cgColor
        layer.lineWidth = 3.0
        layer.fillColor = UIColor.clear.cgColor
        return layer
    }

    private func drawTextOverlay(observation: VNTextObservation) -> CAShapeLayer {
        let rect = observation.boundingBox(in: previewLayer)
        let layer = CAShapeLayer()
        layer.path = UIBezierPath(rect: rect).cgPath
        layer.strokeColor = UIColor.yellow.cgColor
        layer.lineWidth = 1.5
        layer.fillColor = UIColor.clear.cgColor
        return layer
    }
}

extension DocumentScannerViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Use autoreleasepool to manage memory for each frame processing cycle
        autoreleasepool {
            let imageOrientation = CGImagePropertyOrientation(
                interfaceOrientation: UIApplication.shared.windows.first?.windowScene?.interfaceOrientation ?? .portrait
            )

            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: imageOrientation, options: [:])

            let group = DispatchGroup()
            var rectangleObservations: [VNRectangleObservation]?
            var textObservations: [VNRecognizeTextObservation]?
            var detectionError: Error?

            // Perform rectangle detection concurrently
            group.enter()
            videoDataOutputQueue.async {
                do {
                    try handler.perform([self.rectangleDetectionRequest])
                    rectangleObservations = self.rectangleDetectionRequest.results as? [VNRectangleObservation]
                } catch {
                    detectionError = error
                }
                group.leave()
            }

            // Perform text recognition concurrently
            group.enter()
            videoDataOutputQueue.async {
                do {
                    try handler.perform([self.textRecognitionRequest])
                    textObservations = self.textRecognitionRequest.results as? [VNRecognizeTextObservation]
                } catch {
                    detectionError = error
                }
                group.leave()
            }

            // Wait for both requests to complete, then update UI on main thread
            group.notify(queue: .main) {
                self.clearAllOverlays()

                if let error = detectionError {
                    print("Vision processing failed: \(error.localizedDescription)")
                    self.stabilityTracker.reset()
                    self.stabilityLabel.text = "Error: \(error.localizedDescription)"
                    return
                }

                // Process Rectangle Observations
                let currentRectObservation = rectangleObservations?.first
                self.stabilityTracker.update(with: currentRectObservation, currentTime: CACurrentMediaTime())

                if let rect = currentRectObservation {
                    let documentLayer = self.drawRectangleOverlay(observation: rect, isStable: self.stabilityTracker.isDocumentStable)
                    self.previewLayer.addSublayer(documentLayer)
                    self.documentOverlayLayers.append(documentLayer)
                }

                // Update stability label
                if self.stabilityTracker.isDocumentStable {
                    self.stabilityLabel.text = "Document Ready!"
                    self.stabilityLabel.textColor = .green
                } else {
                    self.stabilityLabel.text = "Searching for document..."
                    self.stabilityLabel.textColor = .white
                }

                // Process Text Observations
                if let texts = textObservations {
                    for textObservation in texts {
                        // For VNRecognizeTextObservation, boundingBox refers to the line/word
                        let textLayer = self.drawTextOverlay(observation: textObservation)
                        self.previewLayer.addSublayer(textLayer)
                        self.textOverlayLayers.append(textLayer)
                    }
                }
            }
        }
    }
}

// MARK: - Helper Extensions (reused from previous exercises)

extension CGImagePropertyOrientation {
    init(interfaceOrientation: UIInterfaceOrientation) {
        switch interfaceOrientation {
        case .portrait: self = .up
        case .portraitUpsideDown: self = .down
        case .landscapeLeft: self = .right
        case .landscapeRight: self = .left
        default: self = .up
        }
    }
}

// Extension for VNRectangleObservation to convert bounding box
extension VNRectangleObservation {
    func boundingBox(in previewLayer: AVCaptureVideoPreviewLayer) -> CGRect {
        let flippedBoundingBox = CGRect(
            x: boundingBox.origin.x,
            y: 1 - boundingBox.origin.y - boundingBox.height,
            width: boundingBox.width,
            height: boundingBox.height
        )
        return previewLayer.layerRectConverted(fromMetadataOutputRect: flippedBoundingBox)
    }
}

// Extension for VNTextObservation to convert bounding box
extension VNTextObservation {
    func boundingBox(in previewLayer: AVCaptureVideoPreviewLayer) -> CGRect {
        let flippedBoundingBox = CGRect(
            x: boundingBox.origin.x,
            y: 1 - boundingBox.origin.y - boundingBox.height,
            width: boundingBox.width,
            height: boundingBox.height
        )
        return previewLayer.layerRectConverted(fromMetadataOutputRect: flippedBoundingBox)
    }
}
