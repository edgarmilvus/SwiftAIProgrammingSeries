
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import MLX
import MLXNN

// Reuse MLPClassifier from Exercise 2
class MLPClassifier: MLXNN.Module {
    let inputLayer: MLXNN.Linear
    let hiddenLayer1: MLXNN.Linear
    let hiddenLayer2: MLXNN.Linear
    let outputLayer: MLXNN.Linear
    let activation: MLXNN.ReLU

    init(inputFeatures: Int, hiddenDim1: Int, hiddenDim2: Int, outputClasses: Int) {
        self.inputLayer = MLXNN.Linear(inputSize: inputFeatures, outputSize: hiddenDim1)
        self.hiddenLayer1 = MLXNN.Linear(inputSize: hiddenDim1, outputSize: hiddenDim2)
        self.hiddenLayer2 = MLXNN.Linear(inputSize: hiddenDim2, outputSize: hiddenDim2)
        self.outputLayer = MLXNN.Linear(inputSize: hiddenDim2, outputSize: outputClasses)
        self.activation = MLXNN.ReLU()
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        let h1 = activation(inputLayer(x))
        let h2 = activation(hiddenLayer1(h1))
        let h3 = activation(hiddenLayer2(h2))
        return outputLayer(h3)
    }
}

// Main execution block
print("\n--- Exercise 4: Basic Training Loop with valueAndGradient ---")

// 1. Refine MLPClassifier (reused) and Data Generation
let numFeatures = 3
let outputClasses = 2
let hiddenDim1 = 64
let hiddenDim2 = 32
let learningRate: Float = 0.01
let numEpochs = 10

// Generate a larger synthetic dataset for training
let numSamples = 100

// Features: Random data for 100 users, 3 features each
let x_train_data = (0..<numSamples * numFeatures).map { _ in Float.random(in: 0.0...100.0) }
let x_train = MLXArray(x_train_data, shape: [numSamples, numFeatures], type: .float32)

// Target labels: Randomly assign 0 (low risk) or 1 (high risk)
// For a more realistic scenario, these would be correlated with x_train
let y_train_data = (0..<numSamples).map { _ in Int.random(in: 0...1) }
let y_train = MLXArray(y_train_data, type: .int32) // Labels must be Int for crossEntropy

print("\nTraining data generated: \(numSamples) samples.")
print("x_train shape: \(x_train.shape)")
print("y_train shape: \(y_train.shape)")

let model = MLPClassifier(inputFeatures: numFeatures, hiddenDim1: hiddenDim1, hiddenDim2: hiddenDim2, outputClasses: outputClasses)

// 2. Define the Loss Function
func lossFn(model: MLPClassifier, x: MLXArray, y: MLXArray) -> MLXArray {
    let logits = model(x)
    // Calculate cross-entropy loss. labels must be Int.
    return MLXNN.losses.crossEntropy(logits: logits, labels: y, reduction: .mean)
}

// 3. Implement the Training Step with valueAndGradient
print("\nStarting training loop for \(numEpochs) epochs...")

for epoch in 0..<numEpochs {
    // Compute loss and gradients with respect to model parameters
    // MLX.valueAndGradient takes the function, then the arguments to differentiate with respect to.
    // Here, we want gradients for the 'model' parameters.
    let (loss, gradients) = MLX.valueAndGradient(lossFn, model, x_train, y_train)

    // Manually update model parameters
    // `model.parameters()` returns a dictionary of [String: MLXArray]
    // `gradients` from `valueAndGradient` is also a [String: MLXArray]
    for (name, param) in model.parameters() {
        if let grad = gradients[name] {
            // Update the parameter: param = param - learningRate * grad
            // `param.update()` modifies the MLXNN.Parameter in place.
            param.update(param.array - learningRate * grad)
        }
    }

    // Print the loss for each epoch. This triggers the execution of the graph.
    print("Epoch \(epoch + 1): Loss = \(loss.toFloat())")
}

print("\nTraining complete.")

print("\nDiscussion on Functional Transformation and Lazy Evaluation:")
print("`MLX.valueAndGradient` is a core example of a functional transformation in MLX.")
print("It takes a function (`lossFn`) and returns a new function (implicitly, through its execution) that computes both the original function's value (loss) and its gradient with respect to specified inputs (model parameters).")
print("It does not modify the model state directly; instead, it computes the gradients which are then used to *manually* update the parameters.")
print("This functional approach allows MLX to build a complete computational graph for the forward pass, loss calculation, and backpropagation.")
print("MLX's lazy evaluation means that this entire graph is constructed symbolically.")
print("The actual numerical computations on the CPU/GPU/Neural Engine are only performed when the `loss` or `gradients` MLXArray instances are explicitly accessed (e.g., by calling `.toFloat()` or iterating through `gradients`).")
print("This deferred execution allows MLX to perform global optimizations on the graph (e.g., fusing operations, optimizing memory usage) before dispatching the work to the hardware, leading to highly efficient execution.")
