
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

/// Custom error types for safety violations
enum SafetyError: Error, LocalizedError {
    case prohibitedTermDetected(String)
    case emptyInput
    
    var errorDescription: String? {
        switch self {
        case .prohibitedTermDetected(let term):
            return "Input contains prohibited content: \(term)."
        case .emptyInput:
            return "Input cannot be empty."
        }
    }
}

@available(iOS 18.0, *)
actor ContentFilter {
    private var blacklist: Set<String>
    
    // Mapping for simple leetspeak/obfuscation normalization
    private let obfuscationMap: [Character: Character] = [
        "0": "o", "1": "i", "3": "e", "4": "a", "@": "a", 
        "5": "s", "$": "s", "7": "t", "!": "i", "v": "v" // 'v' is standard, but helps logic
    ]

    init(blacklist: Set<String>) {
        // Store blacklist in lowercase for consistent matching
        self.blacklist = Set(blacklist.map { $0.lowercased() })
    }

    /// Normalizes input by removing special characters and resolving leetspeak
    private func normalize(_ input: String) -> String {
        let lowercased = input.lowercased()
        var normalized = ""
        
        for char in lowercased {
            if let replacement = obfuscationMap[char] {
                normalized.append(replacement)
            } else if char.isLetter || char.isWhitespace {
                normalized.append(char)
            }
            // Ignore emojis and special symbols here to prevent obfuscation like "v!olence"
        }
        return normalized
    }

    /// Validates the input against the blacklist using word boundaries
    func validate(input: String) async throws -> Bool {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw SafetyError.emptyInput }

        let normalizedInput = normalize(trimmed)
        
        // Check each word in the normalized input to respect word boundaries
        // This prevents "badminton" from being flagged if "bad" is blocked.
        let words = normalizedInput.components(separatedBy: .whitespacesAndNewlines)
        
        for word in words {
            // We use a regex-like approach or direct set lookup for efficiency
            // Since we split by whitespace, direct lookup is safe for single words
            if blacklist.contains(word) {
                throw SafetyError.prohibitedTermDetected(word)
            }
            
            // Secondary check for substring within a word if the word itself isn't the hit
            // but contains a prohibited sequence (e.g., "v!olence" -> "violence")
            for prohibited in blacklist {
                if word.contains(prohibited) {
                    throw SafetyError.prohibitedTermDetected(prohibited)
                }
            }
        }
        
        return true
    }
}

// MARK: - Usage Example
@MainActor
func runExample() async {
    let filter = ContentFilter(blacklist: ["violence", "scary", "bad"])
    
    let testInputs = ["Tell me a story", "v!olence is bad", "badminton", "  ", "sc@ry"]
    
    for input in testInputs {
        do {
            let isSafe = try await filter.validate(input: input)
            print("✅ Input: '\(input)' -> Safe: \(isSafe)")
        } catch {
            print("❌ Input: '\(input)' -> Error: \(error.localizedDescription)")
        }
    }
}
