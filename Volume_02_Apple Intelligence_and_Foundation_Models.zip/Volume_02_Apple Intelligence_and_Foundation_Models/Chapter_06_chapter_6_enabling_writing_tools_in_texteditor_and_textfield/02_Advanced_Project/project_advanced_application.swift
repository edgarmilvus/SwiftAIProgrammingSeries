
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// MARK: - Package.swift (Illustrative Swift Package Manager Manifest)
// This section demonstrates how a project might define its dependencies.
// For Apple's WritingTools framework, no external SPM dependencies are strictly required,
// as it's part of the iOS/macOS SDK. However, for a real-world app with custom AI,
// you might include Core ML or other libraries here.

/*
import PackageDescription

let package = Package(
    name: "SmartDocumentEditor",
    platforms: [
        .iOS(.v18), // WritingTools and associated APIs require iOS 18+
        .macOS(.v15) // Or other platforms supporting Apple Intelligence
    ],
    products: [
        .library(
            name: "SmartDocumentEditor",
            targets: ["SmartDocumentEditor"]),
    ],
    dependencies: [
        // Example: If integrating a custom text analysis library or a remote AI SDK
        // .package(url: "https://github.com/example/text-analyzer.git", from: "1.0.0")
    ],
    targets: [
        .target(
            name: "SmartDocumentEditor",
            dependencies: []),
        .testTarget(
            name: "SmartDocumentEditorTests",
            dependencies: ["SmartDocumentEditor"]),
    ]
)
*/

// MARK: - DocumentViewModel.swift & Supporting Types

import Foundation
import SwiftUI // Required for WritingToolsConfiguration and TextEditor
import Observation // For @Observable

/// 1. DocumentPurpose Enum: Defines the types of documents our editor supports.
///    Each purpose carries specific instructions for Apple Intelligence Writing Tools.
enum DocumentPurpose: String, CaseIterable, Identifiable {
    case general = "General Note"
    case formalReport = "Formal Report"
    case creativeStory = "Creative Story"
    case technicalDoc = "Technical Document"
    case codeSnippet = "Code Snippet"

    var id: String { self.rawValue }

    /// Provides a detailed textual context hint for Apple's Writing Tools.
    /// This is crucial for guiding the underlying Apple Intelligence models.
    var writingToolsContextHint: String {
        switch self {
        case .general: return "This is a general note or memo, suitable for everyday communication."
        case .formalReport: return "This is a formal business or academic report, requiring precise, concise, and professional language. Focus on clarity, objectivity, and adherence to formal tone."
        case .creativeStory: return "This is a piece of creative writing, such as a short story or poem. Emphasize vivid imagery, engaging narrative, unique vocabulary, and emotional resonance. Grammar and structure can be more flexible for artistic effect."
        case .technicalDoc: return "This is a technical document, like an API specification or user manual. Prioritize clarity, accuracy, unambiguous language, and structured information. Jargon is acceptable if consistent within the domain."
        case .codeSnippet: return "This is a code snippet or programming example. Grammar and spelling checks are largely irrelevant; focus on syntax, variable naming, and comments if applicable. Writing Tools should generally be disabled or minimal."
        }
    }

    /// Determines if Writing Tools should be fully enabled for this purpose.
    var areWritingToolsEnabled: Bool {
        switch self {
        case .codeSnippet: return false // Writing Tools are typically not helpful for code
        default: return true
        }
    }

    /// Provides a user-friendly description for UI display.
    var description: String {
        switch self {
        case .general: return "Basic grammar and style checks."
        case .formalReport: return "Focus on professionalism, conciseness, and tone."
        case .creativeStory: return "Emphasize flow, vocabulary, and imagery."
        case .technicalDoc: return "Prioritize clarity, accuracy, and structure."
        case .codeSnippet: return "Writing Tools disabled for code."
        }
    }
}

/// 2. ContentAnalyzer Class: A simulated service for inferring document purpose.
///    In a real application, this would integrate with sophisticated NLP models
///    (e.g., Core ML, a custom backend AI service, or a large language model API).
class ContentAnalyzer {
    enum AnalysisError: Error, LocalizedError {
        case emptyContent
        case analysisFailed(String)

        var errorDescription: String? {
            switch self {
            case .emptyContent: return "Content cannot be empty for analysis."
            case .analysisFailed(let reason): return "Content analysis failed: \(reason)"
            }
        }
    }

    /// Asynchronously analyzes the given text to infer its purpose.
    /// - Parameter text: The document content to analyze.
    /// - Returns: The inferred `DocumentPurpose`.
    /// - Throws: `AnalysisError` if the content is empty or analysis fails.
    func analyze(text: String) async throws -> DocumentPurpose {
        guard !text.isEmpty else {
            throw AnalysisError.emptyContent
        }

        // Simulate a delay for a complex AI operation or network call
        try await Task.sleep(for: .milliseconds(700))

        let lowercasedText = text.lowercased()

        // Simple keyword-based classification for demonstration
        if lowercasedText.contains("func") || lowercasedText.contains("var") || lowercasedText.contains("import") || lowercasedText.contains("class") || lowercasedText.contains("let ") {
            return .codeSnippet
        }
        if lowercasedText.contains("report") || lowercasedText.contains("memo") || lowercasedText.contains("official") || lowercasedText.contains("executive summary") || lowercasedText.contains("policy") {
            return .formalReport
        }
        if lowercasedText.contains("story") || lowercasedText.contains("chapter") || lowercasedText.contains("narrative") || lowercasedText.contains("poem") || lowercasedText.contains("character") {
            return .creativeStory
        }
        if lowercasedText.contains("api") || lowercasedText.contains("architecture") || lowercasedText.contains("specification") || lowercasedText.contains("algorithm") || lowercasedText.contains("protocol") {
            return .technicalDoc
        }
        return .general
    }
}

/// 3. DocumentViewModel: Manages the document's state and dynamically configures Writing Tools.
///    Uses `@Observable` for efficient SwiftUI updates and `async/await` for analysis.
@Observable
@available(iOS 18.0, *) // WritingToolsConfiguration is iOS 18+
final class DocumentViewModel {
    /// The current content of the document being edited.
    var documentContent: String = "" {
        didSet {
            // Trigger debounced analysis when content changes to avoid excessive processing
            Task { @MainActor in
                await debounceAnalysis()
            }
        }
    }

    /// The inferred purpose of the document, which drives Writing Tools configuration.
    var currentDocumentPurpose: DocumentPurpose = .general {
        didSet {
            // Update Writing Tools configuration immediately when purpose changes
            updateWritingToolsConfiguration()
        }
    }

    /// The `WritingToolsConfiguration` applied to the `TextEditor`.
    /// This property is observed by the `TextEditor` and dynamically changes its behavior.
    var writingToolsConfig: WritingToolsConfiguration

    /// Indicates if a content analysis operation is currently in progress.
    var isAnalyzing: Bool = false

    /// Stores any error encountered during analysis for UI display.
    var analysisError: Error?

    private let contentAnalyzer = ContentAnalyzer()
    private var analysisTask: Task<Void, Never>? // Used for debouncing

    /// Initializes the ViewModel with a default configuration.
    init() {
        // Initialize with a default, basic Writing Tools configuration
        self.writingToolsConfig = WritingToolsConfiguration(
            isEnabled: true,
            context: WritingToolsConfiguration.Context(
                purpose: DocumentPurpose.general.writingToolsContextHint,
                keywords: ["note", "document", "general"]
            )
        )
    }

    /// Debounces content analysis. This prevents `analyzeContent()` from being called
    /// on every keystroke, improving performance and user experience.
    @MainActor
    private func debounceAnalysis() async {
        analysisTask?.cancel() // Cancel any previous pending analysis task
        analysisTask = Task {
            do {
                try await Task.sleep(for: .seconds(0.8)) // Wait 0.8 seconds after last change
                if !Task.isCancelled {
                    await analyzeContent() // Only analyze if not cancelled by a new keystroke
                }
            } catch {
                // Task.sleep can throw CancellationError, which is expected during debounce
                // This is not an actual error to report to the user.
                print("Debounce task cancelled (expected): \(error.localizedDescription)")
            }
        }
    }

    /// Analyzes the `documentContent` to determine its purpose and update
    /// the `writingToolsConfig` accordingly. This method handles async operations and errors.
    @MainActor
    func analyzeContent() async {
        guard !documentContent.isEmpty else {
            currentDocumentPurpose = .general // Reset purpose for empty content
            analysisError = nil
            return
        }

        isAnalyzing = true
        analysisError = nil

        do {
            let purpose = try await contentAnalyzer.analyze(text: documentContent)
            self.currentDocumentPurpose = purpose // This will trigger updateWritingToolsConfiguration()
        } catch {
            self.analysisError = error
            self.currentDocumentPurpose = .general // Fallback to general purpose on error
            print("Error analyzing content: \(error.localizedDescription)")
        }
        isAnalyzing = false
    }

    /// Updates the `writingToolsConfig` property based on the `currentDocumentPurpose`.
    /// This is the core logic for dynamically adjusting Apple Intelligence Writing Tools.
    private func updateWritingToolsConfiguration() {
        let purpose = currentDocumentPurpose
        self.writingToolsConfig = WritingToolsConfiguration(
            isEnabled: purpose.areWritingToolsEnabled,
            context: WritingToolsConfiguration.Context(
                purpose: purpose.writingToolsContextHint,
                // Keywords can provide additional hints to the system
                keywords: [purpose.rawValue.lowercased().replacingOccurrences(of: " ", with: "-"), "document-editor"]
            ),
            // Granular control: Example of disabling specific categories for code snippets.
            // This demonstrates how an app can fine-tune the Writing Tools experience.
            grammar: purpose == .codeSnippet ? .disabled : .enabled,
            spelling: purpose == .codeSnippet ? .disabled : .enabled,
            // Other categories like `conciseness`, `tone`, `vocabulary` can also be configured
            // if the WritingToolsConfiguration API provides more granular control in future iOS versions.
            conciseness: purpose == .formalReport ? .enabled : .default, // Encourage conciseness for reports
            tone: purpose == .formalReport ? .enabled : .default // Emphasize tone for reports
        )
        print("Writing Tools Config updated for purpose: \(purpose.rawValue)")
    }
}

// MARK: - DocumentEditorView.swift

/// 4. DocumentEditorView: The SwiftUI view that presents the TextEditor and UI controls.
///    It binds to the `DocumentViewModel` and applies the dynamic `WritingToolsConfiguration`.
@available(iOS 18.0, *)
struct DocumentEditorView: View {
    @State private var viewModel = DocumentViewModel()
    @FocusState private var isTextEditorFocused: Bool

    var body: some View {
        NavigationView {
            VStack(spacing: 15) {
                // UI for manually selecting document purpose (for testing/override)
                Picker("Document Purpose (Override)", selection: $viewModel.currentDocumentPurpose) {
                    ForEach(DocumentPurpose.allCases) { purpose in
                        Text(purpose.rawValue)
                            .tag(purpose)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                .disabled(viewModel.isAnalyzing) // Disable interaction during analysis

                // Display of the current Writing Tools configuration
                VStack(alignment: .leading, spacing: 5) {
                    Text("Current Writing Tools Configuration:")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text("Inferred Purpose: \(viewModel.currentDocumentPurpose.rawValue)")
                        .font(.caption2)
                    Text("Description: \(viewModel.currentDocumentPurpose.description)")
                        .font(.caption2)
                    Text("Writing Tools Enabled: \(viewModel.currentDocumentPurpose.areWritingToolsEnabled ? "Yes" : "No")")
                        .font(.caption2)
                    Text("Context Hint: \"\(viewModel.currentDocumentPurpose.writingToolsContextHint.prefix(50))...\"")
                        .font(.caption2)
                }
                .padding(8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.secondary.opacity(0.1))
                .cornerRadius(8)
                .padding(.horizontal)

                // The TextEditor, critically applying the dynamic WritingToolsConfiguration
                TextEditor(text: $viewModel.documentContent)
                    .textInputAutocapitalization(.sentences)
                    .autocorrectionDisabled(false) // Let Writing Tools handle corrections intelligently
                    .font(.body)
                    .padding()
                    .frame(minHeight: 200)
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(radius: 2)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(isTextEditorFocused ? Color.accentColor : Color.gray.opacity(0.3), lineWidth: 2)
                    )
                    .focused($isTextEditorFocused)
                    // CRITICAL: Apply the dynamically configured Writing Tools
                    .writingTools(viewModel.writingToolsConfig)
                    .padding(.horizontal)

                // Status and Error Display
                if viewModel.isAnalyzing {
                    ProgressView("Analyzing content...")
                        .padding()
                } else if let error = viewModel.analysisError {
                    Text("Error: \(error.localizedDescription)")
                        .foregroundColor(.red)
                        .padding()
                } else {
                    Text("Type or paste content above. Analysis automatically updates Writing Tools (debounced).")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .padding(.horizontal)
                }

                Spacer()
            }
            .navigationTitle("Smart Document Editor")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Analyze Now") {
                        Task { @MainActor in
                            await viewModel.analyzeContent()
                        }
                    }
                    .disabled(viewModel.isAnalyzing)
                }
            }
            .background(Color.gray.opacity(0.05).ignoresSafeArea())
            .onAppear {
                // Perform initial analysis if content is pre-filled, or just to set default config
                Task { @MainActor in
                    await viewModel.analyzeContent()
                }
            }
        }
    }
}

// MARK: - SmartDocumentEditorApp.swift

/// 5. SmartDocumentEditorApp: The main App entry point.
@available(iOS 18.0, *)
@main
struct SmartDocumentEditorApp: App {
    var body: some Scene {
        WindowGroup {
            DocumentEditorView()
        }
    }
}
