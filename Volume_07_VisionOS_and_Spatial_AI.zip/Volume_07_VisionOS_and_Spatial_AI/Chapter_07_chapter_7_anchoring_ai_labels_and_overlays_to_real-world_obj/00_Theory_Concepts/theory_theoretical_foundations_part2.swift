
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import CoreML
import Vision
import ARKit // For ARFrame

// Define a simple struct to hold detection results
struct AIDetection: Sendable {
    let boundingBox: CGRect // 2D bounding box in image coordinates
    let label: String
    let confidence: Float
    let frameTimestamp: TimeInterval // To associate with ARFrame
}

@available(visionOS 1.0, *)
actor AIInferenceActor {
    // Assuming 'MyObjectDetector' is a Core ML model generated from a .mlmodel file
    private let model: MyObjectDetector // From a previous chapter, e.g., Chapter 6
    private lazy var visionRequest: VNCoreMLRequest = {
        do {
            let model = try VNCoreMLModel(for: model.model)
            let request = VNCoreMLRequest(model: model) { [weak self] request, error in
                self?.handleVisionRequest(request, error: error)
            }
            request.imageCropAndScaleOption = .centerCrop
            return request
        } catch {
            fatalError("Failed to load Vision Core ML model: \(error)")
        }
    }()

    private var currentDetections: [AIDetection] = []
    private var completionHandlers: [(Result<[AIDetection], Error>) -> Void] = []

    init() {
        // Load your Core ML model here
        guard let modelURL = Bundle.main.url(forResource: "MyObjectDetector", withExtension: "mlmodelc"),
              let compiledModel = try? MLModel(contentsOf: modelURL) else {
            fatalError("Failed to load Core ML model")
        }
        self.model = MyObjectDetector(model: compiledModel)
    }

    // Public method to perform inference, isolated to the actor
    func performInference(on frame: ARFrame) async -> [AIDetection]? {
        guard let pixelBuffer = frame.capturedImage else { return nil }

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up) // Adjust orientation as needed
        do {
            try handler.perform([visionRequest])
            let detections = currentDetections // Access actor's isolated state
            currentDetections = [] // Clear for next inference
            return detections
        } catch {
            print("Failed to perform Vision request: \(error)")
            return nil
        }
    }

    // Private method to handle Vision results, called by the request handler
    private func handleVisionRequest(_ request: VNRequest, error: Error?) {
        guard error == nil else {
            print("Vision request failed with error: \(error!)")
            return
        }

        guard let observations = request.results as? [VNRecognizedObjectObservation] else { return }

        let detections: [AIDetection] = observations.compactMap { observation in
            let label = observation.labels.first?.identifier ?? "Unknown"
            let confidence = observation.labels.first?.confidence ?? 0.0
            // Convert Vision's normalized bounding box to image coordinates (if needed, usually Vision handles this)
            // For simplicity, we'll store the normalized box for now, and convert later during anchoring.
            return AIDetection(
                boundingBox: observation.boundingBox,
                label: label,
                confidence: confidence,
                frameTimestamp: Date().timeIntervalSinceReferenceDate // Placeholder, better to pass ARFrame timestamp
            )
        }
        self.currentDetections = detections // Update actor's isolated state
    }
}
