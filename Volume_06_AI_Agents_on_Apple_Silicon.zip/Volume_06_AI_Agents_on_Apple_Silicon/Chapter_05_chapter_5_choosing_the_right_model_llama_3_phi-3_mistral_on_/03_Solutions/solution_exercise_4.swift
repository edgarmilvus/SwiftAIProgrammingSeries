
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import Foundation

// MARK: - Ollama API Response Structures (re-used from previous exercises)

struct OllamaStreamingResponse: Decodable {
    let model: String?
    let createdAt: String?
    let response: String?
    let done: Bool
    // Other fields omitted for brevity, but could be included
}

// MARK: - Chat Data Models

enum Sender: String {
    case user
    case assistant
}

struct ChatMessage: Identifiable, Equatable {
    let id = UUID()
    let sender: Sender
    var text: String
    var isGenerating: Bool = false // For streaming effect
}

// MARK: - Main SwiftUI Application

@main
struct AINoteAssistantApp: App {
    var body: some Scene {
        WindowGroup {
            NoteAssistantView()
        }
    }
}

// MARK: - NoteAssistantView

struct NoteAssistantView: View {
    @State private var messages: [ChatMessage] = []
    @State private var currentInput: String = ""
    @State private var noteContent: String = """
    ## Swift Concurrency Notes

    Swift's concurrency model, introduced in Swift 5.5, revolutionizes how we write asynchronous and parallel code. Key features include:

    1.  **Async/Await:** Syntactic sugar for asynchronous operations, making them look and feel like synchronous code. Functions marked `async` can `await` other async functions.
    2.  **Actors:** Reference types that protect their mutable state from concurrent access. Each actor has its own isolated state and mailbox. Messages sent to an actor are processed sequentially, preventing data races.
    3.  **Tasks:** Lightweight units of work that can run concurrently. They can be structured (parent-child relationships) or unstructured.
    4.  **Structured Concurrency:** A powerful pattern where tasks are organized hierarchically. This improves error handling and cancellation propagation. If a parent task is cancelled, its child tasks are also cancelled.
    5.  **Global Actors:** Special actors like `MainActor` that ensure code runs on a specific execution context (e.g., the main thread for UI updates).

    **Example Scenario:**
    Imagine fetching user data from a network, processing it, and then updating the UI. Traditionally, this involved complex completion handlers. With async/await, it becomes:

    