
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import RealityKit

/// Represents a detected object in the spatial environment.
/// This struct is implicitly Sendable because all its members (UUID, String, Transform, Float, Date) are Sendable.
/// If it contained a non-Sendable reference type, it would need explicit Sendable conformance with guarantees.
struct DetectedSpatialObject: Identifiable, Sendable {
    let id: UUID
    var name: String
    var transform: Transform // RealityKit's Transform is Sendable
    var confidence: Float
    var timestamp: Date
}

// Example of a class that needs explicit Sendable conformance if it were to be shared
// This is generally discouraged for shared mutable state; actors are preferred.
// If it must be shared, it needs to be immutable or use internal locking mechanisms.
@available(visionOS 1.0, *)
final class ImmutableAIModelConfig: Sendable {
    let modelPath: String
    let inferenceBatchSize: Int
    // All properties are immutable (let), making this class Sendable.
    // If 'inferenceBatchSize' was 'var', it would not be implicitly Sendable.
    init(modelPath: String, inferenceBatchSize: Int) {
        self.modelPath = modelPath
        self.inferenceBatchSize = inferenceBatchSize
    }
}
