
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI
import RealityKit
import ARKit
import Combine

// Thread-safe state management for telemetry
actor TelemetryState {
    private(set) var currentRPM: Float = 0.0
    
    func update(rpm: Float) {
        currentRPM = rpm
    }
}

@MainActor
class IndustrialInspector: NSObject, ARSessionDelegate {
    var arView: ARView
    private var telemetryEntity: Entity?
    private var telemetryState = TelemetryState()
    private var cancellables = Set<AnyCancellable>()

    init(arView: ARView) {
        self.arView = arView
        super.init()
    }

    // Simulate a high-frequency sensor stream (e.g., 60Hz)
    func startSensorStream() {
        let sensorStream = AsyncStream<Float> { continuation in
            Timer.scheduledTimer(withTimeInterval: 0.016, repeats: true) { _ in
                let simulatedRPM = Float.random(in: 1150...1250)
                continuation.yield(simulatedRPM)
            }
        }

        Task {
            for await rpm in sensorStream {
                await telemetryState.update(rpm: rpm)
                await updateUI(with: rpm)
            }
        }
    }

    private func updateUI(with rpm: Float) async {
        // Update the text component of the HUD
        // (Assuming the entity has a text component)
        if let model = telemetryEntity as? ModelEntity {
            let newMesh = MeshResource.generateText("RPM: \(Int(rpm))", 
                                                   extrusionDepth: 0.01, 
                                                   font: .systemFont(ofSize: 0.05))
            model.model?.mesh = newMesh
        }
    }

    // The Dynamic Update Loop
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        guard let targetEntity = telemetryEntity else { return }
        
        // 1. Get current moving object position (Simulated via Vision/ARKit)
        let movingObjectTransform = getMovingObjectTransform(frame)
        
        // 2. Predictive Transform (Simple velocity-based prediction)
        // In a real app, you'd calculate velocity = (pos_now - pos_prev) / dt
        let predictedPosition = movingObjectTransform.columns.3.xyz + [0, 0.2, 0] // Offset above part

        // 3. Smooth Interpolation (LERP) to prevent stutter
        let currentPos = targetEntity.position(relativeTo: nil)
        let targetPos = simd_make_float3(predictedPosition)
        
        // Move 20% of the way to the target every frame
        targetEntity.position = simd_lerp(currentPos, targetPos, 0.2)
    }

    private func getMovingObjectTransform(_ frame: ARFrame) -> simd_float4x4 {
        // Placeholder for actual object tracking logic
        return frame.camera.transform 
    }
}

// Extension for easier vector math
extension simd_float4 {
    var xyz: simd_float3 { simd_make_float3(x, y, z) }
}
