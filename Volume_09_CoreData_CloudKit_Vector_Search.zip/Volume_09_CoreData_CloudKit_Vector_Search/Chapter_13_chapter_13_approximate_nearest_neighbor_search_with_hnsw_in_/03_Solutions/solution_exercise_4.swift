
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

// MARK: - Models & Protocols
struct Photo: Sendable, Identifiable {
    let id: UUID
    let caption: String
}

protocol EmbeddingProvider: Sendable {
    func generateEmbedding(for input: String) async throws -> [Float]
}

// MARK: - Mock Implementations
actor MockEmbeddingModel: EmbeddingProvider {
    func generateEmbedding(for input: String) async throws -> [Float] {
        // Simulate network/GPU latency
        try await Task.sleep(for: .milliseconds(200))
        // Deterministic mock vector based on string hash
        let hash = abs(input.hashValue)
        return (0..<512).map { i in
            Float((hash + i) % 100) / 100.0
        }
    }
}

actor PhotoCoreDataStore: Sendable {
    private var database: [UUID: Photo] = [:]
    
    func seed(photos: [Photo]) {
        for p in photos { database[p.id] = p }
    }
    
    func fetch(ids: [UUID]) -> [Photo] {
        return ids.compactMap { database[$0] }
    }
}

// MARK: - Core Service
actor SemanticSearchService {
    private let embeddingProvider: EmbeddingProvider
    private let photoStore: PhotoCoreDataStore
    private let registry: VectorRegistry<UUID>
    private let distanceMetric: DistanceMetric
    
    // In a real app, this would be your actual HNSW instance
    private var mockHNSWIndices: [Int: [Int]] = [:] 

    init(
        embeddingProvider: EmbeddingProvider,
        photoStore: PhotoCoreDataStore,
        registry: VectorRegistry<UUID>,
        distanceMetric: DistanceMetric
    ) {
        self.embeddingProvider = embeddingProvider
        self.photoStore = photoStore
        self.registry = registry
        self.distanceMetric = distanceMetric
    }

    /// The main search pipeline
    func search(query: String) async throws -> [Photo] {
        // 1. Encoding Stage (NLP)
        let queryVector = try await embeddingProvider.generateEmbedding(for: query)
        
        // 2. Retrieval Stage (HNSW)
        // Simulating HNSW returning top 50 integer indices
        let candidateIndices = try await performHNSWSearch(queryVector: queryVector)
        
        // 3. Registry Lookup
        let photoIDs = await registry.resolve(indices: candidateIndices)
        
        // 4. Re-ranking Stage (Refinement)
        // In a real app, we'd fetch the actual vectors for these 50 candidates
        // and perform an exact distance check to find the true top 10.
        let topIDs = try await reRank(photoIDs: photoIDs, queryVector: queryVector)
        
        // 5. Metadata Fetch (Core Data)
        return await photoStore.fetch(ids: topIDs)
    }
    
    private func performHNSWSearch(queryVector: [Float]) async throws -> [Int] {
        // Simulated HNSW latency
        try await Task.sleep(for: .milliseconds(50))
        return (0..<50).map { _ in Int.random(in: 0...1000) }
    }
    
    private func reRank(photoIDs: [UUID], queryVector: [Float]) async throws -> [UUID] {
        // Simulate the computational cost of fine-grained re-ranking
        try await Task.sleep(for: .milliseconds(30))
        return Array(photoIDs.prefix(10))
    }
}

// MARK: - Execution
@available(iOS 18.0, *)
func runLuminaDemo() async throws {
    let embeddingModel = MockEmbeddingModel()
    let photoStore = PhotoCoreDataStore()
    let registry = VectorRegistry<UUID>()
    let metric = CosineDistance()
    
    let service = SemanticSearchService(
        embeddingProvider: embeddingModel,
        photoStore: photoStore,
        registry: registry,
        distanceMetric: metric
    )
    
    // Seed data
    let sampleID = UUID()
    _ = await registry.register(sampleID)
    await photoStore.seed(photos: [Photo(id: sampleID, caption: "A golden retriever in snow")])
    
    print("Searching for 'dog in snow'...")
    let results = try await service.search(query: "dog in snow")
    print("Found \(results.count) relevant photos.")
}
