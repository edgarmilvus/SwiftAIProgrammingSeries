
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import NaturalLanguage // Required for NLTagger

// NLTagger.TagScheme.sentimentScore is available from iOS 13.0, macOS 10.15.
// @available(iOS 18.0, macOS 15.0, *) is used here to align with the chapter's implied modern Swift 6 context.
@available(iOS 13.0, macOS 10.15, *)
enum TicketPriority: String, CaseIterable {
    case highPriorityNegative = "High Priority Negative"
    case lowPriorityNegative = "Low Priority Negative"
    case neutral = "Neutral"
    case lowPriorityPositive = "Low Priority Positive"
    case highPriorityPositive = "High Priority Positive"
    case unclassified = "Unclassified" // For any unexpected cases
}

@available(iOS 13.0, macOS 10.15, *)
struct SupportTicketAnalyzer {

    // 1. Sentiment Analyzer Function
    /// Calculates the sentiment score for a given support ticket text using NLTagger.
    /// - Parameter ticketText: The text of the support ticket.
    /// - Returns: A Double representing the sentiment score (typically -1.0 to 1.0).
    func getTicketSentiment(ticketText: String) -> Double {
        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = ticketText
        let (sentimentTag, _) = tagger.tag(at: ticketText.startIndex, unit: .document, scheme: .sentimentScore)
        return Double(sentimentTag?.rawValue ?? "0.0") ?? 0.0 // Default to 0.0 if analysis fails
    }

    // 2. Dynamic Classification Function
    /// Classifies the priority of a support ticket based on its sentiment score and dynamic thresholds.
    /// - Parameters:
    ///   - sentimentScore: The raw sentiment score of the ticket.
    ///   - negativeThreshold: The score below which a ticket is considered high priority negative.
    ///   - positiveThreshold: The score above which a ticket is considered high priority positive.
    /// - Returns: A `TicketPriority` enum case.
    func classifyTicketPriority(sentimentScore: Double, negativeThreshold: Double, positiveThreshold: Double) -> TicketPriority {
        // Ensure thresholds are logically ordered (negativeThreshold should be <= 0, positiveThreshold >= 0)
        // and that negativeThreshold < positiveThreshold for distinct ranges.
        // For this logic, we assume negativeThreshold is a negative value and positiveThreshold is a positive value.

        if sentimentScore <= negativeThreshold {
            return .highPriorityNegative
        } else if sentimentScore < 0 { // Between negativeThreshold and 0 (exclusive)
            return .lowPriorityNegative
        } else if sentimentScore >= positiveThreshold {
            return .highPriorityPositive
        } else if sentimentScore > 0 { // Between 0 (exclusive) and positiveThreshold
            return .lowPriorityPositive
        } else { // Exactly 0.0
            return .neutral
        }
    }
}

// Demonstration
@available(iOS 13.0, macOS 10.15, *)
func demonstrateDynamicTriage() {
    let analyzer = SupportTicketAnalyzer()

    let tickets = [
        "My app keeps crashing after the latest update, I can't do anything!", // Very negative
        "The new feature is great, but it's a bit slow to load.", // Mixed/mildly negative
        "I need help setting up my account, the instructions are unclear.", // Neutral/informational
        "This is the best service ever! You guys are amazing!", // Very positive
        "I found a minor bug in the billing section, it shows incorrect dates sometimes.", // Mildly negative
        "The support team was incredibly helpful and resolved my issue quickly.", // Positive
        "I just have a question about my subscription plan.", // Neutral
    ]

    // Configuration Set 1: Strict thresholds (only very strong sentiments get high priority)
    let config1NegativeThreshold = -0.7
    let config1PositiveThreshold = 0.7
    print("--- Configuration 1: Strict Thresholds ---")
    print("  Negative Threshold: \(String(format: "%.2f", config1NegativeThreshold)), Positive Threshold: \(String(format: "%.2f", config1PositiveThreshold))")
    for ticket in tickets {
        let score = analyzer.getTicketSentiment(ticketText: ticket)
        let priority = analyzer.classifyTicketPriority(sentimentScore: score,
                                                        negativeThreshold: config1NegativeThreshold,
                                                        positiveThreshold: config1PositiveThreshold)
        print("  Ticket: \"\(ticket)\"")
        print("    Score: \(String(format: "%.2f", score)), Priority: \(priority.rawValue)")
    }

    print("\n--- Configuration 2: Lenient Thresholds ---")
    // Configuration Set 2: More lenient thresholds (even moderate sentiments get high priority)
    let config2NegativeThreshold = -0.3
    let config2PositiveThreshold = 0.3
    print("  Negative Threshold: \(String(format: "%.2f", config2NegativeThreshold)), Positive Threshold: \(String(format: "%.2f", config2PositiveThreshold))")
    for ticket in tickets {
        let score = analyzer.getTicketSentiment(ticketText: ticket)
        let priority = analyzer.classifyTicketPriority(sentimentScore: score,
                                                        negativeThreshold: config2NegativeThreshold,
                                                        positiveThreshold: config2PositiveThreshold)
        print("  Ticket: \"\(ticket)\"")
        print("    Score: \(String(format: "%.2f", score)), Priority: \(priority.rawValue)")
    }
}

// To run the demonstration:
// demonstrateDynamicTriage()
