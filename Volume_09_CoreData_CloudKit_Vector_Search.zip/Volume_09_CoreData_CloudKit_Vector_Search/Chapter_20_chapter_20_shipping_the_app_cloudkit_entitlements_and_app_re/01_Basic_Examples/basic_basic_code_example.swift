
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CoreData
import CloudKit
import Combine

/// An error type specifically tailored for the Persistence Layer of the EchoMind AI app.
/// This helps in providing granular feedback during the App Review process if sync fails.
enum PersistenceError: LocalizedError {
    case containerInitializationFailed(String)
    case cloudKitConfigurationMismatch
    case storeLoadingFailed(Error)

    var errorDescription: String? {
        switch self {
        case .containerInitializationFailed(let msg): return "Failed to init container: \(msg)"
        case .cloudKitConfigurationMismatch: return "CloudKit Container ID does not match Entitlements."
        case .storeLoadingFailed(let err): return "Store loading error: \(err.localizedDescription)"
        }
    }
}

/// `PersistenceController` is a thread-safe, actor-isolated manager responsible for the 
/// Core Data stack and its synchronization with CloudKit.
///
/// In Swift 6, we use `@MainActor` to ensure that any interaction with the UI-facing 
/// `viewContext` is strictly performed on the main thread, preventing data races.
@MainActor
final class PersistenceController {
    
    /// The shared singleton instance used throughout the app.
    static let shared = PersistenceController()

    /// The persistent container that bridges Core Data and CloudKit.
    /// Using `NSPersistentCloudKitContainer` is mandatory for automatic sync.
    let container: NSPersistentCloudKitContainer

    /// A publisher to monitor CloudKit sync events, useful for showing "Syncing..." 
    /// indicators in the UI, which is a requirement for a polished user experience.
    private var syncMonitor: AnyCancellable?

    /// Private initializer to enforce singleton usage.
    /// - Throws: `PersistenceError` if the stack cannot be established.
    private init() {
        // 1. Initialize the container with the name of your .xcdatamodeld file.
        // Note: This name must match your Data Model file exactly.
        let containerName = "EchoMindModel"
        let cloudKitContainerID = "iCloud.com.echomind.ai.assistant" // Must match Entitlements!

        let cloudContainer = NSPersistentCloudKitContainer(name: containerName)

        // 2. Configure the Persistent Store Description.
        // This is where the 'magic' happens for CloudKit.
        guard let description = cloudContainer.persistentStoreDescriptions.first else {
            fatalError("Failed to retrieve the primary persistent store description.")
        }

        // Set the CloudKit Container Identifier. 
        // This links your local SQLite file to your specific iCloud Entitlement.
        description.cloudKitContainerIdentifier = cloudKitContainerID
        
        // Enable remote change notifications. 
        // This allows the app to react when data changes on another device (e.g., iPad syncs to iPhone).
        description.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)

        // Enable history tracking. 
        // This is a prerequisite for CloudKit sync to track what has changed locally vs remotely.
        description.setOption(true as NSNumber, forKey: NSPersistentHistoryTrackingKey)

        // 3. Load the stores.
        container = cloudContainer
        
        do {
            try container.loadPersistentStores { (storeDescription, error) in
                if let error = error as NSError? {
                    // In a production app, you would log this to a service like Sentry or CloudWatch.
                    print("Unresolved error \(error), \(error.userInfo)")
                    // For the sake of this example, we trigger a fatal error.
                    // During App Review, ensure you handle this gracefully for the user.
                }
            }
            
            // 4. Configure the viewContext for the UI.
            // Automatically merges changes from the background sync process into the main context.
            container.viewContext.automaticallyMergesChangesFromParent = true
            
            // Set the merge policy to prioritize the in-memory changes over the store.
            // This prevents crashes when a user is typing while a sync arrives.
            container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
            
            // Start monitoring sync events.
            setupSyncMonitoring()
            
        } catch {
            fatalError("Critical failure loading Core Data stack: \(error)")
        }
    }

    /// Sets up an observer for CloudKit event notifications.
    /// This is critical for "Shipping" because it allows the app to provide 
    /// visual feedback when synchronization is in progress or has failed.
    private func setupSyncMonitoring() {
        NotificationCenter.default.publisher(for: NSPersistentCloudKitContainer.eventChangedNotification)
            .sink { notification in
                guard let event = notification.userInfo?[NSPersistentCloudKitContainer.eventNotificationUserInfoKey] 
                        as? NSPersistentCloudKitContainer.Event else { return }
                
                if event.endDate == nil {
                    // A sync event has started.
                    print("CloudKit Sync Started: \(event.type)")
                } else {
                    // A sync event has finished.
                    print("CloudKit Sync Finished: \(event.type)")
                }
            }
            .store(in: &syncMonitor)
    }
}

// MARK: - Usage Example in a SwiftUI View

@available(iOS 18.0, *)
import SwiftUI

/// A simple view demonstrating how to interact with the CloudKit-enabled context.
struct VoiceNoteListView: View {
    /// Access the managed object context from our singleton.
    @Environment(\.managedObjectContext) private var viewContext
    
    /// Fetching notes from the synchronized store.
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \NoteEntity.timestamp, ascending: false)],
        animation: .default)
    private var notes: FetchedResults<NoteEntity>

    var body: some View {
        NavigationView {
            List {
                ForEach(notes) { note in
                    VStack(alignment: .leading) {
                        Text(note.text ?? "Untitled Note")
                            .font(.headline)
                        Text(note.timestamp?.formatted() ?? "")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .onDelete(perform: deleteItems)
            }
            .navigationTitle("EchoMind AI")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: addNote) {
                        Label("Add Note", systemImage: "plus")
                    }
                }
            }
        }
    }

    private func addNote() {
        // Creating a new entity. Because of NSPersistentCloudKitContainer,
        // this will automatically be uploaded to iCloud once the context is saved.
        let newNote = NoteEntity(context: viewContext)
        newNote.id = UUID()
        newNote.text = "New AI Voice Transcript \(Date().formatted())"
        newNote.timestamp = Date()

        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            print("Error saving note: \(nsError), \(nsError.userInfo)")
        }
    }

    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { notes[$0] }.forEach(viewContext.delete)
            do {
                try viewContext.save()
            } catch {
                print("Error deleting note: \(error)")
            }
        }
    }
}
