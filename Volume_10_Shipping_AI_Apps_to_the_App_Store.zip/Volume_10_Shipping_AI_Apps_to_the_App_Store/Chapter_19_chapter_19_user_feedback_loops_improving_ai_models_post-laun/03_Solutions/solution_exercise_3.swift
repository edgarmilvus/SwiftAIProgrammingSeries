
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

/// 1. Define Privacy Budget
enum PrivacyBudget {
    case strict    // Low epsilon (High noise, high privacy)
    case balanced
    case relaxed   // High epsilon (Low noise, low accuracy)
    
    var epsilon: Double {
        switch self {
        case .strict: return 0.1
        case .balanced: return 1.0
        case .relaxed: return 5.0
        }
    }
}

/// 2. Implement the DifferentialPrivacyEngine
struct DifferentialPrivacyEngine {
    
    /// Implements the Laplace Mechanism: X = mu - b * sgn(u) * ln(1 - 2|u|)
    /// where u is a uniform random variable in (-0.5, 0.5]
    func obfuscate(count: Int, epsilon: Double) -> Double {
        let sensitivity: Double = 1.0 // Counting a single user's feedback
        let b = sensitivity / epsilon
        let mu: Double = 0.0
        
        // Generate u in range (-0.5, 0.5]
        let u = Double.random(in: -0.5...0.5)
        
        // Laplace sampling formula
        let noise = mu - b * (u.signum()) * log(1.0 - 2.0 * abs(u))
        
        return Double(count) + noise
    }
}

/// 3. Create a TelemetryReporter
actor TelemetryReporter {
    private let engine = DifferentialPrivacyEngine()
    
    func reportEmotionFailure(emotion: String, actualCount: Int, budget: PrivacyBudget) async {
        // 4. Perform noise generation in a non-isolated context via the actor
        let obfuscatedValue = engine.obfuscate(count: actualCount, epsilon: budget.epsilon)
        
        print("📡 Sending Telemetry for [\(emotion)]")
        print("Raw Count: \(actualCount) | Obfuscated Value: \(String(format: "%.2f", obfuscatedValue))")
        
        // Mock URLSession call
        // try await URLSession.shared.upload(for: request, from: data)
    }
}

// MARK: - Test Execution
func runPrivacyTest() async {
    let reporter = TelemetryReporter()
    
    print("--- Testing Strict Privacy ---")
    await reporter.reportEmotionFailure(emotion: "Melancholy", actualCount: 100, budget: .strict)
    
    print("\n--- Testing Relaxed Privacy ---")
    await reporter.reportEmotionFailure(emotion: "Melancholy", actualCount: 100, budget: .relaxed)
}
