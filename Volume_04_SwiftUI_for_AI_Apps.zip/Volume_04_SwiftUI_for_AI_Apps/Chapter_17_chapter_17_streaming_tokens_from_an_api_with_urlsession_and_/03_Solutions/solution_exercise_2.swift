
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import Foundation

// Ensure the Python server from the problem description is running on port 8080
// with the path '/json-stream' or '/ai/stream'

// MARK: - Decodable Models for AI Chat Chunks
struct AIChatChunk: Decodable {
    let id: String?
    let object: String?
    let choices: [Choice]?

    struct Choice: Decodable {
        let index: Int
        let delta: Delta
    }

    struct Delta: Decodable {
        let content: String?
        let role: String? // e.g., "assistant"
    }
}

// MARK: - SwiftUI View
struct JSONStreamDecoderView: View {
    @State private var accumulatedContent: String = ""
    @State private var errorMessage: String?
    @State private var isLoading: Bool = false

    private let streamURL = URL(string: "http://localhost:8080/json-stream")! // Or /ai/stream

    var body: some View {
        VStack {
            Text("AI Chat Stream")
                .font(.largeTitle)
                .padding()

            if isLoading {
                ProgressView()
                    .padding()
            }

            ScrollView {
                Text(accumulatedContent)
                    .font(.body)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(8)
                    .padding(.horizontal)
            }
            .frame(maxHeight: .infinity) // Allow scroll view to take available height

            if let errorMessage = errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .padding()
            }

            Button("Start AI Stream") {
                accumulatedContent = ""
                errorMessage = nil
                isLoading = true
                Task {
                    await fetchAndDecodeJSONStream()
                }
            }
            .padding()
            .buttonStyle(.borderedProminent)
            .disabled(isLoading)
        }
        .onAppear {
            // Optional: Auto-start on appear
        }
    }

    @MainActor
    private func fetchAndDecodeJSONStream() async {
        do {
            let (bytes, response) = try await URLSession.shared.bytes(for: URLRequest(url: streamURL))

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                errorMessage = "Server responded with an unexpected status code."
                isLoading = false
                return
            }

            // Leverage AsyncBytes.lines for line-by-line processing
            for await line in bytes.lines {
                // Ignore empty lines or lines that might contain non-JSON data (e.g., 'data: ' prefix)
                guard !line.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { continue }

                // Attempt to decode the JSON line
                if let data = line.data(using: .utf8) {
                    do {
                        let chunk = try JSONDecoder().decode(AIChatChunk.self, from: data)
                        // Extract content if available and append
                        if let content = chunk.choices?.first?.delta.content {
                            accumulatedContent.append(content)
                        }
                    } catch let decodingError as DecodingError {
                        print("JSON Decoding Error: \(decodingError)")
                        // For robustness, we might log this but not stop the stream
                        // errorMessage = "JSON Decoding Error: \(decodingError.localizedDescription)"
                    }
                }
            }
            isLoading = false
            print("AI stream finished successfully.")

        } catch URLError.notConnectedToInternet {
            errorMessage = "No internet connection."
            isLoading = false
        } catch URLError.cannotConnectToHost {
            errorMessage = "Could not connect to the server. Is the Python server running on \(streamURL.absoluteString)?"
            isLoading = false
        } catch {
            errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
            isLoading = false
        }
    }
}
