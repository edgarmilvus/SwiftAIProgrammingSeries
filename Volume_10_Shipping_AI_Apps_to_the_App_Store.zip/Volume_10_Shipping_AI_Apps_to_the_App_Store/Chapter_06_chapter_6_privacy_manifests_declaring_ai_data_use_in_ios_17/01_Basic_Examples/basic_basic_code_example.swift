
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import AVFoundation
import CoreML
import OSLog

/// An error type specific to the AI Assistant's operations.
enum AIAssistantError: Error {
    case modelLoadingFailed
    case audioProcessingFailed
    case telemetryFailure
}

/// The `PrivacyTelemetryActor` is responsible for tracking how the AI model performs.
/// We use an `actor` to ensure thread-safe access to telemetry data in a Swift 6 concurrency environment.
///
/// NOTE: Accessing `UserDefaults` and `FileManager` within this actor triggers the 
/// requirement for 'Required Reason API' declarations in the Privacy Manifest.
actor PrivacyTelemetryActor {
    private let logger = Logger(subsystem: "com.ai.assistant", category: "Telemetry")
    private let userDefaults = UserDefaults.standard
    private let fileManager = FileManager.default
    private let telemetryURL: URL

    init() throws {
        // We define a path in the Documents directory to store inference logs.
        // Using FileManager to access file timestamps or file sizes is a 'Required Reason API'.
        let docs = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        self.telemetryURL = docs.appendingPathComponent("ai_performance_logs.txt")
        
        // Ensure the file exists
        if !fileManager.fileExists(atPath: telemetryURL.path) {
            fileManager.createFile(atPath: telemetryURL.path, contents: nil)
        }
    }

    /// Records the latency of an AI inference task.
    /// - Parameter latency: The time taken in milliseconds.
    /// - Throws: `AIAssistantError.telemetryFailure` if writing to disk fails.
    func recordInferenceLatency(_ latency: Double) throws {
        logger.info("Recording latency: \(latency)ms")
        
        // 1. Using UserDefaults: This requires a declaration in the Privacy Manifest
        // under 'NSPrivacyAccessedAPIType.userDefaults'.
        let currentCount = userDefaults.integer(forKey: "total_inference_count")
        userDefaults.set(currentCount + 1, forKey: "total_inference_count")

        // 2. Using FileManager: Accessing/Creating files requires a declaration 
        // under 'NSPrivacyAccessedAPIType.fileTimestamp' if we check modification dates.
        let logEntry = "\(Date()): \(latency)ms\n"
        guard let data = logEntry.data(using: .utf8) else { return }
        
        if let fileHandle = try? FileHandle(forWritingTo: telemetryURL) {
            defer { try? fileHandle.close() }
            try fileHandle.seekToEnd()
            try fileHandle.write(contentsOf: data)
        } else {
            throw AIAssistantError.telemetryFailure
        }
    }
}

/// The `AIVoiceAssistant` manages the lifecycle of audio recording and AI processing.
/// It is marked with `@MainActor` because it will eventually drive UI updates.
@MainActor
class AIVoiceAssistant: ObservableObject {
    @Published var isProcessing: Bool = false
    @Published var lastResult: String = "Ready"
    
    private let telemetry: PrivacyTelemetryActor?
    private let logger = Logger(subsystem: "com.ai.assistant", category: "Core")

    init() {
        // Initialize the telemetry actor.
        do {
            self.telemetry = try PrivacyTelemetryActor()
        } catch {
            self.telemetry = nil
            logger.error("Failed to initialize telemetry: \(error.localizedDescription)")
        }
    }

    /// Simulates the process of recording audio and running it through a Core ML model.
    /// - Parameter audioData: The raw audio buffer (simulated).
    func processVoiceCommand(audioData: Data) async {
        isProcessing = true
        lastResult = "Analyzing..."
        
        let startTime = CFAbsoluteTimeGetCurrent()

        do {
            // Simulate AI Inference Latency (e.g., 500ms - 1500ms)
            try await Task.sleep(for: .milliseconds(Int.random(in: 500...1500)))
            
            // In a real app, you would call:
            // let prediction = try await myCoreMLModel.prediction(input: audioData)
            let simulatedResult = "Command: 'Set an alarm for 7 AM'"
            
            let duration = (CFAbsoluteTimeGetCurrent() - startTime) * 1000
            
            // Update UI
            self.lastResult = simulatedResult
            
            // Record telemetry asynchronously
            try await telemetry?.recordInferenceLatency(duration)
            
            logger.info("Inference successful: \(simulatedResult)")
            
        } catch {
            self.lastResult = "Error processing command."
            logger.error("Inference failed: \(error.localizedDescription)")
        }

        isProcessing = false
    }
}
