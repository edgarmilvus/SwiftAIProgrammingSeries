
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

import UIKit
import AVFoundation
import Vision

/// A ViewController that displays a live camera feed and overlays detected documents and recognized text.
@available(iOS 17.0, *)
class ViewController: UIViewController {

    // MARK: - UI Elements

    private let cameraView = UIView()
    private let recognizedTextLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        label.numberOfLines = 0
        label.textAlignment = .left
        label.font = .systemFont(ofSize: 14)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Scanning for documents and text..."
        return label
    }()

    private let overlayLayer = CAShapeLayer() // Layer for drawing document rectangles
    private var textBoundingBoxLayers: [CAShapeLayer] = [] // Layers for drawing text bounding boxes

    // MARK: - Processor

    private let scannerProcessor = SmartDocumentScannerProcessor()

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        scannerProcessor.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Task {
            do {
                try await scannerProcessor.setupCamera()
                scannerProcessor.startSession()
            } catch {
                if let cameraError = error as? SmartDocumentScannerProcessor.CameraError {
                    presentAlert(title: "Camera Error", message: cameraError.localizedDescription)
                } else {
                    presentAlert(title: "Error", message: error.localizedDescription)
                }
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        scannerProcessor.stopSession()
    }

    // MARK: - UI Setup

    /// Configures the user interface elements and their layout.
    private func setupUI() {
        view.backgroundColor = .black

        // Add camera view
        view.addSubview(cameraView)
        cameraView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            cameraView.topAnchor.constraint(equalTo: view.topAnchor),
            cameraView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            cameraView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            cameraView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        // Add camera preview layer to the cameraView
        cameraView.layer.addSublayer(scannerProcessor.previewLayer)

        // Add overlay layer for drawing rectangles
        cameraView.layer.addSublayer(overlayLayer)
        overlayLayer.strokeColor = UIColor.systemGreen.cgColor
        overlayLayer.lineWidth = 3.0
        overlayLayer.fillColor = UIColor.systemGreen.withAlphaComponent(0.3).cgColor // Semi-transparent fill

        // Add recognized text label
        view.addSubview(recognizedTextLabel)
        NSLayoutConstraint.activate([
            recognizedTextLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 16),
            recognizedTextLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -16),
            recognizedTextLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            recognizedTextLabel.heightAnchor.constraint(lessThanOrEqualToConstant: 200) // Limit height
        ])
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Ensure the preview layer and overlay layer match the cameraView's bounds.
        scannerProcessor.previewLayer.frame = cameraView.bounds
        overlayLayer.frame = cameraView.bounds
        textBoundingBoxLayers.forEach { $0.frame = cameraView.bounds }
    }

    /// Presents a UIAlertController with a given title and message.
    /// - Parameters:
    ///   - title: The title of the alert.
    ///   - message: The message body of the alert.
    private func presentAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    // MARK: - Drawing Overlays

    /// Draws the detected document rectangles on the `overlayLayer`.
    /// - Parameters:
    ///   - observations: An array of `VNRectangleObservation`.
    ///   - frameSize: The size of the original video frame.
    private func drawDocumentRectangles(observations: [VNRectangleObservation], frameSize: CGSize) {
        let path = UIBezierPath()
        for observation in observations {
            // Convert Vision normalized coordinates to AVFoundation/UIKit coordinates.
            // Vision's origin is bottom-left, UIKit's is top-left.
            // The coordinate system also needs to be scaled from the frame size to the preview layer size.
            let transform = CGAffineTransform.identity
                .scaledBy(x: cameraView.bounds.width / frameSize.width, y: cameraView.bounds.height / frameSize.height)
                .translatedBy(x: 0, y: -frameSize.height) // Flip Y-axis
                .scaledBy(x: 1, y: -1) // Flip Y-axis again to match UIKit's top-left origin

            let convertedRect = observation.boundingBox.applying(transform)

            // Convert the corners of the rectangle observation to points in the preview layer's coordinate system.
            let topLeft = VNImagePointForNormalizedPoint(observation.topLeft, Int(frameSize.width), Int(frameSize.height)).applying(transform)
            let topRight = VNImagePointForNormalizedPoint(observation.topRight, Int(frameSize.width), Int(frameSize.height)).applying(transform)
            let bottomRight = VNImagePointForNormalizedPoint(observation.bottomRight, Int(frameSize.width), Int(frameSize.height)).applying(transform)
            let bottomLeft = VNImagePointForNormalizedPoint(observation.bottomLeft, Int(frameSize.width), Int(frameSize.height)).applying(transform)

            path.move(to: topLeft)
            path.addLine(to: topRight)
            path.addLine(to: bottomRight)
            path.addLine(to: bottomLeft)
            path.close()
        }
        overlayLayer.path = path.cgPath
    }

    /// Draws bounding boxes around recognized text lines.
    /// - Parameters:
    ///   - boundingBoxes: An array of `CGRect` for each recognized text line in Vision coordinates.
    ///   - frameSize: The size of the original video frame.
    private func drawTextBoundingBoxes(boundingBoxes: [CGRect], frameSize: CGSize) {
        // Remove old layers
        textBoundingBoxLayers.forEach { $0.removeFromSuperlayer() }
        textBoundingBoxLayers.removeAll()

        for box in boundingBoxes {
            let layer = CAShapeLayer()
            layer.strokeColor = UIColor.systemBlue.cgColor
            layer.lineWidth = 1.0
            layer.fillColor = UIColor.systemBlue.withAlphaComponent(0.2).cgColor // Semi-transparent fill

            // Convert Vision coordinates (bottom-left origin) to UIKit coordinates (top-left origin).
            // Scale from frame size to preview layer size.
            let transform = CGAffineTransform.identity
                .scaledBy(x: cameraView.bounds.width / frameSize.width, y: cameraView.bounds.height / frameSize.height)
                .translatedBy(x: 0, y: -frameSize.height) // Flip Y-axis
                .scaledBy(x: 1, y: -1) // Flip Y-axis again

            let convertedRect = box.applying(transform)
            layer.path = UIBezierPath(rect: convertedRect).cgPath
            cameraView.layer.addSublayer(layer)
            textBoundingBoxLayers.append(layer)
        }
    }
}

// MARK: - SmartDocumentScannerProcessorDelegate

@available(iOS 17.0, *)
extension ViewController: SmartDocumentScannerProcessorDelegate {
    func processor(_ processor: SmartDocumentScannerProcessor, didDetectDocumentRectangles rectangles: [VNRectangleObservation], in frameSize: CGSize) {
        drawDocumentRectangles(observations: rectangles, frameSize: frameSize)
    }

    func processor(_ processor: SmartDocumentScannerProcessor, didRecognizeText recognizedText: String, boundingBoxes: [CGRect], in frameSize: CGSize) {
        recognizedTextLabel.text = recognizedText.isEmpty ? "No text recognized." : recognizedText
        drawTextBoundingBoxes(boundingBoxes: boundingBoxes, frameSize: frameSize)
    }

    func processor(_ processor: SmartDocumentScannerProcessor, didEncounterError error: Error) {
        print("Scanner Processor Error: \(error.localizedDescription)")
        presentAlert(title: "Scanner Error", message: error.localizedDescription)
    }
}
