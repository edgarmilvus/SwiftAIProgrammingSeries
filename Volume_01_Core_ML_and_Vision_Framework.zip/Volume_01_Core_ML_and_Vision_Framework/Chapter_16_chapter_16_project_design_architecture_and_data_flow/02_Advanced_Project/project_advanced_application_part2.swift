
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import CoreML
import Vision
import UIKit // For UIImage and CIImage
import Foundation // For Error and Bundle

/// Represents the structured output of the document processing pipeline.
struct ProcessedDocument {
    /// The original image provided for processing.
    let originalImage: UIImage
    /// The image of the document after detection, cropping, and perspective correction.
    let croppedDocumentImage: UIImage
    /// The text recognized from the cropped document via OCR.
    let recognizedText: String
    /// The classification of the document type (e.g., "Invoice", "Receipt", "Contract")
    /// determined by the custom Core ML model.
    let documentType: String
    /// The bounding box of the detected document in normalized coordinates (0.0 to 1.0)
    /// relative to the original image.
    let documentBoundingBox: CGRect
}

/// Custom error types for the document processing service, providing detailed failure reasons.
enum DocumentProcessingError: Error, LocalizedError {
    case imageConversionFailed
    case noDocumentDetected
    case documentCroppingFailed
    case textRecognitionFailed(Error?)
    case modelLoadingFailed(Error?)
    case modelPredictionFailed(Error?)
    case unknownError(Error?)

    /// Provides a user-friendly description for each error type.
    var errorDescription: String? {
        switch self {
        case .imageConversionFailed: return "Failed to convert UIImage to CIImage for Vision processing."
        case .noDocumentDetected: return "No document rectangle was detected in the image."
        case .documentCroppingFailed: return "Failed to crop the image to the detected document area."
        case .textRecognitionFailed(let error): return "Text recognition failed: \(error?.localizedDescription ?? "Unknown error occurred during OCR")."
        case .modelLoadingFailed(let error): return "Failed to load the custom Core ML model: \(error?.localizedDescription ?? "Model file not found or invalid")."
        case .modelPredictionFailed(let error): return "Core ML model prediction failed: \(error?.localizedDescription ?? "Prediction output was unexpected")."
        case .unknownError(let error): return "An unknown error occurred during document processing: \(error?.localizedDescription ?? "No specific error provided")."
        }
    }
}

/// A service responsible for advanced document processing using Core ML and Vision frameworks.
/// This service orchestrates document detection, cropping, text recognition (OCR), and custom
/// document type classification in an asynchronous pipeline.
@available(iOS 16.0, *) // Requires iOS 16.0+ for async/await Vision APIs
class DocumentProcessingService {
    /// The Vision Core ML model wrapper for the custom document type classifier.
    private let coreMLModel: VNCoreMLModel

    /// Initializes the document processing service.
    /// - Throws: `DocumentProcessingError.modelLoadingFailed` if the custom Core ML model
    ///   ("DocumentTypeClassifier.mlmodelc") cannot be found or loaded from the app bundle.
    init() throws {
        // Attempt to find the compiled Core ML model in the app's main bundle.
        // The .mlmodel file is automatically compiled into an .mlmodelc directory during build.
        guard let modelURL = Bundle.main.url(forResource: "DocumentTypeClassifier", withExtension: "mlmodelc") else {
            throw DocumentProcessingError.modelLoadingFailed(nil)
        }
        do {
            // Load the MLModel from the URL.
            let mlModel = try MLModel(contentsOf: modelURL)
            // Wrap the MLModel in VNCoreMLModel for Vision framework integration.
            self.coreMLModel = try VNCoreMLModel(for: mlModel)
        } catch {
            // Catch any errors during model loading and wrap them in our custom error type.
            throw DocumentProcessingError.modelLoadingFailed(error)
        }
    }

    /// Processes a given image to detect, crop, recognize text, and classify a document.
    /// This method orchestrates a multi-stage Vision pipeline using Swift's `async/await`.
    ///
    /// - Parameter image: The `UIImage` to be processed.
    /// - Returns: A `ProcessedDocument` containing the original image, cropped document image,
    ///   recognized text, and the classified document type.
    /// - Throws: `DocumentProcessingError` if any step in the processing pipeline fails.
    func processDocument(image: UIImage) async throws -> ProcessedDocument {
        // 1. Convert UIImage to CIImage for Vision processing.
        // Vision's `VNImageRequestHandler` works efficiently with `CIImage`.
        guard let ciImage = CIImage(image: image) else {
            throw DocumentProcessingError.imageConversionFailed
        }

        // Create a Vision request handler for the original image.
        let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])

        // 2. Perform Document Rectangle Detection.
        // This request identifies the bounding box and corners of a document.
        let documentDetectionRequest = VNDetectDocumentCameraRectangleRequest()
        // Use `await` to asynchronously perform the Vision request.
        try await handler.perform([documentDetectionRequest])

        // Extract the first detected document observation. If none, throw an error.
        guard let observation = documentDetectionRequest.results?.first else {
            throw DocumentProcessingError.noDocumentDetected
        }

        // 3. Crop the image to the detected document rectangle and apply perspective correction.
        // `VNImageCropAndScaleDataRequest` is ideal for this, taking the rectangle observation.
        let documentCropRequest = VNImageCropAndScaleDataRequest(rectangle: observation.rectangleObservation)
        // Standardize the output size for consistent input to subsequent OCR and ML tasks.
        documentCropRequest.targetSize = CGSize(width: 1024, height: 1024)
        // Ensure the entire document fits within the target size, maintaining aspect ratio.
        documentCropRequest.targetCropAndScaleOption = .scaleFit

        // Perform the cropping request using the same handler.
        try await handler.perform([documentCropRequest])

        // Retrieve the cropped image as a CVPixelBuffer.
        guard let croppedPixelBuffer = documentCropRequest.results?.first?.pixelBuffer else {
            throw DocumentProcessingError.documentCroppingFailed
        }

        // Convert the CVPixelBuffer to CIImage, then to UIImage for easier handling and display.
        let croppedCIImage = CIImage(cvPixelBuffer: croppedPixelBuffer)
        let context = CIContext() // CIContext is needed to render CIImage to CGImage.
        guard let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) else {
            throw DocumentProcessingError.documentCroppingFailed
        }
        let croppedDocumentImage = UIImage(cgImage: cgImage)

        // Create a new Vision request handler specifically for the cropped image.
        let croppedImageHandler = VNImageRequestHandler(ciImage: croppedCIImage, options: [:])

        // 4. Perform Text Recognition (OCR) on the cropped document.
        // This request extracts textual content from the image.
        let textRecognitionRequest = VNRecognizeTextRequest()
        textRecognitionRequest.recognitionLevel = .accurate // Prioritize accuracy over speed.
        textRecognitionRequest.usesLanguageCorrection = true // Leverage language models for better results.
        textRecognitionRequest.revision = VNRecognizeTextRequestRevision3 // Use the latest API revision.

        // 5. Perform Custom Document Type Classification using Core ML on the cropped document.
        // This request uses our custom `DocumentTypeClassifier.mlmodel`.
        let coreMLRequest = VNCoreMLRequest(model: coreMLModel)
        // Ensure consistent image input to the ML model by specifying crop and scale options.
        coreMLRequest.imageCropAndScaleOption = .centerCrop

        // Perform both text recognition and Core ML classification concurrently.
        // Using `async let` allows these two independent tasks to run in parallel.
        async let recognizedTextResult = Task { () -> String in
            do {
                try await croppedImageHandler.perform([textRecognitionRequest])
                // Extract and concatenate the top text candidates.
                return textRecognitionRequest.results?
                    .compactMap { $0 as? VNRecognizedTextObservation }
                    .flatMap { $0.topCandidates(1) } // Get the best candidate for each detected text block.
                    .map { $0.string }
                    .joined(separator: "\n") ?? "" // Join all recognized lines.
            } catch {
                throw DocumentProcessingError.textRecognitionFailed(error)
            }
        }.value

        async let documentTypeResult = Task { () -> String in
            do {
                try await croppedImageHandler.perform([coreMLRequest])
                // Extract the identifier (label) of the top classification.
                guard let classification = coreMLRequest.results?.first as? VNClassificationObservation else {
                    throw DocumentProcessingError.modelPredictionFailed(nil)
                }
                return classification.identifier
            } catch {
                throw DocumentProcessingError.modelPredictionFailed(error)
            }
        }.value

        // Await both concurrent tasks to complete and retrieve their results.
        let recognizedText = try await recognizedTextResult
        let documentType = try await documentTypeResult

        // 6. Combine all results into a `ProcessedDocument` structure.
        return ProcessedDocument(
            originalImage: image,
            croppedDocumentImage: croppedDocumentImage,
            recognizedText: recognizedText,
            documentType: documentType,
            documentBoundingBox: observation.boundingBox // The normalized bounding box from initial detection.
        )
    }
}

// MARK: - Example Usage in a ViewController (Illustrative)

/// A hypothetical ViewController that uses the DocumentProcessingService.
/// In a real app, this might be triggered by a camera capture or image selection.
@available(iOS 16.0, *)
class DocumentScannerViewController: UIViewController {

    private var documentProcessingService: DocumentProcessingService!
    private let activityIndicator = UIActivityIndicatorView(style: .large)
    private let resultTextView = UITextView()
    private let imageView = UIImageView()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Initialize the service. This might throw if the ML model is missing.
        do {
            documentProcessingService = try DocumentProcessingService()
        } catch {
            print("Error initializing DocumentProcessingService: \(error.localizedDescription)")
            // Display an alert or disable functionality if service fails to initialize.
            let alert = UIAlertController(title: "Error", message: "Failed to load ML model: \(error.localizedDescription)", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)

        resultTextView.isEditable = false
        resultTextView.font = .systemFont(ofSize: 16)
        resultTextView.layer.borderColor = UIColor.lightGray.cgColor
        resultTextView.layer.borderWidth = 1.0
        resultTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(resultTextView)

        activityIndicator.hidesWhenStopped = true
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(activityIndicator)

        let processButton = UIButton(type: .system)
        processButton.setTitle("Process Sample Document", for: .normal)
        processButton.addTarget(self, action: #selector(processSampleDocument), for: .touchUpInside)
        processButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(processButton)

        NSLayoutConstraint.activate([
            processButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            processButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            imageView.topAnchor.constraint(equalTo: processButton.bottomAnchor, constant: 16),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.3),

            resultTextView.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 16),
            resultTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            resultTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            resultTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),

            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    /// Simulates processing an image, typically from a camera or photo library.
    @objc private func processSampleDocument() {
        // Load a sample image from the app bundle.
        // In a real app, this would come from UIImagePickerController or AVCaptureSession.
        guard let sampleImage = UIImage(named: "sample_document") else {
            print("Error: 'sample_document.png' not found in assets.")
            return
        }

        imageView.image = sampleImage
        resultTextView.text = "Processing..."
        activityIndicator.startAnimating()

        // Use a Task to run the asynchronous processing and update UI on the main actor.
        Task {
            do {
                let processedDocument = try await documentProcessingService.processDocument(image: sampleImage)

                // Update UI with results on the main actor.
                await MainActor.run {
                    self.imageView.image = processedDocument.croppedDocumentImage // Show the cropped image
                    self.resultTextView.text = """
                    Document Type: \(processedDocument.documentType)
                    --- Recognized Text ---
                    \(processedDocument.recognizedText)
                    """
                    self.activityIndicator.stopAnimating()
                }
            } catch {
                // Handle errors and update UI.
                await MainActor.run {
                    self.resultTextView.text = "Error: \(error.localizedDescription)"
                    print("Document processing failed: \(error.localizedDescription)")
                    self.activityIndicator.stopAnimating()
                    let alert = UIAlertController(title: "Processing Error", message: error.localizedDescription, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(alert, animated: true)
                }
            }
        }
    }
}
