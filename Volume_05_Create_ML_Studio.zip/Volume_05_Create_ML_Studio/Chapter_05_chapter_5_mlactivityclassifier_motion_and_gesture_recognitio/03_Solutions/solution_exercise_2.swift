
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import CoreML
import CoreMotion

// For demonstration, we'll create a dummy MLActivityClassifier model
// In a real app, you would drag and drop your EbookGestureClassifier.mlmodel into your Xcode project.
// For this exercise, we assume its existence and focus on the Swift integration.
// To make this runnable, you would need to create a dummy .mlmodel that outputs "shake", "double_tap", "none".
// For example, in Create ML, you could train an Activity Classifier with these labels.

@available(iOS 18.0, *)
class GestureControlViewController: UIViewController {

    let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Waiting for gestures..."
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 20, weight: .semibold)
        label.numberOfLines = 0
        return label
    }()

    private var gestureClassifier: MLActivityClassifier?
    private let feedbackGenerator = UIImpactFeedbackGenerator(style: .light) // General feedback
    private let selectionFeedbackGenerator = UISelectionFeedbackGenerator() // For selection-like feedback

    // Debouncing variables
    private var lastDetectedGesture: String?
    private var lastDetectionTime: Date?
    private let gestureCooldown: TimeInterval = 1.0 // 1 second cooldown to prevent rapid firing

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        prepareHaptics()
        setupGestureClassifier()
    }

    private func setupUI() {
        view.addSubview(statusLabel)
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            statusLabel.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.9)
        ])
    }

    private func prepareHaptics() {
        feedbackGenerator.prepare()
        selectionFeedbackGenerator.prepare()
    }

    private func setupGestureClassifier() {
        guard MLActivityClassifier.isActivityMonitoringAvailable() else {
            statusLabel.text = "Error: Activity monitoring not available on this device."
            return
        }

        do {
            // In a real app, 'EbookGestureClassifier' would be the name of your .mlmodel file
            // dragged into the project. Xcode generates a class for it.
            // For this example, we assume MLActivityClassifier can be initialized without a custom model
            // and will use its default capabilities if no model URL is provided.
            // However, the exercise explicitly states 'EbookGestureClassifier.mlmodel'.
            // To properly load a custom model, you'd typically do:
            // guard let modelURL = Bundle.main.url(forResource: "EbookGestureClassifier", withExtension: "mlmodelc") else {
            //     throw NSError(domain: "GestureControl", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model not found"])
            // }
            // self.gestureClassifier = try MLActivityClassifier(model: modelURL)

            // For the purpose of *this* exercise's context (where we simulate model existence),
            // we'll initialize with the default model and pretend it recognizes "shake" and "double_tap".
            // In a real scenario, if you use a custom model, the labels must match the model's output.
            // If the default MLActivityClassifier is used, its labels are standard (walking, running, etc.).
            // We'll proceed by assuming the default model *can* output "shake" and "double_tap" for demonstration.
            // A more accurate simulation would involve creating a dummy MLActivityClassifier that *only* outputs these,
            // or by using the MLActivityClassifier(model: modelURL) initializer with a real custom model.
            self.gestureClassifier = MLActivityClassifier() // Using default for demonstration
            startMonitoringGestures()
        } catch {
            statusLabel.text = "Failed to load gesture classifier: \(error.localizedDescription)"
            print("Failed to load gesture classifier: \(error)")
        }
    }

    private func startMonitoringGestures() {
        guard let classifier = gestureClassifier else { return }

        classifier.startActivityUpdates(to: .main) { [weak self] (prediction, error) in
            guard let self = self else { return }

            if let error = error {
                DispatchQueue.main.async {
                    self.statusLabel.text = "Error monitoring gestures: \(error.localizedDescription)"
                    print("MLActivityClassifier Error: \(error.localizedDescription)")
                    self.gestureClassifier?.stopActivityUpdates()
                }
                return
            }

            if let prediction = prediction {
                DispatchQueue.main.async {
                    self.statusLabel.text = "Detected: \(prediction.label.capitalized) (Confidence: \(String(format: "%.2f", prediction.confidence)))"
                    self.handleGesturePrediction(prediction)
                }
            }
        }
        print("Gesture monitoring started.")
    }

    private func handleGesturePrediction(_ prediction: MLActivityClassifier.Prediction) {
        let currentGesture = prediction.label
        let currentTime = Date()

        // Implement debouncing
        if let lastGesture = lastDetectedGesture,
           let lastTime = lastDetectionTime,
           currentTime.timeIntervalSince(lastTime) < gestureCooldown,
           lastGesture == currentGesture {
            // Still within cooldown for the same gesture, ignore to prevent rapid firing
            return
        }

        // Only process if confidence is reasonably high
        guard prediction.confidence > 0.8 else { // Example confidence threshold
            // If confidence is low, we might not want to act on it, but still update the label
            return
        }

        switch currentGesture {
        case "shake":
            print("Page Bookmarked!")
            feedbackGenerator.impactOccurred()
            lastDetectedGesture = currentGesture
            lastDetectionTime = currentTime
        case "double_tap":
            print("Turning to next page...")
            selectionFeedbackGenerator.selectionChanged()
            lastDetectedGesture = currentGesture
            lastDetectionTime = currentTime
        case "none":
            // Optionally reset lastDetectedGesture if "none" is detected for a period
            // For now, allow other gestures to override "none" without cooldown
            break
        default:
            // Handle other activities or unknown
            break
        }
    }

    deinit {
        gestureClassifier?.stopActivityUpdates()
    }
}
