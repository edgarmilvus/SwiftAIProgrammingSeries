
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

    import Foundation
    import MLX
    import MLXNN // For Module, Conv2d, ReLU, MaxPool2d, Linear, Flatten

    /// @available annotations ensure this code is only compiled and run on platforms supporting MLX.
    @available(macOS 14.0, iOS 17.0, visionOS 1.0, *)
    /// A simple Convolutional Neural Network (CNN) for extracting features from document image patches.
    /// Inherits from `MLXNN.Module` to leverage MLX's model definition capabilities.
    class DocumentFeatureExtractor: MLXNN.Module {
        let conv1: MLXNN.Conv2d
        let conv2: MLXNN.Conv2d
        let linear: MLXNN.Linear

        /// Initializes the feature extractor model.
        /// - Parameters:
        ///   - inputChannels: The number of color channels in the input image (e.g., 1 for grayscale, 3 for RGB).
        ///   - outputFeatures: The desired dimensionality of the output feature vector.
        override init() {
            // Default initializer, typically you'd pass parameters here or use a factory.
            // For demonstration, let's assume fixed parameters.
            let inputChannels = 1 // Grayscale image patch
            let outputFeatures = 128 // A 128-dimensional feature vector

            conv1 = MLXNN.Conv2d(inputChannels, 32, kernelSize: 3, padding: 1) // 32 filters, 3x3 kernel, same padding
            conv2 = MLXNN.Conv2d(32, 64, kernelSize: 3, padding: 1)            // 64 filters, 3x3 kernel, same padding
            linear = MLXNN.Linear(64 * 8 * 8, outputFeatures)                 // Assuming input image patch size leads to 8x8 after pooling

            super.init()
        }

        /// Forward pass definition for the model.
        /// - Parameter input: An `MLXArray` representing the input image patch.
        ///                    Expected shape: `[batch_size, channels, height, width]`.
        /// - Returns: An `MLXArray` representing the extracted feature vector.
        override func callAsFunction(_ input: MLXArray) -> MLXArray {
            var x = input
            x = conv1(x) // Apply first convolution
            x = MLXNN.relu(x) // Apply ReLU activation
            x = MLXNN.maxPool2d(x, kernelSize: 2, stride: 2) // Max pooling reduces spatial dimensions by half

            x = conv2(x) // Apply second convolution
            x = MLXNN.relu(x) // Apply ReLU activation
            x = MLXNN.maxPool2d(x, kernelSize: 2, stride: 2) // Max pooling again

            // Flatten the output of the convolutional layers into a 1D vector
            // The shape calculation (64 * 8 * 8) assumes an input patch of 32x32 pixels,
            // which becomes 8x8 after two 2x2 max pools.
            x = MLXNN.flatten(x, start: 1) // Flatten from the channel dimension onwards

            x = linear(x) // Apply final linear layer to get the feature vector
            return x
        }
    }
    