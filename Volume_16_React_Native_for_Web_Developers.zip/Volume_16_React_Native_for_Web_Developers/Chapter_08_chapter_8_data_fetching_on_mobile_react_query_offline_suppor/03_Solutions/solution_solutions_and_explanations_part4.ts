/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { QueryClient } from '@tanstack/react-query';
import { AsyncStoragePersister, createAsyncStoragePersister } from '@tanstack/query-async-storage-persister';
import { PersistQueryClientProvider } from '@tanstack/react-query-persist-client';
import AsyncStorage from '@react-native-async-storage/async-storage'; // Native
// import { localStorage } from '@tanstack/query-persist-client'; // Web (Mock)

// 1. Universal Storage Adapter
const getStorage = () => {
  // Check if running on web or native
  const isWeb = typeof window !== 'undefined' && 'localStorage' in window;
  
  if (isWeb) {
    // Return a minimal adapter for web if not using the specific web package
    return {
      getItem: (key: string) => Promise.resolve(localStorage.getItem(key)),
      setItem: (key: string, value: string) => Promise.resolve(localStorage.setItem(key, value)),
      removeItem: (key: string) => Promise.resolve(localStorage.removeItem(key)),
    };
  }
  
  // Return AsyncStorage for mobile
  return AsyncStorage;
};

// 2. Configure QueryClient
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      gcTime: 1000 * 60 * 60 * 24, // 24 hours (Garbage Collection time)
      staleTime: 1000 * 60 * 5,    // 5 minutes
      retry: 2,
      // Ensure queries are not garbage collected immediately if offline
      networkMode: 'offlineFirst', 
    },
  },
});

// 3. Create Persister
const persister = createAsyncStoragePersister({
  storage: getStorage(),
  key: 'REACT_QUERY_CACHE',
  throttleTime: 1000, // Save to storage at most once every second to prevent blocking
});

export const UniversalProvider = ({ children }: { children: React.ReactNode }) => {
  return (
    <PersistQueryClientProvider
      client={queryClient}
      persistOptions={{ persister }}
      // 4. Handling Hydration/Corruption
      onSuccess={() => {
        // Resume mutations after hydration is successful
        queryClient.resumePausedMutations();
      }}
      // Note: The library handles basic errors, but we can add custom logic here if needed
    >
      {children}
    </PersistQueryClientProvider>
  );
};

// Usage in App.tsx:
// <UniversalProvider> <App /> </UniversalProvider>
