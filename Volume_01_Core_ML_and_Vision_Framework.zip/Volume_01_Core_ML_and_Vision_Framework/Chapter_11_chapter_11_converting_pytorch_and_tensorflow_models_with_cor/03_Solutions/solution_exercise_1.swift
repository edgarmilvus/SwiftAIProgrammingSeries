
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// MARK: - Utility Extensions (Place in a separate file in a real project)
import UIKit
import CoreVideo
import CoreGraphics
import Vision

extension UIImage {
    /// Converts a UIImage to a CVPixelBuffer, optionally resizing it.
    /// This is a common helper for Vision framework inputs.
    func toCVPixelBuffer(pixelFormatType: OSType = kCVPixelFormatType_32BGRA, width: Int? = nil, height: Int? = nil) -> CVPixelBuffer? {
        let imageWidth = width ?? Int(self.size.width)
        let imageHeight = height ?? Int(self.size.height)

        var pixelBuffer: CVPixelBuffer?
        let attributes: [String: Any] = [
            kCVPixelBufferCGImageCompatibilityKey as String: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey as String: true,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]

        CVPixelBufferCreate(kCFAllocatorDefault,
                            imageWidth,
                            imageHeight,
                            pixelFormatType,
                            attributes as CFDictionary,
                            &pixelBuffer)

        guard let buffer = pixelBuffer else { return nil }

        CVPixelBufferLockBaseAddress(buffer, .zero)
        defer { CVPixelBufferUnlockBaseAddress(buffer, .zero) }

        let pixelData = CVPixelBufferGetBaseAddress(buffer)
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: pixelData,
                                width: imageWidth,
                                height: imageHeight,
                                bitsPerComponent: 8,
                                bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
                                space: rgbColorSpace,
                                bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue)

        context?.translateBy(x: 0, y: CGFloat(imageHeight))
        context?.scaleBy(x: 1.0, y: -1.0)

        UIGraphicsPushContext(context!)
        self.draw(in: CGRect(x: 0, y: 0, width: CGFloat(imageWidth), height: CGFloat(imageHeight)))
        UIGraphicsPopContext()

        return buffer
    }
}

// MARK: - ViewController (Assumes a basic iOS project with a ViewController)
import UIKit
import Vision // Import Vision framework for Core ML inference

// Assume 'PlantIdentifierModel' is the name of your Core ML model file (e.g., PlantIdentifierModel.mlmodel)
// Drag your .mlmodel file into your Xcode project to generate this Swift class.
// For this example, let's assume the model expects 224x224 input.
// You would typically find this in the model's generated Swift class or by inspecting the .mlmodel in Xcode.

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    // MARK: - UI Elements
    private let imageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.backgroundColor = .systemGray5
        iv.layer.cornerRadius = 8
        iv.clipsToBounds = true
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let resultLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = .preferredFont(forTextStyle: .headline)
        label.numberOfLines = 0
        label.text = "Select an image to identify a plant."
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let selectImageButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Select Image", for: .normal)
        button.titleLabel?.font = .preferredFont(forTextStyle: .title3)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let activityIndicator: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.hidesWhenStopped = true
        indicator.translatesAutoresizingMaskIntoConstraints = false
        return indicator
    }()

    // MARK: - Model & Vision Setup
    private var plantClassifier: VNCoreMLModel?
    private var classificationRequest: VNCoreMLRequest?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupModel()
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        view.addSubview(imageView)
        view.addSubview(resultLabel)
        view.addSubview(selectImageButton)
        view.addSubview(activityIndicator)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8), // Aspect ratio for image

            resultLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            selectImageButton.topAnchor.constraint(equalTo: resultLabel.bottomAnchor, constant: 30),
            selectImageButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            selectImageButton.widthAnchor.constraint(equalToConstant: 200),
            selectImageButton.heightAnchor.constraint(equalToConstant: 50),
            selectImageButton.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])

        selectImageButton.addTarget(self, action: #selector(selectImageTapped), for: .touchUpInside)
    }

    private func setupModel() {
        do {
            // Load the Core ML model
            let model = try PlantIdentifierModel(configuration: MLModelConfiguration())
            plantClassifier = try VNCoreMLModel(for: model.model)

            // Create a Vision request for classification
            classificationRequest = VNCoreMLRequest(model: plantClassifier!) { [weak self] request, error in
                self?.processClassifications(for: request, error: error)
            }
            // Configure the request for better accuracy if needed
            classificationRequest?.imageCropAndScaleOption = .centerCrop
        } catch {
            print("Failed to load Vision ML model: \(error)")
            resultLabel.text = "Error: Model failed to load."
        }
    }

    // MARK: - Image Selection
    @objc private func selectImageTapped() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary // Can also be .camera
        present(picker, animated: true)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)

        guard let selectedImage = info[.originalImage] as? UIImage else {
            resultLabel.text = "Error: Could not retrieve image."
            return
        }

        imageView.image = selectedImage
        resultLabel.text = "Classifying..."
        activityIndicator.startAnimating()

        // Perform classification asynchronously to keep the UI responsive
        Task {
            await classifyImage(selectedImage)
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }

    // MARK: - Image Classification
    private func classifyImage(_ image: UIImage) async {
        guard let classificationRequest = classificationRequest else {
            await MainActor.run {
                resultLabel.text = "Error: Model not set up."
                activityIndicator.stopAnimating()
            }
            return
        }

        // Convert UIImage to CVPixelBuffer, resizing to model's expected input dimensions (e.g., 224x224)
        // You might need to adjust width/height based on your specific model's input.
        // If the Vision request's imageCropAndScaleOption is set, Vision handles resizing automatically.
        // However, converting to CVPixelBuffer first can give more control or be necessary for certain models.
        // For VNCoreMLRequest, it's often sufficient to pass the CGImage directly.
        guard let cgImage = image.cgImage else {
            await MainActor.run {
                resultLabel.text = "Error: Could not get CGImage from UIImage."
                activityIndicator.stopAnimating()
            }
            return
        }

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        do {
            try handler.perform([classificationRequest])
        } catch {
            await MainActor.run {
                resultLabel.text = "Error: Failed to perform classification: \(error.localizedDescription)"
                activityIndicator.stopAnimating()
            }
        }
    }

    // MARK: - Process Classification Results
    private func processClassifications(for request: VNRequest, error: Error?) {
        Task { @MainActor in // Ensure UI updates are on the main actor
            activityIndicator.stopAnimating()
            if let error = error {
                resultLabel.text = "Classification Error: \(error.localizedDescription)"
                print("Classification Error: \(error)")
                return
            }

            guard let observations = request.results as? [VNClassificationObservation] else {
                resultLabel.text = "Error: No classification results."
                return
            }

            // Sort observations by confidence and get the top one
            guard let bestClassification = observations.first else {
                resultLabel.text = "No plant species identified with sufficient confidence."
                return
            }

            let confidencePercent = String(format: "%.2f%%", bestClassification.confidence * 100)
            resultLabel.text = "Predicted: \(bestClassification.identifier)\nConfidence: \(confidencePercent)"

            // CHALLENGE: Basic error handling for unexpected results
            if bestClassification.confidence < 0.5 { // Example threshold
                resultLabel.text = "Predicted: \(bestClassification.identifier)\nConfidence: \(confidencePercent)\n(Low confidence, result might be inaccurate.)"
            }
        }
    }
}
