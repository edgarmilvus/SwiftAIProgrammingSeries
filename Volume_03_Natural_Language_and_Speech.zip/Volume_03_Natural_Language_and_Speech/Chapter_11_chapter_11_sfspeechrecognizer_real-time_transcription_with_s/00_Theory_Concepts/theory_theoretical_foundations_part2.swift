
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import Speech

    @available(iOS 18.0, *)
    struct SpeechRecognitionView: View {
        @State private var manager = SpeechRecognizerManager() // StateObject or EnvironmentObject in real app

        var body: some View {
            VStack {
                Text("Transcription: \(manager.currentTranscription)")
                    .font(.title2)
                    .padding()

                Button(manager.isRecognizing ? "Stop Recognition" : "Start Recognition") {
                    if manager.isRecognizing {
                        manager.stopRecognition()
                    } else {
                        Task {
                            do {
                                try await manager.startRecognition()
                            } catch {
                                print("Error starting recognition: \(error.localizedDescription)")
                            }
                        }
                    }
                }
                .disabled(manager.authorizationStatus != .authorized)
                .buttonStyle(.borderedProminent)
                .padding()

                if manager.authorizationStatus == .notDetermined {
                    Button("Request Speech Recognition Authorization") {
                        Task { await manager.requestAuthorization() }
                    }
                    .buttonStyle(.bordered)
                    .padding()
                } else if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted {
                    Text("Speech recognition not authorized. Please enable in Settings.")
                        .foregroundColor(.red)
                        .padding()
                }
            }
            .task {
                // Initial authorization check
                await manager.requestAuthorization()
            }
        }
    }
    