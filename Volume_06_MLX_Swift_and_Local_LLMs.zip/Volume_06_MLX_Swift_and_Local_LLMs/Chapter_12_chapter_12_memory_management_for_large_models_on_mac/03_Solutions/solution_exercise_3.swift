
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
import MLX
import MLXNN
import MLXOptimizers

// 1. Implement LoRALinear
class LoRALinear: MLXNN.Module {
    let originalLinear: MLXNN.Linear
    let loraA: MLXNN.Linear
    let loraB: MLXNN.Linear
    let scaling: Float

    init(originalLinear: MLXNN.Linear, rank: Int, alpha: Float = 1.0) {
        self.originalLinear = originalLinear
        // LoRA-A: input_features -> rank (no bias)
        self.loraA = MLXNN.Linear(inputFeatures: originalLinear.inputFeatures, outputFeatures: rank, bias: false)
        // LoRA-B: rank -> output_features (no bias)
        self.loraB = MLXNN.Linear(inputFeatures: rank, outputFeatures: originalLinear.outputFeatures, bias: false)
        self.scaling = alpha / Float(rank) // LoRA scaling factor
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Original linear transformation (weights are frozen)
        let originalOutput = originalLinear(input)

        // LoRA adaptation: (input @ loraA) @ loraB * scaling
        let loraOutput = loraB(loraA(input)) * scaling

        return originalOutput + loraOutput
    }
}

// 2. Define a simplified LLM layer with LoRA integration
class SimpleTransformerBlockWithLoRA: MLXNN.Module {
    let query: LoRALinear
    let key: LoRALinear
    let value: LoRALinear
    let out: MLXNN.Linear // Output projection for self-attention
    let feedForward: MLXNN.Linear // Example FFN layer
    let norm1: MLXNN.LayerNorm
    let norm2: MLXNN.LayerNorm

    init(modelDim: Int, headDim: Int, numHeads: Int, loraRank: Int) {
        let linearConfig = MLXNN.Linear.Configuration(inputFeatures: modelDim, outputFeatures: modelDim)
        
        // Replace Q, K, V linear layers with LoRALinear
        self.query = LoRALinear(originalLinear: MLXNN.Linear(linearConfig), rank: loraRank)
        self.key = LoRALinear(originalLinear: MLXNN.Linear(linearConfig), rank: loraRank)
        self.value = LoRALinear(originalLinear: MLXNN.Linear(linearConfig), rank: loraRank)
        
        self.out = MLXNN.Linear(inputFeatures: modelDim, outputFeatures: modelDim)
        self.feedForward = MLXNN.Linear(inputFeatures: modelDim, outputFeatures: modelDim * 2) // Example FFN
        self.norm1 = MLXNN.LayerNorm(dimensions: [modelDim])
        self.norm2 = MLXNN.LayerNorm(dimensions: [modelDim])
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Simplified self-attention (no masking, etc. for exercise focus)
        // Apply LayerNorm before attention
        let normalizedInput = norm1(input)

        let q = query(normalizedInput)
        let k = key(normalizedInput)
        let v = value(normalizedInput)

        // Simulate attention mechanism
        // For simplicity, we'll use a placeholder for attention calculation.
        // Actual attention involves dot product, scaling, softmax, and weighted sum.
        // Here, we just combine them linearly for demonstration.
        // The key is that q,k,v come from LoRA-adapted layers.
        let attnOutput = out(q + k + v) // Simplified combination
        let attentionWithResidual = input + attnOutput // First residual connection

        // Apply LayerNorm before FFN
        let normalizedAttention = norm2(attentionWithResidual)
        let ffnOutput = MLXNN.relu(feedForward(normalizedAttention)) // Example FFN with activation

        return attentionWithResidual + ffnOutput // Second residual connection
    }
}

// 3. Implement the training loop
func trainLoRA(model: SimpleTransformerBlockWithLoRA, optimizer: Adam, data: [(input: MLXArray, target: MLXArray)], epochs: Int) {
    // Define the loss function
    func lossFn(model: SimpleTransformerBlockWithLoRA, input: MLXArray, target: MLXArray) -> MLXArray {
        let logits = model(input)
        // Assuming target is integer-encoded class labels for simplicity
        // Reshape logits to [batch * sequence_length, vocab_size] and targets to [batch * sequence_length]
        let reshapedLogits = MLX.reshape(logits, [logits.shape[0] * logits.shape[1], -1])
        let reshapedTargets = MLX.reshape(target, [-1])
        return MLX.losses.crossEntropy(logits: reshapedLogits, targets: reshapedTargets, axis: -1)
    }

    // Extract only LoRA parameters for training
    // These are the parameters of loraA and loraB within each LoRALinear module.
    let loraParameters: [String: MLXArray] = model.parameters().filter { (name, _) in
        name.contains("loraA") || name.contains("loraB")
    }
    print("Identified \(loraParameters.count) LoRA parameters for training.")

    // Create the valueAndGradient function, explicitly targeting only LoRA parameters
    let valueAndGradFun = MLX.valueAndGradient(lossFn)

    for epoch in 0..<epochs {
        var totalLoss: Float = 0.0
        for (input, target) in data {
            // Compute loss and gradients only for LoRA parameters
            let (loss, grads) = valueAndGradFun(model, input, target)
            
            // Filter gradients to ensure only LoRA parameters are updated
            let filteredGrads = grads.filter { (name, _) in
                loraParameters.keys.contains(name)
            }
            
            optimizer.update(model: model, gradients: filteredGrads) // Update only LoRA params
            totalLoss += loss.item(Float.self)
        }
        print("Epoch \(epoch + 1), Average Loss: \(totalLoss / Float(data.count))")
    }
}

// Example usage structure:
@available(iOS 18.0, macOS 15.0, *)
func exercise3Example() {
    print("--- Exercise 3: LoRA Fine-Tuning for Personalized Text Generation ---")

    let modelDim = 256 // Dimension of the model's embeddings
    let headDim = 64
    let numHeads = 4
    let loraRank = 8 // Low rank for LoRA matrices

    // Instantiate the base model with LoRA layers
    let model = SimpleTransformerBlockWithLoRA(modelDim: modelDim, headDim: headDim, numHeads: numHeads, loraRank: loraRank)
    
    // Initialize optimizer for LoRA parameters
    let optimizer = Adam(learningRate: 1e-3)

    // Create dummy data
    var dummyData: [(input: MLXArray, target: MLXArray)] = []
    let numBatches = 10
    let batchSize = 1
    let sequenceLength = 32
    let vocabSize = 100 // Example vocabulary size for target classes

    print("Creating \(numBatches) batches of dummy data...")
    for _ in 0..<numBatches {
        // Input: [batch, sequence_length, model_dim]
        let input = MLXArray.randomUniform(low: 0, high: 1, shape: [batchSize, sequenceLength, modelDim])
        // Target: [batch, sequence_length] (integer class labels)
        let target = MLXArray.randomUniform(low: 0, high: vocabSize, shape: [batchSize, sequenceLength], dtype: .int32)
        dummyData.append((input, target))
    }
    
    // Estimate memory footprint of all model parameters (base + LoRA)
    let totalModelMemory = estimateMemoryFootprint(model: model)
    print("Total model memory (base + LoRA): \(Double(totalModelMemory) / (1024 * 1024)) MB")

    // Estimate memory footprint of only LoRA parameters
    let loraParamsOnly = model.parameters().filter { (name, _) in name.contains("loraA") || name.contains("loraB") }
    let loraMemory = loraParamsOnly.values.reduce(0) { $0 + $1.nbytes }
    print("LoRA parameters memory only: \(Double(loraMemory) / (1024 * 1024)) MB")
    print("LoRA parameters constitute \((Double(loraMemory) / totalModelMemory * 100).formatted(.number.precision(.fractionLength(2))))% of total model parameters memory.")


    // Train only LoRA parameters
    print("Starting LoRA training...")
    trainLoRA(model: model, optimizer: optimizer, data: dummyData, epochs: 5)
    print("LoRA training finished.")
    print("--- End Exercise 3 ---")
}

// Call the example function to run the exercise
// exercise3Example() // Uncomment to run
