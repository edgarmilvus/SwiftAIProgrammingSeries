
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import OSLog
import Darwin

@available(iOS 18.0, *)
actor MemoryMonitor {
    private let logger = Logger(subsystem: "com.quickquery.app", category: "MemoryMonitoring")
    private var pressureSource: DispatchSourceMemoryPressure?
    private var lastLoggedThreshold: UInt64 = 0
    private let thresholdInterval: UInt64 = 100 * 1024 * 1024 // 100MB
    
    // Callback for when safety limit is hit
    var onSafetyLimitExceeded: (() -> Void)?
    private var safetyLimit: UInt64

    init(safetyLimitBytes: UInt64) {
        self.safetyLimit = safetyLimitBytes
    }

    /// Retrieves the current Resident Set Size (RSS) using Mach kernel APIs.
    func getResidentSetSize() -> UInt64 {
        var info = mach_task_basic_info()
        var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size) / 4
        
        let kerr: kern_return_t = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
            }
        }

        guard kerr == KERN_SUCCESS else {
            logger.error("Failed to retrieve task_info: \(kerr)")
            return 0
        }
        
        return UInt64(info.resident_size)
    }

    /// Starts observing system memory pressure events.
    func startMonitoring() {
        let source = DispatchSource.makeMemoryPressureSource(eventMask: [.warning, .critical], queue: .main)
        
        source.setEventHandler { [weak self] in
            Task { [weak self] in
                await self?.handlePressureEvent(source.data)
            }
        }
        
        source.resume()
        self.pressureSource = source
        logger.info("Memory monitoring started.")
    }

    private func handlePressureEvent(_ event: DispatchSource.MemoryPressureEvent) {
        let eventName: String
        switch event {
        case .normal: eventName = "Normal"
        case .warning: eventName = "Warning"
        case .critical: eventName = "Critical"
        @unknown default: eventName = "Unknown"
        }
        
        logger.warning("System Memory Pressure Detected: \(eventName)")
        
        if event == .critical {
            logger.critical("System is in critical memory state!")
        }
    }

    /// Periodic check to be called by a timer or loading loop.
    func performTelemetryCheck() {
        let currentRSS = getResidentSetSize()
        
        // Log threshold crossings (every 100MB)
        if currentRSS >= lastLoggedThreshold + thresholdInterval {
            logger.info("Memory Footprint: \(currentRSS / 1024 / 1024) MB")
            lastLoggedThreshold = (currentRSS / thresholdInterval) * thresholdInterval
        }

        // Check safety limit
        if currentRSS >= safetyLimit {
            logger.critical("Safety limit of \(self.safetyLimit / 1024 / 1024) MB exceeded!")
            onSafetyLimitExceeded?()
        }
    }
    
    func updateSafetyLimit(_ newLimit: UInt64) {
        self.safetyLimit = newLimit
    }
}
