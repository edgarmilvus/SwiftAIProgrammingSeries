
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// Package.swift snippet for MLX Swift dependency
// dependencies: [
//     .package(url: "https://github.com/ml-explore/mlx-swift.git", from: "0.0.1")
// ]

import MLX
import MLXNN // For MLXNN.Module

@available(iOS 18.0, macOS 15.0, *)
func exercise1_calibrateSensorData() {
    // 1. Define a Linear Model
    class SensorCalibrator: MLXNN.Module {
        let weight: MLXArray
        let bias: MLXArray

        init() {
            // Initialize weight and bias with small random values
            self.weight = MLXArray.random(
                [1], min: -0.1, max: 0.1, stream: .current,
                dtype: .float32
            )
            self.bias = MLXArray.random(
                [1], min: -0.1, max: 0.1, stream: .current,
                dtype: .float32
            )
            super.init()
        }

        // Forward pass: output = input * weight + bias
        func callAsFunction(_ input: MLXArray) -> MLXArray {
            return input * weight + bias
        }
    }

    // 2. Generate Synthetic Data
    func generateSyntheticData(
        numSamples: Int, trueWeight: Float, trueBias: Float, noiseScale: Float
    ) -> (MLXArray, MLXArray) {
        // Generate random inputs between 0 and 10
        let inputs = MLXArray.random([numSamples], stream: .current, dtype: .float32) * 10.0
        // Add random noise to targets
        let noise = MLXArray.random([numSamples], stream: .current, dtype: .float32) * noiseScale
        // Calculate targets based on a true linear relationship plus noise
        let targets = inputs * trueWeight + trueBias + noise
        return (inputs, targets)
    }

    let numSamples = 100
    let trueWeight: Float = 2.5
    let trueBias: Float = 7.0
    let noiseScale: Float = 0.5
    let (inputs, targets) = generateSyntheticData(
        numSamples: numSamples, trueWeight: trueWeight, trueBias: trueBias, noiseScale: noiseScale
    )

    // 3. Define the Loss Function (Mean Squared Error)
    func mseLoss(predictions: MLXArray, targets: MLXArray) -> MLXArray {
        // MSE = mean((predictions - targets)^2)
        return (predictions - targets).square().mean()
    }

    // 4. Implement the Training Loop
    let model = SensorCalibrator()
    let learningRate: Float = 0.01
    let optimizer = MLXOptimizers.SGD(learningRate: learningRate)
    let numEpochs = 1000

    print("Initial Model Parameters:")
    print("Weight: \(model.weight.item(Float.self)!)")
    print("Bias: \(model.bias.item(Float.self)!)")

    for epoch in 0..<numEpochs {
        // Compute loss and gradients efficiently using MLX's functional transformation
        let (loss, gradients) = valueAndGradient(model: model) { model in
            let predictions = model(inputs) // Forward pass
            return mseLoss(predictions: predictions, targets: targets) // Calculate loss
        }

        // Apply gradients to update model parameters (weight and bias)
        optimizer.update(model: model, gradients: gradients)

        if epoch % 100 == 0 {
            print("Epoch \(epoch), Loss: \(loss.item(Float.self)!)")
        }
    }

    print("\nFinal Model Parameters:")
    print("Weight: \(model.weight.item(Float.self)!)")
    print("Bias: \(model.bias.item(Float.self)!)")

    // 5. Evaluate
    let testInput = MLXArray(array: [3.0, 7.5, 12.0], dtype: .float32)
    let calibratedPredictions = model(testInput)
    print("\nTest Input: \(testInput)")
    print("Calibrated Predictions: \(calibratedPredictions)")
    // Compare with the true underlying relationship (without noise)
    print("True values for test input (approx): \(testInput * trueWeight + trueBias)")
}
