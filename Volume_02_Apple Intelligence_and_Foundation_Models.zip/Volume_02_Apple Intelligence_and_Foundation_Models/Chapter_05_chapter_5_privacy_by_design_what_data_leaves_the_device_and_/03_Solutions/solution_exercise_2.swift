
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import AppIntents
import Foundation
import SwiftUI // For IntentView

// This AppIntent would typically reside in an 'AppIntentExtension' target
// or directly within a modern SwiftUI app target that supports App Intents.

@available(iOS 18.0, macOS 15.0, *)
struct ComplexQueryIntent: AppIntent {
    static var title: LocalizedStringResource = "Answer Complex Query"
    static var description = IntentDescription(
        "Answers a complex query using AI. For advanced tasks, the system *might* leverage Private Cloud Compute (PCC) while ensuring user privacy and transparency.",
        category: .information
    )

    @Parameter(
        title: "Query",
        description: "The complex question or statement to be processed.",
        inputConnection: .plainText, // Suggests text input from Siri/Shortcuts
        requestValueDialog: "What complex question do you have?"
    )
    var query: String

    init() {} // Required initializer
    init(query: String) {
        self.query = query
    }

    func perform() async throws -> some IntentResult {
        print("Received query: \"\(query)\"")

        // Simulate a complexity check. In a real scenario, the system (not the app)
        // would determine if PCC is needed based on the model's capabilities,
        // the complexity of the input/task, and available on-device resources.
        let isComplexQuery = query.count > 150 || query.contains("explain") || query.contains("analyze") || query.contains("compare") || query.contains("implications")

        var resultText: String
        var simulationNote: String

        if isComplexQuery {
            simulationNote = "--- SIMULATING POTENTIAL PRIVATE CLOUD COMPUTE USAGE ---"
            print(simulationNote)
            print("This query is complex. The system *might* consider using Private Cloud Compute (PCC) for more powerful processing, especially if the on-device model is insufficient.")
            print("If PCC were engaged, the user would see a distinct visual indicator (e.g., the pulsing Siri glow, or a specific app-level indicator mirroring system behavior) for transparency.")
            print("Developers do not directly invoke PCC. The system manages it, ensuring data is cryptographically protected, not logged, and processed ephemerally on specialized Apple silicon servers.")
            print("Only the minimum necessary data, stripped of identifiers, would be sent to PCC, and only if the user has enabled Apple Intelligence features.")
            resultText = "Query processed (conceptually) with potential PCC. The system would have handled the intelligence securely."
        } else {
            simulationNote = "--- ON-DEVICE PROCESSING ---"
            print(simulationNote)
            print("This query is simple enough for on-device processing using local Foundation models or other on-device intelligence.")
            print("No data leaves the device for this operation.")
            resultText = "Query processed (conceptually) on-device."
        }

        // Return a result for the user, including the conceptual processing location.
        return .result(
            value: resultText,
            view: IntentView {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Your Query:").font(.headline)
                    Text(query).font(.body)
                    Divider()
                    Text("Processing Status:").font(.headline)
                    if isComplexQuery {
                        Text("This task is complex. The system *might* have engaged Private Cloud Compute (PCC) for enhanced processing. You would see a system-level indicator (like Siri's pulsing glow) if this were the case.")
                            .font(.caption)
                            .foregroundColor(.orange)
                    } else {
                        Text("This task was processed entirely on your device.")
                            .font(.caption)
                            .foregroundColor(.green)
                    }
                    Text("Apple Intelligence ensures your data is always protected, whether on-device or with PCC.")
                        .font(.footnote)
                        .foregroundColor(.gray)
                }
                .padding()
            }
        )
    }
}
