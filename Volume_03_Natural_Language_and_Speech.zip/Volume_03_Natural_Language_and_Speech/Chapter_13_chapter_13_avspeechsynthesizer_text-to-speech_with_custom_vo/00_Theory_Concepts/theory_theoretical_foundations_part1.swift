
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import AVFoundation

// @available(iOS 18.0, *) - Not strictly needed for AVSpeechUtterance itself,
// but good practice for newer concurrency examples.
@available(iOS 18.0, *)
struct SpeechRequest: Sendable {
    let text: String
    let voiceIdentifier: String? // Optional voice identifier
    let rate: Float
    let pitch: Float
    let volume: Float

    // Default initializer for convenience
    init(text: String, voiceIdentifier: String? = nil, rate: Float = AVSpeechUtteranceDefaultSpeechRate, pitch: Float = 1.0, volume: Float = 1.0) {
        self.text = text
        self.voiceIdentifier = voiceIdentifier
        self.rate = rate
        self.pitch = pitch
        self.volume = volume
    }
}

@available(iOS 18.0, *)
extension AVSpeechUtterance {
    convenience init(request: SpeechRequest) {
        self.init(string: request.text)
        self.rate = request.rate
        self.pitchMultiplier = request.pitch
        self.volume = request.volume
        if let identifier = request.voiceIdentifier,
           let voice = AVSpeechSynthesisVoice(identifier: identifier) {
            self.voice = voice
        } else if let voice = AVSpeechSynthesisVoice(language: "en-US") { // Fallback to a default language
            self.voice = voice
        }
    }
}

// Example Usage:
@available(iOS 18.0, *)
func createUtterance() -> AVSpeechUtterance {
    let text = "Hello, Swift developers! This is a synthesized voice."
    let utterance = AVSpeechUtterance(string: text)

    // Customize speech parameters
    utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.9 // Speak a bit slower
    utterance.pitchMultiplier = 1.1 // Higher pitch
    utterance.volume = 0.8 // Slightly lower volume
    utterance.preUtteranceDelay = 0.5 // Pause for 0.5 seconds before speaking
    utterance.postUtteranceDelay = 0.2 // Pause for 0.2 seconds after speaking

    // Select a specific voice (e.g., a premium English voice)
    if let premiumVoice = AVSpeechSynthesisVoice(identifier: "com.apple.ttsbundle.siri_female_en-US_premium") {
        utterance.voice = premiumVoice
    } else if let defaultVoice = AVSpeechSynthesisVoice(language: "en-US") {
        utterance.voice = defaultVoice
    }

    return utterance
}
