
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

import XCTest
import CoreML
import Vision
@testable import YourAIApp // Replace with your actual module name

@available(iOS 18.0, *)
final class DocumentIntelligenceTests: XCTestCase {
    
    var engine: DocumentIntelligenceEngine!
    var goldenSet: [GroundTruthEntry]!
    
    override func setUp() async throws {
        try await super.setUp()
        // Initialize the engine with a real or mock model
        engine = try DocumentIntelligenceEngine()
        
        // In a real test, this would be loaded from a JSON file in the Test Bundle
        goldenSet = [
            GroundTruthEntry(imageName: "receipt_01", expectedType: .receipt, minimumConfidenceThreshold: 0.9),
            GroundTruthEntry(imageName: "id_card_01", expectedType: .identityCard, minimumConfidenceThreshold: 0.9),
            GroundTruthEntry(imageName: "inv_01", expectedType: .invoice, minimumConfidenceThreshold: 0.85)
        ]
    }
    
    override func tearDown() async throws {
        engine = nil
        goldenSet = nil
        try await super.tearDown()
    }

    /// ADVANCED TEST: Model Validation via Golden Set
    /// This test uses Swift 6 Concurrency to run multiple inferences in parallel,
    /// simulating a heavy CI/CD load and testing the engine's thread safety.
    func testModelAccuracyWithGoldenSet() async throws {
        let aggregator = MetricsAggregator()
        
        // Use a TaskGroup to run inferences concurrently
        try await withThrowingTaskGroup(of: Void.self) { group in
            for entry in goldenSet {
                group.addTask {
                    // 1. Load the image from the test bundle
                    guard let image = self.loadTestImage(named: entry.imageName) else {
                        throw IntelligenceError.invalidInputImage
                    }
                    
                    // 2. Perform inference
                    let result = try await self.engine.classify(image: image)
                    
                    // 3. Validate against ground truth
                    let isCorrect = (result.type == entry.expectedType) && 
                                    (result.confidence >= entry.minimumConfidenceThreshold)
                    
                    // 4. Record results in the thread-safe aggregator
                    await aggregator.record(
                        expected: entry.expectedType,
                        actual: result.type,
                        isCorrect: isCorrect
                    )
                }
            }
            
            // Wait for all tasks to complete
            try await group.waitForAll()
        }
        
        // 5. Finalize and Assert Statistical Significance
        let metrics = await aggregator.finalize()
        
        print("--- AI Model Validation Report ---")
        print("Total Tested: \(metrics.totalTested)")
        print("Accuracy: \(metrics.accuracy * 100)%")
        print("Precision: \(metrics.precision)")
        print("Recall: \(metrics.recall)")
        print("F1 Score: \(metrics.f1Score)")
        
        // Assertions: We don't want a 100% perfect model (often impossible),
        // but we require a minimum F1 score for production readiness.
        XCTAssertGreaterThan(metrics.accuracy, 0.85, "Model accuracy fell below 85% threshold.")
        XCTAssertGreaterThan(metrics.f1Score, 0.80, "Model F1 score is too low for reliable use.")
    }
    
    /// ADVANCED TEST: Performance Profiling
    /// Uses XCTMetric to measure the exact time taken for inference.
    /// This prevents "Performance Regression" where a new model is accurate but too slow.
    func testInferencePerformance() async throws {
        guard let image = loadTestImage(named: "receipt_01") else {
            XCTFail("Test image missing")
            return
        }
        
        let options = XCTMeasureOptions()
        options.iterationCount = 10 // Run multiple times to get a stable average
        
        // We use XCTMetric to track wall-clock time and CPU usage
        measure(metrics: [XCTClockMetric(), XCTCPUMetric()], options: options) {
            let expectation = expectation(description: "Inference completes")
            
            Task {
                do {
                    _ = try await engine.classify(image: image)
                    expectation.fulfill()
                } catch {
                    XCTFail("Performance test failed with error: \(error)")
                }
            }
            
            wait(for: [expectation], timeout: 5.0)
        }
    }
    
    // MARK: - Helpers
    
    private func loadTestImage(named name: String) -> CGImage? {
        // In a real implementation, you would use Bundle(for: type(of: self))
        // to locate the image in the test bundle.
        return nil // Placeholder for implementation
    }
}
