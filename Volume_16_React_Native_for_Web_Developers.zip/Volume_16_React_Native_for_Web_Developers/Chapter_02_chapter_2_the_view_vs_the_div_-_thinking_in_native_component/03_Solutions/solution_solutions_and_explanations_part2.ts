/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const DashboardLayout = () => {
  // State to manage the flexDirection of the content area
  const [contentDirection, setContentDirection] = useState<'row' | 'column'>('row');

  const toggleDirection = () => {
    setContentDirection((prev) => (prev === 'row' ? 'column' : 'row'));
  };

  return (
    <View style={styles.rootContainer}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerText}>Dashboard</Text>
        <TouchableOpacity onPress={toggleDirection} style={styles.toggleButton}>
          <Text style={styles.toggleButtonText}>
            Switch to {contentDirection === 'row' ? 'Column' : 'Row'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Content Area */}
      <View style={[styles.contentArea, { flexDirection: contentDirection }]}>
        <View style={styles.contentChild}>
          <Text style={styles.childText}>Left / Top</Text>
        </View>
        <View style={styles.contentChild}>
          <Text style={styles.childText}>Right / Bottom</Text>
        </View>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>Nav Item 1</Text>
        <Text style={styles.footerText}>Nav Item 2</Text>
        <Text style={styles.footerText}>Nav Item 3</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1, // Takes up full screen
    backgroundColor: '#fff',
  },
  header: {
    height: 60,
    backgroundColor: '#f8f8f8',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  toggleButton: {
    backgroundColor: '#007AFF',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 4,
  },
  toggleButtonText: {
    color: '#fff',
    fontSize: 12,
  },
  contentArea: {
    flex: 1, // Expands to fill remaining space
    // flexDirection is set dynamically via state
    backgroundColor: '#fff',
  },
  contentChild: {
    flex: 1, // Each child takes equal width/height based on flexDirection
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#eee',
  },
  childText: {
    fontSize: 16,
    color: '#555',
  },
  footer: {
    height: 60,
    backgroundColor: '#333',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  footerText: {
    color: '#fff',
    fontSize: 14,
  },
});

export default DashboardLayout;
