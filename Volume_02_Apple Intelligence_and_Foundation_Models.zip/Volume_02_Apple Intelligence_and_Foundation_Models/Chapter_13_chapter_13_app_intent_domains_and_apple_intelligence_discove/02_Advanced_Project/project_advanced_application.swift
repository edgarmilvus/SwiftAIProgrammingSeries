
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift (Conceptual - not directly part of the runtime script, but for context)
// This file would define your app's dependencies. For AppIntents, it's a system framework.
// If you were to wrap Apple Intelligence APIs in a separate module, it might look like this.

/*
import PackageDescription

let package = Package(
    name: "ResearchNotesApp",
    platforms: [.iOS(.v18)], // AppIntents requires iOS 18+
    products: [
        .library(
            name: "ResearchNotesAppIntents",
            targets: ["ResearchNotesAppIntents"]),
    ],
    dependencies: [
        // No explicit AppIntents SPM dependency, it's a system framework.
        // If there were a hypothetical SDK for Apple Intelligence beyond AppIntents,
        // it might be listed here, e.g.,
        // .package(url: "https://github.com/apple/apple-intelligence-sdk.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "ResearchNotesAppIntents",
            dependencies: [
                // If the AppIntents were in a separate module, it would import Foundation, AppIntents
            ]),
    ]
)
*/

import Foundation
import AppIntents // This is the core framework for defining app intents.
import SwiftUI // Required for IntentView

// MARK: - 1. ResearchNote Model: The Data Structure

/// Represents a single research note within the application.
/// This simple struct holds the content and metadata for a note.
/// It conforms to `Identifiable` for easy referencing and `Codable` for potential persistence.
struct ResearchNote: Identifiable, Codable {
    let id: String
    var title: String
    var content: String
    let creationDate: Date

    init(id: String = UUID().uuidString, title: String, content: String, creationDate: Date = Date()) {
        self.id = id
        self.title = title
        self.content = content
        self.creationDate = creationDate
    }
}

// MARK: - 2. ResearchNotesDataStore: Simulated Data Persistence

/// A singleton class to simulate a data store for `ResearchNote` objects.
/// In a real application, this would interact with Core Data, SwiftData, or a backend API.
/// It provides methods to add and retrieve notes, essential for intents to operate on.
/// Uses a concurrent queue with barriers for thread-safe access to the `notes` dictionary.
class ResearchNotesDataStore {
    static let shared = ResearchNotesDataStore()
    internal var notes: [String: ResearchNote] = [:] // Internal for demonstration purposes
    private let queue = DispatchQueue(label: "com.researchnotesapp.datastore", attributes: .concurrent)

    private init() {
        // Pre-populate with some sample data for demonstration purposes.
        addNote(ResearchNote(title: "Quantum Computing Basics", content: """
        Quantum computing is a new type of computing that uses the principles of quantum mechanics,
        such as superposition and entanglement, to perform calculations. Unlike classical computers
        that use bits representing 0 or 1, quantum computers use qubits, which can represent 0, 1,
        or both simultaneously. This allows them to solve certain problems much faster than classical
        computers, especially in areas like cryptography, drug discovery, and materials science.
        The development of stable qubits and error correction remains a significant challenge.
        """))
        addNote(ResearchNote(title: "AI Ethics in Large Language Models", content: """
        The rapid advancement of large language models (LLMs) brings significant ethical considerations.
        These include bias in training data leading to discriminatory outputs, the potential for
        misinformation and deepfakes, copyright issues with generated content, and job displacement.
        Ensuring transparency, accountability, and fairness in LLM development and deployment is crucial.
        Regulatory frameworks and interdisciplinary collaboration are needed to navigate these challenges
        and harness the benefits of AI responsibly.
        """))
    }

    /// Adds a new research note to the data store in a thread-safe manner.
    /// - Parameter note: The `ResearchNote` object to add.
    func addNote(_ note: ResearchNote) {
        queue.async(flags: .barrier) { // Use a barrier to ensure exclusive write access.
            self.notes[note.id] = note
            print("💾 Added note: \(note.title) (ID: \(note.id))")
        }
    }

    /// Retrieves a research note by its ID asynchronously and safely.
    /// - Parameter id: The unique identifier of the note.
    /// - Returns: The `ResearchNote` if found, otherwise `nil`.
    func getNote(by id: String) async -> ResearchNote? {
        return await queue.async { // Asynchronously read from the dictionary.
            self.notes[id]
        }
    }
}

// MARK: - 3. AppleIntelligenceLLMService: Simulated On-Device LLM Interaction

/// A simulated service for interacting with Apple's on-device LLM capabilities.
/// In a real scenario, this would use dedicated APIs provided by Apple for
/// summarization, text generation, and other AI tasks, potentially via `Foundation.ML`
/// or `CoreML` integration with specialized models.
/// We simulate asynchronous operations and potential failures to mimic real-world conditions.
class AppleIntelligenceLLMService {
    static let shared = AppleIntelligenceLLMService()

    private init() {}

    /// Defines specific error types for the LLM service, making error handling more granular.
    enum LLMServiceError: Error, CustomStringConvertible {
        case summarizationFailed
        case taskGenerationFailed
        case contentTooShort
        case serviceUnavailable
        case unknown(String)

        var description: String {
            switch self {
            case .summarizationFailed: return "Failed to generate summary."
            case .taskGenerationFailed: return "Failed to generate follow-up task."
            case .contentTooShort: return "Content is too short for meaningful processing by LLM."
            case .serviceUnavailable: return "LLM service is temporarily unavailable due to system load."
            case .unknown(let msg): return "An unknown LLM service error occurred: \(msg)"
            }
        }
    }

    /// Simulates summarizing a given text using an on-device LLM.
    /// Introduces artificial delays and random failure points for realism.
    /// - Parameter text: The input text to summarize.
    /// - Returns: A concise summary of the text.
    /// - Throws: `LLMServiceError` if summarization fails or content is unsuitable.
    func summarize(text: String) async throws -> String {
        // Simulate computation or network delay for LLM processing.
        await Task.sleep(nanoseconds: UInt64.random(in: 500_000_000...1_500_000_000))

        // Critical: LLMs require a minimum amount of content for meaningful output.
        guard text.count > 100 else {
            throw LLMServiceError.contentTooShort
        }
        
        // Simulate a random failure for demonstration purposes (~20% chance).
        if Int.random(in: 1...10) <= 2 {
            throw LLMServiceError.summarizationFailed
        }

        // Extremely simplified "summarization" logic for simulation.
        let words = text.split(separator: " ")
        let summaryWords = words.prefix(min(15, words.count))
        let summary = summaryWords.joined(separator: " ") + (words.count > 15 ? "..." : "")
        return summary + "\n(Simulated LLM Summary)"
    }

    /// Simulates generating a follow-up task description based on note content.
    /// - Parameter noteContent: The content of the research note.
    /// - Returns: A suggested task description.
    /// - Throws: `LLMServiceError` if task generation fails.
    func generateFollowUpTask(from noteContent: String) async throws -> String {
        // Simulate computation or network delay.
        await Task.sleep(nanoseconds: UInt64.random(in: 700_000_000...2_000_000_000))

        // Ensure sufficient content for task generation.
        guard noteContent.count > 50 else {
            throw LLMServiceError.contentTooShort
        }

        // Simulate a random failure (~15% chance).
        if Int.random(in: 1...10) <= 1 {
            throw LLMServiceError.taskGenerationFailed
        }

        // Simplified task generation logic.
        let keywords = ["research", "review", "analyze", "document", "present", "follow up on"]
        let suggestedTask = keywords.randomElement()! + " findings from " + noteContent.prefix(50).description.trimmingCharacters(in: .whitespacesAndNewlines) + "..."
        return suggestedTask + " (Simulated LLM Task Suggestion)"
    }
}

// MARK: - 4. ResearchNotesAppIntentDomain: The Intent Grouping

/// Defines the domain for all App Intents provided by the ResearchNotes app.
/// This groups related intents and makes them discoverable by Apple Intelligence.
/// `@available(iOS 18.0, *)` is crucial as `AppIntents` are new in iOS 18.
@available(iOS 18.0, *)
struct ResearchNotesAppIntentDomain: AppIntentDomain {
    static var identifier: String = "researchNotes" // Unique identifier for this domain.
    static var displayName: LocalizedStringResource? = "Research Notes" // User-facing name.
    static var description: IntentDescription? = "Intents for managing and interacting with research notes within the Research Notes app."
}

// MARK: - 5. SummarizeResearchNoteIntent: An Actionable Intent

/// An App Intent to summarize a specific research note using Apple Intelligence's capabilities.
/// This intent will be discoverable by the system, allowing users to ask Siri,
/// use Writing Tools, or leverage other Apple Intelligence features to summarize notes
/// directly from the ResearchNotes app or from other contexts where a note ID is available.
@available(iOS 18.0, *)
struct SummarizeResearchNoteIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize Research Note"
    static var description: IntentDescription? = "Generates a concise summary of a research note using Apple Intelligence."
    static var openAppWhenRun: Bool = false // No need to open the app for just a summary.
    static var intentCategory: IntentCategory = .view // Categorize as a "view" or "read" action.

    /// The unique identifier of the research note to summarize.
    /// `@Parameter` makes this input discoverable and configurable by the system.
    @Parameter(title: "Note ID", description: "The unique identifier of the research note to summarize.")
    var noteID: String

    /// Initializes the intent with a specific note ID.
    /// This initializer is used when the intent is created programmatically,
    /// for example, by Apple Intelligence passing a discovered note ID.
    init(noteID: String) {
        self.noteID = noteID
    }

    /// Default initializer for App Intents, required by the framework.
    /// This is often called by the system when the intent is being configured
    /// or when no specific parameters are provided initially.
    init() {}

    /// Performs the action associated with this intent.
    /// This method is asynchronous and can throw errors, reflecting real-world operations.
    /// It returns an `IntentResult` that includes the summary value.
    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        print("🚀 SummarizeResearchNoteIntent invoked for Note ID: \(noteID)")

        // 1. Retrieve the research note from the data store.
        guard let note = await ResearchNotesDataStore.shared.getNote(by: noteID) else {
            print("❌ Error: Note with ID \(noteID) not found.")
            // Use `IntentError.notFound` for user-facing errors when a required entity is missing.
            throw IntentError.notFound("Research Note with ID '\(noteID)'")
        }

        // 2. Call the simulated LLM service to generate the summary.
        do {
            let summary = try await AppleIntelligenceLLMService.shared.summarize(text: note.content)
            print("✅ Successfully summarized note '\(note.title)': \(summary.prefix(50))...")
            // Return the summary text as the value of the intent result.
            return .result(value: summary, view: nil)
        } catch let error as AppleIntelligenceLLMService.LLMServiceError {
            print("❌ LLM Service Error during summarization: \(error.description)")
            // Map internal LLM errors to `AppIntent`-compatible errors for system display.
            throw IntentError.internalError("Failed to summarize note: \(error.description)")
        } catch {
            print("❌ An unexpected error occurred during summarization: \(error.localizedDescription)")
            throw IntentError.internalError("An unexpected system error occurred during summarization.")
        }
    }
}

// MARK: - 6. CreateFollowUpTaskIntent: An Actionable Intent with LLM Generation

/// An App Intent to create a follow-up task related to a research note.
/// This intent demonstrates how Apple Intelligence could proactively suggest
/// actions based on note content, potentially even generating task descriptions
/// if the user doesn't provide one.
@available(iOS 18.0, *)
struct CreateFollowUpTaskIntent: AppIntent {
    static var title: LocalizedStringResource = "Create Follow-up Task"
    static var description: IntentDescription? = "Creates a new task related to a research note, optionally generating a description using Apple Intelligence."
    static var openAppWhenRun: Bool = true // We might want to open the app to show the new task.
    static var intentCategory: IntentCategory = .create // Categorize as a "create" action.

    /// The unique identifier of the research note to associate the task with.
    @Parameter(title: "Note ID", description: "The unique identifier of the research note to associate the task with.")
    var noteID: String

    /// An optional description for the follow-up task. If not provided, Apple Intelligence
    /// (via our simulated LLM service) may suggest one based on the note's content.
    /// `requestValueDialog` provides a user-friendly prompt if the system needs to ask.
    @Parameter(title: "Task Description", description: "A description for the follow-up task. If empty, Apple Intelligence may suggest one.", requestValueDialog: "What should the task be for this note?")
    var taskDescription: String?

    /// An optional due date for the task.
    @Parameter(title: "Due Date", description: "The optional due date for the task.", requestValueDialog: "When is this task due?")
    var dueDate: Date?

    /// Initializes the intent with specific parameters.
    init(noteID: String, taskDescription: String? = nil, dueDate: Date? = nil) {
        self.noteID = noteID
        self.taskDescription = taskDescription
        self.dueDate = dueDate
    }

    /// Default initializer, required by the framework.
    init() {}

    /// Performs the action to create a follow-up task.
    /// This method handles retrieving the note, potentially generating a task description
    /// using the LLM, and then simulating task creation.
    func perform() async throws -> some IntentResult {
        print("🚀 CreateFollowUpTaskIntent invoked for Note ID: \(noteID)")

        // 1. Retrieve the research note from the data store.
        guard let note = await ResearchNotesDataStore.shared.getNote(by: noteID) else {
            print("❌ Error: Note with ID \(noteID) not found.")
            throw IntentError.notFound("Research Note with ID '\(noteID)'")
        }

        var finalTaskDescription = taskDescription

        // 2. If no task description is provided by the user or system, use the LLM to generate one.
        if finalTaskDescription == nil || finalTaskDescription!.isEmpty {
            print("💡 No task description provided, attempting to generate one using simulated LLM...")
            do {
                finalTaskDescription = try await AppleIntelligenceLLMService.shared.generateFollowUpTask(from: note.content)
                print("✅ LLM generated task description: \(finalTaskDescription!)")
            } catch let error as AppleIntelligenceLLMService.LLMServiceError {
                print("❌ LLM Service Error during task generation: \(error.description)")
                throw IntentError.internalError("Failed to generate task description: \(error.description)")
            } catch {
                print("❌ An unexpected error occurred during task generation: \(error.localizedDescription)")
                throw IntentError.internalError("An unexpected system error occurred while generating task.")
            }
        }

        // Ensure we have a task description before proceeding.
        guard let confirmedTaskDescription = finalTaskDescription else {
            print("❌ Critical: Task description could not be determined even after LLM attempt.")
            throw IntentError.internalError("Task description is missing and could not be generated.")
        }

        // 3. Simulate creating the task in an internal task manager.
        // In a real app, this would involve saving to a database, creating a Calendar event,
        // interacting with Reminders, or posting to a backend service.
        await Task.sleep(nanoseconds: 200_000_000) // Simulate task creation delay.
        let taskDetails = """
        New Task: "\(confirmedTaskDescription)"
        Related to Note: "\(note.title)" (ID: \(note.id))
        Due Date: \(dueDate?.formatted(date: .abbreviated, time: .shortened) ?? "None specified")
        """
        print("✅ Successfully created simulated task:\n\(taskDetails)")

        // 4. Return a success result, optionally with a custom SwiftUI view for richer feedback.
        return .result(view: IntentView {
            VStack(alignment: .leading) {
                Text("Task Created!")
                    .font(.title2)
                    .fontWeight(.bold)
                Text(confirmedTaskDescription)
                    .font(.headline)
                    .padding(.bottom, 4)
                Text("Related to: \(note.title)")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                if let dueDate = dueDate {
                    Text("Due: \(dueDate.formatted(date: .abbreviated, time: .shortened))")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .padding()
            .background(RoundedRectangle(cornerRadius: 10).fill(Color.blue.opacity(0.1)))
        })
    }
}

// MARK: - Conceptual App Integration & Discovery (No executable code here, just explanation)

/*
    ### Apple Intelligence Discovery and Integration

    For these `AppIntent`s to be discoverable by Apple Intelligence, they need to be part of your app's bundle.
    When your app is installed, the system scans its bundle for `AppIntent` and `AppIntentDomain` definitions.

    **How Apple Intelligence Uses These Intents:**

    1.  **Contextual Awareness:** If a user is viewing a document in Mail or Safari, and that document contains
        a reference (e.g., a URL, a specific ID pattern) that your "ResearchNotes" app has registered as
        a potential `AppEntity` or `AppIntent` parameter, Apple Intelligence can suggest actions. For example,
        if the email mentions "summarize note ID: abc-123", the system might suggest "Summarize in ResearchNotes".

    2.  **Writing Tools:** When a user is typing in a text field, and the context aligns with an intent
        (e.g., "Summarize this document"), Apple Intelligence's Writing Tools could present "Summarize in ResearchNotes"
        as an option, potentially pre-filling the `noteID` parameter if contextually available.

    3.  **Siri:** Users could directly invoke these intents via Siri: "Hey Siri, summarize research note abc-123 in Research Notes app."

    4.  **Proactive Suggestions:** In the future, Apple Intelligence might proactively suggest "Create a follow-up task for your 'Quantum Computing Basics' note"
        based on your usage patterns or upcoming meetings.

    **To make them fully discoverable:**

    *   Ensure your `Info.plist` or `App` struct (for SwiftUI lifecycle) correctly declares the `AppIntent`s.
        For `AppIntents`, you typically don't need explicit `Info.plist` entries for *discovery* itself,
        as the system scans the app bundle. However, for features like Widgets or Siri Shortcuts,
        you might have additional configurations. The mere presence of `@available(iOS 18.0, *)`
        `AppIntent` and `AppIntentDomain` definitions in your app's target is generally sufficient
        for Apple Intelligence to begin its discovery process.

    *   For more complex parameter resolution (e.g., resolving a `ResearchNote` object directly instead of just its ID),
        you would define `AppEntity` types for `ResearchNote` and implement `AppEntityQuery` for them.
        This allows Apple Intelligence to understand and resolve your custom data types, enabling more natural language
        interactions (e.g., "summarize 'Quantum Computing Basics' note").
        (This example uses `String` for `noteID` for simplicity, but `AppEntity` would be the advanced pattern here).

    ### Example of Programmatic Intent Invocation (for testing or internal use)

    While Apple Intelligence handles discovery and invocation, you can also test these intents programmatically.
*/

@available(iOS 18.0, *)
func demonstrateIntents() async {
    print("\n--- Demonstrating App Intents (Simulated Apple Intelligence Invocation) ---")

    // Retrieve sample note IDs from our simulated data store.
    let notes = Array(ResearchNotesDataStore.shared.notes.values)
    guard notes.count >= 2 else {
        print("Not enough sample notes available to demonstrate all scenarios.")
        return
    }
    let noteID1 = notes[0].id
    let noteID2 = notes[1].id
    
    // Ensure the data store has initialized and contains notes.
    guard !noteID1.isEmpty else {
        print("No sample notes available to demonstrate.")
        return
    }

    // --- Scenario 1: Summarize a Research Note ---
    print("\n--- Scenario 1: Summarize a Research Note ---")
    print("Attempting to summarize Research Note ID: \(noteID1)")
    let summarizeIntent = SummarizeResearchNoteIntent(noteID: noteID1)
    do {
        let result = try await summarizeIntent.perform()
        if let summary = result.value {
            print("✅ Summarization successful:\n\(summary)")
        } else {
            print("⚠️ Summarization performed but no value returned, which is unexpected for this intent.")
        }
    } catch let error as IntentError {
        print("❌ Intent Error during summarization: \(error.localizedDescription)")
    } catch {
        print("❌ Unexpected error during summarization: \(error.localizedDescription)")
    }

    // --- Scenario 2: Create a Follow-up Task (with LLM generation for description) ---
    print("\n--- Scenario 2: Create a Follow-up Task (LLM generates description) ---")
    print("Attempting to create a follow-up task for Research Note ID: \(noteID2) (LLM will generate description)")
    // Due date set for 7 days from now.
    let createTaskIntent1 = CreateFollowUpTaskIntent(noteID: noteID2, dueDate: Date().addingTimeInterval(7 * 24 * 60 * 60))
    do {
        let result = try await createTaskIntent1.perform()
        // The IntentView is handled by the system for display, so we just confirm success here.
        print("✅ Task creation successful (result view handled internally by system).")
    } catch let error as IntentError {
        print("❌ Intent Error during task creation: \(error.localizedDescription)")
    } catch {
        print("❌ Unexpected error during task creation: \(error.localizedDescription)")
    }

    // --- Scenario 3: Create a Follow-up Task (with user-provided description) ---
    print("\n--- Scenario 3: Create a Follow-up Task (User provides description) ---")
    print("Attempting to create a follow-up task for Research Note ID: \(noteID1) (with provided description)")
    // Due date set for 5 days from now.
    let createTaskIntent2 = CreateFollowUpTaskIntent(noteID: noteID1, taskDescription: "Review LLM ethics paper by end of week.", dueDate: Date().addingTimeInterval(5 * 24 * 60 * 60))
    do {
        let result = try await createTaskIntent2.perform()
        print("✅ Task creation successful (result view handled internally by system).")
    } catch let error as IntentError {
        print("❌ Intent Error during task creation: \(error.localizedDescription)")
    } catch {
        print("❌ Unexpected error during task creation: \(error.localizedDescription)")
    }

    // --- Scenario 4: Summarize a non-existent note (Error Handling Test) ---
    print("\n--- Scenario 4: Summarize a non-existent note (Error Handling Test) ---")
    print("Attempting to summarize a non-existent note (ID: non-existent-123)")
    let nonExistentNoteIntent = SummarizeResearchNoteIntent(noteID: "non-existent-123")
    do {
        _ = try await nonExistentNoteIntent.perform()
        print("⚠️ Summarization unexpectedly succeeded for non-existent note.")
    } catch let error as IntentError {
        print("✅ Expected IntentError caught for non-existent note: \(error.localizedDescription)")
    } catch {
        print("❌ Unexpected error type for non-existent note: \(error.localizedDescription)")
    }

    // --- Scenario 5: Summarize a note with content too short (LLM Service Error Handling Test) ---
    print("\n--- Scenario 5: Summarize a note with very short content (LLM Service Error Handling Test) ---")
    let shortNote = ResearchNote(title: "Short Note", content: "This is a very short note, too short for an LLM to summarize effectively.")
    ResearchNotesDataStore.shared.addNote(shortNote) // Add a short note to the store.
    let shortNoteIntent = SummarizeResearchNoteIntent(noteID: shortNote.id)
    do {
        _ = try await shortNoteIntent.perform()
        print("⚠️ Summarization unexpectedly succeeded for short content note.")
    } catch let error as IntentError {
        print("✅ Expected IntentError caught for short content note (LLMServiceError mapped): \(error.localizedDescription)")
    } catch {
        print("❌ Unexpected error type for short content note: \(error.localizedDescription)")
    }
}

// To run this in an Xcode Playground or a simple command-line tool,
// you'd typically wrap the async call in a Task.
// Make sure to set the platform to iOS 18.0 or higher in your project settings/playground.
if #available(iOS 18.0, *) {
    Task {
        await demonstrateIntents()
    }
} else {
    print("AppIntents require iOS 18.0 or later. This code cannot run on older iOS versions.")
}

/*


::: {style="text-align: center"}
![Visualizing the iOS 15.0 minimum deployment target, which prevents this code from running on older iOS versions.](images/b2_c13_s3_diag1.png){width=80% caption="Visualizing the iOS 15.0 minimum deployment target, which prevents this code from running on older iOS versions."}
:::


*/
