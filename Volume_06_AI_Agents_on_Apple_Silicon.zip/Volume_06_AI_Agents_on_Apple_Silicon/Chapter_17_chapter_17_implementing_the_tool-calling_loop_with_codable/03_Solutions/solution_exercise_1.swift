
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

// MARK: - Common Tooling Infrastructure (from Exercise 1 & 4)

// A structure to represent the LLM's parsed tool call.
// In a real scenario, this would be deserialized from the LLM's output.
struct ToolCall: Codable {
    let toolName: String
    let arguments: String // Raw JSON string of arguments
}

// Helper for encoding/decoding dynamic JSON, crucial for LLM tool manifests
struct AnyCodable: Codable {
    let value: Any

    init(_ value: Any) {
        self.value = value
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let string = try? container.decode(String.self) {
            value = string
        } else if let int = try? container.decode(Int.self) {
            value = int
        } else if let double = try? container.decode(Double.self) {
            value = double
        } else if let bool = try? container.decode(Bool.self) {
            value = bool
        } else if let array = try? container.decode([AnyCodable].self) {
            value = array.map { $0.value }
        } else if let dictionary = try? container.decode([String: AnyCodable].self) {
            value = dictionary.mapValues { $0.value }
        } else if container.decodeNil() { // Handle null values
            value = NSNull()
        }
        else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "AnyCodable value cannot be decoded")
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        if let string = value as? String {
            try container.encode(string)
        } else if let int = value as? Int {
            try container.encode(int)
        } else if let double = value as? Double {
            try container.encode(double)
        } else if let bool = value as? Bool {
            try container.encode(bool)
        } else if let array = value as? [Any] {
            try container.encode(array.map(AnyCodable.init))
        } else if let dictionary = value as? [String: Any] {
            try container.encode(dictionary.mapValues(AnyCodable.init))
        } else if value is NSNull { // Handle null values
            try container.encodeNil()
        }
        else {
            throw EncodingError.invalidValue(value, EncodingError.Context(codingPath: encoder.codingPath, debugDescription: "AnyCodable value cannot be encoded"))
        }
    }
}

// Define a common protocol for all tools.
// This provides a consistent interface for the tool-calling mechanism.
protocol Tool: Codable, Identifiable {
    var id: UUID { get } // Conformance to Identifiable
    var name: String { get }
    var description: String { get }
    var parametersSchema: String { get } // JSON Schema for arguments

    // Associated type for the tool's specific arguments, must be Codable.
    associatedtype Arguments: Codable

    // Executes the tool with parsed arguments.
    func execute(arguments: Arguments) async throws -> String

    // Helper for dynamic argument decoding and execution (for ToolRegistry)
    func decodeAndExecute(jsonArguments: String) async throws -> String
}

extension Tool {
    var id: UUID { UUID() } // Default implementation for Identifiable

    func decodeAndExecute(jsonArguments: String) async throws -> String {
        let decoder = JSONDecoder()
        guard let data = jsonArguments.data(using: .utf8) else {
            throw ToolError.invalidArgumentsData
        }
        let arguments = try decoder.decode(Arguments.self, from: data)
        return try await self.execute(arguments: arguments)
    }
}

enum ToolError: Error, LocalizedError {
    case unknownTool(String)
    case invalidArgumentsData
    case argumentDecodingFailed(Error)
    case toolExecutionFailed(Error)
    case divisionByZero
    case unknownOperation(String)
    case timeZoneNotFound(String)
    case lightNotFound(String)
    case thermostatNotFound(String)
    case sceneNotFound(String)
    case temperatureOutOfRange(Double, min: Double, max: Double)

    var errorDescription: String? {
        switch self {
        case .unknownTool(let name):
            return "Unknown tool: \(name)"
        case .invalidArgumentsData:
            return "Invalid arguments data provided to tool."
        case .argumentDecodingFailed(let error):
            return "Failed to decode tool arguments: \(error.localizedDescription)"
        case .toolExecutionFailed(let error):
            return "Tool execution failed: \(error.localizedDescription)"
        case .divisionByZero:
            return "Cannot divide by zero."
        case .unknownOperation(let op):
            return "Unknown operation: \(op)"
        case .timeZoneNotFound(let city):
            return "Could not find time zone for city: \(city)"
        case .lightNotFound(let name):
            return "Light '\(name)' not found in smart home state."
        case .thermostatNotFound(let name):
            return "Thermostat '\(name)' not found in smart home state."
        case .sceneNotFound(let name):
            return "Scene '\(name)' not found in smart home state."
        case .temperatureOutOfRange(let temp, let min, let max):
            return "Target temperature \(temp) is out of valid range (\(min)-\(max)°C)."
        }
    }
}

// MARK: - ToolRegistry (for Exercise 3 & 4)

class ToolRegistry {
    private var tools: [String: any Tool] = [:]

    func registerTool(_ tool: any Tool) {
        tools[tool.name] = tool
    }

    func findTool(byName name: String) -> (any Tool)? {
        return tools[name]
    }

    // For Exercise 4: Generates the LLM-compatible tool manifest
    func generateLLMToolManifest() throws -> String {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted

        var llmToolDefinitions: [LLMToolDefinition] = []

        for (_, tool) in tools {
            guard let schemaData = tool.parametersSchema.data(using: .utf8) else {
                throw ToolError.invalidArgumentsData // Or a more specific error
            }
            guard let jsonObject = try JSONSerialization.jsonObject(with: schemaData, options: []) as? [String: Any] else {
                throw ToolError.invalidArgumentsData // Or a more specific error
            }

            let functionParameters = LLMFunctionParameter(
                name: tool.name,
                description: tool.description,
                parameters: AnyCodable(jsonObject)
            )
            llmToolDefinitions.append(LLMToolDefinition(function: functionParameters))
        }

        let data = try encoder.encode(llmToolDefinitions)
        return String(data: data, encoding: .utf8)!
    }
}

// MARK: - LLM Tool Manifest Structures (from Exercise 4)

// Example of a minimal LLM tool definition structure
struct LLMFunctionParameter: Codable {
    let name: String
    let description: String
    let parameters: AnyCodable // Use AnyCodable for dynamic JSON schema
}

struct LLMToolDefinition: Codable {
    let type: String = "function"
    let function: LLMFunctionParameter
}

// MARK: - Simulation Helper (for Exercise 3 & 4)

// Placeholder for SmartHomeState for now, will be fully defined in Ex3
class SmartHomeState: CustomStringConvertible {
    var lights: [String: (isOn: Bool, color: String)] = [:]
    var thermostats: [String: (currentTemperature: Double, targetTemperature: Double)] = [:]
    var scenes: [String: [String]] = [:]

    var description: String { return "Smart Home State (not fully initialized yet for Ex1/2)" }
}


func processLLMResponse(toolCallJSON: String, registry: ToolRegistry, smartHomeState: SmartHomeState? = nil) async throws -> String {
    let decoder = JSONDecoder()
    guard let toolCallData = toolCallJSON.data(using: .utf8) else {
        throw ToolError.invalidArgumentsData
    }

    let toolCall: ToolCall
    do {
        toolCall = try decoder.decode(ToolCall.self, from: toolCallData)
    } catch {
        throw ToolError.argumentDecodingFailed(error)
    }

    guard let tool = registry.findTool(byName: toolCall.toolName) else {
        throw ToolError.unknownTool(toolCall.toolName)
    }

    print("\n--- Simulating LLM Call for '\(tool.name)' ---")
    print("Arguments JSON: \(toolCall.arguments)")

    do {
        let result = try await tool.decodeAndExecute(jsonArguments: toolCall.arguments)
        print("Tool execution successful.")
        if let state = smartHomeState {
            print("Current Smart Home State: \(state)")
        }
        return result
    } catch {
        print("Tool execution failed with error: \(error.localizedDescription)")
        throw ToolError.toolExecutionFailed(error)
    }
}

// MARK: - Exercise 1: Basic Arithmetic Tool

// 2.1. Define CalculatorTool Arguments
struct CalculatorArguments: Codable {
    let operand1: Double
    let operand2: Double
    let operation: String // "add", "subtract", "multiply", "divide"
}

// 2.2. Create CalculatorTool
struct CalculatorTool: Tool {
    let name: String = "calculator_tool"
    let description: String = "Performs basic arithmetic operations like addition, subtraction, multiplication, and division."
    let parametersSchema: String = """
    {
        "type": "object",
        "properties": {
            "operand1": {
                "type": "number",
                "description": "The first operand for the calculation."
            },
            "operand2": {
                "type": "number",
                "description": "The second operand for the calculation."
            },
            "operation": {
                "type": "string",
                "enum": ["add", "subtract", "multiply", "divide"],
                "description": "The arithmetic operation to perform."
            }
        },
        "required": ["operand1", "operand2", "operation"]
    }
    """

    typealias Arguments = CalculatorArguments

    func execute(arguments: CalculatorArguments) async throws -> String {
        let result: Double
        switch arguments.operation {
        case "add":
            result = arguments.operand1 + arguments.operand2
        case "subtract":
            result = arguments.operand1 - arguments.operand2
        case "multiply":
            result = arguments.operand1 * arguments.operand2
        case "divide":
            guard arguments.operand2 != 0 else {
                throw ToolError.divisionByZero
            }
            result = arguments.operand1 / arguments.operand2
        default:
            throw ToolError.unknownOperation(arguments.operation)
        }
        return "The result of \(arguments.operand1) \(arguments.operation) \(arguments.operand2) is \(result)."
    }
}

// 3. Simulate LLM Interaction
func runExercise1() async {
    print("--- Running Exercise 1: Basic Arithmetic Tool ---")

    let mockToolCallJSON = """
    {
        "toolName": "calculator_tool",
        "arguments": "{\\"operand1\\": 10.0, \\"operand2\\": 5.0, \\"operation\\": \\"add\\"}"
    }
    """
    let mockToolCallJSONDivideByZero = """
    {
        "toolName": "calculator_tool",
        "arguments": "{\\"operand1\\": 10.0, \\"operand2\\": 0.0, \\"operation\\": \\"divide\\"}"
    }
    """
    let mockToolCallJSONUnknownOp = """
    {
        "toolName": "calculator_tool",
        "arguments": "{\\"operand1\\": 10.0, \\"operand2\\": 2.0, \\"operation\\": \\"power\\"}"
    }
    """

    let registry = ToolRegistry()
    registry.registerTool(CalculatorTool())

    do {
        print("\nScenario 1: Successful Addition")
        let result = try await processLLMResponse(toolCallJSON: mockToolCallJSON, registry: registry)
        print("Final Result: \(result)")
    } catch {
        print("Error in Scenario 1: \(error.localizedDescription)")
    }

    do {
        print("\nScenario 2: Division by Zero Error")
        _ = try await processLLMResponse(toolCallJSON: mockToolCallJSONDivideByZero, registry: registry)
        // This line won't be reached if an error is thrown and caught
    } catch {
        print("Error in Scenario 2: \(error.localizedDescription)")
    }

    do {
        print("\nScenario 3: Unknown Operation Error")
        _ = try await processLLMResponse(toolCallJSON: mockToolCallJSONUnknownOp, registry: registry)
        // This line won't be reached if an error is thrown and caught
    } catch {
        print("Error in Scenario 3: \(error.localizedDescription)")
    }
}
