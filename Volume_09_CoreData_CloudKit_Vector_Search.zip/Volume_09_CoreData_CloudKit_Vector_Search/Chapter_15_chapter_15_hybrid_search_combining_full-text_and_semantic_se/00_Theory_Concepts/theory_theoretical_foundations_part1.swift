
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreML
import Observation

/// Represents a single unit of searchable information.
/// Conforms to Sendable to ensure safe transfer across actor boundaries.
struct SearchResult: Sendable, Identifiable {
    let id: UUID
    let text: String
    let score: Double
    let source: SearchSource
}

enum SearchSource: Sendable {
    case lexical
    case semantic
    case hybrid
}

/// The SearchOrchestrator manages the complex coordination of 
/// lexical and semantic search branches.
@available(iOS 18.0, *)
actor HybridSearchCoordinator {
    
    private let lexicalEngine: LexicalEngine // Wraps Core Data/FTS5
    private let semanticEngine: SemanticEngine // Wraps Core ML/Embeddings
    private let fusionWeight: Double // Alpha for weighted scoring
    
    init(lexicalEngine: LexicalEngine, semanticEngine: SemanticEngine, weight: Double = 0.5) {
        self.lexicalEngine = lexicalEngine
        self.semanticEngine = semanticEngine
        self.fusionWeight = weight
    }
    
    /// Performs a hybrid search using structured concurrency.
    /// This implements the "Fan-out, Fan-in" pattern.
    func search(query: String) async throws -> [SearchResult] {
        // 1. Fan-out: Start both searches in parallel
        async let lexicalResults = lexicalEngine.search(query: query)
        async let semanticResults = semanticEngine.search(query: query)
        
        // 2. Await both branches (Fan-in)
        // This is where the 'Why' of async/await shines: 
        // We don't block the thread while the Neural Engine is working.
        let (lexical, semantic) = try await (lexicalResults, semanticResults)
        
        // 3. Fusion: Combine the disparate results
        return fuse(lexical: lexical, semantic: semantic)
    }
    
    /// Implements Reciprocal Rank Fusion (RRF) or Weighted Scoring.
    private func fuse(lexical: [SearchResult], semantic: [SearchResult]) -> [SearchResult] {
        // In a real implementation, this would apply the RRF formula:
        // Score = 1 / (k + rank)
        // For brevity, we represent the concept of merging the two arrays.
        var combined: [SearchResult] = []
        
        // Logic to merge and re-rank based on the mathematical models 
        // discussed in the theoretical section...
        
        return combined.sorted { $0.score > $1.score }
    }
}

/// The UI layer uses @Observable to react to search updates.
@available(iOS 18.0, *)
@Observable
class SearchViewModel {
    var results: [SearchResult] = []
    var isSearching: Bool = false
    
    private let coordinator: HybridSearchCoordinator
    
    init(coordinator: HybridSearchCoordinator) {
        self.coordinator = coordinator
    }
    
    @MainActor
    func performSearch(text: String) async {
        isSearching = true
        defer { isSearching = false }
        
        do {
            // The call to the actor is non-blocking to the Main Thread.
            self.results = try await coordinator.search(query: text)
        } catch {
            print("Search failed: \(error)")
        }
    }
}
