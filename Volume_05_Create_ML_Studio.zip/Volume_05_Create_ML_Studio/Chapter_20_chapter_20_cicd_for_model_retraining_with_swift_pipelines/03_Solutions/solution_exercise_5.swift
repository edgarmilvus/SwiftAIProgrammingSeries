
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

// --- deploy.swift ---
// To run: swift run deploy v1.1
import Foundation
import CoreML // For MLModel, though not directly loaded in the script, it's the artifact type

@available(macOS 15.0, *) // Using macOS 15.0 for CreateML context, but CoreML is cross-platform
@main
struct DeployScript {
    static func main() async {
        guard CommandLine.arguments.count == 2 else {
            print("Usage: deploy <target_model_version>")
            return
        }
        let targetVersion = CommandLine.arguments[1]
        
        // MARK: - Setup Paths
        let scriptDirectory = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
        let modelRepositoryPath = scriptDirectory.appendingPathComponent("ModelRepository")
        let activeModelsPath = scriptDirectory.appendingPathComponent("ActiveModels")

        let fileManager = FileManager.default
        do {
            // Ensure ActiveModels directory exists
            try fileManager.createDirectory(at: activeModelsPath, withIntermediateDirectories: true, attributes: nil)
            
            let sourceModelURL = modelRepositoryPath.appendingPathComponent(targetVersion).appendingPathComponent("gesture.mlmodel")
            let destinationModelURL = activeModelsPath.appendingPathComponent("gesture.mlmodel")

            // MARK: - Validate Target Model Exists
            guard fileManager.fileExists(atPath: sourceModelURL.path) else {
                print("Error: Model version \(targetVersion) not found in repository at \(sourceModelURL.path).")
                return
            }
            
            // MARK: - Copy Model to ActiveModels
            // Remove old active model if exists before copying new one
            if fileManager.fileExists(atPath: destinationModelURL.path) {
                try fileManager.removeItem(at: destinationModelURL)
                print("Removed old active model from \(destinationModelURL.path).")
            }
            try fileManager.copyItem(at: sourceModelURL, to: destinationModelURL)
            print("Model \(targetVersion) copied to ActiveModels as \(destinationModelURL.path).")

            // MARK: - Update Manifest
            var manifest: ModelManifest
            do {
                manifest = try ManifestManager.loadManifest(from: activeModelsPath)
            } catch {
                // Initialize a new manifest if it doesn't exist or is invalid
                print("Manifest not found or invalid. Initializing new manifest.")
                manifest = ModelManifest(stableModelVersion: "v0.0", availableVersions: [], lastDeploymentTimestamp: Date())
            }
            
            // Discover all available versions in the repository
            let availableVersions = try ManifestManager.discoverAvailableVersions(in: modelRepositoryPath)
            
            manifest.stableModelVersion = targetVersion
            manifest.abTestModelVersion = nil // Clear A/B test on new stable deployment
            manifest.abTestPercentage = 0
            manifest.availableVersions = availableVersions
            manifest.lastDeploymentTimestamp = Date()
            
            try ManifestManager.saveManifest(manifest, to: activeModelsPath)
            print("Manifest updated successfully. Stable model: \(targetVersion).")
            print("Current Manifest:\n\(String(data: try JSONEncoder().encode(manifest), encoding: .utf8) ?? "N/A")")

        } catch {
            print("Deployment failed: \(error.localizedDescription)")
            // Optionally, write a failure manifest
        }
    }
}

// --- configure_ab_test.swift ---
// To run: swift run configure_ab_test v1.2 15
import Foundation

@available(macOS 15.0, *)
@main
struct ConfigureABTestScript {
    static func main() async {
        guard CommandLine.arguments.count == 3,
              let percentage = Int(CommandLine.arguments[2]) else {
            print("Usage: configure_ab_test <ab_test_model_version> <percentage>")
            return
        }
        let abTestVersion = CommandLine.arguments[1]
        
        // MARK: - Setup Paths
        let scriptDirectory = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
        let modelRepositoryPath = scriptDirectory.appendingPathComponent("ModelRepository")
        let activeModelsPath = scriptDirectory.appendingPathComponent("ActiveModels")

        let fileManager = FileManager.default
        do {
            // Load existing manifest
            var manifest = try ManifestManager.loadManifest(from: activeModelsPath)
            
            if percentage > 0 {
                let abTestModelSourceURL = modelRepositoryPath.appendingPathComponent(abTestVersion).appendingPathComponent("gesture.mlmodel")
                // MARK: - Validate A/B Test Model Exists
                guard fileManager.fileExists(atPath: abTestModelSourceURL.path) else {
                    print("Error: A/B test model version \(abTestVersion) not found in repository at \(abTestModelSourceURL.path).")
                    return
                }
                manifest.abTestModelVersion = abTestVersion
                manifest.abTestPercentage = min(max(percentage, 0), 100) // Clamp percentage between 0 and 100
                print("A/B test configured for model \(abTestVersion) with \(manifest.abTestPercentage)% of users.")
            } else {
                manifest.abTestModelVersion = nil
                manifest.abTestPercentage = 0
                print("A/B testing disabled.")
            }
            manifest.lastDeploymentTimestamp = Date()
            
            try ManifestManager.saveManifest(manifest, to: activeModelsPath)
            print("Manifest updated successfully.")
            print("Current Manifest:\n\(String(data: try JSONEncoder().encode(manifest), encoding: .utf8) ?? "N/A")")

        } catch {
            print("A/B test configuration failed: \(error.localizedDescription)")
        }
    }
}

// --- rollback.swift ---
// To run: swift run rollback v1.0
import Foundation

@available(macOS 15.0, *)
@main
struct RollbackScript {
    static func main() async {
        guard CommandLine.arguments.count == 2 else {
            print("Usage: rollback <target_stable_model_version>")
            return
        }
        let targetVersion = CommandLine.arguments[1]
        
        // MARK: - Setup Paths
        let scriptDirectory = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
        let modelRepositoryPath = scriptDirectory.appendingPathComponent("ModelRepository")
        let activeModelsPath = scriptDirectory.appendingPathComponent("ActiveModels")

        let fileManager = FileManager.default
        do {
            // Load existing manifest
            var manifest = try ManifestManager.loadManifest(from: activeModelsPath)
            
            let sourceModelURL = modelRepositoryPath.appendingPathComponent(targetVersion).appendingPathComponent("gesture.mlmodel")
            let destinationModelURL = activeModelsPath.appendingPathComponent("gesture.mlmodel")

            // MARK: - Validate Rollback Target Model Exists
            guard fileManager.fileExists(atPath: sourceModelURL.path) else {
                print("Error: Rollback target model version \(targetVersion) not found in repository at \(sourceModelURL.path).")
                return
            }
            
            // MARK: - Copy Model to ActiveModels
            // Remove old active model if exists
            if fileManager.fileExists(atPath: destinationModelURL.path) {
                try fileManager.removeItem(at: destinationModelURL)
                print("Removed old active model from \(destinationModelURL.path).")
            }
            try fileManager.copyItem(at: sourceModelURL, to: destinationModelURL)
            print("Model rolled back to \(targetVersion) in ActiveModels as \(destinationModelURL.path).")

            // MARK: - Update Manifest
            manifest.stableModelVersion = targetVersion
            manifest.abTestModelVersion = nil // Disable A/B test on rollback
            manifest.abTestPercentage = 0
            manifest.lastDeploymentTimestamp = Date()
            
            try ManifestManager.saveManifest(manifest, to: activeModelsPath)
            print("Manifest updated successfully. Stable model: \(targetVersion). A/B testing disabled.")
            print("Current Manifest:\n\(String(data: try JSONEncoder().encode(manifest), encoding: .utf8) ?? "N/A")")

        } catch {
            print("Rollback failed: \(error.localizedDescription)")
        }
    }
}

// --- App-side Logic (Conceptual Outline) ---
import CoreML
import Foundation // For URL, FileManager, JSONDecoder, Date

@available(iOS 18.0, macOS 15.0, *) // Or other relevant platforms
class GestureRecognizerApp {
    private var currentModel: MLModel?
    private let userID: Int // Simulate a user ID for A/B testing or feature flagging
    private let activeModelsDirectory: URL // Path where the manifest and active model reside

    init(userID: Int) {
        self.userID = userID
        // In a real app, this would point to a downloaded directory or app bundle resource
        self.activeModelsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("ActiveModels")
        
        // Ensure the ModelRepository path is also known for loading specific versions
        // In a real app, models would be downloaded to a cache or fetched from the bundle.
        // For this simulation, we assume ModelRepository is also accessible.
        let scriptDirectory = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
        self.modelRepositoryPath = scriptDirectory.appendingPathComponent("ModelRepository")
        
        loadModel()
    }
    
    // Path to the repository of all model versions (for simulation)
    private let modelRepositoryPath: URL

    /// Loads the appropriate MLModel based on the manifest and user ID.
    private func loadModel() {
        do {
            // 1. Fetch the manifest (simulated as a local file read)
            let manifest = try ManifestManager.loadManifest(from: activeModelsDirectory)

            var modelToLoadVersion: String
            var modelPath: URL
            
            // 2. Determine which model version to load
            if let abTestVersion = manifest.abTestModelVersion, manifest.abTestPercentage > 0 {
                // Simulate A/B test bucketing based on user ID
                if userID % 100 < manifest.abTestPercentage {
                    print("User \(userID) is in A/B test group. Loading model \(abTestVersion).")
                    modelToLoadVersion = abTestVersion
                } else {
                    print("User \(userID) is in stable group. Loading model \(manifest.stableModelVersion).")
                    modelToLoadVersion = manifest.stableModelVersion
                }
            } else {
                print("No A/B test active. Loading stable model \(manifest.stableModelVersion).")
                modelToLoadVersion = manifest.stableModelVersion
            }

            // 3. Construct the path to the chosen model
            // For the app-side, the 'active' model is usually a single 'gesture.mlmodel' in the ActiveModels folder
            // or downloaded to a specific cache location.
            // For this simulation, we'll try to load from the "ActiveModels" directory first,
            // or directly from the "ModelRepository" if we need a specific version not currently 'active'.
            
            let activeModelURL = activeModelsDirectory.appendingPathComponent("gesture.mlmodel")
            let activeModelVersionInManifest = manifest.stableModelVersion // The version currently in ActiveModels
            
            if modelToLoadVersion == activeModelVersionInManifest && FileManager.default.fileExists(atPath: activeModelURL.path) {
                // If the desired model is the one currently "active" and copied, load it
                modelPath = activeModelURL
                print("Loading active model from \(modelPath.path)")
            } else if let abTestVersion = manifest.abTestModelVersion, modelToLoadVersion == abTestVersion {
                // If it's an A/B test model, we'd typically download it or access it from a specific cache.
                // For this simulation, we'll assume it's available in the ModelRepository.
                modelPath = modelRepositoryPath.appendingPathComponent(modelToLoadVersion).appendingPathComponent("gesture.mlmodel")
                print("Loading A/B test model from repository: \(modelPath.path)")
            } else {
                 // Fallback: load the stable model directly from the repository if not found in ActiveModels.
                 // This scenario might occur if 'ActiveModels' only contains the stable model,
                 // but the app wants to load an A/B test model directly.
                modelPath = modelRepositoryPath.appendingPathComponent(modelToLoadVersion).appendingPathComponent("gesture.mlmodel")
                print("Loading stable model from repository (fallback): \(modelPath.path)")
            }

            // 4. Load the MLModel
            self.currentModel = try MLModel(contentsOf: modelPath)
            print("Successfully loaded model version: \(modelToLoadVersion) from \(modelPath.path)")

        } catch {
            print("Error loading model or manifest: \(error.localizedDescription)")
            // In a production app, you would:
            // 1. Log this error to a remote analytics service.
            // 2. Fallback to a default bundled model (if available).
            // 3. Potentially retry fetching the manifest/model.
            self.currentModel = nil // Ensure no stale model is used
        }
    }

    /// Performs gesture recognition using the currently loaded model.
    func performGestureRecognition(input: MLFeatureProvider) -> MLFeatureProvider? {
        guard let model = currentModel else {
            print("Model not loaded. Cannot perform gesture recognition.")
            return nil
        }
        do {
            let prediction = try model.prediction(from: input)
            // Process prediction results
            print("Prediction made using model: \(model.modelDescription.metadata[MLModelMetadataKey.versionString] ?? "Unknown Version")")
            return prediction
        } catch {
            print("Error during prediction: \(error.localizedDescription)")
            return nil
        }
    }
    
    // Example of how to trigger a reload (e.g., after a remote manifest update)
    func refreshModel() {
        print("Refreshing model configuration...")
        loadModel()
    }
}

/*
// --- How to set up for testing (Manual steps) ---
// 1. Create the base directory (e.g., 'ModelManagementSystem')
// 2. Inside it, create 'ModelRepository' and 'ActiveModels' directories.
// 3. Populate 'ModelRepository' with dummy .mlmodel files:
//    ModelRepository/
//    ├── v1.0/
//    │   └── gesture.mlmodel (e.g., a dummy MLActionClassifier)
//    ├── v1.1/
//    │   └── gesture.mlmodel
//    └── v1.2/
//        └── gesture.mlmodel
//
// You can create dummy .mlmodel files using Create ML for an MLActionClassifier
// or simply copy any .mlmodel file and rename it.
//
// Then, compile and run the scripts:
// swift build
//
// // Initial deployment
// ./.build/debug/deploy v1.0
//
// // Configure A/B test
// ./.build/debug/configure_ab_test v1.1 20
//
// // Deploy a new stable version (will clear A/B test)
// ./.build/debug/deploy v1.2
//
// // Rollback
// ./.build/debug/rollback v1.0
//
// // Test app-side logic (conceptual, but you can simulate by creating a manifest.json
// // in ActiveModels and running the GestureRecognizerApp init)
// let app = GestureRecognizerApp(userID: 5) // Should get stable model
// let appAB = GestureRecognizerApp(userID: 15) // Might get A/B test model if configured
*/
