
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftData
import Foundation

/// @available(iOS 17.0, *) is required as SwiftData was introduced in iOS 17.
@available(iOS 17.0, *)
@Model
final class TaskCategory {
    @Attribute(.unique) var name: String
    
    // Relationship: One-to-Many. 
    // If a category is deleted, all associated tasks are also deleted (cascade).
    @Relationship(deleteRule: .cascade, inverse: \TaskItem.category)
    var tasks: [TaskItem] = []
    
    init(name: String) {
        self.name = name
    }
}

@available(iOS 17.0, *)
@Model
final class TaskItem {
    // Non-optional property requirement
    var title: String
    var dueDate: Date
    
    // Default value requirement
    var isCompleted: Bool = false
    
    // Relationship to the category
    var category: TaskCategory?
    
    init(title: String, dueDate: Date, isCompleted: Bool = false, category: TaskCategory? = nil) {
        self.title = title
        self.dueDate = dueDate
        self.isCompleted = isCompleted
        self.category = category
    }
    
    /*
     NOTE ON THE @MODEL MACRO:
     The @Model macro is a powerful Swift compiler tool. When applied to this class, 
     it performs several critical transformations:
     1. It makes the class conform to the `PersistentModel` protocol.
     2. It injects 'backing data' storage, allowing properties to be mapped to 
        the underlying SQLite store without manual boilerplate.
     3. It implements the observation logic required for SwiftUI to react to 
        changes automatically, replacing the older KVO/NSManagedObject mechanism.
     4. It handles the 'identity' of the object, ensuring that SwiftData can 
        uniquely track this instance across different ModelContexts.
     */
}
