
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Foundation // For UUID, URL

// A simplified version of DatasetItem for UI display
@Observable
class ObservableDatasetItem: Identifiable {
    let id: UUID
    let originalDataURL: URL
    var label: String?

    init(item: DatasetItem) {
        self.id = item.id
        self.originalDataURL = item.originalDataURL
        self.label = item.label
    }
}

@available(iOS 17.0, *)
@Observable
class AnnotationViewModel {
    private let annotationManager: AnnotationManager // Interact with the actor
    var observableItems: [ObservableDatasetItem] = []
    var currentCategories: [String] = []
    var summary: String = "Loading..."

    init(manager: AnnotationManager) {
        self.annotationManager = manager
    }

    @MainActor // UI updates must happen on the main actor
    func loadItems() async {
        // In a real app, you'd fetch items from the actor
        // For this example, we'll simulate it.
        let sampleItems = [
            DatasetItem(originalDataURL: URL(string: "file:///img1.jpg")!, label: "cat"),
            DatasetItem(originalDataURL: URL(string: "file:///img2.jpg")!, label: "dog"),
            DatasetItem(originalDataURL: URL(string: "file:///img3.jpg")!) // Unlabeled
        ]
        for item in sampleItems {
            await annotationManager.addItem(item)
        }

        await updateUI()
    }

    @MainActor
    func updateUI() async {
        // Fetch data from the actor
        let allItems = await annotationManager.getUnannotatedItems() // Simplified, fetch all for display
        self.observableItems = allItems.map { ObservableDatasetItem(item: $0) }
        self.currentCategories = await annotationManager.getCategories()
        self.summary = await annotationManager.getDatasetSummary()
    }

    @MainActor
    func applyLabel(to item: ObservableDatasetItem, label: String) async {
        if await annotationManager.updateLabel(for: item.id, newLabel: label) {
            item.label = label // Update observable item directly for immediate UI feedback
            await updateUI() // Re-fetch summary and categories from actor
        }
    }
}

@available(iOS 17.0, *)
struct AnnotationView: View {
    @State private var viewModel: AnnotationViewModel

    init(annotationManager: AnnotationManager) {
        _viewModel = State(initialValue: AnnotationViewModel(manager: annotationManager))
    }

    var body: some View {
        NavigationView {
            List {
                Section("Dataset Summary") {
                    Text(viewModel.summary)
                }
                Section("Categories") {
                    ForEach(viewModel.currentCategories, id: \.self) { category in
                        Text(category)
                    }
                }
                Section("Items to Annotate") {
                    ForEach(viewModel.observableItems) { item in
                        HStack {
                            Text(item.originalDataURL.lastPathComponent)
                            Spacer()
                            if let label = item.label {
                                Text(label)
                                    .foregroundColor(.green)
                            } else {
                                Button("Label") {
                                    // Simulate labeling, in a real app this would open a sheet
                                    Task { @MainActor in
                                        await viewModel.applyLabel(to: item, label: "new_label_\(Int.random(in: 1...10))")
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Dataset Annotation")
            .task {
                await viewModel.loadItems()
            }
        }
    }
}
