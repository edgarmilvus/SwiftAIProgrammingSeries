
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

// @available(iOS 17.0, macOS 14.0, watchOS 10.0, tvOS 17.0, *)
@Observable
class AgentViewModel { // Use a ViewModel to expose agent state for UI
    private let agent: Agent // The actual actor instance
    var currentThought: String = "Idle"
    var conversationHistory: [Message] = []
    var isLoading: Bool = false

    init(agent: Agent) {
        self.agent = agent
    }

    func sendMessage(_ text: String) async {
        isLoading = true
        currentThought = "Thinking..."
        do {
            // Call the actor method to process the message
            let response = try await agent.processMessage(text)
            currentThought = "Response: \(response)"
            // Update local history from actor's history (if agent actor provides a method for it)
            // For simplicity, we'll just append the response here.
            // In a real app, you'd have a way to fetch the full history from the actor.
            await MainActor.run {
                self.conversationHistory.append(Message(role: .user, content: text))
                self.conversationHistory.append(Message(role: .assistant, content: response))
            }
        } catch {
            currentThought = "Error: \(error.localizedDescription)"
        }
        isLoading = false
    }
}
