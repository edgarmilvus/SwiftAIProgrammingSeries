
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

// MARK: - 4. Tool Executor

@available(macOS 15.0, *)
actor ToolExecutor {
    /// A JSON decoder instance for decoding tool arguments.
    private let jsonDecoder = JSONDecoder()

    /// Represents the current state of smart home devices (simulated).
    private var deviceStates: [String: [String: Any]] = [
        "living_room": ["light_color": "white", "light_brightness": 100, "temperature": 22.5, "music_playing": false],
        "bedroom": ["light_color": "white", "light_brightness": 80, "temperature": 20.0, "music_playing": false],
    ]

    /// Executes a given function call, dynamically decoding its arguments.
    /// - Parameter functionCall: The generic `FunctionCall` object from the LLM.
    /// - Returns: A string representing the result of the tool execution.
    /// - Throws: `SmartHomeError` if the tool is not found, arguments are invalid, or execution fails.
    func executeTool(functionCall: SmartHomeTools.FunctionCall) async throws -> String {
        print("Executing tool: \(functionCall.name) with arguments: \(functionCall.arguments)")
        // Simulate network/device interaction delay
        try await Task.sleep(for: .seconds(0.5))

        switch functionCall.name {
        case "SetLightColorTool":
            let args = try decodeArguments(functionCall.arguments, as: SmartHomeTools.SetLightColorArgs.self)
            return try await setLightColor(room: args.room, color: args.color)
        case "SetLightBrightnessTool":
            let args = try decodeArguments(functionCall.arguments, as: SmartHomeTools.SetLightBrightnessArgs.self)
            return try await setLightBrightness(room: args.room, brightness: args.brightness)
        case "GetRoomTemperatureTool":
            let args = try decodeArguments(functionCall.arguments, as: SmartHomeTools.GetRoomTemperatureArgs.self)
            return try await getRoomTemperature(room: args.room)
        case "SetThermostatTemperatureTool":
            let args = try decodeArguments(functionCall.arguments, as: SmartHomeTools.SetThermostatTemperatureArgs.self)
            return try await setThermostatTemperature(room: args.room, temperature: args.temperature)
        case "PlayMusicTool":
            let args = try decodeArguments(functionCall.arguments, as: SmartHomeTools.PlayMusicArgs.self)
            return try await playMusic(room: args.room, songTitle: args.songTitle, artist: args.artist, genre: args.genre)
        default:
            throw SmartHomeError.toolNotFound(functionCall.name)
        }
    }

    /// Helper to decode raw JSON arguments into a specific Codable type.
    private func decodeArguments<T: Codable>(_ arguments: String, as type: T.Type) throws -> T {
        guard let data = arguments.data(using: .utf8) else {
            throw SmartHomeError.invalidToolArguments(
                toolName: String(describing: type),
                decodingError: NSError(domain: "SmartHomeError", code: 0, userInfo: [NSLocalizedDescriptionKey: "Invalid argument JSON string."])
            )
        }
        do {
            return try jsonDecoder.decode(type, from: data)
        } catch {
            throw SmartHomeError.invalidToolArguments(toolName: String(describing: type), decodingError: error)
        }
    }

    // MARK: - Simulated Smart Home Device Functions

    private func setLightColor(room: String, color: String) async throws -> String {
        guard deviceStates[room] != nil else { throw SmartHomeError.toolExecutionFailed(toolName: "SetLightColorTool", message: "Room '\(room)' not found.") }
        deviceStates[room]?["light_color"] = color
        print("Set \(room) light color to \(color).")
        return "Successfully set \(room) light color to \(color)."
    }

    private func setLightBrightness(room: String, brightness: Int) async throws -> String {
        guard deviceStates[room] != nil else { throw SmartHomeError.toolExecutionFailed(toolName: "SetLightBrightnessTool", message: "Room '\(room)' not found.") }
        guard (0...100).contains(brightness) else { throw SmartHomeError.toolExecutionFailed(toolName: "SetLightBrightnessTool", message: "Brightness must be between 0 and 100.") }
        deviceStates[room]?["light_brightness"] = brightness
        print("Set \(room) light brightness to \(brightness)%.")
        return "Successfully set \(room) light brightness to \(brightness)%."
    }

    private func getRoomTemperature(room: String) async throws -> String {
        guard let temperature = deviceStates[room]?["temperature"] as? Double else { throw SmartHomeError.toolExecutionFailed(toolName: "GetRoomTemperatureTool", message: "Temperature data not available for room '\(room)'.") }
        print("Current temperature in \(room) is \(temperature)°C.")
        return "The current temperature in \(room) is \(temperature)°C."
    }

    private func setThermostatTemperature(room: String, temperature: Double) async throws -> String {
        guard deviceStates[room] != nil else { throw SmartHomeError.toolExecutionFailed(toolName: "SetThermostatTemperatureTool", message: "Room '\(room)' not found.") }
        deviceStates[room]?["temperature"] = temperature
        print("Set \(room) thermostat to \(temperature)°C.")
        return "Successfully set \(room) thermostat to \(temperature)°C."
    }
    
    private func playMusic(room: String, songTitle: String?, artist: String?, genre: String?) async throws -> String {
        guard deviceStates[room] != nil else { throw SmartHomeError.toolExecutionFailed(toolName: "PlayMusicTool", message: "Room '\(room)' not found.") }
        deviceStates[room]?["music_playing"] = true
        var message = "Playing music in \(room)."
        if let song = songTitle { message += " Song: \(song)." }
        if let art = artist { message += " Artist: \(art)." }
        if let gen = genre { message += " Genre: \(gen)." }
        print(message)
        return "Successfully executed: \(message)"
    }
}
