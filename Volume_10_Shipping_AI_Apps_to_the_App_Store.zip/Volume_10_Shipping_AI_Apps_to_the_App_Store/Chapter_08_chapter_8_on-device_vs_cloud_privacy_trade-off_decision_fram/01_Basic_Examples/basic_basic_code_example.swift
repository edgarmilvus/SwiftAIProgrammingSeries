
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import UIKit
import Vision
import CoreML
import Combine

// MARK: - Models & Protocols

/// Represents the outcome of an AI processing task.
/// Conforms to `Sendable` to ensure it can safely cross actor boundaries in Swift 6.
struct ProcessingResult: Sendable, Equatable {
    let detectedObjects: [String]
    let confidence: Float
    let processingMethod: ProcessingMethod
    let timestamp: Date
}

/// Defines the method used to process the data, critical for privacy auditing.
enum ProcessingMethod: String, Sendable {
    case onDevice = "On-Device (Local)"
    case cloud = "Cloud (Remote)"
}

/// The privacy policy determines the architectural path.
enum PrivacyPolicy: Sendable {
    case strict // Always use On-Device
    case balanced // Use Cloud only if On-Device fails or for high-precision needs
}

/// A common interface for any AI processing engine.
/// Using `Sendable` ensures that implementations can be used across different concurrency domains.
protocol ImageProcessor: Sendable {
    /// Processes an image and returns a result.
    /// - Parameter image: The input image to analyze.
    /// - Returns: A `ProcessingResult` containing detected entities.
    func process(image: UIImage) async throws -> ProcessingResult
}

// MARK: - Errors

enum PrivacyGuardError: Error, LocalizedError {
    case processingFailed(String)
    case networkError(Error)
    case modelNotLoaded
    
    var errorDescription: String? {
        switch self {
        case .processingFailed(let msg): return "AI Processing failed: \(msg)"
        case .networkError(let err): return "Cloud connectivity issue: \(err.localizedDescription)"
        case .modelNotLoaded: return "The ML model failed to initialize."
        }
    }
}

// MARK: - Implementations

/// An implementation of `ImageProcessor` that runs entirely on the device.
/// It utilizes the Apple Vision framework to tap into the Neural Engine.
final class OnDeviceProcessor: ImageProcessor {
    
    /// The Vision request handler. In a real app, this would wrap a CoreML model.
    /// We mark this as `nonisolated` or ensure it's handled within the async context.
    func process(image: UIImage) async throws -> ProcessingResult {
        // Simulate heavy local computation (e.g., running a YOLO or MobileNet model)
        // In a real app, you would use: try await VNImageRequestHandler(cvPixelBuffer: ...).perform([request])
        try await Task.sleep(for: .seconds(1.5)) 
        
        // Mock detection logic
        let detected = ["Face", "Credit Card", "Document"]
        
        return ProcessingResult(
            detectedObjects: detected,
            confidence: 0.98,
            processingMethod: .onDevice,
            timestamp: Date()
        )
    }
}

/// An implementation of `ImageProcessor` that offloads data to a remote server.
/// This provides higher accuracy but requires network access and compromises privacy.
final class CloudProcessor: ImageProcessor {
    private let apiEndpoint = URL(string: "https://api.ai-vision-service.com/analyze")!
    
    func process(image: UIImage) async throws -> ProcessingResult {
        // Convert image to Data for transmission
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            throw PrivacyGuardError.processingFailed("Could not encode image.")
        }
        
        // Construct the request
        var request = URLRequest(url: apiEndpoint)
        request.httpMethod = "POST"
        request.setValue("image/jpeg", forHTTPHeaderField: "Content-Type")
        
        // In a real implementation, we would use URLSession to upload.
        // For this example, we simulate the network latency and response.
        do {
            try await Task.sleep(for: .seconds(2.5)) // Simulate network round-trip
            
            // Mocking a successful cloud response
            return ProcessingResult(
                detectedObjects: ["Sensitive Document (High Precision)"],
                confidence: 0.99,
                processingMethod: .cloud,
                timestamp: Date()
            )
        } catch {
            throw PrivacyGuardError.networkError(error)
        }
    }
}

// MARK: - The Coordinator (The Brain)

/// The `PrivacyCoordinator` is an `actor`. 
/// This is crucial because it manages the state of the `PrivacyPolicy` and 
/// ensures that multiple concurrent requests don't cause race conditions 
/// when deciding which processor to use.
actor PrivacyCoordinator {
    
    private let onDeviceProcessor: OnDeviceProcessor
    private let cloudProcessor: CloudProcessor
    private var currentPolicy: PrivacyPolicy
    
    init(policy: PrivacyPolicy) {
        self.onDeviceProcessor = OnDeviceProcessor()
        self.cloudProcessor = CloudProcessor()
        self.currentPolicy = policy
    }
    
    /// Allows updating the policy dynamically (e.g., from a User Settings toggle).
    func updatePolicy(_ newPolicy: PrivacyPolicy) {
        self.currentPolicy = newPolicy
    }
    
    /// The core decision-making logic.
    /// This function implements the "Trade-off Decision Framework".
    func analyze(image: UIImage) async throws -> ProcessingResult {
        switch currentPolicy {
        case .strict:
            // Under 'Strict' policy, we NEVER leave the device.
            return try await onDeviceProcessor.process(image: image)
            
        case .balanced:
            // Under 'Balanced', we try local first. If the local model 
            // reports low confidence, we escalate to the cloud.
            let localResult = try await onDeviceProcessor.process(image: image)
            
            if localResult.confidence < 0.90 {
                print("Low confidence (\(localResult.confidence)). Escalating to Cloud...")
                return try await cloudProcessor.process(image: image)
            } else {
                return localResult
            }
        }
    }
}

// MARK: - UI Layer (The Consumer)

/// The ViewModel manages the UI state.
/// It is marked with `@MainActor` to ensure all property updates 
/// happen on the main thread, preventing UI glitches or crashes.
@MainActor
class PrivacyGuardViewModel: ObservableObject {
    
    @Published private(set) var results: [ProcessingResult] = []
    @Published private(set) var isProcessing = false
    @Published var errorMessage: String?
    
    // The coordinator is an actor, so we must access it via 'await'
    private let coordinator: PrivacyCoordinator
    
    init(coordinator: PrivacyCoordinator) {
        self.coordinator = coordinator
    }
    
    /// Triggered by a button press in the UI.
    func handleImageSelection(image: UIImage) {
        isProcessing = true
        errorMessage = nil
        
        // We create a new Task to enter an asynchronous context from a synchronous UI action.
        Task {
            do {
                // The 'await' here is mandatory because coordinator is an actor.
                let result = try await coordinator.analyze(image: image)
                
                // Updating @Published properties is safe because this Task 
                // inherits the @MainActor context from the class.
                self.results.append(result)
                self.isProcessing = false
            } catch {
                self.errorMessage = error.localizedDescription
                self.isProcessing = false
            }
        }
    }
    
    func updatePrivacySetting(to policy: PrivacyPolicy) {
        Task {
            await coordinator.updatePolicy(policy)
        }
    }
}

// MARK: - Simulation / Entry Point

@available(iOS 18.0, *)
struct PrivacyGuardApp {
    static func runSimulation() async {
        print("🚀 Starting PrivacyGuard AI Simulation...")
        
        // 1. Initialize the Coordinator with a 'Strict' policy (Maximum Privacy)
        let coordinator = PrivacyCoordinator(policy: .strict)
        
        // 2. Initialize the ViewModel (MainActor context)
        let viewModel = await PrivacyGuardViewModel(coordinator: coordinator)
        
        // 3. Create a dummy image
        let dummyImage = UIImage() 
        
        // 4. Simulate 'Strict' processing
        print("\n--- Scenario 1: Strict Policy (On-Device Only) ---")
        await viewModel.handleImageSelection(image: dummyImage)
        
        // Wait for processing to finish (simulated)
        try? await Task.sleep(for: .seconds(3))
        
        // 5. Simulate 'Balanced' processing (Escalation)
        print("\n--- Scenario 2: Balanced Policy (Potential Cloud Escalation) ---")
        await viewModel.updatePrivacySetting(to: .balanced)
        await viewModel.handleImageSelection(image: dummyImage)
        
        try? await Task.sleep(for: .seconds(4))
        
        print("\n✅ Simulation Complete.")
    }
}
