
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CreateML
import Observation // Import the Observation framework

@available(iOS 17.0, macOS 14.0, tvOS 17.0, watchOS 10.0, *)
@Observable
class TrainingViewModel {
    enum DataProcessingState {
        case idle
        case loading
        case transforming
        case readyForTraining(MLDataTable)
        case error(Error)
    }

    var state: DataProcessingState = .idle
    var progress: Double = 0.0
    var message: String = "Waiting for data..."

    private let dataPipeline = DataProcessingActor.shared // Access the actor

    func startDataPreparation(csvURL: URL) async {
        state = .loading
        progress = 0.1
        message = "Loading raw data..."

        do {
            await dataPipeline.loadData(from: csvURL)
            progress = 0.5
            message = "Applying transformations..."

            await dataPipeline.applyTransformation()
            progress = 0.9
            message = "Data ready for training!"

            if let finalTable = await dataPipeline.getDataTable() {
                state = .readyForTraining(finalTable)
            } else {
                throw NSError(domain: "TrainingViewModel", code: 2, userInfo: [NSLocalizedDescriptionKey: "No data table after processing."])
            }
            progress = 1.0

        } catch {
            state = .error(error)
            message = "Error: \(error.localizedDescription)"
            progress = 0.0
        }
    }
}

// Example SwiftUI usage (conceptual, not full UI code):
/*
import SwiftUI

@available(iOS 17.0, macOS 14.0, tvOS 17.0, watchOS 10.0, *)
struct TrainingView: View {
    @State private var viewModel = TrainingViewModel()
    @State private var csvURL: URL? // Assume this is populated

    var body: some View {
        VStack {
            Text(viewModel.message)
            ProgressView(value: viewModel.progress)

            switch viewModel.state {
            case .idle:
                Button("Start Data Prep") {
                    if let url = csvURL {
                        Task { await viewModel.startDataPreparation(csvURL: url) }
                    }
                }
            case .loading, .transforming:
                ProgressView()
            case .readyForTraining(let dataTable):
                Text("Data loaded and ready with \(dataTable.rows.count) rows.")
                // Display options to start training
            case .error(let error):
                Text("An error occurred: \(error.localizedDescription)")
                    .foregroundColor(.red)
            }
        }
    }
}
*/
