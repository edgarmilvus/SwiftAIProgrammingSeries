
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import NaturalLanguage // Required for NLModel

@available(iOS 18.0, *) // Conforming to the provided example's availability
class ModerationViewController: UIViewController, UITextViewDelegate {

    // MARK: - UI Elements
    @IBOutlet weak var commentTextView: UITextView!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var statusIndicatorView: UIView! // Visual indicator

    // MARK: - Model Instance
    private var moderationModel: NLModel?

    // MARK: - Debouncing Properties
    private var workItem: DispatchWorkItem?
    private let debounceDelay: TimeInterval = 0.7 // 0.7 seconds delay

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadModerationModel()
    }

    // MARK: - UI Setup
    private func setupUI() {
        commentTextView.delegate = self
        commentTextView.layer.borderColor = UIColor.lightGray.cgColor
        commentTextView.layer.borderWidth = 1.0
        commentTextView.layer.cornerRadius = 5.0
        commentTextView.text = "Type your comment here..."
        commentTextView.textColor = .lightGray
        
        statusLabel.text = "Status: Initializing..."
        statusLabel.font = UIFont.preferredFont(forTextStyle: .subheadline)
        statusLabel.adjustsFontForContentSizeCategory = true
        
        statusIndicatorView.layer.cornerRadius = 8.0 // Make it a circle or rounded rectangle
        statusIndicatorView.backgroundColor = .systemGray.withAlphaComponent(0.2)
    }

    // MARK: - Model Loading
    private func loadModerationModel() {
        guard let modelURL = Bundle.main.url(forResource: "ModerationClassifier", withExtension: "mlmodelc") else {
            statusLabel.text = "Error: ModerationClassifier.mlmodelc not found."
            statusIndicatorView.backgroundColor = .systemRed
            print("Error: ModerationClassifier.mlmodelc not found in app bundle.")
            return
        }

        do {
            moderationModel = try NLModel(contentsOf: modelURL)
            statusLabel.text = "Status: Model loaded. Type to moderate."
            statusIndicatorView.backgroundColor = .systemGreen.withAlphaComponent(0.2)
            print("ModerationClassifier loaded successfully.")
        } catch {
            statusLabel.text = "Status: Error loading model."
            statusIndicatorView.backgroundColor = .systemRed
            print("Error loading moderation model: \(error.localizedDescription)")
        }
    }

    // MARK: - UITextViewDelegate for Real-time Moderation with Debouncing
    func textViewDidChange(_ textView: UITextView) {
        // Clear previous status if user starts typing after an error or placeholder
        if statusLabel.textColor != .label {
            statusLabel.textColor = .label
        }

        // Cancel the previous work item if it exists
        workItem?.cancel()

        // Get the current text, ensuring it's not the placeholder
        let currentText = textView.text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !currentText.isEmpty, currentText != "Type your comment here..." else {
            statusLabel.text = "Status: Type to moderate..."
            statusIndicatorView.backgroundColor = .systemGray.withAlphaComponent(0.2)
            return
        }

        // Create a new work item for classification
        let newWorkItem = DispatchWorkItem { [weak self] in
            guard let self = self, let model = self.moderationModel else {
                DispatchQueue.main.async {
                    self?.statusLabel.text = "Status: Model not ready."
                    self?.statusIndicatorView.backgroundColor = .systemRed.withAlphaComponent(0.2)
                }
                return
            }
            
            // Perform the classification on the current text
            if let predictedLabel = model.predictedLabel(for: currentText) {
                // Update UI on the main queue
                DispatchQueue.main.async {
                    self.statusLabel.text = "Status: \(predictedLabel)"
                    switch predictedLabel {
                    case "Clean":
                        self.statusIndicatorView.backgroundColor = .systemGreen.withAlphaComponent(0.6)
                    case "Spam":
                        self.statusIndicatorView.backgroundColor = .systemYellow.withAlphaComponent(0.6)
                    case "Offensive":
                        self.statusIndicatorView.backgroundColor = .systemRed.withAlphaComponent(0.6)
                    default:
                        self.statusIndicatorView.backgroundColor = .systemGray.withAlphaComponent(0.6)
                    }
                }
            } else {
                DispatchQueue.main.async {
                    self.statusLabel.text = "Status: Could not classify."
                    self.statusIndicatorView.backgroundColor = .systemGray.withAlphaComponent(0.2)
                }
            }
        }

        // Store the new work item
        workItem = newWorkItem

        // Schedule the work item to execute after a delay
        DispatchQueue.main.asyncAfter(deadline: .now() + debounceDelay, execute: newWorkItem)
    }

    // MARK: - UITextViewDelegate for Placeholder behavior
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == .lightGray {
            textView.text = nil
            textView.textColor = .label
        }
    }

    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Type your comment here..."
            textView.textColor = .lightGray
            // Reset status when placeholder is active
            statusLabel.text = "Status: Type to moderate."
            statusIndicatorView.backgroundColor = .systemGray.withAlphaComponent(0.2)
        }
    }
}
