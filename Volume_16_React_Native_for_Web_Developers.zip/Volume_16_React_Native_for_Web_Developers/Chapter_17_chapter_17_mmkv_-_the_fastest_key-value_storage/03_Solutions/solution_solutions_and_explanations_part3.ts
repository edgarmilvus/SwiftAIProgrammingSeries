/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// lib/storage.ts
import { MMKV } from 'react-native-mmkv';

// In a production app, this key should be generated securely and stored 
// in the device's Keychain (iOS) or Keystore (Android).
// For this exercise, we simulate retrieving it.
const getEncryptionKey = (): string | undefined => {
  // SIMULATION: Hardcoded for demonstration.
  // Real implementation: Use 'react-native-keychain' or similar.
  return 'super-secure-encryption-key-12345'; 
};

export const storage = new MMKV({
  id: 'user-storage',
  encryptionKey: getEncryptionKey(),
});

// utils/profileManager.ts
export interface UserProfile {
  id: string;
  preferences: {
    notifications: boolean;
  };
  metadata: {
    lastLogin: number;
  };
  token?: string;
}

const PROFILE_KEY = 'user_profile';

export const saveUserProfile = (profile: UserProfile): void => {
  try {
    const jsonString = JSON.stringify(profile);
    storage.set(PROFILE_KEY, jsonString);
  } catch (error) {
    console.error('Failed to serialize user profile:', error);
  }
};

export const getUserProfile = (): UserProfile | null => {
  try {
    const jsonString = storage.getString(PROFILE_KEY);
    if (!jsonString) return null;
    
    const parsed = JSON.parse(jsonString) as UserProfile;
    return parsed;
  } catch (error) {
    // If encryption key is wrong or data is corrupted/tampered, 
    // MMKV might throw an error or return garbage.
    console.error('Failed to parse user profile or decryption failed:', error);
    return null;
  }
};
