
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Accelerate
import OSLog

// MARK: - Package Dependencies (Conceptual)
/*
 [Package.swift]
 dependencies: [
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
 ]
*/

/// Errors specific to Semantic Search operations.
enum SemanticError: Error, LocalizedError {
    case dimensionMismatch(expected: Int, actual: Int)
    case emptyIndex
    case indexCorrupted
    case vectorNormalizationFailed

    var errorDescription: String? {
        switch self {
        case .dimensionMismatch(let e, let a): return "Vector dimension mismatch. Expected \(e), got \(a)."
        case .emptyIndex: return "The semantic index is currently empty."
        case .indexCorrupted: return "The HNSW graph structure has become inconsistent."
        case .vectorNormalizationFailed: return "Failed to normalize the input vector."
        }
    }
}

/// Represents a single point in high-dimensional space.
/// Conforms to Sendable to ensure safe transfer across actor boundaries.
struct SemanticVector: Sendable, Identifiable {
    let id: UUID
    let values: [Float]
    let metadata: [String: String]
    
    /// The dimensionality of the vector.
    var dimension: Int { values.count }
    
    init(id: UUID = UUID(), values: [Float], metadata: [String: String] = [:]) {
        self.id = id
        self.values = values
        self.metadata = metadata
    }
}

/// A node within the HNSW graph.
/// Using a class because nodes are shared via multiple edges in the graph.
final class HNSWNode: @unchecked Sendable {
    let vector: SemanticVector
    /// Adjacency list: connections to other nodes at various layers.
    /// index 0 is the bottom layer, index 1 is the layer above, etc.
    var connections: [[HNSWNode]]
    
    init(vector: SemanticVector, maxLayers: Int) {
        self.vector = vector
        self.connections = Array(repeating: [], count: maxLayers)
    }
}

/// The core Semantic Memory Engine.
/// Implemented as an `actor` to provide thread-safe access to the graph structure
/// in a highly concurrent environment (e.g., background indexing while querying).
@available(iOS 18.0, *)
actor SemanticMemoryEngine {
    private let logger = Logger(subsystem: "com.echomind.ai", category: "SemanticEngine")
    
    // Configuration parameters
    private let dimension: Int
    private let maxLayers: Int
    private let m: Int // Max number of connections per node
    private let efConstruction: Int // Search depth during construction
    
    // The Graph
    private var entryPoint: HNSWNode?
    private var currentMaxLayer: Int = -1
    private var allNodes: [UUID: HNSWNode] = [:]
    
    /// Initializes a new Semantic Engine.
    /// - Parameters:
    ///   - dimension: The fixed dimensionality of all input vectors.
    ///   - m: Maximum number of connections per node (affects memory/speed trade-off).
    ///   - efConstruction: Controls accuracy vs. build speed.
    init(dimension: Int, m: Int = 16, efConstruction: Int = 200) {
        self.dimension = dimension
        self.m = m
        self.efConstruction = efConstruction
        self.maxLayers = 16 // Sufficient for millions of vectors
    }
    
    // MARK: - Public API
    
    /// Inserts a new vector into the semantic index.
    /// - Parameter vector: The semantic vector to be indexed.
    /// - Throws: `SemanticError.dimensionMismatch` if dimensions don't match.
    func insert(_ vector: SemanticVector) throws {
        guard vector.dimension == dimension else {
            throw SemanticError.dimensionMismatch(expected: dimension, actual: vector.dimension)
        }
        
        // 1. Determine the layer for this node using a probabilistic approach
        let targetLayer = calculateTargetLayer()
        let newNode = HNSWNode(vector: vector, maxLayers: maxLayers)
        allNodes[vector.id] = newNode
        
        // 2. If it's the first node, initialize the entry point
        guard let currentEntryPoint = entryPoint else {
            self.entryPoint = newNode
            self.currentMaxLayer = targetLayer
            return
        }
        
        // 3. Perform a greedy search from the top layer down to the targetLayer
        var currNode = currentEntryPoint
        for layer in (targetLayer + 1...currentMaxLayer).reversed() {
            currNode = findNearestInLayer(to: vector, in: currNode, atLayer: layer)
        }
        
        // 4. Insert the node into layers from targetLayer down to 0
        for layer in (0...targetLayer).reversed() {
            // In a real implementation, we would perform a more complex 
            // 'efConstruction' search here to find the M nearest neighbors
            // and establish bidirectional links.
            linkNode(newNode, to: currNode, atLayer: layer)
            if layer <= currentMaxLayer {
                currNode = findNearestInLayer(to: vector, in: currNode, atLayer: layer)
            }
        }
        
        // 5. Update entry point if this node is in a higher layer
        if targetLayer > currentMaxLayer {
            self.entryPoint = newNode
            self.currentMaxLayer = targetLayer
        }
        
        logger.info("Successfully indexed vector \(vector.id) at layer \(targetLayer)")
    }
    
    /// Performs an Approximate Nearest Neighbor search.
    /// - Parameter query: The vector representing the user's query.
    /// - Parameter k: The number of neighbors to return.
    /// - Returns: An array of the most semantically similar vectors.
    func search(query: SemanticVector, k: Int) async throws -> [SemanticVector] {
        guard let entry = entryPoint else {
            throw SemanticError.emptyIndex
        }
        
        guard query.dimension == dimension else {
            throw SemanticError.dimensionMismatch(expected: dimension, actual: query.dimension)
        }
        
        // 1. Start at the top layer
        var currNode = entry
        for layer in (1...currentMaxLayer).reversed() {
            currNode = findNearestInLayer(to: query, in: currNode, atLayer: layer)
        }
        
        // 2. Search the bottom layer (Layer 0) with a wider search radius (efSearch)
        let results = searchInLayer(query: query, startNode: currNode, atLayer: 0, count: k)
        
        return results.map { $0.vector }
    }
    
    // MARK: - Private Logic (The "Under the Hood" mechanics)
    
    /// Calculates similarity using Accelerate/vDSP.
    /// This is the performance-critical bottleneck.
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        // In a production environment, we assume vectors are pre-normalized.
        // If not, we would use vDSP_sve (sum of squares) and vDSP_vdiv.
        var dotProduct: Float = 0
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        return dotProduct
    }
    
    /// Probabilistic layer selection based on an exponential distribution.
    private func calculateTargetLayer() -> Int {
        let levelFactor = 1.0 / log(Double(m))
        let randomVal = Double.random(in: 0...1)
        let layer = Int(-log(randomVal) * levelFactor)
        return min(layer, maxLayers - 1)
    }
    
    /// Greedy search within a specific layer.
    private func findNearestInLayer(to query: SemanticVector, in startNode: HNSWNode, atLayer: Int) -> HNSWNode {
        var currNode = startNode
        var currDist = cosineSimilarity(query.values, currNode.vector.values)
        
        var changed = true
        while changed {
            changed = false
            for neighbor in currNode.connections[atLayer] {
                let dist = cosineSimilarity(query.values, neighbor.vector.values)
                if dist > currDist { // Higher is better for cosine similarity
                    currDist = dist
                    currNode = neighbor
                    changed = true
                }
            }
        }
        return currNode
    }
    
    /// Exhaustive search in the bottom layer to find top K neighbors.
    private func searchInLayer(query: SemanticVector, startNode: HNSWNode, atLayer: Int, count: Int) -> [HNSWNode] {
        // This implements a priority queue-based search (simplified for this example)
        // In production, this uses a 'candidate set' and a 'result set'.
        var candidates: [(node: HNSWNode, dist: Float)] = [(startNode, cosineSimilarity(query.values, startNode.vector.values))]
        var results: [(node: HNSWNode, dist: Float)] = []
        
        // Simplified traversal
        for _ in 0..<count * 2 { // Heuristic expansion
            guard let next = candidates.popLast() else { break }
            results.append(next)
            
            for neighbor in next.node.connections[atLayer] {
                let d = cosineSimilarity(query.values, neighbor.vector.values)
                candidates.append((neighbor, d))
            }
        }
        
        return results.sorted { $0.dist > $1.dist }.prefix(count).map { $0.node }
    }
    
    /// Establishes connections between nodes.
    private func linkNode(_ newNode: HNSWNode, to existingNode: HNSWNode, atLayer: Int) {
        newNode.connections[atLayer].append(existingNode)
        existingNode.connections[atLayer].append(newNode)
        // In production, we would enforce the 'm' limit here.
    }
}

// MARK: - Application Integration Example

/// A Voice Assistant service that uses the Semantic Engine to remember user context.
@available(iOS 18.0, *)
final class EchoMindAssistant: Sendable {
    private let memory: SemanticMemoryEngine
    private let logger = Logger(subsystem: "com.echomind.app", category: "Assistant")
    
    init(dimension: Int) {
        self.memory = SemanticMemoryEngine(dimension: dimension)
    }
    
    /// Simulates receiving a voice transcription and embedding it.
    func processVoiceInput(text: String, embedding: [Float]) async {
        let vector = SemanticVector(values: embedding, metadata: ["text": text, "timestamp": "\(Date())"])
        do {
            try await memory.insert(vector)
            logger.info("Assistant: 'I've remembered that: \(text)'")
        } catch {
            logger.error("Failed to index voice input: \(error.localizedDescription)")
        }
    }
    
    /// Asks the assistant a question based on semantic similarity.
    func askQuestion(queryText: String, queryEmbedding: [Float]) async -> String {
        let queryVector = SemanticVector(values: queryEmbedding)
        
        do {
            let matches = try await memory.search(query: queryVector, k: 1)
            if let bestMatch = matches.first {
                let originalText = bestMatch.metadata["text"] ?? "Unknown"
                return "Based on what you told me earlier: \"\(originalText)\""
            } else {
                return "I don't recall anything related to that."
            }
        } catch {
            return "My memory is a bit foggy right now. (Error: \(error.localizedDescription))"
        }
    }
}

// MARK: - Execution Logic Breakdown

/*
 1. Initialization: The `SemanticMemoryEngine` is initialized with a fixed dimension (e.g., 1536).
    This dimension must remain constant for the lifetime of the index.
 
 2. Concurrency Model: The engine is an `actor`. This is critical because:
    - Multiple background tasks might be indexing new voice memos.
    - The user might simultaneously trigger a search via the UI.
    - The actor ensures that the graph's adjacency lists (`connections`) are never 
      mutated by two threads simultaneously, preventing crashes and data corruption.
 
 3. The Insertion Pipeline:
    - A new vector arrives.
    - We determine its "entry layer" using a logarithmic distribution. This ensures 
      that most nodes live in Layer 0, while only a few live in the top layers.
    - We traverse from the current entry point down the layers to find the closest 
      neighborhood.
    - Once at the target layer, we create links (edges) to the nearest neighbors.
 
 4. The Search Pipeline:
    - The query vector enters the top layer.
    - It performs a "Greedy Search": it looks at neighbors, moves to the one closest 
      to the query, and repeats until no closer neighbor is found.
    - It then "drops down" to the next layer and repeats the process, starting 
      from the node found in the previous layer.
    - This "zoom-in" effect is what makes HNSW $O(\log N)$.
 
 5. Performance Optimization (The Accelerate Factor):
    - The `cosineSimilarity` function uses `vDSP_dotpr`. 
    - Instead of iterating through 1536 floats in Swift, the CPU uses SIMD units 
      to multiply and add multiple values in a single instruction.
    - This reduces the search latency from milliseconds to microseconds.
*/
