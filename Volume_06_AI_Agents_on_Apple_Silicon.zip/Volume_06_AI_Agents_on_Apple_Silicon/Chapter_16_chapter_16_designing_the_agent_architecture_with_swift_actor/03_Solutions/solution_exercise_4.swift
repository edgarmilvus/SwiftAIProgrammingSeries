
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

// Swift 6
@available(iOS 18.0, macOS 15.0, *)
// Re-using LLMClientActor and LLMService from Exercise 1
// actor LLMClientActor { ... }
// struct LLMService { ... }

// MARK: - Data Structures

struct AnalysisResult: Identifiable, Equatable { // Equatable for @Published observation optimization
    let id = UUID()
    let grammarSuggestions: [String]
    let summary: String
    let sentiment: String
    let timestamp: Date = Date()
    
    static func == (lhs: AnalysisResult, rhs: AnalysisResult) -> Bool {
        lhs.id == rhs.id // Simple equality check for observation
    }
}

// MARK: - Actors

actor DocumentBufferActor {
    private var currentDocumentContent: String = ""
    private var debounceTask: Task<Void, Never>? // Task to manage debouncing
    private let debounceInterval: Duration // e.g., .seconds(0.5)
    private let analysisEngine: AnalysisEngineActor

    init(debounceInterval: Duration, analysisEngine: AnalysisEngineActor) {
        self.debounceInterval = debounceInterval
        self.analysisEngine = analysisEngine
    }

    /// Updates the document content and triggers debounced analysis.
    func updateDocument(newContent: String) {
        // Only update if content actually changed to avoid unnecessary processing
        guard currentDocumentContent != newContent else { return }
        
        currentDocumentContent = newContent
        
        // Cancel any existing debounce task
        debounceTask?.cancel()
        
        // Start a new debounce task
        debounceTask = Task {
            do {
                try await Task.sleep(for: debounceInterval)
                // Check if the task was cancelled during sleep
                if !Task.isCancelled {
                    print("DocumentBufferActor: Debounce complete, sending for analysis (\(currentDocumentContent.prefix(20))...)")
                    // Pass a copy of the content to avoid potential issues if currentDocumentContent changes
                    await analysisEngine.analyze(document: currentDocumentContent)
                }
            } catch is CancellationError {
                print("DocumentBufferActor: Debounce task was cancelled.")
            } catch {
                print("DocumentBufferActor: Error in debounce task: \(error)")
            }
        }
    }
}

actor AnalysisEngineActor {
    private let llmClient: LLMClientActor
    private let suggestionDisplay: SuggestionDisplayActor

    init(llmClient: LLMClientActor, suggestionDisplay: SuggestionDisplayActor) {
        self.llmClient = llmClient
        self.suggestionDisplay = suggestionDisplay
    }

    /// Performs multiple LLM analyses on the document.
    func analyze(document: String) async {
        print("AnalysisEngineActor: Starting analysis of document (\(document.prefix(20))...)")
        
        // Simulate concurrent LLM calls for different analysis types
        // Using async let to run these in parallel
        async let grammarRaw = llmClient.sendPrompt(text: "Perform a grammar check on the following text and list suggested corrections. If no errors, say 'no errors found': \n\"\(document)\"")
        async let summaryRaw = llmClient.sendPrompt(text: "Provide a concise summary of the following document: \n\"\(document)\"")
        async let sentimentRaw = llmClient.sendPrompt(text: "Analyze the sentiment of the following document. Respond with 'Positive', 'Negative', or 'Neutral': \n\"\(document)\"")

        do {
            let grammarResult = try await grammarRaw
            let summaryResult = try await summaryRaw
            let sentimentResult = try await sentimentRaw
            
            // Basic parsing of simulated LLM responses for structured output
            let grammarSuggestions = grammarResult.lowercased().contains("no errors found") ? [] : ["Consider changing 'grammer' to 'grammar'", "Suggestion: 'fix them' -> 'correct them'"]
            let summary = summaryResult.replacingOccurrences(of: "This is a generic LLM response.", with: "Simulated summary: The document discusses grammar errors and AI correction.")
            let sentiment = sentimentResult.lowercased().contains("positive") ? "Positive" : (sentimentResult.lowercased().contains("negative") ? "Negative" : "Neutral")

            let result = AnalysisResult(
                grammarSuggestions: grammarSuggestions,
                summary: summary,
                sentiment: sentiment
            )
            
            print("AnalysisEngineActor: Analysis complete, sending to display.")
            await suggestionDisplay.display(result: result)
        } catch {
            print("AnalysisEngineActor: Error during analysis: \(error.localizedDescription)")
            // Optionally send an error state or partial results to the display actor
        }
    }
}

actor SuggestionDisplayActor {
    // @MainActor @Published properties are automatically updated on the MainActor
    // and can be observed by SwiftUI views.
    @MainActor @Published var latestAnalysisResult: AnalysisResult?
    @MainActor @Published var currentGrammarSuggestions: [String] = []
    @MainActor @Published var currentSummary: String = ""
    @MainActor @Published var currentSentiment: String = "N/A"

    func display(result: AnalysisResult) {
        print("SuggestionDisplayActor: Displaying analysis result (Timestamp: \(result.timestamp)).")
        // Updating @MainActor @Published properties must happen on the MainActor.
        // A Task { @MainActor in ... } block ensures this.
        Task { @MainActor in
            self.latestAnalysisResult = result
            self.currentGrammarSuggestions = result.grammarSuggestions
            self.currentSummary = result.summary
            self.currentSentiment = result.sentiment
        }
    }
}

// MARK: - Example Usage (e.g., in a macOS SwiftUI App)

@available(iOS 18.0, macOS 15.0, *)
class DocumentEditorViewModel: ObservableObject {
    @Published var documentText: String = "Hello, this is a sample document with some grammer errors. I hope the AI can fix them."
    
    // Properties to observe from SuggestionDisplayActor
    // These are also @MainActor @Published, making them safe for SwiftUI.
    @MainActor @Published var grammarSuggestions: [String] = []
    @MainActor @Published var documentSummary: String = ""
    @MainActor @Published var documentSentiment: String = "N/A"

    private let documentBuffer: DocumentBufferActor
    private let suggestionDisplay: SuggestionDisplayActor
    private var observationTask: Task<Void, Never>?

    init() {
        let llmService = LLMService()
        let llmClient = LLMClientActor(llmService: llmService)
        
        self.suggestionDisplay = SuggestionDisplayActor()
        let analysisEngine = AnalysisEngineActor(llmClient: llmClient, suggestionDisplay: suggestionDisplay)
        self.documentBuffer = DocumentBufferActor(debounceInterval: .seconds(0.7), analysisEngine: analysisEngine)
        
        // Observe changes from the SuggestionDisplayActor's @Published properties
        // This task will run indefinitely, observing the stream of updates.
        observationTask = Task { @MainActor in
            for await result in suggestionDisplay.$latestAnalysisResult.values {
                self.grammarSuggestions = result?.grammarSuggestions ?? []
                self.documentSummary = result?.summary ?? ""
                self.documentSentiment = result?.sentiment ?? "N/A"
            }
        }
        
        // Trigger initial analysis for the default text
        Task {
            await documentBuffer.updateDocument(newContent: documentText)
        }
    }
    
    // In a real app, this would be called by a TextEditor's onChange handler
    func textDidChange(newText: String) {
        documentText = newText
        Task {
            await documentBuffer.updateDocument(newContent: newText)
        }
    }
    
    // Clean up observation task when the ViewModel is deallocated
    deinit {
        observationTask?.cancel()
    }
}
