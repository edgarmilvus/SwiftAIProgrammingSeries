
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift snippet for Observable:
// dependencies: [
//     .package(url: "https://github.com/apple/swift-collections", from: "1.0.0"),
// ]

import SwiftUI
import Observation // For @Observable

@available(iOS 18.0, *)
@Observable
class ImageGenerationViewModel {
    private let imageProcessor = ImageProcessor()
    var generatedImage: UIImage?
    var currentPrompt: String = ""
    var isGenerating: Bool = false
    var error: Error?

    func generateImage() {
        guard !currentPrompt.isEmpty else { return }
        isGenerating = true
        generatedImage = nil
        error = nil

        Task {
            do {
                let image = try await imageProcessor.generateImage(prompt: currentPrompt)
                await MainActor.run {
                    self.generatedImage = image
                    self.isGenerating = false
                }
            } catch {
                await MainActor.run {
                    self.error = error
                    self.isGenerating = false
                }
            }
        }
    }
}

@available(iOS 18.0, *)
struct ImageGeneratorView: View {
    @State private var viewModel = ImageGenerationViewModel()

    var body: some View {
        VStack {
            TextField("Enter image prompt", text: $viewModel.currentPrompt)
                .textFieldStyle(.roundedBorder)
                .padding()

            Button("Generate Image") {
                viewModel.generateImage()
            }
            .disabled(viewModel.isGenerating)
            .padding()

            if viewModel.isGenerating {
                ProgressView()
            } else if let image = viewModel.generatedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 300)
            } else if let error = viewModel.error {
                Text("Error: \(error.localizedDescription)")
                    .foregroundColor(.red)
            }
            Spacer()
        }
    }
}
