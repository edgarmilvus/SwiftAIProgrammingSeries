
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift (Hypothetical - Not strictly needed for NaturalLanguage framework itself)
// NaturalLanguage is a system framework, so it doesn't require a Swift Package Manager
// dependency. If you were to include custom utility libraries, they would go here.
//
// For example, if you had a custom text pre-processing library:
/*
import PackageDescription

let package = Package(
    name: "CustomerSupportApp",
    platforms: [
        .iOS(.v15), // Targeting iOS 15 for async/await
        .macOS(.v12) // Targeting macOS 12 for async/await
    ],
    products: [
        .library(
            name: "FeedbackClassifier",
            targets: ["FeedbackClassifier"]),
    ],
    dependencies: [
        // .package(url: "https://github.com/your-org/TextPreprocessingKit.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "FeedbackClassifier",
            dependencies: [
                // "TextPreprocessingKit" // If you had a custom text processing dependency
            ]),
        .testTarget(
            name: "FeedbackClassifierTests",
            dependencies: ["FeedbackClassifier"]),
    ]
)
*/

import Foundation
import NaturalLanguage // The core framework for NLModel

/// Represents the possible categories for customer feedback.
/// These categories would correspond to the labels used during Create ML model training.
enum FeedbackCategory: String, CaseIterable, Codable {
    case bugReport = "Bug Report"
    case featureRequest = "Feature Request"
    case technicalSupport = "Technical Support"
    case billingInquiry = "Billing Inquiry"
    case generalInquiry = "General Inquiry"
    case unknown = "Unknown" // Fallback for cases where the model is uncertain or fails
}

/// Custom errors that can occur during the feedback classification process.
enum CustomerFeedbackClassifierError: Error, LocalizedError {
    case modelNotFound(String)
    case modelLoadingFailed(Error)
    case classificationFailed(String)
    case invalidInput

    var errorDescription: String? {
        switch self {
        case .modelNotFound(let name):
            return "The machine learning model '\(name)' could not be found in the app bundle."
        case .modelLoadingFailed(let error):
            return "Failed to load the NLModel: \(error.localizedDescription)"
        case .classificationFailed(let message):
            return "Text classification failed: \(message)"
        case .invalidInput:
            return "The input text for classification was empty or invalid."
        }
    }
}

/// A structure representing a classified piece of feedback.
struct ClassifiedFeedback: Identifiable, Hashable {
    let id = UUID()
    let originalText: String
    let predictedCategory: FeedbackCategory
    let confidence: Double? // Optional confidence score from the model
}

/// Manages the loading and classification of customer feedback using an NLModel.
/// This class is designed to be thread-safe and uses Swift concurrency for asynchronous operations.
@available(iOS 15.0, macOS 12.0, *) // async/await requires iOS 15+, macOS 12+
final class CustomerFeedbackClassifier {
    private let modelName: String
    private var nlModel: NLModel?
    private let modelLoadingQueue = DispatchQueue(label: "com.example.feedbackclassifier.modelLoading", qos: .userInitiated)

    /// Initializes the classifier with the name of the NLModel file (without extension).
    /// The model is expected to be bundled with the application.
    /// - Parameter modelName: The name of the `.mlmodel` file, e.g., "FeedbackClassifier".
    init(modelName: String) {
        self.modelName = modelName
    }

    /// Asynchronously loads the NLModel from the app bundle.
    /// This method should be called once, typically during application startup or when the classifier is first needed.
    /// - Throws: `CustomerFeedbackClassifierError` if the model cannot be found or loaded.
    func loadModel() async throws {
        // Ensure model loading happens only once and is thread-safe.
        _ = await modelLoadingQueue.sync {
            guard nlModel == nil else { return } // Model already loaded

            guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlmodel") else {
                throw CustomerFeedbackClassifierError.modelNotFound(modelName)
            }

            do {
                // NLModel.init(contentsOf:) is a synchronous call, but we wrap it in a Task
                // to make the overall `loadModel` function async and allow for future
                // asynchronous model loading mechanisms if they become available.
                nlModel = try NLModel(contentsOf: modelURL)
                print("Successfully loaded NLModel: \(modelName)")
            } catch {
                throw CustomerFeedbackClassifierError.modelLoadingFailed(error)
            }
        }
    }

    /// Pre-processes the input text before sending it to the NLModel.
    /// This typically involves lowercasing, stripping whitespace, and removing punctuation.
    /// The pre-processing steps should match what was done during Create ML model training for best results.
    /// - Parameter text: The raw input text.
    /// - Returns: The cleaned text.
    private func preprocess(text: String) -> String {
        return text
            .lowercased() // Convert to lowercase
            .trimmingCharacters(in: .whitespacesAndNewlines) // Remove leading/trailing whitespace
            // You might add more advanced cleaning here, e.g., removing URLs, special characters, etc.
    }

    /// Classifies a single piece of customer feedback asynchronously.
    /// - Parameter text: The customer's feedback message.
    /// - Returns: A `ClassifiedFeedback` struct containing the predicted category and confidence.
    /// - Throws: `CustomerFeedbackClassifierError` if the model is not loaded, input is invalid, or classification fails.
    func classify(text: String) async throws -> ClassifiedFeedback {
        guard let model = nlModel else {
            throw CustomerFeedbackClassifierError.classificationFailed("NLModel is not loaded. Call loadModel() first.")
        }
        guard !text.isEmpty else {
            throw CustomerFeedbackClassifierError.invalidInput
        }

        let processedText = preprocess(text: text)

        do {
            // NLModel.predictedLabel(for:) is a synchronous operation.
            // We wrap it in a Task to ensure it runs off the main thread and
            // to maintain an async API for the classifier.
            return try await Task.detached {
                if let prediction = model.predictedLabel(for: processedText) {
                    let confidence = model.getConfidence(for: processedText, label: prediction)
                    let category = FeedbackCategory(rawValue: prediction) ?? .unknown
                    return ClassifiedFeedback(originalText: text, predictedCategory: category, confidence: confidence)
                } else {
                    // This case might happen if the model cannot make a confident prediction
                    // or if the input is entirely out of its training distribution.
                    return ClassifiedFeedback(originalText: text, predictedCategory: .unknown, confidence: nil)
                }
            }.value
        } catch {
            throw CustomerFeedbackClassifierError.classificationFailed("Prediction failed: \(error.localizedDescription)")
        }
    }

    /// Classifies a batch of customer feedback messages asynchronously.
    /// This method is more efficient than calling `classify(text:)` repeatedly for multiple texts.
    /// - Parameter texts: An array of customer feedback messages.
    /// - Returns: An array of `ClassifiedFeedback` structs.
    /// - Throws: `CustomerFeedbackClassifierError` if the model is not loaded or classification fails for any text.
    func classifyBatch(texts: [String]) async throws -> [ClassifiedFeedback] {
        guard let model = nlModel else {
            throw CustomerFeedbackClassifierError.classificationFailed("NLModel is not loaded. Call loadModel() first.")
        }
        guard !texts.isEmpty else {
            return [] // Return empty array for empty input
        }

        // Process all texts concurrently using a TaskGroup for efficient parallelization.
        return try await withThrowingTaskGroup(of: ClassifiedFeedback.self) { group in
            var classifiedResults: [ClassifiedFeedback] = []

            for text in texts {
                group.addTask {
                    let processedText = self.preprocess(text: text)
                    if let prediction = model.predictedLabel(for: processedText) {
                        let confidence = model.getConfidence(for: processedText, label: prediction)
                        let category = FeedbackCategory(rawValue: prediction) ?? .unknown
                        return ClassifiedFeedback(originalText: text, predictedCategory: category, confidence: confidence)
                    } else {
                        // For batch processing, we might return .unknown rather than throwing for each failure
                        // to allow the rest of the batch to complete. Error handling strategy depends on requirements.
                        return ClassifiedFeedback(originalText: text, predictedCategory: .unknown, confidence: nil)
                    }
                }
            }

            for try await result in group {
                classifiedResults.append(result)
            }

            return classifiedResults
        }
    }
}

// MARK: - NLModel Extension for Confidence (Helper)

extension NLModel {
    /// A helper function to retrieve the confidence score for a specific label.
    /// - Parameters:
    ///   - text: The text that was classified.
    ///   - label: The predicted label for which to get the confidence.
    /// - Returns: The confidence score (0.0 to 1.0) or nil if not available.
    func getConfidence(for text: String, label: String) -> Double? {
        let tagger = NLTagger(tagSchemes: [.sentimentScore]) // NLModel doesn't directly expose confidence in a simple way
        // This is a common workaround or a pattern if the NLModel was trained with a specific tag scheme
        // For NLModel.predictedLabel(for:), confidence is not directly returned.
        // A more direct way to get confidence from a custom text classifier model would be to
        // use NLModel.prediction(for:maximumSuggestions:).
        
        // Let's refine this to use prediction(for:maximumSuggestions:) for direct confidence.
        // This method provides an array of (label, confidence) pairs.
        let predictions = self.predictions(for: text, maximumSuggestions: 1) // Get top prediction
        if let topPrediction = predictions.first, topPrediction.0 == label {
            return topPrediction.1 // Return confidence for the predicted label
        }
        return nil
    }
}


// MARK: - Usage Example in an App Context

// This would typically be in your AppDelegate, SceneDelegate, or a ViewModel.
@available(iOS 15.0, macOS 12.0, *)
actor AppFeedbackManager {
    private let classifier: CustomerFeedbackClassifier

    init(classifier: CustomerFeedbackClassifier) {
        self.classifier = classifier
    }

    /// Initializes and loads the classification model.
    func setupClassifier() async {
        do {
            try await classifier.loadModel()
            print("Classifier model ready.")
        } catch {
            print("Error setting up classifier: \(error.localizedDescription)")
            // In a real app, you might disable classification features or show an alert.
        }
    }

    /// Processes a single user feedback message.
    func processSingleFeedback(message: String) async {
        do {
            let classified = try await classifier.classify(text: message)
            print("--- Single Feedback ---")
            print("Original: \"\(classified.originalText)\"")
            print("Category: \(classified.predictedCategory.rawValue)")
            if let confidence = classified.confidence {
                print("Confidence: \(String(format: "%.2f", confidence * 100))%")
            }
            print("-----------------------")
        } catch {
            print("Error classifying single feedback: \(error.localizedDescription)")
        }
    }

    /// Processes multiple feedback messages from a queue or batch.
    func processBatchFeedback(messages: [String]) async {
        do {
            let classifiedBatch = try await classifier.classifyBatch(texts: messages)
            print("\n--- Batch Feedback ---")
            for feedback in classifiedBatch {
                print("  \"\(feedback.originalText)\" -> \(feedback.predictedCategory.rawValue) (\(String(format: "%.2f", (feedback.confidence ?? 0.0) * 100))%)")
            }
            print("----------------------")
        } catch {
            print("Error classifying batch feedback: \(error.localizedDescription)")
        }
    }
}

// Simulated entry point for an iOS/macOS app
@main
@available(iOS 15.0, macOS 12.0, *)
struct CustomerSupportApp {
    static func main() async {
        // Assume "FeedbackClassifier" is the name of your .mlmodel file
        // generated by Create ML and added to your app's bundle.
        let classifier = CustomerFeedbackClassifier(modelName: "FeedbackClassifier")
        let appManager = AppFeedbackManager(classifier: classifier)

        // 1. Setup the classifier (load model)
        await appManager.setupClassifier()

        // 2. Simulate processing a single feedback
        await appManager.processSingleFeedback(message: "My app crashes every time I open the camera. iOS 17.4, iPhone 15 Pro Max.")

        // 3. Simulate processing a batch of feedback
        let incomingFeedback = [
            "The login button is not working on the latest update.",
            "I'd love to see a dark mode option in the settings.",
            "My subscription was renewed unexpectedly, can you check my billing?",
            "How do I reset my password? I can't find the option.",
            "The app is generally great, but could use some performance improvements."
        ]
        await appManager.processBatchFeedback(messages: incomingFeedback)

        // Simulate an error case: model not found (if you change the model name to something non-existent)
        // let brokenClassifier = CustomerFeedbackClassifier(modelName: "NonExistentModel")
        // let brokenManager = AppFeedbackManager(classifier: brokenClassifier)
        // await brokenManager.setupClassifier()
    }
}
