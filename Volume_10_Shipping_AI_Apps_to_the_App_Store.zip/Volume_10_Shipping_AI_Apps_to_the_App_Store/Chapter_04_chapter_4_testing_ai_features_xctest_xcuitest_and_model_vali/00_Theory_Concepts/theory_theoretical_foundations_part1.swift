
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import XCTest
import CoreML
import Observation

/// A specialized actor designed to isolate model testing 
/// and prevent interference with the main test runner.
@available(iOS 18.0, *)
actor ModelTester {
    private let model: MLModel
    
    init(model: MLModel) {
        self.model = model
    }
    
    /// Performs inference and returns a Sendable result.
    /// This demonstrates the 'Why' of async/await: 
    /// keeping the test runner responsive while the ANE works.
    func performInference(on input: MLFeatureProvider) async throws -> MLFeatureProvider {
        // Simulate the latency of a heavy transformer model
        return try await model.prediction(from: input)
    }
    
    /// Measures the statistical variance of a model's output.
    /// This implements the 'Statistical Validation' concept.
    func validateStability(input: MLFeatureProvider, iterations: Int) async throws -> Double {
        var results: [Double] = []
        
        for _ in 0..<iterations {
            let output = try await performInference(on: input)
            // Assume the first feature is a confidence score for testing
            if let score = output.featureValue(for: "confidence")?.doubleValue {
                results.append(score)
            }
        }
        
        return calculateStandardDeviation(results)
    }
    
    private func calculateStandardDeviation(_ data: [Double]) -> Double {
        guard data.count > 1 else { return 0.0 }
        let mean = data.reduce(0, +) / Double(data.count)
        let v = data.reduce(0) { $0 + pow($1 - mean, 2) }
        return sqrt(v / Double(data.count))
    }
}

@available(iOS 18.0, *)
final class AIModelTests: XCTestCase {
    
    var tester: ModelTester!
    var model: MLModel!

    override func setUp() async throws {
        try await super.setUp()
        // In a real scenario, load your actual .mlmodelc
        // For this example, we assume a pre-loaded model
        // self.model = try MyAIModel(configuration: .init()).model
        // self.tester = ModelTester(model: model)
    }

    /// Test Case: Statistical Stability
    /// Instead of XCTAssertEqual, we use a threshold-based assertion.
    func testModelOutputStability() async throws {
        let input = try MockDataGenerator.generateInput() // Helper to create MLFeatureProvider
        
        // We assert that the model's output variance is below a threshold.
        // This accounts for the 'Stochastic Gap'.
        let variance = try await tester.validateStability(input: input, iterations: 10)
        
        let maxAllowedVariance = 0.05
        XCTAssertLessThan(variance, maxAllowedVariance, "Model output is too stochastic; variance \(variance) exceeds threshold.")
    }
    
    /// Test Case: Concurrency and Race Conditions
    /// Verifies that the ModelActor correctly handles rapid-fire requests.
    func testConcurrentInferenceSafety() async throws {
        let input = try MockDataGenerator.generateInput()
        
        // Use a TaskGroup to simulate multiple simultaneous requests
        try await withThrowingTaskGroup(of: Void.self) { group in
            for _ in 0..<5 {
                group.addTask {
                    _ = try await self.tester.performInference(on: input)
                }
            }
            try await group.waitForAll()
        }
        // If the Actor isolation fails, the Swift 6 runtime will trigger a data race error here.
    }
}
