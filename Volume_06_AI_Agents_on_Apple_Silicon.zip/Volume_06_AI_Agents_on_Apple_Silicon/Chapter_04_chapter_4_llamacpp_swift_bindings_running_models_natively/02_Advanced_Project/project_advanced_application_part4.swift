
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import Foundation
import llama_cpp // Ensure this is imported if using LLMContextConfiguration directly

/// A ViewModel for a SwiftUI application that uses the DocumentSummarizerService.
@available(macOS 14.0, iOS 18.0, *)
@Observable // Swift 6 @Observable macro for SwiftUI integration
final class SummarizerViewModel {
    private let summarizerService: DocumentSummarizerService

    var documentText: String = ""
    var query: String = ""
    var summary: String = "Summary will appear here..."
    var isLoading: Bool = false
    var errorMessage: String?

    /// Initializes the ViewModel, setting up the summarizer service.
    /// - Parameter modelURL: The URL to the GGUF model file.
    init(modelURL: URL) {
        // Define LLM configuration. These values are highly dependent on the model used.
        // n_ctx: Context window size (e.g., 2048, 4096, 8192, etc.)
        // n_gpu_layers: Number of layers to offload to GPU (-1 for all, 0 for none).
        let config = LLMContextConfiguration(
            n_ctx: 4096, // A common context size, adjust based on your model
            n_gpu_layers: -1, // Use all available GPU layers for Apple Silicon acceleration
            main_gpu: 0,
            tensor_split: nil,
            rope_freq_base: 10000.0,
            rope_freq_scale: 1.0,
            n_batch: 512,
            n_threads: UInt32(ProcessInfo.processInfo.activeProcessorCount), // Use all available CPU cores
            flash_attn: true, // Enable Flash Attention if supported by llama.cpp.swift for performance
            low_vram: false,
            mul_mat_q: true,
            f16_kv: true,
            logits_all: false,
            embedding: false
        )
        self.summarizerService = DocumentSummarizerService(modelPath: modelURL, configuration: config)
    }

    /// Loads the LLM model. This should ideally be called once, e.g., on app launch or when the view appears.
    func loadModel() async {
        isLoading = true
        errorMessage = nil
        do {
            try await summarizerService.loadModel()
        } catch {
            errorMessage = error.localizedDescription
            print("Error loading model: \(error.localizedDescription)")
        }
        isLoading = false
    }

    /// Performs the document summarization.
    func performSummarization() async {
        isLoading = true
        errorMessage = nil
        summary = "Generating summary..."

        guard !documentText.isEmpty else {
            errorMessage = "Please enter document text to summarize."
            isLoading = false
            return
        }

        do {
            let generatedSummary = try await summarizerService.summarize(
                documentText: documentText,
                query: query,
                maxLength: 250 // Request a summary up to 250 tokens
            )
            self.summary = generatedSummary
        } catch {
            self.errorMessage = error.localizedDescription
            self.summary = "Failed to generate summary."
            print("Error summarizing: \(error.localizedDescription)")
        }
        isLoading = false
    }

    /// Unloads the LLM model resources.
    func unloadModel() {
        summarizerService.unloadModel()
    }
}

// Example of a basic SwiftUI View that would use this ViewModel
@available(macOS 14.0, iOS 18.0, *)
struct SummarizerView: View {
    // IMPORTANT: Replace with your actual model path.
    // For macOS, you might put models in Application Support or bundled resources.
    // For iOS, models are typically bundled or downloaded.
    // Example for macOS:
    // let modelURL = URL(fileURLWithPath: "/Users/youruser/Documents/models/llama-2-7b-chat.Q4_K_M.gguf")
    // Example for bundled resource (ensure model is added to target's Copy Bundle Resources):
    // let modelURL = Bundle.main.url(forResource: "llama-2-7b-chat.Q4_K_M", withExtension: "gguf")!
    @State private var viewModel = SummarizerViewModel(modelURL:
        Bundle.main.url(forResource: "tinyllama-1.1b-chat-v1.0.Q4_K_M", withExtension: "gguf")! // Placeholder
    )

    var body: some View {
        VStack(spacing: 16) {
            Text("Context-Aware Document Summarizer")
                .font(.largeTitle)
                .fontWeight(.bold)

            TextEditor(text: $viewModel.documentText)
                .frame(minHeight: 150, maxHeight: 300)
                .border(Color.gray.opacity(0.5), width: 1)
                .padding(.horizontal)
                .overlay(
                    Text("Enter document text here...")
                        .foregroundColor(.gray)
                        .opacity(viewModel.documentText.isEmpty ? 1 : 0)
                        .padding(.leading, 24)
                        .padding(.top, 8),
                    alignment: .topLeading
                )

            TextField("Optional Query (e.g., 'focus on key findings')", text: $viewModel.query)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)

            Button {
                Task { await viewModel.performSummarization() }
            } label: {
                if viewModel.isLoading {
                    ProgressView()
                } else {
                    Text("Summarize Document")
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(viewModel.isLoading || viewModel.documentText.isEmpty)

            if let errorMessage = viewModel.errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .padding(.horizontal)
            }

            ScrollView {
                Text(viewModel.summary)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
            }
            .frame(maxHeight: .infinity)
            .padding(.horizontal)
        }
        .padding()
        .task {
            // Load the model when the view appears.
            await viewModel.loadModel()
        }
        .onDisappear {
            // Unload the model when the view disappears to free up resources.
            viewModel.unloadModel()
        }
    }
}

// Preview Provider for SwiftUI (requires a valid modelURL for compilation)
@available(macOS 14.0, iOS 18.0, *)
struct SummarizerView_Previews: PreviewProvider {
    static var previews: some View {
        // This will likely fail to load the model in a preview environment
        // unless you provide a valid, accessible path to a small model.
        // For actual previews, you might mock the service or use a dummy URL.
        SummarizerView()
    }
}
