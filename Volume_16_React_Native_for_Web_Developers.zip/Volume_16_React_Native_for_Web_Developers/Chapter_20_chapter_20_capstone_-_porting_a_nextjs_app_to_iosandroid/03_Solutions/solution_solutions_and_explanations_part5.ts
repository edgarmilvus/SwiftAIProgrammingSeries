/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// utils/share.ts
import { Platform, Alert, Share } from 'react-native';

// Define the data structure for sharing
export interface ShareData {
  title?: string;
  url?: string;
  message?: string;
}

// We define the function as async to handle dynamic imports
export const shareContent = async (data: ShareData) => {
  if (Platform.OS === 'web') {
    // Web Implementation
    if (navigator.share) {
      try {
        await navigator.share(data);
      } catch (error) {
        if ((error as DOMException).name !== 'AbortError') {
          console.error('Error sharing:', error);
          Alert.alert('Share failed', 'Could not share content.');
        }
      }
    } else {
      // Fallback for browsers without Web Share API
      Alert.alert('Not Supported', 'Your browser does not support the Web Share API.');
    }
  } else {
    // Native Implementation (iOS/Android)
    // Dynamic import ensures 'expo-sharing' is not bundled for web
    try {
      const { shareAsync } = await import('expo-sharing');
      await shareAsync(data.url || data.message || '', {
        dialogTitle: data.title || 'Share Content',
        mimeType: 'text/plain',
      });
    } catch (error) {
      console.error('Error sharing on native:', error);
      Alert.alert('Error', 'Failed to share content.');
    }
  }
};

// components/UniversalShareButton.tsx
import React from 'react';
import { TouchableOpacity, Text, Platform, Alert } from 'react-native';

interface UniversalShareButtonProps {
  title: string;
  url: string;
  buttonLabel?: string;
}

export default function UniversalShareButton({ title, url, buttonLabel = 'Share' }: UniversalShareButtonProps) {
  const handlePress = async () => {
    // On web, we might want to check for HTTPS context (required for Web Share API)
    if (Platform.OS === 'web' && window.location.protocol !== 'https:') {
      Alert.alert('Security Restriction', 'Sharing requires a secure context (HTTPS).');
      return;
    }

    await shareContent({ title, url });
  };

  return (
    <TouchableOpacity 
      onPress={handlePress}
      className="bg-blue-500 active:bg-blue-600 px-4 py-2 rounded items-center"
    >
      <Text className="text-white font-semibold text-base">{buttonLabel}</Text>
    </TouchableOpacity>
  );
}
