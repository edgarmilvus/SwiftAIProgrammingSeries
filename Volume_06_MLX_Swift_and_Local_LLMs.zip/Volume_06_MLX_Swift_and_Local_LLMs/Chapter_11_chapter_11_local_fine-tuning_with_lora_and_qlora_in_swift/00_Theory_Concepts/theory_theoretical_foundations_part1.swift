
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift snippet for MLX Swift
// dependencies: [
//     .package(url: "https://github.com/ml-explore/mlx-swift", from: "0.13.0")
// ]

import MLX
import MLXNN

// @available(iOS 18.0, *) // Or other appropriate platform availability
final class LoRALinear: Module {
    let baseLinear: Linear // The original, frozen linear layer
    let adapterA: Linear   // LoRA matrix A
    let adapterB: Linear   // LoRA matrix B
    let scale: Float

    // A concept from a previous chapter: `MLXNN.Module` for defining layers.
    // Here, we build upon the fundamental `Linear` layer.
    init(baseLinear: Linear, rank: Int, scale: Float = 1.0) {
        self.baseLinear = baseLinear
        self.baseLinear.freeze() // Freeze the base weights

        // Initialize LoRA adapters
        // Note: For actual LoRA, A is typically initialized with a Gaussian distribution
        // and B with zeros to ensure the initial adaptation is zero.
        // For simplicity here, we use default initializations.
        self.adapterA = Linear(inputDimensions: baseLinear.outputDimensions, outputDimensions: rank, bias: false)
        self.adapterB = Linear(inputDimensions: rank, outputDimensions: baseLinear.outputDimensions, bias: false)
        self.scale = scale
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Apply the frozen base linear transformation
        let baseOutput = baseLinear(input)

        // Apply LoRA adaptation: (input * A) * B
        let loraOutput = adapterB(adapterA(input)) * scale

        // Combine base and LoRA outputs
        return baseOutput + loraOutput
    }
}
