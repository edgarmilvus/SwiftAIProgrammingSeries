
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import ARKit
import RealityKit
import Combine // For cancellables if needed, though async/await is preferred for new code.

/// Represents a selectable word or phrase in the spatial document that can be
/// targeted by gaze for AI lookup.
struct GazeTarget: Identifiable, Hashable {
    let id = UUID()
    let content: String // The actual word or phrase
    let entity: Entity // The RealityKit entity representing this target's visual/spatial bounds
    let boundingBox: BoundingBox // Local bounding box relative to the entity

    /// Initializes a new gaze target.
    /// - Parameters:
    ///   - content: The text content of the target (e.g., "quantum entanglement").
    ///   - entity: The RealityKit entity that visually represents this target.
    ///   - boundingBox: The local bounding box of the target within its entity.
    init(content: String, entity: Entity, boundingBox: BoundingBox) {
        self.content = content
        self.entity = entity
        self.boundingBox = boundingBox
    }

    // Hashable conformance for comparison
    static func == (lhs: GazeTarget, rhs: GazeTarget) -> Bool {
        lhs.id == rhs.id
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

/// A protocol for providing contextual AI lookups based on text content.
/// This allows for different AI implementations (e.g., local Core ML, remote API).
protocol ContextualAIProvider {
    /// Fetches a definition or contextual information for a given word or phrase.
    /// - Parameter term: The word or phrase to look up.
    /// - Returns: A string containing the definition or contextual information, or nil if not found.
    /// - Throws: An `AIProviderError` if the lookup fails.
    func fetchDefinition(for term: String) async throws -> String?
}

/// An error type specific to the ContextualAIProvider.
enum AIProviderError: Error, LocalizedError {
    case networkError(Error)
    case lookupFailed(String)
    case invalidResponse
    case rateLimitExceeded

    var errorDescription: String? {
        switch self {
        case .networkError(let error):
            return "Network error during AI lookup: \(error.localizedDescription)"
        case .lookupFailed(let term):
            return "Failed to find definition for '\(term)'."
        case .invalidResponse:
            return "AI provider returned an invalid response."
        case .rateLimitExceeded:
            return "AI lookup rate limit exceeded. Please try again later."
        }
    }
}

/// A mock implementation of `ContextualAIProvider` for demonstration purposes.
/// In a real app, this would integrate with Core ML or a cloud AI service.
class MockContextualAIProvider: ContextualAIProvider {
    private let definitions: [String: String] = [
        "quantum entanglement": "A phenomenon where two or more particles become linked in such a way that they share the same fate, regardless of the distance separating them.",
        "holographic principle": "A property of string theory and a supposed property of quantum gravity that states that the description of a volume of space can be thought of as encoded on a lower-dimensional boundary to the region.",
        "spatial computing": "A paradigm shift in human-computer interaction where digital content is seamlessly integrated into the physical world, allowing users to interact with it naturally.",
        "RealityKit": "Apple's framework for building high-performance 3D simulations and augmented reality experiences.",
        "ARKit": "Apple's framework for creating augmented reality experiences, providing device position tracking, scene understanding, and camera image processing."
    ]

    /// Simulates an asynchronous AI lookup with a delay.
    func fetchDefinition(for term: String) async throws -> String? {
        // Simulate network delay or complex computation
        try await Task.sleep(for: .seconds(0.8))

        // Simulate a lookup failure for unknown terms
        guard let definition = definitions[term.lowercased()] else {
            throw AIProviderError.lookupFailed(term)
        }
        return definition
    }
}

/// Manages ARKit eye tracking, gaze raycasting, and triggers AI lookups
/// based on user dwell time on spatial document elements.
@available(visionOS 1.0, *) // Eye tracking is available on visionOS
class GazeInteractionManager: NSObject, ARSessionDelegate {

    // MARK: - Properties

    private let arSession: ARSession
    private let aiProvider: ContextualAIProvider
    private weak var realityScene: RealityKit.Scene? // The RealityKit scene to raycast against

    /// A collection of all gaze-interactive targets in the current document.
    private var gazeTargets: Set<GazeTarget> = []

    /// The currently gazed-at target, if any.
    private var currentGazedTarget: GazeTarget?
    /// The timestamp when the user started gazing at the `currentGazedTarget`.
    private var gazeDwellStartTime: Date?
    /// The minimum duration a user must gaze at a target to trigger an AI lookup.
    private let dwellTimeThreshold: TimeInterval = 1.5 // 1.5 seconds

    /// A flag to prevent multiple concurrent AI lookups for the same target.
    private var isAILookupActive: Bool = false

    /// Closure to be called when an AI definition is ready for display.
    /// Parameters: (definition: String, position: SIMD3<Float>)
    var onDefinitionReady: ((String, SIMD3<Float>) -> Void)?

    /// Closure to be called when an error occurs during AI lookup.
    /// Parameters: (error: Error)
    var onErrorOccurred: ((Error) -> Void)?

    // MARK: - Initialization

    /// Initializes the gaze interaction manager.
    /// - Parameters:
    ///   - realityScene: The RealityKit scene where the document entities reside.
    ///   - aiProvider: The AI provider to use for contextual lookups.
    init(realityScene: RealityKit.Scene, aiProvider: ContextualAIProvider) {
        self.arSession = ARSession()
        self.realityScene = realityScene
        self.aiProvider = aiProvider
        super.init()
        self.arSession.delegate = self
    }

    deinit {
        arSession.pause()
    }

    // MARK: - AR Session Management

    /// Configures and runs the AR session for eye tracking.
    func setupARSession() {
        // Ensure eye tracking is supported on the current device.
        guard ARFaceTrackingConfiguration.isSupported else {
            print("ARFaceTrackingConfiguration is not supported on this device.")
            onErrorOccurred?(ARError(.unsupportedConfiguration))
            return
        }

        let configuration = ARFaceTrackingConfiguration()
        configuration.isWorldTrackingEnabled = true // Essential for world coordinates
        configuration.maximumNumberOfTrackedFaces = 1 // Only need one face for eye tracking

        // Attempt to run the session.
        do {
            arSession.run(configuration, options: [.resetTracking, .removeExistingAnchors])
            print("ARSession started with Face Tracking Configuration.")
        } catch {
            print("Failed to run ARSession: \(error.localizedDescription)")
            onErrorOccurred?(error)
        }
    }

    /// Pauses the AR session.
    func pauseARSession() {
        arSession.pause()
        print("ARSession paused.")
    }

    // MARK: - Gaze Target Management

    /// Adds a new `GazeTarget` to the manager for interaction.
    /// - Parameter target: The `GazeTarget` to add.
    func addGazeTarget(_ target: GazeTarget) {
        gazeTargets.insert(target)
        // Ensure the entity is part of the RealityKit scene and has collision enabled.
        target.entity.components.set(CollisionComponent(shapes: [.boundingBox(size: target.boundingBox.extents)]))
        target.entity.generateCollisionShapes(recursive: false) // Generate collision shapes for raycasting
    }

    /// Removes a `GazeTarget` from the manager.
    /// - Parameter target: The `GazeTarget` to remove.
    func removeGazeTarget(_ target: GazeTarget) {
        gazeTargets.remove(target)
    }

    /// Clears all gaze targets from the manager.
    func clearGazeTargets() {
        gazeTargets.removeAll()
    }

    // MARK: - ARSessionDelegate

    /// Called when the AR session updates the state of tracked anchors.
    /// This is where we process eye tracking data.
    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
        guard let faceAnchor = anchors.first as? ARFaceAnchor,
              faceAnchor.eyeTrackingAvailable,
              let lookAtPoint = faceAnchor.lookAtPoint,
              let gazeRay = faceAnchor.gaze else {
            // Eye tracking data not available or face not tracked
            resetGazeState()
            return
        }

        // 1. Convert gaze ray to world coordinates for raycasting
        // The gaze ray is relative to the face anchor's coordinate system.
        let worldOrigin = faceAnchor.transform.columns.3.simd3 + lookAtPoint
        let worldDirection = faceAnchor.transform.columns.0.simd3 * gazeRay.x +
                             faceAnchor.transform.columns.1.simd3 * gazeRay.y +
                             faceAnchor.transform.columns.2.simd3 * gazeRay.z

        let ray = Ray(origin: worldOrigin, direction: normalize(worldDirection))

        // 2. Perform raycasting in the RealityKit scene
        // We use RealityKit's raycasting against the entities associated with our GazeTargets.
        guard let scene = realityScene else { return }

        // Perform a raycast against all collision entities in the scene.
        let raycastResults = scene.raycast(origin: ray.origin, direction: ray.direction, length: 1000, query: .nearest, mask: .all)

        var newGazedTarget: GazeTarget?
        // Iterate through results to find if we hit one of our registered GazeTargets.
        for result in raycastResults {
            if let hitTarget = gazeTargets.first(where: { $0.entity == result.entity }) {
                newGazedTarget = hitTarget
                break // Found our target, no need to check further
            }
        }

        // 3. Handle gaze dwell logic
        if let target = newGazedTarget {
            // Gaze is on a target
            if target == currentGazedTarget {
                // Still gazing at the same target, check dwell time
                if let startTime = gazeDwellStartTime,
                   Date().timeIntervalSince(startTime) >= dwellTimeThreshold && !isAILookupActive {
                    // Dwell time met, trigger AI lookup
                    isAILookupActive = true // Prevent re-triggering
                    print("Dwell time met for: \(target.content)")
                    Task {
                        await performAILookup(for: target, at: result.position)
                    }
                }
            } else {
                // Gaze moved to a new target
                currentGazedTarget = target
                gazeDwellStartTime = Date()
                print("Started gazing at new target: \(target.content)")
                // Optionally, provide visual feedback for new target focus
            }
        } else {
            // Gaze is not on any registered target, or moved off a target
            resetGazeState()
        }
    }

    /// Resets the internal state related to gaze tracking.
    private func resetGazeState() {
        if currentGazedTarget != nil {
            print("Gaze moved off target or no target detected.")
        }
        currentGazedTarget = nil
        gazeDwellStartTime = nil
        // Important: Do NOT reset isAILookupActive here, as the AI task might still be running.
        // It should be reset when the AI task completes.
    }

    /// Handles AR session errors.
    func session(_ session: ARSession, didFailWithError error: Error) {
        print("AR Session failed: \(error.localizedDescription)")
        onErrorOccurred?(error)
        resetGazeState()
    }

    /// Handles AR session interruptions.
    func sessionWasInterrupted(_ session: ARSession) {
        print("AR Session was interrupted.")
        resetGazeState()
    }

    /// Handles AR session interruption ending.
    func sessionInterruptionEnded(_ session: ARSession) {
        print("AR Session interruption ended, attempting to resume.")
        setupARSession() // Attempt to resume the session
    }

    // MARK: - AI Lookup and Display

    /// Performs an asynchronous AI lookup for the gazed target and dispatches the result.
    /// - Parameters:
    ///   - target: The `GazeTarget` that was gazed at.
    ///   - position: The world position where the AI definition should be displayed.
    private func performAILookup(for target: GazeTarget, at position: SIMD3<Float>) async {
        do {
            let definition = try await aiProvider.fetchDefinition(for: target.content)
            if let definition = definition {
                print("AI Lookup successful for '\(target.content)': \(definition.prefix(50))...")
                DispatchQueue.main.async {
                    self.onDefinitionReady?(definition, position)
                }
            } else {
                print("No definition found for '\(target.content)'.")
                DispatchQueue.main.async {
                    self.onErrorOccurred?(AIProviderError.lookupFailed(target.content))
                }
            }
        } catch {
            print("AI Lookup failed for '\(target.content)': \(error.localizedDescription)")
            DispatchQueue.main.async {
                self.onErrorOccurred?(error)
            }
        }
        // Reset the flag once the AI lookup (and potential display) is complete.
        isAILookupActive = false
    }
}

// MARK: - Integration Example (Simulated RealityView)

/// This struct simulates the environment where `GazeInteractionManager` would be used,
/// typically within a SwiftUI `RealityView` in visionOS.
@available(visionOS 1.0, *)
struct SpatialDocumentReviewApp {
    // A reference to the RealityKit scene. In a real app, this would come from RealityView.
    let realityScene = RealityKit.Scene()
    let gazeManager: GazeInteractionManager
    let aiProvider = MockContextualAIProvider()

    init() {
        self.gazeManager = GazeInteractionManager(realityScene: realityScene, aiProvider: aiProvider)
        setupGazeManagerCallbacks()
        setupMockDocument()
    }

    /// Sets up callbacks for the `GazeInteractionManager` to handle AI results and errors.
    private func setupGazeManagerCallbacks() {
        gazeManager.onDefinitionReady = { definition, position in
            print("Displaying definition: '\(definition)' at \(position)")
            // In a real app, you would create a RealityKit TextEntity or ModelEntity
            // at 'position' to display the definition.
            // For example:
            // let textMesh = MeshResource.generateText(definition, extrusionDepth: 0.01, font: .systemFont(ofSize: 0.05))
            // let textMaterial = SimpleMaterial(color: .white, isMetallic: false)
            // let textEntity = ModelEntity(mesh: textMesh, materials: [textMaterial])
            // textEntity.transform.translation = position + SIMD3<Float>(0, 0.05, 0) // Offset slightly above hit point
            // self.realityScene.addAnchor(AnchorEntity(world: textEntity.transform.translation, content: { textEntity }))
            // (Need to manage removal of old definitions as well)
        }

        gazeManager.onErrorOccurred = { error in
            print("Application Error: \(error.localizedDescription)")
            // In a real app, display an error message to the user spatially or via UI.
        }
    }

    /// Sets up a mock spatial document with interactive gaze targets.
    private func setupMockDocument() {
        // Create a simple plane for the document background
        let documentPlane = ModelEntity(mesh: .generatePlane(width: 1.0, height: 0.7), materials: [SimpleMaterial(color: .gray, isMetallic: false)])
        documentPlane.position = SIMD3<Float>(0, 1.5, -1.0) // Position in front of the user
        let documentAnchor = AnchorEntity(world: documentPlane.position)
        documentAnchor.addChild(documentPlane)
        realityScene.addAnchor(documentAnchor)

        // Simulate words as small entities on the document plane
        // In a real app, these would be laid out by a text rendering engine.
        let words = [
            "quantum entanglement", "holographic principle", "spatial computing",
            "RealityKit", "ARKit", "complex", "interaction", "data"
        ]
        var currentX: Float = -0.4
        let startY: Float = 0.3
        let lineHeight: Float = 0.1
        let wordSpacing: Float = 0.02
        var lineCount = 0

        for (index, word) in words.enumerated() {
            let wordMesh = MeshResource.generateText(word, extrusionDepth: 0.005, font: .systemFont(ofSize: 0.05))
            let wordMaterial = SimpleMaterial(color: .white, isMetallic: false)
            let wordEntity = ModelEntity(mesh: wordMesh, materials: [wordMaterial])

            // Calculate position relative to the document plane
            wordEntity.position = SIMD3<Float>(currentX, startY - Float(lineCount) * lineHeight, 0.005) // Slightly above plane
            documentAnchor.addChild(wordEntity)

            // Create a GazeTarget for this word.
            // The boundingBox should accurately represent the word's clickable area.
            // For simplicity, we'll use a rough estimate or the entity's generated bounding box.
            let localBoundingBox = wordEntity.visualBounds(relativeTo: wordEntity)
            let gazeTarget = GazeTarget(content: word, entity: wordEntity, boundingBox: localBoundingBox)
            gazeManager.addGazeTarget(gazeTarget)

            // Advance position for next word
            let wordWidth = localBoundingBox.extents.x
            currentX += wordWidth + wordSpacing

            // Wrap to next line if needed (very basic logic)
            if currentX > 0.4 && index < words.count - 1 {
                currentX = -0.4
                lineCount += 1
            }
        }
        print("Mock document and gaze targets set up.")
    }

    /// Starts the entire gaze-driven AI system.
    func start() {
        print("Starting Spatial Document Review App...")
        gazeManager.setupARSession()
    }

    /// Pauses the entire gaze-driven AI system.
    func pause() {
        print("Pausing Spatial Document Review App...")
        gazeManager.pauseARSession()
    }
}

// MARK: - Usage Example (within a SwiftUI App structure for visionOS)

/*
 // This would typically be part of your main SwiftUI App file for visionOS.
 @main
 @available(visionOS 1.0, *)
 struct MySpatialApp: App {
     @StateObject private var appModel = SpatialDocumentReviewApp() // Use @StateObject for lifecycle

     var body: some Scene {
         WindowGroup {
             ContentView()
                 .onAppear {
                     appModel.start()
                 }
                 .onDisappear {
                     appModel.pause()
                 }
         }

         // Example of an ImmersiveSpace where the document might be displayed
         ImmersiveSpace(id: "DocumentViewer") {
             RealityView { content in
                 // Add the document anchor and entities to the RealityView content
                 content.add(appModel.realityScene.anchors.first!) // Assuming one main document anchor
             } update: { content in
                 // Update logic if needed
             }
         }
     }
 }

 // A placeholder ContentView for the WindowGroup
 @available(visionOS 1.0, *)
 struct ContentView: View {
     var body: some View {
         VStack {
             Text("Gaze-Driven Document Review")
                 .font(.largeTitle)
             Text("Look at terms in the immersive space to get definitions.")
                 .font(.title2)
         }
     }
 }
 */
