
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import UIKit
import AVFoundation
import Vision

// MARK: - FaceDetectionViewController
/// A basic UIViewController that demonstrates real-time face detection using AVFoundation for camera input
/// and Vision framework for image analysis.
///
/// This controller sets up a camera preview, captures video frames, and processes them
/// with `VNDetectFaceRectanglesRequest` to draw bounding boxes around detected faces.
@available(iOS 18.0, *) // Target modern iOS SDK for latest Swift and API features
class FaceDetectionViewController: UIViewController {

    // MARK: - AVFoundation Properties
    private var captureSession: AVCaptureSession!
    private var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    private var videoDataOutput: AVCaptureVideoDataOutput!
    /// A dedicated background queue for processing video frames from `AVCaptureVideoDataOutput`.
    /// This prevents blocking the main thread and ensures smooth camera capture.
    private let videoDataOutputQueue = DispatchQueue(label: "videoDataOutputQueue", qos: .userInitiated)

    // MARK: - Vision Properties
    /// A `CALayer` placed on top of the `videoPreviewLayer` to draw Vision detection results.
    private var detectionOverlayLayer: CALayer!

    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupCamera()
        setupVisionOverlay()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Ensure the preview layer and overlay layer resize correctly with the view's bounds.
        // This is crucial for correct coordinate mapping.
        videoPreviewLayer?.frame = view.bounds
        detectionOverlayLayer?.frame = view.bounds
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // It's important to stop the capture session when the view is no longer visible
        // to release camera resources and save battery.
        if captureSession?.isRunning == true {
            captureSession.stopRunning()
        }
    }

    // MARK: - Camera Setup
    /// Configures the `AVCaptureSession` to capture video from the device's back camera.
    /// This involves setting up input, output, and the preview layer.
    private func setupCamera() {
        captureSession = AVCaptureSession()
        // Use a common resolution preset for balance between quality and performance.
        captureSession.sessionPreset = .hd1280x720

        // 1. Find the desired camera device (e.g., back wide-angle camera).
        guard let backCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("ERROR: Unable to access back camera.")
            return
        }

        do {
            // 2. Create an `AVCaptureDeviceInput` from the camera device and add it to the session.
            let input = try AVCaptureDeviceInput(device: backCamera)
            if captureSession.canAddInput(input) {
                captureSession.addInput(input)
            } else {
                print("ERROR: Could not add camera input to session.")
                return
            }

            // 3. Setup `AVCaptureVideoDataOutput` to receive video frames for processing.
            videoDataOutput = AVCaptureVideoDataOutput()
            // Set the pixel format. `kCVPixelBufferPixelFormatTypeKey` with `kCVPixelFormatType_32BGRA`
            // is a common and Vision-compatible format.
            videoDataOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA)]
            // `alwaysDiscardsLateVideoFrames = true` is crucial for real-time performance.
            // It tells the output to drop frames if processing can't keep up,
            // preventing a backlog and maintaining responsiveness.
            videoDataOutput.alwaysDiscardsLateVideoFrames = true
            // Set the delegate to `self` to receive frames and specify a dedicated queue
            // for delegate calls, preventing main thread blocking.
            videoDataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)

            if captureSession.canAddOutput(videoDataOutput) {
                captureSession.addOutput(videoDataOutput)
            } else {
                print("ERROR: Could not add video data output to session.")
                return
            }

            // Ensure video orientation matches device orientation for correct preview and analysis.
            if let connection = videoDataOutput.connection(with: .video),
               connection.isSupportedVideoOrientation(UIDevice.current.orientation.toAVCaptureVideoOrientation()) {
                connection.videoOrientation = UIDevice.current.orientation.toAVCaptureVideoOrientation()
            }

            // 4. Setup `AVCaptureVideoPreviewLayer` to display the live camera feed.
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            videoPreviewLayer.videoGravity = .resizeAspectFill // Scale video to fill the layer's bounds
            videoPreviewLayer.frame = view.bounds
            view.layer.addSublayer(videoPreviewLayer) // Add it to the view's layer hierarchy

            // 5. Start the capture session on a background thread.
            // `startRunning()` is a blocking call, so it should not be on the main thread.
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                self?.captureSession.startRunning()
            }

        } catch {
            print("ERROR: Error setting up camera input: \(error.localizedDescription)")
        }
    }

    // MARK: - Vision Overlay Setup
    /// Sets up a `CALayer` on top of the video preview layer to draw Vision detection results.
    /// This separation helps manage drawing logic independently from the camera preview.
    private func setupVisionOverlay() {
        detectionOverlayLayer = CALayer()
        detectionOverlayLayer.frame = view.bounds
        // Add the overlay layer *above* the video preview layer to draw on top.
        videoPreviewLayer?.addSublayer(detectionOverlayLayer)
    }

    // MARK: - Vision Processing
    /// Performs a Vision request on the provided `CVPixelBuffer` and updates the UI with results.
    /// - Parameter pixelBuffer: The `CVPixelBuffer` containing the video frame to analyze.
    private func performVisionRequest(pixelBuffer: CVPixelBuffer) {
        // Create a `VNImageRequestHandler` with the `CVPixelBuffer`.
        // `orientation: .up` assumes the image is already correctly oriented for processing.
        // In a real app, you might need to derive this from `AVCaptureConnection.videoOrientation`.
        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])

        // Create a `VNDetectFaceRectanglesRequest`.
        // The completion handler will be called when Vision finishes processing the request.
        let faceDetectionRequest = VNDetectFaceRectanglesRequest { [weak self] request, error in
            guard let self = self else { return }

            if let error = error {
                print("Vision Face detection error: \(error.localizedDescription)")
                return
            }

            // Process the results on the main thread because UI updates must happen there.
            DispatchQueue.main.async {
                self.drawDetectedFaces(observations: request.results as? [VNFaceObservation])
            }
        }

        // Perform the request. This is a synchronous call on the current queue (`videoDataOutputQueue`).
        do {
            try imageRequestHandler.perform([faceDetectionRequest])
        } catch {
            print("ERROR: Failed to perform Vision request: \(error.localizedDescription)")
        }
    }

    /// Draws bounding boxes for detected faces on the `detectionOverlayLayer`.
    /// - Parameter observations: An array of `VNFaceObservation` objects, representing detected faces.
    private func drawDetectedFaces(observations: [VNFaceObservation]?) {
        // Clear all previous drawing layers to update with new detections.
        detectionOverlayLayer.sublayers?.forEach { $0.removeFromSuperlayer() }

        guard let observations = observations else { return }

        // Vision returns normalized coordinates (0 to 1) relative to the image's dimensions.
        // We need to convert these to the coordinate system of our `videoPreviewLayer`.
        for observation in observations {
            let boundingBox = observation.boundingBox // Normalized rect (0 to 1)
            // `videoPreviewLayer.layerRectConverted(fromMetadataOutputRect:)` is a utility method
            // that correctly transforms Vision's normalized bounding box to the layer's coordinate system,
            // taking into account `videoGravity` and orientation.
            let convertedRect = videoPreviewLayer.layerRectConverted(fromMetadataOutputRect: boundingBox)

            let shapeLayer = CALayer()
            shapeLayer.frame = convertedRect
            shapeLayer.borderColor = UIColor.red.cgColor
            shapeLayer.borderWidth = 2.0
            shapeLayer.cornerRadius = 5.0
            detectionOverlayLayer.addSublayer(shapeLayer)
        }
    }
}

// MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
/// Extension to `FaceDetectionViewController` to conform to `AVCaptureVideoDataOutputSampleBufferDelegate`.
/// This delegate protocol is essential for receiving captured video frames.
@available(iOS 18.0, *)
extension FaceDetectionViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    /// Called when a new video frame (sample buffer) is available from the camera.
    /// This method is called on the `videoDataOutputQueue` we specified during setup.
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Extract the `CVPixelBuffer` from the `CMSampleBuffer`.
        // `CVPixelBuffer` is the raw image data format that Vision works with.
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            return
        }

        // Perform the Vision request on this pixel buffer.
        performVisionRequest(pixelBuffer: pixelBuffer)
    }

    /// Called when a video frame is dropped by `AVCaptureVideoDataOutput`.
    /// This typically happens if `alwaysDiscardsLateVideoFrames` is true and processing
    /// cannot keep up with the incoming frame rate.
    func captureOutput(_ output: AVCaptureOutput, didDrop sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // print("Dropped frame") // Uncomment for debugging dropped frames/performance issues.
    }
}

// MARK: - UIDeviceOrientation to AVCaptureVideoOrientation Conversion
/// Helper extension to convert `UIDeviceOrientation` to `AVCaptureVideoOrientation`.
/// This is important for ensuring the camera feed and Vision analysis are correctly oriented.
extension UIDeviceOrientation {
    func toAVCaptureVideoOrientation() -> AVCaptureVideoOrientation {
        switch self {
        case .portrait: return .portrait
        case .portraitUpsideDown: return .portraitUpsideDown
        case .landscapeLeft: return .landscapeRight // Device rotated left, camera needs to rotate right
        case .landscapeRight: return .landscapeLeft // Device rotated right, camera needs to rotate left
        default: return .portrait // Default to portrait for unknown or flat orientations
        }
    }
}
