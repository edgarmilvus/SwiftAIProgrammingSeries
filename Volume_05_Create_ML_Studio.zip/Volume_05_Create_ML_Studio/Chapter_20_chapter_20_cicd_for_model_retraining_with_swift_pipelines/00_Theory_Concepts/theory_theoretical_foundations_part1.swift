
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    // Example: Programmatic retraining of an image classifier
    import CreateML
    import Foundation

    @available(macOS 10.15, *) // Create ML is macOS specific for training
    func retrainImageClassifier(
        trainingDataURL: URL,
        validationDataURL: URL? = nil,
        outputURL: URL
    ) async throws {
        print("Starting model retraining...")

        // Load training data - typically MLImageClassifier.DataSource.labeledDirectories
        // or MLImageClassifier.DataSource.labeledFiles(at:labeledBy:)
        let trainingData = try MLImageClassifier.DataSource.labeledDirectories(at: trainingDataURL)

        // Optionally load validation data
        let validationData: MLImageClassifier.DataSource?
        if let validationURL = validationDataURL {
            validationData = try MLImageClassifier.DataSource.labeledDirectories(at: validationURL)
        } else {
            validationData = nil
        }

        // Configure and train the model
        let parameters = MLImageClassifier.ModelParameters(
            featureExtractor: .scenePrint(revision: 2), // Or .resnet50
            validation: validationData != nil ? .dataSource(validationData!) : .none,
            maxIterations: 100,
            augmentation: .defaults,
            seed: 42
        )

        let classifier = try await MLImageClassifier(
            trainingData: trainingData,
            parameters: parameters
        )

        // Save the new model
        try classifier.write(to: outputURL)
        print("Model retraining complete. New model saved to: \(outputURL.path)")
    }

    // Example usage (in an async context)
    /*
    @available(macOS 10.15, *)
    func runPipeline() async {
        let trainingDataFolder = URL(fileURLWithPath: "/path/to/new/training_data")
        let outputModelPath = URL(fileURLWithPath: "/path/to/output/new_image_classifier.mlmodel")

        do {
            try await retrainImageClassifier(
                trainingDataURL: trainingDataFolder,
                outputURL: outputModelPath
            )
        } catch {
            print("Error during retraining: \(error.localizedDescription)")
        }
    }
    */
    