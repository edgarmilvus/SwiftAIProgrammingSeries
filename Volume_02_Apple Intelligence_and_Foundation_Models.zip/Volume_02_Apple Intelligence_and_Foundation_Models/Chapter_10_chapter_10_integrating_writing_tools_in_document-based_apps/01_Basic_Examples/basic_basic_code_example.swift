
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import UIKit // Essential for UI components like UIViewController and UITextView
import Foundation // Provides fundamental types and functionality

// MARK: - 1. BasicWritingToolsViewController Definition

/// A `UIViewController` subclass demonstrating the automatic integration of
/// Apple Intelligence Writing Tools within a standard `UITextView`.
///
/// On iOS 18.0 and later, when Apple Intelligence is available, `UITextView`
/// instances that are editable will automatically present Writing Tools
/// options (e.g., Rewrite, Proofread, Summarize) in their contextual menu
/// when text is selected.
///
/// This class explicitly targets iOS 18.0 and above, as Writing Tools are
/// an Apple Intelligence feature introduced with this OS version.
@available(iOS 18.0, *)
class BasicWritingToolsViewController: UIViewController {

    // MARK: - 2. UITextView Setup

    /// The `UITextView` instance where the user can input and edit text.
    /// This is the primary UI component that benefits from automatic Writing Tools integration.
    ///
    /// It's configured with basic styling and an initial placeholder text
    /// to guide the user on how to interact with Writing Tools.
    private lazy var textView: UITextView = {
        let textView = UITextView()
        // Crucial for Auto Layout: tells the system not to create default constraints.
        textView.translatesAutoresizingMaskIntoConstraints = false
        // Apply a system-preferred font for readability.
        textView.font = UIFont.preferredFont(forTextStyle: .body)
        // Add padding around the text content within the text view.
        textView.textContainerInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        // Set background color for visual separation.
        textView.backgroundColor = .systemBackground
        // Rounded corners for a modern UI aesthetic.
        textView.layer.cornerRadius = 8
        // A subtle border to define the text input area.
        textView.layer.borderColor = UIColor.systemGray3.cgColor
        textView.layer.borderWidth = 1
        // ESSENTIAL: The text view MUST be editable for Writing Tools to appear.
        // The system only offers tools for content that can be modified by the user.
        textView.isEditable = true
        // Provide initial text to demonstrate functionality.
        textView.text = "Welcome to your intelligent note pad! Type your thoughts here. You can select any part of this text, long-press (or right-click on Mac Catalyst), and explore Apple Intelligence Writing Tools. For instance, try rewriting this sentence to be more formal, or proofreading the entire paragraph for clarity and grammar."
        return textView
    }()

    // MARK: - 3. View Lifecycle and Layout

    /// Called after the controller's view is loaded into memory.
    /// This is where the UI components are added to the view hierarchy and configured.
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Intelligent Note Pad" // Set the navigation bar title.
        view.backgroundColor = .systemGroupedBackground // Set a background color for the view.

        // Add the configured `UITextView` as a subview to the controller's main view.
        view.addSubview(textView)

        // Activate Auto Layout constraints to position and size the `UITextView`.
        // These constraints pin the text view to the safe area of the superview,
        // providing a consistent margin around the text area.
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])

        // (Optional but good practice): Assign the view controller as the text view's delegate.
        // This allows the view controller to respond to text changes and other text view events.
        // While not strictly necessary for *enabling* Writing Tools, it's common for text editors.
        textView.delegate = self
    }

    // MARK: - 4. Helper for App Scene Setup

    /// A static helper method to create and return a `UINavigationController`
    /// wrapping an instance of `BasicWritingToolsViewController`.
    ///
    /// This method simplifies the process of setting up the initial view controller
    /// in an app's `SceneDelegate` or `AppDelegate`. It also includes a fallback
    /// for devices running older iOS versions, guiding the user towards the
    /// system requirements.
    ///
    /// - Returns: A `UINavigationController` with the `BasicWritingToolsViewController`
    ///            as its root, or a fallback view controller if iOS 18.0 is not available.
    static func createNavigationController() -> UINavigationController {
        if #available(iOS 18.0, *) {
            let viewController = BasicWritingToolsViewController()
            return UINavigationController(rootViewController: viewController)
        } else {
            // Fallback for devices not running iOS 18.0 or later.
            let fallbackVC = UIViewController()
            fallbackVC.view.backgroundColor = .systemRed
            let label = UILabel()
            label.translatesAutoresizingMaskIntoConstraints = false
            label.text = "Apple Intelligence Writing Tools require iOS 18.0 or later."
            label.textColor = .white
            label.numberOfLines = 0
            label.textAlignment = .center
            fallbackVC.view.addSubview(label)
            NSLayoutConstraint.activate([
                label.centerXAnchor.constraint(equalTo: fallbackVC.view.centerXAnchor),
                label.centerYAnchor.constraint(equalTo: fallbackVC.view.centerYAnchor),
                label.leadingAnchor.constraint(equalTo: fallbackVC.view.leadingAnchor, constant: 20),
                label.trailingAnchor.constraint(equalTo: fallbackVC.view.trailingAnchor, constant: -20)
            ])
            return UINavigationController(rootViewController: fallbackVC)
        }
    }
}

// MARK: - 5. UITextViewDelegate Conformance (Optional)

/// Extension for `BasicWritingToolsViewController` to conform to `UITextViewDelegate`.
/// This allows the view controller to receive notifications about text changes
/// and other user interactions with the `UITextView`.
@available(iOS 18.0, *)
extension BasicWritingToolsViewController: UITextViewDelegate {
    /// Tells the delegate that the text in the specified text view changed.
    ///
    /// While this method is not directly involved in *enabling* Writing Tools,
    /// it's useful for real-world applications to track user input,
    /// save changes, or perform other dynamic updates.
    ///
    /// - Parameter textView: The text view whose text changed.
    func textViewDidChange(_ textView: UITextView) {
        // In a real app, you might save the text, update a character count, etc.
        print("Text content updated.")
    }
}

/*
// MARK: - Conceptual App Setup in SceneDelegate

// To run this example, you would typically integrate it into your app's
// SceneDelegate (for apps targeting iOS 13+ and using Scenes) or AppDelegate
// (for older apps or single-scene setups).

// Example `SceneDelegate.swift` snippet:

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }

        window = UIWindow(windowScene: windowScene)
        // Use the helper method to create the initial navigation controller.
        let navigationController = BasicWritingToolsViewController.createNavigationController()
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
    }

    // Other SceneDelegate methods...
}
*/
