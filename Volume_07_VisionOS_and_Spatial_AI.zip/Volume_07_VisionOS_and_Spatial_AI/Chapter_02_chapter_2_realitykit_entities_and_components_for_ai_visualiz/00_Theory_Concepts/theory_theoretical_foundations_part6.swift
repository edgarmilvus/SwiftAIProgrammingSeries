
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.swift
// Description: Theoretical Foundations
// ==========================================

import RealityKit
import Observation // For @Observable

// This could be a component itself, or a property within a component
@available(iOS 18.0, *)
@Observable
class ObservableObjectDetectionData {
    var detectedObjects: [UUID: ObjectDetectionComponent] = [:] {
        didSet {
            // Potentially notify systems or trigger updates
            print("ObservableObjectDetectionData updated with \(detectedObjects.count) objects.")
        }
    }

    func update(from detections: [ObjectDetectionComponent]) {
        // Update logic, potentially merging or replacing
        detectedObjects.removeAll() // Simplified
        for detection in detections {
            detectedObjects[UUID()] = detection
        }
    }
}

// A custom RealityKit component that holds the observable AI data
@available(iOS 18.0, *)
struct ObservableAIComponent: Component {
    var aiData: ObservableObjectDetectionData
    // Other properties if needed

    init(aiData: ObservableObjectDetectionData) {
        self.aiData = aiData
    }
}

// A system that reacts to changes in ObservableAIComponent
@available(iOS 18.0, *)
struct ReactiveAIVisualizationSystem: System {
    static let query = EntityQuery(where: .has(ObservableAIComponent.self))

    init(scene: RealityKit.Scene) {
        // Systems don't directly "observe" in the SwiftUI sense,
        // but they can access the Observable object's current state on each update cycle.
        // For more direct reactivity, you might use Combine or custom notifications.
    }

    func update(context: SceneUpdateContext) {
        for entity in context.scene.performQuery(Self.query) {
            guard let observableComponent = entity.components[ObservableAIComponent.self] else { continue }

            // Access the observable data directly.
            // Changes to aiData.detectedObjects will be reflected here on the next update.
            let currentDetections = Array(observableComponent.aiData.detectedObjects.values)

            // Logic to update visual models based on currentDetections
            // This would be similar to the ObjectVisualizationSystem's logic,
            // but driven by the @Observable data source.
            for detection in currentDetections {
                // ... create/update ModelEntity for each detection ...
            }
        }
    }
}

// How to integrate:
@available(iOS 18.0, *)
class ARAppCoordinator: NSObject, ARSessionDelegate {
    let arView: ARView
    let aiProcessor: AIProcessor
    let observableAIData = ObservableObjectDetectionData() // Instantiate the observable data

    init(arView: ARView, aiModel: VNCoreMLModel) {
        self.arView = arView
        self.aiProcessor = AIProcessor(model: aiModel)
        super.init()
        arView.session.delegate = self

        // Register the reactive system
        ReactiveAIVisualizationSystem.registerSystem()

        // Create a central entity to hold the observable AI data
        let aiDataEntity = Entity()
        aiDataEntity.name = "Global_AI_Data_Entity"
        aiDataEntity.components.set(ObservableAIComponent(aiData: observableAIData))
        arView.scene.addAnchor(AnchorEntity(world: .zero)) // Attach to a global anchor
    }

    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        Task {
            do {
                let detections = try await aiProcessor.processFrame(frame.capturedImage, transform: frame.camera.transform)
                await MainActor.run {
                    // Update the observable data on the main actor to ensure UI/scene updates are safe
                    self.observableAIData.update(from: detections)
                }
            } catch {
                print("AI processing error: \(error)")
            }
        }
    }
}
