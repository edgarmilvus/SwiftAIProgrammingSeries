
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Vision
import CoreML
import PhotosUI

// 1. ModelManager Actor to handle heavy lifting and ensure thread safety
actor ModelManager {
    private var classificationRequest: VNCoreMLRequest?

    init() async throws {
        // In a real app, use: let model = try MobileNetV2(configuration: .init())
        // For this example, we assume a compiled CoreML model exists.
        let config = MLModelConfiguration()
        let model = try VNCoreMLModel(for: MobileNetV2(configuration: config).model)
        
        self.classificationRequest = VNCoreMLRequest(model: model) { _, _ in }
    }

    func classify(image: CGImage) async throws -> [VNClassificationObservation] {
        guard let request = classificationRequest else { throw ModelError.notInitialized }
        
        return try await withCheckedThrowingContinuation { continuation in
            let handler = VNImageRequestHandler(cgImage: image, options: [:])
            
            do {
                // Perform request on a background thread
                try handler.perform([request])
                
                // Extract results from the request
                let results = request.results as? [VNClassificationObservation] ?? []
                continuation.resume(returning: results.sorted(by: { $0.confidence > $1.confidence }))
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
    
    enum ModelError: Error {
        case notInitialized
    }
}

struct ImageInspectorView: View {
    @State private var selectedItem: PhotosPickerItem?
    @State private var selectedImage: UIImage?
    @State private var classifications: [VNClassificationObservation] = []
    @State private var isProcessing = false
    
    // Initialize the actor
    @State private var modelManager: ModelManager?

    var body: some View {
        VStack(spacing: 20) {
            if let selectedImage {
                Image(uiImage: selectedImage)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 400)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }

            PhotosPicker(selection: $selectedItem, matching: .images) {
                Label("Select Photo", systemImage: "photo.on.rectangle")
            }
            .onChange(of: selectedItem) { _, newItem in
                Task { await processSelectedImage(newItem) }
            }

            if isProcessing {
                ProgressView("Analyzing...")
            } else {
                GroupBox("Top Classifications") {
                    List(classifications.prefix(3), id: \.identifier) { observation in
                        HStack {
                            Text(observation.identifier)
                            Spacer()
                            Text(String(format: "%.2f%%", observation.confidence * 100))
                                .foregroundStyle(.secondary)
                        }
                    }
                    .listStyle(.plain)
                }
                .frame(height: 150)
            }
        }
        .padding()
        .task {
            // Initialize the actor asynchronously
            do {
                self.modelManager = try await ModelManager()
            } catch {
                print("Failed to load model: \(error)")
            }
        }
    }

    @MainActor
    private func processSelectedImage(_ item: PhotosPickerItem?) async {
        guard let item else { return }
        isProcessing = true
        
        // 1. Load image data
        guard let data = try? await item.loadTransferable(type: Data.self),
              let uiImage = UIImage(data: data),
              let cgImage = uiImage.cgImage else {
            isProcessing = false
            return
        }
        
        self.selectedImage = uiImage
        
        // 2. Perform inference via the Actor
        do {
            if let manager = modelManager {
                // The heavy work happens in the actor, not the MainActor
                let results = try await manager.classify(image: cgImage)
                self.classifications = results
            }
        } catch {
            print("Inference error: \(error)")
        }
        
        isProcessing = false
    }
}
