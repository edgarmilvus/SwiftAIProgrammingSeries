
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, visionOS 2.0, *)
import SwiftData
import Foundation // For Date and ValueTransformer

// MARK: - Custom Types

// 1. Emotion Enum: Codable and RawRepresentable for direct SwiftData persistence
enum Emotion: String, Codable, CaseIterable, Identifiable {
    case joy, sadness, anger, neutral, surprise

    var id: String { self.rawValue } // Conformance to Identifiable for UI purposes

    // Helper for generating an AppColor based on emotion
    var defaultColor: AppColor {
        switch self {
        case .joy: return AppColor(red: 1.0, green: 0.8, blue: 0.0) // Yellow
        case .sadness: return AppColor(red: 0.2, green: 0.4, blue: 0.8) // Blue
        case .anger: return AppColor(red: 0.8, green: 0.2, blue: 0.2) // Red
        case .neutral: return AppColor(red: 0.6, green: 0.6, blue: 0.6) // Gray
        case .surprise: return AppColor(red: 1.0, green: 0.6, blue: 0.0) // Orange
        }
    }
}

// 2. AppColor Struct: Codable for ValueTransformer
struct AppColor: Codable, Equatable {
    var red: Double
    var green: Double
    var blue: Double
}

// MARK: - Custom Value Transformer

// 3. AppColorTransformer: Converts AppColor to Data and vice-versa
@objc(AppColorTransformer) // Required for ValueTransformer registration
class AppColorTransformer: ValueTransformer {
    override class func transformedValueClass() -> AnyClass {
        NSData.self
    }

    override class func allowsReverseTransformation() -> Bool {
        true
    }

    override func transformedValue(_ value: Any?) -> Any? {
        guard let color = value as? AppColor else { return nil }
        do {
            let data = try JSONEncoder().encode(color)
            return data as NSData
        } catch {
            print("Error encoding AppColor: \(error)")
            return nil
        }
    }

    override func reverseTransformedValue(_ value: Any?) -> Any? {
        guard let data = value as? NSData else { return nil }
        do {
            let color = try JSONDecoder().decode(AppColor.self, from: data as Data)
            return color
        } catch {
            print("Error decoding AppColor: \(error)")
            return nil
        }
    }
}

// MARK: - ValueTransformer Registration
// This must be called before a ModelContainer is initialized.
// A good place is in your App struct's init() or a static initializer.
func registerAppColorTransformer() {
    ValueTransformer.setValueTransformer(AppColorTransformer(), forName: NSValueTransformerName("AppColorTransformer"))
}

// MARK: - EmotionLog Model

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, visionOS 2.0, *)
@Model
class EmotionLog {
    var timestamp: Date
    var recordedEmotion: Emotion // SwiftData handles Codable enums directly
    @Attribute(.transformable(by: "AppColorTransformer")) // Use the custom transformer
    var associatedColor: AppColor

    // Transient property: Not persisted in the database
    @Transient var emotionalIntensity: Int {
        switch recordedEmotion {
        case .joy, .anger: return 10
        case .sadness, .surprise: return 7
        case .neutral: return 3
        }
    }

    init(timestamp: Date = Date(), recordedEmotion: Emotion, associatedColor: AppColor) {
        self.timestamp = timestamp
        self.recordedEmotion = recordedEmotion
        self.associatedColor = associatedColor
    }
}
