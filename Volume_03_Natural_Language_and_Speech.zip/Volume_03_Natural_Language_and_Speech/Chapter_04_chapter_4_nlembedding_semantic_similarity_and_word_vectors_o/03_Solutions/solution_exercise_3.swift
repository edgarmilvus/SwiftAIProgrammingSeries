
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

    // Conceptual example for parallelizing candidate processing
    // func findRelated(to targetArticle: Article, from candidates: [Article], count: Int) async -> [Article] {
    //     // ... get finalTargetEmbedding ...
    //     var similarities: [(article: Article, score: Double)] = []
    //
    //     await withTaskGroup(of: (Article, Double)?.self) { group in
    //         for candidate in candidates where candidate.id != targetArticle.id {
    //             group.addTask {
    //                 if let candidateEmbedding = candidate.embedding ?? self.averageWordEmbedding(for: candidate.summary) {
    //                     let score = self.embeddingModel?.similarity(for: finalTargetEmbedding, to: candidateEmbedding) ?? 0.0
    //                     return (candidate, score)
    //                 }
    //                 return nil
    //             }
    //         }
    //         for await result in group {
    //             if let (article, score) = result {
    //                 similarities.append((article: article, score: score))
    //             }
    //         }
    //     }
    //     return similarities.sorted { $0.score > $1.score }.prefix(count).map { $0.article }
    // }
    