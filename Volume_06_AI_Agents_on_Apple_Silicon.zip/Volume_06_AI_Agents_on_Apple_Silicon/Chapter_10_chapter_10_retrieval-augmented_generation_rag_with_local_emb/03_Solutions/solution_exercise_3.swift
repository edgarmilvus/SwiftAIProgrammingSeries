
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import SwiftData
import LlamaCpp
import PDFKit // Required for PDF parsing on macOS

// Reusing KnowledgeChunk, EmbeddingService, LlamaCppEmbeddingService, TextChunker, SimpleTextChunker,
// Array<Float> extensions, and KnowledgeIngestor from previous exercises.
// Also reusing cosineSimilarity from Exercise 2.

// MARK: - 1. Document Ingestion & Processing

// Advanced Text Chunker with better overlap strategy
class AdvancedTextChunker: TextChunker {
    func chunk(text: String, maxChunkSize: Int, overlapSize: Int) -> [String] {
        var chunks: [String] = []
        let sentences = text.split(separator: ". ")
                                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) + ( $0.hasSuffix(".") ? "" : "." ) }
                                .filter { !$0.isEmpty && $0 != "." }

        var currentChunk = ""
        for sentence in sentences {
            if (currentChunk + " " + sentence).count <= maxChunkSize {
                currentChunk += (currentChunk.isEmpty ? "" : " ") + sentence
            } else {
                // Current chunk is full, add it
                if !currentChunk.isEmpty {
                    chunks.append(currentChunk)
                }

                // Start new chunk with overlap
                var overlapContent = ""
                if overlapSize > 0 && currentChunk.count > overlapSize {
                    let startIndex = currentChunk.index(currentChunk.endIndex, offsetBy: -overlapSize, limitedBy: currentChunk.startIndex) ?? currentChunk.startIndex
                    overlapContent = String(currentChunk[startIndex...])
                }
                currentChunk = overlapContent + (overlapContent.isEmpty ? "" : " ") + sentence
            }
        }
        if !currentChunk.isEmpty {
            chunks.append(currentChunk)
        }
        return chunks.filter { !$0.isEmpty }
    }
}

enum DocumentProcessorError: Error, LocalizedError {
    case fileNotFound
    case unsupportedFileType
    case pdfParsingFailed(String)
    case textLoadingFailed(String)

    var errorDescription: String? {
        switch self {
        case .fileNotFound: return "Document file not found."
        case .unsupportedFileType: return "Unsupported file type. Only .txt and .pdf are supported."
        case .pdfParsingFailed(let message): return "Failed to parse PDF: \(message)"
        case .textLoadingFailed(let message): return "Failed to load text file: \(message)"
        }
    }
}

@available(macOS 15.0, *)
class DocumentProcessor {
    private let modelContext: ModelContext
    private let embeddingService: EmbeddingService
    private let chunker: TextChunker

    init(modelContext: ModelContext, embeddingService: EmbeddingService, chunker: TextChunker) {
        self.modelContext = modelContext
        self.embeddingService = embeddingService
        self.chunker = chunker
    }

    func ingestDocument(url: URL, maxChunkSize: Int = 512, overlapSize: Int = 100) async throws {
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw DocumentProcessorError.fileNotFound
        }

        let fileExtension = url.pathExtension.lowercased()
        let documentIdentifier = url.lastPathComponent
        var documentText = ""

        print("Processing document: \(documentIdentifier)")

        switch fileExtension {
        case "txt":
            do {
                documentText = try String(contentsOf: url, encoding: .utf8)
            } catch {
                throw DocumentProcessorError.textLoadingFailed(error.localizedDescription)
            }
        case "pdf":
            guard let pdfDocument = PDFDocument(url: url) else {
                throw DocumentProcessorError.pdfParsingFailed("Could not create PDFDocument from URL.")
            }
            guard let text = pdfDocument.string else {
                throw DocumentProcessorError.pdfParsingFailed("Could not extract text from PDF.")
            }
            documentText = text
        default:
            throw DocumentProcessorError.unsupportedFileType
        }

        print("Document text extracted. Ingesting chunks...")
        let ingestor = KnowledgeIngestor(modelContext: modelContext, embeddingService: embeddingService, chunker: chunker)
        try await ingestor.ingestText(text: documentText, sourceURL: url, documentIdentifier: documentIdentifier, maxChunkSize: maxChunkSize, overlapSize: overlapSize)
        print("Document '\(documentIdentifier)' successfully ingested.")
    }
}

// MARK: - 3. Local LLM Integration (using llama.cpp.swift)

enum LLMServiceError: Error, LocalizedError {
    case modelNotLoaded
    case generationFailed(String)

    var errorDescription: String? {
        switch self {
        case .modelNotLoaded: return "LLM model is not loaded or initialized."
        case .generationFailed(let message): return "LLM generation failed: \(message)"
        }
    }
}

class LlamaCppLLMService: LLMService {
    private var llamaCpp: LlamaCpp?
    private let modelPath: String
    private let modelLock = NSLock() // To ensure thread-safe model initialization

    init(modelPath: String) {
        self.modelPath = modelPath
    }

    func loadModel() async throws {
        modelLock.lock()
        defer { modelLock.unlock() }

        guard llamaCpp == nil else { return } // Model already loaded

        let url = URL(fileURLWithPath: modelPath)
        guard FileManager.default.fileExists(atPath: modelPath) else {
            throw LLMServiceError.modelNotLoaded
        }

        do {
            llamaCpp = try await Task.detached(priority: .userInitiated) {
                // Note: For LLM, embedding should be false
                try LlamaCpp(modelPath: url.path, embedding: false)
            }.value
            print("LlamaCpp LLM model loaded successfully from: \(modelPath)")
        } catch {
            print("Failed to load LlamaCpp LLM model: \(error.localizedDescription)")
            throw LLMServiceError.modelNotLoaded
        }
    }

    func generateResponse(prompt: String) async throws -> String {
        try await loadModel() // Ensure model is loaded

        guard let llamaCpp = self.llamaCpp else {
            throw LLMServiceError.modelNotLoaded
        }

        do {
            // LlamaCpp.generateResponse is typically synchronous but can be long-running.
            // Wrap in Task.detached to avoid blocking the caller's actor.
            let response = try await Task.detached(priority: .userInitiated) {
                // These parameters might need tuning based on the LLM model
                try llamaCpp.generateResponse(
                    text: prompt,
                    temperature: 0.7,
                    topK: 40,
                    topP: 0.9,
                    nPredict: 256 // Max tokens to generate
                )
            }.value
            return response.trimmingCharacters(in: .whitespacesAndNewlines)
        } catch {
            throw LLMServiceError.generationFailed(error.localizedDescription)
        }
    }
}

// MARK: - 2. RAG Chat Interface (integrated into main app)

@available(macOS 15.0, *)
class RAGChatbot {
    private let modelContext: ModelContext
    private let embeddingService: EmbeddingService
    private let llmService: LLMService

    init(modelContext: ModelContext, embeddingService: EmbeddingService, llmService: LLMService) {
        self.modelContext = modelContext
        self.embeddingService = embeddingService
        self.llmService = llmService
    }

    func chatWithDocuments(query: String, topK: Int = 5, maxContextTokens: Int = 1024) async throws -> String {
        print("Generating embedding for query...")
        let queryEmbedding = try await embeddingService.generateEmbedding(for: query)

        let storedChunks = try modelContext.fetch(FetchDescriptor<KnowledgeChunk>())
        
        var rankedChunks: [(KnowledgeChunk, Float)] = []
        for chunk in storedChunks {
            guard let storedEmbedding = Array<Float>(data: chunk.embeddingData) else { continue }
            if let similarity = cosineSimilarity(vectorA: queryEmbedding, vectorB: storedEmbedding) {
                rankedChunks.append((chunk, similarity))
            }
        }
        
        let sortedChunks = rankedChunks.sorted { $0.1 > $1.1 }
        
        var contextText = ""
        var currentContextTokens = 0
        var retrievedChunkCount = 0

        // Select top K chunks, but also respect max context token limit
        for (chunk, _) in sortedChunks {
            if retrievedChunkCount >= topK { break }
            let chunkContent = chunk.content
            // Estimate tokens by character count (rough, better with a real tokenizer)
            let estimatedTokens = chunkContent.count / 4 // Rough estimate
            
            if currentContextTokens + estimatedTokens <= maxContextTokens {
                contextText += (contextText.isEmpty ? "" : "\n\n") + chunkContent
                currentContextTokens += estimatedTokens
                retrievedChunkCount += 1
            } else {
                break // Stop adding chunks if context window is full
            }
        }

        print("Retrieved \(retrievedChunkCount) relevant chunks for context.")

        let llmPrompt = """
        You are a helpful assistant. Answer the following question based ONLY on the provided context.
        If the answer cannot be found in the context, state that you don't have enough information in a polite way.
        Do not make up information.

        Context:
        \(contextText)

        Question: \(query)

        Answer:
        """
        
        print("Sending prompt to local LLM...")
        let llmResponse = try await llmService.generateResponse(prompt: llmPrompt)
        return llmResponse
    }
}

// MARK: - CLI Application Entry Point (for demonstration)

@main
@available(macOS 15.0, *)
struct RAGChatApp {
    static let embeddingModelPath = "/path/to/your/embedding_model.gguf" // !!! REPLACE THIS !!!
    static let llmModelPath = "/path/to/your/llm_model.gguf" // !!! REPLACE THIS !!!

    static func main() async {
        // --- SwiftData Setup ---
        let schema = Schema([KnowledgeChunk.self])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredDynamically: true)
        guard let modelContainer = try? ModelContainer(for: schema, configurations: [modelConfiguration]) else {
            fatalError("Failed to create ModelContainer.")
        }
        let modelContext = ModelContext(modelContainer)

        // --- Embedding Service Setup ---
        guard let embeddingModelBundlePath = Bundle.main.path(forResource: "all-MiniLM-L6-v2-f16", ofType: "gguf") else {
            print("Error: Embedding model 'all-MiniLM-L6-v2-f16.gguf' not found in bundle.")
            print("Please download a .gguf embedding model and add it to your Xcode project's resources.")
            return
        }
        let embeddingService = LlamaCppEmbeddingService(modelPath: embeddingModelBundlePath)
        print("Attempting to load embedding model from: \(embeddingModelBundlePath)")
        do {
            try await embeddingService.loadModel()
            print("Embedding model loaded successfully.")
        } catch {
            print("Failed to load embedding model: \(error.localizedDescription)")
            return
        }

        // --- LLM Service Setup ---
        guard let llmModelBundlePath = Bundle.main.path(forResource: "tinyllama-1.1b-chat-v1.0.Q4_K_M", ofType: "gguf") else {
            print("Error: LLM model 'tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf' not found in bundle.")
            print("Please download a .gguf LLM model (e.g., TinyLlama) and add it to your Xcode project's resources.")
            return
        }
        let llmService = LlamaCppLLMService(modelPath: llmModelBundlePath)
        print("Attempting to load LLM model from: \(llmModelBundlePath)")
        do {
            try await llmService.loadModel()
            print("LLM model loaded successfully.")
        } catch {
            print("Failed to load LLM model: \(error.localizedDescription)")
            return
        }

        // --- Chunker & Processor Setup ---
        let chunker = AdvancedTextChunker()
        let documentProcessor = DocumentProcessor(modelContext: modelContext, embeddingService: embeddingService, chunker: chunker)
        let chatbot = RAGChatbot(modelContext: modelContext, embeddingService: embeddingService, llmService: llmService)

        // --- CLI Loop ---
        print("\n--- RAG Chatbot CLI ---")
        print("Commands: 'ingest <filepath>', 'chat <query>', 'list', 'exit'.")
        print("Example: 'ingest /Users/youruser/Documents/my_article.pdf'")

        while true {
            print("\nEnter command: ", terminator: "")
            guard let input = readLine() else { continue }
            let components = input.split(separator: " ", maxSplits: 1).map(String.init)
            let command = components.first?.lowercased() ?? ""
            let argument = components.count > 1 ? components[1] : ""

            switch command {
            case "ingest":
                if argument.isEmpty {
                    print("Usage: ingest <filepath>")
                    continue
                }
                let filePath = (argument as NSString).expandingTildeInPath
                let fileURL = URL(fileURLWithPath: filePath)
                do {
                    try await documentProcessor.ingestDocument(url: fileURL)
                    print("Document ingestion complete.")
                } catch {
                    print("Document ingestion failed: \(error.localizedDescription)")
                }
            case "chat":
                if argument.isEmpty {
                    print("Usage: chat <query>")
                    continue
                }
                do {
                    print("Thinking...")
                    let response = try await chatbot.chatWithDocuments(query: argument, topK: 5)
                    print("\n--- Bot Response ---")
                    print(response)
                    print("--------------------")
                } catch {
                    print("Chat failed: \(error.localizedDescription)")
                }
            case "list":
                do {
                    let chunks = try modelContext.fetch(FetchDescriptor<KnowledgeChunk>())
                    if chunks.isEmpty {
                        print("No knowledge chunks found.")
                    } else {
                        print("\n--- Stored Knowledge Chunks ---")
                        for (index, chunk) in chunks.enumerated() {
                            print("Chunk \(index + 1) (ID: \(chunk.id.uuidString.prefix(8))):")
                            print("  Document: \(chunk.documentIdentifier ?? "N/A")")
                            print("  Content: \(chunk.content.prefix(100))...")
                            print("--------------------")
                        }
                    }
                } catch {
                    print("Failed to fetch chunks: \(error.localizedDescription)")
                }
            case "exit":
                print("Exiting.")
                return
            default:
                print("Unknown command. Try 'ingest <filepath>', 'chat <query>', 'list', or 'exit'.")
            }
        }
    }
}
