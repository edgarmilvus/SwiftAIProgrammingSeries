
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
import MLX
import MLXNN
import Foundation // For basic file operations if loading weights

// Define a simple vision model for demonstration purposes
class SimpleVisionModel: MLXNN.Module {
    let conv1: MLXNN.Conv2d
    let pool: MLXNN.MaxPool2d
    let flatten: MLXNN.Flatten
    let linear: MLXNN.Linear

    init() {
        self.conv1 = MLXNN.Conv2d(inputChannels: 3, outputChannels: 16, kernelSize: 3, padding: 1)
        self.pool = MLXNN.MaxPool2d(kernelSize: 2, stride: 2)
        // Assuming input images are 28x28.
        // After conv1 (outputChannels=16, kernel=3, padding=1), shape is 16x28x28.
        // After pool (kernel=2, stride=2), shape is 16x14x14.
        self.flatten = MLXNN.Flatten()
        self.linear = MLXNN.Linear(inputFeatures: 16 * 14 * 14, outputFeatures: 128) // Output 128-dim embedding
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        var x = input
        x = MLXNN.relu(conv1(x))
        x = pool(x)
        x = flatten(x)
        x = linear(x)
        return x
    }
}

// You will need to implement a function to load model weights
// For this exercise, you can initialize the model and consider its parameters as loaded.
// In a real scenario, you'd load from a .safetensors or similar file.
func loadVisionModel() -> SimpleVisionModel {
    let model = SimpleVisionModel()
    // In a real app, you'd load weights here:
    // try? model.load(safetensors: "path/to/weights.safetensors")
    print("Vision model loaded with \(model.parameters().count) parameters.")
    return model
}

// Implement this function
func generateEmbeddings(model: SimpleVisionModel, for images: [MLXArray]) -> MLXArray {
    // Stack the individual image MLXArrays into a single batch MLXArray.
    // axis: 0 means the batch dimension will be the first dimension.
    let batchedInput = MLXArray.stack(images, axis: 0)
    print("Batched input shape: \(batchedInput.shape)")

    // Perform forward pass through the model
    let embeddings = model(batchedInput)
    return embeddings
}

// Example usage structure:
@available(iOS 18.0, macOS 15.0, *)
func exercise1Example() {
    print("--- Exercise 1: Memory-Efficient Image Embedding ---")

    // --- Memory Observation: Model Loading Phase ---
    // Use Xcode Instruments (Memory Allocations) here to observe peak memory during model loading.
    // Or os_signpost for programmatic tracking.
    let model = loadVisionModel()
    print("Model parameters memory footprint: \(estimateMemoryFootprint(model: model) / (1024.0 * 1024.0)) MB")

    var dummyImages: [MLXArray] = []
    let batchSize = 4
    let imageChannels = 3
    let imageHeight = 28
    let imageWidth = 28

    print("Creating \(batchSize) dummy images...")
    for i in 0..<batchSize { // Simulate a batch of 4 images
        // Create dummy image data (e.g., 3x28x28 for a simple model)
        // Ensure the shape matches what the model expects (C, H, W for MLXNN.Conv2d)
        let dummyImage = MLXArray.randomUniform(low: 0, high: 1, shape: [imageChannels, imageHeight, imageWidth])
        dummyImages.append(dummyImage)
        print("  Dummy image \(i+1) created, shape: \(dummyImage.shape), dtype: \(dummyImage.dtype)")
    }

    // --- Memory Observation: Batch Inference Call ---
    // Use Xcode Instruments (Memory Allocations) here to observe memory during inference.
    // Or os_signpost for programmatic tracking.
    print("Generating embeddings for the batch...")
    let embeddings = generateEmbeddings(model: model, for: dummyImages)
    print("Generated embeddings shape: \(embeddings.shape), dtype: \(embeddings.dtype)")

    // Observe memory after inference
    print("--- End Exercise 1 ---")
}

// Helper to estimate memory (reused from Exercise 2 guidance)
@available(iOS 18.0, macOS 15.0, *)
func estimateMemoryFootprint(model: MLXNN.Module) -> Int {
    return model.parameters().values.reduce(0) { $0 + $1.nbytes }
}

// Call the example function to run the exercise
// exercise1Example() // Uncomment to run
