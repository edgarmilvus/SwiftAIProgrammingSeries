
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CoreML
import Observation

// MARK: - Package Dependencies (Conceptual)
/*
 [Package.swift]
 dependencies: [
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0"),
    .package(url: "https://github.com/apple/swift-collections", from: "1.1.0")
 ]
*/

/// Represents the various safety classifications for AI-generated content.
/// Conforms to `Sendable` to ensure safe transfer across concurrency domains.
enum SafetyClassification: String, Sendable, Codable {
    case safe = "safe"
    case toxic = "toxic"
    case hateSpeech = "hate_speech"
    case sexuallyExplicit = "sexually_explicit"
    case dangerousActivity = "dangerous_activity"
    case unknown = "unknown"
}

/// Errors specifically related to the content moderation lifecycle.
enum SafetyError: LocalizedError, Sendable {
    case promptViolation(SafetyClassification)
    case responseViolation(SafetyClassification)
    case moderationTimeout
    case hardwareAccelerationFailure
    
    var errorDescription: String? {
        switch self {
        case .promptViolation(let type):
            return "Your request was flagged for: \(type.rawValue.replacingOccurrences(of: "_", with: " "))."
        case .responseViolation(let type):
            return "The generated content was blocked due to safety concerns: \(type.rawValue)."
        case .moderationTimeout:
            return "Safety check timed out. Please try again."
        case .hardwareAccelerationFailure:
            return "Internal safety engine error."
        }
    }
}

/// A protocol defining the requirements for a moderation strategy.
/// This allows us to swap between Local (CoreML) and Remote (API) strategies.
protocol ModerationStrategy: Sendable {
    /// Analyzes a string of text for safety violations.
    /// - Parameter text: The content to analyze.
    /// - Returns: A classification result.
    func classify(text: String) async throws -> SafetyClassification
}

// MARK: - Concrete Strategies

/// A local, on-device moderation strategy using CoreML.
/// This is critical for low-latency "Pre-Generation" checks.
@available(iOS 18.0, *)
final class LocalCoreMLGuardrail: ModerationStrategy {
    // In a real app, this would be a compiled .mlmodel
    // private let model: ToxicityClassifier 

    func classify(text: String) async throws -> SafetyClassification {
        // Simulate CoreML inference latency
        try await Task.sleep(for: .milliseconds(150))
        
        // Mock logic: In production, this uses model.prediction(text)
        if text.lowercased().contains("bad_word") {
            return .toxic
        }
        return .safe
    }
}

/// A remote moderation strategy using a cloud-based API (e.g., OpenAI Moderation or custom backend).
/// This is used for high-accuracy "Post-Generation" checks.
final class RemoteAPIGuardrail: ModerationStrategy {
    private let endpoint = URL(string: "https://api.safety-check.com/v1/moderate")!
    private let apiKey: String

    init(apiKey: String) {
        self.apiKey = apiKey
    }

    func classify(text: String) async throws -> SafetyClassification {
        // Simulate network latency
        try await Task.sleep(for: .seconds(0.5))
        
        // In production: URLSession request with JSON body
        // For demonstration, we simulate a successful safe response
        return .safe
    }
}

// MARK: - The Safety Orchestrator

/// The `SafetyOrchestrator` is the central authority for all content safety decisions.
/// It is implemented as an `actor` to ensure that the internal state (like blacklisted terms)
/// is protected from data races in a highly concurrent environment.
actor SafetyOrchestrator {
    
    private let localGuardrail: ModerationStrategy
    private let remoteGuardrail: ModerationStrategy
    
    /// A set of user-reported or system-flagged terms that trigger immediate rejection.
    private var blacklist: Set<String> = []
    
    /// Tracks the history of safety violations for audit purposes (required for App Review).
    private(set) var violationLog: [SafetyClassification] = []

    init(local: ModerationStrategy, remote: ModerationStrategy) {
        self.localGuardrail = local
        self.remoteGuardrail = remote
    }

    /// The primary entry point for validating a user's prompt.
    /// Uses a "Fail-Fast" approach: if local checks fail, we don't waste API credits.
    /// - Parameter prompt: The raw input from the user.
    /// - Returns: A validated prompt if safe; otherwise throws a `SafetyError`.
    func validatePrompt(_ prompt: String) async throws -> String {
        // 1. Check against local blacklist (O(1) lookup)
        for word in blacklist {
            if prompt.lowercased().contains(word.lowercased()) {
                throw SafetyError.promptViolation(.toxic)
            }
        }

        // 2. Run Local CoreML Guardrail
        let localResult = try await localGuardrail.classify(text: prompt)
        guard localResult == .safe else {
            logViolation(localResult)
            throw SafetyError.promptViolation(localResult)
        }

        // 3. (Optional) Run Remote Guardrail for high-sensitivity prompts
        // We use TaskGroup to allow for future expansion where multiple remote checks might run.
        return try await withThrowingTaskGroup(of: SafetyClassification.self) { group in
            group.addTask {
                try await self.remoteGuardrail.classify(text: prompt)
            }
            
            let remoteResult = try await group.next() ?? .safe
            
            if remoteResult != .safe {
                logViolation(remoteResult)
                throw SafetyError.promptViolation(remoteResult)
            }
            
            return prompt
        }
    }

    /// Validates the content generated by the AI model.
    /// This is the "Post-Generation" check.
    func validateResponse(_ response: String) async throws -> String {
        // Post-generation checks usually rely more heavily on remote, high-parameter models
        // because local models may lack the nuance to catch sophisticated toxicity.
        let result = try await remoteGuardrail.classify(text: response)
        
        guard result == .safe else {
            logViolation(result)
            throw SafetyError.responseViolation(result)
        }
        
        return response
    }

    /// Adds a term to the blacklist based on user reports or system detection.
    func blacklistTerm(_ term: String) {
        blacklist.insert(term.lowercased())
    }

    private func logViolation(_ type: SafetyClassification) {
        violationLog.append(type)
        // In production, this would also trigger a telemetry event to your backend.
    }
}

// MARK: - UI Integration Layer

/// A ViewModel that manages the state of the AI interaction, 
/// observing the `SafetyOrchestrator`.
@Observable
@MainActor
final class ChatViewModel {
    var messages: [String] = []
    var isProcessing: Bool = false
    var errorMessage: String?
    
    private let safetyEngine: SafetyOrchestrator

    init(safetyEngine: SafetyOrchestrator) {
        self.safetyEngine = safetyEngine
    }

    /// Simulates the end-to-end flow of sending a prompt and receiving an AI response.
    func sendMessage(_ text: String) async {
        isProcessing = true
        errorMessage = nil
        
        do {
            // Step 1: Validate the prompt (Pre-generation)
            let validatedPrompt = try await safetyEngine.validatePrompt(text)
            messages.append("User: \(validatedPrompt)")
            
            // Step 2: Simulate AI Generation (The actual LLM call)
            let aiResponse = try await simulateLLMCall(with: validatedPrompt)
            
            // Step 3: Validate the response (Post-generation)
            let safeResponse = try await safetyEngine.validateResponse(aiResponse)
            messages.append("AI: \(safeResponse)")
            
        } catch let error as SafetyError {
            self.errorMessage = error.localizedDescription
        } catch {
            self.errorMessage = "An unexpected error occurred."
        }
        
        isProcessing = false
    }
    
    private func simulateLLMCall(with prompt: String) async throws -> String {
        try await Task.sleep(for: .seconds(1))
        if prompt.contains("bad_word") { return "This is a toxic response." }
        return "This is a safe and helpful response."
    }
    
    /// Handles the user reporting a specific message.
    /// This satisfies Apple's requirement for a reporting mechanism.
    func reportMessage(_ message: String) async {
        // In a real app, this sends the message and user ID to the backend.
        // Here, we update the local safety engine to prevent similar content.
        await safetyEngine.blacklistTerm(message)
        self.errorMessage = "Report submitted. Thank you for helping keep the community safe."
    }
}
