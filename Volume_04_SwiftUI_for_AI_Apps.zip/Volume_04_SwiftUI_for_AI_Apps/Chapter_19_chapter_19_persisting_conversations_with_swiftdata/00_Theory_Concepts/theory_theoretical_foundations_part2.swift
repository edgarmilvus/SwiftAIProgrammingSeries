
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import SwiftData

@available(iOS 18.0, *)
struct ConversationListView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Conversation.createdAt, order: .reverse) private var conversations: [Conversation]

    var body: some View {
        NavigationStack {
            List {
                ForEach(conversations) { conversation in
                    NavigationLink(destination: ChatView(conversation: conversation)) {
                        VStack(alignment: .leading) {
                            Text(conversation.title)
                                .font(.headline)
                            Text("Last updated: \(conversation.createdAt.formatted())")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                    }
                }
                .onDelete(perform: deleteConversations)
            }
            .navigationTitle("AI Conversations")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("New Chat") {
                        let newConversation = Conversation(title: "New AI Chat", createdAt: Date())
                        modelContext.insert(newConversation)
                        // No explicit save needed here, modelContext handles it
                    }
                }
            }
        }
    }

    private func deleteConversations(offsets: IndexSet) {
        for index in offsets {
            let conversationToDelete = conversations[index]
            modelContext.delete(conversationToDelete)
        }
        // Again, modelContext handles the save
    }
}

@available(iOS 18.0, *)
struct ChatView: View {
    @Environment(\.modelContext) private var modelContext
    @Bindable var conversation: Conversation // Use @Bindable for observable objects passed in

    // @Query can also be used here if you need to filter messages dynamically
    // @Query private var messages: [Message]

    // For simplicity, directly accessing messages from the conversation
    var body: some View {
        VStack {
            ScrollView {
                ForEach(conversation.messages.sorted(by: { $0.timestamp < $1.timestamp })) { message in
                    MessageBubble(message: message)
                }
            }
            .background(Color.clear) // Ensure scroll view background is transparent

            // Input field for user messages
            HStack {
                TextField("Type your message...", text: .constant("")) // Placeholder
                    .textFieldStyle(.roundedBorder)
                Button("Send") {
                    // Simulate sending a message and getting a response
                    let userMessage = Message(role: "user", content: "Hello AI!")
                    conversation.messages.append(userMessage)

                    // Simulate AI response streaming
                    let aiMessage = Message(role: "assistant", content: "", isStreaming: true)
                    conversation.messages.append(aiMessage)

                    // Simulate tokens arriving
                    Task {
                        try await Task.sleep(for: .milliseconds(200))
                        aiMessage.content += "I"
                        try await Task.sleep(for: .milliseconds(100))
                        aiMessage.content += " am"
                        try await Task.sleep(for: .milliseconds(150))
                        aiMessage.content += " an"
                        try await Task.sleep(for: .milliseconds(80))
                        aiMessage.content += " AI"
                        try await Task.sleep(for: .milliseconds(200))
                        aiMessage.content += " assistant."
                        aiMessage.isStreaming = false // Mark as complete
                    }
                    // No explicit save needed after appending to @Bindable conversation.messages
                    // SwiftData tracks changes to @Observable models automatically.
                }
            }
            .padding()
        }
        .navigationTitle(conversation.title)
    }
}

@available(iOS 18.0, *)
struct MessageBubble: View {
    let message: Message

    var body: some View {
        HStack {
            if message.role == "user" {
                Spacer()
                Text(message.content)
                    .padding()
                    .background(Color.blue.opacity(0.8))
                    .foregroundColor(.white)
                    .cornerRadius(15)
            } else {
                Text(message.content + (message.isStreaming ? "▋" : "")) // Add typing indicator
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(15)
                Spacer()
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 4)
    }
}
