/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

digraph BiometricAuthFlow {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#4CAF50", fontname="Helvetica"];
    
    // Define States
    Idle [fillcolor="#E3F2FD", color="#2196F3"];
    CheckingCapabilities [fillcolor="#FFF3E0", color="#FF9800"];
    ReadyToAuth [fillcolor="#E0F2F1", color="#009688"];
    Authenticating [fillcolor="#E1BEE7", color="#9C27B0"];
    Simulating [fillcolor="#E1BEE7", color="#9C27B0", style="dashed"];
    Success [fillcolor="#C8E6C9", color="#4CAF50"];
    Failure [fillcolor="#FFCDD2", color="#F44336"];

    // Define Transitions
    Idle -> CheckingCapabilities [label="Component Mount"];
    
    CheckingCapabilities -> ReadyToAuth [label="Hardware & Permissions OK"];
    CheckingCapabilities -> Failure [label="No Hardware / Permission Denied"];
    
    ReadyToAuth -> Authenticating [label="User Presses 'Unlock' (Native)"];
    ReadyToAuth -> Simulating [label="User Presses 'Unlock' (Dev Mode)"];
    
    Authenticating -> Success [label="authenticateAsync Success"];
    Authenticating -> Failure [label="authenticateAsync Fail / Cancel"];
    
    Simulating -> Success [label="setTimeout(1000ms)"];
    
    // Loops / Self-Transitions
    Failure -> ReadyToAuth [label="User Retries"];
    Success -> Idle [label="User Locks / Timeout"];
}
