
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

enum ConfigurationError: Error {
    case invalidTemperature
}

/// An actor that ensures thread-safe access to sensitive AI configurations.
@available(iOS 18.0, *)
actor LLMConfigurationActor {
    // Private state is isolated to the actor
    private var apiKey: String
    private var modelName: String
    private var temperature: Double
    
    init(apiKey: String, modelName: String, temperature: Double) {
        self.apiKey = apiKey
        self.modelName = modelName
        // Clamp initial temperature
        self.temperature = max(0.0, min(2.0, temperature))
    }
    
    /// Returns a tuple of the current configuration.
    /// Since this is an actor, reading is safe from concurrent writes.
    func getConfiguration() -> (apiKey: String, modelName: String, temperature: Double) {
        return (apiKey, modelName, temperature)
    }
    
    /// Updates all configuration values atomically.
    func updateConfiguration(apiKey: String, modelName: String, temperature: Double) throws {
        // Validation logic
        guard (0.0...2.0).contains(temperature) else {
            throw ConfigurationError.invalidTemperature
        }
        
        self.apiKey = apiKey
        self.modelName = modelName
        self.temperature = temperature
    }
}

// --- Concurrency Test ---
@available(iOS 18.0, *)
func runConfigurationTest() async {
    let configActor = LLMConfigurationActor(apiKey: "initial_key", modelName: "gpt-4o", temperature: 1.0)
    
    print("Starting concurrency test...")
    
    await withTaskGroup(of: Void.self) { group in
        for i in 0..<100 {
            // Half the tasks attempt to update
            if i % 2 == 0 {
                group.addTask {
                    do {
                        // Random temperature between -0.5 and 2.5 to test validation
                        let randomTemp = Double.random(in: -0.5...2.5)
                        try await configActor.updateConfiguration(
                            apiKey: "key_\(i)",
                            modelName: "model_\(i)",
                            temperature: randomTemp
                        )
                    } catch {
                        // Expected for values outside 0.0...2.0
                        // print("Task \(i) failed validation as expected.")
                    }
                }
            } else {
                // Half the tasks attempt to read
                group.addTask {
                    let config = await configActor.getConfiguration()
                    // We use the result to ensure the read doesn't crash
                    _ = config.apiKey
                }
            }
        }
    }
    
    let finalConfig = await configActor.getConfiguration()
    print("Test Complete. Final Temperature: \(finalConfig.temperature)")
}
