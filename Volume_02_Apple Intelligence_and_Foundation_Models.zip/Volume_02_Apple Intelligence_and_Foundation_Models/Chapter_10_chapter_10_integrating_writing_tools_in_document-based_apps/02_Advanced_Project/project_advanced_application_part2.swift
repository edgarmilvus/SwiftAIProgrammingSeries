
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import WritingTools // Import the Apple Intelligence Writing Tools framework
import UIKit // For UITextView, simulating the document editor context

/// Represents the various rewrite styles a user can choose in the ProsePerfect app.
enum RewriteStyle: String, CaseIterable, Identifiable {
    case makeMoreConcise = "Make More Concise"
    case makeMoreDetailed = "Make More Detailed"
    case makeMoreFormal = "Make More Formal"
    case makeMoreCasual = "Make More Casual"
    case rephrase = "Rephrase (General)"
    case summarize = "Summarize"

    var id: String { self.rawValue }

    /// Maps the app's internal RewriteStyle to the system's WritingTools.RewriteOption.
    /// - Returns: The corresponding WritingTools.RewriteOption.
    @available(iOS 18.0, *)
    func toWritingToolsOption() -> WritingTools.RewriteOption {
        switch self {
        case .makeMoreConcise: return .makeMoreConcise
        case .makeMoreDetailed: return .makeMoreDetailed
        case .makeMoreFormal: return .makeMoreFormal
        case .makeMoreCasual: return .makeMoreCasual
        case .rephrase: return .rephrase
        case .summarize: return .summarize
        }
    }
}

/// A custom error type for operations within the WritingToolsRewriteManager.
enum WritingToolsRewriteError: Error, LocalizedError {
    case writingToolsNotAvailable
    case unsupportedRewriteOption(RewriteStyle)
    case rewriteFailed(underlyingError: Error)
    case emptyTextProvided
    case userCancelled

    var errorDescription: String? {
        switch self {
        case .writingToolsNotAvailable:
            return "Writing Tools are not available on this device or iOS version."
        case .unsupportedRewriteOption(let style):
            return "The rewrite option '\(style.rawValue)' is not supported by Writing Tools."
        case .rewriteFailed(let error):
            return "Failed to rewrite text: \(error.localizedDescription)"
        case .emptyTextProvided:
            return "Please select text to rewrite."
        case .userCancelled:
            return "Rewrite operation cancelled by the user."
        }
    }
}

/// Manages interactions with Apple Intelligence Writing Tools for contextual text rewriting.
@available(iOS 18.0, *)
class WritingToolsRewriteManager {
    /// The WritingToolsSession instance used to communicate with the on-device LLM.
    /// A single session can be reused for multiple operations within the same context.
    private let session: WritingToolsSession

    /// Initializes the manager with a new WritingToolsSession.
    init() {
        self.session = WritingToolsSession()
    }

    /// Performs a contextual rewrite on the given text using the specified style.
    ///
    /// - Parameters:
    ///   - text: The original text to be rewritten.
    ///   - style: The desired rewrite style (e.g., .makeMoreFormal, .makeMoreConcise).
    /// - Returns: The rewritten text.
    /// - Throws: `WritingToolsRewriteError` if the operation fails, is cancelled,
    ///           or if Writing Tools are unavailable/unsupported.
    func rewriteText(_ text: String, style: RewriteStyle) async throws -> String {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw WritingToolsRewriteError.emptyTextProvided
        }

        // 1. Check for Writing Tools availability and option support
        // This is a crucial step for graceful degradation on unsupported devices or contexts.
        guard WritingToolsSession.isWritingToolsAvailable else {
            throw WritingToolsRewriteError.writingToolsNotAvailable
        }
        let systemOption = style.toWritingToolsOption()
        guard session.isSupported(option: systemOption) else {
            throw WritingToolsRewriteError.unsupportedRewriteOption(style)
        }

        do {
            // 2. Perform the rewrite operation asynchronously.
            // The `rewrite` method interacts with the on-device LLM.
            let result = try await session.rewrite(text: text, option: systemOption)
            return result.text
        } catch is CancellationError {
            // 3. Handle user cancellation specifically.
            // This can happen if the user dismisses the AI suggestion UI mid-operation.
            throw WritingToolsRewriteError.userCancelled
        } catch let writingToolsError as WritingTools.WritingToolsError {
            // 4. Handle specific WritingTools errors.
            // These errors provide more context about why the AI operation failed.
            print("WritingToolsError: \(writingToolsError.localizedDescription)")
            throw WritingToolsRewriteError.rewriteFailed(underlyingError: writingToolsError)
        } catch {
            // 5. Catch any other unexpected errors during the process.
            print("Unexpected error during rewrite: \(error.localizedDescription)")
            throw WritingToolsRewriteError.rewriteFailed(underlyingError: error)
        }
    }

    /// Asynchronously retrieves the list of rewrite options currently supported by the system.
    /// This can be used to dynamically enable/disable UI elements based on availability.
    ///
    /// - Returns: An array of `WritingTools.RewriteOption` that are supported.
    func getAvailableSystemRewriteOptions() async -> [WritingTools.RewriteOption] {
        guard WritingToolsSession.isWritingToolsAvailable else {
            return []
        }
        // Query the session for all supported options.
        return await session.supportedOptions()
    }
}

// MARK: - Simulated Document Editor Context

/// A simplified representation of a document editor's text view.
/// In a real app, this would be a `UITextView` or `NSTextView`.
/// We use a `String` property to simulate the content and a `NSRange` for selection.
@available(iOS 18.0, *)
class ProsePerfectDocumentEditor {
    var documentContent: String
    var selectedRange: NSRange?

    init(initialContent: String) {
        self.documentContent = initialContent
    }

    /// Simulates getting the currently selected text from the editor.
    func getSelectedText() -> String? {
        guard let selectedRange = selectedRange,
              selectedRange.location != NSNotFound,
              selectedRange.length > 0,
              selectedRange.location + selectedRange.length <= documentContent.utf16.count else {
            return nil
        }
        let start = String.Index(utf16Offset: selectedRange.location, in: documentContent)
        let end = String.Index(utf16Offset: selectedRange.location + selectedRange.length, in: documentContent)
        return String(documentContent[start..<end])
    }

    /// Simulates replacing the selected text with new content.
    func replaceSelectedText(with newText: String) {
        guard let selectedRange = selectedRange,
              selectedRange.location != NSNotFound,
              selectedRange.location + selectedRange.length <= documentContent.utf16.count else {
            // If no valid selection, append or handle as an error
            print("No valid selection to replace. Appending new text.")
            documentContent += "\n\(newText)"
            return
        }

        let mutableContent = NSMutableString(string: documentContent)
        mutableContent.replaceCharacters(in: selectedRange, with: newText)
        documentContent = mutableContent as String
        // Update selection to cover the newly inserted text
        self.selectedRange = NSRange(location: selectedRange.location, length: newText.utf16.count)
        print("Document content updated:\n\(documentContent)")
    }
}

// MARK: - Example Usage in a View Controller Context (Conceptual)

/// This class simulates a UIViewController that would manage the document editor
/// and trigger the rewrite operations.
@available(iOS 18.0, *)
class DocumentEditorViewController {
    let documentEditor: ProsePerfectDocumentEditor
    let rewriteManager: WritingToolsRewriteManager

    init(initialContent: String) {
        self.documentEditor = ProsePerfectDocumentEditor(initialContent: initialContent)
        self.rewriteManager = WritingToolsRewriteManager()
    }

    /// Simulates a user action (e.g., tapping a "Rewrite" button) to trigger the rewrite.
    /// - Parameters:
    ///   - style: The desired rewrite style.
    ///   - selectedRange: The range of text the user has selected in the UI.
    func triggerRewrite(style: RewriteStyle, selectedRange: NSRange) {
        documentEditor.selectedRange = selectedRange
        guard let selectedText = documentEditor.getSelectedText() else {
            print("No text selected for rewrite.")
            return
        }

        print("\n--- Initiating Rewrite ---")
        print("Original Text: \"\(selectedText)\"")
        print("Desired Style: \(style.rawValue)")

        // Use a Task to run the asynchronous rewrite operation.
        // In a real UI, you'd likely show a loading indicator here.
        Task {
            do {
                let rewrittenText = try await rewriteManager.rewriteText(selectedText, style: style)
                print("Rewritten Text: \"\(rewrittenText)\"")

                // Update the document editor with the new text.
                // In a real UI, you might present options to the user before applying.
                documentEditor.replaceSelectedText(with: rewrittenText)
                print("--- Rewrite Successful ---")
            } catch let error as WritingToolsRewriteError {
                print("Rewrite Error: \(error.localizedDescription)")
                // In a real UI, present an alert to the user.
            } catch {
                print("An unexpected error occurred: \(error.localizedDescription)")
            }
        }
    }

    /// Demonstrates querying available options.
    func queryAvailableOptions() {
        Task {
            let options = await rewriteManager.getAvailableSystemRewriteOptions()
            print("\n--- Supported System Rewrite Options ---")
            for option in options {
                print("- \(option)")
            }
            print("----------------------------------------")
        }
    }
}


// MARK: - Demonstration

@available(iOS 18.0, *)
func demonstrateAdvancedWritingTools() {
    let initialDocument = """
    The quick brown fox jumps over the lazy dog. This sentence is a classic example used for testing typefaces and keyboards. It contains every letter of the English alphabet. We need to ensure that our document editor is capable of handling various text transformations efficiently.
    """
    let viewController = DocumentEditorViewController(initialContent: initialDocument)

    // 1. Query available options first (e.g., on app launch or feature activation)
    viewController.queryAvailableOptions()

    // 2. Simulate a user selecting text and choosing to make it more concise.
    // Let's select the first sentence.
    let firstSentenceRange = NSRange(location: 0, length: 44) // "The quick brown fox jumps over the lazy dog."
    viewController.triggerRewrite(style: .makeMoreConcise, selectedRange: firstSentenceRange)

    // Wait a bit for the first rewrite to potentially complete before the next.
    // In a real app, these would be user-driven events.
    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
        // 3. Simulate selecting another part and making it more formal.
        let secondPartRange = NSRange(location: 45, length: 76) // "This sentence is a classic example used for testing typefaces and keyboards. It contains every letter of the English alphabet."
        viewController.triggerRewrite(style: .makeMoreFormal, selectedRange: secondPartRange)
    }

    DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
        // 4. Simulate selecting a part and rephrasing it generally.
        let thirdPartRange = NSRange(location: 122, length: 80) // "We need to ensure that our document editor is capable of handling various text transformations efficiently."
        viewController.triggerRewrite(style: .rephrase, selectedRange: thirdPartRange)
    }

    DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
        // 5. Simulate an error: trying to rewrite empty text.
        let emptyRange = NSRange(location: 0, length: 0)
        viewController.triggerRewrite(style: .summarize, selectedRange: emptyRange)
    }
}

// To run this demonstration in an Xcode Playground or a similar environment:
// Ensure you are targeting an iOS 18.0+ device or simulator.
// Call the function:
// demonstrateAdvancedWritingTools()
