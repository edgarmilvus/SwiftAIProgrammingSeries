
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import NaturalLanguage
import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct EnhancedKeywordExtractor {
    private let stopWords: Set<String> = [
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
        "and", "or", "but", "for", "nor", "so", "yet",
        "in", "on", "at", "by", "with", "from", "of", "to", "into", "onto",
        "this", "that", "these", "those", "it", "its", "he", "him", "his", "she", "her", "hers",
        "we", "us", "our", "ours", "you", "your", "yours", "they", "them", "their", "theirs",
        "i", "me", "my", "mine", "what", "which", "who", "whom", "whose", "where", "when", "why", "how",
        "am", "can", "will", "would", "should", "could", "may", "might", "must",
        "do", "does", "did", "don't", "doesn't", "didn't",
        "have", "has", "had", "not", "no", "yes", "all", "any", "both", "each", "few", "more", "most", "other", "some", "such",
        "only", "own", "same", "so", "than", "too", "very", "s", "t", "can't", "will", "just", "don't", "shouldn't", "now", "d", "ll", "m", "o", "re", "ve", "y", "ain", "aren", "couldn", "didn", "doesn", "hadn", "hasn", "haven", "isn", "ma", "mightn", "mustn", "needn", "shan", "shouldn", "wasn", "weren", "won", "wouldn"
    ]

    // Helper to check if a word is a stop word (case-insensitive)
    private func isStopWord(_ word: String) -> Bool {
        return stopWords.contains(word.lowercased())
    }

    func extractEnhancedKeywords(from text: String, count: Int = 10) -> [String] {
        let tagger = NLTagger(tagSchemes: [.lexicalClass, .lemma])
        tagger.string = text

        var lemmatizedWords: [String] = [] // Stores filtered, lemmatized words for bigram generation
        var keywordFrequencies: [String: Int] = [:] // Stores frequencies for both single words and bigrams

        // 1. Tokenize, Lemmatize, and Filter for Single Words
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lexicalClass, options: [.omitWhitespace, .omitPunctuation, .omitOther]) { lexicalClassTag, tokenRange in
            guard let lexicalClassTag = lexicalClassTag else { return true }

            // Filter for nouns, proper nouns, verbs, and adjectives for single words
            guard lexicalClassTag == .noun || lexicalClassTag == .properNoun || lexicalClassTag == .verb || lexicalClassTag == .adjective else {
                return true
            }

            let word = String(text[tokenRange])
            
            // Get the lemma for the word
            let lemmaTag = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .lemma).0
            let lemmatizedWord = (lemmaTag?.rawValue ?? word).lowercased() // Use rawValue for lemma, fallback to word

            // Apply stop word filtering for single words after lemmatization
            if !isStopWord(lemmatizedWord) {
                lemmatizedWords.append(lemmatizedWord)
                keywordFrequencies[lemmatizedWord, default: 0] += 1
            }
            return true
        }

        // 2. Generate Bigrams from the filtered, lemmatized words
        if lemmatizedWords.count >= 2 {
            for i in 0..<(lemmatizedWords.count - 1) {
                let word1 = lemmatizedWords[i]
                let word2 = lemmatizedWords[i+1]

                // Bigram filtering heuristic: at least one word must not be a stop word
                // and the bigram itself shouldn't be composed of two stop words (which is covered by the first check)
                if !isStopWord(word1) || !isStopWord(word2) {
                    let bigram = "\(word1) \(word2)"
                    keywordFrequencies[bigram, default: 0] += 1
                }
            }
        }

        // 3. Sort and Select Top Keywords
        let sortedKeywords = keywordFrequencies.sorted { (entry1, entry2) -> Bool in
            if entry1.value != entry2.value {
                return entry1.value > entry2.value // Higher frequency first
            } else {
                return entry1.key < entry2.key // Alphabetical for ties
            }
        }

        let topKeywords = sortedKeywords.prefix(count).map { $0.key }

        return topKeywords
    }
}

// Example Usage:
@available(iOS 18.0, macOS 15.0, *)
func runExercise2() {
    let extractor = EnhancedKeywordExtractor()
    let text = "The swift fox runs quickly through the tall grass. Running is its favorite activity. It ran faster than any other fox in the forest. The running fox is a fast runner."
    let keywords = extractor.extractEnhancedKeywords(from: text, count: 5)
    print("Exercise 2 Keywords: \(keywords)")
    // Expected Output (order might vary, but includes lemmatized words and bigrams):
    // ["fox", "run", "tall grass", "activity", "forest"] or similar, "fast runner" might appear.
    // My output for this specific text: ["fox", "run", "tall grass", "runner", "activity"]
}

// Uncomment to run the example in a playground or app
// runExercise2()
