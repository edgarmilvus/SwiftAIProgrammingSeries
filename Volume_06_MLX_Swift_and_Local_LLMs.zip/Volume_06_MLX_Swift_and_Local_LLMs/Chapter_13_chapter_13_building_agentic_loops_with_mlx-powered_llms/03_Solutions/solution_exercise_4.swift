
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import MLX
import Foundation

// MARK: - Tool Definitions

/// Represents a single tool available to the agent.
struct AgentTool {
    let name: String
    let description: String
    let parameters: [String: String] // e.g., ["query": "String", "task": "String"]
    let execute: ([String: String]) async throws -> String
}

/// A registry to manage and describe available tools.
@available(iOS 18.0, macOS 15.0, *)
class ToolRegistry {
    private var tools: [String: AgentTool] = [:]
    
    func register(tool: AgentTool) {
        tools[tool.name] = tool
    }
    
    func getTool(name: String) -> AgentTool? {
        return tools[name]
    }
    
    /// Generates a prompt-friendly description of all registered tools.
    func getToolDescriptionsForLLM() -> String {
        return tools.values.map { tool in
            let params = tool.parameters.map { "\($0.key): \($0.value)" }.joined(separator: ", ")
            return "- \(tool.name): \(tool.description) (Parameters: \(params))"
        }.joined(separator: "\n")
    }
}

// MARK: - Mock Tool Implementations

enum ToolExecutionError: Error, LocalizedError {
    case missingArgument(String)
    case invalidArgument(String, String)
    case unknownTool(String)
    case unknownError(String)
    
    var errorDescription: String? {
        switch self {
        case .missingArgument(let arg): return "Missing required argument: \(arg)"
        case .invalidArgument(let arg, let value): return "Invalid argument '\(arg)' with value '\(value)'"
        case .unknownTool(let name): return "Unknown tool: \(name)"
        case .unknownError(let msg): return "Tool execution failed: \(msg)"
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
func lookupDocumentation(args: [String: String]) async throws -> String {
    guard let query = args["query"] else { throw ToolExecutionError.missingArgument("query") }
    print("Tool: Looking up documentation for: '\(query)'...")
    // Simulate an API call or local search
    return "Documentation found for '\(query)': Swift.org provides extensive guides on MLXArray operations and MLXNN.Module usage. Check the official MLX Swift GitHub repository for examples."
}

@available(iOS 18.0, macOS 15.0, *)
func generateCodeSnippet(args: [String: String]) async throws -> String {
    guard let task = args["task"] else { throw ToolExecutionError.missingArgument("task") }
    let language = args["language"] ?? "Swift"
    print("Tool: Generating \(language) code snippet for task: '\(task)'...")
    // Simulate code generation
    return """
    