
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import HomeKit // Requires HomeKit entitlement and framework linkage

/// Represents custom errors that can occur during tool calling and execution.
enum HomeToolError: Error, LocalizedError {
    case invalidToolCallFormat(String)
    case unknownToolFunction(String)
    case missingToolArguments(function: String, arguments: [String])
    case toolExecutionFailed(function: String, message: String)
    case llmCommunicationFailed(String)
    case noToolCallDetected

    var errorDescription: String? {
        switch self {
        case .invalidToolCallFormat(let json):
            return "Failed to parse tool call JSON: \(json)"
        case .unknownToolFunction(let function):
            return "LLM requested an unknown tool function: \(function)"
        case .missingToolArguments(let function, let args):
            return "Tool function '\(function)' called with missing arguments: \(args.joined(separator: ", "))"
        case .toolExecutionFailed(let function, let message):
            return "Execution of tool '\(function)' failed: \(message)"
        case .llmCommunicationFailed(let message):
            return "LLM communication failed: \(message)"
        case .noToolCallDetected:
            return "No tool call detected in LLM response."
        }
    }
}

// MARK: - 1. Tool Definitions

/// Defines the structure for a tool call that the LLM might output.
/// This structure aligns with common tool calling patterns where the LLM
/// provides a function name and a dictionary of arguments.
struct ToolCall: Codable {
    let function: FunctionCall

    struct FunctionCall: Codable {
        let name: String
        let arguments: [String: JSONValue] // Use JSONValue to handle mixed types

        // Custom decoding to handle arguments as a raw JSON string
        // when the LLM might output them as a single string.
        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            name = try container.decode(String.self, forKey: .name)

            if let argDict = try? container.decode([String: JSONValue].self, forKey: .arguments) {
                arguments = argDict
            } else if let argString = try? container.decode(String.self, forKey: .arguments) {
                // Attempt to parse the string as a JSON dictionary
                guard let data = argString.data(using: .utf8) else {
                    throw HomeToolError.invalidToolCallFormat("Arguments string not UTF-8 decodable.")
                }
                arguments = try JSONDecoder().decode([String: JSONValue].self, from: data)
            } else {
                throw HomeToolError.invalidToolCallFormat("Arguments not a dictionary or parsable string.")
            }
        }
    }
}

/// A flexible JSON value enum to handle various argument types from LLM output.
enum JSONValue: Codable, Hashable {
    case string(String)
    case int(Int)
    case double(Double)
    case bool(Bool)
    case object([String: JSONValue])
    case array([JSONValue])
    case null

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let value = try? container.decode(String.self) {
            self = .string(value)
        } else if let value = try? container.decode(Int.self) {
            self = .int(value)
        } else if let value = try? container.decode(Double.self) {
            self = .double(value)
        } else if let value = try? container.decode(Bool.self) {
            self = .bool(value)
        } else if let value = try? container.decode([String: JSONValue].self) {
            self = .object(value)
        } else if let value = try? container.decode([JSONValue].self) {
            self = .array(value)
        } else if container.decodeNil() {
            self = .null
        } else {
            throw DecodingError.typeMismatch(JSONValue.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Unsupported JSON type"))
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .string(let value): try container.encode(value)
        case .int(let value): try container.encode(value)
        case .double(let value): try container.encode(value)
        case .bool(let value): try container.encode(value)
        case .object(let value): try container.encode(value)
        case .array(let value): try container.encode(value)
        case .null: try container.encodeNil()
        }
    }

    /// Helper to extract string value, if applicable.
    var stringValue: String? {
        if case .string(let value) = self { return value }
        return nil
    }

    /// Helper to extract double value, if applicable.
    var doubleValue: Double? {
        if case .double(let value) = self { return value }
        if case .int(let value) = self { return Double(value) } // Allow int to double conversion
        if case .string(let value) = self, let double = Double(value) { return double }
        return nil
    }

    /// Helper to extract bool value, if applicable.
    var boolValue: Bool? {
        if case .bool(let value) = self { return value }
        if case .string(let value) = self { return Bool(value) }
        return nil
    }
}

// MARK: - 2. LLM Service Abstraction

/// Protocol for an LLM service, allowing for different implementations
/// (e.g., Ollama, llama.cpp Swift bindings, remote API).
protocol LLMServiceProtocol {
    /// Generates a response from the LLM based on the given prompt.
    /// The response can be natural language or a structured tool call JSON.
    /// - Parameter prompt: The user's input command.
    /// - Returns: The LLM's raw string response.
    func generateResponse(prompt: String) async throws -> String
}

/// A mock implementation of `LLMServiceProtocol` for demonstration purposes.
/// In a real app, this would integrate with Ollama or llama.cpp.
@available(iOS 18.0, *)
class MockLLMService: LLMServiceProtocol {
    /// Simulates LLM processing time.
    private let latency: UInt64 = 1_000_000_000 // 1 second

    /// Simulates LLM responses based on predefined prompts.
    func generateResponse(prompt: String) async throws -> String {
        try await Task.sleep(nanoseconds: latency) // Simulate network/processing delay

        // In a real scenario, the LLM would be prompted with tool definitions
        // and would generate a JSON response if a tool is to be called.
        // For example:
        // "Here are the tools you can use:
        // { 'name': 'turnLightOn', 'description': 'Turns on a light in a specific room', 'parameters': {'room': 'string'} }
        // { 'name': 'setThermostat', 'description': 'Sets the temperature of a thermostat in a specific room', 'parameters': {'room': 'string', 'temperature': 'number'} }
        // User input: 'turn on the living room lights'
        // LLM output: '{"function": {"name": "turnLightOn", "arguments": {"room": "living room"}}}'

        switch prompt.lowercased() {
        case let p where p.contains("turn on") && p.contains("living room lights"):
            return """
            {
                "function": {
                    "name": "turnLightOn",
                    "arguments": {
                        "room": "living room"
                    }
                }
            }
            """
        case let p where p.contains("turn off") && p.contains("bedroom lights"):
            return """
            {
                "function": {
                    "name": "toggleLight",
                    "arguments": {
                        "on": false,
                        "room": "bedroom"
                    }
                }
            }
            """
        case let p where p.contains("set thermostat") && p.contains("22 degrees"):
            return """
            {
                "function": {
                    "name": "setThermostat",
                    "arguments": {
                        "room": "living room",
                        "temperature": 22.0
                    }
                }
            }
            """
        case let p where p.contains("what's the weather"):
            return "I'm sorry, I can only control smart home devices."
        case let p where p.contains("invalid tool"):
            return """
            {
                "function": {
                    "name": "nonExistentTool",
                    "arguments": {
                        "param": "value"
                    }
                }
            }
            """
        case let p where p.contains("malformed json"):
            return "This is not valid JSON."
        default:
            return "I didn't understand that. Please try a command like 'turn on the living room lights'."
        }
    }
}

// MARK: - 3. HomeKit Manager

/// A conceptual manager for interacting with HomeKit.
/// In a real application, this would use `HMHomeManager`, `HMHome`, `HMAccessory`, etc.
/// @available(iOS 18.0, *) is used here to match the MockLLMService, but HomeKit itself is available earlier.
@available(iOS 18.0, *)
class HomeKitManager {
    /// Simulates toggling a light accessory in a given room.
    /// - Parameters:
    ///   - on: `true` to turn on, `false` to turn off.
    ///   - room: The name of the room where the light is located.
    /// - Returns: A confirmation message.
    func toggleLight(on: Bool, room: String) async throws -> String {
        print("HomeKit: Attempting to turn \(on ? "on" : "off") light in \(room)...")
        try await Task.sleep(nanoseconds: 500_000_000) // Simulate HomeKit latency
        // In a real app: Find accessory, update characteristic value
        // if let lightbulb = findLightbulb(room: room) {
        //    try await lightbulb.updateCharacteristic(HMCharacteristicTypePowerState, value: on)
        // }
        print("HomeKit: Light in \(room) turned \(on ? "on" : "off").")
        return "Light in \(room) turned \(on ? "on" : "off")."
    }

    /// Simulates setting the thermostat temperature in a given room.
    /// - Parameters:
    ///   - temperature: The target temperature in Celsius.
    ///   - room: The name of the room where the thermostat is located.
    /// - Returns: A confirmation message.
    func setThermostat(temperature: Double, room: String) async throws -> String {
        print("HomeKit: Attempting to set thermostat in \(room) to \(temperature)°C...")
        try await Task.sleep(nanoseconds: 700_000_000) // Simulate HomeKit latency
        // In a real app: Find thermostat, update characteristic value
        // if let thermostat = findThermostat(room: room) {
        //    try await thermostat.updateCharacteristic(HMCharacteristicTypeTargetTemperature, value: temperature)
        // }
        print("HomeKit: Thermostat in \(room) set to \(temperature)°C.")
        return "Thermostat in \(room) set to \(temperature)°C."
    }

    // Add other HomeKit control functions here...
}

// MARK: - 4. Tool Dispatcher

/// `ToolDispatcher` is responsible for parsing LLM output, identifying tool calls,
/// and executing the corresponding functions using the `HomeKitManager`.
@available(iOS 18.0, *)
class ToolDispatcher {
    private let homeKitManager: HomeKitManager
    private let jsonDecoder = JSONDecoder()

    init(homeKitManager: HomeKitManager) {
        self.homeKitManager = homeKitManager
    }

    /// Attempts to dispatch a tool call based on the LLM's JSON output.
    /// - Parameter toolCallJSON: The raw JSON string from the LLM.
    /// - Returns: A string representing the result of the tool execution.
    /// - Throws: `HomeToolError` if parsing fails, tool is unknown, or execution fails.
    func dispatch(toolCallJSON: String) async throws -> String {
        guard let data = toolCallJSON.data(using: .utf8) else {
            throw HomeToolError.invalidToolCallFormat("Tool call JSON not UTF-8 decodable.")
        }

        let toolCall: ToolCall
        do {
            toolCall = try jsonDecoder.decode(ToolCall.self, from: data)
        } catch {
            throw HomeToolError.invalidToolCallFormat("JSON decoding failed: \(error.localizedDescription) for input: \(toolCallJSON)")
        }

        let functionName = toolCall.function.name
        let args = toolCall.function.arguments

        print("ToolDispatcher: Dispatching tool '\(functionName)' with arguments: \(args)")

        switch functionName {
        case "turnLightOn", "toggleLight":
            guard let on = args["on"]?.boolValue ?? true, // Default to true if "on" is missing for "turnLightOn"
                  let room = args["room"]?.stringValue else {
                throw HomeToolError.missingToolArguments(function: functionName, arguments: ["on", "room"])
            }
            return try await homeKitManager.toggleLight(on: on, room: room)

        case "setThermostat":
            guard let temperature = args["temperature"]?.doubleValue,
                  let room = args["room"]?.stringValue else {
                throw HomeToolError.missingToolArguments(function: functionName, arguments: ["temperature", "room"])
            }
            return try await homeKitManager.setThermostat(temperature: temperature, room: room)

        default:
            throw HomeToolError.unknownToolFunction(functionName)
        }
    }
}

// MARK: - 5. Smart Home Assistant Orchestrator

/// The main orchestrator for the Smart Home Assistant app component.
/// It ties together the LLM interaction and tool execution.
@available(iOS 18.0, *)
class SmartHomeAssistant {
    private let llmService: LLMServiceProtocol
    private let toolDispatcher: ToolDispatcher

    /// Initializes the assistant with an LLM service and a HomeKit manager.
    /// - Parameters:
    ///   - llmService: The service to interact with the LLM.
    ///   - homeKitManager: The manager for HomeKit operations.
    init(llmService: LLMServiceProtocol, homeKitManager: HomeKitManager) {
        self.llmService = llmService
        self.toolDispatcher = ToolDispatcher(homeKitManager: homeKitManager)
    }

    /// Handles a user's natural language command, processes it through the LLM,
    /// and executes any detected tool calls.
    /// - Parameter command: The user's input string (e.g., from speech recognition).
    /// - Returns: A user-friendly response string indicating the outcome.
    func handleUserCommand(command: String) async -> String {
        print("\nAssistant: Processing command: \"\(command)\"")
        do {
            // 1. Get response from LLM
            let llmResponse = try await llmService.generateResponse(prompt: command)
            print("Assistant: LLM Raw Response: \(llmResponse)")

            // 2. Attempt to parse LLM response as a tool call
            if llmResponse.trimmingCharacters(in: .whitespacesAndNewlines).starts(with: "{") {
                // Heuristic: If it starts with '{', assume it might be JSON for a tool call.
                // A more robust approach might involve the LLM explicitly tagging tool calls.
                do {
                    let toolResult = try await toolDispatcher.dispatch(toolCallJSON: llmResponse)
                    return "Action successful: \(toolResult)"
                } catch let error as HomeToolError {
                    // If parsing or dispatching failed, it might still be a natural language response
                    // or a specific tool-related error.
                    if case .invalidToolCallFormat = error {
                        // If it looked like JSON but wasn't a valid tool call, treat it as LLM's natural response.
                        return "LLM response: \(llmResponse)"
                    } else {
                        return "Action failed: \(error.localizedDescription)"
                    }
                } catch {
                    return "An unexpected error occurred during tool dispatch: \(error.localizedDescription)"
                }
            } else {
                // If not JSON, it's a natural language response from the LLM.
                return "LLM response: \(llmResponse)"
            }
        } catch let error as HomeToolError {
            return "Failed to process command: \(error.localizedDescription)"
        } catch {
            return "An unexpected error occurred: \(error.localizedDescription)"
        }
    }
}

// MARK: - Application Entry Point (Simulation)

/// Main function to simulate the application's lifecycle and user interactions.
@available(iOS 18.0, *)
func runSmartHomeAssistantDemo() async {
    let homeKitManager = HomeKitManager()
    let llmService = MockLLMService()
    let assistant = SmartHomeAssistant(llmService: llmService, homeKitManager: homeKitManager)

    print("--- Smart Home Assistant Demo ---")

    // Scenario 1: Successful light control
    var response = await assistant.handleUserCommand(command: "Turn on the living room lights")
    print("User Feedback: \(response)")

    // Scenario 2: Successful thermostat control
    response = await assistant.handleUserCommand(command: "Set thermostat in living room to 22 degrees")
    print("User Feedback: \(response)")

    // Scenario 3: Another light control (toggleLight with explicit 'on: false')
    response = await assistant.handleUserCommand(command: "Turn off bedroom lights")
    print("User Feedback: \(response)")

    // Scenario 4: LLM provides natural language response (no tool call)
    response = await assistant.handleUserCommand(command: "What's the weather like?")
    print("User Feedback: \(response)")

    // Scenario 5: LLM outputs an unknown tool
    response = await assistant.handleUserCommand(command: "Invalid tool command")
    print("User Feedback: \(response)")

    // Scenario 6: LLM outputs malformed JSON
    response = await assistant.handleUserCommand(command: "Malformed JSON response")
    print("User Feedback: \(response)")

    // Scenario 7: Missing arguments for a valid tool
    // (This would require modifying MockLLMService to simulate, or more complex parsing)
    // For now, assume MockLLMService always provides correct args if it calls a known tool.
    // If the LLM were to output: {"function": {"name": "turnLightOn", "arguments": {}}}
    // The ToolDispatcher would catch this.
}

// To run this in a Swift Playground or a command-line tool:
@available(iOS 18.0, *)
Task {
    await runSmartHomeAssistantDemo()
}
