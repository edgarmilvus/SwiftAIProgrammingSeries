
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// A technical specification for the creative team to ensure 
/// App Store assets meet visionOS immersion standards.
struct SubmissionAssetSpecification {
    
    enum AssetType {
        case videoPreview
        case staticScreenshot
    }
    
    struct Requirement {
        let title: String
        let description: String
        let technicalSpec: String
    }
    
    let appName: String = "StarGazer"
    
    let transitionStrategy = Requirement(
        title: "Windowed-to-Immersive Transition",
        description: "The video must show a user selecting a constellation in a windowed view, followed by a seamless expansion into a full Immersive Space.",
        technicalSpec: "Use a 3-second cross-dissolve. Avoid sudden 'pops' in geometry. Capture at 60fps to maintain spatial fluidity."
    )
    
    let lightingStrategy = Requirement(
        title: "Spatial Lighting Demonstration",
        description: "Showcase how virtual celestial bodies react to the user's environment.",
        technicalSpec: "Record a video where the nebula's glow increases/decreases as the simulated room light changes, demonstrating ARKit Light Estimation."
    )
    
    let scaleStrategy = Requirement(
        title: "Scale & Depth Demonstration",
        description: "Communicate the difference between a handheld UI and a 10-meter wide nebula.",
        technicalSpec: "Use a 'Human Reference' (a virtual silhouette or a hand gesture) within the frame to provide a sense of scale relative to the room."
    )
    
    let visualHierarchyChecklist: [String] = [
        "Does the asset show depth (Z-axis) rather than just 2D movement?",
        "Is the transition from 2D window to 3D space smooth?",
        "Are lighting changes synchronized with environmental context?",
        "Is the 'Hero' video captured in a high-bitrate format (ProRes) for clarity?"
    ]
    
    func printSpecification() {
        print("--- ASSET SPECIFICATION: \(appName) ---")
        print("\(transitionStrategy.title): \(transitionStrategy.description) [\(transitionStrategy.technicalSpec)]")
        print("\(lightingStrategy.title): \(lightingStrategy.description) [\(lightingStrategy.technicalSpec)]")
        print("\(scaleStrategy.title): \(scaleStrategy.description) [\(scaleStrategy.technicalSpec)]")
        print("\nVisual Hierarchy Checklist:")
        visualHierarchyChecklist.forEach { print("- \($0)") }
    }
}

// Execution
let spec = SubmissionAssetSpecification()
spec.printSpecification()
