
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

enum AIFeature: String, CaseIterable, Sendable {
    case voiceToVoice
    case imageGeneration
    case advancedReasoning
}

actor FeatureFlagManager {
    // Internal state: Mapping features to their rollout percentage (0.0 to 1.0)
    private var rolloutPercentages: [AIFeature: Double] = [:]
    private let userID: UUID
    
    // Default safe fallbacks
    private let defaultFlags: [AIFeature: Bool] = [
        .voiceToVoice: false,
        .imageGeneration: false,
        .advancedReasoning: false
    ]

    init(userID: UUID) {
        self.userID = userID
    }

    /// Determines if a feature is enabled for THIS specific user.
    func isFeatureEnabled(_ feature: AIFeature) async -> Bool {
        // 1. Check if we have a rollout percentage for this feature
        guard let percentage = rolloutPercentages[feature] else {
            return defaultFlags[feature] ?? false
        }

        // 2. Deterministic Hashing
        // We hash the userID + feature name to ensure a user's experience is consistent.
        let combinedString = "\(userID.uuidString)-\(feature.rawValue)"
        let hash = abs(combinedString.hashValue)
        let userScore = Double(hash % 100) / 100.0

        return userScore <= percentage
    }

    /// Simulates an asynchronous network call to fetch new configurations
    func refreshFlags() async {
        // Simulate network latency
        try? await Task.sleep(for: .seconds(1))
        
        // Mocking new values from a remote server (e.g., Firebase Remote Config)
        // voiceToVoice is now at 25% rollout
        self.rolloutPercentages = [
            .voiceToVoice: 0.25,
            .imageGeneration: 1.0,
            .advancedReasoning: 0.10
        ]
        print("Flags refreshed successfully.")
    }
}

// MARK: - Usage Example
@MainActor
struct FeatureViewModel: ObservableObject {
    @Published var isVoiceEnabled = false
    private let flagManager: FeatureFlagManager

    init(flagManager: FeatureFlagManager) {
        self.flagManager = flagManager
    }

    func loadConfiguration() async {
        await flagManager.refreshFlags()
        // Query the actor safely
        self.isVoiceEnabled = await flagManager.isFeatureEnabled(.voiceToVoice)
    }
}
