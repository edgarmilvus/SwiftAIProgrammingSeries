/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// App.tsx (or your main navigation file)
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Button } from 'react-native';
import { createBottomTabNavigator, BottomTabNavigationOptions } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { MaterialIcons } from '@expo/vector-icons'; // Using Expo vector icons
import { cn } from 'nativewind'; // Assuming nativewind setup

// --- Types ---
type TabParamList = {
  Home: { user: { name: string; level: number } };
  Workouts: undefined;
  Profile: { user: { name: string; level: number } };
};

const Tab = createBottomTabNavigator<TabParamList>();

// --- Components ---

// 1. Custom Tab Icon Component
const TabIcon = ({ iconName, color, size, isFocused }: { 
  iconName: keyof typeof MaterialIcons.glyphMap; 
  color: string; 
  size: number; 
  isFocused: boolean; 
}) => {
  return (
    <View className={cn("items-center justify-center p-1 rounded-lg", isFocused && "bg-slate-700")}>
      <MaterialIcons name={iconName} size={size} color={color} />
    </View>
  );
};

// 2. Home Screen
const HomeScreen = ({ navigation }: any) => {
  const dummyUser = { name: "Alex", level: 5 };

  return (
    <View className="flex-1 bg-slate-900 items-center justify-center p-4">
      <Text className="text-white text-2xl font-bold mb-4">Welcome, {dummyUser.name}!</Text>
      <Text className="text-slate-400 mb-8">Level: {dummyUser.level}</Text>
      <Button 
        title="Go to Profile" 
        onPress={() => navigation.navigate('Profile', { user: dummyUser })}
        color="#3b82f6"
      />
    </View>
  );
};

// 3. Workouts Screen (with Badge Logic)
const WorkoutsScreen = ({ navigation }: any) => {
  // Simulating global state for the badge count
  const [newWorkouts, setNewWorkouts] = useState(0);

  return (
    <View className="flex-1 bg-slate-900 items-center justify-center p-4">
      <Text className="text-white text-xl font-bold mb-4">Available Workouts</Text>
      
      <TouchableOpacity 
        className="bg-blue-600 px-4 py-2 rounded mb-4"
        onPress={() => setNewWorkouts(prev => prev + 1)}
      >
        <Text className="text-white">Simulate New Workout (+1 Badge)</Text>
      </TouchableOpacity>

      <Text className="text-slate-400">
        Badge Count: <Text className="text-red-500 font-bold">{newWorkouts}</Text>
      </Text>
      
      {/* Note: In a real app, we'd use Context or a global store to update the badge 
          from here and read it in the navigator options. 
          For this exercise, we simulate it by passing the count via navigation params 
          or a Context provider. Let's assume we update a Context here. */}
    </View>
  );
};

// 4. Profile Screen
const ProfileScreen = ({ route }: any) => {
  // Retrieve params safely
  const { user } = route.params || { user: { name: "Guest", level: 0 } };

  return (
    <View className="flex-1 bg-slate-900 items-center justify-center p-4">
      <Text className="text-white text-2xl font-bold mb-2">Profile</Text>
      <View className="bg-slate-800 p-6 rounded-xl w-full max-w-xs">
        <Text className="text-slate-300 mb-2">Name: <Text className="text-white font-semibold">{user.name}</Text></Text>
        <Text className="text-slate-300">Level: <Text className="text-white font-semibold">{user.level}</Text></Text>
      </View>
    </View>
  );
};

// --- Main Navigator Component ---
export default function App() {
  // Simulating a global state for the badge count to share across tabs
  const [badgeCount, setBadgeCount] = useState(0);

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          // Hide the default header
          headerShown: false,
          
          // Styling the Tab Bar
          tabBarStyle: {
            backgroundColor: '#0f172a', // bg-slate-900
            borderTopColor: '#334155', // border-slate-700
            height: 60,
            paddingBottom: 10,
            paddingTop: 8,
          },
          
          // Dynamic Icon rendering
          tabBarIcon: ({ focused, color, size }) => {
            let iconName: keyof typeof MaterialIcons.glyphMap = 'home';
            
            if (route.name === 'Workouts') iconName = 'fitness-center';
            else if (route.name === 'Profile') iconName = 'person';

            // Handle Badge Logic here
            let badgeDisplay = null;
            if (route.name === 'Workouts' && badgeCount > 0) {
              // Note: Tab bar icons don't natively support badges easily without custom wrapper.
              // We will visually indicate it via the icon style or overlay logic (simplified here).
              // A common pattern is to return a View with the badge.
              return (
                <View className="items-center justify-center">
                  <MaterialIcons name={iconName} size={size} color={color} />
                  <View className="absolute -top-1 -right-1 bg-red-500 rounded-full w-4 h-4 items-center justify-center">
                    <Text className="text-white text-[10px] font-bold">{badgeCount}</Text>
                  </View>
                </View>
              );
            }

            return <TabIcon iconName={iconName} color={color} size={size} isFocused={focused} />;
          },
          
          // Label Styling
          tabBarLabel: ({ focused }) => (
            <Text className={cn("text-xs mb-1", focused ? "text-blue-400 font-bold" : "text-slate-500")}>
              {route.name}
            </Text>
          ),
          
          // Remove the label from the tab bar if you prefer just icons, 
          // but requirements asked for label styling.
          tabBarShowLabel: true,
        })}
      >
        <Tab.Screen name="Home" component={HomeScreen} 
           listeners={({ navigation }) => ({
             tabPress: () => {
               // Pass user data implicitly or via context. 
               // Here we rely on the HomeScreen having access to the user object.
             },
           })}
        />
        
        {/* We pass the setBadgeCount function via initialParams or use a Context provider.
            Here, we wrap the WorkoutsScreen to demonstrate state lifting. */}
        <Tab.Screen name="Workouts">
          {props => <WorkoutsScreen {...props} setBadgeCount={setBadgeCount} />}
        </Tab.Screen>

        <Tab.Screen 
          name="Profile" 
          component={ProfileScreen}
          // Initial params passed from Home button
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
