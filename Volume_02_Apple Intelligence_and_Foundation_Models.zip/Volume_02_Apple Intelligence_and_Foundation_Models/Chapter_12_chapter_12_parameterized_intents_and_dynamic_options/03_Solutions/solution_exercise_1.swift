
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import AppIntents

// MARK: - ReminderPriority Enum
// Define your ReminderPriority enum here, conforming to AppEnum and Codable.
// Make sure it has a 'displayName' property.
@available(iOS 18.0, *)
enum ReminderPriority: String, AppEnum, Codable, CaseIterable {
    case low = "Low"
    case medium = "Medium"
    case high = "High"
    case urgent = "Urgent" // Added an extra case for variety

    static var allCases: [ReminderPriority] {
        [.low, .medium, .high, .urgent]
    }

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Reminder Priority"

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(stringLiteral: self.rawValue)
    }
}

@available(iOS 18.0, *)
struct SetReminderPriorityIntent: AppIntent {
    static var title: LocalizedStringResource = "Set Reminder Priority"
    static var description: IntentDescription = "Sets the priority level for a specific reminder."

    @Parameter(title: "Reminder Title", description: "The title of the reminder to set the priority for.")
    var title: String

    @Parameter(title: "Priority Level", description: "The new priority level for the reminder.")
    var priority: ReminderPriority // Use your defined enum here

    func perform() async throws -> some IntentResult {
        // Implement your logic here.
        // For this exercise, just print a confirmation message.
        print("Setting priority for reminder '\(title)' to \(priority.displayRepresentation.string).")
        
        // In a real app, you would update your data model here.
        // e.g., ReminderManager.shared.updatePriority(for: title, to: priority)
        
        return .result(
            value: "Priority for '\(title)' set to \(priority.displayRepresentation.string)",
            view: IntentResultView {
                VStack(alignment: .leading) {
                    Text("Priority Updated!")
                        .font(.headline)
                    Text("Reminder: \(title)")
                    Text("New Priority: \(priority.displayRepresentation.string)")
                }
            }
        )
    }
}
