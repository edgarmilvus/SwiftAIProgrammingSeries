
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import PrivateCloudCompute // Required for PrivateCloudComputeManager.Error
import Combine // Not strictly required for this async/await example, but often used with modern APIs

// MARK: - Mock AI Service

// Custom error for the mock AI service
enum MockAIError: Error, LocalizedError {
    case genericAIError(String)
    
    var errorDescription: String? {
        switch self {
        case .genericAIError(let message): return "Mock AI Error: \(message)"
        }
    }
}

// Mark the mock service as available only on iOS 18.0 and later
@available(iOS 18.0, *)
class MockTextGenerationService {
    // Configurable flag to simulate PCC unavailability
    var shouldSimulatePCCUnavailableError: Bool = false

    func generateText(prompt: String) async throws -> String {
        // Simulate network delay or complex computation using Swift Concurrency's Task.sleep
        try await Task.sleep(for: .milliseconds(500))

        if shouldSimulatePCCUnavailableError {
            // Simulate PCC being unavailable by throwing the specific error
            throw PrivateCloudComputeManager.Error.unavailable(reason: .systemLimited)
        }
        
        // Simulate other potential errors
        if prompt.contains("fail me") {
            throw MockAIError.genericAIError("The AI encountered an internal processing error.")
        }

        // Simulate a successful AI response based on prompt keywords
        if prompt.contains("meeting") {
            return "Regarding the meeting, I'm looking forward to discussing the agenda items."
        } else if prompt.contains("report") {
            return "I've reviewed the report and have some feedback to share."
        } else {
            return "This is an intelligent AI-generated response based on your prompt: '\(prompt)'."
        }
    }
}

// MARK: - Email Drafting Service

// Struct to encapsulate the result of the email drafting operation
struct EmailDraftResult {
    let reply: String
    let wasFallback: Bool
    let message: String // User-facing message about the outcome
}

// Mark the email drafting service as available only on iOS 18.0 and later
@available(iOS 18.0, *)
class EmailDraftingService {
    private let aiService: MockTextGenerationService

    // Dependency injection for the AI service, making the class testable
    init(aiService: MockTextGenerationService) {
        self.aiService = aiService
    }

    func draftReply(for incomingEmailContent: String) async -> EmailDraftResult {
        do {
            // Attempt to generate an intelligent reply using the AI service
            let intelligentReply = try await aiService.generateText(prompt: incomingEmailContent)
            return EmailDraftResult(reply: intelligentReply, wasFallback: false, message: "Intelligent reply generated.")
        } catch let error as PrivateCloudComputeManager.Error where error == .unavailable {
            // Step 3 & 4: Specific Error Handling and Fallback Logic
            // Catch the specific PrivateCloudComputeManager.Error.unavailable
            let fallbackReply = "Thank you for your email. I will get back to you shortly. (Basic reply due to Private Cloud Compute unavailability.)"
            return EmailDraftResult(reply: fallbackReply, wasFallback: true, message: "Private Cloud Compute unavailable. Using basic fallback.")
        } catch let error as MockAIError {
            // Handle other potential errors from the mock AI service
            let fallbackReply = "An error occurred while generating an intelligent reply. (Using basic fallback.)"
            return EmailDraftResult(reply: fallbackReply, wasFallback: true, message: "AI Error: \(error.localizedDescription). Using basic fallback.")
        } catch {
            // Catch any other unexpected errors
            let fallbackReply = "An unexpected error occurred while generating a reply. (Using basic fallback.)"
            return EmailDraftResult(reply: fallbackReply, wasFallback: true, message: "An unexpected error occurred: \(error.localizedDescription). Using basic fallback.")
        }
    }
}
