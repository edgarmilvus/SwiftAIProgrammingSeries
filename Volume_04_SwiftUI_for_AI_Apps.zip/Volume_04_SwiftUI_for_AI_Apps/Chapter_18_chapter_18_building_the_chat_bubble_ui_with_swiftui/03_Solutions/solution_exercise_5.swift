
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import SwiftUI

// MARK: - ThinkingIndicatorBubbleView
@available(iOS 18.0, *) // Using modern SwiftUI features for animation and timer
struct ThinkingIndicatorBubbleView: View {
    @State private var dotCount: Int = 0
    // Using a Timer.publish for a continuous, repeating animation
    let timer = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()
    let bubbleColor: Color = .gray.opacity(0.1) // Subtle background for indicator
    let dotColor: Color = .secondary.opacity(0.7) // Color for the dots

    var body: some View {
        HStack {
            HStack(spacing: 4) {
                // Dot 1
                Circle()
                    .frame(width: 8, height: 8)
                    .opacity(dotCount > 0 ? 1 : 0)
                    .scaleEffect(dotCount > 0 ? 1 : 0.8) // Subtle scale animation

                // Dot 2
                Circle()
                    .frame(width: 8, height: 8)
                    .opacity(dotCount > 1 ? 1 : 0)
                    .scaleEffect(dotCount > 1 ? 1 : 0.8)

                // Dot 3
                Circle()
                    .frame(width: 8, height: 8)
                    .opacity(dotCount > 2 ? 1 : 0)
                    .scaleEffect(dotCount > 2 ? 1 : 0.8)
            }
            .foregroundColor(dotColor) // Apply dot color
            .padding(8) // Compact padding
            .background(bubbleColor)
            .cornerRadius(12) // Slightly smaller corner radius for compact look
            .onReceive(timer) { _ in
                // Animate the dot count change
                withAnimation(.easeOut(duration: 0.2)) {
                    dotCount = (dotCount + 1) % 4 // Cycle: 0 -> 1 -> 2 -> 3 -> 0
                }
            }
            Spacer() // Push to leading edge like AI messages
        }
    }
}

// MARK: - ContentView for demonstration
@available(iOS 18.0, *)
struct ContentViewThinking: View {
    @State private var showThinkingIndicator: Bool = true
    @State private var aiResponse: String = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                UserChatBubbleView(message: "Generate a complex code snippet for me.")

                if showThinkingIndicator {
                    ThinkingIndicatorBubbleView()
                }

                if !aiResponse.isEmpty {
                    AIChatBubbleView(message: aiResponse)
                }
            }
            .padding()
        }
        .navigationTitle("AI Thinking Indicator")
        .onAppear {
            // Simulate AI thinking then responding
            Task {
                try await Task.sleep(for: .seconds(3))
                withAnimation {
                    showThinkingIndicator = false
                    aiResponse = "