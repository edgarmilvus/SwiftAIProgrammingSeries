
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI

// MARK: - Model Layer

struct PrivacyConfiguration {
    var epsilon: Double
}

/// Mock service representing a remote server receiving data.
class MockAnalyticsService {
    static let shared = MockAnalyticsService()
    
    func upload(noisyValue: Double) {
        print("📡 [Network] Uploading noisy sleep duration: \(String(format: "%.2f", noisyValue)) mins")
    }
}

/// The core logic for collecting and privatizing sleep data.
@Observable
class SleepDataViewModel {
    // Actual user data (Sensitive!)
    private let actualSleepDuration: Double = 480.0 // 8 hours
    
    // UI State
    var epsilon: Double = 1.0
    var reportedValue: Double = 0.0
    var errorMargin: Double = 0.0
    
    private let sensitivity: Double = 120.0 // Max possible deviation (e.g., 2 hours)
    
    func simulateSleepSession() {
        let config = PrivacyConfiguration(epsilon: epsilon)
        reportedValue = applyLDP(value: actualSleepDuration, config: config)
        errorMargin = abs(reportedValue - actualSleepDuration)
        
        MockAnalyticsService.shared.upload(noisyValue: reportedValue)
    }
    
    /// Implements Laplace-based Local Differential Privacy
    private func applyLDP(value: Double, config: PrivacyConfiguration) -> Double {
        let scale = sensitivity / config.epsilon
        let u = Double.random(in: -0.5..<0.5)
        let noise = -scale * (u < 0 ? -1.0 : 1.0) * log(1.0 - 2.0 * abs(u))
        return value + noise
    }
    
    var actualValueString: String {
        String(format: "%.0f mins", actualSleepDuration)
    }
    
    var reportedValueString: String {
        String(format: "%.0f mins", reportedValue)
    }
}

// MARK: - View Layer

struct VitalPulseView: View {
    @State private var viewModel = SleepDataViewModel()
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 30) {
                // Data Comparison Card
                VStack(spacing: 15) {
                    Text("Privacy vs. Utility Simulation")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                    
                    HStack(spacing: 40) {
                        VStack {
                            Text("Actual")
                                .font(.caption)
                            Text(viewModel.actualValueString)
                                .font(.title2).bold()
                                .foregroundStyle(.blue)
                        }
                        
                        Image(systemName: "arrow.right")
                        
                        VStack {
                            Text("Reported")
                                .font(.caption)
                            Text(viewModel.reportedValueString)
                                .font(.title2).bold()
                                .foregroundStyle(.green)
                        }
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.gray.opacity(0.1)))
                    
                    Text("Error Margin: \(Int(viewModel.errorMargin)) mins")
                        .font(.callout)
                        .foregroundStyle(viewModel.errorMargin > 60 ? .red : .primary)
                }
                .padding()

                // Privacy Control
                VStack(alignment: .leading) {
                    HStack {
                        Text("Privacy Budget (ε)")
                            .font(.headline)
                        Spacer()
                        Text(String(format: "%.1f", viewModel.epsilon))
                            .monospacedDigit()
                            .bold()
                    }
                    
                    Slider(value: $viewModel.epsilon, in: 0.1...5.0)
                        .tint(.green)
                    
                    HStack {
                        Text("High Privacy (Low ε)")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                        Spacer()
                        Text("High Utility (High ε)")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding()
                .background(RoundedRectangle(cornerRadius: 12).fill(Color.gray.opacity(0.1)))
                .padding(.horizontal)

                Button(action: {
                    viewModel.simulateSleepSession()
                }) {
                    Label("Simulate Sleep Session", systemImage: "moon.stars.fill")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.horizontal)
                
                Spacer()
            }
            .navigationTitle("VitalPulse LDP")
        }
    }
}

#Preview {
    VitalPulseView()
}
