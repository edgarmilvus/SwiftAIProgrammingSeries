
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Foundation

// MARK: - 1. AI Chat Client Protocol

/// A protocol defining the interface for an AI chat client.
@available(iOS 18.0, macOS 15.0, *)
protocol AIChatClientProtocol {
    /// Sends a message to the AI and returns its response.
    /// - Parameter message: The user's message.
    /// - Returns: The AI's response as a String.
    func sendMessage(_ message: String) async throws -> String
}

// MARK: - 2. Mock AI Chat Client

/// A mock implementation of AIChatClientProtocol for testing and development.
@available(iOS 18.0, macOS 15.0, *)
struct MockAIChatClient: AIChatClientProtocol {
    func sendMessage(_ message: String) async throws -> String {
        // Simulate a network delay
        try await Task.sleep(for: .seconds(0.5))
        if message.lowercased().contains("hello") {
            return "Hello there! How can I assist you today?"
        } else if message.lowercased().contains("swiftui") {
            return "SwiftUI is a declarative UI framework for Apple platforms. It's great for building apps!"
        } else {
            return "I received your message: '\(message)'. This is a canned response from the mock client."
        }
    }
}

// MARK: - 3. Custom Environment Key

@available(iOS 18.0, macOS 15.0, *)
private struct AIChatClientEnvironmentKey: EnvironmentKey {
    static let defaultValue: any AIChatClientProtocol = MockAIChatClient() // Provide a default mock client
}

// MARK: - 4. Extend EnvironmentValues

@available(iOS 18.0, macOS 15.0, *)
extension EnvironmentValues {
    var aiChatClient: any AIChatClientProtocol {
        get { self[AIChatClientEnvironmentKey.self] }
        set { self[AIChatClientEnvironmentKey.self] = newValue }
    }
}

// MARK: - 5. ChatView

@available(iOS 18.0, macOS 15.0, *)
struct ChatView: View {
    @Environment(\.aiChatClient) private var aiChatClient: any AIChatClientProtocol
    
    @State private var messageInput: String = ""
    @State private var chatHistory: [String] = []
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?

    var body: some View {
        VStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(chatHistory, id: \.self) { message in
                        Text(message)
                            .padding(8)
                            .background(message.starts(with: "You:") ? Color.blue.opacity(0.2) : Color.gray.opacity(0.1))
                            .cornerRadius(8)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            }
            .accessibilityIdentifier("chatHistoryScrollView")

            if isLoading {
                ProgressView("AI is typing...")
                    .padding(.bottom, 5)
            }
            
            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.bottom, 5)
            }

            HStack {
                TextField("Type a message...", text: $messageInput)
                    .textFieldStyle(.roundedBorder)
                    .disabled(isLoading)
                    .accessibilityIdentifier("messageInputTextField")

                Button("Send") {
                    sendMessage()
                }
                .disabled(messageInput.isEmpty || isLoading)
                .accessibilityIdentifier("sendMessageButton")
            }
            .padding()
        }
        .navigationTitle("AI Chat")
    }

    private func sendMessage() {
        let userMessage = messageInput
        chatHistory.append("You: \(userMessage)")
        messageInput = ""
        errorMessage = nil
        isLoading = true

        Task {
            do {
                let aiResponse = try await aiChatClient.sendMessage(userMessage)
                await MainActor.run {
                    chatHistory.append("AI: \(aiResponse)")
                }
            } catch {
                await MainActor.run {
                    errorMessage = "Error: \(error.localizedDescription)"
                }
            }
            await MainActor.run {
                isLoading = false
            }
        }
    }
}

// MARK: - 6. App Struct

@main
@available(iOS 18.0, macOS 15.0, *)
struct AIChatApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ChatView()
                    // .environment(\.aiChatClient, MockAIChatClient()) // Explicitly provide, though default is already Mock
            }
        }
    }
}
