
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

// LlamaService.swift
import Foundation
import LlamaCpp // Import the llama.cpp Swift bindings

class LlamaService: ObservableObject {
    @Published var isLoadingModel: Bool = false
    @Published var isGenerating: Bool = false
    @Published var currentResponse: String = ""
    @Published var errorMessage: String?
    @Published var showingErrorAlert: Bool = false

    private var llama: LlamaCpp?
    private var currentGenerationTask: Task<Void, Error>?

    // MARK: - Model Loading
    func loadModel() {
        guard llama == nil else { return } // Model already loaded
        isLoadingModel = true
        errorMessage = nil
        showingErrorAlert = false

        Task {
            do {
                // Assuming the model is bundled with the app
                guard let modelURL = Bundle.main.url(forResource: "tinyllama-1.1b-chat-v1.0.Q4_0", withExtension: "gguf") else {
                    throw LlamaError.modelNotFound
                }
                
                // Configure model parameters (adjust as needed for your model)
                let modelParams = LlamaCpp.ModelParameters(
                    // contextLength: 2048, // Adjust based on model capabilities
                    // gpuLayers: 0, // Set > 0 to offload layers to GPU if supported
                    // mainGpu: 0,
                    // tensorSplit: nil,
                    // vocabOnly: false,
                    // useMmap: true,
                    // useMlock: false
                )

                let newLlama = try LlamaCpp(modelPath: modelURL.path(percentEncoded: false), modelParameters: modelParams)
                
                // Initialize context parameters (adjust as needed)
                let contextParams = LlamaCpp.ContextParameters(
                    seed: UInt32.random(in: 0..<UInt32.max),
                    contextLength: 512, // Example context length
                    batchSize: 512,
                    // rmsNormEpsilon: 5e-6,
                    // nGpuLayers: 0, // Redundant if already set in modelParams, but can override
                    // embedding: false,
                    // ropeFrequencyBase: 10000.0,
                    // ropeFrequencyScale: 1.0,
                    // offloadKVCache: true
                    flashAttention: true
                )
                try newLlama.createContext(parameters: contextParams)

                await MainActor.run {
                    self.llama = newLlama
                    self.isLoadingModel = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "Failed to load LLM model: \(error.localizedDescription)"
                    self.showingErrorAlert = true
                    self.isLoadingModel = false
                }
            }
        }
    }
    
    // MARK: - LLM Generation
    func generate(prompt: String) {
        guard let llama = llama else {
            errorMessage = "LLM model not loaded."
            showingErrorAlert = true
            return
        }
        
        guard !isGenerating else { return } // Prevent multiple generations

        isGenerating = true
        currentResponse = ""
        errorMessage = nil
        showingErrorAlert = false

        currentGenerationTask = Task {
            do {
                // Configure generation parameters
                let generationParams = LlamaCpp.GenerationParameters(
                    // You might need to adjust these based on your model and desired output
                    // For chat models, you might want to wrap the prompt in chat format
                    // e.g., "[INST] \(prompt) [/INST]"
                    // temperature: 0.7,
                    // topK: 40,
                    // topP: 0.9,
                    // repeatPenalty: 1.1,
                    // maxTokens: 256
                )

                // The generate method returns an AsyncSequence of tokens
                for try await token in llama.generate(prompt: prompt, parameters: generationParams) {
                    // Check for cancellation
                    try Task.checkCancellation()
                    
                    await MainActor.run {
                        self.currentResponse += token
                    }
                }
                await MainActor.run {
                    self.isGenerating = false
                }
            } catch {
                if Task.isCancelled {
                    await MainActor.run {
                        self.currentResponse += "\n\n(Generation cancelled)"
                        self.isGenerating = false
                    }
                } else {
                    await MainActor.run {
                        self.errorMessage = "LLM generation error: \(error.localizedDescription)"
                        self.showingErrorAlert = true
                        self.isGenerating = false
                    }
                }
            }
        }
    }

    func stopGeneration() {
        currentGenerationTask?.cancel()
        currentGenerationTask = nil
        isGenerating = false // Immediately update UI
    }
    
    // Custom error for model not found
    enum LlamaError: LocalizedError {
        case modelNotFound
        var errorDescription: String? {
            switch self {
            case .modelNotFound: return "LLM model file not found in bundle. Did you add 'tinyllama-1.1b-chat-v1.0.Q4_0.gguf' to your project?"
            }
        }
    }
}
