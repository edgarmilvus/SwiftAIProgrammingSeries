
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import RealityKit
import CoreML
import ARKit
import Observation

// MARK: - 1. Sendable Data Transfer Object
/// This struct represents the "intelligence" produced by the AI.
/// It is Sendable so it can safely cross the boundary from the 
/// Inference Actor to the Main Actor.
@available(visionOS 2.0, *)
struct AIInferenceResult: Sendable {
    let label: String
    let confidence: Float
    let boundingBox: SIMD3<Float> // Spatial position in meters
}

// MARK: - 2. The Component (Data)
/// Components must be structs to ensure value semantics, 
/// which is critical for ECS performance and thread safety.
@available(visionOS 2.0, *)
struct SpatialAIComponent: Component, Codable {
    var lastInference: AIInferenceResult?
    var isProcessing: Bool = false
    var visualColor: UIColor = .green
}

// MARK: - 3. The Inference Actor (Logic Isolation)
/// This actor encapsulates the heavy ML workload.
/// It prevents the Neural Engine's latency from blocking the UI.
@available(visionOS 2.0, *)
actor SpatialInferenceActor {
    private var model: MLModel? // Assume a loaded CoreML model
    
    init() async throws {
        // In a real scenario, load your specific CoreML model here
        // self.model = try await MyDetectionModel().model
    }
    
    /// Performs inference on a given frame or image buffer.
    /// This is a non-blocking, asynchronous operation.
    func performInference(on input: CVPixelBuffer) async throws -> AIInferenceResult {
        // Simulate ML Latency
        try await Task.sleep(for: .milliseconds(30))
        
        // Mocking the result of a Core ML prediction
        return AIInferenceResult(
            label: "Object Detected",
            confidence: 0.98,
            boundingBox: [0.1, 0.0, -0.5] // 50cm in front of camera
        )
    }
}

// MARK: - 4. The System (The Orchestrator)
/// Systems run every frame. They bridge the gap between 
/// the asynchronous AI data and the synchronous RealityKit scene.
@available(visionOS 2.0, *)
class SpatialAISystem: System {
    // Define the query to find entities with our specific component
    private static let query = EntityQuery(where: .has(SpatialAIComponent.self))
    
    private let inferenceActor: SpatialInferenceActor
    
    required init(scene: Scene) {
        // In a real app, this would be injected or managed via a coordinator
        self.inferenceActor = Task { try await SpatialInferenceActor() }.value 
            ?? SpatialInferenceActor() // Simplified for example
    }
    
    func update(context: SceneUpdateContext) {
        // 1. Iterate through all entities that have a SpatialAIComponent
        context.scene.performQuery(Self.query).forEach { entity in
            guard var aiComponent = entity.components[SpatialAIComponent.self] else { return }
            
            // 2. If the AI is currently processing, we skip this frame 
            // to avoid overlapping inference tasks.
            if aiComponent.isProcessing { return }
            
            // 3. Trigger a new inference task asynchronously
            // We use a Task to bridge the synchronous 'update' method 
            // to the asynchronous 'performInference' method.
            Task { @MainActor in
                aiComponent.isProcessing = true
                entity.components[SpatialAIComponent.self] = aiComponent
                
                do {
                    // In a real app, you would pass the current ARFrame pixel buffer
                    let mockBuffer = CVPixelBuffer() 
                    let result = try await inferenceActor.performInference(on: mockBuffer)
                    
                    // 4. Update the component with the new data
                    // Because we are inside a @MainActor Task, this is thread-safe.
                    var updatedComponent = entity.components[SpatialAIComponent.self]
                    updatedComponent?.lastInference = result
                    updatedComponent?.isProcessing = false
                    
                    // Visual feedback: Change color based on confidence
                    updatedComponent?.visualColor = result.confidence > 0.9 ? .green : .yellow
                    
                    entity.components[SpatialAIComponent.self] = updatedComponent
                    
                    // 5. Update the Entity's transform based on AI data
                    if let pos = result.boundingBox as? SIMD3<Float> {
                        entity.position = pos
                    }
                    
                } catch {
                    print("Inference Error: \(error)")
                    aiComponent.isProcessing = false
                    entity.components[SpatialAIComponent.self] = aiComponent
                }
            }
        }
    }
}
