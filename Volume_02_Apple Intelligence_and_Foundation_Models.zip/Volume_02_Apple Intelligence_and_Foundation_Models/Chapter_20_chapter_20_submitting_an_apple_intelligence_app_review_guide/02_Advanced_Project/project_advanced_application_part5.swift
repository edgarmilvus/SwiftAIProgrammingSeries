
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

    // DocInsightCore/DocumentAnalyzer.swift
    import Foundation
    import Vision // For OCR
    import CoreGraphics // For CGImage

    /// Manages the OCR process and orchestrates calls to the Apple Intelligence service.
    /// This class acts as a central point for intelligent document analysis within the app.
    @available(iOS 18.0, *)
    final class DocumentAnalyzer {
        private let intelligenceService: AppleIntelligenceService

        /// Initializes the DocumentAnalyzer with an `AppleIntelligenceService` implementation.
        /// - Parameter intelligenceService: The service responsible for AI-powered document analysis.
        init(intelligenceService: AppleIntelligenceService = OnDeviceIntelligenceService()) {
            self.intelligenceService = intelligenceService
        }

        /// Performs Optical Character Recognition (OCR) on a given image.
        /// - Parameter image: The `CGImage` representing the document to scan.
        /// - Returns: The extracted text as a `String`.
        /// - Throws: `DocInsightError.ocrFailed` if OCR fails.
        ///
        /// **Review Guideline Context:**
        /// - **Privacy:** OCR is performed on-device using the Vision framework. No image data leaves the device.
        /// - **Performance:** Optimized for speed on Apple silicon, ensuring a responsive user experience.
        func performOCR(on image: CGImage) async throws -> String {
            // Bridge Vision's completion handler API to Swift's async/await.
            return try await withCheckedThrowingContinuation { continuation in
                let request = VNRecognizeTextRequest { (request, error) in
                    if let error = error {
                        continuation.resume(throwing: DocInsightError.ocrFailed(description: error.localizedDescription))
                        return
                    }

                    guard let observations = request.results as? [VNRecognizedTextObservation] else {
                        continuation.resume(throwing: DocInsightError.ocrFailed(description: "No text observations found."))
                        return
                    }

                    // Concatenate recognized text from all observations.
                    let recognizedText = observations.compactMap { observation in
                        // Get the top candidate for each recognized text region.
                        observation.topCandidates(1).first?.string
                    }.joined(separator: "\n") // Join lines with newlines for readability.

                    continuation.resume(returning: recognizedText)
                }

                // Configure request for fast, accurate recognition.
                request.recognitionLevel = .accurate // Prioritize accuracy over speed.
                request.usesLanguageCorrection = true // Improve results with language models.
                request.revision = VNRecognizeTextRequest.currentRevision // Use the latest revision.

                let handler = VNImageRequestHandler(cgImage: image, options: [:])
                do {
                    try handler.perform([request])
                } catch {
                    continuation.resume(throwing: DocInsightError.ocrFailed(description: error.localizedDescription))
                }
            }
        }

        /// Analyzes a document by performing OCR, then using Apple Intelligence for summarization,
        /// entity extraction, and contextual action suggestions.
        /// - Parameters:
        ///   - image: The `CGImage` of the document.
        ///   - documentTitle: A title for the new document.
        /// - Returns: A `Document` object populated with original text, summary, entities, and actions.
        /// - Throws: `DocInsightError` if any step fails.
        ///
        /// **Review Guideline Context:**
        /// - **User Experience:** The entire process should be seamless, with clear progress indicators
        ///   and a reasonable processing time.
        /// - **Error Handling:** Robust error handling is crucial for AI features, as models can sometimes
        ///   fail or return unexpected results. Graceful degradation is important.
        /// - **Feedback Loops:** Provide options for users to give feedback on AI accuracy to help improve models.
        func analyzeDocument(image: CGImage, documentTitle: String) async throws -> (Document, [ContextualAction]) {
            // 1. Perform OCR to get the raw text.
            let originalText = try await performOCR(on: image)
            
            var newDocument = Document(title: documentTitle, originalText: originalText)

            // 2. Summarize the document using on-device LLM.
            do {
                newDocument.summary = try await intelligenceService.summarizeDocument(text: originalText)
            } catch {
                // Log warning but don't stop the entire process if summarization fails.
                print("Warning: Could not summarize document: \(error.localizedDescription)")
                newDocument.summary = "Could not generate summary."
            }

            // 3. Extract entities using enhanced NaturalLanguage.
            var extractedEntities: [ExtractedEntity] = []
            do {
                extractedEntities = try await intelligenceService.extractEntities(text: originalText)
                newDocument.extractedEntities = extractedEntities
            } catch {
                print("Warning: Could not extract entities: \(error.localizedDescription)")
                newDocument.extractedEntities = []
            }

            // 4. Propose contextual actions based on extracted entities and document content.
            var proposedActions: [ContextualAction] = []
            do {
                proposedActions = try await intelligenceService.proposeContextualActions(documentText: originalText, entities: extractedEntities)
            } catch {
                print("Warning: Could not propose contextual actions: \(error.localizedDescription)")
                proposedActions = []
            }

            return (newDocument, proposedActions)
        }
        
        /// Provides text refinement suggestions using Apple's Writing Tools.
        /// - Parameters:
        ///   - text: The text snippet to be refined.
        ///   - refinementPrompt: The instruction for refinement (e.g., "make more professional").
        /// - Returns: The refined text.
        /// - Throws: `DocInsightError` if refinement fails.
        func getRefinementSuggestion(for text: String, with refinementPrompt: String) async throws -> String {
            return try await intelligenceService.refineText(text: text, prompt: refinementPrompt)
        }
    }
    