/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/UniversalImage.tsx
import React, { useState } from 'react';
import { View, StyleSheet, ActivityIndicator, Platform } from 'react-native';

// Conditional imports based on platform
let ExpoImage: any = null;
if (Platform.OS !== 'web') {
    // In a real Expo project, this import would work. 
    // We mock it here for the solution context if running in a non-expo environment.
    try {
        ExpoImage = require('expo-image').Image;
    } catch (e) {
        // Fallback mock if expo-image isn't installed in this specific environment
        ExpoImage = require('react-native').Image;
    }
}

// Define a generic prop type to encompass both native and web props
interface UniversalImageProps {
    source: any; // Can be { uri: string } or require()
    style?: any;
    resizeMode?: 'cover' | 'contain' | 'stretch' | 'center';
}

export const UniversalImage: React.FC<UniversalImageProps> = ({ source, style, resizeMode = 'cover' }) => {
    const [isLoading, setIsLoading] = useState(true);

    // Helper to handle source normalization
    const resolvedSource = typeof source === 'number' ? source : { uri: source?.uri };

    // 1. Native Implementation (Expo Go/Build)
    if (Platform.OS !== 'web' && ExpoImage) {
        return (
            <View style={[styles.container, style]}>
                <ExpoImage
                    source={resolvedSource}
                    style={StyleSheet.absoluteFill}
                    cachePolicy="memory-disk" // Aggressive caching
                    contentFit={resizeMode}
                    onLoadStart={() => setIsLoading(true)}
                    onLoadEnd={() => setIsLoading(false)}
                />
                {isLoading && <ActivityIndicator style={StyleSheet.absoluteFill} size="small" color="#000" />}
            </View>
        );
    }

    // 2. Web Implementation (Next.js or Standard Web)
    // Note: If using Next.js specifically, one might swap <img> for the Next <Image> component.
    // Here we use standard <img> for maximum universal compatibility without strict Next.js dependencies.
    return (
        <View style={[styles.container, style]}>
            <img
                src={typeof source === 'number' ? '' : (source?.uri || '')} // Web expects string URI
                style={{ 
                    width: '100%', 
                    height: '100%', 
                    objectFit: resizeMode // CSS equivalent of resizeMode
                } as React.CSSProperties}
                onLoad={() => setIsLoading(false)}
                alt="Universal Image"
            />
            {isLoading && <div style={styles.webLoader}>Loading...</div>}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        overflow: 'hidden',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#e1e4e8',
    },
    webLoader: {
        position: 'absolute',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        width: '100%',
        height: '100%',
        backgroundColor: '#e1e4e8',
        color: '#333',
        fontWeight: 'bold'
    }
});
