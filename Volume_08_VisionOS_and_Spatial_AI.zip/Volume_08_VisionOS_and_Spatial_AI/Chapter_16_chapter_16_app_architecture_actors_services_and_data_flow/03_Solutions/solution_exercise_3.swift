
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

@available(iOS 18.0, *)
struct AIContextPackage: Sendable {
    let currentQuery: String
    let retrievedContext: [String]
    let timestamp: Date
}

@available(iOS 18.0, *)
protocol MemoryProvider: Sendable {
    func fetchRelevantContext(for query: String) async throws -> [String]
}

@available(iOS 18.0, *)
/// An actor providing simulated RAG (Retrieval-Augmented Generation) capabilities.
actor ContextualMemoryService: MemoryProvider {
    
    // Simulated "Database"
    private let knowledgeBase = [
        "stress": "User mentioned work stress on Monday.",
        "exercise": "User started a morning running routine last week.",
        "diet": "User is trying to reduce sugar intake.",
        "sleep": "User reported difficulty sleeping on Tuesday."
    ]
    
    func fetchRelevantContext(for query: String) async throws -> [String] {
        // Simulate network/database latency
        try await Task.sleep(for: .seconds(0.5))
        
        let lowercasedQuery = query.lowercased()
        
        // Simple keyword matching to simulate vector search
        let matches = knowledgeBase.filter { keyword, _ in
            lowercasedQuery.contains(keyword)
        }.map { $0.value }
        
        return matches
    }
    
    /// Orchestrates the creation of a context package for the LLM.
    func generateContextPackage(for query: String) async throws -> AIContextPackage {
        let context = try await fetchRelevantContext(for: query)
        return AIContextPackage(
            currentQuery: query,
            retrievedContext: context,
            timestamp: Date()
        )
    }
}

// --- Implementation Challenge ---
@available(iOS 18.0, *)
struct JournalCoordinator {
    let memoryService: any MemoryProvider
    
    func processNewEntry(_ entry: String) async {
        print("Processing entry: \"\(entry)\"")
        
        do {
            // 1. Fetch context via the protocol
            let package = try await (memoryService as! ContextualMemoryService).generateContextPackage(for: entry)
            
            // 2. Combine context and entry into a prompt
            let prompt = """
            [CONTEXT]
            \(package.retrievedContext.joined(separator: "\n"))
            
            [USER ENTRY]
            \(package.currentQuery)
            
            [INSTRUCTION]
            Respond to the user entry considering the provided context.
            """
            
            print("--- FINAL PROMPT GENERATED ---")
            print(prompt)
            print("------------------------------")
            
        } catch {
            print("Failed to retrieve memory: \(error)")
        }
    }
}

// --- Execution ---
@available(iOS 18.0, *)
func runMemoryTest() async {
    let service = ContextualMemoryService()
    let coordinator = JournalCoordinator(memoryService: service)
    
    await coordinator.processNewEntry("I am feeling a lot of stress lately.")
}
