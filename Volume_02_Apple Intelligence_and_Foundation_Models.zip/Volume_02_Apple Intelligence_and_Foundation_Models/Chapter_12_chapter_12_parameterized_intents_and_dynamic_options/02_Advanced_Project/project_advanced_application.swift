
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AppIntents // Requires iOS 18+
import SwiftUI // For IntentResultView

// MARK: - 1. Define the Tone Enum with Dynamic Options

/// Represents various tones that can be applied to text.
/// This enum conforms to `AppEnum` to allow it to be used as a parameter type
/// for `AppIntent`s and to provide dynamic options based on context.
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
enum Tone: String, AppEnum, CaseIterable, Identifiable {
    case professional = "Professional"
    case casual = "Casual"
    case humorous = "Humorous"
    case concise = "Concise"
    case empathetic = "Empathetic"
    case persuasive = "Persuasive"
    case informative = "Informative"
    case poetic = "Poetic" // A less common one, might be suggested by AI

    var id: String { self.rawValue }

    /// A descriptive title for the tone, used in UI.
    static var typeDisplayRepresentation: TypeDisplayRepresentation {
        TypeDisplayRepresentation(name: "Tone")
    }

    // MARK: - Dynamic Options Provider for Tone Enum

    /// Provides dynamic options for the `Tone` enum based on contextual text.
    /// In a real application, this would involve calling a service (e.g., an on-device LLM
    /// via `Foundation.AI` or `WritingTools`) to analyze `selectedText`
    /// and suggest relevant tones.
    ///
    /// The `AppIntents` framework will automatically pass relevant context (like other
    /// intent parameters) to this method if defined with appropriate parameters.
    ///
    /// - Parameters:
    ///   - selectedText: The text currently selected by the user, providing context for tone suggestions.
    /// - Returns: An `AppEnumOptionsCollection` containing dynamically suggested tones.
    static func options(for selectedText: String) async throws -> AppEnumOptionsCollection<Tone> {
        // --- Under the Hood: Simulating Apple Intelligence ---
        // In a production app, this would involve:
        // 1. Importing `Foundation.AI` or `WritingTools`.
        // 2. Creating an `AIContext` or `WritingTools.Context`.
        // 3. Calling a method like `AI.suggestTones(for: selectedText)` or
        //    `WritingTools.analyze(text: selectedText).suggestedTones()`.
        // This simulation demonstrates the *pattern* of context-aware AI analysis.

        print("  [AI Simulation] Analyzing selected text for tone suggestions: '\(selectedText)'...")
        await Task.sleep(nanoseconds: 500_000_000) // Simulate AI processing delay

        var suggestedTones: [Tone] = []

        // Simple heuristic for demonstration; a real LLM would do this intelligently.
        let lowercasedText = selectedText.lowercased()
        if lowercasedText.contains("report") || lowercasedText.contains("meeting") || lowercasedText.contains("business") {
            suggestedTones.append(.professional)
            suggestedTones.append(.informative)
            suggestedTones.append(.concise)
        }
        if lowercasedText.contains("joke") || lowercasedText.contains("story") || lowercasedText.contains("narrative") {
            suggestedTones.append(.humorous)
            suggestedTones.append(.casual)
            suggestedTones.append(.poetic)
        }
        if lowercasedText.contains("pitch") || lowercasedText.contains("proposal") || lowercasedText.contains("sales") {
            suggestedTones.append(.persuasive)
            suggestedTones.append(.professional)
            suggestedTones.append(.concise)
        }
        if lowercasedText.contains("apology") || lowercasedText.contains("feedback") || lowercasedText.contains("concern") {
            suggestedTones.append(.empathetic)
            suggestedTones.append(.professional)
        }

        // Add some default common tones if no specific context matches, ensuring a baseline.
        if suggestedTones.isEmpty {
            suggestedTones.append(.professional)
            suggestedTones.append(.casual)
            suggestedTones.append(.concise)
        }

        // Ensure uniqueness and consistent ordering for presentation.
        let uniqueSuggestedTones = Array(Set(suggestedTones)).sorted { $0.rawValue < $1.rawValue }

        // Construct the `AppEnumOptionsCollection` to be returned.
        // This collection defines how the options are displayed in the UI.
        return AppEnumOptionsCollection {
            // Priority: Dynamically suggested tones, clearly marked.
            for tone in uniqueSuggestedTones {
                AppEnumCase(tone) {
                    DisplayRepresentation(title: "\(tone.rawValue) (AI Suggested)")
                }
            }
            // Fallback: All other available tones, for comprehensive choice.
            for tone in Tone.allCases where !uniqueSuggestedTones.contains(tone) {
                AppEnumCase(tone) {
                    DisplayRepresentation(title: tone.rawValue)
                }
            }
        }
    }
}

// MARK: - 2. Define the Parameterized Intent

/// An `AppIntent` that allows users to change the tone of selected text.
/// This intent demonstrates the use of a parameterized enum (`Tone`)
/// which provides dynamic options based on the input text.
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct ChangeToneIntent: AppIntent {
    /// The title displayed for this intent in system interfaces (e.g., Shortcuts app).
    static var title: LocalizedStringResource = "Change Tone of Text"
    /// A brief description of what the intent does.
    static var description = IntentDescription("Changes the tone of the selected text using Apple Intelligence's Writing Tools.")

    /// The text to be rephrased. This would typically come from the app's current context
    /// (e.g., selected text in a document editor).
    @Parameter(title: "Text to Rephrase", description: "The text whose tone you want to change.")
    var originalText: String

    /// The desired new tone for the text.
    /// This parameter's options are dynamically provided by the `Tone` enum itself,
    /// leveraging the `options(for:)` method which takes `originalText` as context.
    @Parameter(title: "Desired Tone", description: "The tone to apply to the text.")
    var selectedTone: Tone

    // MARK: - Parameter Options Provider (for `selectedTone`)

    /// This static method is crucial for providing dynamic options for specific parameters.
    /// The `AppIntents` framework calls this method when it needs to present choices
    /// for a parameter to the user.
    ///
    /// It inspects which parameter options are being requested and, for `\.selectedTone`,
    /// it delegates to `Tone.options(for:)`, passing the value of `originalText`
    /// from the current intent's state as context.
    ///
    /// - Parameter parameter: A `Parameters` object containing the current state of the intent's parameters.
    /// - Returns: An `AppOptionsCollection` containing the dynamically generated options.
    static func parameterOptions(for parameter: Parameters<Self>) async throws -> AppOptionsCollection {
        switch parameter {
        case \.selectedTone:
            // The `wrappedValue` of a parameter is an `Optional`, so we provide a default empty string
            // if `originalText` hasn't been set yet (e.g., when building the intent from scratch).
            let contextText = parameter.originalText.wrappedValue ?? ""
            return try await Tone.options(for: contextText)
        default:
            // For any other parameters that don't need dynamic options, return an empty collection.
            return AppOptionsCollection()
        }
    }

    /// Performs the tone change operation.
    /// In a real app, this would integrate with Apple Intelligence's Writing Tools
    /// or on-device LLM APIs to perform the actual text transformation.
    ///
    /// - Throws: `IntentError` if the operation fails (e.g., empty text, AI service error).
    /// - Returns: An `IntentResult` containing the modified text and a SwiftUI view for presentation.
    func perform() async throws -> some IntentResult {
        print("\n--- Executing ChangeToneIntent ---")
        print("Original Text: '\(originalText)'")
        print("Desired Tone: '\(selectedTone.rawValue)'")

        // --- Under the Hood: Simulating Apple Intelligence's Writing Tools ---
        // In a production app, this would involve:
        // 1. Using `WritingTools.rewrite(text: originalText, style: selectedTone.toWritingStyle())`
        //    or a similar `Foundation.AI` API call to transform the text.
        // This simulation demonstrates the *outcome* of such an operation.
        await Task.sleep(nanoseconds: 1_000_000_000) // Simulate AI processing time

        let modifiedText: String
        do {
            modifiedText = try await mockAppleIntelligenceToneChange(text: originalText, tone: selectedTone)
            print("  [AI Simulation] Text transformation complete.")
            print("Modified Text: '\(modifiedText)'")
        } catch {
            print("  [AI Simulation] Error during AI tone change simulation: \(error.localizedDescription)")
            // Re-throw the error for the intent framework to handle and present to the user.
            throw IntentError.runtimeError("Failed to change tone: \(error.localizedDescription)")
        }

        // Return the result, which could be displayed to the user within a system sheet
        // or passed back to the calling application.
        return .result(
            value: modifiedText,
            view: IntentResultView { // A simple SwiftUI view to display the outcome.
                VStack(alignment: .leading, spacing: 10) {
                    Text("Original Text:")
                        .font(.headline)
                        .foregroundColor(.gray)
                    Text(originalText)
                        .font(.body)
                        .padding(.bottom, 5)

                    Text("Desired Tone:")
                        .font(.headline)
                        .foregroundColor(.gray)
                    Text(selectedTone.rawValue)
                        .font(.body)
                        .padding(.bottom, 5)

                    Text("Modified Text:")
                        .font(.headline)
                        .foregroundColor(.accentColor)
                    Text(modifiedText)
                        .font(.body)
                }
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.white.opacity(0.05))
                .cornerRadius(10)
            }
        )
    }

    /// A mock function simulating Apple Intelligence's Writing Tools API for tone change.
    /// It provides predefined responses based on the chosen tone.
    ///
    /// - Parameters:
    ///   - text: The input text to be rephrased.
    ///   - tone: The desired tone.
    /// - Throws: `IntentError.invalidParameter` if the input text is empty.
    /// - Returns: A string representing the text rephrased in the desired tone.
    private func mockAppleIntelligenceToneChange(text: String, tone: Tone) async throws -> String {
        guard !text.isEmpty else {
            throw IntentError.invalidParameter("Text to rephrase cannot be empty.")
        }

        // This is a simplified simulation. A real implementation would use
        // advanced text generation and transformation capabilities of Apple Intelligence.
        switch tone {
        case .professional:
            return "Regarding the project timeline, it is imperative to allocate resources efficiently to ensure timely completion and adherence to all deliverables."
        case .casual:
            return "Hey, about that project timeline, we really gotta buckle down and get it done on time."
        case .humorous:
            return "The project's timeline is currently doing the limbo, and we need to coax it back to reality before it starts breakdancing past the deadline."
        case .concise:
            return "Project timeline critical; efficient resource allocation required for timely delivery."
        case .empathetic:
            return "I recognize the demands of the project timeline, and I'm confident that with focused effort, we can collectively achieve our delivery goals."
        case .persuasive:
            return "By proactively managing the project timeline, we can not only meet our deadlines but also unlock new efficiencies and demonstrate exceptional execution."
        case .informative:
            return "The established project timeline outlines key milestones and dependencies, requiring coordinated efforts to maintain the projected completion date."
        case .poetic:
            return "The loom of time, a project's thread, weaves a deadline, softly said. With focused hand, and vision bright, we guide its journey to the light."
        }
    }
}

// MARK: - 3. AppIntents Extension (Conceptual)

/// This is a conceptual representation of how an app would register its intents.
/// In a real app, this would be part of an `AppIntents` extension target,
/// allowing the system to discover and interact with your app's functionalities.
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct SmartDocumentEditorIntents: AppIntentsExtension {
    /// The list of `AppIntent` types that this extension provides.
    static var intents: [any AppIntent.Type] {
        [
            ChangeToneIntent.self,
            // You would add other intents for your app here (e.g., SummarizeTextIntent, TranslateTextIntent).
        ]
    }
}

// MARK: - 4. Main Application Simulation

/// Simulates the main application flow, demonstrating how `ChangeToneIntent`
/// would be invoked and how dynamic options are presented and utilized.
/// This `@main` structure allows the script to be run directly.
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
@main
struct SmartDocumentEditorApp {
    static func main() async {
        print("--- Smart Document Editor App Simulation Started ---")

        // Scenario 1: Business-related text
        let selectedText1 = "The project timeline is a critical factor for successful delivery, requiring prompt attention to resource allocation."
        print("\n>>> Scenario 1: User selected text: '\(selectedText1)'")

        // 1. Simulate the AppIntents framework querying for dynamic options.
        //    The framework would internally construct an intent instance and call its
        //    `parameterOptions(for:)` method, providing the already-set parameters.
        print("\n  [App] Fetching dynamic tone options for selected text 1...")
        do {
            // We create a temporary intent instance to pass its parameters to `parameterOptions`.
            // The `selectedTone` is a placeholder as its options are what we're fetching.
            let intentForOptions = ChangeToneIntent(originalText: selectedText1, selectedTone: .professional)
            let optionsCollection = try await ChangeToneIntent.parameterOptions(for: Parameters(originalText: intentForOptions.$originalText, selectedTone: intentForOptions.$selectedTone))

            print("  [App] Available Tone Options (dynamically suggested for text 1):")
            for option in optionsCollection.elements {
                if let toneCase = option.value as? Tone {
                    print("  - \(option.displayRepresentation.title) (Value: \(toneCase.rawValue))")
                }
            }

            // 2. Simulate user choosing an option (e.g., 'Professional') from the presented list.
            let chosenTone1: Tone = .professional
            print("\n  [User Action] User chose tone: \(chosenTone1.rawValue)")

            // 3. Execute the intent with the user's chosen parameters.
            let intent1 = ChangeToneIntent(originalText: selectedText1, selectedTone: chosenTone1)
            let result1 = try await intent1.perform()

            // 4. Process and display the result.
            if let modifiedText = result1.value as? String {
                print("\n  [App] Final Result for Scenario 1: '\(modifiedText)'")
            } else {
                print("\n  [App] Intent 1 returned no text result.")
            }

        } catch {
            print("\n  [App] Error during intent execution for Scenario 1: \(error.localizedDescription)")
        }

        print("\n---------------------------------------------------")

        // Scenario 2: Creative/Narrative text
        let selectedText2 = "I just finished writing a funny short story about a talking cat who accidentally became a detective."
        print("\n>>> Scenario 2: User selected text: '\(selectedText2)'")

        print("\n  [App] Fetching dynamic tone options for selected text 2...")
        do {
            let intentForOptions = ChangeToneIntent(originalText: selectedText2, selectedTone: .casual)
            let optionsCollection = try await ChangeToneIntent.parameterOptions(for: Parameters(originalText: intentForOptions.$originalText, selectedTone: intentForOptions.$selectedTone))

            print("  [App] Available Tone Options (dynamically suggested for text 2):")
            for option in optionsCollection.elements {
                if let toneCase = option.value as? Tone {
                    print("  - \(option.displayRepresentation.title) (Value: \(toneCase.rawValue))")
                }
            }

            // 2. Simulate user choosing an option (e.g., 'Humorous')
            let chosenTone2: Tone = .humorous
            print("\n  [User Action] User chose tone: \(chosenTone2.rawValue)")

            // 3. Execute the intent with the user's chosen parameters.
            let intent2 = ChangeToneIntent(originalText: selectedText2, selectedTone: chosenTone2)
            let result2 = try await intent2.perform()

            // 4. Process and display the result.
            if let modifiedText = result2.value as? String {
                print("\n  [App] Final Result for Scenario 2: '\(modifiedText)'")
            } else {
                print("\n  [App] Intent 2 returned no text result.")
            }

        } catch {
            print("\n  [App] Error during intent execution for Scenario 2: \(error.localizedDescription)")
        }

        print("\n--- Smart Document Editor App Simulation Complete ---")
    }
}
