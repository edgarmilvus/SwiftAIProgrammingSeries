
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

@available(iOS 18.0, *)
import Foundation

actor ResilienceEngine {
    let maxRetries = 3
    let baseDelay: Double = 2.0

    /// Executes a closure that performs a network request.
    /// If the request fails with a 429, it retries with exponential backoff.
    func execute<T>(
        operation: @escaping @Sendable () async throws -> T
    ) async throws -> T {
        var currentAttempt = 0
        
        while true {
            do {
                // Attempt the actual network work
                return try await operation()
            } catch let error as APIError {
                currentAttempt += 1
                
                // Check if we should retry: must be a 429 and within retry limit
                if case .rateLimited = error, currentAttempt <= maxRetries {
                    // Calculate delay: 2^1, 2^2, 2^3...
                    let delaySeconds = pow(baseDelay, Double(currentAttempt))
                    
                    print("Rate limited. Retrying in \(delaySeconds) seconds (Attempt \(currentAttempt))...")
                    
                    // Swift 6: Use the modern Task.sleep with ContinuousClock
                    try await Task.sleep(for: .seconds(delaySeconds))
                    
                    // Continue the loop to try again
                    continue
                } else {
                    // If it's not a 429 or we ran out of retries, throw the error
                    throw error
                }
            } catch {
                // If it's a non-APIError, don't retry; just throw
                throw error
            }
        }
    }
}

// MARK: - Usage Example
/*
let engine = ResilienceEngine()
let manager = NetworkManager()
let url = URL(string: "https://api.example.com/v1/chat/completions")!

do {
    let response: ChatCompletionResponse = try await engine.execute {
        try await manager.request(url, method: .post, body: myPrompt)
    }
    print("Success: \(response.id)")
} catch {
    print("Final Failure: \(error.localizedDescription)")
}
*/
