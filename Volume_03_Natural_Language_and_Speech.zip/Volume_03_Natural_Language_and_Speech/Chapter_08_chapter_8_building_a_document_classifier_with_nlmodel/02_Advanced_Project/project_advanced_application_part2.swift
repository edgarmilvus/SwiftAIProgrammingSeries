
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import NaturalLanguage // For NLModel
import Vision         // For VNRecognizeTextRequest
import UIKit          // For UIImage (in a real app context)
import CoreML         // For MLModelError and MLModel

// MARK: - Custom Error Types

/// Defines specific errors that can occur during document classification.
enum DocumentClassificationError: Error, LocalizedError {
    case modelNotFound
    case modelLoadingFailed(Error)
    case textRecognitionFailed(Error)
    case noTextFound
    case classificationFailed(Error)
    case invalidImageInput
    case unknown

    var errorDescription: String? {
        switch self {
        case .modelNotFound:
            return "The document classification model could not be found in the app bundle."
        case .modelLoadingFailed(let error):
            return "Failed to load the classification model: \(error.localizedDescription)"
        case .textRecognitionFailed(let error):
            return "Failed to recognize text from the image: \(error.localizedDescription)"
        case .noTextFound:
            return "No readable text was found in the document image."
        case .classificationFailed(let error):
            return "Failed to classify the document: \(error.localizedDescription)"
        case .invalidImageInput:
            return "The provided image input is invalid or could not be processed."
        case .unknown:
            return "An unknown error occurred during document classification."
        }
    }
}

// MARK: - Document Classification Service

/// A service responsible for loading an NLModel, performing OCR on images,
/// and classifying the extracted text to categorize documents.
@available(iOS 17.0, *) // NLModel and Vision are available on earlier versions, but async/await is more prevalent from iOS 15. Using 17 for modern context.
class DocumentClassificationService {

    /// The name of the Core ML model file (without extension) bundled with the app.
    private let modelFileName: String
    /// The loaded Natural Language model instance.
    private var documentClassifier: NLModel?
    /// A lock to prevent multiple concurrent model loading attempts.
    private let modelLoadingLock = NSLock()

    /// Initializes the service with the name of the NLModel file.
    /// - Parameter modelFileName: The name of the .mlmodel file (e.g., "DocumentClassifier").
    init(modelFileName: String = "DocumentClassifier") {
        self.modelFileName = modelFileName
    }

    /// Asynchronously loads the NLModel from the app bundle.
    /// This method ensures the model is loaded only once and is thread-safe.
    /// - Throws: `DocumentClassificationError` if the model cannot be found or loaded.
    private func loadModel() async throws {
        // Use a lock to ensure only one thread attempts to load the model at a time.
        modelLoadingLock.lock()
        defer { modelLoadingLock.unlock() }

        // If the model is already loaded, return immediately.
        guard documentClassifier == nil else { return }

        // Attempt to find the model URL in the app bundle.
        guard let modelURL = Bundle.main.url(forResource: modelFileName, withExtension: "mlmodelc") else {
            // .mlmodelc is the compiled version of .mlmodel
            throw DocumentClassificationError.modelNotFound
        }

        do {
            // Initialize NLModel with the URL. This can throw an error.
            documentClassifier = try NLModel(contentsOf: modelURL)
            print("✅ NLModel '\(modelFileName)' loaded successfully.")
        } catch {
            // Wrap the underlying error in our custom error type.
            throw DocumentClassificationError.modelLoadingFailed(error)
        }
    }

    /// Performs OCR on a given UIImage to extract all readable text.
    /// - Parameter image: The `UIImage` to process.
    /// - Returns: A `String` containing all concatenated recognized text.
    /// - Throws: `DocumentClassificationError` if text recognition fails or no text is found.
    private func recognizeText(from image: UIImage) async throws -> String {
        guard let cgImage = image.cgImage else {
            throw DocumentClassificationError.invalidImageInput
        }

        return try await withCheckedThrowingContinuation { continuation in
            // Create a text recognition request.
            let request = VNRecognizeTextRequest { request, error in
                if let error = error {
                    // Handle errors during text recognition.
                    continuation.resume(throwing: DocumentClassificationError.textRecognitionFailed(error))
                    return
                }

                guard let observations = request.results as? [VNTextObservation], !observations.isEmpty else {
                    // No text found in the image.
                    continuation.resume(throwing: DocumentClassificationError.noTextFound)
                    return
                }

                // Concatenate all recognized text.
                let recognizedText = observations.compactMap { observation in
                    // Get the top candidate for each text observation.
                    observation.topCandidates(1).first?.string
                }.joined(separator: "\n") // Join lines with a newline for better readability/context.

                continuation.resume(returning: recognizedText)
            }

            // Configure the request for fast and accurate text recognition.
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = true // Improves accuracy by correcting common errors.
            // Optionally, specify recognition languages.
            // request.recognitionLanguages = ["en-US", "fr-FR"]

            // Create a request handler for the image.
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

            // Perform the request. This is synchronous on the calling thread,
            // but `withCheckedThrowingContinuation` makes the `recognizeText` function
            // asynchronous from the caller's perspective.
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: DocumentClassificationError.textRecognitionFailed(error))
            }
        }
    }

    /// Classifies a given text string using the loaded NLModel.
    /// - Parameter text: The text content of the document.
    /// - Returns: The predicted category label as a `String`.
    /// - Throws: `DocumentClassificationError` if the model is not loaded or classification fails.
    private func classifyDocument(text: String) throws -> String {
        // Ensure the model is loaded before attempting classification.
        guard let classifier = documentClassifier else {
            // This case should ideally not be reached if `loadModel` is called first.
            throw DocumentClassificationError.modelLoadingFailed(
                NSError(domain: "DocumentClassificationService", code: 0, userInfo: [NSLocalizedDescriptionKey: "NLModel not loaded."])
            )
        }

        do {
            // Perform the prediction.
            let prediction = try classifier.prediction(for: text)
            print("📊 Text classified as: \(prediction)")
            return prediction
        } catch {
            throw DocumentClassificationError.classificationFailed(error)
        }
    }

    /// The main public method to classify a document from an image.
    /// It orchestrates model loading, text recognition, and classification.
    /// - Parameter image: The `UIImage` representing the document.
    /// - Returns: A `String` representing the predicted category of the document.
    /// - Throws: `DocumentClassificationError` for any failure during the process.
    func classifyDocument(from image: UIImage) async throws -> String {
        // 1. Ensure the model is loaded.
        // This call will only load the model once across multiple calls to classifyDocument.
        try await loadModel()

        // 2. Recognize text from the image asynchronously.
        let recognizedText = try await recognizeText(from: image)
        print("📝 Recognized text length: \(recognizedText.count) characters.")
        if recognizedText.isEmpty {
            throw DocumentClassificationError.noTextFound
        }
        
        // 3. Classify the recognized text.
        // NLModel.prediction is synchronous, but the overall function is async.
        let classification = try classifyDocument(text: recognizedText)
        return classification
    }
}

// MARK: - Example Usage in an iOS App Context

// This would typically be in a ViewController or ViewModel.
@available(iOS 17.0, *)
class DocumentProcessingViewModel: ObservableObject {
    @Published var classificationResult: String?
    @Published var errorMessage: String?
    @Published var isLoading: Bool = false

    private let classificationService = DocumentClassificationService()

    /// Simulates processing a document image.
    /// In a real app, `documentImage` would come from a `UIImagePickerController` or camera capture.
    /// - Parameter documentImage: The `UIImage` to classify.
    func processDocument(documentImage: UIImage) {
        isLoading = true
        errorMessage = nil
        classificationResult = nil

        Task {
            do {
                // Perform classification in a background task.
                let category = try await classificationService.classifyDocument(from: documentImage)
                // Update UI on the main actor.
                await MainActor.run {
                    self.classificationResult = "Category: \(category)"
                    self.isLoading = false
                }
            } catch {
                // Handle and display any errors.
                await MainActor.run {
                    if let docError = error as? DocumentClassificationError {
                        self.errorMessage = docError.localizedDescription
                    } else {
                        self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                    }
                    print("❌ Classification Error: \(self.errorMessage ?? "Unknown error")")
                    self.isLoading = false
                }
            }
        }
    }

    /// Helper to create a dummy image for demonstration purposes.
    /// In a real app, this would be a user-provided image.
    static func createDummyImage() -> UIImage? {
        // A simple white image to avoid crashing, but won't produce real OCR.
        // For a real test, you'd load an image from assets or file system.
        // Example: UIImage(named: "sample_invoice", in: Bundle.main, compatibleWith: nil)
        
        // To make this runnable without an actual image, we'll create a blank image.
        // In a real scenario, you'd use an image that actually contains text.
        let rect = CGRect(x: 0, y: 0, width: 500, height: 800)
        UIGraphicsBeginImageContextWithOptions(rect.size, false, 0.0)
        UIColor.white.setFill()
        UIRectFill(rect)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
}

// MARK: - How to Use (Conceptual App Entry Point)

/*
// In an actual SwiftUI or UIKit app, you would instantiate the ViewModel and call its methods.
// For example, in a SwiftUI View:

struct DocumentScannerView: View {
    @StateObject private var viewModel = DocumentProcessingViewModel()
    @State private var selectedImage: UIImage? // Assume this is populated by UIImagePicker

    var body: some View {
        VStack {
            if let image = selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 300)
            }
            
            Button("Scan & Classify Document") {
                // Use a dummy image for demonstration if no actual image is selected.
                let imageToProcess = selectedImage ?? DocumentProcessingViewModel.createDummyImage()!
                viewModel.processDocument(documentImage: imageToProcess)
            }
            .disabled(viewModel.isLoading)

            if viewModel.isLoading {
                ProgressView("Classifying...")
            }

            if let result = viewModel.classificationResult {
                Text(result)
                    .font(.headline)
                    .padding()
            }

            if let error = viewModel.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .onAppear {
            // For a real app, you'd prompt the user to select an image here.
            // For this example, we'll just demonstrate the classification logic.
        }
    }
}

// To run this in a Playground or a simple test:
@available(iOS 17.0, *)
func demonstrateClassification() async {
    let viewModel = DocumentProcessingViewModel()
    if let dummyImage = DocumentProcessingViewModel.createDummyImage() {
        print("Starting classification demonstration...")
        viewModel.processDocument(documentImage: dummyImage)
        
        // Wait for a bit to see the async result (in a real app, this is UI driven)
        // This is just for console output in a playground context.
        for _ in 0..<10 {
            try? await Task.sleep(nanoseconds: 1_000_000_000) // Sleep for 1 second
            if !viewModel.isLoading { break }
        }
        
        print("\n--- Demonstration Results ---")
        if let result = viewModel.classificationResult {
            print("Final Result: \(result)")
        } else if let error = viewModel.errorMessage {
            print("Final Error: \(error)")
        } else {
            print("No result or error yet (might still be loading or an issue with the demo setup).")
        }
    } else {
        print("Failed to create dummy image.")
    }
}

// Uncomment and run in an Xcode Playground to see output:
// Task {
//     await demonstrateClassification()
// }
*/
