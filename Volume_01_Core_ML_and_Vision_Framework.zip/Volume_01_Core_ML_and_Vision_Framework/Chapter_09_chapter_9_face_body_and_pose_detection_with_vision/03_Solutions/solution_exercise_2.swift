
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import AVFoundation
import Vision
import CoreMedia

// MARK: - HumanPresenceDetector
class HumanPresenceDetector {

    /// Detects human bodies in a video frame and assesses their prominence.
    /// - Parameters:
    ///   - sampleBuffer: The CMSampleBuffer representing a single video frame.
    ///   - prominenceThreshold: A CGFloat representing the minimum percentage of image height (e.g., 0.5 for 50%)
    ///                          a human's bounding box must occupy to be considered prominent.
    /// - Returns: A tuple containing a Bool (true if at least one prominent human is found)
    ///            and an optional VNHumanObservation (the largest prominent human, if any).
    func detectProminentHuman(in sampleBuffer: CMSampleBuffer, prominenceThreshold: CGFloat = 0.5) -> (Bool, VNHumanObservation?) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            print("Failed to get CVPixelBuffer from CMSampleBuffer.")
            return (false, nil)
        }

        let imageWidth = CVPixelBufferGetWidth(pixelBuffer)
        let imageHeight = CVPixelBufferGetHeight(pixelBuffer)

        // Create a Vision image request handler for the pixel buffer.
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])

        // Create a request to detect human rectangles.
        let request = VNDetectHumanRectanglesRequest()

        var prominentHumanFound = false
        var largestProminentHuman: VNHumanObservation?
        var largestProminentHumanHeight: CGFloat = 0.0

        do {
            try handler.perform([request])

            guard let observations = request.results as? [VNHumanObservation] else {
                print("No human observations found.")
                return (false, nil)
            }

            for observation in observations {
                // Get the bounding box of the detected human.
                let boundingBox = observation.boundingBox

                // Convert Vision's normalized bounding box height to pixel height.
                let humanPixelHeight = boundingBox.height * CGFloat(imageHeight)

                // Check if the human's height meets the prominence threshold.
                if humanPixelHeight >= prominenceThreshold * CGFloat(imageHeight) {
                    prominentHumanFound = true
                    // Keep track of the largest prominent human.
                    if humanPixelHeight > largestProminentHumanHeight {
                        largestProminentHumanHeight = humanPixelHeight
                        largestProminentHuman = observation
                    }
                }
            }

        } catch {
            print("Failed to perform VNDetectHumanRectanglesRequest: \(error)")
        }

        return (prominentHumanFound, largestProminentHuman)
    }
}

// MARK: - Example Usage (within AVCaptureVideoDataOutputSampleBufferDelegate)
/*
class CameraProcessor: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    let humanPresenceDetector = HumanPresenceDetector()
    let videoDataOutputQueue = DispatchQueue(label: "com.example.videoDataOutputQueue", qos: .userInitiated)

    // ... AVCaptureSession setup ...

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Perform detection on a background queue to avoid blocking the camera feed.
        videoDataOutputQueue.async {
            let (isProminent, largestHuman) = self.humanPresenceDetector.detectProminentHuman(in: sampleBuffer, prominenceThreshold: 0.5)

            DispatchQueue.main.async {
                if isProminent {
                    print("Prominent human detected!")
                    // Update UI, start workout, etc.
                    // You can also use `largestHuman` to draw an overlay or get more details.
                } else {
                    print("No prominent human detected.")
                    // Prompt user to adjust position.
                }
            }
        }
    }
}
*/
