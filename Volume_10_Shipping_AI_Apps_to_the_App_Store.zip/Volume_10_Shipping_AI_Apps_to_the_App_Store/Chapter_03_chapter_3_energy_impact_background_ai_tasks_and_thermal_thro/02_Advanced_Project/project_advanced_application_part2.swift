
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import UIKit
import Combine
import CoreML
import Vision

/// Represents the intensity and complexity of the AI workload.
/// By switching between these modes, we can proactively manage thermal output.
enum AIProcessingMode: Sendable, CaseIterable {
    /// Maximum performance: High-precision models, high frame rate (e.g., 30 FPS).
    case highPerformance
    /// Balanced: Medium-precision models, moderate frame rate (e.g., 15 FPS).
    case balanced
    /// Power Saver: Low-precision/quantized models, low frame rate (e.g., 5 FPS).
    case powerSaver
    /// Emergency: Suspend all AI tasks to allow the device to cool down.
    case suspended
}

/// A telemetry snapshot containing the current thermal and energy state.
struct ThermalTelemetry: Sendable {
    let thermalState: ProcessInfo.ThermalState
    let batteryLevel: Float
    let isCharging: Bool
}

/// An error type specific to the Thermal Orchestrator.
enum ThermalOrchestratorError: Error {
    case telemetryUnavailable
    case transitionFailed(from: AIProcessingMode, to: AIProcessingMode)
}

/// The `ThermalOrchestrator` is a thread-safe actor responsible for monitoring
/// the device's thermal state and determining the optimal AI processing mode.
/// It uses Swift 6 concurrency to ensure that telemetry updates do not cause data races.
@available(iOS 18.0, *)
actor ThermalOrchestrator {
    
    /// The current mode the application should be operating in.
    private(set) var currentMode: AIProcessingMode = .highPerformance
    
    /// A stream of mode updates that the Inference Engine can subscribe to.
    private let (modeStream, continuation) = AsyncStream<AIProcessingMode>.makeStream()
    
    /// A set of observers to prevent redundant notifications.
    private var lastReportedMode: AIProcessingMode?
    
    /// The underlying observers for system notifications.
    private var cancellables = Set<AnyCancellable>()

    init() {
        // Note: In a real production app, we would start observing 
        // notifications within a Task to avoid blocking the init.
    }

    /// Starts the telemetry monitoring loop.
    /// - Returns: An AsyncStream that emits new `AIProcessingMode` values whenever the state changes.
    func startMonitoring() -> AsyncStream<AIProcessingMode> {
        setupObservers()
        return modeStream
    }

    /// Configures the observers for thermal and battery state changes.
    private func setupObservers() {
        // Observe Thermal State changes
        NotificationCenter.default.publisher(for: ProcessInfo.thermalStateDidChangeNotification)
            .sink { [weak self] _ in
                Task { [weak self] in
                    await self?.evaluateState()
                }
            }
            .store(in: &cancellables)

        // Observe Battery changes (Thermal management is often coupled with battery health)
        NotificationCenter.default.publisher(for: UIDevice.batteryStateDidChangeNotification)
            .sink { [weak self] _ in
                Task { [weak self] in
                    await self?.evaluateState()
                }
            }
            .store(in: &cancellables)
    }

    /// The core logic engine that maps hardware telemetry to AI processing strategies.
    /// This implements a "Hysteresis" pattern to prevent rapid toggling between modes.
    private func evaluateState() {
        let thermalState = ProcessInfo.processInfo.thermalState
        let batteryLevel = UIDevice.current.batteryLevel
        let isCharging = UIDevice.current.batteryState == .charging || UIDevice.current.batteryState == .full

        let targetMode: AIProcessingMode

        // Decision Matrix:
        // 1. Critical Thermal -> Suspended
        // 2. Serious Thermal -> Power Saver
        // 3. Fair Thermal -> Balanced
        // 4. Nominal Thermal + Low Battery -> Power Saver
        // 5. Nominal Thermal + High Battery -> High Performance
        
        switch thermalState {
        case .critical:
            targetMode = .suspended
        case .serious:
            targetMode = .powerSaver
        case .fair:
            targetMode = .balanced
        case .nominal:
            if batteryLevel < 0.2 && !isCharging {
                targetMode = .powerSaver
            } else {
                targetMode = .highPerformance
            }
        @unknown default:
            targetMode = .balanced
        }

        updateMode(to: targetMode)
    }

    /// Updates the current mode and notifies subscribers if the mode has actually changed.
    /// - Parameter newMode: The newly calculated mode.
    private func updateMode(to newMode: AIProcessingMode) {
        guard newMode != currentMode else { return }
        
        // Implementation of Hysteresis: 
        // We require a more significant change to move from PowerSaver back to HighPerformance
        // to prevent "flapping" when the device is right on the thermal threshold.
        if currentMode == .powerSaver && newMode == .highPerformance {
            // Check if thermal state is truly nominal and battery is healthy
            // In a real app, we might add a timer here to ensure stability.
            print("Attempting to escalate from PowerSaver to HighPerformance...")
        }

        currentMode = newMode
        continuation.yield(newMode)
        print("AI Mode Transitioned to: \(newMode)")
    }
}

/// A high-level engine that executes Vision tasks.
/// It reacts to the `ThermalOrchestrator` to adjust its internal parameters.
@available(iOS 18.0, *)
class AdaptiveVisionEngine {
    
    private let orchestrator: ThermalOrchestrator
    private var processingTask: Task<Void, Never>?
    
    /// The current model being used (e.g., a heavy ResNet vs a light MobileNet).
    private var currentModel: VNCoreMLModel?
    
    /// The current target frame rate.
    private var targetFrameRate: Double = 30.0

    init(orchestrator: ThermalOrchestrator) {
        self.orchestrator = orchestrator
    }

    /// Starts the vision processing loop.
    func start() {
        processingTask = Task {
            // Subscribe to the mode stream from the actor
            let modeStream = await orchestrator.startMonitoring()
            
            // We use a TaskGroup or a simple loop to handle the mode changes
            // and the actual inference loop concurrently.
            await withTaskGroup(of: Void.self) { group in
                // Task 1: Listen for mode changes and update engine parameters
                group.addTask {
                    for await mode in modeStream {
                        await self.applyMode(mode)
                    }
                }
                
                // Task 2: The actual Inference Loop
                group.addTask {
                    await self.runInferenceLoop()
                }
            }
        }
    }

    /// Adjusts the engine's internal parameters based on the assigned mode.
    private func applyMode(_ mode: AIProcessingMode) async {
        switch mode {
        case .highPerformance:
            self.targetFrameRate = 30.0
            // In a real app: self.currentModel = heavyModel
            print("Engine: Switching to High Performance (30 FPS, Large Model)")
            
        case .balanced:
            self.targetFrameRate = 15.0
            // In a real app: self.currentModel = mediumModel
            print("Engine: Switching to Balanced (15 FPS, Medium Model)")
            
        case .powerSaver:
            self.targetFrameRate = 5.0
            // In a real app: self.currentModel = quantizedModel
            print("Engine: Switching to Power Saver (5 FPS, Quantized Model)")
            
        case .suspended:
            self.targetFrameRate = 0.0
            print("Engine: Suspending all AI tasks due to thermal pressure.")
        }
    }

    /// The main loop that simulates high-frequency inference.
    private func runInferenceLoop() async {
        while !Task.isCancelled {
            if targetFrameRate > 0 {
                // 1. Perform AI Inference
                await performInference()
                
                // 2. Calculate delay to maintain target frame rate
                let delayNanoseconds = UInt64(1_000_000_000 / targetFrameRate)
                try? await Task.sleep(nanoseconds: delayNanoseconds)
            } else {
                // If suspended, sleep longer to prevent busy-waiting
                try? await Task.sleep(nanoseconds: 1_000_000_000)
            }
        }
    }

    /// Simulates the heavy lifting of CoreML/Vision inference.
    private func performInference() async {
        // In a real application, this would be:
        // let request = VNCoreMLRequest(model: currentModel!) { ... }
        // try? await handler.perform([request])
        
        // Simulating NPU/GPU workload
        // We use Task.yield() to ensure we don't block the executor
        await Task.yield()
    }
    
    func stop() {
        processingTask?.cancel()
    }
}

// MARK: - Implementation Logic Breakdown

/*
 1. **The Telemetry Layer (ThermalOrchestrator Actor)**:
    - We use an `actor` to ensure that the `currentMode` and the `continuation` of our `AsyncStream` 
      are accessed in a thread-safe manner.
    - We listen to `ProcessInfo.thermalStateDidChangeNotification`. This is the most critical 
      system signal for AI developers.
    - We implement a "Decision Matrix" that maps hardware states to `AIProcessingMode`. 
      This includes a check for battery level, as low battery combined with high heat 
      is a recipe for immediate device shutdown.

 2. **The Hysteresis Pattern**:
    - To prevent "Mode Flapping" (where the device rapidly switches between Balanced and 
      High Performance as it crosses a temperature threshold), the `updateMode` function 
      is designed to be cautious. In a production environment, you would add a "cooldown" 
      timer that requires the device to stay in a `nominal` state for X seconds before 
      upgrading the mode.

 3. **The AsyncStream Communication**:
    - Instead of using traditional delegation or Combine observers, we use `AsyncStream`. 
      This allows the `AdaptiveVisionEngine` to iterate over mode changes using a 
      modern `for await` loop, which is much cleaner and integrates perfectly with 
      Swift's structured concurrency.

 4. **The Inference Engine (AdaptiveVisionEngine)**:
    - This class manages the actual workload. It runs two concurrent tasks within a 
      `TaskGroup`: one to listen for mode updates and another to run the inference loop.
    - The `runInferenceLoop` uses `Task.sleep` to regulate the "heartbeat" of the AI. 
      By adjusting the `targetFrameRate` dynamically, we directly control the duty cycle 
      of the NPU/GPU.
    - The `applyMode` function is where the "Model Switching" logic lives. For an AI app, 
      this means swapping a 100MB FP32 model for a 25MB INT8 quantized model when the 
      device gets hot.

 5. **Concurrency and Safety**:
    - The use of `@available(iOS 18.0, *)` ensures we are using the latest capabilities.
    - `Task.yield()` is used within the simulated inference to ensure that the heavy 
      computational loop does not starve the main thread or other high-priority tasks.
*/
