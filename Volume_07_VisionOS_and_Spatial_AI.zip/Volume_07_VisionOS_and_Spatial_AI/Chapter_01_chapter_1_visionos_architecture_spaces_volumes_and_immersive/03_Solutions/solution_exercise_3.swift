
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI

enum AppMode {
    case management
    case inspection
    case studio
}

// 1. The Orchestrator: Manages the complex state of spatial modes
@Observable
@MainActor
class SpatialOrchestrator {
    var currentMode: AppMode = .management
    var activeImmersiveSessionID: ImmersiveSpaceSession.ID? = nil
    var selectedPhotoID: UUID? = nil

    func enterStudioMode(context: some OpenImmersiveSpaceAction) async {
        // Requirement: Handle conflicts by dismissing existing space first
        if activeImmersiveSessionID != nil {
            await dismissStudioMode(context: context)
        }
        
        // Transitioning to Studio
        let result = await context.openImmersiveSpace(id: "studio-space")
        switch result {
        case .opened(let id):
            activeImmersiveSessionID = id
            currentMode = .studio
        case .error, .userCancelled:
            currentMode = .management
        }
    }

    func dismissStudioMode(context: some DismissImmersiveSpaceAction) async {
        if activeImmersiveSessionID != nil {
            await context.dismissImmersiveSpace()
            activeImmersiveSessionID = nil
            currentMode = .management
        }
    }
}

// 2. The Main App Structure
@main
struct LuminaPhotoProApp: App {
    @State private var orchestrator = SpatialOrchestrator()

    var body: some Scene {
        // Mode A: Management Window
        WindowGroup(id: "library") {
            LibraryView(orchestrator: orchestrator)
        }

        // Mode B: Inspection Volume
        WindowGroup(id: "inspector", for: UUID.self) { $photoID in
            if let id = photoID {
                InspectionVolumeView(photoID: id)
            }
        }
        .windowStyle(.volumetric)
        .defaultSize(width: 0.4, height: 0.4, depth: 0.4, in: .meters)

        // Mode C: Studio Immersive Space
        ImmersiveSpace(id: "studio-space") {
            StudioEnvironmentView()
        }
    }
}

// 3. The Library View (The UI Controller)
struct LibraryView: View {
    var orchestrator: SpatialOrchestrator
    @Environment(\.openWindow) private var openWindow
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace

    var body: some View {
        VStack {
            Text("LuminaPhoto Pro Library")
                .font(.title)
            
            Button("Inspect Selected Photo") {
                let id = UUID()
                orchestrator.selectedPhotoID = id
                openWindow(id: "inspector", value: id)
            }
            
            Button("Enter Studio Mode") {
                Task {
                    await orchestrator.enterStudioMode(context: openImmersiveSpace)
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(.purple)
            
            if orchestrator.currentMode == .studio {
                Button("Exit Studio") {
                    Task {
                        await orchestrator.dismissStudioMode(context: dismissImmersiveSpace)
                    }
                }
                .buttonStyle(.bordered)
            }
        }
        .frame(width: 400, height: 300)
    }
}

// Placeholder Views
struct InspectionVolumeView: View { let photoID: UUID; var body: some View { Text("Inspecting \(photoID.uuidString)") } }
struct StudioEnvironmentView: View { var body: some View { Text("Professional Studio Environment") } }
