
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import RealityKit
import ARKit
import Vision

// 1. Actor to handle spatial smoothing to prevent "jitter"
actor SpatialSmoother {
    private var lastPositions: [String: [SIMD3<Float>]] = [:]
    private let windowSize = 5

    func smooth(id: String, newPosition: SIMD3<Float>) -> SIMD3<Float> {
        var positions = lastPositions[id] ?? []
        positions.append(newPosition)
        if positions.count > windowSize { positions.removeFirst() }
        lastPositions[id] = positions
        
        // Calculate average position (Low-pass filter)
        let sum = positions.reduce(SIMD3<Float>(0, 0, 0), +)
        return sum / Float(positions.count)
    }
}

class SpatialTagManager: ObservableObject {
    private var anchorMap: [String: AnchorEntity] = [:]
    private let smoother = SpatialSmoother()
    var arView: ARView?

    func processDetections(_ observations: [VNRecognizedObjectObservation]) {
        guard let arView = arView else { return }

        for observation in observations {
            let label = observation.labels.first?.identifier ?? "Unknown"
            let center = CGPoint(x: observation.boundingBox.midX, y: observation.boundingBox.midY)
            
            // 2. Perform Raycast to find 3D intersection
            // Note: In visionOS, this uses the scene's raycasting capabilities
            let results = arView.raycast(from: center, allowing: .estimatedPlane, alignment: .any)
            
            if let firstResult = results.first {
                let worldPosition = SIMD3<Float>(firstResult.worldTransform.columns.3.x,
                                                firstResult.worldTransform.columns.3.y,
                                                firstResult.worldTransform.columns.3.z)
                
                Task {
                    // 3. Apply Temporal Smoothing
                    let smoothedPosition = await smoother.smooth(id: label, newPosition: worldPosition)
                    
                    await MainActor.run {
                        updateOrAddTag(label: label, position: smoothedPosition)
                    }
                }
            }
        }
    }

    @MainActor
    private func updateOrAddTag(label: String, position: SIMD3<Float>) {
        guard let arView = arView else { return }

        if let existingAnchor = anchorMap[label] {
            // Smoothly move existing tag
            existingAnchor.position = position
        } else {
            // 4. Create new 3D Tag
            let anchor = AnchorEntity(world: position)
            let mesh = MeshResource.generateText(label, extrusionDepth: 0.01, font: .systemFont(ofSize: 0.05))
            let material = SimpleMaterial(color: .white, isMetallic: true)
            let entity = ModelEntity(mesh: mesh, materials: [material])
            
            anchor.addChild(entity)
            arView.scene.addAnchor(anchor)
            anchorMap[label] = anchor
        }
    }
}

// SwiftUI View would host the ARView and pass detections to SpatialTagManager
