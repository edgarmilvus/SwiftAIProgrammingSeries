
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import Observation
import SwiftUI

@available(iOS 17.0, macOS 14.0, watchOS 10.0, tvOS 17.0, *)
@MainActor // Ensure all access to this model happens on the main actor
@Observable
class ChatViewModel {
    var messages: [ChatMessage] = []
    var currentStreamingResponse: String = ""
    var isGenerating: Bool = false
    var error: Error?
    
    func appendStreamingChunk(_ chunk: String) {
        currentStreamingResponse += chunk
        // Potentially debounce or throttle UI updates for very fast streams
    }
    
    func finalizeStreamingResponse() {
        if !currentStreamingResponse.isEmpty {
            messages.append(ChatMessage(content: currentStreamingResponse, role: .assistant))
            currentStreamingResponse = ""
        }
        isGenerating = false
    }
    
    func startGeneration() {
        isGenerating = true
        currentStreamingResponse = ""
        error = nil
        // Kick off the streaming task here
    }
}

// A SwiftUI View consuming the ViewModel:
/*
@available(iOS 17.0, macOS 14.0, watchOS 10.0, tvOS 17.0, *)
struct ChatView: View {
    @State private var viewModel = ChatViewModel() // Or @Environment(ChatViewModel.self)
    
    var body: some View {
        VStack {
            ScrollView {
                ForEach(viewModel.messages) { message in
                    Text(message.content)
                }
                Text(viewModel.currentStreamingResponse) // Updates live!
                    .foregroundStyle(.gray)
            }
            
            Button("Generate Response") {
                Task {
                    viewModel.startGeneration()
                    // Simulate streaming
                    let chunks = ["Hello", " there", "!", " How", " can", " I", " help", " you", " today", "?"]
                    for chunk in chunks {
                        try? await Task.sleep(for: .milliseconds(50))
                        await viewModel.appendStreamingChunk(chunk)
                    }
                    await viewModel.finalizeStreamingResponse()
                }
            }
            .disabled(viewModel.isGenerating)
        }
    }
}
*/
