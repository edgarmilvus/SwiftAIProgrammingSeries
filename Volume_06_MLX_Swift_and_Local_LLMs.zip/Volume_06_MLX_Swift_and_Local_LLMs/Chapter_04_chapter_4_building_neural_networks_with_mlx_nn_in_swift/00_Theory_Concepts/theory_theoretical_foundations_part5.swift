
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN
import Foundation
import Observation // For @Observable

@available(iOS 17.0, *) // @Observable available from iOS 17
@Observable
class TrainingMonitor {
    var currentEpoch: Int = 0
    var currentLoss: Float = 0.0
    var inferenceResult: String = "No prediction yet."

    // This class could be observed by a SwiftUI View
    // e.g., Text("Epoch: \(monitor.currentEpoch)")
}

@available(iOS 18.0, *)
actor ObservableModelActor {
    private var model: MyModel
    private var optimizer: SGD
    let monitor: TrainingMonitor // Expose the monitor for observation

    init(model: MyModel, learningRate: Float, monitor: TrainingMonitor) {
        self.model = model
        self.optimizer = SGD(learningRate: learningRate)
        self.monitor = monitor
    }

    func trainStep(input: MLXArray, target: MLXArray, epoch: Int) async {
        await Task {
            let lossFn = { (model: MyModel) in
                lossFunction(model: model, input: input, target: target)
            }
            let (loss, gradients) = valueAndGradient(lossFn)(model)
            optimizer.update(model: model, gradients: gradients)
            MLX.eval(model.parameters(), loss, gradients)

            // Update observable state
            monitor.currentEpoch = epoch
            monitor.currentLoss = loss.item()
        }.value
    }

    func performInferenceAndUpdateMonitor(input: MLXArray) async {
        let prediction = await performInference(input: input)
        monitor.inferenceResult = "Prediction: \(prediction.item())"
    }

    private func performInference(input: MLXArray) async -> MLXArray {
        // ... (inference logic as before) ...
        let output = model(input)
        MLX.eval(output)
        return output
    }
}
