
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

// MARK: - DocumentChunk Structure

/// Represents a semantically meaningful chunk of a document.
struct DocumentChunk: Identifiable, CustomStringConvertible {
    let id: String // Unique identifier for the chunk
    let content: String // The text content of the chunk
    let documentId: String // ID of the original document
    let startIndex: Int // Starting character index in the original document
    let endIndex: Int // Ending character index in the original document

    var description: String {
        return "Chunk(id: \(id), docId: \(documentId), start: \(startIndex), end: \(endIndex), content: \"\(content.prefix(50))...\")"
    }
}

// MARK: - DocumentIndexer Class

@available(macOS 14.0, *) // Requires async/await for URL.lines
class DocumentIndexer {
    // In-memory storage for indexed chunks, keyed by documentId.
    private var indexedChunks: [String: [DocumentChunk]] = [:]

    /// Indexes a document from a given URL, splitting its content into chunks.
    /// - Parameter url: The URL pointing to the plain text file.
    /// - Returns: An array of `DocumentChunk`s created from the document.
    /// - Throws: An error if the file cannot be read.
    func indexDocument(at url: URL) async throws -> [DocumentChunk] {
        let documentId = url.lastPathComponent // Use filename as document ID
        var currentOffset = 0
        var chunks: [DocumentChunk] = []
        var chunkIndex = 0

        // Read file content line by line for efficiency, then process paragraphs
        for try await line in url.lines {
            let trimmedLine = line.trimmingCharacters(in: .whitespacesAndNewlines)

            // Simple chunking strategy: treat non-empty lines as paragraphs
            // or concatenate multiple lines into a larger chunk if needed.
            // For this exercise, we'll treat each non-empty line as a chunk.
            if !trimmedLine.isEmpty {
                let id = _generateChunkId(for: trimmedLine, documentId: documentId, index: chunkIndex)
                let newChunk = DocumentChunk(
                    id: id,
                    content: trimmedLine,
                    documentId: documentId,
                    startIndex: currentOffset,
                    endIndex: currentOffset + trimmedLine.count - 1
                )
                chunks.append(newChunk)
                chunkIndex += 1
            }
            // Update offset for the next line, including the newline character
            currentOffset += line.count + 1 // +1 for the newline character
        }

        indexedChunks[documentId] = chunks
        print("Indexed \(chunks.count) chunks for document: \(documentId)")
        return chunks
    }

    /// Generates a unique identifier for a document chunk.
    /// For simplicity, concatenates documentId with the chunk's index.
    private func _generateChunkId(for chunkContent: String, documentId: String, index: Int) -> String {
        // A more robust ID might use a hash of the content + documentId
        // but for this exercise, a simple concatenation is sufficient.
        return "\(documentId)-\(index)"
    }

    /// Retrieves all indexed chunks for a given document ID.
    /// - Parameter documentId: The ID of the document.
    /// - Returns: An array of `DocumentChunk`s, or `nil` if the document is not found.
    func getChunks(for documentId: String) -> [DocumentChunk]? {
        return indexedChunks[documentId]
    }

    /// Retrieves all indexed chunks across all documents.
    func getAllChunks() -> [DocumentChunk] {
        return indexedChunks.values.flatMap { $0 }
    }
}

// MARK: - Example Usage (for testing)

@available(macOS 14.0, *)
func runExercise1() async {
    print("--- Exercise 1: Building a Basic In-Memory Document Indexer ---")

    let indexer = DocumentIndexer()

    // Create a dummy text file for indexing
    let fileContent = """
    This is the first paragraph of a sample document.
    It contains some introductory text.

    Here is the second paragraph.
    It's a bit longer and discusses more details.
    Perhaps it has multiple sentences.

    Finally, the third paragraph concludes the document.
    """
    let filename = "sample_document.txt"
    let fileURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(filename)

    do {
        try fileContent.write(to: fileURL, atomically: true, encoding: .utf8)
        print("Dummy file created at: \(fileURL.path)")

        let indexedChunks = try await indexer.indexDocument(at: fileURL)
        print("\nIndexed \(indexedChunks.count) chunks:")
        for chunk in indexedChunks {
            print(chunk)
        }

        if let retrievedChunks = indexer.getChunks(for: filename) {
            print("\nRetrieved \(retrievedChunks.count) chunks for \(filename):")
            for chunk in retrievedChunks {
                print(chunk.id)
            }
        }

        // Clean up the dummy file
        try FileManager.default.removeItem(at: fileURL)
        print("\nDummy file removed.")

    } catch {
        print("Error during Exercise 1: \(error.localizedDescription)")
    }
}

// To run this example in a playground or app:
// Task {
//     await runExercise1()
// }
