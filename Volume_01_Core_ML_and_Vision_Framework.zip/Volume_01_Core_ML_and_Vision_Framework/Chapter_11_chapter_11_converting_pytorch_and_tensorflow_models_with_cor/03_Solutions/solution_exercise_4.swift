
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

// MARK: - Utility Extensions (Place in a separate file in a real project)
import UIKit
import CoreVideo
import CoreGraphics
import CoreImage
import os // For os_signpost

// UIImage+toCVPixelBuffer (from Exercise 1)
extension UIImage {
    func toCVPixelBuffer(pixelFormatType: OSType = kCVPixelFormatType_32BGRA, width: Int? = nil, height: Int? = nil) -> CVPixelBuffer? {
        let imageWidth = width ?? Int(self.size.width)
        let imageHeight = height ?? Int(self.size.height)

        var pixelBuffer: CVPixelBuffer?
        let attributes: [String: Any] = [
            kCVPixelBufferCGImageCompatibilityKey as String: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey as String: true,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]

        CVPixelBufferCreate(kCFAllocatorDefault,
                            imageWidth,
                            imageHeight,
                            pixelFormatType,
                            attributes as CFDictionary,
                            &pixelBuffer)

        guard let buffer = pixelBuffer else { return nil }

        CVPixelBufferLockBaseAddress(buffer, .zero)
        defer { CVPixelBufferUnlockBaseAddress(buffer, .zero) }

        let pixelData = CVPixelBufferGetBaseAddress(buffer)
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: pixelData,
                                width: imageWidth,
                                height: imageHeight,
                                bitsPerComponent: 8,
                                bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
                                space: rgbColorSpace,
                                bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue)

        context?.translateBy(x: 0, y: CGFloat(imageHeight))
        context?.scaleBy(x: 1.0, y: -1.0)

        UIGraphicsPushContext(context!)
        self.draw(in: CGRect(x: 0, y: 0, width: CGFloat(imageWidth), height: CGFloat(imageHeight)))
        UIGraphicsPopContext()

        return buffer
    }
}

// CVPixelBuffer+toUIImage (from Exercise 3)
extension CVPixelBuffer {
    func toUIImage() -> UIImage? {
        let ciImage = CIImage(cvPixelBuffer: self)
        let context = CIContext()
        guard let cgImage = context.createCGImage(ciImage, from: ciImage.extent) else { return nil }
        return UIImage(cgImage: cgImage)
    }
}

// MARK: - ViewController (Assumes a basic iOS project with a ViewController)
import UIKit
import Vision
import CoreML // For MLModelConfiguration
import os.signpost // For performance monitoring

// Assume 'SuperResolutionModel' and 'DenoisingModel' are your Core ML model files.
// For SuperResolution: Assume it takes flexible input sizes (e.g., 64x64 to 256x256)
// and outputs 4x upscaled.
// For Denoising: Assume it takes fixed input (e.g., 256x256 or 512x512) matching SR output.

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    // MARK: - UI Elements
    private let originalImageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.backgroundColor = .systemGray5
        iv.layer.cornerRadius = 8
        iv.clipsToBounds = true
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let upscaledImageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.backgroundColor = .systemGray5
        iv.layer.cornerRadius = 8
        iv.clipsToBounds = true
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let enhancedImageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.backgroundColor = .systemGray5
        iv.layer.cornerRadius = 8
        iv.clipsToBounds = true
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let selectImageButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Select Image", for: .normal)
        button.titleLabel?.font = .preferredFont(forTextStyle: .title3)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let qualitySpeedSegmentedControl: UISegmentedControl = {
        let sc = UISegmentedControl(items: ["Speed (Float16)", "Quality (Float32)"])
        sc.selectedSegmentIndex = 0 // Default to speed
        sc.translatesAutoresizingMaskIntoConstraints = false
        return sc
    }()

    private let processingTimeLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = .preferredFont(forTextStyle: .caption1)
        label.numberOfLines = 0
        label.text = "Processing Time: N/A"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let activityIndicator: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.hidesWhenStopped = true
        indicator.translatesAutoresizingMaskIntoConstraints = false
        return indicator
    }()

    // MARK: - Model & Vision Setup
    private var superResolutionModel_f16: VNCoreMLModel?
    private var superResolutionModel_f32: VNCoreMLModel?
    private var denoisingModel_f16: VNCoreMLModel?
    private var denoisingModel_f32: VNCoreMLModel?

    // Threshold for when to apply super-resolution (e.g., if image width < 500)
    private let upscalingResolutionThreshold: CGFloat = 500.0
    // Upscale factor of the SR model (e.g., 4x)
    private let superResolutionUpscaleFactor: Int = 4

    // os_signpost logging for performance
    private let log = OSLog(subsystem: "com.example.AdaptiveImageEnhancer", category: "ModelInference")

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupModels()
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        let stackView = UIStackView(arrangedSubviews: [originalImageView, upscaledImageView, enhancedImageView])
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 10
        stackView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(stackView)
        view.addSubview(selectImageButton)
        view.addSubview(qualitySpeedSegmentedControl)
        view.addSubview(processingTimeLabel)
        view.addSubview(activityIndicator)

        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            stackView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.3),

            qualitySpeedSegmentedControl.topAnchor.constraint(equalTo: stackView.bottomAnchor, constant: 30),
            qualitySpeedSegmentedControl.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            qualitySpeedSegmentedControl.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),

            processingTimeLabel.topAnchor.constraint(equalTo: qualitySpeedSegmentedControl.bottomAnchor, constant: 20),
            processingTimeLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            processingTimeLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            selectImageButton.topAnchor.constraint(equalTo: processingTimeLabel.bottomAnchor, constant: 30),
            selectImageButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            selectImageButton.widthAnchor.constraint(equalToConstant: 200),
            selectImageButton.heightAnchor.constraint(equalToConstant: 50),
            selectImageButton.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])

        selectImageButton.addTarget(self, action: #selector(selectImageTapped), for: .touchUpInside)
        qualitySpeedSegmentedControl.addTarget(self, action: #selector(qualitySpeedChanged), for: .valueChanged)
    }

    private func setupModels() {
        let config_f16 = MLModelConfiguration()
        config_f16.computeUnits = .all // Use all available compute units
        config_f16.allowsLowPrecisionAccumulationAndBiasing = true // Enable float16 optimization

        let config_f32 = MLModelConfiguration()
        config_f32.computeUnits = .all
        config_f32.allowsLowPrecisionAccumulationAndBiasing = false // Force float32 for accuracy

        do {
            // Assume you have SuperResolutionModel_f16, SuperResolutionModel_f32, etc.
            // These would be generated from your .mlmodel files converted with coremltools.
            // For example, SuperResolutionModel_f16.mlmodel and SuperResolutionModel_f32.mlmodel
            // and similarly for DenoisingModel.

            // Load Super-Resolution models
            let sr_f16 = try SuperResolutionModel(configuration: config_f16) // Assuming this is the float16 version
            superResolutionModel_f16 = try VNCoreMLModel(for: sr_f16.model)

            let sr_f32 = try SuperResolutionModel(configuration: config_f32) // Assuming this is the float32 version
            superResolutionModel_f32 = try VNCoreMLModel(for: sr_f32.model)

            // Load Denoising models
            let dn_f16 = try DenoisingModel(configuration: config_f16) // Assuming this is the float16 version
            denoisingModel_f16 = try VNCoreMLModel(for: dn_f16.model)

            let dn_f32 = try DenoisingModel(configuration: config_f32) // Assuming this is the float32 version
            denoisingModel_f32 = try VNCoreMLModel(for: dn_f32.model)

        } catch {
            print("Failed to load Core ML models: \(error)")
            processingTimeLabel.text = "Error: Models failed to load."
        }
    }

    // MARK: - Image Selection
    @objc private func selectImageTapped() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)

        guard let selectedImage = info[.originalImage] as? UIImage else { return }

        originalImageView.image = selectedImage
        upscaledImageView.image = nil
        enhancedImageView.image = nil
        processingTimeLabel.text = "Processing..."
        activityIndicator.startAnimating()

        Task {
            await processImage(selectedImage)
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }

    // MARK: - Image Processing Chain
    private func processImage(_ image: UIImage) async {
        let startTime = CFAbsoluteTimeGetCurrent()
        os_signpost(.begin, log: log, name: "TotalImageEnhancement")

        defer { // Ensure activity indicator stops and time is logged
            let endTime = CFAbsoluteTimeGetCurrent()
            let totalTime = endTime - startTime
            os_signpost(.end, log: log, name: "TotalImageEnhancement", "Total time: %.2f s", totalTime)

            Task { @MainActor in
                self.activityIndicator.stopAnimating()
                self.processingTimeLabel.text = String(format: "Processing Time: %.2f s", totalTime)
            }
        }

        guard let originalCGImage = image.cgImage else { return }

        // Determine which models to use based on user preference
        let useFloat16 = qualitySpeedSegmentedControl.selectedSegmentIndex == 0
        guard let srModel = useFloat16 ? superResolutionModel_f16 : superResolutionModel_f32,
              let dnModel = useFloat16 ? denoisingModel_f16 : denoisingModel_f32 else {
            await MainActor.run { self.processingTimeLabel.text = "Error: Models not loaded for selected preference." }
            return
        }

        var currentPixelBuffer: CVPixelBuffer? = image.toCVPixelBuffer() // Initial CVPixelBuffer
        var upscaledImage: UIImage? = nil

        // 1. Adaptive Upscaling
        if image.size.width < upscalingResolutionThreshold || image.size.height < upscalingResolutionThreshold {
            os_signpost(.begin, log: log, name: "SuperResolution")
            print("Performing Super-Resolution...")
            let srRequest = VNCoreMLRequest(model: srModel) { [weak self] request, error in
                self?.handleSuperResolutionResult(request: request, error: error, originalImage: image)
            }
            srRequest.imageCropAndScaleOption = .scaleFit // Ensure aspect ratio is maintained
            srRequest.usesCPUOnly = !useFloat16 // Example: force CPU for float32 if GPU not supported/preferred

            let srHandler = VNImageRequestHandler(cgImage: originalCGImage, options: [:])
            do {
                try srHandler.perform([srRequest])
                // The result is handled in handleSuperResolutionResult, which updates currentPixelBuffer
                // and upscaledImage. We need to wait for it.
                // For direct chaining, we'll get the pixel buffer from the request itself.
                guard let srObservations = srRequest.results as? [VNPixelBufferObservation],
                      let srOutputPixelBuffer = srObservations.first?.pixelBuffer else {
                    print("Super-resolution output not found.")
                    return
                }
                currentPixelBuffer = srOutputPixelBuffer
                upscaledImage = srOutputPixelBuffer.toUIImage()
                await MainActor.run { self.upscaledImageView.image = upscaledImage }
            } catch {
                print("Super-resolution failed: \(error)")
                os_signpost(.event, log: log, name: "SuperResolution", "Failed: %{public}s", error.localizedDescription)
            }
            os_signpost(.end, log: log, name: "SuperResolution")
        } else {
            print("Image resolution is sufficient, skipping Super-Resolution.")
            await MainActor.run { self.upscaledImageView.image = image } // Show original in upscaled slot
        }

        // Ensure we have a pixel buffer to proceed to denoising
        guard let inputForDenoising = currentPixelBuffer else {
            await MainActor.run { self.processingTimeLabel.text = "Error: No image for denoising." }
            return
        }

        // 2. Denoising
        os_signpost(.begin, log: log, name: "Denoising")
        print("Performing Denoising...")
        let dnRequest = VNCoreMLRequest(model: dnModel) { [weak self] request, error in
            self?.handleDenoisingResult(request: request, error: error)
        }
        dnRequest.imageCropAndScaleOption = .scaleFit // Maintain aspect ratio
        dnRequest.usesCPUOnly = !useFloat16

        // Crucial Step: Pass CVPixelBuffer directly from previous model's output to next model's input
        let dnHandler = VNImageRequestHandler(cvPixelBuffer: inputForDenoising, options: [:])
        do {
            try dnHandler.perform([dnRequest])
        } catch {
            print("Denoising failed: \(error)")
            os_signpost(.event, log: log, name: "Denoising", "Failed: %{public}s", error.localizedDescription)
        }
        os_signpost(.end, log: log, name: "Denoising")
    }

    // MARK: - Result Handlers
    private func handleSuperResolutionResult(request: VNRequest, error: Error?, originalImage: UIImage) {
        Task { @MainActor in
            if let error = error {
                print("SR Result Error: \(error)")
                self.processingTimeLabel.text = "SR Error: \(error.localizedDescription)"
                return
            }

            guard let observations = request.results as? [VNPixelBufferObservation],
                  let srOutputPixelBuffer = observations.first?.pixelBuffer else {
                print("No super-resolution output.")
                return
            }
            self.upscaledImageView.image = srOutputPixelBuffer.toUIImage()
            // currentPixelBuffer and upscaledImage are updated in processImage directly for chaining.
            // This handler is mainly for UI update if needed, but direct chaining is done above.
        }
    }

    private func handleDenoisingResult(request: VNRequest, error: Error?) {
        Task { @MainActor in
            if let error = error {
                print("Denoising Result Error: \(error)")
                self.processingTimeLabel.text = "Denoising Error: \(error.localizedDescription)"
                return
            }

            guard let observations = request.results as? [VNPixelBufferObservation],
                  let denoisedPixelBuffer = observations.first?.pixelBuffer else {
                print("No denoising output.")
                return
            }

            self.enhancedImageView.image = denoisedPixelBuffer.toUIImage()
        }
    }

    // MARK: - Quality vs. Speed Challenge
    @objc private func qualitySpeedChanged() {
        // If an image is currently displayed, re-process it with the new setting
        guard let currentImage = originalImageView.image else { return }

        processingTimeLabel.text = "Re-processing with new setting..."
        activityIndicator.startAnimating()

        Task {
            await processImage(currentImage)
        }
    }
}
