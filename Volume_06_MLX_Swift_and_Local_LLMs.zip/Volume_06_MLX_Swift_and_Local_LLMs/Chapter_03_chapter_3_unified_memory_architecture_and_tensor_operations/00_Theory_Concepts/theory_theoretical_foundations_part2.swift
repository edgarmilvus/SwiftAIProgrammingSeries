
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN // For MLXNN.Module
import Foundation

// @available(iOS 18.0, *)
// func exampleValueAndGradient() {

// Define a simple MLXNN.Module (from MLXNN.Module base class)
// MLXNN.Module is Sendable by default, ensuring its parameters can be safely
// passed across concurrency domains.
final class LinearModel: MLXNN.Module, Sendable {
    let weight: MLXArray
    let bias: MLXArray

    // Initialize with trainable parameters
    required init() {
        self.weight = MLXArray.rand([1], stream: .current) // 1 parameter for weight
        self.bias = MLXArray.rand([1], stream: .current)  // 1 parameter for bias
        super.init()
    }

    // Define the forward pass
    func callAsFunction(_ x: MLXArray) -> MLXArray {
        return x * weight + bias
    }
}

// Instantiate the model
let model = LinearModel()

// Define a simple loss function
func meanSquaredError(model: LinearModel, input: MLXArray, target: MLXArray) -> MLXArray {
    let prediction = model(input)
    let error = prediction - target
    return MLX.mean(error * error) // Mean of squared errors
}

// Sample data
let x_data = MLXArray([10.0], stream: .current)
let y_data = MLXArray([20.0], stream: .current) // Target is roughly 2x input

// Get the valueAndGradient function for our loss and model parameters
let lossAndGrad = valueAndGradient(meanSquaredError)

// Compute the loss and gradients
let (loss, gradients) = lossAndGrad(model, x_data, y_data)

// Evaluate the lazy computation graph to get actual values
loss.eval()
gradients.eval() // Evaluate all gradients

print("Initial Loss: \(loss.item() as! Float)")
print("Gradients for Weight: \(gradients.parameters["weight"]!.item() as! Float)")
print("Gradients for Bias: \(gradients.parameters["bias"]!.item() as! Float)")

// In a real training loop, you would then update model.weight and model.bias
// using an optimizer and these gradients.
// }
