
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CoreML
import UIKit
import AVFoundation // For camera feed and real-time processing
import Combine // For reactive UI updates (optional, but good practice)

// MARK: - Model Configuration and Selection

enum ModelQuantizationType: String, CaseIterable, Identifiable {
    case fullPrecision = "Full Precision (FP32)"
    case float16 = "Balanced (Float16)"
    case int8 = "Fast & Compact (Int8)"
    
    var id: String { rawValue }
    
    /// Returns the corresponding model file name (without .mlmodelc extension).
    func modelFileName(baseName: String) -> String {
        switch self {
        case .fullPrecision: return baseName
        case .float16: return "\(baseName)_float16"
        case .int8: return "\(baseName)_int8"
        }
    }
    
    var description: String {
        switch self {
        case .fullPrecision: return "Highest accuracy, potentially slower. Best for powerful devices."
        case .float16: return "Good balance of accuracy and speed. Default for most devices."
        case .int8: return "Fastest inference, smallest size. Ideal for older devices or high frame rates."
        }
    }
}

// MARK: - Core ML Manager for Dynamic Loading

/// Manages loading and providing the currently active Core ML model.
@Observable // For SwiftUI or easily observable in UIKit with Combine/KVO
class MLModelManager {
    private let baseModelName: String
    var currentModel: MLModel?
    var currentModelType: ModelQuantizationType {
        didSet {
            // Persist user preference
            UserDefaults.standard.set(currentModelType.rawValue, forKey: "selectedModelQuantization")
            Task { await loadSelectedModel() }
        }
    }
    
    init(baseModelName: String) {
        self.baseModelName = baseModelName
        // Load preference or default to a balanced option
        if let savedTypeString = UserDefaults.standard.string(forKey: "selectedModelQuantization"),
           let savedType = ModelQuantizationType(rawValue: savedTypeString) {
            self.currentModelType = savedType
        } else {
            // Default based on device capability or a sensible default
            self.currentModelType = Self.suggestedDefaultModelType()
        }
        
        Task { await loadSelectedModel() }
    }
    
    /// Loads the model corresponding to `currentModelType`.
    func loadSelectedModel() async {
        let fileName = currentModelType.modelFileName(baseName: baseModelName)
        guard let modelURL = Bundle.main.url(forResource: fileName, withExtension: "mlmodelc") else {
            print("Error: Model '\(fileName).mlmodelc' not found for \(currentModelType.rawValue).")
            self.currentModel = nil
            return
        }
        
        do {
            self.currentModel = try await MLModel.load(contentsOf: modelURL)
            print("Successfully loaded model: \(fileName) (\(currentModelType.rawValue))")
        } catch {
            print("Failed to load model \(fileName): \(error.localizedDescription)")
            self.currentModel = nil
        }
    }
    
    /// Suggests a default model type based on device characteristics.
    static func suggestedDefaultModelType() -> ModelQuantizationType {
        // Example logic:
        // For simplicity, let's say older devices (e.g., iPhone 8 and below) get Int8.
        // This is a rough heuristic; more robust checks might involve sysctlbyname("hw.machine").
        let device = UIDevice.current
        if device.userInterfaceIdiom == .phone && device.systemVersion.compare("14.0", options: .numeric) == .orderedAscending {
            // Example: Devices older than iOS 14 (pre-A14 chip era) might benefit from Int8
            return .int8
        }
        
        // More advanced: Check for specific hardware capabilities if available via Core ML APIs
        // For now, let's assume balanced is good for most modern devices
        return .float16
    }
}

// MARK: - Real-time Inference Processor

/// Handles camera input and performs real-time object detection.
class RealtimeObjectDetector: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    
    let modelManager: MLModelManager
    let session = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let videoOutputQueue = DispatchQueue(label: "videoOutputQueue", qos: .userInitiated)
    
    var onInferenceResult: ((String, Double) -> Void)? // (modelName, inferenceTimeMs)
    var onFrameProcessed: ((CVPixelBuffer) -> Void)? // For displaying camera feed
    
    private var lastInferenceTime: TimeInterval = 0
    
    init(modelManager: MLModelManager) {
        self.modelManager = modelManager
        super.init()
        setupCamera()
    }
    
    private func setupCamera() {
        guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("No camera device found.")
            return
        }
        
        do {
            let input = try AVCaptureDeviceInput(device: camera)
            session.addInput(input)
            
            videoOutput.setSampleBufferDelegate(self, queue: videoOutputQueue)
            videoOutput.alwaysDiscardsLateVideoFrames = true
            videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
            session.addOutput(videoOutput)
            
            // Ensure video orientation is correct
            if let connection = videoOutput.connection(with: .video), connection.isVideoOrientationSupported {
                connection.videoOrientation = .portrait
            }
            
            session.startRunning()
        } catch {
            print("Error setting up camera: \(error.localizedDescription)")
        }
    }
    
    // MARK: AVCaptureVideoDataOutputSampleBufferDelegate
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        
        // Pass pixelBuffer to UI for display (e.g., on a Metal/CALayer)
        onFrameProcessed?(pixelBuffer)
        
        guard let model = modelManager.currentModel else {
            // Model not loaded yet, skip inference
            onInferenceResult?("Model Not Ready", 0)
            return
        }
        
        // Perform inference on a background queue to avoid blocking video output queue
        Task {
            let startTime = CACurrentMediaTime()
            do {
                let input = try MLDictionaryFeatureProvider(dictionary: ["image": pixelBuffer]) // Adjust input name
                _ = try model.prediction(from: input)
                let inferenceTime = (CACurrentMediaTime() - startTime) * 1000 // ms
                
                // Update UI on main thread
                await MainActor.run {
                    onInferenceResult?("\(modelManager.currentModelType.rawValue)", inferenceTime)
                }
            } catch {
                await MainActor.run {
                    onInferenceResult?("Inference Error", 0)
                }
                print("Inference failed: \(error.localizedDescription)")
            }
        }
    }
    
    func stopRunning() {
        session.stopRunning()
    }
}


// MARK: - Example UI (ViewController)

class ObjectDetectionViewController: UIViewController {
    
    // UI Elements
    let modelStatusLabel = UILabel()
    let inferenceSpeedLabel = UILabel()
    let feedbackLabel = UILabel()
    let modelSelector = UISegmentedControl(items: ModelQuantizationType.allCases.map { $0.rawValue })
    let previewView = UIView() // This would typically be an AVCaptureVideoPreviewLayer
    
    // Model Manager and Detector
    let modelManager = MLModelManager(baseModelName: "MyObjectDetector") // Replace with your base model name
    var detector: RealtimeObjectDetector!
    
    private var cancellables = Set<AnyCancellable>() // For Combine
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        detector = RealtimeObjectDetector(modelManager: modelManager)
        
        // Update UI when model changes or inference completes
        detector.onInferenceResult = { [weak self] modelName, inferenceTimeMs in
            self?.inferenceSpeedLabel.text = String(format: "FPS: %.1f (%.2f ms)", 1000 / inferenceTimeMs, inferenceTimeMs)
            self?.modelStatusLabel.text = "Active Model: \(modelName)"
            self?.feedbackLabel.text = self?.modelManager.currentModelType.description
        }
        
        // For @Observable (SwiftUI or Combine)
        // In UIKit, you might use KVO or a simple property observer on modelManager.currentModelType
        // For demonstration, we'll update UI when modelManager.currentModelType changes.
        // A more robust UIKit approach would use Combine or KVO.
        // For now, the detector's onInferenceResult closure will handle most updates.
        
        // Initial UI update based on default model
        modelSelector.selectedSegmentIndex = ModelQuantizationType.allCases.firstIndex(of: modelManager.currentModelType) ?? 0
        modelStatusLabel.text = "Active Model: \(modelManager.currentModelType.rawValue)"
        feedbackLabel.text = modelManager.currentModelType.description
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        detector.session.startRunning()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        detector.session.stopRunning()
    }
    
    private func setupUI() {
        view.backgroundColor = .systemBackground
        
        // Preview View (simplified for this example)
        previewView.backgroundColor = .black
        previewView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(previewView)
        
        // Add AVCaptureVideoPreviewLayer to previewView
        let previewLayer = AVCaptureVideoPreviewLayer(session: detector.session)
        previewLayer.frame = view.bounds // Will be updated by layoutSubviews
        previewLayer.videoGravity = .resizeAspectFill
        previewView.layer.addSublayer(previewLayer)
        
        // Model Selector
        modelSelector.selectedSegmentIndex = 0
        modelSelector.addTarget(self, action: #selector(modelSelectionChanged), for: .valueChanged)
        modelSelector.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(modelSelector)
        
        // Labels
        modelStatusLabel.textColor = .white
        inferenceSpeedLabel.textColor = .white
        feedbackLabel.textColor = .white
        feedbackLabel.numberOfLines = 0
        
        let stackView = UIStackView(arrangedSubviews: [modelStatusLabel, inferenceSpeedLabel, feedbackLabel])
        stackView.axis = .vertical
        stackView.spacing = 5
        stackView.alignment = .leading
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            previewView.topAnchor.constraint(equalTo: view.topAnchor),
            previewView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            previewView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            previewView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            modelSelector.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            modelSelector.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            modelSelector.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            modelSelector.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20)
        ])
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Update preview layer frame on rotation or layout changes
        if let previewLayer = previewView.layer.sublayers?.first as? AVCaptureVideoPreviewLayer {
            previewLayer.frame = previewView.bounds
        }
    }
    
    @objc func modelSelectionChanged(_ sender: UISegmentedControl) {
        let selectedTitle = sender.titleForSegment(at: sender.selectedSegmentIndex) ?? ""
        if let selectedType = ModelQuantizationType(rawValue: selectedTitle) {
            modelManager.currentModelType = selectedType
            // UI updates will be handled by the detector's onInferenceResult closure once inference starts with new model
        }
    }
}
