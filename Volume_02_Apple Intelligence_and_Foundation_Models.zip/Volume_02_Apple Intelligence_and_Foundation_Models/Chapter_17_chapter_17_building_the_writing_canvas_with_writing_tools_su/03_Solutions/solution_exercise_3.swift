
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import WritingTools // Requires iOS 18.0 / macOS 15.0+

@available(iOS 18.0, macOS 15.0, *)
class JournalEditorViewController: UIViewController {

    // MARK: - UI Elements

    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 8.0
        textView.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        textView.isEditable = true // Ensure text selection is possible
        textView.isSelectable = true
        return textView
    }()

    private lazy var activityIndicator: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.hidesWhenStopped = true
        return indicator
    }()

    // MARK: - WritingToolsService Properties

    var writingToolsService: WritingToolsService?

    // MARK: - View Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Journal Editor"

        setupUI()
        setupWritingToolsService()
        setupEditMenuInteraction()
    }

    // MARK: - Setup Methods

    private func setupUI() {
        view.addSubview(textView)
        view.addSubview(activityIndicator)

        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            activityIndicator.centerXAnchor.constraint(equalTo: textView.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: textView.centerYAnchor)
        ])

        textView.text = """
        Today was a very long and tiring day. I woke up extremely early, and then I had to go to work. My boss gave me a lot of tasks to complete, and I had to stay late to finish them all. I feel quite exhausted now and just want to relax. I am not sure if I will have the energy to do anything else tonight.
        """
    }

    private func setupWritingToolsService() {
        writingToolsService = WritingToolsService()
        // For requestRefinement, a delegate is not strictly required unless you want
        // general suggestions alongside specific refinements.
        // We will directly use the completion handler for refinement results.
        print("WritingToolsService initialized for refinements.")
    }

    private func setupEditMenuInteraction() {
        // UIEditMenuInteraction is available from iOS 16.0, but WritingToolsRefinementType from iOS 18.0
        let interaction = UIEditMenuInteraction(delegate: self)
        textView.addInteraction(interaction)
    }

    // MARK: - Refinement Logic

    private func applyRefinement(type: WritingToolsRefinementType) {
        guard let selectedTextRange = textView.selectedTextRange,
              !selectedTextRange.isEmpty,
              let fullText = textView.text,
              let nsRange = textView.selectedRange(for: selectedTextRange) else {
            print("No text selected for refinement.")
            return
        }

        activityIndicator.startAnimating()
        print("Requesting refinement of type: \(type) for range: \(nsRange)")

        writingToolsService?.requestRefinement(
            for: textView, // Pass the textInput for context
            text: fullText,
            selection: nsRange,
            refinementType: type
        ) { [weak self] result in
            DispatchQueue.main.async {
                self?.activityIndicator.stopAnimating()
                switch result {
                case .success(let refinementResult):
                    print("Refinement successful!")
                    if let newText = refinementResult.text {
                        // Simple replacement: directly apply
                        self?.textView.replace(nsRange, with: newText)
                        print("Applied simple refinement: '\(newText)'")
                    } else if let options = refinementResult.options, !options.isEmpty {
                        // Multiple options: present to user
                        self?.presentRefinementOptions(options, for: nsRange)
                    } else {
                        print("Refinement returned no text and no options.")
                        self?.showAlert(title: "No Refinement", message: "The writing tools service could not provide a suitable refinement.")
                    }
                case .failure(let error):
                    print("Refinement failed with error: \(error.localizedDescription)")
                    self?.showAlert(title: "Refinement Failed", message: error.localizedDescription)
                }
            }
        }
    }

    private func presentRefinementOptions(_ options: [WritingToolsRefinementResult.Option], for originalRange: NSRange) {
        let alertController = UIAlertController(
            title: "Choose Refinement",
            message: "Select your preferred option:",
            preferredStyle: .actionSheet
        )

        for option in options {
            let action = UIAlertAction(title: option.text, style: .default) { [weak self] _ in
                self?.textView.replace(originalRange, with: option.text)
                print("Applied selected option: '\(option.text)'")
            }
            alertController.addAction(action)
        }

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)

        // For iPad, action sheets need a popover presentation controller source view
        if let popoverController = alertController.popoverPresentationController {
            popoverController.sourceView = textView
            popoverController.sourceRect = textView.firstRect(for: textView.selectedTextRange!)
        }

        present(alertController, animated: true, completion: nil)
    }

    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}

// MARK: - UIEditMenuInteractionDelegate (for iOS context menu)

@available(iOS 18.0, *) // UIEditMenuInteraction is iOS 16+, but WritingTools types are iOS 18+
extension JournalEditorViewController: UIEditMenuInteractionDelegate {
    func editMenuInteraction(_ interaction: UIEditMenuInteraction, menuFor configuration: UIEditMenuConfiguration, suggestedActions: [UIMenuElement]) -> UIMenu? {
        guard let selectedTextRange = textView.selectedTextRange, !selectedTextRange.isEmpty else {
            return nil // No selection, no custom menu
        }

        let makeExpressiveAction = UIAction(title: "Make Expressive", image: UIImage(systemName: "sparkles")) { [weak self] _ in
            self?.applyRefinement(type: .makeMoreExpressive)
        }
        let summarizeAction = UIAction(title: "Summarize", image: UIImage(systemName: "list.bullet.rectangle.portrait")) { [weak self] _ in
            self?.applyRefinement(type: .summarize)
        }
        let makeMoreConciseAction = UIAction(title: "Make More Concise", image: UIImage(systemName: "text.alignleft")) { [weak self] _ in
            self?.applyRefinement(type: .makeMoreConcise)
        }
        let makeMoreFriendlyAction = UIAction(title: "Make More Friendly", image: UIImage(systemName: "face.smiling")) { [weak self] _ in
            self?.applyRefinement(type: .changeTone(to: .friendly))
        }
        let makeMoreFormalAction = UIAction(title: "Make More Formal", image: UIImage(systemName: "briefcase")) { [weak self] _ in
            self?.applyRefinement(type: .changeTone(to: .formal))
        }

        let toneMenu = UIMenu(title: "Change Tone", image: UIImage(systemName: "person.text.rectangle"), children: [
            makeMoreFriendlyAction,
            makeMoreFormalAction
        ])

        let writingToolsMenu = UIMenu(title: "Writing Tools", children: [
            makeExpressiveAction,
            makeMoreConciseAction,
            summarizeAction,
            toneMenu
        ])

        // Combine system suggested actions with our custom menu
        return UIMenu(children: suggestedActions + [writingToolsMenu])
    }
}
