
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import WritingTools // Requires iOS 18.0 / macOS 15.0+

@available(iOS 18.0, macOS 15.0, *)
class NotesEditorViewController: UIViewController, WritingToolsServiceDelegate {

    // MARK: - UI Elements

    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.font = UIFont.systemFont(ofSize: 18)
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 8.0
        textView.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return textView
    }()

    private lazy var applySuggestionButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Apply First Suggestion", for: .normal)
        button.addTarget(self, action: #selector(applyFirstSuggestion), for: .touchUpInside)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8.0
        button.contentEdgeInsets = UIEdgeInsets(top: 8, left: 16, bottom: 8, right: 16)
        return button
    }()

    // MARK: - WritingToolsService Properties

    var writingToolsService: WritingToolsService?
    private var latestSuggestions: [WritingToolsSuggestion] = []

    // MARK: - View Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Notes Editor"

        setupUI()
        setupWritingToolsService()
    }

    // MARK: - Setup Methods

    private func setupUI() {
        view.addSubview(textView)
        view.addSubview(applySuggestionButton)

        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 300),

            applySuggestionButton.topAnchor.constraint(equalTo: textView.bottomAnchor, constant: 20),
            applySuggestionButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            applySuggestionButton.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.8),
            applySuggestionButton.heightAnchor.constraint(equalToConstant: 44)
        ])

        textView.text = "This is an exemple of a note. It contains some grammer and spellling mistakes. Hopefully, the writing tools will corect them."
    }

    private func setupWritingToolsService() {
        writingToolsService = WritingToolsService()
        writingToolsService?.delegate = self
        // Connect the service to the UITextView for automatic observation
        writingToolsService?.textInput = textView
        print("WritingToolsService initialized and connected to textView.")
    }

    // MARK: - Actions

    @objc private func applyFirstSuggestion() {
        guard let firstSuggestion = latestSuggestions.first,
              let textInput = writingToolsService?.textInput else {
            print("No suggestions available to apply.")
            return
        }

        // The apply method is designed to work with the text input's undo manager
        textInput.apply(suggestion: firstSuggestion)
        print("Applied suggestion: '\(firstSuggestion.text)' at range \(firstSuggestion.range)")

        // Clear latest suggestions after applying one
        latestSuggestions.removeAll()
        // Optionally, disable the button until new suggestions arrive
        applySuggestionButton.isEnabled = false
    }

    // MARK: - WritingToolsServiceDelegate

    func writingToolsService(_ service: WritingToolsService, didProvideSuggestions suggestions: [WritingToolsSuggestion], for textInput: any WritingToolsTextInput) {
        // IMPORTANT: Delegate methods are called on a background thread.
        // All UI updates must be dispatched to the main thread.
        DispatchQueue.main.async {
            self.latestSuggestions = suggestions
            print("--- Received \(suggestions.count) suggestions ---")
            for suggestion in suggestions {
                print("Suggestion Type: \(suggestion.type.rawValue), Text: '\(suggestion.text)', Range: \(suggestion.range)")
                // For a more detailed view of the suggestion, you can inspect its properties
                // e.g., suggestion.replacementText, suggestion.highlightRange
            }

            self.applySuggestionButton.isEnabled = !suggestions.isEmpty
        }
    }

    func writingToolsService(_ service: WritingToolsService, didFailWithError error: Error, for textInput: any WritingToolsTextInput) {
        DispatchQueue.main.async {
            print("Writing Tools Service failed with error: \(error.localizedDescription)")
            // Optionally, show an alert to the user
        }
    }
}
