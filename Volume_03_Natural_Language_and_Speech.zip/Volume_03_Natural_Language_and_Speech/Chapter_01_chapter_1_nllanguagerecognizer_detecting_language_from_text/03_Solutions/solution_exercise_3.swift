
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import NaturalLanguage
import Foundation // For Date

// Main app entry point (for a complete SwiftUI app)
@main
struct SmartMessagingApp: App {
    var body: some Scene {
        WindowGroup {
            SmartMessagingView()
        }
    }
}

// 1. Define a ChatMessage struct
struct ChatMessage: Identifiable {
    let id = UUID() // Unique identifier for SwiftUI List
    let senderID: String
    let text: String
    let timestamp: Date
}

struct SmartMessagingView: View {
    // 2. Simulate a user's preferredAppLanguage
    let preferredAppLanguage: NLLanguage = .english // User's preferred language

    // 3. Create an array of ChatMessage objects
    let conversation: [ChatMessage] = [
        ChatMessage(senderID: "user1", text: "Hey, how's it going?", timestamp: Date().addingTimeInterval(-3600)), // English
        ChatMessage(senderID: "user2", text: "¡Hola! Todo bien, ¿y tú?", timestamp: Date().addingTimeInterval(-3500)), // Spanish
        ChatMessage(senderID: "user1", text: "I'm doing great, thanks!", timestamp: Date().addingTimeInterval(-3400)), // English
        ChatMessage(senderID: "user3", text: "Comment allez-vous aujourd'hui?", timestamp: Date().addingTimeInterval(-3300)), // French
        ChatMessage(senderID: "user2", text: "Estoy ocupado con un proyecto.", timestamp: Date().addingTimeInterval(-3200)), // Spanish
        ChatMessage(senderID: "user1", text: "That's cool. What project?", timestamp: Date().addingTimeInterval(-3100)), // English
        ChatMessage(senderID: "user4", text: "こんにちは、お元気ですか？", timestamp: Date().addingTimeInterval(-3000)), // Japanese
        ChatMessage(senderID: "user1", text: "👍", timestamp: Date().addingTimeInterval(-2900)), // Emoji, likely undetermined
        ChatMessage(senderID: "user5", text: "This is a very short.", timestamp: Date().addingTimeInterval(-2800)), // Short English, might be undetermined if too short
        ChatMessage(senderID: "user6", text: "Test", timestamp: Date().addingTimeInterval(-2700)), // Very short, likely undetermined
    ]

    var body: some View {
        NavigationView {
            List(conversation) { message in
                VStack(alignment: .leading) {
                    HStack {
                        Text(message.senderID)
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Spacer()
                        Text(message.timestamp, style: .time)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    Text(message.text)
                        .font(.body)
                        .padding(.vertical, 2)

                    // 5. Conditional "Translate" prompt
                    if shouldShowTranslatePrompt(for: message, preferredAppLanguage: preferredAppLanguage) {
                        Button(action: {
                            print("Translate button tapped for message: '\(message.text)'")
                            // In a real app, this would trigger actual translation
                        }) {
                            HStack {
                                Image(systemName: "globe")
                                Text("Translate")
                            }
                            .font(.footnote)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(5)
                        }
                        .buttonStyle(PlainButtonStyle()) // Prevent default button styling
                        .padding(.top, 4)
                    }
                }
                .padding(.vertical, 5)
            }
            .navigationTitle("SwiftChat")
        }
        .onAppear {
            // Log messages that would trigger a prompt
            print("--- Analyzing Conversation for Translate Prompts ---")
            for message in conversation {
                let detectedLang = NLLanguageRecognizer.dominantLanguage(for: message.text)
                let shouldPrompt = shouldShowTranslatePrompt(for: message, preferredAppLanguage: preferredAppLanguage)
                let langDisplayName = languageDisplayName(detectedLang)

                if shouldPrompt {
                    print("Prompt for: '\(message.text)' (Detected: \(langDisplayName), Preferred: \(languageDisplayName(preferredAppLanguage)))")
                } else {
                    print("No prompt for: '\(message.text)' (Detected: \(langDisplayName), Preferred: \(languageDisplayName(preferredAppLanguage)))")
                }
            }
            print("-----------------------------------------------------")
        }
    }

    // 4. Determine if a message would trigger a "Translate" prompt
    private func shouldShowTranslatePrompt(for message: ChatMessage, preferredAppLanguage: NLLanguage) -> Bool {
        let detectedLanguage = NLLanguageRecognizer.dominantLanguage(for: message.text)

        // Only show prompt if:
        // 1. A language was confidently detected (not .undetermined)
        // 2. The detected language is different from the user's preferred language
        return detectedLanguage != .undetermined && detectedLanguage != preferredAppLanguage
    }

    // Helper function to get a localized display name for an NLLanguage
    private func languageDisplayName(_ language: NLLanguage) -> String {
        if language == .undetermined {
            return "Undetermined"
        }
        let locale = Locale(identifier: language.rawValue)
        return locale.localizedString(forLanguageCode: language.rawValue)?.capitalized ?? language.rawValue
    }
}

// MARK: - Preview Provider (for Xcode Canvas)
#Preview {
    SmartMessagingView()
}
