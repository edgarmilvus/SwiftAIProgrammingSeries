/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// App.tsx
import React from 'react';
import { View, Text, TouchableOpacity, Button } from 'react-native';
import { NavigationContainer, useNavigationState } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { MaterialIcons } from '@expo/vector-icons';
import { cn } from 'nativewind';

type FeedStackParamList = {
  FeedList: undefined;
  PostDetail: { postId: number };
};

type ProfileStackParamList = {
  ProfileMain: undefined;
  EditProfile: undefined;
};

type TabParamList = {
  FeedStack: undefined;
  ProfileStack: undefined;
};

const Tab = createBottomTabNavigator<TabParamList>();
const FeedStack = createStackNavigator<FeedStackParamList>();
const ProfileStack = createStackNavigator<ProfileStackParamList>();

// --- Feed Stack Screens ---
const FeedListScreen = ({ navigation }: any) => {
  return (
    <View className="flex-1 bg-slate-900 items-center justify-center">
      <Text className="text-white text-xl mb-4">Feed List</Text>
      <Button 
        title="View Post #1" 
        onPress={() => navigation.navigate('PostDetail', { postId: 1 })}
        color="#3b82f6"
      />
    </View>
  );
};

const PostDetailScreen = ({ route }: any) => {
  return (
    <View className="flex-1 bg-slate-900 items-center justify-center">
      <Text className="text-white text-2xl font-bold">Post Detail</Text>
      <Text className="text-slate-400 mt-2">ID: {route.params.postId}</Text>
      <Text className="text-slate-500 text-sm mt-4">(Tab bar is hidden here)</Text>
    </View>
  );
};

// --- Profile Stack Screens ---
const ProfileMainScreen = ({ navigation }: any) => {
  return (
    <View className="flex-1 bg-slate-900 items-center justify-center">
      <Text className="text-white text-xl mb-4">Profile Main</Text>
      <Button 
        title="Edit Profile" 
        onPress={() => navigation.navigate('EditProfile')}
        color="#10b981"
      />
    </View>
  );
};

const EditProfileScreen = () => {
  return (
    <View className="flex-1 bg-slate-900 items-center justify-center">
      <Text className="text-white text-xl">Edit Profile Form</Text>
    </View>
  );
};

// --- FAB Component ---
const FAB = ({ onPress }: { onPress: () => void }) => (
  <TouchableOpacity
    onPress={onPress}
    className="absolute bottom-20 right-6 bg-blue-500 w-14 h-14 rounded-full items-center justify-center shadow-lg elevation-5"
    style={{ elevation: 5 }}
  >
    <MaterialIcons name="add" size={28} color="white" />
  </TouchableOpacity>
);

// --- Navigators ---

const FeedStackNavigator = () => {
  return (
    <FeedStack.Navigator>
      <FeedStack.Screen name="FeedList" component={FeedListScreen} options={{ headerShown: false }} />
      <FeedStack.Screen name="PostDetail" component={PostDetailScreen} options={{ headerShown: false }} />
    </FeedStack.Navigator>
  );
};

const ProfileStackNavigator = () => {
  return (
    <ProfileStack.Navigator>
      <ProfileStack.Screen name="ProfileMain" component={ProfileMainScreen} options={{ headerShown: false }} />
      <ProfileStack.Screen name="EditProfile" component={EditProfileScreen} options={{ headerShown: false }} />
    </ProfileStack.Navigator>
  );
};

// --- Main App Component ---
export default function App() {
  // Hook to get the current route name deeply nested in the navigation state
  const routeName = useNavigationState(state => {
    const route = state.routes[state.index];
    if (route.state) {
      // @ts-ignore: accessing nested state
      const nestedRoute = route.state.routes[route.state.index];
      return nestedRoute.name;
    }
    return route.name;
  });

  // Logic to hide Tab Bar and FAB on deep screens
  const shouldHideTabBar = routeName === 'PostDetail' || routeName === 'EditProfile';
  const showFAB = routeName === 'FeedList'; // FAB only on Feed List

  return (
    <View className="flex-1">
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            headerShown: false,
            // Dynamic Tab Bar Style
            tabBarStyle: {
              backgroundColor: '#0f172a',
              borderTopColor: '#334155',
              height: shouldHideTabBar ? 0 : 60, // Hide by setting height to 0
              display: shouldHideTabBar ? 'none' : 'flex', // Alternative method
              paddingBottom: 10,
              transitionProperty: 'height, opacity',
              transitionDuration: '0.3s',
            },
            tabBarIcon: ({ color, size }) => {
              let iconName: any = 'home';
              if (route.name === 'FeedStack') iconName = 'feed';
              if (route.name === 'ProfileStack') iconName = 'person';
              return <MaterialIcons name={iconName} size={size} color={color} />;
            },
            tabBarLabel: ({ focused }) => (
              <Text className={cn("text-xs", focused ? "text-blue-400" : "text-slate-500")}>
                {route.name.replace('Stack', '')}
              </Text>
            )
          })}
        >
          <Tab.Screen name="FeedStack" component={FeedStackNavigator} />
          <Tab.Screen name="ProfileStack" component={ProfileStackNavigator} />
        </Tab.Navigator>
      </NavigationContainer>

      {/* FAB Overlay */}
      {showFAB && (
        <FAB onPress={() => console.log("Navigate to Create Post")} />
      )}
    </View>
  );
}
