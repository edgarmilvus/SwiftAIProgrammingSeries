/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// utils/apiFetch.ts
import { logUniversal } from './UniversalLogger';

export async function apiFetch(url: string, options: RequestInit = {}) {
  const method = options.method || 'GET';
  const startTime = Date.now();

  logUniversal('Network', `Request Start: ${method} ${url}`);

  try {
    const response = await fetch(url, options);
    const duration = Date.now() - startTime;
    
    logUniversal('Network', {
      status: response.status,
      duration: `${duration}ms`,
      url: url
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    return response.json();
  } catch (error) {
    logUniversal('NetworkError', error);
    throw error;
  }
}

// hooks/useDebugState.ts
import { useState, useCallback, useRef } from 'react';
import { logUniversal } from '../utils/UniversalLogger';

export function useDebugState<T>(initialValue: T, name: string) {
  const [state, setState] = useState<T>(initialValue);
  // Use a ref to track the previous value without triggering re-renders
  const prevValueRef = useRef<T>(initialValue);

  const setDebugState = useCallback((newValue: T | ((val: T) => T)) => {
    const resolvedNewValue = typeof newValue === 'function' 
      ? (newValue as Function)(prevValueRef.current) 
      : newValue;

    logUniversal('StateUpdate', {
      component: name,
      previous: prevValueRef.current,
      next: resolvedNewValue
    });

    prevValueRef.current = resolvedNewValue;
    setState(resolvedNewValue);
  }, [name]);

  return [state, setDebugState] as const;
}

// components/UserProfile.tsx
import React, { useEffect } from 'react';
import { View, Text, Button } from 'react-native';
import { apiFetch } from '../utils/apiFetch';
import { useDebugState } from '../hooks/useDebugState';

interface User {
  id: number;
  name: string;
  email: string;
}

export function UserProfile() {
  // Using the debug hook to track user state
  const [user, setUser] = useDebugState<User | null>(null, 'UserProfile.user');
  const [loading, setLoading] = useDebugState<boolean>(false, 'UserProfile.loading');

  const fetchUser = async () => {
    setLoading(true);
    try {
      // Using the debug fetch wrapper
      // Note: Using a public test API for demonstration
      const data = await apiFetch('https://jsonplaceholder.typicode.com/users/1');
      setUser(data);
    } catch (err) {
      // Error logging handled inside apiFetch, but could be handled here too
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  return (
    <View style={{ padding: 20 }}>
      <Text>Status: {loading ? 'Loading...' : 'Loaded'}</Text>
      {user && (
        <View>
          <Text>Name: {user.name}</Text>
          <Text>Email: {user.email}</Text>
        </View>
      )}
      <Button title="Reload" onPress={fetchUser} />
    </View>
  );
}
