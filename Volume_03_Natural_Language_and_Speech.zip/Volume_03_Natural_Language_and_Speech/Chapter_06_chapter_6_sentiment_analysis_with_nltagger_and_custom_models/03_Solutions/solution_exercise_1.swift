
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import NaturalLanguage // Required for NLTagger

// NLTagger.TagScheme.sentimentScore is available from iOS 13.0, macOS 10.15.
// @available(iOS 18.0, macOS 15.0, *) is used here to align with the chapter's implied modern Swift 6 context.
@available(iOS 13.0, macOS 10.15, *)
struct ReviewAnalyzer {
    /// Analyzes the sentiment of a given review text.
    /// - Parameter reviewText: The product review string to analyze.
    /// - Returns: A tuple containing the raw sentiment score (Double) and its String classification.
    func analyzeReviewSentiment(reviewText: String) -> (score: Double, classification: String) {
        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = reviewText

        // NLTagger.TagScheme.sentimentScore returns a single value for the entire string when unit is .document.
        // The sentiment score is typically in the range [-1.0, 1.0].
        let (sentimentTag, _) = tagger.tag(at: reviewText.startIndex, unit: .document, scheme: .sentimentScore)

        // Attempt to convert the raw tag value (String) to a Double.
        guard let scoreString = sentimentTag?.rawValue,
              let score = Double(scoreString) else {
            // Return a default or error state if analysis fails.
            return (score: 0.0, classification: "Unable to analyze")
        }

        let classification: String
        if score > 0.5 {
            classification = "Positive"
        } else if score < -0.5 {
            classification = "Negative"
        } else {
            classification = "Neutral"
        }

        return (score: score, classification: classification)
    }
}

// Example Usage:
@available(iOS 13.0, macOS 10.15, *)
func demonstrateReviewAnalysis() {
    let analyzer = ReviewAnalyzer()

    let review1 = "This product is absolutely amazing! I love it so much and highly recommend it."
    let result1 = analyzer.analyzeReviewSentiment(reviewText: review1)
    print("Review 1: \"\(review1)\"\n  Score: \(String(format: "%.2f", result1.score)), Classification: \(result1.classification)\n")

    let review2 = "I am extremely disappointed with this purchase. It broke after just one use, total waste of money."
    let result2 = analyzer.analyzeReviewSentiment(reviewText: review2)
    print("Review 2: \"\(review2)\"\n  Score: \(String(format: "%.2f", result2.score)), Classification: \(result2.classification)\n")

    let review3 = "The item arrived on time. It functions as expected, nothing particularly special or bad."
    let result3 = analyzer.analyzeReviewSentiment(reviewText: review3)
    print("Review 3: \"\(review3)\"\n  Score: \(String(format: "%.2f", result3.score)), Classification: \(result3.classification)\n")

    let review4 = "The app is good, but the latest update introduced a bug that crashes it sometimes."
    let result4 = analyzer.analyzeReviewSentiment(reviewText: review4)
    print("Review 4: \"\(review4)\"\n  Score: \(String(format: "%.2f", result4.score)), Classification: \(result4.classification)\n")
}

// To run the demonstration:
// demonstrateReviewAnalysis()
