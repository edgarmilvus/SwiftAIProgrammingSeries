
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI

// Make GazeIntent conform to Equatable for efficient observation if needed,
// though @Observable handles property changes directly.
extension GazeIntent: Equatable {}

@available(visionOS 1.0, *)
@Observable
class GazeIntentPublisher {
    var currentIntent: GazeIntent = GazeIntent(focusedObjectID: nil, type: .ignore) {
        didSet {
            // Optional: Add logic here if intent changes, e.g., logging
            print("GazeIntentPublisher: Intent changed to \(currentIntent.type)")
        }
    }

    // Method to update the intent from an actor or background task
    func updateIntent(_ newIntent: GazeIntent) {
        currentIntent = newIntent
    }
}

@available(visionOS 1.0, *)
struct GazeDrivenView: View {
    @Environment(GazeIntentPublisher.self) var intentPublisher

    var body: some View {
        VStack {
            Text("Current Gaze Intent:")
                .font(.title2)
            Text("Type: \(intentPublisher.currentIntent.type.rawValue)")
            Text("Focused ID: \(intentPublisher.currentIntent.focusedObjectID ?? "N/A")")
        }
        .padding()
        .background(.regularMaterial)
        .cornerRadius(10)
        // Example: Change background color based on intent
        .opacity(intentPublisher.currentIntent.type == .focus ? 1.0 : 0.7)
    }
}

// Example usage in an App or main view
@available(visionOS 1.0, *)
struct MyGazeApp: App {
    @State private var gazeIntentPublisher = GazeIntentPublisher()
    @State private var gazeAIProcessor = EyeGazeAIProcessor() // Actor instance

    var body: some Scene {
        WindowGroup {
            GazeDrivenView()
                .environment(gazeIntentPublisher) // Make publisher available to views
                .task {
                    // Simulate continuous gaze data and AI processing
                    await simulateGazeLoop()
                }
        }
    }

    private func simulateGazeLoop() async {
        for i in 0..<100 { // Simulate 100 gaze frames
            let simulatedGazeRay = GazeRay(
                origin: .zero,
                direction: SIMD3<Float>(Float.random(in: -1...1), Float.random(in: -1...1), -1),
                confidence: Float.random(in: 0.8...1.0)
            )

            // Send gaze data to the actor
            await gazeAIProcessor.processNewGazeData(simulatedGazeRay)

            // Request inference from the actor
            do {
                let inferredIntent = try await gazeAIProcessor.inferCurrentIntent()
                // Update the observable publisher on the main actor
                await MainActor.run {
                    gazeIntentPublisher.updateIntent(inferredIntent)
                }
            } catch {
                print("Error inferring intent: \(error)")
            }

            try? await Task.sleep(for: .milliseconds(100)) // Simulate frame rate
        }
    }
}
