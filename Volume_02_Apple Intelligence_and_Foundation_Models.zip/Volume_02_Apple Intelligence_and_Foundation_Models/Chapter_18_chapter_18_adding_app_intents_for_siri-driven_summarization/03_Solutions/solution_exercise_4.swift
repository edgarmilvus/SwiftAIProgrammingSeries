
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import AppIntents
import Foundation
import CoreML // Placeholder for Apple Intelligence TextGenerationService

// MARK: - Mock Data Store and Models

// Type of document
enum DocumentType: String, CaseIterable, Identifiable {
    case meetingNotes = "Meeting Notes"
    case researchPaper = "Research Paper"
    case designSpec = "Design Specification"
    case taskUpdate = "Task Update"
    case general = "General Document"

    var id: String { rawValue }
}

// Represents a document linked to a project
struct Document: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var content: String
    var projectID: UUID
    var type: DocumentType
    var creationDate: Date
}

// Represents a project
struct Project: Identifiable, Hashable {
    let id = UUID()
    var name: String
    var description: String
}

// In-memory mock data store for projects and documents
class ProjectStore {
    static let shared = ProjectStore()

    private var projects: [Project] = [
        Project(id: UUID(uuidString: "A0000000-0000-0000-0000-000000000001")!, name: "Project Aurora", description: "Next-gen AR platform"),
        Project(id: UUID(uuidString: "A0000000-0000-0000-0000-000000000002")!, name: "Q3 Marketing Campaign", description: "Campaign for Q3 product launch")
    ]

    private var documents: [Document] = []

    init() {
        // Populate mock documents
        let auroraID = projects[0].id
        let q3MarketingID = projects[1].id

        documents.append(contentsOf: [
            // Project Aurora Documents
            Document(title: "Aurora Kickoff Notes", content: "Initial meeting, defined scope: AR glasses, smart home integration. Key decision: focus on developer SDK first. Action: Bob to research AR frameworks. Date: 2024-07-01", projectID: auroraID, type: .meetingNotes, creationDate: Date(timeIntervalSinceNow: -86400 * 30)),
            Document(title: "Aurora Research Paper on SLAM", content: "Detailed analysis of Simultaneous Localization and Mapping algorithms for AR devices. Discusses pros and cons of various approaches.", projectID: auroraID, type: .researchPaper, creationDate: Date(timeIntervalSinceNow: -86400 * 25)),
            Document(title: "Aurora UI/UX Design Spec v1.0", content: "Specifications for the initial user interface and experience for the Aurora developer portal. Includes wireframes and interaction flows.", projectID: auroraID, type: .designSpec, creationDate: Date(timeIntervalSinceNow: -86400 * 20)),
            Document(title: "Aurora Task Update: SLAM Integration", content: "Bob has successfully integrated ARKit SLAM module. Performance benchmarks are promising. Next step: object recognition.", projectID: auroraID, type: .taskUpdate, creationDate: Date(timeIntervalSinceNow: -86400 * 10)),
            Document(title: "Aurora Meeting Notes: Q3 Review", content: "Reviewed Q3 progress. SLAM integration complete. Object recognition in progress. Challenge: battery life. Decision: explore low-power modes. Action: Alice to investigate power optimization. Date: 2024-07-20", projectID: auroraID, type: .meetingNotes, creationDate: Date(timeIntervalSinceNow: -86400 * 5)),
            Document(title: "Aurora Design Review Feedback", content: "Feedback from internal design review. Minor adjustments needed for developer onboarding flow. Overall positive.", projectID: auroraID, type: .designSpec, creationDate: Date(timeIntervalSinceNow: -86400 * 2)),

            // Q3 Marketing Campaign Documents
            Document(title: "Q3 Campaign Strategy", content: "Strategy document outlining target audience, key messaging, and channels for the Q3 product launch. Focus on social media and influencer marketing.", projectID: q3MarketingID, type: .general, creationDate: Date(timeIntervalSinceNow: -86400 * 40)),
            Document(title: "Q3 Social Media Plan", content: "Detailed plan for social media content, schedule, and ad spend for the Q3 campaign. Includes mockups for Instagram and TikTok.", projectID: q3MarketingID, type: .designSpec, creationDate: Date(timeIntervalSinceNow: -86400 * 15)),
            Document(title: "Q3 Campaign Performance Report", content: "Initial performance report for the first two weeks of the Q3 campaign. Engagement rates are above target. Conversion rates are slightly below target. Action: Adjust ad copy for better CTA.", projectID: q3MarketingID, type: .taskUpdate, creationDate: Date(timeIntervalSinceNow: -86400 * 3))
        ])
    }

    func getProject(byName name: String) -> Project? {
        projects.first { $0.name.localizedCaseInsensitiveContains(name) }
    }

    func getDocuments(forProjectID projectID: UUID, startDate: Date?, endDate: Date?) -> [Document] {
        documents.filter { doc in
            doc.projectID == projectID &&
            (startDate == nil || doc.creationDate >= startDate!) &&
            (endDate == nil || doc.creationDate <= endDate!)
        }.sorted(by: { $0.creationDate < $1.creationDate })
    }
}

// MARK: - App Intent Implementation

@available(iOS 18.0, macOS 15.0, *)
struct GenerateProjectDigestIntent: AppIntent {
    static var title: LocalizedStringResource = "Generate Project Digest"
    static var description = IntentDescription("Generates a comprehensive summary (digest) for a specified project, optionally filtering documents by date range.")
    static var openAppWhenRun: Bool = false

    @Parameter(title: "Project Name", description: "The name of the project to generate a digest for.")
    var projectName: String

    @Parameter(title: "Start Date (Optional)", description: "Only include documents created on or after this date.", default: nil)
    var startDate: Date?

    @Parameter(title: "End Date (Optional)", description: "Only include documents created on or before this date.", default: nil)
    var endDate: Date?

    init() {}
    init(projectName: String, startDate: Date?, endDate: Date?) {
        self.projectName = projectName
        self.startDate = startDate
        self.endDate = endDate
    }

    func perform() async throws -> some IntentResult & ReturnsValue<String> {
        guard let project = ProjectStore.shared.getProject(byName: projectName) else {
            throw AppIntentError.projectNotFound(name: projectName)
        }

        let relevantDocuments = ProjectStore.shared.getDocuments(
            forProjectID: project.id,
            startDate: startDate,
            endDate: endDate
        )

        guard !relevantDocuments.isEmpty else {
            throw AppIntentError.noDocumentsForProject(projectName: project.name, startDate: startDate, endDate: endDate)
        }

        // Aggregate content from all relevant documents
        let aggregatedContent = relevantDocuments
            .map { "Document Title: \($0.title) (Type: \($0.type.rawValue), Date: \($0.creationDate.formatted()))\nContent: \($0.content)" }
            .joined(separator: "\n\n---\n\n")

        // Advanced Prompt Engineering
        var prompt = "Generate a comprehensive project digest for '\(project.name)' based on the following documents. "
        prompt += "Provide an overview of recent progress, highlight key achievements, identify major challenges or blockers, and list upcoming critical tasks or next steps. "
        if let start = startDate, let end = endDate {
            prompt += "Focus specifically on information from documents created between \(start.formatted(date: .abbreviated, time: .omitted)) and \(end.formatted(date: .abbreviated, time: .omitted)). "
        } else if let start = startDate {
            prompt += "Focus on information from documents created since \(start.formatted(date: .abbreviated, time: .omitted)). "
        } else if let end = endDate {
            prompt += "Focus on information from documents created up to \(end.formatted(date: .abbreviated, time: .omitted)). "
        }
        prompt += "Present the digest in a structured, easy-to-read format with clear headings.\n\n"
        prompt += "Aggregated Document Content:\n" + aggregatedContent

        do {
            let digest = try await TextGenerationService.shared.generateSummary(for: aggregatedContent, prompt: prompt)
            return .result(value: digest, dialog: "Here's the project digest for '\(project.name)': \(digest)")
        } catch let error as TextGenerationService.TextGenerationError {
            throw AppIntentError.summarizationFailed(reason: error.description)
        } catch {
            throw AppIntentError.summarizationFailed(reason: "An unexpected error occurred during digest generation: \(error.localizedDescription)")
        }
    }
}

// MARK: - Custom App Intent Errors (Extended for this exercise)

@available(iOS 18.0, macOS 15.0, *)
extension AppIntentError {
    static func projectNotFound(name: String) -> AppIntentError { .summarizationFailed(reason: "Could not find a project with the name '\(name)'.") }
    static func noDocumentsForProject(projectName: String, startDate: Date?, endDate: Date?) -> AppIntentError {
        var message = "No documents found for project '\(projectName)'"
        if let start = startDate, let end = endDate {
            message += " in the date range \(start.formatted(date: .abbreviated, time: .omitted)) to \(end.formatted(date: .abbreviated, time: .omitted))"
        } else if let start = startDate {
            message += " since \(start.formatted(date: .abbreviated, time: .omitted))"
        } else if let end = endDate {
            message += " up to \(end.formatted(date: .abbreviated, time: .omitted))"
        }
        message += "."
        return .summarizationFailed(reason: message)
    }
}
