
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CreateML
import Foundation

@available(iOS 18.0, macOS 15.0, *)
func crossValidatePlantClassifier() throws {
    // 1. Prepare an Image Dataset
    // IMPORTANT: Replace with the actual URL to your image dataset directory.
    // Example structure: YourDatasetDir/Rose/img1.jpg, YourDatasetDir/Tulip/img2.jpg
    // For demonstration, we'll use a placeholder URL and rely on the fatalError.
    let datasetURL = URL(fileURLWithPath: "/path/to/YourPlantImageDataset")
    
    // In a real scenario, you'd ensure this directory exists and contains images.
    // For this exercise, if the path doesn't exist, the program will terminate.
    guard FileManager.default.fileExists(atPath: datasetURL.path) else {
        fatalError("Dataset not found at \(datasetURL.path). Please update the path to your image dataset.")
    }

    // Load all image data into an MLBatchProvider, which is backed by an MLDataTable.
    let allDataSource = try MLImageClassifier.DataSource.labeledDirectories(at: datasetURL)
    let dataTable = allDataSource.data // Access the underlying MLDataTable

    let numFolds = 3
    var foldAccuracies: [Double] = []

    print("Starting \(numFolds)-fold cross-validation for MLImageClassifier...")

    // This implements a basic k-fold split. For imbalanced datasets, stratified splitting is preferred.
    let totalRows = dataTable.rows.count
    let foldSize = totalRows / numFolds

    for i in 0..<numFolds {
        print("\n--- Fold \(i + 1)/\(numFolds) ---")

        // Determine the indices for the current validation fold
        let validationStartIndex = i * foldSize
        let validationEndIndex = (i == numFolds - 1) ? totalRows : (i + 1) * foldSize

        // Split data into training and validation sets for the current fold
        let validationData = dataTable[validationStartIndex..<validationEndIndex]
        
        // Combine the remaining parts for training data
        let trainingData = dataTable[0..<validationStartIndex] + dataTable[validationEndIndex..<totalRows]

        // Ensure the data sources are created correctly from the split data tables
        let trainingDataSource = try MLImageClassifier.DataSource(data: trainingData)
        let validationDataSource = try MLImageClassifier.DataSource(data: validationData)

        // Train the model with default parameters for this exercise
        let parameters = MLImageClassifier.ModelParameters()
        let model = try MLImageClassifier(trainingData: trainingDataSource, parameters: parameters)
        print("Model trained for Fold \(i + 1).")

        // Evaluate the model on the held-out validation set
        let evaluation = model.evaluation(on: validationDataSource)
        if let accuracy = evaluation.accuracy {
            print("Fold \(i + 1) Validation Accuracy: \(String(format: "%.4f", accuracy))")
            foldAccuracies.append(accuracy)
        } else {
            print("Fold \(i + 1) Evaluation Accuracy not available.")
        }
    }

    // 3. Aggregate Results
    if !foldAccuracies.isEmpty {
        let averageAccuracy = foldAccuracies.reduce(0.0, +) / Double(foldAccuracies.count)
        print("\n--- Cross-Validation Complete ---")
        print("Individual Fold Accuracies: \(foldAccuracies.map { String(format: "%.4f", $0) })")
        print("Average Cross-Validation Accuracy: \(String(format: "%.4f", averageAccuracy))")
    } else {
        print("No accuracies recorded.")
    }

    // 4. Report Findings
    print("\nReasoning for Cross-Validation:")
    print("Cross-validation provides a more reliable estimate of a model's generalization performance compared to a single train-test split. By training and evaluating the model multiple times on different subsets of the data, it reduces the risk of the model's performance being overly optimistic or pessimistic due to a 'lucky' or 'unlucky' data split. It helps detect overfitting and gives a more robust measure of how the model will perform on unseen data across various scenarios.")
    print("The individual fold accuracies might vary, reflecting the inherent variability in data subsets. The average accuracy smooths out these variations to give a more stable performance metric.")
}

// To run this exercise, uncomment the line below and update the datasetURL:
// try crossValidatePlantClassifier()
