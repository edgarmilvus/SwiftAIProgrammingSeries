
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

struct ChunkConfig {
    let chunkSize: Int
    let overlapSize: Int
    
    init(chunkSize: Int, overlapSize: Int) throws {
        guard overlapSize < chunkSize else {
            throw ChunkingError.invalidConfiguration
        }
        self.chunkSize = chunkSize
        self.overlapSize = overlapSize
    }
}

enum ChunkingError: Error {
    case invalidConfiguration
}

struct SlidingWindowChunker {
    let config: ChunkConfig
    
    /// Breaks text into overlapping chunks without splitting words.
    func chunk(text: String) -> [String] {
        guard !text.isEmpty else { return [] }
        if text.count <= config.chunkSize { return [text] }
        
        var chunks: [String] = []
        var currentIndex = text.startIndex
        
        while currentIndex < text.endIndex {
            // 1. Calculate the ideal end index based on chunkSize
            let desiredEndIndex = text.index(currentIndex, offsetBy: config.chunkSize, limitedBy: text.endIndex) ?? text.endIndex
            
            // 2. Boundary Awareness: Don't split words. 
            // Look backwards from the desired end to find the last whitespace.
            var actualEndIndex = desiredEndIndex
            if desiredEndIndex < text.endIndex {
                if let lastSpace = text.indices[..<desiredEndIndex].reversed().first(where: { text[$0].isWhitespace }) {
                    // If we found a space, use it to avoid cutting a word
                    // Ensure we don't backtrack so far that we create an empty chunk
                    if lastSpace > currentIndex {
                        actualEndIndex = lastSpace
                    }
                }
            }
            
            // 3. Extract the chunk
            let chunk = String(text[currentIndex..<actualEndIndex])
            if !chunk.isEmpty {
                chunks.append(chunk)
            }
            
            // 4. Calculate next start index (Current + Size - Overlap)
            // We use the 'desiredEndIndex' for the math to maintain consistent window steps,
            // but we must ensure we don't get stuck in an infinite loop.
            let stepSize = config.chunkSize - config.overlapSize
            let nextIndex = text.index(currentIndex, offsetBy: stepSize, limitedBy: text.endIndex) ?? text.endIndex
            
            // Safety check: if stepSize is 0 or we aren't moving, break
            if nextIndex <= currentIndex { break }
            currentIndex = nextIndex
        }
        
        return chunks
    }
}
