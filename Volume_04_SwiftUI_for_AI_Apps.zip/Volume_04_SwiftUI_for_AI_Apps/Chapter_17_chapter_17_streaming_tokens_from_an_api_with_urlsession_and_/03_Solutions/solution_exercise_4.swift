
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import Foundation

// Ensure the Python server from the problem description is running on port 8080
// with the path '/json-stream' or '/ai/stream'

// MARK: - Decodable Models (re-using from Exercise 2)
struct AIChatChunk: Decodable {
    let id: String?
    let object: String?
    let choices: [Choice]?

    struct Choice: Decodable {
        let index: Int
        let delta: Delta
    }

    struct Delta: Decodable {
        let content: String?
        let role: String?
    }
}

// MARK: - Custom Error Type
enum AIStreamDecoderError: Error, LocalizedError {
    case invalidData(String)
    case jsonDecodingFailed(Error)
    case underlyingStreamError(Error)

    var errorDescription: String? {
        switch self {
        case .invalidData(let message):
            return "Invalid data received: \(message)"
        case .jsonDecodingFailed(let error):
            return "JSON decoding failed: \(error.localizedDescription)"
        case .underlyingStreamError(let error):
            return "Underlying stream error: \(error.localizedDescription)"
        }
    }
}

// MARK: - Custom AsyncSequence Implementation
struct AIStreamDecoder<Chunk: Decodable>: AsyncSequence, AsyncIteratorProtocol {
    typealias Element = Chunk

    private let asyncBytes: URLSession.AsyncBytes
    private var buffer = Data()
    private let jsonDecoder = JSONDecoder()

    init(asyncBytes: URLSession.AsyncBytes) {
        self.asyncBytes = asyncBytes
    }

    // makeAsyncIterator returns self because AIStreamDecoder also conforms to AsyncIteratorProtocol
    func makeAsyncIterator() -> AIStreamDecoder<Chunk> {
        self // Return self as the iterator
    }

    mutating func next() async throws -> Chunk? {
        var iterator = asyncBytes.makeAsyncIterator() // Get an iterator for the underlying bytes

        while true {
            do {
                // Try to find a newline in the current buffer
                if let newlineRange = buffer.firstRange(of: Data([0x0A])) { // 0x0A is ASCII for \n
                    let jsonLineData = buffer.prefix(upTo: newlineRange.lowerBound)
                    buffer.removeSubrange(..<newlineRange.upperBound) // Remove line and newline from buffer

                    // Skip empty lines or just newlines
                    guard !jsonLineData.isEmpty else { continue }

                    do {
                        let chunk = try jsonDecoder.decode(Chunk.self, from: jsonLineData)
                        return chunk
                    } catch {
                        // Log decoding error but continue processing the stream
                        print("AIStreamDecoder: JSON decoding error for line: '\(String(data: jsonLineData, encoding: .utf8) ?? "N/A")' - \(error)")
                        // Optionally, throw AIStreamDecoderError.jsonDecodingFailed(error) if you want to stop on first malformed JSON
                        // For robustness, we'll just skip this chunk and try the next.
                        continue
                    }
                }

                // If no newline, read more bytes from the underlying stream
                guard let nextByte = try await iterator.next() else {
                    // Stream finished, process any remaining data in buffer
                    if !buffer.isEmpty {
                        let remainingData = buffer
                        buffer.removeAll() // Clear buffer
                        do {
                            let chunk = try jsonDecoder.decode(Chunk.self, from: remainingData)
                            return chunk
                        } catch {
                            print("AIStreamDecoder: JSON decoding error for remaining buffer: '\(String(data: remainingData, encoding: .utf8) ?? "N/A")' - \(error)")
                            // If remaining data is not a valid JSON, we just return nil, signalling end of stream
                            return nil
                        }
                    }
                    return nil // End of stream
                }
                buffer.append(nextByte)

            } catch let urlError as URLError {
                throw AIStreamDecoderError.underlyingStreamError(urlError)
            } catch {
                // Catch any other errors from the underlying stream or Task.checkCancellation
                throw AIStreamDecoderError.underlyingStreamError(error)
            }
        }
    }
}

// MARK: - SwiftUI Usage Example
struct CustomAsyncSequenceView: View {
    @State private var accumulatedContent: String = ""
    @State private var errorMessage: String?
    @State private var isLoading: Bool = false
    @State private var streamingTask: Task<Void, Never>?

    private let streamURL = URL(string: "http://localhost:8080/json-stream")! // Or /ai/stream

    var body: some View {
        VStack {
            Text("Custom AI Stream Decoder")
                .font(.largeTitle)
                .padding()

            if isLoading {
                ProgressView()
                    .padding()
            }

            ScrollView {
                Text(accumulatedContent)
                    .font(.body)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.green.opacity(0.1))
                    .cornerRadius(8)
                    .padding(.horizontal)
            }
            .frame(maxHeight: .infinity)

            if let errorMessage = errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .padding()
            }

            HStack {
                Button("Start Custom Stream") {
                    streamingTask?.cancel() // Cancel previous task
                    accumulatedContent = ""
                    errorMessage = nil
                    isLoading = true
                    streamingTask = Task {
                        await processAIStream()
                    }
                }
                .padding()
                .buttonStyle(.borderedProminent)
                .disabled(isLoading)

                Button("Cancel") {
                    streamingTask?.cancel()
                    isLoading = false
                    errorMessage = "Streaming cancelled by user."
                }
                .buttonStyle(.bordered)
                .disabled(!isLoading)
            }
        }
        .onDisappear {
            streamingTask?.cancel() // Ensure task is cancelled if view disappears
        }
    }

    @MainActor
    func processAIStream() async {
        do {
            let (bytes, response) = try await URLSession.shared.bytes(for: URLRequest(url: streamURL))

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                errorMessage = "Server responded with an unexpected status code."
                isLoading = false
                return
            }

            // Using the custom AIStreamDecoder
            let decoder = AIStreamDecoder<AIChatChunk>(asyncBytes: bytes)
            for await chunk in decoder {
                try Task.checkCancellation() // Allow cancellation during iteration
                if let content = chunk.choices?.first?.delta.content {
                    accumulatedContent.append(content)
                }
            }
            isLoading = false
            print("Custom AI stream finished successfully.")

        } catch is CancellationError {
            print("Streaming task cancelled.")
            errorMessage = "Streaming cancelled."
            isLoading = false
        } catch let decoderError as AIStreamDecoderError {
            errorMessage = "Decoder error: \(decoderError.localizedDescription)"
            isLoading = false
        } catch URLError.notConnectedToInternet {
            errorMessage = "No internet connection."
            isLoading = false
        } catch URLError.cannotConnectToHost {
            errorMessage = "Could not connect to the server. Is the Python server running on \(streamURL.absoluteString)?"
            isLoading = false
        } catch {
            errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
            isLoading = false
        }
    }
}
