
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import SwiftUI
import TextGeneration

@available(iOS 18.0, *)
struct ArticleView: View {
    let articleContent: String
    @State private var summary: String?
    @State private var isLoadingSummary = false
    @State private var showingErrorAlert = false
    @State private var errorMessage: String = ""

    // State to track TextGenerationService availability
    @State private var isTextGenerationAvailable = TextGenerationService.shared.isAvailable

    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                Text(articleContent)
                    .font(.body)
                    .padding()

                if let summary = summary {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("AI-Generated Summary:")
                            .font(.headline)
                        Text(summary)
                            .font(.subheadline)
                    }
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
                    .padding(.horizontal)
                    .transition(.opacity) // Smooth transition for summary appearance
                }

                Button {
                    Task {
                        await generateSummary()
                    }
                } label: {
                    Label("Summarize Article", systemImage: "text.book.closed.fill")
                }
                .buttonStyle(.borderedProminent)
                .disabled(isLoadingSummary || !isTextGenerationAvailable) // Disable if loading or not available
                .padding()

                if isLoadingSummary {
                    ProgressView("Generating Summary...")
                        .padding()
                        .transition(.opacity)
                }
            }
        }
        .animation(.easeInOut, value: isLoadingSummary) // Animate changes to isLoadingSummary
        .animation(.easeInOut, value: summary) // Animate changes to summary
        .onAppear {
            // Observe availability changes
            NotificationCenter.default.addObserver(forName: TextGenerationService.availabilityDidChangeNotification, object: nil, queue: .main) { _ in
                isTextGenerationAvailable = TextGenerationService.shared.isAvailable
            }
        }
        .onDisappear {
            // Clean up observer
            NotificationCenter.default.removeObserver(self, name: TextGenerationService.availabilityDidChangeNotification, object: nil)
        }
        .alert("Error", isPresented: $showingErrorAlert) {
            Button("OK") { }
        } message: {
            Text(errorMessage)
        }
    }

    private func generateSummary() async {
        guard isTextGenerationAvailable else {
            errorMessage = "Text Generation Service is not available on this device."
            showingErrorAlert = true
            return
        }
        isLoadingSummary = true
        summary = nil // Clear previous summary

        // Truncate article content if it's excessively long to fit model context and for performance
        let maxArticleLengthForPrompt = 5000 // Example limit, adjust based on model capabilities and performance testing
        let contentForPrompt = String(articleContent.prefix(maxArticleLengthForPrompt))

        let prompt = "Summarize the following article concisely:\n\n\(contentForPrompt)"
        let request = TextGenerationRequest(prompt: prompt)
        request.options.maxTokens = 200 // Limit summary length to keep it concise
        request.options.temperature = 0.3 // Lower temperature for factual, less creative summary

        do {
            let result = try await TextGenerationService.shared.generate(request)
            if let generatedText = result.text, !generatedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                self.summary = generatedText
            } else {
                errorMessage = "No summary could be generated for this article."
                showingErrorAlert = true
            }
        } catch {
            errorMessage = "Failed to generate summary: \(error.localizedDescription)"
            showingErrorAlert = true
            print("Error generating summary: \(error.localizedDescription)")
        }
        isLoadingSummary = false
    }
}

// Example usage in a parent view:
@available(iOS 18.0, *)
struct ArticleView_Previews: PreviewProvider {
    static var previews: some View {
        ArticleView(articleContent: """
            Apple Intelligence is a personal intelligence system that puts powerful generative models right at the core of iPhone, iPad, and Mac. It’s deeply integrated into iOS 18, iPadOS 18, and macOS Sequoia. Apple Intelligence unlocks new ways for users to enhance their writing and communicate more effectively with Writing Tools, create fun images in new styles with Image Playground, and simplify everyday tasks with new Siri capabilities and more. Built with privacy from the ground up, Apple Intelligence is flexible and can scale its computational power, drawing on on-device processing and Private Cloud Compute. It’s designed to understand and create language and images, take action across apps, and draw from personal context.
            
            This revolutionary suite of features is designed to be helpful and relevant to users’ daily lives. For example, Writing Tools can help users proofread, rewrite, and summarize text across Mail, Notes, Pages, and third-party apps. Image Playground allows users to create playful images in seconds, choosing from Animation, Illustration, or Sketch styles. Siri, now more natural, personal, and contextually aware, can understand and respond to users in new ways, including typing to Siri.
            
            Privacy is a core tenet of Apple Intelligence. All on-device processing ensures that personal data remains on the user’s device. For more complex requests, Private Cloud Compute extends Apple Intelligence’s capabilities by sending data to dedicated Apple silicon servers, ensuring that data is never stored or exposed to Apple, and is only used to fulfill the user’s request. This innovative approach to privacy sets Apple Intelligence apart and reinforces Apple's commitment to user data protection.
            """)
    }
}
