
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI

// MARK: - StreamingAIChatBubbleView
@available(iOS 18.0, *) // Requires iOS 18 for Task.sleep and modern concurrency
struct StreamingAIChatBubbleView: View {
    let fullResponse: String
    @State private var displayedText: String = ""
    @State private var streamingTask: Task<Void, Never>? = nil

    var body: some View {
        HStack {
            Text(displayedText)
                .padding(10)
                .background(Color.gray.opacity(0.2))
                .foregroundColor(.primary)
                .cornerRadius(15)
                .frame(maxWidth: 280, alignment: .leading)
            Spacer()
        }
        .onAppear {
            startStreaming()
        }
        .onDisappear {
            stopStreaming()
        }
    }

    private func startStreaming() {
        // Ensure previous task is cancelled if view reappears
        stopStreaming()

        displayedText = "" // Reset text for new streaming
        streamingTask = Task {
            for character in fullResponse {
                // Check for cancellation before each append
                guard !Task.isCancelled else { return }
                
                displayedText.append(character)
                // Introduce a small delay for the streaming effect
                try? await Task.sleep(for: .milliseconds(50)) // Swift 6: .milliseconds is cleaner than nanoseconds
            }
        }
    }

    private func stopStreaming() {
        streamingTask?.cancel()
        streamingTask = nil
    }
}

// MARK: - ContentView for demonstration
@available(iOS 18.0, *)
struct ContentViewStreaming: View {
    let longAIResponse = "Modern AI models often stream their responses word by word or character by character to provide a more immediate and engaging user experience. This dynamic display significantly enhances the perceived responsiveness of the application, making interactions feel more natural and less like waiting for a batch process to complete."

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                UserChatBubbleView(message: "Tell me about AI response streaming.") // Reusing Exercise 1's bubble
                StreamingAIChatBubbleView(fullResponse: longAIResponse)
                UserChatBubbleView(message: "That's a very clear explanation!")
                AIChatBubbleView(message: "I'm glad I could help.") // Reusing Exercise 1's bubble
            }
            .padding()
        }
        .navigationTitle("Streaming AI Chat")
    }
}

// MARK: - Preview Provider
@available(iOS 18.0, *)
#Preview {
    ContentViewStreaming()
}
