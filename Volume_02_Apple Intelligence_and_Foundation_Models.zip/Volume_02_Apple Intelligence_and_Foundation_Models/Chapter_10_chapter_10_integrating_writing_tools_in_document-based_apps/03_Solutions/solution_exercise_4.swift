
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit
import WritingTools // Assume WritingTools framework is available

@available(iOS 18.0, *)
class SmartReplyViewController: UIViewController, UITextViewDelegate {
    
    // Mock data for the "previous email" content
    private let previousEmailContent = """
    Subject: Meeting rescheduled
    
    Hi Team,
    
    Due to an unexpected conflict, I need to reschedule our weekly sync meeting originally set for Tuesday at 10 AM.
    
    I'm proposing we move it to Wednesday at 2 PM. Please let me know if this new time works for everyone by end of day today.
    
    Apologies for any inconvenience this may cause.
    
    Best,
    Alice
    """
    
    private let draftTextView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = UIFont.preferredFont(forTextStyle: .body)
        tv.isEditable = true
        tv.isSelectable = true
        tv.backgroundColor = .systemBackground
        tv.layer.borderColor = UIColor.systemGray3.cgColor
        tv.layer.borderWidth = 1
        tv.layer.cornerRadius = 8
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return tv
    }()
    
    private lazy var smartReplyButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Generate Smart Reply", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        button.addTarget(self, action: #selector(generateSmartReplyAction), for: .touchUpInside)
        return button
    }()
    
    // To keep track of the suggested reply's range for potential acceptance/rejection
    private var suggestedReplyRange: NSRange?
    private static let smartReplyAttributeName = NSAttributedString.Key("SmartReplySuggestion")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGroupedBackground
        title = "Smart Reply (iOS 18+)"
        
        view.addSubview(smartReplyButton)
        view.addSubview(draftTextView)
        
        NSLayoutConstraint.activate([
            smartReplyButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            smartReplyButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            draftTextView.topAnchor.constraint(equalTo: smartReplyButton.bottomAnchor, constant: 20),
            draftTextView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            draftTextView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            draftTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
        
        draftTextView.delegate = self
        draftTextView.text = "Hi Alice,\n\n" // Initial draft text
    }
    
    @objc private func generateSmartReplyAction() {
        // Remove any previous suggestions before generating a new one
        if let range = suggestedReplyRange {
            let mutableAttributedString = NSMutableAttributedString(attributedString: draftTextView.attributedText)
            mutableAttributedString.deleteCharacters(in: range)
            draftTextView.attributedText = mutableAttributedString
            suggestedReplyRange = nil
        }
        
        Task {
            await performSmartReplyGeneration(for: previousEmailContent)
        }
    }
    
    private func performSmartReplyGeneration(for contextEmail: String) async {
        DispatchQueue.main.async {
            self.smartReplyButton.isEnabled = false
            self.smartReplyButton.setTitle("Generating Reply...", for: .normal)
            // Optionally, show activity indicator
        }
        
        let prompt = "Based on the following email, suggest a concise and polite reply:\n\n\(contextEmail)\n\nSuggested reply:"
        
        let request = WritingToolsRequest.GenerateTextRequest(
            prompt: prompt,
            context: WritingToolsRequest.GenerateTextRequest.Context(
                sourceText: contextEmail,
                selectedText: nil, // No specific selection, the whole email is context
                insertionPoint: nil // No specific insertion point in the source
            )
        )
        
        do {
            let result = try await WritingToolsService.shared.generateTextRequest(for: request)
            
            if let suggestedReply = result.generateText.suggestions.first?.text, !suggestedReply.isEmpty {
                DispatchQueue.main.async {
                    self.insertSuggestedReply(suggestedReply)
                    print("Smart reply generated.")
                }
            } else {
                DispatchQueue.main.async {
                    print("No smart reply suggestions available.")
                }
            }
        } catch {
            DispatchQueue.main.async {
                print("Error generating smart reply: \(error.localizedDescription)")
            }
        }
        
        DispatchQueue.main.async {
            self.smartReplyButton.isEnabled = true
            self.smartReplyButton.setTitle("Generate Smart Reply", for: .normal)
            // Optionally, hide activity indicator
        }
    }
    
    private func insertSuggestedReply(_ reply: String) {
        let mutableAttributedString = NSMutableAttributedString(attributedString: draftTextView.attributedText)
        
        let replyWithPrefix = "\n\(reply)\n" // Add newlines for separation
        
        let suggestionAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.italicSystemFont(ofSize: UIFont.preferredFont(forTextStyle: .body).pointSize),
            .foregroundColor: UIColor.systemGray,
            Self.smartReplyAttributeName: true // Custom attribute to mark it as a suggestion
        ]
        let attributedReply = NSAttributedString(string: replyWithPrefix, attributes: suggestionAttributes)
        
        // Insert at current cursor position or end of text
        let insertionLocation = draftTextView.selectedRange.location
        mutableAttributedString.insert(attributedReply, at: insertionLocation)
        
        draftTextView.attributedText = mutableAttributedString
        
        // Store the range of the inserted suggestion
        suggestedReplyRange = NSRange(location: insertionLocation, length: attributedReply.length)
        
        // Move cursor to the end of the suggested reply
        draftTextView.selectedRange = NSRange(location: insertionLocation + attributedReply.length, length: 0)
        
        // Optionally, add a UI element (e.g., "Accept" button) next to the suggestion
        // For simplicity, we'll assume the user can directly edit it.
        // If the user starts typing within the suggested range, we might convert it to regular text.
    }
    
    // MARK: - UITextViewDelegate (for handling edits to suggestions)
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        // If the user starts typing within or immediately after a suggested reply,
        // convert the suggestion to regular text.
        if let suggestedRange = suggestedReplyRange,
           NSIntersectionRange(suggestedRange, range).length > 0 || range.location == suggestedRange.upperBound {
            
            let mutableAttributedString = NSMutableAttributedString(attributedString: textView.attributedText)
            mutableAttributedString.removeAttribute(Self.smartReplyAttributeName, range: suggestedRange)
            mutableAttributedString.removeAttributes([.font, .foregroundColor], range: suggestedRange) // Remove styling
            
            // Re-apply default font and color if necessary, or let the text view's default handle it
            mutableAttributedString.addAttributes([
                .font: UIFont.preferredFont(forTextStyle: .body),
                .foregroundColor: UIColor.label
            ], range: suggestedRange)
            
            textView.attributedText = mutableAttributedString
            suggestedReplyRange = nil // Clear the suggestion state
        }
        return true
    }
    
    // Ensure the view controller is available for iOS 18+
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        guard #available(iOS 18.0, *) else { return nil }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        guard #available(iOS 18.0, *) else { return }
    }
}
