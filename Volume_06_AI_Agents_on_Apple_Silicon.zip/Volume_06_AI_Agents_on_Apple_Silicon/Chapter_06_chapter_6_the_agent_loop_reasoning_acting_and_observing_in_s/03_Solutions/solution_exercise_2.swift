
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

// MARK: - 1. SummaryAgentState

/// Defines the preferred length for a summary.
enum SummaryLength: String, Codable, CaseIterable {
    case short = "short"
    case medium = "medium"
    case long = "long"

    var description: String {
        switch self {
        case .short: return "a concise summary, about 1-2 sentences."
        case .medium: return "a moderate summary, about 3-5 sentences."
        case .long: return "a detailed summary, about 5-10 sentences or a paragraph."
        }
    }
}

/// Holds the persistent state for the summarizer agent.
class SummaryAgentState {
    var preferredSummaryLength: SummaryLength

    init(preferredSummaryLength: SummaryLength = .medium) {
        self.preferredSummaryLength = preferredSummaryLength
    }
}

// MARK: - 2. SummarizeTool

/// Protocol for LLM inference (reused from Exercise 1).
protocol LLMInference {
    @available(iOS 18.0, macOS 15.0, *)
    func infer(prompt: String) async throws -> String
}

/// A mock LLM for summarization.
class MockSummarizerLLM: LLMInference {
    @available(iOS 18.0, macOS 15.0, *)
    func infer(prompt: String) async throws -> String {
        try await Task.sleep(for: .milliseconds(200)) // Simulate LLM processing time

        if prompt.contains("short summary") {
            return "This is a very short summary of the text: The document discusses agent-based systems and their applications."
        } else if prompt.contains("medium summary") {
            return "This is a medium-length summary: Agent-based systems involve reasoning, acting, and observing loops. They can be used for tasks like tool dispatch, context-aware processing, and conversational interactions. This text provides exercises to implement such agents in Swift."
        } else if prompt.contains("detailed summary") {
            return """
            This is a detailed summary: The provided document outlines several practical exercises for implementing agent-based systems in Swift.
            Exercise 1 focuses on a simple tool dispatcher agent, demonstrating how an LLM can interpret user queries to select and execute predefined Swift functions.
            Exercise 2 introduces a context-aware summarizer agent, which maintains a persistent state like preferred summary length to tailor its output.
            Exercise 3 challenges the user to build a code refactoring assistant, using LLMs for code analysis and generation of structured suggestions.
            Finally, Exercise 4 presents a multi-turn conversational calendar agent, requiring complex state management and orchestration of multiple tool calls to handle dynamic user interactions.
            All exercises emphasize leveraging Swift's concurrency features and designing modular, robust components.
            """
        }
        return "Couldn't generate a summary based on the prompt."
    }
}

/// The tool responsible for interacting with the LLM to summarize text.
@available(iOS 18.0, macOS 15.0, *)
struct SummarizeTool {
    private let llm: LLMInference

    init(llm: LLMInference) {
        self.llm = llm
    }

    func summarize(text: String, length: SummaryLength) async throws -> String {
        let prompt = """
        Please provide \(length.description) of the following text.
        Text: \"\"\"
        \(text)
        \"\"\"
        Summary:
        """
        return try await llm.infer(prompt: prompt)
    }
}

// MARK: - 3. SummarizerAgent

@available(iOS 18.0, macOS 15.0, *)
class SummarizerAgent {
    private let state: SummaryAgentState
    private let summarizeTool: SummarizeTool

    init(llm: LLMInference, initialState: SummaryAgentState = SummaryAgentState()) {
        self.state = initialState
        self.summarizeTool = SummarizeTool(llm: llm)
    }

    /// Summarizes the given text using the agent's current preferred summary length.
    func summarize(text: String) async throws -> String {
        print("Agent is summarizing text with preference: \(state.preferredSummaryLength.rawValue)")
        // Reasoning & Acting: The SummarizeTool encapsulates the LLM interaction
        let summary = try await summarizeTool.summarize(text: text, length: state.preferredSummaryLength)
        return summary
    }

    /// Updates the agent's preferred summary length. This is a simplified "observation" step.
    func setSummaryPreference(length: SummaryLength) {
        state.preferredSummaryLength = length
        print("Agent's summary preference updated to: \(length.rawValue)")
    }
}

// MARK: - Example Usage Flow

@available(iOS 18.0, macOS 15.0, *)
func runSummarizerExample() async throws {
    let llm = MockSummarizerLLM()
    let agent = SummarizerAgent(llm: llm)

    let longText = """
    The concept of agent-based systems is becoming increasingly central to the design of intelligent applications, especially with the rise of powerful Large Language Models (LLMs). An agent typically operates within a continuous loop of reasoning, acting, and observing. In the reasoning phase, the agent interprets its current environment and goals, often using an LLM to understand natural language inputs or to plan a sequence of actions. The acting phase involves executing specific tools or functions based on the reasoning outcome, which could range from simple data retrieval to complex system modifications. Finally, the observing phase involves perceiving the results of its actions or new environmental stimuli, updating its internal state, and feeding this information back into the reasoning phase for the next iteration of the loop.

    This chapter focuses on implementing these agent loops in Swift, leveraging its robust concurrency features. By designing agents that can dynamically select tools, manage persistent context, and engage in multi-turn interactions, developers can create highly interactive and intelligent user experiences in iOS and macOS applications. The exercises provided aim to solidify these concepts through practical implementation, covering scenarios such as simple tool dispatch, context-aware document summarization, code refactoring assistance, and complex conversational agents. Each exercise emphasizes modular design, effective LLM prompting, and efficient use of Swift's modern asynchronous programming paradigms.
    """

    print("--- Initial summary (default preference: \(agent.state.preferredSummaryLength.rawValue)) ---")
    let summary1 = try await agent.summarize(text: longText)
    print(summary1)

    print("\n--- Setting preference to short ---")
    agent.setSummaryPreference(length: .short)

    print("\n--- Second summary (short preference: \(agent.state.preferredSummaryLength.rawValue)) ---")
    let summary2 = try await agent.summarize(text: longText)
    print(summary2)

    print("\n--- Setting preference to long ---")
    agent.setSummaryPreference(length: .long)

    print("\n--- Third summary (long preference: \(agent.state.preferredSummaryLength.rawValue)) ---")
    let summary3 = try await agent.summarize(text: longText)
    print(summary3)
}

// To run the example in a playground or an app:
// if #available(iOS 18.0, macOS 15.0, *) {
//     Task {
//         try await runSummarizerExample()
//     }
// } else {
//     print("Requires iOS 18.0 / macOS 15.0 or later for async/await functionality.")
// }
