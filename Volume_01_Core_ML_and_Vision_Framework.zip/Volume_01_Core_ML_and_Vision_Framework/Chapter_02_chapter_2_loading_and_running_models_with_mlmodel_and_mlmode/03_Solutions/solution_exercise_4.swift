
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CoreML
import Foundation

// MARK: - Custom Error Types

enum SentimentAnalysisError: Error, LocalizedError, Sendable { // Conforming to Sendable for Swift 6 concurrency
    case modelLoadingFailed(underlyingError: Error)
    case inputPreparationFailed(message: String, underlyingError: Error?)
    case predictionFailed(message: String, underlyingError: Error)
    case unexpectedOutputFormat(details: String)
    case modelNotReady

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let error):
            return "Failed to load sentiment model: \(error.localizedDescription)"
        case .inputPreparationFailed(let message, let error):
            return "Failed to prepare input for message '\(message)': \(error?.localizedDescription ?? "Unknown error")"
        case .predictionFailed(let message, let error):
            return "Prediction failed for message '\(message)': \(error.localizedDescription)"
        case .unexpectedOutputFormat(let details):
            return "Model returned unexpected output format: \(details)"
        case .modelNotReady:
            return "Sentiment model is not loaded or ready for predictions."
        }
    }
}

// MARK: - SentimentResult Struct

struct SentimentResult: Sendable { // Conforming to Sendable for Swift 6 concurrency
    let message: String
    let sentiment: String // e.g., "Positive", "Negative", "Neutral"
    let confidence: Double
    let error: SentimentAnalysisError? // To capture errors for individual messages in a batch
}

// MARK: - SentimentAnalyzer Class

@available(iOS 17.0, *)
class SentimentAnalyzer {
    private var model: MLModel?
    private let modelURL: URL
    private let modelInputName: String // e.g., "text"
    private let modelOutputLabelName: String // e.g., "sentiment"
    private let modelOutputProbabilitiesName: String // e.g., "sentimentProbs"

    /// Initializes the SentimentAnalyzer.
    /// - Parameters:
    ///   - modelURL: The URL to the compiled sentiment analysis model.
    ///   - inputName: The name of the text input feature in the model (e.g., "text").
    ///   - outputLabelName: The name of the predicted sentiment label output (e.g., "sentiment").
    ///   - outputProbabilitiesName: The name of the probabilities output dictionary (e.g., "sentimentProbs").
    init(modelURL: URL, inputName: String, outputLabelName: String, outputProbabilitiesName: String) {
        self.modelURL = modelURL
        self.modelInputName = inputName
        self.modelOutputLabelName = outputLabelName
        self.modelOutputProbabilitiesName = outputProbabilitiesName
        loadModel()
    }

    /// Loads the Core ML model, handling potential errors.
    private func loadModel() {
        do {
            self.model = try MLModel(contentsOf: modelURL)
            print("Sentiment model loaded successfully from \(modelURL.lastPathComponent).")
        } catch {
            print(SentimentAnalysisError.modelLoadingFailed(underlyingError: error).localizedDescription)
            self.model = nil
        }
    }

    /// Converts a single String message into an MLFeatureProvider.
    /// This method needs to match your model's input requirements.
    /// - Parameter message: The text message to convert.
    /// - Throws: `SentimentAnalysisError.inputPreparationFailed` if conversion fails.
    /// - Returns: An `MLDictionaryFeatureProvider` for the message.
    private func createFeatureProvider(for message: String) throws -> MLDictionaryFeatureProvider {
        // This example assumes the model directly takes a String input.
        // If your model expects tokenized input (e.g., MLMultiArray of word IDs),
        // this method would be significantly more complex.
        return try MLDictionaryFeatureProvider(dictionary: [modelInputName: MLFeatureValue(string: message)])
    }

    /// Predicts sentiment for a batch of messages using `MLModel.predictions(inputs:options:)`.
    /// - Parameter messages: An array of String messages to analyze.
    /// - Returns: An array of `SentimentResult`, one for each input message,
    ///            including any individual errors.
    func predictSentiment(for messages: [String]) async -> [SentimentResult] {
        guard let model = model else {
            return messages.map {
                SentimentResult(message: $0, sentiment: "Unknown", confidence: 0.0, error: .modelNotReady)
            }
        }

        var results: [SentimentResult] = []
        var featureProviders: [MLFeatureProvider] = []
        var messagesForBatch: [String] = [] // Keep track of messages that successfully became feature providers

        // Prepare feature providers for all messages, handling individual input errors
        for message in messages {
            do {
                let provider = try createFeatureProvider(for: message)
                featureProviders.append(provider)
                messagesForBatch.append(message) // Only add to batch if input preparation succeeded
            } catch {
                // If input preparation fails for a message, record the error and skip it for batch prediction
                results.append(SentimentResult(message: message, sentiment: "Error", confidence: 0.0, error: .inputPreparationFailed(message: message, underlyingError: error)))
            }
        }

        guard !featureProviders.isEmpty else {
            // If no feature providers could be created, return results with errors
            return results
        }

        do {
            // Perform batch prediction using async/await
            // MLModel.predictions(inputs:options:) is designed for batch processing.
            // Under the Hood: Batch prediction can be significantly more efficient than
            // individual predictions because it reduces the overhead per item (e.g.,
            // model loading, context switching, memory allocation) and allows the
            // underlying hardware (CPU, GPU, Neural Engine) to be utilized more effectively
            // with parallel processing.
            let batchPredictions = try await model.predictions(inputs: featureProviders)

            // Interpret results for each prediction in the batch
            for (index, prediction) in batchPredictions.enumerated() {
                let originalMessage = messagesForBatch[index] // Get the original message for this result

                if let sentimentLabel = prediction.featureValue(forName: modelOutputLabelName)?.stringValue,
                   let probabilities = prediction.featureValue(forName: modelOutputProbabilitiesName)?.dictionaryValue as? [String: Double],
                   let confidence = probabilities[sentimentLabel] {
                    results.append(SentimentResult(message: originalMessage, sentiment: sentimentLabel, confidence: confidence, error: nil))
                } else {
                    // If output format is unexpected for a specific prediction
                    results.append(SentimentResult(message: originalMessage, sentiment: "Unknown", confidence: 0.0, error: .unexpectedOutputFormat(details: "Missing sentiment label or probabilities for '\(originalMessage)'")))
                }
            }
        } catch {
            // If the *entire batch* prediction fails (e.g., a critical model error),
            // mark all messages that were part of this batch as failed.
            print(SentimentAnalysisError.predictionFailed(message: "Batch prediction failed completely", underlyingError: error).localizedDescription)
            for message in messagesForBatch {
                // Only add an error result if it hasn't already been added (e.g., from input preparation)
                if !results.contains(where: { $0.message == message }) {
                    results.append(SentimentResult(message: message, sentiment: "Error", confidence: 0.0, error: .predictionFailed(message: message, underlyingError: error)))
                }
            }
        }

        return results
    }

    /// Convenience method for single message prediction (internally calls batch prediction).
    func predictSentiment(for message: String) async -> SentimentResult {
        let results = await predictSentiment(for: [message])
        return results.first ?? SentimentResult(message: message, sentiment: "Error", confidence: 0.0, error: .predictionFailed(message: message, underlyingError: nil))
    }
}

// MARK: - Example Usage in a ViewController

@available(iOS 17.0, *)
class SentimentViewController: UIViewController {

    var analyzer: SentimentAnalyzer!
    var textView: UITextView!
    var analyzeButton: UIButton!
    var resultLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        setupAnalyzer()
    }

    private func setupUI() {
        textView = UITextView()
        textView.font = .preferredFont(forTextStyle: .body)
        textView.layer.borderWidth = 1
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.cornerRadius = 5
        textView.text = "This is a great app! I love it so much. It's truly fantastic."
        textView.translatesAutoresizingMaskIntoConstraints = false

        analyzeButton = UIButton(type: .system)
        analyzeButton.setTitle("Analyze Sentiment", for: .normal)
        analyzeButton.addTarget(self, action: #selector(analyzeText), for: .touchUpInside)
        analyzeButton.translatesAutoresizingMaskIntoConstraints = false

        resultLabel = UILabel()
        resultLabel.numberOfLines = 0
        resultLabel.textAlignment = .center
        resultLabel.font = .preferredFont(forTextStyle: .headline)
        resultLabel.translatesAutoresizingMaskIntoConstraints = false

        let stackView = UIStackView(arrangedSubviews: [textView, analyzeButton, resultLabel])
        stackView.axis = .vertical
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 150)
        ])
    }

    private func setupAnalyzer() {
        // IMPORTANT: Replace "SentimentClassifier" with your actual model name
        // and adjust input/output names according to your model's specification.
        // Example for a simple text classifier:
        // Input: "text" (String)
        // Output: "sentiment" (String), "sentimentProbs" (Dictionary<String, Double>)

        guard let modelURL = Bundle.main.url(forResource: "SentimentClassifier", withExtension: "mlmodelc") else {
            print("Error: SentimentClassifier.mlmodelc not found in bundle.")
            return
        }

        analyzer = SentimentAnalyzer(
            modelURL: modelURL,
            inputName: "text",
            outputLabelName: "sentiment",
            outputProbabilitiesName: "sentimentProbs"
        )
    }

    @objc private func analyzeText() {
        guard let text = textView.text, !text.isEmpty else {
            resultLabel.text = "Please enter some text."
            return
        }

        Task { // Use a Task to call the async prediction method
            let messages = [
                "This is a fantastic product! Highly recommended.",
                "I'm feeling neutral about this, it's neither good nor bad.",
                "Absolutely terrible experience, I hate it.",
                "The weather is quite pleasant today.",
                "This message should fail input preparation if the model expects something else.", // Example for error testing
                text // User's input
            ]

            print("\n--- Analyzing batch of messages ---")
            let results = await analyzer.predictSentiment(for: messages)

            var displayString = "Batch Analysis Results:\n"
            for result in results {
                if let error = result.error {
                    displayString += "  '\(result.message)': Error - \(error.localizedDescription)\n"
                } else {
                    displayString += "  '\(result.message)': \(result.sentiment) (\(String(format: "%.2f", result.confidence * 100))%)\n"
                }
            }
            print(displayString)
            resultLabel.text = displayString

            // Example for single message prediction
            print("\n--- Analyzing single message ---")
            let singleResult = await analyzer.predictSentiment(for: "This is just okay, nothing special.")
            print("Single message result: '\(singleResult.message)': \(singleResult.sentiment) (\(String(format: "%.2f", singleResult.confidence * 100))%)")
        }
    }
}

// To run this example:
// 1. Create a new iOS project.
// 2. Obtain or create a text classification Core ML model (e.g., using Create ML or a pre-trained NLP model).
//    Ensure it takes a String as input and outputs a sentiment label (String) and probabilities (Dictionary<String, Double>).
//    Drag its compiled .mlmodelc into your project.
// 3. Replace the contents of your ViewController.swift with the code above.
