
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit // Use AppKit for macOS
import Foundation

// MARK: - StreamingViewController

@available(iOS 18.0, macOS 15.0, *)
class StreamingViewController: UIViewController { // Or NSViewController for macOS

    // MARK: - UI Elements

    private lazy var textView: UITextView = { // Or NSTextView for macOS
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.isEditable = false
        tv.font = .monospacedSystemFont(ofSize: 16, weight: .regular)
        tv.backgroundColor = .systemGray6
        tv.textColor = .label
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return tv
    }()

    private lazy var startButton: UIButton = { // Or NSButton for macOS
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Start Streaming", for: .normal)
        button.addTarget(self, action: #selector(startStreamingTapped), for: .touchUpInside)
        return button
    }()

    // MARK: - Properties

    private let streamingURL = URL(string: "http://127.0.0.1:5000/stream/text")!
    private var streamingTask: Task<Void, Error>?

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // Cancel any ongoing streaming task when the view disappears
        streamingTask?.cancel()
    }

    // MARK: - UI Setup

    private func setupUI() {
        view.backgroundColor = .systemBackground

        view.addSubview(textView)
        view.addSubview(startButton)

        NSLayoutConstraint.activate([
            startButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            startButton.heightAnchor.constraint(equalToConstant: 44),

            textView.topAnchor.constraint(equalTo: startButton.bottomAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    // MARK: - Actions

    @objc private func startStreamingTapped() {
        // Clear previous text and disable button while streaming
        textView.text = ""
        startButton.isEnabled = false
        startButton.setTitle("Streaming...", for: .normal)

        streamingTask = Task {
            defer { // Ensure UI is reset even if an error occurs or task is cancelled
                Task { @MainActor in
                    self.startButton.isEnabled = true
                    self.startButton.setTitle("Start Streaming", for: .normal)
                }
            }
            await streamTextFeed()
        }
    }

    // MARK: - Streaming Logic

    private func streamTextFeed() async {
        do {
            let (bytes, response) = try await URLSession.shared.bytes(for: streamingURL)

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                throw URLError(.badServerResponse)
            }

            print("Starting text stream...")

            for await chunk in bytes {
                // Check for cancellation within the loop
                try Task.checkCancellation()

                guard let text = String(data: chunk, encoding: .utf8) else {
                    print("Could not decode chunk to UTF-8 string.")
                    continue
                }

                // Update UI on the MainActor
                await MainActor.run {
                    textView.text.append(text)
                    // Scroll to bottom
                    let bottom = NSRange(location: textView.text.count - 1, length: 1)
                    textView.scrollRangeToVisible(bottom)
                }
            }
            print("Text stream finished.")

        } catch is CancellationError {
            print("Text stream cancelled.")
            await MainActor.run {
                textView.text.append("\n\n--- Stream Cancelled ---")
            }
        } catch {
            print("Error during text streaming: \(error.localizedDescription)")
            await MainActor.run {
                textView.text.append("\n\n--- Error: \(error.localizedDescription) ---")
            }
        }
    }
}
