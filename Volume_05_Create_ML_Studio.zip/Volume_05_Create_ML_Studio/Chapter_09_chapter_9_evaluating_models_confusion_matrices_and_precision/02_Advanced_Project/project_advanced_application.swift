
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet for Swift Package Manager dependencies
// This example does not require external dependencies beyond Foundation and CoreML
// (CoreML is implicitly used for Create ML models, but not directly invoked here for evaluation).
/*
// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "ContentModerationEvaluator",
    platforms: [
        .iOS(.v18), // Or .macOS(.v15), .tvOS(.v18), .watchOS(.v11)
    ],
    products: [
        .library(
            name: "ContentModerationEvaluator",
            targets: ["ContentModerationEvaluator"]),
    ],
    targets: [
        .target(
            name: "ContentModerationEvaluator",
            dependencies: []),
        .testTarget(
            name: "ContentModerationEvaluatorTests",
            dependencies: ["ContentModerationEvaluator"]),
    ]
)
*/

import Foundation

/// Represents the possible ground truth labels for content.
enum ContentLabel: String, Codable, CaseIterable {
    case harmful = "Harmful"
    case safe = "Safe"
}

/// Represents a specific moderation action taken based on model confidence.
enum ModerationAction: String, Codable, CaseIterable {
    case manualReview = "Manual Review" // Low confidence, human needed
    case softBlock = "Soft Block"       // Medium confidence, hide from public
    case hardBlock = "Hard Block"       // High confidence, immediate removal
    case noAction = "No Action"         // Below all thresholds
}

/// Defines a confidence threshold that triggers a specific moderation action.
struct ActionThreshold: Codable, Identifiable {
    let id = UUID()
    let confidenceThreshold: Double // Minimum confidence to trigger this action
    let action: ModerationAction

    /// Initializes a new action threshold.
    /// - Parameters:
    ///   - confidenceThreshold: The minimum model confidence (0.0 to 1.0) to trigger this action.
    ///   - action: The moderation action associated with this threshold.
    init(confidenceThreshold: Double, action: ModerationAction) {
        precondition(confidenceThreshold >= 0.0 && confidenceThreshold <= 1.0, "Confidence threshold must be between 0.0 and 1.0.")
        self.confidenceThreshold = confidenceThreshold
        self.action = action
    }
}

/// Represents a single prediction from the Create ML model, along with its ground truth.
struct ModerationPrediction: Codable, Identifiable {
    let id: String // Unique ID for the content (e.g., image ID, post ID)
    let predictedHarmfulConfidence: Double // Model's confidence that content is 'Harmful'
    let groundTruth: ContentLabel         // The actual label of the content

    /// Initializes a new moderation prediction.
    /// - Parameters:
    ///   - id: A unique identifier for the content.
    ///   - predictedHarmfulConfidence: The model's confidence score for the 'harmful' class (0.0 to 1.0).
    ///   - groundTruth: The true label of the content.
    init(id: String, predictedHarmfulConfidence: Double, groundTruth: ContentLabel) {
        precondition(predictedHarmfulConfidence >= 0.0 && predictedHarmfulConfidence <= 1.0, "Predicted confidence must be between 0.0 and 1.0.")
        self.id = id
        self.predictedHarmfulConfidence = predictedHarmfulConfidence
        self.groundTruth = groundTruth
    }
}

/// Custom error types for the evaluation process.
enum ModerationEvaluationError: Error, LocalizedError {
    case emptyPredictionSet
    case invalidThresholdConfiguration(String)
    case targetClassNotPresent

    var errorDescription: String? {
        switch self {
        case .emptyPredictionSet:
            return "The prediction set is empty. Cannot perform evaluation."
        case .invalidThresholdConfiguration(let message):
            return "Invalid threshold configuration: \(message)"
        case .targetClassNotPresent:
            return "The target class for evaluation (e.g., 'Harmful') was not encountered in predictions."
        }
    }
}

/// Stores the calculated evaluation metrics for a given action or overall system.
struct EvaluationMetrics: Identifiable {
    let id = UUID()
    let truePositives: Int
    let falsePositives: Int
    let falseNegatives: Int
    let trueNegatives: Int
    let actionTriggered: ModerationAction? // Nil for overall metrics
    let thresholdUsed: Double?             // Nil for overall metrics

    /// Precision: TP / (TP + FP) - Proportion of positive identifications that were actually correct.
    var precision: Double {
        let denominator = Double(truePositives + falsePositives)
        return denominator > 0 ? Double(truePositives) / denominator : 0.0
    }

    /// Recall (Sensitivity): TP / (TP + FN) - Proportion of actual positives that were identified correctly.
    var recall: Double {
        let denominator = Double(truePositives + falseNegatives)
        return denominator > 0 ? Double(truePositives) / denominator : 0.0
    }

    /// F1-Score: 2 * (Precision * Recall) / (Precision + Recall) - Harmonic mean of precision and recall.
    var f1Score: Double {
        let denominator = precision + recall
        return denominator > 0 ? 2 * (precision * recall) / denominator : 0.0
    }

    /// Accuracy: (TP + TN) / (TP + FP + FN + TN) - Overall correctness of the model.
    var accuracy: Double {
        let total = Double(truePositives + falsePositives + falseNegatives + trueNegatives)
        return total > 0 ? Double(truePositives + trueNegatives) / total : 0.0
    }

    /// Initializes a new EvaluationMetrics instance.
    /// - Parameters:
    ///   - truePositives: Count of true positives.
    ///   - falsePositives: Count of false positives.
    ///   - falseNegatives: Count of false negatives.
    ///   - trueNegatives: Count of true negatives.
    ///   - actionTriggered: The specific moderation action these metrics apply to, or nil for overall.
    ///   - thresholdUsed: The confidence threshold used for this evaluation, or nil for overall.
    init(truePositives: Int, falsePositives: Int, falseNegatives: Int, trueNegatives: Int,
         actionTriggered: ModerationAction? = nil, thresholdUsed: Double? = nil) {
        self.truePositives = truePositives
        self.falsePositives = falsePositives
        self.falseNegatives = falseNegatives
        self.trueNegatives = trueNegatives
        self.actionTriggered = actionTriggered
        self.thresholdUsed = thresholdUsed
    }
}

/// A service for evaluating content moderation model predictions across multiple action tiers.
@available(iOS 18.0, *) // Using modern concurrency features
final class ContentModerationEvaluator {

    /// The target class that we consider "positive" (e.g., "Harmful").
    private let targetPositiveClass: ContentLabel

    /// Initializes the ContentModerationEvaluator.
    /// - Parameter targetPositiveClass: The `ContentLabel` that represents the positive class for evaluation (e.g., `.harmful`).
    init(targetPositiveClass: ContentLabel = .harmful) {
        self.targetPositiveClass = targetPositiveClass
    }

    /// Evaluates a set of model predictions against a defined moderation policy (action tiers).
    /// This method calculates metrics for each action tier and an overall system evaluation.
    ///
    /// - Parameters:
    ///   - predictions: An array of `ModerationPrediction` objects from the model.
    ///   - policy: An array of `ActionThreshold` objects defining the moderation policy.
    ///             These should be sorted by `confidenceThreshold` in descending order for correct processing.
    /// - Returns: A `Result` containing an array of `EvaluationMetrics` for each action tier and an overall summary,
    ///            or a `ModerationEvaluationError` if evaluation fails.
    /// - Throws: `ModerationEvaluationError` if the input predictions are empty or policy is misconfigured.
    func evaluatePredictions(
        predictions: [ModerationPrediction],
        policy: [ActionThreshold]
    ) async throws -> [EvaluationMetrics] {

        // 1. Input Validation and Sorting
        guard !predictions.isEmpty else {
            throw ModerationEvaluationError.emptyPredictionSet
        }

        // Sort policy thresholds in descending order to ensure the most stringent action
        // (highest confidence) is evaluated first. This is crucial for correctly assigning actions.
        let sortedPolicy = policy.sorted { $0.confidenceThreshold > $1.confidenceThreshold }
        guard !sortedPolicy.isEmpty else {
            throw ModerationEvaluationError.invalidThresholdConfiguration("Policy cannot be empty.")
        }

        // 2. Process Predictions and Assign Actions
        // We'll use a dictionary to store metrics for each action.
        var metricsByAction: [ModerationAction: (tp: Int, fp: Int, fn: Int, tn: Int)] = [:]
        for action in ModerationAction.allCases {
            metricsByAction[action] = (0, 0, 0, 0)
        }

        // Initialize overall counters for the entire system's performance
        var overallTP = 0
        var overallFP = 0
        var overallFN = 0
        var overallTN = 0

        // Use a TaskGroup for concurrent processing if predictions were very large,
        // but for typical evaluation sets, a simple loop is often sufficient and clearer.
        // For pedagogical purposes, we'll keep it synchronous here to focus on the logic.
        for prediction in predictions {
            // Determine the highest-priority action triggered by this prediction
            var triggeredAction: ModerationAction = .noAction
            for threshold in sortedPolicy {
                if prediction.predictedHarmfulConfidence >= threshold.confidenceThreshold {
                    triggeredAction = threshold.action
                    break // Found the highest-priority action for this confidence
                }
            }

            // Update metrics for the specific triggered action
            var (tp, fp, fn, tn) = metricsByAction[triggeredAction]!

            let isPredictionPositive = (prediction.predictedHarmfulConfidence >= sortedPolicy.last!.confidenceThreshold && triggeredAction != .noAction) // If any action was triggered, we consider it a positive prediction for the *system*
            let isGroundTruthPositive = (prediction.groundTruth == targetPositiveClass)

            // Update metrics for the specific action tier
            if triggeredAction != .noAction { // Only count for specific actions, not 'noAction'
                if isPredictionPositive && isGroundTruthPositive {
                    tp += 1
                } else if isPredictionPositive && !isGroundTruthPositive {
                    fp += 1
                } else if !isPredictionPositive && isGroundTruthPositive {
                    fn += 1
                }
                // TN for a specific action tier is tricky. It's usually calculated against the *entire dataset*
                // not just what triggered the action. For per-action metrics, we focus on TP/FP/FN relative
                // to items that *triggered* that action.
                // For TN, we'll calculate it in the overall system evaluation.
            }

            // Update overall system metrics
            // For overall system, we consider any action (manual review, soft block, hard block) as a "positive" prediction
            // and 'noAction' as a "negative" prediction.
            if triggeredAction != .noAction { // System classified as positive
                if isGroundTruthPositive {
                    overallTP += 1
                } else {
                    overallFP += 1
                }
            } else { // System classified as negative
                if !isGroundTruthPositive {
                    overallTN += 1
                } else {
                    overallFN += 1
                }
            }
            
            metricsByAction[triggeredAction] = (tp, fp, fn, tn)
        }

        // 3. Generate EvaluationMetrics objects
        var results: [EvaluationMetrics] = []

        for threshold in sortedPolicy {
            let (tp, fp, fn, tn) = metricsByAction[threshold.action]!
            // Note: TN for individual action tiers is often not meaningful in isolation
            // as it would imply all *other* predictions were negative for *this specific action*.
            // We set TN to 0 here for per-action metrics, as they focus on the positives of that action.
            // The overall TN is more relevant.
            results.append(EvaluationMetrics(truePositives: tp, falsePositives: fp,
                                             falseNegatives: fn, trueNegatives: 0,
                                             actionTriggered: threshold.action,
                                             thresholdUsed: threshold.confidenceThreshold))
        }

        // Add the 'No Action' metrics if applicable
        if let (tp, fp, fn, tn) = metricsByAction[.noAction] {
            // For 'No Action', we are effectively predicting 'Safe'.
            // So, TP for 'No Action' means correctly predicting 'Safe' (Ground Truth: Safe, Predicted: Safe).
            // FP for 'No Action' means incorrectly predicting 'Safe' (Ground Truth: Harmful, Predicted: Safe).
            // This is actually TN and FN from the perspective of the *Harmful* class.
            // To align with the other metrics where we count 'Harmful' as positive:
            // TP_noAction = TN_overall (correctly classified as safe)
            // FP_noAction = FN_overall (incorrectly classified as safe, should have been harmful)
            // FN_noAction = FP_overall (incorrectly classified as harmful, should have been safe)
            // TN_noAction = TP_overall (correctly classified as harmful)
            // This can be confusing, so it's often better to just report overall metrics for 'no action'.
            // For simplicity, we'll report what *triggered* no action and was correctly safe.
            let noActionTP = predictions.filter { $0.predictedHarmfulConfidence < sortedPolicy.last!.confidenceThreshold && $0.groundTruth == .safe }.count
            let noActionFN = predictions.filter { $0.predictedHarmfulConfidence < sortedPolicy.last!.confidenceThreshold && $0.groundTruth == .harmful }.count
            results.append(EvaluationMetrics(truePositives: noActionTP, falsePositives: 0, // No FP if we consider 'no action' as predicting 'safe'
                                             falseNegatives: noActionFN, trueNegatives: 0,
                                             actionTriggered: .noAction,
                                             thresholdUsed: sortedPolicy.last!.confidenceThreshold))
        }


        // 4. Calculate Overall System Metrics
        let overallMetrics = EvaluationMetrics(truePositives: overallTP,
                                               falsePositives: overallFP,
                                               falseNegatives: overallFN,
                                               trueNegatives: overallTN,
                                               actionTriggered: nil, // Indicates overall
                                               thresholdUsed: nil)
        results.append(overallMetrics)

        return results
    }
}

// MARK: - Real-World Apple App Context Example

@available(iOS 18.0, *)
struct ModerationDashboardView {
    @State private var evaluationResults: [EvaluationMetrics] = []
    @State private var isLoading = false
    @State private var errorMessage: String?

    // Simulate a large dataset of predictions
    private func generateSamplePredictions(count: Int) -> [ModerationPrediction] {
        var predictions: [ModerationPrediction] = []
        for i in 0..<count {
            let isHarmful = Bool.random() // Roughly 50/50 split for ground truth
            let confidence: Double

            if isHarmful {
                // Ground truth is harmful, model should ideally predict high confidence
                confidence = Double.random(in: 0.6...0.99)
            } else {
                // Ground truth is safe, model should ideally predict low confidence
                confidence = Double.random(in: 0.01...0.7)
            }

            // Introduce some noise/misclassifications
            if Bool.random(by: 0.15) { // 15% chance of "wrong" confidence direction
                if isHarmful { // Harmful content, but model is unsure (low confidence)
                    confidence = Double.random(in: 0.01...0.5)
                } else { // Safe content, but model is overconfident (high confidence)
                    confidence = Double.random(in: 0.7...0.99)
                }
            }

            predictions.append(ModerationPrediction(
                id: "content_\(i)",
                predictedHarmfulConfidence: confidence,
                groundTruth: isHarmful ? .harmful : .safe
            ))
        }
        return predictions
    }

    /// Main function to perform the evaluation.
    func performEvaluation() async {
        isLoading = true
        errorMessage = nil
        do {
            // 1. Define the Moderation Policy with Action Tiers
            // Sorted by confidenceThreshold descending is good practice, though the evaluator sorts it.
            let moderationPolicy: [ActionThreshold] = [
                ActionThreshold(confidenceThreshold: 0.90, action: .hardBlock),
                ActionThreshold(confidenceThreshold: 0.75, action: .softBlock),
                ActionThreshold(confidenceThreshold: 0.50, action: .manualReview)
            ]

            // 2. Simulate Model Predictions (In a real app, these would come from Core ML inference)
            let rawPredictions = generateSamplePredictions(count: 5000)

            // 3. Initialize and Run the Evaluator
            let evaluator = ContentModerationEvaluator(targetPositiveClass: .harmful)
            let results = try await evaluator.evaluatePredictions(predictions: rawPredictions, policy: moderationPolicy)
            
            // 4. Update UI with results
            evaluationResults = results
        } catch {
            errorMessage = "Evaluation failed: \(error.localizedDescription)"
            print("Error during evaluation: \(error)")
        }
        isLoading = false
    }

    // A simplified representation of a SwiftUI View for demonstration.
    // In a real SwiftUI app, this would be a `View` struct.
    func displayResults() {
        print("--- Content Moderation System Evaluation Results ---")
        if isLoading {
            print("Loading evaluation results...")
            return
        }

        if let error = errorMessage {
            print("Error: \(error)")
            return
        }

        guard !evaluationResults.isEmpty else {
            print("No evaluation results available.")
            return
        }

        for result in evaluationResults {
            let title: String
            if let action = result.actionTriggered {
                title = "Action: \(action.rawValue) (Threshold: \(String(format: "%.2f", result.thresholdUsed ?? 0.0)))"
            } else {
                title = "Overall System Performance"
            }
            
            print("\n\(title)")
            print("  True Positives (TP): \(result.truePositives)")
            print("  False Positives (FP): \(result.falsePositives)")
            print("  False Negatives (FN): \(result.falseNegatives)")
            print("  True Negatives (TN): \(result.trueNegatives)") // Note: TN for per-action is often 0 or not directly applicable
            print("  Precision: \(String(format: "%.2f", result.precision * 100))%")
            print("  Recall: \(String(format: "%.2f", result.recall * 100))%")
            print("  F1-Score: \(String(format: "%.2f", result.f1Score * 100))%")
            if result.actionTriggered == nil { // Only show accuracy for overall system
                print("  Accuracy: \(String(format: "%.2f", result.accuracy * 100))%")
            }
        }
        print("-----------------------------------------------------")
    }
}

// Example usage in an async context (e.g., from an AppDelegate, SceneDelegate, or main function)
@available(iOS 18.0, *)
@main
struct ModerationApp {
    static func main() async {
        let dashboard = ModerationDashboardView()
        await dashboard.performEvaluation()
        dashboard.displayResults()
    }
}
