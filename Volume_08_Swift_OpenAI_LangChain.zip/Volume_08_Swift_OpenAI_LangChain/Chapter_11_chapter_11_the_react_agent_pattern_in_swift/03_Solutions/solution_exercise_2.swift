
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI
import Observation

@available(iOS 18.0, *)
enum AgentStep: Identifiable, Sendable {
    case thought(String)
    case action(name: String, args: [String: AnySendable])
    case observation(String)
    case finalAnswer(String)
    
    var id: UUID { UUID() }
}

struct AnySendable: Sendable {
    let value: Sendable
    init(_ value: Sendable) { self.value = value }
    func asString() -> String? { value as? String }
}

@available(iOS 18.0, *)
@Observable
class AgentViewModel {
    var steps: [AgentStep] = []
    var isRunning = false
    
    @MainActor
    func runTask(prompt: String) async {
        isRunning = true
        steps.removeAll()
        
        // Simulate the ReAct Loop
        let simulatedLoop: AsyncStream<AgentStep> = AsyncStream { continuation in
            Task {
                // Step 1: Thought
                continuation.yield(.thought("I need to find out how to organize the user's tasks for tomorrow."))
                try? await Task.sleep(for: .seconds(1))
                
                // Step 2: Action
                continuation.yield(.action(name: "get_tomorrow_tasks", args: [:]))
                try? await Task.sleep(for: .seconds(1))
                
                // Step 3: Observation
                continuation.yield(.observation("Found 3 tasks: 1. Meeting, 2. Gym, 3. Grocery."))
                try? await Task.sleep(for: .seconds(1))
                
                // Step 4: Final Thought/Answer
                continuation.yield(.thought("I have the tasks. Now I will present the organized list."))
                continuation.yield(.finalAnswer("You have 3 tasks tomorrow: Meeting, Gym, and Groceries."))
                
                continuation.finish()
            }
        }
        
        // Consume the stream and update the UI on the MainActor
        for await step in simulatedLoop {
            steps.append(step)
        }
        
        isRunning = false
    }
}

@available(iOS 18.0, *)
struct AgentLogView: View {
    @State private var viewModel = AgentViewModel()
    
    var body: some View {
        NavigationStack {
            List(viewModel.steps) { step in
                switch step {
                case .thought(let text):
                    Label(text, systemImage: "bubble.left.fill")
                        .italic()
                        .foregroundStyle(.secondary)
                case .action(let name, _):
                    HStack {
                        Image(systemName: "hammer.fill")
                        Text("Action: \(name)")
                            .font(.system(.body, design: .monospaced))
                    }
                    .fontWeight(.bold)
                    .foregroundStyle(.orange)
                case .observation(let text):
                    Label(text, systemImage: "eye.fill")
                        .foregroundStyle(.blue)
                case .finalAnswer(let text):
                    VStack(alignment: .leading) {
                        Text("Final Answer")
                            .font(.caption)
                            .fontWeight(.bold)
                        Text(text)
                            .fontWeight(.heavy)
                    }
                    .foregroundStyle(.green)
                }
            }
            .navigationTitle("Agent Reasoning")
            .toolbar {
                Button(viewModel.isRunning ? "Running..." : "Start Agent") {
                    Task {
                        await viewModel.runTask(prompt: "Organize my tasks.")
                    }
                }
                .disabled(viewModel.isRunning)
            }
        }
    }
}
