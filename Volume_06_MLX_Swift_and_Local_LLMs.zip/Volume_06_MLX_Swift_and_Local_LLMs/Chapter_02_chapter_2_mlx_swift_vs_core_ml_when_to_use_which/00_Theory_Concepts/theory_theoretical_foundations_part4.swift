
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import Foundation

@available(iOS 18.0, *)
actor ModelLoader {
    private var model: LinearLayer?

    func loadModel(inputFeatures: Int, outputFeatures: Int) async throws -> LinearLayer {
        // Simulate a time-consuming model loading operation
        try await Task.sleep(for: .seconds(2))
        let loadedModel = LinearLayer(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
        self.model = loadedModel
        return loadedModel
    }

    func performInference(input: MLXArray) async throws -> MLXArray {
        guard let model = model else {
            throw NSError(domain: "ModelLoader", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model not loaded"])
        }
        // Inference can also be a long-running operation
        return model(input)
    }
}

@available(iOS 18.0, *)
func demonstrateAsyncInference() async {
    let loader = ModelLoader()
    do {
        print("Starting model load...")
        let model = try await loader.loadModel(inputFeatures: 10, outputFeatures: 5)
        print("Model loaded successfully.")

        let input = MLXArray.rand([1, 10], .float32)
        let output = try await loader.performInference(input: input)
        print("Inference complete. Output shape: \(output.shape)")
    } catch {
        print("Error during async operation: \(error.localizedDescription)")
    }
}
