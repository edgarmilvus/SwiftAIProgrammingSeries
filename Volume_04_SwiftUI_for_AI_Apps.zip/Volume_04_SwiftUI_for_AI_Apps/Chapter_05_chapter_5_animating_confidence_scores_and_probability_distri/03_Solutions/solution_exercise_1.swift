
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI

@available(iOS 18.0, macOS 15.0, *)
struct ConfidenceGaugeView: View {
    @State var confidenceScore: Double // Simulate updates to this value

    // Helper to determine color based on confidence score
    private var barColor: Color {
        if confidenceScore < 0.5 {
            return .orange // Low confidence
        } else if confidenceScore < 0.75 {
            return .yellow // Medium confidence
        } else {
            return .green // High confidence
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("AI Prediction Confidence")
                .font(.headline)
                .padding(.bottom, 5)

            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    // Background track of the progress bar
                    Capsule()
                        .fill(Color.gray.opacity(0.3))
                        .frame(height: 30)

                    // Animated foreground bar
                    Capsule()
                        .fill(barColor) // Dynamic color
                        .frame(width: geometry.size.width * CGFloat(confidenceScore), height: 30)
                        .animation(.easeInOut(duration: 0.7), value: confidenceScore) // Smooth width animation
                        .animation(.easeInOut(duration: 0.7), value: barColor) // Smooth color animation
                }
            }
            .frame(height: 30) // Fixed height for the gauge
            .padding(.horizontal)

            // Textual display of confidence score
            Text(confidenceScore, format: .percent.precision(.fractionLength(1)))
                .font(.title2.bold())
                .foregroundColor(barColor)
                .animation(.easeInOut(duration: 0.7), value: confidenceScore) // Animate text color
                .padding(.horizontal)
        }
        .padding()
        .onAppear {
            // Simulate initial and subsequent updates
            confidenceScore = 0.65
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                withAnimation(.easeInOut(duration: 1.0)) { // Explicit animation block for multiple changes
                    confidenceScore = 0.92
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                withAnimation(.easeInOut(duration: 1.0)) {
                    confidenceScore = 0.38
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
                withAnimation(.easeInOut(duration: 1.0)) {
                    confidenceScore = 0.70
                }
            }
        }
    }
}
