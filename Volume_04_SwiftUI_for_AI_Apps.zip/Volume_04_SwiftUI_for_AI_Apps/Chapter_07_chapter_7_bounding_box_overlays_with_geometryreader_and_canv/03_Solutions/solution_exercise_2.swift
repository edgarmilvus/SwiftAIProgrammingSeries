
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

struct InteractiveBoundingBoxSelectorView: View {
    // @State to store the last tap location, optional because no box is drawn initially.
    @State private var tapLocation: CGPoint?

    // Define the fixed size of the square bounding box.
    let boxSize: CGFloat = 50

    var body: some View {
        VStack {
            Text("Interactive Bounding Box Selector")
                .font(.headline)
                .padding()

            // The image to overlay. Using a system symbol.
            Image(systemName: "photo.fill")
                .resizable()
                .scaledToFit()
                .foregroundColor(.gray)
                .padding()
                // Attach a TapGesture to the image.
                .gesture(
                    TapGesture()
                        .onEnded { value in
                            // Capture the tap location within the image's coordinate space.
                            tapLocation = value.location
                        }
                )
                // Overlay with GeometryReader and Canvas
                .overlay(
                    GeometryReader { geometry in
                        Canvas { context, size in
                            // Only draw if a tap location exists.
                            if let location = tapLocation {
                                // Calculate the top-left origin for the fixed-size box,
                                // centering it around the tap location.
                                let boxOriginX = location.x - (boxSize / 2)
                                let boxOriginY = location.y - (boxSize / 2)

                                let drawRect = CGRect(
                                    x: boxOriginX,
                                    y: boxOriginY,
                                    width: boxSize,
                                    height: boxSize
                                )

                                // Create and draw the path for the bounding box.
                                let path = Path(roundedRect: drawRect, cornerRadius: 5)
                                context.stroke(path, with: .color(.blue), lineWidth: 2)
                            }
                        }
                        // Important: allowsHitTesting(false) here is crucial.
                        // If it were true, the Canvas would intercept taps, and
                        // the TapGesture on the Image would not fire.
                        .allowsHitTesting(false)
                    }
                )
                .frame(width: 300, height: 200) // Fixed frame for demonstration
                .background(Color.secondary.opacity(0.1))
        }
    }
}

// Preview Provider
struct InteractiveBoundingBoxSelectorView_Previews: PreviewProvider {
    static var previews: some View {
        InteractiveBoundingBoxSelectorView()
    }
}
