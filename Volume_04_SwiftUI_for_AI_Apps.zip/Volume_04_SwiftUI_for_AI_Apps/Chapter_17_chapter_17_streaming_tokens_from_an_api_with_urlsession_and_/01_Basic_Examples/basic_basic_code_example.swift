
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import SwiftUI

// MARK: - AIChatService: Handles API Communication

/// A service responsible for interacting with a hypothetical AI backend
/// to stream text responses.
@available(iOS 15.0, macOS 12.0, *) // Requires modern Swift Concurrency features
class AIChatService {

    private let apiBaseURL: URL

    /// Initializes the chat service with the base URL of the AI API.
    /// - Parameter apiBaseURL: The base URL for the AI API endpoint.
    init(apiBaseURL: URL) {
        self.apiBaseURL = apiBaseURL
    }

    /// Streams text tokens from a hypothetical AI API endpoint.
    ///
    /// This function demonstrates how to use `URLSession.shared.bytes(for: request)`
    /// to get an `AsyncBytes` sequence and iterate over it to receive data
    /// in real-time, simulating an AI model streaming its response.
    ///
    /// For simplicity, this example assumes the API sends newline-delimited
    /// UTF-8 encoded text chunks. In a real-world scenario, you might need
    /// to parse Server-Sent Events (SSE) or custom JSON streaming protocols.
    ///
    /// - Parameter prompt: The user's input prompt for the AI.
    /// - Returns: An `AsyncThrowingStream` of `String` tokens, representing
    ///   the AI's streamed response. Each `String` is a piece of the response.
    ///   The stream can throw errors if the network request fails or data
    ///   cannot be processed.
    func streamAIText(prompt: String) -> AsyncThrowingStream<String, Error> {
        AsyncThrowingStream { continuation in
            Task { // The work inside AsyncThrowingStream's closure runs in a Task
                do {
                    // 1. Construct the URL and Request
                    //    This example assumes a POST request to an endpoint like /stream
                    //    with a JSON body containing the prompt.
                    //    NOTE: Replace "https://api.example.com/ai" with your actual AI API endpoint.
                    //    This URL is a placeholder and will not connect to a real AI service.
                    guard let url = apiBaseURL.appendingPathComponent("stream") else {
                        continuation.finish(throwing: URLError(.badURL))
                        return
                    }

                    var request = URLRequest(url: url)
                    request.httpMethod = "POST"
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")

                    // Simulate sending the prompt. In a real app, you might include
                    // API keys or other authentication headers.
                    let requestBody: [String: String] = ["prompt": prompt]
                    request.httpBody = try JSONEncoder().encode(requestBody)

                    // 2. Initiate the Network Request and Get AsyncBytes
                    //    `URLSession.shared.bytes(for: request)` returns a tuple
                    //    containing the HTTPURLResponse and an AsyncBytes sequence.
                    let (bytes, response) = try await URLSession.shared.bytes(for: request)

                    // 3. Validate the HTTP Response
                    //    Ensure the server responded with a success status code (2xx).
                    guard let httpResponse = response as? HTTPURLResponse else {
                        continuation.finish(throwing: URLError(.badServerResponse))
                        return
                    }

                    guard (200...299).contains(httpResponse.statusCode) else {
                        // Attempt to read error message from response body if status is not 2xx
                        let errorData = try await bytes.reduce(into: Data()) { $0.append($1) }
                        let errorString = String(data: errorData, encoding: .utf8) ?? "Unknown server error"
                        continuation.finish(throwing: URLError(.badServerResponse, userInfo: [NSLocalizedDescriptionKey: "Server error: \(httpResponse.statusCode) - \(errorString)"]))
                        return
                    }

                    // 4. Process the Streamed Bytes
                    //    Iterate over the `AsyncBytes` sequence. Each `byte` represents
                    //    a single `UInt8` received from the network.
                    var buffer = Data()
                    for try await byte in bytes {
                        buffer.append(byte)

                        // 5. Simulate Token Extraction (Simplified for newline-delimited chunks)
                        //    In many streaming APIs (e.g., Server-Sent Events, or simple text streams),
                        //    data chunks are delimited by newline characters (`\n`).
                        //    This example buffers bytes until a newline character is found.
                        //    When a newline is found, the accumulated data *before* the newline
                        //    is treated as a complete "token" or message chunk.
                        while let newlineRange = buffer.firstRange(of: Data([0x0A])) { // 0x0A is ASCII for '\n'
                            let tokenData = buffer.prefix(upTo: newlineRange.lowerBound)
                            if let token = String(data: tokenData, encoding: .utf8), !token.isEmpty {
                                continuation.yield(token) // Yield the extracted token
                            }
                            // Remove the processed token data and the newline from the buffer
                            buffer.removeSubrange(..<newlineRange.upperBound)
                        }
                    }

                    // 6. Handle any remaining data in the buffer after the stream ends
                    //    This might occur if the server closes the connection without a final newline.
                    if !buffer.isEmpty, let finalToken = String(data: buffer, encoding: .utf8), !finalToken.isEmpty {
                        continuation.yield(finalToken)
                    }

                    // 7. Signal Completion
                    //    Once the `bytes` sequence finishes (e.g., server closes connection),
                    //    signal that the stream has completed successfully.
                    continuation.finish()

                } catch {
                    // 8. Handle Errors
                    //    If any error occurs during the network request or byte processing,
                    //    signal the error to the stream's subscribers.
                    continuation.finish(throwing: error)
                }
            }
        }
    }
}

// MARK: - ChatView: SwiftUI UI for Demonstration

/// A simple SwiftUI view to demonstrate consuming the AI chat stream.
@available(iOS 15.0, macOS 12.0, *)
struct ChatView: View {
    @State private var prompt: String = "Tell me a short story about a brave knight."
    @State private var streamedResponse: String = ""
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?

    // Initialize the chat service with a placeholder URL.
    // In a real app, this would be configured appropriately, e.g., from environment variables.
    // IMPORTANT: Replace "https://api.example.com/ai" with a real (mock) API endpoint
    // that supports streaming if you want to see actual network activity.
    private let chatService = AIChatService(apiBaseURL: URL(string: "https://api.example.com/ai")!)

    var body: some View {
        VStack(spacing: 20) {
            Text("AI Assistant")
                .font(.largeTitle)
                .bold()

            ScrollView {
                Text(streamedResponse)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
            }
            .frame(maxHeight: 200)

            TextField("Enter your prompt", text: $prompt)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)

            Button {
                Task { // Create a new Task for the async operation
                    await startStreaming()
                }
            } label: {
                Text(isLoading ? "Streaming..." : "Ask AI")
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isLoading ? Color.blue.opacity(0.5) : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .disabled(isLoading)
            .padding(.horizontal)

            if let errorMessage = errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
            }
        }
        .padding()
    }

    /// Initiates the streaming process and updates the UI.
    /// This function is marked `@MainActor` because it updates `@State` properties,
    /// which directly affect the SwiftUI user interface.
    @MainActor
    private func startStreaming() async {
        isLoading = true
        streamedResponse = "" // Clear previous response
        errorMessage = nil

        do {
            // Call the service to get the AsyncThrowingStream of tokens
            let stream = chatService.streamAIText(prompt: prompt)

            // Iterate over the stream to receive tokens in real-time
            for try await token in stream {
                // Append each received token to the response string, updating the UI incrementally.
                streamedResponse += token
            }
        } catch {
            errorMessage = error.localizedDescription
            print("Streaming Error: \(error.localizedDescription)")
        } finally {
            isLoading = false
        }
    }
}

// MARK: - App Entry Point

/// The main entry point for the AI Chat application.
@available(iOS 15.0, macOS 12.0, *)
@main
struct AIApp: App {
    var body: some Scene {
        WindowGroup {
            ChatView()
        }
    }
}
