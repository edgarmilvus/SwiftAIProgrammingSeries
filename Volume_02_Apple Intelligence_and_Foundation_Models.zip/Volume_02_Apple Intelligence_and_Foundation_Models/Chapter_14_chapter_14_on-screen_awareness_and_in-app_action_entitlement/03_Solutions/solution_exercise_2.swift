
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import AppIntents
import Foundation // For URL

@available(iOS 18.0, *)
struct LogWorkoutIntent: AppIntent {
    // 1. Define static properties for user-facing information
    static var title: LocalizedStringResource = "Log Workout"
    static var description: IntentDescription = "Logs a new workout in the fitness tracker application."
    static var openAppWhenRun: Bool = true // Indicate that the app should open when this intent is run

    // No parameters needed for this basic version, as per the exercise.

    // 2. Implement the perform() method
    func perform() async throws -> some IntentResult {
        // Your implementation to handle the action goes here.
        // For this exercise, simulate opening the workout logging screen.
        print("LogWorkoutIntent triggered: Opening workout logging screen.")

        // In a real app, you might navigate to a specific view using a deep link or internal routing.
        // For example, if your app has a custom URL scheme:
        // await UIApplication.shared.open(URL(string: "yourapp://logWorkout")!)

        // Return a simple result, indicating success.
        return .result()
    }
}

// Don't forget to declare this intent in your app's Info.plist or via the AppIntents framework.
// For AppIntents, the system automatically discovers them if they are part of your app's target.
// However, for Siri and Apple Intelligence to discover them, you typically need to declare them
// in your project settings under the "Info" tab, in the "Custom iOS Target Properties" section,
// or directly in Info.plist.

/*
// Conceptual Info.plist entry for the entitlement (this is usually managed by Xcode's capabilities or AppIntents declaration):
// In Xcode, you would typically add the "Siri & Search" capability, and then declare your AppIntents
// in the App Intents section of your target's Info.plist or Build Settings.
// The underlying entitlement looks something like this:
<key>com.apple.developer.siri.action-intents</key>
<array>
    <dict>
        <key>IntentClassName</key>
        <string>LogWorkoutIntent</string>
        <key>IntentIdentifier</key>
        <string>LogWorkoutIntent</string>
    </dict>
</array>
*/

// Why this is important:
// Declaring AppIntents allows Apple Intelligence, Siri, Shortcuts, and Spotlight to discover and invoke specific functionalities within your app.
// It's the foundational step for enabling deep integration with the system, allowing users to interact with your app's features using natural language or automated workflows.
// By setting `openAppWhenRun = true`, the system knows to bring your app to the foreground when this intent is executed.
