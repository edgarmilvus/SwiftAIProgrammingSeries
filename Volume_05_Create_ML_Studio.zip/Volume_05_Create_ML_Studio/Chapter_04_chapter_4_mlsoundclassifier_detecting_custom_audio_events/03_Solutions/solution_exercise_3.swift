
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import AVFoundation
import CoreML
import Combine

// Assume BirdSongClassifier.mlmodel is added to the project.
// This model should have classes like "Robin", "Sparrow", "Owl", "Crow", "BackgroundNoise".
// Input format: MLMultiArray of shape [1, N] where N is samples for 2-3 seconds @ 16kHz, mono, Float32.
// Let's assume 2 seconds of audio at 16kHz, so N = 32000.

// MARK: - Core ML Model Wrapper

struct BirdSongClassifierInput {
    let input: MLMultiArray
}

struct BirdSongClassifierOutput {
    let label: String // The top predicted label
    let labelProbability: [String : Double] // Probabilities for all labels
}

final class BirdSongClassifierModel {
    private let model: BirdSongClassifier
    let modelInputLength: Int // Number of samples per classification chunk
    let expectedSampleRate: Double = 16000.0

    init(bufferDuration: TimeInterval) throws {
        let configuration = MLModelConfiguration()
        self.model = try BirdSongClassifier(configuration: configuration)
        self.modelInputLength = Int(bufferDuration * expectedSampleRate)
    }

    func predict(input: BirdSongClassifierInput) throws -> BirdSongClassifierOutput {
        let prediction = try model.prediction(input: input.input)
        return BirdSongClassifierOutput(label: prediction.label, labelProbability: prediction.labelProbability)
    }
    
    // Helper to get the expected audio format for the model (mono, Float32, 16kHz)
    var audioFormat: AVAudioFormat {
        return AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: expectedSampleRate, channels: 1, interleaved: false)!
    }
}

// MARK: - Audio Buffer Accumulator

class AudioBufferAccumulator {
    private let targetBufferDuration: TimeInterval
    private let targetSampleRate: Double
    private let audioFormat: AVAudioFormat
    private var accumulatedBuffer: AVAudioPCMBuffer
    private let lock = NSLock() // Protects accumulatedBuffer access

    init(targetBufferDuration: TimeInterval, targetSampleRate: Double) {
        self.targetBufferDuration = targetBufferDuration
        self.targetSampleRate = targetSampleRate
        self.audioFormat = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: targetSampleRate, channels: 1, interleaved: false)!
        // Pre-allocate buffer for the full target duration
        self.accumulatedBuffer = AVAudioPCMBuffer(pcmFormat: audioFormat, frameCapacity: AVAudioFrameCount(targetBufferDuration * targetSampleRate))!
        self.accumulatedBuffer.frameLength = 0 // Start empty
    }

    /// Appends an incoming buffer's data to the accumulator.
    /// Returns a full buffer if capacity is reached, otherwise nil.
    func append(buffer: AVAudioPCMBuffer) -> AVAudioPCMBuffer? {
        lock.lock()
        defer { lock.unlock() }

        // Ensure the incoming buffer's format is compatible (or convert it)
        guard buffer.format.commonFormat == audioFormat.commonFormat &&
              buffer.format.sampleRate == audioFormat.sampleRate &&
              buffer.format.channelCount == audioFormat.channelCount else {
            print("Incoming buffer format mismatch. Resampling needed.")
            return nil // For simplicity, we assume format matches.
        }

        let framesToCopy = min(buffer.frameLength, accumulatedBuffer.frameCapacity - accumulatedBuffer.frameLength)
        
        if framesToCopy > 0 {
            accumulatedBuffer.append(buffer, startingFrame: 0, frameCount: framesToCopy)
        }

        if accumulatedBuffer.frameLength == accumulatedBuffer.frameCapacity {
            // Buffer is full, return a copy and reset the accumulator
            let fullBuffer = accumulatedBuffer.copy() as! AVAudioPCMBuffer
            accumulatedBuffer.frameLength = 0 // Reset for next accumulation
            return fullBuffer
        }
        return nil
    }

    /// Resets the accumulator, discarding any partially accumulated audio.
    func reset() {
        lock.lock()
        defer { lock.unlock() }
        accumulatedBuffer.frameLength = 0
    }
}

// MARK: - Audio Processing & Classification Service

struct BirdDetection: Identifiable, Equatable {
    let id = UUID()
    let timestamp: Date
    let species: String
    let confidence: Double
    
    // Used to avoid logging the same continuous sound repeatedly
    static func == (lhs: BirdDetection, rhs: BirdDetection) -> Bool {
        return lhs.species == rhs.species && lhs.confidence == rhs.confidence && Calendar.current.isDate(lhs.timestamp, equalTo: rhs.timestamp, toGranularity: .second)
    }
}

class BirdSongMonitor: ObservableObject {
    @Published var detections: [BirdDetection] = []
    @Published var permissionGranted: Bool = false
    @Published var isMonitoring: Bool = false
    @Published var errorMessage: String?

    private let audioEngine = AVAudioEngine()
    private var classifier: BirdSongClassifierModel?
    private let audioProcessingQueue = DispatchQueue(label: "com.example.birdSongAudioProcessing", qos: .userInitiated)
    
    private let classificationBufferDuration: TimeInterval = 2.0 // 2 seconds per classification
    private var bufferAccumulator: AudioBufferAccumulator!

    // For avoiding redundant logging: keep track of the last detected species
    private var lastLoggedSpecies: String?
    private var lastLoggedTimestamp: Date?
    private let redundancyThreshold: TimeInterval = 5.0 // Don't log same species within 5 seconds

    init() {
        do {
            classifier = try BirdSongClassifierModel(bufferDuration: classificationBufferDuration)
            bufferAccumulator = AudioBufferAccumulator(
                targetBufferDuration: classificationBufferDuration,
                targetSampleRate: classifier!.expectedSampleRate
            )
        } catch {
            errorMessage = "Failed to load ML model: \(error.localizedDescription)"
            print("Error loading model: \(error)")
        }
    }
    
    deinit {
        stopMonitoring()
    }

    func requestMicrophonePermission() async {
        let status = AVCaptureDevice.authorizationStatus(for: .audio)
        switch status {
        case .authorized:
            permissionGranted = true
        case .notDetermined:
            await AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                DispatchQueue.main.async {
                    self?.permissionGranted = granted
                    if !granted {
                        self?.errorMessage = "Microphone permission denied. Please enable it in Settings."
                    }
                }
            }
        case .denied, .restricted:
            permissionGranted = false
            errorMessage = "Microphone permission denied. Please enable it in Settings."
        @unknown default:
            permissionGranted = false
            errorMessage = "Unknown microphone permission status."
        }
    }

    func startMonitoring() {
        guard permissionGranted, classifier != nil else {
            errorMessage = "Microphone permission not granted or model not loaded."
            return
        }

        let inputNode = audioEngine.inputNode
        let bus = 0
        
        let inputFormat = inputNode.inputFormat(forBus: bus)
        let outputFormat = classifier!.audioFormat // Mono, Float32, 16kHz

        if inputFormat.sampleRate != outputFormat.sampleRate || inputFormat.channelCount != outputFormat.channelCount {
            audioEngine.attach(AVAudioMixerNode())
            let mixer = audioEngine.mainMixerNode
            audioEngine.connect(inputNode, to: mixer, format: inputFormat)
            audioEngine.connect(mixer, to: audioEngine.outputNode, format: outputFormat)
            
            inputNode.installTap(onBus: bus, bufferSize: AVAudioFrameCount(outputFormat.sampleRate / 10), format: outputFormat) { [weak self] buffer, time in
                self?.handleIncomingAudio(buffer: buffer)
            }
        } else {
            inputNode.installTap(onBus: bus, bufferSize: AVAudioFrameCount(inputFormat.sampleRate / 10), format: inputFormat) { [weak self] buffer, time in
                self?.handleIncomingAudio(buffer: buffer)
            }
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
            isMonitoring = true
            errorMessage = nil
            detections = [] // Clear previous detections
            lastLoggedSpecies = nil
            lastLoggedTimestamp = nil
        } catch {
            errorMessage = "Error starting audio engine: \(error.localizedDescription)"
            print("Error starting audio engine: \(error)")
        }
    }

    func stopMonitoring() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        isMonitoring = false
        bufferAccumulator.reset()
        lastLoggedSpecies = nil
        lastLoggedTimestamp = nil
    }

    private func handleIncomingAudio(buffer: AVAudioPCMBuffer) {
        audioProcessingQueue.async { [weak self] in
            guard let self = self, let classifier = self.classifier else { return }

            if let fullBuffer = self.bufferAccumulator.append(buffer: buffer) {
                // We have a full buffer for classification
                guard let multiArray = fullBuffer.toMLMultiArray(
                    modelInputLength: classifier.modelInputLength,
                    targetSampleRate: classifier.expectedSampleRate
                ) else {
                    print("Failed to convert full buffer to MLMultiArray.")
                    return
                }

                do {
                    let prediction = try classifier.predict(input: BirdSongClassifierInput(input: multiArray))
                    
                    // Filter out background noise or low confidence predictions
                    guard prediction.label != "BackgroundNoise",
                          let confidence = prediction.labelProbability[prediction.label],
                          confidence > 0.6 else { // Example confidence threshold for logging
                        return
                    }
                    
                    let newDetection = BirdDetection(timestamp: Date(), species: prediction.label, confidence: confidence)
                    
                    DispatchQueue.main.async {
                        // Avoid logging redundant entries for continuous sounds
                        if let lastSpecies = self.lastLoggedSpecies,
                           let lastTimestamp = self.lastLoggedTimestamp,
                           lastSpecies == newDetection.species,
                           newDetection.timestamp.timeIntervalSince(lastTimestamp) < self.redundancyThreshold {
                            // Update existing entry if it's the same species and within threshold
                            if let index = self.detections.firstIndex(where: { $0.species == lastSpecies }) {
                                self.detections[index] = newDetection // Update confidence/timestamp
                            }
                        } else {
                            // Add new detection
                            self.detections.insert(newDetection, at: 0) // Add to top of list
                            // Keep log from growing indefinitely
                            if self.detections.count > 100 {
                                self.detections.removeLast()
                            }
                        }
                        self.lastLoggedSpecies = newDetection.species
                        self.lastLoggedTimestamp = newDetection.timestamp
                    }
                } catch {
                    print("Error during prediction: \(error)")
                }
            }
        }
    }
}

// MARK: - Helper Extension for AVAudioPCMBuffer to MLMultiArray Conversion (Same as Exercise 1/2)
extension AVAudioPCMBuffer {
    func toMLMultiArray(modelInputLength: Int, targetSampleRate: Double) -> MLMultiArray? {
        guard let floatChannelData = floatChannelData else { return nil }
        guard format.channelCount == 1 else { return nil }
        guard format.sampleRate == targetSampleRate else { return nil }

        let frameCount = Int(frameLength)
        guard frameCount >= modelInputLength else { return nil }

        do {
            let multiArray = try MLMultiArray(shape: [1, NSNumber(value: modelInputLength)], dataType: .float32)
            let bufferPointer = UnsafeMutableBufferPointer(start: floatChannelData[0], count: frameCount)

            for i in 0..<modelInputLength {
                multiArray[i] = NSNumber(value: bufferPointer[i])
            }
            return multiArray
        } catch {
            print("Failed to create MLMultiArray: \(error)")
            return nil
        }
    }
}

// MARK: - SwiftUI View

struct BirdSongIdentifierView: View {
    @StateObject private var monitor = BirdSongMonitor()

    var body: some View {
        VStack {
            Text("Bird Song Identifier")
                .font(.largeTitle)
                .padding()

            if let errorMessage = monitor.errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }

            if monitor.permissionGranted {
                Text(monitor.isMonitoring ? "Listening for Bird Songs..." : "Ready to Identify")
                    .font(.headline)
                    .padding()

                Button(action: {
                    if monitor.isMonitoring {
                        monitor.stopMonitoring()
                    } else {
                        monitor.startMonitoring()
                    }
                }) {
                    Text(monitor.isMonitoring ? "Stop Monitoring" : "Start Monitoring")
                        .font(.title2)
                        .padding()
                        .background(monitor.isMonitoring ? Color.red : Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()

                Divider()

                Text("Detections Log:")
                    .font(.title2)
                    .padding(.top)

                ScrollView {
                    LazyVStack(alignment: .leading) {
                        ForEach(monitor.detections) { detection in
                            HStack {
                                Text(detection.timestamp, formatter: itemFormatter)
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                Text("\(detection.species)")
                                    .font(.body)
                                    .fontWeight(.medium)
                                    .foregroundColor(colorForSpecies(detection.species))
                                Text(String(format: "(%.1f%%)", detection.confidence * 100))
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                Spacer()
                            }
                            .padding(.vertical, 2)
                        }
                    }
                    .padding(.horizontal)
                }
            } else {
                Text("Microphone access is required to identify bird songs.")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding()
                Button("Request Microphone Access") {
                    Task {
                        await monitor.requestMicrophonePermission()
                    }
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
        }
        .onAppear {
            Task {
                await monitor.requestMicrophonePermission()
            }
        }
        .padding()
    }

    private func colorForSpecies(_ species: String) -> Color {
        switch species {
        case "Robin": return .red
        case "Sparrow": return .brown
        case "Owl": return .purple
        case "Crow": return .black
        default: return .blue
        }
    }

    private let itemFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.timeStyle = .medium
        return formatter
    }()
}

// MARK: - App Entry Point (for iOS)
/*
@main
struct BirdSongIdentifierApp: App {
    var body: some Scene {
        WindowGroup {
            BirdSongIdentifierView()
        }
    }
}
*/
