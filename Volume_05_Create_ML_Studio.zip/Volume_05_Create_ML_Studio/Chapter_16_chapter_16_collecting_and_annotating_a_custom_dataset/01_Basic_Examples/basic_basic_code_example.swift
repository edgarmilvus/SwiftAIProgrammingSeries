
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import UIKit // For UIImage, used for placeholder images
// No PhotosUI needed directly for this basic example as we are simulating image input.

/// A structure representing a single image entry in our custom dataset,
/// complete with its assigned annotation label.
/// It conforms to `Codable` for easy serialization to/from JSON,
/// and `Identifiable` for potential use in UI lists (e.g., SwiftUI).
struct AnnotatedImage: Codable, Identifiable {
    /// A unique identifier for this annotation entry.
    let id: UUID
    /// The filename of the image, relative to the dataset directory.
    let imageFileName: String
    /// The human-assigned label or category for the image. This is the core "annotation".
    let annotationLabel: String
    /// The timestamp when the annotation was created.
    let timestamp: Date

    /// Initializes a new `AnnotatedImage` entry.
    /// - Parameters:
    ///   - id: A unique UUID for the entry. Defaults to a new UUID.
    ///   - imageFileName: The filename of the associated image.
    ///   - annotationLabel: The label assigned to the image.
    ///   - timestamp: The creation date. Defaults to the current date.
    init(id: UUID = UUID(), imageFileName: String, annotationLabel: String, timestamp: Date = Date()) {
        self.id = id
        self.imageFileName = imageFileName
        self.annotationLabel = annotationLabel
        self.timestamp = timestamp
    }
}

/// Custom error type for dataset operations, providing clear, localized descriptions.
enum DatasetError: Error, LocalizedError {
    /// Indicates failure to convert a `UIImage` into a storable data format (e.g., JPEG).
    case imageConversionFailed
    /// Indicates an error occurred while saving image data to disk.
    case imageSaveFailed(Error)
    /// Indicates an error occurred while saving the annotation metadata (JSON file).
    case annotationSaveFailed(Error)
    /// Indicates an error occurred while loading annotation metadata from disk.
    case annotationLoadFailed(Error)
    /// Indicates an error occurred while deleting an image file from disk.
    case imageDeleteFailed(Error)
    /// Indicates an error occurred while deleting the dataset directory.
    case datasetDirectoryDeletionFailed(Error)

    /// A localized description of the error for user-facing messages or logging.
    var errorDescription: String? {
        switch self {
        case .imageConversionFailed:
            return "Failed to convert image to data format (e.g., JPEG)."
        case .imageSaveFailed(let error):
            return "Failed to save image to disk: \(error.localizedDescription)"
        case .annotationSaveFailed(let error):
            return "Failed to save annotation metadata: \(error.localizedDescription)"
        case .annotationLoadFailed(let error):
            return "Failed to load annotation metadata: \(error.localizedDescription)"
        case .imageDeleteFailed(let error):
            return "Failed to delete image file: \(error.localizedDescription)"
        case .datasetDirectoryDeletionFailed(let error):
            return "Failed to delete dataset directory: \(error.localizedDescription)"
        }
    }
}

/// Manages the collection, storage, and retrieval of annotated images.
/// This class handles file system interactions, ensuring images and their
/// metadata (annotations) are persistently stored in a structured manner
/// within the app's sandbox.
class DatasetManager {
    /// A shared singleton instance of the `DatasetManager` for easy access throughout the app.
    static let shared = DatasetManager()

    /// The name of the subdirectory within the app's Documents directory where the dataset will be stored.
    private let datasetDirectoryName = "CustomImageDataset"
    /// The filename for the JSON file that stores all `AnnotatedImage` metadata.
    private let annotationsFileName = "annotations.json"

    /// The URL to the dedicated dataset directory within the app's sandbox.
    /// This property ensures the directory path is always correctly resolved.
    private var datasetDirectory: URL {
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            // In a production app, this would be handled more gracefully,
            // perhaps by returning an optional or throwing an error.
            fatalError("Could not find the app's Documents directory. This is a critical system error.")
        }
        return documentsDirectory.appendingPathComponent(datasetDirectoryName, isDirectory: true)
    }

    /// The full URL to the annotations JSON file within the dataset directory.
    private var annotationsFileUrl: URL {
        return datasetDirectory.appendingPathComponent(annotationsFileName)
    }

    /// Private initializer to enforce the singleton pattern.
    /// It ensures the dataset directory exists upon initialization.
    private init() {
        createDatasetDirectoryIfNeeded()
    }

    /// Creates the dataset directory if it doesn't already exist.
    /// This ensures that file operations can proceed without issues.
    private func createDatasetDirectoryIfNeeded() {
        if !FileManager.default.fileExists(atPath: datasetDirectory.path) {
            do {
                try FileManager.default.createDirectory(at: datasetDirectory, withIntermediateDirectories: true, attributes: nil)
                print("DatasetManager: Created dataset directory at: \(datasetDirectory.path)")
            } catch {
                print("DatasetManager: Error creating dataset directory: \(error.localizedDescription)")
            }
        }
    }

    /// Saves an image to the dataset directory and records its annotation metadata.
    /// This is an asynchronous operation as it involves file I/O.
    /// - Parameters:
    ///   - image: The `UIImage` object to be saved.
    ///   - label: The string label (annotation) to associate with the image.
    /// - Returns: The `AnnotatedImage` metadata object that was saved.
    /// - Throws: `DatasetError` if image conversion or file saving fails.
    @discardableResult
    func saveImageAndAnnotation(image: UIImage, label: String) async throws -> AnnotatedImage {
        // 1. Generate a unique filename for the image using a UUID.
        let imageUUID = UUID()
        let imageFileName = "\(imageUUID.uuidString).jpeg"
        let imageFileUrl = datasetDirectory.appendingPathComponent(imageFileName)

        // 2. Convert UIImage to Data (JPEG format). Compression quality 0.8 is a good balance.
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            throw DatasetError.imageConversionFailed
        }

        // 3. Save the image data to disk. `.atomicWrite` ensures data integrity.
        do {
            try imageData.write(to: imageFileUrl, options: [.atomicWrite])
            print("DatasetManager: Saved image to: \(imageFileUrl.lastPathComponent)")
        } catch {
            throw DatasetError.imageSaveFailed(error)
        }

        // 4. Create the `AnnotatedImage` metadata object.
        let newAnnotation = AnnotatedImage(id: imageUUID, imageFileName: imageFileName, annotationLabel: label)

        // 5. Load existing annotations, append the new one, and save the updated list back to disk.
        var allAnnotations = try await loadAnnotations() // Load existing
        allAnnotations.append(newAnnotation) // Add new

        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted // For human-readable JSON
            let data = try encoder.encode(allAnnotations)
            try data.write(to: annotationsFileUrl, options: [.atomicWrite])
            print("DatasetManager: Saved annotation metadata for: '\(newAnnotation.annotationLabel)'")
            return newAnnotation
        } catch {
            throw DatasetError.annotationSaveFailed(error)
        }
    }

    /// Loads all annotated image metadata from the annotations JSON file.
    /// This is an asynchronous operation.
    /// - Returns: An array of `AnnotatedImage` objects. Returns an empty array if the file doesn't exist.
    /// - Throws: `DatasetError` if loading or decoding the JSON fails.
    func loadAnnotations() async throws -> [AnnotatedImage] {
        // If the annotations file doesn't exist, it means there are no annotations yet.
        guard FileManager.default.fileExists(atPath: annotationsFileUrl.path) else {
            return []
        }

        do {
            let data = try Data(contentsOf: annotationsFileUrl)
            let decoder = JSONDecoder()
            let annotations = try decoder.decode([AnnotatedImage].self, from: data)
            return annotations
        } catch {
            throw DatasetError.annotationLoadFailed(error)
        }
    }

    /// Retrieves the full file URL for an image given its relative filename.
    /// - Parameter fileName: The `imageFileName` from an `AnnotatedImage` object.
    /// - Returns: The absolute `URL` pointing to the image file.
    func imageUrl(forFileName fileName: String) -> URL {
        return datasetDirectory.appendingPathComponent(fileName)
    }

    /// Deletes an image file and its corresponding annotation entry from the dataset.
    /// This is an asynchronous operation.
    /// - Parameter annotation: The `AnnotatedImage` object to delete.
    /// - Throws: `DatasetError` if file deletion or annotation manifest update fails.
    func deleteAnnotation(_ annotation: AnnotatedImage) async throws {
        // 1. Delete the actual image file from disk.
        let imagePath = imageUrl(forFileName: annotation.imageFileName)
        if FileManager.default.fileExists(atPath: imagePath.path) {
            do {
                try FileManager.default.removeItem(at: imagePath)
                print("DatasetManager: Deleted image file: \(imagePath.lastPathComponent)")
            } catch {
                throw DatasetError.imageDeleteFailed(error)
            }
        } else {
            print("DatasetManager: Image file not found for deletion: \(imagePath.lastPathComponent)")
        }

        // 2. Remove the annotation entry from the manifest and save the updated list.
        var allAnnotations = try await loadAnnotations()
        allAnnotations.removeAll { $0.id == annotation.id }

        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            let data = try encoder.encode(allAnnotations)
            try data.write(to: annotationsFileUrl, options: [.atomicWrite])
            print("DatasetManager: Removed annotation for '\(annotation.annotationLabel)' from manifest.")
        } catch {
            throw DatasetError.annotationSaveFailed(error) // Reusing error type for saving manifest
        }
    }

    /// Deletes the entire custom dataset directory and its contents.
    /// Use with extreme caution, as this will permanently remove all collected data.
    /// - Throws: `DatasetError` if the directory cannot be removed.
    func deleteAllDatasetFiles() async throws {
        guard FileManager.default.fileExists(atPath: datasetDirectory.path) else {
            print("DatasetManager: Dataset directory does not exist, nothing to delete.")
            return
        }
        do {
            try FileManager.default.removeItem(at: datasetDirectory)
            print("DatasetManager: Successfully deleted entire dataset directory: \(datasetDirectory.path)")
        } catch {
            throw DatasetError.datasetDirectoryDeletionFailed(error)
        }
        // Re-create the directory for future use if needed, or let the `init` handle it.
        createDatasetDirectoryIfNeeded()
    }
}

/// A simulator class that mimics the interaction of a UI-based app
/// with the `DatasetManager`. It runs on the main actor as it conceptually
/// represents UI-level operations.
@MainActor
class AnnotationAppSimulator {
    /// The shared instance of our dataset manager.
    let datasetManager = DatasetManager.shared

    /// Simulates the process of a user adding a new annotated image.
    /// In a real app, the `image` would come from a photo picker and the `label` from user input.
    /// - Parameters:
    ///   - image: A `UIImage` to be annotated.
    ///   - label: The annotation string for the image.
    func addNewAnnotatedImage(image: UIImage, label: String) async {
        print("\n--- AnnotationAppSimulator: Adding new annotated image ---")
        do {
            let newAnnotation = try await datasetManager.saveImageAndAnnotation(image: image, label: label)
            print("AnnotationAppSimulator: Successfully added annotation: '\(newAnnotation.annotationLabel)' for image \(newAnnotation.imageFileName)")
        } catch {
            print("AnnotationAppSimulator: Error adding annotation: \(error.localizedDescription)")
        }
    }

    /// Simulates displaying a list of all current annotations to the user.
    func listAllAnnotations() async {
        print("\n--- AnnotationAppSimulator: Listing all annotations ---")
        do {
            let annotations = try await datasetManager.loadAnnotations()
            if annotations.isEmpty {
                print("AnnotationAppSimulator: No annotations found.")
            } else {
                print("AnnotationAppSimulator: Found \(annotations.count) annotations:")
                for annotation in annotations {
                    print("- ID: \(annotation.id.uuidString.prefix(8))... Label: '\(annotation.annotationLabel)', File: '\(annotation.imageFileName)'")
                }
            }
        } catch {
            print("AnnotationAppSimulator: Error loading annotations: \(error.localizedDescription)")
        }
    }

    /// Simulates a user deleting the first annotation found in the dataset.
    func deleteFirstAnnotation() async {
        print("\n--- AnnotationAppSimulator: Deleting first annotation ---")
        do {
            let annotations = try await datasetManager.loadAnnotations()
            guard let firstAnnotation = annotations.first else {
                print("AnnotationAppSimulator: No annotations to delete.")
                return
            }
            print("AnnotationAppSimulator: Attempting to delete annotation: '\(firstAnnotation.annotationLabel)' (File: \(firstAnnotation.imageFileName))")
            try await datasetManager.deleteAnnotation(firstAnnotation)
            print("AnnotationAppSimulator: Successfully deleted annotation and its image.")
        } catch {
            print("AnnotationAppSimulator: Error deleting annotation: \(error.localizedDescription)")
        }
    }

    /// Simulates a user clearing the entire dataset.
    func clearDataset() async {
        print("\n--- AnnotationAppSimulator: Clearing entire dataset ---")
        do {
            try await datasetManager.deleteAllDatasetFiles()
            print("AnnotationAppSimulator: Dataset cleared successfully.")
        } catch {
            print("AnnotationAppSimulator: Error clearing dataset: \(error.localizedDescription)")
        }
    }
}

// MARK: - Main Execution Block
/// The entry point for the simulated application.
/// `@main` is used to define the app's starting point, and `async` indicates
/// that the main function can perform asynchronous operations.
/// `@available(iOS 18.0, *)` is used here to align with the latest SDK context,
/// though `@main async` is available from iOS 15.0.
@main
@available(iOS 18.0, *)
struct BasicAnnotationApp {
    static func main() async {
        let simulator = AnnotationAppSimulator()

        // Optional: Clear previous runs for a clean start during development/testing.
        // Uncomment the line below to clear the dataset every time the app runs.
        // await simulator.clearDataset()

        // 1. Add some initial annotated images to our dataset.
        // We use placeholder UIImages (system icons) for demonstration purposes.
        // In a real app, these would be actual photos or images selected by the user.
        print("\n>>> STEP 1: Adding initial annotated images <<<")
        let image1 = UIImage(systemName: "photo")!.withTintColor(.red, renderingMode: .alwaysOriginal)
        let image2 = UIImage(systemName: "photo")!.withTintColor(.blue, renderingMode: .alwaysOriginal)
        let image3 = UIImage(systemName: "photo")!.withTintColor(.green, renderingMode: .alwaysOriginal)
        let image4 = UIImage(systemName: "star.fill")!.withTintColor(.yellow, renderingMode: .alwaysOriginal)

        await simulator.addNewAnnotatedImage(image: image1, label: "RedObject")
        await simulator.addNewAnnotatedImage(image: image2, label: "BlueObject")
        await simulator.addNewAnnotatedImage(image: image3, label: "GreenObject")
        await simulator.addNewAnnotatedImage(image: image4, label: "Star")

        // 2. List all annotations currently in the dataset.
        print("\n>>> STEP 2: Listing all current annotations <<<")
        await simulator.listAllAnnotations()

        // 3. Add another image to demonstrate dataset growth.
        print("\n>>> STEP 3: Adding another image <<<")
        let image5 = UIImage(systemName: "heart.fill")!.withTintColor(.purple, renderingMode: .alwaysOriginal)
        await simulator.addNewAnnotatedImage(image: image5, label: "Heart")

        // 4. List again to confirm the new addition.
        print("\n>>> STEP 4: Listing annotations after new addition <<<")
        await simulator.listAllAnnotations()

        // 5. Delete one annotation from the dataset.
        print("\n>>> STEP 5: Deleting the first annotation <<<")
        await simulator.deleteFirstAnnotation()

        // 6. List one last time to confirm the deletion.
        print("\n>>> STEP 6: Listing annotations after deletion <<<")
        await simulator.listAllAnnotations()

        // Optional: Clean up the dataset entirely at the end of the run.
        // This is useful for ensuring a fresh state for subsequent runs during development.
        // await simulator.clearDataset()

        print("\n--- Simulation Complete ---")
    }
}
