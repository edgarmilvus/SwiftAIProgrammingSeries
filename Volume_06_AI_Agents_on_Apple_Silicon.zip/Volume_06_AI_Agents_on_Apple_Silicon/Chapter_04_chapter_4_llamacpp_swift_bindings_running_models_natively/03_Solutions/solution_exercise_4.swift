
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import AppKit
import Foundation
import Combine // For debouncing

// Assume LlamaKit bindings (LlamaModel, LlamaContext, LlamaModelParams, LlamaContextParams, LlamaError)
// as defined in Exercise 1 are available in the project.
// For this solution, the mock LlamaKit definitions from Exercise 1 are implicitly included.

// MARK: - Code Completion Manager (ViewModel)

@MainActor
class CodeCompletionManager: ObservableObject {
    private var llamaModel: LlamaModel?
    private var llamaContext: LlamaContext?
    private let modelPath: String // Path to the GGUF model
    
    @Published var editorContent: String = "" // The actual code in the editor
    @Published var completionSuggestion: String = "" // The ghost text suggestion
    @Published var isGenerating: Bool = false
    @Published var errorMessage: String?

    private var currentCompletionTask: Task<Void, Never>? // For cancellation
    private let maxCompletionTokens = 50 // Max tokens for a single completion
    private let contextWindowSize: UInt32 = 2048 // Context window size for code models
    private let debounceInterval: TimeInterval = 0.7 // Seconds to wait after last keystroke

    init(modelPath: String) {
        self.modelPath = modelPath
    }

    func loadModelAndContext() async {
        isGenerating = true // Indicate loading state
        errorMessage = nil
        completionSuggestion = ""
        
        do {
            // 2. Code-Specific LLM Loading
            llamaModel = LlamaModel(path: modelPath)
            try llamaModel?.load() // Load a "code-specific" model

            guard let model = llamaModel else {
                throw LlamaError.generalError("Failed to initialize LlamaModel.")
            }

            // Context initialization with code-specific params (e.g., larger context)
            var contextParams = LlamaContextParams()
            contextParams.n_ctx = contextWindowSize
            contextParams.n_threads = 8 // More threads for potentially faster code generation
            contextParams.temp = 0.2 // Lower temperature for more deterministic/logical code
            contextParams.top_p = 0.95
            contextParams.repeat_penalty = 1.0 // Less penalty for code, which can be repetitive
            llamaContext = try LlamaContext(model: model, params: contextParams)
            
            editorContent = "Model for code completion loaded. Start typing Swift code!\n"
            print("CodeCompletionManager: Code model and context ready.")
        } catch {
            errorMessage = error.localizedDescription
            editorContent = "Error: \(error.localizedDescription)\n"
            print("CodeCompletionManager: Error loading code model/context: \(error.localizedDescription)")
        }
        isGenerating = false
    }

    // Function to request code completion based on current editor content
    func requestCodeCompletion(currentCursorPosition: Int) async {
        guard let model = llamaModel, let context = llamaContext, !isGenerating else { return }

        // Cancel any previous completion task to ensure only the latest request is processed
        currentCompletionTask?.cancel()
        currentCompletionTask = nil
        completionSuggestion = "" // Clear previous suggestion

        // 4. Contextual Prompting
        let currentCodePrefix = String(editorContent.prefix(currentCursorPosition))
        guard !currentCodePrefix.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        // For code models, a common prompt template is to provide the prefix and let it complete.
        // Some models support fill-in-the-middle (FIM) like <fim_prefix> CODE <fim_suffix> CODE <fim_middle>
        // For this mock, we'll use a simple prefix completion.
        let prompt = currentCodePrefix
        print("CodeCompletionManager: Requesting completion for prompt: '\(prompt)'")

        currentCompletionTask = Task { @MainActor in
            isGenerating = true
            errorMessage = nil

            do {
                try context.reset() // Reset context for fresh inference
                let promptTokens = model.tokenize(text: prompt, addBos: true)
                try context.feedPrompt(tokens: promptTokens)

                var generatedCompletion = ""
                for _ in 0..<maxCompletionTokens {
                    try Task.checkCancellation() // Critical for responsiveness

                    let nextToken = context.sampleNextToken()

                    if nextToken == model.getEosToken() || nextToken == model.getNewlineToken() {
                        // Stop at EOS or newline for single-line/block completion
                        print("CodeCompletionManager: [EOS] or [Newline] detected, stopping completion.")
                        break
                    }
                    if nextToken == -1 {
                        throw LlamaError.inferenceFailed("Invalid token generated.")
                    }

                    let newText = model.detokenize(tokens: [nextToken])
                    // Filter out non-code characters or unwanted tokens if necessary
                    if newText.contains(where: { $0.isWhitespace || $0.isNewline || $0.isASCII }) { // Simple filter
                        generatedCompletion += newText
                    } else {
                        // Stop if model generates non-code like tokens
                        break
                    }
                    
                    // Simulate latency for token generation
                    try await Task.sleep(seconds: 0.005)
                }
                
                // Only set suggestion if it's not empty and task wasn't cancelled
                if !Task.isCancelled && !generatedCompletion.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    completionSuggestion = generatedCompletion.trimmingCharacters(in: .whitespacesAndNewlines)
                    print("CodeCompletionManager: Generated completion: '\(completionSuggestion)'")
                } else {
                    completionSuggestion = ""
                }

            } catch is LlamaError {
                errorMessage = "LLM Error: \(error.localizedDescription)"
                print("CodeCompletionManager: LLM error during completion: \(error.localizedDescription)")
                completionSuggestion = ""
            } catch is CancellationError {
                print("CodeCompletionManager: Completion task cancelled.")
                completionSuggestion = ""
            } catch {
                errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                print("CodeCompletionManager: Unexpected error during completion: \(error.localizedDescription)")
                completionSuggestion = ""
            }
            isGenerating = false
        }
    }
    
    // Call this when editor content changes to cancel ongoing tasks
    func cancelCompletion() {
        currentCompletionTask?.cancel()
        currentCompletionTask = nil
        completionSuggestion = ""
        isGenerating = false
    }
    
    deinit {
        print("CodeCompletionManager: Deallocating.")
        currentCompletionTask?.cancel()
        llamaContext = nil
        llamaModel = nil
    }
}

// MARK: - macOS AppKit UI (Mock Editor)

class CodeEditorViewController: NSViewController, NSTextViewDelegate {
    var codeTextView: NSTextView!
    var scrollView: NSScrollView!
    
    private let manager: CodeCompletionManager
    private var textDidChangeSubject = PassthroughSubject<Void, Never>()
    private var cancellables = Set<AnyCancellable>()
    
    // Store the suggestion range to manage ghost text
    private var suggestionRange: NSRange?

    init(manager: CodeCompletionManager) {
        self.manager = manager
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        // IMPORTANT: Replace with the actual path to your .gguf model file.
        // For this mock, a dummy file will be created/used at this path.
        let modelFileName = "dummy_code_model.gguf"
        let modelPath = FileManager.default.temporaryDirectory.appendingPathComponent(modelFileName).path
        self.manager = CodeCompletionManager(modelPath: modelPath)
        super.init(coder: coder)
    }

    override func loadView() {
        self.view = NSView(frame: NSRect(x: 0, y: 0, width: 800, height: 600))
        self.view.autoresizesSubviews = true
        setupUI()
        bindViewModel()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup debouncing for completion requests
        textDidChangeSubject
            .debounce(for: .seconds(manager.debounceInterval), scheduler: DispatchQueue.main)
            .sink { [weak self] _ in
                guard let self = self else { return }
                self.manager.requestCodeCompletion(currentCursorPosition: self.codeTextView.selectedRange().location)
            }
            .store(in: &cancellables)
        
        // Load model on startup
        Task {
            await manager.loadModelAndContext()
        }
    }

    private func setupUI() {
        let contentView = self.view
        
        scrollView = NSScrollView()
        scrollView.hasVerticalScroller = true
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(scrollView)

        codeTextView = NSTextView()
        codeTextView.isEditable = true
        codeTextView.isSelectable = true
        codeTextView.textContainerInset = NSSize(width: 10, height: 10)
        codeTextView.font = NSFont.monospacedSystemFont(ofSize: 14, weight: .regular)
        codeTextView.delegate = self
        codeTextView.string = manager.editorContent // Initial content
        
        // Custom key event handling for Tab/Escape
        // This is a simplified approach; a real IDE would use a custom NSTextView subclass
        // or more robust event monitoring.
        codeTextView.fieldEditor?.delegate = self // Make the text view itself the delegate for field editor key events
        
        scrollView.documentView = codeTextView
        
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            scrollView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            scrollView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            scrollView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20)
        ])
    }

    private func bindViewModel() {
        manager.$editorContent
            .receive(on: DispatchQueue.main)
            .sink { [weak self] newContent in
                // Only update if the content actually changed, to avoid recursion
                if self?.codeTextView.string != newContent {
                    self?.codeTextView.string = newContent
                }
                self?.codeTextView.scrollToEndOfDocument(nil)
            }
            .store(in: &cancellables)
        
        manager.$completionSuggestion
            .receive(on: DispatchQueue.main)
            .sink { [weak self] suggestion in
                self?.displaySuggestion(suggestion)
            }
            .store(in: &cancellables)
        
        manager.$errorMessage
            .receive(on: DispatchQueue.main)
            .sink { [weak self] message in
                if let msg = message {
                    let alert = NSAlert()
                    alert.messageText = "Error"
                    alert.informativeText = msg
                    alert.alertStyle = .critical
                    alert.runModal()
                }
            }
            .store(in: &cancellables)
        
        manager.$isGenerating
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isGenerating in
                // Optional: Show a spinner or status bar message
                print("Completion status: \(isGenerating ? "Generating..." : "Idle")")
            }
            .store(in: &cancellables)
    }

    // MARK: - NSTextViewDelegate Methods
    
    // 3. Input Monitoring and Debouncing
    func textDidChange(_ notification: Notification) {
        // Update manager's editorContent
        manager.editorContent = codeTextView.string
        
        // Clear any existing ghost text immediately
        clearSuggestion()
        
        // Cancel any ongoing completion task immediately
        manager.cancelCompletion()
        
        // Emit event for debounced completion request
        textDidChangeSubject.send(())
    }
    
    // Handle key presses for accepting/dismissing suggestions
    func textView(_ textView: NSTextView, doCommandBy commandSelector: Selector) -> Bool {
        if commandSelector == #selector(NSResponder.insertTab(_:)) {
            // User pressed Tab
            if !manager.completionSuggestion.isEmpty {
                acceptSuggestion()
                return true // Handled
            }
        } else if commandSelector == #selector(NSResponder.cancelOperation(_:)) {
            // User pressed Escape
            if !manager.completionSuggestion.isEmpty {
                dismissSuggestion()
                return true // Handled
            }
        }
        // For other commands, let the text view handle them
        return false
    }

    // MARK: - Suggestion Display
    
    private func displaySuggestion(_ suggestion: String) {
        clearSuggestion() // Clear any old suggestion first

        guard !suggestion.isEmpty,
              let textStorage = codeTextView.textStorage else { return }

        let cursorLocation = codeTextView.selectedRange().location
        let insertionRange = NSRange(location: cursorLocation, length: 0)
        
        // This is a simplified "ghost text" display.
        // A real implementation might use a custom text layout manager or overlay view.
        // Here, we insert the text with a specific attribute and then remove it.
        let ghostAttributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: NSColor.systemGray,
            .font: NSFont.monospacedSystemFont(ofSize: 14, weight: .regular)
        ]
        
        let attributedSuggestion = NSAttributedString(string: suggestion, attributes: ghostAttributes)
        
        // Temporarily insert the suggestion
        textStorage.insert(attributedSuggestion, at: insertionRange.location)
        suggestionRange = NSRange(location: insertionRange.location, length: attributedSuggestion.length)
        
        // Adjust cursor position to be before the ghost text
        codeTextView.setSelectedRange(insertionRange)
    }
    
    private func clearSuggestion() {
        guard let range = suggestionRange,
              let textStorage = codeTextView.textStorage else { return }
        
        // Check if the range is still valid and corresponds to our suggestion
        if range.location + range.length <= textStorage.length {
            textStorage.deleteCharacters(in: range)
        }
        suggestionRange = nil
    }

    // MARK: - Accept/Dismiss Mechanism
    
    func acceptSuggestion() {
        guard let suggestion = manager.completionSuggestion, !suggestion.isEmpty,
              let range = suggestionRange,
              let textStorage = codeTextView.textStorage else { return }
        
        // Remove ghost text attributes, insert as regular text
        textStorage.deleteCharacters(in: range) // Remove the ghost text
        let regularSuggestion = NSAttributedString(string: suggestion, attributes: [.font: codeTextView.font!])
        textStorage.insert(regularSuggestion, at: range.location) // Insert as regular text
        
        let newCursorLocation = range.location + regularSuggestion.length
        codeTextView.setSelectedRange(NSRange(location: newCursorLocation, length: 0))
        
        // Update manager's content and clear suggestion state
        manager.editorContent = codeTextView.string
        manager.completionSuggestion = ""
        suggestionRange = nil
        
        // Trigger a new debounced completion request if needed, as content changed
        textDidChangeSubject.send(())
    }

    func dismissSuggestion() {
        clearSuggestion()
        manager.completionSuggestion = "" // Clear the manager's state
    }
}

// MARK: - App Delegate for macOS

@main
class AppDelegate: NSObject, NSApplicationDelegate {
    var window: NSWindow!
    var viewController: CodeEditorViewController!

    func applicationDidFinishLaunching(_ notification: Notification) {
        let modelFileName = "dummy_code_model.gguf"
        let modelPath = FileManager.default.temporaryDirectory.appendingPathComponent(modelFileName).path
        let manager = CodeCompletionManager(modelPath: modelPath)
        
        viewController = CodeEditorViewController(manager: manager)
        
        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 800, height: 600),
            styleMask: [.titled, .closable, .resizable, .miniaturizable],
            backing: .buffered,
            defer: false
        )
        window.center()
        window.title = "SwiftGenius Code Completion"
        window.contentViewController = viewController
        window.makeKeyAndOrderFront(nil)
        
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
    }
    
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }
}
