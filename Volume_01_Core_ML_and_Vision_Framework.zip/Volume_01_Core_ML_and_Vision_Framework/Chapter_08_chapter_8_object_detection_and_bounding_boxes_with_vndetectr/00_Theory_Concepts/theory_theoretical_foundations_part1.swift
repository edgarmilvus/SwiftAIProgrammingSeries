
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
extension VNImageRequestHandler {
    /// Performs Vision requests asynchronously.
    /// - Parameter requests: An array of VNRequest objects to perform.
    /// - Returns: An array of VNObservation results from the requests.
    func performAsync(_ requests: [VNRequest]) async throws -> [VNObservation] {
        // The actual perform call is synchronous from the perspective of this task.
        // By calling it within an async context, we ensure the caller's thread
        // (e.g., MainActor) is not blocked.
        try self.perform(requests)

        // Collect all results from the requests.
        let allObservations = requests.compactMap { $0.results }.flatMap { $0 }
        return allObservations
    }
}

@available(iOS 18.0, *)
class ImageProcessor {
    func processImageForRectangles(imageBuffer: CVPixelBuffer) async throws -> [VNRectangleObservation] {
        let handler = VNImageRequestHandler(cvPixelBuffer: imageBuffer)
        let request = VNDetectRectanglesRequest()
        request.quadratureTolerance = 10.0 // Example parameter

        // Call the async extension method
        let observations = try await handler.performAsync([request])

        // Filter and cast to the specific observation type
        guard let rectangleObservations = observations as? [VNRectangleObservation] else {
            return []
        }
        return rectangleObservations
    }
}
