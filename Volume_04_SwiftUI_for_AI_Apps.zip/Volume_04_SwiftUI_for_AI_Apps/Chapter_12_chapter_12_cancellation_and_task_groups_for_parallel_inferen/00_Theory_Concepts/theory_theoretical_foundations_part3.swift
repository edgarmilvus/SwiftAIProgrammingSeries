
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation // For Data

@available(iOS 18.0, *)
actor InferenceCoordinator {
    private var modelCache: [String: Data] = [:] // Simulate cached model data

    func loadModelData(for modelID: String) async throws -> Data {
        if let cachedData = modelCache[modelID] {
            print("Using cached data for model \(modelID)")
            return cachedData
        }

        print("Loading model data for \(modelID) from network...")
        // Simulate network request
        try await Task.sleep(for: .seconds(1))
        let data = Data(modelID.utf8) // Placeholder data
        modelCache[modelID] = data
        return data
    }

    // Simulate an inference operation that depends on model data
    func performInference(modelData: Data, input: String) async throws -> String {
        print("Performing inference with model data '\(String(data: modelData, encoding: .utf8) ?? "")' for input: '\(input)'")
        try await Task.sleep(for: .milliseconds(500)) // Simulate inference time
        try Task.checkCancellation()
        return "Result for '\(input)' using model '\(String(data: modelData, encoding: .utf8) ?? "")'"
    }
}

@available(iOS 18.0, *)
func parallelInferenceExample(coordinator: InferenceCoordinator) async throws -> [String] {
    let inputs = ["prompt1", "prompt2", "prompt3", "prompt4"]
    let modelIDs = ["modelA", "modelB", "modelA", "modelC"] // Some models are reused

    print("Starting parallel inference for \(inputs.count) inputs...")

    return try await withTaskGroup(of: String.self) { group in
        var results: [String] = []

        for (index, input) in inputs.enumerated() {
            let modelID = modelIDs[index]

            group.addTask {
                // Load model data (potentially in parallel with other tasks)
                let modelData = try await coordinator.loadModelData(for: modelID)

                // Perform inference
                let result = try await coordinator.performInference(modelData: modelData, input: input)
                print("Completed inference for input '\(input)'")
                return result
            }
        }

        // Collect results as they complete
        for await result in group {
            results.append(result)
        }
        
        print("All parallel inferences completed. Total results: \(results.count)")
        return results.sorted() // Sort for consistent output order
    }
}
