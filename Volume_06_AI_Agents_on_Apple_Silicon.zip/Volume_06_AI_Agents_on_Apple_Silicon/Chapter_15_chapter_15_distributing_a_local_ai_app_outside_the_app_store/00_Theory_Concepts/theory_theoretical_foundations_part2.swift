
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    // Package.swift snippet for a Swift Package Manager dependency
    // that wraps llama.cpp
    // This demonstrates how a custom binding might be structured.
    import PackageDescription

    let package = Package(
        name: "MyLocalLLMApp",
        platforms: [.macOS(.v13)], // Or appropriate version for llama.cpp
        products: [
            .executable(name: "MyLocalLLMApp", targets: ["MyLocalLLMApp"]),
        ],
        dependencies: [
            // Assuming 'LlamaKit' is a Swift package that provides Swift bindings
            // to llama.cpp, potentially including pre-compiled binaries or
            // building llama.cpp from source.
            .package(url: "https://github.com/my-org/LlamaKit.git", from: "1.0.0"),
            // Or a local path for development:
            // .package(path: "../LlamaKit")
        ],
        targets: [
            .executableTarget(
                name: "MyLocalLLMApp",
                dependencies: ["LlamaKit"]
            )
        ]
    )
    