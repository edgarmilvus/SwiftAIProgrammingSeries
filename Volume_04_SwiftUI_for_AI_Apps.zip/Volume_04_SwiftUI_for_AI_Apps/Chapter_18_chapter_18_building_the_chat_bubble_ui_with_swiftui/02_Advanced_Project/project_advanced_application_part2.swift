
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import Foundation

/// Represents a suggestion for an AI tool call.
/// This structure holds all necessary information to display and potentially execute a tool call.
struct ToolCallSuggestion: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let description: String
    let parameters: [String: String] // Example: ["location": "Cupertino", "unit": "celsius"]
    
    static let exampleWeather = ToolCallSuggestion(
        name: "get_weather",
        description: "Fetch current weather conditions for a location.",
        parameters: ["location": "Cupertino", "unit": "celsius"]
    )
    
    static let exampleGenerateImage = ToolCallSuggestion(
        name: "generate_image",
        description: "Create an image based on a textual prompt.",
        parameters: ["prompt": "A cat wearing a wizard hat, digital art"]
    )
}

/// Defines the various types of content that can appear within a single chat bubble.
/// This allows for rich, mixed-content messages, crucial for advanced AI interactions.
enum MessageContent: Identifiable, Hashable {
    case text(String)
    case toolCallSuggestion(ToolCallSuggestion)
    
    var id: UUID {
        switch self {
        case .text(_): return UUID() // Unique ID for each text block
        case .toolCallSuggestion(let suggestion): return suggestion.id
        }
    }
}
