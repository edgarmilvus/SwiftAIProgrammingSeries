
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import NaturalLanguage // Don't forget to import NaturalLanguage

@available(iOS 18.0, *) // NLLanguageRecognizer is available on older OS versions, but we're demonstrating modern Swift features.
class LanguageDetector {
    // The NLLanguageRecognizer can be reused for multiple detections.
    // It's not thread-safe for concurrent modification, but safe for concurrent *reads* or sequential use.
    // For concurrent writes/modifications (e.g., processString(_:)), an Actor is ideal.
    private let recognizer = NLLanguageRecognizer()

    /// Asynchronously detects the primary language of a given text.
    /// - Parameter text: The string to analyze.
    /// - Returns: The most likely NLLanguage, or nil if no language could be determined.
    func detectLanguage(for text: String) async -> NLLanguage? {
        return await Task.detached { [self] in // Offload to a background thread
            self.recognizer.processString(text)
            return self.recognizer.dominantLanguage
        }.value
    }

    /// Asynchronously detects all likely languages and their confidence scores.
    /// - Parameter text: The string to analyze.
    /// - Parameter maxHypotheses: The maximum number of language hypotheses to return.
    /// - Returns: A dictionary mapping NLLanguage to its confidence score.
    func detectAllLanguages(for text: String, maxHypotheses: Int = 3) async -> [NLLanguage: Double] {
        return await Task.detached { [self] in
            // Reset the recognizer for a fresh analysis if it was used incrementally before.
            // For a single string, processString(_:) implicitly resets.
            self.recognizer.reset()
            self.recognizer.processString(text)
            return self.recognizer.hypotheses(withMaximum: maxHypotheses)
        }.value
    }
}

// Example Usage in a SwiftUI View or ViewModel
@available(iOS 18.0, *)
func demonstrateAsyncDetection() async {
    let detector = LanguageDetector()
    let text = "Hello, world! Bonjour le monde! Hola mundo!"

    if let dominantLanguage = await detector.detectLanguage(for: text) {
        print("Dominant language: \(dominantLanguage.rawValue)")
    }

    let allLanguages = await detector.detectAllLanguages(for: text)
    print("All detected languages:")
    for (language, confidence) in allLanguages {
        print("- \(language.rawValue): \(String(format: "%.2f", confidence * 100))%")
    }
}
