
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import NaturalLanguage

@available(iOS 18.0, *)
@Observable
class TokenizationViewModel {
    var inputText: String = "" {
        didSet {
            // Trigger tokenization whenever inputText changes
            Task { await tokenizeCurrentText() }
        }
    }
    var wordTokens: [String] = []
    var sentenceTokens: [String] = []

    private let tokenizer = NLTokenizer(unit: .word) // Can be reused for same unit

    init() {
        // Initial tokenization if default text is set
        Task { await tokenizeCurrentText() }
    }

    @MainActor // Ensure UI updates are on the main actor
    func tokenizeCurrentText() async {
        guard !inputText.isEmpty else {
            wordTokens = []
            sentenceTokens = []
            return
        }

        // Offload heavy work to a background task
        let (newWordTokens, newSentenceTokens) = await Task.detached { [inputText] in
            let wordTokenizer = NLTokenizer(unit: .word)
            wordTokenizer.string = inputText
            var words: [String] = []
            wordTokenizer.enumerateTokens(in: inputText.startIndex..<inputText.endIndex) { tokenRange, _ in
                words.append(String(inputText[tokenRange]))
                return true
            }

            let sentenceTokenizer = NLTokenizer(unit: .sentence)
            sentenceTokenizer.string = inputText
            var sentences: [String] = []
            sentenceTokenizer.enumerateTokens(in: inputText.startIndex..<inputText.endIndex) { tokenRange, _ in
                sentences.append(String(inputText[tokenRange]))
                return true
            }
            return (words, sentences)
        }.value

        self.wordTokens = newWordTokens
        self.sentenceTokens = newSentenceTokens
    }
}

@available(iOS 18.0, *)
struct TokenizationView: View {
    @State private var viewModel = TokenizationViewModel()

    var body: some View {
        VStack {
            TextField("Enter text here", text: $viewModel.inputText)
                .textFieldStyle(.roundedBorder)
                .padding()

            Text("Words (\(viewModel.wordTokens.count)):")
                .font(.headline)
            ScrollView {
                Text(viewModel.wordTokens.joined(separator: " | "))
                    .padding(.horizontal)
            }

            Text("Sentences (\(viewModel.sentenceTokens.count)):")
                .font(.headline)
                .padding(.top)
            ScrollView {
                Text(viewModel.sentenceTokens.joined(separator: "\n"))
                    .padding(.horizontal)
            }
            Spacer()
        }
        .navigationTitle("NLTokenizer Demo")
    }
}
