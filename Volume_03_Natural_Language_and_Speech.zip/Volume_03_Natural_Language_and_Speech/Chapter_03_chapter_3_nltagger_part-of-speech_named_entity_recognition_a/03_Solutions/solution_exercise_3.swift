
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 11.0, macOS 10.13, tvOS 11.0, watchOS 4.0, *)
struct ParsedCalendarEvent {
    var title: String?
    var attendees: [String] = []
    var location: [String] = []
    var dateTime: [String] = []
}

// Helper extension to check for range intersection
extension Range where Bound == String.Index {
    func intersects(with other: Range<String.Index>) -> Bool {
        return self.lowerBound < other.upperBound && self.upperBound > other.lowerBound
    }
}

@available(iOS 11.0, macOS 10.13, tvOS 11.0, watchOS 4.0, *)
func parseEventDetails(from naturalLanguageString: String) -> ParsedCalendarEvent {
    var event = ParsedCalendarEvent()
    
    // Use Sets to automatically handle uniqueness for entities
    var uniqueAttendees: Set<String> = []
    var uniqueLocation: Set<String> = []
    var uniqueDateTime: Set<String> = []
    
    // Keep track of ranges covered by identified entities to exclude them from the title
    var entityRanges: [Range<String.Index>] = []
    
    let tagger = NLTagger(tagSchemes: [.nameType, .lexicalClass, .lemma])
    tagger.string = naturalLanguageString
    
    let fullRange = naturalLanguageString.startIndex..<naturalLanguageString.endIndex
    
    // MARK: - Pass 1: Extract Named Entities (Person, Place, Organization, Date, Time)
    tagger.enumerateTags(in: fullRange, unit: .word, scheme: .nameType, options: [.omitWhitespace, .omitPunctuation, .joinNames]) { tag, range in
        if let tag = tag, let tokenRange = Range(range, in: naturalLanguageString) {
            let entityString = String(naturalLanguageString[tokenRange])
            
            switch tag {
            case .person:
                uniqueAttendees.insert(entityString)
                entityRanges.append(tokenRange)
            case .place:
                uniqueLocation.insert(entityString)
                entityRanges.append(tokenRange)
            case .organization: // Organizations can also function as locations
                uniqueLocation.insert(entityString)
                entityRanges.append(tokenRange)
            case .date, .time:
                uniqueDateTime.insert(entityString)
                entityRanges.append(tokenRange)
            default:
                break
            }
        }
        return true
    }
    
    // Sort and convert sets to arrays for the event struct
    event.attendees = uniqueAttendees.sorted()
    event.location = uniqueLocation.sorted()
    event.dateTime = uniqueDateTime.sorted()
    
    // MARK: - Pass 2: Extract Title (Lemmatized non-entities, non-stop-words)
    let stopWords: Set<String> = ["a", "an", "the", "is", "are", "was", "were", "and", "or", "but", "for", "nor", "so", "yet", "at", "by", "in", "of", "on", "to", "with", "from", "into", "during", "through", "above", "below", "up", "down", "out", "off", "over", "under", "again", "further", "then", "once", "here", "there", "when", "where", "why", "how", "all", "any", "both", "each", "few", "more", "most", "other", "some", "such", "no", "not", "only", "own", "same", "so", "than", "too", "very", "s", "t", "can", "will", "just", "don", "should", "now", "about", "this", "that", "it", "he", "she", "we", "they", "i", "you", "me", "him", "her", "us", "them", "my", "your", "his", "her", "its", "our", "their", "what", "which", "who", "whom", "whose", "if", "because", "as", "until", "while", "though", "although", "since", "before", "after", "while", "where", "when", "why", "how", "however", "therefore", "thus", "consequently", "meanwhile", "next"]
    
    var titleWords: [String] = []
    
    tagger.enumerateTags(in: fullRange, unit: .word, scheme: .lexicalClass, options: [.omitWhitespace, .omitPunctuation]) { lexicalClassTag, tokenRange, stop in
        guard let lexicalClassTag = lexicalClassTag,
              let tokenRange = tokenRange else { return true }
        
        // Check if this token's range overlaps with any identified entity range
        let isEntityWord = entityRanges.contains { entityRange in
            return tokenRange.intersects(with: entityRange)
        }
        
        if !isEntityWord {
            // Only consider nouns, verbs, and adjectives for the title
            if lexicalClassTag == .noun || lexicalClassTag == .verb || lexicalClassTag == .adjective {
                // Get the lemma for the token
                let lemmaTag = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .lemma)?.0
                if let lemma = lemmaTag?.rawValue.lowercased(), !stopWords.contains(lemma) {
                    titleWords.append(lemma)
                }
            }
        }
        return true
    }
    
    // Join title words, capitalize the first letter for a cleaner title
    if !titleWords.isEmpty {
        let titleString = titleWords.joined(separator: " ")
        event.title = titleString.prefix(1).uppercased() + titleString.dropFirst()
    }
    
    return event
}
