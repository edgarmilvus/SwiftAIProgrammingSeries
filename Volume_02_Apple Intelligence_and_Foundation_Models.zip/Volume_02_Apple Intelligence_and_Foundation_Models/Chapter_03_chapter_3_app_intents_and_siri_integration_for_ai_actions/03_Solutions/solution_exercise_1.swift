
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import AppIntents
import Foundation

@available(iOS 18.0, macOS 15.0, *)
struct CreateNoteIntent: AppIntent {
    static var title: LocalizedStringResource = "Create Note"
    static var description: IntentDescription = "Creates a new note with a specified title and optional content."

    @Parameter(title: "Note Title", description: "The title for the new note.")
    var title: String

    @Parameter(title: "Note Content", description: "The main content of the note.", default: "")
    var content: String?

    init() {} // Required initializer for AppIntent
    init(title: String, content: String?) {
        self.title = title
        self.content = content
    }

    func perform() async throws -> some IntentResult {
        // In a real application, this is where you would save the note
        // to a persistent data store (e.g., Core Data, Realm, CloudKit).
        print("Creating note: '\(title)' with content: '\(content ?? "No content")'")

        // Return a dialog result to confirm the action to the user.
        return .result(dialog: "Note '\(title)' created successfully.")
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct QuickNotesAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: CreateNoteIntent(), // Provide a default intent instance for the shortcut template
            phrases: [
                "Create a new note in \(.applicationName)",
                "Jot down \(.applicationName) \(.parameter(\.$title))",
                "Make a \(.applicationName) note about \(.parameter(\.$title))"
            ],
            shortTitle: "Create Note",
            systemImageName: "note.text.badge.plus"
        )
    }
}
