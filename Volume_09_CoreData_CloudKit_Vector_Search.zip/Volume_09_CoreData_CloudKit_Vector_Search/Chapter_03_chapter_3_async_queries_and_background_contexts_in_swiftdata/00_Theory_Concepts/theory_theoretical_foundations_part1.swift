
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import SwiftData
import Observation

/// An error type specific to our AI Ingestion process.
enum IngestionError: Error {
    case modelFailure
    case persistenceFailure
}

/// The IngestionActor is a specialized ModelActor designed to handle 
/// the heavy computational load of turning text into semantic memory.
/// It is isolated from the MainActor to prevent UI hangs.
@available(iOS 18.0, *)
@ModelActor
actor SemanticIngestionActor {
    
    /// Processes a large block of text by chunking it and generating embeddings.
    /// - Parameter text: The raw string content to be ingested.
    /// - Returns: An array of PersistentIdentifiers representing the newly created chunks.
    /// This allows the caller to know which objects were created without 
    /// violating Sendable constraints.
    func ingest(text: String) async throws -> [PersistentIdentifier] {
        // 1. Simulate heavy text chunking logic
        let chunks = text.components(separatedBy: "\n\n") // Simplified chunking
        var createdIDs: [PersistentIdentifier] = []
        
        for chunk in chunks {
            // 2. Simulate Core ML Embedding Generation
            // In a real app, this would call a Core ML model.
            let vector = try await generateEmbedding(for: chunk)
            
            // 3. Create the model within the Actor's private context
            let newChunk = SemanticChunk(text: chunk, embedding: vector)
            modelContext.insert(newChunk)
            
            // 4. Track the ID for safe transfer back to the MainActor
            createdIDs.append(newChunk.persistentModelID)
        }
        
        // 5. Persist the changes to the ModelContainer
        try modelContext.save()
        
        return createdIDs
    }
    
    /// A private helper simulating a call to a Core ML transformer.
    private func generateEmbedding(for text: String) async throws -> [Float] {
        // Simulate the latency of a neural network inference
        try await Task.sleep(for: .milliseconds(100))
        
        // Return a mock 1536-dimensional vector
        return (0..<1536).map { _ in Float.random(in: -1...1) }
    }
}

/// The SemanticChunk model as defined in previous chapters.
@available(iOS 18.0, *)
@Model
final class SemanticChunk {
    var text: String
    var embedding: [Float]
    var timestamp: Date
    
    init(text: String, embedding: [Float]) {
        self.text = text
        self.embedding = embedding
        self.timestamp = Date()
    }
}
