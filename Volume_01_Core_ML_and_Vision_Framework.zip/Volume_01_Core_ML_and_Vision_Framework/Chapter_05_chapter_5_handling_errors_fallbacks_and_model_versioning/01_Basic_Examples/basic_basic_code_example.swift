
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import CoreML
import Vision
import Foundation // For URL, Bundle, NSError

/// Manages the loading and selection of Core ML image classification models,
/// including error handling and fallback mechanisms.
///
/// This class demonstrates how to robustly load machine learning models,
/// prioritizing a primary model and falling back to a simpler alternative
/// if the primary model encounters loading issues.
@available(iOS 17.0, macOS 14.0, *) // Target a recent stable OS version for modern Swift features
class SmartPhotoClassifier {

    /// The currently loaded Core ML model. This will be either the 'Pro' or 'Basic' model.
    private var currentMLModel: MLModel?

    /// The Vision model wrapper for the current Core ML model, used for Vision framework integration.
    private var currentVNCoreMLModel: VNCoreMLModel?

    /// Initializes the classifier by attempting to load the primary model,
    /// and falling back to a simpler model if the primary fails.
    ///
    /// Model loading can be a long-running operation, especially for larger models.
    /// It's good practice to perform this asynchronously to avoid blocking the main thread.
    init() {
        Task { // Use a Task to perform potentially long-running operations asynchronously.
            await loadModelsSequentially()
        }
    }

    /// Attempts to load models, prioritizing a 'Pro' version and falling back
    /// to a 'Basic' version if the 'Pro' model fails to load.
    ///
    /// This method encapsulates the core error handling and fallback logic for model loading.
    private func loadModelsSequentially() async {
        print("Attempting to load primary 'Pro' image classifier model...")

        do {
            // 1. Attempt to load the primary, more advanced model.
            //    We simulate a missing 'ProImageClassifier.mlmodel' to trigger the fallback.
            //    In a real app, 'ProImageClassifier' would be included in the bundle
            //    or downloaded over-the-air.
            let proModelURL = try getModelURL(named: "ProImageClassifier") // This will throw if the file doesn't exist.
            
            // Configure the model to utilize all available compute units (CPU, GPU, Neural Engine)
            let config = MLModelConfiguration()
            config.computeUnits = .all 
            
            // Initialize the Core ML model with its configuration.
            self.currentMLModel = try MLModel(contentsOf: proModelURL, configuration: config)
            
            // Log success and the model's version string (useful for debugging and versioning).
            print("✅ Successfully loaded 'ProImageClassifier.mlmodel' (Version: \(currentMLModel?.modelDescription.metadata.versionString ?? "N/A"))")

            // 2. Wrap the Core ML model in a Vision model (`VNCoreMLModel`) for easier integration
            //    with the Vision framework, which handles image preprocessing and post-processing.
            self.currentVNCoreMLModel = try VNCoreMLModel(for: currentMLModel!)

        } catch let error as CoreMLError {
            // Specific error handling for CoreML-related errors (e.g., model corruption, input/output mismatch).
            print("❌ CoreML Error loading 'ProImageClassifier.mlmodel': \(error.localizedDescription)")
            handleFallbackLoading(reason: error.localizedDescription)
        } catch {
            // Generic error handling for any other issues during loading (e.g., file not found,
            // permission issues, malformed model file that isn't a CoreMLError).
            print("❌ Generic Error loading 'ProImageClassifier.mlmodel': \(error.localizedDescription)")
            handleFallbackLoading(reason: error.localizedDescription)
        }
    }

    /// Handles the fallback logic, attempting to load a simpler model if the primary failed.
    /// - Parameter reason: The reason for the primary model's failure, for logging purposes.
    private func handleFallbackLoading(reason: String) {
        print("Initiating fallback: Primary model failed to load. Reason: \(reason)")
        print("Attempting to load fallback 'Basic' image classifier model...")

        do {
            // 3. Attempt to load the fallback, simpler model.
            //    Ensure 'BasicImageClassifier.mlmodel' is actually in your app bundle
            //    for this to succeed.
            let basicModelURL = try getModelURL(named: "BasicImageClassifier") // This *should* succeed.
            
            // Use the same configuration for the fallback model.
            let config = MLModelConfiguration()
            config.computeUnits = .all
            
            self.currentMLModel = try MLModel(contentsOf: basicModelURL, configuration: config)
            print("✅ Successfully loaded 'BasicImageClassifier.mlmodel' (Version: \(currentMLModel?.modelDescription.metadata.versionString ?? "N/A")) as fallback.")

            // 4. Wrap the fallback Core ML model in a Vision model.
            self.currentVNCoreMLModel = try VNCoreMLModel(for: currentMLModel!)

        } catch {
            // 5. If even the fallback model fails to load, this is a critical error.
            //    The app's classification functionality will be severely limited or unavailable.
            print("❌ CRITICAL ERROR: Failed to load even the fallback 'BasicImageClassifier.mlmodel'. Application may not function correctly for classification. Error: \(error.localizedDescription)")
            self.currentMLModel = nil
            self.currentVNCoreMLModel = nil
            // In a real app, you might notify the user or disable relevant UI features.
        }
    }

    /// Helper function to retrieve the URL of a compiled Core ML model (`.mlmodelc`)
    /// from the application's main bundle.
    /// - Parameter name: The base name of the `.mlmodel` file (e.g., "MyModel").
    /// - Returns: The URL to the compiled `.mlmodelc` directory.
    /// - Throws: An `NSError` if the model cannot be found in the bundle, simulating a `CoreMLError.modelNotFound` scenario.
    private func getModelURL(named name: String) throws -> URL {
        guard let url = Bundle.main.url(forResource: name, withExtension: "mlmodelc") else {
            // If the .mlmodelc file is not found, we throw an error.
            // This is how we simulate the 'ProImageClassifier' being missing.
            print("DEBUG: Could not find \(name).mlmodelc in bundle.")
            // Using NSError for simplicity in this basic example.
            // In a production app, a custom AppError enum would provide more specific context.
            throw NSError(domain: "SmartPhotoClassifier", code: 1001, userInfo: [NSLocalizedDescriptionKey: "Model '\(name)' not found in app bundle."])
        }
        return url
    }

    /// Performs image classification using the currently loaded model.
    /// This is a placeholder to illustrate where the loaded `VNCoreMLModel` would be utilized.
    /// - Parameter image: The image to classify (e.g., a `CIImage` or `CGImage`).
    /// - Returns: A string describing the classification result, or an error message if no model is loaded.
    func classifyImage(_ image: CIImage) async -> String {
        guard let model = currentVNCoreMLModel else {
            return "Classification failed: No model loaded."
        }

        // Create a Vision request using the loaded VNCoreMLModel.
        let request = VNCoreMLRequest(model: model) { request, error in
            if let error = error {
                print("Error during classification: \(error.localizedDescription)")
                return
            }
            // Process classification results here.
            guard let observations = request.results as? [VNClassificationObservation] else { return }
            if let topClassification = observations.first {
                print("Classification result: \(topClassification.identifier) (\(topClassification.confidence * 100.0)%)")
            }
        }

        // In a real application, you would execute this request using a `VNImageRequestHandler`.
        // For this example, we'll just return a placeholder string.
        // let handler = VNImageRequestHandler(ciImage: image)
        // do {
        //     try handler.perform([request])
        // } catch {
        //     print("Failed to perform classification request: \(error)")
        // }
        return "Image submitted for classification using \(currentMLModel?.modelDescription.metadata.versionString ?? "unknown") model."
    }

    /// Returns the version string of the currently loaded model.
    /// This is useful for debugging and for displaying to the user which model version is active.
    var loadedModelVersion: String {
        return currentMLModel?.modelDescription.metadata.versionString ?? "No model loaded"
    }
}

// MARK: - Example Usage in an iOS/macOS Application

// To demonstrate the functionality, we'll use a simple `@main` entry point.
// In a real SwiftUI or UIKit app, you would integrate `SmartPhotoClassifier`
// into your `ContentView` or `ViewController`.

@main
@available(iOS 17.0, macOS 14.0, *)
struct SmartPhotoApp {
    static func main() {
        print("--- Smart Photo Organizer App Starting ---")

        // Initialize the classifier. This triggers the asynchronous model loading logic.
        let classifier = SmartPhotoClassifier()

        // In a real app, you would typically have UI that waits for the model to be ready
        // before attempting classification. For this command-line-style example,
        // we'll introduce a short delay to allow the async loading Task to complete.
        Task {
            // Give the model loading Task a moment to execute.
            try? await Task.sleep(for: .seconds(1))
            
            print("\n--- Model Loading Status ---")
            print("Current loaded model version: \(classifier.loadedModelVersion)")

            // Simulate a classification attempt (requires a real image, omitted for brevity).
            // For example:
            // if let sampleImage = CIImage(contentsOf: URL(fileURLWithPath: "/path/to/image.jpg")) {
            //     let result = await classifier.classifyImage(sampleImage)
            //     print("Classification attempt result: \(result)")
            // } else {
            //     print("Could not load sample image for classification.")
            // }

            print("\n--- Smart Photo Organizer App Finished ---")
        }
    }
}
