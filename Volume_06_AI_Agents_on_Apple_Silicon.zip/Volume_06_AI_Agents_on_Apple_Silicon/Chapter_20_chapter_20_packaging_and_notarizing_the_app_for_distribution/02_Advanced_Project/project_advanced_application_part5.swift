
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

/// @available(macOS 14.0, *)
/// A conceptual SwiftUI view model for the AI Code Reviewer application.
/// This demonstrates how the `LLMService` and `CodeReviewAgent` would be integrated
/// into a user interface, providing real-time feedback and handling asynchronous operations.
///
/// **Why this is advanced:**
/// - **Observable State**: Uses `@Observable` (or `@StateObject`/`@ObservedObject` for older Swift)
///   to drive UI updates from asynchronous operations.
/// - **Structured Concurrency in UI**: `Task` modifiers and explicit `Task` creation for
///   long-running background work.
/// - **User Feedback**: Provides loading indicators and error messages for a polished UX.
import SwiftUI
import Foundation // For URLSession, FileManager etc.

// Using @Observable for Swift 6 / iOS 17+ / macOS 14+
@Observable
final class CodeReviewViewModel {
    private let llmService: LLMService
    private let reviewAgent: CodeReviewAgent

    var codeInput: String = ""
    var reviewResult: String = "Enter Swift code above and click 'Review' to get AI suggestions."
    var isLoading: Bool = false
    var errorMessage: String?
    var isModelLoaded: Bool = false // Reflects the state of the LLMService

    init() {
        // In a real app, you might configure these with specific model paths/URLs
        let modelFileName = "tinyllama-1.1b-chat-v1.0.Q4_0.gguf"
        // This URL should point to a publicly accessible model file.
        // For demonstration, using a placeholder or a very small test file.
        // Replace with a real URL for a GGUF model if testing locally.
        let modelDownloadURL = URL(string: "https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0.Q4_0.gguf")!
        
        self.llmService = LLMService(modelFileName: modelFileName, modelDownloadURL: modelDownloadURL)
        self.reviewAgent = CodeReviewAgent(llmService: llmService)
        
        // Asynchronously check model status on init
        Task { await updateModelLoadedStatus() }
    }
    
    /// Asynchronously updates the `isModelLoaded` status from the LLMService.
    private func updateModelLoadedStatus() async {
        self.isModelLoaded = await llmService.isModelLoaded
    }

    /// Initiates the code review process.
    /// This method is marked `MainActor` as it directly interacts with UI-bound state.
    @MainActor
    func performCodeReview() {
        guard !isLoading else { return } // Prevent multiple concurrent reviews

        isLoading = true
        errorMessage = nil
        reviewResult = "Reviewing code..."

        Task {
            do {
                // The agent handles model loading if it's not already loaded.
                let result = try await reviewAgent.reviewCode(code: codeInput, context: "Focus on Swift concurrency and error handling.")
                reviewResult = result
            } catch let error as LLMServiceError {
                errorMessage = "AI Service Error: \(error.localizedDescription)"
                reviewResult = "Failed to review code."
            } catch {
                errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
                reviewResult = "Failed to review code."
            }
            isLoading = false
            await updateModelLoadedStatus() // Update status after potential model loading/unloading
        }
    }
    
    /// Explicitly loads the LLM model.
    /// This could be triggered by a "Load Model" button in the UI.
    @MainActor
    func loadModelExplicitly() {
        guard !isLoading else { return }
        isLoading = true
        errorMessage = nil
        reviewResult = "Loading AI model..."
        
        Task {
            do {
                try await llmService.loadModel()
                reviewResult = "AI Model loaded successfully. Ready for review."
            } catch let error as LLMServiceError {
                errorMessage = "Model Load Error: \(error.localizedDescription)"
                reviewResult = "Failed to load AI model."
            } catch {
                errorMessage = "An unexpected error occurred during model load: \(error.localizedDescription)"
                reviewResult = "Failed to load AI model."
            }
            isLoading = false
            await updateModelLoadedStatus()
        }
    }
    
    /// Explicitly unloads the LLM model.
    /// This could be triggered by an "Unload Model" button to free up memory.
    @MainActor
    func unloadModelExplicitly() {
        llmService.unloadModel() // Unloading is synchronous and non-throwing
        reviewResult = "AI Model unloaded. Memory freed."
        errorMessage = nil
        Task { await updateModelLoadedStatus() }
    }
}

// Conceptual SwiftUI View
struct CodeReviewView: View {
    @State private var viewModel = CodeReviewViewModel()

    var body: some View {
        VStack(spacing: 15) {
            Text("AI Code Reviewer")
                .font(.largeTitle)
                .padding(.bottom, 10)

            HStack {
                Text("Model Status:")
                Text(viewModel.isModelLoaded ? "Loaded" : "Not Loaded")
                    .foregroundColor(viewModel.isModelLoaded ? .green : .red)
                
                Spacer()
                
                Button("Load Model") {
                    viewModel.loadModelExplicitly()
                }
                .disabled(viewModel.isModelLoaded || viewModel.isLoading)
                
                Button("Unload Model") {
                    viewModel.unloadModelExplicitly()
                }
                .disabled(!viewModel.isModelLoaded || viewModel.isLoading)
            }
            .padding(.horizontal)

            TextEditor(text: $viewModel.codeInput)
                .frame(height: 150)
                .border(Color.gray, width: 0.5)
                .padding(.horizontal)
                .font(.body.monospaced())
                .scrollContentBackground(.hidden)
                .background(Color.secondary.opacity(0.1))
                .cornerRadius(5)
                .overlay(
                    Text("Enter Swift code here...")
                        .foregroundColor(.gray)
                        .opacity(viewModel.codeInput.isEmpty ? 1 : 0)
                        .padding(.leading, 20)
                        .padding(.top, 8)
                    , alignment: .topLeading
                )

            Button(action: viewModel.performCodeReview) {
                if viewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(.white)
                        .frame(maxWidth: .infinity)
                } else {
                    Text("Review Code")
                        .frame(maxWidth: .infinity)
                }
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(viewModel.codeInput.isEmpty || viewModel.isLoading || !viewModel.isModelLoaded)
            .padding(.horizontal)

            if let errorMessage = viewModel.errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.horizontal)
            }

            ScrollView {
                Text(viewModel.reviewResult)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color.secondary.opacity(0.05))
                    .cornerRadius(5)
                    .textSelection(.enabled) // Allow text selection for copying results
            }
            .padding(.horizontal)
        }
        .padding()
        .frame(minWidth: 600, minHeight: 700) // For macOS window sizing
    }
}

// App Entry Point (for macOS)
@main
struct AICodeReviewerApp: App {
    var body: some Scene {
        WindowGroup {
            CodeReviewView()
        }
        .windowStyle(.hiddenTitleBar) // Example: A modern macOS window style
    }
}
