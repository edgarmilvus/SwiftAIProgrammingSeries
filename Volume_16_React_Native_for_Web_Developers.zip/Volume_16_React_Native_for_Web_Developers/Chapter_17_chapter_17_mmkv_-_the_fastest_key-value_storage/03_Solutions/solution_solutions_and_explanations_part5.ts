/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// checkpointer/mmkvCheckpointer.ts
import { storage } from '../lib/storage';

// 1. Define the interface (simplified for the exercise)
// In a real scenario, this would extend interfaces from '@langchain/langgraph'
interface Checkpointer {
  put(threadId: string, checkpointId: string, state: any): Promise<void>;
  get(threadId: string, checkpointId: string): Promise<any>;
  list(threadId: string): Promise<any[]>; // Helper to list checkpoints
}

// 2. Implement the class
export class MMKVCheckpointer implements Checkpointer {
  
  // Helper to generate a consistent key
  private getCheckpointKey(threadId: string, checkpointId: string): string {
    return `langgraph_checkpoint_${threadId}_${checkpointId}`;
  }

  private getThreadKey(threadId: string): string {
    return `langgraph_thread_${threadId}`;
  }

  /**
   * Saves the graph state to MMKV.
   */
  async put(threadId: string, checkpointId: string, state: any): Promise<void> {
    // Serialize the state
    const serializedState = JSON.stringify(state);
    
    // Save the specific checkpoint
    const checkpointKey = this.getCheckpointKey(threadId, checkpointId);
    storage.set(checkpointKey, serializedState);

    // Maintain a list of checkpoint IDs for this thread (optional but useful)
    const threadKey = this.getThreadKey(threadId);
    const existingList = storage.getString(threadKey);
    let checkpointList: string[] = existingList ? JSON.parse(existingList) : [];
    
    if (!checkpointList.includes(checkpointId)) {
      checkpointList.push(checkpointId);
      storage.set(threadKey, JSON.stringify(checkpointList));
    }
  }

  /**
   * Retrieves a specific checkpoint state.
   */
  async get(threadId: string, checkpointId: string): Promise<any> {
    const checkpointKey = this.getCheckpointKey(threadId, checkpointId);
    const data = storage.getString(checkpointKey);
    
    if (!data) return null;
    try {
      return JSON.parse(data);
    } catch (e) {
      console.error("Failed to parse checkpoint data", e);
      return null;
    }
  }

  /**
   * Lists all checkpoints for a given thread.
   */
  async list(threadId: string): Promise<any[]> {
    const threadKey = this.getThreadKey(threadId);
    const data = storage.getString(threadKey);
    
    if (!data) return [];
    
    const checkpointIds: string[] = JSON.parse(data);
    const checkpoints = [];
    
    for (const id of checkpointIds) {
      const state = await this.get(threadId, id);
      if (state) {
        checkpoints.push({ id, state });
      }
    }
    return checkpoints;
  }
}
