/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview MetricCard.tsx
 * A "Hello World" example demonstrating the shift from HTML divs to React Native Views.
 * This component represents a SaaS dashboard widget displaying a metric value.
 */

import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Dimensions, 
  Platform 
} from 'react-native';

// 1. DATA INTERFACE
// In web, we might use an interface for API response shapes.
// In React Native, we use TypeScript interfaces to enforce prop types.
interface MetricCardProps {
  label: string;
  value: string | number;
  trend?: 'up' | 'down' | 'neutral';
}

// 2. PLATFORM-SPECIFIC LOGIC
// React Native allows us to handle platform differences natively.
// Here, we define a shadow style that only applies to iOS (as Android handles elevation differently).
const iosShadowStyles = Platform.select({
  ios: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  android: {
    elevation: 4, // Android uses elevation, not shadows
  },
  default: {}, // Web or other platforms
});

// 3. THE COMPONENT DEFINITION
const MetricCard: React.FC<MetricCardProps> = ({ label, value, trend = 'neutral' }) => {
  
  // 4. STYLE LOGIC
  // Unlike CSS, styles in React Native are plain JavaScript objects.
  // We use StyleSheet.create for performance optimization (immutable references).
  const styles = StyleSheet.create({
    // The 'View' replaces the 'div'. It acts as a container.
    cardContainer: {
      backgroundColor: '#FFFFFF',
      borderRadius: 12,
      padding: 16,
      width: Dimensions.get('window').width * 0.4, // 40% of screen width
      ...iosShadowStyles, // Spread platform-specific styles
      
      // FLEXBOX FIRST: React Native defaults to flex: 1, flexDirection: 'column'
      // We explicitly set column layout for this card.
      flexDirection: 'column',
      justifyContent: 'space-between',
    },
    
    // The 'Text' component replaces '<p>', '<span>', or '<h1>'.
    // Note: Text cannot contain other Views or Text components (unlike HTML).
    labelStyle: {
      fontSize: 14,
      color: '#6B7280', // Tailwind-like gray-500
      fontWeight: '500',
      marginBottom: 8,
      textTransform: 'uppercase',
      letterSpacing: 0.5,
    },
    
    valueStyle: {
      fontSize: 28,
      color: '#111827', // Tailwind-like gray-900
      fontWeight: '700',
    },
    
    trendIndicator: {
      marginTop: 8,
      fontSize: 12,
      fontWeight: '600',
      color: trend === 'up' ? '#10B981' : trend === 'down' ? '#EF4444' : '#6B7280',
    },
  });

  // 5. RENDER STRUCTURE
  return (
    <View style={styles.cardContainer}>
      <View>
        <Text style={styles.labelStyle}>{label}</Text>
        <Text style={styles.valueStyle}>{value}</Text>
      </View>
      
      <View style={{ marginTop: 8 }}>
        <Text style={styles.trendIndicator}>
          {trend === 'up' ? '▲ +12%' : trend === 'down' ? '▼ -4%' : '— 0%'}
        </Text>
      </View>
    </View>
  );
};

export default MetricCard;
