
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift snippet (example for an external AI SDK)
// Not strictly required for the theoretical explanation of core Swift features.
// This would be relevant if integrating a specific AI model library.

import PackageDescription

let package = Package(
    name: "AIApp",
    platforms: [.iOS(.v17), .macOS(.v14)], // Minimum platform for @Observable
    products: [
        .library(
            name: "AIAppCore",
            targets: ["AIAppCore"]),
    ],
    dependencies: [
        // Example: If using a specific AI SDK
        .package(url: "https://github.com/some/aisdk.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "AIAppCore",
            dependencies: [
                .product(name: "AISDK", package: "aisdk") // Link to the AI SDK
            ]),
    ]
)
