
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
class TextProcessor {
    func tokenizeDocument(text: String, unit: NLTokenUnit) async -> [NSRange] {
        // Perform tokenization on a background thread.
        // The `await` keyword ensures the UI remains responsive.
        return await Task.detached {
            let tokenizer = NLTokenizer(unit: unit)
            tokenizer.string = text
            var ranges: [NSRange] = []
            tokenizer.enumerateTokens(in: text.startIndex..<text.endIndex) { tokenRange, _ in
                let nsRange = NSRange(tokenRange, in: text)
                ranges.append(nsRange)
                return true // Continue enumeration
            }
            return ranges
        }.value
    }

    // Example usage in a UI context (e.g., a SwiftUI View or ViewController)
    func processTextForDisplay(input: String) async {
        print("Starting tokenization...")
        let wordRanges = await tokenizeDocument(text: input, unit: .word)
        print("Finished word tokenization. Found \(wordRanges.count) words.")

        let sentenceRanges = await tokenizeDocument(text: input, unit: .sentence)
        print("Finished sentence tokenization. Found \(sentenceRanges.count) sentences.")
        // Update UI or pass to further processing
    }
}
