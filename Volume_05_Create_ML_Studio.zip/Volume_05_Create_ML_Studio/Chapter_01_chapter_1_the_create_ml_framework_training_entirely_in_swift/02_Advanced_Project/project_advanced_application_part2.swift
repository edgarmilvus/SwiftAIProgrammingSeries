
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CreateML
import CoreML
import Vision
import UniformTypeIdentifiers // Useful for document-related apps, even if not directly used in this snippet

// MARK: - Intelligent Document Classifier: Advanced Application

/// `DocumentClassifierManager` handles the entire lifecycle of an image classification model
/// for document categorization: from training with local data to persisting the model
/// and performing real-time predictions using the Vision framework.
///
/// This class acts as a ViewModel or service layer for integrating Create ML
/// directly into an iOS/macOS application.
@available(iOS 17.0, macOS 14.0, *) // Create ML often requires recent OS versions
class DocumentClassifierManager: ObservableObject {
    /// Publishes the current status of the training or model loading process.
    @Published var trainingStatus: String = "Idle"
    /// Publishes the most recent predicted document category.
    @Published var currentPrediction: String = "N/A"
    /// Publishes the confidence level of the most recent prediction (0.0 - 1.0).
    @Published var predictionConfidence: Double = 0.0

    private var trainedModel: MLModel?
    private var visionCoreMLModel: VNCoreMLModel?

    // MARK: - Model Paths

    /// The base name for our Core ML model file.
    private let modelFileName = "DocumentClassifier.mlmodel"

    /// Computes the URL where the raw `.mlmodel` will be saved after training.
    /// This is typically within the app's sandboxed `Application Support` directory.
    private var rawModelURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
            .appendingPathComponent(modelFileName)
    }

    /// Computes the URL where the *compiled* `.mlmodelc` model will be stored.
    /// Core ML models must be compiled for a specific device before use.
    /// Storing it separately helps manage the lifecycle and distinction from the raw model.
    private var compiledModelURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
            .appendingPathComponent("CompiledModels") // Custom directory for compiled models
            .appendingPathComponent(modelFileName + "c") // Compiled models have a 'c' suffix
    }

    // MARK: - Initialization

    /// Initializes the DocumentClassifierManager and attempts to load a pre-existing model.
    init() {
        // Attempt to load a pre-existing model upon initialization to make it ready for inference.
        // This is an asynchronous operation, so it's wrapped in a Task.
        Task {
            await loadModel()
        }
    }

    // MARK: - Training Logic

    /// Initiates the training process for the document classifier.
    /// This method performs the following steps:
    /// 1. Updates the UI status.
    /// 2. Loads training data from labeled directories within the app bundle.
    /// 3. Configures and trains an `MLImageClassifier`.
    /// 4. Evaluates the trained model.
    /// 5. Persists the trained model to the app's sandbox.
    /// 6. Loads the newly trained model for immediate inference use.
    /// - Parameter trainingDataBundleURL: The URL to the root directory of the training data
    ///   within the app's bundle. This directory should contain subdirectories, each named
    ///   after a document category, containing images for that category.
    ///   Example structure: `TrainingData/Invoice/img1.jpg`, `TrainingData/Receipt/img2.png`.
    func trainModel(from trainingDataBundleURL: URL) async {
        // Update UI status on the main thread
        DispatchQueue.main.async {
            self.trainingStatus = "Starting training..."
        }

        do {
            // 2. Asynchronously Loading and Preparing Training Data
            // Create ML's DataSource for image classifiers expects a directory structure
            // where subdirectories are class labels. This is efficient for bundled data.
            let dataSource = MLImageClassifier.DataSource.labeledDirectories(at: trainingDataBundleURL)
            DispatchQueue.main.async {
                self.trainingStatus = "Training data loaded. Starting classification training..."
            }

            // 3. Configuring and Training the MLImageClassifier
            // We use the default configuration, which often works well.
            // For advanced use, a specific feature extractor or data augmentations could be applied:
            // let config = MLImageClassifier.Configuration(featureExtractor: .scenePrint(revision: 2),
            //                                              augmentation: .defaults)
            // let classifier = try await MLImageClassifier(trainingData: dataSource, configuration: config)
            let classifier = try await MLImageClassifier(trainingData: dataSource)
            
            DispatchQueue.main.async {
                self.trainingStatus = "Model trained successfully. Evaluating performance..."
            }

            // Evaluate the model on the training data. Create ML automatically splits a portion
            // for validation if no explicit validation data is provided.
            let evaluation = classifier.evaluation(on: dataSource)
            let accuracy = evaluation.accuracy * 100 // Convert accuracy to percentage
            
            DispatchQueue.main.async {
                self.trainingStatus = String(format: "Training complete. Validation Accuracy: %.2f%%", accuracy)
            }

            // 4. Persisting the Trained Model
            // Save the newly trained model to the raw model URL in the app's sandbox.
            try classifier.write(to: rawModelURL)
            DispatchQueue.main.async {
                self.trainingStatus = "Model saved to: \(self.rawModelURL.lastPathComponent)"
            }

            // After successful training and saving, load the newly trained model for immediate use.
            await loadModel()

        } catch MLClassifier.TrainingError.dataCollection(let details) {
            // Specific error handling for data collection issues during training.
            DispatchQueue.main.async {
                self.trainingStatus = "Training failed: Data collection error: \(details.localizedDescription)"
                print("Training failed: Data collection error: \(details)")
            }
        } catch {
            // General error handling for any other training-related failures.
            DispatchQueue.main.async {
                self.trainingStatus = "Training failed: \(error.localizedDescription)"
                print("Training failed with error: \(error)")
            }
        }
    }

    // MARK: - Model Loading Logic

    /// Loads a previously trained and saved Core ML model.
    /// This method first attempts to compile the raw `.mlmodel` if it hasn't been compiled,
    /// then loads the compiled `.mlmodelc` for inference.
    ///
    /// The process involves:
    /// 1. Checking for an existing compiled model (`.mlmodelc`).
    /// 2. If not found, checking for a raw model (`.mlmodel`).
    /// 3. If a raw model is found, compiling it using `MLModel.compileModel(at:)`.
    /// 4. Moving the compiled model to a persistent location.
    /// 5. Loading the compiled model into `MLModel` and `VNCoreMLModel`.
    func loadModel() async {
        DispatchQueue.main.async {
            self.trainingStatus = "Attempting to load model..."
        }

        let fileManager = FileManager.default
        do {
            // Ensure the directory for compiled models exists.
            let compiledModelsDirectory = compiledModelURL.deletingLastPathComponent()
            if !fileManager.fileExists(atPath: compiledModelsDirectory.path) {
                try fileManager.createDirectory(at: compiledModelsDirectory, withIntermediateDirectories: true, attributes: nil)
            }

            // 5. Loading the Model for Inference
            // Prioritize loading the already compiled model for performance.
            if fileManager.fileExists(atPath: compiledModelURL.path) {
                let model = try MLModel(contentsOf: compiledModelURL)
                self.trainedModel = model
                self.visionCoreMLModel = try VNCoreMLModel(for: model)
                DispatchQueue.main.async {
                    self.trainingStatus = "Successfully loaded compiled model for inference."
                }
            } else if fileManager.fileExists(atPath: rawModelURL.path) {
                // If only the raw model exists, compile it first. This is an expensive, one-time operation.
                DispatchQueue.main.async {
                    self.trainingStatus = "Compiling raw model for the first time..."
                }
                let compiledURL = try await MLModel.compileModel(at: rawModelURL)
                
                // Move the compiled model from the temporary location to our designated persistent directory.
                try fileManager.moveItem(at: compiledURL, to: compiledModelURL)
                
                let model = try MLModel(contentsOf: compiledModelURL)
                self.trainedModel = model
                self.visionCoreMLModel = try VNCoreMLModel(for: model)
                DispatchQueue.main.async {
                    self.trainingStatus = "Successfully compiled and loaded model for inference."
                }
            } else {
                // No model found, either raw or compiled.
                DispatchQueue.main.async {
                    self.trainingStatus = "No trained model found on disk. Please train one."
                }
            }
        } catch {
            // Handle any errors during model loading or compilation.
            DispatchQueue.main.async {
                self.trainingStatus = "Failed to load/compile model: \(error.localizedDescription)"
                print("Failed to load/compile model: \(error)")
            }
            // Reset models if loading fails.
            self.trainedModel = nil
            self.visionCoreMLModel = nil
        }
    }

    // MARK: - Prediction Logic

    /// Performs classification on a given image using the loaded Core ML model via Vision.
    /// This method leverages the Vision framework for efficient image processing and inference.
    /// - Parameter image: The `CGImage` to classify. Vision works optimally with `CGImage` or `CVPixelBuffer`.
    /// - Returns: A tuple containing the predicted `DocumentCategory` and its confidence.
    /// - Throws: `DocumentClassifierError` if the model is not loaded or prediction fails.
    func classifyDocument(image: CGImage) async throws -> (category: DocumentCategory, confidence: Double) {
        guard let visionCoreMLModel = visionCoreMLModel else {
            // If the Vision Core ML model is not ready, throw an error.
            DispatchQueue.main.async {
                self.currentPrediction = "Model not ready."
                self.predictionConfidence = 0.0
            }
            throw DocumentClassifierError.modelNotLoaded
        }

        // 6. Performing Image Classification using Vision and Core ML
        // Create a VNCoreMLRequest with the loaded model.
        let request = VNCoreMLRequest(model: visionCoreMLModel) { [weak self] request, error in
            guard let self = self else { return }

            if let error = error {
                // Handle errors that occur during the Vision request.
                DispatchQueue.main.async {
                    self.currentPrediction = "Prediction Error"
                    self.predictionConfidence = 0.0
                }
                print("Vision request failed with error: \(error.localizedDescription)")
                return
            }

            // Process the results if the request was successful.
            guard let observations = request.results as? [VNClassificationObservation],
                  let bestClassification = observations.first else {
                DispatchQueue.main.async {
                    self.currentPrediction = "No classification results."
                    self.predictionConfidence = 0.0
                }
                print("No classification results found from Vision.")
                return
            }

            // Update UI on the main thread with the best prediction.
            DispatchQueue.main.async {
                self.currentPrediction = bestClassification.identifier
                self.predictionConfidence = Double(bestClassification.confidence)
            }
        }

        // Configure the request for optimal performance.
        // `.centerCrop` is a common strategy for image classification inputs.
        request.imageCropAndScaleOption = .centerCrop

        // Use VNImageRequestHandler to perform the Vision request on the input image.
        // `withCheckedContinuation` bridges the completion handler pattern of Vision
        // to Swift's structured concurrency (`async/await`).
        try await withCheckedContinuation { (continuation: CheckedContinuation<Void, Error>) in
            let handler = VNImageRequestHandler(cgImage: image, options: [:])
            do {
                try handler.perform([request])
                continuation.resume(returning: ()) // Resume on success
            } catch {
                continuation.resume(throwing: error) // Resume on failure
            }
        }

        // After the request completes, retrieve the best classification from the request's results.
        // This part is outside the completion handler to allow the `async` function to return a value.
        guard let observations = request.results as? [VNClassificationObservation],
              let bestClassification = observations.first,
              let category = DocumentCategory(rawValue: bestClassification.identifier) else {
            throw DocumentClassifierError.predictionFailed("Could not interpret classification results or no valid category found.")
        }

        return (category: category, confidence: Double(bestClassification.confidence))
    }

    // MARK: - Utility and Error Handling

    /// Custom error types for the document classifier, providing localized descriptions.
    enum DocumentClassifierError: Error, LocalizedError {
        case modelNotLoaded
        case trainingDataNotFound(URL)
        case predictionFailed(String)

        var errorDescription: String? {
            switch self {
            case .modelNotLoaded:
                return "The Core ML model has not been loaded or trained yet. Please train or load a model."
            case .trainingDataNotFound(let url):
                return "Training data not found at the expected URL: \(url.path). Ensure 'TrainingData' folder is in the app bundle."
            case .predictionFailed(let message):
                return "Document prediction failed: \(message)"
            }
        }
    }

    /// Helper function to simulate fetching the training data URL from the app bundle.
    /// In a real app, this data would be bundled with the app, downloaded, or user-provided.
    /// - Returns: URL to the root of the training data directory (e.g., `AppBundle/TrainingData/`).
    /// - Throws: `DocumentClassifierError.trainingDataNotFound` if the directory doesn't exist.
    static func getTrainingDataURL() throws -> URL {
        guard let bundleURL = Bundle.main.url(forResource: "TrainingData", withExtension: nil) else {
            // Provide a placeholder URL for the error message if the resource isn't found.
            throw DocumentClassifierError.trainingDataNotFound(URL(string: "file:///path/to/TrainingData")!)
        }
        return bundleURL
    }
}

// MARK: - Example Usage (Conceptual SwiftUI View Integration)

// This section provides a conceptual example of how `DocumentClassifierManager`
// could be integrated into a SwiftUI application. It demonstrates triggering
// training, selecting an image, and performing classification.

/*
 import SwiftUI
 import UIKit // For UIImage and CGImage

 @available(iOS 17.0, *)
 struct DocumentClassifierView: View {
     // StateObject manages the lifecycle of our classifier manager.
     @StateObject private var classifierManager = DocumentClassifierManager()
     @State private var selectedImage: UIImage?
     @State private var showingImagePicker = false
     @State private var classificationResult: String = "No image selected"
     @State private var classificationConfidence: Double = 0.0

     var body: some View {
         NavigationView {
             VStack {
                 Text("Document Classifier Status: \(classifierManager.trainingStatus)")
                     .font(.subheadline)
                     .padding(.bottom, 5)

                 if let image = selectedImage {
                     Image(uiImage: image)
                         .resizable()
                         .scaledToFit()
                         .frame(height: 200)
                         .cornerRadius(10)
                         .padding()
                 } else {
                     Text("Select an image to classify")
                         .foregroundColor(.gray)
                         .frame(width: 250, height: 200)
                         .background(Color.gray.opacity(0.1))
                         .cornerRadius(10)
                         .padding()
                 }

                 Text("Predicted Category: \(classificationResult)")
                     .font(.headline)
                     .padding(.top)
                 Text(String(format: "Confidence: %.2f%%", classificationConfidence * 100))
                     .font(.subheadline)
                     .foregroundColor(.secondary)

                 Spacer()

                 VStack {
                     Button("Train Model") {
                         // Trigger training asynchronously.
                         Task {
                             do {
                                 let trainingDataURL = try DocumentClassifierManager.getTrainingDataURL()
                                 await classifierManager.trainModel(from: trainingDataURL)
                             } catch {
                                 print("Error getting training data URL: \(error.localizedDescription)")
                                 classifierManager.trainingStatus = "Error: \(error.localizedDescription)"
                             }
                         }
                     }
                     .buttonStyle(.borderedProminent)
                     .padding(.bottom, 5)

                     Button("Select Image & Classify") {
                         showingImagePicker = true
                     }
                     .buttonStyle(.bordered)
                 }
                 .padding()
             }
             .navigationTitle("Smart Document Scanner")
             .sheet(isPresented: $showingImagePicker) {
                 ImagePicker(selectedImage: $selectedImage) { image in
                     // When an image is picked, attempt classification.
                     if let uiImage = image, let cgImage = uiImage.cgImage {
                         Task {
                             do {
                                 let (category, confidence) = try await classifierManager.classifyDocument(image: cgImage)
                                 classificationResult = category.rawValue
                                 classificationConfidence = confidence
                             } catch {
                                 classificationResult = "Classification Error: \(error.localizedDescription)"
                                 classificationConfidence = 0.0
                             }
                         }
                     }
                 }
             }
         }
     }
 }

 // A simple `UIViewControllerRepresentable` for selecting images from the photo library.
 @available(iOS 17.0, *)
 struct ImagePicker: UIViewControllerRepresentable {
     @Binding var selectedImage: UIImage?
     var onImagePicked: (UIImage?) -> Void

     func makeUIViewController(context: Context) -> UIImagePickerController {
         let picker = UIImagePickerController()
         picker.delegate = context.coordinator
         picker.sourceType = .photoLibrary // Or .camera for a camera app
         return picker
     }

     func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

     func makeCoordinator() -> Coordinator {
         Coordinator(self)
     }

     class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
         var parent: ImagePicker

         init(_ parent: ImagePicker) {
             self.parent = parent
         }

         func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
             if let image = info[.originalImage] as? UIImage {
                 parent.selectedImage = image
                 parent.onImagePicked(image) // Call the callback with the picked image
             }
             picker.dismiss(animated: true)
         }

         func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
             parent.onImagePicked(nil) // Call callback with nil if cancelled
             picker.dismiss(animated: true)
         }
     }
 }
 */
