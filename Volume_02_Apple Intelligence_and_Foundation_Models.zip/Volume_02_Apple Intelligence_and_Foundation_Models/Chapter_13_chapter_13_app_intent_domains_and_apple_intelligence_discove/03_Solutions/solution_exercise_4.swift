
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import AppIntents
import Foundation

// MARK: - Ingredient Module (Conceptual)

@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct IngredientEntity: AppEntity {
    let id: UUID
    var name: String
    var quantity: Double // e.g., in grams, milliliters, or units

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Ingredient"

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(
            title: "\(name)",
            subtitle: "Qty: \(quantity)"
        )
    }
    
    var appEntityIdentifier: String { id.uuidString }

    init(id: UUID, name: String, quantity: Double) {
        self.id = id
        self.name = name
        self.quantity = quantity
    }
}

@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct IngredientEntityQuery: AppEntityQuery {
    // Simulate an in-memory inventory
    static var inventory: [IngredientEntity] = [
        IngredientEntity(id: UUID(uuidString: "10000000-0000-0000-0000-000000000001")!, name: "Milk", quantity: 1000), // ml
        IngredientEntity(id: UUID(uuidString: "10000000-0000-0000-0000-000000000002")!, name: "Flour", quantity: 500), // grams
        IngredientEntity(id: UUID(uuidString: "10000000-0000-0000-0000-000000000003")!, name: "Eggs", quantity: 12), // units
        IngredientEntity(id: UUID(uuidString: "10000000-0000-0000-0000-000000000004")!, name: "Sugar", quantity: 300), // grams
        IngredientEntity(id: UUID(uuidString: "10000000-0000-0000-0000-000000000005")!, name: "Chocolate Chips", quantity: 200) // grams
    ]

    func entities(for identifiers: [IngredientEntity.ID]) async throws -> [IngredientEntity] {
        return Self.inventory.filter { identifiers.contains($0.id) }
    }

    func entities(matching query: String) async throws -> [IngredientEntity] {
        return Self.inventory.filter { $0.name.localizedCaseInsensitiveContains(query) }
    }

    func suggestedEntities() async throws -> [IngredientEntity] {
        return Self.inventory.sorted { $0.name < $1.name }
    }
}

@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct CheckIngredientAvailabilityIntent: AppIntent {
    static var title: LocalizedStringResource = "Check Ingredient Availability"
    static var description: LocalizedStringResource = "Checks the available quantity of a specific ingredient."
    static var openAppWhenRun: Bool = false

    @Parameter(title: "Ingredient", description: "The ingredient to check.", requestValueDialog: "Which ingredient are you curious about?")
    var ingredient: IngredientEntity // Parameter of type IngredientEntity

    func perform() async throws -> some IntentResult {
        if let currentIngredient = IngredientEntityQuery.inventory.first(where: { $0.id == ingredient.id }) {
            print("✅ Cooking App: You have \(currentIngredient.quantity) units of \(currentIngredient.name).")
            return .result(
                dialog: "You have \(currentIngredient.quantity) units of \(currentIngredient.name)."
            )
        } else {
            print("❌ Cooking App: Ingredient '\(ingredient.name)' not found in inventory.")
            return .result(
                dialog: "I couldn't find \(ingredient.name) in your inventory."
            )
        }
    }
}


// MARK: - Recipe Module (Conceptual)

@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct RecipeEntity: AppEntity {
    let id: UUID
    var title: String
    // This is the key: an array of IngredientEntity, demonstrating cross-entity referencing.
    var requiredIngredients: [IngredientEntity] 

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Recipe"

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(
            title: "\(title)",
            subtitle: "Requires \(requiredIngredients.count) ingredients"
        )
    }

    var appEntityIdentifier: String { id.uuidString }

    init(id: UUID, title: String, requiredIngredients: [IngredientEntity]) {
        self.id = id
        self.title = title
        self.requiredIngredients = requiredIngredients
    }
}

@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct RecipeEntityQuery: AppEntityQuery {
    // Simulate some recipes, referencing ingredients from the IngredientEntityQuery.inventory
    static var recipes: [RecipeEntity] = {
        let milk = IngredientEntityQuery.inventory.first(where: { $0.name == "Milk" })!
        let flour = IngredientEntityQuery.inventory.first(where: { $0.name == "Flour" })!
        let eggs = IngredientEntityQuery.inventory.first(where: { $0.name == "Eggs" })!
        let sugar = IngredientEntityQuery.inventory.first(where: { $0.name == "Sugar" })!
        let chocolateChips = IngredientEntityQuery.inventory.first(where: { $0.name == "Chocolate Chips" })!

        return [
            RecipeEntity(
                id: UUID(uuidString: "20000000-0000-0000-0000-000000000001")!,
                title: "Chocolate Chip Cookies",
                requiredIngredients: [flour, sugar, eggs, chocolateChips]
            ),
            RecipeEntity(
                id: UUID(uuidString: "20000000-0000-0000-0000-000000000002")!,
                title: "Pancakes",
                requiredIngredients: [flour, milk, eggs]
            )
        ]
    }()

    func entities(for identifiers: [RecipeEntity.ID]) async throws -> [RecipeEntity] {
        return Self.recipes.filter { identifiers.contains($0.id) }
    }

    func entities(matching query: String) async throws -> [RecipeEntity] {
        return Self.recipes.filter { $0.title.localizedCaseInsensitiveContains(query) }
    }

    func suggestedEntities() async throws -> [RecipeEntity] {
        return Self.recipes.sorted { $0.title < $1.title }
    }
}

@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct FindRecipeByIngredientIntent: AppIntent {
    static var title: LocalizedStringResource = "Find Recipe by Ingredient"
    static var description: LocalizedStringResource = "Finds recipes that use a specific ingredient."
    static var openAppWhenRun: Bool = true

    @Parameter(title: "Ingredient", description: "The ingredient to search recipes for.", requestValueDialog: "Which ingredient do you want to find recipes for?")
    var ingredient: IngredientEntity // Parameter of type IngredientEntity

    func perform() async throws -> some IntentResult {
        let matchingRecipes = RecipeEntityQuery.recipes.filter { recipe in
            recipe.requiredIngredients.contains(where: { $0.id == ingredient.id })
        }

        if matchingRecipes.isEmpty {
            print("❌ Cooking App: No recipes found using \(ingredient.name).")
            return .result(
                dialog: "I couldn't find any recipes that use \(ingredient.name)."
            )
        } else {
            let recipeTitles = matchingRecipes.map { $0.title }.joined(separator: ", ")
            print("✅ Cooking App: Found recipes using \(ingredient.name): \(recipeTitles)")
            return .result(
                dialog: "I found \(matchingRecipes.count) recipes using \(ingredient.name): \(recipeTitles)."
            )
        }
    }
}


// MARK: - AppIntentsPackage for Modularity

@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct CookingAppIntents: AppIntentsPackage {
    // List all intents belonging to this package
    static var appIntents: [AppIntent.Type] {
        [
            FindRecipeByIngredientIntent.self,
            CheckIngredientAvailabilityIntent.self
        ]
    }

    // List all entities belonging to this package
    static var appEntities: [AppEntity.Type] {
        [
            IngredientEntity.self,
            RecipeEntity.self
        ]
    }
}

// 8. Make Discoverable via AppShortcutsProvider
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct CookingAppShortcuts: AppShortcutsProvider {
    // Define individual shortcuts for user phrases
    static var appShortcuts: [AppShortcut] {
        [
            AppShortcut(
                // Placeholder instance for AppEntity parameters
                intent: FindRecipeByIngredientIntent(ingredient: IngredientEntity(id: UUID(), name: "Milk", quantity: 0)),
                phrases: [
                    "Find recipes with \(.parameter(\.$ingredient))",
                    "What can I cook with \(.parameter(\.$ingredient))?"
                ],
                shortTitle: "Find Recipes",
                systemImageName: "fork.knife"
            ),
            AppShortcut(
                // Placeholder instance for AppEntity parameters
                intent: CheckIngredientAvailabilityIntent(ingredient: IngredientEntity(id: UUID(), name: "Flour", quantity: 0)),
                phrases: [
                    "Do I have \(.parameter(\.$ingredient))?",
                    "Check for \(.parameter(\.$ingredient))"
                ],
                shortTitle: "Check Ingredient",
                systemImageName: "basket"
            )
        ]
    }

    // Crucially, include your AppIntentsPackage here to make all its contents discoverable
    static var packages: [AppIntentsPackage.Type] {
        [CookingAppIntents.self]
    }
}
