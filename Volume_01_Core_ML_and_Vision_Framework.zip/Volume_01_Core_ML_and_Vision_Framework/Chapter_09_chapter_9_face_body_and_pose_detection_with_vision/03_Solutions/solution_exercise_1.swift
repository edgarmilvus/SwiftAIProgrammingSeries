
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import Vision
import CoreGraphics

// MARK: - FaceDetectionManager
class FaceDetectionManager {

    /// Processes a UIImage to detect faces, draw bounding boxes, and visualize landmarks.
    /// - Parameter image: The input UIImage to process.
    /// - Returns: A new UIImage with detected faces and landmarks annotated, or the original image if processing fails.
    func annotateFaces(in image: UIImage) async -> UIImage {
        guard let cgImage = image.cgImage else {
            print("Failed to get CGImage from UIImage.")
            return image
        }

        // Create a Vision image request handler.
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        // Create requests for face rectangles and landmarks.
        // VNDetectFaceRectanglesRequest can implicitly provide landmarks if VNDetectFaceLandmarksRequest is also in the array.
        let faceDetectionRequest = VNDetectFaceRectanglesRequest()
        let faceLandmarksRequest = VNDetectFaceLandmarksRequest()

        do {
            // Perform the requests.
            try handler.perform([faceDetectionRequest, faceLandmarksRequest])

            guard let faceObservations = faceDetectionRequest.results as? [VNFaceObservation] else {
                print("No face observations found.")
                return image
            }

            // Use UIGraphicsImageRenderer to draw on a copy of the image.
            let renderer = UIGraphicsImageRenderer(size: image.size)
            let annotatedImage = renderer.image { context in
                // Draw the original image first.
                image.draw(at: .zero)

                let cgContext = context.cgContext

                // Configure drawing styles.
                cgContext.setLineWidth(2.0)
                cgContext.setStrokeColor(UIColor.red.cgColor) // Bounding box color
                cgContext.setFillColor(UIColor.yellow.withAlphaComponent(0.3).cgColor) // Landmark fill color
                
                // Iterate through each detected face.
                for faceObservation in faceObservations {
                    // Convert Vision's normalized bounding box to UIKit's coordinate system.
                    // Vision origin is bottom-left, UIKit is top-left.
                    let boundingBox = faceObservation.boundingBox
                    let imageRect = CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height)
                    let convertedBoundingBox = VNImageRectForNormalizedRect(boundingBox, Int(image.size.width), Int(image.size.height))
                    
                    // Draw the bounding box.
                    cgContext.stroke(convertedBoundingBox)

                    // Visualize landmarks if available.
                    if let landmarks = faceObservation.landmarks {
                        // Draw contours for various facial features.
                        self.drawLandmark(landmarks.faceContour, in: cgContext, on: image.size)
                        self.drawLandmark(landmarks.leftEye, in: cgContext, on: image.size)
                        self.drawLandmark(landmarks.rightEye, in: cgContext, on: image.size)
                        self.drawLandmark(landmarks.nose, in: cgContext, on: image.size)
                        self.drawLandmark(landmarks.noseCrest, in: cgContext, on: image.size)
                        self.drawLandmark(landmarks.medianLine, in: cgContext, on: image.size)
                        self.drawLandmark(landmarks.outerLips, in: cgContext, on: image.size)
                        self.drawLandmark(landmarks.innerLips, in: cgContext, on: image.size)
                        self.drawLandmark(landmarks.leftEyebrow, in: cgContext, on: image.size)
                        self.drawLandmark(landmarks.rightEyebrow, in: cgContext, on: image.size)
                    }
                }
            }
            return annotatedImage

        } catch {
            print("Failed to perform Vision requests: \(error)")
            return image
        }
    }

    /// Helper function to draw a VNFaceLandmarkRegion2D onto a CGContext.
    /// - Parameters:
    ///   - landmarkRegion: The landmark region to draw.
    ///   - context: The Core Graphics context to draw on.
    ///   - imageSize: The size of the original image for coordinate conversion.
    private func drawLandmark(_ landmarkRegion: VNFaceLandmarkRegion2D?, in context: CGContext, on imageSize: CGSize) {
        guard let landmarkRegion = landmarkRegion else { return }

        context.setStrokeColor(UIColor.green.cgColor) // Landmark line color
        context.setFillColor(UIColor.blue.withAlphaComponent(0.2).cgColor) // Landmark fill color
        context.setLineWidth(1.0)

        // Create a path for the landmark region.
        let path = CGMutablePath()
        let points = landmarkRegion.normalizedPoints
        
        // Convert normalized Vision points to UIKit pixel coordinates and add to path.
        if !points.isEmpty {
            let firstPoint = VNImagePointForNormalizedPoint(points[0], Int(imageSize.width), Int(imageSize.size.height))
            path.move(to: firstPoint)

            for i in 1..<points.count {
                let point = VNImagePointForNormalizedPoint(points[i], Int(imageSize.width), Int(imageSize.size.height))
                path.addLine(to: point)
            }
            
            // Close the path for closed contours like eyes or lips.
            if landmarkRegion.isClosed {
                path.closeSubpath()
            }
        }

        context.addPath(path)
        context.drawPath(using: .fillStroke) // Fill and stroke the landmark path.
    }
}

// MARK: - Example Usage (for iOS)
/*
// Assume you have a UIImage named `inputImage`
let inputImage = UIImage(named: "your_image_with_faces")! // Replace with an actual image

Task {
    let faceDetectionManager = FaceDetectionManager()
    let annotatedImage = await faceDetectionManager.annotateFaces(in: inputImage)

    // Display `annotatedImage` in a UIImageView or save it.
    // For example:
    // myImageView.image = annotatedImage
}
*/

// MARK: - macOS Adaptation Notes
/*
For macOS, replace `UIImage` with `NSImage` and `UIGraphicsImageRenderer` with `NSGraphicsContext` or `NSImage`'s `lockFocus()` / `unlockFocus()` methods.
The `VNImageRectForNormalizedRect` and `VNImagePointForNormalizedPoint` functions work identically as they are part of the Vision framework.
Drawing with `CGContext` remains largely the same.
*/
