
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import AVFoundation

// Re-using CircularBuffer from Exercise 3

// MARK: - AI Event Data Model

@available(iOS 18.0, *)
enum AIEventType: String, CaseIterable, Identifiable {
    case speech, clap, music, silence, unknown
    var id: String { self.rawValue }

    var displayColor: Color {
        switch self {
        case .speech: return .green
        case .clap: return .red
        case .music: return .purple
        case .silence: return .gray
        case .unknown: return .orange
        }
    }
}

@available(iOS 18.0, *)
struct AIEvent: Identifiable {
    let id = UUID()
    let timestamp: Date // Absolute time of event start
    let duration: TimeInterval // Duration of the event
    let eventType: AIEventType
    let confidence: Float // 0.0 to 1.0

    var endTime: Date {
        timestamp.addingTimeInterval(duration)
    }
}

// MARK: - Audio Input Manager with AI Event Simulation and Time Tracking

@available(iOS 18.0, *)
class AudioInputManagerWithAI: ObservableObject {
    private let audioEngine = AVAudioEngine()
    private var inputNode: AVAudioInputNode!
    private var audioFormat: AVAudioFormat!

    @Published var waveformSamples: [Float] = [] // The current window of samples for display
    @Published var detectedEvents: [AIEvent] = []

    private var circularBuffer: CircularBuffer<Float>

    private let displaySampleCount: Int = 500 // Number of aggregated samples to display
    private let aggregationFactor: Int = 20  // Aggregate this many raw samples into one display point
    private var sampleRate: Double = 44100.0 // Default, will be updated from audioFormat

    // Time tracking for event synchronization
    @Published var latestSampleTime: Date = Date() // Approximate time of the *last* sample in waveformSamples
    var displayDuration: TimeInterval {
        // Calculate the actual duration represented by the displaySampleCount
        // This is the duration of the visible window
        return Double(displaySampleCount * aggregationFactor) / sampleRate
    }

    private var aiSimulationTimer: Timer?

    init() {
        self.circularBuffer = CircularBuffer(capacity: displaySampleCount)
        setupAudioSession()
        setupAudioEngine()
        simulateAIEvents()
    }

    private func setupAudioSession() {
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.playAndRecord, mode: .measurement, options: [.mixWithOthers, .allowBluetoothA2DP, .defaultToSpeaker])
            try audioSession.setActive(true)
        } catch {
            print("Failed to set up audio session: \(error.localizedDescription)")
        }
    }

    private func setupAudioEngine() {
        inputNode = audioEngine.inputNode
        audioFormat = inputNode.outputFormat(forBus: 0)
        sampleRate = audioFormat.sampleRate // Update actual sample rate

        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
            guard granted else {
                print("Microphone permission denied.")
                return
            }
            self?.installAudioTap()
        }
    }

    private func installAudioTap() {
        let bufferSize: AVAudioFrameCount = 1024
        inputNode.installTap(onBus: 0, bufferSize: bufferSize, format: audioFormat) { [weak self] buffer, _ in
            self?.processAudioBuffer(buffer)
        }
    }

    private func processAudioBuffer(_ buffer: AVAudioPCMBuffer) {
        guard let channelData = buffer.floatChannelData else { return }
        let samples = channelData[0]
        let frameLength = Int(buffer.frameLength)

        var newAggregatedSamples: [Float] = []
        for i in 0..<frameLength / aggregationFactor {
            var maxAmplitude: Float = 0.0
            for j in 0..<aggregationFactor {
                let sampleIndex = i * aggregationFactor + j
                guard sampleIndex < frameLength else { break }
                let sample = abs(samples[sampleIndex])
                if sample > maxAmplitude {
                    maxAmplitude = sample
                }
            }
            newAggregatedSamples.append(maxAmplitude)
        }

        DispatchQueue.main.async {
            // Update latestSampleTime based on when this buffer was processed
            // This is an approximation for visualization, a precise audio graph would use AVAudioTime
            self.latestSampleTime = Date()

            for sample in newAggregatedSamples {
                self.circularBuffer.append(sample)
            }
            self.waveformSamples = self.circularBuffer.elements
            
            // Filter out old events that are no longer visible
            let oldestVisibleTime = self.latestSampleTime.addingTimeInterval(-self.displayDuration)
            self.detectedEvents.removeAll { $0.endTime < oldestVisibleTime }
        }
    }

    private func simulateAIEvents() {
        aiSimulationTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            // Simulate an event occurring now, with random type, duration, and confidence
            let now = Date()
            let eventType = AIEventType.allCases.randomElement() ?? .unknown
            let duration = TimeInterval.random(in: 0.5...2.0)
            let confidence = Float.random(in: 0.6...0.99)

            let newEvent = AIEvent(timestamp: now, duration: duration, eventType: eventType, confidence: confidence)

            DispatchQueue.main.async {
                self.detectedEvents.append(newEvent)
                // Events are filtered in processAudioBuffer, but can also filter here
            }
        }
    }

    func start() {
        do {
            try audioEngine.start()
            print("Audio engine started.")
            aiSimulationTimer?.fire() // Start AI events when engine starts
        } catch {
            print("Error starting audio engine: \(error.localizedDescription)")
        }
    }

    func stop() {
        audioEngine.stop()
        inputNode.removeTap(onBus: 0)
        circularBuffer.removeAll()
        waveformSamples = []
        detectedEvents = [] // Clear events on stop
        aiSimulationTimer?.invalidate()
        aiSimulationTimer = nil
        print("Audio engine stopped and tap removed. AI simulation stopped.")
    }

    deinit {
        stop()
    }
}

// MARK: - Waveform View with AI Event Overlays (using Canvas)

@available(iOS 18.0, *)
struct WaveformWithAIEventsView: View {
    @ObservedObject var audioManager: AudioInputManagerWithAI
    var lineColor: Color = .blue
    var lineWidth: CGFloat = 2.0
    var isFilled: Bool = false
    var gradientFillStartColor: Color = .blue.opacity(0.8)
    var gradientFillEndColor: Color = .blue.opacity(0.2)

    @State private var currentVerticalScale: Float = 0.0 // For smooth scaling

    var body: some View {
        Canvas { context, size in
            guard !audioManager.waveformSamples.isEmpty else { return }

            let width = size.width
            let height = size.size.height
            let midY = height / 2

            // Calculate current time window based on the audio manager's published properties
            let latestSampleTime = audioManager.latestSampleTime
            let displayDuration = audioManager.displayDuration
            let oldestVisibleTime = latestSampleTime.addingTimeInterval(-displayDuration)

            // --- Draw Waveform (similar to Exercise 3) ---
            let maxAmplitude = audioManager.waveformSamples.max() ?? 0.01
            let targetVerticalScale = (maxAmplitude > 0.01) ? (height / 2) / maxAmplitude : 0.0
            
            if currentVerticalScale == 0.0 {
                currentVerticalScale = targetVerticalScale
            } else {
                let smoothingFactor: Float = 0.1
                currentVerticalScale = currentVerticalScale * (1 - smoothingFactor) + targetVerticalScale * smoothingFactor
            }
            
            var waveformPath = Path()
            waveformPath.move(to: CGPoint(x: 0, y: midY))
            for i in 0..<audioManager.waveformSamples.count {
                let x = CGFloat(i) / CGFloat(audioManager.waveformSamples.count - 1) * width
                let y = midY - CGFloat(audioManager.waveformSamples[i]) * CGFloat(currentVerticalScale)
                waveformPath.addLine(to: CGPoint(x: x, y: y))
            }
            
            if isFilled {
                waveformPath.addLine(to: CGPoint(x: width, y: midY))
                waveformPath.addLine(to: CGPoint(x: 0, y: midY))
                waveformPath.closeSubpath()
                context.fill(waveformPath, with: .linearGradient(
                    Gradient(colors: [gradientFillStartColor, gradientFillEndColor]),
                    startPoint: CGPoint(x: width / 2, y: 0),
                    endPoint: CGPoint(x: width / 2, y: height)
                ))
            } else {
                context.stroke(waveformPath, with: .color(lineColor), lineWidth: lineWidth)
            }

            // --- Draw AI Event Overlays ---
            for event in audioManager.detectedEvents {
                // Only draw events that are within the current display window
                guard event.timestamp < latestSampleTime && event.endTime > oldestVisibleTime else { continue }

                // Calculate start and end X positions for the event
                let eventStartTimeOffset = event.timestamp.timeIntervalSince(oldestVisibleTime)
                let eventEndTimeOffset = event.endTime.timeIntervalSince(oldestVisibleTime)

                let startX = CGFloat(eventStartTimeOffset / displayDuration) * width
                let endX = CGFloat(eventEndTimeOffset / displayDuration) * width

                // Ensure event is within bounds
                let clampedStartX = max(0, startX)
                let clampedEndX = min(width, endX)
                let eventWidth = clampedEndX - clampedStartX

                guard eventWidth > 0 else { continue } // Don't draw tiny events

                // Draw a colored rectangle for the event duration
                let eventRect = CGRect(x: clampedStartX, y: 0, width: eventWidth, height: height)
                context.fill(Path(eventRect), with: .color(event.eventType.displayColor.opacity(event.confidence * 0.3)))

                // Draw a marker line at the start of the event
                var markerPath = Path()
                markerPath.move(to: CGPoint(x: clampedStartX, y: 0))
                markerPath.addLine(to: CGPoint(x: clampedStartX, y: height))
                context.stroke(markerPath, with: .color(event.eventType.displayColor.opacity(event.confidence)), lineWidth: 1.5)

                // Draw text label for the event
                if eventWidth > 60 { // Only show label if there's enough space
                    let text = Text("\(event.eventType.rawValue.capitalized) \(Int(event.confidence * 100))%")
                        .font(.caption2)
                        .foregroundColor(.white)
                    context.draw(text, at: CGPoint(x: clampedStartX + 5, y: height - 20), anchor: .leading)
                }
            }
        }
        .frame(height: 150)
        .background(Color.black.opacity(0.8))
        .cornerRadius(8)
    }
}

// MARK: - Main Content View for Exercise 4 (Smart Audio Journal Feature)

@available(iOS 18.0, *)
struct ContentView_Exercise4: View {
    @StateObject private var audioManager = AudioInputManagerWithAI()
    @State private var isRecording = false

    // Customization states
    @State private var lineColor: Color = .blue
    @State private var lineWidth: CGFloat = 2.0
    @State private var isFilled: Bool = true
    @State private var gradientStartColor: Color = .blue.opacity(0.8)
    @State private var gradientEndColor: Color = .blue.opacity(0.2)

    var body: some View {
        VStack {
            Text("Smart Audio Journal")
                .font(.largeTitle)
                .padding(.bottom, 5)
            Text("AI Event Annotations")
                .font(.title2)
                .foregroundColor(.gray)
                .padding(.bottom)

            WaveformWithAIEventsView(
                audioManager: audioManager,
                lineColor: lineColor,
                lineWidth: lineWidth,
                isFilled: isFilled,
                gradientFillStartColor: gradientStartColor,
                gradientFillEndColor: gradientEndColor
            )
            .padding()

            Button(action: toggleRecording) {
                Label(isRecording ? "Stop Journaling" : "Start Journaling", systemImage: isRecording ? "stop.fill" : "mic.fill")
                    .font(.title2)
                    .padding()
                    .background(isRecording ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(15)
            }
            .padding()
        }
        .onAppear {
            // audioManager.start() // Optional: start automatically
        }
        .onDisappear {
            audioManager.stop()
        }
    }

    private func toggleRecording() {
        if isRecording {
            audioManager.stop()
        } else {
            audioManager.start()
        }
        isRecording.toggle()
    }
}
