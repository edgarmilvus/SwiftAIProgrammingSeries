
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import MLX
import MLXNN

@available(iOS 18.0, macOS 15.0, *)
class SimplifiedTextEncoder: MLXNN.Module {
    let embedding: MLXNN.Embedding
    let transformerBlock: MLXNN.TransformerEncoderLayer
    let projection: MLXNN.Linear

    init(vocabSize: Int, embeddingDim: Int, numHeads: Int, ffnDim: Int, outputDim: Int) {
        self.embedding = MLXNN.Embedding(outputDimensions: embeddingDim, vocabularySize: vocabSize)
        self.transformerBlock = MLXNN.TransformerEncoderLayer(
            dimensions: embeddingDim,
            numHeads: numHeads,
            feedForwardDimensions: ffnDim
        )
        self.projection = MLXNN.Linear(inputDimensions: embeddingDim, outputDimensions: outputDim)
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // input: [batch_size, sequence_length]
        let embedded = embedding(input) // [batch_size, sequence_length, embedding_dim]
        let encoded = transformerBlock(embedded) // [batch_size, sequence_length, embedding_dim]

        // Pool the sequence output (e.g., mean pooling over the sequence length axis)
        let pooled = MLX.mean(encoded, axis: [1]) // [batch_size, embedding_dim]

        // Project to the final output dimension
        return projection(pooled) // [batch_size, output_dim]
    }
}

@available(iOS 18.0, macOS 15.0, *)
class SimplifiedImageEncoder: MLXNN.Module {
    let conv1: MLXNN.Conv2d
    let conv2: MLXNN.Conv2d
    let linear: MLXNN.Linear

    init(inputChannels: Int, hiddenChannels: Int, outputDim: Int, imageHeight: Int, imageWidth: Int) {
        self.conv1 = MLXNN.Conv2d(
            inputChannels: inputChannels,
            outputChannels: hiddenChannels,
            kernelSize: 3,
            padding: 1
        )
        self.conv2 = MLXNN.Conv2d(
            inputChannels: hiddenChannels,
            outputChannels: hiddenChannels * 2,
            kernelSize: 3,
            padding: 1
        )
        // Calculate the flattened size after two max pools (2x2 kernel, stride 2)
        let finalSpatialHeight = imageHeight / 4
        let finalSpatialWidth = imageWidth / 4
        let finalChannels = hiddenChannels * 2
        self.linear = MLXNN.Linear(inputDimensions: finalChannels * finalSpatialHeight * finalSpatialWidth, outputDimensions: outputDim)
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // input: [batch_size, channels, height, width]
        var x = MLX.relu(conv1(input))
        x = MLX.maxPool2d(x, kernelSize: 2, stride: 2)

        x = MLX.relu(conv2(x))
        x = MLX.maxPool2d(x, kernelSize: 2, stride: 2)

        let batchSize = x.dim[0]
        let flattened = MLX.flatten(x, start: 1) // [batch_size, total_features_per_image]

        return linear(flattened) // [batch_size, output_dim]
    }
}

// MARK: - Weight Conversion, Multi-Modal Inference, and Similarity Calculation

@available(iOS 18.0, macOS 15.0, *)
func runMultiModalEmbeddingExercise() {
    print("\n--- Exercise 4: Multi-Modal Embedding for Product Search ---")

    // Model Hyperparameters
    let embeddingDim = 128 // Shared embedding space dimension
    
    // Text Encoder params
    let textVocabSize = 5000
    let textEmbeddingDim = 256
    let textNumHeads = 4
    let textFfnDim = 512
    let textSequenceLength = 15

    // Image Encoder params
    let imageInputChannels = 3
    let imageHiddenChannels = 64
    let imageHeight = 64
    let imageWidth = 64

    let batchSize = 1 // For similarity, usually one text and one image at a time

    // 1. Instantiate `SimplifiedTextEncoder` and `SimplifiedImageEncoder`
    let textEncoder = SimplifiedTextEncoder(
        vocabSize: textVocabSize,
        embeddingDim: textEmbeddingDim,
        numHeads: textNumHeads,
        ffnDim: textFfnDim,
        outputDim: embeddingDim // Output to shared embedding space
    )
    let imageEncoder = SimplifiedImageEncoder(
        inputChannels: imageInputChannels,
        hiddenChannels: imageHiddenChannels,
        outputDim: embeddingDim, // Output to shared embedding space
        imageHeight: imageHeight,
        imageWidth: imageWidth
    )
    print("Text and Image Encoders instantiated.")

    // 2. Create dummy HuggingFace-like weights for both encoders
    var hfWeights: [String: MLXArray] = [:]

    // Text Encoder Weights (prefixed with "text_model.")
    hfWeights["text_model.embeddings.word_embeddings.weight"] = MLXArray.rand([textVocabSize, textEmbeddingDim], .float32)
    hfWeights["text_model.encoder.layer.0.attention.self.query.weight"] = MLXArray.rand([textEmbeddingDim, textEmbeddingDim], .float32)
    hfWeights["text_model.encoder.layer.0.attention.self.query.bias"] = MLXArray.rand([textEmbeddingDim], .float32)
    hfWeights["text_model.encoder.layer.0.attention.output.dense.weight"] = MLXArray.rand([textEmbeddingDim, textEmbeddingDim], .float32)
    hfWeights["text_model.encoder.layer.0.attention.output.dense.bias"] = MLXArray.rand([textEmbeddingDim], .float32)
    hfWeights["text_model.encoder.layer.0.attention.output.LayerNorm.weight"] = MLXArray.rand([textEmbeddingDim], .float32)
    hfWeights["text_model.encoder.layer.0.attention.output.LayerNorm.bias"] = MLXArray.rand([textEmbeddingDim], .float32)
    hfWeights["text_model.projection.weight"] = MLXArray.rand([embeddingDim, textEmbeddingDim], .float32)
    hfWeights["text_model.projection.bias"] = MLXArray.rand([embeddingDim], .float32)

    // Image Encoder Weights (prefixed with "vision_model.")
    hfWeights["vision_model.features.0.weight"] = MLXArray.rand([imageHiddenChannels, imageInputChannels, 3, 3], .float32)
    hfWeights["vision_model.features.0.bias"] = MLXArray.rand([imageHiddenChannels], .float32)
    hfWeights["vision_model.features.3.weight"] = MLXArray.rand([imageHiddenChannels * 2, imageHiddenChannels, 3, 3], .float32)
    hfWeights["vision_model.features.3.bias"] = MLXArray.rand([imageHiddenChannels * 2], .float32)
    let finalSpatialSizeImage = (imageHeight / 4) * (imageWidth / 4)
    let finalChannelsImage = imageHiddenChannels * 2
    let linearInputDimImage = finalChannelsImage * finalSpatialSizeImage
    hfWeights["vision_model.classifier.6.weight"] = MLXArray.rand([embeddingDim, linearInputDimImage], .float32)
    hfWeights["vision_model.classifier.6.bias"] = MLXArray.rand([embeddingDim], .float32)
    
    print("Simulated HuggingFace weights created. Total: \(hfWeights.count) tensors.")

    // 3. Implement Cross-Modal Weight Conversion
    // Text Encoder mapping
    textEncoder.embedding.weight = hfWeights["text_model.embeddings.word_embeddings.weight"]!
    textEncoder.transformerBlock.selfAttention.query.weight = hfWeights["text_model.encoder.layer.0.attention.self.query.weight"]!.transposed()
    textEncoder.transformerBlock.selfAttention.query.bias = hfWeights["text_model.encoder.layer.0.attention.self.query.bias"]!
    // ... (map other transformerBlock weights as in Exercise 1, simplified here)
    textEncoder.transformerBlock.selfAttention.output.weight = hfWeights["text_model.encoder.layer.0.attention.output.dense.weight"]!.transposed()
    textEncoder.transformerBlock.selfAttention.output.bias = hfWeights["text_model.encoder.layer.0.attention.output.dense.bias"]!
    textEncoder.transformerBlock.norm1.weight = hfWeights["text_model.encoder.layer.0.attention.output.LayerNorm.weight"]!
    textEncoder.transformerBlock.norm1.bias = hfWeights["text_model.encoder.layer.0.attention.output.LayerNorm.bias"]!
    // For simplicity, skip FFN and norm2 mapping here, but would be similar to Ex1
    textEncoder.projection.weight = hfWeights["text_model.projection.weight"]!.transposed()
    textEncoder.projection.bias = hfWeights["text_model.projection.bias"]!

    // Image Encoder mapping
    imageEncoder.conv1.weight = hfWeights["vision_model.features.0.weight"]!.permuted(2, 3, 1, 0)
    imageEncoder.conv1.bias = hfWeights["vision_model.features.0.bias"]!
    imageEncoder.conv2.weight = hfWeights["vision_model.features.3.weight"]!.permuted(2, 3, 1, 0)
    imageEncoder.conv2.bias = hfWeights["vision_model.features.3.bias"]!
    imageEncoder.linear.weight = hfWeights["vision_model.classifier.6.weight"]!.transposed()
    imageEncoder.linear.bias = hfWeights["vision_model.classifier.6.bias"]!
    
    print("Weights successfully converted and loaded into both MLX Swift encoders.")

    // 4. Perform Multi-Modal Inference
    // Dummy text input: [batch_size, sequence_length]
    let dummyTextInput = MLXArray.rand([batchSize, textSequenceLength], .int32) * MLXArray(textVocabSize)
    // Dummy image input: [batch_size, channels, height, width]
    let dummyImageInput = MLXArray.rand([batchSize, imageInputChannels, imageHeight, imageWidth], .float32)
    MLX.eval(dummyTextInput, dummyImageInput)

    print("\nDummy text input shape: \(dummyTextInput.shape)")
    print("Dummy image input shape: \(dummyImageInput.shape)")

    let textEmbedding = textEncoder(dummyTextInput)
    let imageEmbedding = imageEncoder(dummyImageInput)
    MLX.eval(textEmbedding, imageEmbedding) // Force computation of embeddings

    print("\nText embedding shape: \(textEmbedding.shape)")
    print("Image embedding shape: \(imageEmbedding.shape)")
    print("Text embedding (first item): \(textEmbedding[0])")
    print("Image embedding (first item): \(imageEmbedding[0])")

    // 5. Calculate Cosine Similarity
    // Normalize embeddings to unit length
    let normalizedTextEmbedding = MLX.normalize(textEmbedding, axis: -1)
    let normalizedImageEmbedding = MLX.normalize(imageEmbedding, axis: -1)
    MLX.eval(normalizedTextEmbedding, normalizedImageEmbedding)

    // Compute dot product (cosine similarity)
    // For batch_size=1, this will be a scalar. For batch_size > 1, it's a [batch_size, batch_size] matrix
    // if comparing all text embeddings against all image embeddings.
    // Here, we compare corresponding items in the batch.
    let similarity = MLX.sum(normalizedTextEmbedding * normalizedImageEmbedding, axis: -1)
    MLX.eval(similarity)

    print("\nCosine Similarity between text and image embeddings: \(similarity.item(Float.self))")
    // (Note: Since dummy data is random, the similarity will likely be low and close to 0)

    print("--- End Exercise 4 ---")
}

// Call the function to run the exercise
// runMultiModalEmbeddingExercise() // Uncomment to run in a playground or main.swift
