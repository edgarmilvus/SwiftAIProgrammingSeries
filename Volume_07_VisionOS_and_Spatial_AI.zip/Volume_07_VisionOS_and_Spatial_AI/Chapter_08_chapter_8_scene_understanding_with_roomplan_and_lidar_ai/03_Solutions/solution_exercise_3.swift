
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import RealityKit
import ARKit

struct SemanticPlacerView: View {
    var body: some View {
        ARViewContainer()
            .edgesIgnoringSafeArea(.all)
    }
}

struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        
        // Setup configuration
        let config = ARWorldTrackingConfiguration()
        config.sceneReconstruction = .meshWithClassification
        arView.session.run(config)
        
        // Add Tap Gesture
        let tapGesture = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap(_:)))
        arView.addGestureRecognizer(tapGesture)
        
        context.coordinator.arView = arView
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }
    
    class Coordinator: NSObject {
        weak var arView: ARView?
        
        @objc func handleTap(_ recognizer: UITapGestureRecognizer) {
            guard let arView = arView else { return }
            let tapLocation = recognizer.location(in: arView)
            
            // 1. Perform Raycast
            // We use raycast to find the intersection with the reconstructed mesh
            let results = arView.raycast(from: tapLocation, allowing: .estimatedPlane, alignment: .any)
            
            if let firstResult = results.first {
                placeObject(at: firstResult)
            }
        }
        
        private func placeObject(at result: ARRaycastResult) {
            guard let arView = arView else { return }
            
            // 2. Determine Semantic Type via Classification
            // In a real RoomPlan implementation, we'd check the CapturedRoom model.
            // Here, we use the ARMeshAnchor classification.
            let isWall = result.anchor is ARMeshAnchor && 
                         (result.worldTransform.columns.1.y < -0.9 || result.worldTransform.columns.1.y > 0.9) 
                         // Simplified: check verticality of the normal
            
            let entity: ModelEntity
            
            if isWall {
                // Place "Painting"
                entity = ModelEntity(mesh: .generateBox(size: [0.4, 0.3, 0.02]), materials: [SimpleMaterial(color: .brown, isMetallic: false)])
                
                // 3. Orientation Logic: Ensure it faces the user and is flush to the wall
                let transform = result.worldTransform
                // The wall normal is the Y-axis of the transform in many ARKit raycasts
                entity.setTransformMatrix(transform, relativeTo: nil)
            } else {
                // Place "Chair"
                entity = ModelEntity(mesh: .generateBox(size: [0.4, 0.5, 0.4]), materials: [SimpleMaterial(color: .gray, isMetallic: false)])
                
                // 4. Constraint Logic: Ensure it is upright on the floor
                var floorTransform = result.worldTransform
                floorTransform.columns.1 = [0, 1, 0, 0] // Force the Up vector to be Y-up
                entity.setTransformMatrix(floorTransform, relativeTo: nil)
            }
            
            let anchorEntity = AnchorEntity(world: result.worldTransform)
            anchorEntity.addChild(entity)
            arView.scene.addAnchor(anchorEntity)
        }
    }
}
