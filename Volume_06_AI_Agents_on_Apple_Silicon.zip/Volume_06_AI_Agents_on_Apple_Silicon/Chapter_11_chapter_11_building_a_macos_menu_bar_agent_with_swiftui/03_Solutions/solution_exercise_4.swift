
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

// PopoverRootView.swift (Updated for Exercise 3)
import SwiftUI

struct PopoverRootView: View {
    @Binding var isPopoverShown: Bool

    @State private var topic: String = ""
    @State private var generatedIdeas: [String] = []
    @State private var isLoading: Bool = false
    @State private var isDarkMode: Bool = false // Kept from Exercise 2

    var body: some View {
        VStack(spacing: 15) {
            Text("Brainstormer: Quick Idea Generator")
                .font(.headline)
                .padding(.bottom, 5)

            // Topic Input
            TextField("Enter a topic (e.g., 'app ideas')", text: $topic)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
                .frame(width: 220)

            // Generate Ideas Button
            Button("Generate Ideas") {
                generateIdeas()
            }
            .padding(.horizontal)
            .buttonStyle(.borderedProminent)
            .disabled(topic.isEmpty || isLoading) // Disable if topic is empty or loading

            // Loading Indicator
            if isLoading {
                ProgressView("Generating...")
                    .progressViewStyle(.circular)
                    .padding(.vertical, 10)
            }

            // Generated Ideas Display
            if generatedIdeas.isEmpty && !isLoading {
                Spacer() // Push content up if no ideas and not loading
                Text("Enter a topic and generate ideas.")
                    .font(.caption)
                    .foregroundColor(.gray)
                    .padding(.horizontal)
            } else if !generatedIdeas.isEmpty {
                ScrollView {
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(generatedIdeas, id: \.self) { idea in
                            Text("• \(idea)")
                                .font(.subheadline)
                        }
                    }
                    .padding(.horizontal)
                }
                .frame(maxHeight: 150) // Constrain scroll view height
                .border(Color.gray.opacity(0.3), width: 1) // Optional: Add a border
                .cornerRadius(5)
                .padding(.horizontal)
            }
            
            // Toggle for Dark Mode (from Exercise 2)
            Toggle(isOn: $isDarkMode) {
                Text("Dark Mode")
            }
            .toggleStyle(.switch)
            .padding(.horizontal)
            .frame(width: 220, alignment: .leading)
            .padding(.top, 5)

            Spacer()

            Button("Dismiss") {
                isPopoverShown = false
            }
            .buttonStyle(.bordered)
            .tint(isDarkMode ? .white : .accentColor)
        }
        .padding()
        .frame(width: 280, height: 400) // Adjust popover size for more content
        .background(isDarkMode ? Color.black.opacity(0.9) : Color.white)
        .foregroundColor(isDarkMode ? Color.white : Color.black)
        .cornerRadius(10)
    }

    // MARK: - Simulated LLM Logic
    private func generateIdeas() {
        isLoading = true
        generatedIdeas = [] // Clear previous ideas

        Task {
            // Simulate an asynchronous LLM call
            await Task.sleep(for: .seconds(3)) // 3-second delay

            let topicLowercased = topic.lowercased()
            var ideas: [String] = []

            if topicLowercased.contains("app") {
                ideas = [
                    "AI-powered recipe generator with ingredient scanner",
                    "Personalized study planner with smart reminders",
                    "Smart home automation dashboard for custom routines",
                    "Voice-controlled journal for daily reflections",
                    "Collaborative brainstorming tool with mind mapping"
                ]
            } else if topicLowercased.contains("marketing") {
                ideas = [
                    "Interactive AR product showcases for e-commerce",
                    "Hyper-personalized email campaigns using LLMs",
                    "Gamified loyalty programs for customer engagement",
                    "Micro-influencer discovery platform",
                    "AI-driven content calendar and generation"
                ]
            } else if topicLowercased.contains("food") || topicLowercased.contains("recipe") {
                ideas = [
                    "AI sous-chef suggesting recipes based on fridge contents",
                    "Meal prep planner with nutritional tracking",
                    "Virtual cooking classes with real-time feedback",
                    "Food waste reduction app with smart inventory",
                    "Subscription box for exotic ingredients"
                ]
            } else {
                ideas = [
                    "A new concept for sustainable urban farming.",
                    "Innovative solutions for remote team collaboration.",
                    "Personalized learning paths for skill development.",
                    "Interactive storytelling platform.",
                    "Eco-friendly product design challenges."
                ]
            }

            // Update UI on the main actor
            await MainActor.run {
                self.generatedIdeas = ideas
                self.isLoading = false
            }
        }
    }
}
