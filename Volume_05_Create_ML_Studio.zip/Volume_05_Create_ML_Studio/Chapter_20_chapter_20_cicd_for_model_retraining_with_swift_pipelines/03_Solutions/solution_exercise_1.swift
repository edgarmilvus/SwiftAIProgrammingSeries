
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// PlantClassifierTrainer.swift

import Foundation
import CreateML // Ensure CreateML is available in your build environment

@available(macOS 15.0, *) // Create ML APIs often require recent macOS versions
@main
struct PlantClassifierTrainer {
    static func main() async {
        // MARK: - Configuration
        // IMPORTANT: Replace these paths with actual directories on your system.
        // Example structure:
        // /Users/youruser/PlantData/training/Rose/rose_1.jpg
        // /Users/youruser/PlantData/validation/Rose/rose_test_1.jpg
        let trainingDataPath = URL(fileURLWithPath: "/Users/youruser/PlantData/training")
        let validationDataPath = URL(fileURLWithPath: "/Users/youruser/PlantData/validation")
        let outputDirectory = URL(fileURLWithPath: "/Users/youruser/PlantModels")

        let fileManager = FileManager.default

        // MARK: - Setup Output Directory
        if !fileManager.fileExists(atPath: outputDirectory.path) {
            do {
                print("Creating output directory: \(outputDirectory.path)")
                try fileManager.createDirectory(at: outputDirectory, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print("Error creating output directory: \(error.localizedDescription)")
                return
            }
        }

        do {
            // MARK: - Load Data
            print("Loading training data from: \(trainingDataPath.path)")
            let trainingData = try MLImageClassifier.DataSource.labeledDirectories(at: trainingDataPath)
            print("Successfully loaded training data.")

            print("Loading validation data from: \(validationDataPath.path)")
            let validationData = try MLImageClassifier.DataSource.labeledDirectories(at: validationDataPath)
            print("Successfully loaded validation data.")

            // MARK: - Train Model
            print("Starting MLImageClassifier training...")
            let classifier = try await MLImageClassifier(trainingData: trainingData, validationData: validationData)
            print("Model training complete.")

            // MARK: - Basic Evaluation
            let trainingMetrics = classifier.evaluation(on: trainingData)
            let validationMetrics = classifier.evaluation(on: validationData)

            print("\n--- Model Evaluation ---")
            print("Training Accuracy: \(String(format: "%.2f", trainingMetrics.accuracy * 100))%")
            print("Validation Accuracy: \(String(format: "%.2f", validationMetrics.accuracy * 100))%")
            print("------------------------\n")

            // MARK: - Save Model
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyyMMdd_HHmmss"
            let timestamp = dateFormatter.string(from: Date())
            let modelFileName = "PlantClassifier_\(timestamp).mlmodel"
            let modelOutputURL = outputDirectory.appendingPathComponent(modelFileName)

            print("Saving model to: \(modelOutputURL.path)")
            try classifier.write(to: modelOutputURL)
            print("Model saved successfully as \(modelFileName).")

        } catch {
            // MARK: - Error Handling
            print("An error occurred during model training or saving: \(error.localizedDescription)")
            // More detailed error logging could be added here based on specific error types
            if let mlError = error as? MLCError {
                print("Create ML Error Code: \(mlError.errorCode)")
                print("Create ML Error Domain: \(mlError.errorDomain)")
            }
        }
    }
}
