
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet for demonstrating dependencies.
// In a real project, CreateML and CoreML are system frameworks.
// This is illustrative of how one might declare other Swift Package Manager dependencies.
/*
// swift-tools-version:6.0
import PackageDescription

let package = Package(
    name: "SmartDocumentScannerML",
    platforms: [
        .iOS(.v18),
        .macOS(.v15)
    ],
    products: [
        .library(
            name: "SmartDocumentScannerML",
            targets: ["SmartDocumentScannerML"]),
    ],
    dependencies: [
        // Example of a hypothetical utility package for image processing or data handling
        // .package(url: "https://github.com/apple/swift-algorithms", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "SmartDocumentScannerML",
            dependencies: []), // CreateML and CoreML are linked system frameworks
        .testTarget(
            name: "SmartDocumentScannerMLTests",
            dependencies: ["SmartDocumentScannerML"]),
    ]
)
*/

import Foundation
import CreateML
import CoreML // For loading and evaluating the trained model

// MARK: - 1. Custom Error Handling

/// Custom error types for the document classification training process.
enum DocumentClassifierError: Error, LocalizedError {
    case invalidDataDirectory(URL)
    case noTrainingDataFound(URL)
    case dataSplittingFailed(String)
    case modelTrainingFailed(String)
    case modelEvaluationFailed(String)
    case fileOperationFailed(String)
    case invalidModelURL
    case modelNotFound(URL)

    var errorDescription: String? {
        switch self {
        case .invalidDataDirectory(let url):
            return "The provided data directory URL is invalid or inaccessible: \(url.path)"
        case .noTrainingDataFound(let url):
            return "No image data found in the directory: \(url.path). Ensure subdirectories represent labels."
        case .dataSplittingFailed(let reason):
            return "Failed to split data for cross-validation: \(reason)"
        case .modelTrainingFailed(let reason):
            return "Model training failed: \(reason)"
        case .modelEvaluationFailed(let reason):
            return "Model evaluation failed: \(reason)"
        case .fileOperationFailed(let reason):
            return "File operation failed: \(reason)"
        case .invalidModelURL:
            return "Invalid URL provided for model operations."
        case .modelNotFound(let url):
            return "Model not found at the specified URL: \(url.path)"
        }
    }
}

// MARK: - 2. Hyperparameter Definition

/// Defines a set of hyperparameters (in this context, data augmentation strategies)
/// for an MLImageClassifier.
struct HyperparameterSet: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let augmentationParameters: MLImageClassifier.ModelParameters.ImageAugmentationOptions

    /// Initializes a new hyperparameter set.
    /// - Parameters:
    ///   - name: A descriptive name for this set (e.g., "Aggressive Augmentation").
    ///   - rotation: The maximum rotation angle for augmentation.
    ///   - flip: Whether to apply horizontal and/or vertical flips.
    ///   - crop: Whether to apply random cropping.
    ///   - blur: Whether to apply random blurring.
    ///   - exposure: Whether to adjust exposure.
    ///   - noise: Whether to add random noise.
    init(name: String,
         rotation: Double = 0,
         flip: MLImageClassifier.ModelParameters.ImageAugmentationOptions.Flip = [],
         crop: MLImageClassifier.ModelParameters.ImageAugmentationOptions.Crop = [],
         blur: Bool = false,
         exposure: Bool = false,
         noise: Bool = false) {
        self.name = name
        var options: MLImageClassifier.ModelParameters.ImageAugmentationOptions = []
        if rotation > 0 { options.insert(.rotation(maximumAngle: rotation)) }
        if !flip.isEmpty { options.insert(.flip(flip)) }
        if !crop.isEmpty { options.insert(.crop(crop)) }
        if blur { options.insert(.blur) }
        if exposure { options.insert(.exposure) }
        if noise { options.insert(.noise) }
        self.augmentationParameters = options
    }

    /// Creates MLImageClassifier.ModelParameters from this hyperparameter set.
    var modelParameters: MLImageClassifier.ModelParameters {
        .init(imageAugmentationOptions: augmentationParameters)
    }
}

// MARK: - 3. DocumentClassifierTrainer Class

/// Manages the training and evaluation of MLImageClassifier models for document classification.
/// Incorporates k-fold cross-validation and hyperparameter tuning (via augmentation strategies).
@available(iOS 18.0, macOS 15.0, *) // CreateML updates often align with OS releases
class DocumentClassifierTrainer {

    private let fileManager = FileManager.default
    private let outputDirectory: URL

    /// Initializes the trainer with an output directory for models and temporary files.
    /// - Parameter outputDirectory: The URL where trained models and intermediate results will be saved.
    init(outputDirectory: URL) {
        self.outputDirectory = outputDirectory
    }

    /// Prepares data for a specific fold in k-fold cross-validation.
    /// This function assumes the data is organized in subdirectories, where each subdirectory name is a label.
    /// Example: `dataRoot/Invoice/img1.jpg`, `dataRoot/Receipt/img2.png`
    /// - Parameters:
    ///   - dataRootURL: The root URL containing all labeled image data.
    ///   - kFolds: The total number of folds for cross-validation.
    ///   - currentFoldIndex: The zero-based index of the current fold to prepare.
    /// - Returns: A tuple containing the training data (URL to label mapping) and testing data.
    /// - Throws: `DocumentClassifierError` if data cannot be prepared.
    private func prepareFoldData(dataRootURL: URL, kFolds: Int, currentFoldIndex: Int) async throws -> (training: [URL: String], testing: [URL: String]) {
        guard fileManager.fileExists(atPath: dataRootURL.path) else {
            throw DocumentClassifierError.invalidDataDirectory(dataRootURL)
        }

        var allLabeledData: [URL: String] = [:]
        let enumerator = fileManager.enumerator(at: dataRootURL, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsPackageDescendants, .skipsHiddenFiles])

        // Collect all image files and their labels
        guard let subdirectories = try? fileManager.contentsOfDirectory(at: dataRootURL, includingPropertiesForKeys: nil, options: .skipsSubdirectoryDescendants) else {
            throw DocumentClassifierError.invalidDataDirectory(dataRootURL)
        }

        for labelDirURL in subdirectories where labelDirURL.hasDirectoryPath {
            let label = labelDirURL.lastPathComponent // Directory name is the label
            let imageFiles = try fileManager.contentsOfDirectory(at: labelDirURL, includingPropertiesForKeys: nil, options: .skipsSubdirectoryDescendants)
                .filter { $0.pathExtension.lowercased() == "jpg" || $0.pathExtension.lowercased() == "png" || $0.pathExtension.lowercased() == "jpeg" }
            for fileURL in imageFiles {
                allLabeledData[fileURL] = label
            }
        }

        guard !allLabeledData.isEmpty else {
            throw DocumentClassifierError.noTrainingDataFound(dataRootURL)
        }

        // Shuffle and split data for the current fold
        let shuffledData = allLabeledData.shuffled()
        let foldSize = shuffledData.count / kFolds
        let testStartIndex = currentFoldIndex * foldSize
        let testEndIndex = (currentFoldIndex == kFolds - 1) ? shuffledData.count : (testStartIndex + foldSize)

        let testingDataArray = Array(shuffledData[testStartIndex..<testEndIndex])
        let trainingDataArray = Array(shuffledData[0..<testStartIndex] + shuffledData[testEndIndex..<shuffledData.count])

        let trainingData = Dictionary(uniqueKeysWithValues: trainingDataArray)
        let testingData = Dictionary(uniqueKeysWithValues: testingDataArray)

        print("Fold \(currentFoldIndex + 1)/\(kFolds): Training with \(trainingData.count) samples, Testing with \(testingData.count) samples.")
        return (trainingData, testingData)
    }

    /// Trains an `MLImageClassifier` model.
    /// - Parameters:
    ///   - trainingData: A dictionary where keys are image URLs and values are their corresponding labels.
    ///   - parameters: The `MLImageClassifier.ModelParameters` to use for training.
    ///   - outputURL: The URL where the trained `.mlmodel` file will be saved.
    /// - Returns: The URL of the saved `.mlmodel` file.
    /// - Throws: `DocumentClassifierError` if training fails.
    private func trainModel(trainingData: [URL: String], parameters: MLImageClassifier.ModelParameters, outputURL: URL) async throws -> URL {
        print("Starting model training for \(outputURL.lastPathComponent)...")
        do {
            let data = try MLImageClassifier.DataSource.labeledDirectories(trainingData.keys.map { $0.deletingLastPathComponent().deletingLastPathComponent() }.first!)
            // CreateML's labeledDirectories expects a root URL containing label subdirectories.
            // This is a simplification assuming all trainingData URLs come from a single root.
            // For more complex scenarios, you might need to create temporary labeled directories.
            // A more robust approach:
            var temporaryTrainingDataDir: URL?
            do {
                temporaryTrainingDataDir = try fileManager.url(for: .itemReplacementDirectory, in: .userDomainMask, appropriateFor: outputURL, create: true)
                for (imageURL, label) in trainingData {
                    let labelDir = temporaryTrainingDataDir!.appendingPathComponent(label)
                    try fileManager.createDirectory(at: labelDir, withIntermediateDirectories: true, attributes: nil)
                    let destinationURL = labelDir.appendingPathComponent(imageURL.lastPathComponent)
                    try fileManager.copyItem(at: imageURL, to: destinationURL)
                }
                let data = MLImageClassifier.DataSource.labeledDirectories(at: temporaryTrainingDataDir!)
                let model = try await MLImageClassifier(trainingData: data, parameters: parameters)
                try model.write(to: outputURL)
                print("Model trained and saved to \(outputURL.path)")
                return outputURL
            } finally {
                if let tempDir = temporaryTrainingDataDir {
                    try? fileManager.removeItem(at: tempDir) // Clean up temporary data
                }
            }
        } catch {
            throw DocumentClassifierError.modelTrainingFailed("Error: \(error.localizedDescription)")
        }
    }

    /// Evaluates a trained `MLImageClassifier` model.
    /// - Parameters:
    ///   - modelURL: The URL of the `.mlmodel` file to evaluate.
    ///   - testingData: A dictionary where keys are image URLs and values are their true labels.
    /// - Returns: An `MLClassifierMetrics` object containing accuracy, precision, recall, etc.
    /// - Throws: `DocumentClassifierError` if evaluation fails.
    private func evaluateModel(modelURL: URL, testingData: [URL: String]) async throws -> MLClassifierMetrics {
        print("Evaluating model at \(modelURL.lastPathComponent)...")
        guard fileManager.fileExists(atPath: modelURL.path) else {
            throw DocumentClassifierError.modelNotFound(modelURL)
        }
        do {
            let model = try MLModel(contentsOf: modelURL)
            let classifier = try MLImageClassifier(mlModel: model)

            // CreateML's evaluation expects a data source. We need to convert our testingData
            // into a format compatible with MLImageClassifier.DataSource.
            // A robust way is to create a temporary directory structure for evaluation.
            var temporaryEvaluationDataDir: URL?
            do {
                temporaryEvaluationDataDir = try fileManager.url(for: .itemReplacementDirectory, in: .userDomainMask, appropriateFor: modelURL, create: true)
                for (imageURL, label) in testingData {
                    let labelDir = temporaryEvaluationDataDir!.appendingPathComponent(label)
                    try fileManager.createDirectory(at: labelDir, withIntermediateDirectories: true, attributes: nil)
                    let destinationURL = labelDir.appendingPathComponent(imageURL.lastPathComponent)
                    try fileManager.copyItem(at: imageURL, to: destinationURL)
                }
                let evaluationDataSource = MLImageClassifier.DataSource.labeledDirectories(at: temporaryEvaluationDataDir!)
                let metrics = classifier.evaluation(on: evaluationDataSource)
                print("Model evaluation complete for \(modelURL.lastPathComponent). Accuracy: \(metrics.accuracy)")
                return metrics
            } finally {
                if let tempDir = temporaryEvaluationDataDir {
                    try? fileManager.removeItem(at: tempDir) // Clean up temporary data
                }
            }
        } catch {
            throw DocumentClassifierError.modelEvaluationFailed("Error: \(error.localizedDescription)")
        }
    }

    /// Performs k-fold cross-validation across multiple hyperparameter sets.
    /// This is the core advanced application logic.
    /// - Parameters:
    ///   - dataRootURL: The root URL containing all labeled image data.
    ///   - kFolds: The number of folds for cross-validation.
    ///   - hyperparameterSets: An array of `HyperparameterSet` objects to evaluate.
    /// - Returns: A dictionary mapping each hyperparameter set to its average `MLClassifierMetrics` across all folds.
    /// - Throws: `DocumentClassifierError` if any step in the process fails.
    func performKFoldCrossValidation(dataRootURL: URL, kFolds: Int, hyperparameterSets: [HyperparameterSet]) async throws -> [HyperparameterSet: MLClassifierMetrics] {
        print("Starting \(kFolds)-fold cross-validation for \(hyperparameterSets.count) hyperparameter sets...")

        var results: [HyperparameterSet: [MLClassifierMetrics]] = [:]
        for set in hyperparameterSets {
            results[set] = []
        }

        // Create a temporary directory for models for this cross-validation run
        let cvRunTempDir = outputDirectory.appendingPathComponent("CV_Run_\(UUID().uuidString)", isDirectory: true)
        try fileManager.createDirectory(at: cvRunTempDir, withIntermediateDirectories: true, attributes: nil)
        defer {
            // Clean up the temporary directory after the function completes
            try? fileManager.removeItem(at: cvRunTempDir)
        }

        // Iterate through each fold
        for foldIndex in 0..<kFolds {
            print("\n--- Processing Fold \(foldIndex + 1) of \(kFolds) ---")
            let (trainingData, testingData) = try await prepareFoldData(dataRootURL: dataRootURL, kFolds: kFolds, currentFoldIndex: foldIndex)

            // Concurrently train and evaluate models for each hyperparameter set within this fold
            await withTaskGroup(of: (HyperparameterSet, MLClassifierMetrics?, Error?).self) { group in
                for hyperSet in hyperparameterSets {
                    group.addTask {
                        let modelFileName = "DocumentClassifier_\(hyperSet.name.replacingOccurrences(of: " ", with: "_"))_Fold\(foldIndex + 1).mlmodel"
                        let modelOutputURL = cvRunTempDir.appendingPathComponent(modelFileName)

                        do {
                            let trainedModelURL = try await self.trainModel(trainingData: trainingData, parameters: hyperSet.modelParameters, outputURL: modelOutputURL)
                            let metrics = try await self.evaluateModel(modelURL: trainedModelURL, testingData: testingData)
                            return (hyperSet, metrics, nil)
                        } catch {
                            print("Error processing \(hyperSet.name) for Fold \(foldIndex + 1): \(error.localizedDescription)")
                            return (hyperSet, nil, error)
                        }
                    }
                }

                for await (hyperSet, metrics, error) in group {
                    if let metrics = metrics {
                        results[hyperSet]?.append(metrics)
                    } else if let error = error {
                        // Handle or log errors for specific hyperparameter sets/folds
                        print("Failed to get metrics for \(hyperSet.name) in a fold due to error: \(error.localizedDescription)")
                    }
                }
            }
        }

        // Aggregate results: calculate average metrics for each hyperparameter set
        var averageResults: [HyperparameterSet: MLClassifierMetrics] = [:]
        for (hyperSet, metricsArray) in results {
            guard !metricsArray.isEmpty else {
                print("Warning: No metrics collected for hyperparameter set: \(hyperSet.name)")
                continue
            }
            let avgAccuracy = metricsArray.map { $0.accuracy }.reduce(0, +) / Double(metricsArray.count)
            // For other metrics, you'd need to average them similarly, or pick one representative.
            // MLClassifierMetrics doesn't have a direct initializer from average components,
            // so we'll just create a placeholder with the average accuracy for demonstration.
            let averageMetrics = MLClassifierMetrics(accuracy: avgAccuracy, validationMetrics: nil) // Simplification
            averageResults[hyperSet] = averageMetrics
            print("\nAverage metrics for \(hyperSet.name): Accuracy = \(String(format: "%.4f", avgAccuracy))")
        }

        return averageResults
    }
}

// MARK: - 4. Main Application Entry Point (Simulated)

/// Simulates the main execution flow of the Smart Document Scanner app's training module.
@main
@available(iOS 18.0, macOS 15.0, *)
struct SmartDocumentScannerApp {
    static func main() async {
        // --- Configuration ---
        // IMPORTANT: Replace with a real path to your dataset.
        // The dataset should be structured as:
        // dataRootURL/
        //   Invoice/
        //     invoice1.jpg
        //     invoice2.png
        //   Receipt/
        //     receipt1.jpg
        //     receipt2.png
        //   Contract/
        //     contract1.jpg
        //     contract2.png
        let dataRootURL = URL(fileURLWithPath: "/Users/Shared/DocumentDataset") // Example path
        let outputDirectory = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("SmartDocumentScannerModels")

        let kFolds = 3 // Number of folds for cross-validation

        // Define different hyperparameter sets (i.e., different augmentation strategies)
        let hyperparameterSets: [HyperparameterSet] = [
            .init(name: "No Augmentation"),
            .init(name: "Mild Augmentation", rotation: 5, flip: .horizontal, crop: .random),
            .init(name: "Moderate Augmentation", rotation: 10, flip: [.horizontal, .vertical], crop: .random, blur: true),
            .init(name: "Aggressive Augmentation", rotation: 15, flip: [.horizontal, .vertical], crop: [.random, .center], blur: true, exposure: true, noise: true)
        ]

        // Ensure output directory exists
        do {
            try FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true, attributes: nil)
        } catch {
            print("Failed to create output directory: \(error.localizedDescription)")
            return
        }

        let trainer = DocumentClassifierTrainer(outputDirectory: outputDirectory)

        do {
            let results = try await trainer.performKFoldCrossValidation(
                dataRootURL: dataRootURL,
                kFolds: kFolds,
                hyperparameterSets: hyperparameterSets
            )

            print("\n--- Cross-Validation Results Summary ---")
            var bestSet: HyperparameterSet?
            var highestAccuracy: Double = -1.0

            for (hyperSet, metrics) in results.sorted(by: { $0.value.accuracy > $1.value.accuracy }) {
                print("Hyperparameter Set: \(hyperSet.name)")
                print("  Augmentation: \(hyperSet.augmentationParameters)")
                print("  Average Accuracy: \(String(format: "%.4f", metrics.accuracy))")
                if metrics.accuracy > highestAccuracy {
                    highestAccuracy = metrics.accuracy
                    bestSet = hyperSet
                }
            }

            if let bestSet = bestSet {
                print("\n--- Best Performing Hyperparameter Set ---")
                print("Name: \(bestSet.name)")
                print("Augmentation: \(bestSet.augmentationParameters)")
                print("Achieved Average Accuracy: \(String(format: "%.4f", highestAccuracy))")

                // In a real app, you would now use this bestSet to train the final production model
                // on the *entire* dataset (or a large portion of it) and then deploy it.
                print("\nRecommendation: Train the final production model using the '\(bestSet.name)' augmentation strategy on the full dataset.")
            } else {
                print("No valid results found to determine the best hyperparameter set.")
            }

            print("\nAll models and temporary files were cleaned up from \(outputDirectory.path)")

        } catch {
            print("\nAn error occurred during cross-validation: \(error.localizedDescription)")
            if let docError = error as? DocumentClassifierError {
                print("Specific error: \(docError.errorDescription ?? "Unknown")")
            }
        }
    }
}
