
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN // For MLXNN.Module

// @available(iOS 18.0, *) // Apply this if using @Observable for model state in a UI context
final class SimpleLinearModel: MLXNN.Module {
    let weight: MLXArray
    let bias: MLXArray

    init(inputFeatures: Int, outputFeatures: Int) {
        // Initialize parameters with random values, requiring gradients
        self.weight = MLXArray.random(
            [outputFeatures, inputFeatures],
            stream: .current,
            requiresGrad: true
        )
        self.bias = MLXArray.zeros(
            [outputFeatures],
            stream: .current,
            requiresGrad: true
        )
        super.init()
    }

    func callAsFunction(_ x: MLXArray) -> MLXArray {
        return x.matmul(weight.T) + bias
    }
}

// Define a simple loss function (Mean Squared Error)
func mseLoss(model: SimpleLinearModel, x: MLXArray, y: MLXArray) -> MLXArray {
    let predictions = model(x)
    let error = predictions - y
    return (error * error).mean()
}

// --- Using valueAndGradient ---

// 1. Create a model instance
let model = SimpleLinearModel(inputFeatures: 10, outputFeatures: 1)

// 2. Generate some dummy data
let x_data = MLXArray.random([100, 10])
let y_data = MLXArray.random([100, 1])

// 3. Define the function for which we want value and gradient
//    This function must take the parameters to be differentiated as its first argument.
//    MLX automatically identifies trainable parameters within the Module.
let lossAndGradientFn = valueAndGradient(mseLoss)

// 4. Execute the transformed function to get the loss and gradients
let (loss, gradients) = lossAndGradientFn(model, x_data, y_data)

// The `gradients` object is a dictionary-like structure mapping parameter names to their gradients.
print("Initial Loss: \(loss.item())")
// print("Gradients for weight: \(gradients.parameters["weight"]!)")
// print("Gradients for bias: \(gradients.parameters["bias"]!)")

// Note: In a real training loop, these gradients would then be used by an optimizer
// to update the model's parameters.
