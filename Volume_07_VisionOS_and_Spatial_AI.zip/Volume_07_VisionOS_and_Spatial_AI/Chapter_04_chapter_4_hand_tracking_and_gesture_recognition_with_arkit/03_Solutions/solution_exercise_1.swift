
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import ARKit
import RealityKit
import Foundation
import Combine

@MainActor
class HandVisualizer: ObservableObject {
    private let session = ARKitSession()
    private let handTracking = HandTrackingProvider()
    private var jointEntities: [HandJointName: ModelEntity] = [:]
    
    // The joints we want to visualize
    private let jointsToTrack: Set<HandJointName> = [
        .wrist, .indexFingerTip, .thumbTip, .middleFingerTip
    ]
    
    private var subscriptions = Set<AnyCancellable>()
    
    func startSession(in scene: Scene) async {
        do {
            try await session.run([handTracking])
            
            // Subscribe to the scene update loop to sync transforms every frame
            scene.subscribe(to: SceneEvents.Update.self) { [weak self] _ in
                self?.updateVisuals()
            }.store(in: &subscriptions)
            
        } catch {
            print("Failed to start ARKit session: \(error)")
        }
    }
    
    private func updateVisuals() {
        // Get the current hand anchors from the provider
        let anchors = handTracking.handAnchors
        
        for anchor in anchors {
            // 1. Ensure we have entities for the joints we need
            prepareEntities(for: anchor, in: anchor.parent ?? Entity())
            
            // 2. Update each joint's transform
            for jointName in jointsToTrack {
                guard let entity = jointEntities[jointName],
                      let jointTransform = anchor.handSkeleton.transform(for: jointName) else {
                    continue
                }
                
                // CRITICAL MATH: Convert local joint transform to world space
                // worldTransform = HandAnchorTransform * LocalJointTransform
                let worldTransform = anchor.transform * jointTransform
                
                entity.setTransformMatrix(worldTransform, relativeTo: nil)
            }
        }
    }
    
    private func prepareEntities(for anchor: HandAnchor, in sceneRoot: Entity) {
        for jointName in jointsToTrack {
            if jointEntities[jointName] == nil {
                // Create a small sphere (5mm radius)
                let mesh = MeshResource.generateSphere(radius: 0.005)
                let material = SimpleMaterial(color: .cyan, isMetallic: true)
                let entity = ModelEntity(mesh: mesh, materials: [material])
                
                // Add to the scene root so they exist in the world
                sceneRoot.addChild(entity)
                jointEntities[jointName] = entity
            }
        }
    }
}
