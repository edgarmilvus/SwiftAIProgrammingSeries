
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import Combine
import Foundation
// import AIModelKit // In a real app, this would be imported from the Package.swift dependency

// MARK: - 1. Data Models

/// Represents a bounding box in normalized coordinates (0.0 to 1.0).
struct BoundingBox: Hashable, Codable {
    var x: Double
    var y: Double
    var width: Double
    var height: Double
}

/// Represents the raw output for a single detected object from an AI model in one frame.
/// - `id`: Unique identifier for the object, allowing tracking across frames.
/// - `boundingBox`: The location and size of the detected object.
/// - `probabilities`: A dictionary mapping class labels (e.g., "cat", "dog") to their raw probability scores.
struct DetectedObject: Identifiable, Hashable, Codable {
    let id: UUID
    let boundingBox: BoundingBox
    let probabilities: [String: Double] // Raw probabilities from the model
    let timestamp: Date = Date()
}

/// Represents a detected object with its probability distribution smoothed over time.
/// This is what the UI will consume.
struct SmoothedObjectDetection: Identifiable, Hashable {
    let id: UUID
    let boundingBox: BoundingBox
    let smoothedProbabilities: [String: Double] // Smoothed probabilities for visualization
    let dominantClass: String?
    let dominantConfidence: Double

    init(id: UUID, boundingBox: BoundingBox, smoothedProbabilities: [String: Double]) {
        self.id = id
        self.boundingBox = boundingBox
        self.smoothedProbabilities = smoothedProbabilities

        if let (classLabel, confidence) = smoothedProbabilities.max(by: { $0.value < $1.value }) {
            self.dominantClass = classLabel
            self.dominantConfidence = confidence
        } else {
            self.dominantClass = nil
            self.dominantConfidence = 0.0
        }
    }
}

// MARK: - 2. Distribution Smoothing Logic

/// `DistributionSmoother` manages the temporal smoothing of probability distributions
/// for a *single* detected object using an Exponential Moving Average (EMA).
///
/// This helps to stabilize fluctuating model predictions over time, providing a
/// more consistent and less "flickering" visualization.
@available(iOS 18.0, *)
@MainActor // Ensure all state changes and publishing happen on the main actor
class DistributionSmoother: ObservableObject {
    let objectID: UUID
    private var currentBoundingBox: BoundingBox // The latest known bounding box for this object
    private var smoothedProbabilities: [String: Double] = [:] {
        didSet {
            // Only publish if the smoothed probabilities have actually changed meaningfully
            if oldValue != smoothedProbabilities {
                publishSmoothedDetection()
            }
        }
    }
    private var cancellables = Set<AnyCancellable>()

    /// The decay factor for the Exponential Moving Average.
    /// A value closer to 1.0 gives more weight to recent observations (less smoothing).
    /// A value closer to 0.0 gives more weight to past observations (more smoothing).
    private let alpha: Double // EMA smoothing factor

    /// Publishes the latest smoothed detection for this object.
    @Published private(set) var smoothedDetection: SmoothedObjectDetection?

    /// Initializes a new smoother for a given object.
    /// - Parameters:
    ///   - objectID: The unique identifier for the object being tracked.
    ///   - initialBoundingBox: The initial bounding box of the object.
    ///   - initialProbabilities: The first set of probabilities for the object.
    ///   - alpha: The EMA smoothing factor (0.0 to 1.0).
    init(objectID: UUID, initialBoundingBox: BoundingBox, initialProbabilities: [String: Double], alpha: Double = 0.3) {
        self.objectID = objectID
        self.currentBoundingBox = initialBoundingBox
        self.smoothedProbabilities = initialProbabilities
        self.alpha = min(max(alpha, 0.0), 1.0) // Clamp alpha between 0 and 1
        publishSmoothedDetection()
    }

    /// Updates the smoother with new raw detection data.
    /// - Parameters:
    ///   - newBoundingBox: The latest bounding box for the object.
    ///   - newProbabilities: The latest raw probability distribution.
    func update(newBoundingBox: BoundingBox, newProbabilities: [String: Double]) {
        self.currentBoundingBox = newBoundingBox

        // Initialize smoothed probabilities if empty (first update or new class appeared)
        if smoothedProbabilities.isEmpty {
            smoothedProbabilities = newProbabilities
            return
        }

        var newSmoothed: [String: Double] = [:]
        let allKeys = Set(smoothedProbabilities.keys).union(newProbabilities.keys)

        for key in allKeys {
            let oldVal = smoothedProbabilities[key] ?? 0.0
            let newVal = newProbabilities[key] ?? 0.0
            // Apply Exponential Moving Average: S_t = alpha * Y_t + (1 - alpha) * S_{t-1}
            newSmoothed[key] = alpha * newVal + (1.0 - alpha) * oldVal
        }

        // Normalize the newSmoothed probabilities to ensure they sum to 1.0
        let sum = newSmoothed.values.reduce(0, +)
        if sum > 0 {
            smoothedProbabilities = newSmoothed.mapValues { $0 / sum }
        } else {
            smoothedProbabilities = newSmoothed // All zeros, no normalization needed
        }
    }

    /// Helper to publish the current smoothed detection.
    private func publishSmoothedDetection() {
        self.smoothedDetection = SmoothedObjectDetection(
            id: objectID,
            boundingBox: currentBoundingBox,
            smoothedProbabilities: smoothedProbabilities
        )
    }
}

// MARK: - 3. Object Detection Management

/// `ObjectDetectionManager` simulates receiving real-time AI model outputs
/// and manages the `DistributionSmoother` instances for each detected object.
/// It publishes a list of `SmoothedObjectDetection` for the UI.
@available(iOS 18.0, *)
@MainActor // Ensure all state changes and publishing happen on the main actor
class ObjectDetectionManager: ObservableObject {
    /// A dictionary to hold `DistributionSmoother` instances, keyed by object ID.
    private var activeSmoothers: [UUID: DistributionSmoother] = [:]
    private var cancellables = Set<AnyCancellable>()

    /// The list of smoothed detections currently active in the scene, published for SwiftUI.
    @Published private(set) var smoothedDetections: [SmoothedObjectDetection] = []

    /// Configuration for object tracking.
    private let smoothingAlpha: Double
    private let objectRetentionTime: TimeInterval // How long to keep a smoother active without updates (e.g., 2 seconds)

    /// Initializes the manager with smoothing and retention parameters.
    /// - Parameters:
    ///   - smoothingAlpha: The EMA smoothing factor for probabilities.
    ///   - objectRetentionTime: The duration in seconds an object is tracked after its last detection.
    init(smoothingAlpha: Double = 0.3, objectRetentionTime: TimeInterval = 2.0) {
        self.smoothingAlpha = smoothingAlpha
        self.objectRetentionTime = objectRetentionTime

        // Start a background task to periodically clean up old smoothers.
        Task { await cleanupOldSmoothers() }
    }

    /// Simulates receiving a batch of raw `DetectedObject`s from the AI model.
    /// - Parameter detections: An array of `DetectedObject`s from the current frame.
    func processNewDetections(_ detections: [DetectedObject]) {
        var updatedObjectIDs: Set<UUID> = []

        for detection in detections {
            updatedObjectIDs.insert(detection.id)

            if let smoother = activeSmoothers[detection.id] {
                // Object already tracked, update its smoother
                smoother.update(newBoundingBox: detection.boundingBox, newProbabilities: detection.probabilities)
            } else {
                // New object detected, create a new smoother
                let newSmoother = DistributionSmoother(
                    objectID: detection.id,
                    initialBoundingBox: detection.boundingBox,
                    initialProbabilities: detection.probabilities,
                    alpha: smoothingAlpha
                )
                activeSmoothers[detection.id] = newSmoother

                // Subscribe to the new smoother's published `smoothedDetection`
                newSmoother.$smoothedDetection
                    .compactMap { $0 } // Only pass non-nil values
                    .sink { [weak self] smoothed in
                        guard let self = self else { return }
                        // Update the main list of smoothed detections
                        // This involves finding and replacing the existing smoothed detection or adding a new one.
                        if let index = self.smoothedDetections.firstIndex(where: { $0.id == smoothed.id }) {
                            self.smoothedDetections[index] = smoothed
                        } else {
                            self.smoothedDetections.append(smoothed)
                        }
                    }
                    .store(in: &cancellables)
            }
        }

        // Remove detections that are no longer present in the current frame
        // (This is a simplified approach, a more robust tracker would handle occlusions better)
        let objectsToPrune = Set(activeSmoothers.keys).subtracting(updatedObjectIDs)
        for id in objectsToPrune {
            // For now, we immediately remove if not detected.
            // A more advanced system would keep it for `objectRetentionTime` and fade out.
            activeSmoothers.removeValue(forKey: id)
            smoothedDetections.removeAll { $0.id == id }
        }
    }

    /// Periodically checks for and removes smoothers for objects that haven't been updated
    /// within the `objectRetentionTime`. This prevents memory leaks for lost objects.
    private func cleanupOldSmoothers() async {
        while !Task.isCancelled {
            try? await Task.sleep(for: .seconds(objectRetentionTime / 2)) // Check every half retention time
            await MainActor.run {
                let now = Date()
                let expiredIDs = activeSmoothers.filter { _, smoother in
                    // We need a last update timestamp in Smoother or rely on the detection list update time
                    // For simplicity here, we'll assume objects not in `smoothedDetections` are candidates for removal
                    // A better approach would be to store last update timestamp in DistributionSmoother
                    !smoothedDetections.contains(where: { $0.id == smoother.objectID })
                }.map { $0.key }

                for id in expiredIDs {
                    activeSmoothers.removeValue(forKey: id)
                    // The `smoothedDetections` list is already updated by the `sink`
                    // We only need to remove the smoother itself.
                }
            }
        }
    }

    /// Simulates AI model inference at a regular interval.
    /// In a real app, this would be driven by camera frame callbacks.
    func startSimulation() {
        Task {
            while !Task.isCancelled {
                // Simulate receiving detections from an AI model
                let simulatedDetections = await MockAIModel.generateDetections()
                await MainActor.run {
                    self.processNewDetections(simulatedDetections)
                }
                try? await Task.sleep(for: .milliseconds(150)) // Simulate ~7 FPS update rate
            }
        }
    }
}

// MARK: - 4. SwiftUI Visualization Component

/// A SwiftUI `View` that displays an animated bar chart for a probability distribution.
/// The bars animate smoothly as their underlying values change.
@available(iOS 18.0, *)
struct ProbabilityDistributionBarView: View {
    let distribution: [String: Double]
    let maxBars: Int = 5 // Limit to top N classes for readability
    let threshold: Double = 0.1 // Only show bars above this confidence

    /// Sorts and filters the distribution to show only the most relevant classes.
    private var displayableDistribution: [(String, Double)] {
        distribution
            .filter { $0.value >= threshold }
            .sorted { $0.value > $1.value }
            .prefix(maxBars)
            .map { ($0.key, $0.value) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            ForEach(displayableDistribution, id: \.0) { (label, value) in
                HStack {
                    Text(label)
                        .font(.caption2)
                        .foregroundColor(.white)
                        .minimumScaleFactor(0.7)
                        .lineLimit(1)
                        .frame(width: 40, alignment: .leading) // Fixed width for labels
                    
                    GeometryReader { geometry in
                        ZStack(alignment: .leading) {
                            Capsule()
                                .fill(Color.gray.opacity(0.3))
                                .frame(height: 8)
                            
                            Capsule()
                                .fill(barColor(for: label))
                                .frame(width: geometry.size.width * CGFloat(value), height: 8)
                                .animation(.spring(response: 0.4, dampingFraction: 0.7, blendDuration: 0.5), value: value)
                        }
                    }
                    .frame(height: 8) // Ensure GeometryReader has a fixed height
                    
                    Text(String(format: "%.0f%%", value * 100))
                        .font(.caption2)
                        .foregroundColor(.white)
                        .frame(width: 35, alignment: .trailing)
                }
            }
            if displayableDistribution.isEmpty && !distribution.isEmpty {
                Text("Detecting...")
                    .font(.caption2)
                    .foregroundColor(.white.opacity(0.7))
            }
        }
        .padding(4)
        .background(Color.black.opacity(0.6))
        .cornerRadius(6)
        .fixedSize(horizontal: false, vertical: true) // Allow vertical expansion, fix horizontal
    }

    /// Provides a consistent color for each class label.
    private func barColor(for label: String) -> Color {
        switch label {
        case "person": return .blue
        case "cat": return .orange
        case "dog": return .yellow
        case "car": return .red
        case "tree": return .green
        case "bicycle": return .purple
        default: return .cyan
        }
    }
}

// MARK: - 5. Main Camera Overlay View

/// The main SwiftUI view that acts as an overlay for a camera feed,
/// displaying bounding boxes and animated probability distributions.
@available(iOS 18.0, *)
struct CameraOverlayView: View {
    @StateObject private var detectionManager = ObjectDetectionManager()
    @State private var frameSize: CGSize = .zero // Size of the camera feed view

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Placeholder for the actual camera feed
                Color.black.opacity(0.1) // Simulate camera background
                    .onAppear {
                        frameSize = geometry.size
                        detectionManager.startSimulation()
                    }
                    .onChange(of: geometry.size) { _, newSize in
                        frameSize = newSize
                    }

                // Overlay for each detected object
                ForEach(detectionManager.smoothedDetections) { detection in
                    let rect = rect(from: detection.boundingBox, in: frameSize)
                    
                    Group {
                        // Bounding Box
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(detection.dominantConfidence > 0.5 ? barColor(for: detection.dominantClass ?? "") : .gray, lineWidth: 2)
                            .frame(width: rect.width, height: rect.height)
                            .offset(x: rect.minX - frameSize.width / 2, y: rect.minY - frameSize.height / 2)

                        // Dominant Class Label (optional, for quick glance)
                        if let dominantClass = detection.dominantClass, detection.dominantConfidence > 0.5 {
                            Text("\(dominantClass.capitalized) (\(String(format: "%.0f%%", detection.dominantConfidence * 100)))")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 3)
                                .background(barColor(for: dominantClass).opacity(0.8))
                                .cornerRadius(5)
                                .offset(x: rect.minX - frameSize.width / 2, y: rect.minY - frameSize.height / 2 - 25)
                        }

                        // Probability Distribution Bar View
                        ProbabilityDistributionBarView(distribution: detection.smoothedProbabilities)
                            .offset(x: rect.minX - frameSize.width / 2, y: rect.maxY - frameSize.height / 2 + 5) // Position below bounding box
                            .frame(maxWidth: rect.width * 1.5) // Allow the distribution view to be slightly wider
                            .animation(.spring(response: 0.4, dampingFraction: 0.7, blendDuration: 0.5), value: detection.smoothedProbabilities) // Animate position changes too
                    }
                    .position(x: rect.midX, y: rect.midY) // Position the whole group
                    .transition(.opacity.animation(.easeOut(duration: 0.3))) // Fade in/out new/removed objects
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    /// Helper to convert normalized bounding box to actual screen coordinates.
    private func rect(from normalizedBox: BoundingBox, in size: CGSize) -> CGRect {
        let x = normalizedBox.x * size.width
        let y = normalizedBox.y * size.height
        let width = normalizedBox.width * size.width
        let height = normalizedBox.height * size.height
        return CGRect(x: x, y: y, width: width, height: height)
    }
    
    /// Provides a consistent color for each class label (duplicated for simplicity, could be shared).
    private func barColor(for label: String) -> Color {
        switch label {
        case "person": return .blue
        case "cat": return .orange
        case "dog": return .yellow
        case "car": return .red
        case "tree": return .green
        case "bicycle": return .purple
        default: return .cyan
        }
    }
}

// MARK: - Mock AI Model (for simulation)

/// A mock AI model to simulate real-time object detection outputs.
/// In a production app, this would be replaced by actual Core ML or backend inference.
@available(iOS 18.0, *)
actor MockAIModel {
    private static var trackedObjects: [UUID: DetectedObject] = [:]
    private static var nextObjectID: Int = 0

    static func generateDetections() async -> [DetectedObject] {
        var newDetections: [DetectedObject] = []
        let currentTime = Date().timeIntervalSince1970

        // Simulate new objects appearing
        if Int.random(in: 0..<10) == 0 && trackedObjects.count < 3 { // 10% chance to add a new object if less than 3
            let newID = UUID()
            let randomX = Double.random(in: 0.1..<0.9)
            let randomY = Double.random(in: 0.1..<0.9)
            let randomWidth = Double.random(in: 0.1..<0.3)
            let randomHeight = Double.random(in: 0.1..<0.3)
            let initialBox = BoundingBox(x: randomX, y: randomY, width: randomWidth, height: randomHeight)

            let classes = ["person", "cat", "dog", "car", "tree", "bicycle"]
            let randomClass1 = classes.randomElement()!
            var initialProbs: [String: Double] = [randomClass1: Double.random(in: 0.6..<0.9)]

            // Add a second, less confident class sometimes
            if Bool.random() {
                var remainingClasses = classes.filter { $0 != randomClass1 }
                if let randomClass2 = remainingClasses.randomElement() {
                    initialProbs[randomClass2] = Double.random(in: 0.1..<0.3)
                }
            }
            
            // Normalize for initial state
            let sum = initialProbs.values.reduce(0, +)
            if sum > 0 {
                initialProbs = initialProbs.mapValues { $0 / sum }
            }

            let newObject = DetectedObject(id: newID, boundingBox: initialBox, probabilities: initialProbs)
            trackedObjects[newID] = newObject
        }

        // Update existing objects
        for (id, var object) in trackedObjects {
            // Simulate slight movement
            object.boundingBox.x += Double.random(in: -0.01..<0.01)
            object.boundingBox.y += Double.random(in: -0.01..<0.01)
            
            // Clamp bounding box to stay within bounds
            object.boundingBox.x = max(0, min(1 - object.boundingBox.width, object.boundingBox.x))
            object.boundingBox.y = max(0, min(1 - object.boundingBox.height, object.boundingBox.y))

            // Simulate probability shifts
            var currentProbs = object.probabilities
            let classes = Array(currentProbs.keys)
            if let dominantClass = classes.first(where: { currentProbs[$0] == currentProbs.values.max() }) {
                // Tend to reinforce dominant class or introduce new uncertainty
                var newProbs = currentProbs
                newProbs[dominantClass] = (newProbs[dominantClass] ?? 0.0) + Double.random(in: -0.05..<0.05)

                // Introduce a new class or shift to another
                if Bool.random() && classes.count > 1 {
                    let otherClass = classes.filter { $0 != dominantClass }.randomElement()!
                    newProbs[otherClass] = (newProbs[otherClass] ?? 0.0) + Double.random(in: -0.03..<0.03)
                } else if Bool.random() { // Introduce a new class from the full list
                    let allClasses = ["person", "cat", "dog", "car", "tree", "bicycle"]
                    let newCandidateClass = allClasses.filter { !classes.contains($0) }.randomElement()
                    if let newClass = newCandidateClass {
                        newProbs[newClass] = (newProbs[newClass] ?? 0.0) + Double.random(in: 0.01..<0.05)
                    }
                }
                
                // Ensure all probabilities are non-negative and sum to 1
                newProbs = newProbs.mapValues { max(0, $0) }
                let sum = newProbs.values.reduce(0, +)
                if sum > 0 {
                    object.probabilities = newProbs.mapValues { $0 / sum }
                } else {
                    object.probabilities = newProbs // All zeros, no normalization needed
                }
            }
            
            trackedObjects[id] = object
            newDetections.append(object)
        }

        // Simulate objects disappearing
        if Int.random(in: 0..<20) == 0 && !trackedObjects.isEmpty { // 5% chance to remove an object
            if let idToRemove = trackedObjects.keys.randomElement() {
                trackedObjects.removeValue(forKey: idToRemove)
            }
        }
        
        return newDetections
    }
}
