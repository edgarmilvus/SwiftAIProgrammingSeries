/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

// packages/types/src/env.ts
import { z } from 'zod';

// 1. Define the shape and constraints
const envSchema = z.object({
  // Must be a valid URL string
  API_URL: z.string().url(),
  // Must be a string, defaulting to 'development' if missing
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  // Must be a positive number
  RATE_LIMIT: z.coerce.number().positive(),
});

// 2. Parse the environment variables
// We cast process.env to the schema's input type to allow for partial objects during parsing
export const env = envSchema.parse(process.env);

// 3. Infer the TypeScript type for use in the app
export type Env = z.infer<typeof envSchema>;
