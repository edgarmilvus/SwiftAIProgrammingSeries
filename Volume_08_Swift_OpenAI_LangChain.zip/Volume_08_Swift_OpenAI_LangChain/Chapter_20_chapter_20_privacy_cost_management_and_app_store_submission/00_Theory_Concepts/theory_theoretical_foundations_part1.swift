
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation

/// A protocol defining what it means to be "Sanitizable"
protocol Sanitizable {
    func sanitized() async -> String
}

/// The PrivacyGuard is an Actor, ensuring that the sanitization process
/// is isolated and thread-safe. This prevents "leaking" raw data into logs
/// or other concurrent tasks.
@available(iOS 18.0, *)
actor PrivacyGuard {
    private var sensitivePatterns: [NSRegularExpression] = []

    init(patterns: [String]) {
        self.sensitivePatterns = patterns.compactMap { 
            try? NSRegularExpression(pattern: $0, options: .caseInsensitive) 
        }
    }

    /// Processes a raw input and returns a version stripped of PII.
    /// Because this is an actor, no other part of the app can access
    /// the 'raw' state of the data during this computation.
    func scrub(_ input: String) async -> String {
        var scrubbed = input
        let range = NSRange(location: 0, length: scrubbed.utf16.count)
        
        for pattern in sensitivePatterns {
            scrubbed = pattern.stringByReplacingMatches(
                in: scrubbed,
                options: [],
                range: range,
                withTemplate: "[REDACTED]"
            )
        }
        
        // Under the hood: We are performing a heavy computation.
        // Swift 6's actor isolation ensures this doesn't block the MainActor (UI).
        return scrubbed
    }
}
