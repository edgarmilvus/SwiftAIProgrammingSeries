
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import NaturalLanguage // Assuming this is part of the framework

@available(iOS 18.0, *)
class EmbeddingProcessor {
    func generateEmbedding(for text: String, language: NLLanguage? = nil) async throws -> [Double]? {
        // NLEmbedding operations can be long-running, so async is crucial.
        // This simulates a potentially time-consuming operation.
        let embedding = NLEmbedding.wordEmbedding(for: language ?? .english)
        guard let vector = await embedding?.vector(for: text) else {
            print("Could not get embedding vector for '\(text)'")
            return nil
        }
        return vector
    }

    func compareTexts(text1: String, text2: String) async throws -> Double? {
        // Perform two embedding generations concurrently
        async let vector1 = generateEmbedding(for: text1)
        async let vector2 = generateEmbedding(for: text2)

        guard let v1 = await vector1, let v2 = await vector2 else {
            print("Failed to get vectors for comparison.")
            return nil
        }

        // Calculate cosine similarity - NLEmbedding provides this directly
        let embedding = NLEmbedding.wordEmbedding(for: .english)
        return await embedding?.cosineSimilarity(for: v1, to: v2)
    }
}

@available(iOS 18.0, *)
@main
struct MyApp {
    static func main() async {
        let processor = EmbeddingProcessor()
        do {
            let similarity = try await processor.compareTexts(text1: "apple", text2: "fruit")
            if let similarity {
                print("Similarity between 'apple' and 'fruit': \(similarity)")
            }

            let longTextEmbedding = try await processor.generateEmbedding(for: "The quick brown fox jumps over the lazy dog.")
            if let longTextEmbedding {
                print("Embedding for long text (first 5 dimensions): \(longTextEmbedding.prefix(5))...")
            }
        } catch {
            print("An error occurred: \(error)")
        }
    }
}
