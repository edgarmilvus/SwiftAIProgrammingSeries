
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import UIKit
import AVFoundation
import Vision
import CoreImage.CIFilterBuiltins

/// @available(iOS 15.0, *) // Vision and AVFoundation features used are available on iOS 15+
/// A delegate protocol for `CameraProcessor` to communicate detected documents and text.
protocol CameraProcessorDelegate: AnyObject {
    /// Informs the delegate about a detected document rectangle.
    /// - Parameters:
    ///   - processor: The `CameraProcessor` instance.
    ///   - rectangle: The `VNDocumentCameraRectangleObservation` representing the document.
    ///   - imageSize: The original size of the image frame.
    func cameraProcessor(_ processor: CameraProcessor, didDetect rectangle: VNDocumentCameraRectangleObservation, in imageSize: CGSize)

    /// Informs the delegate about recognized text from a perspective-corrected document.
    /// - Parameters:
    ///   - processor: The `CameraProcessor` instance.
    ///   - recognizedText: The string containing all recognized text.
    ///   - correctedImage: The perspective-corrected image of the document.
    func cameraProcessor(_ processor: CameraProcessor, didRecognize recognizedText: String, from correctedImage: CIImage)

    /// Informs the delegate about an error encountered by the processor.
    /// - Parameters:
    ///   - processor: The `CameraProcessor` instance.
    ///   - error: The `Error` that occurred.
    func cameraProcessor(_ processor: CameraProcessor, didEncounterError error: Error)
}

/// @available(iOS 15.0, *)
/// Manages the AVFoundation camera pipeline and Vision requests for real-time document scanning.
class CameraProcessor: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {

    weak var delegate: CameraProcessorDelegate?

    private let captureSession = AVCaptureSession()
    private let videoDataOutput = AVCaptureVideoDataOutput()
    private let videoDataOutputQueue = DispatchQueue(label: "com.advancedml.videoDataOutputQueue")
    private let visionProcessingQueue = DispatchQueue(label: "com.advancedml.visionProcessingQueue", qos: .userInitiated)

    private var documentDetectionRequest: VNDetectDocumentCameraRectangleRequest!
    private var textRecognitionRequest: VNRecognizeTextRequest!

    // MARK: - Setup

    /// Initializes the camera and Vision pipeline.
    /// Call this method to start the setup process.
    func setupCameraAndVision() {
        // 1. Configure the AVCaptureSession
        captureSession.beginConfiguration()
        setupCaptureInput()
        setupCaptureOutput()
        setupVisionRequests()
        captureSession.commitConfiguration()
    }

    /// Starts the camera session. Call after `setupCameraAndVision()`.
    func startRunning() {
        visionProcessingQueue.async { [weak self] in
            self?.captureSession.startRunning()
        }
    }

    /// Stops the camera session.
    func stopRunning() {
        visionProcessingQueue.async { [weak self] in
            self?.captureSession.stopRunning()
        }
    }

    /// Provides the `AVCaptureVideoPreviewLayer` to display the camera feed.
    /// - Returns: An `AVCaptureVideoPreviewLayer` configured for the capture session.
    func getPreviewLayer() -> AVCaptureVideoPreviewLayer {
        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = .resizeAspectFill
        return previewLayer
    }

    private func setupCaptureInput() {
        guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            delegate?.cameraProcessor(self, didEncounterError: CameraProcessorError.noCameraAvailable)
            return
        }

        do {
            let cameraInput = try AVCaptureDeviceInput(device: camera)
            if captureSession.canAddInput(cameraInput) {
                captureSession.addInput(cameraInput)
            } else {
                delegate?.cameraProcessor(self, didEncounterError: CameraProcessorError.cannotAddInput)
            }
        } catch {
            delegate?.cameraProcessor(self, didEncounterError: error)
        }
    }

    private func setupCaptureOutput() {
        videoDataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
        videoDataOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA] // BGRA for CIImage compatibility
        videoDataOutput.alwaysDiscardsLateVideoFrames = true // Discard late frames to maintain real-time performance

        if captureSession.canAddOutput(videoDataOutput) {
            captureSession.addOutput(videoDataOutput)
        } else {
            delegate?.cameraProcessor(self, didEncounterError: CameraProcessorError.cannotAddOutput)
        }

        // Ensure the video output is in portrait orientation for consistent Vision processing
        if let connection = videoDataOutput.connection(with: .video), connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait
        }
    }

    private func setupVisionRequests() {
        // Configure Document Detection Request
        documentDetectionRequest = VNDetectDocumentCameraRectangleRequest { [weak self] request, error in
            guard let self = self else { return }
            if let error = error {
                self.delegate?.cameraProcessor(self, didEncounterError: error)
                return
            }
            self.handleDocumentDetectionResults(request.results)
        }

        // Configure Text Recognition Request
        textRecognitionRequest = VNRecognizeTextRequest { [weak self] request, error in
            guard let self = self else { return }
            if let error = error {
                self.delegate?.cameraProcessor(self, didEncounterError: error)
                return
            }
            self.handleTextRecognitionResults(request.results)
        }
        textRecognitionRequest.recognitionLevel = .accurate // Prioritize accuracy over speed
        textRecognitionRequest.usesLanguageCorrection = true
        textRecognitionRequest.recognitionLanguages = ["en-US"] // Specify languages for better accuracy
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    /// Processes each video frame from the camera.
    /// This method is called on `videoDataOutputQueue`.
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Convert CVPixelBuffer to CIImage
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        let imageSize = ciImage.extent.size

        // Perform Vision requests on a dedicated queue
        visionProcessingQueue.async { [weak self] in
            guard let self = self else { return }
            let handler = VNImageRequestHandler(ciImage: ciImage, orientation: .up, options: [:])
            do {
                // First, perform document detection
                try handler.perform([self.documentDetectionRequest])

                // If a document was detected and corrected, the text recognition will be triggered from `handleDocumentDetectionResults`
            } catch {
                self.delegate?.cameraProcessor(self, didEncounterError: error)
            }
        }
    }

    // MARK: - Vision Result Handling

    private func handleDocumentDetectionResults(_ results: [Any]?) {
        guard let observations = results as? [VNDocumentCameraRectangleObservation],
              let document = observations.first else {
            // No document detected, or multiple documents (take the first/largest)
            // Optionally, clear previous overlays if no document is detected
            DispatchQueue.main.async { [weak self] in
                self?.delegate?.cameraProcessor(self, didDetect: VNDocumentCameraRectangleObservation(), in: .zero) // Signal no document
            }
            return
        }

        // Report the detected rectangle to the delegate for UI overlay
        DispatchQueue.main.async { [weak self] in
            if let ciImage = self?.currentCIImage { // Assuming currentCIImage is updated in captureOutput
                self?.delegate?.cameraProcessor(self, didDetect: document, in: ciImage.extent.size)
            }
        }

        // Perform perspective correction
        if let correctedImage = self.performPerspectiveCorrection(on: currentCIImage, with: document) {
            // Now perform text recognition on the corrected image
            let handler = VNImageRequestHandler(ciImage: correctedImage, orientation: .up, options: [:])
            do {
                try handler.perform([self.textRecognitionRequest])
                // Store the corrected image to pass with recognized text
                self.lastCorrectedImage = correctedImage
            } catch {
                self.delegate?.cameraProcessor(self, didEncounterError: error)
            }
        }
    }

    private var currentCIImage: CIImage? // Store the current frame's CIImage for correction
    private var lastCorrectedImage: CIImage? // Store the last corrected image for delegate

    /// Helper to store the current CIImage for subsequent processing.
    private func updateCurrentCIImage(from pixelBuffer: CVPixelBuffer) {
        currentCIImage = CIImage(cvPixelBuffer: pixelBuffer)
    }

    /// Applies perspective correction to an image based on detected document corners.
    /// - Parameters:
    ///   - image: The input `CIImage`.
    ///   - document: The `VNDocumentCameraRectangleObservation` providing the corner points.
    /// - Returns: A new `CIImage` with perspective correction applied, or `nil` if correction fails.
    private func performPerspectiveCorrection(on image: CIImage?, with document: VNDocumentCameraRectangleObservation) -> CIImage? {
        guard let image = image else { return nil }

        let filter = CIFilter.perspectiveCorrection()
        filter.inputImage = image
        filter.topLeft = document.topLeft
        filter.topRight = document.topRight
        filter.bottomLeft = document.bottomLeft
        filter.bottomRight = document.bottomRight

        return filter.outputImage
    }

    private func handleTextRecognitionResults(_ results: [Any]?) {
        guard let observations = results as? [VNRecognizedTextObservation] else { return }

        let recognizedText = observations.compactMap { observation in
            // Get the top candidate for each text block
            observation.topCandidates(1).first?.string
        }.joined(separator: "\n") // Join all detected text lines

        // Report recognized text and the corrected image to the delegate
        DispatchQueue.main.async { [weak self] in
            guard let self = self, let correctedImage = self.lastCorrectedImage else { return }
            self.delegate?.cameraProcessor(self, didRecognize: recognizedText, from: correctedImage)
        }
    }

    // MARK: - Error Handling

    enum CameraProcessorError: Error, LocalizedError {
        case noCameraAvailable
        case cannotAddInput
        case cannotAddOutput
        case authorizationDenied

        var errorDescription: String? {
            switch self {
            case .noCameraAvailable: return "No camera device available."
            case .cannotAddInput: return "Could not add camera input to the capture session."
            case .cannotAddOutput: return "Could not add video data output to the capture session."
            case .authorizationDenied: return "Camera access was denied. Please enable it in Settings."
            }
        }
    }
}

// MARK: - ViewController Integration Example

/// @available(iOS 15.0, *)
/// A `UIViewController` that integrates the `CameraProcessor` to display a live camera feed,
/// overlay detected document rectangles, and show recognized text.
class DocumentScannerViewController: UIViewController, CameraProcessorDelegate {

    private let cameraProcessor = CameraProcessor()
    private var previewLayer: AVCaptureVideoPreviewLayer!
    private let documentOutlineLayer = CAShapeLayer()
    private let recognizedTextLabel = UILabel()
    private let correctedImageView = UIImageView()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupUI()
        checkCameraPermissions()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        cameraProcessor.startRunning()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        cameraProcessor.stopRunning()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.bounds
        documentOutlineLayer.frame = view.bounds
    }

    private func setupUI() {
        // Setup camera preview layer
        previewLayer = cameraProcessor.getPreviewLayer()
        previewLayer.frame = view.bounds
        view.layer.addSublayer(previewLayer)

        // Setup document outline layer
        documentOutlineLayer.strokeColor = UIColor.green.cgColor
        documentOutlineLayer.lineWidth = 3.0
        documentOutlineLayer.fillColor = UIColor.green.withAlphaComponent(0.2).cgColor // Semi-transparent fill
        previewLayer.addSublayer(documentOutlineLayer)

        // Setup recognized text label
        recognizedTextLabel.textColor = .white
        recognizedTextLabel.numberOfLines = 0
        recognizedTextLabel.textAlignment = .left
        recognizedTextLabel.font = .systemFont(ofSize: 14)
        recognizedTextLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        recognizedTextLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(recognizedTextLabel)

        // Setup corrected image view (for debugging/displaying the corrected document)
        correctedImageView.contentMode = .scaleAspectFit
        correctedImageView.backgroundColor = .darkGray
        correctedImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(correctedImageView)

        NSLayoutConstraint.activate([
            recognizedTextLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            recognizedTextLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            recognizedTextLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -10),
            recognizedTextLabel.heightAnchor.constraint(lessThanOrEqualToConstant: 150), // Limit height

            correctedImageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            correctedImageView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            correctedImageView.widthAnchor.constraint(equalToConstant: 100),
            correctedImageView.heightAnchor.constraint(equalToConstant: 150)
        ])
    }

    private func checkCameraPermissions() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            setupCameraProcessor()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                DispatchQueue.main.async {
                    if granted {
                        self?.setupCameraProcessor()
                    } else {
                        self?.cameraProcessor(self!.cameraProcessor, didEncounterError: CameraProcessor.CameraProcessorError.authorizationDenied)
                    }
                }
            }
        case .denied, .restricted:
            cameraProcessor(cameraProcessor, didEncounterError: CameraProcessor.CameraProcessorError.authorizationDenied)
        @unknown default:
            fatalError("Unknown AVCaptureDevice.authorizationStatus")
        }
    }

    private func setupCameraProcessor() {
        cameraProcessor.delegate = self
        cameraProcessor.setupCameraAndVision()
    }

    // MARK: - CameraProcessorDelegate

    /// Handles detected document rectangles by drawing an overlay.
    func cameraProcessor(_ processor: CameraProcessor, didDetect rectangle: VNDocumentCameraRectangleObservation, in imageSize: CGSize) {
        if imageSize == .zero { // No document detected, clear overlay
            documentOutlineLayer.path = nil
            return
        }

        // Convert Vision's normalized points (0-1) to view coordinates
        func convertPoint(_ point: CGPoint) -> CGPoint {
            // Vision coordinates are normalized (0-1), origin bottom-left.
            // AVCaptureVideoPreviewLayer coordinates are UIKit (0-width, 0-height), origin top-left.
            // Need to flip Y and scale.
            let flippedY = CGPoint(x: point.x, y: 1 - point.y)
            return previewLayer.layerPointConverted(fromCaptureDevicePoint: flippedY)
        }

        let path = UIBezierPath()
        path.move(to: convertPoint(rectangle.topLeft))
        path.addLine(to: convertPoint(rectangle.topRight))
        path.addLine(to: convertPoint(rectangle.bottomRight))
        path.addLine(to: convertPoint(rectangle.bottomLeft))
        path.close()

        documentOutlineLayer.path = path.cgPath
    }

    /// Handles recognized text and updates the UI.
    func cameraProcessor(_ processor: CameraProcessor, didRecognize recognizedText: String, from correctedImage: CIImage) {
        recognizedTextLabel.text = recognizedText.isEmpty ? "No text recognized." : recognizedText

        // Convert CIImage to UIImage for display
        let context = CIContext()
        if let cgImage = context.createCGImage(correctedImage, from: correctedImage.extent) {
            correctedImageView.image = UIImage(cgImage: cgImage)
        } else {
            correctedImageView.image = nil
        }
    }

    /// Handles errors from the camera processor.
    func cameraProcessor(_ processor: CameraProcessor, didEncounterError error: Error) {
        DispatchQueue.main.async { [weak self] in
            let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self?.present(alert, animated: true)
            self?.cameraProcessor.stopRunning()
            self?.documentOutlineLayer.path = nil
            self?.recognizedTextLabel.text = "Error: \(error.localizedDescription)"
            self?.correctedImageView.image = nil
        }
    }
}
