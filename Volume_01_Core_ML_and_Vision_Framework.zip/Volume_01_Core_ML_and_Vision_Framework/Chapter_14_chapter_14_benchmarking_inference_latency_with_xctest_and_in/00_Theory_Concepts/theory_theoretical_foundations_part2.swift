
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreML
import Vision

@available(iOS 18.0, *)
class InferenceManager {
    let model: MyImageClassifier // Assume MyImageClassifier is your Core ML model class

    init(model: MyImageClassifier) {
        self.model = model
    }

    // Asynchronous inference function
    func performInference(imageBuffer: CVPixelBuffer) async throws -> MyImageClassifierOutput {
        // This work will run on a background thread provided by the Swift concurrency runtime.
        // The calling context can await its completion without blocking.
        let input = MyImageClassifierInput(image: imageBuffer)
        let prediction = try await model.prediction(input: input)
        return prediction
    }

    // Example of calling from a UI context (e.g., a SwiftUI View or UIKit ViewController)
    @MainActor
    func processImageAndDisplayResult(imageBuffer: CVPixelBuffer) {
        Task {
            do {
                let output = try await performInference(imageBuffer: imageBuffer)
                // Update UI with output on the main actor
                print("Inference complete: \(output.featureNames)")
            } catch {
                // Handle error on the main actor
                print("Inference failed: \(error)")
            }
        }
    }
}
