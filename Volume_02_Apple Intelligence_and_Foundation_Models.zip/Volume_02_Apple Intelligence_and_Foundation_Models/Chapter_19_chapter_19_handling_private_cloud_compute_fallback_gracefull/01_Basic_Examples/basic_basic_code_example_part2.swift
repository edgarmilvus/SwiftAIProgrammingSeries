
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

/// A simulated service representing an Apple Intelligence API for document processing.
/// This service demonstrates how compute policies influence where the processing occurs.
@available(iOS 18.0, macOS 15.0, *)
class AIProcessingService {

    /// Processes a document text based on the specified compute policy.
    ///
    /// - Parameters:
    ///   - documentText: The text content of the document to process.
    ///   - policy: The desired `AIComputePolicy` for this task.
    /// - Returns: An `AIProcessingResult` indicating the summary and the compute source.
    /// - Throws: An `AIProcessingError` if processing fails or is unavailable.
    func processDocument(documentText: String, policy: AIComputePolicy) async throws -> AIProcessingResult {
        print("Attempting to process document with policy: \(policy.rawValue)")

        // Simulate varying on-device capabilities/resource availability
        let onDeviceCapacityAvailable = Bool.random() // In a real app, this would be determined by the system.

        if policy == .onDeviceOnly || (policy == .onDevicePreferred && onDeviceCapacityAvailable) {
            // --- Attempt On-Device Compute ---
            print("Trying on-device compute...")
            try await Task.sleep(for: .seconds(Double.random(in: 0.5...2.0))) // Simulate on-device processing time

            if documentText.count < 100 && onDeviceCapacityAvailable { // Simulate on-device limits
                print("On-device compute successful!")
                return AIProcessingResult(
                    summary: "On-device summary: '\(documentText.prefix(50))...'",
                    source: .onDevice
                )
            } else if policy == .onDeviceOnly {
                print("On-device compute failed (e.g., text too long, resources low). Policy is On-Device Only.")
                throw AIProcessingError.notAvailable("On-device capacity insufficient or text too complex for current device.")
            }
        }

        // --- Fallback or Direct Private Cloud Compute ---
        if policy == .onDevicePreferred || policy == .privateCloudOnly {
            print("Falling back to Private Cloud Compute (or directly using PCC)...")
            try await Task.sleep(for: .seconds(Double.random(in: 2.0...5.0))) // Simulate PCC processing time

            // Simulate potential PCC network errors
            if Bool.random() && policy != .onDevicePreferred { // Make PCC fail sometimes if not fallback
                print("Simulating PCC network error.")
                throw AIProcessingError.networkError("Failed to connect to Private Cloud Compute.")
            }
            
            print("Private Cloud Compute successful!")
            return AIProcessingResult(
                summary: "Private Cloud Compute summary: '\(documentText.prefix(50))...'",
                source: .privateCloudCompute
            )
        }

        // Should not be reached if policies cover all cases, but good for completeness
        throw AIProcessingError.notAvailable("No valid compute path found for the given policy.")
    }
}
