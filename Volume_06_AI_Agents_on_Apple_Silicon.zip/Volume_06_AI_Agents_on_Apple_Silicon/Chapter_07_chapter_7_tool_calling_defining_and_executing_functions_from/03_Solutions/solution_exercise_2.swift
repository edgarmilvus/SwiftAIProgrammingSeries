
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

// MARK: - 1. Data Representation

struct WeatherReport: Codable {
    let city: String
    let temperature: Int
    let conditions: String
    let humidity: Int
    
    // Helper for user-friendly display
    var description: String {
        "The weather in \(city) is \(temperature)°C and \(conditions) with \(humidity)% humidity."
    }
}

// MARK: - 2. Tool Definition (Swift Function)

// Mock data store
let mockWeatherData: [String: WeatherReport] = [
    "London": WeatherReport(city: "London", temperature: 15, conditions: "partly cloudy", humidity: 70),
    "Paris": WeatherReport(city: "Paris", temperature: 20, conditions: "sunny", humidity: 60),
    "New York": WeatherReport(city: "New York", temperature: 25, conditions: "clear skies", humidity: 55),
    "Tokyo": WeatherReport(city: "Tokyo", temperature: 22, conditions: "rainy", humidity: 85)
]

func getWeatherForCity(city: String) -> WeatherReport? {
    // Simulate a lookup, case-insensitive
    return mockWeatherData[city.capitalized]
}

// MARK: - 3. Tool Description (JSON Schema - Manual Representation)

let weatherToolSchema: [String: Any] = [
    "type": "function",
    "function": [
        "name": "getWeatherForCity",
        "description": "Retrieves the current mock weather conditions for a specified city.",
        "parameters": [
            "type": "object",
            "properties": [
                "city": ["type": "string", "description": "The name of the city to get weather for (e.g., 'London', 'Paris')"]
            ],
            "required": ["city"]
        ]
    ]
]

// MARK: - 4. LLM Integration (Mocking LLM Output)

// Structs to decode the LLM's expected JSON tool call output
struct WeatherToolCallArgument: Codable {
    let city: String
}

struct WeatherToolCall: Codable {
    let toolName: String
    let arguments: WeatherToolCallArgument
}

// Simulate LLM's response
func simulateLLMWeatherToolCall(for prompt: String) -> WeatherToolCall? {
    if prompt.contains("weather") {
        if prompt.contains("London") {
            return WeatherToolCall(toolName: "getWeatherForCity", arguments: WeatherToolCallArgument(city: "London"))
        } else if prompt.contains("Paris") {
            return WeatherToolCall(toolName: "getWeatherForCity", arguments: WeatherToolCallArgument(city: "Paris"))
        } else if prompt.contains("New York") {
            return WeatherToolCall(toolName: "getWeatherForCity", arguments: WeatherToolCallArgument(city: "New York"))
        } else if prompt.contains("Tokyo") {
            return WeatherToolCall(toolName: "getWeatherForCity", arguments: WeatherToolCallArgument(city: "Tokyo"))
        } else if prompt.contains("Berlin") { // Simulate a city not in mock data
            return WeatherToolCall(toolName: "getWeatherForCity", arguments: WeatherToolCallArgument(city: "Berlin"))
        }
    }
    return nil
}

// MARK: - 5. Tool Call Parsing & Execution

func executeWeatherToolCall(toolCall: WeatherToolCall) -> String {
    let city = toolCall.arguments.city
    
    if let weatherReport = getWeatherForCity(city: city) {
        return "Tool 'getWeatherForCity' executed successfully. \(weatherReport.description)"
    } else {
        return "Error executing tool 'getWeatherForCity': Could not find weather data for \(city)."
    }
}

// MARK: - Main Interaction Flow (Simulation)

func processUserWeatherPrompt(prompt: String) {
    print("User: \(prompt)")
    
    if let toolCall = simulateLLMWeatherToolCall(for: prompt) {
        print("LLM suggests tool call: \(toolCall.toolName) with arguments city:\(toolCall.arguments.city)")
        let executionResult = executeWeatherToolCall(toolCall: toolCall)
        print("Tool Execution Result: \(executionResult)")
        // In a real app, this result would be sent back to the LLM for summarization.
        print("AI Assistant: \(executionResult)")
    } else {
        print("AI Assistant: I can't find a suitable tool for that request or understand the city.")
    }
    print("---")
}

// Test cases
processUserWeatherPrompt(prompt: "What's the weather like in London?")
processUserWeatherPrompt(prompt: "Tell me about the weather in New York.")
processUserWeatherPrompt(prompt: "Is it raining in Tokyo?")
processUserWeatherPrompt(prompt: "What's the forecast for Berlin?") // City not found
processUserWeatherPrompt(prompt: "How are you doing today?") // No tool call
