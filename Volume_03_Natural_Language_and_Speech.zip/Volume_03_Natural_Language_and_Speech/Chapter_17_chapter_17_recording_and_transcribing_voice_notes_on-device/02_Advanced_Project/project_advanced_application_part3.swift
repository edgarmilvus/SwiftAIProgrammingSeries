
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

/// Represents the comprehensive analysis result of a voice journal entry.
struct VoiceJournalAnalysisResult: Identifiable {
    let id = UUID()
    let audioFileURL: URL
    let transcription: String
    let sentimentScore: Double? // Nil if sentiment analysis fails or isn't applicable
    let sentimentDescription: String

    /// Provides a human-readable description of the sentiment score.
    var formattedSentiment: String {
        guard let score = sentimentScore else { return "N/A" }
        switch score {
        case ..< -0.5: return "Very Negative (\(String(format: "%.2f", score)))"
        case -0.5 ..< -0.1: return "Negative (\(String(format: "%.2f", score)))"
        case -0.1 ... 0.1: return "Neutral (\(String(format: "%.2f", score)))"
        case 0.1 ..< 0.5: return "Positive (\(String(format: "%.2f", score)))"
        case 0.5...: return "Very Positive (\(String(format: "%.2f", score)))"
        default: return "N/A"
        }
    }
}
