
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// MARK: - Exercise 3: Smart Home Scene Manager

// 1. Smart Home State Management
class SmartHomeState: CustomStringConvertible {
    var lights: [String: (isOn: Bool, color: String)]
    var thermostats: [String: (currentTemperature: Double, targetTemperature: Double)]
    var scenes: [String: [String]]

    init() {
        self.lights = [
            "Living Room Light": (isOn: false, color: "white"),
            "Bedroom Lamp": (isOn: true, color: "yellow")
        ]
        self.thermostats = [
            "Main Thermostat": (currentTemperature: 21.0, targetTemperature: 21.0),
            "Bedroom Thermostat": (currentTemperature: 20.0, targetTemperature: 20.0)
        ]
        self.scenes = [
            "Movie Night": ["Set Living Room Light to Red", "Turn off Bedroom Lamp", "Set Main Thermostat to 20C"],
            "Good Morning": ["Turn on Bedroom Lamp", "Set Main Thermostat to 22C"]
        ]
    }

    // For better debugging output
    var description: String {
        let lightStates = lights.map { "\($0.key): {isOn: \($0.value.isOn), color: \($0.value.color)}" }.joined(separator: ", ")
        let thermostatStates = thermostats.map { "\($0.key): {current: \($0.value.currentTemperature)°C, target: \($0.value.targetTemperature)°C}" }.joined(separator: ", ")
        return "\n  Lights: [\(lightStates)]\n  Thermostats: [\(thermostatStates)]"
    }
}

// 2. Define Multiple Smart Home Tools

// 2.1. SetLightStateTool
struct SetLightStateArguments: Codable {
    let lightName: String
    let isOn: Bool?
    let color: String? // e.g., "red", "blue", "white", "yellow"
}

struct SetLightStateTool: Tool {
    let name: String = "set_light_state_tool"
    let description: String = "Sets the power state (on/off) or color of a specific smart light."
    let parametersSchema: String = """
    {
        "type": "object",
        "properties": {
            "lightName": {
                "type": "string",
                "description": "The name of the light to control (e.g., 'Living Room Light', 'Bedroom Lamp')."
            },
            "isOn": {
                "type": "boolean",
                "description": "Whether the light should be turned on or off."
            },
            "color": {
                "type": "string",
                "enum": ["red", "blue", "white", "yellow", "green"],
                "description": "The color to set the light to."
            }
        },
        "required": ["lightName"]
    }
    """

    typealias Arguments = SetLightStateArguments

    // SmartHomeState dependency injected during initialization
    let smartHomeState: SmartHomeState

    func execute(arguments: SetLightStateArguments) async throws -> String {
        guard var light = smartHomeState.lights[arguments.lightName] else {
            throw ToolError.lightNotFound(arguments.lightName)
        }

        if let isOn = arguments.isOn {
            light.isOn = isOn
        }
        if let color = arguments.color {
            light.color = color
        }
        smartHomeState.lights[arguments.lightName] = light

        return "Successfully updated '\(arguments.lightName)': isOn=\(light.isOn), color=\(light.color)."
    }
}

// 2.2. AdjustThermostatTool
struct AdjustThermostatArguments: Codable {
    let thermostatName: String
    let targetTemperature: Double
}

struct AdjustThermostatTool: Tool {
    let name: String = "adjust_thermostat_tool"
    let description: String = "Adjusts the target temperature of a specific smart thermostat."
    let parametersSchema: String = """
    {
        "type": "object",
        "properties": {
            "thermostatName": {
                "type": "string",
                "description": "The name of the thermostat to control (e.g., 'Main Thermostat', 'Bedroom Thermostat')."
            },
            "targetTemperature": {
                "type": "number",
                "description": "The desired target temperature in Celsius (e.g., 22.5)."
            }
        },
        "required": ["thermostatName", "targetTemperature"]
    }
    """

    typealias Arguments = AdjustThermostatArguments

    let smartHomeState: SmartHomeState

    func execute(arguments: AdjustThermostatArguments) async throws -> String {
        guard var thermostat = smartHomeState.thermostats[arguments.thermostatName] else {
            throw ToolError.thermostatNotFound(arguments.thermostatName)
        }

        let minTemp: Double = 15.0
        let maxTemp: Double = 30.0
        guard arguments.targetTemperature >= minTemp && arguments.targetTemperature <= maxTemp else {
            throw ToolError.temperatureOutOfRange(arguments.targetTemperature, min: minTemp, max: maxTemp)
        }

        thermostat.targetTemperature = arguments.targetTemperature
        smartHomeState.thermostats[arguments.thermostatName] = thermostat

        return "Successfully set '\(arguments.thermostatName)' target temperature to \(arguments.targetTemperature)°C."
    }
}

// 2.3. ActivateSceneTool
struct ActivateSceneArguments: Codable {
    let sceneName: String
}

struct ActivateSceneTool: Tool {
    let name: String = "activate_scene_tool"
    let description: String = "Activates a predefined smart home scene."
    let parametersSchema: String = """
    {
        "type": "object",
        "properties": {
            "sceneName": {
                "type": "string",
                "description": "The name of the scene to activate (e.g., 'Movie Night', 'Good Morning')."
            }
        },
        "required": ["sceneName"]
    }
    """

    typealias Arguments = ActivateSceneArguments

    let smartHomeState: SmartHomeState

    func execute(arguments: ActivateSceneArguments) async throws -> String {
        guard let actions = smartHomeState.scenes[arguments.sceneName] else {
            throw ToolError.sceneNotFound(arguments.sceneName)
        }

        let actionsDescription = actions.joined(separator: ", ")
        return "Scene '\(arguments.sceneName)' activated. Actions performed: [\(actionsDescription)]."
    }
}

// 4. Orchestrate the Tool-Calling Loop Simulation
func runExercise3() async {
    print("\n--- Running Exercise 3: Smart Home Scene Manager ---")

    let smartHomeState = SmartHomeState()
    let registry = ToolRegistry()

    // Register smart home tools with the shared state
    registry.registerTool(SetLightStateTool(smartHomeState: smartHomeState))
    registry.registerTool(AdjustThermostatTool(smartHomeState: smartHomeState))
    registry.registerTool(ActivateSceneTool(smartHomeState: smartHomeState))

    print("Initial Smart Home State: \(smartHomeState)")

    let scenarios: [(String, String)] = [
        ("Turn on Living Room Light", """
        {
            "toolName": "set_light_state_tool",
            "arguments": "{\\"lightName\\": \\"Living Room Light\\", \\"isOn\\": true}"
        }
        """),
        ("Set Bedroom Lamp to Yellow", """
        {
            "toolName": "set_light_state_tool",
            "arguments": "{\\"lightName\\": \\"Bedroom Lamp\\", \\"color\\": \\"yellow\\"}"
        }
        """),
        ("Set Main Thermostat to 22.5C", """
        {
            "toolName": "adjust_thermostat_tool",
            "arguments": "{\\"thermostatName\\": \\"Main Thermostat\\", \\"targetTemperature\\": 22.5}"
        }
        """),
        ("Activate Movie Night Scene", """
        {
            "toolName": "activate_scene_tool",
            "arguments": "{\\"sceneName\\": \\"Movie Night\\"}"
        }
        """),
        ("Attempt to control non-existent light", """
        {
            "toolName": "set_light_state_tool",
            "arguments": "{\\"lightName\\": \\"Garage Light\\", \\"isOn\\": true}"
        }
        """),
        ("Attempt to set thermostat to extreme temperature", """
        {
            "toolName": "adjust_thermostat_tool",
            "arguments": "{\\"thermostatName\\": \\"Main Thermostat\\", \\"targetTemperature\\": 35.0}"
        }
        """),
        ("Attempt to activate non-existent scene", """
        {
            "toolName": "activate_scene_tool",
            "arguments": "{\\"sceneName\\": \\"Party Time\\"}"
        }
        """)
    ]

    for (description, json) in scenarios {
        print("\n=== Scenario: \(description) ===")
        do {
            let result = try await processLLMResponse(toolCallJSON: json, registry: registry, smartHomeState: smartHomeState)
            print("Tool Output: \(result)")
        } catch {
            print("Agent Error: \(error.localizedDescription)")
        }
        print("Updated Smart Home State: \(smartHomeState)")
    }
}
