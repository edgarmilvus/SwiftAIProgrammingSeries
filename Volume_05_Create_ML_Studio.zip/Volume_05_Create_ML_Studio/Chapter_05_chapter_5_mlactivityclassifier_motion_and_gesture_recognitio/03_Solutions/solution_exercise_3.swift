
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import CoreMotion
import Foundation // For file operations

@available(iOS 18.0, *)
class GestureDataCollectorViewController: UIViewController {

    let motionManager = CMMotionManager()
    var recordedData: [(timestamp: TimeInterval, accelX: Double, accelY: Double, accelZ: Double, gyroX: Double, gyroY: Double, gyroZ: Double)] = []
    var isRecording = false {
        didSet {
            recordButton.setTitle(isRecording ? "Stop Recording" : "Start Recording", for: .normal)
            recordButton.backgroundColor = isRecording ? .systemRed : .systemGreen
            gestureSelector.isEnabled = !isRecording
        }
    }
    var currentGestureLabel: String = "vertical_wave" // Default label for recording

    let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Select gesture and tap record."
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 18, weight: .semibold)
        label.numberOfLines = 0
        return label
    }()

    let gestureSelector: UISegmentedControl = {
        let items = ["Vertical Wave", "Horizontal Swipe"]
        let control = UISegmentedControl(items: items)
        control.selectedSegmentIndex = 0
        control.selectedSegmentTintColor = .systemBlue
        return control
    }()

    let recordButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Start Recording", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 20, weight: .bold)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .systemGreen
        button.layer.cornerRadius = 10
        return button
    }()

    let instructionsLabel: UILabel = {
        let label = UILabel()
        label.text = "Instructions: Perform the selected gesture for 3-5 seconds while recording."
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 15)
        label.numberOfLines = 0
        label.textColor = .secondaryLabel
        return label
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        setupMotionManager()
        setupButtonActions()
        updateInstructions() // Initial instructions
    }

    private func setupUI() {
        let stackView = UIStackView(arrangedSubviews: [statusLabel, gestureSelector, instructionsLabel, recordButton])
        stackView.axis = .vertical
        stackView.spacing = 20
        stackView.alignment = .center
        stackView.distribution = .fillProportionally

        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),

            recordButton.heightAnchor.constraint(equalToConstant: 60),
            recordButton.widthAnchor.constraint(equalTo: stackView.widthAnchor, multiplier: 0.8)
        ])
    }

    private func setupMotionManager() {
        if motionManager.isAccelerometerAvailable && motionManager.isGyroAvailable {
            motionManager.accelerometerUpdateInterval = 0.01 // 100 Hz
            motionManager.gyroUpdateInterval = 0.01          // 100 Hz
            statusLabel.text = "Ready to record motion data."
        } else {
            statusLabel.text = "Error: Accelerometer or Gyroscope not available."
            recordButton.isEnabled = false
            gestureSelector.isEnabled = false
        }
    }

    private func setupButtonActions() {
        recordButton.addTarget(self, action: #selector(recordButtonTapped), for: .touchUpInside)
        gestureSelector.addTarget(self, action: #selector(gestureSelectionChanged), for: .valueChanged)
    }

    @objc private func gestureSelectionChanged() {
        currentGestureLabel = gestureSelector.selectedSegmentIndex == 0 ? "vertical_wave" : "horizontal_swipe"
        updateInstructions()
        statusLabel.text = "Selected: \(currentGestureLabel.capitalized.replacingOccurrences(of: "_", with: " ")). Tap record."
    }

    private func updateInstructions() {
        if currentGestureLabel == "vertical_wave" {
            instructionsLabel.text = "Instructions: Hold device upright and move it up and down rhythmically."
        } else {
            instructionsLabel.text = "Instructions: Hold device upright and move it left and right rhythmically."
        }
    }

    @objc private func recordButtonTapped() {
        if isRecording {
            stopRecording()
        } else {
            startRecording()
        }
    }

    private func startRecording() {
        guard motionManager.isAccelerometerAvailable && motionManager.isGyroAvailable else {
            statusLabel.text = "Error: Motion sensors not available."
            return
        }

        recordedData.removeAll()
        isRecording = true
        statusLabel.text = "Recording \(currentGestureLabel.capitalized.replacingOccurrences(of: "_", with: " "))..."

        motionManager.startAccelerometerUpdates(to: .main) { [weak self] (accelerometerData, error) in
            guard let self = self, self.isRecording else { return }
            if let accel = accelerometerData?.acceleration {
                let timestamp = Date().timeIntervalSince1970
                // Store placeholder gyro data; will be updated when gyro data arrives
                self.recordedData.append((timestamp, accel.x, accel.y, accel.z, 0, 0, 0))
            }
        }

        motionManager.startGyroUpdates(to: .main) { [weak self] (gyroData, error) in
            guard let self = self, self.isRecording else { return }
            if let gyro = gyroData?.rotationRate {
                let timestamp = Date().timeIntervalSince1970
                // Find the closest accelerometer data point by timestamp and update it
                // This is a simplified approach. A more robust solution would synchronize streams.
                if var lastAccelData = self.recordedData.last,
                   abs(lastAccelData.timestamp - timestamp) < self.motionManager.gyroUpdateInterval * 2 { // Within a reasonable window
                    lastAccelData.gyroX = gyro.x
                    lastAccelData.gyroY = gyro.y
                    lastAccelData.gyroZ = gyro.z
                    self.recordedData[self.recordedData.count - 1] = lastAccelData
                } else {
                    // If no recent accel data, add a new entry with placeholder accel data
                    self.recordedData.append((timestamp, 0, 0, 0, gyro.x, gyro.y, gyro.z))
                }
            }
        }
        print("Started recording for \(currentGestureLabel).")
    }

    private func stopRecording() {
        motionManager.stopAccelerometerUpdates()
        motionManager.stopGyroUpdates()
        isRecording = false
        statusLabel.text = "Recording stopped. Saving data..."
        saveRecordedDataToFile()
        print("Stopped recording for \(currentGestureLabel).")
    }

    private func saveRecordedDataToFile() {
        guard !recordedData.isEmpty else {
            statusLabel.text = "No data recorded."
            return
        }

        let timestamp = Int(Date().timeIntervalSince1970)
        let filename = "\(currentGestureLabel)_\(timestamp).csv"
        let header = "timestamp,accelerometer_x,accelerometer_y,accelerometer_z,gyroscope_x,gyroscope_y,gyroscope_z\n"
        var csvString = header

        for dataPoint in recordedData {
            csvString += "\(dataPoint.timestamp),\(dataPoint.accelX),\(dataPoint.accelY),\(dataPoint.accelZ),\(dataPoint.gyroX),\(dataPoint.gyroY),\(dataPoint.gyroZ)\n"
        }

        do {
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            let fileURL = documentsURL.appendingPathComponent(filename)
            try csvString.write(to: fileURL, atomically: true, encoding: .utf8)
            statusLabel.text = "Data saved to \(filename)"
            print("Data saved to: \(fileURL.lastPathComponent)")
            // Optionally, print the path to console for easy access in Xcode's device logs
            print("Full path: \(fileURL.path)")
        } catch {
            statusLabel.text = "Failed to save data: \(error.localizedDescription)"
            print("Error saving data: \(error)")
        }

        recordedData.removeAll() // Clear data after saving
    }

    deinit {
        motionManager.stopAccelerometerUpdates()
        motionManager.stopGyroUpdates()
    }
}

// MARK: - Part 2: Model Integration (Conceptual & Implementation)

// You will need to add SmartHomeGestureClassifier.mlmodel to your project.
// For testing, you could create a dummy model or simply assume its existence
// and focus on the Swift integration part.

@available(iOS 18.0, *)
class SmartHomeControlViewController: UIViewController {

    let statusLabel: UILabel = {
        let label = UILabel()
        label.text = "Waiting for smart home gestures..."
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 22, weight: .bold)
        label.numberOfLines = 0
        return label
    }()

    private var smartHomeClassifier: MLActivityClassifier?

    // Debouncing variables to prevent rapid action toggling
    private var lastDetectedSmartHomeGesture: String?
    private var lastSmartHomeDetectionTime: Date?
    private let smartHomeGestureCooldown: TimeInterval = 1.5 // Cooldown for smart home actions

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        setupSmartHomeClassifier()
    }

    private func setupUI() {
        view.addSubview(statusLabel)
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            statusLabel.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.9)
        ])
    }

    private func setupSmartHomeClassifier() {
        guard MLActivityClassifier.isActivityMonitoringAvailable() else {
            statusLabel.text = "Error: Activity monitoring not available on this device."
            return
        }

        do {
            // Assume SmartHomeGestureClassifier.mlmodel has been dragged into the project
            // and Xcode has generated its Swift class.
            // For a real custom model, you'd use:
            // guard let modelURL = Bundle.main.url(forResource: "SmartHomeGestureClassifier", withExtension: "mlmodelc") else {
            //     throw NSError(domain: "SmartHomeControl", code: 1, userInfo: [NSLocalizedDescriptionKey: "Model not found"])
            // }
            // self.smartHomeClassifier = try MLActivityClassifier(model: modelURL)

            // For demonstration, we'll use the default MLActivityClassifier and
            // pretend it outputs "vertical_wave", "horizontal_swipe", "none".
            self.smartHomeClassifier = MLActivityClassifier()
            startSmartHomeMonitoring()
        } catch {
            statusLabel.text = "Failed to load smart home gesture classifier: \(error.localizedDescription)"
            print("Failed to load smart home gesture classifier: \(error)")
        }
    }

    private func startSmartHomeMonitoring() {
        guard let classifier = smartHomeClassifier else { return }

        classifier.startActivityUpdates(to: .main) { [weak self] (prediction, error) in
            guard let self = self else { return }

            if let error = error {
                DispatchQueue.main.async {
                    self.statusLabel.text = "Error monitoring smart home gestures: \(error.localizedDescription)"
                    print("MLActivityClassifier Error: \(error.localizedDescription)")
                    self.smartHomeClassifier?.stopActivityUpdates()
                }
                return
            }

            if let prediction = prediction {
                DispatchQueue.main.async {
                    self.statusLabel.text = "Detected: \(prediction.label.capitalized.replacingOccurrences(of: "_", with: " ")) (Confidence: \(String(format: "%.2f", prediction.confidence)))"
                    self.handleSmartHomeGesturePrediction(prediction)
                }
            }
        }
        print("Smart home gesture monitoring started.")
    }

    private func handleSmartHomeGesturePrediction(_ prediction: MLActivityClassifier.Prediction) {
        let currentGesture = prediction.label
        let currentTime = Date()

        // Debounce logic
        if let lastGesture = lastDetectedSmartHomeGesture,
           let lastTime = lastSmartHomeDetectionTime,
           currentTime.timeIntervalSince(lastTime) < smartHomeGestureCooldown,
           lastGesture == currentGesture {
            return // Still within cooldown for the same gesture
        }

        guard prediction.confidence > 0.85 else { // Higher confidence for critical actions
            return
        }

        switch currentGesture {
        case "vertical_wave":
            print("Toggling Lights!")
            // Simulate haptic feedback for action confirmation
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            lastDetectedSmartHomeGesture = currentGesture
            lastSmartHomeDetectionTime = currentTime
        case "horizontal_swipe":
            print("Adjusting Brightness!")
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            lastDetectedSmartHomeGesture = currentGesture
            lastSmartHomeDetectionTime = currentTime
        case "none":
            // No action for "none", allow other gestures to be detected
            break
        default:
            break
        }
    }

    deinit {
        smartHomeClassifier?.stopActivityUpdates()
    }
}
