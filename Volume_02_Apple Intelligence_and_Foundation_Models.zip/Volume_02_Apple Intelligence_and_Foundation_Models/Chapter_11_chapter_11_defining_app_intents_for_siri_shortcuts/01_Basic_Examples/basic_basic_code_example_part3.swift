
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.swift
// Description: Basic Code Example
// ==========================================

import AppIntents
import Foundation

/// An AppEntity that represents a `Reminder` for App Intents.
/// This allows Siri and Shortcuts to identify and refer to specific reminders in our app.
@available(iOS 18.0, *) // App Intents are available from iOS 18
struct ReminderAppEntity: AppEntity {
    // The unique identifier for this entity. Must match the ID of our Reminder struct.
    let id: UUID
    // The title of the reminder, used for display purposes in Siri/Shortcuts UI.
    let title: String
    // The completion status of the reminder.
    let isCompleted: Bool

    // Required initializer to create an AppEntity instance.
    init(id: UUID, title: String, isCompleted: Bool) {
        self.id = id
        self.title = title
        self.isCompleted = isCompleted
    }

    // Convenience initializer to create an AppEntity from our Reminder struct.
    init(reminder: Reminder) {
        self.id = reminder.id
        self.title = reminder.title
        self.isCompleted = reminder.isCompleted
    }

    /// The display representation of this entity, shown in Siri and Shortcuts.
    /// This should be user-friendly and clearly identify the entity.
    static var defaultDisplayRepresentation: DisplayRepresentation {
        DisplayRepresentation(title: "Reminder")
    }

    /// How this entity is displayed when a specific instance is shown.
    /// For example, "Buy groceries" instead of just "Reminder".
    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(
            title: "\(title)",
            subtitle: isCompleted ? "Completed" : "Pending"
        )
    }

    /// The query provider for this entity. This tells Siri how to find instances
    /// of this entity (e.g., all reminders, or a specific reminder by ID).
    static var defaultQuery: ReminderEntityQuery {
        ReminderEntityQuery()
    }

    // You can also define custom properties for filtering or sorting if needed.
    // static var properties = EntityProperties {
    //     Property(\.$title)
    // }
}

/// The query object responsible for fetching `ReminderAppEntity` instances.
/// This is how Siri asks your app for a list of reminders or a specific reminder.
@available(iOS 18.0, *)
struct ReminderEntityQuery: EntityQuery {
    /// Fetches a specific `ReminderAppEntity` by its ID.
    /// This is used when Siri knows the ID of the reminder (e.g., from a previous interaction).
    func entities(for identifiers: [UUID]) async throws -> [ReminderAppEntity] {
        let reminders = identifiers.compactMap { id in
            ReminderStore.shared.findReminder(by: id)
        }
        return reminders.map(ReminderAppEntity.init)
    }

    /// Fetches all available `ReminderAppEntity` instances.
    /// This is used when Siri needs to present a list of choices to the user.
    func suggestedEntities() async throws -> [ReminderAppEntity] {
        // Only suggest pending reminders for actions like "mark complete"
        let pendingReminders = ReminderStore.shared.getAllReminders().filter { !$0.isCompleted }
        return pendingReminders.map(ReminderAppEntity.init)
    }

    // You can also implement `entities(matching:)` for text-based searches if needed.
    // func entities(matching query: String) async throws -> [ReminderAppEntity] {
    //     let matchingReminders = ReminderStore.shared.getAllReminders().filter {
    //         $0.title.localizedCaseInsensitiveContains(query)
    //     }
    //     return matchingReminders.map(ReminderAppEntity.init)
    // }
}
