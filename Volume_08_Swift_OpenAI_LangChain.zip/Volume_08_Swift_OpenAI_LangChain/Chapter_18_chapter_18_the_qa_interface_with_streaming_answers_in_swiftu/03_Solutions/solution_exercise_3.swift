
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import Observation

// A wrapper to bridge UIKit's selection capabilities to SwiftUI
struct TextViewRepresentable: UIViewRepresentable {
    @Binding var selectedText: String
    
    func makeUIView(context: Context) -> UITextView {
        let textView = UITextView()
        textView.delegate = context.coordinator
        textView.font = .preferredFont(forTextStyle: .body)
        return textView
    }
    
    func updateUIView(_ uiView: UITextView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UITextViewDelegate {
        var parent: TextViewRepresentable
        init(_ parent: TextViewRepresentable) { self.parent = parent }
        
        func textViewDidChangeSelection(_ textView: UITextView) {
            let range = textView.selectedTextRange
            if let range = range, let selected = textView.text(in: range) {
                if !selected.isEmpty {
                    parent.selectedText = selected
                }
            } else {
                parent.selectedText = ""
            }
        }
    }
}

@Observable
@MainActor
class SidebarViewModel {
    var explanation: String = ""
    var activeTask: Task<Void, Never>? = nil
    
    func processSelection(_ text: String) {
        // CRITICAL: Cancel the previous task before starting a new one
        activeTask?.cancel()
        
        guard !text.isEmpty else {
            explanation = ""
            return
        }
        
        explanation = "Analyzing..."
        
        // Start a new task for the new selection
        activeTask = Task {
            let stream = simulateExplanationStream(for: text)
            explanation = "" // Clear "Analyzing..."
            
            for await chunk in stream {
                if Task.isCancelled { break }
                explanation += chunk
            }
        }
    }
    
    private func simulateExplanationStream(for input: String) -> AsyncStream<String> {
        AsyncStream { continuation in
            Task {
                let response = "You selected: '\(input)'. This concept relates to..."
                let words = response.components(separatedBy: " ")
                for word in words {
                    try? await Task.sleep(for: .milliseconds(150))
                    continuation.yield(word + " ")
                }
                continuation.finish()
            }
        }
    }
}

struct InsightFlowView: View {
    @State private var selectedText = ""
    @State private var sidebarVM = SidebarViewModel()

    var body: some View {
        NavigationSplitView {
            VStack {
                Text("Editor")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                TextViewRepresentable(selectedText: $selectedText)
            }
            .onChange(of: selectedText) { _, newValue in
                sidebarVM.processSelection(newValue)
            }
        } detail: {
            if !selectedText.isEmpty {
                VStack(alignment: .leading) {
                    Text("AI Insight")
                        .font(.headline)
                    Divider()
                    Text(sidebarVM.explanation)
                        .font(.body)
                    Spacer()
                }
                .padding()
                .transition(.move(edge: .trailing).combined(with: .opacity))
            } else {
                ContentUnavailableView("No Selection", systemImage: "textformat.size", description: Text("Select text to see AI insights."))
            }
        }
    }
}
