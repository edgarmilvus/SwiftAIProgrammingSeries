/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { 
  View, 
  TextInput, 
  Platform, 
  StyleSheet, 
  Dimensions,
  KeyboardAvoidingView,
  SafeAreaView,
  StatusBar
} from 'react-native';

// Helper to determine if the platform is mobile
const isMobile = Platform.OS === 'ios' || Platform.OS === 'android';

export const ChatInput = () => {
  const [text, onChangeText] = useState('');

  // Dynamic styling based on Platform.OS
  const containerStyle = [
    styles.containerBase,
    isMobile ? styles.containerMobile : styles.containerWeb,
    Platform.OS === 'ios' ? styles.iosSpecific : null,
    Platform.OS === 'android' ? styles.androidSpecific : null,
  ];

  const inputStyle = [
    styles.inputBase,
    isMobile ? styles.inputMobile : styles.inputWeb,
  ];

  return (
    <View style={styles.wrapper}>
      {/* 
        On mobile, we wrap in KeyboardAvoidingView to prevent the keyboard 
        from covering the input. On Web, this is usually handled by the browser 
        or a CSS sticky footer approach.
      */}
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={containerStyle}
      >
        <TextInput
          style={inputStyle}
          value={text}
          onChangeText={onChangeText}
          placeholder="Type a message..."
          placeholderTextColor={Platform.OS === 'android' ? '#888' : '#999'}
          // Web specific props can be passed safely, ignored on native
          // @ts-ignore - web specific prop
          enterKeyHint="send"
        />
      </KeyboardAvoidingView>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    flex: 1, // Ensures the wrapper takes available space
  },
  // --- Base Styles ---
  containerBase: {
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  inputBase: {
    borderWidth: 1,
    borderRadius: 5,
    fontSize: 16,
    paddingHorizontal: 15,
  },

  // --- Mobile Specific (iOS & Android) ---
  containerMobile: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#f9f9f9',
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
    paddingBottom: 20, // Safe area padding
  },
  inputMobile: {
    backgroundColor: '#fff',
    paddingVertical: 12,
    borderColor: '#d1d1d1',
  },

  // --- Web Specific ---
  containerWeb: {
    position: 'relative',
    width: '100%',
    maxWidth: 800,
    marginHorizontal: 'auto', // Center if container allows
    backgroundColor: 'transparent',
  },
  inputWeb: {
    width: '100%',
    backgroundColor: '#fff',
    borderColor: '#ccc',
    paddingVertical: 10,
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)', // Web shadow
  },

  // --- Platform Nuances ---
  iosSpecific: {
    backgroundColor: '#f2f2f7',
  },
  androidSpecific: {
    elevation: 4,
    backgroundColor: '#fff',
  },
});
