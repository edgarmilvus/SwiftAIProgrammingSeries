/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part5.ts
// Description: Advanced Application Script
// ==========================================

// packages/shared/components/AnalyticsDisplay.native.tsx

import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { AnalyticsDataPoint } from '../types/analytics';

/**
 * @description Native-specific rendering of analytics data.
 * Uses React Native components (FlatList) for performance on mobile.
 * @param data - Array of analytics points.
 */
export const AnalyticsDisplay: React.FC<{ data: AnalyticsDataPoint[] }> = ({ data }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Real-Time Analytics (Mobile)</Text>
      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text style={styles.metric}>{item.metric}</Text>
            <Text style={styles.value}>{item.value}</Text>
            <Text style={styles.time}>
              {item.timestamp.toLocaleTimeString()}
            </Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#f5f5f5' },
  header: { fontSize: 20, fontWeight: 'bold', marginBottom: 16 },
  item: {
    backgroundColor: 'white',
    padding: 12,
    marginBottom: 8,
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metric: { fontSize: 16, fontWeight: '600' },
  value: { fontSize: 16, color: '#007AFF' },
  time: { fontSize: 12, color: '#666' },
});
