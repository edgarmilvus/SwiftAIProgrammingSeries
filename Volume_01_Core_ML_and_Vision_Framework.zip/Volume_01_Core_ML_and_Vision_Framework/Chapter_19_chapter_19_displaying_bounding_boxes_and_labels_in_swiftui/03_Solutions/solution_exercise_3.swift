
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import CoreGraphics // For CGRect
import Foundation   // For UUID

// MARK: - Reusing Mock Data Structures & Helper from Exercise 1

// DetectionResult, CGRect.visionToSwiftUIRect, and BoundingBoxOverlay are reused.
// BoundingBoxOverlay is configured to handle `isSelected` state.

// MARK: - Exercise 3 Solution View

struct Exercise3View: View {
    // Mock dataset
    let detections: [DetectionResult] = [
        .init(boundingBox: CGRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4), label: "Cat", confidence: 0.98),
        .init(boundingBox: CGRect(x: 0.5, y: 0.6, width: 0.2, height: 0.3), label: "Dog", confidence: 0.85),
        .init(boundingBox: CGRect(x: 0.05, y: 0.8, width: 0.15, height: 0.1), label: "Bird", confidence: 0.72),
        .init(boundingBox: CGRect(x: 0.7, y: 0.1, width: 0.25, height: 0.2), label: "Car", confidence: 0.91)
    ]

    // State to manage the currently selected object's ID
    @State private var selectedObjectID: UUID?

    var body: some View {
        VStack {
            Text("Exercise 3: Interactive Object Selection")
                .font(.headline)
                .padding()

            GeometryReader { geometry in
                Image("sample_image") // <--- IMPORTANT: Add "sample_image.jpg" to your asset catalog
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .overlay(
                        ZStack {
                            ForEach(detections) { detection in
                                let swiftUIRect = CGRect.visionToSwiftUIRect(
                                    normalizedRect: detection.boundingBox,
                                    imageSize: geometry.size
                                )
                                
                                BoundingBoxOverlay(
                                    id: detection.id,
                                    swiftUIRect: swiftUIRect,
                                    label: detection.label,
                                    confidence: detection.confidence,
                                    containerSize: geometry.size,
                                    isSelected: detection.id == selectedObjectID, // Pass selection state
                                    displayConfidence: true,
                                    strokeColor: .blue,
                                    labelPlacementPreference: .auto
                                )
                                // Make the entire bounding box area tappable
                                .contentShape(Rectangle()) // Makes the transparent parts tappable
                                .onTapGesture {
                                    if selectedObjectID == detection.id {
                                        selectedObjectID = nil // Deselect if tapped again
                                    } else {
                                        selectedObjectID = detection.id // Select new object
                                    }
                                }
                            }
                        }
                    )
            }
            .padding()

            // Display selected object's UUID
            Text(selectedObjectID != nil ? "Selected ID: \(selectedObjectID!.uuidString)" : "No object selected.")
                .font(.subheadline)
                .padding()
        }
    }
}

// Preview Provider
struct Exercise3View_Previews: PreviewProvider {
    static var previews: some View {
        Exercise3View()
    }
}
