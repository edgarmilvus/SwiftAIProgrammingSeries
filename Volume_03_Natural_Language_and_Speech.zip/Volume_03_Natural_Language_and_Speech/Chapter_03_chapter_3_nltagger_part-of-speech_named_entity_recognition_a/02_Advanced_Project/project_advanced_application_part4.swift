
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

// MARK: - Main Application Flow Demonstration

/// Simulates the main application entry point or a view model.
@main
struct SmartScannerApp {
    static func main() async {
        let analyzer = DocumentAnalyzer()

        // Example 1: Meeting Invitation
        let meetingText = """
        You are invited to a project review meeting with Dr. Alice Smith and Mr. Bob Johnson.
        The meeting will be held at Apple Park, Cupertino, California on October 26, 2024.
        We will discuss the new product launch and marketing strategy.
        Please bring your latest reports.
        """

        print("--- Analyzing Meeting Invitation ---")
        do {
            let result = try await analyzer.analyzeDocument(text: meetingText)
            print("Language: \(result.recognizedLanguage.rawValue)")
            print("\nNamed Entities:")
            result.namedEntities.forEach { entity in
                print("- \(entity.type.rawValue): \(entity.name) \(entity.dateValue != nil ? "(\(entity.dateValue!.formatted(date: .abbreviated, time: .omitted)))" : "")")
            }
            print("\nImportant Terms (Lemmas):")
            result.importantTerms.sorted { $0.value > $1.value }.forEach { term, count in
                print("- \(term): \(count)")
            }
            print("\nSuggested Actions:")
            result.suggestedActions.forEach { action in
                print("- \(action)")
            }
        } catch {
            print("Error analyzing meeting text: \(error.localizedDescription)")
        }

        print("\n--- Analyzing Business Card ---")
        let businessCardText = """
        John Doe
        Senior Software Engineer
        Acme Corporation
        123 Main Street, Anytown, USA
        Contact: john.doe@acmecorp.com
        """
        do {
            let result = try await analyzer.analyzeDocument(text: businessCardText)
            print("Language: \(result.recognizedLanguage.rawValue)")
            print("\nNamed Entities:")
            result.namedEntities.forEach { entity in
                print("- \(entity.type.rawValue): \(entity.name)")
            }
            print("\nImportant Terms (Lemmas):")
            result.importantTerms.sorted { $0.value > $1.value }.forEach { term, count in
                print("- \(term): \(count)")
            }
            print("\nSuggested Actions:")
            result.suggestedActions.forEach { action in
                print("- \(action)")
            }
        } catch {
            print("Error analyzing business card text: \(error.localizedDescription)")
        }

        print("\n--- Testing Empty Input ---")
        do {
            _ = try await analyzer.analyzeDocument(text: "")
        } catch {
            print("Expected error caught: \(error.localizedDescription)")
        }

        print("\n--- Testing Unsupported Language (Simulated) ---")
        // NLTagger supports many languages, but our `DocumentAnalyzer` explicitly limits it for this example
        // to demonstrate error handling for unsupported languages.
        let frenchText = "Bonjour, je m'appelle Marie et je suis de Paris."
        do {
            // Temporarily set a different language to trigger the unsupported language error
            // In a real scenario, NLLanguageRecognizer would detect French.
            // For this example, we'll just show the error path.
            class MockDocumentAnalyzer: DocumentAnalyzer {
                override func analyzeDocument(text: String) async throws -> AnalyzedDocument {
                    if text == "Bonjour, je m'appelle Marie et je suis de Paris." {
                         throw DocumentAnalyzerError.unsupportedLanguage(.french)
                    }
                    return try await super.analyzeDocument(text: text)
                }
            }
            let mockAnalyzer = MockDocumentAnalyzer()
            _ = try await mockAnalyzer.analyzeDocument(text: frenchText)
        } catch {
            print("Expected error caught: \(error.localizedDescription)")
        }
    }
}
