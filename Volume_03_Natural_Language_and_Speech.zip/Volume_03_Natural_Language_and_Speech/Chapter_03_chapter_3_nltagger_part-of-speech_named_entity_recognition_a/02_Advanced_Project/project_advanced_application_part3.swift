
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

/// Manages the analysis of document text using NaturalLanguage framework.
@available(iOS 13.0, *) // NLTagger is available from iOS 13.0
class DocumentAnalyzer {
    private let tagger: NLTagger
    private let languageRecognizer: NLLanguageRecognizer

    /// Initializes the DocumentAnalyzer.
    init() {
        // Initialize NLTagger with all relevant tag schemes.
        // .tokenType: For basic token types (word, punctuation, whitespace).
        // .lemma: For lemmatization (base form of a word).
        // .partOfSpeech: For grammatical categories (noun, verb, adjective).
        // .namedEntity: For recognizing specific entities (person, organization, location, date).
        self.tagger = NLTagger(tagSchemes: [.tokenType, .lemma, .partOfSpeech, .namedEntity])
        self.languageRecognizer = NLLanguageRecognizer()
    }

    /// Analyzes the given text, extracting named entities, important terms, and suggesting actions.
    ///
    /// - Parameter text: The document text to analyze.
    /// - Returns: An `AnalyzedDocument` containing all extracted information and suggested actions.
    /// - Throws: `DocumentAnalyzerError` if analysis fails.
    func analyzeDocument(text: String) async throws -> AnalyzedDocument {
        guard !text.isEmpty else {
            throw DocumentAnalyzerError.emptyInput
        }

        // 1. Language Recognition (Asynchronous)
        // Determines the dominant language of the input text, crucial for accurate tagging.
        let recognizedLanguage = await withCheckedContinuation { continuation in
            languageRecognizer.processString(text)
            let language = languageRecognizer.dominantLanguage
            languageRecognizer.reset() // Reset for next use
            continuation.resume(returning: language)
        }

        guard let language = recognizedLanguage else {
            throw DocumentAnalyzerError.languageNotRecognized
        }

        // We'll primarily support English for this example, but NLTagger supports many.
        guard language == .english else {
            throw DocumentAnalyzerError.unsupportedLanguage(language)
        }

        // Configure the tagger with the recognized language.
        tagger.string = text
        tagger.setLanguage(language, range: text.startIndex..<text.endIndex)

        var namedEntities: [NamedEntity] = []
        var importantTerms: [String: Int] = [:]

        // 2. Perform Tagging for Named Entities, POS, and Lemmatization (Asynchronous)
        // Iterate through the text to extract tokens and their tags.
        // Using `enumerateTags` is an efficient way to get all tags for a given range.
        try await withCheckedThrowingContinuation { continuation in
            tagger.enumerateTags(in: text.startIndex..<text.endIndex,
                                 unit: .word, // Process word by word
                                 scheme: .namedEntity, // Primary scheme for this pass
                                 options: [.omitPunctuation, .omitWhitespace, .joinNames]) { tag, tokenRange in
                guard let tag = tag else { return true } // Continue if no tag

                let token = String(text[tokenRange])

                // Extract Named Entities (Person, Organization, Location, Date)
                if tag == .personalName || tag == .organizationName || tag == .placeName || tag == .date {
                    var dateValue: Date?
                    if tag == .date {
                        // Attempt to parse the date string into a Date object
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "MMMM d, yyyy" // Example format, adjust as needed
                        dateValue = dateFormatter.date(from: token)
                        if dateValue == nil {
                            dateFormatter.dateFormat = "MMM d, yyyy"
                            dateValue = dateFormatter.date(from: token)
                        }
                        if dateValue == nil {
                            dateFormatter.dateFormat = "MM/dd/yyyy"
                            dateValue = dateFormatter.date(from: token)
                        }
                        // Add more date formats as necessary for robust parsing
                    }
                    namedEntities.append(NamedEntity(type: NLToken.TokenType(tag), name: token, originalRange: tokenRange, dateValue: dateValue))
                }

                // 3. Perform Lemmatization and POS Tagging for Important Terms
                // This is done in the same enumeration for efficiency, but could be a separate pass
                // with a different scheme if needed.
                // We're interested in nouns and verbs for "important terms".
                let posTag = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .partOfSpeech).0
                let lemmaTag = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .lemma).0

                if let pos = posTag, let lemma = lemmaTag {
                    if pos == .noun || pos == .verb || pos == .adjective {
                        let baseForm = String(text[lemma.range!]) // Get the actual lemma string
                        importantTerms[baseForm, default: 0] += 1
                    }
                }

                return true // Continue enumeration
            }
            continuation.resume(returning: ())
        }

        // Filter out common stop words from important terms if desired
        let stopWords: Set<String> = ["the", "a", "an", "is", "are", "was", "were", "be", "been", "being", "and", "or", "but", "for", "with", "on", "at", "from", "by", "of", "to", "in", "it", "its"]
        let filteredTerms = importantTerms.filter { !stopWords.contains($0.key.lowercased()) && $0.value > 1 } // Only terms appearing more than once

        var analyzedDoc = AnalyzedDocument(originalText: text, recognizedLanguage: language, namedEntities: namedEntities, importantTerms: filteredTerms)

        // 4. Suggest Actions based on Extracted Entities
        analyzedDoc.suggestedActions = suggestActions(from: analyzedDoc)

        return analyzedDoc
    }

    /// Suggests potential actions based on the extracted named entities.
    /// This method simulates integration with other Apple frameworks like EventKit or Contacts.
    ///
    /// - Parameter analyzedDocument: The document with its extracted entities.
    /// - Returns: An array of suggested action strings.
    private func suggestActions(from analyzedDocument: AnalyzedDocument) -> [String] {
        var actions: [String] = []

        let persons = analyzedDocument.namedEntities.filter { $0.type == .personalName }
        let organizations = analyzedDocument.namedEntities.filter { $0.type == .organizationName }
        let locations = analyzedDocument.namedEntities.filter { $0.type == .placeName }
        let dates = analyzedDocument.namedEntities.compactMap { $0.type == .date ? $0.dateValue : nil }

        // Rule 1: If dates and people are found, suggest a calendar event.
        if !dates.isEmpty && !persons.isEmpty {
            let earliestDate = dates.min()
            let personNames = persons.map { $0.name }.joined(separator: ", ")
            actions.append("Create Calendar Event: Meeting with \(personNames) on \(earliestDate?.formatted(date: .long, time: .omitted) ?? "an unknown date").")
            // In a real app, this would trigger EventKit UI.
        }

        // Rule 2: If organizations and locations are found, suggest adding a contact or looking up the organization.
        if !organizations.isEmpty && !locations.isEmpty {
            let orgName = organizations.first?.name ?? "Unknown Organization"
            let locationName = locations.first?.name ?? "Unknown Location"
            actions.append("Add Contact/Lookup: \(orgName) at \(locationName).")
            // In a real app, this would trigger Contacts UI or MapKit lookup.
        } else if !organizations.isEmpty {
            let orgName = organizations.first?.name ?? "Unknown Organization"
            actions.append("Add Contact/Lookup: \(orgName).")
        }

        // Rule 3: If only people are found, suggest adding them as contacts.
        if !persons.isEmpty && organizations.isEmpty && dates.isEmpty {
            let personNames = persons.map { $0.name }.joined(separator: ", ")
            actions.append("Add Contacts: \(personNames).")
        }

        // Rule 4: If only locations are found, suggest opening in maps.
        if !locations.isEmpty && persons.isEmpty && organizations.isEmpty && dates.isEmpty {
            let locationName = locations.first?.name ?? "Unknown Location"
            actions.append("Open in Maps: \(locationName).")
        }

        return actions
    }
}
