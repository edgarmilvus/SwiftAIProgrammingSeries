
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CoreML
import Vision
import Foundation // For ProcessInfo.ThermalState and Timer
import UIKit // For UIImage (used by CVPixelBuffer extension)

// Assume you have two Core ML models added to your project:
// 1. A lightweight person detection model (e.g., YOLOv3Tiny or MobileNetV2_SSDLite)
//    Let's use 'YOLOv3' and pretend it's optimized for person detection.
// 2. A more complex action recognition model (e.g., a custom model).
//    Let's use 'ActionClassifier' as a placeholder.

// MARK: - Exercise 3: Real-time Video Stream Analysis with Dynamic Compute Unit Switching

// Helper to simulate CVPixelBuffer frames
class FrameGenerator {
    private var timer: Timer?
    var onNewFrame: ((CVPixelBuffer) -> Void)?

    func startGeneratingFrames(interval: TimeInterval, width: Int, height: Int) {
        timer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            if let dummyBuffer = self.createDummyPixelBuffer(width: width, height: height) {
                self.onNewFrame?(dummyBuffer)
            }
        }
    }

    func stopGeneratingFrames() {
        timer?.invalidate()
        timer = nil
    }

    private func createDummyPixelBuffer(width: Int, height: Int) -> CVPixelBuffer? {
        let pixelFormat = kCVPixelFormatType_32BGRA // Common format for iOS
        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault, width, height, pixelFormat, nil, &pixelBuffer)
        guard status == kCVReturnSuccess, let buffer = pixelBuffer else { return nil }
        
        // Fill with some dummy data (e.g., a simple pattern)
        CVPixelBufferLockBaseAddress(buffer, .readWrite)
        if let baseAddress = CVPixelBufferGetBaseAddress(buffer) {
            let bytesPerRow = CVPixelBufferGetBytesPerRow(buffer)
            let data = baseAddress.assumingMemoryBound(to: UInt8.self)
            for y in 0..<height {
                for x in 0..<width {
                    let offset = y * bytesPerRow + x * 4 // BGRA
                    data[offset + 0] = UInt8(x % 255) // Blue
                    data[offset + 1] = UInt8(y % 255) // Green
                    data[offset + 2] = 128            // Red
                    data[offset + 3] = 255            // Alpha
                }
            }
        }
        CVPixelBufferUnlockBaseAddress(buffer, .readWrite)
        return buffer
    }
}

// Global state for thermal throttling simulation
// In a real app, you would observe ProcessInfo.processInfo.thermalState
var simulatedThermalState: ProcessInfo.ThermalState = .fair {
    didSet {
        if oldValue != simulatedThermalState {
            print("SIMULATION: Thermal state changed to \(simulatedThermalState.description)")
        }
    }
}

// Extension to make MLComputeUnits conform to CustomStringConvertible for logging
extension MLComputeUnits: CustomStringConvertible {
    public var description: String {
        switch self {
        case .cpuOnly: return "CPU Only"
        case .cpuAndGPU: return "CPU & GPU"
        case .cpuAndNeuralEngine: return "CPU & Neural Engine"
        case .all: return "All (Core ML Default)"
        @unknown default: return "Unknown Compute Unit"
        }
    }
}

class SmartSecurityCameraProcessor {
    // IMPORTANT: Replace with your actual generated model classes
    private var personDetector: YOLOv3! // Primary model
    private var actionClassifier: ActionClassifier! // Secondary model

    private var isAnalyzingAction: Bool = false
    private var actionAnalysisTimer: Timer?

    private let preferredPersonDetectorUnits: MLComputeUnits = .cpuAndNeuralEngine
    private let preferredActionClassifierUnits: MLComputeUnits = .cpuAndGPU

    // Current units in use, can change due to thermal throttling
    private var currentPersonDetectorUnits: MLComputeUnits
    private var currentActionClassifierUnits: MLComputeUnits

    private let personDetectorInputSize: (width: Int, height: Int) = (416, 416) // Example for YOLOv3
    private let actionClassifierInputSize: (width: Int, height: Int) = (224, 224) // Example for ResNet-like action classifier

    init() {
        currentPersonDetectorUnits = preferredPersonDetectorUnits
        currentActionClassifierUnits = preferredActionClassifierUnits
        loadModels()
    }

    // Function to load/reload models with specified compute units
    private func loadModels() {
        do {
            let personDetectorConfig = MLModelConfiguration()
            personDetectorConfig.computeUnits = currentPersonDetectorUnits
            self.personDetector = try YOLOv3(configuration: personDetectorConfig) // IMPORTANT: Replace YOLOv3
            print("Loaded PersonDetector with \(currentPersonDetectorUnits.description)")

            let actionClassifierConfig = MLModelConfiguration()
            actionClassifierConfig.computeUnits = currentActionClassifierUnits
            self.actionClassifier = try ActionClassifier(configuration: actionClassifierConfig) // IMPORTANT: Replace ActionClassifier
            print("Loaded ActionClassifier with \(currentActionClassifierUnits.description)")
        } catch {
            fatalError("Failed to load models with current configurations: \(error.localizedDescription)")
        }
    }

    // Checks thermal state and reloads models if compute units need to change
    private func updateComputeUnitsBasedOnThermalState() {
        let newPersonDetectorUnits: MLComputeUnits
        let newActionClassifierUnits: MLComputeUnits

        if simulatedThermalState == .critical || simulatedThermalState == .serious {
            newPersonDetectorUnits = .cpuOnly
            newActionClassifierUnits = .cpuOnly
            if currentPersonDetectorUnits != .cpuOnly {
                print("WARNING: Thermal throttling detected (\(simulatedThermalState.description)). Switching all models to .cpuOnly.")
            }
        } else {
            newPersonDetectorUnits = preferredPersonDetectorUnits
            newActionClassifierUnits = preferredActionClassifierUnits
            if currentPersonDetectorUnits == .cpuOnly { // Only log if we were previously throttled
                print("Thermal state improved (\(simulatedThermalState.description)). Reverting models to preferred compute units.")
            }
        }

        // Reload models only if compute units actually changed
        if newPersonDetectorUnits != currentPersonDetectorUnits || newActionClassifierUnits != currentActionClassifierUnits {
            currentPersonDetectorUnits = newPersonDetectorUnits
            currentActionClassifierUnits = newActionClassifierUnits
            loadModels() // Reloading models is necessary to apply new compute units
        }
    }

    func processFrame(_ pixelBuffer: CVPixelBuffer) {
        updateComputeUnitsBasedOnThermalState() // Check thermal state on each frame

        // 1. Run Primary Model (Person Detector)
        do {
            guard let resizedPixelBuffer = pixelBuffer.resized(to: personDetectorInputSize.width, personDetectorInputSize.height) else {
                print("Failed to resize pixel buffer for PersonDetector.")
                return
            }
            
            // IMPORTANT: Adapt to your model's input type.
            // For YOLOv3, it's typically an image.
            let personInput = YOLOv3Input(image: resizedPixelBuffer) // Replace with your model's input type
            let personPrediction = try personDetector.prediction(input: personInput) // Replace with your model's prediction method

            // Simulate person detection output
            // In a real YOLOv3, you'd parse bounding boxes and confidence scores.
            // For simplicity, let's assume a single confidence score for "person".
            let personConfidence: Double = Double.random(in: 0.0...1.0) // Random confidence for demo
            
            // Let's make it detect a person more often to trigger action analysis
            let actualPersonConfidence = (personConfidence > 0.7) ? Double.random(in: 0.85...0.95) : Double.random(in: 0.0...0.6)

            print("PersonDetector inference (Compute Unit: \(currentPersonDetectorUnits.description)): Confidence = \(String(format: "%.2f", actualPersonConfidence))")

            let personDetectionThreshold: Double = 0.8
            if actualPersonConfidence > personDetectionThreshold && !isAnalyzingAction {
                print("High-confidence person detected! Initiating action analysis.")
                isAnalyzingAction = true
                actionAnalysisTimer?.invalidate() // Invalidate previous timer if any
                actionAnalysisTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { [weak self] _ in
                    self?.isAnalyzingAction = false
                    print("Action analysis window ended. Reverting to primary detection.")
                }
            }
        } catch {
            print("Error during PersonDetector inference: \(error.localizedDescription)")
        }

        // 2. Run Secondary Model (Action Classifier) if in action analysis mode
        if isAnalyzingAction {
            do {
                guard let resizedPixelBuffer = pixelBuffer.resized(to: actionClassifierInputSize.width, actionClassifierInputSize.height) else {
                    print("Failed to resize pixel buffer for ActionClassifier.")
                    return
                }
                // IMPORTANT: Adapt to your model's input type.
                let actionInput = ActionClassifierInput(image: resizedPixelBuffer) // Replace with your model's input type
                let actionPrediction = try actionClassifier.prediction(input: actionInput) // Replace with your model's prediction method

                // Simulate action classification output
                // In a real model, you would extract the class label from prediction.
                let actionLabels = ["walking", "running", "standing", "sitting", "falling"]
                let actionLabel: String = actionLabels.randomElement() ?? "unknown" // Placeholder: random action for demo
                print("ActionClassifier inference (Compute Unit: \(currentActionClassifierUnits.description)): Action = \(actionLabel)")

            } catch {
                print("Error during ActionClassifier inference: \(error.localizedDescription)")
            }
        }
    }
}

// Example of how you might use this:
/*
// 1. Add YOLOv3.mlmodel and ActionClassifier.mlmodel to your project.
//    (ActionClassifier.mlmodel needs to be a custom model you create or simulate).
// 2. Ensure the CVPixelBuffer `resized` extension is implemented correctly (e.g., using Core Image).

let frameGenerator = FrameGenerator()
let securityProcessor = SmartSecurityCameraProcessor()

frameGenerator.onNewFrame = { pixelBuffer in
    securityProcessor.processFrame(pixelBuffer)
}

// Start generating frames every 0.5 seconds (2 FPS simulation)
frameGenerator.startGeneratingFrames(interval: 0.5, width: 640, height: 480) // Example camera resolution

// Simulate thermal state changes after some time
DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
    simulatedThermalState = .serious
}

DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
    simulatedThermalState = .critical
}

DispatchQueue.main.asyncAfter(deadline: .now() + 15) {
    simulatedThermalState = .fair
}

// To run this in a non-UI environment (like a command-line tool or playground):
// RunLoop.current.run() // Keeps the current run loop alive indefinitely.
// For a limited time:
DispatchQueue.main.asyncAfter(deadline: .now() + 20) {
    frameGenerator.stopGeneratingFrames()
    print("\nSimulation ended.")
    exit(0) // Terminate the program after simulation
}
RunLoop.current.run()
*/
