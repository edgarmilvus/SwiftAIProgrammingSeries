
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, *)
struct DocumentClassificationView: View {
    @State private var viewModel = DocumentScannerViewModel()

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // ... Title ...
                if viewModel.isScanning {
                    ProgressView("Analyzing Document...") // Shows progress
                } else if let error = viewModel.errorMessage {
                    // Displays error message
                } else if viewModel.topClassifications.isEmpty {
                    // Placeholder when no results are available
                } else {
                    // Displays top classifications using ForEach and ConfidenceBarView
                    ForEach(viewModel.topClassifications) { classification in
                        ConfidenceBarView(label: classification.label, confidence: classification.confidence)
                    }
                    .transition(.opacity.animation(.easeInOut(duration: 0.5))) // Smooth transition for results block
                }
                Spacer()
                Button {
                    Task { await viewModel.performAIMLClassification(for: nil) }
                } label: { /* ... button styling ... */ }
                .disabled(viewModel.isScanning) // Disable button during scan
            }
        }
    }
}
