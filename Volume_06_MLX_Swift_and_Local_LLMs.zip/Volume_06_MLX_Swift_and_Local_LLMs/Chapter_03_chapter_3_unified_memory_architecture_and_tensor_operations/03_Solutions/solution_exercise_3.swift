
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import MLX
import MLXNN

@available(iOS 18.0, macOS 15.0, *)
class DenseLayer: MLXNN.Module {
    let weight: MLXArray
    let bias: MLXArray

    init(inputFeatures: Int, outputFeatures: Int) {
        // Initialize weight and bias parameters.
        // MLXNN.Module automatically marks parameters defined as MLXArray properties
        // as requiring gradients, making them trainable.
        self.weight = MLXArray.random(
            low: -0.1, high: 0.1,
            shape: [outputFeatures, inputFeatures], // MLX expects [output, input] for matrix multiplication
            dtype: .float32
        )
        self.bias = MLXArray.zeros([outputFeatures], dtype: .float32)
        super.init()
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Implement the forward pass: input @ weight.T + bias
        // input: [batchSize, inputFeatures]
        // weight: [outputFeatures, inputFeatures]
        // We need to transpose weight for (input @ weight.T) to be [batchSize, outputFeatures]
        let output = input @ weight.T + bias
        return output
    }
}

@available(iOS 18.0, macOS 15.0, *)
func demonstrateDenseLayerAndGradient(
    inputFeatures: Int,
    outputFeatures: Int,
    batchSize: Int
) {
    print("--- Dense Layer and Gradient Demonstration ---")
    let layer = DenseLayer(inputFeatures: inputFeatures, outputFeatures: outputFeatures)
    print("DenseLayer initialized with inputFeatures: \(inputFeatures), outputFeatures: \(outputFeatures)")
    print("Weight shape: \(layer.weight.shape), Bias shape: \(layer.bias.shape)")

    // Create a sample input. Make sure it requires gradients.
    let input = MLXArray.random(
        low: -1.0, high: 1.0,
        shape: [batchSize, inputFeatures],
        dtype: .float32,
        requiresGrad: true // Crucial: tells MLX to track operations for this array to compute its gradient
    )
    print("Input MLXArray created with shape: \(input.shape), requiresGrad: \(input.requiresGrad)")

    // Define a simple function whose gradient we want to compute.
    // For this exercise, we'll just sum the output of the dense layer to get a scalar.
    let computeOutputAndScalarSum = { (x: MLXArray) -> MLXArray in
        let output = layer(x) // Forward pass through the dense layer
        return MLX.sum(output) // Sum the output to get a scalar for gradient calculation
    }

    // Use valueAndGradient to get the scalar sum and its gradient with respect to the input 'input'
    // argnums: 0 specifies that we want the gradient with respect to the first argument of the closure (x)
    let (scalarSum, gradients) = MLX.valueAndGradient(computeOutputAndScalarSum, argnums: 0)(input)

    print("\nScalar Sum of Dense Layer Output: \(scalarSum.item())")
    print("Gradient of Scalar Sum with respect to Input Shape: \(gradients.shape)")
    print("Gradient of Scalar Sum with respect to Input (first 5 elements, if > 5):")
    // Evaluate the gradient MLXArray to get its data
    let gradData = gradients.flattened().data.map { $0.floatValue }
    print(gradData.prefix(5))
}

// Example usage:
// demonstrateDenseLayerAndGradient(inputFeatures: 10, outputFeatures: 5, batchSize: 1)
// demonstrateDenseLayerAndGradient(inputFeatures: 8, outputFeatures: 3, batchSize: 4)
