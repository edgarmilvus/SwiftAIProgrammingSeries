
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import Vision
import PhotosUI

// Re-using the UIImage extension from Exercise 1 for coordinate conversion
extension UIImage {
    func rectForImageView(imageView: UIImageView) -> CGRect {
        let imageViewSize = imageView.bounds.size
        let imageSize = self.size

        let scaleWidth = imageViewSize.width / imageSize.width
        let scaleHeight = imageViewSize.height / imageSize.height

        var scale: CGFloat
        var xOffset: CGFloat = 0
        var yOffset: CGFloat = 0

        switch imageView.contentMode {
        case .scaleAspectFit:
            scale = min(scaleWidth, scaleHeight)
            xOffset = (imageViewSize.width - imageSize.width * scale) / 2.0
            yOffset = (imageViewSize.height - imageSize.height * scale) / 2.0
        case .scaleAspectFill:
            scale = max(scaleWidth, scaleHeight)
            xOffset = (imageViewSize.width - imageSize.width * scale) / 2.0
            yOffset = (imageViewSize.height - imageSize.height * scale) / 2.0
        case .center:
            scale = 1.0
            xOffset = (imageViewSize.width - imageSize.width) / 2.0
            yOffset = (imageViewSize.height - imageSize.height) / 2.0
        case .scaleToFill:
            return imageView.bounds
        default:
            scale = 1.0
        }
        return CGRect(x: xOffset, y: yOffset, width: imageSize.width * scale, height: imageSize.height * scale)
    }
}

class SmartCropViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    private let imageView = UIImageView()
    private let selectImageButton = UIButton(type: .system)
    private let cropButton = UIButton(type: .system)

    // Store all detected rectangle layers and their current corner points (in view coordinates)
    private var detectedRectangles: [(layer: CAShapeLayer, corners: [CGPoint])] = []
    private var selectedRectangleIndex: Int? {
        didSet {
            updateSelectionUI()
        }
    }
    private var cornerHandles: [CAShapeLayer] = []
    private let handleRadius: CGFloat = 15.0 // Increased for easier tapping

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupGestureRecognizers()
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .lightGray
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isUserInteractionEnabled = true // Enable interaction for gestures
        view.addSubview(imageView)

        selectImageButton.setTitle("Select Image", for: .normal)
        selectImageButton.addTarget(self, action: #selector(selectImageTapped), for: .touchUpInside)
        selectImageButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(selectImageButton)

        cropButton.setTitle("Crop", for: .normal)
        cropButton.addTarget(self, action: #selector(cropTapped), for: .touchUpInside)
        cropButton.translatesAutoresizingMaskIntoConstraints = false
        cropButton.isEnabled = false // Disable until a rectangle is selected
        view.addSubview(cropButton)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: imageView.widthAnchor, multiplier: 3/4),

            selectImageButton.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            selectImageButton.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant: -10),
            selectImageButton.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            cropButton.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            cropButton.leadingAnchor.constraint(equalTo: view.centerXAnchor, constant: 10),
            cropButton.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    private func setupGestureRecognizers() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        imageView.addGestureRecognizer(tapGesture)
    }

    @objc private func selectImageTapped() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }

    @objc private func cropTapped() {
        guard let selectedIndex = selectedRectangleIndex,
              let image = imageView.image else { return }

        let selectedLayer = detectedRectangles[selectedIndex].layer
        let currentCorners = detectedRectangles[selectedIndex].corners

        // Convert the current view coordinates of the rectangle back to normalized CGRect
        let imageRectInView = image.rectForImageView(imageView: imageView)

        // Find min/max X/Y from current corners to form a bounding box in view coordinates
        let minX = currentCorners.map { $0.x }.min() ?? 0
        let maxX = currentCorners.map { $0.x }.max() ?? 0
        let minY = currentCorners.map { $0.y }.min() ?? 0
        let maxY = currentCorners.map { $0.y }.max() ?? 0

        let viewCropRect = CGRect(x: minX, y: minY, width: maxX - minX, height: maxY - minY)

        // Convert viewCropRect back to normalized coordinates (0-1)
        // This is the inverse of the conversion in drawDetectedRectangles
        let normalizedX = (viewCropRect.origin.x - imageRectInView.origin.x) / imageRectInView.width
        let normalizedY = 1.0 - ((viewCropRect.origin.y - imageRectInView.origin.y + viewCropRect.height) / imageRectInView.height) // Invert Y
        let normalizedWidth = viewCropRect.width / imageRectInView.width
        let normalizedHeight = viewCropRect.height / imageRectInView.height

        let finalNormalizedCropRect = CGRect(x: normalizedX, y: normalizedY, width: normalizedWidth, height: normalizedHeight)

        print("Crop confirmed! Final normalized CGRect: \(finalNormalizedCropRect)")
        // In a real app, you would now perform the actual image cropping using this CGRect
    }

    // MARK: - UIImagePickerControllerDelegate

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true) { [weak self] in
            guard let self = self, let originalImage = info[.originalImage] as? UIImage else { return }
            self.imageView.image = originalImage
            self.detectRectanglesForCrop(in: originalImage)
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    // MARK: - Rectangle Detection

    private func detectRectanglesForCrop(in image: UIImage) {
        // Clear previous overlays and selections
        detectedRectangles.forEach { $0.layer.removeFromSuperlayer() }
        detectedRectangles.removeAll()
        selectedRectangleIndex = nil
        cropButton.isEnabled = false

        guard let cgImage = image.cgImage else {
            print("Failed to get CGImage from UIImage.")
            return
        }

        let request = VNDetectRectanglesRequest { [weak self] request, error in
            guard let self = self else { return }
            if let error = error {
                print("Rectangle detection error: \(error.localizedDescription)")
                return
            }

            guard let observations = request.results as? [VNRectangleObservation] else {
                print("No rectangles detected or could not cast results.")
                return
            }

            DispatchQueue.main.async {
                self.drawDetectedRectangles(observations: observations, on: image)
            }
        }

        request.minimumConfidence = 0.7 // Only show confident detections
        request.minimumSize = 0.1 // Detect rectangles that are at least 10% of the image
        request.maximumObservations = 10 // Allow multiple suggestions

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        Task {
            do {
                try handler.perform([request])
            } catch {
                print("Failed to perform Vision request: \(error.localizedDescription)")
            }
        }
    }

    private func drawDetectedRectangles(observations: [VNRectangleObservation], on image: UIImage) {
        guard let image = imageView.image else { return }

        let imageRectInView = image.rectForImageView(imageView: imageView)

        for observation in observations {
            let normalizedBoundingBox = observation.boundingBox
            let visionRectInImageCoords = VNImageRectForNormalizedRect(normalizedBoundingBox, Int(image.size.width), Int(image.size.height))

            // Convert Vision corners to view coordinates
            let cornersInView = [
                convertVisionPointToViewPoint(observation.topLeft, image: image, imageRectInView: imageRectInView),
                convertVisionPointToViewPoint(observation.topRight, image: image, imageRectInView: imageRectInView),
                convertVisionPointToViewPoint(observation.bottomRight, image: image, imageRectInView: imageRectInView),
                convertVisionPointToViewPoint(observation.bottomLeft, image: image, imageRectInView: imageRectInView)
            ]

            let path = UIBezierPath()
            path.move(to: cornersInView[0])
            path.addLine(to: cornersInView[1])
            path.addLine(to: cornersInView[2])
            path.addLine(to: cornersInView[3])
            path.close()

            let layer = CAShapeLayer()
            layer.path = path.cgPath
            layer.strokeColor = UIColor.lightGray.withAlphaComponent(0.8).cgColor
            layer.lineWidth = 2.0
            layer.fillColor = UIColor.blue.withAlphaComponent(0.2).cgColor // Translucent overlay
            imageView.layer.addSublayer(layer)

            detectedRectangles.append((layer: layer, corners: cornersInView))
        }
    }

    private func convertVisionPointToViewPoint(_ visionPoint: CGPoint, image: UIImage, imageRectInView: CGRect) -> CGPoint {
        let visionPointInImageCoords = VNImagePointForNormalizedPoint(visionPoint, Int(image.size.width), Int(image.size.height))
        return CGPoint(
            x: imageRectInView.origin.x + visionPointInImageCoords.x * imageRectInView.width / image.size.width,
            y: imageRectInView.origin.y + (image.size.height - visionPointInImageCoords.y) * imageRectInView.height / image.size.height
        )
    }

    // MARK: - Gesture Handling

    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        let location = gesture.location(in: imageView)
        selectedRectangleIndex = nil // Deselect previous

        for (index, rectTuple) in detectedRectangles.enumerated() {
            if let path = rectTuple.layer.path, path.contains(location) {
                selectedRectangleIndex = index
                break
            }
        }
    }

    private func updateSelectionUI() {
        // Clear all previous handle layers
        cornerHandles.forEach { $0.removeFromSuperlayer() }
        cornerHandles.removeAll()

        for (index, rectTuple) in detectedRectangles.enumerated() {
            if index == selectedRectangleIndex {
                // Selected state
                rectTuple.layer.strokeColor = UIColor.systemBlue.cgColor
                rectTuple.layer.fillColor = UIColor.systemBlue.withAlphaComponent(0.4).cgColor
                cropButton.isEnabled = true
                drawCornerHandles(for: rectTuple.corners)
            } else {
                // Deselected state
                rectTuple.layer.strokeColor = UIColor.lightGray.withAlphaComponent(0.8).cgColor
                rectTuple.layer.fillColor = UIColor.blue.withAlphaComponent(0.2).cgColor
            }
        }
        if selectedRectangleIndex == nil {
            cropButton.isEnabled = false
        }
    }

    private func drawCornerHandles(for corners: [CGPoint]) {
        for (index, point) in corners.enumerated() {
            let handleLayer = CAShapeLayer()
            handleLayer.path = UIBezierPath(ovalIn: CGRect(x: point.x - handleRadius, y: point.y - handleRadius, width: handleRadius * 2, height: handleRadius * 2)).cgPath
            handleLayer.fillColor = UIColor.white.cgColor
            handleLayer.strokeColor = UIColor.systemBlue.cgColor
            handleLayer.lineWidth = 2.0
            imageView.layer.addSublayer(handleLayer)
            cornerHandles.append(handleLayer)

            // Add pan gesture to each handle
            let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
            // Attach gesture to a dummy view over the handle for easier hit testing
            let handleView = UIView(frame: CGRect(x: point.x - handleRadius, y: point.y - handleRadius, width: handleRadius * 2, height: handleRadius * 2))
            handleView.backgroundColor = .clear // invisible
            handleView.tag = index // Use tag to identify which corner is being dragged
            handleView.addGestureRecognizer(panGesture)
            imageView.addSubview(handleView)
            // Store reference to handleView to remove later
            cornerHandles.append(handleView.layer) // We'll clear all layers/views associated with handles
        }
    }

    @objc private func handlePan(_ gesture: UIPanGestureRecognizer) {
        guard let selectedIndex = selectedRectangleIndex,
              let draggedHandleView = gesture.view,
              let image = imageView.image else { return }

        let translation = gesture.translation(in: imageView)
        let currentPoint = gesture.location(in: imageView)

        var currentCorners = detectedRectangles[selectedIndex].corners
        let handleIndex = draggedHandleView.tag // 0:topLeft, 1:topRight, 2:bottomRight, 3:bottomLeft

        switch gesture.state {
        case .began, .changed:
            currentCorners[handleIndex] = currentPoint // Update the dragged corner
            detectedRectangles[selectedIndex].corners = currentCorners // Update stored corners

            // Redraw the selected rectangle with updated corners
            let path = UIBezierPath()
            path.move(to: currentCorners[0])
            path.addLine(to: currentCorners[1])
            path.addLine(to: currentCorners[2])
            path.addLine(to: currentCorners[3])
            path.close()
            detectedRectangles[selectedIndex].layer.path = path.cgPath

            // Redraw handles at new positions
            cornerHandles.forEach { $0.removeFromSuperlayer() }
            cornerHandles.removeAll()
            drawCornerHandles(for: currentCorners)

            // Reset translation for continuous dragging
            gesture.setTranslation(.zero, in: imageView)

        case .ended, .cancelled:
            // Optional: Snap to grid or perform final validation
            break
        default:
            break
        }
    }
}
