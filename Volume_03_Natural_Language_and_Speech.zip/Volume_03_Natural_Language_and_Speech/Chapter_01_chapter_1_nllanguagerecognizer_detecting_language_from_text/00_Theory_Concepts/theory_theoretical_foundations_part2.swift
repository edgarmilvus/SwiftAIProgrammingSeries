
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 18.0, *)
actor LanguageRecognizerActor {
    private let recognizer = NLLanguageRecognizer()
    private var recognitionCache: [String: (NLLanguage?, [(NLLanguage, Double)])] = [:]

    // A maximum cache size to prevent unbounded memory growth
    private let maxCacheSize = 100

    /// Processes text and returns the dominant language and all hypotheses, using a cache.
    func recognize(text: String) async -> (dominant: NLLanguage?, hypotheses: [(NLLanguage, Double)]) {
        if let cachedResult = recognitionCache[text] {
            return cachedResult
        }

        // Perform the actual recognition
        recognizer.processString(text)
        let dominant = recognizer.dominantLanguage
        let hypotheses = recognizer.languageHypotheses(withMaximum: 5)
            .map { (language: $0.key, confidence: $0.value) }
            .filter { $0.confidence > 0.1 }

        let result = (dominant, hypotheses)

        // Add to cache, managing size
        if recognitionCache.count >= maxCacheSize {
            // Simple LRU-like eviction: remove the first element (oldest, if ordered)
            // For true LRU, a more complex data structure like a dictionary with a linked list would be used.
            recognitionCache.removeFirst()
        }
        recognitionCache[text] = result

        return result
    }
    
    // An example of clearing the cache, which is also an isolated operation
    func clearCache() {
        recognitionCache.removeAll()
    }
}

// Example Usage
@available(iOS 18.0, *)
func demonstrateActorUsage() async {
    let actor = LanguageRecognizerActor()

    // Multiple tasks can concurrently request recognition from the actor
    let task1 = Task { await actor.recognize(text: "Hello, how are you?") }
    let task2 = Task { await actor.recognize(text: "Bonjour, comment allez-vous?") }
    let task3 = Task { await actor.recognize(text: "Hello, how are you?") } // This will hit the cache

    let result1 = await task1.value
    let result2 = await task2.value
    let result3 = await task3.value

    print("Task 1 Dominant: \(result1.dominant?.rawValue ?? "N/A")")
    print("Task 2 Dominant: \(result2.dominant?.rawValue ?? "N/A")")
    print("Task 3 Dominant: \(result3.dominant?.rawValue ?? "N/A")") // Should be same as Task 1
}
