
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import ARKit
import RealityKit
import Observation
import Combine

// MARK: - Dependencies

/// Package.swift equivalent dependencies:
/// - RealityKit (Built-in)
/// - ARKit (Built-in)
/// - Observation (Swift 5.9+)
/// - Swift Algorithms (Optional, for smoothing)

// MARK: - Error Handling

/// Defines specific failure states for the spatial interaction engine.
enum SpatialGestureError: Error, LocalizedError {
    case trackingLost
    case permissionDenied
    case invalidHandPose(String)
    case hardwareIncompatibility

    var errorDescription: String? {
        switch self {
        case .trackingLost: return "Hand tracking lost. Please ensure hands are within the field of view."
        case .permissionDenied: return "Camera access is required for hand tracking."
        case .invalidHandPose(let reason): return "Invalid hand pose: \(reason)"
        case .hardwareIncompatibility: return "This device does not support advanced hand tracking."
        }
    }
}

// MARK: - Models

/// Represents the semantic state of a hand in 3D space.
struct HandState {
    let isPinching: Bool
    let position: SIMD3<Float>
    let orientation: simd_quatf
    let velocity: SIMD3<Float>
    let joints: [HandSkeleton.Joint: simd_float4x4]
    
    static var empty: HandState {
        HandState(isPinching: false, position: .zero, orientation: .init(ix: 0, iy: 0, iz: 0, r: 1), velocity: .zero, joints: [:])
    }
}

// MARK: - The Core Engine (Concurrency Layer)

/// `HandTrackingActor` is the source of truth for hand data.
/// Using an `actor` ensures that the high-frequency updates from ARKit 
/// do not create data races when being read by the GestureInterpreter or the UI.
@available(visionOS 2.0, *)
actor HandTrackingActor {
    private var leftHand: HandState = .empty
    private var rightHand: HandState = .empty
    
    /// Updates the internal state for a specific hand.
    /// - Parameters:
    ///   - hand: The hand type (left or right).
    ///   - newState: The new state calculated from ARKit joints.
    func updateHand(_ hand: HandAnchor.Hand, with newState: HandState) {
        if hand == .left {
            leftHand = newState
        } else {
            rightHand = newState
        }
    }
    
    func getHandState(_ hand: HandAnchor.Hand) -> HandState {
        return hand == .left ? leftHand : rightHand
    }
    
    /// Calculates the distance between two hands for scaling gestures.
    func getInterHandDistance() -> Float {
        return distance(leftHand.position, rightHand.position)
    }
}

// MARK: - Gesture Interpretation Logic

/// `GestureInterpreter` processes raw joint data into semantic actions.
/// It implements Hysteresis to prevent jitter.
@available(visionOS 2.0, *)
final class GestureInterpreter {
    
    // Hysteresis constants
    private let pinchActivationThreshold: Float = 0.015 // 1.5cm
    private let pinchDeactivationThreshold: Float = 0.025 // 2.5cm
    
    private var leftHandPinching = false
    private var rightHandPinching = false
    
    /// Analyzes joint data to determine if a pinch is occurring.
    /// - Parameter joints: The dictionary of joint transforms.
    /// - Returns: A boolean indicating the semantic pinch state.
    func processPinch(for joints: [HandSkeleton.Joint: simd_float4x4], currentPinching: Bool) -> Bool {
        // Extract thumb tip and index tip positions
        guard let thumbTip = joints[.thumbTip],
              let indexTip = joints[.indexFingerTip] else {
            return false
        }
        
        // Convert 4x4 matrices to 3D positions
        let thumbPos = thumbTip.columns.3.xyz
        let indexPos = indexTip.columns.3.xyz
        
        let currentDistance = distance(thumbPos, indexPos)
        
        // Apply Hysteresis logic
        if !currentPinching {
            // If not pinching, check if we've crossed the activation threshold
            return currentDistance < pinchActivationThreshold
        } else {
            // If already pinching, check if we've crossed the deactivation threshold
            return currentDistance < pinchDeactivationThreshold
        }
    }
}

// MARK: - The Sculpting Engine

/// `SculptingEngine` manages the interaction between the user's hands and RealityKit entities.
@available(visionOS 2.0, *)
@MainActor
class SculptingEngine: ObservableObject {
    private let trackingActor = HandTrackingActor()
    private let interpreter = GestureInterpreter()
    private var handProvider: HandTrackingProvider?
    
    // The target entity being manipulated
    var targetEntity: Entity?
    
    // Tracking state for the "grab" interaction
    private var initialEntityTransform: simd_float4x4?
    private var initialHandTransform: simd_float4x4?
    
    @Published var isTrackingActive = false
    @Published var errorMessage: String?

    init() {
        setupHandTracking()
    }
    
    private func setupHandTracking() {
        Task {
            do {
                handProvider = try HandTrackingProvider()
                try await handProvider?.run()
                isTrackingActive = true
                startUpdateLoop()
            } catch {
                self.errorMessage = error.localizedDescription
            }
        }
    }
    
    /// The main high-frequency loop.
    /// In a production app, this would be driven by the ARKit update delegate,
    /// but here we use a continuous Task for demonstration.
    private func startUpdateLoop() {
        Task {
            while isTrackingActive {
                await processFrame()
                // Control loop frequency to match display refresh (approx 90Hz)
                try? await Task.sleep(for: .milliseconds(11))
            }
        }
    }
    
    private func processFrame() async {
        guard let provider = handProvider else { return }
        
        // Process both hands
        for handAnchor in provider.allAnchors {
            let handType = handAnchor.hand
            let joints = handAnchor.skeleton.jointTransforms
            
            // 1. Calculate semantic pinch state
            let isPinching = interpreter.processPinch(for: joints, currentPinching: false) // Simplified for example
            
            // 2. Construct HandState
            let newState = HandState(
                isPinching: isPinching,
                position: handAnchor.originFromAnchorTransform.columns.3.xyz,
                orientation: handAnchor.originFromAnchorTransform.rotation,
                velocity: .zero, // In a real app, calculate via (pos - prevPos)/dt
                joints: joints
            )
            
            // 3. Update the Actor (Thread-safe storage)
            await trackingActor.updateHand(handType, with: newState)
            
            // 4. Perform Interaction Logic on MainActor
            handleInteraction(for: handType, state: newState)
        }
    }
    
    /// Handles the actual movement of RealityKit entities.
    private func handleInteraction(for hand: HandAnchor.Hand, state: HandState) {
        guard let target = targetEntity else { return }
        
        if state.isPinching {
            if initialEntityTransform == nil {
                // STARTING A GRAB
                initialEntityTransform = target.transform.matrix
                initialHandTransform = state.position.toTransform().matrix
            } else {
                // CONTINUING A GRAB (6-DOF Manipulation)
                // Calculate the delta between current hand and initial hand
                let currentHandTransform = state.position.toTransform().matrix
                let handDelta = currentHandTransform * initialHandTransform!.inverse
                
                // Apply delta to the entity
                target.transform.matrix = handDelta * initialEntityTransform!
            }
        } else {
            // RELEASE THE GRAB
            initialEntityTransform = nil
            initialHandTransform = nil
        }
    }
}

// MARK: - Helpers

extension SIMD4<Float> {
    /// Extracts the xyz components from a SIMD4 vector.
    var xyz: SIMD3<Float> {
        SIMD3<Float>(x, y, z)
    }
}

extension SIMD3<Float> {
    /// Converts a position vector into a transformation matrix.
    func toTransform() -> simd_float4x4 {
        var matrix = matrix_identity_float4x4
        matrix.columns.3 = SIMD4<Float>(x, y, z, 1)
        return matrix
    }
}

extension simd_float4x4 {
    /// Extracts rotation as a quaternion.
    var rotation: simd_quatf {
        simd_quaternion(self)
    }
    
    /// Inverts the matrix.
    var inverse: simd_float4x4 {
        self.inverse
    }
}

// MARK: - SwiftUI View Layer

@available(visionOS 2.0, *)
struct SculptingView: View {
    @StateObject private var engine = SculptingEngine()
    
    var body: some View {
        RealityView { content in
            // Create a high-detail sphere for sculpting
            let sphere = ModelEntity(
                mesh: .generateSphere(radius: 0.1),
                materials: [SimpleMaterial(color: .systemBlue, isMetallic: true)]
            )
            sphere.name = "SculptTarget"
            content.add(sphere)
            
            // Link the engine to the entity
            engine.targetEntity = sphere
        }
        .overlay {
            if let error = engine.errorMessage {
                Text("Error: \(error)")
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(10)
            }
        }
    }
}
