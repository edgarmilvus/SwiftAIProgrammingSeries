
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import os.log // For Apple's unified logging system

// Ensure compatibility with latest Swift concurrency features
@available(iOS 18.0, macOS 15.0, *)
final class ConversationHistoryManager {

    // MARK: - 1. Define Core Data Structures

    /// Represents the role of a message in a conversation.
    enum ConversationRole: String, Codable {
        case system
        case user
        case assistant
    }

    /// Represents a single message in the conversation history.
    struct Message: Identifiable, Codable, Equatable {
        let id = UUID()
        let role: ConversationRole
        let content: String
        var tokenCount: Int // Simulated token count

        /// Initializes a new message and simulates its token count.
        /// In a real application, `tokenCount` would be derived from a proper tokenizer
        /// (e.g., `llama.cpp`'s BPE tokenizer).
        init(role: ConversationRole, content: String) {
            self.role = role
            self.content = content
            self.tokenCount = Message.simulateTokenCount(content)
        }

        // MARK: - 2. Implement Token Counting Simulation

        /// Simulates token counting based on character length.
        /// This is a placeholder; a real implementation would use a tokenizer
        /// specific to the LLM (e.g., `tiktoken` or `llama.cpp`'s tokenizer).
        /// - Parameter text: The text content to count tokens for.
        /// - Returns: An estimated token count.
        static func simulateTokenCount(_ text: String) -> Int {
            // A common heuristic is 1 token per 4 characters for English text.
            // This is a rough estimation and should be replaced by actual tokenizer logic.
            return max(1, (text.count + 3) / 4)
        }
    }

    // MARK: - 3. Define Custom Errors

    /// Errors that can occur during conversation history management.
    enum ConversationHistoryError: Error, LocalizedError {
        case messageExceedsBudget(messageTokens: Int, budget: Int)
        case trimmingFailed(reason: String)
        case emptyContextRequested

        var errorDescription: String? {
            switch self {
            case .messageExceedsBudget(let msgTokens, let budget):
                return "The new message (\(msgTokens) tokens) exceeds the entire conversation budget (\(budget) tokens)."
            case .trimmingFailed(let reason):
                return "Failed to trim conversation history: \(reason)"
            case .emptyContextRequested:
                return "Requested conversation context is empty."
            }
        }
    }

    // MARK: - Private Properties

    private var messages: [Message] = []
    private let maxTokenBudget: Int
    private let logger = Logger(subsystem: "com.example.SmartAssistant", category: "ConversationHistory")

    // MARK: - Initialization

    /// Initializes the conversation history manager with a maximum token budget.
    /// - Parameter maxTokenBudget: The maximum number of tokens allowed for the LLM's context window.
    init(maxTokenBudget: Int) {
        precondition(maxTokenBudget > 0, "Max token budget must be positive.")
        self.maxTokenBudget = maxTokenBudget
        logger.info("Initialized ConversationHistoryManager with budget: \(maxTokenBudget) tokens.")
    }

    // MARK: - Public Methods

    // MARK: - 5. Implement `addMessage(_:)`

    /// Adds a new message to the conversation history.
    /// - Parameter message: The message to add.
    /// - Throws: `ConversationHistoryError.messageExceedsBudget` if the message itself
    ///           is larger than the `maxTokenBudget`.
    func addMessage(_ message: Message) throws {
        if message.tokenCount > maxTokenBudget {
            logger.error("Attempted to add message that exceeds budget: \(message.tokenCount) > \(maxTokenBudget)")
            throw ConversationHistoryError.messageExceedsBudget(
                messageTokens: message.tokenCount, budget: maxTokenBudget
            )
        }
        messages.append(message)
        logger.debug("Message added: '\(message.content.prefix(50))...' (\(message.tokenCount) tokens)")
    }

    // MARK: - 6. Implement `getConversationContext()`

    /// Retrieves the conversation history, trimmed to fit within the `maxTokenBudget`.
    /// This method applies an advanced trimming strategy to prioritize important messages.
    /// - Returns: An array of `Message` objects representing the context for the LLM.
    /// - Throws: `ConversationHistoryError.emptyContextRequested` if no context can be formed.
    func getConversationContext() async throws -> [Message] {
        guard !messages.isEmpty else {
            logger.warning("Attempted to get context from an empty history.")
            throw ConversationHistoryError.emptyContextRequested
        }

        // Apply trimming logic to ensure the context fits the budget
        let trimmedContext = await trimHistory()

        guard !trimmedContext.isEmpty else {
            logger.error("Trimming resulted in an empty context, which should not happen if messages were present.")
            throw ConversationHistoryError.trimmingFailed(reason: "Resulting context is empty after trimming.")
        }

        let currentTokenCount = trimmedContext.reduce(0) { $0 + $1.tokenCount }
        logger.info("Retrieved trimmed context with \(trimmedContext.count) messages, total tokens: \(currentTokenCount)/\(maxTokenBudget)")
        return trimmedContext
    }

    // MARK: - 7. Implement `trimHistory()` (Advanced Trimming Logic)

    /// Asynchronously trims the conversation history to fit within the `maxTokenBudget`.
    /// This advanced strategy prioritizes system messages and recent user/assistant turns.
    /// - Returns: An array of `Message` objects that fit the budget.
    private func trimHistory() async -> [Message] {
        var currentContext: [Message] = []
        var currentTokenCount = 0

        // Phase 1: Always try to include system messages first.
        // System messages are crucial for defining the AI's persona or task.
        let systemMessages = messages.filter { $0.role == .system }
        for message in systemMessages {
            if currentTokenCount + message.tokenCount <= maxTokenBudget {
                currentContext.append(message)
                currentTokenCount += message.tokenCount
            } else {
                logger.warning("Not all system messages could fit. Remaining budget: \(maxTokenBudget - currentTokenCount)")
                // If even a system message can't fit, we might have a serious problem or a very small budget.
                // For this advanced app, we prioritize keeping *some* system context.
                break // Stop adding system messages if budget is hit.
            }
        }

        // Phase 2: Add non-system messages, prioritizing the most recent ones.
        // Iterate backwards through non-system messages to keep the latest conversation turns.
        let nonSystemMessages = messages.filter { $0.role != .system }
        var messagesToAdd: [Message] = []
        var tempTokenCount = currentTokenCount

        for message in nonSystemMessages.reversed() {
            if tempTokenCount + message.tokenCount <= maxTokenBudget {
                messagesToAdd.insert(message, at: 0) // Insert at beginning to maintain chronological order
                tempTokenCount += message.tokenCount
            } else {
                logger.debug("Skipping older non-system message due to budget: '\(message.content.prefix(30))...'")
            }
        }
        currentContext.append(contentsOf: messagesToAdd)
        currentTokenCount = tempTokenCount // Update total token count after adding non-system messages

        // Phase 3: If still over budget (e.g., due to a very long system prompt + one long recent message),
        // remove oldest non-system messages *from the current context* until budget is met.
        // This is a fallback in case Phase 2 added too much or Phase 1 took up most of the budget.
        while currentTokenCount > maxTokenBudget && currentContext.count > systemMessages.count {
            if let oldestNonSystemIndex = currentContext.firstIndex(where: { $0.role != .system }) {
                let removedMessage = currentContext.remove(at: oldestNonSystemIndex)
                currentTokenCount -= removedMessage.tokenCount
                logger.debug("Aggressively removed oldest non-system message: '\(removedMessage.content.prefix(30))...' to meet budget.")
            } else {
                // This case should ideally not be reached if system messages are handled separately
                // and we only remove non-system messages.
                logger.error("Failed to find non-system message to remove during aggressive trimming, but still over budget.")
                break
            }
        }

        // Final check: if even after aggressive trimming, we are over budget,
        // it implies that the system messages themselves exceed the budget, or
        // a single recent message exceeds it (which should be caught by addMessage).
        // This is a safeguard.
        if currentTokenCount > maxTokenBudget {
            logger.critical("Conversation context still exceeds max budget after aggressive trimming! Current: \(currentTokenCount), Max: \(maxTokenBudget)")
            // In a real app, this might trigger a more drastic action or error.
            // For now, we'll return the (still over-budget) context with a critical log.
        }

        return currentContext
    }

    /// Clears the entire conversation history.
    func clearHistory() {
        messages.removeAll()
        logger.info("Conversation history cleared.")
    }
}

// MARK: - 8. Demonstrate Usage in a `SmartAssistantService`

/// A service layer that integrates the ConversationHistoryManager
/// and simulates interaction with a local LLM.
@available(iOS 18.0, macOS 15.0, *)
final class SmartAssistantService {
    private let historyManager: ConversationHistoryManager
    private let logger = Logger(subsystem: "com.example.SmartAssistant", category: "SmartAssistantService")

    /// Initializes the service with a specified LLM token budget.
    /// - Parameter llmTokenBudget: The maximum token context window for the LLM.
    init(llmTokenBudget: Int) {
        self.historyManager = ConversationHistoryManager(maxTokenBudget: llmTokenBudget)
        logger.info("SmartAssistantService initialized with LLM budget: \(llmTokenBudget)")
    }

    /// Processes a user query, manages history, and simulates an LLM response.
    /// - Parameter userQuery: The user's input string.
    /// - Returns: The simulated LLM's response.
    /// - Throws: `ConversationHistoryError` if history management fails.
    func processUserQuery(_ userQuery: String) async throws -> String {
        logger.debug("Processing user query: '\(userQuery)'")

        // 1. Add user message to history
        let userMessage = ConversationHistoryManager.Message(role: .user, content: userQuery)
        try historyManager.addMessage(userMessage)

        // 2. Get the trimmed conversation context for the LLM
        let contextMessages = try await historyManager.getConversationContext()

        // 3. Simulate LLM inference with the context
        let llmResponse = await simulateLLMResponse(with: contextMessages)

        // 4. Add LLM's response to history
        let assistantMessage = ConversationHistoryManager.Message(role: .assistant, content: llmResponse)
        try historyManager.addMessage(assistantMessage)

        logger.info("LLM responded: '\(llmResponse.prefix(50))...'")
        return llmResponse
    }

    /// Simulates an LLM generating a response based on the provided context.
    /// In a real app, this would involve calling a `llama.cpp` binding.
    /// - Parameter context: The array of messages forming the LLM's input context.
    /// - Returns: A simulated response string.
    private func simulateLLMResponse(with context: [ConversationHistoryManager.Message]) async -> String {
        // Simulate network/computation delay
        try? await Task.sleep(for: .milliseconds(500))

        let lastUserMessage = context.last(where: { $0.role == .user })?.content ?? "No recent user query."
        let contextSummary = context.map { "\($0.role.rawValue): \($0.content.prefix(20))..." }.joined(separator: "; ")

        let response: String
        if context.isEmpty {
            response = "I'm sorry, I seem to have lost our conversation context. How can I help you?"
        } else if context.count == 1 && context.first?.role == .system {
            response = "Hello! I'm your smart assistant. How can I assist you today?"
        } else {
            response = "Based on our recent chat, and your query about '\(lastUserMessage.prefix(30))...', I can tell you that... (Simulated LLM Response)"
        }
        return response
    }

    /// Adds an initial system prompt to guide the assistant's behavior.
    /// - Parameter prompt: The system instruction.
    func addSystemPrompt(_ prompt: String) throws {
        let systemMessage = ConversationHistoryManager.Message(role: .system, content: prompt)
        try historyManager.addMessage(systemMessage)
        logger.info("System prompt added: '\(prompt.prefix(50))...'")
    }

    /// Clears the entire conversation history.
    func clearConversation() {
        historyManager.clearHistory()
    }
}

// MARK: - Example Usage in an Apple Application Context

@available(iOS 18.0, macOS 15.0, *)
@main
struct SmartAssistantApp {
    static func main() async {
        let llmTokenBudget = 100 // A small budget for demonstration purposes
        let assistant = SmartAssistantService(llmTokenBudget: llmTokenBudget)

        print("--- Smart Assistant Demo ---")
        print("LLM Token Budget: \(llmTokenBudget)\n")

        do {
            // 1. Add a system prompt
            try assistant.addSystemPrompt("You are a helpful AI assistant focused on Swift programming and Apple platforms. Keep responses concise.")

            // 2. User asks a question
            print("User: What's new in Swift 6 concurrency?")
            var response = try await assistant.processUserQuery("What's new in Swift 6 concurrency?")
            print("Assistant: \(response)\n")

            // 3. User asks a follow-up (history should be managed)
            print("User: Can you give me an example with Actors?")
            response = try await assistant.processUserQuery("Can you give me an example with Actors?")
            print("Assistant: \(response)\n")

            // 4. User asks a long question that might push older history out
            print("User: I'm building an app that needs to fetch data from multiple network endpoints concurrently, process it, and then update a UI. What's the best way to do this using async/await and potentially Combine or Observation in Swift 6 on iOS 18?")
            response = try await assistant.processUserQuery("I'm building an app that needs to fetch data from multiple network endpoints concurrently, process it, and then update a UI. What's the best way to do this using async/await and potentially Combine or Observation in Swift 6 on iOS 18?")
            print("Assistant: \(response)\n")

            // 5. User asks a very short, new question. The system prompt and most recent messages should remain.
            print("User: What about TaskGroups?")
            response = try await assistant.processUserQuery("What about TaskGroups?")
            print("Assistant: \(response)\n")

            // 6. Demonstrate an error case: message too large
            let veryLongMessage = String(repeating: "This is a very long sentence. ", count: 100) // ~500 tokens
            print("User: \(veryLongMessage.prefix(50))... (Attempting to send a very long message)")
            do {
                _ = try await assistant.processUserQuery(veryLongMessage)
            } catch ConversationHistoryManager.ConversationHistoryError.messageExceedsBudget(let msgTokens, let budget) {
                print("Error: \(msgTokens) tokens for message, but budget is \(budget). Message too large!\n")
            }

            // 7. Clear history
            assistant.clearConversation()
            print("Conversation history cleared.\n")

            // 8. New conversation
            print("User: Hello!")
            response = try await assistant.processUserQuery("Hello!")
            print("Assistant: \(response)\n")

        } catch {
            print("An unexpected error occurred: \(error.localizedDescription)")
        }
    }
}
