
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import AppKit // Required for AppKit components

// MARK: - 1. The AppKit Component (Legacy Status Log View)

/// `AppKitStatusView` is a simple AppKit NSView subclass designed to display
/// status messages from our voice assistant. In a real-world scenario, this
/// could be a much more complex view with custom drawing, text rendering,
/// or even embedded OpenGL/Metal content.
///
/// It exposes a `updateStatus` method to allow external SwiftUI views to
/// change its displayed content.
class AppKitStatusView: NSView {
    // MARK: Properties
    private let statusLabel: NSTextField

    // MARK: Initialization
    override init(frame frameRect: NSRect) {
        // Initialize with a default frame, though it will be managed by SwiftUI
        super.init(frame: frameRect)
        setupView()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: View Setup
    /// Configures the subviews within the AppKitStatusView.
    private func setupView() {
        // Create an NSTextField to display the status message.
        statusLabel = NSTextField(labelWithString: "Assistant Status: Idle")
        statusLabel.translatesAutoresizingMaskIntoConstraints = false // Enable Auto Layout
        statusLabel.isSelectable = false // Make text not selectable
        statusLabel.isEditable = false // Make text not editable
        statusLabel.backgroundColor = .clear // Transparent background
        statusLabel.font = .monospacedSystemFont(ofSize: 12, weight: .regular) // Monospaced font for logs
        statusLabel.textColor = .secondaryLabelColor // Subtler text color
        statusLabel.maximumNumberOfLines = 0 // Allow multiple lines
        statusLabel.lineBreakMode = .byWordWrapping // Wrap words

        // Add the label as a subview
        addSubview(statusLabel)

        // Set up Auto Layout constraints to fill the parent view
        NSLayoutConstraint.activate([
            statusLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            statusLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            statusLabel.topAnchor.constraint(equalTo: topAnchor, constant: 10),
            statusLabel.bottomAnchor.constraint(lessThanOrEqualTo: bottomAnchor, constant: -10) // Allow content to push down
        ])

        // Set a background color for better visibility in the example
        self.wantsLayer = true // Needed to set layer properties
        self.layer?.backgroundColor = NSColor.windowBackgroundColor.cgColor // Light gray background
        self.layer?.cornerRadius = 8 // Rounded corners
    }

    // MARK: Public API
    /// Updates the status message displayed by the `NSTextField`.
    /// This method is called from the SwiftUI `updateNSView` method.
    /// - Parameter newStatus: The new string to display as the status.
    func updateStatus(_ newStatus: String) {
        // Ensure UI updates happen on the main thread.
        // While SwiftUI's `updateNSView` is typically on the main thread,
        // it's a good practice to be explicit for AppKit views, especially
        // if this method were called from an asynchronous context.
        DispatchQueue.main.async {
            self.statusLabel.stringValue = "Assistant Status: \(newStatus)"
            // In a real log view, you might append to a text view,
            // scroll to bottom, etc.
        }
    }
}

// MARK: - 2. The SwiftUI Bridge (NSViewRepresentable)

/// `AppKitStatusViewRepresentable` acts as the bridge between SwiftUI and our
/// AppKitStatusView. It conforms to `NSViewRepresentable`, allowing SwiftUI
/// to manage the lifecycle and data flow for the AppKit view.
struct AppKitStatusViewRepresentable: NSViewRepresentable {
    // MARK: Properties
    /// The current status string, passed from SwiftUI state.
    var currentStatus: String

    // MARK: NSViewRepresentable Protocol Conformance

    /// `makeNSView(context:)` is called by SwiftUI to create and configure
    /// the initial instance of the AppKit view. This happens only once.
    /// - Parameter context: An `NSViewRepresentableContext` containing information
    ///   about the current environment.
    /// - Returns: An instance of `AppKitStatusView`.
    func makeNSView(context: Context) -> AppKitStatusView {
        // Create an instance of our AppKit view.
        // SwiftUI will manage its frame and lifecycle.
        let appKitView = AppKitStatusView()
        appKitView.updateStatus(currentStatus) // Set initial status
        return appKitView
    }

    /// `updateNSView(_:context:)` is called by SwiftUI whenever relevant
    /// state changes in the SwiftUI view that hosts this representable.
    /// This is where you update the AppKit view's properties based on
    /// the new `currentStatus` value.
    /// - Parameters:
    ///   - nsView: The existing instance of `AppKitStatusView` created by `makeNSView`.
    ///   - context: An `NSViewRepresentableContext`.
    func updateNSView(_ nsView: AppKitStatusView, context: Context) {
        // Update the AppKit view's status whenever `currentStatus` changes in SwiftUI.
        nsView.updateStatus(currentStatus)
    }

    /// `dismantleNSView(_:coordinator:)` (optional) is called by SwiftUI
    /// when the AppKit view is removed from the view hierarchy. Use this
    /// for cleanup, such as invalidating timers, releasing resources,
    /// or breaking strong reference cycles if you had a coordinator.
    /// - Parameters:
    ///   - nsView: The instance of `AppKitStatusView` being dismantled.
    ///   - coordinator: The coordinator object (if `makeCoordinator` was implemented).
    static func dismantleNSView(_ nsView: AppKitStatusView, coordinator: ()) {
        // For this simple example, no specific cleanup is needed.
        // In more complex scenarios, you might invalidate timers, release delegates, etc.
        print("AppKitStatusView dismantled.")
    }
}

// MARK: - 3. The SwiftUI Host View

/// `ContentView` is our main SwiftUI view that integrates the AppKit component.
/// It holds the state for the assistant's status and provides a button to
/// simulate status updates.
struct ContentView: View {
    // MARK: State
    /// `@State` property to hold the current status message.
    /// Changes to this property will trigger `updateNSView` in `AppKitStatusViewRepresentable`.
    @State private var assistantStatus: String = "Initializing..."
    @State private var statusCounter: Int = 0

    // MARK: Body
    var body: some View {
        VStack(spacing: 20) {
            Text("Voice Assistant Dashboard")
                .font(.largeTitle)
                .fontWeight(.bold)

            // Embed the AppKitStatusViewRepresentable here.
            // It will display the AppKitStatusView, managed by SwiftUI.
            AppKitStatusViewRepresentable(currentStatus: assistantStatus)
                .frame(maxWidth: .infinity, minHeight: 100) // Give it a fixed height for visibility
                .padding()
                .background(Color.clear) // The AppKit view has its own background
                .cornerRadius(10)
                .shadow(radius: 5)

            Button("Simulate New Status Update") {
                statusCounter += 1
                let statuses = [
                    "Listening for command...",
                    "Processing request...",
                    "Generating response...",
                    "Responding...",
                    "Command complete. Awaiting next input.",
                    "Network error. Retrying...",
                    "Assistant sleeping."
                ]
                assistantStatus = statuses[statusCounter % statuses.count]
            }
            .padding()
            .background(Color.accentColor)
            .foregroundColor(.white)
            .cornerRadius(8)
            .shadow(radius: 3)

            Spacer()
        }
        .padding()
        .frame(minWidth: 500, minHeight: 400) // Set a reasonable window size for macOS
        .onAppear {
            // Initial status update after the view appears
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                assistantStatus = "Ready to receive commands."
            }
        }
    }
}

// MARK: - macOS App Entry Point

/// The main entry point for our macOS application.
@main
struct VoiceAssistantApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .windowStyle(.hiddenTitleBar) // A common style for modern macOS apps
    }
}
