
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import AVFoundation
import Vision
import CoreML // Assume MyObjectDetector.mlmodel is added to the project

// MARK: - TrackedObject Structure
struct TrackedObject {
    let id: UUID
    var observation: VNRecognizedObjectObservation
    var boxLayer: CAShapeLayer
    var textLayer: CATextLayer
    var lastSeenTimestamp: TimeInterval
}

class InventoryScannerViewController: UIViewController {

    private var captureSession: AVCaptureSession!
    private var previewLayer: AVCaptureVideoPreviewLayer!
    private var videoDataOutput: AVCaptureVideoDataOutput!
    private let videoDataOutputQueue = DispatchQueue(label: "VideoDataOutput", qos: .userInitiated)

    private var objectDetectionRequest: VNCoreMLRequest!
    private var trackedObjects: [UUID: TrackedObject] = [:]
    private var lastDetectionTime: TimeInterval = 0
    private let detectionInterval: TimeInterval = 1.0 / 15.0 // Target 15 FPS for detection

    private var selectedObjectId: UUID? {
        didSet {
            // Update UI for previously selected object
            if let oldId = oldValue, let oldObject = trackedObjects[oldId] {
                oldObject.boxLayer.strokeColor = UIColor.red.cgColor
            }
            // Update UI for newly selected object
            if let newId = selectedObjectId, let newObject = trackedObjects[newId] {
                newObject.boxLayer.strokeColor = UIColor.blue.cgColor
                print("Selected object: \(newObject.observation.labels.first?.identifier ?? "Unknown")")
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
        setupVision()
        setupGestureRecognizer()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !captureSession.isRunning {
            videoDataOutputQueue.async {
                self.captureSession.startRunning()
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession.isRunning {
            videoDataOutputQueue.async {
                self.captureSession.stopRunning()
            }
        }
        clearAllOverlays()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer.frame = view.bounds
        // Re-layout overlay layers if bounds change (clearing and redrawing is simpler here)
        DispatchQueue.main.async {
            self.clearAllOverlays()
        }
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .hd1920x1080 // Higher resolution for object detection

        guard let backCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Unable to access back camera.")
            return
        }

        do {
            let input = try AVCaptureDeviceInput(device: backCamera)
            if captureSession.canAddInput(input) {
                captureSession.addInput(input)
            }

            videoDataOutput = AVCaptureVideoDataOutput()
            videoDataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
            videoDataOutput.alwaysDiscardsLateVideoFrames = true // Crucial for performance
            videoDataOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]

            if captureSession.canAddOutput(videoDataOutput) {
                captureSession.addOutput(videoDataOutput)
            }

            if let connection = videoDataOutput.connection(with: .video), connection.isVideoOrientationSupported {
                connection.videoOrientation = .portrait
            }

            previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            previewLayer.videoGravity = .resizeAspectFill
            previewLayer.frame = view.bounds
            view.layer.addSublayer(previewLayer)

        } catch {
            print("Error setting up camera input: \(error.localizedDescription)")
        }
    }

    private func setupVision() {
        do {
            // Assume MyObjectDetector.mlmodel is your custom Core ML model
            let config = MLModelConfiguration()
            let coreMLModel = try MyObjectDetector(configuration: config).model // Replace MyObjectDetector with your model's generated class
            let visionModel = try VNCoreMLModel(for: coreMLModel)

            objectDetectionRequest = VNCoreMLRequest(model: visionModel) { [weak self] request, error in
                self?.handleObjectDetection(request: request, error: error)
            }
            objectDetectionRequest.imageCropAndScaleOption = .scaleFit // or .centerCrop, depends on model training
        } catch {
            print("Error setting up Vision model: \(error.localizedDescription)")
        }
    }

    private func setupGestureRecognizer() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        view.addGestureRecognizer(tapGesture)
    }

    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        let tapLocation = gesture.location(in: view)
        // Convert tap location to previewLayer coordinates
        let tapLocationInPreview = previewLayer.convert(tapLocation, from: view.layer)

        var tappedObject: TrackedObject?
        for (id, object) in trackedObjects {
            if object.boxLayer.path?.boundingBox.contains(tapLocationInPreview) ?? false {
                tappedObject = object
                selectedObjectId = id
                break
            }
        }

        if tappedObject == nil {
            selectedObjectId = nil // Deselect if no object tapped
        }
    }

    private func handleObjectDetection(request: VNRequest, error: Error?) {
        DispatchQueue.main.async {
            // Remove old objects that haven't been detected recently
            let currentTime = CACurrentMediaTime()
            self.trackedObjects = self.trackedObjects.filter { (id, object) in
                if currentTime - object.lastSeenTimestamp > 0.5 { // Object considered lost after 0.5 seconds
                    object.boxLayer.removeFromSuperlayer()
                    object.textLayer.removeFromSuperlayer()
                    if self.selectedObjectId == id { self.selectedObjectId = nil } // Deselect if lost
                    return false
                }
                return true
            }

            guard let observations = request.results as? [VNRecognizedObjectObservation] else {
                print("Object detection failed: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            var newOrUpdatedIds: Set<UUID> = []
            for observation in observations {
                // Heuristic for matching: find closest existing object with similar label
                var matchedObject: TrackedObject?
                let currentObjectLabel = observation.labels.first?.identifier ?? "unknown"

                for (id, tracked) in self.trackedObjects {
                    let trackedLabel = tracked.observation.labels.first?.identifier ?? "unknown"
                    let iou = self.iou(observation.boundingBox, tracked.observation.boundingBox)

                    // Match if labels are same/similar and IoU is high enough
                    if currentObjectLabel == trackedLabel && iou > 0.3 { // Threshold for IoU overlap
                        matchedObject = tracked
                        break
                    }
                }

                let rect = observation.boundingBox(in: self.previewLayer)
                let labelText = "\(currentObjectLabel) (\(String(format: "%.1f", (observation.labels.first?.confidence ?? 0) * 100))%)"

                if var matched = matchedObject {
                    // Update existing object
                    matched.observation = observation
                    matched.lastSeenTimestamp = currentTime
                    matched.boxLayer.path = UIBezierPath(rect: rect).cgPath
                    matched.textLayer.string = labelText
                    matched.textLayer.frame = self.textLayerFrame(for: rect, text: labelText)
                    self.trackedObjects[matched.id] = matched
                    newOrUpdatedIds.insert(matched.id)
                } else {
                    // Create new object
                    let newId = UUID()
                    let boxLayer = self.createBoundingBoxLayer(with: rect, isSelected: (newId == self.selectedObjectId))
                    let textLayer = self.createLabelLayer(with: labelText, in: rect)

                    self.previewLayer.addSublayer(boxLayer)
                    self.previewLayer.addSublayer(textLayer)

                    self.trackedObjects[newId] = TrackedObject(
                        id: newId,
                        observation: observation,
                        boxLayer: boxLayer,
                        textLayer: textLayer,
                        lastSeenTimestamp: currentTime
                    )
                    newOrUpdatedIds.insert(newId)
                }
            }
        }
    }

    private func createBoundingBoxLayer(with rect: CGRect, isSelected: Bool) -> CAShapeLayer {
        let layer = CAShapeLayer()
        layer.path = UIBezierPath(rect: rect).cgPath
        layer.strokeColor = isSelected ? UIColor.blue.cgColor : UIColor.red.cgColor
        layer.lineWidth = 2.0
        layer.fillColor = UIColor.clear.cgColor
        return layer
    }

    private func createLabelLayer(with text: String, in rect: CGRect) -> CATextLayer {
        let textLayer = CATextLayer()
        textLayer.string = text
        textLayer.fontSize = 14
        textLayer.foregroundColor = UIColor.white.cgColor
        textLayer.backgroundColor = UIColor.red.withAlphaComponent(0.6).cgColor
        textLayer.alignmentMode = .center
        textLayer.contentsScale = UIScreen.main.scale // For sharp text
        textLayer.frame = textLayerFrame(for: rect, text: text)
        return textLayer
    }

    private func textLayerFrame(for boxRect: CGRect, text: String) -> CGRect {
        let textHeight: CGFloat = 20
        let textWidth = (text as NSString).size(withAttributes: [.font: UIFont.systemFont(ofSize: 14)]).width + 10 // Add padding
        return CGRect(x: boxRect.origin.x, y: boxRect.origin.y - textHeight, width: min(textWidth, boxRect.width), height: textHeight)
    }

    private func clearAllOverlays() {
        for (_, object) in trackedObjects {
            object.boxLayer.removeFromSuperlayer()
            object.textLayer.removeFromSuperlayer()
        }
        trackedObjects.removeAll()
        selectedObjectId = nil
    }

    // MARK: - IoU Calculation for Tracking Heuristic
    private func iou(_ rect1: CGRect, _ rect2: CGRect) -> CGFloat {
        let intersection = rect1.intersection(rect2)
        let union = rect1.union(rect2)
        if union.width == 0 || union.height == 0 { return 0 }
        return (intersection.width * intersection.height) / (union.width * union.height)
    }
}

extension InventoryScannerViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Throttling: Only process frames at a target FPS
        let currentTime = CACurrentMediaTime()
        guard currentTime - lastDetectionTime > detectionInterval else { return }
        lastDetectionTime = currentTime

        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Use autoreleasepool to manage memory for each frame processing cycle
        autoreleasepool {
            let imageOrientation = CGImagePropertyOrientation(
                interfaceOrientation: UIApplication.shared.windows.first?.windowScene?.interfaceOrientation ?? .portrait
            )

            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: imageOrientation, options: [:])

            do {
                try handler.perform([objectDetectionRequest])
            } catch {
                print("Failed to perform object detection: \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - Helper Extensions (reused from previous exercises)

extension CGImagePropertyOrientation {
    init(interfaceOrientation: UIInterfaceOrientation) {
        switch interfaceOrientation {
        case .portrait: self = .up
        case .portraitUpsideDown: self = .down
        case .landscapeLeft: self = .right
        case .landscapeRight: self = .left
        default: self = .up
        }
    }
}

extension VNRecognizedObjectObservation {
    func boundingBox(in previewLayer: AVCaptureVideoPreviewLayer) -> CGRect {
        let flippedBoundingBox = CGRect(
            x: boundingBox.origin.x,
            y: 1 - boundingBox.origin.y - boundingBox.height,
            width: boundingBox.width,
            height: boundingBox.height
        )
        return previewLayer.layerRectConverted(fromMetadataOutputRect: flippedBoundingBox)
    }
}

// NOTE: MyObjectDetector.mlmodel is a placeholder. You need to replace it with your actual Core ML model.
// For example, if you download a YOLOv3-tiny model and convert it, it might generate a class like YOLOv3Tiny.
// Make sure to add your .mlmodel file to the project.
