
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CreateML
import CoreML

// MARK: - Placeholder Data Source and Evaluation (from previous exercises)
@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
private func evaluateModel(_ model: MLImageClassifier, on dataSource: MLImageClassifier.DataSource) async throws -> Double {
    print("  (Simulating model evaluation for validation accuracy for Drone Surveillance...)")
    // Simulate varying accuracies to demonstrate different impacts
    let baseAccuracy = Double.random(in: 0.70...0.80) // Baseline might be lower
    return baseAccuracy + Double.random(in: 0.0...0.18) // Augmentations can add up to 18%
}

// MARK: - Experiment Structure and Helper Functions

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
struct AugmentationExperimentResult {
    let strategy: String
    let trainingTime: TimeInterval // in seconds
    let validationAccuracy: Double
    let modelFileSizeKB: Double
}

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
func runAugmentationExperiment(trainingData: MLImageClassifier.DataSource, validationData: MLImageClassifier.DataSource) async throws -> [AugmentationExperimentResult] {
    var results: [AugmentationExperimentResult] = []
    let epochs = 10 // Keep epochs consistent for fair comparison in individual impact
    let combinedEpochs = 15 // Potentially more epochs for the final combined strategy

    // Helper to train and record
    func trainAndRecord(strategy: String, augmentations: MLImageClassifier.DataSource.AugmentationOptions?, epochs: Int) async throws {
        let startTime = Date()
        print("Training with strategy: \(strategy) for \(epochs) epochs...")
        
        let parameters = MLImageClassifier.ModelParameters(
            validationData: validationData,
            augmentationOptions: augmentations,
            epochs: epochs,
            shuffle: true,
            learningRate: 0.001,
            progressHandler: { context in
                if let metrics = context.metrics {
                    // print("    \(strategy) Epoch \(metrics.epoch): Val Acc = \(String(format: "%.2f", metrics.validationAccuracy * 100))%")
                }
            }
        )
        let model = try await MLImageClassifier.train(
            trainingData: trainingData,
            parameters: parameters
        )
        let trainingTime = Date().timeIntervalSince(startTime)
        
        // Save model to a temporary location to get file size
        let tempDir = FileManager.default.temporaryDirectory
        let modelURL = tempDir.appendingPathComponent("temp_\(UUID().uuidString).mlmodelc")
        try model.write(to: modelURL)
        
        // Get directory size (which is the .mlmodelc bundle size)
        var modelFileSize: UInt64 = 0
        if let enumerator = FileManager.default.enumerator(at: modelURL, includingPropertiesForKeys: [.fileSizeKey], options: []) {
            for case let fileURL as URL in enumerator {
                let attributes = try FileManager.default.attributesOfItem(atPath: fileURL.path)
                if let fileSize = attributes[.size] as? UInt64 {
                    modelFileSize += fileSize
                }
            }
        }
        
        try FileManager.default.removeItem(at: modelURL) // Clean up
        
        let validationAccuracy = try await evaluateModel(model, on: validationData)

        results.append(AugmentationExperimentResult(
            strategy: strategy,
            trainingTime: trainingTime,
            validationAccuracy: validationAccuracy,
            modelFileSizeKB: Double(modelFileSize) / 1024.0
        ))
        print("  Finished \(strategy). Accuracy: \(String(format: "%.2f", validationAccuracy * 100))%, Time: \(String(format: "%.2f", trainingTime))s, Size: \(String(format: "%.2f", modelFileSizeKB))KB")
    }

    // 1. Baseline Model
    try await trainAndRecord(strategy: "Baseline (No Augmentation)", augmentations: nil, epochs: epochs)

    // 2. Individual Augmentation Impact
    // Rotation only
    var rotationOptions = MLImageClassifier.DataSource.AugmentationOptions()
    rotationOptions.rotation = .degrees(range: -25.0...25.0)
    try await trainAndRecord(strategy: "Rotation Only", augmentations: rotationOptions, epochs: epochs)

    // ColorJitter only
    var colorJitterOptions = MLImageClassifier.DataSource.AugmentationOptions()
    colorJitterOptions.colorJitter = .fraction(brightness: 0.1, contrast: 0.1, saturation: 0.05, hue: 0.02)
    try await trainAndRecord(strategy: "ColorJitter Only", augmentations: colorJitterOptions, epochs: epochs)
    
    // Blur only
    var blurOptions = MLImageClassifier.DataSource.AugmentationOptions()
    blurOptions.blur = .pixels(range: 0.0...2.0)
    try await trainAndRecord(strategy: "Blur Only", augmentations: blurOptions, epochs: epochs)

    // Scale only
    var scaleOptions = MLImageClassifier.DataSource.AugmentationOptions()
    scaleOptions.scale = .fraction(min: 0.8, max: 1.2)
    try await trainAndRecord(strategy: "Scale Only", augmentations: scaleOptions, epochs: epochs)

    // Translation only
    var translationOptions = MLImageClassifier.DataSource.AugmentationOptions()
    translationOptions.translation = .fraction(range: -0.15...0.15)
    try await trainAndRecord(strategy: "Translation Only", augmentations: translationOptions, epochs: epochs)

    // Horizontal Flip only
    var flipOptions = MLImageClassifier.DataSource.AugmentationOptions()
    flipOptions.flip = .horizontal
    try await trainAndRecord(strategy: "Horizontal Flip Only", augmentations: flipOptions, epochs: epochs)

    // Random Crop only
    var randomCropOptions = MLImageClassifier.DataSource.AugmentationOptions()
    randomCropOptions.randomCrop = .fraction(min: 0.85, max: 1.0)
    try await trainAndRecord(strategy: "Random Crop Only", augmentations: randomCropOptions, epochs: epochs)

    // 3. Combined Strategy (Design this based on your hypothesis for aerial imagery)
    var combinedOptions = MLImageClassifier.DataSource.AugmentationOptions()
    combinedOptions.rotation = .degrees(range: -15.0...15.0) // Moderate rotation, drone might tilt
    combinedOptions.scale = .fraction(min: 0.75, max: 1.25)  // Significant scale variation (altitude changes)
    combinedOptions.translation = .fraction(range: -0.15...0.15) // Object can be anywhere in frame
    combinedOptions.flip = .horizontal // Objects can appear mirrored from above
    // Minor color jitter for varying light conditions (cloud cover, time of day)
    combinedOptions.colorJitter = .fraction(brightness: 0.05, contrast: 0.05) 
    // Omit aggressive blur or perspective warp if not typical for drone images
    // Drone cameras are usually stable, so heavy blur/perspective warp might be less necessary.
    // Random crop might be less suitable if objects are small and sparse.
    try await trainAndRecord(strategy: "Optimized Combined Strategy", augmentations: combinedOptions, epochs: combinedEpochs)

    return results
}

// MARK: - Main Execution Logic (Example)

@available(iOS 18.0, macOS 15.0, tvOS 18.0, visionOS 1.0, *)
func runDroneSurveillanceExperiment() async throws {
    // --- IMPORTANT: Replace with your actual data sources ---
    let dummyTrainingData = try MLImageClassifier.DataSource.labeledDirectories(at: URL(fileURLWithPath: "/tmp/dummy_drone_training"))
    let dummyValidationData = try MLImageClassifier.DataSource.labeledDirectories(at: URL(fileURLWithPath: "/tmp/dummy_drone_validation"))
    
    try FileManager.default.createDirectory(at: URL(fileURLWithPath: "/tmp/dummy_drone_training/classA"), withIntermediateDirectories: true, attributes: nil)
    try FileManager.default.createDirectory(at: URL(fileURLWithPath: "/tmp/dummy_drone_validation/classA"), withIntermediateDirectories: true, attributes: nil)

    print("--- Starting Drone Surveillance Augmentation Experiment ---")
    let experimentResults = try await runAugmentationExperiment(trainingData: dummyTrainingData, validationData: dummyValidationData)

    print("\n--- Comparative Analysis ---")
    print("Strategy | Accuracy (%) | Training Time (s) | Model Size (KB)")
    print("-----------------------------------------------------------------")
    for result in experimentResults {
        print(String(format: "%-16s | %.2f         | %.2f             | %.2f",
                     result.strategy, result.validationAccuracy * 100, result.trainingTime, result.modelFileSizeKB))
    }
    print("-----------------------------------------------------------------")

    print("\n--- Justification for Optimized Combined Strategy ---")
    print("Based on the scenario (drone surveillance) and typical aerial imagery characteristics:")
    print("- **Scale & Translation:** These are paramount. Objects (vehicles, animals, persons) appear at vastly different scales due to varying drone altitudes and can be located anywhere in the wide aerial frame. High ranges for `scale` and `translation` are critical.")
    print("- **Rotation & Horizontal Flip:** Drones can tilt slightly, and objects can be oriented in any direction. Horizontal flip is useful as objects might appear mirrored from above. A moderate rotation range is usually sufficient.")
    print("- **Color Jitter:** Minor brightness/contrast adjustments account for varying lighting conditions (cloud cover, time of day) but typically less extreme than ground-level photos.")
    print("- **Omitted Augmentations:**")
    print("  - **Blur:** Drone cameras are usually stable and high-resolution. Excessive blur might simulate conditions not typical of good drone footage and could hinder learning fine details.")
    print("  - **Perspective Warp:** While possible, severe perspective distortion is less common from a high-altitude drone compared to close-up ground photography.")
    print("  - **Random Crop:** For small, sparse objects in wide aerial views, aggressive random cropping could remove the object entirely or only show a tiny part, making classification harder. A full-image context is often more valuable.")
    print("\n**Performance Budgeting:**")
    print("The goal is to achieve high accuracy with a reasonable training time and model size for on-device deployment. Augmentations like `blur` and `perspectiveWarp` can be computationally expensive during training and might not offer proportional accuracy gains for aerial data, potentially increasing model complexity without benefit. By carefully selecting augmentations that directly address drone imagery challenges and omitting less relevant ones, we aim for an efficient yet robust model. The chosen combined strategy focuses on the most impactful transformations (scale, translation, rotation, flip) which are crucial for aerial object detection, with minor color adjustments, balancing accuracy gains against computational costs and model footprint.")
    
    // Clean up dummy directories
    try? FileManager.default.removeItem(at: URL(fileURLWithPath: "/tmp/dummy_drone_training"))
    try? FileManager.default.removeItem(at: URL(fileURLWithPath: "/tmp/dummy_drone_validation"))
}

// To run this code:
// Task {
//     try await runDroneSurveillanceExperiment()
// }
