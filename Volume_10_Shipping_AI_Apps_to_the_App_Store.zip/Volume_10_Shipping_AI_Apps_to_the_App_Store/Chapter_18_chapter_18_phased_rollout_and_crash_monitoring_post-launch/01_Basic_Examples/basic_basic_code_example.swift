
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Observation
import OSLog

// MARK: - Models & Errors

/// Represents the different types of telemetry data we collect.
/// In an AI app, we must distinguish between network errors and model-specific errors.
enum TelemetryEvent: Sendable {
    case inferenceStarted(modelID: String)
    case inferenceCompleted(modelID: String, latency: TimeInterval)
    case criticalError(error: AIError)
    case resourceWarning(type: ResourceType)
}

/// Specific error types encountered during AI operations.
enum AIError: Error, Sendable {
    case modelLoadingFailed
    case inferenceTimeout
    case contextWindowExceeded
    case hardwareAccelerationUnavailable
    case unknown(String)
}

/// Types of system resources to monitor during heavy AI workloads.
enum ResourceType: Sendable {
    case thermalThrottling
    case highMemoryPressure
}

/// The health status of the current app deployment.
enum DeploymentHealth: Sendable {
    case healthy
    case degraded(reason: String)
    case critical(reason: String)
}

// MARK: - Monitoring Service

/// An Actor-based service to handle telemetry.
/// Using an `actor` ensures that multiple concurrent AI tasks can report 
/// metrics simultaneously without causing data races in our telemetry logs.
///
/// This is the "Brain" of your post-launch monitoring.
actor TelemetryService {
    private let logger = Logger(subsystem: "com.ai.assistant", category: "Telemetry")
    private var errorCount: Int = 0
    private let errorThreshold: Int = 5 // Threshold to trigger a "Halt Rollout" signal
    
    /// Tracks the current health of the deployment.
    private(set) var currentHealth: DeploymentHealth = .healthy

    /// Records a telemetry event and evaluates if the deployment is still safe.
    /// - Parameter event: The event to record.
    func record(_ event: TelemetryEvent) {
        switch event {
        case .inferenceStarted(let modelID):
            logger.info("🚀 Starting inference for model: \(modelID)")
            
        case .inferenceCompleted(let modelID, let latency):
            logger.info("✅ Inference completed for \(modelID) in \(latency)s")
            if latency > 5.0 {
                logger.warning("⚠️ High latency detected: \(latency)s")
            }
            
        case .criticalError(let error):
            errorCount += 1
            logger.error("❌ Critical AI Error: \(String(describing: error))")
            evaluateHealth()
            
        case .resourceWarning(let type):
            logger.warning("🌡️ Resource Warning: \(String(describing: type))")
            currentHealth = .degraded(reason: "System resources under pressure: \(String(describing: type))")
        }
    }

    /// Internal logic to decide if the phased rollout should be halted.
    /// In a real-world app, this might trigger a remote configuration flag 
    /// that disables the new AI feature globally.
    private func evaluateHealth() {
        if errorCount >= errorThreshold {
            currentHealth = .critical(reason: "Error threshold exceeded (\(errorCount) errors).")
            logger.critical("🚨 DEPLOYMENT CRITICAL: Error threshold reached. Suggest halting phased rollout.")
        } else if errorCount > 0 {
            currentHealth = .degraded(reason: "Increasing error rate detected.")
        }
    }
}

// MARK: - AI Logic Engine

/// A simulated AI Model Manager.
/// This class represents the heavy-lifting component that interacts with CoreML or an API.
@available(iOS 18.0, *)
final class AIModelManager: Sendable {
    private let telemetry: TelemetryService
    private let modelID = "GPT-4o-Mini-Local"

    init(telemetry: TelemetryService) {
        self.telemetry = telemetry
    }

    /// Simulates an AI inference task.
    /// - Returns: A string representing the AI response.
    /// - Throws: An `AIError` if the simulation fails.
    func generateResponse(prompt: String) async throws -> String {
        await telemetry.record(.inferenceStarted(modelID: modelID))
        let startTime = CFAbsoluteTimeGetCurrent()

        // Simulate network/compute latency
        try await Task.sleep(for: .seconds(Double.random(in: 0.5...2.0)))

        // Simulate a random failure to demonstrate monitoring
        let randomFailure = Int.random(in: 1...10)
        if randomFailure == 1 {
            let error = AIError.inferenceTimeout
            await telemetry.record(.criticalError(error: error))
            throw error
        }

        let duration = CFAbsoluteTimeGetCurrent() - startTime
        await telemetry.record(.inferenceCompleted(modelID: modelID, latency: duration))
        
        return "AI Response to: \(prompt)"
    }
}

// MARK: - View Model (UI Layer)

/// The ViewModel manages the UI state and coordinates between the AI engine and the user.
/// It uses the `@Observable` macro (introduced in Swift 5.9/iOS 17+) for modern state management.
///
/// It is marked with `@MainActor` to ensure all UI updates happen on the main thread.
@Observable
@MainActor
final class VoiceAssistantViewModel {
    var responseText: String = "Ask me anything..."
    var isProcessing: Bool = false
    var healthStatus: String = "System Healthy"
    var deploymentHealth: DeploymentHealth = .healthy

    private let aiManager: AIModelManager
    private let telemetry: TelemetryService

    init(aiManager: AIModelManager, telemetry: TelemetryService) {
        self.aiManager = aiManager
        self.telemetry = telemetry
        
        // Start a background task to monitor health updates from the actor
        Task {
            await monitorHealthLoop()
        }
    }

    /// Continuously polls the telemetry service for health changes.
    /// In a production app, you might use an `AsyncStream` from the actor instead of polling.
    private func monitorHealthLoop() async {
        while !Task.isCancelled {
            let health = await telemetry.currentHealth
            self.deploymentHealth = health
            
            switch health {
            case .healthy:
                self.healthStatus = "✅ System Healthy"
            case .degraded(let reason):
                self.healthStatus = "⚠️ Degraded: \(reason)"
            case .critical(let reason):
                self.healthStatus = "🚨 CRITICAL: \(reason)"
            }
            
            // Poll every 2 seconds
            try? await Task.sleep(for: .seconds(2))
        }
    }

    /// The primary entry point for user interaction.
    func handleUserPrompt(_ prompt: String) async {
        isProcessing = true
        responseText = "Thinking..."
        
        do {
            let result = try await aiManager.generateResponse(prompt: prompt)
            responseText = result
        } catch {
            responseText = "Error: \(error.localizedDescription)"
        }
        
        isProcessing = false
    }
}

// MARK: - View (SwiftUI)

import SwiftUI

@available(iOS 18.0, *)
struct VoiceAssistantView: View {
    @State private var viewModel: VoiceAssistantViewModel
    @State private var promptInput: String = ""

    init(viewModel: VoiceAssistantViewModel) {
        _viewModel = State(initialValue: viewModel)
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                // Deployment Health Banner
                statusBanner
                
                Spacer()
                
                // AI Response Area
                ScrollView {
                    Text(viewModel.responseText)
                        .font(.title3)
                        .multilineTextAlignment(.center)
                        .padding()
                }
                .frame(maxWidth: .infinity)
                .background(Color.secondary.opacity(0.1))
                .cornerRadius(12)
                
                Spacer()

                // Input Area
                HStack {
                    TextField("Type a prompt...", text: $promptInput)
                        .textFieldStyle(.roundedBorder)
                        .disabled(viewModel.isProcessing)

                    if viewModel.isProcessing {
                        ProgressView()
                    } else {
                        Button("Send") {
                            let currentPrompt = promptInput
                            promptInput = ""
                            Task {
                                await viewModel.handleUserPrompt(currentPrompt)
                            }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
            }
            .padding()
            .navigationTitle("AI Assistant")
        }
    }

    private var statusBanner: some View {
        Group {
            Text(viewModel.healthStatus)
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(statusColor)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(statusColor.opacity(0.2))
                .cornerRadius(20)
        }
    }

    private var statusColor: Color {
        switch viewModel.deploymentHealth {
        case .healthy: return .green
        case .degraded: return .orange
        case .critical: return .red
        }
    }
}

// MARK: - App Entry Point Simulation

@main
struct AIServiceApp {
    static func main() async {
        // 1. Initialize the Telemetry Service (The Monitor)
        let telemetry = TelemetryService()
        
        // 2. Initialize the AI Engine (The Worker)
        let aiManager = AIModelManager(telemetry: telemetry)
        
        // 3. Initialize the ViewModel (The Coordinator)
        let viewModel = VoiceAssistantViewModel(aiManager: aiManager, telemetry: telemetry)
        
        // In a real app, this would launch the SwiftUI App lifecycle.
        // For this example, we simulate user interaction.
        print("Starting AI App Simulation...")
        
        await viewModel.handleUserPrompt("Hello, how are you?")
        
        // Simulate several failures to trigger the "Critical" state
        print("Simulating failures to test monitoring...")
        for _ in 1...6 {
            await viewModel.handleUserPrompt("Trigger error")
            try? await Task.sleep(for: .seconds(0.5))
        }
        
        // Allow time for the health monitor loop to catch up
        try? await Task.sleep(for: .seconds(3))
        
        print("Final Health Status: \(viewModel.healthStatus)")
    }
}
