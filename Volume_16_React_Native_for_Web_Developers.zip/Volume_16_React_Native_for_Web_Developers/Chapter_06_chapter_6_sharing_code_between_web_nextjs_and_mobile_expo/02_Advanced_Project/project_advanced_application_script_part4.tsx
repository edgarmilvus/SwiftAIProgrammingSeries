/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.tsx
// Description: Advanced Application Script
// ==========================================

// packages/shared/components/AnalyticsDisplay.web.tsx

import React from 'react';
import { AnalyticsDataPoint } from '../types/analytics';

/**
 * @description Web-specific rendering of analytics data.
 * Uses standard HTML/JSX elements.
 * @param data - Array of analytics points.
 */
export const AnalyticsDisplay: React.FC<{ data: AnalyticsDataPoint[] }> = ({ data }) => {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '20px' }}>
      <h2>Real-Time Analytics (Web)</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ borderBottom: '2px solid #ccc' }}>
            <th style={{ textAlign: 'left', padding: '8px' }}>Metric</th>
            <th style={{ textAlign: 'right', padding: '8px' }}>Value</th>
            <th style={{ textAlign: 'right', padding: '8px' }}>Time</th>
          </tr>
        </thead>
        <tbody>
          {data.map((point) => (
            <tr key={point.id} style={{ borderBottom: '1px solid #eee' }}>
              <td style={{ padding: '8px' }}>{point.metric}</td>
              <td style={{ padding: '8px', textAlign: 'right' }}>{point.value}</td>
              <td style={{ padding: '8px', textAlign: 'right' }}>
                {point.timestamp.toLocaleTimeString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
