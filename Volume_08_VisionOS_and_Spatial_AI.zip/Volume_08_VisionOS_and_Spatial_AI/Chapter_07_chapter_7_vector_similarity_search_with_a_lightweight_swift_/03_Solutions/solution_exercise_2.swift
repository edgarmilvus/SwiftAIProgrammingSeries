
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

/// A representation of a piece of text and its semantic meaning.
struct Document: Identifiable, Codable, Sendable {
    let id: UUID
    let text: String
    let embedding: [Float]
}

/// An in-memory storage engine for vector-based retrieval.
final class VectorStore: Sendable {
    // Using an actor-like pattern or internal synchronization for thread safety
    // In a real app, this might be an 'actor' to protect the 'documents' array.
    private let documents: Box<[Document]>
    
    // Helper to allow 'let' storage of a mutable array in a Sendable class
    private final class Box<T> {
        var value: T
        init(_ value: T) { self.value = value }
    }

    init(documents: [Document] = []) {
        self.documents = Box(documents)
    }

    /// Adds a new document to the store.
    func add(_ document: Document) {
        // Note: In a real high-concurrency environment, use an Actor.
        // For this exercise, we simulate thread-safe updates.
        documents.value.append(document)
    }

    /// Clears all documents from the store.
    func clearAll() {
        documents.value.removeAll()
    }

    /// Searches for the top 'k' most similar documents.
    /// - Parameters:
    ///   - queryVector: The embedding of the search query.
    ///   - limit: The maximum number of results to return.
    /// - Returns: An array of documents sorted by similarity (descending).
    func search(queryVector: [Float], limit: Int) -> [Document] {
        // 1. Calculate similarity for every document (Brute Force / Linear Scan)
        let scoredDocuments = documents.value.compactMap { doc -> (Document, Float)? in
            // We ignore errors here for the sake of the search API, 
            // assuming the store maintains valid dimensions.
            guard let similarity = try? VectorMath.cosineSimilarity(between: queryVector, and: doc.embedding) else {
                return nil
            }
            return (doc, similarity)
        }
        
        // 2. Sort by similarity in descending order
        let sorted = scoredDocuments.sorted { $0.1 > $1.1 }
        
        // 3. Return the top 'k' documents
        return sorted.prefix(limit).map { $0.0 }
    }
}

// MARK: - Testing the VectorStore
let store = VectorStore()
let doc1 = Document(id: UUID(), text: "I love coding in Swift", embedding: [0.1, 0.9, 0.0])
let doc2 = Document(id: UUID(), text: "The weather is sunny", embedding: [0.8, 0.1, 0.1])
let doc3 = Document(id: UUID(), text: "Swift programming is fun", embedding: [0.15, 0.85, 0.05])

store.add(doc1)
store.add(doc2)
store.add(doc3)

let query: [Float] = [0.12, 0.88, 0.02] // Similar to doc1 and doc3
let results = store.search(queryVector: query, limit: 2)

print("Top Search Results:")
results.forEach { print("- \($0.text)") }
