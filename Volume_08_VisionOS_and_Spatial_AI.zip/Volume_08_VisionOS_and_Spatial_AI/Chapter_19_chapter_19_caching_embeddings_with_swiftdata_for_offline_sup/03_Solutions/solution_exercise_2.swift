
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import SwiftData

enum EmbeddingError: Error {
    case networkFailure
    case encodingError
}

actor EmbeddingService {
    private let container: ModelContainer
    private let modelID = "text-embedding-3-small"

    init(container: ModelContainer) {
        self.container = container
    }

    func getEmbedding(for text: String, sourceID: String) async throws -> [Float] {
        // 1. Normalization
        let normalizedText = text.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // 2. Local Lookup
        let vector = try await performLocalLookup(for: normalizedText, sourceID: sourceID)
        
        if let cachedVector = vector {
            return cachedVector
        }

        // 3. Cache Miss: Call API (Mocked for this exercise)
        let newVector = try await fetchFromOpenAI(text: normalizedText)

        // 4. Persistence
        try await saveToCache(
            text: normalizedText,
            vector: newVector,
            sourceID: sourceID
        )

        return newVector
    }

    @MainActor
    private func performLocalLookup(for text: String, sourceID: String) throws -> [Float]? {
        let context = ModelContext(container)
        let predicate = #Predicate<TextChunk> {
            $0.content == text && 
            $0.sourceID == sourceID && 
            $0.modelIdentifier == modelID
        }
        
        var descriptor = FetchDescriptor<TextChunk>(predicate: predicate)
        descriptor.fetchLimit = 1
        
        let results = try context.fetch(descriptor)
        if let match = results.first {
            match.lastAccessed = .now // Update LRU metadata
            return match.embedding
        }
        return nil
    }

    @MainActor
    private func saveToCache(text: String, vector: [Float], sourceID: String) throws {
        let context = ModelContext(container)
        let newChunk = TextChunk(
            content: text,
            embedding: vector,
            sourceID: sourceID,
            modelIdentifier: modelID
        )
        context.insert(newChunk)
        try context.save()
    }

    // Mock API Call
    private func fetchFromOpenAI(text: String) async throws -> [Float] {
        try await Task.sleep(for: .seconds(1)) // Simulate latency
        return (0..<1536).map { _ in Float.random(in: -1...1) }
    }
}
