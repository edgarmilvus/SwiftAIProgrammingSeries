
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// This solution focuses on macOS (AppKit) as the scenario implies a code editor,
// but the core Project and ProjectManager logic is largely platform-agnostic.

import Foundation
import UniformTypeIdentifiers
import AppKit // For NSOpenPanel and AppKit UI

// MARK: - Project Model

struct Project: Identifiable, Codable {
    let id: UUID
    var name: String
    var bookmarkData: Data // Stored bookmark data
    var resolvedURL: URL? // Transient: resolved URL, not persisted directly
    var isValid: Bool // Transient: indicates if bookmark currently resolves and grants access

    // Custom initializer for new projects
    init(url: URL, bookmarkData: Data) {
        self.id = UUID()
        self.name = url.lastPathComponent
        self.bookmarkData = bookmarkData
        self.resolvedURL = url // Initially resolved
        self.isValid = true // Initially valid
    }

    // Codable conformance (only for persisted properties)
    private enum CodingKeys: String, CodingKey {
        case id, name, bookmarkData
    }
}

// MARK: - Project Manager

class ProjectManager: ObservableObject { // ObservableObject for SwiftUI/Combine integration
    @Published private(set) var projects: [Project] = []
    private let userDefaultsKey = "savedProjectsBookmarks"

    init() {
        loadProjects()
    }

    // MARK: - Lifecycle & Persistence

    private func loadProjects() {
        guard let encodedProjects = UserDefaults.standard.data(forKey: userDefaultsKey) else {
            print("No saved projects found.")
            return
        }

        do {
            let bookmarkDatas = try JSONDecoder().decode([Data].self, from: encodedProjects)
            // Process projects asynchronously to avoid blocking UI on launch
            Task {
                var loadedProjects: [Project] = []
                for bookmarkData in bookmarkDatas {
                    var project = Project(id: UUID(), name: "Unknown Project", bookmarkData: bookmarkData)
                    await self.resolveAndAccessProject(&project)
                    loadedProjects.append(project)
                }
                await MainActor.run {
                    self.projects = loadedProjects
                    print("Loaded \(self.projects.count) projects.")
                }
            }
        } catch {
            print("Error decoding saved projects: \(error.localizedDescription)")
            UserDefaults.standard.removeObject(forKey: userDefaultsKey) // Clear corrupted data
        }
    }

    private func saveProjects() {
        Task {
            // Only save the bookmarkData, not transient properties
            let bookmarkDatas = projects.map { $0.bookmarkData }
            do {
                let encodedProjects = try JSONEncoder().encode(bookmarkDatas)
                UserDefaults.standard.set(encodedProjects, forKey: userDefaultsKey)
                print("Projects saved.")
            } catch {
                print("Error encoding projects for saving: \(error.localizedDescription)")
            }
        }
    }

    // Call this when the app is about to terminate
    func stopAccessingAllProjects() {
        for project in projects {
            project.resolvedURL?.stopAccessingSecurityScopedResource()
        }
        print("Stopped accessing all project resources.")
    }

    // MARK: - Project Management Operations

    func addProject() async {
        let openPanel = NSOpenPanel()
        openPanel.canChooseFiles = false
        openPanel.canChooseDirectories = true
        openPanel.allowsMultipleSelection = false
        openPanel.prompt = "Select Project Folder"

        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            openPanel.begin { [weak self] response in
                guard response == .OK, let url = openPanel.url else {
                    print("Open panel cancelled or no URL selected.")
                    continuation.resume()
                    return
                }

                // Initial access to create bookmark
                guard url.startAccessingSecurityScopedResource() else {
                    print("Failed to start accessing selected folder for bookmark creation.")
                    DispatchQueue.main.async { // Ensure UI update on main thread
                        // In a real app, show an alert to the user
                        print("Error: Could not gain initial access to selected folder.")
                    }
                    continuation.resume()
                    return
                }
                defer { url.stopAccessingSecurityScopedResource() } // Release initial access

                do {
                    let bookmarkData = try url.bookmarkData(options: .withSecurityScopedResource,
                                                            includingResourceValuesForKeys: nil,
                                                            relativeTo: nil)
                    var newProject = Project(url: url, bookmarkData: bookmarkData)
                    // Resolve and access immediately to set initial status
                    await self?.resolveAndAccessProject(&newProject)

                    await MainActor.run {
                        self?.projects.append(newProject)
                        self?.saveProjects()
                    }
                } catch {
                    print("Error creating bookmark for selected folder: \(error.localizedDescription)")
                    DispatchQueue.main.async {
                        // In a real app, show an alert to the user
                        print("Error: Failed to create bookmark.")
                    }
                }
                continuation.resume()
            }
        }
    }

    func removeProject(id: UUID) {
        guard let index = projects.firstIndex(where: { $0.id == id }) else { return }

        let projectToRemove = projects[index]
        projectToRemove.resolvedURL?.stopAccessingSecurityScopedResource() // Stop access

        projects.remove(at: index)
        saveProjects()
        print("Project '\(projectToRemove.name)' removed.")
    }

    func refreshProjectStatus(id: UUID) async {
        guard let index = projects.firstIndex(where: { $0.id == id }) else { return }

        var projectToRefresh = projects[index]
        await resolveAndAccessProject(&projectToRefresh) // Re-resolve and re-access

        await MainActor.run {
            self.projects[index] = projectToRefresh
            // If bookmarkData changed (due to stale refresh), save projects
            if self.projects[index].bookmarkData != projectToRefresh.bookmarkData {
                self.saveProjects()
            }
        }
        print("Project '\(projectToRefresh.name)' status refreshed.")
    }

    // MARK: - Core Resolution & Access Logic

    private func resolveAndAccessProject(_ project: inout Project) async {
        project.resolvedURL?.stopAccessingSecurityScopedResource() // Stop any previous access for this project
        project.resolvedURL = nil
        project.isValid = false

        var isStale = false
        do {
            let resolvedURL = try URL(resolvingBookmarkData: project.bookmarkData,
                                      options: .withSecurityScopedResource,
                                      relativeTo: nil,
                                      bookmarkDataIsStale: &isStale)

            if isStale {
                print("Project '\(project.name)' bookmark is stale. Attempting to refresh...")
                do {
                    let newBookmarkData = try resolvedURL.bookmarkData(options: .withSecurityScopedResource,
                                                                       includingResourceValuesForKeys: nil,
                                                                       relativeTo: nil)
                    project.bookmarkData = newBookmarkData
                    print("Project '\(project.name)' bookmark refreshed.")
                } catch {
                    print("Failed to refresh bookmark for '\(project.name)': \(error.localizedDescription)")
                    // If refresh fails, the original bookmark is likely invalid.
                    // Keep isValid=false, but we still have the resolvedURL to try accessing.
                }
            }

            // Attempt to gain access to the resource
            if resolvedURL.startAccessingSecurityScopedResource() {
                project.resolvedURL = resolvedURL
                project.isValid = true
                print("Project '\(project.name)' successfully resolved and accessed.")
            } else {
                print("Failed to start accessing security-scoped resource for '\(project.name)'.")
                // Access denied even after resolving
            }
        } catch {
            print("Error resolving bookmark for '\(project.name)': \(error.localizedDescription)")
            // Bookmark resolution failed entirely
        }
    }
}

// MARK: - UI Implementation (macOS AppKit)

class ProjectsViewController: NSViewController, NSTableViewDataSource, NSTableViewDelegate {

    let projectManager = ProjectManager() // Instantiate ProjectManager
    var projectListObserver: AnyCancellable? // For Combine observation

    let addProjectButton = NSButton(title: "Add Project...", target: nil, action: nil)
    let removeProjectButton = NSButton(title: "Remove Selected", target: nil, action: nil)
    let refreshProjectButton = NSButton(title: "Refresh Selected", target: nil, action: nil)

    let tableView = NSTableView()
    let tableScrollView = NSScrollView()

    override func loadView() {
        self.view = NSView()
        self.view.wantsLayer = true
        self.view.layer?.backgroundColor = NSColor.windowBackgroundColor.cgColor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupProjectObservation()
    }

    override func viewWillDisappear() {
        super.viewWillDisappear()
        projectManager.stopAccessingAllProjects()
    }

    func setupUI() {
        addProjectButton.target = self
        addProjectButton.action = #selector(addProjectTapped)
        addProjectButton.translatesAutoresizingMaskIntoConstraints = false

        removeProjectButton.target = self
        removeProjectButton.action = #selector(removeProjectTapped)
        removeProjectButton.translatesAutoresizingMaskIntoConstraints = false
        removeProjectButton.isEnabled = false // Disable initially

        refreshProjectButton.target = self
        refreshProjectButton.action = #selector(refreshProjectTapped)
        refreshProjectButton.translatesAutoresizingMaskIntoConstraints = false
        refreshProjectButton.isEnabled = false // Disable initially

        let buttonStack = NSStackView(views: [addProjectButton, removeProjectButton, refreshProjectButton])
        buttonStack.orientation = .horizontal
        buttonStack.spacing = 8
        buttonStack.distribution = .fillProportionally
        buttonStack.translatesAutoresizingMaskIntoConstraints = false

        tableScrollView.documentView = tableView
        tableScrollView.hasVerticalScroller = true
        tableScrollView.translatesAutoresizingMaskIntoConstraints = false

        let nameColumn = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("ProjectName"))
        nameColumn.title = "Project Name"
        nameColumn.width = 200
        tableView.addTableColumn(nameColumn)

        let statusColumn = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("ProjectStatus"))
        statusColumn.title = "Status"
        statusColumn.width = 100
        tableView.addTableColumn(statusColumn)

        tableView.dataSource = self
        tableView.delegate = self
        tableView.columnAutoresizingStyle = .uniformColumnAutoresizingStyle
        tableView.usesAlternatingRowBackgroundColors = true
        tableView.target = self
        tableView.action = #selector(tableViewSelectionDidChange)

        let mainStack = NSStackView(views: [buttonStack, tableScrollView])
        mainStack.orientation = .vertical
        mainStack.spacing = 10
        mainStack.distribution = .fill
        mainStack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mainStack)

        NSLayoutConstraint.activate([
            mainStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            mainStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            mainStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            mainStack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20),
            tableScrollView.heightAnchor.constraint(greaterThanOrEqualToConstant: 150)
        ])
    }

    func setupProjectObservation() {
        // Use Combine to react to changes in the projectManager.projects array
        projectListObserver = projectManager.$projects
            .receive(on: DispatchQueue.main) // Ensure updates on main thread
            .sink { [weak self] _ in
                self?.tableView.reloadData()
                self?.updateButtonStates()
            }
    }

    @objc func addProjectTapped() {
        Task { await projectManager.addProject() }
    }

    @objc func removeProjectTapped() {
        let selectedRow = tableView.selectedRow
        guard selectedRow >= 0 && selectedRow < projectManager.projects.count else { return }
        let projectId = projectManager.projects[selectedRow].id
        projectManager.removeProject(id: projectId)
    }

    @objc func refreshProjectTapped() {
        let selectedRow = tableView.selectedRow
        guard selectedRow >= 0 && selectedRow < projectManager.projects.count else { return }
        let projectId = projectManager.projects[selectedRow].id
        Task { await projectManager.refreshProjectStatus(id: projectId) }
    }

    @objc func tableViewSelectionDidChange() {
        updateButtonStates()
    }

    func updateButtonStates() {
        let hasSelection = tableView.selectedRow >= 0
        removeProjectButton.isEnabled = hasSelection
        refreshProjectButton.isEnabled = hasSelection
    }

    // MARK: - NSTableViewDataSource

    func numberOfRows(in tableView: NSTableView) -> Int {
        return projectManager.projects.count
    }

    // MARK: - NSTableViewDelegate

    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        let project = projectManager.projects[row]
        let identifier = tableColumn?.identifier ?? NSUserInterfaceItemIdentifier("")

        if identifier == NSUserInterfaceItemIdentifier("ProjectName") {
            let cell = tableView.makeView(withIdentifier: identifier, owner: self) as? NSTableCellView ?? {
                let newCell = NSTableCellView()
                newCell.identifier = identifier
                newCell.textField = NSTextField(frame: .zero)
                newCell.textField?.isEditable = false
                newCell.textField?.isBordered = false
                newCell.textField?.backgroundColor = .clear
                newCell.addSubview(newCell.textField!)
                newCell.textField?.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    newCell.textField!.leadingAnchor.constraint(equalTo: newCell.leadingAnchor, constant: 4),
                    newCell.textField!.trailingAnchor.constraint(equalTo: newCell.trailingAnchor, constant: -4),
                    newCell.textField!.centerYAnchor.constraint(equalTo: newCell.centerYAnchor)
                ])
                return newCell
            }()
            cell.textField?.stringValue = project.name
            return cell
        } else if identifier == NSUserInterfaceItemIdentifier("ProjectStatus") {
            let cell = tableView.makeView(withIdentifier: identifier, owner: self) as? NSTableCellView ?? {
                let newCell = NSTableCellView()
                newCell.identifier = identifier
                newCell.textField = NSTextField(frame: .zero)
                newCell.textField?.isEditable = false
                newCell.textField?.isBordered = false
                newCell.textField?.backgroundColor = .clear
                newCell.addSubview(newCell.textField!)
                newCell.textField?.translatesAutoresizingMaskIntoConstraints = false
                NSLayoutConstraint.activate([
                    newCell.textField!.leadingAnchor.constraint(equalTo: newCell.leadingAnchor, constant: 4),
                    newCell.textField!.trailingAnchor.constraint(equalTo: newCell.trailingAnchor, constant: -4),
                    newCell.textField!.centerYAnchor.constraint(equalTo: newCell.centerYAnchor)
                ])
                return newCell
            }()
            cell.textField?.stringValue = project.isValid ? "Valid" : "Invalid"
            cell.textField?.textColor = project.isValid ? .controlTextColor : .red
            return cell
        }
        return nil
    }
}

// Example AppDelegate for macOS to set up the window and initial view controller
@main
class AppDelegate: NSObject, NSApplicationDelegate {

    var window: NSWindow!
    var projectsVC: ProjectsViewController!

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 700, height: 500),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.center()
        window.setFrameAutosaveName("ProjectManagerWindow")
        
        projectsVC = ProjectsViewController()
        window.contentViewController = projectsVC
        
        window.makeKeyAndOrderFront(nil)
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        projectsVC.projectManager.stopAccessingAllProjects()
    }

    func applicationSupportsSecureRestorableState(_ app: NSApplication) -> Bool {
        return true
    }
}
