
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
protocol AITokenStreamer {
    func streamTokens(prompt: String) async throws -> AsyncThrowingStream<String, Error>
}

@available(iOS 18.0, *)
class MyAIModel: AITokenStreamer {
    func streamTokens(prompt: String) async throws -> AsyncThrowingStream<String, Error> {
        // Simulate an asynchronous token stream
        AsyncThrowingStream { continuation in
            Task {
                let words = "The quick brown fox jumps over the lazy dog.".components(separatedBy: " ")
                for (index, word) in words.enumerated() {
                    try await Task.sleep(for: .milliseconds(100)) // Simulate network/inference delay
                    continuation.yield(word + (index < words.count - 1 ? " " : ""))
                }
                continuation.finish()
            }
        }
    }
}
