/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';

// Define props for the component
interface PlatformCardProps {
  variant?: 'elevated' | 'flat';
}

const PlatformCard: React.FC<PlatformCardProps> = ({ variant = 'elevated' }) => {
  
  // 1. Base Styles
  const baseStyles = {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
    margin: 20,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 150,
  };

  // 2. Platform-Specific Logic
  // We define styles for iOS shadow, Android elevation, and Flat border
  const platformStyles = StyleSheet.create({
    iosShadow: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
    },
    androidShadow: {
      elevation: 5,
    },
    flatBorder: {
      borderWidth: 1,
      borderColor: '#ddd',
      shadowColor: 'transparent', // Remove shadow if flat
      elevation: 0, // Remove elevation if flat
    },
  });

  // 3. Dynamic Style Assembly
  const cardStyle = [
    baseStyles,
    // Apply platform shadow only if variant is 'elevated'
    variant === 'elevated' 
      ? (Platform.OS === 'ios' ? platformStyles.iosShadow : platformStyles.androidShadow)
      : platformStyles.flatBorder,
  ];

  const displayText = Platform.OS === 'ios' 
    ? 'This is an iOS Card' 
    : 'This is an Android Card';

  return (
    <View style={cardStyle}>
      <Text style={{ fontSize: 18, fontWeight: '600' }}>{displayText}</Text>
      <Text style={{ marginTop: 8, color: '#666', fontSize: 12 }}>
        Variant: {variant.toUpperCase()}
      </Text>
    </View>
  );
};

export default PlatformCard;
