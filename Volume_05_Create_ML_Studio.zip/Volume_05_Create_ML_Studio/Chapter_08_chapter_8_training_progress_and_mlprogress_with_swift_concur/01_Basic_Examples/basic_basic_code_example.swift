
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Foundation
import CoreML // Essential for MLProgress and related types

/// A simple struct to represent training data.
/// In a real app, this would be more complex, perhaps
/// an `MLImageClassifier.DataSource` or similar, loaded from files or memory.
struct TrainingData {
    let name: String
    let numberOfSamples: Int
}

/// A simulated service that performs model training and reports progress.
/// This class mimics the behavior of `MLModel.train` which, in its async variant,
/// returns an `MLProgress` instance for real-time progress updates.
@available(iOS 18.0, macOS 15.0, *) // MLProgress is available on newer SDKs
class TrainingService {

    /// Simulates the training of a machine learning model.
    ///
    /// This asynchronous function performs a series of simulated training steps,
    /// reporting its progress through the returned `MLProgress` instance.
    /// The actual "training" work is performed in a detached task, allowing
    /// the `MLProgress` instance to be returned immediately for observation.
    ///
    /// - Parameters:
    ///   - data: The `TrainingData` to be used for training.
    ///   - epochs: The number of training epochs to simulate.
    /// - Returns: An `MLProgress` instance that emits `MLProgress.Update` values
    ///            as the training progresses.
    func trainModel(data: TrainingData, epochs: Int) -> MLProgress {
        // 1. Create an AsyncStream to feed progress updates.
        //    This stream will be the underlying source for the MLProgress AsyncSequence.
        //    The `continuation` is used to imperatively send values into the stream.
        let (stream, continuation) = AsyncStream.makeStream(of: MLProgress.Update.self)

        // 2. Initialize MLProgress with the created AsyncStream.
        //    The `MLProgress` instance is an `AsyncSequence` that wraps our `AsyncStream`.
        //    It is returned immediately, allowing the caller to start observing progress
        //    while the actual training task runs concurrently in the background.
        let progress = MLProgress(updates: stream)

        // 3. Launch a detached Task to perform the simulated training work.
        //    `Task.detached` is used here because the lifecycle of the training task
        //    is independent of the caller's scope (i.e., `trainModel` returns quickly).
        Task.detached {
            print("[\(Date())] Training task started for \(data.name) with \(epochs) epochs.")

            do {
                // Simulate an initial setup phase before training begins.
                continuation.yield(.progress(0.0, description: "Initializing training..."))
                try await Task.sleep(for: .seconds(0.5)) // Simulate initial load time

                // Loop through each simulated epoch.
                for epoch in 1...epochs {
                    // Calculate overall progress based on completed epochs.
                    let progressValue = Double(epoch) / Double(epochs)
                    let description = "Epoch \(epoch)/\(epochs) completed."

                    // Report epoch completion and overall progress.
                    // `MLProgress.Update.epoch` typically includes metrics for that epoch.
                    continuation.yield(.epoch(epoch, metrics: ["loss": Double.random(in: 0.1...0.5), "accuracy": Double.random(in: 0.8...0.95)]))
                    // `MLProgress.Update.progress` provides a general progress percentage.
                    continuation.yield(.progress(progressValue, description: description))

                    print("[\(Date())] \(description)")

                    // Simulate some computation time for the current epoch.
                    try await Task.sleep(for: .seconds(Double.random(in: 0.5...1.5)))

                    // Simulate a validation step occasionally, reporting specific metrics.
                    if epoch % 2 == 0 && epoch < epochs {
                        continuation.yield(.validationMetrics(epoch, metrics: ["val_loss": Double.random(in: 0.15...0.6), "val_accuracy": Double.random(in: 0.75...0.9)]))
                        print("[\(Date())] Validation metrics reported for epoch \(epoch).")
                        try await Task.sleep(for: .seconds(0.3)) // Short pause for validation
                    }

                    // Simulate a model checkpoint save (e.g., every 3 epochs).
                    if epoch % 3 == 0 && epoch < epochs {
                        let checkpointURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("model_checkpoint_epoch_\(epoch).mlmodel")
                        continuation.yield(.checkpoint(checkpointURL))
                        print("[\(Date())] Checkpoint saved at \(checkpointURL.lastPathComponent).")
                        try await Task.sleep(for: .seconds(0.2)) // Short pause for saving
                    }
                }

                // Simulate finalization steps.
                continuation.yield(.progress(1.0, description: "Training complete!"))
                // Report the final state of the training.
                continuation.yield(.state(.completed))
                print("[\(Date())] Training task finished successfully.")
                // Signal that the stream has ended, releasing resources.
                continuation.finish()

            } catch {
                // Handle cancellation or other errors that might occur during the task.
                if Task.isCancelled {
                    print("[\(Date())] Training task cancelled.")
                    // Report a failed state if the task was cancelled.
                    continuation.yield(.state(.failed(error: CancellationError())))
                } else {
                    print("[\(Date())] Training task failed with error: \(error.localizedDescription)")
                    // Report a failed state with the actual error.
                    continuation.yield(.state(.failed(error: error)))
                }
                // Ensure the stream finishes even if an error occurs, to prevent hanging observers.
                continuation.finish()
            }
        }
        return progress
    }
}

/// A ViewModel to manage the state and logic for the training UI.
/// Uses Swift 6's new `@Observable` macro for reactive updates, automatically
/// notifying SwiftUI views when its properties change.
@available(iOS 18.0, macOS 15.0, *)
@Observable
final class TrainingViewModel {
    private let trainingService = TrainingService() // Instance of our simulated training service

    // UI-bound properties, automatically observed by SwiftUI due to @Observable.
    var trainingProgress: Double = 0.0
    var trainingDescription: String = "Idle"
    var isTraining: Bool = false
    var lastEpochMetrics: [String: Any]?
    var trainingError: Error?
    
    // Holds a reference to the Task observing MLProgress, allowing for cancellation.
    private var observationTask: Task<Void, Never>?

    /// Starts the simulated model training process.
    ///
    /// This method initiates training via `TrainingService` and then
    /// sets up an asynchronous task to observe the `MLProgress` updates.
    /// UI state variables are updated on the main actor as progress is received.
    func startTraining() {
        guard !isTraining else { return } // Prevent starting multiple training sessions concurrently

        // Reset UI state for a new training session.
        isTraining = true
        trainingProgress = 0.0
        trainingDescription = "Starting training..."
        lastEpochMetrics = nil
        trainingError = nil

        // Define parameters for the simulated training.
        let trainingData = TrainingData(name: "Cat vs Dog Classifier", numberOfSamples: 1000)
        let epochs = 5

        // Kick off the training process which returns an MLProgress instance.
        let progressSequence = trainingService.trainModel(data: trainingData, epochs: epochs)

        // Create a Task to observe the MLProgress sequence.
        // `@MainActor` is crucial here: it ensures all updates to `@Observable`
        // properties (which affect the UI) are performed on the main thread,
        // preventing UI glitches or crashes.
        observationTask = Task { @MainActor [weak self] in
            guard let self else { return } // Guard against self being deallocated

            do {
                // Iterate over the MLProgress sequence to receive updates.
                // The `for try await` loop will suspend until the next update is available
                // or the sequence finishes/throws an error.
                for try await update in progressSequence {
                    switch update {
                    case .progress(let value, let description):
                        self.trainingProgress = value
                        self.trainingDescription = description ?? "Training in progress..."
                        print("UI Update: Progress \(Int(value * 100))%, \(self.trainingDescription)")
                    case .epoch(let epoch, let metrics):
                        self.trainingDescription = "Epoch \(epoch) completed."
                        self.lastEpochMetrics = metrics
                        print("UI Update: Epoch \(epoch) Metrics: \(metrics ?? [:])")
                    case .validationMetrics(let epoch, let metrics):
                        print("UI Update: Validation for Epoch \(epoch) Metrics: \(metrics ?? [:])")
                    case .checkpoint(let url):
                        print("UI Update: Checkpoint saved at \(url.lastPathComponent)")
                    case .state(let state):
                        // Handle different training states.
                        switch state {
                        case .running:
                            self.trainingDescription = "Training is running."
                        case .paused:
                            self.trainingDescription = "Training is paused."
                        case .completed:
                            self.trainingDescription = "Training completed successfully!"
                            self.isTraining = false // Training has finished
                            self.trainingProgress = 1.0 // Ensure 100% on completion
                            print("UI Update: Training completed.")
                        case .failed(let error):
                            self.trainingDescription = "Training failed: \(error.localizedDescription)"
                            self.trainingError = error
                            self.isTraining = false // Training has failed
                            print("UI Update: Training failed with error: \(error.localizedDescription)")
                        @unknown default:
                            self.trainingDescription = "Unknown training state."
                        }
                    @unknown default:
                        // Handle any future, unknown MLProgress.Update cases gracefully.
                        print("UI Update: Received unknown MLProgress update.")
                    }
                }
            } catch {
                // Catch errors thrown by the `AsyncSequence` itself (e.g., if the
                // underlying training task failed unexpectedly or was cancelled).
                self.trainingDescription = "Error observing progress: \(error.localizedDescription)"
                self.trainingError = error
                self.isTraining = false
                print("UI Update: Error observing progress: \(error.localizedDescription)")
            }
            // If the observation loop finishes (either by completion or error)
            // and `isTraining` is still true, it means the sequence finished
            // unexpectedly without reporting a `.completed` or `.failed` state.
            if self.isTraining {
                 self.isTraining = false
                 self.trainingDescription = "Training observation ended unexpectedly."
            }
            self.observationTask = nil // Clear the task reference once done.
        }
    }

    /// Cancels the ongoing training task.
    /// This will cooperatively cancel the `observationTask`, which in turn
    /// can lead to the `TrainingService`'s detached task being cancelled
    /// if it checks `Task.isCancelled`.
    func cancelTraining() {
        observationTask?.cancel()
        observationTask = nil // Clear the task reference
        isTraining = false
        trainingDescription = "Training cancelled."
        print("Training cancelled by user.")
    }
}

/// The main SwiftUI view for demonstrating training progress in a real-world app context.
/// This could be part of an app that allows users to fine-tune a custom image classifier.
@available(iOS 18.0, macOS 15.0, *)
struct ContentView: View {
    // `@State` is used to create and own the `TrainingViewModel` instance.
    // SwiftUI automatically observes `@Observable` objects stored in `@State`.
    @State private var viewModel = TrainingViewModel()

    var body: some View {
        VStack(spacing: 20) {
            Text("Custom Model Training")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundStyle(.primary)

            // ProgressView to show the current training progress.
            ProgressView(value: viewModel.trainingProgress) {
                Text(viewModel.trainingDescription)
                    .font(.headline)
                    .foregroundStyle(.secondary)
            }
            .progressViewStyle(.linear)
            .padding()
            .background(.ultraThinMaterial)
            .cornerRadius(12)
            .shadow(radius: 5)

            // Display last epoch metrics if available.
            if let metrics = viewModel.lastEpochMetrics {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Last Epoch Metrics:")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    ForEach(metrics.sorted(by: { $0.key < $1.key }), id: \.key) { key, value in
                        Text("\(key): \(String(describing: value))")
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                }
                .padding()
                .background(Color.blue.opacity(0.1))
                .cornerRadius(8)
            }

            // Display any training errors.
            if let error = viewModel.trainingError {
                Text("Error: \(error.localizedDescription)")
                    .foregroundColor(.white)
                    .font(.callout)
                    .padding()
                    .background(Color.red)
                    .cornerRadius(8)
            }

            HStack(spacing: 15) {
                // Button to start training, disabled if training is already in progress.
                Button(action: viewModel.startTraining) {
                    Label("Start Training", systemImage: "play.fill")
                        .font(.title3)
                        .padding(.vertical, 8)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                .disabled(viewModel.isTraining)

                // Button to cancel training, disabled if no training is active.
                Button(action: viewModel.cancelTraining) {
                    Label("Cancel Training", systemImage: "stop.fill")
                        .font(.title3)
                        .padding(.vertical, 8)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .tint(.red)
                .disabled(!viewModel.isTraining)
            }
            .padding(.top)
        }
        .padding(30)
        .frame(minWidth: 500, minHeight: 450) // For macOS window sizing and better presentation
        .background(.background)
        .preferredColorScheme(.dark) // Example: enforce dark mode
    }
}

// MARK: - App Entry Point (for a complete runnable example)
@available(iOS 18.0, macOS 15.0, *)
@main
struct TrainingProgressApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
