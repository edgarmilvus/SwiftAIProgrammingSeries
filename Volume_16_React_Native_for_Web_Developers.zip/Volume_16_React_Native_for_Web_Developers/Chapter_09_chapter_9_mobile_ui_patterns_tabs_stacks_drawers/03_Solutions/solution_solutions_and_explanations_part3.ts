/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// App.tsx
import React, { useState, useContext, createContext } from 'react';
import { View, Text, TouchableOpacity, Switch, Alert } from 'react-native';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createDrawerNavigator, DrawerContentComponentProps, DrawerItemList } from '@react-navigation/drawer';
import { MaterialIcons } from '@expo/vector-icons';
import { cn } from 'nativewind';

// --- Context for Theme ---
type ThemeContextType = {
  isDark: boolean;
  toggleTheme: () => void;
};

const ThemeContext = createContext<ThemeContextType>({
  isDark: true,
  toggleTheme: () => {},
});

// --- Components ---

// 1. Custom Drawer Content
const CustomDrawerContent = (props: DrawerContentComponentProps) => {
  const { isDark, toggleTheme } = useContext(ThemeContext);
  const navigation = useNavigation<any>();

  const handleLogout = () => {
    // Simulate clearing auth state and resetting stack
    Alert.alert("Logged Out", "You have been logged out successfully.", [
      { text: "OK", onPress: () => navigation.reset({ index: 0, routes: [{ name: 'LoginScreen' }] }) }
    ]);
  };

  return (
    <View className={cn("flex-1", isDark ? "bg-slate-800" : "bg-white")}>
      {/* Custom Header */}
      <View className="p-6 pt-12 bg-slate-900 mb-4">
        <Text className="text-white text-2xl font-bold">User Profile</Text>
        <Text className="text-slate-400">alex@example.com</Text>
      </View>

      {/* Standard Drawer Items */}
      <View className="flex-1">
        <DrawerItemList {...props} />
      </View>

      {/* Footer with Theme Toggle & Logout */}
      <View className="p-4 border-t border-slate-700 bg-slate-900">
        <View className="flex-row items-center justify-between mb-4">
          <Text className={cn("font-semibold", isDark ? "text-white" : "text-black")}>
            Dark Mode
          </Text>
          <Switch value={isDark} onValueChange={toggleTheme} trackColor={{ false: '#374151', true: '#3b82f6' }} />
        </View>
        
        <TouchableOpacity 
          onPress={handleLogout}
          className="flex-row items-center p-2 rounded bg-red-900/50"
        >
          <MaterialIcons name="logout" size={24} color="#ef4444" />
          <Text className="text-red-500 font-bold ml-3">Log Out</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// 2. Dummy Screens
const HomeScreen = () => {
  const { isDark } = useContext(ThemeContext);
  return (
    <View className={cn("flex-1 items-center justify-center", isDark ? "bg-slate-900" : "bg-slate-100")}>
      <Text className={cn("text-2xl font-bold", isDark ? "text-white" : "text-black")}>Home Screen</Text>
      <Text className="text-slate-500 mt-2">Swipe right to open drawer</Text>
    </View>
  );
};

const SettingsScreen = () => {
  const { isDark } = useContext(ThemeContext);
  return (
    <View className={cn("flex-1 items-center justify-center", isDark ? "bg-slate-900" : "bg-slate-100")}>
      <Text className={cn("text-2xl font-bold", isDark ? "text-white" : "text-black")}>Settings</Text>
    </View>
  );
};

const LoginScreen = () => {
  const navigation = useNavigation<any>();
  return (
    <View className="flex-1 items-center justify-center bg-slate-900">
      <Text className="text-white text-2xl font-bold mb-8">Login Screen</Text>
      <TouchableOpacity 
        onPress={() => navigation.navigate('MainApp')}
        className="bg-blue-600 px-6 py-3 rounded-lg"
      >
        <Text className="text-white font-bold">Login (Simulated)</Text>
      </TouchableOpacity>
    </View>
  );
};

// --- Navigators ---
const Drawer = createDrawerNavigator();

// Wrapper to provide Theme Context to Navigation
export default function App() {
  const [isDark, setIsDark] = useState(true);

  const toggleTheme = () => setIsDark(prev => !prev);

  return (
    <ThemeContext.Provider value={{ isDark, toggleTheme }}>
      <NavigationContainer>
        <Drawer.Navigator
          initialRouteName="LoginScreen"
          // Use screenOptions to apply theme dynamically to headers
          screenOptions={{
            headerTintColor: isDark ? '#fff' : '#000',
            headerStyle: { backgroundColor: isDark ? '#0f172a' : '#fff' },
            drawerStyle: {
              backgroundColor: isDark ? '#1e293b' : '#fff', // bg-slate-800 / white
            },
            drawerActiveTintColor: '#3b82f6',
            drawerInactiveTintColor: isDark ? '#94a3b8' : '#475569',
          }}
          drawerContent={props => <CustomDrawerContent {...props} />}
        >
          {/* We wrap the Main App flow in a Group or separate navigator if needed, 
              but here we simply add screens. 
              LoginScreen is separate to simulate Auth flow. */}
          
          <Drawer.Screen 
            name="LoginScreen" 
            component={LoginScreen} 
            options={{ drawerItemStyle: { height: 0 }, drawerLabel: () => null }} 
          />

          <Drawer.Screen 
            name="MainApp" 
            component={HomeScreen} 
            options={{ 
              title: 'Dashboard',
              drawerIcon: ({ color }) => <MaterialIcons name="home" color={color} size={24} />
            }} 
          />
          
          <Drawer.Screen 
            name="Settings" 
            component={SettingsScreen} 
            options={{ 
              drawerIcon: ({ color }) => <MaterialIcons name="settings" color={color} size={24} />
            }} 
          />
        </Drawer.Navigator>
      </NavigationContainer>
    </ThemeContext.Provider>
  );
}
