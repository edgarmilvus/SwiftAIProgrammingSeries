
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

@available(iOS 18.0, *)
struct SemanticResultRow: View {
    let title: String
    let similarityScore: Double // Range 0.0 to 1.0

    var body: some View {
        HStack(spacing: 16) {
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                
                // Confidence Meter
                GeometryReader { geometry in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.secondary.opacity(0.2))
                        
                        Capsule()
                            .fill(SemanticColor.color(for: similarityScore))
                            .frame(width: geometry.size.width * CGFloat(similarityScore))
                            // Smooth animation when the score changes
                            .animation(.spring(duration: 0.4), value: similarityScore)
                    }
                }
                .frame(height: 6)
            }
            
            Spacer()
            
            // Percentage Label
            Text("\(Int(similarityScore * 100))% match")
                .font(.caption2.monospacedDigit())
                .foregroundStyle(SemanticColor.color(for: similarityScore))
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(SemanticColor.color(for: similarityScore).opacity(0.1))
                .clipShape(Capsule())
        }
        .padding(.vertical, 4)
    }
}

@available(iOS 18.0, *)
enum SemanticColor {
    static func color(for score: Double) -> Color {
        switch score {
        case 0.9...1.0:
            return .green // Emerald Green
        case 0.7..<0.9:
            return .orange // Amber
        default:
            return .gray // Low Confidence
        }
    }
}

#Preview {
    List {
        SemanticResultRow(title: "Deep Learning Concepts", similarityScore: 0.95)
        SemanticResultRow(title: "SwiftUI Layouts", similarityScore: 0.75)
        SemanticResultRow(title: "Cooking Recipes", similarityScore: 0.40)
    }
}
