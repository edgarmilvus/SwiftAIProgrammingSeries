
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import CoreGraphics // For CGRect
import Foundation   // For UUID

// MARK: - Reusing Mock Data Structures & Helper from Exercise 1

// DetectionResult, CGRect.visionToSwiftUIRect, and BoundingBoxOverlay are reused.

// MARK: - Exercise 4 Solution View

struct Exercise4View: View {
    // Two distinct mock datasets
    let largeObjects: [DetectionResult] = [
        .init(boundingBox: CGRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4), label: "Vehicle", confidence: 0.95),
        .init(boundingBox: CGRect(x: 0.5, y: 0.6, width: 0.25, height: 0.3), label: "Tree", confidence: 0.88),
        .init(boundingBox: CGRect(x: 0.7, y: 0.1, width: 0.2, height: 0.25), label: "Building", confidence: 0.92)
    ]

    let environmentalIndicators: [DetectionResult] = [
        .init(boundingBox: CGRect(x: 0.15, y: 0.25, width: 0.1, height: 0.1), label: "Leaf Blight", confidence: 0.65), // Low confidence
        .init(boundingBox: CGRect(x: 0.55, y: 0.65, width: 0.08, height: 0.08), label: "Algae Bloom", confidence: 0.78),
        .init(boundingBox: CGRect(x: 0.75, y: 0.15, width: 0.05, height: 0.05), label: "Waste Particle", confidence: 0.55) // Low confidence
    ]

    // State for toggle switches
    @State private var showLargeObjects: Bool = true
    @State private var showEnvironmentalIndicators: Bool = true

    var body: some View {
        VStack {
            Text("Exercise 4: Multi-Layered Detections with Filtering")
                .font(.headline)
                .padding()

            GeometryReader { geometry in
                Image("sample_image") // <--- IMPORTANT: Add "sample_image.jpg" to your asset catalog
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .overlay(
                        ZStack {
                            // Layer 1: Large Objects (conditionally rendered)
                            if showLargeObjects {
                                ForEach(largeObjects) { detection in
                                    let swiftUIRect = CGRect.visionToSwiftUIRect(
                                        normalizedRect: detection.boundingBox,
                                        imageSize: geometry.size
                                    )
                                    BoundingBoxOverlay(
                                        id: detection.id,
                                        swiftUIRect: swiftUIRect,
                                        label: detection.label,
                                        confidence: detection.confidence,
                                        containerSize: geometry.size,
                                        strokeColor: .blue, // Distinct style for large objects
                                        displayConfidence: true,
                                        labelPlacementPreference: .auto
                                    )
                                }
                            }

                            // Layer 2: Environmental Indicators (conditionally rendered)
                            if showEnvironmentalIndicators {
                                ForEach(environmentalIndicators) { detection in
                                    let swiftUIRect = CGRect.visionToSwiftUIRect(
                                        normalizedRect: detection.boundingBox,
                                        imageSize: geometry.size
                                    )
                                    BoundingBoxOverlay(
                                        id: detection.id,
                                        swiftUIRect: swiftUIRect,
                                        label: detection.label,
                                        confidence: detection.confidence,
                                        containerSize: geometry.size,
                                        strokeColor: .red, // Distinct style for environmental indicators
                                        displayConfidence: true,
                                        labelPlacementPreference: .auto
                                    )
                                }
                            }
                        }
                    )
            }
            .padding()

            // Toggle switches for filtering
            Toggle("Show Large Objects", isOn: $showLargeObjects)
                .padding(.horizontal)
            Toggle("Show Environmental Indicators", isOn: $showEnvironmentalIndicators)
                .padding(.horizontal)
        }
    }
}

// Preview Provider
struct Exercise4View_Previews: PreviewProvider {
    static var previews: some View {
        Exercise4View()
    }
}
