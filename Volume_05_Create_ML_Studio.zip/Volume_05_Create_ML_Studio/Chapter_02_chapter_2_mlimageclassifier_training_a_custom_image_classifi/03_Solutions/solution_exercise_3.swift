
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import Vision
import CoreML
import PhotosUI // For modern image picking

// 1. Model Training (Conceptual - performed in Create ML)
//    - Assume 'ApplianceDamageClassifier.mlmodel' is trained and added to the Xcode project.
//    - It classifies images into categories like "Dent", "Scratch", "Crack", "No Damage".

struct ApplianceDamageAssessmentView: View {
    @State private var selectedImage: UIImage?
    @State private var topPredictions: [String] = [] // Store top N predictions
    @State private var showingImagePicker = false
    @State private var selectedPhotoItem: PhotosPickerItem?

    var body: some View {
        NavigationView {
            VStack {
                if let image = selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 300)
                        .padding()
                } else {
                    Image(systemName: "camera.metering.matrix")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                        .foregroundColor(.gray)
                        .padding()
                }

                Text("Damage Assessment:")
                    .font(.headline)
                    .padding(.top)

                if topPredictions.isEmpty {
                    Text("Select an image to assess damage.")
                        .foregroundColor(.secondary)
                } else {
                    ForEach(topPredictions, id: \.self) { prediction in
                        Text(prediction)
                            .font(.subheadline)
                            .padding(.horizontal)
                    }
                    .padding(.bottom)

                    // User feedback mechanism
                    HStack {
                        Button("Yes, Correct") {
                            print("User confirmed correct classification.")
                            // In a real app, send feedback to a backend
                        }
                        .buttonStyle(.bordered)
                        Button("No, Incorrect") {
                            print("User reported incorrect classification.")
                            // In a real app, prompt for correct label, send feedback
                        }
                        .buttonStyle(.bordered)
                    }
                    .padding(.vertical)
                }

                Spacer()

                Button("Select Image") {
                    if #available(iOS 16, *) {
                        selectedPhotoItem = nil
                    } else {
                        showingImagePicker = true
                    }
                }
                .buttonStyle(.borderedProminent)
                .padding()
            }
            .navigationTitle("Appliance Damage")
            .onChange(of: selectedPhotoItem) { newItem in
                Task {
                    if let data = try? await newItem?.loadTransferable(type: Data.self),
                       let uiImage = UIImage(data: data) {
                        selectedImage = uiImage
                        await classifyDamage(uiImage)
                    }
                }
            }
            .sheet(isPresented: $showingImagePicker) {
                ImagePicker(selectedImage: $selectedImage, isPresented: $showingImagePicker, sourceType: .photoLibrary)
            }
            .photosPicker(isPresented: .init(get: {
                #available(iOS 16, *)
                return !showingImagePicker && selectedPhotoItem == nil
            }, set: { newValue in
                if #available(iOS 16, *) {
                    if !newValue { selectedPhotoItem = nil }
                }
            }), selection: $selectedPhotoItem, matching: .images)
        }
    }

    // Function to perform Core ML inference and get top N predictions
    @MainActor
    private func classifyDamage(_ image: UIImage) async {
        topPredictions = ["Classifying..."]

        guard let ciImage = CIImage(image: image) else {
            topPredictions = ["Error: Could not convert image to CIImage."]
            return
        }

        do {
            let config = MLModelConfiguration()
            let model = try ApplianceDamageClassifier(configuration: config)
            let visionModel = try VNCoreMLModel(for: model.model)

            let request = VNCoreMLRequest(model: visionModel) { request, error in
                if let error = error {
                    self.topPredictions = ["Vision error: \(error.localizedDescription)"]
                    return
                }

                guard let observations = request.results as? [VNClassificationObservation] else {
                    self.topPredictions = ["No classification results."]
                    return
                }

                // Sort observations by confidence in descending order and take top N
                let sortedObservations = observations.sorted { $0.confidence > $1.confidence }
                let topN = 3 // Display top 3 predictions

                self.topPredictions = sortedObservations.prefix(topN).map { observation in
                    let confidence = String(format: "%.1f%%", observation.confidence * 100)
                    return "\(observation.identifier) (\(confidence))"
                }
            }
            request.imageCropAndScaleOption = .centerCrop // Or .scaleFit, depending on your model

            let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])
            try handler.perform([request])

        } catch {
            topPredictions = ["Model error: \(error.localizedDescription)"]
        }
    }
}

// Re-using ImagePicker from Exercise 1 for older iOS / convenience
// (Definition omitted here for brevity, assume it's available)

// For preview purposes
struct ApplianceDamageAssessmentView_Previews: PreviewProvider {
    static var previews: some View {
        ApplianceDamageAssessmentView()
    }
}
