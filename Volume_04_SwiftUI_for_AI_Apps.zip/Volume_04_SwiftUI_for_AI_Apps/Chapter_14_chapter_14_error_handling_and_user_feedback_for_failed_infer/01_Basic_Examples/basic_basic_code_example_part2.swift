
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import UIKit // Required for UIImage

/// A mock AI model that simulates categorizing a photo.
/// It can be configured to fail at different stages for demonstration purposes.
class MockAICategorizer {
    /// Simulates whether the model should fail during loading.
    var shouldFailModelLoading: Bool = false
    /// Simulates whether the input image should be considered invalid.
    var shouldFailInputValidation: Bool = false
    /// Simulates whether the actual inference process should fail.
    var shouldFailInference: Bool = false

    /// Simulates an asynchronous photo categorization process.
    /// - Parameter image: The `UIImage` to categorize.
    /// - Returns: A `String` representing the photo's category.
    /// - Throws: `PhotoCategorizationError` if any simulated failure occurs.
    func categorizePhoto(image: UIImage) async throws -> String {
        // Simulate network or disk latency
        try await Task.sleep(for: .seconds(1))

        // 1. Simulate Model Loading Failure
        if shouldFailModelLoading {
            print("DEBUG: Simulating model loading failure.")
            throw PhotoCategorizationError.modelLoadingFailed(reason: "Corrupt model file.")
        }

        // 2. Simulate Input Validation Failure
        // In a real app, you might check image dimensions, pixel format, etc.
        if shouldFailInputValidation || image.size.width < 10 { // Example: too small image
            print("DEBUG: Simulating invalid input image.")
            throw PhotoCategorizationError.invalidInputImage
        }

        // Simulate more processing time
        try await Task.sleep(for: .seconds(0.5))

        // 3. Simulate Inference Failure
        if shouldFailInference {
            print("DEBUG: Simulating inference failure.")
            // We can wrap an underlying system error if available
            let underlyingSystemError = NSError(domain: "com.example.inference", code: 1001, userInfo: [NSLocalizedDescriptionKey: "Tensor processing error."])
            throw PhotoCategorizationError.inferenceFailed(underlyingError: underlyingSystemError)
        }

        // If all goes well, return a simulated category
        print("DEBUG: Photo categorized successfully.")
        return "Nature" // Example category
    }
}
