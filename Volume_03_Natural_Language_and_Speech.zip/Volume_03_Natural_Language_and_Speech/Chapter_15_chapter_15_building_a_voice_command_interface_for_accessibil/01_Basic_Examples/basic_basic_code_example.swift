
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Speech
import AVFoundation

/// Represents a voice command that can be recognized by the processor.
/// Conforms to `CaseIterable` to easily iterate through all possible commands.
enum VoiceCommand: String, CaseIterable {
    case scrollUp = "scroll up"
    case scrollDown = "scroll down"
    case takePhoto = "take photo"
    case zoomIn = "zoom in"

    /// Provides a user-friendly description for each command.
    var description: String {
        switch self {
        case .scrollUp: return "Scrolls the document content upwards."
        case .scrollDown: return "Scrolls the document content downwards."
        case .takePhoto: return "Captures an image using the camera."
        case .zoomIn: return "Zooms in on the current view."
        }
    }
}

/// A protocol for delegates to receive recognized commands and transcription updates.
protocol SpeechCommandProcessorDelegate: AnyObject {
    /// Called when a voice command is successfully recognized.
    /// - Parameters:
    ///   - processor: The `SpeechCommandProcessor` instance.
    ///   - command: The `VoiceCommand` that was recognized.
    func speechCommandProcessor(_ processor: SpeechCommandProcessor, didRecognizeCommand command: VoiceCommand)
    
    /// Called when speech recognition provides a partial or final transcription.
    /// - Parameters:
    ///   - processor: The `SpeechCommandProcessor` instance.
    ///   - transcription: The current transcribed string.
    func speechCommandProcessor(_ processor: SpeechCommandProcessor, didUpdateTranscription transcription: String)
    
    /// Called when an error occurs during speech recognition.
    /// - Parameters:
    ///   - processor: The `SpeechCommandProcessor` instance.
    ///   - error: The `Error` that occurred.
    func speechCommandProcessor(_ processor: SpeechCommandProcessor, didEncounterError error: Error)
    
    /// Called when the authorization status for speech recognition changes.
    /// - Parameters:
    ///   - processor: The `SpeechCommandProcessor` instance.
    ///   - status: The new `SFSpeechRecognizerAuthorizationStatus`.
    func speechCommandProcessor(_ processor: SpeechCommandProcessor, didChangeAuthorizationStatus status: SFSpeechRecognizerAuthorizationStatus)
}

/// A class that handles speech recognition and command processing for accessibility.
/// It integrates with AVFoundation for audio input and the Speech framework for recognition.
/// All state changes and delegate calls are ensured to happen on the main thread via `@MainActor`.
@MainActor
class SpeechCommandProcessor {
    
    // MARK: - Properties
    
    /// The speech recognizer instance, configured for a specific locale.
    private let speechRecognizer: SFSpeechRecognizer?
    
    /// The audio engine responsible for capturing microphone input.
    private var audioEngine: AVAudioEngine?
    
    /// The recognition request for live audio buffers. This is where audio data is fed.
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    
    /// The current speech recognition task. Manages the lifecycle of a recognition session.
    private var recognitionTask: SFSpeechRecognitionTask?
    
    /// The current authorization status for speech recognition.
    private(set) var authorizationStatus: SFSpeechRecognizerAuthorizationStatus = .notDetermined
    
    /// A flag indicating if the processor is currently transcribing speech.
    private(set) var isTranscribing: Bool = false
    
    /// The delegate to report recognized commands and transcription updates.
    weak var delegate: SpeechCommandProcessorDelegate?
    
    // MARK: - Initialization
    
    /// Initializes a new speech command processor.
    /// - Parameter localeIdentifier: The identifier for the locale to use for speech recognition (e.g., "en-US").
    init(localeIdentifier: String = "en-US") {
        // Initialize the speech recognizer with the specified locale.
        // If the locale is not supported, speechRecognizer will be nil.
        speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: localeIdentifier))
        
        // Set the delegate for the speech recognizer to receive authorization status updates.
        // This is crucial for handling changes like network availability.
        speechRecognizer?.delegate = self
        
        // Immediately check the current authorization status.
        self.authorizationStatus = SFSpeechRecognizer.authorizationStatus()
    }
    
    // MARK: - Authorization
    
    /// Requests authorization for speech recognition and microphone access.
    /// This method must be called before starting transcription.
    /// It updates the `authorizationStatus` property and notifies the delegate.
    /// - Throws: `SpeechCommandProcessorError.authorizationDenied` if speech authorization is denied.
    /// - Throws: `SpeechCommandProcessorError.microphoneAccessDenied` if microphone access is denied.
    func requestAuthorization() async throws {
        // 1. Request speech recognition authorization.
        let speechAuthStatus = await SFSpeechRecognizer.requestAuthorization()
        self.authorizationStatus = speechAuthStatus
        delegate?.speechCommandProcessor(self, didChangeAuthorizationStatus: speechAuthStatus)

        guard speechAuthStatus == .authorized else {
            // If speech authorization is not granted, throw an error.
            throw SpeechCommandProcessorError.authorizationDenied(speechAuthStatus)
        }

        // 2. Request microphone authorization.
        let audioSession = AVAudioSession.sharedInstance()
        let microphoneGranted = await withCheckedContinuation { continuation in
            audioSession.requestRecordPermission { granted in
                continuation.resume(returning: granted)
            }
        }

        guard microphoneGranted else {
            // If microphone authorization is not granted, throw an error.
            throw SpeechCommandProcessorError.microphoneAccessDenied
        }
    }
    
    // MARK: - Transcription Control
    
    /// Starts the speech transcription process.
    /// This method sets up the audio engine and begins listening for speech.
    /// - Throws: `SpeechCommandProcessorError` if setup fails or authorization is not granted.
    func startTranscribing() async throws {
        // Ensure previous tasks are stopped before starting a new one to prevent resource conflicts.
        stopTranscribing()
        
        guard authorizationStatus == .authorized else {
            // Cannot start without proper authorization.
            throw SpeechCommandProcessorError.notAuthorized
        }
        
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            // Speech recognizer must be available (e.g., network connectivity).
            throw SpeechCommandProcessorError.recognizerUnavailable
        }
        
        // 1. Configure the audio session for recording.
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            throw SpeechCommandProcessorError.audioSessionSetupFailed(error)
        }
        
        // 2. Initialize audio engine and recognition request.
        audioEngine = AVAudioEngine()
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        recognitionRequest?.shouldReportPartialResults = true // Receive updates as speech is recognized.
        
        guard let audioEngine = audioEngine, let recognitionRequest = recognitionRequest else {
            throw SpeechCommandProcessorError.internalError("Failed to initialize audio engine or recognition request.")
        }
        
        // 3. Add the input node to the audio engine.
        let inputNode = audioEngine.inputNode
        
        // 4. Create the recognition task.
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return } // Safely unwrap self to prevent retain cycles.
            
            if let result = result {
                // Process the recognized text.
                let recognizedText = result.bestTranscription.formattedString
                self.delegate?.speechCommandProcessor(self, didUpdateTranscription: recognizedText)
                
                // If it's a final result, try to process it as a command.
                if result.isFinal {
                    self.handleRecognizedText(recognizedText)
                }
            } else if let error = error {
                // Handle recognition errors.
                self.delegate?.speechCommandProcessor(self, didEncounterError: error)
                self.stopTranscribing() // Stop on error to reset state.
            }
        }
        
        // 5. Install a tap on the input node to provide audio buffers to the recognition request.
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer) // Feed audio buffers to the speech recognition request.
        }
        
        // 6. Prepare and start the audio engine.
        audioEngine.prepare()
        do {
            try audioEngine.start()
            self.isTranscribing = true
            print("Speech transcription started.")
        } catch {
            throw SpeechCommandProcessorError.audioEngineStartFailed(error)
        }
    }
    
    /// Stops the speech transcription process and cleans up resources.
    func stopTranscribing() {
        // 1. Stop and detach audio engine components.
        audioEngine?.stop()
        audioEngine?.inputNode.removeTap(onBus: 0) // Crucial: remove tap to prevent memory leaks.
        audioEngine = nil // Release the audio engine.
        
        // 2. End and release the recognition request.
        recognitionRequest?.endAudio()
        recognitionRequest = nil // Release the recognition request.
        
        // 3. Cancel and release the recognition task.
        recognitionTask?.cancel() // Cancel the task if it's still running.
        recognitionTask = nil // Release the recognition task.
        
        isTranscribing = false
        print("Speech transcription stopped.")
        
        // 4. Deactivate audio session to release microphone and allow other apps to use audio.
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        } catch {
            delegate?.speechCommandProcessor(self, didEncounterError: SpeechCommandProcessorError.audioSessionDeactivationFailed(error))
        }
    }
    
    // MARK: - Command Handling
    
    /// Analyzes the recognized text to identify and trigger voice commands.
    /// - Parameter text: The transcribed text from speech recognition.
    private func handleRecognizedText(_ text: String) {
        let lowercasedText = text.lowercased()
        
        // Iterate through all defined commands to find a match.
        for command in VoiceCommand.allCases {
            if lowercasedText.contains(command.rawValue) {
                print("Command recognized: \(command.rawValue)")
                delegate?.speechCommandProcessor(self, didRecognizeCommand: command)
                // Optionally, stop transcription after a command is recognized if it's a single-shot command.
                // For a continuous command interface, you might not want to stop here.
                // self.stopTranscribing()
                return // Only handle the first recognized command found.
            }
        }
        print("No command recognized for: \"\(text)\"")
    }
    
    // MARK: - Error Handling
    
    /// Custom error types for the `SpeechCommandProcessor` to provide more specific error information.
    enum SpeechCommandProcessorError: Error, LocalizedError {
        case authorizationDenied(SFSpeechRecognizerAuthorizationStatus)
        case microphoneAccessDenied
        case notAuthorized
        case recognizerUnavailable
        case audioSessionSetupFailed(Error)
        case audioEngineStartFailed(Error)
        case audioSessionDeactivationFailed(Error)
        case internalError(String)
        
        var errorDescription: String? {
            switch self {
            case .authorizationDenied(let status):
                return "Speech recognition authorization denied: \(status.localizedDescription). Please enable in Settings."
            case .microphoneAccessDenied:
                return "Microphone access denied. Please enable in Settings."
            case .notAuthorized:
                return "Speech recognition is not authorized. Please request authorization first."
            case .recognizerUnavailable:
                return "Speech recognizer is not available on this device or for this locale (e.g., no network)."
            case .audioSessionSetupFailed(let error):
                return "Failed to set up audio session: \(error.localizedDescription)"
            case .audioEngineStartFailed(let error):
                return "Failed to start audio engine: \(error.localizedDescription)"
            case .audioSessionDeactivationFailed(let error):
                return "Failed to deactivate audio session: \(error.localizedDescription)"
            case .internalError(let message):
                return "Internal error: \(message)"
            }
        }
    }
}

// MARK: - SFSpeechRecognizerDelegate

extension SpeechCommandProcessor: SFSpeechRecognizerDelegate {
    /// Called when the availability of the speech recognizer changes.
    /// This can happen due to network connectivity changes, server issues, etc.
    /// - Parameters:
    ///   - speechRecognizer: The `SFSpeechRecognizer` instance.
    ///   - available: A boolean indicating if the recognizer is currently available.
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        // This delegate method could be used to update UI, e.g., enable/disable a "start listening" button.
        print("Speech recognizer availability changed: \(available ? "Available" : "Unavailable")")
        // In a real app, you might want to notify the delegate or update an internal state.
        if !available && isTranscribing {
            // If recognizer becomes unavailable while transcribing, stop and report error.
            delegate?.speechCommandProcessor(self, didEncounterError: SpeechCommandProcessorError.recognizerUnavailable)
            stopTranscribing()
        }
    }
}

// MARK: - Example Usage

// This section demonstrates how you would integrate the SpeechCommandProcessor
// into a hypothetical application context, like a ViewController or SwiftUI View.

/// A simple example class to demonstrate how to use the `SpeechCommandProcessor`.
/// In a real app, this logic would likely reside within a `ViewController`, `ViewModel`, or `App` struct.
/// `@available(iOS 18.0, *)` is used here to ensure compatibility with the latest Swift features
/// like `@MainActor` on classes and `Task.sleep`, though the core `Speech` framework APIs
/// are available on older iOS versions.
@available(iOS 18.0, *)
class VoiceControlledDocumentView: SpeechCommandProcessorDelegate {
    let processor = SpeechCommandProcessor()
    
    // In a real app, these would be `@Published` properties for SwiftUI or UI elements for UIKit.
    var currentTranscription: String = "Say a command..." {
        didSet { print("Transcription: \(currentTranscription)") }
    }
    var currentStatus: String = "Idle" {
        didSet { print("Status: \(currentStatus)") }
    }
    
    init() {
        processor.delegate = self
    }
    
    /// Simulates pressing a "Start Listening" button in the UI.
    func startListeningButtonTapped() {
        Task { @MainActor in // Ensure UI updates and delegate calls are on the main actor.
            currentStatus = "Requesting authorization..."
            do {
                try await processor.requestAuthorization()
                currentStatus = "Authorization granted. Starting transcription..."
                try await processor.startTranscribing()
                currentStatus = "Listening for commands..."
            } catch {
                currentStatus = "Error: \(error.localizedDescription)"
                print("Error starting transcription: \(error)")
            }
        }
    }
    
    /// Simulates pressing a "Stop Listening" button in the UI.
    func stopListeningButtonTapped() {
        processor.stopTranscribing()
        currentStatus = "Stopped listening."
        currentTranscription = "Say a command..."
    }
    
    // MARK: - SpeechCommandProcessorDelegate Conformance
    
    /// Delegate method called when a voice command is recognized.
    func speechCommandProcessor(_ processor: SpeechCommandProcessor, didRecognizeCommand command: VoiceCommand) {
        currentStatus = "Command recognized: \(command.rawValue)"
        // Simulate performing the action associated with the command.
        switch command {
        case .scrollUp:
            print("--- Performing Scroll Up action ---")
            // In a real app, this would interact with the document view's scroll position.
        case .scrollDown:
            print("--- Performing Scroll Down action ---")
            // In a real app, this would interact with the document view's scroll position.
        case .takePhoto:
            print("--- Performing Take Photo action ---")
            // In a real app, this would interact with a camera service to capture an image.
        case .zoomIn:
            print("--- Performing Zoom In action ---")
            // In a real app, this would interact with the view's zoom level.
        }
        // Depending on the command, you might want to stop listening after a single command.
        // For a continuous voice command interface, you'd keep listening.
        // For this example, we'll keep listening.
    }
    
    /// Delegate method called when transcription updates.
    func speechCommandProcessor(_ processor: SpeechCommandProcessor, didUpdateTranscription transcription: String) {
        currentTranscription = transcription
        // In a real UI, this would update a text label or overlay displaying the live transcription.
    }
    
    /// Delegate method called when an error occurs during recognition.
    func speechCommandProcessor(_ processor: SpeechCommandProcessor, didEncounterError error: Error) {
        currentStatus = "Error during recognition: \(error.localizedDescription)"
        print("Recognition error: \(error)")
        stopListeningButtonTapped() // Stop listening on error to ensure a clean state.
    }
    
    /// Delegate method called when authorization status changes.
    func speechCommandProcessor(_ processor: SpeechCommandProcessor, didChangeAuthorizationStatus status: SFSpeechRecognizerAuthorizationStatus) {
        let statusString: String
        switch status {
        case .notDetermined: statusString = "Not Determined"
        case .denied: statusString = "Denied"
        case .restricted: statusString = "Restricted"
        case .authorized: statusString = "Authorized"
        @unknown default: statusString = "Unknown" // Handle future cases gracefully.
        }
        currentStatus = "Authorization Status: \(statusString)"
    }
}

/*
// To run this example in a simple main function (e.g., in a Playground or command-line tool),
// you would need to simulate user interaction. In a real iOS/macOS app,
// `startListeningButtonTapped()` would be triggered by a UI element.

@available(iOS 18.0, *)
func main() {
    let documentView = VoiceControlledDocumentView()
    
    print("--- Voice Controlled Document View Example ---")
    
    // Simulate user tapping 'Start Listening'
    documentView.startListeningButtonTapped()
    
    // For a command-line simulation, we need to keep the program alive
    // to allow async operations (like speech recognition) to run.
    // In a real app, the main run loop handles this automatically.
    
    // We'll use a Task.sleep to simulate interaction over time.
    // In a real app, the user would interact with the microphone.
    Task { @MainActor in
        print("\n--- Awaiting speech for 15 seconds... ---")
        try await Task.sleep(for: .seconds(15)) // Listen for 15 seconds
        documentView.stopListeningButtonTapped()
        print("--- Example Finished ---")
        // In a real app, the app would continue running until terminated by the user.
        // For a playground, this Task will complete and the playground might stop.
    }
    
    // In a Swift Playground, you might need to enable "Run Manually" and use
    // XCPlaygroundPage.current.needsIndefiniteExecution = true
    // However, with async/await, the Task should keep it alive for its duration.
}

// Uncomment the line below to run the example in a Swift Playground or a command-line tool.
// main()
*/
