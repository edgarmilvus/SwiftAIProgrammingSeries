
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, visionOS 2.0, *)
import SwiftData
import Foundation // For UUID and Date

@Model
class Category {
    @Attribute(.unique) var name: String
    @Relationship(inverse: \Thought.category) var thoughts: [Thought]

    init(name: String) {
        self.name = name
        self.thoughts = [] // Initialize with an empty array of thoughts
    }
}

@available(iOS 18.0, macOS 15.0, tvOS 18.0, watchOS 11.0, visionOS 2.0, *)
@Model
class Thought {
    var id: UUID
    var text: String
    var timestamp: Date
    var sentimentScore: Double?
    var moodEmoji: String?
    @Relationship(inverse: \Category.thoughts) var category: Category // A thought must belong to one category

    init(id: UUID = UUID(), text: String, timestamp: Date = Date(), sentimentScore: Double? = nil, moodEmoji: String? = nil, category: Category) {
        self.id = id
        self.text = text
        self.timestamp = timestamp
        self.sentimentScore = sentimentScore
        self.moodEmoji = moodEmoji
        self.category = category // Assign the required category
    }
}
