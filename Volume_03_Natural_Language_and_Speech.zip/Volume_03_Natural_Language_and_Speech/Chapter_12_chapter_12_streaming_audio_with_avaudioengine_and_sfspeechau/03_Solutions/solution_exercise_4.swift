
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import UIKit

class VolumeMeterView: UIView {
    var level: Float = 0.0 { // 0.0 to 1.0
        didSet {
            // Ensure UI updates are on the main thread
            DispatchQueue.main.async {
                self.setNeedsDisplay() // Trigger redraw when level changes
            }
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }

    private func setupView() {
        backgroundColor = .clear
        layer.cornerRadius = 5
        layer.masksToBounds = true
    }

    override func draw(_ rect: CGRect) {
        super.draw(rect)

        guard let context = UIGraphicsGetCurrentContext() else { return }

        // Background for the meter
        context.setFillColor(UIColor.darkGray.cgColor)
        context.fill(rect)

        // Calculate the width of the colored bar based on the level
        let barWidth = rect.width * CGFloat(level)
        let barRect = CGRect(x: 0, y: 0, width: barWidth, height: rect.height)

        // Choose color based on level (e.g., green for low, yellow for medium, red for high)
        let color: UIColor
        if level > 0.85 {
            color = .systemRed // High level, potential clipping
        } else if level > 0.6 {
            color = .systemYellow // Medium level
        } else {
            color = .systemGreen // Good level
        }

        context.setFillColor(color.cgColor)
        context.fill(barRect)
    }
}
