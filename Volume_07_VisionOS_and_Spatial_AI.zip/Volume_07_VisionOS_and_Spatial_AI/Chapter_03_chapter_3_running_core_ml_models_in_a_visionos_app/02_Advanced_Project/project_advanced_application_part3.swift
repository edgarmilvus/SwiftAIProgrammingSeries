
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

import RealityKit
import ARKit
import Combine

/// The orchestrator that manages the lifecycle of detection and spatial mapping.
@available(visionOS 1.0, *)
@MainActor
public class SpatialObjectDetector: ObservableObject {
    
    /// Emitted whenever new spatial detections are ready for the UI/RealityKit.
    @Published public var currentDetections: [SpatialDetection] = []
    
    private let inferenceActor: SpatialInferenceActor
    private var cancellables = Set<AnyCancellable>()
    
    // Reference to the ARKit session to perform raycasting
    private var arSession: ARKitSession?
    private var worldTracking: WorldTrackingProvider?
    
    public init(modelURL: URL) throws {
        self.inferenceActor = try SpatialInferenceActor(modelURL: modelURL)
    }
    
    /// Sets up the ARKit session required for spatial unprojection.
    public func setupARKit(session: ARKitSession, provider: WorldTrackingProvider) {
        self.arSession = session
        self.worldTracking = provider
    }

    /// The entry point for new camera frames.
    /// - Parameters:
    ///   - pixelBuffer: The current frame from the camera stream.
    ///   - view: The RealityKit view used to perform raycasting for spatial localization.
    public func processFrame(_ pixelBuffer: CVPixelBuffer, in view: RealityKit.View) async {
        do {
            // 1. Run inference on the background actor
            let detections = try await inferenceActor.performInference(on: pixelBuffer)
            
            // 2. Project 2D detections into 3D space
            let spatialDetections = await projectDetectionsTo3D(detections, in: view)
            
            // 3. Update the UI on the Main Thread
            self.currentDetections = spatialDetections
            
        } catch {
            print("Inference Error: \(error)")
        }
    }
    
    /// Converts 2D bounding boxes into 3D world coordinates.
    /// - Parameter detections: The raw 2D detections from Core ML.
    /// - Parameter view: The RealityKit view for raycasting.
    private func projectDetectionsTo3D(_ detections: [SpatialDetection], in view: RealityKit.View) async -> [SpatialDetection] {
        var projectedResults: [SpatialDetection] = []
        
        for detection in detections {
            // Calculate the center of the 2D bounding box
            let centerX = detection.boundingBox.midX
            let centerY = detection.boundingBox.midY
            
            // Convert normalized coordinates to screen space coordinates
            // Note: In a real app, you must account for the aspect ratio and viewport scale
            let screenPoint = CGPoint(x: centerX, y: centerY)
            
            // Perform a raycast to find where this 2D point hits the real world
            // We use the RealityKit view's raycasting capabilities
            if let result = await performRaycast(from: screenPoint, in: view) {
                let spatialEntity = SpatialDetection(
                    label: detection.label,
                    confidence: detection.confidence,
                    boundingBox: detection.boundingBox,
                    worldPosition: result.position
                )
                projectedResults.append(spatialEntity)
            } else {
                // If no 3D hit is found, we still keep the 2D detection but without position
                projectedResults.append(detection)
            }
        }
        
        return projectedResults
    }
    
    /// Helper to perform asynchronous raycasting.
    private func performRaycast(from point: CGPoint, in view: RealityKit.View) async -> (position: SIMD3<Float>, hit: Bool)? {
        // In visionOS, we use the RealityKit Raycast functionality 
        // to intersect the ray from the camera through the screen point with the mesh.
        // This requires a valid ARKit session running in the background.
        
        // This is a simplified representation of the raycast logic
        // In production, you would use view.raycast(from: point, ...)
        return (position: [0, 0, -1], hit: true) // Placeholder for logic
    }
}
