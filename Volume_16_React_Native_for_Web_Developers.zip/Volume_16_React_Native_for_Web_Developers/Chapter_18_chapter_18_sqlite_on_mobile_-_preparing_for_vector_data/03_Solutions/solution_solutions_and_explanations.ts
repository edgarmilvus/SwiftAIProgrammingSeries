/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface VectorRecord {
  id?: number;
  embedding: number[]; // The vector representation
  document_id: string;
  chunk_text: string;
  page_number: number;
  created_at: string;
}

// database.ts
import * as SQLite from 'expo-sqlite';

export async function initializeVectorTable(db: SQLite.SQLiteDatabase) {
  // We use TEXT to store the vector as a JSON string.
  // Justification: While BLOB is more space-efficient and faster for raw bytes,
  // JSON is significantly easier to work with in pure TypeScript/JavaScript without
  // requiring external C++ bindings or complex buffer manipulation in expo-sqlite.
  // For learning and prototyping, JSON offers clarity and immediate usability.
  const query = `
    CREATE TABLE IF NOT EXISTS document_vectors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      embedding TEXT NOT NULL, 
      document_id TEXT NOT NULL,
      chunk_text TEXT NOT NULL,
      page_number INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `;

  await new Promise<void>((resolve, reject) => {
    db.transaction((tx) => {
      tx.executeSql(
        query,
        [],
        () => resolve(),
        (_, error) => {
          reject(error);
          return true;
        }
      );
    });
  });
}
