
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import SwiftData
import OSLog

/// Represents the errors that can occur during high-volume semantic data operations.
enum SemanticMemoryError: Error {
    case batchInsertionFailed(String)
    case contextSaveFailure(Error)
    case invalidEmbeddingDimension
}

/// The core model representing a single unit of semantic memory.
/// We use `@available(iOS 18.0, *)` as we rely on advanced SwiftData features.
@available(iOS 18.0, *)
@Model
final class SemanticMemoryEntry {
    /// The unique identifier for the memory, useful for cross-actor syncing.
    @Attribute(.unique) var id: UUID
    
    /// The raw text content of the memory (e.g., a transcript fragment).
    var content: String
    
    /// The timestamp of the interaction, crucial for temporal decay algorithms.
    var timestamp: Date
    
    /// The high-dimensional vector embedding. 
    /// NOTE: In production, ensure this is stored as a compressed format if possible.
    @Attribute(.externalStorage) var embedding: Data
    
    /// Metadata tags for rapid non-vector filtering (e.g., "work", "personal").
    var tags: [String]
    
    init(id: UUID = UUID(), content: String, timestamp: Date = .now, embedding: Data, tags: [String] = []) {
        self.id = id
        self.content = content
        self.timestamp = timestamp
        self.embedding = embedding
        self.tags = tags
    }
}

/// A specialized Actor designed to handle heavy-duty SwiftData operations on a background thread.
/// Using `@ModelActor` ensures that all database work is isolated from the MainActor.
@available(iOS 18.0, *)
@ModelActor
actor MemoryIngestionEngine {
    private let logger = Logger(subsystem: "com.ai.memory", category: "Ingestion")
    
    /// The size of the batch for each save operation. 
    /// Smaller batches reduce memory spikes but increase I/O overhead.
    private let batchSize: Int = 50

    /// Ingests a large collection of semantic entries using a chunking strategy.
    /// - Parameter entries: An array of raw data needed to construct entries.
    /// - Throws: `SemanticMemoryError` if insertion or saving fails.
    func ingestLargeDataset(rawEntries: [(content: String, embedding: Data, tags: [String])]) async throws {
        logger.info("Starting ingestion of \(rawEntries.count) entries.")
        
        // 1. Break the massive array into manageable chunks to prevent memory exhaustion.
        let chunks = rawEntries.chunked(into: batchSize)
        
        for (index, chunk) in chunks.enumerated() {
            try await processChunk(chunk)
            
            // 2. Log progress for observability.
            logger.debug("Successfully processed chunk \(index + 1) of \(chunks.count)")
            
            // 3. Yield control back to the system to prevent actor starvation.
            await Task.yield()
        }
        
        logger.info("Ingestion complete.")
    }

    /// Processes a single chunk of data within the actor's isolated context.
    private func processChunk(_ chunk: [(content: String, embedding: Data, tags: [String])]) throws {
        for item in chunk {
            // Validate embedding size (Example: 1536 for OpenAI text-embedding-3-small)
            guard item.embedding.count > 0 else {
                throw SemanticMemoryError.invalidEmbeddingDimension
            }
            
            let entry = SemanticMemoryEntry(
                content: item.content,
                embedding: item.embedding,
                tags: item.tags
            )
            
            // Insert into the actor-local model context.
            modelContext.insert(entry)
        }
        
        // 4. Explicitly save after every chunk. 
        // This clears the context's internal 'dirty' object map, preventing OOM.
        do {
            try modelContext.save()
        } catch {
            logger.error("Failed to save chunk: \(error.localizedDescription)")
            throw SemanticMemoryError.contextSaveFailure(error)
        }
    }
}

// MARK: - Helper Extensions

extension Array {
    /// Splits an array into smaller arrays of a specified size.
    func chunked(into size: Int) -> [[Element]] {
        stride(from: 0, to: count, by: size).map {
            Array(self[$0 ..< Swift.min($0 + size, count)])
        }
    }
}

// MARK: - Advanced Querying Service

@available(iOS 18.0, *)
struct SemanticSearchService {
    /// Performs a metadata-filtered search before applying vector math.
    /// This "Pre-filtering" strategy is critical for performance.
    /// - Parameters:
    ///   - tag: The metadata tag to filter by.
    ///   - context: The ModelContext to use for fetching.
    /// - Returns: An array of matching entries.
    func fetchEntries(withTag tag: String, in context: ModelContext) throws -> [SemanticMemoryEntry] {
        // 5. Predicate Optimization: 
        // We filter by 'tags' (indexed metadata) first. This reduces the number of 
        // high-dimensional 'embedding' blobs loaded into memory from disk.
        let predicate = #Predicate<SemanticMemoryEntry> { entry in
            entry.tags.contains(tag)
        }
        
        var descriptor = FetchDescriptor<SemanticMemoryEntry>(predicate: predicate)
        
        // 6. Fetch Limit & Offset: 
        // Never fetch the whole database. Use limits to implement pagination.
        descriptor.fetchLimit = 100
        descriptor.sortBy = [SortDescriptor(\.timestamp, order: .reverse)]
        
        return try context.fetch(descriptor)
    }
}
