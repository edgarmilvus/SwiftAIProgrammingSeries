
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import SwiftUI
import NaturalLanguage // Contains TextSummarizer

@available(iOS 18.0, macOS 15.0, *)
struct ArticleSummarizerView: View {
    @State private var inputText: String = ""
    @State private var summaryText: String = "Summary will appear here."
    @State private var isSummarizing: Bool = false
    @State private var showingErrorAlert: Bool = false
    @State private var errorMessage: String = ""

    var body: some View {
        VStack {
            Text("Article Text")
                .font(.headline)
            TextEditor(text: $inputText)
                .frame(minHeight: 200)
                .border(Color.gray, width: 1)
                .padding([.horizontal, .bottom])
                .accessibilityLabel("Input text for summarization")

            Button {
                Task {
                    await summarizeArticle()
                }
            } label: {
                if isSummarizing {
                    ProgressView()
                } else {
                    Text("Summarize Article")
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(isSummarizing || inputText.isEmpty)
            .padding(.bottom)

            Text("Summary")
                .font(.headline)
            TextEditor(text: $summaryText)
                .frame(minHeight: 150)
                .border(Color.gray, width: 1)
                .padding([.horizontal, .top])
                .accessibilityLabel("Generated summary")
        }
        .navigationTitle("Article Summarizer")
        .padding()
        .alert("Error", isPresented: $showingErrorAlert) {
            Button("OK") { }
        } message: {
            Text(errorMessage)
        }
    }

    @available(iOS 18.0, macOS 15.0, *)
    private func summarizeArticle() async {
        isSummarizing = true
        errorMessage = ""
        showingErrorAlert = false
        do {
            // Instantiate TextSummarizer
            let summarizer = TextSummarizer()

            // Call the summarize method
            let summary = try await summarizer.summarize(inputText)
            summaryText = summary
        } catch {
            errorMessage = "Failed to summarize: \(error.localizedDescription)"
            showingErrorAlert = true
            summaryText = "Error: Could not generate summary."
            print("Error summarizing: \(error)")
        }
        isSummarizing = false
    }
}

// Minimal App structure for demonstration
@main
@available(iOS 18.0, macOS 15.0, *)
struct SummarizerApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView { // Or NavigationStack in iOS 16+
                ArticleSummarizerView()
            }
        }
    }
}
