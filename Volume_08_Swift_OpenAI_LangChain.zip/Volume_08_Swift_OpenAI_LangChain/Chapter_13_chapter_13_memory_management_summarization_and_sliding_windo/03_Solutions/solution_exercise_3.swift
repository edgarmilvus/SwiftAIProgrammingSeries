
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation

/// Protocol for a service that interacts with an LLM to perform summarization.
protocol SummarizationProvider: Sendable {
    func summarize(messages: [ChatMessage]) async throws -> String
}

/// A mock provider that simulates an LLM summarization call.
struct MockLLMSummarizer: SummarizationProvider {
    func summarize(messages: [ChatMessage]) async throws -> String {
        // Simulate LLM latency
        try await Task.sleep(for: .seconds(1))
        let combinedText = messages.map { "\($0.role.rawValue): \($0.content)" }.joined(separator: "\n")
        return "Summary of history: [The user and assistant discussed \(messages.count) topics regarding \(combinedText.prefix(20))...]"
    }
}

/// The orchestrator that manages the transition from raw history to summarized history.
actor ContextOrchestrator {
    private var history: [ChatMessage] = []
    private let summarizer: any SummarizationProvider
    private let compressionThreshold: Int
    private let recentMessageCount: Int
    
    init(
        summarizer: any SummarizationProvider,
        compressionThreshold: Int = 200, // Low for testing
        recentMessageCount: Int = 2
    ) {
        self.summarizer = summarizer
        self.compressionThreshold = compressionThreshold
        self.recentMessageCount = recentMessageCount
    }
    
    /// The primary entry point for adding messages and managing context lifecycle.
    func addMessageAndManageContext(newMsg: ChatMessage) async throws {
        // Step 1: Append the new message
        history.append(newMsg)
        
        // Step 2: Calculate current "token" count (using a simple heuristic for this example)
        let currentTokenCount = history.reduce(0) { $0 + $1.content.count / 4 }
        
        // Step 3: Check if compression is needed
        if currentTokenCount > compressionThreshold {
            print("--- Threshold reached (\(currentTokenCount) tokens). Starting compression... ---")
            try await performCompression()
        }
    }
    
    private func performCompression() async throws {
        // Step 4: Identify "Old Messages" (everything except the most recent N)
        let splitIndex = history.count - recentMessageCount
        guard splitIndex > 0 else { return }
        
        let oldMessages = Array(history[..<splitIndex])
        let recentMessages = Array(history[..<history.count].suffix(recentMessageCount))
        
        do {
            // Step 5: Call the provider to summarize
            let summaryString = try await summarizer.summarize(messages: oldMessages)
            
            // Step 6: Construct new history
            let systemSummaryMsg = ChatMessage(
                role: .system, 
                content: "Summary of the previous conversation: \(summaryString)"
            )
            
            // The new history is the Summary + the recent uncompressed messages
            self.history = [systemSummaryMsg] + recentMessages
            print("--- Compression Complete. New history size: \(history.count) messages. ---")
            
        } catch {
            // Error Handling: Fallback to simple pruning if summarization fails
            print("Summarization failed: \(error). Falling back to pruning.")
            if history.count > recentMessageCount {
                history.removeFirst()
            }
            throw error
        }
    }
    
    func getHistory() -> [ChatMessage] {
        return history
    }
}

// --- Implementation Test ---
@main
struct CompressionTest {
    static func main() async {
        let orchestrator = ContextOrchestrator(summarizer: MockLLMSummarizer())
        
        // Simulate a stream of messages
        for i in 1...10 {
            let msg = ChatMessage(role: .user, content: "This is message number \(i). It contains enough text to eventually trigger the compression threshold.")
            do {
                try await orchestrator.addMessageAndManageContext(newMsg: msg)
                let currentHistory = await orchestrator.getHistory()
                print("Current History Count: \(currentHistory.count)")
            } catch {
                print("Error: \(error)")
            }
        }
    }
}
