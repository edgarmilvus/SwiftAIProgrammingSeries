
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import CreateML // Essential for MLDataTable and Create ML operations
import Foundation // For Date, UUID, and other foundational types

// MARK: - 1. Define the Data Structure for a Workout Entry

/// Represents a single workout entry in our "Workout Log Analyzer" application.
/// While `MLDataTable` can infer types, defining a Swift struct helps
/// ensure type consistency and clarity in our application logic.
///
/// - Properties:
///   - id: A unique identifier for each workout entry.
///   - date: The date the workout was performed.
///   - type: The category of the workout (e.g., "Cardio", "Strength", "Yoga").
///   - durationMinutes: The length of the workout in minutes.
///   - caloriesBurned: The estimated number of calories burned during the workout.
///   - intensityLevel: A categorical description of the workout's intensity (e.g., "High", "Medium", "Low").
struct WorkoutEntry: Identifiable {
    let id = UUID() // Unique ID for each entry
    let date: Date
    let type: String
    let durationMinutes: Double
    let caloriesBurned: Int
    let intensityLevel: String
}

// MARK: - 2. Prepare Sample Data in Swift

// In a real app, this data would come from user input, a database, or a network request.
// For this example, we'll create an array of dictionaries.
// MLDataTable can be initialized directly from an array of dictionaries
// where each dictionary represents a row and its keys are column names.
let sampleWorkoutData: [[String: Any]] = [
    [
        "date": Calendar.current.date(from: DateComponents(year: 2023, month: 10, day: 26))!,
        "type": "Cardio",
        "durationMinutes": 45.0,
        "caloriesBurned": 350,
        "intensityLevel": "High"
    ],
    [
        "date": Calendar.current.date(from: DateComponents(year: 2023, month: 10, day: 27))!,
        "type": "Strength",
        "durationMinutes": 60.0,
        "caloriesBurned": 400,
        "intensityLevel": "Medium"
    ],
    [
        "date": Calendar.current.date(from: DateComponents(year: 2023, month: 10, day: 28))!,
        "type": "Yoga",
        "durationMinutes": 30.0,
        "caloriesBurned": 150,
        "intensityLevel": "Low"
    ],
    [
        "date": Calendar.current.date(from: DateComponents(year: 2023, month: 10, day: 29))!,
        "type": "Cardio",
        "durationMinutes": 60.0,
        "caloriesBurned": 500,
        "intensityLevel": "High"
    ],
    [
        "date": Calendar.current.date(from: DateComponents(year: 2023, month: 10, day: 30))!,
        "type": "Strength",
        "durationMinutes": 45.0,
        "caloriesBurned": 300,
        "intensityLevel": "Medium"
    ],
    // Example with a missing value for 'caloriesBurned' to show how MLDataTable handles it
    [
        "date": Calendar.current.date(from: DateComponents(year: 2023, month: 10, day: 31))!,
        "type": "Running",
        "durationMinutes": 50.0,
        // "caloriesBurned": nil, // Omitting a key is one way to represent missing data
        "intensityLevel": "High"
    ]
]

// MARK: - 3. Create MLDataTable from Swift Data

// MLDataTable's initializer can throw errors if the data is malformed or inconsistent.
// Therefore, it's crucial to use a 'do-catch' block.
do {
    // The most straightforward way to create an MLDataTable from in-memory Swift data.
    // Create ML will infer the column types (e.g., String, Double, Int, Date)
    // based on the values in the provided array of dictionaries.
    let workoutDataTable = try MLDataTable(array: sampleWorkoutData)

    // MARK: - 4. Inspect the Created MLDataTable

    print("--- MLDataTable Created Successfully ---")

    // 4.1. Print a general description of the table
    // This provides a quick overview of the table's structure and a few rows.
    print("\nTable Description:\n\(workoutDataTable.description)")

    // 4.2. Access basic properties
    print("\nColumn Names: \(workoutDataTable.columnNames)") // List of all column headers
    print("Number of Rows (size): \(workoutDataTable.size)") // Total number of data rows

    // 4.3. Iterate and print inferred column types
    // Understanding the inferred types is crucial for subsequent data transformations
    // and model training, as Create ML expects specific types for certain tasks.
    print("\nInferred Column Types:")
    for columnName in workoutDataTable.columnNames {
        // Accessing a column by name returns an MLDataColumn, from which we can get its type.
        let columnType = workoutDataTable[columnName]?.type ?? .undefined
        print("  - \(columnName): \(columnType)")
    }

    // 4.4. Access a specific column
    // Columns can be accessed using subscript syntax, returning an MLDataColumn.
    if let workoutTypesColumn = workoutDataTable["type"] {
        print("\nFirst 3 entries of 'type' column:")
        // You can iterate over an MLDataColumn or access individual elements.
        for i in 0..<min(3, workoutTypesColumn.size) {
            print("  - \(workoutTypesColumn[i])")
        }
    }

    // 4.5. Demonstrate basic data filtering
    // MLDataTable provides powerful filtering capabilities.
    // Here, we filter for workouts with "High" intensity.
    let highIntensityWorkouts = workoutDataTable.filter(where: "intensityLevel", isEqualTo: "High")
    print("\n--- Filtered MLDataTable (High Intensity Workouts) ---")
    print("Number of High Intensity Workouts: \(highIntensityWorkouts.size)")
    print("Description of High Intensity Workouts:\n\(highIntensityWorkouts.description)")

    // 4.6. Inspect a column for missing values (from the example with 'Running' workout)
    // MLDataTable handles missing values gracefully.
    if let caloriesColumn = workoutDataTable["caloriesBurned"] {
        print("\n'caloriesBurned' column statistics:")
        print("  - Number of missing values: \(caloriesColumn.missingValueCount)")
        // Note: For actual training, you'd typically handle these missing values
        // by filling them (e.g., with mean, median) or removing rows.
    }

} catch {
    // Handle any errors that occur during MLDataTable creation,
    // such as inconsistent data types across rows for the same column.
    print("Error creating MLDataTable: \(error.localizedDescription)")
}

