
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import RealityKit
import AVFoundation

@MainActor
class AudioBeaconAgent: Entity, HasModel, HasAudio {
    private var audioResource: AudioFileResource?
    private var audioPlaybackController: AudioPlaybackController?
    
    required init() {
        super.init()
    }
    
    init(mesh: MeshResource, material: Material, audioResource: AudioFileResource) {
        self.audioResource = audioResource
        super.init()
        self.components.set(ModelComponent(mesh: mesh, materials: [material]))
        
        // Attach Spatial Audio Component
        var spatialComponent = SpatialAudioComponent()
        spatialComponent.directivity = .beam(focus: 0.5) // Directional sound
        self.components.set(spatialComponent)
        
        // Start rhythmic pulsing
        playRhythmicPulse()
    }
    
    private func playRhythmicPulse() {
        guard let resource = audioResource else { return }
        // Play the sound in a loop
        audioPlaybackController = self.prepareAudio(resource)
        audioPlaybackController?.play()
    }
    
    /// Updates the pitch of the spatial audio based on proximity to the listener.
    /// - Parameter distance: The current distance between the user and this entity.
    func updateSonicFeedback(distance: Float) {
        guard let controller = audioPlaybackController else { return }
        
        // Map distance (0.5m to 5.0m) to pitch (1.0 to 2.0)
        // Closer = Higher pitch (more urgent/detectable)
        let minDistance: Float = 0.5
        let maxDistance: Float = 5.0
        let normalizedDistance = max(0, min(1, (distance - minDistance) / (maxDistance - minDistance)))
        
        // Inverse relationship: higher pitch when distance is low
        let pitchScale = 2.0 - normalizedDistance 
        
        // Note: In current RealityKit, pitch modulation is often handled 
        // via the AudioPlaybackController or custom AVAudioEngine nodes.
        controller.speed = Double(pitchScale) 
    }
}

// MARK: - Simulation
@MainActor
func runWayfindingSimulation() async {
    let audioRes = try! await AudioFileResource.load(named: "ping_pulse", in: nil, inputMode: .spatial, loadingMode: .preload)
    let agent = AudioBeaconAgent(
        mesh: .generateSphere(radius: 0.1),
        material: SimpleMaterial(color: .yellow, isMetallic: false),
        audioResource: audioRes
    )
    
    // Simulate movement: Agent moving from 5m away to 1m away
    for distance in stride(from: 5.0, through: 1.0, by: -0.5) {
        agent.updateSonicFeedback(distance: Float(distance))
        print("Agent distance: \(distance)m - Pitch adjusted.")
        try? await Task.sleep(for: .seconds(1))
    }
}
