
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import SwiftData

@Model
final class PricePoint {
    var symbol: String
    var price: Double
    var timestamp: Date
    
    init(symbol: String, price: Double, timestamp: Date) {
        self.symbol = symbol
        self.price = price
        self.timestamp = timestamp
    }
}

struct RawPriceData: Sendable {
    let symbol: String
    let price: Double
    let timestamp: Date
}

final class PriceIngestionService: Sendable {
    private let container: ModelContainer
    
    init(container: ModelContainer) {
        self.container = container
    }
    
    func ingest(rawPoints: [RawPriceData]) async throws {
        // Create a new context specifically for this background work
        // This context is isolated from the main context.
        let backgroundContext = ModelContext(container)
        
        // Ensure we don't block the caller; this runs on a background thread
        try await Task.detached {
            for point in rawPoints {
                let newPrice = PricePoint(
                    symbol: point.symbol,
                    price: point.price,
                    timestamp: point.timestamp
                )
                backgroundContext.insert(newPrice)
            }
            
            // Batch save to persist changes and trigger a merge to the main context
            try backgroundContext.save()
        }.value
    }
}

// Usage Example
// let service = PriceIngestionService(container: sharedContainer)
// try await service.ingest(rawPoints: burstOfData)
