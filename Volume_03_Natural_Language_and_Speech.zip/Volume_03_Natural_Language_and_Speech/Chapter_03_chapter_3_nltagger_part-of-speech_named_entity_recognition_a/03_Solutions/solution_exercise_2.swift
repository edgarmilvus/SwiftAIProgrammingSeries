
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 11.0, macOS 10.13, tvOS 11.0, watchOS 4.0, *)
func extractKeyEntities(from articleText: String) -> [NLTag: [String]] {
    var extractedEntities: [NLTag: Set<String>] = [ // Use Set for uniqueness
        .person: [],
        .organization: []
    ]
    
    let tagger = NLTagger(tagSchemes: [.nameType])
    tagger.string = articleText
    
    let fullRange = NSRange(articleText.startIndex..<articleText.endIndex, in: articleText)
    
    tagger.enumerateTags(in: fullRange, unit: .word, scheme: .nameType, options: [.omitWhitespace, .omitPunctuation, .joinNames]) { tag, range in
        if let tag = tag, let tokenRange = Range(range, in: articleText) {
            let entityString = String(articleText[tokenRange])
            
            switch tag {
            case .person:
                extractedEntities[.person]?.insert(entityString)
            case .organization:
                extractedEntities[.organization]?.insert(entityString)
            default:
                // Ignore other entity types like .place, .date, .time
                break
            }
        }
        return true // Continue enumeration
    }
    
    // Convert Sets back to Arrays for the final return type
    return extractedEntities.mapValues { Array($0).sorted() }
}
