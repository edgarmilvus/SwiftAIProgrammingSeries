
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

// MARK: - Utility Extensions (Place in a separate file in a real project)
import AppKit
import CoreVideo
import CoreGraphics
import Vision

extension NSImage {
    /// Converts an NSImage to a CVPixelBuffer, optionally resizing it.
    /// This is a common helper for Vision framework inputs on macOS.
    func toCVPixelBuffer(pixelFormatType: OSType = kCVPixelFormatType_32BGRA, width: Int? = nil, height: Int? = nil) -> CVPixelBuffer? {
        guard let cgImage = self.cgImage(forProposedRect: nil, context: nil, hints: nil) else { return nil }

        let imageWidth = width ?? cgImage.width
        let imageHeight = height ?? cgImage.height

        var pixelBuffer: CVPixelBuffer?
        let attributes: [String: Any] = [
            kCVPixelBufferCGImageCompatibilityKey as String: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey as String: true,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]

        CVPixelBufferCreate(kCFAllocatorDefault,
                            imageWidth,
                            imageHeight,
                            pixelFormatType,
                            attributes as CFDictionary,
                            &pixelBuffer)

        guard let buffer = pixelBuffer else { return nil }

        CVPixelBufferLockBaseAddress(buffer, .zero)
        defer { CVPixelBufferUnlockBaseAddress(buffer, .zero) }

        let pixelData = CVPixelBufferGetBaseAddress(buffer)
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: pixelData,
                                width: imageWidth,
                                height: imageHeight,
                                bitsPerComponent: 8,
                                bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
                                space: rgbColorSpace,
                                bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue)

        context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: CGFloat(imageWidth), height: CGFloat(imageHeight)))

        return buffer
    }
}

// MARK: - Custom NSImageView for Drawing Detections
class DetectorImageView: NSImageView {
    var detections: [VNRecognizedObjectObservation] = []
    var confidenceThreshold: Float = 0.5 // Default threshold
    var originalImageSize: NSSize = .zero // To correctly scale detections

    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)

        guard let currentImage = self.image, !detections.isEmpty, originalImageSize != .zero else { return }

        // Set up drawing context
        NSGraphicsContext.saveGraphicsState()
        guard let context = NSGraphicsContext.current?.cgContext else { return }

        // Calculate scale factor for drawing
        let imageRect = self.bounds // Assuming contentMode is .scaleAspectFit or similar
        let scaleX = imageRect.width / originalImageSize.width
        let scaleY = imageRect.height / originalImageSize.height

        context.setLineWidth(2.0)
        context.setStrokeColor(NSColor.systemGreen.cgColor)
        context.setFillColor(NSColor.systemGreen.withAlphaComponent(0.2).cgColor)

        for detection in detections where detection.confidence >= confidenceThreshold {
            // Vision returns normalized coordinates (0-1), origin is bottom-left.
            // NSView/NSImage origin is top-left.
            let boundingBox = detection.boundingBox
            let rectWidth = boundingBox.width * originalImageSize.width * scaleX
            let rectHeight = boundingBox.height * originalImageSize.height * scaleY
            let rectX = boundingBox.minX * originalImageSize.width * scaleX
            let rectY = (1 - boundingBox.maxY) * originalImageSize.height * scaleY // Adjust Y for top-left origin

            let drawingRect = NSRect(x: rectX, y: rectY, width: rectWidth, height: rectHeight)

            context.stroke(drawingRect)
            context.fill(drawingRect)

            // Draw label
            if let label = detection.labels.first?.identifier {
                let confidence = String(format: "%.2f", detection.confidence)
                let text = "\(label) (\(confidence))"
                let font = NSFont.systemFont(ofSize: 12)
                let attributes: [NSAttributedString.Key: Any] = [
                    .font: font,
                    .foregroundColor: NSColor.white,
                    .backgroundColor: NSColor.systemGreen.withAlphaComponent(0.8)
                ]
                let attributedString = NSAttributedString(string: text, attributes: attributes)
                let textSize = attributedString.size()

                // Position label above the bounding box
                let textRect = NSRect(x: rectX, y: rectY - textSize.height - 2, width: textSize.width + 4, height: textSize.height + 2)
                attributedString.draw(in: textRect)
            }
        }

        NSGraphicsContext.restoreGraphicsState()
    }

    // Override image setter to clear detections and redraw
    override var image: NSImage? {
        didSet {
            detections = []
            originalImageSize = image?.size ?? .zero
            needsDisplay = true
        }
    }
}

// MARK: - ViewController (Assumes a basic macOS project with a ViewController)
import Cocoa

// Assume 'GroceryDetectorModel' is the name of your Core ML model file (e.g., GroceryDetectorModel.mlmodel)
// Drag your .mlmodel file into your Xcode project to generate this Swift class.
// For this example, let's assume the model expects 300x300 input.

class ViewController: NSViewController {

    // MARK: - UI Elements
    private let imageView: DetectorImageView = {
        let iv = DetectorImageView()
        iv.imageScaling = .scaleProportionallyUpOrDown
        iv.imageAlignment = .alignCenter
        iv.layer?.backgroundColor = NSColor.systemGray.cgColor
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let selectImageButton: NSButton = {
        let button = NSButton(title: "Select Image", target: nil, action: nil)
        button.bezelStyle = .rounded
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let confidenceLabel: NSTextField = {
        let label = NSTextField(labelWithString: "Confidence Threshold: 0.50")
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let confidenceSlider: NSSlider = {
        let slider = NSSlider(value: 0.5, minValue: 0.0, maxValue: 1.0, target: nil, action: nil)
        slider.doubleValue = 0.5
        slider.translatesAutoresizingMaskIntoConstraints = false
        return slider
    }()

    private let activityIndicator: NSProgressIndicator = {
        let indicator = NSProgressIndicator()
        indicator.style = .spinning
        indicator.controlSize = .large
        indicator.isDisplayedWhenStopped = false
        indicator.translatesAutoresizingMaskIntoConstraints = false
        return indicator
    }()

    // MARK: - Model & Vision Setup
    private var objectDetector: VNCoreMLModel?
    private var detectionRequest: VNCoreMLRequest?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupModel()
    }

    private func setupUI() {
        view.addSubview(imageView)
        view.addSubview(selectImageButton)
        view.addSubview(confidenceLabel)
        view.addSubview(confidenceSlider)
        view.addSubview(activityIndicator)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.7),

            selectImageButton.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            selectImageButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            selectImageButton.widthAnchor.constraint(equalToConstant: 150),

            confidenceLabel.topAnchor.constraint(equalTo: selectImageButton.bottomAnchor, constant: 20),
            confidenceLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),

            confidenceSlider.centerYAnchor.constraint(equalTo: confidenceLabel.centerYAnchor),
            confidenceSlider.leadingAnchor.constraint(equalTo: confidenceLabel.trailingAnchor, constant: 10),
            confidenceSlider.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            confidenceSlider.widthAnchor.constraint(greaterThanOrEqualToConstant: 200), // Ensure slider has space

            activityIndicator.centerXAnchor.constraint(equalTo: imageView.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: imageView.centerYAnchor)
        ])

        selectImageButton.target = self
        selectImageButton.action = #selector(selectImageTapped)

        confidenceSlider.target = self
        confidenceSlider.action = #selector(confidenceSliderChanged)
    }

    private func setupModel() {
        do {
            let model = try GroceryDetectorModel(configuration: MLModelConfiguration())
            objectDetector = try VNCoreMLModel(for: model.model)

            detectionRequest = VNCoreMLRequest(model: objectDetector!) { [weak self] request, error in
                self?.processDetections(for: request, error: error)
            }
            // For object detection, .scaleFit is often appropriate to preserve aspect ratio
            detectionRequest?.imageCropAndScaleOption = .scaleFit
        } catch {
            print("Failed to load Vision ML model: \(error)")
            // Display error to user if possible
        }
    }

    // MARK: - Image Selection
    @objc private func selectImageTapped() {
        let openPanel = NSOpenPanel()
        openPanel.canChooseFiles = true
        openPanel.canChooseDirectories = false
        openPanel.allowsMultipleSelection = false
        openPanel.allowedFileTypes = ["png", "jpg", "jpeg", "heic"]

        openPanel.begin { [weak self] response in
            guard response == .OK, let url = openPanel.url else { return }

            Task { @MainActor in // Ensure UI updates are on the main actor
                self?.activityIndicator.startAnimation(nil)
                self?.imageView.image = nil // Clear previous image and detections
            }

            // Perform image loading and detection asynchronously
            Task {
                if let image = NSImage(contentsOf: url) {
                    await self?.detectObjects(in: image)
                } else {
                    await MainActor.run {
                        self?.activityIndicator.stopAnimation(nil)
                        // Display error to user
                    }
                }
            }
        }
    }

    // MARK: - Object Detection
    private func detectObjects(in image: NSImage) async {
        guard let detectionRequest = detectionRequest else {
            await MainActor.run {
                self.activityIndicator.stopAnimation(nil)
                // Display error to user
            }
            return
        }

        // Vision framework can work directly with CGImage
        guard let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
            await MainActor.run {
                self.activityIndicator.stopAnimation(nil)
                // Display error to user
            }
            return
        }

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        do {
            try handler.perform([detectionRequest])
            await MainActor.run {
                self.imageView.image = image // Set image after detection is performed
                // Detections will be set in processDetections and trigger redraw
            }
        } catch {
            await MainActor.run {
                self.activityIndicator.stopAnimation(nil)
                // Display error to user
                print("Failed to perform object detection: \(error)")
            }
        }
    }

    // MARK: - Process Detection Results
    private func processDetections(for request: VNRequest, error: Error?) {
        Task { @MainActor in // Ensure UI updates are on the main actor
            activityIndicator.stopAnimation(nil)
            if let error = error {
                print("Object Detection Error: \(error)")
                // Display error to user
                return
            }

            guard let observations = request.results as? [VNRecognizedObjectObservation] else {
                print("No object detection results.")
                return
            }

            // Update the custom NSImageView with detections and trigger redraw
            imageView.detections = observations
            imageView.needsDisplay = true // Force redraw to show bounding boxes
        }
    }

    // MARK: - Confidence Threshold Challenge
    @objc private func confidenceSliderChanged() {
        let newThreshold = confidenceSlider.floatValue
        confidenceLabel.stringValue = String(format: "Confidence Threshold: %.2f", newThreshold)
        imageView.confidenceThreshold = newThreshold
        imageView.needsDisplay = true // Redraw detections with new threshold
    }
}
