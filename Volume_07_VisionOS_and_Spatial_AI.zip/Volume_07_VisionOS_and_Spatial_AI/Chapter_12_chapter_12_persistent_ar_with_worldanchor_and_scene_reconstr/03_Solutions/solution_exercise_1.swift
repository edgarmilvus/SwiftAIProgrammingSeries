
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import ARKit
import RealityKit
import SwiftUI

@MainActor
class AnchorManager: ObservableObject {
    let session = ARKitSession()
    let worldTracking = WorldTrackingProvider()
    
    @Published var isSessionRunning = false

    func startSession() async {
        do {
            try await session.run([worldTracking])
            isSessionRunning = true
        } catch {
            print("Failed to start ARKit session: \(error)")
        }
    }

    /// Performs a raycast and places an anchor if a surface is hit
    func placeAnchor(at point: CGPoint, in realityView: RealityViewContent) async {
        // 1. Perform a raycast from the 2D screen point into the 3D world
        // We look for estimated planes or existing mesh surfaces
        let raycastResults = await worldTracking.raycast(from: point, allowing: .estimatedPlane, alignment: .any)
        
        guard let firstResult = raycastResults.first else {
            print("No surface detected at this point.")
            return
        }

        // 2. Create an AnchorEntity using the transform from the raycast result.
        // This ties the entity to a specific point in the physical environment.
        let anchor = AnchorEntity(world: firstResult.worldTransform)
        
        // 3. Create a simple visual representation (a floating sphere)
        let sphereMesh = MeshResource.generateSphere(radius: 0.05)
        let material = SimpleMaterial(color: .systemBlue, isMetallic: true)
        let sphereEntity = ModelEntity(mesh: sphereMesh, materials: [material])
        
        // 4. Attach the sphere to the anchor and add the anchor to the scene
        anchor.addChild(sphereEntity)
        realityView.add(anchor)
        
        print("Anchor placed at: \(firstResult.worldTransform.columns.3)")
    }
}

struct AnchorPlacementView: View {
    @StateObject private var manager = AnchorManager()

    var body: some View {
        RealityView { content in
            // The session must be started to perform raycasting
        } update: { content in
            // Updates handled via manager
        }
        .gesture(
            SpatialTapGesture()
                .onEnded { value in
                    let location = value.location
                    Task {
                        // In a real app, we'd pass the RealityViewContent via a coordinator or reference
                        // For this exercise, we assume the manager has access to the content
                    }
                }
        )
        .task {
            await manager.startSession()
        }
    }
}
