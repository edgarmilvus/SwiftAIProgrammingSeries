
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation

// A simple struct representing an AI prompt, implicitly Sendable
struct TextPrompt: Sendable {
    let text: String
    let temperature: Double = 0.7
    let maxTokens: Int = 100
}

// A struct representing the result of an AI generation, implicitly Sendable
struct AIGenerationResult: Sendable {
    let text: String
    let finishReason: String // e.g., "stop", "length"
    let tokenCount: Int
}

// An example of a class that needs explicit Sendable conformance
// if it manages internal state that can be mutated concurrently.
// For simple data-holding classes, it might be implicitly Sendable if immutable.
// If it contains mutable state, it would need to be actor-isolated or protected.
@available(iOS 18.0, *)
final class AIContextManager: @unchecked Sendable { // @unchecked Sendable requires manual verification
    private var internalState: [String: Any] = [:]
    private let lock = OSAllocatedUnfairLock() // Using a lock for thread safety

    func updateContext(key: String, value: Any) {
        lock.lock()
        defer { lock.unlock() }
        internalState[key] = value
    }

    func getContext(key: String) -> Any? {
        lock.lock()
        defer { lock.unlock() }
        return internalState[key]
    }
}

// In most AI scenarios, inputs and outputs are value types or immutable reference types,
// making Sendable conformance straightforward.
@available(iOS 18.0, *)
actor InferenceEngine {
    func performInference(prompt: TextPrompt) async throws -> AIGenerationResult {
        // 'prompt' (TextPrompt) is Sendable and can be passed safely.
        // The result (AIGenerationResult) is also Sendable.
        print("Processing prompt: \(prompt.text)")
        // Simulate inference
        try await Task.sleep(for: .milliseconds(500))
        let result = AIGenerationResult(text: "Generated response for '\(prompt.text)'", finishReason: "stop", tokenCount: 20)
        return result
    }
}

@available(iOS 18.0, *)
func runInference() async {
    let engine = InferenceEngine()
    let myPrompt = TextPrompt(text: "Tell me a short story about a brave knight.")
    do {
        let result = try await engine.performInference(prompt: myPrompt)
        print("AI Result: \(result.text)")
    } catch {
        print("Inference error: \(error)")
    }
}
