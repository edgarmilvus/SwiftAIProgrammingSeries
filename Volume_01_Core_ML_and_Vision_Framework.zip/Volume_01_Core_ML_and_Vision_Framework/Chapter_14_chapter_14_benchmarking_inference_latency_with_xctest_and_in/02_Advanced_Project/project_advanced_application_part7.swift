
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part7.swift
// Description: Advanced Application
// ==========================================

/// @available(iOS 17.0, *)
/// Represents a simulated Camera View Controller that dynamically selects an object detection model.
@MainActor // Ensures all UI updates happen on the main thread
class CameraViewController: UIViewController {
    private var currentDetector: ObjectDetectionModel?
    private let dynamicModelSelector = DynamicModelSelector()
    private let logHandle = OSLog(subsystem: "com.example.SmartCameraApp", category: "CameraVC")

    // UI elements (simulated)
    private let statusLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.textColor = .white
        label.backgroundColor = .black.withAlphaComponent(0.5)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .darkGray
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()

        // Simulate a sample image for benchmarking
        guard let sampleImage = UIImage(named: "sample_image") else {
            os_log("Error: 'sample_image.jpg' not found in asset catalog. Please add one.", log: logHandle, type: .error)
            statusLabel.text = "Error: Sample image missing."
            return
        }
        imageView.image = sampleImage

        // Start the dynamic model selection process
        Task {
            await setupDynamicModelSelection(with: sampleImage)
        }
    }

    private func setupUI() {
        view.addSubview(imageView)
        view.addSubview(statusLabel)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            imageView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.7),

            statusLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 10),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            statusLabel.heightAnchor.constraint(equalToConstant: 100)
        ])
    }

    /// Initializes and performs dynamic model selection.
    /// - Parameter sampleImage: The `UIImage` to convert to a `CVPixelBuffer` for benchmarking.
    func setupDynamicModelSelection(with sampleImage: UIImage) async {
        statusLabel.text = "Initializing models and benchmarking..."
        os_log("Attempting to load candidate models.", log: logHandle, type: .info)

        var candidateModels: [ObjectDetectionModel] = []
        do {
            candidateModels.append(try FastObjectDetector())
            candidateModels.append(try AccurateObjectDetector())
            os_log("Successfully loaded %d candidate models.", log: logHandle, type: .info, candidateModels.count)
        } catch {
            os_log("Failed to load one or more models: %{public}s", log: logHandle, type: .error, error.localizedDescription)
            statusLabel.text = "Error loading models: \(error.localizedDescription)"
            return
        }

        guard let samplePixelBuffer = sampleImage.toCVPixelBuffer() else {
            os_log("Failed to convert sample image to CVPixelBuffer.", log: logHandle, type: .error)
            statusLabel.text = "Error: Could not prepare sample image."
            return
        }

        do {
            os_log("Starting dynamic model selection process...", log: logHandle, type: .info)
            let optimalModel = try await dynamicModelSelector.selectOptimalModel(
                models: candidateModels,
                samplePixelBuffer: samplePixelBuffer,
                iterations: 5,
                targetLatencyThreshold: 0.08 // Aim for < 80ms for real-time
            )

            if let model = optimalModel {
                currentDetector = model
                statusLabel.text = "Optimal model selected: \(model.modelIdentifier).\nReady for detection!"
                os_log("Camera initialized with optimal model: %{public}s", log: logHandle, type: .info, model.modelIdentifier)
                // Now, you would start your AVCaptureSession and use `currentDetector`
                // for real-time inference on incoming frames.
                await performInitialDetection(with: samplePixelBuffer, using: model)
            } else {
                statusLabel.text = "Could not determine optimal model. Using fallback (e.g., FastDetector)."
                os_log("Failed to select optimal model. Falling back to FastDetector.", log: logHandle, type: .warning)
                currentDetector = candidateModels.first(where: { $0.modelIdentifier == "FastDetector" })
            }
        } catch {
            statusLabel.text = "Error during model selection: \(error.localizedDescription)"
            os_log("Error during model selection: %{public}s", log: logHandle, type: .error, error.localizedDescription)
        }
    }

    /// Performs an initial detection using the selected model on the sample image.
    /// This simulates the first frame processing.
    /// - Parameters:
    ///   - pixelBuffer: The `CVPixelBuffer` to process.
    ///   - model: The selected `ObjectDetectionModel`.
    func performInitialDetection(with pixelBuffer: CVPixelBuffer, using model: ObjectDetectionModel) async {
        statusLabel.text = "Performing initial detection with \(model.modelIdentifier)..."
        do {
            let observations = try await model.predict(pixelBuffer: pixelBuffer)
            let detectionCount = observations.count
            statusLabel.text = "Selected model: \(model.modelIdentifier).\nDetected \(detectionCount) objects."
            os_log("Initial detection with %{public}s: Found %d objects.", log: logHandle, type: .info, model.modelIdentifier, detectionCount)
            // In a real app, you would draw bounding boxes on the imageView
            // For now, we'll just log and update status.
        } catch {
            statusLabel.text = "Error during initial detection: \(error.localizedDescription)"
            os_log("Error during initial detection with %{public}s: %{public}s", log: logHandle, type: .error, model.modelIdentifier, error.localizedDescription)
        }
    }
}
