
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import RealityKit
import ARKit
import Foundation

enum GrabState {
    case idle
    case dragging(targetEntity: Entity, offset: SIMD3<Float>)
}

/// Actor to manage grab state safely across threads
actor SpatialGrabManager {
    private(set) var state: GrabState = .idle
    
    func updateState(_ newState: GrabState) {
        state = newState
    }
}

@MainActor
class GrabController {
    private let grabManager = SpatialGrabManager()
    private let pinchThreshold: Float = 0.02 // 2cm between thumb and index
    private var smoothingFactor: Float = 0.2 // Lower is smoother/slower
    
    func update(
        handTracking: HandTrackingProvider, 
        scene: Scene
    ) async {
        guard let handAnchor = handTracking.handAnchors.first else {
            await grabManager.updateState(.idle)
            return
        }
        
        let thumbTip = handAnchor.handSkeleton.transform(for: .thumbTip)
        let indexTip = handAnchor.handSkeleton.transform(for: .indexFingerTip)
        
        // 1. Detect Pinch
        let pinchDistance = simd_distance(thumbTip.translation, indexTip.translation)
        let isPinching = pinchDistance < pinchThreshold
        
        let currentState = await grabManager.state
        
        switch currentState {
        case .idle:
            if isPinching {
                // 2. Hit Testing: Find if we are pinching an object
                // (Simplified: assume we found an entity via raycast)
                if let entity = performHitTest(at: handAnchor.transform.translation) {
                    let offset = entity.position(relativeTo: nil) - handAnchor.transform.translation
                    await grabManager.updateState(.dragging(targetEntity: entity, offset: offset))
                }
            }
            
        case .dragging(let entity, let offset):
            if !isPinching {
                await grabManager.updateState(.idle)
            } else {
                // 3. The Drag with Offset and Smoothing
                let targetPosition = handAnchor.transform.translation + offset
                let currentPosition = entity.position(relativeTo: nil)
                
                // Linear Interpolation (Lerp) for smoothing
                let smoothedPosition = simd_mix(currentPosition, targetPosition, SIMD3<Float>(repeating: smoothingFactor))
                
                entity.position = smoothedPosition
            }
        }
    }
    
    private func performHitTest(at position: SIMD3<Float>) -> Entity? {
        // Logic for raycasting or proximity check to find grabbable entities
        return nil // Implementation placeholder
    }
}
