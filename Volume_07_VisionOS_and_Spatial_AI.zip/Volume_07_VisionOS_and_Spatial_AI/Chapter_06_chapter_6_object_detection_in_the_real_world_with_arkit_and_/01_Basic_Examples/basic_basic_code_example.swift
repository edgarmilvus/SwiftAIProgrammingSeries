
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import AVFoundation
import Vision

// MARK: - Models

/// Represents a detected object in the real world.
/// Conforms to `Sendable` to safely pass data across concurrency boundaries.
struct DetectedObject: Identifiable, Sendable {
    let id = UUID()
    let label: String
    let confidence: Float
    let boundingBox: CGRect
}

// MARK: - Detection Engine

/// The `ObjectDetectionEngine` is responsible for processing video frames
/// and running Vision requests.
@available(iOS 18.0, *)
final class ObjectDetectionEngine: NSObject, ObservableObject {
    
    /// Published property to notify the UI of new detections.
    @Published var detectedObjects: [DetectedObject] = []
    
    /// The capture session that manages the camera hardware.
    private let captureSession = AVCaptureSession()
    
    /// A serial dispatch queue to handle video frames off the main thread.
    /// Using a dedicated queue prevents UI stuttering.
    private let videoDataQueue = DispatchQueue(label: "com.spatialai.videoQueue", qos: .userInteractive)
    
    /// The Vision request used for object detection.
    private var detectionRequest: VNCoreMLRequest?

    override init() {
        super.init()
        setupDetectionRequest()
        setupCaptureSession()
    }

    /// Configures the Vision request with a pre-trained model.
    /// In a real app, you would load a custom .mlmodel file here.
    private func setupDetectionRequest() {
        // For this example, we use the built-in animal detection model provided by Vision
        // to ensure the code is runnable without external assets.
        guard let model = try? VNCoreMLModel(for: SqueezeNet(configuration: .init()).model) else {
            print("Failed to load CoreML model")
            return
        }

        // Create the request
        let request = VNCoreMLRequest(model: model) { [weak self] request, error in
            self?.processDetectionResults(for: request, error: error)
        }
        
        // Ensure the request uses the Neural Engine for maximum efficiency
        request.preferBackgroundProcessing = false
        self.detectionRequest = request
    }

    /// Sets up the AVFoundation pipeline.
    private func setupCaptureSession() {
        captureSession.beginConfiguration()
        
        // 1. Select the camera input
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let videoDeviceInput = try? AVCaptureDeviceInput(device: videoDevice),
              captureSession.canAddInput(videoDeviceInput) else {
            return
        }
        captureSession.addInput(videoDeviceInput)

        // 2. Set up the video data output
        let videoOutput = AVCaptureVideoDataOutput()
        // We use BGRA format as it is highly optimized for Vision/CoreML processing
        videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        videoOutput.setSampleBufferDelegate(self, queue: videoDataQueue)

        guard captureSession.canAddOutput(videoOutput) else { return }
        captureSession.addOutput(videoOutput)
        
        captureSession.commitConfiguration()
    }

    /// Starts the camera stream.
    func start() {
        // Run the session on a background thread to avoid blocking the caller
        Task.detached(priority: .userInitiated) {
            self.captureSession.startRunning()
        }
    }

    /// Processes the results from the Vision request.
    /// - Parameters:
    ///   - request: The Vision request that produced the results.
    ///   - error: An error if the inference failed.
    private func processDetectionResults(for request: VNRequest, error: Error?) {
        // Always check for errors in the async pipeline
        guard error == nil, let observations = request.results as? [VNRecognizedObjectObservation] else {
            return
        }

        // Map Vision observations to our Sendable DetectedObject model
        let newDetections = observations.map { observation in
            DetectedObject(
                label: observation.labels.first?.identifier ?? "Unknown",
                confidence: observation.confidence,
                boundingBox: observation.boundingBox // Note: This is in normalized coordinates (0-1)
            )
        }

        // CRITICAL: Update the @Published property on the @MainActor
        Task { @MainActor in
            self.detectedObjects = newDetections
        }
    }
}

// MARK: - AVCaptureVideoDataOutputDelegate

extension ObjectDetectionEngine: AVCaptureVideoDataOutputSampleBufferDelegate {
    /// This delegate method is called for every single frame captured by the camera.
    /// Performance here is critical; do not perform heavy logic on the main thread.
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // 1. Ensure we have a valid pixel buffer
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // 2. Ensure the detection request is ready
        guard let request = detectionRequest else { return }

        // 3. Create a Vision request handler to process the current frame
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .right, options: [:])

        do {
            // 4. Perform the request (this is the heavy inference step)
            try handler.perform([request])
        } catch {
            print("Vision error: \(error.localizedDescription)")
        }
    }
}

// MARK: - UI Layer

/// A view that draws bounding boxes over the camera feed.
struct DetectionOverlayView: View {
    let objects: [DetectedObject]

    var body: some View {
        GeometryReader { geometry in
            ForEach(objects) { object in
                // Convert normalized Vision coordinates to SwiftUI view coordinates
                let rect = convertNormalizedToView(
                    normalizedRect: object.boundingBox,
                    viewSize: geometry.size
                )
                
                ZStack {
                    // The Bounding Box
                    Rectangle()
                        .stroke(Color.green, lineWidth: 3)
                        .background(Color.green.opacity(0.2))
                        .frame(width: rect.width, height: rect.height)
                        .position(x: rect.midX, y: rect.midY)

                    // The Label
                    Text("\(object.label) \(Int(object.confidence * 100))%")
                        .font(.caption.bold())
                        .padding(4)
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(4)
                        .position(x: rect.midX, y: rect.minY - 10)
                }
            }
        }
    }

    /// Converts Vision's normalized (0.0 to 1.0) coordinates to the view's coordinate space.
    /// Vision's origin is BOTTOM-LEFT; SwiftUI's origin is TOP-LEFT.
    private func convertNormalizedToView(normalizedRect: CGRect, viewSize: CGSize) -> CGRect {
        return CGRect(
            x: normalizedRect.origin.x * viewSize.width,
            // Flip the Y-axis: 1.0 - y_normalized
            y: (1.0 - normalizedRect.origin.y - normalizedRect.height) * viewSize.height,
            width: normalizedRect.width * viewSize.width,
            height: normalizedRect.height * viewSize.height
        )
    }
}

/// The main entry point for the application.
struct ContentView: View {
    @StateObject private var engine = ObjectDetectionEngine()

    var body: some View {
        ZStack {
            // In a production app, you would use a custom UIViewRepresentable 
            // to show the AVCaptureVideoPreviewLayer.
            Color.black.ignoresSafeArea()
            
            Text("Camera Preview Placeholder")
                .foregroundColor(.white)

            // Overlay the detection boxes
            DetectionOverlayView(objects: engine.detectedObjects)
        }
        .onAppear {
            engine.start()
        }
    }
}
