/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// components/Skeleton.tsx
import React from 'react';
import './Skeleton.css'; // Assuming CSS for animation

interface SkeletonProps {
  count: number;
  className?: string;
}

export function Skeleton({ count, className }: SkeletonProps) {
  // Render 'count' number of placeholder elements with pulsing animation
  return (
    <div>
      {Array.from({ length: count }).map((_, index) => (
        <div 
          key={index} 
          className={`skeleton-bar ${className}`} 
          style={{ height: '20px', marginBottom: '8px', borderRadius: '4px' }}
        />
      ))}
    </div>
  );
}

// components/UserAnalytics.tsx
'use client';

import { useState, useEffect } from 'react';
import { Skeleton } from './Skeleton';

// 1. Define strict interface for data
interface AnalyticsData {
  userId: string;
  activity: number;
}

// Define a type for the component state
type FetchState = {
  data: AnalyticsData[] | null;
  isLoading: boolean;
  error: string | null;
};

export function UserAnalytics() {
  // 2. Handle states (Loading, Error, Success) using a state machine approach
  const [state, setState] = useState<FetchState>({
    data: null,
    isLoading: false,
    error: null,
  });

  useEffect(() => {
    const fetchData = async () => {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      
      try {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Mock data response
        const mockData: AnalyticsData[] = [
          { userId: 'user_1', activity: 85 },
          { userId: 'user_2', activity: 45 },
          { userId: 'user_3', activity: 92 },
        ];
        
        setState({ data: mockData, isLoading: false, error: null });
      } catch (err) {
        setState({ data: null, isLoading: false, error: "Failed to fetch analytics data." });
      }
    };

    fetchData();
  }, []);

  // 3. Render logic based on state
  if (state.isLoading) {
    // Progressive Loading: Show Skeleton UI
    return (
      <div className="analytics-container">
        <h3>User Activity</h3>
        <Skeleton count={5} className="animate-pulse" />
      </div>
    );
  }

  if (state.error) {
    return <div className="error-alert">Error: {state.error}</div>;
  }

  if (!state.data) {
    return <div>No data available.</div>;
  }

  // Success State
  return (
    <div className="analytics-container">
      <h3>User Activity</h3>
      <div className="data-grid">
        {state.data.map((item) => (
          <div key={item.userId} className="data-row">
            <span>User: {item.userId}</span>
            <span>Activity Score: {item.activity}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// To integrate with code splitting (as requested in requirements):
// export default dynamic(() => Promise.resolve(UserAnalytics), { ssr: false });
