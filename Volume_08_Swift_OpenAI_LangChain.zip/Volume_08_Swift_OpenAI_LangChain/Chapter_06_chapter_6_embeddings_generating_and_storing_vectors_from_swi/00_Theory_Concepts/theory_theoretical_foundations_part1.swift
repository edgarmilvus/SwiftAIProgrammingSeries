
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Accelerate

/// Represents a point in high-dimensional semantic space.
/// Conforms to Sendable to allow safe transfer across actor boundaries.
@available(iOS 18.0, macOS 15.0, *)
public struct SemanticVector: Sendable, Identifiable {
    public let id: UUID
    public let values: [Float]
    public let dimension: Int

    public init(id: UUID = UUID(), values: [Float]) {
        self.id = id
        self.values = values
        self.dimension = values.count
    }
}

/// An error type specific to embedding operations.
public enum EmbeddingError: Error {
    case dimensionMismatch
    case networkFailure
    case modelInferenceError
}

/// The EmbeddingEngine is responsible for the transformation of text to vectors.
/// We use an actor to ensure that any local model state (if using Core ML)
/// is isolated and thread-safe.
@available(iOS 18.0, macOS 15.0, *)
public actor EmbeddingEngine {
    private let dimension: Int
    
    public init(dimension: Int = 1536) {
        self.dimension = dimension
    }

    /// Generates an embedding for a given string.
    /// This is an async function to handle the inherent latency of the process.
    public func generateEmbedding(for text: String) async throws -> SemanticVector {
        // In a real-world scenario, this would call an OpenAI API 
        // or run a local Core ML model.
        
        // Simulating network/inference latency
        try await Task.sleep(for: .seconds(0.5))
        
        // Mocking a vector for demonstration
        let mockValues = (0..<dimension).map { _ in Float.random(in: -1...1) }
        return SemanticVector(values: mockValues)
    }
}

/// A VectorStore manages the collection of embeddings.
/// It uses an actor to protect the underlying storage from concurrent access.
@available(iOS 18.0, macOS 15.0, *)
public actor VectorStore {
    private var storage: [SemanticVector] = []
    
    public init() {}

    /// Adds a vector to the store.
    public func insert(_ vector: SemanticVector) {
        storage.append(vector)
    }

    /// Performs a similarity search.
    /// Returns the most similar vectors to the query.
    public func findNearest(to query: SemanticVector, limit: Int = 5) -> [SemanticVector] {
        // In a production app, we would use an HNSW (Hierarchical Navigable Small World) 
        // algorithm or a specialized vector DB. 
        // Here, we perform a brute-force linear scan for theoretical clarity.
        
        let sorted = storage.sorted { v1, v2 in
            cosineSimilarity(query, v1) > cosineSimilarity(query, v2)
        }
        
        return Array(sorted.prefix(limit))
    }

    /// Calculates the cosine similarity between two vectors using the Accelerate framework.
    /// This is the 'Under the Hood' implementation of the mathematical theory.
    private func cosineSimilarity(_ a: SemanticVector, _ b: SemanticVector) -> Float {
        guard a.dimension == b.dimension else { return 0.0 }
        
        // Using Accelerate's vDSP (Digital Signal Processing) for high-performance math.
        // This is significantly faster than a standard Swift loop.
        var dotProduct: Float = 0
        vDSP_dotpr(a.values, 1, b.values, 1, &dotProduct, vDSP_Length(a.dimension))
        
        var normA: Float = 0
        vDSP_svesq(a.values, 1, &normA, vDSP_Length(a.dimension))
        
        var normB: Float = 0
        vDSP_svesq(b.values, 1, &normB, vDSP_Length(b.dimension))
        
        // normA and normB are the sum of squares; we need the square root.
        return dotProduct / (sqrt(normA) * sqrt(normB))
    }
}
