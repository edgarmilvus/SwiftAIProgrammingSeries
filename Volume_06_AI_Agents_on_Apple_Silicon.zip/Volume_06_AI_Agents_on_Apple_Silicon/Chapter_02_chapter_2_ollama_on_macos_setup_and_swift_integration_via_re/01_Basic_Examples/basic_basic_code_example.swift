
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import SwiftUI

// MARK: - Ollama Data Models

/// Represents the structure of a request to Ollama's /api/generate endpoint.
///
/// This struct conforms to `Encodable` to allow easy conversion into JSON data
/// for the HTTP request body.
struct OllamaGenerateRequest: Encodable {
    let model: String     // The name of the model to use (e.g., "llama2", "mistral")
    let prompt: String    // The user's input prompt for the model
    let stream: Bool      // Whether to stream the response (false for a single complete response)
    // You can add more parameters here as needed, like 'options' for temperature, top_k, etc.
    // For simplicity, we'll keep it basic for this example.
}

/// Represents the structure of a response from Ollama's /api/generate endpoint.
///
/// This struct conforms to `Decodable` to allow easy parsing of the JSON data
/// received from the HTTP response.
struct OllamaGenerateResponse: Decodable {
    let model: String
    let createdAt: String
    let response: String // The actual generated text from the LLM
    let done: Bool
    // Other fields like 'context', 'total_duration', 'load_duration', etc.,
    // can be added here if needed for more advanced use cases.
}

// MARK: - OllamaService

/// A service class responsible for interacting with the local Ollama server.
///
/// Uses `URLSession` for network requests and `Codable` for JSON serialization/deserialization.
@Observable // Makes this class observable for SwiftUI views in iOS 17+/macOS 14+
@MainActor // Ensures all state changes and network callbacks are on the main actor
class OllamaService {
    // The base URL for the local Ollama server.
    // Ensure Ollama is running and accessible at this address.
    private let baseURL = URL(string: "http://localhost:11434")!
    
    // Published properties to hold the current prompt and the AI's response.
    // Marked with @Published (or @Observable) to trigger UI updates.
    var currentPrompt: String = ""
    var responseText: String = "Ask Ollama something..."
    var isLoading: Bool = false
    var errorMessage: String?
    
    /// Sends a prompt to the specified Ollama model and retrieves a response.
    ///
    /// - Parameters:
    ///   - prompt: The user's input string.
    ///   - model: The name of the Ollama model to use (e.g., "llama2").
    /// - Throws: An `Error` if the network request fails, encoding/decoding fails,
    ///           or the server returns an error.
    func generateResponse(prompt: String, model: String = "llama2") async {
        isLoading = true
        errorMessage = nil
        responseText = "" // Clear previous response
        
        do {
            // 1. Construct the request URL
            let url = baseURL.appendingPathComponent("api/generate")
            
            // 2. Create the request body payload
            let requestBody = OllamaGenerateRequest(model: model, prompt: prompt, stream: false)
            
            // 3. Encode the request body to JSON
            let encoder = JSONEncoder()
            encoder.keyEncodingStrategy = .convertToSnakeCase // Ollama expects snake_case keys
            let jsonData = try encoder.encode(requestBody)
            
            // 4. Create the URLRequest
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = jsonData
            
            // 5. Perform the network request using async/await
            let (data, response) = try await URLSession.shared.data(for: request)
            
            // 6. Validate the HTTP response
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                let status = (response as? HTTPURLResponse)?.statusCode ?? -1
                let errorData = String(data: data, encoding: .utf8) ?? "No error data"
                throw OllamaError.serverError(statusCode: status, message: errorData)
            }
            
            // 7. Decode the JSON response
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase // Ollama responds with snake_case keys
            let ollamaResponse = try decoder.decode(OllamaGenerateResponse.self, from: data)
            
            // 8. Update the UI-bound response text
            self.responseText = ollamaResponse.response
            
        } catch {
            // 9. Handle and display errors
            self.errorMessage = "Error: \(error.localizedDescription)"
            print("OllamaService Error: \(error)")
        }
        
        isLoading = false
    }
    
    // Custom error type for better error handling
    enum OllamaError: LocalizedError {
        case serverError(statusCode: Int, message: String)
        case invalidResponse
        
        var errorDescription: String? {
            switch self {
            case .serverError(let code, let message):
                return "Ollama Server Error \(code): \(message)"
            case .invalidResponse:
                return "Invalid response from Ollama server."
            }
        }
    }
}

// MARK: - ContentView (SwiftUI)

/// The main SwiftUI view for our local chat interface.
///
/// This view provides a text field for user input, a button to send the prompt,
/// and a text area to display the AI's response.
@available(iOS 17.0, macOS 14.0, *) // Requires modern SwiftUI features like @Observable
struct ContentView: View {
    // State object to manage the lifecycle of our OllamaService.
    // @StateObject for older iOS versions, @State + @Observable for newer.
    @State private var ollamaService = OllamaService()
    
    var body: some View {
        VStack(spacing: 20) {
            // Title
            Text("Local Ollama Chat")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            // Input field for the prompt
            TextField("Enter your prompt here...", text: $ollamaService.currentPrompt, axis: .vertical)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
                .lineLimit(5) // Allow multiline input
            
            // Send button
            Button {
                // Trigger the async response generation when the button is tapped
                Task {
                    await ollamaService.generateResponse(prompt: ollamaService.currentPrompt)
                }
            } label: {
                Text(ollamaService.isLoading ? "Generating..." : "Send to Ollama")
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(ollamaService.isLoading ? Color.gray : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .disabled(ollamaService.currentPrompt.isEmpty || ollamaService.isLoading) // Disable if prompt is empty or loading
            .padding(.horizontal)
            
            // Display area for Ollama's response
            ScrollView {
                Text(ollamaService.responseText)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.secondary.opacity(0.1))
                    .cornerRadius(8)
            }
            .padding(.horizontal)
            
            // Display error messages if any
            if let errorMessage = ollamaService.errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding(.horizontal)
            }
        }
        .padding()
        .frame(minWidth: 400, minHeight: 400) // For macOS window sizing
    }
}

// MARK: - App Entry Point

@main
@available(iOS 17.0, macOS 14.0, *)
struct OllamaChatApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
