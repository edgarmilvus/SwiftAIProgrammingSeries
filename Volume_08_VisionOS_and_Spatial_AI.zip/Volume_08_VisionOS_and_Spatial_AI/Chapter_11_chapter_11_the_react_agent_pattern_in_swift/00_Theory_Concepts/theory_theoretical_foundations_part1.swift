
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

/// Represents the various stages of a ReAct cycle.
/// Conforming to Sendable ensures these can be passed between 
/// the Agent Actor and the UI Layer.
@available(iOS 18.0, *)
enum AgentStep: Sendable, Hashable {
    case thought(String)
    case action(toolName: String, parameters: [String: String])
    case observation(String)
    case finalAnswer(String)
}

/// A container for the agent's entire cognitive history.
@available(iOS 18.0, *)
struct AgentMemory: Sendable {
    let steps: [AgentStep]
    
    var lastStep: AgentStep? {
        steps.last
    }
}

/// The protocol defining what a 'Tool' is in the ReAct ecosystem.
/// Tools must be Sendable because they are invoked by the Agent Actor
/// but often execute on background threads.
@available(iOS 18.0, *)
protocol ReActTool: Sendable {
    var name: String { get }
    var description: String { get }
    func execute(parameters: [String: String]) async throws -> String
}
