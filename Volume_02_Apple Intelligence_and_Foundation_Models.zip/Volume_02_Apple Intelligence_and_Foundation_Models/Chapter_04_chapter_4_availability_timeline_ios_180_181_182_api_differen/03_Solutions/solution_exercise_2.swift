
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import WritingTools // For WritingToolsService and TextEditingRequest
import UIKit        // For UI elements

// Ensure the entire class is only compiled and available on iOS 18.0 and later.
@available(iOS 18.0, *)
class RichTextEditorViewController: UIViewController {

    // MARK: - UI Elements

    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.font = .preferredFont(forTextStyle: .body)
        textView.text = "This is some example text that needs refinement. It contains a few grammatical errors and could be more concise. Let's try to improve it using Apple's Writing Tools."
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 0.5
        textView.layer.cornerRadius = 5
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
    }()

    private lazy var refineButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Refine Selection", for: .normal)
        button.addTarget(self, action: #selector(refineSelectionTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    // MARK: - UI Setup

    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "Pro Notes Editor"

        view.addSubview(textView)
        view.addSubview(refineButton)

        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.5), // Take up half the screen

            refineButton.topAnchor.constraint(equalTo: textView.bottomAnchor, constant: 20),
            refineButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            refineButton.widthAnchor.constraint(equalToConstant: 200),
            refineButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    // MARK: - Writing Tools Integration

    @objc private func refineSelectionTapped() {
        // Ensure there's selected text
        guard let selectedRange = textView.selectedTextRange,
              let selectedText = textView.text(in: selectedRange),
              !selectedText.isEmpty else {
            presentAlert(title: "No Text Selected", message: "Please select some text in the editor to refine.")
            return
        }

        // Store the original selection range to restore after editing
        let originalNSRange = NSRange(selectedRange, in: textView.textStorage)

        // Create a TextEditingRequest with the selected text
        let request = TextEditingRequest(text: selectedText)

        // Present the Writing Tools UI
        WritingToolsService.shared.present(request: request, from: self) { [weak self] result in
            guard let self = self else { return }

            switch result {
            case .success(let editedText):
                // Ensure UI updates happen on the main thread
                DispatchQueue.main.async {
                    // Replace the selected text with the edited text
                    self.textView.textStorage.replaceCharacters(in: originalNSRange, with: editedText)

                    // Optionally, re-select the newly inserted text
                    if let newSelectedRange = self.textView.textStorage.rangeOfBytes(in: NSRange(location: originalNSRange.location, length: editedText.count)) {
                        self.textView.selectedRange = newSelectedRange
                    }
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    self.presentAlert(title: "Refinement Failed", message: "Error: \(error.localizedDescription)")
                }
                print("Writing Tools error: \(error)")
            case .cancelled:
                print("Writing Tools operation cancelled by user.")
            @unknown default:
                // Handle future cases gracefully
                fatalError("Unhandled result case from WritingToolsService.")
            }
        }
    }

    // MARK: - Helper

    private func presentAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
