
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 18.0, *)
    func trainModelAsync(model: SimpleLinearModel, optimizer: Adam, epochs: Int, data: (x: MLXArray, y: MLXArray)) async {
        for epoch in 0..<epochs {
            // Perform one training step
            let (loss, gradients) = valueAndGradient(mseLoss)(model, data.x, data.y)
            optimizer.update(model: model, gradients: gradients)
            MLXArray.eval(model.parameters(), optimizer.parameters()) // Explicitly evaluate
            print("Epoch \(epoch), Loss: \(loss.item())")
            // Potentially yield control to the system to keep UI responsive
            await Task.yield()
        }
    }

    // Usage:
    // Task {
    //     await trainModelAsync(model: myModel, optimizer: myOptimizer, epochs: 10, data: (x_data, y_data))
    //     print("Training complete!")
    // }
    