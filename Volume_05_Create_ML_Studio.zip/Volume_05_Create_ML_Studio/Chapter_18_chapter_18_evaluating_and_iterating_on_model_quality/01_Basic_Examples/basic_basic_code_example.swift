
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CoreML
import Vision
import UIKit // For UIImage and image data handling
import Combine // For potential future UI updates or data flow, though not strictly used in this basic example

/// Represents a simple Fruit Classification Service that uses a Core ML model.
/// This class handles the loading of the model, image preprocessing, and prediction.
@available(iOS 18.0, *) // Targeting latest SDK for demonstration
class FruitClassifierService {

    private var model: VNCoreMLModel?

    /// Initializes the FruitClassifierService by loading the Core ML model.
    /// - Throws: An error if the model cannot be loaded or initialized.
    init() throws {
        guard let coreMLModel = try? MyFruitClassifier(configuration: MLModelConfiguration()).model else {
            // This error indicates a problem with the generated MyFruitClassifier class or the .mlmodel file.
            throw FruitClassifierError.modelLoadingFailed
        }
        self.model = try VNCoreMLModel(for: coreMLModel)
        print("MyFruitClassifier model loaded successfully.")
    }

    /// Performs fruit classification on a given UIImage.
    /// - Parameter image: The UIImage to classify.
    /// - Returns: A tuple containing the top predicted label and its confidence, or nil if classification fails.
    /// - Throws: A FruitClassifierError if image processing or classification encounters an issue.
    func classifyFruit(image: UIImage) async throws -> (label: String, confidence: Float)? {
        guard let model = self.model else {
            throw FruitClassifierError.modelNotInitialized
        }

        // 1. Prepare the image for Vision processing.
        // Vision typically expects a CIImage or CGImage.
        guard let cgImage = image.cgImage else {
            throw FruitClassifierError.invalidImageInput
        }

        // 2. Create a Vision request for our Core ML model.
        // VNCoreMLRequest is the standard way to integrate Core ML models with Vision.
        let request = VNCoreMLRequest(model: model) { [weak self] request, error in
            guard let self = self else { return } // Ensure self is still alive

            if let error = error {
                print("Fruit classification request failed with error: \(error.localizedDescription)")
                // In a real app, you might want to surface this error to the user or a more robust logging system.
                return
            }

            // 3. Process the results.
            // VNClassificationObservation contains the predicted labels and confidence scores.
            guard let observations = request.results as? [VNClassificationObservation] else {
                print("No classification observations found.")
                return
            }

            // Get the top prediction (highest confidence).
            if let topObservation = observations.first {
                print("Prediction: \(topObservation.identifier) (Confidence: \(topObservation.confidence * 100.0)%)")
                // This is where you would typically update UI or store the result.
                // For this example, we'll just print it.
            } else {
                print("No confident prediction found.")
            }
        }

        // Optional: Configure image preprocessing.
        // Create ML models often expect specific image sizes (e.g., 299x299 for InceptionV3).
        // Vision handles scaling automatically, but you can control aspects like aspect ratio.
        request.imageCropAndScaleOption = .centerCrop // Common for many image classifiers

        // 4. Perform the request using VNImageRequestHandler.
        // This handler takes the image and performs the Vision requests.
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        do {
            try handler.perform([request])
            // The results are available in the request's completion handler.
            // To make this an async function, we need to await the completion.
            // For simplicity in this basic example, we'll let the completion handler print directly.
            // In a real async scenario, you'd use a continuation or a Combine Future.

            // To truly make this `async throws -> (label: String, confidence: Float)?`,
            // we need to bridge the callback-based Vision API to async/await.
            // Let's refactor the request to use `withCheckedThrowingContinuation`.
            return try await withCheckedThrowingContinuation { continuation in
                let asyncRequest = VNCoreMLRequest(model: model) { request, error in
                    if let error = error {
                        continuation.resume(throwing: FruitClassifierError.classificationFailed(error.localizedDescription))
                        return
                    }

                    guard let observations = request.results as? [VNClassificationObservation],
                          let topObservation = observations.first else {
                        continuation.resume(returning: nil) // No confident prediction
                        return
                    }
                    continuation.resume(returning: (label: topObservation.identifier, confidence: topObservation.confidence))
                }
                asyncRequest.imageCropAndScaleOption = .centerCrop

                let asyncHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
                do {
                    try asyncHandler.perform([asyncRequest])
                } catch {
                    continuation.resume(throwing: FruitClassifierError.visionRequestFailed(error.localizedDescription))
                }
            }

        } catch {
            throw FruitClassifierError.visionRequestFailed(error.localizedDescription)
        }
    }
}

/// Custom error types for the FruitClassifierService.
enum FruitClassifierError: Error, LocalizedError {
    case modelLoadingFailed
    case modelNotInitialized
    case invalidImageInput
    case classificationFailed(String)
    case visionRequestFailed(String)

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed:
            return "Failed to load the Core ML model. Ensure 'MyFruitClassifier.mlmodel' is correctly included and compiled."
        case .modelNotInitialized:
            return "The Core ML model was not initialized."
        case .invalidImageInput:
            return "The provided UIImage could not be converted to a CGImage for processing."
        case .classificationFailed(let details):
            return "Fruit classification failed: \(details)"
        case .visionRequestFailed(let details):
            return "Vision request failed: \(details)"
        }
    }
}

// --- Usage Example (e.g., in a ViewController or SwiftUI View) ---

// Assume you have a MyFruitClassifier.mlmodel file in your project.
// Create ML generates a Swift class named MyFruitClassifier for it.

@available(iOS 18.0, *)
class ViewController: UIViewController { // Or a ViewModel in SwiftUI

    var classifierService: FruitClassifierService?
    var cancellables = Set<AnyCancellable>() // For Combine, if used

    override func viewDidLoad() {
        super.viewDidLoad()
        setupClassifier()
        // Simulate a user taking a picture or selecting one from the gallery
        // For demonstration, we'll load an image from the app bundle.
        // Make sure you have an image named "apple.jpg" in your Asset Catalog or bundle.
        if let appleImage = UIImage(named: "apple") {
            Task {
                await classifyImage(appleImage)
            }
        } else {
            print("Error: 'apple.jpg' not found in assets. Please add an image for testing.")
        }
    }

    /// Sets up the FruitClassifierService.
    private func setupClassifier() {
        do {
            classifierService = try FruitClassifierService()
        } catch {
            print("Failed to initialize FruitClassifierService: \(error.localizedDescription)")
            // Handle error, e.g., show an alert to the user.
        }
    }

    /// Performs classification on a given image and prints the result.
    /// - Parameter image: The UIImage to classify.
    private func classifyImage(_ image: UIImage) async {
        guard let service = classifierService else {
            print("Classifier service not available.")
            return
        }

        print("\n--- Starting Classification ---")
        do {
            if let (label, confidence) = try await service.classifyFruit(image: image) {
                print("Final Classification Result: \(label) with \(String(format: "%.2f", confidence * 100))% confidence.")
                // Here, you would update your UI (e.g., a UILabel or Text view)
                // Example: myResultLabel.text = "It's a \(label)! (\(String(format: "%.1f", confidence * 100))%)"
            } else {
                print("Could not classify the fruit confidently.")
            }
        } catch {
            print("Classification failed: \(error.localizedDescription)")
            // Handle specific errors, e.g., show an error message to the user.
        }
        print("--- Classification Finished ---\n")
    }
}

// --- Placeholder for your generated Core ML model ---
// You would drag your MyFruitClassifier.mlmodel file into your Xcode project.
// Xcode automatically generates a Swift class for it.
// For this example to compile, you'd need a dummy class if you don't have the actual model yet.
/*
// Dummy class for compilation if MyFruitClassifier.mlmodel is not present
class MyFruitClassifier {
    static let url: URL = URL(fileURLWithPath: "path/to/your/model.mlmodel") // Placeholder
    init(configuration: MLModelConfiguration) throws {
        // Dummy implementation
    }
    var model: MLModel {
        // Return a dummy MLModel or throw an error
        fatalError("MyFruitClassifier.mlmodel not loaded. This is a dummy class.")
    }
}
*/
