
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_7.swift
// Description: Solution for Exercise 7
// ==========================================

// MARK: - Create ML Model Generation (Run this in an Xcode Playground)
import CreateML
import Foundation

// 1. Prepare your dataset (simulated data for sentence-level feature identification)
// Each sentence is labeled with the *primary* feature it describes.
// For true NER (sequence tagging), data would be token-level, which Create ML Text Classifier doesn't directly support.
let featureData: [[String: String]] = [
    ["text": "The 6.1-inch Liquid Retina display is vibrant.", "feature_type": "ScreenFeature"],
    ["text": "Battery life lasts all day, easily 18 hours.", "feature_type": "BatteryFeature"],
    ["text": "Powered by the A17 Bionic chip.", "feature_type": "ProcessorFeature"],
    ["text": "It boasts a stunning 12MP Ultra Wide camera.", "feature_type": "CameraFeature"],
    ["text": "The device comes with 128GB of storage.", "feature_type": "StorageFeature"],
    ["text": "New model features a 6.7-inch OLED panel.", "feature_type": "ScreenFeature"],
    ["text": "Expect up to 24 hours of video playback.", "feature_type": "BatteryFeature"],
    ["text": "Equipped with the powerful M2 chip.", "feature_type": "ProcessorFeature"],
    ["text": "Dual 48-megapixel cameras for pro photography.", "feature_type": "CameraFeature"],
    ["text": "Available in 256GB and 512GB options.", "feature_type": "StorageFeature"],
    ["text": "The resolution is 2532 by 1170 pixels.", "feature_type": "ScreenFeature"],
    ["text": "Fast charging capability is a plus.", "feature_type": "BatteryFeature"],
    ["text": "Runs on the latest Snapdragon 8 Gen 2.", "feature_type": "ProcessorFeature"],
    ["text": "Improved low-light performance on the main lens.", "feature_type": "CameraFeature"],
    ["text": "Comes with 8GB RAM as standard.", "feature_type": "MemoryFeature"], // Added MemoryFeature
    ["text": "A beautiful Super Retina XDR display.", "feature_type": "ScreenFeature"],
    ["text": "Long-lasting power for your daily tasks.", "feature_type": "BatteryFeature"],
    ["text": "The new Neural Engine is incredibly fast.", "feature_type": "ProcessorFeature"],
    ["text": "Capture stunning detail with the telephoto lens.", "feature_type": "CameraFeature"],
    ["text": "You get ample space for all your files.", "feature_type": "StorageFeature"],
    ["text": "This phone has a durable ceramic shield front cover.", "feature_type": "Other"], // Example of 'Other'
    ["text": "The design is sleek and modern.", "feature_type": "Other"],
    ["text": "It features a water and dust resistant design.", "feature_type": "Other"],
    ["text": "The sound quality is immersive.", "feature_type": "Other"]
]

// Convert to MLDataTable
let dataTable = try! MLDataTable(array: featureData)

// Split into training and testing data
let (trainingData, testingData) = dataTable.randomSplit(by: 0.8, seed: 456)

// 2. Train the text classifier
let classifier = try! MLTextClassifier(trainingData: trainingData,
                                       textColumn: "text",
                                       labelColumn: "feature_type")

// 3. Evaluate the model (optional)
let evaluationMetrics = classifier.evaluation(on: testingData, textColumn: "text", labelColumn: "feature_type")
print("Validation Accuracy: \(evaluationMetrics.accuracy)")

// 4. Save the model
let modelURL = URL(fileURLWithPath: "/tmp/FeatureIdentifier.mlmodel") // Change path as needed
try! classifier.write(to: modelURL)
print("Model saved to: \(modelURL.path)")

// Drag the generated FeatureIdentifier.mlmodel from /tmp/ to your Xcode project.
