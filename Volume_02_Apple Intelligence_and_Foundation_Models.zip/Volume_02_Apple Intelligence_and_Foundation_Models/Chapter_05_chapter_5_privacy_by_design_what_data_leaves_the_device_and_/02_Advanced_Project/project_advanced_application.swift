
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import TextUnderstanding // Apple's framework for on-device text intelligence
// import FoundationModels // Apple's framework for interacting with server-side foundation models (conceptual for this example)

// NOTE: TextUnderstanding and FoundationModels are system frameworks in iOS 18+.
// They are not typically included via Swift Package Manager as external dependencies,
// but rather linked directly in your Xcode project's target settings.

// MARK: - 1. Data Models

/// Represents a scanned document, containing its raw text content.
/// The `PrivacySensitiveContent` annotation is crucial here, indicating that the `content`
/// field holds data that should not be used for learning or transmitted off-device
/// without explicit user consent. This is a Swift 6 feature for Apple Intelligence.
@available(iOS 18.0, *)
struct DocumentScan: Identifiable {
    let id = UUID()
    /// The raw text content of the document. Marked as privacy-sensitive.
    @PrivacySensitiveContent var content: String
    /// An optional title for the document.
    let title: String?
    /// The date the document was scanned.
    let scanDate: Date

    init(content: String, title: String? = nil, scanDate: Date = Date()) {
        self._content = .init(wrappedValue: content) // Initialize PrivacySensitiveContent
        self.title = title
        self.scanDate = scanDate
    }
}

/// Represents the result of on-device analysis.
@available(iOS 18.0, *)
struct LocalAnalysisResult {
    let extractedEntities: [String: [String]] // e.g., ["Dates": ["2023-10-26"], "Names": ["John Doe"]]
    let summary: String
    let confidenceScore: Double // How confident the on-device model is
    let requiresAdvancedAnalysis: Bool // Flag if local analysis wasn't sufficient
}

/// Represents the result of off-device analysis.
@available(iOS 18.0, *)
struct AdvancedAnalysisResult {
    let detailedSummary: String
    let classification: String // e.g., "Legal Contract", "Financial Statement"
    let recommendedActions: [String]
}

// MARK: - 2. Custom Errors

/// Custom error types for privacy-related and processing failures.
@available(iOS 18.0, *)
enum DocumentProcessorError: Error, LocalizedError {
    case onDeviceAnalysisFailed(String)
    case offDeviceAnalysisDenied
    case offDeviceAnalysisFailed(String)
    case privacyViolationAttempted(String)
    case invalidDocumentContent

    var errorDescription: String? {
        switch self {
        case .onDeviceAnalysisFailed(let reason):
            return "On-device analysis failed: \(reason)"
        case .offDeviceAnalysisDenied:
            return "Off-device analysis was explicitly denied by the user."
        case .offDeviceAnalysisFailed(let reason):
            return "Advanced off-device analysis failed: \(reason)"
        case .privacyViolationAttempted(let detail):
            return "A privacy violation was attempted: \(detail). Data transmission aborted."
        case .invalidDocumentContent:
            return "Document content is empty or invalid for processing."
        }
    }
}

// MARK: - 3. Privacy-Aware Document Processor Class

/// Manages the processing of documents, prioritizing on-device analysis and
/// carefully mediating off-device interactions with user consent.
@available(iOS 18.0, *)
actor PrivacyAwareDocumentProcessor {

    /// Initializes the processor.
    /// In a real app, you might inject dependencies here (e.g., specific configurations
    /// for TextUnderstanding or a client for FoundationModels).
    init() {
        // Initialization for TextUnderstanding is often implicit or via static methods.
        // For FoundationModels, you'd typically configure a client instance here.
    }

    /// Performs initial, privacy-preserving analysis of a document entirely on-device.
    /// - Parameter document: The `DocumentScan` object containing the content.
    /// - Returns: A `LocalAnalysisResult` if successful.
    /// - Throws: `DocumentProcessorError.onDeviceAnalysisFailed` if local processing fails.
    ///
    /// **Under the Hood:**
    /// This method leverages Apple's `TextUnderstanding` framework to perform tasks like
    /// entity extraction and summarization. Because `DocumentScan.content` is marked with
    /// `@PrivacySensitiveContent`, the `TextUnderstanding` framework is aware that this
    /// data should not leave the device, be used for model training, or be stored persistently
    /// in ways that violate user privacy. This is a key "Privacy by Design" mechanism.
    func processDocumentLocally(document: DocumentScan) async throws -> LocalAnalysisResult {
        guard !document.content.isEmpty else {
            throw DocumentProcessorError.invalidDocumentContent
        }

        print("[\(document.title ?? "Untitled")] Starting on-device analysis...")
        do {
            // Simulate on-device entity extraction using TextUnderstanding
            let entityExtractor = TextUnderstanding.EntityExtractor()
            let entities = try await entityExtractor.extract(text: document.content)
            
            var extractedEntities: [String: [String]] = [:]
            for entity in entities {
                // Simplified type extraction for demonstration
                let type = String(describing: type(of: entity)).replacingOccurrences(of: "TextUnderstanding.", with: "")
                extractedEntities[type, default: []].append(entity.description)
            }

            // Simulate on-device summarization using TextUnderstanding
            let summarizer = TextUnderstanding.Summarizer()
            let summary = try await summarizer.summarize(text: document.content, maxLength: 150)

            let confidence = Double.random(in: 0.7...0.95) // Simulate confidence
            let requiresAdvanced = confidence < 0.85 || summary.count < 50 // Example logic for needing more

            print("[\(document.title ?? "Untitled")] On-device analysis complete. Summary: '\(summary.prefix(50))...'")
            return LocalAnalysisResult(
                extractedEntities: extractedEntities,
                summary: summary,
                confidenceScore: confidence,
                requiresAdvancedAnalysis: requiresAdvanced
            )
        } catch {
            print("[\(document.title ?? "Untitled")] On-device analysis failed: \(error.localizedDescription)")
            throw DocumentProcessorError.onDeviceAnalysisFailed(error.localizedDescription)
        }
    }

    /// Determines if a document *should* be considered for off-device advanced analysis.
    /// This decision is based on the results of local analysis and the app's requirements.
    ///
    /// **The "Why":**
    /// This method embodies the "Privacy by Design" principle of data minimization.
    /// We only *consider* sending data off-device if the on-device capabilities
    /// are insufficient for the user's goal. This prevents unnecessary data exposure.
    /// - Parameters:
    ///   - document: The original `DocumentScan`.
    ///   - localAnalysisResult: The result from `processDocumentLocally`.
    /// - Returns: `true` if off-device analysis is recommended, `false` otherwise.
    func shouldOfferAdvancedAnalysis(document: DocumentScan, localAnalysisResult: LocalAnalysisResult) -> Bool {
        // Example logic: Offer advanced analysis if local confidence is low
        // or if the local summary is too brief, or if specific entities were not found.
        let needsMoreDetail = localAnalysisResult.requiresAdvancedAnalysis
        let userPreferenceForDetail = true // In a real app, this would be a user setting

        if needsMoreDetail && userPreferenceForDetail {
            print("[\(document.title ?? "Untitled")] Local analysis indicates a need for advanced processing.")
            return true
        }
        print("[\(document.title ?? "Untitled")] Local analysis is sufficient, no advanced processing offered.")
        return false
    }

    /// Sends a *carefully curated and anonymized* portion of the document for advanced off-device analysis.
    /// This method explicitly requires user consent and performs data minimization.
    ///
    /// **The "How" and "When":**
    /// This is the critical privacy gate. Data only leaves the device `when`
    /// the user has given `explicitConsent` and `how` it leaves is controlled
    /// by the `preparePayloadForOffDevice` function, which ensures data minimization.
    ///
    /// **Under the Hood (Conceptual `FoundationModels` or custom API):**
    /// While `FoundationModels` is an Apple framework, its interaction often involves
    /// server-side components. This method simulates that interaction, emphasizing
    /// the developer's responsibility to prepare the data appropriately.
    /// - Parameters:
    ///   - document: The original `DocumentScan`.
    ///   - explicitConsent: A boolean indicating if the user has explicitly consented.
    ///   - specificQuery: An optional query for the advanced model (e.g., "Summarize this for a lawyer").
    /// - Returns: An `AdvancedAnalysisResult` if successful.
    /// - Throws: `DocumentProcessorError.offDeviceAnalysisDenied` if consent is false,
    ///           `DocumentProcessorError.offDeviceAnalysisFailed` if the remote call fails,
    ///           `DocumentProcessorError.privacyViolationAttempted` if internal checks fail.
    func sendForAdvancedAnalysis(
        document: DocumentScan,
        explicitConsent: Bool,
        specificQuery: String? = nil
    ) async throws -> AdvancedAnalysisResult {
        guard explicitConsent else {
            print("[\(document.title ?? "Untitled")] Off-device analysis denied by user.")
            throw DocumentProcessorError.offDeviceAnalysisDenied
        }

        print("[\(document.title ?? "Untitled")] User consented. Preparing data for advanced analysis...")

        // CRITICAL PRIVACY STEP: Prepare the payload for off-device transmission.
        // This function would implement anonymization, truncation, or extraction
        // of *only* the non-sensitive parts relevant to the advanced query.
        let offDevicePayload = try preparePayloadForOffDevice(
            originalContent: document.content,
            specificQuery: specificQuery
        )

        guard !offDevicePayload.isEmpty else {
            throw DocumentProcessorError.invalidDocumentContent
        }

        // Simulate interaction with a remote Foundation Model or custom server API
        print("[\(document.title ?? "Untitled")] Sending \(offDevicePayload.count) characters off-device for advanced analysis...")
        do {
            // In a real app, this would be an API call to FoundationModels or your backend.
            // Example: let advancedResult = try await FoundationModels.shared.analyze(payload: offDevicePayload, query: specificQuery)
            
            // Simulate network delay and processing
            try await Task.sleep(for: .seconds(Double.random(in: 1.0...3.0)))

            // Simulate a successful response
            let detailedSummary = "Advanced summary for '\(document.title ?? "Untitled")': \(offDevicePayload.prefix(50))... (more detail from server)"
            let classification = specificQuery?.contains("lawyer") == true ? "Legal Contract (Expert)" : "General Document"
            let actions = ["Review key clauses", "Follow up with sender"]

            print("[\(document.title ?? "Untitled")] Advanced analysis complete.")
            return AdvancedAnalysisResult(
                detailedSummary: detailedSummary,
                classification: classification,
                recommendedActions: actions
            )
        } catch {
            print("[\(document.title ?? "Untitled")] Off-device analysis failed: \(error.localizedDescription)")
            throw DocumentProcessorError.offDeviceAnalysisFailed(error.localizedDescription)
        }
    }

    /// Helper function to prepare the data payload for off-device transmission.
    /// This is where data minimization and anonymization strategies are applied.
    ///
    /// **The "What" Data Leaves the Device:**
    /// This function is the gatekeeper for what specific data elements are allowed
    /// to leave the device. It should *never* send the raw `PrivacySensitiveContent`
    /// unless explicitly designed to do so with multiple layers of consent and warnings.
    /// For this example, we simulate extracting a non-sensitive snippet or a query.
    /// - Parameters:
    ///   - originalContent: The full, privacy-sensitive content of the document.
    ///   - specificQuery: The user's specific query for advanced analysis.
    /// - Returns: A string representing the minimized, potentially anonymized payload.
    /// - Throws: `DocumentProcessorError.privacyViolationAttempted` if an unsafe operation is detected.
    private func preparePayloadForOffDevice(originalContent: String, specificQuery: String?) throws -> String {
        // CRITICAL: This is a placeholder for actual anonymization/minimization logic.
        // In a real app, you would:
        // 1. Use `TextUnderstanding` again to extract *only* non-sensitive concepts.
        // 2. Truncate the content to the absolute minimum required for the query.
        // 3. Replace PII (Personally Identifiable Information) with placeholders.
        // 4. Send only the `specificQuery` if the model can operate on that alone.

        // For demonstration, we'll simulate sending a non-sensitive query or a very short,
        // generalized snippet, explicitly avoiding the full `originalContent`.
        if let query = specificQuery, !query.isEmpty {
            // If the query itself is sufficient, send only the query.
            return "Query: \(query)"
        } else {
            // Otherwise, send a very short, generalized snippet.
            // This is a simplification; real anonymization is complex.
            let safeSnippet = originalContent
                .prefix(100) // Truncate to first 100 characters
                .replacingOccurrences(of: "John Doe", with: "[PERSON_NAME]") // Simple anonymization
                .replacingOccurrences(of: "$", with: "AMOUNT_SYMBOL") // Example of sanitization
            print("   -> Payload for off-device: '\(safeSnippet)...'")
            return String(safeSnippet)
        }
    }
}

// MARK: - 4. Example Usage in an App Context

/// A hypothetical view model or application coordinator demonstrating the processor's use.
/// This would typically be an `ObservableObject` in a SwiftUI application.
@available(iOS 18.0, *)
class DocumentScannerAppCoordinator: ObservableObject {
    @Published var documents: [DocumentScan] = []
    @Published var processingStatus: String = "Ready"
    @Published var localAnalysisResults: [UUID: LocalAnalysisResult] = [:]
    @Published var advancedAnalysisResults: [UUID: AdvancedAnalysisResult] = [:]
    @Published var showConsentAlert: Bool = false
    @Published var documentAwaitingConsent: DocumentScan?
    @Published var advancedQueryForConsent: String?

    private let processor = PrivacyAwareDocumentProcessor()

    /// Simulates scanning a new document.
    /// - Parameters:
    ///   - content: The raw text content of the document.
    ///   - title: The title of the document.
    func scanNewDocument(content: String, title: String) {
        let newDocument = DocumentScan(content: content, title: title)
        documents.append(newDocument)
        Task { await processDocument(newDocument) }
    }

    /// Processes a document, starting with local analysis.
    /// - Parameter document: The `DocumentScan` to process.
    private func processDocument(_ document: DocumentScan) async {
        DispatchQueue.main.async { self.processingStatus = "Processing '\(document.title ?? "Untitled")' locally..." }
        do {
            let localResult = try await processor.processDocumentLocally(document: document)
            DispatchQueue.main.async {
                self.localAnalysisResults[document.id] = localResult
                self.processingStatus = "Local analysis for '\(document.title ?? "Untitled")' complete."

                // Check if advanced analysis is needed and offer consent
                if self.processor.shouldOfferAdvancedAnalysis(document: document, localAnalysisResult: localResult) {
                    self.documentAwaitingConsent = document
                    self.advancedQueryForConsent = "Provide a detailed summary and classification."
                    self.showConsentAlert = true // Trigger UI alert for consent
                }
            }
        } catch {
            DispatchQueue.main.async {
                self.processingStatus = "Error processing '\(document.title ?? "Untitled")' locally: \(error.localizedDescription)"
            }
        }
    }

    /// Handles user's consent decision for advanced analysis.
    /// - Parameters:
    ///   - document: The document for which consent was requested.
    ///   - granted: `true` if consent was given, `false` otherwise.
    ///   - query: The specific query for advanced analysis.
    func handleConsent(for document: DocumentScan, granted: Bool, query: String?) async {
        DispatchQueue.main.async {
            self.showConsentAlert = false
            self.documentAwaitingConsent = nil
            self.advancedQueryForConsent = nil
        }

        guard granted else {
            DispatchQueue.main.async {
                self.processingStatus = "Advanced analysis for '\(document.title ?? "Untitled")' denied by user."
            }
            return
        }

        DispatchQueue.main.async { self.processingStatus = "Sending '\(document.title ?? "Untitled")' for advanced analysis (with consent)..." }
        do {
            let advancedResult = try await processor.sendForAdvancedAnalysis(
                document: document,
                explicitConsent: granted,
                specificQuery: query
            )
            DispatchQueue.main.async {
                self.advancedAnalysisResults[document.id] = advancedResult
                self.processingStatus = "Advanced analysis for '\(document.title ?? "Untitled")' complete."
            }
        } catch {
            DispatchQueue.main.async {
                self.processingStatus = "Error during advanced analysis for '\(document.title ?? "Untitled")': \(error.localizedDescription)"
            }
        }
    }
}

// MARK: - Example of how you might use it in a SwiftUI View (Conceptual)

/*
import SwiftUI

@available(iOS 18.0, *)
struct DocumentScannerView: View {
    @StateObject private var coordinator = DocumentScannerAppCoordinator()
    @State private var documentText: String = ""
    @State private var documentTitle: String = ""

    var body: some View {
        NavigationView {
            VStack {
                TextField("Document Title", text: $documentTitle)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                TextEditor(text: $documentText)
                    .frame(minHeight: 100)
                    .border(Color.gray, width: 1)
                    .padding()

                Button("Scan Document") {
                    guard !documentText.isEmpty else { return }
                    coordinator.scanNewDocument(content: documentText, title: documentTitle.isEmpty ? "Untitled Document" : documentTitle)
                    documentText = ""
                    documentTitle = ""
                }
                .padding()

                Text(coordinator.processingStatus)
                    .padding()
                    .font(.caption)

                List(coordinator.documents) { doc in
                    VStack(alignment: .leading) {
                        Text(doc.title ?? "Untitled Document").font(.headline)
                        if let localResult = coordinator.localAnalysisResults[doc.id] {
                            Text("Local Summary: \(localResult.summary.prefix(100))...")
                                .font(.subheadline)
                            Text("Local Confidence: \(localResult.confidenceScore, specifier: "%.2f")")
                                .font(.caption)
                        }
                        if let advancedResult = coordinator.advancedAnalysisResults[doc.id] {
                            Text("Advanced Summary: \(advancedResult.detailedSummary.prefix(100))...")
                                .font(.subheadline)
                                .foregroundColor(.blue)
                            Text("Classification: \(advancedResult.classification)")
                                .font(.caption)
                        }
                    }
                }
            }
            .navigationTitle("Smart Document Scanner")
            .alert("Advanced Analysis Needed", isPresented: $coordinator.showConsentAlert, presenting: coordinator.documentAwaitingConsent) { document in
                Button("Allow (Send Minimal Data)") {
                    Task {
                        if let doc = coordinator.documentAwaitingConsent, let query = coordinator.advancedQueryForConsent {
                            await coordinator.handleConsent(for: doc, granted: true, query: query)
                        }
                    }
                }
                Button("Deny", role: .cancel) {
                    Task {
                        if let doc = coordinator.documentAwaitingConsent {
                            await coordinator.handleConsent(for: doc, granted: false, query: nil)
                        }
                    }
                }
            } message: { document in
                Text("Local analysis for '\(document.title ?? "Untitled")' was not fully conclusive. Do you want to send a *minimal, anonymized* snippet for advanced analysis? This will use a server-side model.")
            }
        }
    }
}
*/
