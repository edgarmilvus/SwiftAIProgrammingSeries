
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import MLX // For context on MLX framework

@available(iOS 18.0, macOS 15.0, *)
struct WeatherTool {
    let name: String = "get_current_weather"
    let description: String = "Fetches the current weather conditions for a specified city. Requires a 'city' parameter (String)."

    private let mockWeatherData: [String: String] = [
        "London": "Cloudy, 10°C, light rain.",
        "New York": "Sunny, 22°C, clear skies.",
        "Tokyo": "Partly cloudy, 18°C, gentle breeze.",
        "Paris": "Overcast, 15°C, chance of showers.",
        "Sydney": "Warm, 28°C, high humidity."
    ]

    /// Simulates fetching current weather for a given city.
    /// - Parameter city: The name of the city.
    /// - Returns: A descriptive string of the weather, or nil if the city is not found.
    func getCurrentWeather(forCity city: String) -> String? {
        return mockWeatherData[city]
    }
}

@available(iOS 18.0, macOS 15.0, *)
class WeatherToolDispatcher {
    private let weatherTool = WeatherTool()

    // MARK: - Decodable Structures for LLM Output Parsing

    /// Represents the arguments for the weather tool.
    struct WeatherArguments: Decodable {
        let city: String
    }

    /// Represents a generic tool call structure from the LLM.
    struct ToolCall: Decodable {
        let name: String
        let arguments: WeatherArguments // Specific to WeatherTool
    }

    /// Represents the overall LLM output containing a tool call.
    struct LLMOutput: Decodable {
        let tool_call: ToolCall
    }

    /// Dispatches a tool call based on the LLM's simulated output.
    /// - Parameter llmOutputJson: A JSON string representing the LLM's decision to call a tool.
    /// - Returns: A string representing the result of the tool call or an error message.
    func dispatchToolCall(llmOutputJson: String) -> String {
        guard let jsonData = llmOutputJson.data(using: .utf8) else {
            return "Error: Invalid JSON string."
        }

        do {
            let llmOutput = try JSONDecoder().decode(LLMOutput.self, from: jsonData)
            let toolCall = llmOutput.tool_call

            if toolCall.name == weatherTool.name {
                let city = toolCall.arguments.city
                if let weather = weatherTool.getCurrentWeather(forCity: city) {
                    return "Here's the weather for \(city): \(weather)"
                } else {
                    return "Sorry, I couldn't find weather data for \(city). Please try another city."
                }
            } else {
                return "Error: Unknown tool '\(toolCall.name)'."
            }
        } catch {
            return "Error parsing LLM output: \(error.localizedDescription)"
        }
    }
}

// Example Usage:
/*
@available(iOS 18.0, macOS 15.0, *)
func runWeatherExercise() {
    let dispatcher = WeatherToolDispatcher()

    // Simulate LLM output for "What's the weather in London?"
    let llmOutput1 = """
    {
      "tool_call": {
        "name": "get_current_weather",
        "arguments": {
          "city": "London"
        }
      }
    }
    """
    print("User query: What's the weather in London?")
    print("LLM output (simulated): \(llmOutput1)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput1))\n")

    // Simulate LLM output for "Weather in Tokyo?"
    let llmOutput2 = """
    {
      "tool_call": {
        "name": "get_current_weather",
        "arguments": {
          "city": "Tokyo"
        }
      }
    }
    """
    print("User query: Weather in Tokyo?")
    print("LLM output (simulated): \(llmOutput2)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput2))\n")

    // Simulate LLM output for an unknown city
    let llmOutput3 = """
    {
      "tool_call": {
        "name": "get_current_weather",
        "arguments": {
          "city": "Mars"
        }
      }
    }
    """
    print("User query: What's the weather on Mars?")
    print("LLM output (simulated): \(llmOutput3)")
    print("Tool dispatcher response: \(dispatcher.dispatchToolCall(llmOutputJson: llmOutput3))\n")
}

// runWeatherExercise()
*/
