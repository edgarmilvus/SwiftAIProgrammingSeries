/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// File: components/UserAvatar.tsx
// This component demonstrates the basic usage of the React Native Image component.
// It is designed to work in a universal app context (Next.js Web + Expo Mobile).

import React from 'react';
import { Image, StyleSheet, View, Text } from 'react-native';

/**
 * Props for the UserAvatar component.
 * @property {string} avatarUrl - The URL of the user's avatar image.
 * @property {string} userName - The name of the user for accessibility/alt text.
 */
type UserAvatarProps = {
  avatarUrl: string;
  userName: string;
};

/**
 * A simple component displaying a user's avatar.
 * 
 * Why this structure?
 * In React Native, images do not automatically size themselves to their content
 * like they do in HTML. You must provide dimensions or use specific layout strategies.
 */
const UserAvatar: React.FC<UserAvatarProps> = ({ avatarUrl, userName }) => {
  return (
    <View style={styles.container}>
      {/* 
        The Image Component:
        - source: Accepts an object with a 'uri' property for remote images.
        - resizeMode: Determines how the image is resized to fit its container.
          'cover' (default) scales the image to fill the container, cropping excess.
        - fadeDuration: Controls the fade-in animation (default 300ms). 
          Setting to 0 can make the UI feel snappier but jarring.
      */}
      <Image
        source={{ uri: avatarUrl }}
        style={styles.avatar}
        resizeMode="cover"
        fadeDuration={300} 
        accessibilityLabel={`${userName}'s avatar`}
      />
      
      <Text style={styles.label}>{userName}</Text>
    </View>
  );
};

// Styling is required to give the image physical dimensions.
// Unlike CSS, React Native styles are not cascading by default.
const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5',
    borderRadius: 12,
    margin: 10,
    width: 120, // Fixed width for simplicity
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40, // Circular image
    marginBottom: 8,
    // In a real app, you might add a background color as a placeholder
    backgroundColor: '#e1e4e8', 
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
});

export default UserAvatar;

// File: App.tsx (Usage Example)
// This demonstrates how to consume the component in a root file.

import React from 'react';
import { SafeAreaView, StatusBar } from 'react-native';
import UserAvatar from './components/UserAvatar';

export default function App() {
  // Example usage with a placeholder image service
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
      <StatusBar barStyle="dark-content" />
      <UserAvatar 
        avatarUrl="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
        userName="Alex Developer"
      />
    </SafeAreaView>
  );
}
