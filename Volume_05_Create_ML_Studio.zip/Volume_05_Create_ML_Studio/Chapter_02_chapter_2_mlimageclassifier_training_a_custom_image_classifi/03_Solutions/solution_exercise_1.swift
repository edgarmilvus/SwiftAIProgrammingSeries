
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Vision
import CoreML
import PhotosUI // For modern image picking

// 1. Model Training (Conceptual - performed in Create ML)
//    - Assume 'PetBreedClassifier.mlmodel' is trained and added to the Xcode project.
//    - It classifies images into categories like "Golden Retriever", "Pug", "Siamese", "Persian".

struct PetBreedIdentifierView: View {
    @State private var selectedImage: UIImage?
    @State private var classificationResult: String = "Select an image to classify."
    @State private var showingImagePicker = false
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary

    // Use PhotosPicker for iOS 16+ for a modern image selection experience
    @State private var selectedPhotoItem: PhotosPickerItem?

    var body: some View {
        NavigationView {
            VStack {
                if let image = selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 300)
                        .padding()
                } else {
                    Image(systemName: "photo.on.rectangle.angled")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                        .foregroundColor(.gray)
                        .padding()
                }

                Text(classificationResult)
                    .font(.headline)
                    .padding()

                Spacer()

                HStack {
                    Button("Select from Library") {
                        if #available(iOS 16, *) {
                            // Use PhotosPicker
                            selectedPhotoItem = nil // Reset
                        } else {
                            // Fallback to UIImagePickerController for older iOS
                            sourceType = .photoLibrary
                            showingImagePicker = true
                        }
                    }
                    .buttonStyle(.borderedProminent)

                    if UIImagePickerController.isSourceTypeAvailable(.camera) {
                        Button("Take Photo") {
                            sourceType = .camera
                            showingImagePicker = true
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
                .padding()
            }
            .navigationTitle("Pet Breed Identifier")
            .onChange(of: selectedPhotoItem) { newItem in
                Task {
                    if let data = try? await newItem?.loadTransferable(type: Data.self),
                       let uiImage = UIImage(data: data) {
                        selectedImage = uiImage
                        await classifyImage(uiImage)
                    }
                }
            }
            .sheet(isPresented: $showingImagePicker) {
                ImagePicker(selectedImage: $selectedImage, isPresented: $showingImagePicker, sourceType: sourceType)
            }
            .photosPicker(isPresented: .init(get: {
                // Only show PhotosPicker if not showing UIImagePickerController and on iOS 16+
                #available(iOS 16, *)
                return !showingImagePicker && selectedPhotoItem == nil && sourceType == .photoLibrary
            }, set: { newValue in
                if #available(iOS 16, *) {
                    if !newValue { selectedPhotoItem = nil } // Dismissal logic
                }
            }), selection: $selectedPhotoItem, matching: .images)
        }
    }

    // Function to perform Core ML inference
    @MainActor // Ensure UI updates on the main thread
    private func classifyImage(_ image: UIImage) async {
        classificationResult = "Classifying..."

        guard let ciImage = CIImage(image: image) else {
            classificationResult = "Error: Could not convert image to CIImage."
            return
        }

        do {
            // Load the Core ML model
            let config = MLModelConfiguration()
            let model = try PetBreedClassifier(configuration: config)
            let visionModel = try VNCoreMLModel(for: model.model)

            // Create a Vision request
            let request = VNCoreMLRequest(model: visionModel) { request, error in
                if let error = error {
                    self.classificationResult = "Vision error: \(error.localizedDescription)"
                    return
                }

                guard let observations = request.results as? [VNClassificationObservation],
                      let topObservation = observations.first else {
                    self.classificationResult = "No classification results."
                    return
                }

                let confidence = String(format: "%.2f%%", topObservation.confidence * 100)
                self.classificationResult = "Prediction: \(topObservation.identifier) (\(confidence) confident)"
            }

            // Perform the request on a background thread using VNImageRequestHandler
            // This is implicitly handled by the Vision framework's internal dispatch.
            let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])
            try handler.perform([request])

        } catch {
            classificationResult = "Model error: \(error.localizedDescription)"
        }
    }
}

// MARK: - UIImagePickerController Wrapper (for older iOS or camera)
struct ImagePicker: UIViewControllerRepresentable {
    @Binding var selectedImage: UIImage?
    @Binding var isPresented: Bool
    var sourceType: UIImagePickerController.SourceType

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = sourceType
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        var parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                parent.selectedImage = image
                Task { @MainActor in // Use MainActor to ensure UI updates are on the main thread
                    await parent.parent.classifyImage(image)
                }
            }
            parent.isPresented = false
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.isPresented = false
        }
    }
}

// For preview purposes
struct PetBreedIdentifierView_Previews: PreviewProvider {
    static var previews: some View {
        PetBreedIdentifierView()
    }
}
