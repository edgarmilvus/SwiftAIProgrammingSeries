
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CoreData

// Custom Migration Policy to handle the structural split
class TaskToMetadataPolicy: NSEntityMigrationPolicy {
    
    override func createDestinationInstances(forSource sInstance: NSManagedObject, 
                                           in mapping: NSEntityMapping, 
                                           manager: NSMigrationManager) throws {
        
        // 1. Create the Destination Task instance
        let destContext = manager.destinationContext
        let destTask = NSEntityDescription.insertNewObject(forEntityName: mapping.destinationEntityName!, 
                                                           into: destContext)
        
        // 2. Map simple attributes
        destTask.setValue(sInstance.value(forKey: "title"), forKey: "title")
        destTask.setValue(sInstance.value(forKey: "dueDate"), forKey: "dueDate")
        
        // 3. Handle the Structural Shift: Create the Metadata entity
        let metadataEntityName = "TaskMetadata"
        let destMetadata = NSEntityDescription.insertNewObject(forEntityName: metadataEntityName, 
                                                              into: destContext)
        
        // 4. Transfer the priority from the old Task to the new Metadata
        if let priority = sInstance.value(forKey: "priority") {
            destMetadata.setValue(priority, forKey: "priority")
        }
        
        // 5. Establish the One-to-One Relationship
        destTask.setValue(destMetadata, forKey: "metadata")
        
        // 6. Register the association for the manager
        manager.associate(sourceInstance: sInstance, withDestinationInstance: destTask, for: mapping)
    }
}
