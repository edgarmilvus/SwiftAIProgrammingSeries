
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import Foundation // WritingTools leverage Foundation models

@available(iOS 18.0, *)
class JournalEntryViewController: UIViewController {

    let textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = UIFont.preferredFont(forTextStyle: .body)
        tv.isEditable = true // Essential for WritingTools
        tv.isSelectable = true // Essential for WritingTools
        tv.text = "This is a sample journal entry. I want to make sure my thoughts are clear and concise. Sometimes I struggle with finding the right words to express complex ideas, and I hope Apple Intelligence can help me refine my writing without compromising my privacy. This entire process should happen locally on my device."
        tv.backgroundColor = .systemBackground
        tv.layer.cornerRadius = 8
        tv.layer.borderColor = UIColor.systemGray3.cgColor
        tv.layer.borderWidth = 1
        return tv
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Privacy-Focused Journal"
        view.backgroundColor = .systemGroupedBackground

        view.addSubview(textView)
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 300)
        ])

        // No explicit API call is needed to "enable" WritingTools for UITextView.
        // They are automatically available when the system detects an editable and selectable text view
        // on iOS 18.0+ with Apple Intelligence enabled.
        // The user interacts with them via the text selection context menu (long-press or double-tap).

        // For demonstration purposes, you would run this on a device/simulator with iOS 18.0+
        // and interact with the text (select text, then look for options like "Check Writing", "Rephrase", "Summarize").
        print("UITextView initialized. WritingTools will be available via text selection context menu.")
        print("All standard text refinement operations (rephrase, summarize, proofread) provided by WritingTools for this UITextView are processed entirely on-device.")
        print("No user text data leaves the device for these operations.")
    }
}

// To run this in a simple Xcode project:
// 1. Create a new iOS App project (SwiftUI or UIKit).
// 2. If UIKit, set this ViewController as the initial view controller in SceneDelegate or AppDelegate.
//    If SwiftUI, wrap it in a UIViewControllerRepresentable:
/*
import SwiftUI
@available(iOS 18.0, *)
struct JournalEntryViewWrapper: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> JournalEntryViewController {
        return JournalEntryViewController()
    }

    func updateUIViewController(_ uiViewController: JournalEntryViewController, context: Context) {
        // No update needed for this simple example
    }
}

@available(iOS 18.0, *)
#Preview {
    JournalEntryViewWrapper()
}
*/
