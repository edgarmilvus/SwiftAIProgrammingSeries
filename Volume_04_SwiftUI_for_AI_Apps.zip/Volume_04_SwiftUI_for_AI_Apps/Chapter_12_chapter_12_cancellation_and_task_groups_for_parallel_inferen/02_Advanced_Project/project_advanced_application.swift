
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// MARK: - 1. Swift Package Manager Dependencies (Illustrative)
// While this example mocks AI models, in a real application, you might use:
//
// import CoreML // For on-device inference with trained models
// import Vision // For image processing tasks like text recognition
// import NaturalLanguage // For text-based tasks like sentiment analysis
//
// A Package.swift snippet for a hypothetical AI-focused module might look like this:
/*
import PackageDescription

let package = Package(
    name: "AIInferenceModule",
    platforms: [
        .iOS(.v18), .macOS(.v15) // Targeting modern OS versions for latest concurrency features
    ],
    products: [
        .library(
            name: "AIInferenceModule",
            targets: ["AIInferenceModule"]),
    ],
    dependencies: [
        // No external dependencies for this specific example,
        // but here's where you'd list them, e.g.:
        // .package(url: "https://github.com/apple/swift-algorithms", from: "1.0.0"),
        // .package(url: "https://github.com/google/swift-protobuf", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "AIInferenceModule",
            dependencies: []),
    ]
)
*/

import Foundation // For Error, UUID, Data, etc.

// MARK: - 2. Custom Errors

/// Custom error types for document processing and AI inference.
enum DocumentProcessingError: Error, LocalizedError {
    case ocrFailed(pageIndex: Int, underlyingError: Error)
    case classificationFailed(pageIndex: Int, underlyingError: Error)
    case sentimentAnalysisFailed(pageIndex: Int, underlyingError: Error)
    case unknownInferenceError(pageIndex: Int, task: String)
    case pageProcessingCancelled(pageIndex: Int)
    case documentProcessingCancelled

    var errorDescription: String? {
        switch self {
        case .ocrFailed(let pageIndex, let error):
            return "OCR failed for page \(pageIndex): \(error.localizedDescription)"
        case .classificationFailed(let pageIndex, let error):
            return "Classification failed for page \(pageIndex): \(error.localizedDescription)"
        case .sentimentAnalysisFailed(let pageIndex, let error):
            return "Sentiment analysis failed for page \(pageIndex): \(error.localizedDescription)"
        case .unknownInferenceError(let pageIndex, let task):
            return "An unknown error occurred during \(task) for page \(pageIndex)."
        case .pageProcessingCancelled(let pageIndex):
            return "Processing for page \(pageIndex) was cancelled."
        case .documentProcessingCancelled:
            return "Document processing was cancelled."
        }
    }
}

// MARK: - 3. Data Structures for Inference Results

/// Represents the type of document.
enum DocumentType: String, Codable {
    case invoice, receipt, contract, form, report, unknown
}

/// Represents the sentiment of text.
enum Sentiment: String, Codable {
    case positive, neutral, negative, mixed, unknown
}

/// A structured result containing all inference outputs for a single document page.
struct PageInferenceResult: Identifiable, Codable, Equatable {
    let id: UUID
    let pageIndex: Int
    var extractedText: String?
    var documentType: DocumentType?
    var sentiment: Sentiment?
    var errors: [String] = [] // To collect specific errors for this page

    init(pageIndex: Int) {
        self.id = UUID()
        self.pageIndex = pageIndex
    }
}

// MARK: - 4. Mock AI Models (Illustrating `async` and Cancellation)

/// Represents a single document page as raw image data.
struct DocumentPage: Identifiable, Sendable {
    let id: UUID = UUID()
    let pageIndex: Int
    let imageData: Data // In a real app, this would be an image type (e.g., UIImage, NSImage)
}

/// A mock OCR model that simulates text extraction.
/// It includes cancellation checks and potential artificial delays/failures.
final class MockOCRModel: @unchecked Sendable { // @unchecked Sendable for simplicity, in real code, ensure thread safety
    /// Performs OCR on the given page image data.
    /// - Parameters:
    ///   - pageData: The raw image data of the document page.
    ///   - pageIndex: The index of the page being processed.
    /// - Returns: The extracted text.
    /// - Throws: `CancellationError` if the task is cancelled, or a generic `Error` for other failures.
    func performOCR(pageData: Data, pageIndex: Int) async throws -> String {
        // Simulate a network request or heavy computation
        let delay = UInt64.random(in: 1_000_000_000...3_000_000_000) // 1 to 3 seconds
        try await Task.sleep(nanoseconds: delay)

        // Crucial for cancellation: check if the task has been cancelled
        try Task.checkCancellation()

        // Simulate random failure
        if Bool.random() && pageIndex % 5 == 0 { // 20% chance of failure for every 5th page
            throw NSError(domain: "MockOCR", code: 101, userInfo: [NSLocalizedDescriptionKey: "Simulated OCR engine failure for page \(pageIndex)"])
        }

        // Simulate text extraction
        return "Extracted text from page \(pageIndex): This is some sample text for demonstration purposes. It includes various details that might be relevant for further analysis."
    }
}

/// A mock Document Classifier model.
final class MockDocumentClassifierModel: @unchecked Sendable {
    /// Classifies the document type based on image data.
    /// - Parameters:
    ///   - pageData: The raw image data of the document page.
    ///   - pageIndex: The index of the page being processed.
    /// - Returns: The classified `DocumentType`.
    /// - Throws: `CancellationError` if the task is cancelled, or a generic `Error` for other failures.
    func classifyDocument(pageData: Data, pageIndex: Int) async throws -> DocumentType {
        let delay = UInt64.random(in: 500_000_000...2_000_000_000) // 0.5 to 2 seconds
        try await Task.sleep(nanoseconds: delay)
        try Task.checkCancellation()

        if Bool.random() && pageIndex % 7 == 0 { // ~14% chance of failure for every 7th page
            throw NSError(domain: "MockClassifier", code: 201, userInfo: [NSLocalizedDescriptionKey: "Simulated classifier model error for page \(pageIndex)"])
        }

        let types: [DocumentType] = [.invoice, .receipt, .contract, .form, .report]
        return types.randomElement() ?? .unknown
    }
}

/// A mock Sentiment Analysis model.
final class MockSentimentAnalysisModel: @unchecked Sendable {
    /// Analyzes the sentiment of the given text.
    /// - Parameters:
    ///   - text: The text to analyze.
    ///   - pageIndex: The index of the page the text came from.
    /// - Returns: The `Sentiment` of the text.
    /// - Throws: `CancellationError` if the task is cancelled, or a generic `Error` for other failures.
    func analyzeSentiment(text: String, pageIndex: Int) async throws -> Sentiment {
        let delay = UInt64.random(in: 300_000_000...1_500_000_000) // 0.3 to 1.5 seconds
        try await Task.sleep(nanoseconds: delay)
        try Task.checkCancellation()

        if Bool.random() && pageIndex % 3 == 0 { // ~33% chance of failure for every 3rd page
            throw NSError(domain: "MockSentiment", code: 301, userInfo: [NSLocalizedDescriptionKey: "Simulated sentiment analysis API limit exceeded for page \(pageIndex)"])
        }

        let sentiments: [Sentiment] = [.positive, .neutral, .negative, .mixed]
        return sentiments.randomElement() ?? .unknown
    }
}

// MARK: - 5. Document Processor Orchestration

/// Manages the parallel processing of document pages using multiple AI models.
/// Demonstrates `TaskGroup` for parallel inference and robust cancellation.
@available(iOS 18.0, *) // Using modern concurrency features, assume iOS 18+ for this advanced example
final class DocumentProcessor {
    private let ocrModel = MockOCRModel()
    private let classifierModel = MockDocumentClassifierModel()
    private let sentimentModel = MockSentimentAnalysisModel()

    /// Processes a collection of document pages in parallel, applying multiple AI inference tasks to each.
    ///
    /// This method uses a `TaskGroup` to concurrently process each `DocumentPage`.
    /// For each page, it then uses *another* nested `TaskGroup` to run OCR, classification,
    /// and sentiment analysis models in parallel.
    ///
    /// Cancellation:
    /// - If the `processDocumentPages` task is cancelled, the outer `TaskGroup` will be cancelled.
    /// - Cancellation propagates to the inner tasks, ensuring all ongoing inference for a page stops.
    /// - Individual mock models check `Task.isCancelled` and throw `CancellationError`.
    ///
    /// - Parameter pages: An array of `DocumentPage` objects to process.
    /// - Returns: An array of `PageInferenceResult`, each containing the combined
    ///   inference outputs for a page.
    /// - Throws: `DocumentProcessingError.documentProcessingCancelled` if the entire
    ///   document processing task is cancelled. Other errors from individual page
    ///   processing are captured within `PageInferenceResult.errors`.
    func processDocumentPages(pages: [DocumentPage]) async throws -> [PageInferenceResult] {
        print("🚀 Starting document processing for \(pages.count) pages...")

        var results: [PageInferenceResult] = []
        results.reserveCapacity(pages.count)

        // Outer TaskGroup: Process each page concurrently
        try await withThrowingTaskGroup(of: PageInferenceResult?.self) { group in
            for page in pages {
                group.addTask { [weak self] in
                    guard let self = self else { return nil } // Self could be deallocated
                    print("  Starting processing for page \(page.pageIndex)...")

                    var pageResult = PageInferenceResult(pageIndex: page.pageIndex)
                    var currentTaskErrors: [String] = [] // Errors specific to this page's processing

                    do {
                        // Inner TaskGroup: Run multiple AI models in parallel for a single page
                        try await withThrowingTaskGroup(of: Void.self) { innerGroup in
                            var ocrText: String?

                            // Task 1: Perform OCR
                            innerGroup.addTask {
                                do {
                                    ocrText = try await self.ocrModel.performOCR(pageData: page.imageData, pageIndex: page.pageIndex)
                                    pageResult.extractedText = ocrText
                                    print("    ✅ OCR completed for page \(page.pageIndex)")
                                } catch is CancellationError {
                                    throw DocumentProcessingError.pageProcessingCancelled(pageIndex: page.pageIndex)
                                } catch {
                                    currentTaskErrors.append("OCR failed: \(error.localizedDescription)")
                                    throw DocumentProcessingError.ocrFailed(pageIndex: page.pageIndex, underlyingError: error)
                                }
                            }

                            // Task 2: Classify Document
                            innerGroup.addTask {
                                do {
                                    pageResult.documentType = try await self.classifierModel.classifyDocument(pageData: page.imageData, pageIndex: page.pageIndex)
                                    print("    ✅ Classification completed for page \(page.pageIndex)")
                                } catch is CancellationError {
                                    throw DocumentProcessingError.pageProcessingCancelled(pageIndex: page.pageIndex)
                                } catch {
                                    currentTaskErrors.append("Classification failed: \(error.localizedDescription)")
                                    throw DocumentProcessingError.classificationFailed(pageIndex: page.pageIndex, underlyingError: error)
                                }
                            }

                            // Task 3: Perform Sentiment Analysis (depends on OCR text, so it waits for ocrText)
                            innerGroup.addTask {
                                do {
                                    // Wait for OCR to complete. If OCR fails, this task won't proceed successfully.
                                    // In a real scenario, you might have a more complex dependency management or
                                    // pass nil/empty string if OCR is optional for sentiment.
                                    guard let text = ocrText else {
                                        // This implies a dependency. If OCR fails, this task might also "fail" or wait indefinitely.
                                        // For now, we'll assume ocrText will eventually be set if OCR succeeds.
                                        // A more robust solution might involve a `Channel` or `AsyncStream`.
                                        // For this example, we'll simply check after `innerGroup.next()`
                                        // and potentially handle it as a missing dependency.
                                        return // It's okay for this task to complete without sentiment if OCR didn't produce text
                                    }
                                    pageResult.sentiment = try await self.sentimentModel.analyzeSentiment(text: text, pageIndex: page.pageIndex)
                                    print("    ✅ Sentiment analysis completed for page \(page.pageIndex)")
                                } catch is CancellationError {
                                    throw DocumentProcessingError.pageProcessingCancelled(pageIndex: page.pageIndex)
                                } catch {
                                    currentTaskErrors.append("Sentiment analysis failed: \(error.localizedDescription)")
                                    throw DocumentProcessingError.sentimentAnalysisFailed(pageIndex: page.pageIndex, underlyingError: error)
                                }
                            }

                            // Wait for all inner tasks to complete or throw
                            try await innerGroup.waitForAll()

                        } // End of inner TaskGroup for a single page
                        
                    } catch is CancellationError {
                        print("  ❌ Page \(page.pageIndex) processing cancelled.")
                        pageResult.errors.append(DocumentProcessingError.pageProcessingCancelled(pageIndex: page.pageIndex).localizedDescription)
                        // Do not rethrow CancellationError from inner task to outer group directly,
                        // as it would cancel the entire outer group. Instead, capture it as an error
                        // for the specific page. The outer group's task needs to complete,
                        // even if it's with a nil result or an error-filled PageInferenceResult.
                    } catch let error as DocumentProcessingError {
                        print("  ❌ Page \(page.pageIndex) processing failed with error: \(error.localizedDescription)")
                        pageResult.errors.append(error.localizedDescription)
                    } catch {
                        print("  ❌ Page \(page.pageIndex) processing failed with unexpected error: \(error.localizedDescription)")
                        pageResult.errors.append(DocumentProcessingError.unknownInferenceError(pageIndex: page.pageIndex, task: "multiple models").localizedDescription)
                    }
                    
                    pageResult.errors.append(contentsOf: currentTaskErrors)
                    return pageResult // Return the result (potentially with errors) for this page
                }
            }

            // Collect results from all page tasks
            for try await result in group {
                if let result = result {
                    results.append(result)
                }
            }
        }
        
        // Sort results by page index for consistent output
        results.sort { $0.pageIndex < $1.pageIndex }

        print("🎉 Document processing completed. Processed \(results.count) pages.")
        return results
    }
}

// MARK: - 6. Example Usage and Cancellation Demonstration

@available(iOS 18.0, *)
actor AppViewModel { // Simulating a ViewModel in an app
    private let documentProcessor = DocumentProcessor()
    private var processingTask: Task<Void, Never>?

    /// Starts processing a mock document with a specified number of pages.
    ///
    /// - Parameter numberOfPages: The total number of pages in the document.
    func startProcessingDocument(numberOfPages: Int) {
        // Generate mock pages
        let pages = (0..<numberOfPages).map { index in
            DocumentPage(pageIndex: index, imageData: Data(repeating: UInt8(index % 255), count: 1024))
        }

        // Create a new task for processing, storing it so it can be cancelled
        processingTask = Task {
            do {
                let results = try await documentProcessor.processDocumentPages(pages: pages)
                print("\n--- Final Results ---")
                for result in results {
                    let status = result.errors.isEmpty ? "SUCCESS" : "FAILED (\(result.errors.count) errors)"
                    print("Page \(result.pageIndex): Status: \(status)")
                    if !result.errors.isEmpty {
                        print("  Errors: \(result.errors.joined(separator: "; "))")
                    } else {
                        print("  Text: \(result.extractedText?.prefix(30) ?? "N/A")...")
                        print("  Type: \(result.documentType?.rawValue ?? "N/A")")
                        print("  Sentiment: \(result.sentiment?.rawValue ?? "N/A")")
                    }
                }
            } catch is CancellationError {
                print("\n🚨 Entire document processing was cancelled by user action!")
            } catch {
                print("\n🚨 An unhandled error occurred during document processing: \(error.localizedDescription)")
            }
        }
    }

    /// Cancels the ongoing document processing task.
    func cancelProcessing() {
        print("\nCancelling document processing...")
        processingTask?.cancel()
        processingTask = nil
    }
}

// MARK: - Main Execution Block

@available(iOS 18.0, *)
func runDocumentProcessingDemo() async {
    let viewModel = AppViewModel()

    // Scenario 1: Successful processing
    print("--- Scenario 1: Successful Processing (5 pages) ---")
    await viewModel.startProcessingDocument(numberOfPages: 5)
    await Task.sleep(nanoseconds: 10_000_000_000) // Wait for a while (10 seconds)
    await viewModel.cancelProcessing() // Ensure any lingering tasks are cancelled, though it should be done by now.

    print("\n\n--- Scenario 2: Processing with Cancellation (10 pages, cancel after 3 seconds) ---")
    await viewModel.startProcessingDocument(numberOfPages: 10)
    await Task.sleep(nanoseconds: 3_000_000_000) // Wait for 3 seconds
    await viewModel.cancelProcessing() // User cancels mid-way
    await Task.sleep(nanoseconds: 5_000_000_000) // Give time for cancellation to propagate and tasks to finish/stop

    print("\n\n--- Scenario 3: Processing with Failures (15 pages) ---")
    await viewModel.startProcessingDocument(numberOfPages: 15)
    await Task.sleep(nanoseconds: 15_000_000_000) // Wait for a longer time
    await viewModel.cancelProcessing() // Ensure cleanup
}

// To run the demo in a playground or an app:
// Ensure your project targets iOS 18.0 or later, or remove @available annotations
// and understand that some features might behave differently on older OS versions.
if #available(iOS 18.0, *) {
    Task {
        await runDocumentProcessingDemo()
    }
} else {
    print("This demo requires iOS 18.0 or later.")
}
