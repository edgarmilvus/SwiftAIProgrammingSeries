
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CoreData
import Foundation

// 1. Define the ValueTransformer for [Float] to handle vector storage
@objc(FloatArrayTransformer)
final class FloatArrayTransformer: NSSecureUnarchiveFromDataTransformer {
    static let name = NSValueTransformerName(rawValue: "FloatArrayTransformer")

    override static var allowedTopLevelClasses: [AnyClass] {
        return [NSArray.self, NSNumber.self]
    }

    static func register() {
        let transformer = FloatArrayTransformer()
        ValueTransformer.setValueTransformer(transformer, forName: name)
    }
}

// 2. Persistent Container Setup
class NotePersistenceController {
    static let shared = NotePersistenceController()

    let container: NSPersistentContainer

    init() {
        // Register transformer BEFORE loading the store to prevent migration crashes
        FloatArrayTransformer.register()
        
        container = NSPersistentContainer(name: "NoteModel")
        
        guard let description = container.persistentStoreDescriptions.first else {
            fatalError("Failed to retrieve persistent store description.")
        }

        // Enable Lightweight Migration
        description.setOption(true as NSNumber, forKey: NSMigratePersistentStoresAutomaticallyOption)
        description.setOption(true as NSNumber, forKey: NSInferMappingModelAutomaticallyOption)

        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }
    }
}

// 3. Test Case Simulation
@MainActor
func testLightweightMigration() async {
    let controller = NotePersistenceController.shared
    let context = controller.container.viewContext

    // Step A: Simulate V1 Data (In a real test, this would be a separate store file)
    // Assume Note has 'text' and 'timestamp'
    let newNote = NSEntityDescription.insertNewObject(forEntityName: "Note", into: context)
    newNote.setValue("Hello AI", forKey: "text")
    newNote.setValue(Date(), forKey: "timestamp")
    
    try? context.save()
    print("V1 Data Seeded.")

    // Step B: Trigger Migration (In reality, this happens when the container loads the V2 model)
    // We verify the attributes added in V2
    let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Note")
    
    do {
        let results = try context.fetch(fetchRequest)
        if let note = results.first {
            let text = note.value(forKey: "text") as? String
            let category = note.value(forKey: "category") as? String
            let embedding = note.value(forKey: "embedding") as? [Float]

            assert(text == "Hello AI", "Data Loss: Text mismatch")
            assert(category == nil, "Migration Error: Category should be nil")
            assert(embedding == nil, "Migration Error: Embedding should be nil")
            print("✅ Lightweight Migration Successful: Data preserved, new fields are nil.")
        }
    } catch {
        print("❌ Migration failed: \(error)")
    }
}
