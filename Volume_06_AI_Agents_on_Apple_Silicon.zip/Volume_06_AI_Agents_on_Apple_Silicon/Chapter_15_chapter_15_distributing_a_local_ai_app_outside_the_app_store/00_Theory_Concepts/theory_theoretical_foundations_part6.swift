
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.swift
// Description: Theoretical Foundations
// ==========================================

// Example: Inference parameters need to be Sendable to be passed to an actor method
struct InferenceParameters: Sendable {
    let temperature: Double
    let topP: Double
    let maxTokens: Int
    // All properties are value types and thus Sendable, making InferenceParameters Sendable.
}

// If you had a class that needed to be Sendable, it would require careful handling:
final class LLMConfiguration: Sendable {
    let modelPath: String
    let contextSize: Int
    // All properties are immutable. If there were mutable properties,
    // they would need synchronization (e.g., NSLock, or protected by an actor).

    init(modelPath: String, contextSize: Int) {
        self.modelPath = modelPath
        self.contextSize = contextSize
    }
}
