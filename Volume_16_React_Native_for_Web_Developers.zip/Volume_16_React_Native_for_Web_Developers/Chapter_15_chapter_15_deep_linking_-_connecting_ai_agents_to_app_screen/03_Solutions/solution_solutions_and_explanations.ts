/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// App.tsx
import React, { useEffect, useRef } from 'react';
import { NavigationContainer, NavigationContainerRef } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import * as Linking from 'expo-linking';
import { View, Text, Button, Alert } from 'react-native';

// Define your screens
const ArticleDetail = ({ route }: any) => {
  const { articleId } = route.params || {};
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 24 }}>Article ID: {articleId}</Text>
    </View>
  );
};

const HomeScreen = ({ navigation }: any) => {
  const handleShare = async () => {
    // Generate a URL for article ID 123
    const url = Linking.makeUrl('/article/123');
    // In a real app, you would use Share.share from 'react-native'
    Alert.alert('Generated Link', `Link: ${url}`);
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Home Screen</Text>
      <Button title="Generate Test Link" onPress={handleShare} />
      <Button title="Go to Article 123" onPress={() => navigation.navigate('Article', { articleId: '123' })} />
    </View>
  );
};

const Stack = createStackNavigator();

// 1. Define the linking configuration
const linking = {
  prefixes: [Linking.createURL('/')], // Handles myapp:// or exp://192.168.x.x:8081/
  config: {
    screens: {
      Home: '', // Base path
      Article: 'article/:articleId', // Maps myapp://article/123
    },
  },
};

export default function App() {
  const navigationRef = useRef<NavigationContainerRef<any>>(null);

  // 2. Handle incoming URLs when app is launched from terminated state
  useEffect(() => {
    const handleInitialURL = async () => {
      const initialUrl = await Linking.getInitialURL();
      if (initialUrl && navigationRef.current) {
        // Parse the URL. 
        // Note: React Navigation's linking config handles this automatically,
        // but we can manually parse if needed.
        const { path, queryParams } = Linking.parse(initialUrl);
        
        if (path === 'article' && queryParams.articleId) {
          navigationRef.current.navigate('Article', { articleId: queryParams.articleId });
        }
      }
    };

    handleInitialURL();
  }, []);

  return (
    <NavigationContainer ref={navigationRef} linking={linking} fallback={<Text>Loading...</Text>}>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Article" component={ArticleDetail} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
