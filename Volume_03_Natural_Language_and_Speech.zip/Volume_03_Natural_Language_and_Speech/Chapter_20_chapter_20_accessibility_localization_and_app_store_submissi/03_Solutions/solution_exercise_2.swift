
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import SwiftUI

// Define a simple Article model
struct Article: Identifiable {
    let id = UUID()
    let title: String
    let summary: String
    let timestamp: Date
    let category: ArticleCategory
}

enum ArticleCategory: String, CaseIterable, Identifiable {
    case politics = "Politics"
    case photography = "Photography"
    case tech = "Technology"
    case sports = "Sports"

    var id: String { self.rawValue }

    var iconName: String {
        switch self {
        case .politics: return "newspaper.fill"
        case .photography: return "camera.fill"
        case .tech: return "laptopcomputer"
        case .sports: return "sportscourt.fill"
        }
    }

    var accessibilityLabel: String {
        switch self {
        case .politics: return "Politics category"
        case .photography: return "Photography news category"
        case .tech: return "Technology category"
        case .sports: return "Sports news category"
        }
    }
}

struct ArticleListItem: View {
    let article: Article

    // DateFormatter for the timestamp
    private static let dateFormatter: RelativeDateTimeFormatter = {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .full // e.g., "2 hours ago", "yesterday"
        return formatter
    }()

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: article.category.iconName)
                .font(.title2) // Dynamically scales with content size
                .foregroundColor(.accentColor)
                .frame(width: 40, height: 40) // Ensure consistent size for icon
                .accessibilityHidden(true) // Hide individual icon from VoiceOver to avoid redundancy
                // The category info will be part of the combined accessibility label for the cell

            VStack(alignment: .leading, spacing: 4) {
                Text(article.title)
                    .font(.headline) // Automatically supports Dynamic Type
                    .lineLimit(2)
                    .minimumScaleFactor(0.8) // Allow text to shrink slightly if needed

                Text(article.summary)
                    .font(.subheadline) // Automatically supports Dynamic Type
                    .foregroundColor(.gray)
                    .lineLimit(3)
                    .minimumScaleFactor(0.8)

                Text(Self.dateFormatter.localizedString(for: article.timestamp, relativeTo: Date()))
                    .font(.caption) // Automatically supports Dynamic Type
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 8)
        .accessibilityElement(children: .combine) // Make the entire HStack a single accessibility element
        .accessibilityLabel(
            "\(article.title), \(article.category.accessibilityLabel). \(article.summary). Sent \(Self.dateFormatter.localizedString(for: article.timestamp, relativeTo: Date()))."
        )
        .accessibilityHint("Double tap to open article.")
    }
}

// MARK: - Preview Provider (for demonstration)
struct ArticleListItem_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ArticleListItem(article: Article(
                title: "Swift 6 Concurrency Model Unveiled at WWDC",
                summary: "Apple introduces new structured concurrency features and actors for safer, more efficient asynchronous programming in Swift 6.",
                timestamp: Date().addingTimeInterval(-3600 * 2), // 2 hours ago
                category: .tech
            ))
            .previewDisplayName("Default Size")

            ArticleListItem(article: Article(
                title: "Local Elections See Record Turnout Across the Nation",
                summary: "Voters flocked to the polls, signaling strong engagement in local governance and community issues.",
                timestamp: Date().addingTimeInterval(-3600 * 24 * 7), // 1 week ago
                category: .politics
            ))
            .environment(\.sizeCategory, .extraExtraLarge) // Simulate larger Dynamic Type
            .previewDisplayName("Large Text Size")

            ArticleListItem(article: Article(
                title: "Capturing the Golden Hour: Tips for Stunning Landscape Photography",
                summary: "Learn how to utilize the magical light of sunrise and sunset to elevate your landscape shots.",
                timestamp: Date().addingTimeInterval(-3600 * 24 * 365), // 1 year ago
                category: .photography
            ))
            .environment(\.locale, Locale(identifier: "es")) // Simulate Spanish locale for date
            .previewDisplayName("Spanish Locale")
        }
        .padding()
        .previewLayout(.sizeThatFits)
    }
}
