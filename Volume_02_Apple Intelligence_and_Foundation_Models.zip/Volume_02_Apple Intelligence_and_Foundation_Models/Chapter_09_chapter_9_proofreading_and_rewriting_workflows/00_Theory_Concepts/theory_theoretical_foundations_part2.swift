
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
import WritingTools
import Foundation

// An actor to safely manage AI requests and potentially internal model state
actor AIManagementActor {
    private let writingToolsManager = WritingToolsManager() // The actual AI interface

    // A simple cache for recent requests to avoid redundant processing
    private var lastProcessedText: String?
    private var lastSuggestions: [WritingSuggestion]?

    func getProofreadingSuggestions(for text: String) async throws -> [WritingSuggestion] {
        // Check cache within the actor's isolated context
        if text == lastProcessedText, let cachedSuggestions = lastSuggestions {
            return cachedSuggestions
        }

        let proofreadingRequest = WritingProofreadingRequest(text: text)
        // Perform the actual AI inference. This is an asynchronous operation.
        let suggestions = try await writingToolsManager.proofread(request: proofreadingRequest)

        // Update cache within the actor's isolated context
        self.lastProcessedText = text
        self.lastSuggestions = suggestions
        
        return suggestions
    }
    
    // Example for rewriting
    func rewriteText(_ text: String, instruction: String) async throws -> String {
        let rewriteRequest = WritingRewriteRequest(text: text, instruction: instruction)
        let rewrittenText = try await writingToolsManager.rewrite(request: rewriteRequest)
        return rewrittenText
    }
}

// How the ViewModel would use the actor:
@available(iOS 18.0, *)
extension DocumentEditorViewModel {
    private let aiActor = AIManagementActor() // Instantiate the actor

    func requestProofreadingSuggestionsViaActor() async {
        isLoading = true
        suggestions = []

        do {
            // Interact with the actor. This call is `await`ed.
            let newSuggestions = try await aiActor.getProofreadingSuggestions(for: documentText)
            await MainActor.run {
                self.suggestions = newSuggestions
                self.isLoading = false
            }
        } catch {
            print("Error requesting proofreading via actor: \(error.localizedDescription)")
            await MainActor.run {
                self.isLoading = false
            }
        }
    }
}
