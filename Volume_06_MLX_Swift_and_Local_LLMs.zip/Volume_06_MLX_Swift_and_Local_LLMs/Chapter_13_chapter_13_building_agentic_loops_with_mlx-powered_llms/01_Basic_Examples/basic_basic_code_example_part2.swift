
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import MLX
import MLXNN // For neural network modules like Linear
import Foundation // For basic data types and printing

// Ensure this code runs on supported platforms
@available(iOS 18.0, macOS 15.0, *)
final class ChatSuggestionService {

    /// A simple neural network module for generating chat reply suggestions.
    ///
    /// This module takes an input embedding (e.g., representing chat context)
    /// and outputs scores for a fixed number of predefined replies.
    /// It inherits from `MLXNN.Module`, allowing MLX to automatically track its parameters.
    class SuggestionModel: MLXNN.Module {
        let inputDim: Int
        let outputDim: Int
        var linear1: MLXNN.Linear
        var linear2: MLXNN.Linear

        /// Initializes the SuggestionModel.
        /// - Parameters:
        ///   - inputDim: The dimensionality of the input embedding.
        ///   - outputDim: The number of possible reply suggestions (output classes).
        init(inputDim: Int, outputDim: Int) {
            self.inputDim = inputDim
            self.outputDim = outputDim
            // Define two linear layers. MLXNN.Linear automatically creates weight and bias parameters.
            self.linear1 = MLXNN.Linear(inputDim, inputDim * 2) // Expand dimensions
            self.linear2 = MLXNN.Linear(inputDim * 2, outputDim) // Project to output suggestions
            super.init() // Call the superclass initializer
        }

        /// Performs the forward pass of the model.
        /// - Parameter input: An `MLXArray` representing the input embedding.
        /// - Returns: An `MLXArray` containing scores for each reply suggestion.
        override func callAsFunction(_ input: MLXArray) -> MLXArray {
            // Apply the first linear layer, then ReLU activation, then the second linear layer.
            // MLX operations are chained elegantly.
            return input
                .applying(linear1) // Apply the first linear transformation
                .relu()            // Apply ReLU activation function
                .applying(linear2) // Apply the second linear transformation
        }
    }

    private var model: SuggestionModel
    private let suggestionLabels: [String]

    /// Initializes the ChatSuggestionService with a pre-trained or new model.
    /// In a real app, you might load weights from disk here.
    /// - Parameters:
    ///   - inputDimension: The expected dimension of the input chat context embedding.
    ///   - suggestions: An array of string suggestions the model should predict scores for.
    init(inputDimension: Int, suggestions: [String]) {
        self.suggestionLabels = suggestions
        self.model = SuggestionModel(inputDim: inputDimension, outputDim: suggestions.count)
        print("ChatSuggestionService initialized with model. Input dim: \(inputDimension), Output dim: \(suggestions.count)")
    }

    /// Generates reply suggestions for a given chat context embedding.
    /// - Parameter chatContextEmbedding: An `MLXArray` representing the numerical context of the chat.
    /// - Returns: An array of `(String, Float)` tuples, where String is the suggestion
    ///            and Float is its score, sorted by score in descending order.
    func generateSuggestions(for chatContextEmbedding: MLXArray) async throws -> [(String, Float)] {
        // 1. Perform a forward pass (inference)
        // This builds the computation graph but doesn't execute it immediately due to lazy evaluation.
        let outputScores = model(chatContextEmbedding)

        // 2. Eagerly evaluate the graph and retrieve results
        // .eval() forces the computation graph to execute on the GPU/CPU.
        // .asArray(Float.self) converts the MLXArray to a Swift Array of Floats.
        let scores = try await outputScores.eval().asArray(Float.self)

        guard scores.count == suggestionLabels.count else {
            throw ChatSuggestionError.mismatchedOutput(expected: suggestionLabels.count, actual: scores.count)
        }

        // 3. Pair scores with labels and sort
        let sortedSuggestions = zip(suggestionLabels, scores)
            .map { (label, score) in (label, score) }
            .sorted { $0.1 > $1.1 } // Sort by score, highest first

        return sortedSuggestions
    }

    /// Demonstrates a conceptual training step using `valueAndGradient`.
    /// This is for illustration purposes to show how gradients are computed.
    /// In a real scenario, this would be part of an optimizer loop.
    func conceptualTrainingStep(
        inputEmbedding: MLXArray,
        targetScores: MLXArray,
        learningRate: Float = 0.01
    ) async throws {
        print("\n--- Starting Conceptual Training Step ---")

        // 1. Define a loss function
        // This closure takes the model parameters and input/target, and returns the loss.
        // MLX's functional transformations operate on closures like this.
        let lossFn = { (model: SuggestionModel, input: MLXArray, target: MLXArray) -> MLXArray in
            let predictions = model(input)
            // Using Mean Squared Error (MSE) as a simple loss function for demonstration
            let loss = (predictions - target).square().mean()
            return loss
        }

        // 2. Use `valueAndGradient` to compute loss and gradients
        // This is a core MLX functional transformation. It takes a function (our lossFn)
        // and arguments (model, input, target), and returns a tuple:
        // (the value of the function, the gradients of the function with respect to its differentiable arguments).
        // In our case, the differentiable arguments are the model's parameters.
        let (loss, gradients) = await valueAndGradient(lossFn, model, inputEmbedding, targetScores)

        // 3. Eagerly evaluate the loss and gradients
        let evaluatedLoss = try await loss.eval().item(Float.self)
        print("Calculated Loss: \(evaluatedLoss)")

        // 4. Apply gradients (conceptual update)
        // In a real training loop, an optimizer (like SGD, Adam) would apply these gradients
        // to update the model's parameters. Here, we'll just print them and simulate a manual update.
        for (paramName, grad) in gradients.parameters() {
            print("Gradient for \(paramName): \(try await grad.eval().item(Float.self)) (first element)")
            // Conceptual parameter update: param = param - learning_rate * gradient
            // This is simplified; a real optimizer handles this more robustly.
            if let param = model.parameters()[paramName] {
                 _ = param.update(param - learningRate * grad)
            }
        }
        print("--- Conceptual Training Step Complete ---")
    }
}

// MARK: - App Integration Example

/// An example ViewModel for a chat interface, demonstrating how to use the service.
@available(iOS 18.0, macOS 15.0, *)
@Observable // Swift 6's @Observable macro for SwiftUI
final class ChatViewModel {
    private let suggestionService: ChatSuggestionService
    var currentChatText: String = ""
    var suggestedReplies: [(String, Float)] = []
    var isLoadingSuggestions: Bool = false
    var errorMessage: String?

    init() {
        // Define our fixed set of suggestions and input dimension
        let suggestions = ["Yes, definitely!", "Sounds good.", "I'll get back to you.", "No, thanks.", "What do you think?"]
        let inputDim = 128 // Example embedding dimension
        self.suggestionService = ChatSuggestionService(inputDimension: inputDim, suggestions: suggestions)
    }

    /// Simulates receiving a new chat message and generating suggestions.
    /// This would typically be triggered by user input or a new incoming message.
    func generateSuggestionsForCurrentChat() async {
        isLoadingSuggestions = true
        errorMessage = nil
        suggestedReplies = []

        // In a real app, 'currentChatText' would be converted to an embedding
        // using another MLX model (e.g., a Sentence Transformer).
        // For this example, we'll create a dummy random embedding.
        let dummyEmbedding = MLXRandom.normal(shape: [1, 128]) // [batch_size, embedding_dim]

        do {
            let suggestions = try await suggestionService.generateSuggestions(for: dummyEmbedding)
            // Ensure UI updates happen on the main actor
            await MainActor.run {
                self.suggestedReplies = suggestions
            }
        } catch {
            await MainActor.run {
                self.errorMessage = "Failed to generate suggestions: \(error.localizedDescription)"
            }
            print("Error generating suggestions: \(error)")
        }
        await MainActor.run {
            self.isLoadingSuggestions = false
        }
    }

    /// Simulates a very basic fine-tuning step based on some feedback.
    /// This is purely illustrative for `valueAndGradient`.
    func simulateFineTuningFeedback() async {
        print("\nSimulating fine-tuning feedback...")
        // Dummy input and target for a single training step
        let dummyInput = MLXRandom.normal(shape: [1, 128])
        // Let's say we want the first suggestion to have a higher score (1.0) and others lower (0.1)
        let dummyTarget = MLXArray([1.0, 0.1, 0.1, 0.1, 0.1], shape: [1, 5]) // Assuming 5 suggestions

        do {
            try await suggestionService.conceptualTrainingStep(
                inputEmbedding: dummyInput,
                targetScores: dummyTarget
            )
            print("Fine-tuning simulation complete.")
        } catch {
            print("Fine-tuning simulation failed: \(error)")
        }
    }
}

// MARK: - Error Handling
enum ChatSuggestionError: Error, LocalizedError {
    case mismatchedOutput(expected: Int, actual: Int)

    var errorDescription: String? {
        switch self {
        case .mismatchedOutput(let expected, let actual):
            return "Model output dimension mismatch. Expected \(expected), got \(actual)."
        }
    }
}

// MARK: - How to Run (Example Usage)
@available(iOS 18.0, macOS 15.0, *)
func runChatSuggestionExample() async {
    print("--- Running MLX Chat Suggestion Example ---")

    let viewModel = ChatViewModel()

    // 1. Generate initial suggestions
    print("\nGenerating initial suggestions...")
    await viewModel.generateSuggestionsForCurrentChat()

    if !viewModel.suggestedReplies.isEmpty {
        print("Suggested Replies:")
        for (label, score) in viewModel.suggestedReplies {
            print("- \(label) (Score: \(String(format: "%.4f", score)))")
        }
    } else if let error = viewModel.errorMessage {
        print("Error: \(error)")
    }

    // 2. Simulate a conceptual fine-tuning step
    await viewModel.simulateFineTuningFeedback()

    // 3. Generate suggestions again to see if there's any (minor) change
    //    due to the conceptual update.
    print("\nGenerating suggestions after conceptual fine-tuning...")
    await viewModel.generateSuggestionsForCurrentChat()

    if !viewModel.suggestedReplies.isEmpty {
        print("Suggested Replies (after conceptual fine-tuning):")
        for (label, score) in viewModel.suggestedReplies {
            print("- \(label) (Score: \(String(format: "%.4f", score)))")
        }
    } else if let error = viewModel.errorMessage {
        print("Error: \(error)")
    }

    print("\n--- MLX Chat Suggestion Example Complete ---")
}

// To run this in a Playground or a simple command-line tool:
// Task {
//     await runChatSuggestionExample()
// }
