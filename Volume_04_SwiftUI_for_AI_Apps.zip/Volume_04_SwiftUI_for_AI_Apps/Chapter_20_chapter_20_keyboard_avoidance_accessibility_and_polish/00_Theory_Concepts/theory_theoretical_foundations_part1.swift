
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import Combine // For NotificationCenter publishers

@available(iOS 18.0, *)
struct ChatView: View {
    @State private var messageText: String = ""
    @State private var keyboardHeight: CGFloat = 0

    // A simple Observable object to hold AI response state
    @Observable class ChatViewModel {
        var messages: [String] = []
        var isGenerating: Bool = false

        func sendPrompt(_ prompt: String) async {
            messages.append("User: \(prompt)")
            isGenerating = true
            // Simulate AI inference
            try? await Task.sleep(for: .seconds(1))
            let aiResponse = "AI: This is a simulated response to your prompt: \(prompt)"
            messages.append(aiResponse)
            isGenerating = false
        }
    }

    @State private var viewModel = ChatViewModel()

    var body: some View {
        VStack {
            ScrollView {
                VStack(alignment: .leading) {
                    ForEach(viewModel.messages, id: \.self) { message in
                        Text(message)
                            .padding(.vertical, 4)
                    }
                    if viewModel.isGenerating {
                        ProgressView()
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            }
            .scrollDismissesKeyboard(.interactively) // iOS 15+
            
            HStack {
                TextField("Enter prompt...", text: $messageText)
                    .textFieldStyle(.roundedBorder)
                Button("Send") {
                    Task {
                        await viewModel.sendPrompt(messageText)
                        messageText = ""
                    }
                }
                .disabled(messageText.isEmpty || viewModel.isGenerating)
            }
            .padding()
            .background(.ultraThinMaterial)
            // This padding dynamically adjusts based on keyboardHeight
            .padding(.bottom, keyboardHeight) 
            .animation(.easeOut(duration: 0.2), value: keyboardHeight) // Smooth animation
        }
        .onReceive(Publishers.keyboardHeight) { newHeight in
            // Update keyboardHeight state, triggering UI redraw
            self.keyboardHeight = newHeight
        }
        // Reference to a previous chapter concept: Reactive state management.
        // The `keyboardHeight` is a piece of reactive state, similar to how
        // `@State` or `@Binding` from earlier chapters drives UI updates.
        // Here, it's driven by system events rather than user input directly,
        // but the principle of UI reacting to state changes is identical.
    }
}

// Helper to get keyboard height using Combine and NotificationCenter
extension Publishers {
    static var keyboardHeight: AnyPublisher<CGFloat, Never> {
        NotificationCenter.default.publisher(for: UIResponder.keyboardWillChangeFrameNotification)
            .map { notification -> CGFloat in
                (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect)?.height ?? 0
            }
            .eraseToAnyPublisher()
    }
}
