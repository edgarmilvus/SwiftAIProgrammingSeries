
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift snippet for MLX dependencies
// This would be part of your main Package.swift file
/*
import PackageDescription

let package = Package(
    name: "MyMLXApp",
    platforms: [
        .macOS(.v14), .iOS(.v17) // Or higher, depending on MLX Swift requirements
    ],
    products: [
        .library(
            name: "MyMLXApp",
            targets: ["MyMLXApp"]),
    ],
    dependencies: [
        .package(url: "https://github.com/ml-explore/mlx-swift.git", branch: "main") // Or a specific tag
    ],
    targets: [
        .target(
            name: "MyMLXApp",
            dependencies: [
                .product(name: "MLX", package: "mlx-swift"),
                .product(name: "MLXNN", package: "mlx-swift")
            ]),
        .testTarget(
            name: "MyMLXAppTests",
            dependencies: ["MyMLXApp"]),
    ]
)
*/

import MLX
import MLXNN

@available(iOS 18.0, *) // MLX Swift typically targets newer OS versions
class CustomTransformerBlock: MLXNN.Module {
    let attention: MLXNN.MultiHeadAttention
    let feedForward: MLXNN.Sequential
    let norm1: MLXNN.LayerNorm
    let norm2: MLXNN.LayerNorm

    required init(modelDimension: Int, numHeads: Int) {
        self.attention = MLXNN.MultiHeadAttention(dimensions: modelDimension, numHeads: numHeads)
        self.feedForward = MLXNN.Sequential(
            MLXNN.Linear(inputDimensions: modelDimension, outputDimensions: modelDimension * 4),
            MLXNN.ReLU(),
            MLXNN.Linear(inputDimensions: modelDimension * 4, outputDimensions: modelDimension)
        )
        self.norm1 = MLXNN.LayerNorm(dimensions: modelDimension)
        self.norm2 = MLXNN.LayerNorm(dimensions: modelDimension)
        super.init()
    }

    override func callAsFunction(_ input: MLXArray, mask: MLXArray? = nil) -> MLXArray {
        // Self-attention with residual connection and layer normalization
        var output = norm1(input)
        output = input + attention(output, key: output, value: output, mask: mask)

        // Feed-forward with residual connection and layer normalization
        output = output + feedForward(norm2(output))
        return output
    }
}
