
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

// Example SwiftUI View (iOS 17+)
import SwiftUI

@available(iOS 18.0, *) // Assuming AudioRecognitionManager is iOS 18.0 due to @ObservableObject in its init
struct RecognitionView: View {
    @State private var recognitionManager = AudioRecognitionManager() // @State for actor lifecycle

    var body: some View {
        VStack {
            Text(recognitionManager.currentTranscription)
                .font(.title)
                .padding()

            if recognitionManager.isRecognizing {
                ProgressView()
            } else {
                Button("Start Recognition") {
                    Task {
                        do {
                            try await recognitionManager.startRecognition()
                        } catch {
                            recognitionManager.lastError = error
                        }
                    }
                }
                .disabled(recognitionManager.authorizationStatus != .authorized)
            }

            if let error = recognitionManager.lastError {
                Text("Error: \(error.localizedDescription)")
                    .foregroundColor(.red)
            }
        }
        .onAppear {
            Task {
                await recognitionManager.requestAuthorization()
            }
        }
        .onDisappear {
            Task {
                await recognitionManager.stopRecognition()
            }
        }
    }
}
