
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import SwiftUI
import RealityKit
import ARKit
import Observation

// MARK: - Dependencies

/*
 Package.swift equivalent:
 dependencies: [
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0"),
    .package(url: "https://github.com/apple/swift-collections", from: "1.1.0")
 ]
*/

// MARK: - Domain Models & Errors

/// Represents the various visual modes available in the application.
enum SpatialMode: Equatable {
    case dashboard        // 2D Window
    case modelInspection  // 3D Volume
    case immersiveAnalysis // Full Immersive Space
}

/// Errors specific to spatial transitions and asset loading.
enum SpatialError: LocalizedError {
    case transitionFailed(reason: String)
    case assetLoadFailure(entityName: String)
    case insufficientPermissions
    
    var errorDescription: String? {
        switch self {
        case .transitionFailed(let reason): return "Transition failed: \(reason)"
        case .assetLoadFailure(let name): return "Failed to load 3D asset: \(name)"
        case .insufficientPermissions: return "Spatial tracking permissions denied."
        }
    }
}

/// A data model representing a complex spatial entity (e.g., a molecular structure or engine component).
struct SpatialEntityModel: Identifiable, Hashable {
    let id: UUID
    let name: String
    let modelName: String // The name of the USDZ file
    let metadata: [String: String]
}

// MARK: - State Management

/// The single source of truth for the application's spatial state.
/// Using @Observable (Swift 5.9+) for efficient UI updates.
@Observable
@MainActor
final class AppState {
    var currentMode: SpatialMode = .dashboard
    var selectedModel: SpatialEntityModel?
    var isTransitioning: Bool = false
    var errorMessage: String?
    
    /// Updates the mode and handles UI side effects.
    func updateMode(_ mode: SpatialMode) {
        self.currentMode = mode
    }
}

/// An Actor responsible for the heavy lifting of spatial orchestration.
/// This ensures that transitions and asset loading do not block the Main Actor (UI).
actor SpatialCoordinator {
    private let state: AppState
    
    init(state: AppState) {
        self.state = state
    }
    
    /// Orchestrates the transition between different spatial modes.
    /// - Parameter targetMode: The mode the user wishes to enter.
    /// - Throws: `SpatialError` if the transition cannot be completed.
    func transition(to targetMode: SpatialMode, for model: SpatialEntityModel? = nil) async throws {
        // 1. Prevent overlapping transitions
        await MainActor.run { state.isTransitioning = true }
        
        // 2. Simulate network or heavy disk I/O for asset preparation
        try await Task.sleep(for: .seconds(1.5))
        
        // 3. Perform logic-based validation
        if targetMode == .modelInspection && model == nil {
            throw SpatialError.transitionFailed(reason: "No model selected for inspection.")
        }
        
        // 4. Update the state on the MainActor
        await MainActor.run {
            self.state.selectedModel = model
            self.state.updateMode(targetMode)
            self.state.isTransitioning = false
        }
    }
}

// MARK: - View Components

/// The primary 2D Dashboard view.
/// This serves as the entry point for user interaction.
struct DashboardView: View {
    @Environment(AppState.self) private var state
    let coordinator: SpatialCoordinator
    let availableModels: [SpatialEntityModel]
    
    var body: some View {
        NavigationStack {
            List(availableModels) { model in
                HStack {
                    VStack(alignment: .leading) {
                        Text(model.name)
                            .font(.headline)
                        Text("Complexity: \(model.metadata["complexity"] ?? "Low")")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    
                    Spacer()
                    
                    Button("Inspect 3D") {
                        Task {
                            do {
                                try await coordinator.transition(to: .modelInspection, for: model)
                            } catch {
                                await handleError(error)
                            }
                        }
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
            .navigationTitle("Data Intelligence")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Enter Immersion") {
                        Task {
                            try? await coordinator.transition(to: .immersiveAnalysis)
                        }
                    }
                }
            }
            .overlay {
                if state.isTransitioning {
                    ProgressView("Preparing Spatial Environment...")
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(10)
                }
            }
        }
    }
    
    @MainActor
    private func handleError(_ error: Error) {
        state.errorMessage = error.localizedDescription
    }
}

/// A 3D Volume view used for detailed inspection of a single model.
/// Uses RealityKit's `RealityView` to render the object.
struct ModelVolumeView: View {
    let model: SpatialEntityModel
    @Environment(AppState.self) private var state
    let coordinator: SpatialCoordinator

    var body: some View {
        RealityView { content in
            // In a production app, we would use Entity.loadAsync
            // For this example, we assume the asset is prepared.
            if let entity = try? await Entity.load(named: model.modelName) {
                entity.scale = [0.01, 0.01, 0.01] // Adjust based on asset scale
                content.add(entity)
            }
        }
        .gesture(TapGesture().onEnded {
            Task {
                // Transitioning from Volume to Immersive Space
                try? await coordinator.transition(to: .immersiveAnalysis)
            }
        })
        .overlay(alignment: .bottom) {
            Button("Expand to Full Immersion") {
                Task {
                    try? await coordinator.transition(to: .immersiveAnalysis)
                }
            }
            .buttonStyle(.borderedProminent)
            .padding(.bottom, 40)
        }
    }
}

/// The Full Immersive Space view.
/// This represents a "diegetic" environment where the user is surrounded by data.
struct ImmersiveAnalysisView: View {
    @Environment(AppState.self) private var state
    let coordinator: SpatialCoordinator

    var body: some View {
        RealityView { content in
            // Create a spatial "data cloud" using primitive entities
            let cloudAnchor = Entity()
            for _ in 0..<50 {
                let sphere = ModelEntity(
                    mesh: .generateSphere(radius: 0.05),
                    materials: [SimpleMaterial(color: .cyan.withAlphaComponent(0.5), isMetallic: true)]
                )
                sphere.position = [
                    Float.random(in: -2...2),
                    Float.random(in: -1...1),
                    Float.random(in: -2...2)
                ]
                cloudAnchor.addChild(sphere)
            }
            content.add(cloudAnchor)
        }
        .gesture(TapGesture().onEnded {
            Task {
                // Return to dashboard
                try? await coordinator.transition(to: .dashboard)
            }
        })
    }
}

// MARK: - Main App Entry Point

@main
struct SpatialIntelligenceApp: App {
    @State private var appState = AppState()
    @State private var coordinator: SpatialCoordinator?
    
    // Mock data for demonstration
    let mockModels = [
        SpatialEntityModel(id: UUID(), name: "Turbine Assembly", modelName: "turbine_v1", metadata: ["complexity": "High"]),
        SpatialEntityModel(id: UUID(), name: "Circuit Board", modelName: "pcb_alpha", metadata: ["complexity": "Medium"]),
        SpatialEntityModel(id: UUID(), name: "Fluid Dynamics Model", modelName: "fluid_sim", metadata: ["complexity": "Extreme"])
    ]

    init() {
        // Initialization of coordinator must happen carefully to ensure 
        // it's ready before the app body executes.
        let state = AppState()
        _appState = State(initialValue: state)
        self.coordinator = SpatialCoordinator(state: state)
    }

    var body: some Scene {
        // 1. The Main Window (2D Dashboard)
        WindowGroup {
            DashboardView(
                coordinator: coordinator!,
                availableModels: mockModels
            )
            .environment(appState)
        }

        // 2. The Volume (3D Inspection)
        // We use a specific window style to trigger the Volume behavior.
        WindowGroup(id: "ModelVolume") {
            if let model = appState.selectedModel {
                ModelVolumeView(model: model, coordinator: coordinator!)
                    .environment(appState)
            }
        }
        .windowStyle(.volumetric)

        // 3. The Immersive Space (Full Immersion)
        ImmersiveSpace(id: "ImmersiveAnalysis") {
            ImmersiveAnalysisView(coordinator: coordinator!)
                .environment(appState)
        }
    }
}
