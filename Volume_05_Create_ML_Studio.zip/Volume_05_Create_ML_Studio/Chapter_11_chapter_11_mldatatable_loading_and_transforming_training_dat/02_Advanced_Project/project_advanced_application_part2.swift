
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CreateML // MLDataTable is part of the CreateML framework

/// Represents metadata associated with a document.
/// This struct conforms to `Codable` for easy serialization/deserialization,
/// simulating data loaded from a JSON file or a database.
struct DocumentMetadata: Codable, Identifiable {
    let id: String // Unique identifier for the document, e.g., "doc_123"
    let fileName: String
    let fileSizeKB: Int
    let pageCount: Int
    let creationDate: Date
    let documentTypeHint: String? // Optional hint, could be "invoice", "report"
}

/// Custom errors specific to our document processing workflow.
enum DocumentProcessingError: Error, LocalizedError {
    case dataLoadingFailed(String)
    case metadataParsingFailed(String)
    case tableTransformationFailed(String)
    case missingRequiredColumn(String)
    case invalidColumnType(column: String, expected: String, actual: String)

    var errorDescription: String? {
        switch self {
        case .dataLoadingFailed(let reason):
            return "Failed to load document data: \(reason)"
        case .metadataParsingFailed(let reason):
            return "Failed to parse document metadata: \(reason)"
        case .tableTransformationFailed(let reason):
            return "Failed to transform MLDataTable: \(reason)"
        case .missingRequiredColumn(let columnName):
            return "Required column '\(columnName)' is missing from MLDataTable."
        case .invalidColumnType(let column, let expected, let actual):
            return "Column '\(column)' has unexpected type. Expected \(expected), got \(actual)."
        }
    }
}

/// An actor responsible for asynchronously loading, transforming, and combining document data
/// and metadata into a unified `MLDataTable` suitable for Create ML model training.
/// This demonstrates advanced `MLDataTable` usage including joining, custom column transformations,
/// and robust error handling within an asynchronous context.
@available(iOS 16.0, macOS 13.0, watchOS 9.0, tvOS 16.0, *) // MLDataTable and async/await availability
actor DocumentProcessor {
    private let fileManager: FileManager
    private let dateFormatter: ISO8601DateFormatter

    /// Initializes the document processor.
    /// - Parameter fileManager: The file manager to use for file operations. Defaults to `FileManager.default`.
    init(fileManager: FileManager = .default) {
        self.fileManager = fileManager
        self.dateFormatter = ISO8601DateFormatter()
        self.dateFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    }

    // MARK: - Simulated Data Loading

    /// Simulates loading raw document text content from a source.
    /// In a real app, this might read from local files, a database, or a network service.
    /// - Parameter docID: The unique identifier for the document.
    /// - Returns: A string containing the document's text content.
    /// - Throws: `DocumentProcessingError.dataLoadingFailed` if the content cannot be loaded.
    private func loadDocumentContent(docID: String) async throws -> String {
        // Simulate network delay or file I/O
        try await Task.sleep(for: .milliseconds(50))
        switch docID {
        case "doc_001": return "This is a detailed invoice for services rendered in Q1. Total amount due: $1200. Payment terms are 30 days."
        case "doc_002": return "Annual report for fiscal year 2023. Highlights include revenue growth of 15% and successful product launches."
        case "doc_003": return "Memorandum regarding the new HR policy update. Effective date: July 1st. Please review carefully."
        case "doc_004": return "Contract agreement between Party A and Party B. Terms and conditions apply. Valid for 12 months from signing date."
        case "doc_005": return "Another invoice, this one for software licenses. Amount: $500. Due immediately."
        default: throw DocumentProcessingError.dataLoadingFailed("Content for \(docID) not found.")
        }
    }

    /// Simulates loading structured metadata for multiple documents.
    /// In a real app, this might parse a JSON file, query a database, or receive an API response.
    /// - Parameter documentIDs: An array of document IDs for which to load metadata.
    /// - Returns: An array of `DocumentMetadata` objects.
    /// - Throws: `DocumentProcessingError.metadataParsingFailed` if metadata cannot be parsed.
    private func loadDocumentMetadata(documentIDs: [String]) async throws -> [DocumentMetadata] {
        // Simulate network delay or file I/O
        try await Task.sleep(for: .milliseconds(100))

        // Example JSON string representing metadata for multiple documents
        let jsonString = """
        [
            { "id": "doc_001", "fileName": "invoice_Q1_2024.pdf", "fileSizeKB": 250, "pageCount": 2, "creationDate": "2024-03-15T10:30:00Z", "documentTypeHint": "invoice" },
            { "id": "doc_002", "fileName": "FY2023_AnnualReport.docx", "fileSizeKB": 1200, "pageCount": 50, "creationDate": "2024-01-20T14:00:00Z", "documentTypeHint": "report" },
            { "id": "doc_003", "fileName": "HR_Policy_Memo.txt", "fileSizeKB": 50, "pageCount": 1, "creationDate": "2024-06-01T09:00:00Z", "documentTypeHint": "memo" },
            { "id": "doc_004", "fileName": "Service_Contract.pdf", "fileSizeKB": 800, "pageCount": 10, "creationDate": "2024-02-28T11:45:00Z", "documentTypeHint": "contract" },
            { "id": "doc_005", "fileName": "Software_Invoice.pdf", "fileSizeKB": 180, "pageCount": 1, "creationDate": "2024-07-01T16:00:00Z", "documentTypeHint": "invoice" },
            { "id": "doc_006", "fileName": "Unclassified_Doc.pdf", "fileSizeKB": 300, "pageCount": 3, "creationDate": "2024-07-05T10:00:00Z" } // doc_006 has no content, simulating partial data
        ]
        """
        guard let data = jsonString.data(using: .utf8) else {
            throw DocumentProcessingError.metadataParsingFailed("Failed to convert JSON string to data.")
        }

        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601 // Matches ISO8601DateFormatter for standard date format
        do {
            let allMetadata = try decoder.decode([DocumentMetadata].self, from: data)
            // Filter for requested IDs, as not all metadata might be relevant
            return allMetadata.filter { documentIDs.contains($0.id) }
        } catch {
            throw DocumentProcessingError.metadataParsingFailed("JSON decoding error: \(error.localizedDescription)")
        }
    }

    // MARK: - MLDataTable Operations

    /// Processes a collection of document IDs, combining their content and metadata
    /// into a single, transformed `MLDataTable` suitable for Create ML model training.
    ///
    /// This method demonstrates several advanced `MLDataTable` features:
    /// 1.  **Asynchronous Data Loading:** Concurrently loads text content and metadata using `withTaskGroup`.
    /// 2.  **MLDataTable Creation from Heterogeneous Sources:** Creates separate tables for text and metadata.
    /// 3.  **Data Joining:** Merges the text and metadata tables using `join(on:type:)` based on a common `documentID`.
    /// 4.  **Custom Column Transformations:**
    ///     *   Text preprocessing (lowercasing, tokenization, word count) on the `rawContent` column.
    ///     *   Feature engineering from metadata (e.g., `fileSizeKB` to `isLargeDocument`, `pageCount` to `isMultiPage`).
    ///     *   Date feature extraction (`creationDate` to `creationMonth`, `creationYear`).
    /// 5.  **Handling Missing Data:** Demonstrates adding default values for optional fields (e.g., `documentTypeHint`).
    /// 6.  **Column Selection:** Filters and reorders columns to prepare the final dataset.
    ///
    /// - Parameter documentIDs: An array of unique identifiers for the documents to process.
    /// - Returns: A fully prepared `MLDataTable`.
    /// - Throws: `DocumentProcessingError` if any step of the processing fails.
    func processDocumentsForTraining(documentIDs: [String]) async throws -> MLDataTable {
        print("1. Starting document processing for IDs: \(documentIDs.joined(separator: ", "))")

        // 1. Asynchronously load all raw data using Swift Concurrency's TaskGroup.
        // This allows fetching content for multiple documents in parallel, improving efficiency.
        var documentContents: [String: String] = [:]
        await withTaskGroup(of: (String, String?).self) { group in
            for id in documentIDs {
                group.addTask {
                    do {
                        let content = try await self.loadDocumentContent(docID: id)
                        return (id, content)
                    } catch {
                        // Log warnings for individual failures but continue processing others
                        print("Warning: Could not load content for \(id): \(error.localizedDescription)")
                        return (id, nil) // Return nil content if loading fails
                    }
                }
            }
            for await (id, content) in group {
                if let content = content {
                    documentContents[id] = content
                }
            }
        }

        let metadataArray: [DocumentMetadata]
        do {
            metadataArray = try await loadDocumentMetadata(documentIDs: documentIDs)
        } catch {
            throw DocumentProcessingError.dataLoadingFailed("Failed to load metadata: \(error.localizedDescription)")
        }

        // Filter out document IDs for which we couldn't load complete data (both content and metadata).
        let availableDocumentIDs = Set(documentContents.keys).intersection(metadataArray.map(\.id))
        guard !availableDocumentIDs.isEmpty else {
            throw DocumentProcessingError.dataLoadingFailed("No complete document data (content + metadata) available for processing.")
        }
        print("   - Successfully loaded content for \(documentContents.count) documents.")
        print("   - Successfully loaded metadata for \(metadataArray.count) documents.")
        print("   - Proceeding with \(availableDocumentIDs.count) complete documents after filtering.")

        // 2. Create initial MLDataTables from raw data.
        // We convert our Swift data structures into dictionaries that MLDataTable can ingest.

        // MLDataTable for document text content
        let textData: [[String: MLDataValueConvertible]] = availableDocumentIDs.compactMap { id in
            guard let content = documentContents[id] else { return nil }
            return ["documentID": id, "rawContent": content]
        }
        var textDataTable: MLDataTable
        do {
            textDataTable = try MLDataTable(dictionary: textData)
            print("2.1 Created textDataTable with \(textDataTable.rows.count) rows and columns: \(textDataTable.columnNames.joined(separator: ", ")).")
        } catch {
            throw DocumentProcessingError.tableTransformationFailed("Failed to create textDataTable: \(error.localizedDescription)")
        }

        // MLDataTable for document metadata
        let metadataData: [[String: MLDataValueConvertible]] = metadataArray.compactMap { meta in
            guard availableDocumentIDs.contains(meta.id) else { return nil }
            return [
                "documentID": meta.id,
                "fileName": meta.fileName,
                "fileSizeKB": meta.fileSizeKB,
                "pageCount": meta.pageCount,
                "creationDate": meta.creationDate,
                "documentTypeHint": meta.documentTypeHint ?? "unknown" // Handle optional with a default string
            ]
        }
        var metadataDataTable: MLDataTable
        do {
            metadataDataTable = try MLDataTable(dictionary: metadataData)
            print("2.2 Created metadataDataTable with \(metadataDataTable.rows.count) rows and columns: \(metadataDataTable.columnNames.joined(separator: ", ")).")
        } catch {
            throw DocumentProcessingError.tableTransformationFailed("Failed to create metadataDataTable: \(error.localizedDescription)")
        }

        // 3. Join the two MLDataTables on `documentID`.
        // This is a crucial "Advanced Application" step, combining features from different sources.
        // An inner join ensures that only documents with both text content and metadata are included.
        var combinedDataTable: MLDataTable
        do {
            combinedDataTable = try textDataTable.join(on: "documentID", how: .inner, other: metadataDataTable)
            print("3. Successfully joined textDataTable and metadataDataTable on 'documentID'. Combined table has \(combinedDataTable.rows.count) rows.")
        } catch {
            throw DocumentProcessingError.tableTransformationFailed("Failed to join MLDataTables: \(error.localizedDescription)")
        }

        // 4. Apply Advanced Custom Column Transformations (Feature Engineering).
        // This step demonstrates using `addColumns(named:transformer:)` to create new features
        // from existing ones, which is fundamental for effective ML models.
        print("4. Applying custom column transformations (Feature Engineering)...")

        // 4.1. Text Feature Engineering: `rawContent` -> `processedContent`, `wordCount`.
        // `processedContent` is lowercased and stripped of punctuation for text analysis.
        // `wordCount` provides a simple numerical feature derived from text length.
        do {
            combinedDataTable = try combinedDataTable.addColumns(named: ["processedContent", "wordCount"]) { (row: MLDataRow) -> (String, Int)? in
                guard let rawContent = row["rawContent"]?.stringValue else { return nil }
                let processed = rawContent.lowercased()
                                          .replacingOccurrences(of: "[^a-z0-9\\s]", with: "", options: .regularExpression) // Remove punctuation
                                          .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression) // Normalize multiple spaces
                let wordCount = processed.split(separator: " ").count
                return (processed, wordCount)
            }
            print("   - Added 'processedContent' (cleaned text) and 'wordCount' columns.")
        } catch {
            throw DocumentProcessingError.tableTransformationFailed("Failed to add text processing columns: \(error.localizedDescription)")
        }

        // 4.2. Metadata Feature Engineering: `fileSizeKB` -> `isLargeDocument`, `pageCount` -> `isMultiPage`.
        // Converting numerical features into boolean flags can sometimes simplify the learning task for models.
        do {
            combinedDataTable = try combinedDataTable.addColumns(named: ["isLargeDocument", "isMultiPage"]) { (row: MLDataRow) -> (Bool, Bool)? in
                guard let fileSizeKB = row["fileSizeKB"]?.int64Value,
                      let pageCount = row["pageCount"]?.int64Value else { return nil }
                let isLarge = fileSizeKB > 1000 // Example threshold for "large" document (1MB)
                let isMultiPage = pageCount > 1
                return (isLarge, isMultiPage)
            }
            print("   - Added 'isLargeDocument' and 'isMultiPage' columns (derived from metadata).")
        } catch {
            throw DocumentProcessingError.tableTransformationFailed("Failed to add metadata feature columns: \(error.localizedDescription)")
        }

        // 4.3. Date Feature Engineering: `creationDate` -> `creationMonth`, `creationYear`.
        // Extracting components from dates can provide cyclical or temporal features useful for models.
        do {
            combinedDataTable = try combinedDataTable.addColumns(named: ["creationMonth", "creationYear"]) { (row: MLDataRow) -> (Int, Int)? in
                guard let dateValue = row["creationDate"]?.dateValue else { return nil }
                let calendar = Calendar.current
                let month = calendar.component(.month, from: dateValue)
                let year = calendar.component(.year, from: dateValue)
                return (month, year)
            }
            print("   - Added 'creationMonth' and 'creationYear' columns (derived from creationDate).")
        } catch {
            throw DocumentProcessingError.tableTransformationFailed("Failed to add date feature columns: \(error.localizedDescription)")
        }

        // 4.4. Verify `documentTypeHint` (target label) - ensure it's present and of the correct type.
        // This column will be used as the 'labelColumn' for classification models.
        guard combinedDataTable.columnNames.contains("documentTypeHint") else {
            throw DocumentProcessingError.missingRequiredColumn("documentTypeHint")
        }
        guard combinedDataTable["documentTypeHint"]?.columnType == .string else {
            throw DocumentProcessingError.invalidColumnType(column: "documentTypeHint", expected: "string", actual: combinedDataTable["documentTypeHint"]?.columnType.description ?? "unknown")
        }
        print("   - Verified 'documentTypeHint' column for target label (classification category).")


        // 5. Select and reorder final columns for clarity and model input.
        // It's good practice to drop intermediate or redundant columns that won't be used by the model.
        let finalColumnNames = [
            "documentID",           // Identifier (often kept for debugging/tracking, not model input)
            "processedContent",     // Main text feature for text classifiers
            "wordCount",            // Numerical feature
            "fileSizeKB",           // Original metadata feature
            "isLargeDocument",      // Derived boolean feature
            "pageCount",            // Original metadata feature
            "isMultiPage",          // Derived boolean feature
            "creationMonth",        // Derived numerical feature
            "creationYear",         // Derived numerical feature
            "documentTypeHint"      // Target label column for classification
        ]

        var finalDataTable: MLDataTable
        do {
            finalDataTable = try combinedDataTable[finalColumnNames]
            print("5. Final MLDataTable prepared with columns: \(finalDataTable.columnNames.joined(separator: ", "))")
            print("   - First 3 rows of the final table for inspection:")
            print(finalDataTable.head(3)) // Display a few rows to verify transformations
        } catch {
            throw DocumentProcessingError.tableTransformationFailed("Failed to select final columns: \(error.localizedDescription)")
        }

        print("6. Document processing complete. The MLDataTable is now ready for Create ML model training.")
        return finalDataTable
    }

    /// Saves the processed `MLDataTable` to a file, typically a `.mltable` or `.csv` for inspection.
    /// This is useful for persisting the prepared data or for debugging.
    /// - Parameters:
    ///   - dataTable: The `MLDataTable` to save.
    ///   - url: The file URL where the table should be saved.
    /// - Throws: `DocumentProcessingError.tableTransformationFailed` if saving fails.
    func saveDataTable(_ dataTable: MLDataTable, to url: URL) throws {
        do {
            try dataTable.write(to: url, atomically: true)
            print("MLDataTable successfully saved to: \(url.lastPathComponent)")
        } catch {
            throw DocumentProcessingError.tableTransformationFailed("Failed to save MLDataTable to \(url.lastPathComponent): \(error.localizedDescription)")
        }
    }
}

// MARK: - Application Entry Point (Simulation)

/// Main function to simulate the app's data processing flow within DocInsight Pro.
/// This demonstrates how the `DocumentProcessor` actor would be used in an application.
@main
@available(iOS 16.0, macOS 13.0, watchOS 9.0, tvOS 16.0, *)
struct DocInsightProApp {
    static func main() async {
        let processor = DocumentProcessor()
        // Define the set of document IDs that the app wants to process for training.
        // Note: "doc_006" is included to demonstrate handling of partial data (missing content).
        let documentIDsToProcess = ["doc_001", "doc_002", "doc_003", "doc_004", "doc_005", "doc_006"]

        do {
            // Initiate the advanced document processing workflow.
            let trainingDataTable = try await processor.processDocumentsForTraining(documentIDs: documentIDsToProcess)

            // Simulate saving the prepared table to a temporary file.
            let tempDirectory = URL(fileURLWithPath: NSTemporaryDirectory())
            let outputURL = tempDirectory.appendingPathComponent("processed_documents.mltable")
            try processor.saveDataTable(trainingDataTable, to: outputURL)

            print("\n--- Final Training Data Table Summary ---")
            print("Shape: \(trainingDataTable.rows.count) rows, \(trainingDataTable.columnNames.count) columns")
            print("Columns and Types:")
            for (name, type) in trainingDataTable.columnNames.map({ ($0, trainingDataTable[$0]!.columnType) }) {
                print("  - \(name): \(type)")
            }

            // Illustrative example of how this table would then be used for training:
            // (This part is outside the scope of Chapter 11 but shows the ultimate goal)
            /*
            print("\n--- Initiating Create ML Model Training (Illustrative) ---")
            let textClassifier = try MLTextClassifier(trainingData: trainingDataTable,
                                                      textColumn: "processedContent",
                                                      labelColumn: "documentTypeHint")
            print("✅ Model training complete! The classifier is now ready to be evaluated and deployed.")
            // Further steps would involve evaluating the model, saving it, and integrating it into the app.
            */

        } catch {
            print("\n🚨 Fatal Error during document processing: \(error.localizedDescription)")
            if let docError = error as? DocumentProcessingError {
                print("   Detailed Reason: \(docError.errorDescription ?? "No specific description available.")")
            }
        }
    }
}
