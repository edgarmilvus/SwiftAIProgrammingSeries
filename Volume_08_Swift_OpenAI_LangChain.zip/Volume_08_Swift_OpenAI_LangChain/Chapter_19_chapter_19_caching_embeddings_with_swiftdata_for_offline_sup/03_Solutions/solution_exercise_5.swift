
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import SwiftData

actor DatabaseMaintenanceActor {
    private let container: ModelContainer
    private let modelID = "text-embedding-3-large" // The new target model

    init(container: ModelContainer) {
        self.container = container
    }

    // 1. LRU Pruning
    func pruneOldEmbeddings(keepingLastCount: Int) async throws {
        let context = ModelContext(container)
        
        // Fetch chunks sorted by lastAccessed ascending (oldest first)
        let descriptor = FetchDescriptor<TextChunk>(sortBy: [SortDescriptor(\.lastAccessed)])
        let allChunks = try context.fetch(descriptor)
        
        if allChunks.count > keepingLastCount {
            let numToDelete = allChunks.count - keepingLastCount
            let chunksToDelete = allChunks.prefix(numToDelete)
            
            for chunk in chunksToDelete {
                context.delete(chunk)
            }
            try context.save()
        }
    }

    // 2. Model Migration / Re-indexing
    func reindexAllChunks(toNewModel newModelID: String, apiService: EmbeddingService) async throws {
        let context = ModelContext(container)
        let descriptor = FetchDescriptor<TextChunk>()
        let allChunks = try context.fetch(descriptor)
        
        let batchSize = 10
        
        for (index, chunk) in allChunks.enumerated() {
            // Check for cancellation to respect system resources
            try Task.checkCancellation()
            
            // Only re-index if the model is actually different
            if chunk.modelIdentifier != newModelID {
                // Call API (via the service)
                // Note: In real code, ensure apiService is accessible to this actor
                let newVector = try await simulateNewEmbedding(for: chunk.content)
                
                chunk.embedding = newVector
                chunk.modelIdentifier = newModelID
                chunk.timestamp = .now
            }
            
            // Batch saving to prevent memory spikes and ensure persistence
            if index % batchSize == 0 {
                try context.save()
                // Small sleep to avoid hitting rate limits aggressively
                try await Task.sleep(for: .milliseconds(500))
            }
        }
        
        try context.save() // Final save
    }
    
    private func simulateNewEmbedding(for text: String) async throws -> [Float] {
        return (0..<1536).map { _ in Float.random(in: -1...1) }
    }
}
