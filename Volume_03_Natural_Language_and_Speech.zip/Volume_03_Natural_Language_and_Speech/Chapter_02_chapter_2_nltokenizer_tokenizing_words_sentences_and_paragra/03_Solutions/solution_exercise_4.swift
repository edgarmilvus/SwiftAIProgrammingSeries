
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import NaturalLanguage

/// A class that parses a document into sentences and allows sequential navigation.
class SentenceNavigator {
    private let documentText: String
    private let sentenceRanges: [Range<String.Index>]
    private(set) var currentIndex: Int = 0 // `private(set)` allows external read, internal write.

    /// Initializes the navigator with the full document text.
    /// All sentences are tokenized and their ranges are stored upon initialization.
    ///
    /// - Parameter documentText: The complete string content of the document.
    init(documentText: String) {
        self.documentText = documentText
        var ranges: [Range<String.Index>] = []

        // Handle empty document immediately.
        guard !documentText.isEmpty else {
            self.sentenceRanges = []
            return
        }

        // Initialize NLTokenizer for sentence units.
        // Tokenization happens once during initialization for efficiency.
        let sentenceTokenizer = NLTokenizer(unit: .sentence)
        sentenceTokenizer.string = documentText

        // Enumerate all sentences and store their ranges.
        sentenceTokenizer.enumerateTokens(in: documentText.startIndex..<documentText.endIndex, unit: .sentence, using: { tokenRange, _ in
            ranges.append(tokenRange)
            return true // Continue enumeration
        })
        self.sentenceRanges = ranges

        // Ensure currentIndex is valid if there are sentences.
        if !sentenceRanges.isEmpty {
            self.currentIndex = 0
        } else {
            self.currentIndex = -1 // Indicate no current sentence if document is empty
        }
    }

    /// Returns the current sentence as a String.
    /// - Returns: The current sentence, or `nil` if there are no sentences or `currentIndex` is invalid.
    func currentSentence() -> String? {
        guard currentIndex >= 0 && currentIndex < sentenceRanges.count else {
            return nil // No valid current sentence.
        }
        let range = sentenceRanges[currentIndex]
        return String(documentText[range])
    }

    /// Advances to the next sentence and returns it.
    /// If already at the last sentence, it stays there and returns the last sentence.
    /// - Returns: The next sentence, or the current (last) sentence if at the end. Returns `nil` if no sentences exist.
    @discardableResult // Suppresses warning if return value is not used.
    func nextSentence() -> String? {
        guard !sentenceRanges.isEmpty else {
            return nil
        }
        if currentIndex < sentenceRanges.count - 1 {
            currentIndex += 1
        }
        return currentSentence()
    }

    /// Moves to the previous sentence and returns it.
    /// If already at the first sentence, it stays there and returns the first sentence.
    /// - Returns: The previous sentence, or the current (first) sentence if at the beginning. Returns `nil` if no sentences exist.
    @discardableResult // Suppresses warning if return value is not used.
    func previousSentence() -> String? {
        guard !sentenceRanges.isEmpty else {
            return nil
        }
        if currentIndex > 0 {
            currentIndex -= 1
        }
        return currentSentence()
    }

    /// Resets the navigator to the first sentence.
    func reset() {
        if !sentenceRanges.isEmpty {
            currentIndex = 0
        } else {
            currentIndex = -1
        }
    }

    /// Returns the total number of sentences in the document.
    var numberOfSentences: Int {
        return sentenceRanges.count
    }
}

// Example Usage:
let document = "This is the first sentence. Here is the second sentence. And finally, the third one. What a great document!"
let navigator = SentenceNavigator(documentText: document)

print("--- Document Navigation ---")
print("Total sentences: \(navigator.numberOfSentences)")
print("Current: \(navigator.currentSentence() ?? "No sentence")") // "This is the first sentence."
print("Index: \(navigator.currentIndex)")

print("Next: \(navigator.nextSentence() ?? "No sentence")")    // "Here is the second sentence."
print("Index: \(navigator.currentIndex)")

print("Next: \(navigator.nextSentence() ?? "No sentence")")    // "And finally, the third one."
print("Index: \(navigator.currentIndex)")

print("Next: \(navigator.nextSentence() ?? "No sentence")")    // "What a great document!"
print("Index: \(navigator.currentIndex)")

print("Next (at end): \(navigator.nextSentence() ?? "No sentence")") // "What a great document!" (stays at last)
print("Index: \(navigator.currentIndex)")

print("Previous: \(navigator.previousSentence() ?? "No sentence")") // "And finally, the third one."
print("Index: \(navigator.currentIndex)")

print("Previous: \(navigator.previousSentence() ?? "No sentence")") // "Here is the second sentence."
print("Index: \(navigator.currentIndex)")

print("Previous: \(navigator.previousSentence() ?? "No sentence")") // "This is the first sentence."
print("Index: \(navigator.currentIndex)")

print("Previous (at start): \(navigator.previousSentence() ?? "No sentence")") // "This is the first sentence." (stays at first)
print("Index: \(navigator.currentIndex)")

print("\n--- Empty Document Test ---")
let emptyDocNavigator = SentenceNavigator(documentText: "")
print("Total sentences: \(emptyDocNavigator.numberOfSentences)") // 0
print("Current: \(emptyDocNavigator.currentSentence() ?? "No sentence")") // No sentence
print("Next: \(emptyDocNavigator.nextSentence() ?? "No sentence")") // No sentence

print("\n--- Single Sentence Document Test ---")
let singleSentenceDoc = "This is the only sentence."
let singleSentenceNavigator = SentenceNavigator(documentText: singleSentenceDoc)
print("Total sentences: \(singleSentenceNavigator.numberOfSentences)") // 1
print("Current: \(singleSentenceNavigator.currentSentence() ?? "No sentence")") // This is the only sentence.
print("Next: \(singleSentenceNavigator.nextSentence() ?? "No sentence")") // This is the only sentence.
print("Previous: \(singleSentenceNavigator.previousSentence() ?? "No sentence")") // This is the only sentence.
