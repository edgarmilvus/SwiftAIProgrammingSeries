
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import OSLog

// MARK: - Error Domain

/// Represents all possible failure states within the AI Networking Layer.
/// Using a structured error enum allows the UI to provide specific feedback to the user.
enum AIClientError: Error, LocalizedError {
    case invalidURL
    case requestFailed(statusCode: Int, data: Data?)
    case decodingError(DecodingError)
    case networkError(Error)
    case unauthorized
    case serverError(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "The constructed URL was invalid."
        case .requestFailed(let code, _): return "Server returned an error code: \(code)."
        case .decodingError(let error): return "Failed to parse the AI response: \(error.localizedDescription)"
        case .networkError(let error): return "Network connectivity issue: \(error.localizedDescription)"
        case .unauthorized: return "API Key is invalid or expired."
        case .serverError(let message): return "AI Server Error: \(message)"
        }
    }
}

// MARK: - Endpoint Protocol

/// A protocol defining the requirements for an API request.
/// This allows us to define different AI features (Chat, Image, Embedding) 
/// as distinct types rather than hardcoding strings in the client.
protocol APIEndpoint {
    var baseURL: URL { get }
    var path: String { get }
    var method: HTTPMethod { get }
    var headers: [String: String] { get }
    var body: Encodable? { get }
}

enum HTTPMethod: String {
    case get = "GET"
    case post = "POST"
}

// MARK: - Models (Codable)

/// The request structure for an OpenAI-compatible Chat Completion.
struct ChatCompletionRequest: Codable, Sendable {
    let model: String
    let messages: [ChatMessage]
    let temperature: Double?
    
    struct ChatMessage: Codable, Sendable {
        let role: String
        let content: String
    }
}

/// The response structure for an OpenAI-compatible Chat Completion.
struct ChatCompletionResponse: Codable, Sendable {
    let id: String
    let choices: [Choice]
    
    struct Choice: Codable, Sendable {
        let message: ChatMessage
        let finishReason: String?
        
        struct ChatMessage: Codable, Sendable {
            let role: String
            let content: String
        }
    }
}

/// A specialized error model returned by many LLM APIs when a request fails.
struct APIErrorResponse: Codable {
    let error: ErrorDetail
    struct ErrorDetail: Codable {
        let message: String
        let type: String
    }
}

// MARK: - The AI Client (Actor)

/// `AIClient` is an `actor`, ensuring that all network operations and 
/// internal state (like the API key) are isolated to a single thread of execution.
/// This prevents data races in high-concurrency environments like a chat app.
@available(iOS 18.0, macOS 15.0, *)
actor AIClient {
    private let apiKey: String
    private let session: URLSession
    private let logger = Logger(subsystem: "com.ai.app", category: "Networking")
    
    /// Initializes the client with a secure API key and a custom URLSession.
    /// - Parameters:
    ///   - apiKey: The Bearer token for authentication.
    ///   - configuration: Custom URLSessionConfiguration for advanced tuning (timeouts, etc).
    init(apiKey: String, configuration: URLSessionConfiguration = .default) {
        self.apiKey = apiKey
        self.session = URLSession(configuration: configuration)
    }
    
    /// Executes a type-safe request against a given endpoint.
    /// - Parameter endpoint: A type conforming to `APIEndpoint`.
    /// - Returns: A decoded object of type `T`.
    /// - Throws: `AIClientError` if the request or decoding fails.
    func execute<T: Decodable>(_ endpoint: APIEndpoint) async throws -> T {
        // 1. Construct the URL
        let url = endpoint.baseURL.appendingPathComponent(endpoint.path)
        var request = URLRequest(url: url)
        request.httpMethod = endpoint.method.rawValue
        
        // 2. Set Headers
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        endpoint.headers.forEach { request.setValue($1, forHTTPHeaderField: $0) }
        
        // 3. Encode Body
        if let body = endpoint.body {
            let encoder = JSONEncoder()
            // Use snake_case to match OpenAI's API standard
            encoder.keyEncodingStrategy = .convertToSnakeCase 
            request.httpBody = try encoder.encode(body)
        }
        
        logger.info("🚀 Sending \(endpoint.method.rawValue) request to \(url.absoluteString)")
        
        // 4. Perform Network Task
        let data: Data
        let response: URLResponse
        
        do {
            (data, response) = try await session.data(for: request)
        } catch {
            logger.error("❌ Network transport error: \(error.localizedDescription)")
            throw AIClientError.networkError(error)
        }
        
        // 5. Validate HTTP Status Code
        guard let httpResponse = response as? HTTPURLResponse else {
            throw AIClientError.requestFailed(statusCode: 0, data: nil)
        }
        
        try validateResponse(httpResponse, data: data)
        
        // 6. Decode Successful Response
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        
        do {
            return try decoder.decode(T.self, from: data)
        } catch let decodingError as DecodingError {
            logger.error("❌ Decoding failed: \(decodingError.localizedDescription)")
            throw AIClientError.decodingError(decodingError)
        } catch {
            throw error
        }
    }
    
    /// Private helper to handle HTTP status code validation and API-specific error parsing.
    private func validateResponse(_ response: HTTPURLResponse, data: Data) throws {
        switch response.statusCode {
        case 200...299:
            return // Success
        case 401:
            throw AIClientError.unauthorized
        case 400...499, 500...599:
            // Attempt to parse the error message from the API itself
            if let apiError = try? JSONDecoder().decode(APIErrorResponse.self, from: data) {
                throw AIClientError.serverError(apiError.error.message)
            } else {
                throw AIClientError.requestFailed(statusCode: response.statusCode, data: data)
            }
        default:
            throw AIClientError.requestFailed(statusCode: response.statusCode, data: data)
        }
    }
}

// MARK: - Concrete Endpoint Implementation

/// A concrete implementation of an endpoint for Chat Completions.
struct ChatEndpoint: APIEndpoint {
    let baseURL = URL(string: "https://api.openai.com/v1")!
    let path = "/chat/completions"
    let method: HTTPMethod = .post
    let headers: [String : String] = [:]
    let body: Encodable?
}

// MARK: - Real-World Usage Example

@available(iOS 18.0, macOS 15.0, *)
struct AIServiceDemo {
    func runDemo() async {
        let client = AIClient(apiKey: "sk-your-api-key-here")
        
        let chatRequest = ChatCompletionRequest(
            model: "gpt-4o",
            messages: [
                .init(role: "system", content: "You are a helpful Swift developer assistant."),
                .init(role: "user", content: "Explain the benefit of using Actors in Swift 6.")
            ],
            temperature: 0.7
        )
        
        let endpoint = ChatEndpoint(body: chatRequest)
        
        do {
            print("--- Starting AI Request ---")
            let response: ChatCompletionResponse = try await client.execute(endpoint)
            
            if let firstChoice = response.choices.first {
                print("🤖 AI Response: \(firstChoice.message.content)")
            }
        } catch let error as AIClientError {
            print("⚠️ AI Client Error: \(error.localizedDescription)")
        } catch {
            print("❓ Unexpected Error: \(error)")
        }
    }
}
