
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI

// MARK: - AIConfidenceLevel Enum

enum AIConfidenceLevel: CaseIterable, Identifiable {
    case high, medium, low, uncertain

    var id: Self { self } // Conformance to Identifiable for ForEach if needed

    var color: Color {
        switch self {
        case .high: return .green
        case .medium: return .orange
        case .low: return .red
        case .uncertain: return .gray
        }
    }

    var description: String {
        switch self {
        case .high: return "Highly Confident"
        case .medium: return "Moderately Confident"
        case .low: return "Low Confidence"
        case .uncertain: return "Uncertain / Needs Review"
        }
    }
}

// MARK: - Enhanced ConfidenceBar Component

struct ConfidenceBar: View {
    let confidence: Double // Raw confidence value (0.0 - 1.0)
    let level: AIConfidenceLevel // Categorical confidence level
    let height: CGFloat = 20
    let cornerRadius: CGFloat = 8

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: height)

                RoundedRectangle(cornerRadius: cornerRadius)
                    // Use the color derived from the AIConfidenceLevel
                    .fill(level.color)
                    .frame(width: geometry.size.width * CGFloat(confidence), height: height)
                    .animation(.easeInOut(duration: 0.5), value: confidence)
            }
        }
        .frame(height: height)
    }
}

// MARK: - ContentView Integration (Simulating AI Chatbot)

struct ContentView: View {
    @State private var aiResponse: String = "Welcome! How can I help you today?"
    @State private var aiConfidence: Double = 0.85
    @State private var aiConfidenceLevel: AIConfidenceLevel = .high

    var body: some View {
        VStack(spacing: 25) {
            Text("AI Chatbot Response")
                .font(.title2)
                .fontWeight(.bold)

            // Simulated AI Response Text
            Text(aiResponse)
                .font(.body)
                .padding(.horizontal)
                .multilineTextAlignment(.center)
                .frame(minHeight: 80) // Give some space for longer responses

            // Enhanced ConfidenceBar
            ConfidenceBar(confidence: aiConfidence, level: aiConfidenceLevel)
                .padding(.horizontal)

            // Display the descriptive text from the AIConfidenceLevel
            Text("AI's Assessment: \(aiConfidenceLevel.description) (\(String(format: "%.0f%%", aiConfidence * 100)))")
                .font(.subheadline)
                .foregroundColor(.secondary)

            Spacer()

            Button("Simulate New AI Response") {
                simulateAIResponse()
            }
            .buttonStyle(.borderedProminent)
            .tint(.purple) // Swift 6 tint modifier
        }
        .padding()
    }

    // Helper function to simulate AI responses
    private func simulateAIResponse() {
        let responses = [
            "The capital of France is Paris.",
            "Water boils at 100 degrees Celsius at sea level.",
            "I'm not entirely sure, but I think the answer is related to quantum mechanics.",
            "That's a complex question, I might need more context.",
            "The square root of 9 is 3.",
            "I predict a 70% chance of rain tomorrow in London.",
            "I'm still learning and cannot provide an answer to that."
        ]
        aiResponse = responses.randomElement() ?? "Error: No response."

        // Generate random confidence and determine level
        let randomConfidence = Double.random(in: 0.05...0.99)
        aiConfidence = randomConfidence

        if randomConfidence >= 0.8 {
            aiConfidenceLevel = .high
        } else if randomConfidence >= 0.5 {
            aiConfidenceLevel = .medium
        } else if randomConfidence >= 0.2 {
            aiConfidenceLevel = .low
        } else {
            aiConfidenceLevel = .uncertain
        }
    }
}

// MARK: - Preview Provider

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
