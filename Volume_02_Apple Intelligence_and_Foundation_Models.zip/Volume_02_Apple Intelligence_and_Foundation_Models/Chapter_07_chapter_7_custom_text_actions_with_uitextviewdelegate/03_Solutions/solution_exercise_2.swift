
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import Foundation // In a real iOS 18 project, you would import Foundation.AI

// Reusing the MockAITextGenerator and AI alias from Exercise 1.
// In a real project, these would be defined once or imported from the framework.

class RephraseSentenceViewController: UIViewController, UITextViewDelegate {

    private lazy var textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = UIFont.preferredFont(forTextStyle: .body)
        tv.isEditable = true
        tv.isSelectable = true
        tv.layer.borderColor = UIColor.lightGray.cgColor
        tv.layer.borderWidth = 1.0
        tv.layer.cornerRadius = 8.0
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        tv.text = "The quick brown fox jumps over the lazy dog. This sentence is a classic example of a pangram. It is often used for testing typefaces and keyboards. We can try to rephrase this for better flow or different emphasis. Select one of these sentences to rephrase it."
        return tv
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Rephrase Sentence"
        view.backgroundColor = .systemBackground
        setupTextView()
    }

    private func setupTextView() {
        view.addSubview(textView)
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 300)
        ])
        textView.delegate = self
    }

    // MARK: - UITextViewDelegate

    @available(iOS 16.0, *) // textInput(_:primaryActionFor:sender:) is available from iOS 16
    func textInput(_ textInput: UITextInput, primaryActionFor textRange: UITextRange, sender: Any?) -> UIAction? {
        guard let textView = textInput as? UITextView else { return nil }

        // Get the currently selected text
        guard let selectedText = textView.text(in: textRange), !selectedText.isEmpty else {
            return nil // No text selected, no primary action
        }

        // Heuristic: Only offer rephrase if selection is relatively short (e.g., <= 200 chars)
        // and doesn't span multiple paragraphs. A more robust solution would parse sentences.
        if selectedText.count > 200 || selectedText.contains("\n\n") {
            return nil // Too long or multiple paragraphs, likely not a single sentence
        }

        // Create the custom "Rephrase Sentence" action
        let rephraseAction = UIAction(title: "Rephrase Sentence", image: UIImage(systemName: "text.bubble")) { [weak self] _ in
            self?.performRephrasing(for: selectedText, in: textRange)
        }
        return rephraseAction
    }

    // MARK: - AI Integration

    private func performRephrasing(for text: String, in textRange: UITextRange) {
        // Feature availability check for iOS 18
        guard #available(iOS 18.0, *) else {
            self.showAlert(title: "Feature Unavailable", message: "This AI feature requires iOS 18 or later.")
            return
        }

        self.showLoadingAlert(message: "Rephrasing...")

        Task {
            do {
                let prompt = "Rephrase the following sentence for clarity and style: '\(text)'"
                let result = try await AI.TextGenerator.generate(prompt)
                
                DispatchQueue.main.async {
                    self.dismissLoadingAlert()
                    // Replace the selected text with the rephrased version
                    self.textView.replace(textRange, withText: result.text)
                    // Optionally, reset selection or move cursor after replacement
                    self.textView.selectedTextRange = nil // Deselect the text
                }
            } catch {
                DispatchQueue.main.async {
                    self.dismissLoadingAlert()
                    self.showAlert(title: "Error", message: error.localizedDescription)
                }
            }
        }
    }

    // MARK: - UI Utility Functions (reused from Exercise 1)

    private var loadingAlert: UIAlertController?

    private func showLoadingAlert(message: String) {
        loadingAlert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        let indicator = UIActivityIndicatorView(style: .medium)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        loadingAlert?.view.addSubview(indicator)
        
        NSLayoutConstraint.activate([
            indicator.centerXAnchor.constraint(equalTo: loadingAlert!.view.centerXAnchor),
            indicator.centerYAnchor.constraint(equalTo: loadingAlert!.view.centerYAnchor, constant: 20)
        ])
        indicator.startAnimating()
        present(loadingAlert!, animated: true)
    }

    private func dismissLoadingAlert() {
        loadingAlert?.dismiss(animated: true)
        loadingAlert = nil
    }

    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
