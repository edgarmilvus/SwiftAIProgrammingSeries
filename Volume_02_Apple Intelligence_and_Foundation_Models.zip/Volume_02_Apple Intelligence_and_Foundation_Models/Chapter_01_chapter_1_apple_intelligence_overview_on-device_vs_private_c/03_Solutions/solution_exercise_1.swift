
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import CoreML // Included to signify potential Core ML integration, though not directly used in mock

@available(iOS 18.0, macOS 15.0, *)
class NoteSummarizer {
    /// Summarizes the given text using an on-device model.
    /// This method simulates interaction with Apple Intelligence APIs like Foundation.ML's
    /// text summarization or a custom Core ML model. All processing is strictly on-device.
    ///
    /// - Parameter text: The input text to summarize.
    /// - Returns: A summarized version of the text, or nil if summarization fails or is not applicable.
    /// - Throws: An error if the simulated summarization process encounters an issue.
    func summarize(text: String) async throws -> String? {
        // --- ON-DEVICE PROCESSING BEGINS ---
        // This block simulates the execution of a local machine learning model.
        // No data leaves the user's device.

        // Simulate a brief processing time for an on-device model inference.
        // In a real scenario, this would be the actual computation time of the ML model.
        try await Task.sleep(for: .milliseconds(500))

        // Basic validation: A very short text might not need summarization or be summarizable.
        guard text.count >= 50 else {
            return "Note is too short for effective summarization. Original: \"\(text)\""
        }

        // --- MOCK SUMMARIZATION LOGIC ---
        // In a production application, this would be replaced by a call to:
        // 1. Foundation.ML's high-level text summarization API (e.g., MLTextSummarizer).
        // 2. Direct inference with a Core ML model (e.g., using a compiled .mlmodel).
        //
        // For demonstration, we'll take the first third of the words as a "summary".
        let words = text.split(separator: " ").filter { !$0.isEmpty } // Split by space, remove empty strings
        let numberOfWords = words.count
        let summaryWordCount = max(10, numberOfWords / 3) // Ensure a minimum summary length
        
        let summaryWords = words.prefix(summaryWordCount)
        let summary = summaryWords.joined(separator: " ") + "..."
        // --- ON-DEVICE PROCESSING ENDS ---

        return summary
    }
}

// Example Usage:
@available(iOS 18.0, macOS 15.0, *)
func demonstrateSummarization() async {
    let summarizer = NoteSummarizer()
    let longNote = """
    This is a very long note about the importance of on-device machine learning for user privacy and performance.
    It details how Apple Intelligence leverages local models to process sensitive data without sending it to external servers.
    This approach ensures that user data remains secure and private, enhancing trust and user experience.
    Furthermore, on-device processing reduces latency, making applications feel more responsive and fluid.
    The future of intelligent applications heavily relies on efficient local computation, especially for tasks
    involving personal information. This methodology aligns perfectly with Apple's core values regarding privacy by design.
    """

    print("--- Exercise 1: On-Device Note Summarization ---")
    print("Original Note (first 100 chars): \"\(longNote.prefix(100))...\"")

    do {
        if let summary = try await summarizer.summarize(text: longNote) {
            print("Summary: \"\(summary)\"")
        }

        let shortNote = "Hello, this is a short note."
        if let shortSummary = try await summarizer.summarize(text: shortNote) {
            print("Short Note Summary: \"\(shortSummary)\"")
        }
    } catch {
        print("Error summarizing note: \(error.localizedDescription)")
    }
    print("---------------------------------------------------\n")
}

// To run this example in a playground or application:
// Task {
//     await demonstrateSummarization()
// }
