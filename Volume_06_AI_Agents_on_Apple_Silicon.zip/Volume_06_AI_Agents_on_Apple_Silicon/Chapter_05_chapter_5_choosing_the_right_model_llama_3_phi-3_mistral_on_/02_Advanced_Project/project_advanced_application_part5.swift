
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

// LlamaCppWrapperProtocol.swift
/// A protocol defining the interface for interacting with a llama.cpp-like inference engine.
/// This abstraction allows for different concrete implementations (e.g., real binding, mock).
protocol LlamaCppWrapperProtocol: Sendable {
    /// Loads an LLM model from the specified path.
    /// - Parameter modelPath: The file path to the GGUF model file.
    /// - Throws: `LLMInferenceError` if the model cannot be loaded.
    func loadModel(from modelPath: String) async throws

    /// Unloads the currently loaded model, releasing its resources.
    func unloadModel() async

    /// Generates a response from the loaded LLM for a given prompt.
    /// - Parameters:
    ///   - prompt: The input text prompt for the LLM.
    ///   - temperature: Controls the randomness of the output (e.g., 0.0 for deterministic, 1.0 for creative).
    ///   - maxTokens: The maximum number of tokens to generate.
    /// - Returns: An `AsyncThrowingStream` of `String` tokens, allowing for real-time streaming of the response.
    /// - Throws: `LLMInferenceError` if inference fails or no model is loaded.
    func generate(prompt: String, temperature: Float, maxTokens: Int) async throws -> AsyncThrowingStream<String, Error>
}
