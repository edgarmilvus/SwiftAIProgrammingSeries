
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import MLX

@available(iOS 18.0, macOS 15.0, *)
class LinearPredictor: MLXNN.Module {
    // 1. Define a Custom MLXNN.Module
    // These MLXArray properties will automatically be tracked as trainable parameters
    let weight: MLXArray
    let bias: MLXArray

    required init() {
        super.init()
        // 2. Initialize Parameters
        // Using arbitrary float values. MLXArray directly infers the shape.
        self.weight = MLXArray(0.7) // Represents 'm' in y = mx + c
        self.bias = MLXArray(0.2)   // Represents 'c' in y = mx + c

        // Optionally, you could initialize with random values:
        // self.weight = MLXArray.randomUniform(low: -1.0, high: 1.0, shape: [1])
        // self.bias = MLXArray.randomUniform(low: -1.0, high: 1.0, shape: [1])
    }

    // 3. Implement Forward Pass
    override func callAsFunction(_ inputs: MLXArray) -> MLXArray {
        // Implement the linear regression formula: output = input * weight + bias
        return inputs * weight + bias
    }
}

@available(iOS 18.0, macOS 15.0, *)
func testLinearPredictor() {
    // 4. Perform Inference
    let predictor = LinearPredictor()

    print("--- Linear Predictor Inference ---")
    print("Model Parameters: weight=\(predictor.weight.item()), bias=\(predictor.bias.item())")

    // Test with a few sample MLXArray inputs
    let input1 = MLXArray(1.0)  // 1 hour usage
    let prediction1 = predictor(input1)
    print("Input: \(input1.item()) hours, Predicted Satisfaction: \(prediction1.item())") // Expected: 1.0 * 0.7 + 0.2 = 0.9

    let input2 = MLXArray(5.0)  // 5 hours usage
    let prediction2 = predictor(input2)
    print("Input: \(input2.item()) hours, Predicted Satisfaction: \(prediction2.item())") // Expected: 5.0 * 0.7 + 0.2 = 3.7

    let input3 = MLXArray(10.0) // 10 hours usage
    let prediction3 = predictor(input3)
    print("Input: \(input3.item()) hours, Predicted Satisfaction: \(prediction3.item())") // Expected: 10.0 * 0.7 + 0.2 = 7.2

    let batchInput = MLXArray([1.0, 5.0, 10.0]) // Batch of inputs
    let batchPredictions = predictor(batchInput)
    print("Batch Inputs: \(batchInput.description), Batch Predictions: \(batchPredictions.description)")
}

// To run this, you would call:
// testLinearPredictor()
