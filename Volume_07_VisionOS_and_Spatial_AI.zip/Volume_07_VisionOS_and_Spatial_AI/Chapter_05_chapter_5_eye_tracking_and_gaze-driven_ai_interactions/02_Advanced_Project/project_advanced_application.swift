
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift
// Note: In a real project, this would be in your Package.swift file.
/*
let package = Package(
    name: "SpatialIntelligence",
    platforms: [.visionOS(.v1)],
    products: [
        .library(name: "SpatialIntelligence", targets: ["SpatialIntelligence"]),
    ],
    dependencies: [],
    targets: [
        .target(
            name: "SpatialIntelligence",
            dependencies: [],
            path: "Sources"
        )
    ]
)
*/

import SwiftUI
import RealityKit
import ARKit
import Vision
import CoreML
import Combine

// MARK: - Domain Models

/// Represents the semantic meaning of an object identified via AI.
enum SpatialContext: Sendable {
    case unknown
    case object(name: String, properties: [String: String])
    case actionable(action: String, targetID: UUID)
    case error(String)
}

/// Errors specific to the Gaze and AI pipeline.
enum SpatialIntelligenceError: Error, LocalizedError {
    case gazeSignalLost
    case visionAnalysisFailed(String)
    case modelLoadingError
    case entityNotFound

    var errorDescription: String? {
        switch self {
        case .gazeSignalLost: return "The gaze tracking signal was interrupted."
        case .visionAnalysisFailed(let msg): return "AI Analysis failed: \(msg)"
        case .modelLoadingError: return "Failed to initialize CoreML model."
        case .entityNotFound: return "No valid spatial entity found at gaze location."
        }
    }
}

/// A container for the state of a gaze interaction.
struct GazeInteractionState: Sendable {
    let entityID: UUID
    let startTime: ContinuousClock.Instant
    let lastObservedTime: ContinuousClock.Instant
    let dwellDuration: Duration
}

// MARK: - The Intent Engine

/// `GazeIntentEngine` is a Swift 6 Actor responsible for managing the lifecycle of a gaze interaction.
/// By using an actor, we ensure that the high-frequency gaze updates from the ARKit stream
/// do not cause data races when calculating dwell times or triggering AI tasks.
@available(visionOS 1.0, *)
actor GazeIntentEngine {
    
    // Configuration Constants
    private let dwellThreshold: Duration = .seconds(1.5)
    private let jitterTolerance: TimeInterval = 0.2 // Seconds to allow for brief gaze loss
    
    // State Tracking
    private var currentInteraction: GazeInteractionState?
    private var isProcessingAI: Bool = false
    
    /// A stream of semantic updates sent to the UI.
    private let (contextStream, contextContinuation) = AsyncStream<SpatialContext>.makeStream()
    
    /// Provides a stream of context updates for the UI to consume.
    nonisolated var contextUpdates: AsyncStream<SpatialContext> {
        contextStream
    }

    /// Processes a new gaze hit-test result.
    /// - Parameter entity: The RealityKit entity currently being looked at.
    /// - Parameter clock: The current monotonic clock for precise timing.
    func updateGaze(with entity: Entity?, clock: ContinuousClock) async {
        // If we aren't processing an AI task, we can update the dwell timer.
        guard !isProcessingAI else { return }

        if let entity = entity {
            let id = entity.id
            
            if let current = currentInteraction, current.entityID == id {
                // User is still looking at the same object.
                let newDuration = clock.now - current.startTime
                currentInteraction = GazeInteractionState(
                    entityID: id,
                    startTime: current.startTime,
                    lastObservedTime: clock.now,
                    dwellDuration: newDuration
                )
                
                // Check if dwell threshold is met.
                if newDuration >= dwellThreshold {
                    await triggerAIAnalysis(for: entity)
                }
            } else {
                // User shifted gaze to a new object or started looking.
                currentInteraction = GazeInteractionState(
                    entityID: id,
                    startTime: clock.now,
                    lastObservedTime: clock.now,
                    dwellDuration: .zero
                )
            }
        } else {
            // User is looking at empty space.
            currentInteraction = nil
        }
    }

    /// Triggers the heavy-lifting AI analysis.
    /// This is isolated from the main gaze update loop to prevent frame drops.
    private func triggerAIAnalysis(for entity: Entity) async {
        guard !isProcessingAI else { return }
        isProcessingAI = true
        
        // Reset interaction to prevent repeated triggers during the same dwell.
        currentInteraction = nil 
        
        do {
            let context = try await performSemanticAnalysis(on: entity)
            contextContinuation.yield(context)
        } catch {
            contextContinuation.yield(.error(error.localizedDescription))
        }
        
        isProcessingAI = false
    }

    /// Performs the actual Vision/CoreML work.
    /// In a production app, this would involve capturing a texture from the entity
    /// or using the camera feed with a spatial mask.
    private func performSemanticAnalysis(on entity: Entity) async throws -> SpatialContext {
        // Simulation of high-latency AI processing.
        // In reality, you would use:
        // 1. ARKit's scene reconstruction to get a mesh.
        // 2. Vision framework to analyze a snapshot.
        try await Task.sleep(for: .milliseconds(500))
        
        // Mocking AI logic:
        let mockEntityName = entity.name.isEmpty ? "Unknown Object" : entity.name
        
        // Logic: If the object is named "Lamp", provide actionable context.
        if mockEntityName.lowercased().contains("lamp") {
            return .actionable(action: "Adjust Brightness", targetID: entity.id)
        } else {
            return .object(name: mockEntityName, properties: ["Material": "Unknown", "Context": "Spatial"])
        }
    }
}

// MARK: - The Spatial View Component

/// The main View that integrates the Gaze Engine with the RealityKit scene.
@available(visionOS 1.0, *)
struct SpatialIntelligenceView: View {
    
    @State private var currentContext: String = "Look at an object to begin..."
    @State private var isAnalyzing: Bool = false
    
    // The Actor instance is held in a State object or an EnvironmentObject.
    @State private var engine = GazeIntentEngine()
    let clock = ContinuousClock()

    var body: some View {
        ZStack {
            // The 3D Scene
            RealityView { content in
                // Setup a mock scene
                let lamp = Entity()
                lamp.name = "Desk Lamp"
                lamp.components.set(CollisionComponent(shapes: [.generateBox(size: [0.2, 0.2, 0.2])]))
                lamp.components.set(ModelComponent(mesh: .generateBox(size: 0.2), materials: [SimpleMaterial(color: .yellow, isMetallic: true)]))
                lamp.position = [0, 0, -0.5]
                content.add(lamp)
                
                let book = Entity()
                book.name = "Textbook"
                book.components.set(CollisionComponent(shapes: [.generateBox(size: [0.2, 0.3, 0.05])]))
                book.components.set(ModelComponent(mesh: .generateBox(size: [0.2, 0.3, 0.05]), materials: [SimpleMaterial(color: .blue, isMetallic: false)]))
                book.position = [0.3, 0, -0.5]
                content.add(book)
            }
            .gesture(SpatialGesture()) // Custom gesture to simulate gaze or use ARKit
            
            // The HUD (Heads-Up Display)
            VStack {
                if isAnalyzing {
                    ProgressView("AI Analyzing...")
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(10)
                } else {
                    Text(currentContext)
                        .font(.title)
                        .padding()
                        .background(.black.opacity(0.7))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                }
                Spacer()
            }
            .padding(.top, 50)
        }
        .task {
            // Observe the engine's asynchronous stream of context updates.
            for await context in await engine.contextUpdates {
                updateUI(with: context)
            }
        }
    }

    private func updateUI(with context: SpatialContext) {
        switch context {
        case .unknown:
            currentContext = "Looking at nothing..."
        case .object(let name, let props):
            currentContext = "Object: \(name)\n\(props.map { "\($0.key): \($0.value)" }.joined(separator: "\n"))"
        case .actionable(let action, _):
            currentContext = "Action Available: \(action)"
        case .error(let msg):
            currentContext = "Error: \(msg)"
        }
    }
    
    // MARK: - Gaze Simulation Logic
    
    /// In a real visionOS app, you would use `SpatialTrackingSession` or 
    /// `ARKit` gaze raycasting. For this demonstration, we use a custom gesture.
    struct SpatialGesture: Gesture {
        // This is a placeholder for the actual ARKit gaze raycasting logic.
        // In production, the update loop would be driven by the ARKit frame update.
    }
}

// MARK: - Production Implementation Note: The Integration Loop

/// This class demonstrates how the high-frequency ARKit loop connects to the Actor.
@available(visionOS 1.0, *)
class SpatialSessionManager: ObservableObject {
    private var engine: GazeIntentEngine
    private var clock = ContinuousClock()
    
    init(engine: GazeIntentEngine) {
        self.engine = engine
    }
    
    /// This method would be called inside the `session(_:didUpdate:)` delegate method of ARKit.
    /// It bridges the synchronous/high-frequency world of ARKit to the asynchronous Actor.
    func handleFrameUpdate(gazeRay: Ray, scene: Scene) {
        Task {
            // 1. Perform hit-test in the RealityKit scene.
            // 2. Pass the resulting entity to the engine.
            // This is non-blocking because it's a Task.
            let hitEntity = scene.hitTest(gazeRay) // Pseudo-code for hit-testing
            await engine.updateGaze(with: hitEntity, clock: clock)
        }
    }
}

/// A simple Ray structure for demonstration.
struct Ray {
    let origin: SIMD3<Float>
    let direction: SIMD3<Float>
}

extension Scene {
    func hitTest(_ ray: Ray) -> Entity? {
        // Implementation of ray-entity intersection logic
        return nil 
    }
}
