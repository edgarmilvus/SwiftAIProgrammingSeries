
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part4.swift
// Description: Advanced Application
// ==========================================

    // DocInsightCore/AppleIntelligenceService.swift
    import Foundation
    import Vision // Used for OCR in DocumentAnalyzer, but relevant here for context
    import NaturalLanguage // For entity extraction
    import SwiftUI // For Image type in Vision (not directly used here, but common)

    /// Represents a potential contextual action suggested by Apple Intelligence.
    /// These actions could be presented to the user to enhance productivity.
    @available(iOS 18.0, *)
    struct ContextualAction: Identifiable {
        let id = UUID()
        let title: String
        let iconSystemName: String // SFSymbol name for UI
        let actionType: ActionType
        let payload: [String: AnyHashable]? // e.g., ["date": Date(), "title": "Meeting"]

        enum ActionType: String {
            case addToCalendar
            case createContact
            case openURL
            case searchWeb
            case createReminder
            case custom // For app-specific actions
        }
    }

    /// A protocol defining the interface for Apple Intelligence services.
    /// This abstraction allows for different implementations (e.g., mock for testing, real on-device).
    @available(iOS 18.0, *)
    protocol AppleIntelligenceService {
        /// Summarizes the provided text using on-device LLM.
        /// - Parameter text: The input text to summarize.
        /// - Returns: A concise summary of the text.
        func summarizeDocument(text: String) async throws -> String

        /// Extracts key entities (people, organizations, dates, etc.) from the provided text.
        /// Leverages enhanced on-device NaturalLanguage models.
        /// - Parameter text: The input text for entity extraction.
        /// - Returns: An array of `ExtractedEntity`.
        func extractEntities(text: String) async throws -> [ExtractedEntity]

        /// Refines a given text snippet based on a specific prompt (e.g., "make more concise", "fix grammar").
        /// Uses Apple's Writing Tools framework.
        /// - Parameters:
        ///   - text: The text snippet to refine.
        ///   - prompt: The refinement instruction.
        /// - Returns: The refined text.
        func refineText(text: String, prompt: String) async throws -> String

        /// Proposes contextual actions based on the document's content and extracted entities.
        /// This simulates the broader Apple Intelligence framework's proactive suggestions.
        /// - Parameters:
        ///   - documentText: The full text of the document.
        ///   - entities: The entities previously extracted from the document.
        /// - Returns: An array of `ContextualAction` suggestions.
        func proposeContextualActions(documentText: String, entities: [ExtractedEntity]) async throws -> [ContextualAction]
    }

    /// Concrete implementation of `AppleIntelligenceService` using Apple's on-device frameworks.
    /// This class demonstrates how an advanced application would integrate with Apple Intelligence.
    @available(iOS 18.0, *)
    final class OnDeviceIntelligenceService: AppleIntelligenceService {

        // MARK: - On-Device LLM (Foundation.TextGenerationService) for Summarization

        /// Summarizes the provided text using on-device LLM.
        /// Uses `Foundation.TextGenerationService` which provides access to Apple's on-device large language models.
        ///
        /// **Review Guideline Context:**
        /// - **Privacy:** All processing is on-device, ensuring user data privacy. No data leaves the device.
        /// - **Performance:** On-device models are optimized for speed and efficiency, providing immediate feedback.
        /// - **Clarity:** The app must clearly indicate when AI is being used for summarization (e.g., "AI Summary").
        /// - **Accuracy:** While the model is powerful, the app should allow users to review and edit summaries,
        ///   and provide feedback on accuracy.
        func summarizeDocument(text: String) async throws -> String {
            // Ensure the feature is available on the current OS version.
            guard #available(iOS 18.0, *) else {
                throw DocInsightError.intelligenceServiceUnavailable
            }
            
            // --- SIMULATED API INTERACTION ---
            // In a real iOS 18 environment, you would interact with Foundation.TextGenerationService.
            // For example:
            // let service = TextGenerationService()
            // let request = TextGenerationRequest(prompt: "Summarize the following document:\n\n\(text)")
            // let result = try await service.generate(request)
            // return result.generatedText
            
            // Simulate processing delay for demonstration.
            await Task.sleep(for: .seconds(1.0))
            
            // Provide a basic, deterministic "summary" for demonstration without actual LLM.
            if text.count < 50 {
                return "This short document appears to be about: \(text.prefix(20))."
            }
            let words = text.split(separator: " ").prefix(20)
            return "AI Summary: " + words.joined(separator: " ") + "..."
        }

        // MARK: - Enhanced Entity Extraction (NaturalLanguage Framework)

        /// Extracts key entities from the provided text using `NaturalLanguage` framework.
        /// In iOS 18, `NaturalLanguage` is expected to leverage on-device foundation models
        /// for more robust and context-aware entity recognition, potentially beyond standard NER.
        ///
        /// **Review Guideline Context:**
        /// - **Data Minimization:** Only relevant text is passed to the framework.
        /// - **Transparency:** The app should clearly show which entities were extracted and allow users
        ///   to interact with them (e.g., tap to edit, add to contacts).
        /// - **Accuracy:** Allow users to correct or add missing entities, providing feedback to improve models.
        func extractEntities(text: String) async throws -> [ExtractedEntity] {
            guard #available(iOS 18.0, *) else {
                throw DocInsightError.intelligenceServiceUnavailable
            }

            // --- SIMULATED ENHANCED NL INTERACTION ---
            // In iOS 18, NLTagger might have new tag schemes or options that leverage AI for
            // more sophisticated entity recognition.
            // For example:
            // let tagger = NLTagger(tagSchemes: [.nameType, .organizationName, .date, .currency, .customLLMEntities])
            // tagger.string = text
            // let entities = try await tagger.tags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .nameTypeOrCustomLLM, options: .joinNames)
            
            await Task.sleep(for: .seconds(0.8)) // Simulate processing delay

            var extracted: [ExtractedEntity] = []
            
            // Use NLTagger for basic entity recognition (Person, Org, Place).
            // This is augmented with regex for dates/money to simulate enhanced capabilities.
            let tagger = NLTagger(tagSchemes: [.nameType])
            tagger.string = text
            
            text.enumerateSubstrings(in: text.startIndex..<text.endIndex, options: .bySentences) { (substring, substringRange, enclosingRange, stop) in
                guard let substring = substring else { return }
                
                // NLTagger for Name, Organization, Place
                tagger.enumerateTags(in: substringRange, unit: .word, scheme: .nameType, options: .joinNames) { tag, tokenRange in
                    if let tag = tag, let value = text[tokenRange].base as String? {
                        let entityType: ExtractedEntity.EntityType
                        switch tag {
                        case .personalName: entityType = .person
                        case .organizationName: entityType = .organization
                        case .placeName: entityType = .location
                        default: return // Skip other types for this example
                        }
                        extracted.append(ExtractedEntity(type: entityType, value: value, range: tokenRange))
                    }
                    return true
                }
                
                // Simulate robust date detection with Regex (could be an AI model in iOS 18)
                let dateRegex = try? NSRegularExpression(pattern: "\\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s+\\d{1,2},\\s+\\d{4}\\b|\\d{1,2}/\\d{1,2}/\\d{2,4}|\\d{4}-\\d{2}-\\d{2}", options: .caseInsensitive)
                dateRegex?.enumerateMatches(in: substring, options: [], range: NSRange(substringRange, in: text)) { (match, _, _) in
                    if let matchRange = match?.range, let swiftRange = Range(matchRange, in: text) {
                        extracted.append(ExtractedEntity(type: .date, value: String(text[swiftRange]), range: swiftRange))
                    }
                }
                
                // Simulate money detection with Regex
                let moneyRegex = try? NSRegularExpression(pattern: "\\$\\d{1,3}(?:,\\d{3})*(?:\\.\\d{2})?\\b|\\b\\d{1,3}(?:,\\d{3})*(?:\\.\\d{2})?\\s*(?:USD|EUR|GBP)\\b", options: [])
                moneyRegex?.enumerateMatches(in: substring, options: [], range: NSRange(substringRange, in: text)) { (match, _, _) in
                    if let matchRange = match?.range, let swiftRange = Range(matchRange, in: text) {
                        extracted.append(ExtractedEntity(type: .money, value: String(text[swiftRange]), range: swiftRange))
                    }
                }
            }

            return extracted
        }

        // MARK: - Writing Tools (Foundation.WritingToolsService)

        /// Refines a given text snippet based on a specific prompt using Apple's Writing Tools.
        /// This framework provides powerful text manipulation capabilities directly on-device.
        ///
        /// **Review Guideline Context:**
        /// - **User Control:** Users must explicitly invoke Writing Tools. Suggestions should not be automatically applied.
        /// - **Transparency:** Clearly label AI-generated refinements (e.g., "AI Suggestion").
        /// - **Undo/Redo:** Provide easy ways for users to revert changes or choose between suggestions.
        /// - **Contextual Relevance:** Ensure prompts are relevant to the app's function and user's intent.
        func refineText(text: String, prompt: String) async throws -> String {
            guard #available(iOS 18.0, *) else {
                throw DocInsightError.intelligenceServiceUnavailable
            }
            // Writing Tools might have input limits, validate input.
            guard !text.isEmpty && text.count <= 1000 else {
                throw DocInsightError.invalidTextForRefinement
            }

            // --- SIMULATED API INTERACTION ---
            // In a real iOS 18 environment, you would interact with Foundation.WritingToolsService.
            // For example:
            // let service = WritingToolsService()
            // let request = WritingToolsRequest(text: text, instruction: prompt)
            // let result = try await service.refine(request)
            // return result.refinedText

            await Task.sleep(for: .seconds(0.7)) // Simulate processing delay

            // A very basic, deterministic "refinement" for demonstration.
            if prompt.lowercased().contains("concise") {
                return "Refined (concise): " + text.prefix(text.count / 2) + "..."
            } else if prompt.lowercased().contains("grammar") {
                return "Refined (grammar): " + text.replacingOccurrences(of: "is", with: "was").replacingOccurrences(of: "a", with: "an")
            } else {
                return "Refined (generic): " + text.uppercased() // Example fallback
            }
        }

        // MARK: - Contextual Actions (Broader Apple Intelligence Framework)

        /// Proposes contextual actions based on the document's content and extracted entities.
        /// This simulates the broader Apple Intelligence framework's proactive suggestions,
        /// which might appear as system-level suggestions (e.g., in the Suggestions bar)
        /// or within the app's UI.
        ///
        /// **Review Guideline Context:**
        /// - **Opt-in/Consent:** Users should have clear control over enabling/disabling these suggestions.
        /// - **Non-intrusive:** Suggestions should be helpful and appear at relevant times, not disruptive.
        /// - **Clear Intent:** The purpose of each suggestion must be clear to the user.
        /// - **Relevance:** Suggestions must be highly relevant to the app's content and the user's immediate task.
        /// - **Privacy:** All analysis for these suggestions happens on-device.
        func proposeContextualActions(documentText: String, entities: [ExtractedEntity]) async throws -> [ContextualAction] {
            guard #available(iOS 18.0, *) else {
                throw DocInsightError.intelligenceServiceUnavailable
            }
            guard !entities.isEmpty || !documentText.isEmpty else {
                throw DocInsightError.missingDataForContextualAction
            }

            await Task.sleep(for: .seconds(0.5)) // Simulate processing delay

            var actions: [ContextualAction] = []

            // Example: Detect a date to suggest adding to calendar
            if let dateEntity = entities.first(where: { $0.type == .date }),
               let date = ISO8601DateFormatter().date(from: dateEntity.value) { // Attempt to parse date string
                actions.append(ContextualAction(
                    title: "Add '\(dateEntity.value)' to Calendar",
                    iconSystemName: "calendar.badge.plus",
                    actionType: .addToCalendar,
                    payload: ["date": date, "title": "Document Event"]
                ))
            } else if documentText.lowercased().contains("meeting on") {
                 // Fallback or additional check for dates not caught by entity extraction
                actions.append(ContextualAction(
                    title: "Suggest Meeting Event",
                    iconSystemName: "calendar.badge.plus",
                    actionType: .addToCalendar,
                    payload: ["title": "Meeting from Document"]
                ))
            }

            // Example: Detect a person to suggest creating a contact
            if let personEntity = entities.first(where: { $0.type == .person }) {
                actions.append(ContextualAction(
                    title: "Create Contact for '\(personEntity.value)'",
                    iconSystemName: "person.crop.circle.badge.plus",
                    actionType: .createContact,
                    payload: ["name": personEntity.value]
                ))
            }
            
            // Example: Detect a URL to suggest opening it
            if let urlEntity = entities.first(where: { $0.type == .url }),
               let url = URL(string: urlEntity.value) {
                actions.append(ContextualAction(
                    title: "Open Link: \(url.host ?? "URL")",
                    iconSystemName: "link",
                    actionType: .openURL,
                    payload: ["url": url]
                ))
            } else if documentText.lowercased().contains("visit website") {
                actions.append(ContextualAction(
                    title: "Search for Website",
                    iconSystemName: "safari",
                    actionType: .searchWeb,
                    payload: ["query": "website from document"]
                ))
            }

            // Example: Detect a receipt or expense-related keywords
            if documentText.lowercased().contains("total amount") || documentText.lowercased().contains("receipt") {
                actions.append(ContextualAction(
                    title: "Create Expense Report",
                    iconSystemName: "dollarsign.circle",
                    actionType: .custom, // Custom action for the DocInsight app
                    payload: ["type": "expense", "amount": entities.first(where: { $0.type == .money })?.value ?? "unknown"]
                ))
            }

            return actions
        }
    }
    