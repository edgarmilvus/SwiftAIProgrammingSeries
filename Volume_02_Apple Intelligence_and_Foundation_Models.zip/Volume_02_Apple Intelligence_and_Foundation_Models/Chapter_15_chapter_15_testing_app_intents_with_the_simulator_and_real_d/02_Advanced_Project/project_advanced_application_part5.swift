
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

/// Defines the interface for a note summarization service.
protocol NoteSummarizing {
    /// Summarizes the given text content.
    /// - Parameters:
    ///   - text: The text content to summarize.
    ///   - length: The desired length of the summary.
    /// - Returns: The summarized text.
    /// - Throws: `SummarizerError` if summarization fails.
    func summarize(text: String, length: SummaryLengthOption) async throws -> String
}

/// Custom errors for the summarizer.
enum SummarizerError: Error, CustomStringConvertible {
    case processingFailed
    case contentTooShort
    case serviceUnavailable

    var description: String {
        switch self {
        case .processingFailed: return "The summarization process encountered an internal error."
        case .contentTooShort: return "The note content is too short to summarize effectively."
        case .serviceUnavailable: return "Apple Intelligence service is currently unavailable."
        }
    }
}

/// A mock implementation of the `NoteSummarizing` protocol.
/// In a real app, this would integrate with Apple Intelligence APIs.
class MockNoteSummarizer: NoteSummarizing {
    /// Simulates AI summarization.
    /// Includes artificial delay and error conditions for testing purposes.
    func summarize(text: String, length: SummaryLengthOption) async throws -> String {
        // Simulate network/processing delay
        try await Task.sleep(for: .seconds(Double.random(in: 1.0...3.0)))

        // Simulate error conditions
        if text.count < 20 {
            throw SummarizerError.contentTooShort
        }
        if Bool.random() && text.contains("fail") { // Simulate occasional AI failure
            throw SummarizerError.processingFailed
        }

        // Simple mock summarization logic based on length
        let words = text.split(separator: " ")
        let summaryWordsCount: Int
        switch length {
        case .short: summaryWordsCount = min(15, words.count)
        case .medium: summaryWordsCount = min(30, words.count)
        case .long: summaryWordsCount = min(50, words.count)
        }

        let summary = words.prefix(summaryWordsCount).joined(separator: " ") + "..."
        return "Summary (\(length.rawValue)): \(summary)"
    }
}
