
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

    // MARK: - Example Usage in an App Context (e.g., a SwiftUI View Model)

    /// A ViewModel to demonstrate the integration of `DocumentAnalyzer` and `AppleIntelligenceService`.
    /// This would typically be used by a SwiftUI View to display document analysis results.
    @available(iOS 18.0, *)
    final class DocumentAnalysisViewModel: ObservableObject {
        @Published var currentDocument: Document?
        @Published var contextualActions: [ContextualAction] = []
        @Published var isLoading: Bool = false
        @Published var errorMessage: String?
        @Published var refinedTextResult: String?

        private let analyzer: DocumentAnalyzer
        
        // In a real SwiftUI app, you might inject the ModelContext:
        // @Environment(\.modelContext) private var modelContext

        /// Initializes the ViewModel, optionally with a custom `DocumentAnalyzer`.
        init(analyzer: DocumentAnalyzer = DocumentAnalyzer()) {
            self.analyzer = analyzer
        }

        /// Simulates scanning a document and initiating the analysis process.
        /// This method would be called when a user imports an image or takes a photo.
        /// - Parameters:
        ///   - image: The `CGImage` of the scanned document.
        ///   - title: A title for the document.
        func scanAndAnalyzeDocument(image: CGImage, title: String) async {
            await MainActor.run {
                self.isLoading = true
                self.errorMessage = nil
                self.currentDocument = nil
                self.contextualActions = []
            }

            do {
                let (document, actions) = try await analyzer.analyzeDocument(image: image, documentTitle: title)
                await MainActor.run {
                    self.currentDocument = document
                    self.contextualActions = actions
                    // In a real app, you would save the document to SwiftData here:
                    // modelContext.insert(document)
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                }
            }
            await MainActor.run {
                self.isLoading = false
            }
        }
        
        /// Requests a refinement for a specific text snippet using Writing Tools.
        /// This method would be called when a user selects text and chooses a refinement option.
        /// - Parameters:
        ///   - textToRefine: The text to be refined.
        ///   - prompt: The refinement instruction (e.g., "make more professional", "fix grammar").
        func requestTextRefinement(textToRefine: String, prompt: String) async {
            await MainActor.run {
                self.isLoading = true
                self.errorMessage = nil
                self.refinedTextResult = nil
            }
            
            do {
                let refined = try await analyzer.getRefinementSuggestion(for: textToRefine, with: prompt)
                await MainActor.run {
                    self.refinedTextResult = refined
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                }
            }
            await MainActor.run {
                self.isLoading = false
            }
        }
    }
    