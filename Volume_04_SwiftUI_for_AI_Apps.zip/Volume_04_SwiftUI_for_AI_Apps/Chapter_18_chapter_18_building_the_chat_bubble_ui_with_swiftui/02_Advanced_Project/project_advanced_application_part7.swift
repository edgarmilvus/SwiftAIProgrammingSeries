
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part7.swift
// Description: Advanced Application
// ==========================================

/// The main view of the Smart Assistant app, displaying the chat interface.
@available(iOS 17.0, *)
struct ContentView: View {
    @StateObject private var viewModel = StreamingChatViewModel()
    @State private var inputText: String = ""
    @FocusState private var isInputFocused: Bool
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Chat message display area
                ScrollViewReader { proxy in
                    ScrollView {
                        VStack(spacing: 8) {
                            ForEach(viewModel.messages) { message in
                                ForEach(message.content, id: \.id) { contentPart in
                                    StreamingChatBubbleView(
                                        content: contentPart,
                                        isUserMessage: message.isUserMessage,
                                        isStreaming: message.isStreaming,
                                        onAcceptToolCall: viewModel.performToolCall,
                                        onDeclineToolCall: viewModel.declineToolCall
                                    )
                                }
                            }
                        }
                        .padding(.vertical)
                    }
                    .onChange(of: viewModel.messages) { _ in
                        // Scroll to the bottom whenever new messages arrive
                        if let lastMessage = viewModel.messages.last {
                            // Scroll to the last content part of the last message
                            if let lastContentPart = lastMessage.content.last {
                                proxy.scrollTo(lastContentPart.id, anchor: .bottom)
                            } else {
                                // If no content yet, scroll to the message itself
                                proxy.scrollTo(lastMessage.id, anchor: .bottom)
                            }
                        }
                    }
                }
                
                // Input field and send button
                HStack {
                    TextField("Type a message...", text: $inputText)
                        .textFieldStyle(.roundedBorder)
                        .focused($isInputFocused)
                        .padding(.horizontal, 8)
                        .onSubmit {
                            sendMessage()
                        }
                    
                    Button {
                        sendMessage()
                    } label: {
                        if viewModel.isLoadingAIResponse {
                            ProgressView()
                        } else {
                            Image(systemName: "arrow.up.circle.fill")
                                .font(.title2)
                        }
                    }
                    .disabled(inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || viewModel.isLoadingAIResponse)
                    .padding(.trailing, 8)
                }
                .padding(.vertical, 8)
                .background(.bar)
                
                // Error message display
                if let errorMessage = viewModel.errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .font(.caption)
                        .padding(.bottom, 5)
                }
            }
            .navigationTitle("Smart Assistant")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                // Initial welcome message
                Task { @MainActor in
                    viewModel.messages.append(ChatMessage(text: "Hello! How can I help you today?", isUserMessage: false))
                }
            }
        }
    }
    
    /// Handles sending the user's message to the view model.
    private func sendMessage() {
        guard !inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        viewModel.sendMessage(text: inputText)
        inputText = ""
        isInputFocused = false // Dismiss keyboard after sending
    }
}

// MARK: - Preview Provider
@available(iOS 17.0, *)
#Preview {
    ContentView()
}
