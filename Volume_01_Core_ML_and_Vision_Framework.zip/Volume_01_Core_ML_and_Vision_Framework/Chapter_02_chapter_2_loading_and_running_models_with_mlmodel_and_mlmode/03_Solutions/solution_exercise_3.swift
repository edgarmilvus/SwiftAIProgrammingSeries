
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CoreML
import Vision
import UIKit
import Foundation // For Timer

// Reusing the UIImage extension from Exercise 1 & 2
extension UIImage {
    func toCVPixelBuffer(targetSize: CGSize, pixelFormat: OSType = kCVPixelFormatType_32BGRA) -> CVPixelBuffer? {
        let width = Int(targetSize.width)
        let height = Int(targetSize.height)

        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(nil, width, height, pixelFormat, nil, &pixelBuffer)

        guard status == kCVReturnSuccess, let buffer = pixelBuffer else {
            print("Error creating CVPixelBuffer: \(status)")
            return nil
        }

        CVPixelBufferLockBaseAddress(buffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }

        let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue
        )

        guard let cgImage = self.cgImage else {
            print("Failed to get CGImage from UIImage.")
            return nil
        }

        context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        return buffer
    }
}

// Reusing MLComputeUnits CustomStringConvertible from Exercise 2
extension MLComputeUnits: CustomStringConvertible {
    public var description: String {
        switch self {
        case .cpuOnly: return "CPU Only"
        case .cpuAndGPU: return "CPU and GPU"
        case .all: return "All Available (CPU, GPU, Neural Engine)"
        case .cpuAndNeuralEngine: return "CPU and Neural Engine"
        @unknown default: return "Unknown Compute Unit"
        }
    }
}

// MARK: - GuardianEyeObjectDetector Class

@available(iOS 17.0, *)
class GuardianEyeObjectDetector {
    private let modelURL: URL
    private var currentModel: MLModel?
    private var detectionTimer: Timer?
    private var simulatedFrameIndex = 0
    private let detectionInterval: TimeInterval // How often to process frames
    private let modelInputName: String
    private let modelImageSize: CGSize
    private let modelOutputNames: (boxes: String, scores: String, labels: String) // Output names for object detection

    // Store simulated frames (e.g., from assets)
    private let simulatedFrames: [UIImage]

    /// The currently active compute units. Setting this property will trigger a model reload.
    var currentComputeUnits: MLComputeUnits = .all { // Default to high performance
        didSet {
            if oldValue != currentComputeUnits {
                print("Switching compute units to: \(currentComputeUnits)")
                // Stop current detection, reload model, then restart detection
                let wasRunning = (detectionTimer != nil)
                stopDetection()
                loadModel(with: currentComputeUnits)
                if wasRunning {
                    startDetection(interval: detectionInterval)
                }
            }
        }
    }

    /// Initializes the object detector.
    /// - Parameters:
    ///   - modelURL: URL to the compiled object detection model.
    ///   - simulatedFrames: An array of UIImages to simulate camera input.
    ///   - detectionInterval: The interval between processing simulated frames.
    ///   - inputName: The name of the image input feature (e.g., "image").
    ///   - imageSize: The expected input image size for the model (e.g., 416x416).
    ///   - outputNames: A tuple of output names for bounding boxes, scores, and labels.
    init(modelURL: URL, simulatedFrames: [UIImage], detectionInterval: TimeInterval = 1.0,
         inputName: String, imageSize: CGSize, outputNames: (boxes: String, scores: String, labels: String)) {
        self.modelURL = modelURL
        self.simulatedFrames = simulatedFrames
        self.detectionInterval = detectionInterval
        self.modelInputName = inputName
        self.modelImageSize = imageSize
        self.modelOutputNames = outputNames
        loadModel(with: self.currentComputeUnits) // Load with default units initially
    }

    /// Loads or reloads the Core ML model with the specified compute units.
    private func loadModel(with units: MLComputeUnits) {
        var configuration = MLModelConfiguration()
        configuration.computeUnits = units
        do {
            self.currentModel = try MLModel(contentsOf: modelURL, configuration: configuration)
            print("Object detection model loaded with \(units) compute units.")
        } catch {
            print("Failed to load object detection model with \(units) compute units: \(error.localizedDescription)")
            self.currentModel = nil
        }
    }

    /// Starts the simulated object detection process.
    func startDetection() {
        guard detectionTimer == nil else {
            print("Detection already running.")
            return
        }
        guard !simulatedFrames.isEmpty else {
            print("No simulated frames available to process.")
            return
        }

        detectionTimer = Timer.scheduledTimer(withTimeInterval: detectionInterval, repeats: true) { [weak self] _ in
            guard let self = self, let model = self.currentModel else { return }

            let currentImage = self.simulatedFrames[self.simulatedFrameIndex % self.simulatedFrames.count]
            self.simulatedFrameIndex += 1

            // 1. Convert UIImage to CVPixelBuffer
            guard let pixelBuffer = currentImage.toCVPixelBuffer(targetSize: self.modelImageSize) else {
                print("Failed to convert image to CVPixelBuffer for frame \(self.simulatedFrameIndex).")
                return
            }

            do {
                // 2. Create MLFeatureProvider
                let inputFeatures = try MLDictionaryFeatureProvider(dictionary: [self.modelInputName: MLFeatureValue(pixelBuffer: pixelBuffer)])
                let prediction = try model.prediction(input: inputFeatures)

                // 3. Parse MLMultiArray outputs for bounding boxes, confidences, and labels.
                // This part is highly model-specific and often complex.
                // For demonstration, we'll just print basic info.
                if let boxes = prediction.featureValue(forName: self.modelOutputNames.boxes)?.multiArrayValue,
                   let scores = prediction.featureValue(forName: self.modelOutputNames.scores)?.multiArrayValue,
                   let labels = prediction.featureValue(forName: self.modelOutputNames.labels)?.multiArrayValue {

                    print("\n--- Frame \(self.simulatedFrameIndex) Detection Results (\(self.currentComputeUnits)) ---")
                    print("Raw output shapes - Boxes: \(boxes.shape), Scores: \(scores.shape), Labels: \(labels.shape)")

                    // Example: Iterate through a few potential detections
                    let numDetections = min(boxes.shape[0], 5) // Process up to 5 detections for brevity
                    for i in 0..<numDetections {
                        // Accessing multi-array elements:
                        // Boxes are usually [num_boxes, 4] for (x, y, width, height) or (x1, y1, x2, y2)
                        // Scores are usually [num_boxes]
                        // Labels are usually [num_boxes] (integer indices)

                        // Note: Direct access `boxes[i, 0]` requires `MLMultiArray` subscripting,
                        // which can be cumbersome. For real apps, you'd often convert to a Swift array
                        // or use a helper. Here, we'll conceptualize it.
                        let score = scores[i].doubleValue // Assuming scores are directly accessible
                        let labelIndex = labels[i].intValue // Assuming labels are integer indices

                        // Assuming a simple mapping for label index to string (e.g., for a custom model)
                        let objectLabel = self.mapLabelIndexToString(labelIndex)

                        // For bounding box, just print the first value for simplicity
                        let boxCoord1 = boxes[i * boxes.strides[0].intValue].doubleValue // Accessing the first coordinate of the i-th box

                        // In a real app, you'd apply a confidence threshold and Non-Maximum Suppression (NMS) here.
                        if score > 0.5 { // Example threshold
                            print("  Detected '\(objectLabel)' with score \(String(format: "%.2f", score)) at box start: \(String(format: "%.2f", boxCoord1))...")
                        }
                    }

                } else {
                    print("Object detection outputs not found or in unexpected format for model: \(self.modelURL.lastPathComponent)")
                }

            } catch {
                print("Error during object detection for frame \(self.simulatedFrameIndex): \(error.localizedDescription)")
            }
        }
        RunLoop.current.add(detectionTimer!, forMode: .common)
        print("Starting simulated object detection with \(currentComputeUnits) units.")
    }

    /// Stops the simulated object detection process.
    func stopDetection() {
        detectionTimer?.invalidate()
        detectionTimer = nil
        print("Stopped simulated object detection.")
    }

    // MARK: - Helper for label mapping (model-specific)
    private func mapLabelIndexToString(_ index: Int) -> String {
        // This mapping is highly dependent on your specific object detection model.
        // For example, a custom Create ML model might output integer indices 0, 1, 2...
        // which map to your defined classes like "cat", "dog", "car".
        let classLabels = ["person", "car", "dog", "cat", "bicycle", "unknown"]
        if index >= 0 && index < classLabels.count {
            return classLabels[index]
        }
        return "unknown object (\(index))"
    }

    deinit {
        stopDetection()
    }
}

// MARK: - Example Usage in a ViewController

@available(iOS 17.0, *)
class ObjectDetectionViewController: UIViewController {

    var detector: GuardianEyeObjectDetector?
    var modeSegmentedControl: UISegmentedControl!
    var startStopButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        setupDetector()
    }

    private func setupUI() {
        modeSegmentedControl = UISegmentedControl(items: ["Power Saving (CPU)", "High Performance (All)"])
        modeSegmentedControl.selectedSegmentIndex = 1 // Default to High Performance
        modeSegmentedControl.addTarget(self, action: #selector(modeChanged), for: .valueChanged)
        modeSegmentedControl.translatesAutoresizingMaskIntoConstraints = false

        startStopButton = UIButton(type: .system)
        startStopButton.setTitle("Start Detection", for: .normal)
        startStopButton.addTarget(self, action: #selector(toggleDetection), for: .touchUpInside)
        startStopButton.translatesAutoresizingMaskIntoConstraints = false

        let stackView = UIStackView(arrangedSubviews: [modeSegmentedControl, startStopButton])
        stackView.axis = .vertical
        stackView.spacing = 20
        stackView.alignment = .center
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20)
        ])
    }

    private func setupDetector() {
        // IMPORTANT: Replace "YOLOv3Tiny" with your actual object detection model name.
        // Adjust input/output names and image size according to your model's specification.
        // Example for a YOLO-like model:
        // Input: "image" (Image, 416x416, BGRA)
        // Outputs: "boxes" (MLMultiArray), "scores" (MLMultiArray), "labels" (MLMultiArray)
        // (These names are highly model-specific. Check your .mlmodel file in Xcode for exact names).

        guard let modelURL = Bundle.main.url(forResource: "YOLOv3Tiny", withExtension: "mlmodelc") else {
            print("Error: YOLOv3Tiny.mlmodelc not found in bundle.")
            return
        }

        // Load some sample images for simulation
        let simulatedImages: [UIImage] = (1...3).compactMap { UIImage(named: "frame\($0)") }
        guard !simulatedImages.isEmpty else {
            print("Error: No simulated frames (e.g., 'frame1.jpg') found in assets.")
            return
        }

        detector = GuardianEyeObjectDetector(
            modelURL: modelURL,
            simulatedFrames: simulatedImages,
            detectionInterval: 2.0, // Process a frame every 2 seconds
            inputName: "image", // Common input name
            imageSize: CGSize(width: 416, height: 416), // Common YOLO input size
            outputNames: (boxes: "boxes", scores: "scores", labels: "labels") // Example output names
        )

        // Set initial mode based on UI
        detector?.currentComputeUnits = modeSegmentedControl.selectedSegmentIndex == 0 ? .cpuOnly : .all
    }

    @objc private func modeChanged(_ sender: UISegmentedControl) {
        let newComputeUnits: MLComputeUnits = sender.selectedSegmentIndex == 0 ? .cpuOnly : .all
        detector?.currentComputeUnits = newComputeUnits
    }

    @objc private func toggleDetection() {
        if startStopButton.title(for: .normal) == "Start Detection" {
            detector?.startDetection()
            startStopButton.setTitle("Stop Detection", for: .normal)
        } else {
            detector?.stopDetection()
            startStopButton.setTitle("Start Detection", for: .normal)
        }
    }
}

// To run this example:
// 1. Create a new iOS project.
// 2. Obtain an object detection Core ML model (e.g., YOLOv3Tiny.mlmodelc from Apple's Core ML Models).
//    Drag it into your project.
// 3. Add a few images to your Assets.xcassets, named "frame1", "frame2", "frame3", etc.,
//    to simulate a camera feed.
// 4. Replace the contents of your ViewController.swift with the code above.
//    (You might need to rename the class or create a new one).
