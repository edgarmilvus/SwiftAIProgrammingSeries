/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/generate-roadmap/route.ts
import { NextRequest } from 'next/server';

/**
 * @fileoverview A Next.js API Route acting as a Supervisor Node for a multi-agent system.
 * This route simulates a "Managed Workflow" similar to Expo's, where complex tasks
 * are delegated to specialized agents and streamed back to the client.
 */

// -----------------------------------------------------------------------------
// 1. Types and Interfaces
// -----------------------------------------------------------------------------

/**
 * Represents the state of the graph execution.
 * Similar to a Next.js middleware pipeline, this tracks the current context.
 */
interface GraphState {
  messages: Array<{ role: string; content: string }>;
  currentAgent: string | null;
  task: string;
  isComplete: boolean;
}

/**
 * Definition of a tool available to the Supervisor or Workers.
 */
interface Tool {
  name: string;
  description: string;
  // In a real scenario, this would be a complex function.
  // Here, it simulates an API call or a specialized LLM generation.
  execute: (input: string) => Promise<string>;
}

// -----------------------------------------------------------------------------
// 2. Simulated Worker Agents (Tools)
// -----------------------------------------------------------------------------

/**
 * Tool: React Native Expert
 * Specialized in generating code snippets and architecture advice.
 */
const reactNativeExpert: Tool = {
  name: 'react_native_expert',
  description: 'Generates TypeScript/React Native code snippets and architectural patterns.',
  execute: async (input: string): Promise<string> => {
    // Simulate processing delay (network latency)
    await new Promise((resolve) => setTimeout(resolve, 300));
    
    if (input.toLowerCase().includes('navigation')) {
      return `
**React Native Navigation Setup:**
To implement universal routing, we use Expo Router. It utilizes file-based routing similar to Next.js.

\`\`\`tsx
// app/_layout.tsx
import { Stack } from 'expo-router';

export default function RootLayout() {
  return (
    <Stack>
      <Stack.Screen name="index" options={{ title: 'Home' }} />
    </Stack>
  );
}
\`\`\`
`;
    }
    return "I specialize in React Native code. Please specify if you need navigation, state management, or UI components.";
  }
};

/**
 * Tool: Expo SDK Expert
 * Specialized in native capabilities and configuration.
 */
const expoSdkExpert: Tool = {
  name: 'expo_sdk_expert',
  description: 'Advises on Expo SDK usage, native configuration, and development builds.',
  execute: async (input: string): Promise<string> => {
    await new Promise((resolve) => setTimeout(resolve, 300));
    
    if (input.toLowerCase().includes('camera') || input.toLowerCase().includes('native')) {
      return `
**Expo SDK Configuration:**
For accessing native device features like the camera, use the \`expo-camera\` package. No native code required!

\`\`\`bash
npx expo install expo-camera
\`\`\`

\`\`\`tsx
import { Camera, CameraType } from 'expo-camera';
// ... implementation details
\`\`\`
`;
    }
    return "I can help with Expo modules. Ask about Camera, Location, or SecureStore.";
  }
};

// -----------------------------------------------------------------------------
// 3. The Supervisor Node Logic
// -----------------------------------------------------------------------------

/**
 * The Supervisor Node analyzes the current state and decides the next action.
 * This mimics the logic of a Next.js Router determining which page/component to serve.
 * 
 * @param state - The current execution state
 * @returns A decision object containing the next agent or a final response
 */
async function supervisorNode(state: GraphState): Promise<{
  nextAgent: string | null;
  reasoning: string;
}> {
  const lastMessage = state.messages[state.messages.length - 1].content;
  
  // Simple routing logic (in production, this would be an LLM call)
  if (lastMessage.toLowerCase().includes('code') || lastMessage.toLowerCase().includes('navigation')) {
    return {
      nextAgent: 'react_native_expert',
      reasoning: 'Detected request for code implementation. Routing to React Native Expert.'
    };
  }
  
  if (lastMessage.toLowerCase().includes('native') || lastMessage.toLowerCase().includes('sdk')) {
    return {
      nextAgent: 'expo_sdk_expert',
      reasoning: 'Detected request for native capabilities. Routing to Expo SDK Expert.'
    };
  }

  // If no specific tool matches, we synthesize the final response
  return {
    nextAgent: null,
    reasoning: 'Task complete. Synthesizing final roadmap based on gathered context.'
  };
}

// -----------------------------------------------------------------------------
// 4. The API Route (Edge Runtime)
// -----------------------------------------------------------------------------

/**
 * POST Handler: The entry point for the Supervisor Node.
 * Uses Edge Runtime for low-latency streaming.
 */
export async function POST(req: NextRequest) {
  const { prompt } = await req.json();

  if (!prompt) {
    return new Response(JSON.stringify({ error: 'Prompt is required' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  // Initialize the Graph State
  const initialState: GraphState = {
    messages: [{ role: 'user', content: prompt }],
    currentAgent: null,
    task: prompt,
    isComplete: false,
  };

  // Create a ReadableStream to stream the response token-by-token
  const stream = new ReadableStream({
    async start(controller) {
      const encoder = new TextEncoder();
      let state = initialState;

      // --- The ReAct Loop (Reasoning - Action - Observation) ---
      // We limit iterations to prevent infinite loops in this demo
      let iterations = 0;
      const MAX_ITERATIONS = 5;

      while (!state.isComplete && iterations < MAX_ITERATIONS) {
        iterations++;

        // 1. REASONING (Supervisor Decision)
        const decision = await supervisorNode(state);
        
        // Stream the reasoning step
        controller.enqueue(encoder.encode(`[Supervisor]: ${decision.reasoning}\n`));

        // 2. ACTION (Worker Execution)
        if (decision.nextAgent) {
          state.currentAgent = decision.nextAgent;
          
          // Select the tool (Worker Agent)
          let tool: Tool | undefined;
          if (decision.nextAgent === 'react_native_expert') tool = reactNativeExpert;
          if (decision.nextAgent === 'expo_sdk_expert') tool = expoSdkExpert;

          if (tool) {
            // Execute the tool and stream results
            controller.enqueue(encoder.encode(`[Agent ${decision.nextAgent}]: Processing...\n`));
            const observation = await tool.execute(state.task);
            
            // 3. OBSERVATION (Update State)
            state.messages.push({ role: 'assistant', content: observation });
            controller.enqueue(encoder.encode(`[Agent ${decision.nextAgent}]: ${observation}\n`));
          }
        } else {
          // Final synthesis step
          const finalResponse = `
# Universal App Roadmap

Based on your request: "${state.task}"

## 1. Architecture
Use Expo for the foundation. It provides the "Next.js of Mobile" experience with universal routing.

## 2. Implementation Details
${state.messages.map(m => m.content).join('\n')}

## 3. Next Steps
Run \`npx create-expo-app@latest\` to start.
`;
          controller.enqueue(encoder.encode(`[Final Output]:\n${finalResponse}\n`));
          state.isComplete = true;
        }
      }

      if (!state.isComplete) {
        controller.enqueue(encoder.encode("[Supervisor]: Max iterations reached. Stopping loop.\n"));
      }

      controller.close();
    },
  });

  // Return the stream response
  return new Response(stream, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}
