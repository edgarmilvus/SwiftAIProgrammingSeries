
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import MLX

@available(iOS 18.0, macOS 15.0, *)
func normalizeImage(pixelData: [Float], width: Int, height: Int) -> MLXArray {
    precondition(pixelData.count == width * height, "Pixel data array size must match width * height.")

    // 1. MLXArray Creation: Convert the [Float] array into an MLXArray.
    // The shape is initially 1D as the input is a flat array.
    let imageArray = MLXArray(pixelData, shape: [pixelData.count], dtype: .float32)

    // 2. Normalization Step 1 (Scaling): Scale pixel values from 0-255 to 0-1.
    let scaledImage = imageArray / 255.0

    // 3. Normalization Step 2 (Mean Subtraction): Subtract the global mean.
    let globalMean = MLX.mean(scaledImage)
    let meanSubtractedImage = scaledImage - globalMean

    // 4. Reshaping: Reshape the normalized 1D MLXArray back into a 2D representation.
    let reshapedImage = MLX.reshape(meanSubtractedImage, [height, width])

    return reshapedImage
}

// Example usage:
// let imageWidth = 256
// let imageHeight = 256
// let rawPixels = Array(repeating: Float.random(in: 0...255), count: imageWidth * imageHeight)
//
// let normalizedImageTensor = normalizeImage(pixelData: rawPixels, width: imageWidth, height: imageHeight)
//
// print("Original pixel data (first 5): \(rawPixels.prefix(5))")
// print("Normalized Image Tensor Shape: \(normalizedImageTensor.shape)")
// print("Normalized Image Tensor (first 5 elements, after reshaping and evaluation):")
// // To get data back, we need to evaluate the graph and convert to Swift array
// let evaluatedData = normalizedImageTensor.flattened().data.map { $0.floatValue }
// print(evaluatedData.prefix(5))
//
// // Verify mean (should be close to 0)
// let finalMean = MLX.mean(normalizedImageTensor).item()
// print("Final Mean of normalized image: \(finalMean)")
//
// // Verify range (should be roughly -1 to 1 after scaling and mean subtraction)
// let minVal = MLX.min(normalizedImageTensor).item()
// let maxVal = MLX.max(normalizedImageTensor).item()
// print("Final Min value: \(minVal), Final Max value: \(maxVal)")
