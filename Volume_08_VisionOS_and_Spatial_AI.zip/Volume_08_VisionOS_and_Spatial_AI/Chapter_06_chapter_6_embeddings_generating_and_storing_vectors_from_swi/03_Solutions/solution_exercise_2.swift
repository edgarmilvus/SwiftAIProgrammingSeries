
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation
import Accelerate

struct SimilarityEvaluator {
    let threshold: Float

    /// Determines if two vectors are semantically equivalent based on a threshold.
    func areSemanticallyEquivalent(_ vectorA: Vector, _ vectorB: Vector) -> Bool {
        let similarity = cosineSimilarity(between: vectorA, and: vectorB)
        return similarity >= threshold
    }

    /// Calculates Cosine Similarity using Apple's Accelerate framework for SIMD optimization.
    /// Formula: (A · B) / (||A|| * ||B||)
    func cosineSimilarity(between a: Vector, and b: Vector) -> Float {
        guard a.count == b.count, !a.isEmpty else { return 0.0 }

        // 1. Calculate Dot Product (A · B)
        var dotProduct: Float = 0
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))

        // 2. Calculate Magnitude of A (||A||)
        var sumSquaresA: Float = 0
        vDSP_svesq(a, 1, &sumSquaresA, vDSP_Length(a.count))
        let magnitudeA = sqrt(sumSquaresA)

        // 3. Calculate Magnitude of B (||B||)
        var sumSquaresB: Float = 0
        vDSP_svesq(b, 1, &sumSquaresB, vDSP_Length(b.count))
        let magnitudeB = sqrt(sumSquaresB)

        // 4. Final Similarity Calculation
        let denominator = magnitudeA * magnitudeB
        guard denominator > 0 else { return 0.0 }
        
        return dotProduct / denominator
    }
}

// MARK: - Unit Tests
import XCTest

final class SimilarityTests: XCTestCase {
    let evaluator = SimilarityEvaluator(threshold: 0.95)

    func testSelfSimilarity() {
        let vec: Vector = [0.1, 0.2, 0.3, 0.4]
        let similarity = evaluator.cosineSimilarity(between: vec, and: vec)
        XCTAssertEqual(similarity, 1.0, accuracy: 0.0001)
    }

    func testOrthogonalVectors() {
        let vecA: Vector = [1.0, 0.0, 0.0]
        let vecB: Vector = [0.0, 1.0, 0.0]
        let similarity = evaluator.cosineSimilarity(between: vecA, and: vecB)
        XCTAssertEqual(similarity, 0.0, accuracy: 0.0001)
    }

    func testThresholdLogic() {
        let vecA: Vector = [1.0, 0.0, 0.0]
        let vecB: Vector = [0.99, 0.01, 0.0] // Very close
        let vecC: Vector = [0.5, 0.5, 0.0]   // Not very close
        
        XCTAssertTrue(evaluator.areSemanticallyEquivalent(vecA, vecB))
        XCTAssertFalse(evaluator.areSemanticallyEquivalent(vecA, vecC))
    }
}
