/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// App.tsx
import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, Button, Alert } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { Swipeable } from 'react-native-gesture-handler'; // Requires installation
import { MaterialIcons } from '@expo/vector-icons';
import { cn } from 'nativewind';

// --- Types ---
type Task = {
  id: string;
  title: string;
  description: string;
  completed: boolean;
};

type RootStackParamList = {
  MainTabs: undefined;
  TaskDetail: { task: Task; updateTask: (id: string, completed: boolean) => void };
};

type MainTabsParamList = {
  TaskList: undefined;
  Settings: undefined;
};

const RootStack = createStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<MainTabsParamList>();

// --- Components ---

// 1. Task List Screen
const TaskListScreen = ({ navigation }: any) => {
  const [tasks, setTasks] = useState<Task[]>([
    { id: '1', title: 'Buy Groceries', description: 'Milk, Eggs, Bread', completed: false },
    { id: '2', title: 'Finish Report', description: 'Q4 Financials', completed: true },
    { id: '3', title: 'Call Mom', description: 'Check in on health', completed: false },
  ]);

  // Function to update task status
  const updateTaskStatus = (id: string, newStatus: boolean) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: newStatus } : t));
  };

  // Function to delete task
  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  // Right action for Swipeable (Delete button)
  const renderRightActions = (progress: any, dragX: any, id: string) => {
    return (
      <TouchableOpacity 
        onPress={() => deleteTask(id)}
        className="bg-red-600 justify-center items-end px-4 rounded-lg mb-3"
      >
        <MaterialIcons name="delete" size={24} color="white" />
      </TouchableOpacity>
    );
  };

  const renderItem = ({ item }: { item: Task }) => (
    <Swipeable
      renderRightActions={(p, d) => renderRightActions(p, d, item.id)}
      friction={2}
    >
      <TouchableOpacity
        onPress={() => navigation.navigate('TaskDetail', { task: item, updateTask: updateTaskStatus })}
        className={cn(
          "bg-slate-800 p-4 rounded-xl mb-3 mx-4 shadow-md border-l-4",
          item.completed ? "border-green-500 opacity-70" : "border-blue-500"
        )}
      >
        <Text className={cn("text-white font-bold text-lg", item.completed && "line-through text-slate-400")}>
          {item.title}
        </Text>
        <Text className="text-slate-400 text-sm mt-1">{item.description}</Text>
      </TouchableOpacity>
    </Swipeable>
  );

  return (
    <View className="flex-1 bg-slate-900 pt-4">
      <FlatList 
        data={tasks} 
        renderItem={renderItem} 
        keyExtractor={item => item.id}
        contentContainerStyle={{ paddingBottom: 20 }}
      />
      <View className="absolute bottom-6 right-6">
        <TouchableOpacity className="bg-blue-600 w-14 h-14 rounded-full items-center justify-center shadow-lg">
          <MaterialIcons name="add" size={30} color="white" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

// 2. Task Detail Screen
const TaskDetailScreen = ({ route, navigation }: any) => {
  const { task, updateTask } = route.params;
  const [isCompleted, setIsCompleted] = useState(task.completed);

  const handleToggle = () => {
    const newStatus = !isCompleted;
    setIsCompleted(newStatus);
    // Update the task in the parent list immediately
    updateTask(task.id, newStatus);
  };

  return (
    <View className="flex-1 bg-slate-900 p-6">
      <View className="bg-slate-800 rounded-xl p-6 shadow-lg">
        <Text className="text-2xl font-bold text-white mb-2">{task.title}</Text>
        <Text className="text-slate-400 mb-6 text-base">{task.description}</Text>
        
        <View className="border-t border-slate-700 pt-4 mt-4">
          <Text className="text-slate-300 mb-3 font-semibold">Status: {isCompleted ? 'Completed' : 'Pending'}</Text>
          <Button 
            title={isCompleted ? "Mark as Pending" : "Mark as Completed"} 
            onPress={handleToggle}
            color={isCompleted ? "#f59e0b" : "#10b981"}
          />
        </View>
      </View>
    </View>
  );
};

// 3. Settings Screen (Placeholder for Tab)
const SettingsScreen = () => (
  <View className="flex-1 bg-slate-900 items-center justify-center">
    <Text className="text-white text-xl">Settings</Text>
  </View>
);

// --- Navigators ---

// Inner Tab Navigator
const MainTabs = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: { backgroundColor: '#0f172a', borderTopColor: '#334155' },
        tabBarActiveTintColor: '#3b82f6',
        tabBarInactiveTintColor: '#64748b',
      }}
    >
      <Tab.Screen 
        name="TaskList" 
        component={TaskListScreen} 
        options={{ 
          tabBarLabel: 'Tasks',
          tabBarIcon: ({ color }) => <MaterialIcons name="list" size={24} color={color} />
        }}
      />
      <Tab.Screen 
        name="Settings" 
        component={SettingsScreen} 
        options={{ 
          tabBarLabel: 'Settings',
          tabBarIcon: ({ color }) => <MaterialIcons name="settings" size={24} color={color} />
        }}
      />
    </Tab.Navigator>
  );
};

// Root Stack Navigator (Wraps Tabs)
export default function App() {
  return (
    <NavigationContainer>
      <RootStack.Navigator>
        <RootStack.Screen 
          name="MainTabs" 
          component={MainTabs} 
          options={{ headerShown: false }} 
        />
        <RootStack.Screen 
          name="TaskDetail" 
          component={TaskDetailScreen} 
          options={{ 
            title: 'Task Details',
            headerStyle: { backgroundColor: '#0f172a' },
            headerTintColor: '#fff',
          }} 
        />
      </RootStack.Navigator>
    </NavigationContainer>
  );
}
