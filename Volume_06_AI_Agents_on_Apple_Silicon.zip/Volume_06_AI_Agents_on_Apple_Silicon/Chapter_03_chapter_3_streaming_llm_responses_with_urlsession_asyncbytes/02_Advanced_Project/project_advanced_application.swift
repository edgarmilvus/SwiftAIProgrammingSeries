
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet (for demonstration of dependencies)
// This example primarily uses built-in Foundation and SwiftUI,
// so no external dependencies are strictly required for the core streaming logic.
// However, for a real-world app, you might have:
/*
import PackageDescription

let package = Package(
    name: "AIStreamingClient",
    platforms: [
        .iOS(.v18),
        .macOS(.v15)
    ],
    products: [
        .library(
            name: "AIStreamingClient",
            targets: ["AIStreamingClient"]),
    ],
    dependencies: [
        // Example: If you were using a dedicated Ollama client library
        // .package(url: "https://github.com/some/ollama-swift-client.git", from: "1.0.0"),
        // Or a more advanced JSON parsing library if needed
        // .package(url: "https://github.com/some/advanced-json.git", from: "2.0.0"),
    ],
    targets: [
        .target(
            name: "AIStreamingClient",
            dependencies: []),
        .testTarget(
            name: "AIStreamingClientTests",
            dependencies: ["AIStreamingClient"]),
    ]
)
*/

// --- Start of the main Swift 6 script/app component ---

import Foundation
import SwiftUI // For UI context, though core logic is independent
import OSLog // For robust logging

/// A logger instance for the AI streaming service.
private let logger = Logger(subsystem: "com.example.AIStreamingApp", category: "LLMService")

// MARK: - 1. Data Models for LLM Responses

/// Represents a single chunk of data streamed from an LLM.
/// This structure is designed to match a common LLM streaming protocol
/// where each line is a JSON object containing a 'response' field.
///
/// Example of an incoming NDJSON stream chunk:
/// `{"model":"llama3","created_at":"2024-07-29T10:00:00.123456Z","response":"Hello","done":false}`
/// `{"model":"llama3","created_at":"2024-07-29T10:00:00.234567Z","response":" world","done":false}`
/// `{"model":"llama3","created_at":"2024-07-29T10:00:00.456789Z","response":"","done":true,"total_duration":123456789,...}`
struct LLMResponseChunk: Decodable, Identifiable {
    let id = UUID() // Unique identifier for SwiftUI list updates, though not used directly in this example.
    let response: String? // The actual text chunk from the LLM.
    let done: Bool // Indicates if the LLM has completed its response.

    // Nested 'detail' struct if the LLM provides more complex metadata (e.g., from Ollama's 'pull' or 'show' APIs).
    struct Detail: Decodable {
        let model: String?
        let message: String?
        // Add other fields as per specific LLM API documentation (e.g., 'context', 'parameters').
    }
    let detail: Detail? // Optional detailed metadata about the model or message.

    /// Initializes an `LLMResponseChunk` from a decoder.
    /// Handles cases where `response` might be missing or `nil` in a chunk.
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.response = try container.decodeIfPresent(String.self, forKey: .response)
        self.done = try container.decode(Bool.self, forKey: .done)
        self.detail = try container.decodeIfPresent(Detail.self, forKey: .detail)
    }
}

// MARK: - 2. Custom Error Handling

/// Custom errors for the LLM streaming service, providing specific context for failures.
enum LLMServiceError: Error, LocalizedError {
    case invalidURL
    case networkError(Error)
    case decodingError(Error, String?) // Includes the raw string that failed to decode for debugging.
    case streamInterrupted
    case serverError(statusCode: Int, message: String?) // For HTTP non-2xx responses.
    case unknownError(Error)

    /// Provides a user-friendly description for each error type.
    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "The URL for the LLM service was invalid. Please check the base URL configuration."
        case .networkError(let error):
            return "A network error occurred: \(error.localizedDescription). Check your internet connection or server availability."
        case .decodingError(let error, let rawData):
            return "Failed to decode LLM response chunk. This might indicate an unexpected server response format. Error: \(error.localizedDescription). Raw data: \(rawData ?? "N/A")"
        case .streamInterrupted:
            return "The LLM response stream was unexpectedly interrupted. The server might have closed the connection prematurely."
        case .serverError(let statusCode, let message):
            return "LLM server returned an error (HTTP \(statusCode)): \(message ?? "No specific message provided by the server")."
        case .unknownError(let error):
            return "An unexpected error occurred: \(error.localizedDescription)."
        }
    }
}

// MARK: - 3. LLM Streaming Service Core Logic

/// `LLMStreamProcessor` is responsible for sending prompts to an LLM service
/// (like Ollama) and streaming back its responses using `URLSession.AsyncBytes`.
///
/// This class encapsulates the network communication and JSON parsing logic.
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
final class LLMStreamProcessor {
    private let session: URLSession
    private let baseURL: URL

    /// Initializes the `LLMStreamProcessor` with a base URL for the LLM service.
    /// - Parameter baseURL: The base URL of the LLM API endpoint (e.g., "http://localhost:11434/api/").
    init(baseURL: URL) {
        self.baseURL = baseURL
        // Use a default URLSession, or a custom one for specific configurations (e.g., timeout).
        self.session = URLSession.shared
    }

    /// Streams responses from the LLM for a given prompt and model.
    ///
    /// This method leverages `URLSession.AsyncBytes` to receive data chunks
    /// as they become available, providing a highly responsive user experience.
    /// It parses each line (assumed to be NDJSON) as an `LLMResponseChunk`.
    ///
    /// - Parameters:
    ///   - prompt: The input text prompt for the LLM.
    ///   - model: The identifier of the LLM model to use (e.g., "llama3").
    /// - Returns: An `AsyncThrowingStream` of `LLMResponseChunk` objects that can be
    ///            iterated over using `for await`.
    /// - Throws: `LLMServiceError` if there are issues with URL construction, network, or JSON decoding.
    func streamLLMResponse(prompt: String, model: String) -> AsyncThrowingStream<LLMResponseChunk, Error> {
        // 1. Construct the API request URL.
        // For Ollama's /api/generate endpoint, it's typically a POST request to /api/generate.
        guard let url = URL(string: "generate", relativeTo: baseURL) else {
            logger.error("Failed to construct URL for LLM generation with base URL: \(self.baseURL.absoluteString).")
            // Immediately terminate the stream with an error if the URL is invalid.
            return AsyncThrowingStream { continuation in
                continuation.finish(throwing: LLMServiceError.invalidURL)
            }
        }

        // 2. Prepare the request body.
        // This JSON structure is typical for Ollama's /api/generate endpoint for streaming.
        let requestBody: [String: Any] = [
            "model": model,
            "prompt": prompt,
            "stream": true // This parameter is CRUCIAL for enabling streaming responses from the LLM.
        ]

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: requestBody, options: [])
        } catch {
            logger.error("Failed to serialize request body: \(error.localizedDescription, privacy: .public).")
            // Terminate the stream if the request body cannot be formed.
            return AsyncThrowingStream { continuation in
                continuation.finish(throwing: LLMServiceError.decodingError(error, nil))
            }
        }

        // 3. Create an AsyncThrowingStream to yield decoded chunks.
        // This allows the caller (e.g., a ViewModel) to `for await` over the responses
        // as `LLMResponseChunk` objects, abstracting away raw byte processing.
        return AsyncThrowingStream { continuation in
            // Create a Task to perform the asynchronous network request.
            // This task will be managed by the AsyncThrowingStream's lifecycle.
            let streamTask = Task {
                do {
                    // 4. Initiate the network request and get the AsyncBytes sequence.
                    // `URLSession.shared.bytes(for: request)` returns an `AsyncSequence` of `UInt8`
                    // and the `URLResponse` as soon as headers are received.
                    let (bytes, response) = try await session.bytes(for: request)

                    // 5. Validate the HTTP response.
                    guard let httpResponse = response as? HTTPURLResponse else {
                        logger.error("Received non-HTTP response from LLM service.")
                        throw LLMServiceError.networkError(URLError(.badServerResponse))
                    }

                    guard (200...299).contains(httpResponse.statusCode) else {
                        // If the server returns an error (e.g., 404, 500), try to read an error message
                        // from the response body to provide more context.
                        var errorMessageData = Data()
                        // Attempt to read a small portion of the error body for a message.
                        for try await byte in bytes.prefix(256) { // Read up to 256 bytes for error message.
                            errorMessageData.append(byte)
                        }
                        let errorMessage = String(data: errorMessageData, encoding: .utf8)
                        logger.error("LLM server returned HTTP error: \(httpResponse.statusCode). Message: \(errorMessage ?? "N/A", privacy: .public).")
                        throw LLMServiceError.serverError(statusCode: httpResponse.statusCode, message: errorMessage)
                    }

                    // 6. Process the streamed bytes line by line.
                    // `bytes.lines` is a convenient `AsyncSequence` that splits the incoming byte stream
                    // into lines, which is perfect for NDJSON parsing.
                    for try await line in bytes.lines {
                        // Check for task cancellation before processing each line.
                        // This ensures responsiveness to cancellation requests from the consumer.
                        Task.checkCancellation()

                        guard !line.isEmpty else {
                            // Skip empty lines, which can sometimes appear in streaming protocols.
                            continue
                        }

                        guard let data = line.data(using: .utf8) else {
                            logger.warning("Failed to convert line to Data (UTF-8) for decoding: '\(line, privacy: .public)'.")
                            // Skip this line if it's not valid UTF-8, but continue the stream.
                            continue
                        }

                        // 7. Decode each line as an LLMResponseChunk.
                        do {
                            let chunk = try JSONDecoder().decode(LLMResponseChunk.self, from: data)
                            logger.debug("Received chunk: \(chunk.response ?? "<nil>", privacy: .public) (done: \(chunk.done)).")
                            continuation.yield(chunk) // Yield the decoded chunk to the AsyncThrowingStream.
                        } catch {
                            logger.error("Failed to decode LLMResponseChunk from line: '\(line, privacy: .public)'. Error: \(error.localizedDescription, privacy: .public).")
                            // For robustness, we log the decoding error and continue processing other lines.
                            // A stricter application might choose to terminate the stream here by throwing.
                            // continuation.finish(throwing: LLMServiceError.decodingError(error, line))
                        }
                    }
                    // 8. The `for await` loop completed, meaning the server closed the stream gracefully.
                    logger.info("LLM response stream completed successfully.")
                    continuation.finish() // Signal the successful completion of the stream.

                } catch is CancellationError {
                    // 9. Handle `Task` cancellation gracefully.
                    // This occurs if `streamTask.cancel()` is called.
                    logger.info("LLM stream task was cancelled by consumer.")
                    continuation.finish(throwing: CancellationError())
                } catch let urlError as URLError {
                    // Handle network-specific errors.
                    logger.error("Network error during LLM streaming: \(urlError.localizedDescription, privacy: .public).")
                    continuation.finish(throwing: LLMServiceError.networkError(urlError))
                } catch let serviceError as LLMServiceError {
                    // Re-throw our custom service errors.
                    logger.error("LLM Service Error: \(serviceError.localizedDescription, privacy: .public).")
                    continuation.finish(throwing: serviceError)
                } catch {
                    // 10. Catch any other unexpected errors during the streaming process.
                    logger.critical("An unexpected error occurred during LLM streaming: \(error.localizedDescription, privacy: .public).")
                    continuation.finish(throwing: LLMServiceError.unknownError(error))
                }
            }

            // 11. Cancellation handler for the AsyncThrowingStream.
            // If the consumer of the `AsyncThrowingStream` stops iterating (e.g., the `Task`
            // observing it is cancelled), this `onTermination` closure is called.
            // It allows us to cancel the underlying `streamTask` performing the network request,
            // preventing resource leaks.
            continuation.onTermination = { @Sendable _ in
                logger.info("AsyncThrowingStream terminated. Cancelling underlying network task.")
                streamTask.cancel()
            }
        }
    }
}

// MARK: - 4. Real-world Apple App Context (SwiftUI ViewModel)

/// A SwiftUI `ObservableObject` to integrate the LLM streaming into an app's UI.
/// This acts as a bridge between the user interface and the `LLMStreamProcessor`.
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
final class ChatViewModel: ObservableObject {
    // @Published properties automatically update SwiftUI views when they change.
    @Published var currentResponse: String = ""
    @Published var isStreaming: Bool = false
    @Published var errorMessage: String? = nil
    @Published var receivedChunks: [LLMResponseChunk] = [] // Stores individual chunks for potential advanced display.

    private let llmProcessor: LLMStreamProcessor
    private var streamingTask: Task<Void, Never>? // Holds the `Task` that observes the stream for cancellation.

    /// Initializes the `ChatViewModel` with an `LLMStreamProcessor` instance.
    init(llmProcessor: LLMStreamProcessor) {
        self.llmProcessor = llmProcessor
    }

    /// Starts a new LLM streaming session for a given prompt and model.
    /// This method manages the lifecycle of the streaming `Task` and updates UI-bound properties.
    /// - Parameters:
    ///   - prompt: The user's input prompt for the LLM.
    ///   - model: The identifier of the LLM model to use (e.g., "llama3").
    func startStreaming(prompt: String, model: String) {
        // 1. Reset the UI state for a new request.
        cancelStreaming() // Ensure any previous streaming task is cancelled before starting a new one.
        currentResponse = ""
        errorMessage = nil
        receivedChunks = []
        isStreaming = true // Indicate that streaming has begun.

        // 2. Create a new `Task` to observe the `AsyncThrowingStream`.
        // The `@MainActor` annotation ensures all UI updates happen on the main thread.
        streamingTask = Task { @MainActor in
            do {
                // 3. Iterate over the streamed chunks using `for try await`.
                // Each `chunk` received from `llmProcessor.streamLLMResponse` will update the UI incrementally.
                for try await chunk in llmProcessor.streamLLMResponse(prompt: prompt, model: model) {
                    // Check for cancellation within the loop for immediate responsiveness.
                    Task.checkCancellation()

                    receivedChunks.append(chunk) // Store the raw chunk for potential debugging or detailed display.
                    if let responseText = chunk.response {
                        currentResponse += responseText // Append the new text to the current response.
                    }

                    if chunk.done {
                        logger.info("Final chunk received. LLM stream complete.")
                        isStreaming = false // Mark streaming as complete.
                        break // Exit the loop as the LLM has signaled completion.
                    }
                }
                isStreaming = false // Ensure state is reset if the loop finishes naturally without a `done` chunk.
            } catch {
                // 4. Handle any errors propagated from the streaming process.
                errorMessage = (error as? LLMServiceError)?.errorDescription ?? error.localizedDescription
                logger.error("Error during LLM streaming in ViewModel: \(error.localizedDescription, privacy: .public).")
                isStreaming = false // Ensure streaming state is reset even on error.
            }
        }
    }

    /// Cancels the ongoing LLM streaming task, if any.
    /// This is crucial for stopping active network requests and releasing resources.
    func cancelStreaming() {
        streamingTask?.cancel() // Send a cancellation signal to the underlying Task.
        streamingTask = nil // Clear the reference to the old task.
        isStreaming = false // Update UI state.
        logger.info("Streaming task cancelled by user or new request.")
    }
}

// MARK: - 5. Example Usage (Conceptual SwiftUI View)

/// A conceptual SwiftUI View demonstrating how `ChatViewModel` would be used
/// to build an interactive AI Code Explainer interface.
/// This part is illustrative of UI integration and not strictly part of the streaming core logic.
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
struct ChatView: View {
    @StateObject private var viewModel: ChatViewModel
    @State private var promptText: String = "Explain the concept of 'Structured Concurrency' in Swift 6, including `Task`, `async/await`, and `AsyncSequence`."
    @State private var selectedModel: String = "llama3" // Example model, replace with actual available models.

    /// Initializes the `ChatView` with a dependency-injected `LLMStreamProcessor`.
    init(llmProcessor: LLMStreamProcessor) {
        _viewModel = StateObject(wrappedValue: ChatViewModel(llmProcessor: llmProcessor))
    }

    var body: some View {
        VStack(spacing: 16) {
            // Input field for the user's prompt.
            TextField("Enter your prompt or code snippet here...", text: $promptText, axis: .vertical)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
                .lineLimit(5) // Allow the text field to expand for longer inputs.

            // Picker for selecting the LLM model.
            Picker("Select Model", selection: $selectedModel) {
                Text("llama3").tag("llama3")
                Text("phi3").tag("phi3")
                Text("mistral").tag("mistral")
                Text("gemma").tag("gemma")
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)

            // Action buttons for starting and cancelling streaming.
            HStack {
                Button("Start Streaming Explanation") {
                    viewModel.startStreaming(prompt: promptText, model: selectedModel)
                }
                .buttonStyle(.borderedProminent)
                .disabled(viewModel.isStreaming || promptText.isEmpty) // Disable if already streaming or prompt is empty.

                Button("Cancel Streaming") {
                    viewModel.cancelStreaming()
                }
                .buttonStyle(.bordered)
                .disabled(!viewModel.isStreaming) // Only enable if actively streaming.
            }
            .padding(.horizontal)

            // Scrollable area to display the streamed LLM response.
            ScrollView {
                Text(viewModel.currentResponse)
                    .font(.body)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
                    .textSelection(.enabled) // Allow users to select and copy the text.
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .overlay(
                // Show a progress indicator when streaming.
                Group {
                    if viewModel.isStreaming {
                        ProgressView("Streaming...")
                            .padding()
                            .background(.regularMaterial)
                            .cornerRadius(10)
                    }
                }
            )

            // Display error messages if any occurred.
            if let errorMessage = viewModel.errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .padding()
                    .multilineTextAlignment(.center)
            }
        }
        .padding(.vertical)
        .navigationTitle("AI Code Explainer") // Title for the navigation bar.
    }
}

// MARK: - 6. App Entry Point (for demonstration)

/// Main App structure for a SwiftUI application.
/// This is the entry point where the application starts and dependencies are initialized.
@available(iOS 18.0, macOS 15.0, watchOS 11.0, tvOS 18.0, *)
@main
struct AIStreamingApp: App {
    // Instantiate the LLMStreamProcessor with your Ollama server URL.
    // IMPORTANT: Ensure Ollama is running locally and the model is downloaded.
    // E.g., `ollama serve` in terminal, then `ollama run llama3`.
    // Adjust the URL if your Ollama instance is on a different host or port.
    private let llmProcessor = LLMStreamProcessor(baseURL: URL(string: "http://localhost:11434/api/")!)

    var body: some Scene {
        WindowGroup {
            NavigationView { // Provides navigation capabilities, though a simple view is shown here.
                ChatView(llmProcessor: llmProcessor)
            }
        }
    }
}
