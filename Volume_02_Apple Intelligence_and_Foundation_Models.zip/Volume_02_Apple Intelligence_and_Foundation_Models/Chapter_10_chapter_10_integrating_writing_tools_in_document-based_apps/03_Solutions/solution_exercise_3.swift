
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import UIKit
import WritingTools // Assume WritingTools framework is available

@available(iOS 18.0, *)
class SummarizeSectionViewController: UIViewController, UITextViewDelegate {
    
    private let textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = UIFont.preferredFont(forTextStyle: .body)
        tv.isEditable = true
        tv.isSelectable = true
        tv.backgroundColor = .systemBackground
        tv.layer.borderColor = UIColor.systemGray3.cgColor
        tv.layer.borderWidth = 1
        tv.layer.cornerRadius = 8
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return tv
    }()
    
    private lazy var summarizeButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Summarize Section", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        button.addTarget(self, action: #selector(summarizeSelectedSection), for: .touchUpInside)
        button.isEnabled = false // Disabled by default until a heading is selected
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGroupedBackground
        title = "Summarize Section (iOS 18+)"
        
        view.addSubview(summarizeButton)
        view.addSubview(textView)
        
        NSLayoutConstraint.activate([
            summarizeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            summarizeButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            textView.topAnchor.constraint(equalTo: summarizeButton.bottomAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
        
        textView.delegate = self
        textView.text = """
# Introduction to Swift Concurrency

Swift Concurrency, introduced in Swift 5.5, provides powerful language features for writing asynchronous and parallel code. It aims to simplify the complexities traditionally associated with concurrent programming, such as callback hell and manual thread management. Key components include async/await, Actors, and Structured Concurrency.

## Async/Await

The `async` and `await` keywords are fundamental to Swift Concurrency. `async` functions can be suspended and resumed, allowing them to perform long-running operations without blocking the calling thread. `await` is used to call `async` functions and pause the current execution until the `async` function returns. This makes asynchronous code flow much more like synchronous code, improving readability and maintainability.

### Structured Concurrency

Structured Concurrency ensures that asynchronous tasks are managed in a hierarchical manner. Tasks are organized into a tree-like structure, making it easier to reason about their lifecycle, error handling, and cancellation. `TaskGroup` and `async let` are primary tools for creating child tasks within a parent task. This approach helps prevent common concurrency bugs like resource leaks and forgotten tasks.

## Actors

Actors are reference types that protect their mutable state from concurrent access. They provide a safe way to share mutable state across different tasks by ensuring that only one task can access an actor's isolated state at any given time. This eliminates data races and simplifies synchronization logic, making it easier to build robust concurrent systems.

### Isolation and Reentrancy

Actor isolation means that an actor's properties and methods can only be accessed directly from within the actor itself. External access requires `await` and goes through the actor's implicit serial executor. Reentrancy allows an actor to suspend its execution while `await`ing another `async` call and then resume, potentially allowing other tasks to access its state during the suspension. This is a powerful feature but requires careful consideration to avoid unexpected behavior.
"""
    }
    
    // MARK: - Text View Delegate
    
    func textViewDidChangeSelection(_ textView: UITextView) {
        // Enable/disable summarize button based on selection
        summarizeButton.isEnabled = findSelectedHeadingRange() != nil
    }
    
    // MARK: - Core Logic for Summarization
    
    @objc private func summarizeSelectedSection() {
        guard let (headingRange, sectionText) = findSectionContent() else {
            print("No valid section found for summarization based on current selection.")
            // Optionally show alert to user
            return
        }
        
        Task {
            await performSummarization(for: sectionText, afterHeadingRange: headingRange)
        }
    }
    
    // Helper to find the selected heading and its associated section content
    private func findSectionContent() -> (headingRange: NSRange, sectionText: String)? {
        guard let selectedRange = textView.selectedTextRange, !selectedRange.isEmpty else { return nil }
        
        let fullText = textView.text as NSString
        let selectedNSRange = NSRange(selectedRange, in: textView.text)
        
        // Find the line containing the selection
        let lineRange = fullText.lineRange(for: selectedNSRange)
        let line = fullText.substring(with: lineRange)
        
        // Regex to detect Markdown-style headings (e.g., # Heading, ## Subheading)
        let headingRegex = try! NSRegularExpression(pattern: "^(#+)\\s(.+)$", options: .anchorsMatchLines)
        
        guard let headingMatch = headingRegex.firstMatch(in: line, options: [], range: NSRange(location: 0, length: line.count)) else {
            return nil // Selected line is not a heading
        }
        
        // Extract the heading level (number of '#' characters)
        let headingPrefixRange = headingMatch.range(at: 1)
        let headingLevel = line[Range(headingPrefixRange, in: line)!].count
        
        // Calculate the full range of the selected heading within the document
        let documentHeadingRange = NSRange(location: lineRange.location, length: lineRange.length - 1) // Exclude newline
        
        // Find the end of the section
        var sectionEndLocation = fullText.length
        let fullTextRange = NSRange(location: 0, length: fullText.length)
        
        // Iterate through lines after the current heading to find the next heading of same or higher level
        fullText.enumerateSubstrings(in: NSRange(location: lineRange.upperBound, length: fullText.length - lineRange.upperBound), options: .byLines) { (substring, substringRange, enclosingRange, stop) in
            if let substring = substring {
                if let nextHeadingMatch = headingRegex.firstMatch(in: substring, options: [], range: NSRange(location: 0, length: substring.count)) {
                    let nextHeadingPrefixRange = nextHeadingMatch.range(at: 1)
                    let nextHeadingLevel = substring[Range(nextHeadingPrefixRange, in: substring)!].count
                    
                    if nextHeadingLevel <= headingLevel {
                        // Found a heading of same or higher level, this is the end of our section
                        sectionEndLocation = substringRange.location + lineRange.upperBound - 1 // -1 to exclude newline before next heading
                        stop.pointee = true
                        return
                    }
                }
            }
        }
        
        let sectionNSRange = NSRange(location: lineRange.location, length: sectionEndLocation - lineRange.location)
        let sectionText = fullText.substring(with: sectionNSRange)
        
        return (documentHeadingRange, sectionText)
    }
    
    // Helper to just check if the selection is on a heading for button state
    private func findSelectedHeadingRange() -> NSRange? {
        guard let selectedRange = textView.selectedTextRange, !selectedRange.isEmpty else { return nil }
        
        let fullText = textView.text as NSString
        let selectedNSRange = NSRange(selectedRange, in: textView.text)
        let lineRange = fullText.lineRange(for: selectedNSRange)
        let line = fullText.substring(with: lineRange)
        
        let headingRegex = try! NSRegularExpression(pattern: "^(#+)\\s(.+)$", options: .anchorsMatchLines)
        return headingRegex.firstMatch(in: line, options: [], range: NSRange(location: 0, length: line.count)) != nil ? lineRange : nil
    }
    
    private func performSummarization(for sectionText: String, afterHeadingRange: NSRange) async {
        DispatchQueue.main.async {
            self.summarizeButton.isEnabled = false
            self.summarizeButton.setTitle("Summarizing...", for: .normal)
            // Optionally, show activity indicator
        }
        
        let request = WritingToolsRequest.SummarizeRequest(text: sectionText)
        
        do {
            let result = try await WritingToolsService.shared.summarizeRequest(for: request)
            
            if let summary = result.summarize.summary, !summary.isEmpty {
                DispatchQueue.main.async {
                    self.insertSummary(summary, after: afterHeadingRange)
                    print("Section summarized successfully.")
                }
            } else {
                DispatchQueue.main.async {
                    print("No summary generated for the section.")
                }
            }
        } catch {
            DispatchQueue.main.async {
                print("Error summarizing section: \(error.localizedDescription)")
            }
        }
        
        DispatchQueue.main.async {
            self.summarizeButton.isEnabled = true
            self.summarizeButton.setTitle("Summarize Section", for: .normal)
            // Optionally, hide activity indicator
        }
    }
    
    private func insertSummary(_ summary: String, after headingRange: NSRange) {
        let mutableAttributedString = NSMutableAttributedString(attributedString: textView.attributedText)
        
        let summaryPrefix = "\n\nSummary: "
        let formattedSummary = summaryPrefix + summary
        
        let summaryAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.italicSystemFont(ofSize: UIFont.preferredFont(forTextStyle: .subheadline).pointSize),
            .foregroundColor: UIColor.systemGray
        ]
        let attributedSummary = NSAttributedString(string: formattedSummary, attributes: summaryAttributes)
        
        // Insertion point: after the heading line, including its newline character
        let insertionLocation = headingRange.location + headingRange.length
        
        mutableAttributedString.insert(attributedSummary, at: insertionLocation)
        textView.attributedText = mutableAttributedString
        
        // Scroll to the new summary
        let newSummaryRange = NSRange(location: insertionLocation, length: attributedSummary.length)
        textView.scrollRangeToVisible(newSummaryRange)
    }
    
    // Ensure the view controller is available for iOS 18+
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        guard #available(iOS 18.0, *) else { return nil }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        guard #available(iOS 18.0, *) else { return }
    }
}
