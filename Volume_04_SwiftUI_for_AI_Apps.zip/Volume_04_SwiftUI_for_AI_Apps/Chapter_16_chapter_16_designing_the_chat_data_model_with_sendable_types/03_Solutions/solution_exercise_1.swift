
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation

// 1. Define a User struct
struct User: Identifiable {
    let id: UUID
    let name: String
    let avatarURL: URL? // URL is Sendable
    
    // User is automatically Sendable because all its properties are Sendable:
    // UUID (struct), String (struct), Optional<URL> (Optional is Sendable if its wrapped type is Sendable, and URL is a Sendable struct).
}

// 2. Define a ChatMessage struct
struct ChatMessage: Identifiable {
    let id: UUID
    let sender: User // User is Sendable
    let content: String
    let timestamp: Date // Date is Sendable
    
    // ChatMessage is automatically Sendable because all its properties are Sendable:
    // UUID (struct), User (Sendable struct), String (struct), Date (struct).
}

// Example Usage (for verification, not part of the core solution)
func demonstrateSendable() {
    let user1 = User(id: UUID(), name: "Alice", avatarURL: URL(string: "https://example.com/alice.png"))
    let message1 = ChatMessage(id: UUID(), sender: user1, content: "Hello there!", timestamp: Date())

    // In a real app, you might pass these across actor boundaries:
    // Task { await someActor.process(message1) }
    // The compiler ensures this is safe because ChatMessage (and User) are Sendable.
    
    print("User: \(user1.name), Message: \(message1.content)")
}

// Call to demonstrate (optional)
// demonstrateSendable()
