
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

// ContentView.swift
import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Welcome to NeuroAgent!")
                .font(.largeTitle)
                .padding()

            Text("Your personal AI companion.")
                .font(.headline)
                .padding(.bottom, 20)

            Button {
                // This action requires the com.apple.security.network.client entitlement.
                // In a real app, this would initiate an async network request.
                Task { // Using Swift 6 concurrency for a hypothetical async operation
                    print("Initiating model download...")
                    await simulateNetworkDownload()
                    print("Model download simulated successfully.")
                }
            } label: {
                Label("Download Latest Model", systemImage: "cloud.arrow.down.fill")
            }
            .padding()

            Button {
                // This action requires the com.apple.security.files.user-selected.read-write entitlement.
                // In a real app, this would present a save panel (e.g., NSSavePanel).
                Task { // Using Swift 6 concurrency for a hypothetical async operation
                    print("Saving current chat session...")
                    await simulateFileSave()
                    print("Chat log save simulated successfully.")
                }
            } label: {
                Label("Save Chat Log", systemImage: "doc.text.fill")
            }
            .padding()

            Spacer()
            Text("App Sandbox and Entitlements configured.")
                .font(.caption)
                .foregroundColor(.gray)
        }
        .frame(minWidth: 400, minHeight: 300)
        .padding()
    }

    /// Simulates an asynchronous network download.
    private func simulateNetworkDownload() async {
        // In a real app: URLSession.shared.data(from: url)
        try? await Task.sleep(nanoseconds: 2 * 1_000_000_000) // Simulate 2-second download
    }

    /// Simulates an asynchronous file save operation.
    private func simulateFileSave() async {
        // In a real app: NSSavePanel to get user permission, then FileWrapper or Data.write
        try? await Task.sleep(nanoseconds: 1 * 1_000_000_000) // Simulate 1-second save
    }
}

#Preview {
    ContentView()
}
