
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import CoreML // Required for MLModel and related types
import Vision   // Often used for image processing with Core ML models

// MARK: - Helper Extension for UIImage to CVPixelBuffer Conversion

/// An extension to `UIImage` to facilitate conversion to `CVPixelBuffer`,
/// which is the required input format for many Core ML image models.
extension UIImage {
    /// Converts a `UIImage` to a `CVPixelBuffer` suitable for Core ML inference.
    /// - Parameters:
    ///   - width: The desired width of the pixel buffer.
    ///   - height: The desired height of the pixel buffer.
    /// - Returns: An optional `CVPixelBuffer` if the conversion is successful, otherwise `nil`.
    ///
    /// This method scales the image to the specified dimensions and converts its
    /// pixel data into a `CVPixelBuffer` with a BGRA pixel format.
    func toCVPixelBuffer(width: Int, height: Int) -> CVPixelBuffer? {
        // Ensure the image has a valid CGImage
        guard let cgImage = self.cgImage else { return nil }

        // Define pixel buffer attributes
        let options: [String: Any] = [
            kCVPixelBufferCGImageCompatibilityKey as String: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey as String: true,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]

        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            width,
            height,
            kCVPixelFormatType_32BGRA, // Core ML models often expect BGRA
            options as CFDictionary,
            &pixelBuffer
        )

        guard status == kCVReturnSuccess, let unwrappedPixelBuffer = pixelBuffer else {
            print("Failed to create CVPixelBuffer: \(status)")
            return nil
        }

        CVPixelBufferLockBaseAddress(unwrappedPixelBuffer, .init(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(unwrappedPixelBuffer)

        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        guard let context = CGContext(
            data: pixelData,
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(unwrappedPixelBuffer),
            space: rgbColorSpace,
            bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
        ) else {
            print("Failed to create CGContext for CVPixelBuffer.")
            return nil
        }

        // Draw the image into the context, scaling it to fill the buffer
        context.translateBy(x: 0, y: CGFloat(height))
        context.scaleBy(x: 1.0, y: -1.0) // Flip context to draw image correctly
        context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        CVPixelBufferUnlockBaseAddress(unwrappedPixelBuffer, .init(rawValue: 0))

        return unwrappedPixelBuffer
    }
}

// MARK: - SwiftUI View for Plant Classifier

/// A SwiftUI view that integrates a custom Create ML image classification model.
///
/// This view allows loading a sample image, performing inference using a `PlantClassifier` model,
/// and displaying the predicted plant species and its confidence.
@available(iOS 18.0, *) // Targeting latest iOS SDK for modern Swift 6 features
struct PlantClassifierView: View {
    // MARK: - Model Loading

    /// A lazy-loaded instance of our custom Core ML model.
    ///
    /// Using `lazy var` ensures the model is only loaded when it's first accessed,
    /// preventing unnecessary resource consumption if the view is created but not used.
    /// The `try?` handles potential errors during model initialization (e.g., model file not found).
    private lazy var plantClassifier: PlantClassifier? = {
        do {
            // Attempt to load the model. The PlantClassifier class is auto-generated by Xcode
            // when you add your PlantClassifier.mlmodel file to the project.
            let config = MLModelConfiguration()
            // It's good practice to explicitly set the compute unit for performance optimization.
            // .all for default (GPU/Neural Engine if available), .cpuOnly for debugging/fallback.
            config.computeUnits = .all
            return try PlantClassifier(configuration: config)
        } catch {
            print("Error loading PlantClassifier model: \(error.localizedDescription)")
            return nil
        }
    }()

    // MARK: - State Variables

    @State private var selectedImage: UIImage? = UIImage(named: "samplePlant") // A sample image from Assets.xcassets
    @State private var predictionLabel: String = "No prediction yet"
    @State private var predictionConfidence: String = ""
    @State private var isProcessing: Bool = false

    // MARK: - View Body

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // Display the selected image
                Group {
                    if let image = selectedImage {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: 300)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                    } else {
                        Image(systemName: "photo.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 150)
                            .foregroundColor(.gray)
                            .opacity(0.6)
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(10)
                    }
                }
                .padding(.horizontal)

                // Display prediction results
                Text(predictionLabel)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                Text(predictionConfidence)
                    .font(.headline)
                    .foregroundColor(.secondary)

                // Button to trigger prediction
                Button {
                    Task {
                        await classifyImage()
                    }
                } label: {
                    Label("Classify Plant", systemImage: "leaf.fill")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                }
                .padding(.horizontal)
                .disabled(isProcessing || selectedImage == nil) // Disable button while processing or no image

                if isProcessing {
                    ProgressView("Classifying...")
                        .progressViewStyle(.circular)
                        .padding()
                }

                Spacer()
            }
            .navigationTitle("Plant Identifier")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                // Initial classification on appear if an image is already set
                // For a real app, you'd integrate UIImagePickerController here.
                Task {
                    await classifyImage()
                }
            }
        }
    }

    // MARK: - Classification Logic

    /// Performs image classification using the loaded Core ML model.
    ///
    /// This asynchronous function handles the entire inference pipeline:
    /// 1. Checks for model and image availability.
    /// 2. Converts the `UIImage` to a `CVPixelBuffer`.
    /// 3. Creates the model input.
    /// 4. Executes the prediction.
    /// 5. Updates the UI with the results on the main actor.
    @MainActor // Ensure UI updates happen on the main thread
    private func classifyImage() async {
        guard let model = plantClassifier else {
            predictionLabel = "Model not loaded."
            predictionConfidence = ""
            return
        }
        guard let image = selectedImage else {
            predictionLabel = "No image selected."
            predictionConfidence = ""
            return
        }

        isProcessing = true
        predictionLabel = "Classifying..."
        predictionConfidence = ""

        do {
            // Get the expected input size from the model's input description.
            // For image models, this is typically a CVPixelBuffer of specific width/height.
            guard let imageConstraint = model.model.inputDescriptionsByName["image"]?.imageConstraint else {
                throw NSError(domain: "PlantClassifier", code: 1, userInfo: [NSLocalizedDescriptionKey: "Image input constraint not found."])
            }
            let inputWidth = Int(imageConstraint.pixelsWide)
            let inputHeight = Int(imageConstraint.pixelsHigh)

            // Convert UIImage to CVPixelBuffer with the model's expected dimensions
            guard let pixelBuffer = image.toCVPixelBuffer(width: inputWidth, height: inputHeight) else {
                throw NSError(domain: "PlantClassifier", code: 2, userInfo: [NSLocalizedDescriptionKey: "Failed to convert image to pixel buffer."])
            }

            // Create the model input object. The `image` label corresponds to the input
            // name defined in your Create ML model.
            let modelInput = PlantClassifierInput(image: pixelBuffer)

            // Perform the prediction
            let output = try model.prediction(input: modelInput)

            // Process the output
            let topPrediction = output.classLabel
            // Find the confidence for the top prediction
            if let confidence = output.classLabelProbs[topPrediction] {
                predictionLabel = "Prediction: \(topPrediction)"
                predictionConfidence = String(format: "Confidence: %.2f%%", confidence * 100)
            } else {
                predictionLabel = "Prediction: \(topPrediction)"
                predictionConfidence = "Confidence unknown"
            }

        } catch {
            predictionLabel = "Classification failed!"
            predictionConfidence = "Error: \(error.localizedDescription)"
            print("Classification error: \(error)")
        }

        isProcessing = false
    }
}

// MARK: - App Entry Point

@main
@available(iOS 18.0, *)
struct CreateMLIntegrationApp: App {
    var body: some Scene {
        WindowGroup {
            PlantClassifierView()
        }
    }
}

/*
To make this code runnable:
1.  **Create a Create ML Model:** Train an image classifier in Create ML (e.g., using a dataset of plant images). Name the output model `PlantClassifier.mlmodel`.
2.  **Add Model to Xcode:** Drag `PlantClassifier.mlmodel` into your Xcode project navigator. Ensure it's added to your app target. Xcode will automatically generate `PlantClassifier.swift`.
3.  **Add Sample Image:** Add an image file (e.g., `plant_example.jpg`) to your `Assets.xcassets` and name it "samplePlant". This image will be used by `UIImage(named: "samplePlant")`.
4.  **Run on iOS 18.0+:** Ensure your project target is iOS 18.0 or later, or adjust `@available` attributes if targeting older versions (Core ML is available on older versions, but `Task` and `await` are more common with modern Swift).
*/
