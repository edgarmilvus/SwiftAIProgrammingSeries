
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 17.0, *)
actor SentimentService {
    private let builtInTagger: NLTagger
    private let customAnalyzer: CustomSentimentAnalyzer?

    init() {
        self.builtInTagger = NLTagger(tagSchemes: [.sentiment])
        self.customAnalyzer = CustomSentimentAnalyzer() // May be nil if custom model fails to load
    }

    func performBuiltInAnalysis(text: String) async -> Double? {
        // NLTagger's enumerateTags is synchronous, so we'll wrap it in a Task
        // to ensure it runs on a background thread if called from the main actor.
        return await Task.detached {
            self.builtInTagger.string = text
            var sentimentScore: Double?
            self.builtInTagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .document, scheme: .sentiment, options: []) { tag, tokenRange in
                if let tag = tag, let score = Double(tag.rawValue) {
                    sentimentScore = score
                }
                return true
            }
            return sentimentScore
        }.value
    }

    func performCustomAnalysis(text: String) async -> String? {
        guard let customAnalyzer = customAnalyzer else { return nil }
        return await customAnalyzer.analyzeCustomSentiment(for: text)
    }
}

// Usage from a UI context (e.g., a SwiftUI View or ViewController)
@available(iOS 17.0, *)
class MyViewModel: ObservableObject { // Or @Observable (iOS 17+)
    @Published var currentSentiment: Double?
    @Published var customSentimentLabel: String?

    private let sentimentService = SentimentService()

    func analyzeText(_ text: String) async {
        // Perform both analyses concurrently
        async let builtInResult = sentimentService.performBuiltInAnalysis(text: text)
        async let customResult = sentimentService.performCustomAnalysis(text: text)

        // Await their results and update UI on the main actor
        await MainActor.run {
            self.currentSentiment = await builtInResult
            self.customSentimentLabel = await customResult
        }
    }
}
