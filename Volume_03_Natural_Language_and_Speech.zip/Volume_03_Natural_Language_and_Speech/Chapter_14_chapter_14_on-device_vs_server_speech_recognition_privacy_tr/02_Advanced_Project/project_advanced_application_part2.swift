
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Speech
import AVFoundation

/// Custom error types for the SpeechRecognitionManager.
enum SpeechRecognitionError: Error, LocalizedError {
    case notAuthorized
    case recognizerUnavailable
    case audioEngineSetupFailed(Error)
    case recordingInProgress
    case noInputNode
    case recognitionTaskFailed(Error)
    case alreadyRecording

    var errorDescription: String? {
        switch self {
        case .notAuthorized:
            return "Speech recognition is not authorized. Please enable it in Settings."
        case .recognizerUnavailable:
            return "Speech recognizer is not available for the selected locale."
        case .audioEngineSetupFailed(let error):
            return "Audio engine setup failed: \(error.localizedDescription)"
        case .recordingInProgress:
            return "A recording is already in progress."
        case .noInputNode:
            return "Audio engine input node is not available."
        case .recognitionTaskFailed(let error):
            return "Speech recognition task failed: \(error.localizedDescription)"
        case .alreadyRecording:
            return "Cannot start recording; already recording."
        }
    }
}

/// Manages speech recognition for the Secure Voice Notes app,
/// allowing dynamic switching between on-device and server-based recognition.
@available(iOS 15.0, *) // SFSpeechRecognizer and async/await require iOS 15+
class SpeechRecognitionManager: NSObject, SFSpeechRecognizerDelegate {

    // MARK: - Properties

    /// The primary speech recognizer. Optional because it might not be available or authorized.
    private var speechRecognizer: SFSpeechRecognizer?

    /// The audio engine responsible for capturing and processing audio input.
    private let audioEngine = AVAudioEngine()

    /// The request object that feeds audio buffers to the speech recognizer.
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?

    /// The task object that manages the speech recognition process.
    private var recognitionTask: SFSpeechRecognitionTask?

    /// A flag indicating whether the manager is currently recording and recognizing speech.
    private(set) var isRecording = false

    /// Closure to deliver transcription updates and errors to the caller.
    /// - Parameters:
    ///   - transcript: The current partial or final transcription string.
    ///   - error: An optional error if the recognition failed.
    var transcriptUpdateHandler: ((String?, Error?) -> Void)?

    /// The locale for speech recognition (e.g., "en-US").
    let locale: Locale

    // MARK: - Initialization

    /// Initializes the speech recognition manager with a specific locale.
    /// - Parameter localeIdentifier: The BCP-47 language tag for the desired locale (e.g., "en-US").
    init(localeIdentifier: String = "en-US") {
        self.locale = Locale(identifier: localeIdentifier)
        super.init()
        // Initialize SFSpeechRecognizer. It can be nil if the locale is not supported.
        speechRecognizer = SFSpeechRecognizer(locale: self.locale)
        speechRecognizer?.delegate = self // Set self as delegate to monitor availability changes.
    }

    // MARK: - Authorization

    /// Requests authorization for speech recognition and microphone access.
    /// - Returns: A boolean indicating if authorization was granted.
    /// - Throws: `SpeechRecognitionError.notAuthorized` if authorization fails.
    func requestAuthorization() async throws {
        // Request microphone access
        let audioPermissionStatus = await AVCaptureDevice.requestAccess(for: .audio)
        guard audioPermissionStatus else {
            throw SpeechRecognitionError.notAuthorized
        }

        // Request speech recognition authorization
        return await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { authStatus in
                switch authStatus {
                case .authorized:
                    print("Speech recognition authorized.")
                    continuation.resume(returning: ())
                case .denied, .restricted, .notDetermined:
                    print("Speech recognition not authorized. Status: \(authStatus.rawValue)")
                    continuation.resume(throwing: SpeechRecognitionError.notAuthorized)
                @unknown default:
                    print("Unknown authorization status.")
                    continuation.resume(throwing: SpeechRecognitionError.notAuthorized)
                }
            }
        }
    }

    // MARK: - Recording Control

    /// Starts the speech recognition process.
    /// - Parameter prefersOnDeviceRecognition: A boolean indicating if on-device recognition is preferred.
    ///                                       If `true` and supported, on-device recognition is used.
    ///                                       Otherwise, server-based recognition is used.
    /// - Throws: `SpeechRecognitionError` if setup or recognition fails.
    func startRecording(prefersOnDeviceRecognition: Bool) async throws {
        guard !isRecording else {
            throw SpeechRecognitionError.alreadyRecording
        }

        // 1. Cancel any existing recognition task and request.
        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest = nil

        // 2. Ensure speech recognizer is available and authorized.
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            throw SpeechRecognitionError.recognizerUnavailable
        }
        guard SFSpeechRecognizer.authorizationStatus() == .authorized else {
            throw SpeechRecognitionError.notAuthorized
        }

        // 3. Configure audio session.
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            throw SpeechRecognitionError.audioEngineSetupFailed(error)
        }

        // 4. Create recognition request.
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            throw SpeechRecognitionError.audioEngineSetupFailed(NSError(domain: "SpeechRecognition", code: 0, userInfo: [NSLocalizedDescriptionKey: "Unable to create SFSpeechAudioBufferRecognitionRequest"]))
        }

        // CRITICAL: Set the preference for on-device recognition.
        // This is where the privacy trade-off is implemented.
        // If the user prefers on-device AND the recognizer supports it,
        // then we require on-device. Otherwise, it defaults to server-based.
        recognitionRequest.requiresOnDeviceRecognition = prefersOnDeviceRecognition && speechRecognizer.supportsOnDeviceRecognition
        print("Attempting recognition. On-device preference: \(prefersOnDeviceRecognition). Supported on-device: \(speechRecognizer.supportsOnDeviceRecognition). Actual requiresOnDeviceRecognition: \(recognitionRequest.requiresOnDeviceRecognition)")


        // 5. Start the recognition task.
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            var isFinal = false
            if let result = result {
                self.transcriptUpdateHandler?(result.bestTranscription.formattedString, nil)
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                // If there's an error or the task is final, stop recording and report.
                self.isRecording = false // Set to false before cleanup to avoid re-triggering logic
                self.audioEngine.stop()
                self.audioEngine.inputNode.removeTap(onBus: 0)
                self.recognitionRequest?.endAudio()
                self.recognitionTask = nil
                self.recognitionRequest = nil
                self.resetAudioSession()

                if let error = error {
                    print("Recognition task error: \(error.localizedDescription)")
                    self.transcriptUpdateHandler?(nil, SpeechRecognitionError.recognitionTaskFailed(error))
                } else if isFinal {
                    print("Recognition task completed successfully.")
                    // Final result already sent via handler
                }
            }
        }

        // 6. Configure audio engine for input.
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }

        // 7. Prepare and start the audio engine.
        audioEngine.prepare()
        do {
            try audioEngine.start()
            isRecording = true
            print("Audio engine started. Recording...")
        } catch {
            self.isRecording = false
            throw SpeechRecognitionError.audioEngineSetupFailed(error)
        }
    }

    /// Stops the current speech recognition session.
    func stopRecording() {
        guard isRecording else { return }

        print("Stopping recording...")
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0) // Remove the tap to prevent memory leaks
        recognitionRequest?.endAudio() // Signal that no more audio will be appended
        recognitionTask?.cancel() // Cancel the task if it's still running
        recognitionTask = nil
        recognitionRequest = nil
        isRecording = false
        resetAudioSession()
        print("Recording stopped.")
    }

    /// Resets the audio session to a default state, deactivating it.
    private func resetAudioSession() {
        do {
            let audioSession = AVAudioSession.sharedInstance()
            if audioSession.isActive {
                try audioSession.setActive(false, options: .notifyOthersOnDeactivation)
            }
        } catch {
            print("Error deactivating audio session: \(error.localizedDescription)")
        }
    }

    // MARK: - SFSpeechRecognizerDelegate

    /// Called when the availability of the speech recognizer changes.
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            print("Speech recognizer is now available.")
        } else {
            print("Speech recognizer is no longer available.")
            // Potentially inform the user or switch to a different mode.
        }
    }
}

/*
// Example Usage in a ViewController or ViewModel:

@available(iOS 15.0, *)
class VoiceNotesViewModel: ObservableObject {
    @Published var transcript: String = ""
    @Published var isRecording: Bool = false
    @Published var errorMessage: String?
    @Published var prefersOnDevice: Bool = true // User setting

    private var speechManager: SpeechRecognitionManager

    init() {
        speechManager = SpeechRecognitionManager(localeIdentifier: "en-US")
        speechManager.transcriptUpdateHandler = { [weak self] newTranscript, error in
            DispatchQueue.main.async {
                if let newTranscript = newTranscript {
                    self?.transcript = newTranscript
                }
                if let error = error {
                    self?.errorMessage = error.localizedDescription
                    self?.isRecording = false
                }
            }
        }
    }

    func toggleRecording() {
        if isRecording {
            stopRecording()
        } else {
            startRecording()
        }
    }

    private func startRecording() {
        Task {
            do {
                // First, ensure authorization.
                try await speechManager.requestAuthorization()

                // Then, start recording with the user's preference.
                try await speechManager.startRecording(prefersOnDeviceRecognition: prefersOnDevice)
                DispatchQueue.main.async {
                    self.isRecording = true
                    self.transcript = ""
                    self.errorMessage = nil
                }
            } catch {
                DispatchQueue.main.async {
                    self.errorMessage = error.localizedDescription
                    self.isRecording = false
                }
            }
        }
    }

    private func stopRecording() {
        speechManager.stopRecording()
        DispatchQueue.main.async {
            self.isRecording = false
        }
    }
}

// In a SwiftUI View (for context):
// struct VoiceNotesView: View {
//     @StateObject private var viewModel = VoiceNotesViewModel()
//
//     var body: some View {
//         VStack {
//             Toggle("Prefer On-Device Recognition", isOn: $viewModel.prefersOnDevice)
//                 .padding()
//             TextEditor(text: $viewModel.transcript)
//                 .frame(height: 200)
//                 .border(Color.gray, width: 1)
//                 .padding()
//             Button(action: { viewModel.toggleRecording() }) {
//                 Text(viewModel.isRecording ? "Stop Recording" : "Start Recording")
//                     .padding()
//                     .background(viewModel.isRecording ? Color.red : Color.blue)
//                     .foregroundColor(.white)
//                     .cornerRadius(10)
//             }
//             .padding()
//             if let error = viewModel.errorMessage {
//                 Text(error)
//                     .foregroundColor(.red)
//                     .padding()
//             }
//         }
//     }
// }
*/
