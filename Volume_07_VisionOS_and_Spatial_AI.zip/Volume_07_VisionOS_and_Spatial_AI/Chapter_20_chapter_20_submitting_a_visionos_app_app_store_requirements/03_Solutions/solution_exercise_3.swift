
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import ARKit
import Observation

@available(visionOS 1.0, *)
enum PermissionStatus {
    case notDetermined, authorized, denied, restricted
}

@available(visionOS 1.0, *)
@Observable
@MainActor
class PermissionManager {
    var cameraStatus: PermissionStatus = .notDetermined
    var spatialStatus: PermissionStatus = .notDetermined
    
    /// Simulates checking system permissions
    func checkPermissions() async {
        // In a real app, we would check AVCaptureDevice.authorizationStatus
        // and ARKit session availability.
        try? await Task.sleep(for: .seconds(1)) 
        self.cameraStatus = .notDetermined 
    }
    
    /// Triggers the actual system dialogs
    func requestPermissions() async {
        // Simulating the delay of a system dialog interaction
        print("Triggering system permission dialog...")
        try? await Task.sleep(for: .seconds(2))
        
        // Simulate user granting permission
        self.cameraStatus = .authorized
        self.spatialStatus = .authorized
    }
    
    func resetToDenied() {
        self.cameraStatus = .denied
    }
}

@available(visionOS 1.0, *)
struct PermissionPreflightView: View {
    var manager: PermissionManager
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: "arkit")
                .font(.system(size: 60))
                .foregroundStyle(.blue)
            
            VStack(spacing: 10) {
                Text("Enable Spatial Scanning")
                    .font(.largeTitle)
                
                Text("To place virtual furniture in your room, SpatialScan needs to understand your environment's geometry and use the camera for alignment.")
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
            }
            
            if manager.cameraStatus == .denied {
                Text("Permission is required in Settings to use this feature.")
                    .font(.caption)
                    .foregroundStyle(.red)
            }
            
            Button(action: {
                Task {
                    await manager.requestPermissions()
                    dismiss()
                }
            }) {
                Text("Continue")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
        }
        .padding(40)
        .frame(width: 500, height: 400)
        .glassBackgroundEffect() // Essential for visionOS
    }
}

@available(visionOS 1.0, *)
struct PermissionOrchestratorView: View {
    @State private var manager = PermissionManager()
    @State private var showPreflight = false
    
    var body: some View {
        VStack {
            if manager.cameraStatus == .authorized {
                Text("Ready to Scan! 🚀")
                    .font(.largeTitle)
            } else if manager.cameraStatus == .denied {
                Text("Please enable Camera in Settings.")
                    .foregroundStyle(.red)
                Button("Simulate Reset (For Demo)") {
                    manager.resetToDenied()
                }
            } else {
                Button("Start Spatial Scan") {
                    showPreflight = true
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .sheet(isPresented: $showPreflight) {
            PermissionPreflightView(manager: manager)
        }
        .task {
            await manager.checkPermissions()
        }
    }
}
