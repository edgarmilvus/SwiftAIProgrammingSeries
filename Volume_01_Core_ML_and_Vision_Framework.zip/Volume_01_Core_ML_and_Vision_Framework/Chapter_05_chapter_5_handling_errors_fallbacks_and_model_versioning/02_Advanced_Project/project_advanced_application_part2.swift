
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import CoreML
import Vision
import UIKit // For UIImage, CGImage

// MARK: - 1. Error Definitions
/// Custom error types for the document classifier service, providing detailed context.
enum AppError: Error, LocalizedError {
    case modelLoadingFailed(name: String, underlyingError: Error)
    case predictionFailed(underlyingError: Error)
    case invalidInput
    case modelNotFound(name: String)
    case unsupportedModelVersion(expected: String, actual: String)

    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let name, let error):
            return "Failed to load Core ML model '\(name)': \(error.localizedDescription)"
        case .predictionFailed(let error):
            return "Core ML prediction failed: \(error.localizedDescription)"
        case .invalidInput:
            return "Invalid input provided for classification."
        case .modelNotFound(let name):
            return "Core ML model '\(name)' could not be found."
        case .unsupportedModelVersion(let expected, let actual):
            return "Model version mismatch. Expected \(expected), got \(actual)."
        }
    }
}

// MARK: - 2. Document Type Definitions
/// Represents the types of documents our service can classify.
enum DocumentType: String, CaseIterable, Codable {
    case invoice = "Invoice"
    case receipt = "Receipt"
    case businessCard = "Business Card"
    case idCard = "ID Card"
    case generic = "Generic Document" // Fallback if no specific classification
    case unknown = "Unknown" // Fallback for prediction failures or unclassified items

    var description: String {
        return self.rawValue
    }
}

// MARK: - 3. Model Versioning
/// Defines the different versions of Core ML models the service can handle.
enum ModelVersion {
    case v2 // Newer, potentially downloaded, more accurate model
    case v1 // Shipped with the app, default model
    case fallback // No ML model available; uses simple heuristics
}

/// A service responsible for classifying document types using Core ML and Vision.
/// It supports multiple model versions, robust error handling, and fallbacks to ensure stability.
@available(iOS 18.0, *) // Requires iOS 18 for full Swift 6 concurrency features
class DocumentClassifierService {

    /// The currently active VNCoreMLModel used for predictions.
    private var currentModel: VNCoreMLModel?
    /// The version of the currently active model.
    private var currentModelVersion: ModelVersion = .fallback

    // Expected version strings for model metadata verification.
    private let expectedV1ModelVersionString = "1.0"
    private let expectedV2ModelVersionString = "2.1" // Example: v2.0 had a bug, updated to v2.1

    // Names of the Core ML model assets (assuming they are compiled to .mlmodelc)
    private let v1ModelName = "DocumentClassifier_v1"
    private let v2ModelName = "DocumentClassifier_v2"

    /// Initializes the document classifier service.
    /// It attempts to load the best available Core ML model asynchronously upon creation.
    init() {
        Task {
            await loadBestAvailableModel()
        }
    }

    // MARK: - 4. Model Loading Strategy with Fallbacks

    /// Asynchronously attempts to load the best available Core ML model.
    /// Prioritizes a newer, potentially downloaded model (v2) over the bundled model (v1).
    /// If all ML model loading fails, the service will operate in a fallback mode using heuristics.
    private func loadBestAvailableModel() async {
        print("Attempting to load best available Core ML model...")

        // 4.1. Try to load the V2 model from the user's Documents directory (simulating OTA update)
        // This allows for dynamic updates without an app store release.
        if let v2ModelData = await loadModel(name: v2ModelName, version: .v2, fromBundle: false) {
            self.currentModel = v2ModelData.vnModel
            self.currentModelVersion = v2ModelData.version
            print("Successfully loaded \(v2ModelName) (Version \(v2ModelData.version)) from Documents directory.")
            return
        }

        // 4.2. If V2 fails or isn't present, try to load the V1 model from the app bundle.
        // This ensures the app always has a baseline model.
        if let v1ModelData = await loadModel(name: v1ModelName, version: .v1, fromBundle: true) {
            self.currentModel = v1ModelData.vnModel
            self.currentModelVersion = v1ModelData.version
            print("Successfully loaded \(v1ModelName) (Version \(v1ModelData.version)) from app bundle.")
            return
        }

        // 4.3. If both ML models fail to load, revert to a non-ML fallback mode.
        // This prevents the app from being unusable if ML models are corrupted or missing.
        self.currentModel = nil
        self.currentModelVersion = .fallback
        print("Failed to load any Core ML model. Operating in fallback mode.")
    }

    /// Helper function to load a specific MLModel and wrap it in VNCoreMLModel.
    /// Includes robust error handling and critical model version verification.
    /// - Parameters:
    ///   - name: The name of the Core ML model asset (e.g., "MyModel").
    ///   - version: The `ModelVersion` enum value representing this model.
    ///   - fromBundle: If `true`, loads from the main app bundle. If `false`, attempts to load from the user's Documents directory.
    /// - Returns: A tuple containing the `VNCoreMLModel` and its `ModelVersion` if successful, otherwise `nil`.
    private func loadModel(name: String, version: ModelVersion, fromBundle: Bool) async -> (vnModel: VNCoreMLModel, version: ModelVersion)? {
        let modelURL: URL?
        if fromBundle {
            // Locate the model within the app's main bundle.
            modelURL = Bundle.main.url(forResource: name, withExtension: "mlmodelc")
        } else {
            // Construct a URL for the model in the user's Documents directory.
            // This is where dynamically downloaded models would typically be stored.
            let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            modelURL = documentsDirectory?.appendingPathComponent("\(name).mlmodelc")

            // For demonstration: If we're trying to load a V2 model not from the bundle
            // and it doesn't exist, we treat it as a failure to find the model.
            if version == .v2 && !(modelURL.map { FileManager.default.fileExists(atPath: $0.path) } ?? false) {
                print("V2 model '\(name)' not found in Documents directory. Skipping attempt to load from there.")
                return nil
            }
        }

        guard let url = modelURL else {
            print("Error: Model URL for \(name) could not be constructed or found.")
            return nil
        }

        do {
            let config = MLModelConfiguration()
            // Asynchronously load the MLModel. This can be a heavy operation.
            let mlModel = try await MLModel.load(contentsOf: url, configuration: config)

            // --- 5. Model Versioning Check ---
            // It's crucial to verify the model's metadata to ensure compatibility.
            // An app might expect a model with specific input/output schemas tied to a version.
            let expectedVersionString: String
            switch version {
            case .v1: expectedVersionString = expectedV1ModelVersionString
            case .v2: expectedVersionString = expectedV2ModelVersionString
            case .fallback: expectedVersionString = "" // Not applicable for fallback mode
            }

            if let actualVersionString = mlModel.modelDescription.metadata[MLModelMetadataKey.versionString] as? String {
                if !expectedVersionString.isEmpty && actualVersionString != expectedVersionString {
                    // Log a warning or throw an error if the version doesn't match.
                    // The decision to proceed or fail depends on the app's tolerance for version mismatches.
                    print("Warning: Model '\(name)' loaded with version '\(actualVersionString)' but expected '\(expectedVersionString)'. This might indicate a compatibility issue.")
                    // For a stricter app, you might throw:
                    // throw AppError.unsupportedModelVersion(expected: expectedVersionString, actual: actualVersionString)
                } else {
                    print("Model '\(name)' version '\(actualVersionString)' confirmed.")
                }
            } else {
                print("Warning: Model '\(name)' has no version string metadata. Cannot verify compatibility.")
            }

            // Wrap the MLModel in a VNCoreMLModel for use with the Vision framework.
            let vnCoreMLModel = try VNCoreMLModel(for: mlModel)
            return (vnModel: vnCoreMLModel, version: version)
        } catch let coreMLError as CoreMLError {
            // Handle Core ML specific loading errors (e.g., model file corruption, invalid format).
            print("CoreMLError loading model \(name) from \(url.lastPathComponent): \(coreMLError.localizedDescription)")
            return nil
        } catch let visionError as VisionError {
             // Handle Vision specific errors during VNCoreMLModel initialization.
             print("VisionError initializing VNCoreMLModel for \(name): \(visionError.localizedDescription)")
            return nil
        } catch {
            // Catch any other unexpected errors during model loading.
            print("Generic error loading model \(name) from \(url.lastPathComponent): \(error.localizedDescription)")
            return nil
        }
    }

    // MARK: - 6. Document Classification with Error Handling and Fallback

    /// Classifies a given document image using the currently loaded ML model.
    /// This method is `async` as Core ML prediction can be computationally intensive.
    /// It automatically falls back to a heuristic-based classification if no ML model is available
    /// or if the ML prediction process encounters an error.
    /// - Parameter image: The `CGImage` of the document to classify.
    /// - Returns: The classified `DocumentType`.
    /// - Throws: `AppError` if an unrecoverable error occurs (e.g., invalid input).
    func classifyDocument(image: CGImage) async throws -> DocumentType {
        guard let model = currentModel else {
            // If no ML model is loaded (e.g., due to previous loading failures),
            // perform a non-ML based fallback classification.
            print("No Core ML model loaded. Performing fallback classification.")
            return performFallbackClassification(image: image)
        }

        // Using `withCheckedThrowingContinuation` to bridge the callback-based Vision API
        // into Swift's modern `async/await` paradigm.
        return try await withCheckedThrowingContinuation { continuation in
            // Create a VNCoreMLRequest for the loaded model.
            let request = VNCoreMLRequest(model: model) { [weak self] request, error in
                guard let self = self else {
                    // If the service is deallocated during prediction, resume with an error.
                    continuation.resume(throwing: AppError.predictionFailed(underlyingError: NSError(domain: "DocumentClassifierService", code: 0, userInfo: [NSLocalizedDescriptionKey: "Service deallocated during prediction"])))
                    return
                }

                if let error = error {
                    // Handle errors during the Vision request execution.
                    print("Vision request failed with error: \(error.localizedDescription)")
                    // Instead of throwing, we can choose to gracefully fall back to a generic/unknown type.
                    continuation.resume(returning: .unknown)
                    return
                }

                // Attempt to extract classification observations from the request results.
                guard let observations = request.results as? [VNClassificationObservation],
                      let bestObservation = observations.first else {
                    print("No classification observations found.")
                    continuation.resume(returning: .unknown) // Fallback if no observations
                    return
                }

                let confidenceThreshold: VNConfidence = 0.8 // Example: Require a high confidence
                if bestObservation.confidence > confidenceThreshold,
                   let documentType = DocumentType(rawValue: bestObservation.identifier) {
                    // If confidence is high and identifier maps to a known type, return it.
                    print("Classified as \(documentType.description) with confidence \(bestObservation.confidence)")
                    continuation.resume(returning: documentType)
                } else {
                    // If confidence is too low or identifier is unknown, fall back to generic.
                    print("Classification below threshold or unknown identifier: \(bestObservation.identifier) (\(bestObservation.confidence)). Falling back to generic.")
                    continuation.resume(returning: .generic)
                }
            }

            // Configure the Vision request for optimal image processing (e.g., cropping).
            request.imageCropAndScaleOption = .centerCrop // Or .scaleFit, .scaleFill based on model's training

            // Create a Vision image request handler for the input image.
            let handler = VNImageRequestHandler(cgImage: image, options: [:])
            do {
                // Perform the Vision request on a background thread managed by Vision.
                try handler.perform([request])
            } catch let visionError as VisionError {
                // Handle errors from the Vision image request handler itself.
                print("Vision handler failed to perform request: \(visionError.localizedDescription)")
                continuation.resume(returning: .unknown) // Graceful fallback
            } catch {
                // Catch any other unexpected errors during handler execution.
                print("Generic error performing Vision request: \(error.localizedDescription)")
                continuation.resume(returning: .unknown) // Graceful fallback
            }
        }
    }

    /// Provides a simple, non-ML based classification as a fallback.
    /// This method is invoked when no Core ML model is available or usable.
    /// In a real application, this could involve basic image analysis (e.g., aspect ratio,
    /// presence of text using Vision's text detection) to provide a slightly more intelligent guess.
    /// - Parameter image: The `CGImage` of the document.
    /// - Returns: A `DocumentType` based on fallback heuristics.
    private func performFallbackClassification(image: CGImage) -> DocumentType {
        // Example: A very basic heuristic based on image dimensions.
        // This is a placeholder; a real fallback might use more sophisticated logic.
        if image.width > image.height * 1.5 { // Wide document often implies certain types
            return .generic
        } else if image.height > image.width * 1.5 { // Tall document
            return .generic
        }
        return .generic // Default fallback if no specific heuristic applies
    }

    // MARK: - 7. Utility for Demonstration: Simulating OTA Model Updates

    /// Simulates downloading and saving a new model version (v2) to the app's Documents directory.
    /// In a production app, this would involve network requests to fetch the model.
    /// After successful download, it triggers a reload of the best available model.
    func simulateDownloadV2Model() async throws {
        guard let v2ModelBundleURL = Bundle.main.url(forResource: v2ModelName, withExtension: "mlmodelc") else {
            throw AppError.modelNotFound(name: v2ModelName)
        }

        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let destinationURL = documentsDirectory.appendingPathComponent("\(v2ModelName).mlmodelc")

        do {
            // Remove any existing v2 model to ensure a fresh "download".
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try FileManager.default.removeItem(at: destinationURL)
                print("Removed old \(v2ModelName) from Documents directory.")
            }
            // Copy the model from the app bundle to the Documents directory to simulate a download.
            try FileManager.default.copyItem(at: v2ModelBundleURL, to: destinationURL)
            print("Successfully simulated download and saved \(v2ModelName) to: \(destinationURL.path)")

            // After download, attempt to reload models to pick up the new version.
            await loadBestAvailableModel()
        } catch {
            print("Error simulating V2 model download: \(error.localizedDescription)")
            throw error
        }
    }

    /// Simulates removing a previously downloaded model (v2) from the Documents directory.
    /// After removal, it triggers a reload of the best available model, which should then fall back to v1.
    func simulateRemoveV2Model() async throws {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let destinationURL = documentsDirectory.appendingPathComponent("\(v2ModelName).mlmodelc")

        if FileManager.default.fileExists(atPath: destinationURL.path) {
            do {
                try FileManager.default.removeItem(at: destinationURL)
                print("Successfully removed \(v2ModelName) from Documents directory.")
                // After removal, attempt to reload models to revert to the next available (v1 or fallback).
                await loadBestAvailableModel()
            } catch {
                print("Error removing V2 model: \(error.localizedDescription)")
                throw error
            }
        } else {
            print("V2 model not found in Documents directory to remove.")
        }
    }
}
