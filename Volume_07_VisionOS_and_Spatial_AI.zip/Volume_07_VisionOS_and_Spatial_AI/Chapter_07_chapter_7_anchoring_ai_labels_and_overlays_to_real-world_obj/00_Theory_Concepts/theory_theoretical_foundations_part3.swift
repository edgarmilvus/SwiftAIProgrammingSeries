
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import Observation
import RealityKit
import ARKit

@Observable
@available(visionOS 1.0, *)
class ObservableDetectedObjects {
    var detections: [AIDetection] = []
    var camera: ARCamera? // To help with coordinate transformations

    func update(with newDetections: [AIDetection], for camera: ARCamera) {
        self.detections = newDetections
        self.camera = camera
    }

    // Method to convert 2D bounding box to 3D world position for anchoring
    func worldPosition(for detection: AIDetection) -> SIMD3<Float>? {
        guard let camera = camera else { return nil }

        // The bounding box is normalized (0-1) relative to the image.
        // We want to find the center of the bottom edge of the bounding box.
        let normalizedCenterBottom = CGPoint(
            x: detection.boundingBox.midX,
            y: detection.boundingBox.minY // Vision's origin is bottom-left
        )

        // Convert normalized image coordinates to screen coordinates (if needed, depends on ARView setup)
        // For simplicity, let's assume we want to unproject from the image plane directly.
        // This is a simplified approach. In a real app, you'd use `ARView.unproject` or `ARFrame.hitTest`.
        // For direct image-to-world projection, you often need to define a plane.
        
        // A more robust approach involves raycasting from the center of the bounding box
        // and finding an intersection with the real world or a detected plane.
        // For theoretical explanation, let's describe the concept.
        
        // Simplified theoretical projection: Find a point in 3D space corresponding to the 2D point.
        // This requires a depth estimate or knowing a plane.
        // Let's assume a hypothetical `unprojectToWorld` method that takes 2D image coords and returns 3D.
        
        // In practice, you might use ARView.raycast or ARFrame.hitTest to find a real-world point.
        // For this theoretical section, let's illustrate the *need* for this transformation.
        
        // Example (conceptual, not direct ARFrame API):
        // let worldPoint = camera.unprojectPoint(normalizedCenterBottom, ontoPlane: someDetectedPlane, ...)
        // Or, more commonly, use ARView's hitTest/raycast:
        // let hitTestResults = arView.hitTest(normalizedCenterBottom, types: [.featurePoint, .estimatedPlane])
        // if let result = hitTestResults.first {
        //     return result.worldTransform.columns.3.xyz
        // }
        // For now, return a placeholder. The actual implementation is complex and depends on context.
        return SIMD3<Float>(0,0,0) // Placeholder
    }
}
