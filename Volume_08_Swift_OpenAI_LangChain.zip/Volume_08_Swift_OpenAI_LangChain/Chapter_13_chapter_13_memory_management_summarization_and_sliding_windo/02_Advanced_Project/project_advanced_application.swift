
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Observation

// MARK: - Dependencies

/// In a real-world scenario, this would be defined in your Package.swift
/// dependencies: [
///   .package(url: "https://github.com/openai/openai-swift", from: "1.0.0")
/// ]

// MARK: - Models

/// Represents the role of a participant in the conversation.
enum ChatRole: String, Codable, Sendable {
    case system
    case user
    case assistant
}

/// A single unit of conversation.
struct ChatMessage: Identifiable, Codable, Sendable {
    let id: UUID
    let role: ChatRole
    let content: String
    let timestamp: Date
    
    init(role: ChatRole, content: String) {
        self.id = UUID()
        self.role = role
        self.content = content
        self.timestamp = Date()
    }
}

/// Errors specific to the Memory Management subsystem.
enum MemoryError: Error, LocalizedError {
    case summarizationFailed(String)
    case tokenLimitHardCapReached
    case encodingError
    
    var errorDescription: String? {
        switch self {
        case .summarizationFailed(let msg): return "Failed to compress history: \(msg)"
        case .tokenLimitHardCapReached: return "The conversation is too large even after summarization."
        case .encodingError: return "Failed to calculate token density."
        }
    }
}

// MARK: - Protocols

/// Defines the capability to compress text using an LLM.
protocol SummarizationService: Sendable {
    /// Takes a collection of messages and returns a single distilled string.
    func summarize(messages: [ChatMessage]) async throws -> String
}

// MARK: - Core Logic

/// The `ContextOrchestrator` is the central brain of the memory system.
/// It uses Swift 6 Actor isolation to ensure that as the user types and 
/// the LLM responds, the message history remains thread-safe.
@available(iOS 18.0, macOS 15.0, *)
actor ContextOrchestrator {
    
    // Configuration Constants
    private let maxWindowTokens: Int
    private let summarizationThreshold: Int
    private let systemPrompt: String
    
    // State
    private var slidingWindow: [ChatMessage] = []
    private var runningSummary: String = ""
    private let summarizer: any SummarizationService
    
    /// Initializes the orchestrator.
    /// - Parameters:
    ///   - maxWindowTokens: The maximum number of tokens allowed in the 'active' window.
    ///   - summarizationThreshold: The point at which we trigger a summary of old messages.
    ///   - systemPrompt: The foundational instruction for the AI.
    ///   - summarizer: The service used to perform the compression.
    init(
        maxWindowTokens: Int = 2000,
        summarizationThreshold: Int = 1500,
        systemPrompt: String,
        summarizer: any SummarizationService
    ) {
        self.maxWindowTokens = maxWindowTokens
        self.summarizationThreshold = summarizationThreshold
        self.systemPrompt = systemPrompt
        self.summarizer = summarizer
    }
    
    /// Adds a new message to the history and triggers memory maintenance if necessary.
    /// - Parameter message: The new message from the user or assistant.
    func appendMessage(_ message: ChatMessage) async throws {
        slidingWindow.append(message)
        
        // Check if we need to perform memory maintenance
        let currentTokenCount = estimateTokenCount(for: slidingWindow)
        
        if currentTokenCount > summarizationThreshold {
            try await performMemoryMaintenance()
        }
    }
    
    /// Consolidates old messages into the running summary to free up window space.
    private func performMemoryMaintenance() async throws {
        // 1. Identify messages to be "evicted" from the sliding window.
        // We keep the most recent messages and summarize the older ones.
        // We'll keep the last 5 messages as the 'high-fidelity' window.
        let keepCount = 5
        guard slidingWindow.count > keepCount else { return }
        
        let messagesToSummarize = Array(slidingWindow.prefix(slidingWindow.count - keepCount))
        let remainingWindow = Array(slidingWindow.suffix(keepCount))
        
        // 2. Call the summarizer service.
        // This is an expensive LLM call, but it happens in the background.
        do {
            let newSummaryFragment = try await summarizer.summarize(messages: messagesToSummarize)
            
            // 3. Update the running summary. 
            // We append the new fragment to the existing summary to maintain a continuous narrative.
            if !runningSummary.isEmpty {
                runningSummary += " Previous context: \(newSummaryFragment)"
            } else {
                runningSummary = newSummaryFragment
            }
            
            // 4. Reset the sliding window to only contain the recent messages.
            self.slidingWindow = remainingWindow
            
            print("Memory Maintenance Complete. Summary length: \(runningSummary.count)")
        } catch {
            throw MemoryError.summarizationFailed(error.localizedDescription)
        }
    }
    
    /// Constructs the final payload to be sent to the LLM.
    /// This combines the System Prompt, the Running Summary, and the Sliding Window.
    func constructContextPayload() -> [ChatMessage] {
        var payload: [ChatMessage] = []
        
        // 1. The System Prompt (The "Identity")
        payload.append(ChatMessage(role: .system, content: systemPrompt))
        
        // 2. The Compressed History (The "Long-term Memory")
        if !runningSummary.isEmpty {
            payload.append(ChatMessage(role: .system, content: "Summary of previous conversation: \(runningSummary)"))
        }
        
        // 3. The Sliding Window (The "Short-term Memory")
        payload.append(contentsOf: slidingWindow)
        
        return payload
    }
    
    /// A heuristic-based token estimator.
    /// In production, use a proper BPE (Byte Pair Encoding) tokenizer like tiktoken.
    private func estimateTokenCount(for messages: [ChatMessage]) -> Int {
        let totalChars = messages.reduce(0) { $0 + $1.content.count }
        // Rough heuristic: 1 token ≈ 4 characters for English text
        return totalChars / 4
    }
}

// MARK: - Production Implementation Example

/// A concrete implementation of the summarization service using an LLM.
final class OpenAISummarizer: SummarizationService, @unchecked Sendable {
    /// In a real app, this would use an OpenAI client to call `gpt-4o-mini` 
    /// specifically for the task of summarization.
    func summarize(messages: [ChatMessage]) async throws -> String {
        // Simulate network latency
        try await Task.sleep(for: .seconds(1.5))
        
        let combinedText = messages.map { "\($0.role.rawValue): \($0.content)" }.joined(separator: "\n")
        
        // Mocking the LLM response
        // In reality: let response = try await openAI.chat(prompt: "Summarize this: \(combinedText)")
        return "The user discussed technical architecture and requested a Swift implementation."
    }
}

// MARK: - Application Usage

@available(iOS 18.0, macOS 15.0, *)
@MainActor
struct ResearchAssistantViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var isProcessing: Bool = false
    
    private let orchestrator: ContextOrchestrator
    
    init(orchestrator: ContextOrchestrator) {
        self.orchestrator = orchestrator
    }
    
    func sendMessage(_ text: String) async {
        let userMsg = ChatMessage(role: .user, content: text)
        messages.append(userMsg)
        isProcessing = true
        
        do {
            // 1. Update the Orchestrator's internal memory
            try await orchestrator.appendMessage(userMsg)
            
            // 2. Get the optimized context payload
            let context = await orchestrator.constructContextPayload()
            
            // 3. Simulate sending the context to the LLM
            // let response = try await llmClient.generate(messages: context)
            try await Task.sleep(for: .seconds(1))
            let assistantMsg = ChatMessage(role: .assistant, content: "I have processed your request regarding: \(text)")
            
            // 4. Update local UI and orchestrator
            messages.append(assistantMsg)
            try await orchestrator.appendMessage(assistantMsg)
            
        } catch {
            print("Error: \(error.localizedDescription)")
        }
        
        isProcessing = false
    }
}
