
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CreateML
import Foundation

@available(iOS 18.0, macOS 15.0, *)
func automatedSoundClassifierTuning() async throws { // Made async for potential parallelization
    // 1. Prepare a Sound Dataset
    // IMPORTANT: Replace with the actual URL to your sound dataset directory.
    // Example structure: YourSoundDatasetDir/Robin/sound1.wav, YourSoundDatasetDir/Sparrow/sound2.wav
    let datasetURL = URL(fileURLWithPath: "/path/to/YourBirdSoundDataset")
    
    guard FileManager.default.fileExists(atPath: datasetURL.path) else {
        fatalError("Dataset not found at \(datasetURL.path). Please update the path to your sound dataset.")
    }

    let allData = try MLSoundClassifier.DataSource.labeledDirectories(at: datasetURL)

    // 2. Define Hyperparameter Space
    let maxIterationsOptions = [25, 50, 100]
    let validationDataRatioOptions = [0.1, 0.2, 0.3]

    var bestAccuracy: Double = 0.0
    var bestParameters: (maxIterations: Int, validationDataRatio: Double)? = nil
    var bestModel: MLSoundClassifier? = nil // Optionally store the best model

    print("Starting automated grid search for MLSoundClassifier...")

    // 3. Implement Grid Search
    // Using TaskGroup for parallel execution of hyperparameter combinations
    await withTaskGroup(of: (Double, MLSoundClassifier.ModelParameters, MLSoundClassifier?).self) { group in
        for iterations in maxIterationsOptions {
            for validationRatio in validationDataRatioOptions {
                group.addTask {
                    print("\n--- Testing Iterations: \(iterations), Validation Ratio: \(validationRatio) ---")

                    let parameters = MLSoundClassifier.ModelParameters(
                        maxIterations: iterations,
                        validationDataRatio: validationRatio
                    )

                    do {
                        let model = try MLSoundClassifier(trainingData: allData, parameters: parameters)
                        print("Model trained for iterations \(iterations), ratio \(validationRatio).")

                        if let validationMetrics = model.validationMetrics as? MLSoundClassifierMetrics {
                            let currentAccuracy = validationMetrics.accuracy
                            print("Validation Accuracy for (\(iterations), \(validationRatio)): \(String(format: "%.4f", currentAccuracy))")
                            return (currentAccuracy, parameters, model)
                        } else {
                            print("Validation metrics not available or not sound classifier metrics for (\(iterations), \(validationRatio)).")
                        }
                    } catch {
                        print("Error training model with iterations \(iterations), ratio \(validationRatio): \(error)")
                    }
                    return (0.0, parameters, nil) // Return 0.0 accuracy if error or metrics not available
                }
            }
        }

        // Collect results from all tasks
        for await (accuracy, params, model) in group {
            if accuracy > bestAccuracy {
                bestAccuracy = accuracy
                bestParameters = (maxIterations: params.maxIterations ?? 0, validationDataRatio: params.validationDataRatio ?? 0.0)
                bestModel = model
                print("-> New best model found with accuracy: \(String(format: "%.4f", accuracy))")
            }
        }
    }

    // 4. Report Best Model
    print("\n--- Grid Search Complete ---")
    if let bestParams = bestParameters {
        print("Best Hyperparameters Found:")
        print("  Max Iterations: \(bestParams.maxIterations)")
        print("  Validation Data Ratio: \(bestParams.validationDataRatio)")
        print("Best Validation Accuracy: \(String(format: "%.4f", bestAccuracy))")

        // Optionally, save the best model
        // if let finalBestModel = bestModel {
        //     let metadata = MLModelMetadata(author: "Your Name", shortDescription: "Bird Sound Classifier", version: "1.0")
        //     try finalBestModel.write(to: URL(fileURLWithPath: "/tmp/BestBirdSoundClassifier.mlmodel"), metadata: metadata)
        //     print("Best model saved to /tmp/BestBirdSoundClassifier.mlmodel")
        // }
    } else {
        print("No best model found.")
    }
}

// To run this exercise, uncomment the lines below and update the datasetURL:
// Task {
//    try await automatedSoundClassifierTuning()
// }
