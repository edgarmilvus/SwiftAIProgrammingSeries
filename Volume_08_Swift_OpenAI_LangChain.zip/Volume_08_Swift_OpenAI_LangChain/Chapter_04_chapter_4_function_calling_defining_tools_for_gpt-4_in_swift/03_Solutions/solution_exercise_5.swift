
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation

enum CommandType: String, Codable, Sendable {
    case listProcesses = "list_processes"
    case findFile = "find_file"
    case shellExec = "shell_exec"
}

enum CommandStatus: Codable, Sendable {
    case success(String)
    case requiresApproval(String)
    case error(String)
}

actor SecurityManager {
    // Defines which command types are dangerous
    func evaluate(commandType: CommandType) -> Bool {
        switch commandType {
        case .shellExec: return false // Dangerous
        case .listProcesses, .findFile: return true // Safe
        }
    }
}

actor SystemBridge {
    func execute(commandType: CommandType, argument: String) async throws -> String {
        switch commandType {
        case .listProcesses:
            return "Running: [Process 1, Process 2, Process 3]"
        case .findFile:
            return "Found: /Users/admin/Documents/report.pdf"
        case .shellExec:
            // In a real app, this uses Process()
            return "Executed: \(argument)"
        }
    }
}

struct CommanderTool {
    let security: SecurityManager
    let bridge: SystemBridge
    
    func executeSystemCommand(command_type: CommandType, argument: String) async throws -> CommandStatus {
        // 1. Security Check
        let isSafe = await security.evaluate(commandType: command_type)
        
        if !isSafe {
            // 2. HITL Pattern: Return a 'Proposal' instead of executing
            return .requiresApproval("The command '\(argument)' is classified as DANGEROUS. Do you want to proceed?")
        }
        
        // 3. Safe Execution
        do {
            let result = try await bridge.execute(commandType: command_type, argument: argument)
            return .success(result)
        } catch {
            return .error(error.localizedDescription)
        }
    }
}

// --- Simulation of the Human-in-the-Loop Workflow ---
Task {
    let commander = CommanderTool(security: SecurityManager(), bridge: SystemBridge())
    
    // Scenario: LLM attempts a dangerous command (Prompt Injection simulation)
    let maliciousInput = """
    {
        "command_type": "shell_exec",
        "argument": "rm -rf /"
    }
    """.data(using: .utf8)!
    
    print("--- LLM Request: Malicious Command ---")
    
    do {
        let decoder = JSONDecoder()
        struct RawArgs: Codable {
            let command_type: CommandType
            let argument: String
        }
        let args = try decoder.decode(RawArgs.self, from: maliciousInput)
        
        let status = try await commander.executeSystemCommand(command_type: args.command_type, argument: args.argument)
        
        switch status {
        case .success(let msg):
            print("✅ Success: \(msg)")
        case .requiresApproval(let prompt):
            // This is where the UI intercepts the flow
            print("⚠️ SECURITY ALERT: \(prompt)")
            print("--- [UI: Displaying macOS Confirmation Dialog...] ---")
            
            // Simulate User clicking "Cancel"
            let userApproved = false 
            if !userApproved {
                print("❌ User denied the command. System protected.")
            }
        case .error(let err):
            print("❌ Error: \(err)")
        }
    } catch {
        print("❌ Parsing Error: \(error)")
    }
}
