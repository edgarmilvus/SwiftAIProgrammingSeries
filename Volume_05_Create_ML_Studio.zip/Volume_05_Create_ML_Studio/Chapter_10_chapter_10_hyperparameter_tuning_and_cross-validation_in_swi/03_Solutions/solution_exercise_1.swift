
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import CreateML
import Foundation

@available(iOS 18.0, macOS 15.0, *)
func tuneRecipeClassifier() throws {
    // 1. Prepare a Tabular Dataset
    // Create a sample MLDataTable representing recipe data.
    // In a real app, this would be loaded from a CSV, JSON, or Core Data.
    let dataArray: [[String: MLDataValueConvertible]] = [
        ["prepTime": 15, "cookTime": 20, "difficultyRating": 2, "numberOfIngredients": 5, "category": "Quick Meal"],
        ["prepTime": 60, "cookTime": 120, "difficultyRating": 4, "numberOfIngredients": 12, "category": "Gourmet"],
        ["prepTime": 30, "cookTime": 45, "difficultyRating": 3, "numberOfIngredients": 8, "category": "Quick Meal"],
        ["prepTime": 10, "cookTime": 15, "difficultyRating": 1, "numberOfIngredients": 4, "category": "Quick Meal"],
        ["prepTime": 90, "cookTime": 180, "difficultyRating": 5, "numberOfIngredients": 15, "category": "Gourmet"],
        ["prepTime": 20, "cookTime": 25, "difficultyRating": 2, "numberOfIngredients": 6, "category": "Quick Meal"],
        ["prepTime": 75, "cookTime": 150, "difficultyRating": 4, "numberOfIngredients": 10, "category": "Gourmet"],
        ["prepTime": 40, "cookTime": 50, "difficultyRating": 3, "numberOfIngredients": 7, "category": "Quick Meal"],
        ["prepTime": 5, "cookTime": 10, "difficultyRating": 1, "numberOfIngredients": 3, "category": "Quick Meal"],
        ["prepTime": 100, "cookTime": 200, "difficultyRating": 5, "numberOfIngredients": 18, "category": "Gourmet"]
    ]
    let data = try MLDataTable(array: dataArray)

    // Define the target column for classification
    let targetColumn = "category"

    // Define hyperparameter values to test for maxIterations
    let maxIterationsOptions = [10, 50, 200]
    let validationDataRatio = 0.2 // Fixed validation ratio for consistent comparison

    print("Starting hyperparameter tuning for MLClassifier (maxIterations)...")

    var bestValidationAccuracy: Double = 0.0
    var bestIterations: Int = 0

    for iterations in maxIterationsOptions {
        print("\n--- Testing maxIterations: \(iterations) ---")

        // 2. Instantiate MLClassifier.ModelParameters with current maxIterations
        let parameters = MLClassifier.ModelParameters(
            maxIterations: iterations,
            validationDataRatio: validationDataRatio // Use a fixed validation ratio
        )

        do {
            // 3. Train the model
            let model = try MLClassifier(trainingData: data,
                                         targetColumn: targetColumn,
                                         parameters: parameters)
            print("Model trained with \(iterations) iterations.")

            // 4. Evaluate and Compare
            // Access training and validation metrics directly from the model
            if let trainingMetrics = model.trainingMetrics as? MLClassifierMetrics {
                print("  Training Accuracy: \(String(format: "%.4f", trainingMetrics.accuracy))")
            } else {
                print("  Training metrics not available or not classifier metrics.")
            }

            if let validationMetrics = model.validationMetrics as? MLClassifierMetrics {
                let currentValidationAccuracy = validationMetrics.accuracy
                print("  Validation Accuracy: \(String(format: "%.4f", currentValidationAccuracy))")

                // Keep track of the best model based on validation accuracy
                if currentValidationAccuracy > bestValidationAccuracy {
                    bestValidationAccuracy = currentValidationAccuracy
                    bestIterations = iterations
                }
            } else {
                print("  Validation metrics not available or not classifier metrics.")
            }

        } catch {
            print("Error training model with \(iterations) iterations: \(error)")
        }
    }

    // 5. Report Findings
    print("\n--- Hyperparameter Tuning Complete ---")
    print("Best 'maxIterations' value: \(bestIterations)")
    print("Achieved best Validation Accuracy: \(String(format: "%.4f", bestValidationAccuracy))")
    print("\nReasoning: A higher 'maxIterations' allows the model more opportunities to learn from the data. However, too many iterations can lead to overfitting (high training accuracy, lower validation accuracy), while too few can lead to underfitting (low accuracy overall). The goal is to find the sweet spot where validation accuracy is maximized, indicating good generalization.")
}

// To run this exercise, uncomment the line below:
// try tuneRecipeClassifier()
