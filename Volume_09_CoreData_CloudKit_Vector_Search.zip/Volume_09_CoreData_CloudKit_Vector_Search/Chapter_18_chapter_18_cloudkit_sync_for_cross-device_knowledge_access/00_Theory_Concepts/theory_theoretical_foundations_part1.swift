
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreData
import CloudKit
import Observation

@available(iOS 18.0, *)
/// A thread-safe actor responsible for managing the synchronization state 
/// of the AI's semantic memory.
actor KnowledgeSyncManager {
    
    enum SyncStatus: Sendable {
        case idle
        case syncing(progress: Double)
        case error(Error)
    }
    
    // We use @Observable to allow the UI to react to sync changes.
    // Note: While the actor manages the logic, the state is observed via a separate UI-facing object.
    @Observation
    final class SyncState: Sendable {
        var status: SyncStatus = .idle
    }
    
    private let state: SyncState
    
    init(state: SyncState) {
        self.state = state
    }
    
    /// Initiates a manual synchronization of the knowledge base.
    /// This is an asynchronous operation that does not block the caller.
    func triggerManualSync() async {
        await updateStatus(.syncing(progress: 0.0))
        
        do {
            // In a real implementation, this would interact with 
            // NSPersistentCloudKitContainer's performBackgroundTask.
            try await simulateCloudKitSync()
            await updateStatus(.idle)
        } catch {
            await updateStatus(.error(error))
        }
    }
    
    private func updateStatus(_ newStatus: SyncStatus) async {
        // Updating @Observable properties must happen on the MainActor
        await MainActor.run {
            state.status = newStatus
        }
    }
    
    private func simulateCloudKitSync() async throws {
        // Simulate network latency and heavy vector processing
        for i in 1...10 {
            try await Task.sleep(for: .seconds(0.5))
            let progress = Double(i) / 10.0
            await updateStatus(.syncing(progress: progress))
        }
    }
}
