
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation

// MARK: - Shell Command Execution Core

/// Custom error types for shell command execution, providing detailed context for failures.
enum ShellCommandError: Error, LocalizedError {
    /// Indicates that the command could not be launched by the system.
    case launchFailed(command: String, error: Error)
    /// Indicates that the command was launched but terminated with a non-zero exit status,
    /// implying an error in the command's execution.
    case commandFailed(command: String, status: Int32, stdout: String, stderr: String)
    /// Indicates a failure to decode the command's output (either stdout or stderr) into a String.
    case outputDecodingFailed(command: String)

    /// Provides a user-friendly description for each error type.
    var errorDescription: String? {
        switch self {
        case .launchFailed(let command, let error):
            return "Failed to launch command '\(command)': \(error.localizedDescription)"
        case .commandFailed(let command, let status, let stdout, let stderr):
            // Include stdout and stderr for better debugging of command failures.
            return "Command '\(command)' failed with status \(status).\nStdout: \(stdout)\nStderr: \(stderr)"
        case .outputDecodingFailed(let command):
            return "Failed to decode output for command '\(command)'."
        }
    }
}

/// A utility class designed to execute shell commands and capture their standard output and error.
/// This class encapsulates the `Process` and `Pipe` logic, providing a clean, asynchronous interface
/// suitable for integration into Swift applications, including AI agents.
@available(macOS 14.0, *) // Requires macOS 14.0 or later for modern concurrency features (async/await).
class ShellCommandExecutor {

    /// Executes a shell command and returns its standard output.
    ///
    /// This method leverages `/usr/bin/env` as the executable. This is a common Unix utility
    /// that runs a program in a modified environment. By using `/usr/bin/env` with the actual
    /// command as its first argument, we enable the system to locate the command (e.g., "ollama", "which")
    /// using the standard PATH environment variable, mimicking how commands are typically run in a shell.
    ///
    /// - Parameters:
    ///   - command: The primary shell command to execute (e.g., "ls", "which", "ollama").
    ///   - arguments: An array of string arguments to pass to the command. These are passed safely
    ///                and are not interpreted as shell commands themselves, preventing injection attacks.
    ///   - environment: An optional dictionary of environment variables to set for the process.
    ///                  If `nil`, the child process inherits the current process's environment variables.
    /// - Returns: The standard output of the command as a String, typically trimmed of leading/trailing whitespace.
    /// - Throws: `ShellCommandError` if the command fails to launch, terminates with a non-zero status,
    ///           or if its output cannot be read or decoded.
    func execute(command: String, arguments: [String] = [], environment: [String: String]? = nil) async throws -> String {
        // 1. Initialize Process: The `Process` class is the core component provided by Foundation
        //    for running other executables.
        let process = Process()
        
        // Set the executable URL to `/usr/bin/env`. This allows us to rely on the system's PATH
        // to find the actual `command` (like `ollama` or `which`) without needing its full, absolute path.
        process.executableURL = URL(fileURLWithPath: "/usr/bin/env")
        
        // The first argument to `/usr/bin/env` is the command we want to execute, followed by its own arguments.
        process.arguments = [command] + arguments

        // 2. Setup Pipes for Output: `Pipe` objects are crucial for capturing the output
        //    (both standard output and standard error) of the child process. Without pipes,
        //    the output would typically go to the console where the parent process is running.
        let outputPipe = Pipe()
        let errorPipe = Pipe()
        
        // Redirect the child process's standard output to our `outputPipe`.
        process.standardOutput = outputPipe
        // Redirect the child process's standard error to our `errorPipe`.
        process.standardError = errorPipe

        // 3. Set Environment Variables (Optional): If custom environment variables are provided,
        //    they are set here. Otherwise, the child process inherits the parent's environment.
        if let environment = environment {
            process.environment = environment
        }

        // 4. Launch the Process: The `run()` method attempts to start the external process.
        //    This operation can throw an error if the executable cannot be found, permissions are insufficient,
        //    or other system-level issues prevent launch.
        do {
            try process.run()
        } catch {
            throw ShellCommandError.launchFailed(command: command, error: error)
        }

        // 5. Read Output (Simplified Asynchronous Reading): For this basic example, we first wait
        //    for the process to complete its execution, and then read all available data from its pipes.
        //    For very long-running processes or commands that produce continuous output, a more advanced
        //    approach using `outputPipe.fileHandleForReading.readabilityHandler` would be necessary
        //    to read chunks of data as they become available without blocking.
        process.waitUntilExit() // Blocks the current `Task` (but not the main thread) until the process finishes.

        // Read all data from the standard output pipe.
        let outputData = outputPipe.fileHandleForReading.readDataToEndOfFile()
        // Attempt to decode the raw `Data` into a `String` using UTF-8 encoding.
        guard let output = String(data: outputData, encoding: .utf8) else {
            throw ShellCommandError.outputDecodingFailed(command: command)
        }

        // Read all data from the standard error pipe. This is vital for debugging and comprehensive error reporting.
        let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
        // Attempt to decode error output. If it fails, default to an empty string.
        let errorOutput = String(data: errorData, encoding: .utf8) ?? ""

        // 6. Check Termination Status: After the process exits, its `terminationStatus`
        //    provides an indication of success (0) or failure (non-zero).
        if process.terminationStatus != 0 {
            throw ShellCommandError.commandFailed(
                command: command,
                status: process.terminationStatus,
                stdout: output,
                stderr: errorOutput
            )
        }

        // If successful, return the captured standard output.
        return output
    }
}

// MARK: - Example Usage in an AI Agent Context

/// A conceptual view model for a "Local AI Service Monitor" macOS app.
/// This class demonstrates how an AI agent (or its managing UI) would interact
/// with local services using the `ShellCommandExecutor` to gather information or trigger actions.
@available(macOS 14.0, *)
class AIServiceMonitorViewModel: ObservableObject {
    // @Published properties for UI binding in a SwiftUI application.
    @Published var ollamaStatus: String = "Checking Ollama status..."
    @Published var lastCommandOutput: String = ""
    @Published var errorMessage: String?

    // An instance of our shell command executor.
    private let executor = ShellCommandExecutor()

    /// Checks if Ollama is installed by running `which ollama`.
    /// This is a common first step for an AI agent to verify its execution environment.
    func checkOllamaInstallation() {
        // Use a `Task` to perform asynchronous work off the main thread.
        Task {
            do {
                let output = try await executor.execute(command: "which", arguments: ["ollama"])
                // Update UI-bound properties. This *must* be done on the MainActor.
                await MainActor.run {
                    self.ollamaStatus = "Ollama found at: \(output.trimmingCharacters(in: .whitespacesAndNewlines))"
                    self.lastCommandOutput = output
                    self.errorMessage = nil
                }
            } catch {
                // Handle errors and update UI accordingly.
                await MainActor.run {
                    self.ollamaStatus = "Ollama not found or command failed."
                    self.lastCommandOutput = ""
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }

    /// Executes the `ollama list` command to retrieve a list of locally available models.
    /// An AI agent might use this information to dynamically select which model to load or use
    /// based on user input or task requirements.
    func listOllamaModels() {
        Task {
            do {
                let output = try await executor.execute(command: "ollama", arguments: ["list"])
                await MainActor.run {
                    self.lastCommandOutput = output
                    self.errorMessage = nil
                }
            } catch {
                await MainActor.run {
                    self.lastCommandOutput = ""
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }
}

// MARK: - Standalone Demonstration

/// A simple `@main` structure to demonstrate the `ShellCommandExecutor` and `AIServiceMonitorViewModel`
/// functionality in a runnable command-line context without requiring a full SwiftUI app.
/// This allows for easy testing and understanding of the core logic.
@main
@available(macOS 14.0, *)
struct LocalAIServiceMonitorApp {
    static func main() async {
        let viewModel = AIServiceMonitorViewModel()

        print("--- AI Agent: Checking Ollama Installation ---")
        viewModel.checkOllamaInstallation()
        // Allow a brief moment for the asynchronous task to complete and update the view model.
        try? await Task.sleep(for: .seconds(2))
        print("Ollama Status: \(viewModel.ollamaStatus)")
        if let error = viewModel.errorMessage {
            print("Error: \(error)")
        } else {
            print("Raw Output: \n\(viewModel.lastCommandOutput)")
        }
        print("\n")

        print("--- AI Agent: Listing Ollama Models ---")
        viewModel.listOllamaModels()
        // `ollama list` might take a bit longer, so increase the sleep time.
        try? await Task.sleep(for: .seconds(5))
        if let error = viewModel.errorMessage {
            print("Error: \(error)")
        } else {
            print("Ollama Models:\n\(viewModel.lastCommandOutput)")
        }
        print("\n")

        print("--- AI Agent: Demonstrating error handling for a non-existent command ---")
        Task {
            do {
                let output = try await viewModel.executor.execute(command: "nonexistentcommand123")
                print("Unexpected output for nonexistent command: \(output)")
            } catch {
                print("Successfully caught error for nonexistent command: \(error.localizedDescription)")
            }
        }
        try? await Task.sleep(for: .seconds(1)) // Give time for the task to execute.
        print("\n")

        print("--- AI Agent: Demonstrating error handling for a failing but existing command ---")
        Task {
            do {
                // `ls` usually succeeds, but with a clearly invalid argument, it will fail.
                let output = try await viewModel.executor.execute(command: "ls", arguments: ["--bad-argument"])
                print("Unexpected output for failing command: \(output)")
            } catch {
                print("Successfully caught error for failing command: \(error.localizedDescription)")
            }
        }
        try? await Task.sleep(for: .seconds(1)) // Give time for the task to execute.
        print("\n")
    }
}
