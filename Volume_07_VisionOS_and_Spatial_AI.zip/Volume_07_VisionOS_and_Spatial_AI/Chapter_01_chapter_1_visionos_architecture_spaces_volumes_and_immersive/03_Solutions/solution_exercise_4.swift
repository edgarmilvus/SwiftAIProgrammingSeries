
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import RealityKit

enum ImmersionLevel {
    case none, shared, full
}

@Observable
@MainActor
class EnvironmentManager {
    var level: ImmersionLevel = .none
    var isTransitioning: Bool = false
    
    func transition(to newLevel: ImmersionLevel, 
                    openAction: @escaping () async -> Void, 
                    dismissAction: @escaping () async -> Void) async {
        isTransitioning = true
        
        // 1. Sequence: Dismiss current before opening new
        if level != .none {
            await dismissAction()
        }
        
        // 2. Wait for the system to settle
        try? await Task.sleep(for: .seconds(1.5))
        
        // 3. Open the new space
        await openAction()
        
        level = newLevel
        isTransitioning = false
    }
}

struct AdaptiveControlView: View {
    @State private var envManager = EnvironmentManager()
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace

    var body: some View {
        VStack(spacing: 20) {
            Text("Architecture Viz Engine")
            
            HStack {
                Button("Shared Mode") {
                    Task {
                        await envManager.transition(to: .shared, 
                                                 openAction: { _ = await openImmersiveSpace(id: "shared-space") }, 
                                                 dismissAction: { await dismissImmersiveSpace() })
                    }
                }
                
                Button("Full Mode") {
                    Task {
                        await envManager.transition(to: .full, 
                                                 openAction: { _ = await openImmersiveSpace(id: "full-space") }, 
                                                 dismissAction: { await dismissImmersiveSpace() })
                    }
                }
            }
        }
        .frame(width: 400, height: 200)
        // 4. The Smooth Transition Overlay
        .overlay {
            if envManager.isTransitioning {
                Color.black
                    .ignoresSafeArea()
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut, value: envManager.isTransitioning)
    }
}

@main
struct AdaptiveApp: App {
    var body: some Scene {
        WindowGroup { AdaptiveControlView() }

        ImmersiveSpace(id: "shared-space") {
            SharedBuildingView()
        }

        ImmersiveSpace(id: "full-space") {
            FullBuildingView()
        }
    }
}

struct SharedBuildingView: View { 
    var body: some View { 
        RealityView { content in 
            // In a real app, load a model anchored to a plane
            print("Shared space loaded: Building anchored to room.")
        } 
    } 
}

struct FullBuildingView: View { 
    var body: some View { 
        RealityView { content in 
            // In a real app, load a skybox and massive environment
            print("Full space loaded: Skybox active.")
        } 
    } 
}
