
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import AVFoundation

// MARK: - PronunciationGuide

class PronunciationGuide: NSObject {
    private let synthesizer = AVSpeechSynthesizer()

    override init() {
        super.init()
        synthesizer.delegate = self // Set delegate for potential future use or logging
    }

    /// Intelligently selects the best available voice for a given language code and speaks the text.
    ///
    /// - Parameters:
    ///   - text: The text to be pronounced.
    ///   - languageCode: A BCP-47 language code (e.g., "en-US", "fr-FR", "ja-JP").
    /// - Returns: A tuple containing the name and language of the voice actually used, or nil if speech failed.
    func pronounce(_ text: String, in languageCode: String) -> (voiceName: String, voiceLanguage: String)? {
        let utterance = AVSpeechUtterance(string: text)
        var selectedVoice: AVSpeechSynthesisVoice?
        var voiceSelectionLog: String = ""

        // 1. Intelligent Voice Selection
        if let bestVoice = findBestVoice(for: languageCode) {
            selectedVoice = bestVoice
            voiceSelectionLog = "Selected voice: \(bestVoice.name) (\(bestVoice.language), Quality: \(bestVoice.quality.description))"
        } else {
            // 2. System Default Fallback
            selectedVoice = AVSpeechSynthesisVoice(language: nil) // System default
            voiceSelectionLog = "WARNING: No specific voice found for '\(languageCode)'. Falling back to system default voice."
        }

        utterance.voice = selectedVoice
        print(voiceSelectionLog)

        guard let finalVoice = utterance.voice else {
            print("ERROR: No voice could be selected, even system default. Speech cannot proceed.")
            return nil
        }

        // 3. Pronunciation
        synthesizer.speak(utterance)

        // 4. Reporting
        return (voiceName: finalVoice.name, voiceLanguage: finalVoice.language)
    }

    /// Finds the best available AVSpeechSynthesisVoice for a given BCP-47 language code.
    ///
    /// - Parameter languageCode: The desired BCP-47 language code (e.g., "en-US").
    /// - Returns: The best matching `AVSpeechSynthesisVoice`, or `nil` if no suitable voice is found.
    private func findBestVoice(for languageCode: String) -> AVSpeechSynthesisVoice? {
        let allVoices = AVSpeechSynthesisVoice.speechVoices()
        let requestedPrimaryLanguage = String(languageCode.prefix(2)) // e.g., "en" from "en-US"

        var candidates: [AVSpeechSynthesisVoice] = []

        // Step 1: Exact locale match (e.g., "en-US" for "en-US")
        let exactMatches = allVoices.filter { $0.language.lowercased() == languageCode.lowercased() }
        candidates.append(contentsOf: exactMatches)

        // Step 2: Primary language fallback (e.g., "en-US" for "en-AU" if no "en-AU" exists)
        if candidates.isEmpty {
            let primaryLanguageMatches = allVoices.filter { $0.language.lowercased().hasPrefix(requestedPrimaryLanguage.lowercased()) }
            candidates.append(contentsOf: primaryLanguageMatches)
            print("No exact locale match for '\(languageCode)'. Considering primary language voices.")
        }

        // If candidates exist, sort by quality (Enhanced > Compact)
        if !candidates.isEmpty {
            let sortedCandidates = candidates.sorted { (voice1, voice2) -> Bool in
                // Prioritize Enhanced quality
                if voice1.quality == .enhanced && voice2.quality != .enhanced { return true }
                if voice1.quality != .enhanced && voice2.quality == .enhanced { return false }
                // For same quality, prefer premium/compact if any other implicit preference
                // (AVSpeechSynthesisVoice doesn't expose explicit "premium" flag directly,
                // but quality is the main differentiator).
                return voice1.name < voice2.name // Stable sort for same quality
            }
            return sortedCandidates.first
        }

        return nil // No suitable voice found
    }
}

// MARK: - AVSpeechSynthesizerDelegate (for Exercise 3, primarily for general logging)

extension PronunciationGuide: AVSpeechSynthesizerDelegate {
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        print("Pronunciation finished.")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        print("Pronunciation cancelled.")
    }
}

// MARK: - Helper Extension for AVSpeechSynthesisVoice Quality Description

extension AVSpeechSynthesisVoiceQuality: CustomStringConvertible {
    public var description: String {
        switch self {
        case .default: return "Default"
        case .compact: return "Compact"
        case .enhanced: return "Enhanced"
        @unknown default: return "Unknown"
        }
    }
}

// MARK: - Example Usage

func demonstrateExercise3() {
    print("--- Exercise 3 Demonstration ---")
    let pronunciationGuide = PronunciationGuide()

    // 1. Exact match (e.g., "en-US")
    print("\nAttempting to pronounce 'Hello' in 'en-US':")
    if let result = pronunciationGuide.pronounce("Hello, how are you?", in: "en-US") {
        print("Pronounced by: \(result.voiceName) (\(result.voiceLanguage))")
    }

    // 2. Primary language fallback (e.g., "en-AU" might fall back to "en-US")
    print("\nAttempting to pronounce 'G'day mate' in 'en-AU':")
    if let result = pronunciationGuide.pronounce("G'day mate, fancy a cuppa?", in: "en-AU") {
        print("Pronounced by: \(result.voiceName) (\(result.voiceLanguage))")
    }

    // 3. Different language (e.g., "fr-FR")
    print("\nAttempting to pronounce 'Bonjour' in 'fr-FR':")
    if let result = pronunciationGuide.pronounce("Bonjour, comment ça va?", in: "fr-FR") {
        print("Pronounced by: \(result.voiceName) (\(result.voiceLanguage))")
    }

    // 4. Language with no exact match, but primary exists (e.g., "es-MX" might fall back to "es-ES")
    print("\nAttempting to pronounce 'Hola' in 'es-MX':")
    if let result = pronunciationGuide.pronounce("Hola, ¿qué tal?", in: "es-MX") {
        print("Pronounced by: \(result.voiceName) (\(result.voiceLanguage))")
    }

    // 5. Completely unknown language (should trigger system default fallback)
    print("\nAttempting to pronounce 'Unknown' in 'xx-XX':")
    if let result = pronunciationGuide.pronounce("This should use the system default voice.", in: "xx-XX") {
        print("Pronounced by: \(result.voiceName) (\(result.voiceLanguage))")
    } else {
        print("Failed to pronounce (no voice selected).")
    }

    // Give some time for the synthesizer to process utterances
    Thread.sleep(forTimeInterval: 10.0)
    print("--- Exercise 3 Demonstration Complete ---")
}

// Call the demonstration function to run the example
// demonstrateExercise3()
