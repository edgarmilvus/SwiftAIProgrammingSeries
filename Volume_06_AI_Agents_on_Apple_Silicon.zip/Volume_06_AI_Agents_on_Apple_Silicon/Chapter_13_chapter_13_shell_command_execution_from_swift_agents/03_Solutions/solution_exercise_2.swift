
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import Foundation

enum DiskUsageError: Error, LocalizedError {
    case commandNotFound(path: String)
    case executionFailed(status: Int, stderr: String)
    case outputParsingFailed(output: String)
    case directoryNotFound(path: String)
    case permissionDenied(path: String)
    case unknown(Error)

    var errorDescription: String? {
        switch self {
        case .commandNotFound(let path):
            return "Disk usage command ('du') not found at '\(path)'. Is it installed and in your PATH?"
        case .executionFailed(let status, let stderr):
            if stderr.contains("No such file or directory") {
                return "Directory not found or accessible. Error: \(stderr)"
            }
            if stderr.contains("Permission denied") {
                return "Permission denied for directory. Error: \(stderr)"
            }
            return "Disk usage command failed with exit status \(status).\nError: \(stderr)"
        case .outputParsingFailed(let output):
            return "Failed to parse disk usage output: '\(output)'"
        case .directoryNotFound(let path):
            return "The specified directory does not exist: '\(path)'"
        case .permissionDenied(let path):
            return "Permission denied to access directory: '\(path)'"
        case .unknown(let error):
            return "An unknown error occurred: \(error.localizedDescription)"
        }
    }
}

/// Reports the human-readable size of a directory.
/// - Parameters:
///   - directoryURL: The URL of the directory to measure.
///   - duExecutablePath: Optional URL to the 'du' executable. Defaults to /usr/bin/du.
/// - Returns: A human-readable size string (e.g., "1.2G", "450M").
/// - Throws: A DiskUsageError if the command fails or output cannot be parsed.
func getDirectorySize(for directoryURL: URL, duExecutablePath: URL? = nil) async throws -> String {
    let process = Process()
    let stdoutPipe = Pipe()
    let stderrPipe = Pipe()

    process.standardOutput = stdoutPipe
    process.standardError = stderrPipe

    // Determine 'du' executable path
    let defaultDuPath = "/usr/bin/du" // Standard location on macOS
    let executableURL: URL
    if let customPath = duExecutablePath {
        executableURL = customPath
    } else {
        executableURL = URL(fileURLWithPath: defaultDuPath)
    }
    process.executableURL = executableURL

    // Crucially, pass the directory path as a separate argument.
    // Process.arguments array handles proper quoting/escaping for shell safety.
    process.arguments = ["-sh", directoryURL.path]

    do {
        try process.run()
    } catch {
        if let posixError = error as? POSIXError, posixError.code == .ENOENT {
            throw DiskUsageError.commandNotFound(path: executableURL.path)
        }
        throw DiskUsageError.unknown(error)
    }

    process.waitUntilExit()

    let stdoutData = stdoutPipe.fileHandleForReading.readDataToEndOfFile()
    let stderrData = stderrPipe.fileHandleForReading.readDataToEndOfFile()

    let stdout = String(data: stdoutData, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    let stderr = String(data: stderrData, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

    guard process.terminationStatus == 0 else {
        // Check for specific error messages in stderr
        if stderr.contains("No such file or directory") {
            throw DiskUsageError.directoryNotFound(path: directoryURL.path)
        }
        if stderr.contains("Permission denied") {
            throw DiskUsageError.permissionDenied(path: directoryURL.path)
        }
        throw DiskUsageError.executionFailed(status: Int(process.terminationStatus), stderr: stderr)
    }

    // Expected output format: "1.2G\t/path/to/directory"
    // We want to extract "1.2G"
    let components = stdout.split(separator: "\t")
    guard let sizeString = components.first, !sizeString.isEmpty else {
        throw DiskUsageError.outputParsingFailed(output: stdout)
    }

    return String(sizeString)
}

// Example Usage:
/*
Task {
    // Create a dummy directory for testing
    let tempDir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    try? FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true, attributes: nil)
    try? "Hello World".write(to: tempDir.appendingPathComponent("file1.txt"), atomically: true, encoding: .utf8)
    try? "Swift is great!".write(to: tempDir.appendingPathComponent("file2.txt"), atomically: true, encoding: .utf8)

    print("Measuring size of: \(tempDir.path)")
    do {
        let size = try await getDirectorySize(for: tempDir)
        print("Directory size: \(size)") // Expected: something like "16K"

        // Test with a non-existent directory
        let nonExistentURL = URL(fileURLWithPath: "/path/to/nonexistent/dir_\(UUID().uuidString)")
        print("\nMeasuring size of non-existent: \(nonExistentURL.path)")
        _ = try await getDirectorySize(for: nonExistentURL)

    } catch {
        if let duError = error as? DiskUsageError {
            print("Disk Usage Error: \(duError.localizedDescription)")
        } else {
            print("An unexpected error occurred: \(error.localizedDescription)")
        }
    } finally {
        // Clean up dummy directory
        try? FileManager.default.removeItem(at: tempDir)
    }
}
*/
