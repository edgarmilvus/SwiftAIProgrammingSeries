
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 18.0, *)
    func processUserRequest(_ prompt: String, llm: LLMInferenceActor, toolRegistry: ToolRegistryActor) async throws -> String {
        var currentPrompt = prompt
        var conversationHistory: [Message] = [] // Assuming Message is a Codable struct for conversation turns

        // Inject tool definitions into the initial prompt
        let toolDefinitions = await toolRegistry.getToolDefinitions() // e.g., JSON schema
        conversationHistory.append(.system(content: "Available tools: \(toolDefinitions)"))
        conversationHistory.append(.user(content: currentPrompt))

        while true {
            let llmOutput = try await llm.generate(messages: conversationHistory) // LLM inference
            
            // Assume llmOutput is a structured representation of the LLM's response
            // It could be a simple string or a parsed tool call object
            if let toolCall = parseToolCall(llmOutput) { // Custom parsing logic
                print("LLM requested tool: \(toolCall.name) with args: \(toolCall.arguments)")
                
                do {
                    let toolResult = try await toolRegistry.executeTool(toolCall.name, arguments: toolCall.arguments)
                    print("Tool '\(toolCall.name)' executed, result: \(toolResult)")
                    
                    // Inject tool result back into conversation history
                    conversationHistory.append(.toolResult(toolName: toolCall.name, result: toolResult))
                    // Continue the loop for another LLM inference
                } catch {
                    print("Error executing tool \(toolCall.name): \(error)")
                    conversationHistory.append(.toolError(toolName: toolCall.name, error: error.localizedDescription))
                    // Decide whether to retry, inform user, or let LLM handle error
                }
            } else {
                // LLM generated a final response (not a tool call)
                conversationHistory.append(.assistant(content: llmOutput.text))
                return llmOutput.text
            }
        }
    }
    