
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import NaturalLanguage
import Foundation

// Assume 'MyDocumentClassifier.mlmodel' is bundled with your app
// This is a hypothetical model for demonstration purposes.
@available(iOS 18.0, *)
class DocumentClassifier {
    private var model: NLModel?

    init() {
        // Attempt to load the model from the app bundle
        guard let modelURL = Bundle.main.url(forResource: "MyDocumentClassifier", withExtension: "mlmodel") else {
            print("Error: MyDocumentClassifier.mlmodel not found in app bundle.")
            return
        }
        do {
            self.model = try NLModel(contentsOf: modelURL)
            print("NLModel loaded successfully.")
        } catch {
            print("Error loading NLModel: \(error.localizedDescription)")
        }
    }

    /// Predicts a single label for a given text.
    /// Returns the predicted label string, or nil if the model isn't loaded or prediction fails.
    func classify(text: String) -> String? {
        guard let model = model else {
            print("Model not loaded. Cannot classify.")
            return nil
        }
        return model.predictedLabel(for: text)
    }

    /// Predicts the top 'maximumCount' labels and their confidence scores for a given text.
    /// Returns an array of (label: String, confidence: Double) tuples.
    func classifyWithConfidences(text: String, maximumCount: Int = 3) -> [(label: String, confidence: Double)] {
        guard let model = model else {
            print("Model not loaded. Cannot classify.")
            return []
        }
        // predictedLabels returns an array of (label: String, score: Double)
        let predictions = model.predictedLabels(for: text, maximumCount: maximumCount)
        return predictions.map { (label: $0.0, confidence: $0.1) }
    }
}

// Example Usage (requires a trained model to be present)
@available(iOS 18.0, *)
func demonstrateClassification() async {
    let classifier = DocumentClassifier()

    let text1 = "This movie was absolutely fantastic! I loved every minute of it."
    if let label = classifier.classify(text: text1) {
        print("Text: '\(text1)' -> Predicted Label: \(label)") // e.g., "Positive"
    }

    let text2 = "The service was slow and the food was just okay, nothing special."
    let topLabels = classifier.classifyWithConfidences(text: text2, maximumCount: 2)
    print("Text: '\(text2)' -> Top Labels:")
    for (label, confidence) in topLabels {
        print("  - \(label) (Confidence: \(String(format: "%.2f", confidence * 100))%)") // e.g., "Negative" (92%), "Neutral" (7%)
    }
}

// To run this in a playground or app:
// if #available(iOS 18.0, *) {
//     Task {
//         await demonstrateClassification()
//     }
// }
