
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import RealityKit
import ARKit
import Foundation

class MultiHandInteractionController {
    private var previousHandDistance: Float?
    private var previousHandAngle: Float?
    
    func update(
        leftHand: HandAnchor?, 
        rightHand: HandAnchor?, 
        targetEntity: Entity
    ) {
        guard let left = leftHand, let right = rightHand else {
            previousHandDistance = nil
            previousHandAngle = nil
            return
        }
        
        let leftPos = left.transform.translation
        let rightPos = right.transform.translation
        
        // 1. Scaling Logic (Distance Delta)
        let currentDistance = simd_distance(leftPos, rightPos)
        if let prevDist = previousHandDistance {
            let scaleFactor = currentDistance / prevDist
            let currentScale = targetEntity.scale
            targetEntity.scale = currentScale * scaleFactor
        }
        previousHandDistance = currentDistance
        
        // 2. Rotation Logic (Angular Delta on Y-Axis)
        // Calculate the angle of the vector connecting the two hands
        let directionVector = rightPos - leftPos
        let currentAngle = atan2(directionVector.z, directionVector.x)
        
        if let prevAngle = previousHandAngle {
            var angleDelta = currentAngle - prevAngle
            
            // Handle the -PI to PI wrap-around jump
            if angleDelta > .pi { angleDelta -= 2 * .pi }
            if angleDelta < -.pi { angleDelta += 2 * .pi }
            
            let currentRotation = targetEntity.orientation
            let rotationDelta = simd_quaternion(angleDelta, SIMD3<Float>(0, 1, 0))
            targetEntity.orientation = rotationDelta * currentRotation
        }
        previousHandAngle = currentAngle
    }
}
