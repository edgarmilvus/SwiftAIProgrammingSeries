
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Example of lazy evaluation and valueAndGradient
import MLX
import MLXNN

// Assume a simple linear layer for demonstration
class LinearLayer: MLXNN.Module {
    let weight: MLXArray
    let bias: MLXArray

    init(inputSize: Int, outputSize: Int) {
        self.weight = MLXArray.randomUniform(low: -0.01, high: 0.01, [outputSize, inputSize])
        self.bias = MLXArray.zeros([outputSize])
        super.init()
    }

    override func callAsFunction(_ x: MLXArray) -> MLXArray {
        return matmul(weight, x) + bias
    }
}

// Define a simple loss function
func meanSquaredError(predictions: MLXArray, targets: MLXArray) -> MLXArray {
    return mean(square(predictions - targets))
}

// Instantiate the model and define inputs
let inputSize = 10
let outputSize = 1
let layer = LinearLayer(inputSize: inputSize, outputSize: outputSize)
let x = MLXArray.randomUniform(low: 0, high: 1, [inputSize, 1]) // Input
let y_target = MLXArray.randomUniform(low: 0, high: 1, [outputSize, 1]) // Target

// 1. Define the computation for the loss
// This builds the graph, but doesn't execute yet
let lossFn = { (x: MLXArray, y_target: MLXArray) -> MLXArray in
    let predictions = layer(x)
    return meanSquaredError(predictions: predictions, targets: y_target)
}

// 2. Use valueAndGradient to get both the loss value and its gradients
// This creates *another* graph for the gradients, still without execution
let (loss, grads) = valueAndGradient(lossFn)(x, y_target)

// 3. Only now, when we access `loss.item()` or `grads.eval()`,
// does the entire optimized graph (forward + backward) execute.
print("Initial Loss: \(loss.item())") // Forces execution of the forward pass

// To inspect gradients, we'd typically iterate and evaluate them
// grads is a Dictionary<Parameter, MLXArray>
// grads.eval() // Would force evaluation of all gradient arrays

// Update parameters (e.g., with SGD) - this would involve new MLXArray operations
// layer.weight.update(layer.weight - learningRate * grads[layer.weight]!)
