
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import UIKit
import CoreImage
import CoreGraphics // For CGImage and related types

// MARK: - 1. Defining Augmentation Strategies

/// Represents various data augmentation techniques that can be applied to an image.
/// These strategies are designed to simulate different real-world conditions
/// and improve the robustness of a machine learning model.
enum AugmentationStrategy: CaseIterable, Identifiable {
    case original // To include the original image in the dataset
    case horizontalFlip
    case verticalFlip
    case rotate(angle: Float) // Angle in degrees
    case crop(percentage: CGFloat) // Percentage of image to crop from edges
    case brightness(factor: Float) // Brightness adjustment
    case contrast(factor: Float) // Contrast adjustment
    case saturation(factor: Float) // Saturation adjustment
    case gaussianBlur(radius: Float) // Blur effect

    var id: String {
        switch self {
        case .original: return "original"
        case .horizontalFlip: return "horizontalFlip"
        case .verticalFlip: return "verticalFlip"
        case .rotate(let angle): return "rotate_\(Int(angle))"
        case .crop(let percentage): return "crop_\(Int(percentage * 100))"
        case .brightness(let factor): return "brightness_\(Int(factor * 100))"
        case .contrast(let factor): return "contrast_\(Int(factor * 100))"
        case .saturation(let factor): return "saturation_\(Int(factor * 100))"
        case .gaussianBlur(let radius): return "blur_\(Int(radius))"
        }
    }

    /// Provides a human-readable description of the augmentation.
    var description: String {
        switch self {
        case .original: return "Original Image"
        case .horizontalFlip: return "Horizontal Flip"
        case .verticalFlip: return "Vertical Flip"
        case .rotate(let angle): return "Rotate \(Int(angle))°"
        case .crop(let percentage): return "Crop \(Int(percentage * 100))%"
        case .brightness(let factor): return "Brightness (\(factor))"
        case .contrast(let factor): return "Contrast (\(factor))"
        case .saturation(let factor): return "Saturation (\(factor))"
        case .gaussianBlur(let radius): return "Gaussian Blur (Radius: \(radius))"
        }
    }
}

// MARK: - 2. Error Handling for Augmentation Process

/// Custom errors that can occur during the image augmentation process.
enum ImageAugmentationError: Error, LocalizedError {
    case invalidImageInput
    case failedToApplyFilter(strategy: AugmentationStrategy, underlyingError: Error?)
    case failedToGenerateCGImage(strategy: AugmentationStrategy)
    case failedToSaveImage(url: URL, underlyingError: Error?)
    case directoryCreationFailed(url: URL, underlyingError: Error?)
    case invalidOutputURL

    var errorDescription: String? {
        switch self {
        case .invalidImageInput:
            return "The input image provided for augmentation is invalid or nil."
        case .failedToApplyFilter(let strategy, let error):
            return "Failed to apply \(strategy.description) filter. Details: \(error?.localizedDescription ?? "Unknown error")."
        case .failedToGenerateCGImage(let strategy):
            return "Failed to generate CGImage from CIImage after applying \(strategy.description)."
        case .failedToSaveImage(let url, let error):
            return "Failed to save augmented image to \(url.lastPathComponent). Details: \(error?.localizedDescription ?? "Unknown error")."
        case .directoryCreationFailed(let url, let error):
            return "Failed to create output directory at \(url.lastPathComponent). Details: \(error?.localizedDescription ?? "Unknown error")."
        case .invalidOutputURL:
            return "The provided output directory URL is invalid or inaccessible."
        }
    }
}

// MARK: - 3. The Core Augmentor Class

/// `PlantImageAugmentor` is responsible for generating a diverse set of augmented images
/// from a single source image, suitable for improving the robustness of Create ML models.
/// This is particularly useful for rare plant species or challenging photographic conditions,
/// where expanding the dataset artificially can significantly boost model performance.
@available(iOS 17.0, *) // Targeting iOS 17 for modern Create ML and concurrency features
class PlantImageAugmentor {

    private let ciContext: CIContext

    /// Initializes the augmentor with a Core Image context.
    /// Using a single `CIContext` for multiple operations is more efficient
    /// as it can cache resources and manage GPU contexts.
    init() {
        // Use a GPU-backed context for performance if available, fallback to CPU.
        // `[.useSoftwareRenderer: false]` hints at GPU preference.
        self.ciContext = CIContext(options: [.useSoftwareRenderer: false])
    }

    /// Applies a single augmentation strategy to a given `CIImage`.
    /// Core Image filters are highly optimized for image processing on Apple hardware,
    /// leveraging GPU capabilities when available.
    /// - Parameters:
    ///   - ciImage: The input `CIImage` to be augmented.
    ///   - strategy: The `AugmentationStrategy` to apply.
    /// - Returns: A new `CIImage` with the augmentation applied.
    /// - Throws: `ImageAugmentationError` if the filter application fails or results in no image.
    private func applyAugmentation(to ciImage: CIImage, strategy: AugmentationStrategy) throws -> CIImage {
        var outputImage: CIImage?

        // Apply filters based on the chosen strategy using Core Image.
        switch strategy {
        case .original:
            outputImage = ciImage
        case .horizontalFlip:
            // `CIAffineTransform` is versatile for geometric transformations.
            // A horizontal flip is achieved by scaling the x-axis by -1 and translating.
            let transform = CGAffineTransform(scaleX: -1, y: 1)
                .translatedBy(x: -ciImage.extent.width, y: 0)
            outputImage = ciImage.transformed(by: transform)
        case .verticalFlip:
            // Similarly, a vertical flip scales the y-axis by -1 and translates.
            let transform = CGAffineTransform(scaleX: 1, y: -1)
                .translatedBy(x: 0, y: -ciImage.extent.height)
            outputImage = ciImage.transformed(by: transform)
        case .rotate(let angle):
            // Rotation is applied around the center of the image to prevent shifting.
            let radians = angle * .pi / 180.0
            let transform = CGAffineTransform(translationX: ciImage.extent.width / 2, y: ciImage.extent.height / 2)
                .rotated(by: radians)
                .translatedBy(x: -ciImage.extent.width / 2, y: -ciImage.extent.height / 2)
            outputImage = ciImage.transformed(by: transform)
        case .crop(let percentage):
            // Crops an equal percentage from all four sides of the image.
            let cropRect = ciImage.extent.insetBy(
                dx: ciImage.extent.width * percentage / 2,
                dy: ciImage.extent.height * percentage / 2
            )
            outputImage = ciImage.cropped(to: cropRect)
        case .brightness(let factor):
            // `CIColorControls` is used for adjusting color properties.
            guard let filter = CIFilter(name: "CIColorControls") else { break }
            filter.setValue(ciImage, forKey: kCIInputImageKey)
            filter.setValue(factor, forKey: kCIInputBrightnessKey)
            outputImage = filter.outputImage
        case .contrast(let factor):
            guard let filter = CIFilter(name: "CIColorControls") else { break }
            filter.setValue(ciImage, forKey: kCIInputImageKey)
            filter.setValue(factor, forKey: kCIInputContrastKey)
            outputImage = filter.outputImage
        case .saturation(let factor):
            guard let filter = CIFilter(name: "CIColorControls") else { break }
            filter.setValue(ciImage, forKey: kCIInputImageKey)
            filter.setValue(factor, forKey: kCIInputSaturationKey)
            outputImage = filter.outputImage
        case .gaussianBlur(let radius):
            // `CIGaussianBlur` applies a blur effect.
            guard let filter = CIFilter(name: "CIGaussianBlur") else { break }
            filter.setValue(ciImage, forKey: kCIInputImageKey)
            filter.setValue(radius, forKey: kCIInputRadiusKey)
            outputImage = filter.outputImage
        }

        guard let finalImage = outputImage else {
            throw ImageAugmentationError.failedToApplyFilter(strategy: strategy, underlyingError: nil)
        }
        return finalImage
    }

    /// Saves a `CIImage` to a specified URL as a PNG file.
    /// This process involves rendering the `CIImage` into a `CGImage`,
    /// converting it to `UIImage`, and then saving its PNG representation.
    /// This step is computationally intensive and benefits from being offloaded
    /// from the main thread, which Swift concurrency handles implicitly.
    /// - Parameters:
    ///   - ciImage: The `CIImage` to save.
    ///   - outputURL: The file URL where the image should be saved.
    /// - Throws: `ImageAugmentationError` if the image cannot be rendered or saved.
    private func saveCIImage(_ ciImage: CIImage, to outputURL: URL) async throws {
        // Render CIImage to CGImage using the shared CIContext.
        guard let cgImage = ciContext.createCGImage(ciImage, from: ciImage.extent) else {
            throw ImageAugmentationError.failedToGenerateCGImage(strategy: .original) // Strategy might be generic here
        }

        // Convert CGImage to UIImage and then to PNG data.
        let uiImage = UIImage(cgImage: cgImage)
        guard let data = uiImage.pngData() else {
            throw ImageAugmentationError.failedToSaveImage(url: outputURL, underlyingError: nil)
        }

        // Write data to file using an atomic write for data integrity.
        do {
            try data.write(to: outputURL, options: .atomicWrite)
        } catch {
            throw ImageAugmentationError.failedToSaveImage(url: outputURL, underlyingError: error)
        }
    }

    /// Generates a collection of augmented images from a single input image.
    /// Each augmented image is saved to a structured directory, making it
    /// ready for consumption by Create ML's `MLImageClassifier.DataSource.labeledDirectories`.
    /// This method leverages Swift's `TaskGroup` for concurrent processing,
    /// allowing multiple augmentations to be applied and saved in parallel.
    ///
    /// - Parameters:
    ///   - inputImage: The original `UIImage` to augment.
    ///   - label: The classification label for the input image (e.g., "Monstera Deliciosa").
    ///   - strategies: An array of `AugmentationStrategy` to apply.
    ///   - outputDirectoryURL: The base URL for the output directory. Augmented images
    ///                         will be saved under `outputDirectoryURL/label/`.
    /// - Returns: An array of URLs pointing to the saved augmented images.
    /// - Throws: `ImageAugmentationError` if any part of the process fails.
    func generateAugmentedImages(
        from inputImage: UIImage,
        withLabel label: String,
        strategies: [AugmentationStrategy],
        to outputDirectoryURL: URL
    ) async throws -> [URL] {
        // 1. Validate input image: Convert UIImage to CIImage for Core Image processing.
        guard let ciImage = CIImage(image: inputImage) else {
            throw ImageAugmentationError.invalidImageInput
        }

        // 2. Prepare output directory: Create the `outputDirectoryURL/label/` structure.
        let labeledOutputURL = outputDirectoryURL.appendingPathComponent(label, isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: labeledOutputURL, withIntermediateDirectories: true, attributes: nil)
        } catch {
            throw ImageAugmentationError.directoryCreationFailed(url: labeledOutputURL, underlyingError: error)
        }

        var savedImageURLs: [URL] = []
        let imageExtension = "png" // PNG is a lossless format suitable for ML datasets.

        // 3. Concurrently apply augmentations and save images using `TaskGroup`.
        // `withThrowingTaskGroup` ensures that if any individual task throws an error,
        // the entire group is cancelled, and the error is propagated.
        try await withThrowingTaskGroup(of: URL.self) { group in
            for strategy in strategies {
                group.addTask { [weak self] in
                    // Ensure self is still alive; otherwise, throw an error.
                    guard let self = self else {
                        throw ImageAugmentationError.invalidImageInput // Or a more specific error for deallocated self
                    }

                    // 4. Apply the specific augmentation strategy.
                    let augmentedCIImage = try self.applyAugmentation(to: ciImage, strategy: strategy)

                    // 5. Define the output file name and URL for the augmented image.
                    let fileName = "\(label)_\(strategy.id).\(imageExtension)"
                    let fileURL = labeledOutputURL.appendingPathComponent(fileName)

                    // 6. Save the augmented image to the file system.
                    try await self.saveCIImage(augmentedCIImage, to: fileURL)

                    print("Generated and saved: \(fileURL.lastPathComponent)")
                    return fileURL
                }
            }

            // 7. Collect results from all completed tasks.
            for try await url in group {
                savedImageURLs.append(url)
            }
        }

        return savedImageURLs
    }
}

// MARK: - 4. Example Usage in an iOS App Context

/// This class simulates a view controller in a "Smart Plant Identifier" iOS app.
/// It demonstrates how the `PlantImageAugmentor` could be used to prepare
/// augmented data for a Create ML model.
/// In a real app, `UIImagePickerController` would provide the `UIImage` from user selection.
@available(iOS 17.0, *)
class PlantDataContributorViewController: UIViewController {

    private let augmentor = PlantImageAugmentor()
    private var selectedImage: UIImage? // Assume this is set by a UIImagePickerController
    private let plantLabel = "Monstera Deliciosa" // Example label for the plant
    private var outputBaseURL: URL! // Where augmented data will be stored

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // For demonstration, load a dummy image. In a real app, this would come from the user.
        selectedImage = UIImage(systemName: "photo.fill")?.withTintColor(.systemGreen, renderingMode: .alwaysOriginal).resized(to: CGSize(width: 200, height: 200))

        // Use a temporary directory for output. In a real app, this might be a sandboxed
        // directory for upload or a specific cache directory, ensuring proper cleanup.
        outputBaseURL = FileManager.default.temporaryDirectory.appendingPathComponent("AugmentedPlantData")
        print("Augmented images will be saved to: \(outputBaseURL.path)")
    }

    /// Sets up the basic user interface for the demonstration.
    private func setupUI() {
        view.backgroundColor = .systemBackground

        let titleLabel = UILabel()
        titleLabel.text = "Expert Contribution: Augment Plant Images"
        titleLabel.font = .preferredFont(forTextStyle: .title2)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleLabel)

        let imageView = UIImageView(image: selectedImage)
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)

        let augmentButton = UIButton(type: .system)
        augmentButton.setTitle("Generate Augmented Data", for: .normal)
        augmentButton.titleLabel?.font = .preferredFont(forTextStyle: .headline)
        augmentButton.addTarget(self, action: #selector(augmentButtonTapped), for: .touchUpInside)
        augmentButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(augmentButton)

        let activityIndicator = UIActivityIndicatorView(style: .large)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.hidesWhenStopped = true
        view.addSubview(activityIndicator)

        NSLayoutConstraint.activate([
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),

            imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            imageView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 30),
            imageView.widthAnchor.constraint(equalToConstant: 250),
            imageView.heightAnchor.constraint(equalToConstant: 250),

            augmentButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            augmentButton.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 50),
            augmentButton.widthAnchor.constraint(equalToConstant: 300),
            augmentButton.heightAnchor.constraint(equalToConstant: 50),

            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: augmentButton.centerYAnchor)
        ])
    }

    /// Action handler for the augment button.
    /// This method demonstrates the asynchronous nature of the augmentation process
    /// and how to update the UI safely using `MainActor.run`.
    @objc private func augmentButtonTapped() {
        guard let image = selectedImage else {
            presentAlert(title: "Error", message: "Please select an image first.")
            return
        }

        // Disable button and show activity indicator during processing for user feedback.
        let augmentButton = view.subviews.first(where: { ($0 as? UIButton)?.titleLabel?.text == "Generate Augmented Data" }) as? UIButton
        let activityIndicator = view.subviews.first(where: { $0 is UIActivityIndicatorView }) as? UIActivityIndicatorView
        augmentButton?.isEnabled = false
        activityIndicator?.startAnimating()

        // Define a comprehensive set of augmentation strategies to apply.
        // This array can be dynamically configured based on specific needs.
        let strategies: [AugmentationStrategy] = [
            .original,
            .horizontalFlip,
            .verticalFlip,
            .rotate(angle: 90),
            .rotate(angle: -90),
            .rotate(angle: 180),
            .crop(percentage: 0.1), // Crop 10% from edges
            .brightness(factor: 1.2), // Brighter
            .brightness(factor: 0.8), // Darker
            .contrast(factor: 1.5), // Higher contrast
            .contrast(factor: 0.7), // Lower contrast
            .saturation(factor: 1.5), // More saturated
            .saturation(factor: 0.7), // Less saturated
            .gaussianBlur(radius: 2.0) // Slight blur
        ]

        // Offload the potentially long-running augmentation process to a background task.
        Task {
            do {
                print("Starting augmentation for \(plantLabel)...")
                let augmentedImageURLs = try await augmentor.generateAugmentedImages(
                    from: image,
                    withLabel: plantLabel,
                    strategies: strategies,
                    to: outputBaseURL
                )

                // Update UI on the main actor after completion.
                await MainActor.run {
                    presentAlert(title: "Success", message: "Generated \(augmentedImageURLs.count) augmented images for '\(plantLabel)'.\nReady for Create ML training!")
                    print("Augmentation complete. Total images: \(augmentedImageURLs.count)")
                    print("Saved to: \(outputBaseURL.path)/\(plantLabel)")
                }
            } catch {
                // Handle errors and update UI on the main actor.
                await MainActor.run {
                    if let augError = error as? ImageAugmentationError {
                        presentAlert(title: "Augmentation Error", message: augError.localizedDescription)
                    } else {
                        presentAlert(title: "Error", message: "An unexpected error occurred: \(error.localizedDescription)")
                    }
                    print("Augmentation failed: \(error.localizedDescription)")
                }
            }
            // Re-enable button and hide activity indicator regardless of success or failure.
            await MainActor.run {
                augmentButton?.isEnabled = true
                activityIndicator?.stopAnimating()
            }
        }
    }

    /// Helper to present an alert to the user.
    private func presentAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

// MARK: - UIImage Extension for Resizing (Utility)
// This is a utility extension to make the dummy image used in the example
// look better by resizing it to a manageable size.
extension UIImage {
    /// Resizes the image to a specified target size while maintaining its aspect ratio.
    /// - Parameter targetSize: The desired maximum size for the image.
    /// - Returns: A new `UIImage` resized to fit within the target size, or `nil` if resizing fails.
    func resized(to targetSize: CGSize) -> UIImage? {
        let size = self.size
        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height

        // Determine what aspect ratio to use to scale down (the smaller of the two ratios).
        let ratio = min(widthRatio, heightRatio)
        let newSize = CGSize(width: size.width * ratio, height: size.height * ratio)

        let rect = CGRect(origin: .zero, size: newSize)

        // Begin a graphics context for drawing the resized image.
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        self.draw(in: rect) // Draw the original image into the new context.
        let newImage = UIGraphicsGetImageFromCurrentImageContext() // Get the new image.
        UIGraphicsEndImageContext() // End the graphics context.

        return newImage
    }
}
