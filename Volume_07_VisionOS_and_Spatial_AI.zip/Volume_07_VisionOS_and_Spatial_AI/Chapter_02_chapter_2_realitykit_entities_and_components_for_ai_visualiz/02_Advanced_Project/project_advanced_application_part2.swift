
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import RealityKit
import ARKit // For potential real-world anchoring, though simulated here
import SwiftUI // For ObservableObject and @MainActor

/// A custom RealityKit component that holds data for visualizing AI-inferred properties.
/// This component allows us to attach semantic AI insights directly to `Entity` objects
/// within the RealityKit scene, decoupling the raw AI data from its visual representation.
///
/// By conforming to `Component`, instances of `AIVisualizationComponent` can be added
/// to any `Entity`, making the entity "aware" of specific AI-driven visualization needs.
@available(visionOS 1.0, *)
public struct AIVisualizationComponent: Component, Codable {
    /// The primary label or name inferred by the AI (e.g., "Lamp", "Chair").
    public var primaryLabel: String
    /// An optional secondary property inferred by the AI (e.g., "On", "Off", "Healthy").
    public var inferredProperty: String?
    /// The color hint for visualization. This could dictate the color of a bounding box,
    /// an overlaid material, or text.
    public var visualizationColor: SIMD3<Float> // RGB color components
    /// A flag indicating if the visualization should be active or visible.
    public var isActive: Bool = true

    /// Initializes a new `AIVisualizationComponent`.
    /// - Parameters:
    ///   - primaryLabel: The main label from AI detection.
    ///   - inferredProperty: An optional property derived from AI.
    ///   - visualizationColor: The RGB color for the visual cue.
    ///   - isActive: Whether the visualization is currently active.
    public init(primaryLabel: String, inferredProperty: String? = nil, visualizationColor: SIMD3<Float>, isActive: Bool = true) {
        self.primaryLabel = primaryLabel
        self.inferredProperty = inferredProperty
        self.visualizationColor = visualizationColor
        self.isActive = isActive
    }

    // MARK: - Under the Hood: Why Components?
    // Components are central to RealityKit's Entity-Component-System (ECS) architecture.
    // They provide a flexible way to add distinct capabilities or data to entities
    // without using inheritance.
    //
    // 1. Decoupling: Separates data (AI insights) from behavior/rendering logic.
    //    The component holds *what* to visualize, not *how* to visualize it.
    // 2. Reusability: The same component type can be added to different entities.
    // 3. Scalability: Easily add new types of AI visualizations by defining new components
    //    or extending existing ones, without modifying core entity classes.
    // 4. Performance: RealityKit can efficiently manage and query entities based on their
    //    components, especially useful for systems that process specific types of data.
    // 5. Persistence: Conforming to `Codable` allows components to be saved and loaded,
    //    enabling persistence of AI-augmented scenes across app sessions.
}
