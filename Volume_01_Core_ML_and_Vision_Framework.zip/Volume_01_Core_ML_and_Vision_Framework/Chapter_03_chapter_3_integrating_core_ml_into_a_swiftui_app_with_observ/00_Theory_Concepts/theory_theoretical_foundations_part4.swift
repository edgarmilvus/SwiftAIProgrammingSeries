
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreML
import Vision
import SwiftUI // For @Observable

@available(iOS 17.0, *) // @Observable requires iOS 17+
@Observable
class ImageClassifierViewModel {
    var classificationResult: String = "No image classified yet."
    var isLoading: Bool = false
    var selectedImage: UIImage? {
        didSet {
            // Trigger classification when a new image is selected
            if let image = selectedImage {
                Task { await classifyImage(image: image) }
            } else {
                classificationResult = "No image selected."
            }
        }
    }

    private var classifier = MyImageClassifier() // Assume MyImageClassifier is initialized and loads its model

    @MainActor // Ensure UI updates happen on the main actor
    func classifyImage(image: UIImage) async {
        isLoading = true
        classificationResult = "Classifying..."

        do {
            // Convert UIImage to CVPixelBuffer
            guard let pixelBuffer = image.toCVPixelBuffer(width: 224, height: 224) else { // Helper extension needed
                throw ClassifierError.inputConversionFailed
            }

            let prediction = try await classifier.classifyImage(pixelBuffer: pixelBuffer)
            classificationResult = classifier.processClassificationResults(prediction: prediction)
        } catch {
            classificationResult = "Error: \(error.localizedDescription)"
            print("Classification error: \(error)")
        }
        isLoading = false
    }
}

// Example SwiftUI View
@available(iOS 17.0, *)
struct ClassifierView: View {
    @State private var viewModel = ImageClassifierViewModel()
    @State private var showPhotosPicker = false

    var body: some View {
        VStack {
            if let image = viewModel.selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 300)
            } else {
                Text("Select an image to classify")
                    .frame(height: 300)
                    .background(Color.gray.opacity(0.2))
            }

            Text(viewModel.classificationResult)
                .font(.headline)
                .padding()

            if viewModel.isLoading {
                ProgressView()
            }

            Button("Select Image") {
                showPhotosPicker = true
            }
            .buttonStyle(.borderedProminent)
            .photosPicker(isPresented: $showPhotosPicker, selection: $viewModel.selectedImage) // Simplified for example, real PhotosPicker uses transferrable
        }
        .padding()
    }
}
