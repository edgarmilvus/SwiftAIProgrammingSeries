
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Accelerate

/// A representation of a high-dimensional embedding.
/// We use SIMD (Single Instruction, Multiple Data) to allow the CPU to 
/// perform vector math on multiple components simultaneously.
@available(iOS 18.0, *)
struct PhotoEmbedding: Sendable, Identifiable {
    let id: UUID
    let description: String
    /// The vector components. Using SIMD<Float, 4> for a simplified 4D example.
    /// In a real app, this would be SIMD<Float, 512> or higher.
    let vector: SIMD4<Float>
    
    init(id: UUID = UUID(), description: String, vector: SIMD4<Float>) {
        self.id = id
        self.description = description
        self.vector = vector
    }
}

/// A node within the HNSW graph.
/// Each node maintains a list of neighbors to allow for graph traversal.
final class HNSWNode: Sendable {
    let embedding: PhotoEmbedding
    /// Neighbors at different layers. 
    /// Layer 0 is the densest (base layer).
    /// Higher indices represent sparser, upper layers.
    let neighbors: ThreadSafeNeighborStore

    init(embedding: PhotoEmbedding) {
        self.embedding = embedding
        self.neighbors = ThreadSafeNeighborStore()
    }
}

/// A thread-safe container for managing neighbors in a concurrent environment.
/// Since HNSW construction and searching can happen on multiple threads,
/// we must protect the adjacency list.
final class ThreadSafeNeighborStore: @unchecked Sendable {
    private var adjacencyList: [Int: [HNSWNode]] = [:]
    private let lock = NSLock()

    func addNeighbor(_ neighbor: HNSWNode, toLayer layer: Int) {
        lock.lock()
        defer { lock.unlock() }
        var current = adjacencyList[layer] ?? []
        current.append(neighbor)
        adjacencyList[layer] = current
    }

    func getNeighbors(forLayer layer: Int) -> [HNSWNode] {
        lock.lock()
        defer { lock.unlock() }
        return adjacencyList[layer] ?? []
    }
}

/// The core HNSW Index. 
/// We use an `actor` to ensure that the index state is protected from 
/// data races during simultaneous insertions and searches.
@available(iOS 18.0, *)
actor HNSWIndex {
    private var nodes: [HNSWNode] = []
    private let maxLayers: Int = 3
    private let entryPoint: HNSWNode?
    
    /// In a real HNSW, we'd track the entry point for the highest layer.
    /// For this simplified version, we'll use the first node added.
    private var topEntryPoint: HNSWNode?

    init() {
        self.entryPoint = nil
    }

    /// Adds a new photo embedding to the index.
    /// - Parameter embedding: The semantic vector of the photo.
    func insert(_ embedding: PhotoEmbedding) {
        let newNode = HNSWNode(embedding: embedding)
        nodes.append(newNode)
        
        // In a real HNSW, we would determine the node's maximum layer 
        // using a random probability distribution.
        let targetLayer = Int.random(in: 0..<maxLayers)
        
        if topEntryPoint == nil {
            topEntryPoint = newNode
            return
        }

        // Simplified: We connect the new node to existing nodes 
        // at its target layer and below.
        for layer in 0...targetLayer {
            connectToNearestNeighbors(newNode, atLayer: layer)
        }
        
        if targetLayer >= (topEntryPoint?.embedding.vector.magnitude ?? 0) { // Mock logic
             // Update top entry point if this node is in a higher layer
        }
    }

    /// Performs an Approximate Nearest Neighbor search.
    /// - Parameter query: The vector we are searching for.
    /// - Returns: The closest PhotoEmbedding found.
    func search(query: SIMD4<Float>) -> PhotoEmbedding? {
        guard let startNode = topEntryPoint else { return nil }
        
        var currentNode = startNode
        var currentDistance = euclideanDistance(query, currentNode.embedding.vector)
        
        // 1. Greedy Search through layers (Simplified)
        // In a real HNSW, we would start at the top layer and move down.
        // Here, we traverse the base layer (Layer 0) to find the local minimum.
        
        var improved = true
        while improved {
            improved = false
            let neighbors = currentNode.neighbors.getNeighbors(forLayer: 0)
            
            for neighbor in neighbors {
                let dist = euclideanDistance(query, neighbor.embedding.vector)
                if dist < currentDistance {
                    currentDistance = dist
                    currentNode = neighbor
                    improved = true
                }
            }
        }
        
        return currentNode.embedding
    }

    /// Helper function to link nodes.
    private func connectToNearestNeighbors(_ newNode: HNSWNode, atLayer layer: Int) {
        // In a real implementation, this would perform a search to find 
        // the K-nearest neighbors and establish bidirectional links.
        let existingNodes = nodes.filter { $0.embedding.id != newNode.embedding.id }
        for existing in existingNodes {
            // For demonstration, we link to any node that is "close enough"
            if euclideanDistance(newNode.embedding.vector, existing.embedding.vector) < 1.5 {
                newNode.neighbors.addNeighbor(existing, toLayer: layer)
                existing.neighbors.addNeighbor(newNode, toLayer: layer)
            }
        }
    }

    /// High-performance Euclidean distance calculation using SIMD.
    /// This is the "Under the Hood" engine of the search.
    private func euclideanDistance(_ a: SIMD4<Float>, _ b: SIMD4<Float>) -> Float {
        let diff = a - b
        // sum of squares: (a-b)^2
        let squaredSum = (diff * diff).sum()
        return sqrt(squaredSum)
    }
}

// MARK: - Execution Example

@available(iOS 18.0, *)
@MainActor
struct SmartGalleryDemo {
    func run() async {
        print("🚀 Initializing Smart Photo Gallery HNSW Index...")
        let index = HNSWIndex()

        // 1. Mock Data: Creating photo embeddings
        let photos = [
            PhotoEmbedding(description: "Golden Retriever in park", vector: SIMD4<Float>(0.1, 0.8, 0.1, 0.1)),
            PhotoEmbedding(description: "Sunset at the beach", vector: SIMD4<Float>(0.9, 0.1, 0.1, 0.1)),
            PhotoEmbedding(description: "Snowy mountain peak", vector: SIMD4<Float>(0.1, 0.1, 0.9, 0.2)),
            PhotoEmbedding(description: "Puppy playing in snow", vector: SIMD4<Float>(0.2, 0.7, 0.8, 0.1))
        ]

        // 2. Indexing: Adding photos to the graph
        for photo in photos {
            await index.insert(photo)
            print("📸 Indexed: \(photo.description)")
        }

        // 3. Querying: Searching for "A dog in the cold"
        // The query vector is semantically close to the "Puppy playing in snow" vector.
        let queryVector = SIMD4<Float>(0.15, 0.75, 0.85, 0.15)
        print("\n🔍 Searching for: 'A dog in the cold'...")
        
        if let result = await index.search(query: queryVector) {
            print("✅ Match Found: \(result.description)")
        } else {
            print("❌ No match found.")
        }
    }
}

// To run this in a Swift Playground or App:
// Task { await SmartGalleryDemo().run() }
