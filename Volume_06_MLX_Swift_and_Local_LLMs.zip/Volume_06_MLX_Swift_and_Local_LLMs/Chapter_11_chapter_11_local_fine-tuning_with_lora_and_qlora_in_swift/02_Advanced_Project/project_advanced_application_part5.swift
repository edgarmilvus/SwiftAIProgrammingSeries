
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

import MLX

/// Generates a synthetic dataset for document classification.
/// - Parameters:
///   - numSamples: The number of samples to generate.
///   - embeddingDimension: The dimension of each document embedding.
///   - numClasses: The number of classification categories.
///   - fineTuneBias: A bias added to the fine-tuning data to simulate a domain shift.
///   - key: The `MLXRandom.Key` for data generation.
/// - Returns: A tuple containing `(embeddings, labels)`.
func generateSyntheticData(
    numSamples: Int,
    embeddingDimension: Int,
    numClasses: Int,
    fineTuneBias: Float = 0.0,
    key: MLXRandom.Key
) -> (embeddings: MLXArray, labels: MLXArray) {
    var currentKey = key

    // Generate random document embeddings
    let embeddings = MLXArray.randomNormal([numSamples, embeddingDimension], key: currentKey.split())
    currentKey = currentKey.split()

    // Generate labels based on a simple linear combination of embeddings + bias
    // and then take argmax for classification.
    // The fineTuneBias makes the fine-tuning data slightly different.
    let baseWeights = MLXArray.randomNormal([embeddingDimension, numClasses], key: currentKey.split())
    currentKey = currentKey.split()

    let logits = embeddings.matmul(baseWeights) + fineTuneBias
    let labels = MLXArray.argmax(logits, axis: -1)

    return (embeddings: embeddings, labels: labels)
}
