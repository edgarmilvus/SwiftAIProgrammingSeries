
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN // Import MLXNN for Module

@available(iOS 18.0, *) // Swift 6 features often align with new OS versions
class Linear: MLXNN.Module {
    let weight: MLXArray
    let bias: MLXArray?

    // Initializer where parameters are declared
    init(inputFeatures: Int, outputFeatures: Int, bias: Bool = true) {
        // Initialize learnable parameters. MLXNN.Module automatically tracks these.
        self.weight = MLXArray.randomUniform(low: -1, high: 1, [outputFeatures, inputFeatures])
        if bias {
            self.bias = MLXArray.zeros([outputFeatures])
        } else {
            self.bias = nil
        }
        super.init() // Call the superclass initializer
    }

    // The forward pass, defining how data flows through the layer
    func callAsFunction(_ input: MLXArray) -> MLXArray {
        var output = MLX.matmul(weight, input) // Matrix multiplication
        if let bias = bias {
            output = output + bias // Add bias if present
        }
        return output
    }
}

@available(iOS 18.0, *)
class MLP: MLXNN.Module {
    // Modules can contain other modules, demonstrating composition
    let layer1: Linear
    let relu: MLXNN.ReLU
    let layer2: Linear

    init(inputFeatures: Int, hiddenFeatures: Int, outputFeatures: Int) {
        self.layer1 = Linear(inputFeatures: inputFeatures, outputFeatures: hiddenFeatures)
        self.relu = MLXNN.ReLU() // Activation function
        self.layer2 = Linear(inputFeatures: hiddenFeatures, outputFeatures: outputFeatures)
        super.init()
    }

    func callAsFunction(_ input: MLXArray) -> MLXArray {
        let x = layer1(input)
        let x_relu = relu(x)
        return layer2(x_relu)
    }
}
