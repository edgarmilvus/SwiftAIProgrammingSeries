
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

// MARK: - Protocols & Models

protocol MemoryLayer: Sendable {
    var layerName: String { get }
}

struct CoreDirective: MemoryLayer, Sendable {
    let layerName = "Core Directive"
    let persona: String
    let primaryGoal: String
}

struct LivingSummary: MemoryLayer, Sendable {
    let layerName = "Living Summary"
    var content: String
}

// MARK: - Services

protocol SummaryEvolver: Sendable {
    func evolve(currentSummary: String, prunedMessages: [ChatMessage]) async throws -> String
}

struct LLMSummaryEvolver: SummaryEvolver {
    func evolve(currentSummary: String, prunedMessages: [ChatMessage]) async throws -> String {
        // In a real app, this would call an LLM with a prompt like:
        // "Update the following summary with these new messages: [Summary] + [Messages]"
        try await Task.sleep(for: .seconds(1)) 
        let newInfo = prunedMessages.map { $0.content }.joined(separator: " ")
        return "Updated Summary: \(currentSummary) | New info: \(newInfo.prefix(30))..."
    }
}

// MARK: - The Engine

actor ChronicleContextEngine {
    // Layer 1: Static
    private let coreDirective: CoreDirective
    
    // Layer 2: Evolving
    private var livingSummary: LivingSummary
    
    // Layer 3: Transient
    private var activeBuffer: [ChatMessage] = []
    
    // Dependencies & Config
    private let evolver: any SummaryEvolver
    private let maxBufferSize: Int
    private let evolutionTrigger: Int
    
    init(
        coreDirective: CoreDirective,
        initialSummary: String,
        evolver: any SummaryEvolver,
        maxBufferSize: Int = 10,
        evolutionTrigger: Int = 5
    ) {
        self.coreDirective = coreDirective
        self.livingSummary = LivingSummary(content: initialSummary)
        self.evolver = evolver
        self.maxBufferSize = maxBufferSize
        self.evolutionTrigger = evolutionTrigger
    }
    
    /// Adds a message and triggers background evolution if the threshold is met.
    func addMessage(_ message: ChatMessage) async {
        activeBuffer.append(message)
        
        // Check if it's time to evolve the Living Summary
        if activeBuffer.count >= evolutionTrigger {
            let messagesToPrune = activeBuffer
            let currentSummaryText = livingSummary.content
            
            // Clear the buffer immediately to make room for new messages
            activeBuffer.removeAll()
            
            // Perform evolution in a detached task to avoid blocking the user's current interaction
            Task.detached(priority: .background) {
                do {
                    let updatedSummary = try await self.evolver.evolve(
                        currentSummary: currentSummaryText,
                        prunedMessages: messagesToPrune
                    )
                    await self.updateLivingSummary(updatedSummary)
                } catch {
                    print("Chronicle Engine: Evolution failed: \(error)")
                }
            }
        }
        
        // Maintain the sliding window for the active buffer
        if activeBuffer.count > maxBufferSize {
            activeBuffer.removeFirst()
        }
    }
    
    private func updateLivingSummary(_ newContent: String) {
        self.livingSummary = LivingSummary(content: newContent)
        print("✨ Chronicle Engine: Living Summary evolved.")
    }
    
    /// Assembles the final multi-layered prompt for the LLM.
    func assemblePrompt() -> String {
        var prompt = "### CORE DIRECTIVE\n\(coreDirective.persona)\nGoal: \(coreDirective.primaryGoal)\n\n"
        prompt += "### LIVING SUMMARY\n\(livingSummary.content)\n\n"
        prompt += "### RECENT DIALOGUE\n"
        
        for msg in activeBuffer {
            prompt += "[\(msg.role.rawValue)]: \(msg.content)\n"
        }
        
        return prompt
    }
}

// --- Implementation Test ---
@main
struct ChronicleTest {
    static func main() async {
        let directive = CoreDirective(persona: "Expert Research Assistant", primaryGoal: "Analyze quantum computing trends.")
        let engine = ChronicleContextEngine(
            coreDirective: directive,
            initialSummary: "User is interested in quantum supremacy.",
            evolver: LLMSummaryEvolver(),
            maxBufferSize: 5,
            evolutionTrigger: 3
        )
        
        print("--- Starting Research Session ---")
        
        for i in 1...7 {
            let msg = ChatMessage(role: .user, content: "Research point \(i): Detailed observation about qubits.")
            await engine.addMessage(msg)
            print("Message \(i) added.")
            
            // Small delay to simulate user typing
            try? await Task.sleep(for: .milliseconds(500))
        }
        
        // Wait for background evolution to complete
        try? await Task.sleep(for: .seconds(2))
        
        print("\n--- Final Assembled Prompt ---")
        print(await engine.assemblePrompt())
    }
}
