
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation // For LocalizedError

/// Custom errors for the DocumentSummarizerService.
enum SummarizerError: Error, LocalizedError, Sendable {
    /// Indicates that the specified LLM model file could not be found.
    case modelNotFound(path: URL)
    /// Indicates a failure during the loading process of the LLM model.
    case modelLoadFailed(underlyingError: Error)
    /// Indicates a failure during the LLM inference (generation) process.
    case inferenceFailed(underlyingError: Error)
    /// Indicates that the combined input text and prompt exceed the model's context window.
    case inputTooLong(currentLength: Int, maxContext: Int)
    /// Indicates that the LLM returned an invalid or empty summary.
    case invalidOutput

    /// Provides a user-friendly description for each error case.
    var errorDescription: String? {
        switch self {
        case .modelNotFound(let path):
            return "LLM model file not found at: \(path.lastPathComponent). Please ensure the model exists."
        case .modelLoadFailed(let error):
            return "Failed to load LLM model: \(error.localizedDescription). Check model integrity and configuration."
        case .inferenceFailed(let error):
            return "LLM inference failed: \(error.localizedDescription). This might be due to an invalid prompt or model issues."
        case .inputTooLong(let current, let max):
            return "Input text and prompt exceed model's context window (\(current) tokens > \(max) tokens). Please shorten the document or query, or use a model with a larger context."
        case .invalidOutput:
            return "The LLM returned an invalid or empty summary. Try rephrasing your query or providing more context."
        }
    }
}
