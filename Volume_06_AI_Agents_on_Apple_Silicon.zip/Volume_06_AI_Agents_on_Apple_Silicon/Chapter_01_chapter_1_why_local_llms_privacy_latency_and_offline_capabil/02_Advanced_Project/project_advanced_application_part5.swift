
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part5.swift
// Description: Advanced Application
// ==========================================

// MARK: - 4. Real-World Application Context (Simulated Usage)

/// A simulated view model or controller demonstrating the usage of `DocumentProcessor`.
/// In a real app, this would be part of a SwiftUI View or a UIKit ViewController.
@available(iOS 18.0, macOS 15.0, *)
class SecureScanAppViewModel: ObservableObject { // Use ObservableObject for SwiftUI integration
    @Published var currentDocument: Document?
    @Published var processedDocument: ProcessedDocument?
    @Published var errorMessage: String?
    @Published var isLoading: Bool = false

    private let documentProcessor: DocumentProcessor
    private var processingTask: Task<Void, Never>? // To manage cancellation

    /// Initializes the view model with a document processor.
    /// Dependency injection allows us to easily swap `MockLLMService` with a real one.
    init(documentProcessor: DocumentProcessor) {
        self.documentProcessor = documentProcessor
    }

    /// Simulates scanning a document and extracting its text.
    /// - Parameter documentURL: The URL of the document to "scan".
    func scanDocument(at documentURL: URL) {
        processingTask?.cancel() // Cancel any ongoing task
        processingTask = Task { @MainActor in
            isLoading = true
            errorMessage = nil
            processedDocument = nil

            do {
                let extractedText = try await documentProcessor.extractText(from: documentURL)
                self.currentDocument = Document(title: documentURL.lastPathComponent, rawContent: extractedText)
            } catch {
                self.errorMessage = (error as? DocumentProcessingError)?.localizedDescription ?? "Failed to scan document: \(error.localizedDescription)"
            }
            isLoading = false
        }
    }

    /// Triggers the summarization of the currently loaded document.
    func performSummarization() {
        guard let document = currentDocument else {
            errorMessage = "No document loaded to summarize."
            return
        }

        processingTask?.cancel()
        processingTask = Task { @MainActor in
            isLoading = true
            errorMessage = nil
            processedDocument = nil

            do {
                let result = try await documentProcessor.summarizeDocument(document: document)
                self.processedDocument = result
            } catch {
                self.errorMessage = (error as? DocumentProcessingError)?.localizedDescription ?? "Failed to summarize: \(error.localizedDescription)"
            }
            isLoading = false
        }
    }

    /// Triggers the redaction of sensitive information from the currently loaded document.
    /// - Parameter instructions: Specific instructions for the LLM on what to redact.
    func performRedaction(instructions: String = "Redact all personal names, addresses, emails, and social security numbers.") {
        guard let document = currentDocument else {
            errorMessage = "No document loaded to redact."
            return
        }

        processingTask?.cancel()
        processingTask = Task { @MainActor in
            isLoading = true
            errorMessage = nil
            processedDocument = nil

            do {
                let result = try await documentProcessor.redactDocument(document: document, redactionInstructions: instructions)
                self.processedDocument = result
            } catch {
                self.errorMessage = (error as? DocumentProcessingError)?.localizedDescription ?? "Failed to redact: \(error.localizedDescription)"
            }
            isLoading = false
        }
    }

    /// Cancels any ongoing processing task.
    func cancelProcessing() {
        processingTask?.cancel()
        isLoading = false
        errorMessage = "Operation cancelled."
    }
}

// --- Example Usage in a main context or SwiftUI App ---
@main
@available(iOS 18.0, macOS 15.0, *)
struct SecureScanAppEntryPoint {
    static func main() async {
        print("--- SecureScan App: Starting On-Device Document Processing Demo ---")

        // 1. Initialize the local LLM service (using our mock for demonstration)
        let mockLLMService = MockLLMService(latency: .seconds(2)) // Simulate 2-second inference
        
        // 2. Initialize the document processor with the LLM service
        let processor = DocumentProcessor(llmService: mockLLMService, defaultLLMModel: "secure-local-model")
        
        // 3. Initialize the view model (which would be used by a UI)
        let viewModel = SecureScanAppViewModel(documentProcessor: processor)

        // --- Simulate User Interactions ---

        // Simulate scanning a sensitive document
        print("\n--- Scanning 'sensitive_report.pdf' ---")
        let sensitiveDocURL = URL(fileURLWithPath: "/path/to/sensitive_report.pdf")
        viewModel.scanDocument(at: sensitiveDocURL)
        await Task.yield() // Allow scanDocument's Task to start
        print("Scanning in progress... (isLoading: \(viewModel.isLoading))")
        await Task.sleep(for: .seconds(0.5)) // Wait a bit for the async task to progress

        // Wait for the scanning to complete
        while viewModel.isLoading { await Task.sleep(for: .milliseconds(100)) }
        if let doc = viewModel.currentDocument {
            print("Document Scanned: '\(doc.title)' (Content length: \(doc.rawContent.count))")
            print("Raw Content Sample: \(doc.rawContent.prefix(100))...")
        } else if let error = viewModel.errorMessage {
            print("Error scanning: \(error)")
        }

        // Simulate redacting the sensitive document
        if viewModel.currentDocument != nil {
            print("\n--- Performing Redaction on Sensitive Document ---")
            viewModel.performRedaction()
            await Task.yield()
            print("Redaction in progress... (isLoading: \(viewModel.isLoading))")
            await Task.sleep(for: .seconds(0.5))

            // Wait for redaction to complete
            while viewModel.isLoading { await Task.sleep(for: .milliseconds(100)) }
            if let processed = viewModel.processedDocument {
                print("Redaction Complete (\(processed.operationType)):")
                print(processed.processedContent)
            } else if let error = viewModel.errorMessage {
                print("Error redacting: \(error)")
            }
        }

        // Simulate scanning a general report
        print("\n--- Scanning 'annual_report.pdf' ---")
        let reportDocURL = URL(fileURLWithPath: "/path/to/annual_report.pdf")
        viewModel.scanDocument(at: reportDocURL)
        await Task.yield()
        while viewModel.isLoading { await Task.sleep(for: .milliseconds(100)) }
        if let doc = viewModel.currentDocument {
            print("Document Scanned: '\(doc.title)' (Content length: \(doc.rawContent.count))")
            print("Raw Content Sample: \(doc.rawContent.prefix(100))...")
        } else if let error = viewModel.errorMessage {
            print("Error scanning: \(error)")
        }

        // Simulate summarizing the general report
        if viewModel.currentDocument != nil {
            print("\n--- Performing Summarization on Annual Report ---")
            viewModel.performSummarization()
            await Task.yield()
            print("Summarization in progress... (isLoading: \(viewModel.isLoading))")
            await Task.sleep(for: .seconds(0.5))

            // Wait for summarization to complete
            while viewModel.isLoading { await Task.sleep(for: .milliseconds(100)) }
            if let processed = viewModel.processedDocument {
                print("Summarization Complete (\(processed.operationType)):")
                print(processed.processedContent)
            } else if let error = viewModel.errorMessage {
                print("Error summarizing: \(error)")
            }
        }
        
        // Demonstrate cancellation
        print("\n--- Demonstrating Cancellation ---")
        let longDocURL = URL(fileURLWithPath: "/path/to/very_long_document.txt")
        viewModel.scanDocument(at: longDocURL)
        await Task.yield()
        print("Scanning long document...")
        await Task.sleep(for: .milliseconds(200)) // Let it start
        viewModel.cancelProcessing()
        print("Processing cancelled.")
        await Task.sleep(for: .milliseconds(100)) // Give time for cancellation to propagate
        if let error = viewModel.errorMessage {
            print("Cancellation result: \(error)")
        }
        print("--- SecureScan App Demo Finished ---")
    }
}
