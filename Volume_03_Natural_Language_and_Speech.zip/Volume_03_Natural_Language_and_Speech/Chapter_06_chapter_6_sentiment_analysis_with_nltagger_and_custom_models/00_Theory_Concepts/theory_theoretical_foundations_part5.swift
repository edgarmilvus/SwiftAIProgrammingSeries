
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import NaturalLanguage

@available(iOS 17.0, *)
@Observable class ContentViewModel { // Using @Observable for iOS 17+
    var inputText: String = ""
    var builtInSentimentScore: Double?
    var customSentimentLabel: String?
    var isLoading: Bool = false

    private let sentimentService = SentimentService() // Assume SentimentService is also @available(iOS 17.0, *)

    @MainActor
    func analyzeText() async {
        guard !inputText.isEmpty else {
            builtInSentimentScore = nil
            customSentimentLabel = nil
            return
        }

        isLoading = true
        defer { isLoading = false } // Ensure loading state is reset

        async let builtInScore = sentimentService.performBuiltInAnalysis(text: inputText)
        async let customLabel = sentimentService.performCustomAnalysis(text: inputText)

        self.builtInSentimentScore = await builtInScore
        self.customSentimentLabel = await customLabel
    }
}

@available(iOS 17.0, *)
struct SentimentView: View {
    @State private var viewModel = ContentViewModel()

    var body: some View {
        VStack {
            TextField("Enter text for sentiment analysis", text: $viewModel.inputText)
                .textFieldStyle(.roundedBorder)
                .padding()

            Button("Analyze Sentiment") {
                Task {
                    await viewModel.analyzeText()
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(viewModel.isLoading)

            if viewModel.isLoading {
                ProgressView()
            } else {
                if let score = viewModel.builtInSentimentScore {
                    Text("Built-in Sentiment: \(score, format: .number.precision(.fractionLength(2)))")
                        .font(.headline)
                        .padding(.top)
                }
                if let label = viewModel.customSentimentLabel {
                    Text("Custom Sentiment: \(label)")
                        .font(.headline)
                }
            }
            Spacer()
        }
        .navigationTitle("Sentiment Analyzer")
    }
}
