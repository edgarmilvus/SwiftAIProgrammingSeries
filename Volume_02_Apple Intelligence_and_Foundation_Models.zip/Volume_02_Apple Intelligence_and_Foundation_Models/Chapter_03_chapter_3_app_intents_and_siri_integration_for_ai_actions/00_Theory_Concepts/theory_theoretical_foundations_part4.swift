
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

    // Example of a custom struct intended to be returned by an AppIntent
    // It's implicitly Sendable if all its members are Sendable.
    struct AISummaryOutput: Codable, Sendable { // Explicitly mark Sendable if needed, often inferred
        let summary: String
        let wordCount: Int
        let keywords: [String]
    }

    @available(iOS 18.0, *)
    struct AdvancedSummarizeIntent: AppIntent {
        static var title: LocalizedStringResource = "Advanced Summarize"
        @Parameter var text: String

        func perform() async throws -> some IntentResult & ReturnsValue<AISummaryOutput> {
            // Simulate AI processing
            try await Task.sleep(for: .seconds(1))
            let output = AISummaryOutput(summary: "Advanced summary of \(text)", wordCount: 100, keywords: ["AI", "summary"])
            return .result(value: output)
        }
    }
    