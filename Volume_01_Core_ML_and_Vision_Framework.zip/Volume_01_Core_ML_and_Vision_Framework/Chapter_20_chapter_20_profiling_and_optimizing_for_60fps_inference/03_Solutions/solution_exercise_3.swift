
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import CoreML
import Vision
import Foundation
import UIKit // For UIImage and loading assets

// Assume YOLOv3.mlmodel is included in your project
// You can download it from Apple's Core ML Models page:
// https://developer.apple.com/machine-learning/models/
// Drag YOLOv3.mlmodel into your project, Xcode will auto-generate YOLOv3 class.

@available(iOS 18.0, *)
class ObjectDetector {
    private let vnCoreMLModel: VNCoreMLModel
    private let targetSize = CGSize(width: 416, height: 416) // YOLOv3 input size
    
    init() throws {
        let config = MLModelConfiguration()
        // Consider setting computeUnits based on performance needs, e.g., .neuralEngine
        config.computeUnits = .all 
        guard let model = try? YOLOv3(configuration: config) else { // Replace with your model
            fatalError("Failed to load Core ML object detector model.")
        }
        self.vnCoreMLModel = try VNCoreMLModel(for: model.model)
    }
    
    /// Creates a VNCoreMLRequest for object detection.
    func createObjectDetectionRequest() -> VNCoreMLRequest {
        let request = VNCoreMLRequest(model: vnCoreMLModel)
        request.imageCropAndScaleOption = .scaleFit // Maintain aspect ratio
        request.usesCPUOnly = false // Allow Neural Engine usage by default
        return request
    }

    /// Creates a sample CVPixelBuffer from a UIImage.
    private func createSamplePixelBuffer(from image: UIImage, targetSize: CGSize, pixelFormat: OSType = kCVPixelFormatType_32BGRA) -> CVPixelBuffer? {
        let width = Int(targetSize.width)
        let height = Int(targetSize.height)

        var pixelBuffer: CVPixelBuffer?
        let attributes = [
            kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ] as CFDictionary

        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         width,
                                         height,
                                         pixelFormat,
                                         attributes,
                                         &pixelBuffer)

        guard status == kCVReturnSuccess, let unwrappedPixelBuffer = pixelBuffer else {
            return nil
        }

        CVPixelBufferLockBaseAddress(unwrappedPixelBuffer, .init(rawValue: 0))
        defer { CVPixelBufferUnlockBaseAddress(unwrappedPixelBuffer, .init(rawValue: 0)) }

        let baseAddress = CVPixelBufferGetBaseAddress(unwrappedPixelBuffer)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(unwrappedPixelBuffer)

        guard let context = CGContext(data: baseAddress,
                                      width: width,
                                      height: height,
                                      bitsPerComponent: 8,
                                      bytesPerRow: bytesPerRow,
                                      space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue) else {
            return nil
        }

        context.clear(CGRect(x: 0, y: 0, width: width, height: height))
        let rect = CGRect(x: 0, y: 0, width: width, height: height)
        context.draw(image.cgImage!, in: rect)

        return unwrappedPixelBuffer
    }
    
    /// Performs object detection on a single CVPixelBuffer.
    func detectObjects(in pixelBuffer: CVPixelBuffer) async throws -> [VNRecognizedObjectObservation] {
        let request = createObjectDetectionRequest()
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        try handler.perform([request])
        
        guard let observations = request.results as? [VNRecognizedObjectObservation] else {
            return []
        }
        return observations
    }
    
    /// Option A: Performs object detection on a batch of CVPixelBuffers using VNSequenceRequestHandler.
    /// Note: VNSequenceRequestHandler processes images sequentially by default, but optimizes overhead.
    func detectObjectsInBatchSequenceHandler(pixelBuffers: [CVPixelBuffer]) async throws -> [[VNRecognizedObjectObservation]] {
        let sequenceHandler = VNSequenceRequestHandler()
        var allResults: [[VNRecognizedObjectObservation]] = []
        
        for pixelBuffer in pixelBuffers {
            let request = createObjectDetectionRequest()
            try sequenceHandler.perform([request], on: pixelBuffer)
            
            guard let observations = request.results as? [VNRecognizedObjectObservation] else {
                allResults.append([])
                continue
            }
            allResults.append(observations)
        }
        return allResults
    }
    
    /// Option B: Performs object detection on a batch of CVPixelBuffers using custom async batching (TaskGroup).
    /// This leverages concurrent execution for independent images.
    func detectObjectsInBatchTaskGroup(pixelBuffers: [CVPixelBuffer]) async throws -> [[VNRecognizedObjectObservation]] {
        return try await withThrowingTaskGroup(of: [VNRecognizedObjectObservation].self) { group in
            var allResults: [[VNRecognizedObjectObservation]] = Array(repeating: [], count: pixelBuffers.count)
            
            for (index, pixelBuffer) in pixelBuffers.enumerated() {
                group.addTask {
                    let request = self.createObjectDetectionRequest()
                    let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
                    try handler.perform([request])
                    
                    guard let observations = request.results as? [VNRecognizedObjectObservation] else {
                        return []
                    }
                    return observations
                }
            }
            
            // Collect results. TaskGroup doesn't guarantee order, so we need to track original index if needed.
            // For this exercise, we'll just collect them as they complete.
            for try await result in group {
                // If order matters, you'd need to pass the index into the task and store it with the result.
                // For now, we'll just append, which means results might not correspond to input order.
                // To maintain order, each task would return (index, results) and then sort.
                allResults.append(result) // This will append, not maintain order.
            }
            // A more robust way to maintain order:
            // var indexedResults: [(Int, [VNRecognizedObjectObservation])] = []
            // for try await (index, result) in group { indexedResults.append((index, result)) }
            // indexedResults.sort { $0.0 < $1.0 }
            // return indexedResults.map { $0.1 }
            
            // For simplicity in this example, we'll just return the collected results.
            // Note: The `allResults` initialized with `count` will be overwritten here.
            // A better approach for `TaskGroup` is to `reduce` or `map` a sequence of tasks.
            return allResults.filter { !$0.isEmpty } // Filter out the initial empty arrays if not using indexed return
        }
    }
}

@available(iOS 18.0, *)
class ObjectDetectionBatcher {
    private let numberOfImages = 10
    private var objectDetector: ObjectDetector!
    
    @MainActor
    func runBatchingExperiment() async {
        do {
            objectDetector = try ObjectDetector()
        } catch {
            print("Failed to initialize ObjectDetector: \(error)")
            return
        }

        // Generate sample images
        var samplePixelBuffers: [CVPixelBuffer] = []
        for i in 0..<numberOfImages {
            guard let sampleImage = UIImage(named: "sample_image_\(i % 3 + 1)") else { // Use 3 sample images
                fatalError("Sample image sample_image_\(i % 3 + 1).jpg not found.")
            }
            guard let pixelBuffer = objectDetector.createSamplePixelBuffer(from: sampleImage, targetSize: objectDetector.targetSize) else {
                fatalError("Failed to create pixel buffer for image \(i).")
            }
            samplePixelBuffers.append(pixelBuffer)
        }
        
        print("--- Object Detection Batching Experiment ---")

        // 1. Single-Image Pipeline (Sequential Baseline)
        print("\n--- Running Single-Image Pipeline (Sequential) ---")
        let startTimeSingle = ContinuousClock().now
        var singleImageResults: [[VNRecognizedObjectObservation]] = []
        for pixelBuffer in samplePixelBuffers {
            let results = try! await objectDetector.detectObjects(in: pixelBuffer)
            singleImageResults.append(results)
        }
        let durationSingle = ContinuousClock().now - startTimeSingle
        print("Total time for \(numberOfImages) images (sequential): \(durationSingle.formatted(.units(fractionalPart: .show(length: 6))))")
        print("First image results count (sequential): \(singleImageResults.first?.count ?? 0)")

        // 2. Batch Processing Option A: VNSequenceRequestHandler
        print("\n--- Running Batch Processing (VNSequenceRequestHandler) ---")
        let startTimeSequence = ContinuousClock().now
        let sequenceResults = try! await objectDetector.detectObjectsInBatchSequenceHandler(pixelBuffers: samplePixelBuffers)
        let durationSequence = ContinuousClock().now - startTimeSequence
        print("Total time for \(numberOfImages) images (VNSequenceRequestHandler): \(durationSequence.formatted(.units(fractionalPart: .show(length: 6))))")
        print("First image results count (sequence): \(sequenceResults.first?.count ?? 0)")

        // 3. Batch Processing Option B: Custom Async Batching (TaskGroup)
        print("\n--- Running Batch Processing (Custom Async/TaskGroup) ---")
        let startTimeTaskGroup = ContinuousClock().now
        let taskGroupResults = try! await objectDetector.detectObjectsInBatchTaskGroup(pixelBuffers: samplePixelBuffers)
        let durationTaskGroup = ContinuousClock().now - startTimeTaskGroup
        print("Total time for \(numberOfImages) images (TaskGroup): \(durationTaskGroup.formatted(.units(fractionalPart: .show(length: 6))))")
        print("First image results count (TaskGroup): \(taskGroupResults.first?.count ?? 0)")

        print("\n--- Comparison ---")
        print("Sequential processing: \(durationSingle.formatted(.units(fractionalPart: .show(length: 6))))")
        print("VNSequenceRequestHandler: \(durationSequence.formatted(.units(fractionalPart: .show(length: 6))))")
        print("Custom Async/TaskGroup: \(durationTaskGroup.formatted(.units(fractionalPart: .show(length: 6))))")
    }
}

// To run this code, you would typically call:
/*
@available(iOS 18.0, *)
Task {
    let batcher = ObjectDetectionBatcher()
    await batcher.runBatchingExperiment()
}
*/
