
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import CoreML
import Foundation

// MARK: - Model Loading and Version Retrieval Utility

@available(iOS 18.0, macOS 15.0, *)
enum ModelLoadingError: Error, LocalizedError {
    case modelNotFound(String)
    case versionStringNotFound
    case other(Error)

    var errorDescription: String? {
        switch self {
        case .modelNotFound(let name): return "ML Model '\(name)' not found in app bundle."
        case .versionStringNotFound: return "Model metadata is missing the version string."
        case .other(let error): return "An unexpected error occurred: \(error.localizedDescription)"
        }
    }
}

@available(iOS 18.0, macOS 15.0, *)
class ModelManager: ObservableObject {
    @Published var currentModelVersion: String = "Loading..."
    @Published var currentModel: MLModel?
    @Published var errorMessage: String?

    // Function to load an MLModel and extract its version string
    // This function is marked async to allow it to be called from a Task,
    // ensuring UI responsiveness, even though MLModel(contentsOf:) is synchronous.
    func loadModelAndGetVersion(modelName: String) async {
        errorMessage = nil // Clear previous errors
        do {
            guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "mlpackage") else {
                throw ModelLoadingError.modelNotFound(modelName)
            }

            // MLModel loading is synchronous, so we perform it in a background Task.
            let loadedModel = try await Task.detached {
                // Ensure configuration is provided, even if default
                return try MLModel(contentsOf: modelURL, configuration: MLModelConfiguration())
            }.value

            guard let version = loadedModel.modelDescription.metadata[MLModelMetadataKey.versionString] as? String else {
                throw ModelLoadingError.versionStringNotFound
            }

            DispatchQueue.main.async {
                self.currentModel = loadedModel
                self.currentModelVersion = version
                print("Successfully loaded model: \(modelName) with version: \(version)")
            }

            // Example of using the model (optional, for demonstration)
            // if let imageClassifier = loadedModel as? MLImageClassifier {
            //     // Perform inference here
            //     print("Model is an image classifier, ready for inference.")
            // }

        } catch let error as ModelLoadingError {
            DispatchQueue.main.async {
                self.errorMessage = error.localizedDescription
                self.currentModelVersion = "Error"
                self.currentModel = nil
                print("Model loading failed: \(error.localizedDescription)")
            }
        } catch {
            DispatchQueue.main.async {
                self.errorMessage = ModelLoadingError.other(error).localizedDescription
                self.currentModelVersion = "Error"
                self.currentModel = nil
                print("Model loading failed: \(error.localizedDescription)")
            }
        }
    }
}

// MARK: - SwiftUI View

@available(iOS 18.0, macOS 15.0, *)
struct Exercise1View: View {
    @StateObject private var modelManager = ModelManager()
    @State private var useVersion2 = false // State to simulate model update

    var body: some View {
        VStack(spacing: 20) {
            Text("Image Classifier App")
                .font(.largeTitle)
                .fontWeight(.bold)

            Spacer()

            Text("Active Model Version:")
                .font(.headline)
            Text(modelManager.currentModelVersion)
                .font(.title)
                .foregroundColor(modelManager.errorMessage != nil ? .red : .accentColor)
                .padding()
                .background(Capsule().fill(Color.gray.opacity(0.1)))

            if let errorMessage = modelManager.errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .multilineTextAlignment(.center)
                    .padding()
            }

            Spacer()

            Button(useVersion2 ? "Revert to v1.0.0" : "Simulate Update to v1.1.0") {
                useVersion2.toggle()
                Task {
                    await modelManager.loadModelAndGetVersion(modelName: useVersion2 ? "PhotoClassifier_v2" : "PhotoClassifier_v1")
                }
            }
            .buttonStyle(.borderedProminent)
            .padding()

            Text("Note: For this demo, 'PhotoClassifier_v1.mlpackage' and 'PhotoClassifier_v2.mlpackage' are expected in the app bundle.")
                .font(.footnote)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        .padding()
        .onAppear {
            // Load initial model when the view appears
            Task {
                await modelManager.loadModelAndGetVersion(modelName: "PhotoClassifier_v1")
            }
        }
    }
}

// MARK: - App Entry Point (for demonstration in an Xcode project)
/*
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            Exercise1View()
        }
    }
}
*/
