
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Example: An MLService method for image classification
@available(iOS 18.0, *)
actor ImageClassifierService {
    private let model: MLModel // Assume this is loaded safely
    // ... other properties

    init(model: MLModel) {
        self.model = model
    }

    func classifyImage(pixelBuffer: CVPixelBuffer) async throws -> String {
        // Perform preprocessing if necessary
        // This is where we'd typically use Vision or direct Core ML inference
        // For simplicity, let's simulate a Core ML prediction
        let input = MLFeatureProvider(dictionary: ["image": pixelBuffer])
        let output = try await model.prediction(from: input)
        guard let label = output.featureValue(for: "classLabel")?.stringValue else {
            throw ImageClassificationError.noLabelFound
        }
        return label
    }
}

enum ImageClassificationError: Error {
    case noLabelFound
    case inferenceFailed(Error)
    // ...
}

// In a ViewModel or other orchestrator:
@available(iOS 18.0, *)
class MyImageViewModel {
    private let classifier: ImageClassifierService
    @Published var classificationResult: String?
    @Published var isLoading = false
    @Published var error: Error?

    init(classifier: ImageClassifierService) {
        self.classifier = classifier
    }

    @MainActor
    func processImage(_ imageBuffer: CVPixelBuffer) async {
        isLoading = true
        error = nil
        do {
            // The actual ML inference happens off the main actor
            let result = try await classifier.classifyImage(pixelBuffer: imageBuffer)
            // Once done, switch back to main actor to update UI state
            classificationResult = result
        } catch {
            self.error = error
            classificationResult = nil
        }
        isLoading = false
    }
}
