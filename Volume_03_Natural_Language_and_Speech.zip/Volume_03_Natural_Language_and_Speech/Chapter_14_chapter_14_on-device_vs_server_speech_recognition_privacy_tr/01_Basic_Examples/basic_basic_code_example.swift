
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import Speech
import AVFoundation

/// A service for performing on-device speech transcription.
/// Ensures audio data never leaves the device for privacy-sensitive applications.
@available(iOS 18.0, *) // SFSpeechRecognizer.requiresOnDeviceRecognition is stable and improved on newer OS versions.
class OnDeviceSpeechTranscriber: ObservableObject {

    /// The speech recognizer instance, configured for the current locale.
    private let speechRecognizer: SFSpeechRecognizer?

    /// The recognition request that will be used to process audio.
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?

    /// The recognition task that manages the lifetime of the speech recognition process.
    private var recognitionTask: SFSpeechRecognitionTask?

    /// The audio engine used to capture microphone input.
    private let audioEngine = AVAudioEngine()

    /// Published property to update UI with the transcribed text.
    @Published var transcribedText: String = "Tap 'Start' to speak..."

    /// Published property to indicate if transcription is in progress.
    @Published var isTranscribing: Bool = false

    /// Initializes the speech transcriber.
    /// Sets up the SFSpeechRecognizer for the device's current locale.
    init() {
        // Initialize with the default locale. For specific languages, use SFSpeechRecognizer(locale: Locale(identifier: "en-US")).
        speechRecognizer = SFSpeechRecognizer()

        // Ensure the recognizer supports on-device recognition.
        guard let recognizer = speechRecognizer, recognizer.isAvailable else {
            transcribedText = "Speech recognition is not available on this device."
            return
        }

        // Crucially, verify that on-device recognition is supported for the current locale.
        if !recognizer.supportsOnDeviceRecognition {
            transcribedText = "On-device speech recognition is not supported for the current language."
            speechRecognizer = nil // Disable if on-device is not supported.
            return
        }

        // Set the delegate to receive authorization status changes.
        // Although we check authorization before starting, this is good practice for dynamic changes.
        // speechRecognizer?.delegate = self // Uncomment and implement SFSpeechRecognizerDelegate if needed for real-time status updates.
    }

    /// Requests authorization for speech recognition and microphone access.
    /// This must be called before attempting to start transcription.
    /// - Returns: `true` if authorized, `false` otherwise.
    func requestAuthorization() async -> Bool {
        let speechAuthStatus = await SFSpeechRecognizer.requestAuthorization()
        let audioAuthStatus = AVCaptureDevice.authorizationStatus(for: .audio)

        switch (speechAuthStatus, audioAuthStatus) {
        case (.authorized, .authorized):
            print("Speech and Microphone authorization granted.")
            return true
        case (.denied, _), (.restricted, _), (.notDetermined, _):
            print("Speech authorization denied or restricted.")
            // Handle UI to inform the user to enable permissions in settings.
            @MainActor
            func updateText() {
                self.transcribedText = "Authorization required: Please enable Speech Recognition and Microphone in Settings."
            }
            await updateText()
            return false
        default:
            print("Unexpected authorization status combination.")
            return false
        }
    }

    /// Starts the on-device speech recognition process.
    /// - Throws: `Error` if the audio engine cannot be started or authorization is not granted.
    func startTranscribing() async throws {
        // 1. Ensure authorization is granted before proceeding.
        guard await requestAuthorization() else {
            throw TranscriberError.authorizationDenied
        }

        // 2. Stop any existing recognition task to prepare for a new one.
        stopTranscribing()

        // 3. Create a new recognition request configured for on-device processing.
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else {
            throw TranscriberError.recognitionRequestFailed
        }

        // CRITICAL: Explicitly require on-device recognition.
        // If this is true and on-device recognition is not available, the request will fail.
        recognitionRequest.requiresOnDeviceRecognition = true
        recognitionRequest.shouldReportPartialResults = true // Provide results as the user speaks.

        // 4. Configure the audio session for recording.
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

        // 5. Set up the audio engine for microphone input.
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer) // Append audio buffers to the recognition request.
        }

        // 6. Start the audio engine.
        audioEngine.prepare()
        try audioEngine.start()

        // 7. Start the speech recognition task.
        recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self = self else { return }

            var isFinal = false

            if let result = result {
                // Update the UI with the latest transcription result.
                // @MainActor is crucial here as UI updates must happen on the main thread.
                Task { @MainActor in
                    self.transcribedText = result.bestTranscription.formattedString
                    self.isTranscribing = !result.isFinal // Update transcription status
                }
                isFinal = result.isFinal
            }

            if error != nil || isFinal {
                // If an error occurs or the transcription is final, stop the process.
                self.stopTranscribing()
                // Handle specific errors, e.g., if on-device recognition failed.
                if let error = error as? SFSpeechRecognizerError {
                    switch error.code {
                    case .onDeviceRecognitionNotAvailable:
                        Task { @MainActor in
                            self.transcribedText = "On-device recognition failed. Please check language support or device resources."
                        }
                        print("Error: On-device recognition not available for this session.")
                    default:
                        Task { @MainActor in
                            self.transcribedText = "Transcription error: \(error.localizedDescription)"
                        }
                        print("Transcription error: \(error.localizedDescription)")
                    }
                } else if error != nil {
                     Task { @MainActor in
                        self.transcribedText = "Transcription error: \(error!.localizedDescription)"
                     }
                }
            }
        }
        
        // 8. Update UI state.
        Task { @MainActor in
            self.isTranscribing = true
            self.transcribedText = "Listening..."
        }
    }

    /// Stops the current speech recognition process.
    func stopTranscribing() {
        // 1. Invalidate and release the recognition task.
        recognitionTask?.cancel()
        recognitionTask = nil

        // 2. End the recognition request. This is important to free up resources.
        recognitionRequest?.endAudio()
        recognitionRequest = nil

        // 3. Stop the audio engine and remove its tap.
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)

        // 4. Deactivate the audio session.
        try? AVAudioSession.sharedInstance().setActive(false)
        
        // 5. Update UI state.
        Task { @MainActor in
            self.isTranscribing = false
            if self.transcribedText == "Listening..." { // If nothing was transcribed
                 self.transcribedText = "Tap 'Start' to speak..."
            }
        }
    }

    /// Custom error types for the transcriber.
    enum TranscriberError: Error, LocalizedError {
        case authorizationDenied
        case recognitionRequestFailed
        case audioEngineFailed
        case onDeviceNotSupported

        var errorDescription: String? {
            switch self {
            case .authorizationDenied: return "Speech recognition and microphone access denied."
            case .recognitionRequestFailed: return "Failed to create speech recognition request."
            case .audioEngineFailed: return "Failed to start audio engine."
            case .onDeviceNotSupported: return "On-device recognition not supported for current language or device."
            }
        }
    }
}

// Example usage within a SwiftUI View (or similar application entry point)
import SwiftUI

@available(iOS 18.0, *)
struct SpeechRecordingView: View {
    @StateObject private var transcriber = OnDeviceSpeechTranscriber()

    var body: some View {
        VStack {
            Text(transcriber.transcribedText)
                .font(.title2)
                .padding()

            Button(action: {
                if transcriber.isTranscribing {
                    transcriber.stopTranscribing()
                } else {
                    Task {
                        do {
                            try await transcriber.startTranscribing()
                        } catch {
                            transcriber.stopTranscribing() // Ensure cleanup on error
                            print("Error starting transcription: \(error.localizedDescription)")
                            // Update UI with error message if needed
                            await MainActor.run {
                                transcriber.transcribedText = "Error: \(error.localizedDescription)"
                            }
                        }
                    }
                }
            }) {
                Text(transcriber.isTranscribing ? "Stop Transcribing" : "Start Transcribing")
                    .font(.headline)
                    .padding()
                    .background(transcriber.isTranscribing ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()
        }
        .onAppear {
            // Request authorization when the view appears, or at app launch.
            Task {
                _ = await transcriber.requestAuthorization()
            }
        }
    }
}

// MARK: - Info.plist Requirements
/*
    For this code to function, you MUST add the following entries to your app's Info.plist:

    <key>NSMicrophoneUsageDescription</key>
    <string>This app needs access to your microphone to transcribe your speech into text on-device.</string>

    <key>NSSpeechRecognitionUsageDescription</key>
    <string>This app needs access to speech recognition to convert your voice into text on-device for privacy reasons.</string>
*/
