
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation

// Package.swift snippet for a module using @Observable
/*
// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "AIAgentShell",
    platforms: [
        .macOS(.v14), // For @Observable
        .iOS(.v17)
    ],
    products: [
        .library(
            name: "AIAgentShell",
            targets: ["AIAgentShell"]),
    ],
    targets: [
        .target(
            name: "AIAgentShell"),
        .testTarget(
            name: "AIAgentShellTests",
            dependencies: ["AIAgentShell"]),
    ]
)
*/

/// Represents the state of a running shell command.
@available(macOS 14.0, iOS 17.0, *)
@Observable
class CommandOutput {
    var stdout: String = ""
    var stderr: String = ""
    var isRunning: Bool = false
    var exitCode: Int? = nil
    var error: Error? = nil
    var commandID: UUID

    init(commandID: UUID) {
        self.commandID = commandID
    }
}

@available(macOS 14.0, iOS 17.0, *)
actor StreamingShellExecutor {
    private var activeProcesses: [UUID: Process] = [:]
    private var commandOutputs: [UUID: CommandOutput] = [:]

    enum ShellError: Error {
        case commandNotFound(String)
        case executionFailed(command: String, exitCode: Int, stderr: String)
        case cancelled
        case unknown
    }

    /// Executes a shell command asynchronously and streams its output.
    /// - Parameters:
    ///   - command: The path to the executable.
    ///   - arguments: An array of string arguments.
    ///   - currentDirectoryURL: The working directory for the command.
    ///   - environment: Optional environment variables.
    /// - Returns: An `Observable` `CommandOutput` instance for monitoring.
    func executeStreaming(
        command: String,
        arguments: [String] = [],
        currentDirectoryURL: URL? = nil,
        environment: [String: String]? = nil
    ) async throws -> CommandOutput {
        let processUUID = UUID()
        let process = Process()
        let outputPipe = Pipe()
        let errorPipe = Pipe()

        process.executableURL = URL(fileURLWithPath: command)
        process.arguments = arguments
        process.standardOutput = outputPipe
        process.standardError = errorPipe
        process.currentDirectoryURL = currentDirectoryURL
        process.environment = environment

        let commandOutput = CommandOutput(commandID: processUUID)
        commandOutputs[processUUID] = commandOutput
        activeProcesses[processUUID] = process

        commandOutput.isRunning = true

        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                do {
                    // Handlers for stdout/stderr data
                    outputPipe.fileHandleForReading.readabilityHandler = { handle in
                        let data = handle.availableData
                        if !data.isEmpty {
                            Task { @MainActor in
                                commandOutput.stdout += data.toString
                            }
                        }
                    }

                    errorPipe.fileHandleForReading.readabilityHandler = { handle in
                        let data = handle.availableData
                        if !data.isEmpty {
                            Task { @MainActor in
                                commandOutput.stderr += data.toString
                            }
                        }
                    }

                    process.terminationHandler = { _ in
                        Task { @MainActor in
                            commandOutput.isRunning = false
                            commandOutput.exitCode = Int(process.terminationStatus)

                            // Ensure all data is read before resuming continuation
                            outputPipe.fileHandleForReading.readabilityHandler = nil
                            errorPipe.fileHandleForReading.readabilityHandler = nil
                            _ = outputPipe.fileHandleForReading.readDataToEndOfFile()
                            _ = errorPipe.fileHandleForReading.readDataToEndOfFile()

                            if process.terminationStatus == 0 {
                                continuation.resume(returning: commandOutput)
                            } else {
                                let error = ShellError.executionFailed(
                                    command: command + " " + arguments.joined(separator: " "),
                                    exitCode: Int(process.terminationStatus),
                                    stderr: commandOutput.stderr
                                )
                                commandOutput.error = error
                                continuation.resume(throwing: error)
                            }
                            await self.removeProcess(for: processUUID)
                        }
                    }

                    try process.run()

                } catch let error as NSError {
                    Task { @MainActor in
                        commandOutput.isRunning = false
                        if error.code == 4 && error.domain == NSPOSIXErrorDomain {
                            commandOutput.error = ShellError.commandNotFound(command)
                            continuation.resume(throwing: ShellError.commandNotFound(command))
                        } else {
                            commandOutput.error = error
                            continuation.resume(throwing: error)
                        }
                        await self.removeProcess(for: processUUID)
                    }
                }
            }
        } onCancel: {
            process.terminate()
            Task { @MainActor in
                commandOutput.isRunning = false
                commandOutput.error = ShellError.cancelled
                await self.removeProcess(for: processUUID)
            }
        }
    }

    private func removeProcess(for uuid: UUID) {
        commandOutputs.removeValue(forKey: uuid)
        activeProcesses.removeValue(forKey: uuid)
    }

    func cancelCommand(uuid: UUID) {
        activeProcesses[uuid]?.terminate()
        removeProcess(for: uuid) // Actor-isolated call
    }
}
