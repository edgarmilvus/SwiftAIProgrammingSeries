
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    // Example: An actor to manage the camera session
    @available(iOS 18.0, *)
    actor AVCameraManager {
        private var captureSession: AVCaptureSession?
        private var videoOutput: AVCaptureVideoDataOutput?
        // ... other AVFoundation components

        // State to be observed by SwiftUI
        @Published private(set) var isRunning: Bool = false
        @Published private(set) var currentFrame: CVPixelBuffer? // For AI processing

        init() {
            // Initial setup, but actual session start is async
        }

        func setupSession() async throws {
            // Perform heavy setup on actor's isolated executor
            guard captureSession == nil else { return }

            let session = AVCaptureSession()
            // Configure session with inputs/outputs
            // ...

            self.captureSession = session
            self.videoOutput = AVCaptureVideoDataOutput()
            // Configure videoOutput and set delegate
            // ...

            // Start session on a background queue
            Task { await session.startRunning() } // Start running in a non-blocking way
            isRunning = true
        }

        func stopSession() async {
            guard let session = captureSession else { return }
            await session.stopRunning() // Stop running in a non-blocking way
            isRunning = false
            captureSession = nil
            videoOutput = nil
        }

        // Delegate method for AVCaptureVideoDataOutputSampleBufferDelegate
        // This would typically be within a Coordinator, which then calls this actor method.
        func processSampleBuffer(_ sampleBuffer: CMSampleBuffer) async {
            guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
            // Perform AI inference here or pass to another actor/task
            self.currentFrame = pixelBuffer // Update state for potential AI processing
            // ... trigger AI inference task
        }
    }
    