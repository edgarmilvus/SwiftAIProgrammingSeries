
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CreateML // Assuming CreateML is imported via SPM or directly

@available(macOS 12.0, iOS 15.0, tvOS 15.0, watchOS 8.0, *)
class DataImporter {
    enum ImportError: Error {
        case fileNotFound
        case dataCorrupted(String)
    }

    /// Asynchronously loads an MLDataTable from a CSV file.
    /// This operation can be I/O bound, so async/await is crucial for responsiveness.
    func loadCSV(from url: URL) async throws -> MLDataTable {
        // Simulate a network or disk operation
        try await Task.sleep(for: .seconds(2))

        guard FileManager.default.fileExists(atPath: url.path(percentEncoded: false)) else {
            throw ImportError.fileNotFound
        }

        do {
            // MLDataTable.init(contentsOf:) is an async operation itself
            let dataTable = try await MLDataTable(contentsOf: url)
            print("Successfully loaded data table with \(dataTable.rows.count) rows.")
            return dataTable
        } catch {
            throw ImportError.dataCorrupted("Failed to parse CSV: \(error.localizedDescription)")
        }
    }

    /// Asynchronously performs a transformation on an MLDataTable.
    /// This could be computationally intensive.
    func transform(table: MLDataTable) async throws -> MLDataTable {
        // Simulate a heavy computation
        try await Task.sleep(for: .seconds(1))

        // Example transformation: create a new column based on existing ones
        let transformedTable = try await table.mapColumns { (column: MLDataColumn<Double>) -> Double in
            return column.map { $0 * 100.0 } // Scale a numeric column
        } named: "scaled_value"

        print("Successfully transformed data table.")
        return transformedTable
    }
}

// Usage example within an async context:
@available(macOS 12.0, iOS 15.0, tvOS 15.0, watchOS 8.0, *)
func processData() async {
    let importer = DataImporter()
    // Assume `csvURL` points to a valid CSV file
    guard let csvURL = Bundle.main.url(forResource: "my_data", withExtension: "csv") else {
        print("CSV file not found.")
        return
    }

    do {
        print("Loading data...")
        let originalTable = try await importer.loadCSV(from: csvURL)
        print("Original table columns: \(originalTable.columnNames)")

        print("Transforming data...")
        let transformedTable = try await importer.transform(table: originalTable)
        print("Transformed table columns: \(transformedTable.columnNames)")

        // Further processing, e.g., splitting for training
        let (trainingData, testingData) = transformedTable.randomSplit(by: 0.8, seed: 0)
        print("Training data rows: \(trainingData.rows.count)")
        print("Testing data rows: \(testingData.rows.count)")

    } catch {
        print("Data processing failed: \(error)")
    }
}
