
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import NaturalLanguage
import CoreML // Required for NLModel

@available(iOS 17.0, *)
enum CustomSentimentTagScheme: String, NLTagScheme {
    case customSentiment = "CustomSentiment"
}

@available(iOS 17.0, *)
class CustomSentimentAnalyzer {
    private let tagger: NLTagger
    private let customModel: NLModel

    init?() {
        // Load your custom Core ML model.
        // This assumes 'MyCustomSentimentModel' is compiled into your app bundle.
        guard let modelURL = Bundle.main.url(forResource: "MyCustomSentimentModel", withExtension: "mlmodelc"),
              let coreMLModel = try? MLModel(contentsOf: modelURL),
              let nlModel = try? NLModel(mlModel: coreMLModel) else {
            print("Failed to load custom sentiment model.")
            return nil
        }
        self.customModel = nlModel

        // Initialize NLTagger with a placeholder scheme, then set the custom model.
        self.tagger = NLTagger(tagSchemes: [.sentiment]) // Placeholder, will be replaced
        self.tagger.setModels([customModel], forTagScheme: CustomSentimentTagScheme.customSentiment)
    }

    func analyzeCustomSentiment(for text: String) async -> String? {
        tagger.string = text

        var sentimentLabel: String?
        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .document, scheme: CustomSentimentTagScheme.customSentiment, options: []) { tag, tokenRange in
            if let tag = tag {
                sentimentLabel = tag.rawValue // e.g., "Positive", "Negative", "Neutral"
            }
            return true
        }
        return sentimentLabel
    }
}
