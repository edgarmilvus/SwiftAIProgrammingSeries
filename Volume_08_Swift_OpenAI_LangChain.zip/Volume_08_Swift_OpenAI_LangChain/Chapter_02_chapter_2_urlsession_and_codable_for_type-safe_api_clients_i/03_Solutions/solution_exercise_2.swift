
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

@available(iOS 18.0, *)
import Foundation

enum APIError: Error, LocalizedError {
    case unauthorized(String)
    case rateLimited(String)
    case serverError(String)
    case decodingError(Error)
    case unknown(Int)
    
    var errorDescription: String? {
        switch self {
        case .unauthorized(let msg): return "Authentication Failed: \(msg)"
        case .rateLimited(let msg): return "Rate Limit Exceeded: \(msg)"
        case .serverError(let msg): return "Server Error: \(msg)"
        case .decodingError(let err): return "Data Parsing Error: \(err.localizedDescription)"
        case .unknown(let code): return "Unexpected Error (Status: \(code))"
        }
    }
}

// Model for the error JSON returned by the API
struct ErrorResponse: Codable {
    let error: ErrorDetail
}

struct ErrorDetail: Codable {
    let message: String
    let type: String
}

struct ResilientClient {
    private let decoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return decoder
    }()

    func performRequest(for request: URLRequest) async throws -> Data {
        let (data, response) = try await URLSession.shared.data(for: request)
        
        // Cast to HTTPURLResponse to inspect status code
        guard let httpResponse = response as? HTTPURLResponse else {
            throw APIError.unknown(0)
        }

        switch httpResponse.statusCode {
        case 200...299:
            return data
        case 401:
            let errorMsg = try? decoder.decode(ErrorResponse.self, from: data).error.message
            throw APIError.unauthorized(errorMsg ?? "Unauthorized access")
        case 429:
            let errorMsg = try? decoder.decode(ErrorResponse.self, from: data).error.message
            throw APIError.rateLimited(errorMsg ?? "Too many requests")
        case 500...599:
            let errorMsg = try? decoder.decode(ErrorResponse.self, from: data).error.message
            throw APIError.serverError(errorMsg ?? "Internal server error")
        default:
            throw APIError.unknown(httpResponse.statusCode)
        }
    }
}
