
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.swift
// Description: Basic Code Example
// ==========================================

import AppIntents
import Foundation

/// An App Intent to mark a specific reminder as complete.
@available(iOS 18.0, *) // App Intents are available from iOS 18
struct MarkReminderCompleteIntent: AppIntent {
    /// The user-facing title of the intent, displayed in Siri and Shortcuts.
    static var title: LocalizedStringResource = "Mark Reminder as Complete"

    /// A brief description of what the intent does.
    static var description: IntentDescription? = "Marks a selected reminder as completed in the Reminder app."

    /// Specifies whether the app should be opened when this intent is run.
    /// Setting to `false` allows the intent to run entirely in the background.
    static var openAppWhenRun: Bool = false // We want this to run in the background if possible

    /// The parameter for our intent: the reminder to be marked complete.
    /// The `@Parameter` attribute makes this property discoverable by Siri and Shortcuts.
    /// `requestValueDialog` provides a specific prompt if Siri needs to ask the user for this value.
    @Parameter(
        title: "Reminder to Complete",
        description: "The reminder you want to mark as complete.",
        requestValueDialog: "Which reminder should I mark as complete?"
    )
    var reminderToComplete: ReminderAppEntity

    /// The main execution block of the intent.
    /// This method is asynchronous because intent operations can involve network requests,
    /// database access, or other long-running tasks.
    func perform() async throws -> some IntentResult {
        // 1. Retrieve the reminder from our mock data store using the ID from the AppEntity.
        guard var reminder = ReminderStore.shared.findReminder(by: reminderToComplete.id) else {
            // If the reminder isn't found, return an error dialog.
            throw "Reminder not found."
        }

        // 2. Check if the reminder is already completed.
        if reminder.isCompleted {
            return .result(
                dialog: "The reminder \"\(reminder.title)\" is already completed."
            )
        }

        // 3. Update the reminder's status.
        reminder.isCompleted = true
        _ = ReminderStore.shared.updateReminder(reminder) // Update in the store

        // 4. Return a success dialog.
        return .result(
            dialog: "I've marked \"\(reminder.title)\" as complete."
        )
    }
}

// Helper extension for throwing String errors easily
extension String: LocalizedError {
    public var errorDescription: String? { return self }
}
