
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_8.swift
// Description: Solution for Exercise 8
// ==========================================

import UIKit
import CoreML
import NaturalLanguage

// Assume FeatureIdentifier.mlmodel has been added to the project
// and Xcode has automatically generated the FeatureIdentifier class.

class FeatureExtractionViewController: UIViewController {
    // UI Elements
    private let productDescriptionTextView: UITextView = {
        let textView = UITextView()
        textView.font = .systemFont(ofSize: 17)
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 5.0
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
    }()

    private let extractButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Extract Features", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let extractedFeaturesLabel: UILabel = {
        let label = UILabel()
        label.text = "Extracted Features:\n"
        label.font = .systemFont(ofSize: 16)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        return scrollView
    }()

    // Core ML Model instance
    private var featureIdentifier: FeatureIdentifier?

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Product Feature Extractor"
        view.backgroundColor = .white
        setupUI()
        loadModel()
    }

    private func setupUI() {
        view.addSubview(productDescriptionTextView)
        view.addSubview(extractButton)
        view.addSubview(scrollView)
        scrollView.addSubview(extractedFeaturesLabel)

        NSLayoutConstraint.activate([
            productDescriptionTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            productDescriptionTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            productDescriptionTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            productDescriptionTextView.heightAnchor.constraint(equalToConstant: 150),

            extractButton.topAnchor.constraint(equalTo: productDescriptionTextView.bottomAnchor, constant: 20),
            extractButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            extractButton.widthAnchor.constraint(equalToConstant: 250),
            extractButton.heightAnchor.constraint(equalToConstant: 50),

            scrollView.topAnchor.constraint(equalTo: extractButton.bottomAnchor, constant: 20),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            scrollView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),

            // Extracted features label within scroll view
            extractedFeaturesLabel.topAnchor.constraint(equalTo: scrollView.topAnchor),
            extractedFeaturesLabel.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            extractedFeaturesLabel.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            extractedFeaturesLabel.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            extractedFeaturesLabel.widthAnchor.constraint(equalTo: scrollView.widthAnchor) // Important for vertical scrolling
        ])

        extractButton.addTarget(self, action: #selector(extractFeatures), for: .touchUpInside)
    }

    private func loadModel() {
        do {
            let config = MLModelConfiguration()
            self.featureIdentifier = try FeatureIdentifier(configuration: config)
            print("Core ML model 'FeatureIdentifier' loaded successfully.")
        } catch {
            print("Error loading feature identifier model: \(error.localizedDescription)")
            extractedFeaturesLabel.text = "Error: Model failed to load."
        }
    }

    // MARK: - Feature Extraction Logic (Hybrid Approach)
    @objc private func extractFeatures() {
        guard let fullText = productDescriptionTextView.text, !fullText.isEmpty else {
            extractedFeaturesLabel.text = "Extracted Features: Please enter product description."
            return
        }

        guard let classifier = featureIdentifier else {
            extractedFeaturesLabel.text = "Extracted Features: Model not loaded, cannot extract."
            return
        }

        extractedFeaturesLabel.text = "Extracted Features:\n" // Clear previous results

        Task {
            let extractedResults = await Task.detached {
                var results: [(type: String, phrase: String)] = []
                let tagger = NLTagger(tagSchemes: [.sentence, .tokenType, .lemma, .nameType, .measurement], options: .omitWhitespace)
                tagger.string = fullText

                // 1. Tokenize into sentences
                tagger.enumerateTags(in: fullText.startIndex..<fullText.endIndex, unit: .sentence, scheme: .sentence, options: .omitWhitespace) { _, sentenceRange in
                    let sentence = String(fullText[sentenceRange])

                    // 2. Classify each sentence for its primary feature type
                    do {
                        let prediction = try classifier.prediction(text: sentence)
                        let featureType = prediction.feature_type

                        // If the model identifies a specific feature type (and it's not 'Other' or general)
                        if featureType != "Other" && featureType != "unknown" { // Assuming 'unknown' is a possible fallback
                            // 3. Heuristic Extraction within the classified sentence
                            // This part is rule-based/regex-based, as MLTextClassifier doesn't do span extraction.
                            var extractedPhrase: String?

                            switch featureType {
                            case "ScreenFeature":
                                // Regex for patterns like "X.X-inch", "X.X inch", "X by Y pixels", "OLED display"
                                if let match = sentence.range(of: #"(\d+(\.\d+)?\s*(inch|inches|'')?(\s*(liquid|super)\s*retina|oled|display|panel|xdr))|(\d+\s*by\s*\d+\s*pixels)"#, options: .regularExpression) {
                                    extractedPhrase = String(sentence[match])
                                }
                            case "BatteryFeature":
                                // Regex for patterns like "X hours", "X-hour battery life", "all day battery"
                                if let match = sentence.range(of: #"(\d+(\.\d+)?\s*(hours|hrs)?\s*battery life)|(all day battery)|(fast charging)"#, options: .regularExpression) {
                                    extractedPhrase = String(sentence[match])
                                }
                            case "ProcessorFeature":
                                // Regex for chip names like "AXX Bionic", "MXX chip", "Snapdragon"
                                if let match = sentence.range(of: #"(A\d+\s*Bionic\s*chip)|(M\d+\s*chip)|(Snapdragon\s*\d+\s*Gen\s*\d+)"#, options: .regularExpression) {
                                    extractedPhrase = String(sentence[match])
                                }
                            case "CameraFeature":
                                // Regex for "XMP camera", "X-megapixel lens", "telephoto", "ultra wide"
                                if let match = sentence.range(of: #"(\d+(\.\d+)?MP\s*(ultra\s*wide|telephoto)?\s*camera)|(\d+-megapixel\s*lens)"#, options: .regularExpression) {
                                    extractedPhrase = String(sentence[match])
                                }
                            case "StorageFeature":
                                // Regex for "XGB storage", "XGB of storage", "XGB RAM"
                                if let match = sentence.range(of: #"(\d+\s*GB\s*(of\s*)?(storage|ram))"#, options: .regularExpression) {
                                    extractedPhrase = String(sentence[match])
                                }
                            case "MemoryFeature":
                                // Regex for "XGB RAM"
                                if let match = sentence.range(of: #"(\d+\s*GB\s*RAM)"#, options: .regularExpression) {
                                    extractedPhrase = String(sentence[match])
                                }
                            default:
                                break // No specific extraction for other categories
                            }

                            if let phrase = extractedPhrase {
                                results.append((type: featureType, phrase: phrase))
                            } else {
                                // If no specific phrase extracted, just report the sentence as containing the feature
                                results.append((type: featureType, phrase: sentence))
                            }
                        }
                    } catch {
                        print("Error classifying sentence '\(sentence)': \(error.localizedDescription)")
                    }
                    return true
                }
                return results
            }.value

            await MainActor.run {
                if extractedResults.isEmpty {
                    extractedFeaturesLabel.text = "Extracted Features: No specific product features identified."
                } else {
                    var outputText = "Extracted Features:\n"
                    for (type, phrase) in extractedResults {
                        outputText += "- \(type.replacingOccurrences(of: "Feature", with: "")): \(phrase)\n"
                    }
                    extractedFeaturesLabel.text = outputText
                }
            }
        }
    }
}
