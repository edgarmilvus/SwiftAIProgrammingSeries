
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
@Observable
final class FineTuningMonitor {
    var currentLoss: Float = 0.0
    var progress: Float = 0.0
    var isTraining: Bool = false
    var statusMessage: String = "Ready"

    // This monitor would be updated by the LLMFineTuner actor
    // via a delegate pattern, async stream, or by the actor directly mutating
    // a shared instance if the monitor is also an actor or has proper synchronization.
    // For simplicity, imagine the actor updates this from its isolated context.
    func update(loss: Float, progress: Float, isTraining: Bool, message: String) {
        self.currentLoss = loss
        self.progress = progress
        self.isTraining = isTraining
        self.statusMessage = message
    }
}

// In a SwiftUI View:
/*
struct FineTuningView: View {
    @State private var monitor = FineTuningMonitor()
    @State private var fineTuner: LLMFineTuner? // Managed by state or environment

    var body: some View {
        VStack {
            Text("Loss: \(monitor.currentLoss, specifier: "%.4f")")
            ProgressView(value: monitor.progress)
                .progressViewStyle(.linear)
            Text(monitor.statusMessage)
            Button("Start Fine-Tuning") {
                Task {
                    monitor.isTraining = true
                    monitor.statusMessage = "Training..."
                    // Assume fineTuner is initialized elsewhere
                    // and has access to model, optimizer, data
                    await fineTuner?.startFineTuning(epochs: 5)
                    monitor.isTraining = false
                    monitor.statusMessage = "Training Complete"
                }
            }
            .disabled(monitor.isTraining)
        }
    }
}
*/
