/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// SecureSessionManager.tsx
import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ActivityIndicator } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import * as LocalAuthentication from 'expo-local-authentication';

const SESSION_KEY = 'app_session_token';
const MOCK_TOKEN = 'auth_success_123';

type AuthStatus = 'loading' | 'unauthenticated' | 'biometric_check' | 'pin_entry' | 'authenticated';

export default function SecureSessionManager() {
  const [status, setStatus] = useState<AuthStatus>('loading');
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);

  // 1. Check existing session on mount
  useEffect(() => {
    checkSession();
  }, []);

  const checkSession = async () => {
    const token = await SecureStore.getItemAsync(SESSION_KEY);
    if (token === MOCK_TOKEN) {
      setStatus('authenticated');
    } else {
      setStatus('unauthenticated');
      // Trigger biometric check immediately if unauthenticated
      attemptBiometrics();
    }
  };

  // 2. Biometric Logic with Fallback
  const attemptBiometrics = async () => {
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const isEnrolled = await LocalAuthentication.isEnrolledAsync();

      if (hasHardware && isEnrolled) {
        setStatus('biometric_check');
        const result = await LocalAuthentication.authenticateAsync({
          promptMessage: 'Verify Identity',
        });

        if (result.success) {
          await loginSuccess();
        } else {
          // Fallback to PIN
          setError('Biometrics failed. Please enter PIN.');
          setStatus('pin_entry');
        }
      } else {
        // No hardware, go straight to PIN
        setStatus('pin_entry');
      }
    } catch (e) {
      setError('Biometric error. Using PIN fallback.');
      setStatus('pin_entry');
    }
  };

  // 3. PIN Logic
  const handlePinSubmit = async () => {
    // Simulate PIN verification (e.g., check against stored hash)
    if (pin === '1234') {
      await loginSuccess();
    } else {
      setError('Invalid PIN. Try 1234.');
      setPin('');
    }
  };

  // 4. Login Success (Biometric or PIN)
  const loginSuccess = async () => {
    await SecureStore.setItemAsync(SESSION_KEY, MOCK_TOKEN);
    setStatus('authenticated');
    setError(null);
  };

  // 5. Logout
  const logout = async () => {
    await SecureStore.deleteItemAsync(SESSION_KEY);
    setStatus('unauthenticated');
    setPin('');
    // Re-trigger biometric check immediately or wait for user action
    attemptBiometrics(); 
  };

  // Render Logic
  if (status === 'loading') {
    return <View style={styles.container}><ActivityIndicator size="large" /></View>;
  }

  if (status === 'authenticated') {
    return (
      <View style={styles.container}>
        <Text style={styles.successTitle}>Session Active</Text>
        <Text>Token: {MOCK_TOKEN}</Text>
        <Button title="Logout" onPress={logout} color="red" />
      </View>
    );
  }

  if (status === 'pin_entry') {
    return (
      <View style={styles.container}>
        <Text>Enter PIN (Fallback)</Text>
        {error && <Text style={styles.error}>{error}</Text>}
        <TextInput 
          style={styles.input} 
          keyboardType="numeric" 
          secureTextEntry 
          value={pin} 
          onChangeText={setPin} 
          placeholder="1234"
        />
        <Button title="Submit PIN" onPress={handlePinSubmit} />
      </View>
    );
  }

  // Biometric Check UI
  return (
    <View style={styles.container}>
      <Text>Verifying Biometrics...</Text>
      <ActivityIndicator />
      <Text style={styles.hint}>If this hangs, wait for timeout or cancel to trigger PIN.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  input: { borderWidth: 1, padding: 10, width: 200, marginVertical: 10, textAlign: 'center' },
  error: { color: 'red', marginBottom: 10 },
  successTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 10 },
  hint: { fontSize: 10, color: 'gray', marginTop: 10, textAlign: 'center' }
});
