
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_6.swift
// Description: Solution for Exercise 6
// ==========================================

import RealityKit
import simd
import SwiftUI

// MARK: - Custom Component

@available(visionOS 1.0, *)
struct TrajectoryComponent: Component, Codable {
    var historicalPath: [SIMD3<Float>]
    var predictedPath: [SIMD3<Float>]
    var maxPathLength: Int // To prevent historicalPath from growing indefinitely

    // Keep track of previous path states to optimize mesh regeneration
    var previousHistoricalPathCount: Int
    var previousPredictedPathCount: Int

    init(historicalPath: [SIMD3<Float>] = [], predictedPath: [SIMD3<Float>] = [], maxPathLength: Int = 100) {
        self.historicalPath = historicalPath
        self.predictedPath = predictedPath
        self.maxPathLength = maxPathLength
        self.previousHistoricalPathCount = historicalPath.count
        self.previousPredictedPathCount = predictedPath.count
    }
    
    // Helper to add a new historical point and prune old ones
    mutating func addHistoricalPoint(_ point: SIMD3<Float>) {
        historicalPath.append(point)
        if historicalPath.count > maxPathLength {
            historicalPath.removeFirst(historicalPath.count - maxPathLength)
        }
    }
}

// MARK: - Custom System

@available(visionOS 1.0, *)
struct TrajectoryVisualizationSystem: System {
    static let query = EntityQuery(where: .has(TrajectoryComponent.self))

    private static let historicalPathVisualizerName = "HistoricalPathVisualizer"
    private static let predictedPathVisualizerName = "PredictedPathVisualizer"

    init(scene: Scene) {
        TrajectoryComponent.registerComponent()
        TrajectoryVisualizationSystem.registerSystem()
    }

    func update(context: SceneUpdateContext) {
        for entity in context.scene.performQuery(Self.query) {
            guard var trajectoryData = entity.components[TrajectoryComponent.self] else { continue }

            // MARK: - Historical Path Visualization
            var historicalModelEntity = entity.findEntity(named: Self.historicalPathVisualizerName) as? ModelEntity
            if historicalModelEntity == nil {
                historicalModelEntity = ModelEntity()
                historicalModelEntity?.name = Self.historicalPathVisualizerName
                entity.addChild(historicalModelEntity!)
            }
            
            if let visualizer = historicalModelEntity, !trajectoryData.historicalPath.isEmpty {
                // Regenerate mesh only if the number of points changed
                if trajectoryData.historicalPath.count != trajectoryData.previousHistoricalPathCount {
                    let historicalMesh = MeshResource.generateLine(
                        points: trajectoryData.historicalPath,
                        thickness: 0.005, // 5mm thickness
                        cornerRadius: 0.002 // Slightly rounded corners
                    )
                    let historicalMaterial = UnlitMaterial(color: .init(red: 0.0, green: 0.8, blue: 0.0, alpha: 1.0)) // Green
                    visualizer.model = ModelComponent(mesh: historicalMesh, materials: [historicalMaterial])
                    trajectoryData.previousHistoricalPathCount = trajectoryData.historicalPath.count
                    entity.components.set(trajectoryData) // Update component back to entity
                }
            } else if let visualizer = historicalModelEntity, trajectoryData.historicalPath.isEmpty {
                // Remove model component if path is empty
                visualizer.model = nil
            }

            // MARK: - Predicted Path Visualization
            var predictedModelEntity = entity.findEntity(named: Self.predictedPathVisualizerName) as? ModelEntity
            if predictedModelEntity == nil {
                predictedModelEntity = ModelEntity()
                predictedModelEntity?.name = Self.predictedPathVisualizerName
                entity.addChild(predictedModelEntity!)
            }
            
            if let visualizer = predictedModelEntity, !trajectoryData.predictedPath.isEmpty {
                // Regenerate mesh only if the number of points changed
                if trajectoryData.predictedPath.count != trajectoryData.previousPredictedPathCount {
                    // For a dashed line, we generate multiple small line segments
                    var dashedLinePoints: [SIMD3<Float>] = []
                    let segmentLength: Float = 0.03 // 3cm segment
                    let gapLength: Float = 0.02 // 2cm gap
                    let thickness: Float = 0.003 // 3mm thickness

                    for i in 0..<(trajectoryData.predictedPath.count - 1) {
                        let startPoint = trajectoryData.predictedPath[i]
                        let endPoint = trajectoryData.predictedPath[i+1]
                        let direction = normalize(endPoint - startPoint)
                        let totalDistance = distance(startPoint, endPoint)
                        
                        var currentDistance: Float = 0
                        while currentDistance < totalDistance {
                            let segmentStart = startPoint + direction * currentDistance
                            let segmentEnd = startPoint + direction * min(currentDistance + segmentLength, totalDistance)
                            
                            dashedLinePoints.append(segmentStart)
                            dashedLinePoints.append(segmentEnd)
                            
                            currentDistance += segmentLength + gapLength
                        }
                    }

                    let predictedMesh = MeshResource.generateLines(
                        points: dashedLinePoints,
                        thickness: thickness,
                        cornerRadius: 0.001
                    )
                    // Translucent blue for predicted path
                    let predictedMaterial = UnlitMaterial(color: .init(red: 0.0, green: 0.0, blue: 1.0, alpha: 0.6))
                    visualizer.model = ModelComponent(mesh: predictedMesh, materials: [predictedMaterial])
                    trajectoryData.previousPredictedPathCount = trajectoryData.predictedPath.count
                    entity.components.set(trajectoryData) // Update component back to entity
                }
            } else if let visualizer = predictedModelEntity, trajectoryData.predictedPath.isEmpty {
                // Remove model component if path is empty
                visualizer.model = nil
            }
        }
    }
}

// MARK: - Simulation in ContentView

@available(visionOS 1.0, *)
struct ContentView: View {
    @State private var arView: ARView?
    @State private var agvPosition: SIMD3<Float> = [0, 0, -0.5]
    @State private var updateTimer: Timer?

    var body: some View {
        RealityView { content in
            let arView = ARView(frame: .zero)
            self.arView = arView

            TrajectoryComponent.registerComponent()
            TrajectoryVisualizationSystem.registerSystem()
            
            let anchor = AnchorEntity()
            content.add(anchor)

            // Create an entity for the AGV/robot (e.g., a small cube)
            let agvEntity = ModelEntity(mesh: .generateBox(size: 0.05), materials: [SimpleMaterial(color: .purple, isMetallic: false)])
            agvEntity.position = agvPosition
            agvEntity.name = "AGV"
            anchor.addChild(agvEntity)
            
            // Add the TrajectoryComponent
            agvEntity.components.set(TrajectoryComponent())
            
            content.add(arView.scene)
            
            // Start simulation timer
            startSimulationTimer(for: agvEntity)

        } update: { content in
            // RealityKit systems run automatically.
        }
        .onDisappear {
            updateTimer?.invalidate()
            updateTimer = nil
        }
    }
    
    private func startSimulationTimer(for agvEntity: Entity) {
        updateTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
            guard let arView = arView,
                  let anchor = arView.scene.anchors.first,
                  let agv = anchor.findEntity(named: "AGV"),
                  var trajectoryData = agv.components[TrajectoryComponent.self] else { return }

            // Simulate AGV movement
            let newX = sin(Float(Date().timeIntervalSinceReferenceDate) * 0.5) * 0.2
            let newY = cos(Float(Date().timeIntervalSinceReferenceDate) * 0.3) * 0.1
            let newZ = -0.5 + sin(Float(Date().timeIntervalSinceReferenceDate) * 0.7) * 0.1
            agvPosition = [newX, newY, newZ]
            agv.position = agvPosition

            // Update historical path
            trajectoryData.addHistoricalPoint(agvPosition)

            // Generate new predicted path (e.g., a straight line into the future)
            var newPredictedPath: [SIMD3<Float>] = []
            let predictionLength = 5 // Number of future points
            let stepSize: Float = 0.05 // Distance per step
            let currentDirection = normalize(agvPosition - (trajectoryData.historicalPath.count > 1 ? trajectoryData.historicalPath[trajectoryData.historicalPath.count - 2] : agvPosition))
            
            for i in 1...predictionLength {
                newPredictedPath.append(agvPosition + currentDirection * stepSize * Float(i))
            }
            trajectoryData.predictedPath = newPredictedPath

            // Update the component on the entity
            agv.components.set(trajectoryData)
        }
    }
}
