
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, *)
import SwiftUI
import AppleIntelligence

// Assume SummarizationService is an actor or a class that uses async/await internally
actor AIService {
    func summarize(text: String) async throws -> String {
        // Simulate LLM call
        try await Task.sleep(for: .seconds(2))
        return "Summary of: \(text.prefix(50))..."
    }
}

@Observable // Makes this class observable by SwiftUI views
class ContentViewModel {
    var originalText: String = ""
    var summary: String = "No summary yet."
    var isLoading: Bool = false
    private let aiService = AIService() // Inject or create your AI service

    func performSummarization() async {
        guard !originalText.isEmpty else {
            summary = "Please enter text to summarize."
            return
        }

        isLoading = true
        summary = "Summarizing..."
        do {
            let generatedSummary = try await aiService.summarize(text: originalText)
            self.summary = generatedSummary // UI will update automatically
        } catch {
            self.summary = "Error: \(error.localizedDescription)"
        }
        isLoading = false
    }
}

@available(iOS 18.0, *)
struct SummarizationView: View {
    @State private var viewModel = ContentViewModel()

    var body: some View {
        VStack(spacing: 20) {
            TextEditor(text: $viewModel.originalText)
                .frame(height: 150)
                .border(Color.gray, width: 1)
                .padding()

            Button("Summarize") {
                Task {
                    await viewModel.performSummarization()
                }
            }
            .disabled(viewModel.isLoading || viewModel.originalText.isEmpty)

            if viewModel.isLoading {
                ProgressView()
            } else {
                Text(viewModel.summary)
                    .font(.body)
                    .padding()
            }
        }
        .navigationTitle("AI Summarization")
    }
}
