/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// lib/universal-app-script.ts

/**
 * ============================================================================
 * 1. TYPE DEFINITIONS & STATE MANAGEMENT
 * ============================================================================
 * Defines the Graph State (shared context) and the atomic units of execution.
 */

// The Graph State acts as the single source of truth passed between nodes.
export interface AppState {
  request: {
    endpoint: string;
    method: 'GET' | 'POST';
    platform: 'web' | 'ios' | 'android';
  };
  result: any | null;
  cacheKey: string | null;
  logs: string[];
  nextNode: string | null; // Used by Conditional Edge
}

// The Thought-Action-Observation triple structure.
export interface ReActStep {
  thought: string;
  action: {
    name: string;
    input: Record<string, any>;
  };
  observation?: string;
}

/**
 * ============================================================================
 * 2. WORKER AGENTS (Specialized Handlers)
 * ============================================================================
 * Each worker handles a specific domain: Web Caching, Native Storage, or API Fetching.
 */

class WebCacheWorker {
  /**
   * Simulates a web-specific caching mechanism (e.g., Redis or Next.js Data Cache).
   * @param key - The cache identifier.
   */
  async execute(key: string): Promise<any> {
    console.log(`[WebCacheWorker] Checking cache for: ${key}`);
    // Simulate cache hit
    return { source: 'web-cache', data: { id: 1, title: 'Cached Web Data' } };
  }
}

class NativeStorageWorker {
  /**
   * Simulates native device storage access (AsyncStorage/SecureStore).
   * This logic would typically be platform-gated in a universal app.
   */
  async execute(key: string): Promise<any> {
    console.log(`[NativeStorageWorker] Accessing native storage for: ${key}`);
    // Simulate native storage retrieval
    return { source: 'native-store', data: { id: 2, token: 'device_token_xyz' } };
  }
}

class ApiFetchWorker {
  /**
   * Performs the actual network request to the backend.
   * Handles timeouts and error parsing.
   */
  async execute(endpoint: string, method: string): Promise<any> {
    console.log(`[ApiFetchWorker] Fetching ${method} ${endpoint}`);
    // Simulate network latency
    await new Promise((r) => setTimeout(r, 500));
    return { source: 'api', data: { id: 3, message: 'Fresh data from server' } };
  }
}

/**
 * ============================================================================
 * 3. SUPERVISOR NODE (The Orchestrator)
 * ============================================================================
 * Uses an LLM-style prompt to analyze state and route tasks.
 */

class SupervisorNode {
  private workers = {
    webCache: new WebCacheWorker(),
    nativeStorage: new NativeStorageWorker(),
    apiFetch: new ApiFetchWorker(),
  };

  /**
   * The "Advanced Application Script" logic.
   * Analyzes the Graph State to determine the next action.
   * In a real scenario, this would call an LLM (e.g., GPT-4) with the state.
   */
  async analyzeAndRoute(state: AppState): Promise<ReActStep> {
    const { request, cacheKey } = state;
    
    // Simulated LLM Reasoning
    let thought = "";
    let actionName = "";
    let actionInput = {};

    if (request.platform === 'web' && cacheKey) {
      thought = "Platform is Web and a cache key exists. Check Web Cache first.";
      actionName = "webCache";
      actionInput = { key: cacheKey };
    } else if (request.platform !== 'web' && cacheKey) {
      thought = "Platform is Native (iOS/Android). Check Native Storage first.";
      actionName = "nativeStorage";
      actionInput = { key: cacheKey };
    } else {
      thought = "No cache available or cache key missing. Fallback to API Fetch.";
      actionName = "apiFetch";
      actionInput = { endpoint: request.endpoint, method: request.method };
    }

    return {
      thought,
      action: { name: actionName, input: actionInput },
    };
  }

  /**
   * Executes the chosen worker based on the Supervisor's decision.
   */
  async executeWorker(step: ReActStep): Promise<any> {
    const { name, input } = step.action;
    
    switch (name) {
      case 'webCache':
        return await this.workers.webCache.execute(input.key);
      case 'nativeStorage':
        return await this.workers.nativeStorage.execute(input.key);
      case 'apiFetch':
        return await this.workers.apiFetch.execute(input.endpoint, input.method);
      default:
        throw new Error(`Unknown worker: ${name}`);
    }
  }
}

/**
 * ============================================================================
 * 4. CONDITIONAL EDGE LOGIC
 * ============================================================================
 * Determines the flow of the graph based on the result.
 */

function conditionalRouter(state: AppState, result: any): string {
  // If we got data from cache or storage, we are done (End Node).
  if (result.source !== 'api') {
    console.log("[Conditional Edge] Data found in local storage. Routing to END.");
    return 'end_node';
  }

  // If we fetched from API, we might want to cache it next (Cache Node).
  if (result.source === 'api') {
    console.log("[Conditional Edge] Data fetched from API. Routing to CACHE.");
    return 'cache_node';
  }

  return 'error_node';
}

/**
 * ============================================================================
 * 5. THE MAIN ORCHESTRATOR (GRAPH EXECUTION ENGINE)
 * ============================================================================
 * Simulates the LangGraph execution loop.
 */

export class UniversalAppOrchestrator {
  private supervisor = new SupervisorNode();
  
  /**
   * The main entry point. This mimics a Next.js API Route handler or 
   * a React Native useEffect hook triggering a data sync.
   */
  async run(request: AppState['request']): Promise<AppState> {
    // Initialize Graph State
    let state: AppState = {
      request,
      result: null,
      cacheKey: request.platform === 'web' ? 'web_session_123' : 'native_token_456',
      logs: [],
      nextNode: 'supervisor',
    };

    console.log(`🚀 Starting Universal App Script for ${request.platform.toUpperCase()}...`);

    // Graph Execution Loop (Simulating LangGraph)
    while (state.nextNode !== 'end_node') {
      
      if (state.nextNode === 'supervisor') {
        // 1. Supervisor Analysis (Thought)
        const step = await this.supervisor.analyzeAndRoute(state);
        state.logs.push(`Supervisor Reasoning: ${step.thought}`);
        state.logs.push(`Action: ${step.action.name}`);

        // 2. Execute Worker (Action)
        const observation = await this.supervisor.executeWorker(step);
        state.result = observation;
        state.logs.push(`Observation: ${JSON.stringify(observation)}`);

        // 3. Conditional Edge (Routing)
        const next = conditionalRouter(state, observation);
        state.nextNode = next;
      } 
      
      else if (state.nextNode === 'cache_node') {
        // In a real graph, we would have a dedicated Cache Writer node here.
        // For this demo, we simulate writing back to the cache.
        console.log("[Cache Node] Writing fresh API data to local storage...");
        state.logs.push("Cache Node: Data persisted to local storage.");
        state.nextNode = 'end_node';
      }
      
      else {
        console.error("Unknown state or error occurred.");
        state.nextNode = 'end_node';
      }
    }

    console.log("🏁 Execution Complete.");
    return state;
  }
}

/**
 * ============================================================================
 * 6. USAGE EXAMPLE (Simulating a Next.js API Route)
 * ============================================================================
 */

// Example 1: Web Request (Should hit Web Cache)
const webOrchestrator = new UniversalAppOrchestrator();
webOrchestrator.run({ 
  endpoint: '/api/users', 
  method: 'GET', 
  platform: 'web' 
}).then((finalState) => {
  console.log('\n--- Final State (Web) ---');
  console.log(finalState.logs);
  console.log('Result:', finalState.result);
});

// Example 2: iOS Request (Should hit Native Storage)
const iosOrchestrator = new UniversalAppOrchestrator();
iosOrchestrator.run({ 
  endpoint: '/api/users', 
  method: 'GET', 
  platform: 'ios' 
}).then((finalState) => {
  console.log('\n--- Final State (iOS) ---');
  console.log(finalState.logs);
  console.log('Result:', finalState.result);
});
