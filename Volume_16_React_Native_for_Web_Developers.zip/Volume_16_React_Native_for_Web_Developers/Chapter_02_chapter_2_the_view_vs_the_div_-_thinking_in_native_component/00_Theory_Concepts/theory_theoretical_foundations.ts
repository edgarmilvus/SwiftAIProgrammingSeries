/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// WEB MENTALITY (Imperative Data Fetching)
// We often fetch inside a useEffect or on mount, causing layout shifts.
// const DivComponent = () => {
//   const [data, setData] = useState(null);
//   useEffect(() => {
//     fetch('/api/data').then(res => setData(res));
//   }, []);
//   return <div>{data ? data.title : 'Loading...'}</div>;
// };

// REACT NATIVE MENTALITY (Declarative Data Fetching in SCs)
// The View is populated with data fetched on the server before it ever reaches the device.
// This ensures the View has dimensions and content immediately, preventing jank.
// This is the "Universal App" approach.

// Server Component (runs on server/edge)
async function UserProfileView() {
  // 1. Data Fetching in SCs: Fetch happens here.
  const user = await fetchUserFromDatabase(); 
  
  // 2. The View is constructed with data.
  // Note: We are not using <div>, we are using <View>.
  return (
    <View style={styles.container}>
      <View style={styles.avatarContainer}>
        {/* Image component would map to native image views */}
        <Image source={{ uri: user.avatarUrl }} />
      </View>
      <View style={styles.textContainer}>
        <Text>{user.name}</Text>
        <Text>{user.bio}</Text>
      </View>
    </View>
  );
}
