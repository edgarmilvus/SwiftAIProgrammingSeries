
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import AppIntents
import Foundation

// MARK: - Recipe Data Structures and Errors

struct RecipeDetails: Codable, Hashable {
    let title: String
    let ingredients: [String]
    let instructions: String
}

enum RecipeError: Error, CustomLocalizedStringResourceConvertible {
    case notFound
    case searchFailed // Added for completeness

    var localizedStringResource: LocalizedStringResource {
        switch self {
        case .notFound:
            return "Recipe not found."
        case .searchFailed:
            return "Recipe search failed. Please try again."
        }
    }
}

// MARK: - Mock Recipe Data Source (for simulation)
// In a real app, this would be fetched from a database or API.
fileprivate let mockRecipes: [RecipeDetails] = [
    .init(title: "Spaghetti Carbonara",
          ingredients: ["200g spaghetti", "100g pancetta", "2 large eggs", "50g Pecorino Romano cheese", "Black pepper"],
          instructions: "1. Cook spaghetti. 2. Fry pancetta until crispy. 3. Whisk eggs with grated cheese and pepper. 4. Combine hot spaghetti with pancetta, then quickly stir in egg mixture to create a creamy sauce."),
    .init(title: "Chicken Curry",
          ingredients: ["500g chicken breast", "1 onion", "2 cloves garlic", "1 tbsp ginger", "2 tbsp curry paste", "400ml coconut milk", "Rice for serving"],
          instructions: "1. Sauté onion, garlic, ginger. 2. Add chicken and cook until browned. 3. Stir in curry paste. 4. Pour in coconut milk and simmer until chicken is cooked through. 5. Serve with rice."),
    .init(title: "Tomato Soup",
          ingredients: ["1kg ripe tomatoes", "1 onion", "2 cloves garlic", "500ml vegetable broth", "Basil"],
          instructions: "1. Sauté onion and garlic. 2. Add chopped tomatoes and broth, simmer. 3. Blend until smooth. 4. Season and garnish with basil.")
]

// MARK: - Search Recipes Intent

@available(iOS 18.0, *)
struct SearchRecipesIntent: AppIntent {
    static var intentDisplayName: LocalizedStringResource = "Search Recipes"
    static var description: LocalizedStringResource = "Searches for recipes by a given keyword and returns matching titles."

    @Parameter(title: "Keyword", description: "The term to search for in recipe titles or ingredients.")
    var keyword: String

    static var parameterSummary: some ParameterSummary {
        Summary("Search recipes for \((\.$keyword))")
    }

    func perform() async throws -> some IntentResult & ReturnsValue<[String]> {
        let matchingTitles = mockRecipes
            .filter { $0.title.localizedCaseInsensitiveContains(keyword) || $0.ingredients.joined(separator: " ").localizedCaseInsensitiveContains(keyword) }
            .map { $0.title }

        if matchingTitles.isEmpty {
            // Optionally throw an error if no results, or return empty array as specified
            // For this exercise, returning an empty array is fine for "no match"
            return .result(
                value: [],
                dialog: "No recipes found matching '\(keyword)'."
            )
        }

        return .result(
            value: matchingTitles,
            dialog: "Found \(matchingTitles.count) recipes matching '\(keyword)'."
        )
    }
}

// MARK: - Get Recipe Details Intent

@available(iOS 18.0, *)
struct GetRecipeDetailsIntent: AppIntent {
    static var intentDisplayName: LocalizedStringResource = "Get Recipe Details"
    static var description: LocalizedStringResource = "Retrieves the full details (ingredients, instructions) for a specific recipe."

    @Parameter(title: "Recipe Title", description: "The exact title of the recipe to retrieve details for.")
    var recipeTitle: String

    static var parameterSummary: some ParameterSummary {
        Summary("Get details for \((\.$recipeTitle))")
    }

    func perform() async throws -> some IntentResult & ReturnsValue<RecipeDetails> {
        guard let recipe = mockRecipes.first(where: { $0.title.localizedCaseInsensitiveCompare(recipeTitle) == .orderedSame }) else {
            throw RecipeError.notFound
        }

        return .result(
            value: recipe,
            dialog: "Here are the details for \(recipe.title)."
        )
    }
}

// MARK: - App Shortcuts Provider

@available(iOS 18.0, *)
struct MyRecipesAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: SearchRecipesIntent(),
            phrases: [
                "Search for \(\.$keyword) recipes",
                "Find recipes with \(\.$keyword)"
            ],
            shortTitle: "Search Recipes",
            systemImageName: "magnifyingglass"
        )
        AppShortcut(
            intent: GetRecipeDetailsIntent(),
            phrases: [
                "Show details for \(\.$recipeTitle)",
                "What are the ingredients for \(\.$recipeTitle)"
            ],
            shortTitle: "Get Recipe Details",
            systemImageName: "menucard"
        )
    }
}
