/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Text, Dimensions } from 'react-native';
import { Accelerometer } from 'expo-sensors';

const { width, height } = Dimensions.get('window');
const BALL_SIZE = 20;
const TARGET_SIZE = 100;

export default function SteadyHandGame() {
  const [ballPos, setBallPos] = useState({ x: width / 2, y: height / 2 });
  const [isPlaying, setIsPlaying] = useState(true);
  const [timer, setTimer] = useState(0);
  const [gameStatus, setGameStatus] = useState<'playing' | 'won'>('playing');

  // TODO: Implement game loop using useEffect
  // TODO: Read Accelerometer data
  // TODO: Update ball position based on tilt
  // TODO: Check if ball is inside target zone (center of screen)
  // TODO: Update timer or reset logic

  return (
    <View style={styles.container}>
      <Text>Steady Hand Challenge</Text>
      <Text>Time: {timer.toFixed(2)}s</Text>
      <View style={styles.gameArea}>
        <View style={styles.targetZone} />
        <View style={[styles.ball, { left: ballPos.x, top: ballPos.y }]} />
      </View>
      {gameStatus === 'won' && <Text style={styles.winText}>You Win!</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  gameArea: { width: width - 40, height: height / 2, backgroundColor: '#eee', position: 'relative' },
  targetZone: { 
    position: 'absolute', 
    width: TARGET_SIZE, 
    height: TARGET_SIZE, 
    borderRadius: TARGET_SIZE / 2, 
    backgroundColor: 'rgba(0,255,0,0.3)', 
    left: (width - 40) / 2 - TARGET_SIZE / 2, 
    top: (height / 2) / 2 - TARGET_SIZE / 2 
  },
  ball: { 
    position: 'absolute', 
    width: BALL_SIZE, 
    height: BALL_SIZE, 
    borderRadius: BALL_SIZE / 2, 
    backgroundColor: 'red' 
  },
  winText: { fontSize: 24, color: 'green', marginTop: 20, fontWeight: 'bold' }
});
