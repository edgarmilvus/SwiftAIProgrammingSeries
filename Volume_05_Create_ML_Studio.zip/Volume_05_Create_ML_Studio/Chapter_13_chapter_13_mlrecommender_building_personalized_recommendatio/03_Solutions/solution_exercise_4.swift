
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import CreateML
import CoreML

// MARK: - Data Schema and Generation

// Represents a single user listening event
struct PodcastInteraction: Codable {
    let userID: String
    let episodeID: String
    let podcastID: String
    let listenDuration: Double // Implicit feedback (e.g., seconds listened)
    let explicitLike: Int?    // Explicit feedback (1 for like, 0 for dislike, nil if not provided)
    let timestamp: Date
}

// Helper to generate initial and new interaction data
class PodcastDataGenerator {
    private var allInteractions: [PodcastInteraction] = []
    private var nextEpisodeIndex = 1
    private var nextPodcastIndex = 1

    let users = (1...10).map { "user\($0)" }
    var podcasts: [String] = []
    var episodes: [String: [String]] = [:] // podcastID -> [episodeIDs]

    init() {
        // Initial set of podcasts and episodes
        for _ in 1...5 { // 5 podcasts initially
            let podcastID = "podcast\(nextPodcastIndex)"
            podcasts.append(podcastID)
            episodes[podcastID] = []
            for _ in 1...5 { // 5 episodes per podcast
                let episodeID = "episode\(nextEpisodeIndex)"
                episodes[podcastID]?.append(episodeID)
                nextEpisodeIndex += 1
            }
            nextPodcastIndex += 1
        }
    }

    func generateInitialInteractions(count: Int) -> [PodcastInteraction] {
        var initialData: [PodcastInteraction] = []
        for _ in 0..<count {
            if let user = users.randomElement(),
               let podcast = podcasts.randomElement(),
               let episode = episodes[podcast]?.randomElement() {
                let duration = Double.random(in: 30...3600) // 30 seconds to 1 hour
                let like: Int? = Bool.random() ? (duration > 1800 ? 1 : 0) : nil // More likely to like if listened long
                initialData.append(PodcastInteraction(userID: user, episodeID: episode, podcastID: podcast, listenDuration: duration, explicitLike: like, timestamp: Date()))
            }
        }
        allInteractions.append(contentsOf: initialData)
        return initialData
    }

    func generateNewInteractions(count: Int) -> [PodcastInteraction] {
        var newData: [PodcastInteraction] = []
        // Simulate new episodes being added
        if nextEpisodeIndex % 10 == 0 { // Every 10 new interactions, add a new episode
            let podcastID = podcasts.randomElement()!
            let newEpisodeID = "episode\(nextEpisodeIndex)"
            episodes[podcastID]?.append(newEpisodeID)
            print("Added new episode: \(newEpisodeID) to \(podcastID)")
        }
        if nextPodcastIndex % 2 == 0 { // Every 20 new interactions, add a new podcast
             let newPodcastID = "podcast\(nextPodcastIndex)"
             podcasts.append(newPodcastID)
             episodes[newPodcastID] = []
             for _ in 1...3 { // 3 episodes for new podcast
                 let newEpisodeID = "episode\(nextEpisodeIndex)"
                 episodes[newPodcastID]?.append(newEpisodeID)
                 nextEpisodeIndex += 1
             }
             nextPodcastIndex += 1
             print("Added new podcast: \(newPodcastID)")
        }

        for _ in 0..<count {
            if let user = users.randomElement(),
               let podcast = podcasts.randomElement(),
               let episode = episodes[podcast]?.randomElement() {
                let duration = Double.random(in: 30...3600)
                let like: Int? = Bool.random() ? (duration > 1800 ? 1 : 0) : nil
                newData.append(PodcastInteraction(userID: user, episodeID: episode, podcastID: podcast, listenDuration: duration, explicitLike: like, timestamp: Date()))
            }
        }
        allInteractions.append(contentsOf: newData)
        return newData
    }

    func getAllInteractionsAsMLDataTable() throws -> MLDataTable {
        let userIDs = allInteractions.map { $0.userID }
        let episodeIDs = allInteractions.map { $0.episodeID }
        let podcastIDs = allInteractions.map { $0.podcastID }
        let listenDurations = allInteractions.map { $0.listenDuration }
        let explicitLikes = allInteractions.map { $0.explicitLike }

        var dictionary: [String: MLDataValueConvertible] = [
            "userID": userIDs,
            "episodeID": episodeIDs,
            "podcastID": podcastIDs,
            "listenDuration": listenDurations
        ]
        // Only add explicitLike if it's consistently present or handled as optional in MLDataTable
        // For simplicity, we'll use listenDuration as the primary rating for this exercise.
        // If explicitLike was always present, it could be used too.
        // dictionary["explicitLike"] = explicitLikes // If all are non-nil Int, otherwise needs careful handling

        return try MLDataTable(dictionary: dictionary)
    }
}

// MARK: - Model Training and Update Mechanism

@available(iOS 18.0, macOS 15.0, *) // MLRecommenderBuilder might require newer OS versions for certain features or general availability
class PodcastRecommenderService {
    private var recommender: MLRecommender?
    private let modelDirectory: URL
    private let modelFileName = "PodPulseRecommender.mlmodel"
    private var currentModelURL: URL { modelDirectory.appendingPathComponent(modelFileName) }

    // Use a background actor for model operations to avoid blocking the main thread
    private actor RecommenderActor {
        var recommender: MLRecommender?
        let modelDirectory: URL
        let modelFileName: String
        var currentModelURL: URL { modelDirectory.appendingPathComponent(modelFileName) }

        init(modelDirectory: URL, modelFileName: String) {
            self.modelDirectory = modelDirectory
            self.modelFileName = modelFileName
        }

        func loadModel() async throws -> MLRecommender {
            print("RecommenderActor: Attempting to load model from \(currentModelURL.lastPathComponent)")
            guard FileManager.default.fileExists(atPath: currentModelURL.path) else {
                throw NSError(domain: "PodcastRecommenderService", code: 404, userInfo: [NSLocalizedDescriptionKey: "Model file not found at \(currentModelURL.lastPathComponent)"])
            }
            let compiledModelURL = try MLModel.compileModel(at: currentModelURL)
            let loadedRecommender = try MLRecommender(contentsOf: compiledModelURL)
            self.recommender = loadedRecommender
            print("RecommenderActor: Model loaded successfully.")
            return loadedRecommender
        }

        func retrainAndSaveRecommender(with newData: MLDataTable) async throws {
            print("RecommenderActor: Initiating model retraining...")
            let builder = MLRecommenderBuilder(trainingData: newData,
                                                 userIdentifierColumn: "userID",
                                                 itemIdentifierColumn: "episodeID",
                                                 ratingColumn: "listenDuration") // Using listenDuration as implicit strength
            let newModel = try builder.build()
            try newModel.write(to: currentModelURL)
            self.recommender = newModel // Update the in-memory model
            print("RecommenderActor: MLRecommender model successfully retrained and saved to: \(currentModelURL.lastPathComponent)")
        }

        func getRecommender() -> MLRecommender? {
            return recommender
        }
    }

    private let recommenderActor: RecommenderActor

    init() {
        self.modelDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        self.recommenderActor = RecommenderActor(modelDirectory: modelDirectory, modelFileName: modelFileName)
        // Attempt to load model on initialization, possibly in background
        Task {
            try? await recommenderActor.loadModel()
        }
    }

    /// Trains an initial model or retrains an existing one with new data.
    func retrainModel(with allInteractionData: MLDataTable) async throws {
        // This function runs on a background actor
        try await recommenderActor.retrainAndSaveRecommender(with: allInteractionData)
        // After retraining, ensure the main service's recommender reference is updated if needed,
        // or just rely on the actor's internal state. For simplicity, we'll always query via actor.
    }

    /// Provides podcast recommendations for a user.
    /// If an episodeID is provided, it gives item-to-item suggestions; otherwise, user-to-item.
    func getPodcastRecommendations(for userID: String, afterEpisode episodeID: String? = nil, count: Int = 5) async -> [String] {
        guard let currentRecommender = await recommenderActor.getRecommender() else {
            print("Recommender model not available. Cannot provide recommendations.")
            return []
        }

        do {
            var recommendations: MLDataTable
            if let episode = episodeID {
                print("Getting item-to-item recommendations for user \(userID), similar to episode \(episode)...")
                recommendations = try currentRecommender.recommendations(forItems: [episode], k: count)
            } else {
                print("Getting user-to-item recommendations for user \(userID)...")
                recommendations = try currentRecommender.recommendations(forUsers: [userID], k: count)
            }

            let recommendedEpisodeIDs = recommendations["episodeID"]
                .map { $0.map { $0.stringValue ?? "" } } ?? []
            
            // Filter out the input episode itself if it appears in item-to-item recommendations
            return recommendedEpisodeIDs.filter { $0 != episodeID }

        } catch {
            print("Error getting podcast recommendations: \(error)")
            return []
        }
    }
}

// MARK: - Example Usage

func runExercise3() async {
    print("--- Running Exercise 3: Dynamic Podcast Suggestions & On-Device Model Updates ---")

    let dataGenerator = PodcastDataGenerator()
    let recommenderService = PodcastRecommenderService()

    // 1. Initial Model Training
    let initialInteractions = dataGenerator.generateInitialInteractions(count: 100)
    print("Generated \(initialInteractions.count) initial interactions.")
    let initialDataTable = try! dataGenerator.getAllInteractionsAsMLDataTable()
    do {
        print("Performing initial model training...")
        try await recommenderService.retrainModel(with: initialDataTable)
    } catch {
        print("Initial model training failed: \(error)")
        return
    }

    // Give some time for the model to load in the actor
    try? await Task.sleep(for: .seconds(1))

    // 4. Runtime Model Loading and Initial Recommendations
    let testUser = dataGenerator.users.first!
    let initialRecommendations = await recommenderService.getPodcastRecommendations(for: testUser, count: 3)
    print("\nInitial recommendations for \(testUser): \(initialRecommendations)")

    let testEpisode = initialInteractions.randomElement()?.episodeID
    if let testEpisode = testEpisode {
        let similarEpisodeRecommendations = await recommenderService.getPodcastRecommendations(for: testUser, afterEpisode: testEpisode, count: 2)
        print("Recommendations similar to \(testEpisode): \(similarEpisodeRecommendations)")
    }

    // 3. Dynamic Update Mechanism - Simulate new data and retraining
    print("\n--- Simulating new user interactions and on-device retraining ---")
    for i in 1...3 {
        print("\nRetraining cycle \(i)...")
        let newInteractions = dataGenerator.generateNewInteractions(count: 50)
        print("Generated \(newInteractions.count) new interactions.")
        let latestDataTable = try! dataGenerator.getAllInteractionsAsMLDataTable()

        do {
            print("Retraining model with \(latestDataTable.rows.count) total interactions...")
            try await recommenderService.retrainModel(with: latestDataTable)
            print("Model retrained. Providing updated recommendations.")
            let updatedRecommendations = await recommenderService.getPodcastRecommendations(for: testUser, count: 3)
            print("Updated recommendations for \(testUser): \(updatedRecommendations)")
        } catch {
            print("Retraining failed: \(error)")
        }
        try? await Task.sleep(for: .seconds(2)) // Simulate time passing
    }

    print("--- Exercise 3 Finished ---\n")
}

// Call the async function to run the exercise
Task {
    await runExercise3()
}
