
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import CoreMotion // CMAccelerometerData is NOT Sendable by default

// Custom struct to hold sensor data that IS Sendable
struct SensorDataPoint: Sendable {
    let x: Double
    let y: Double
    let z: Double
    let timestamp: TimeInterval // Use TimeInterval for simplicity

    init(accelerometerData: CMAccelerometerData) {
        self.x = accelerometerData.acceleration.x
        self.y = accelerometerData.acceleration.y
        self.z = accelerometerData.acceleration.z
        self.timestamp = accelerometerData.timestamp
    }

    init(gyroData: CMGyroData) {
        self.x = gyroData.rotationRate.x
        self.y = gyroData.rotationRate.y
        self.z = gyroData.rotationRate.z
        self.timestamp = gyroData.timestamp
    }
}

// Now, a window of these points can be Sendable
struct SensorDataWindow: Sendable {
    let accelerometerPoints: [SensorDataPoint]
    let gyroscopePoints: [SensorDataPoint]
    let windowStartTime: TimeInterval
}

@available(iOS 18.0, *)
actor ActivityClassifierActor {
    // ... (previous actor code) ...

    // This method now accepts Sendable data
    func performClassification(window: SensorDataWindow) async throws -> String {
        // Convert SensorDataWindow to MLMultiArray or expected input format for MLActivityClassifier
        // let input = try await convertToMLInput(window)
        // let prediction = try await classifier.prediction(input: input)
        // return prediction.activityLabel

        try await Task.sleep(for: .milliseconds(50))
        let randomActivity = ["Walking", "Running", "Standing", "Sitting"].randomElement()!
        return randomActivity
    }
}
