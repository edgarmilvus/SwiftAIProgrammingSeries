/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// File: components/ProjectsDashboard.tsx
// Framework: React Native Web / Next.js
// Dependencies: @tanstack/react-query

import React, { useState, useEffect } from 'react';
import { 
  useQuery, 
  useQueryClient, 
  onlineManager, 
  focusManager,
  QueryClient,
  QueryClientProvider
} from '@tanstack/react-query';

// ==========================================
// 1. Types & Interfaces
// ==========================================

/**
 * Represents a single Project entity in our SaaS application.
 */
interface Project {
  id: string;
  name: string;
  status: 'active' | 'archived';
  lastUpdated: string;
}

/**
 * Standardized API Response structure.
 */
interface ApiResponse<T> {
  data: T;
  timestamp: number;
}

// ==========================================
// 2. Mock API Layer (Simulating Async Processing)
// ==========================================

/**
 * Simulates a network request to a backend.
 * In a real app, this would be `fetch('/api/projects')`.
 * We introduce artificial latency and random failures to test resilience.
 */
const fetchProjects = async (): Promise<Project[]> => {
  // Simulate network latency (500ms - 1500ms)
  await new Promise(resolve => setTimeout(resolve, 800));

  // Simulate random network failure (10% chance)
  if (Math.random() < 0.1) {
    throw new Error('Network Error: Failed to fetch projects');
  }

  // Mock data return
  const mockData: Project[] = [
    { id: '1', name: 'Project Alpha', status: 'active', lastUpdated: new Date().toISOString() },
    { id: '2', name: 'Project Beta', status: 'archived', lastUpdated: new Date(Date.now() - 86400000).toISOString() },
    { id: '3', name: 'Project Gamma', status: 'active', lastUpdated: new Date().toISOString() },
  ];

  return mockData;
};

// ==========================================
// 3. Query Client Configuration (Offline Logic)
// ==========================================

/**
 * Configures the global Query Client instance.
 * 
 * UNDER THE HOOD:
 * - `staleTime`: Defines how long data is considered "fresh". 
 *   Mobile apps benefit from longer stale times (e.g., 5 minutes) to reduce data usage.
 * - `onlineManager`: Monitors `navigator.onLine`. If offline, queries will pause 
 *   execution and retry when connectivity returns.
 * - `focusManager`: Monitors window/tab focus. Refetches data when the user 
 *   returns to the app (vital for mobile backgrounding).
 */
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: 3, // Retry failed requests 3 times
      retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
    },
  },
});

// Helper to simulate online/offline toggling for demonstration purposes
const toggleOnlineStatus = () => {
  onlineManager.setOnline(window.navigator.onLine);
};

// Helper to simulate focus/blur events
const toggleFocusStatus = () => {
  focusManager.setFocused(document.hasFocus());
};

// ==========================================
// 4. UI Component: Projects Dashboard
// ==========================================

/**
 * The main dashboard component.
 * 
 * Features:
 * 1. Uses `useQuery` to fetch and cache project data.
 * 2. Handles Loading, Error, and Success states explicitly.
 * 3. Provides manual controls to simulate network fluctuation.
 */
const ProjectsDashboard: React.FC = () => {
  const queryClient = useQueryClient();
  
  // useQuery hook integration
  const { 
    data, 
    error, 
    isLoading, 
    isFetching, 
    refetch 
  } = useQuery<Project[], Error>({
    queryKey: ['projects'], // Unique key for caching
    queryFn: fetchProjects, // The async function to execute
  });

  // State to simulate network toggles for the demo
  const [isSimulatedOnline, setIsSimulatedOnline] = useState(true);

  // Effect to sync local simulation state with React Query's onlineManager
  useEffect(() => {
    onlineManager.setOnline(isSimulatedOnline);
  }, [isSimulatedOnline]);

  /**
   * Renders the status badge based on fetching state.
   */
  const renderStatus = () => {
    if (isLoading) return <span className="text-blue-600">Initial Load...</span>;
    if (isFetching) return <span className="text-orange-500">Syncing...</span>;
    return <span className="text-green-600">Up to date</span>;
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'system-ui, sans-serif', maxWidth: '600px', margin: '0 auto' }}>
      
      {/* Header & Network Controls */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', borderBottom: '1px solid #eee', paddingBottom: '10px' }}>
        <h1 style={{ margin: 0 }}>Project Dashboard</h1>
        <div style={{ fontSize: '0.85rem' }}>
          Status: {renderStatus()}
        </div>
      </div>

      <div style={{ marginBottom: '20px', padding: '10px', background: '#f0f4f8', borderRadius: '8px' }}>
        <p style={{ margin: '0 0 10px 0', fontWeight: 'bold' }}>Simulation Controls:</p>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button 
            onClick={() => {
              setIsSimulatedOnline(!isSimulatedOnline);
              toggleOnlineStatus();
            }}
            style={{ padding: '8px', cursor: 'pointer', background: isSimulatedOnline ? '#ef4444' : '#22c55e', color: 'white', border: 'none', borderRadius: '4px' }}
          >
            {isSimulatedOnline ? 'Simulate Offline' : 'Simulate Online'}
          </button>
          
          <button 
            onClick={() => toggleFocusStatus()} // Triggers focusManager listeners
            style={{ padding: '8px', cursor: 'pointer', background: '#6366f1', color: 'white', border: 'none', borderRadius: '4px' }}
          >
            Simulate App Focus
          </button>

          <button 
            onClick={() => refetch()} 
            style={{ padding: '8px', cursor: 'pointer', background: '#3b82f6', color: 'white', border: 'none', borderRadius: '4px' }}
            disabled={isFetching}
          >
            Manual Refetch
          </button>
        </div>
      </div>

      {/* Data Rendering Area */}
      <div>
        {isLoading && <div>Loading initial data...</div>}
        
        {error && (
          <div style={{ padding: '10px', background: '#fee2e2', color: '#991b1b', borderRadius: '4px', marginBottom: '10px' }}>
            <strong>Error:</strong> {error.message}
            <div style={{ marginTop: '5px', fontSize: '0.9em' }}>
              <em>Note: If you are "Offline", this error is expected until you toggle back Online.</em>
            </div>
          </div>
        )}

        {data && (
          <div style={{ display: 'grid', gap: '10px' }}>
            {data.map((project) => (
              <div 
                key={project.id} 
                style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '6px', background: 'white' }}
              >
                <div style={{ fontWeight: 'bold', fontSize: '1.1rem' }}>{project.name}</div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '5px', fontSize: '0.9rem', color: '#555' }}>
                  <span>Status: {project.status}</span>
                  <span>Updated: {new Date(project.lastUpdated).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Cache Inspection (Dev Tool) */}
      <div style={{ marginTop: '30px', padding: '10px', background: '#fafafa', border: '1px dashed #ccc', fontSize: '0.8rem' }}>
        <strong>Current Query Cache State:</strong>
        <pre style={{ whiteSpace: 'pre-wrap' }}>
          {JSON.stringify(queryClient.getQueryData(['projects']), null, 2)}
        </pre>
      </div>
    </div>
  );
};

// ==========================================
// 5. Wrapper Provider (For Next.js/Universal App)
// ==========================================

/**
 * Wraps the application with the QueryClientProvider.
 * This is required to make `useQuery` available throughout the component tree.
 * In a Universal App (Expo Web/Next.js), this wrapper is placed in `_app.tsx` or `layout.tsx`.
 */
export default function DashboardWrapper() {
  return (
    <QueryClientProvider client={queryClient}>
      <ProjectsDashboard />
    </QueryClientProvider>
  );
}
