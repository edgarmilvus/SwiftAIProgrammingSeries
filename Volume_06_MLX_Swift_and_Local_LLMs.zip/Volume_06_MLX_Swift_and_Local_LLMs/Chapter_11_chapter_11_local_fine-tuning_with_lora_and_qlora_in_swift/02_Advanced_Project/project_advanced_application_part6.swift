
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

import Foundation
import MLX
import MLXNN
import MLXNN_Optimizers

/// Custom error types for the fine-tuning process.
enum FineTunerError: Error {
    case modelInitializationFailed(String)
    case dataGenerationFailed(String)
    case trainingFailed(String)
    case parameterSerializationFailed(String)
    case parameterDeserializationFailed(String)
    case fileOperationFailed(String)
}

/// An actor responsible for orchestrating the LoRA fine-tuning process
/// for the `SimpleDocumentClassifier`.
@available(iOS 18.0, macOS 14.0, visionOS 1.0, *)
actor DocumentFineTuner {
    private var model: SimpleDocumentClassifier
    private var optimizer: Adam
    private let learningRate: Float
    private let batchSize: Int
    private let numEpochs: Int
    private let embeddingDimension: Int
    private let hiddenDimension: Int
    private let numClasses: Int
    private let loraRank: Int
    private let loraAlpha: Double
    private var randomKey: MLXRandom.Key

    /// Initializes the `DocumentFineTuner`.
    /// - Parameters:
    ///   - embeddingDimension: Dimension of document embeddings.
    ///   - hiddenDimension: Dimension of the hidden layer in the classifier.
    ///   - numClasses: Number of output classification categories.
    ///   - loraRank: The low rank `r` for the LoRA matrices.
    ///   - loraAlpha: Scaling factor for the LoRA output.
    ///   - learningRate: Learning rate for the Adam optimizer.
    ///   - batchSize: Batch size for training.
    ///   - numEpochs: Number of training epochs.
    ///   - seed: Random seed for reproducibility.
    init(embeddingDimension: Int, hiddenDimension: Int, numClasses: Int,
         loraRank: Int, loraAlpha: Double, learningRate: Float,
         batchSize: Int, numEpochs: Int, seed: UInt64 = 0) throws {
        self.embeddingDimension = embeddingDimension
        self.hiddenDimension = hiddenDimension
        self.numClasses = numClasses
        self.loraRank = loraRank
        self.loraAlpha = loraAlpha
        self.learningRate = learningRate
        self.batchSize = batchSize
        self.numEpochs = numEpochs
        self.randomKey = MLXRandom.Key(seed: seed)

        do {
            // Initialize the model. `key.split()` ensures different sub-modules get unique keys.
            self.model = SimpleDocumentClassifier(
                embeddingDimension: embeddingDimension,
                hiddenDimension: hiddenDimension,
                numClasses: numClasses,
                loraRank: loraRank,
                loraAlpha: loraAlpha,
                key: randomKey.split()
            )
            // Initialize the Adam optimizer.
            self.optimizer = Adam(learningRate: learningRate)
        } catch {
            throw FineTunerError.modelInitializationFailed("Failed to initialize model or optimizer: \(error.localizedDescription)")
        }
    }

    /// The core training function.
    /// It generates synthetic data, performs the fine-tuning loop,
    /// and updates only the LoRA adapter parameters.
    /// - Throws: `FineTunerError` if any training step fails.
    func fineTune() async throws {
        print("Starting LoRA fine-tuning for Smart Document Assistant...")
        print("  - Embedding Dim: \(embeddingDimension), Hidden Dim: \(hiddenDimension), Classes: \(numClasses)")
        print("  - LoRA Rank: \(loraRank), LoRA Alpha: \(loraAlpha)")
        print("  - Learning Rate: \(learningRate), Batch Size: \(batchSize), Epochs: \(numEpochs)")

        // --- 1. Generate Synthetic Data ---
        // Simulate a fine-tuning dataset with a slight domain shift (fineTuneBias).
        var currentKey = randomKey.split()
        let (trainEmbeddings, trainLabels) = generateSyntheticData(
            numSamples: 1000, // More samples for training
            embeddingDimension: embeddingDimension,
            numClasses: numClasses,
            fineTuneBias: 0.5, // Introduce a bias for fine-tuning
            key: currentKey.split()
        )
        currentKey = currentKey.split()
        print("Generated synthetic training data: \(trainEmbeddings.shape) embeddings, \(trainLabels.shape) labels.")

        // --- 2. Identify Trainable Parameters (LoRA Adapters Only) ---
        // MLX's functional API requires explicit parameter collection.
        // We only want the LoRA parameters for fine-tuning.
        let loraParameters = model.loraParameters()
        if loraParameters.isEmpty {
            throw FineTunerError.trainingFailed("No LoRA parameters found in the model to train.")
        }
        print("Identified \(loraParameters.count) LoRA parameters for training.")

        // --- 3. Define the Loss Function and Gradient Calculation ---
        // MLX uses `valueAndGradient` for efficient computation of loss and gradients.
        // The `lossFunction` is a closure that captures the model and returns the loss.
        let lossFunction = { (model: SimpleDocumentClassifier, inputs: MLXArray, targets: MLXArray) -> MLXArray in
            let logits = model(inputs)
            let loss = MLXNN.Loss.crossEntropy(logits: logits, targets: targets, reduction: .mean)
            return loss
        }

        // Create a `valueAndGradient` function specifically for the LoRA parameters.
        // This is where MLX's lazy evaluation comes into play: the computation graph
        // for the loss and its gradients is built, but not executed until `evaluate` is called.
        let valueAndGrad = MLX.valueAndGradient(lossFunction)

        // --- 4. Training Loop ---
        let numBatches = (trainEmbeddings.shape[0] + batchSize - 1) / batchSize
        print("Starting training for \(numEpochs) epochs with \(numBatches) batches per epoch...")

        for epoch in 0..<numEpochs {
            var epochLoss: Float = 0.0
            for i in 0..<numBatches {
                let start = i * batchSize
                let end = min((i + 1) * batchSize, trainEmbeddings.shape[0])
                let batchEmbeddings = trainEmbeddings[start..<end]
                let batchLabels = trainLabels[start..<end]

                // Perform the forward pass and compute gradients.
                // This is where the MLX computation graph is evaluated on the GPU/CPU.
                let (loss, gradients) = valueAndGrad(model, batchEmbeddings, batchLabels)

                // Update the model's LoRA parameters using the optimizer.
                // `optimizer.update` applies the gradients to the trainable parameters.
                // It returns a new set of parameters with the updates applied.
                let (updatedParameters, updatedOptimizerState) = optimizer.update(
                    parameters: model.parameters(), // Pass all model parameters
                    gradients: gradients,           // But gradients are only for LoRA params
                    state: optimizer.state
                )
                model.update(parameters: updatedParameters) // Apply updates to the model
                optimizer.state = updatedOptimizerState

                // Fetch the loss value from the MLXArray.
                // This triggers the computation of the loss if it hasn't been evaluated yet.
                let currentLoss = loss.item(Float.self)
                epochLoss += currentLoss

                if i % 50 == 0 {
                    print("  Epoch \(epoch + 1)/\(numEpochs), Batch \(i + 1)/\(numBatches), Loss: \(String(format: "%.4f", currentLoss))")
                }
            }
            print("Epoch \(epoch + 1) completed. Average Loss: \(String(format: "%.4f", epochLoss / Float(numBatches)))")
        }
        print("LoRA fine-tuning complete.")
    }

    /// Retrieves the current LoRA adapter parameters from the model.
    /// This is useful for saving only the fine-tuned adapter weights.
    /// - Returns: A dictionary of `MLXArray` parameters representing the LoRA adapters.
    func getLoRAAdapterParameters() -> [String: MLXArray] {
        var loraParams: [String: MLXArray] = [:]
        for (name, module) in model.namedModules() {
            if let loraAdapter = module as? LoRALinearAdapter {
                loraParams["\(name).loraA"] = loraAdapter.loraA
                loraParams["\(name).loraB"] = loraAdapter.loraB
            }
        }
        return loraParams
    }

    /// Saves the LoRA adapter parameters to a specified file URL.
    /// - Parameter url: The file URL to save the parameters to.
    /// - Throws: `FineTunerError` if serialization or file writing fails.
    func saveLoRAAdapterParameters(to url: URL) throws {
        let loraParams = getLoRAAdapterParameters()
        do {
            let data = try MLXArray.save(loraParams)
            try data.write(to: url)
            print("LoRA adapter parameters saved to: \(url.lastPathComponent)")
        } catch {
            throw FineTunerError.fileOperationFailed("Failed to save LoRA parameters to \(url.lastPathComponent): \(error.localizedDescription)")
        }
    }

    /// Loads LoRA adapter parameters from a specified file URL into the model.
    /// - Parameter url: The file URL to load the parameters from.
    /// - Throws: `FineTunerError` if file reading or deserialization fails.
    func loadLoRAAdapterParameters(from url: URL) throws {
        do {
            let data = try Data(contentsOf: url)
            let loadedParams = try MLXArray.load(data)

            // Iterate through the model's named parameters and update only the LoRA ones
            var updatedModelParams = model.parameters()
            var appliedCount = 0
            for (name, array) in loadedParams {
                if updatedModelParams.keys.contains(name) {
                    updatedModelParams[name] = array
                    appliedCount += 1
                } else {
                    print("Warning: Loaded parameter '\(name)' not found in current model's LoRA parameters. Skipping.")
                }
            }
            model.update(parameters: updatedModelParams)
            print("Loaded \(appliedCount) LoRA adapter parameters from: \(url.lastPathComponent)")
        } catch {
            throw FineTunerError.fileOperationFailed("Failed to load LoRA parameters from \(url.lastPathComponent): \(error.localizedDescription)")
        }
    }

    /// Performs inference with the fine-tuned model.
    /// - Parameter input: An input document embedding (`MLXArray`).
    /// - Returns: The predicted class logits (`MLXArray`).
    func predict(input: MLXArray) -> MLXArray {
        // Ensure the model is in evaluation mode (though for this simple MLP, it doesn't change behavior)
        // MLXNN.Module doesn't have an explicit `eval()` mode like PyTorch,
        // but it's good practice to consider it for models with dropout/batchnorm.
        return model(input)
    }
}
