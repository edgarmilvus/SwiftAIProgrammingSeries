
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CloudKit

@available(iOS 18.0, *)
actor VectorSyncEngine {
    private let publicDB: CKDatabase
    private var buffer: [CKRecord] = []
    private let maxBatchSize = 20
    private var lastFlushDate = Date()
    
    init(container: CKContainer) {
        self.publicDB = container.publicCloudDatabase
    }

    func queueEmbedding(vector: [Float], metadata: [String: String]) async throws {
        let record = CKRecord(recordType: "Embedding")
        
        // 1. Convert [Float] to Data
        let data = vector.withUnsafeBytes { Data($0) }
        record["vectorData"] = data as CKRecordValue
        
        for (key, value) in metadata {
            record[key] = value as CKRecordValue
        }
        
        buffer.append(record)
        
        // 2. Check batching criteria (Count or Time)
        if buffer.count >= maxBatchSize || Date().timeIntervalSince(lastFlushDate) >= 5 {
            try await flush()
        }
    }
    
    private func flush() async throws {
        guard !buffer.isEmpty else { return }
        
        let recordsToUpload = buffer
        buffer.removeAll()
        lastFlushDate = Date()
        
        try await performUpload(records: recordsToUpload)
    }
    
    private func performUpload(records: [CKRecord], attempt: Int = 1) async throws {
        let operation = CKModifyRecordsOperation(recordsToSave: records, recordIDsToDelete: nil)
        operation.savePolicy = .changedKeys
        
        do {
            try await publicDB.modifyRecords(saving: records, deleting: [])
        } catch let error as CKError {
            // 3. Handle Rate Limiting (Exponential Backoff)
            if error.code == .limitExceeded || error.code == .serviceUnavailable {
                let retryAfter = error.userInfo[CKErrorRetryAfterKey] as? Double ?? pow(2.0, Double(attempt))
                try await Task.sleep(for: .seconds(retryAfter))
                try await performUpload(records: records, attempt: attempt + 1)
                return
            }
            
            // 4. Handle Partial Failures
            if error.code == .partialFailure, let partialErrors = error.userInfo[CKPartialErrorsByItemIDKey] as? [CKRecord.ID: Error] {
                var failedRecords: [CKRecord] = []
                for record in records {
                    if let error = partialErrors[record.recordID] {
                        print("Record \(record.recordID) failed: \(error)")
                        failedRecords.append(record)
                    }
                }
                // Re-add failed records to the buffer for the next cycle
                if !failedRecords.isEmpty {
                    self.buffer.append(contentsOf: failedRecords)
                }
            } else {
                throw error
            }
        }
    }
}

// Helper for Float to Data conversion
extension Array where Element == Float {
    func toData() -> Data {
        return self.withUnsafeBytes { Data($0) }
    }
}
