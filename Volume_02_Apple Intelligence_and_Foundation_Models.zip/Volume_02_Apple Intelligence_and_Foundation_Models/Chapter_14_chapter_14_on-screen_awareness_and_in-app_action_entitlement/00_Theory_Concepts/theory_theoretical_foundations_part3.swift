
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift (if using Observable in a separate module)
// dependencies: [
//     .package(url: "https://github.com/apple/swift-collections", from: "1.0.0"),
// ]

// @available(iOS 18.0, *)
import SwiftUI
import Observation // Required for @Observable

@available(iOS 18.0, *)
@Observable
class AISuggestionViewModel {
    var suggestions: [AISuggestion] = []
    var isLoadingSuggestions: Bool = false
    var selectedSuggestion: AISuggestion?

    private let contextManager: AIContextManager

    init(contextManager: AIContextManager) {
        self.contextManager = contextManager
    }

    @MainActor // UI updates should be on the main actor
    func fetchAndObserveSuggestions() async {
        isLoadingSuggestions = true
        // In a real app, you'd fetch from contextManager, which gets them from AI service
        // For this example, let's simulate
        try? await Task.sleep(for: .seconds(1))
        let newSuggestions = await contextManager.getPendingSuggestions() // Get from actor
        self.suggestions = newSuggestions
        isLoadingSuggestions = false
    }

    @MainActor
    func applySelectedSuggestion() async {
        guard let suggestion = selectedSuggestion else { return }
        if let proposedText = suggestion.proposedText {
            // Apply text change to the UI/document
            print("Applying text: \(proposedText)")
        } else if let action = suggestion.proposedAction, let actionID = suggestion.actionID {
            // This would typically involve user confirmation first
            print("User approved action: \(action.name)")
            do {
                await contextManager.performAction(id: actionID, parameters: ["body": "Generated content"]) // Example params
            } catch {
                print("Failed to perform action: \(error)")
            }
        }
        selectedSuggestion = nil // Clear after applying
    }
}

@available(iOS 18.0, *)
struct AISuggestionView: View {
    @State private var viewModel: AISuggestionViewModel

    init(contextManager: AIContextManager) {
        _viewModel = State(wrappedValue: AISuggestionViewModel(contextManager: contextManager))
    }

    var body: some View {
        VStack {
            if viewModel.isLoadingSuggestions {
                ProgressView("Thinking...")
            } else if viewModel.suggestions.isEmpty {
                Text("No AI suggestions available.")
            } else {
                List(viewModel.suggestions) { suggestion in
                    HStack {
                        if let text = suggestion.proposedText {
                            Text(text)
                        } else if let action = suggestion.proposedAction {
                            Text("Action: \(action.name)")
                        }
                        Spacer()
                        Button("Apply") {
                            viewModel.selectedSuggestion = suggestion
                            Task { await viewModel.applySelectedSuggestion() }
                        }
                    }
                }
            }
        }
        .task {
            await viewModel.fetchAndObserveSuggestions()
        }
    }
}
