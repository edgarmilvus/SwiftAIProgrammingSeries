
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import AppleIntelligence

// Assume these are defined elsewhere, e.g., from previous chapters
@available(iOS 18.0, *)
protocol LocalAIMachine {
    func process(input: String) async throws -> AIResult
}

@available(iOS 18.0, *)
protocol PrivateCloudComputeService {
    func process(input: String) async throws -> AIResult
    var isAvailable: Bool { get async } // A conceptual check for PCC availability
}

@available(iOS 18.0, *)
struct AIResult: Sendable {
    let text: String
    let source: String // e.g., "local", "PCC"
}

@available(iOS 18.0, *)
enum AIError: Error, LocalizedError {
    case localComputeFailed(underlying: Error)
    case cloudComputeUnavailable(underlying: Error?)
    case noViableOption

    var errorDescription: String? {
        switch self {
        case .localComputeFailed(let underlying):
            return "Local AI processing failed: \(underlying.localizedDescription)"
        case .cloudComputeUnavailable(let underlying):
            return "Private Cloud Compute is unavailable. \(underlying?.localizedDescription ?? "Please check network or settings.")"
        case .noViableOption:
            return "Could not complete the AI task. Please try again later."
        }
    }
}

@available(iOS 18.0, *)
class AIOrchestrator {
    let localMachine: LocalAIMachine
    let pccService: PrivateCloudComputeService

    init(localMachine: LocalAIMachine, pccService: PrivateCloudComputeService) {
        self.localMachine = localMachine
        self.pccService = pccService
    }

    func performAIAction(input: String) async throws -> AIResult {
        // 1. Attempt on-device processing first (primary path)
        do {
            let result = try await localMachine.process(input: input)
            print("AI action completed successfully using local compute.")
            return AIResult(text: result.text, source: "local")
        } catch {
            print("Local AI failed: \(error.localizedDescription).")
            // 2. If local fails, attempt Private Cloud Compute (secondary path)
            // Check PCC availability first for a more graceful path
            if await pccService.isAvailable {
                do {
                    let result = try await pccService.process(input: input)
                    print("AI action completed successfully using Private Cloud Compute.")
                    return AIResult(text: result.text, source: "PCC")
                } catch let pccError as AIError {
                    // Specific AIError from PCC service (e.g., .cloudComputeUnavailable)
                    print("Private Cloud Compute failed with specific AIError: \(pccError.localizedDescription).")
                    throw pccError // Propagate specific PCC error
                } catch {
                    // General error during PCC processing
                    print("Private Cloud Compute failed with generic error: \(error.localizedDescription).")
                    throw AIError.cloudComputeUnavailable(underlying: error)
                }
            } else {
                print("Private Cloud Compute is not available or restricted.")
                // 3. Both local and PCC failed/unavailable (tertiary path: graceful fallback)
                // Here, you might attempt a simpler local model, return a default, or throw a user-friendly error.
                throw AIError.noViableOption
            }
        }
    }
}
