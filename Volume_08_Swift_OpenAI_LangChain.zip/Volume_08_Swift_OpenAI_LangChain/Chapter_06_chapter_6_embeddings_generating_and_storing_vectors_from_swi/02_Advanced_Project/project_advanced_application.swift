
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import SwiftData
import Accelerate
import Observation

// MARK: - Dependencies (Package.swift equivalent)
/*
 dependencies: [
    .package(url: "https://github.com/openai/openai-swift", from: "1.0.0"),
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0")
 ]
*/

/// Errors specific to the Semantic Engine operations.
enum SemanticError: Error, LocalizedError {
    case embeddingGenerationFailed(String)
    case vectorMismatch(expected: Int, actual: Int)
    case storageFailure(String)
    case unauthorized
    
    var errorDescription: String? {
        switch self {
        case .embeddingGenerationFailed(let msg): return "Failed to generate embedding: \(msg)"
        case .vectorMismatch(let e, let a): return "Dimension mismatch. Expected \(e), got \(a)."
        case .storageFailure(let msg): return "Persistence error: \(msg)"
        case .unauthorized: return "API Key is missing or invalid."
        }
    }
}

// MARK: - Models

/// A persistent model representing a user's note with its semantic vector.
@Model
final class SemanticNote {
    var id: UUID
    var content: String
    var timestamp: Date
    
    /// The embedding vector stored as raw Data to optimize SwiftData performance.
    /// High-dimensional arrays are more efficiently stored as binary blobs.
    @Attribute(.externalStorage) var embeddingData: Data
    
    /// The dimension of the vector (e.g., 1536 for OpenAI)
    var dimension: Int
    
    init(content: String, embedding: [Float]) {
        self.id = UUID()
        self.content = content
        self.timestamp = Date()
        self.dimension = embedding.count
        // Convert [Float] to Data for efficient storage
        self.embeddingData = embedding.withUnsafeBytes { Data($0) }
    }
    
    /// Helper to retrieve the vector back as [Float]
    var embedding: [Float] {
        embeddingData.withUnsafeBytes { buffer in
            Array(buffer.bindMemory(to: Float.self))
        }
    }
}

// MARK: - Services

/// An Actor to handle OpenAI API interactions, ensuring thread-safety 
/// and preventing data races when multiple tasks request embeddings.
@available(iOS 18.0, macOS 15.0, *)
actor EmbeddingService {
    private let apiKey: String
    private let model = "text-embedding-3-small"
    
    init(apiKey: String) {
        self.apiKey = apiKey
    }
    
    /// Generates a vector embedding for a given string.
    /// - Parameter text: The input text to embed.
    /// - Returns: An array of Floats representing the semantic vector.
    func generateEmbedding(for text: String) async throws -> [Float] {
        guard !apiKey.isEmpty else { throw SemanticError.unauthorized }
        
        let url = URL(string: "https://api.openai.com/v1/embeddings")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "input": text,
            "model": model
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw SemanticError.embeddingGenerationFailed("Server returned error status.")
        }
        
        // Parsing the OpenAI response structure
        let decoded = try JSONDecoder().decode(OpenAIEmbeddingResponse.self, from: data)
        guard let vector = decoded.data.first?.embedding else {
            throw SemanticError.embeddingGenerationFailed("No vector found in response.")
        }
        
        return vector
    }
}

/// Internal DTO for OpenAI response parsing.
struct OpenAIEmbeddingResponse: Codable {
    struct DataContainer: Codable {
        let embedding: [Float]
    }
    let data: [DataContainer]
}

// MARK: - Core Engine

/// The orchestrator that connects the Embedding Service, SwiftData, and the Math Engine.
@available(iOS 18.0, macOS 15.0, *)
@Observable
final class SemanticSearchEngine {
    private let embeddingService: EmbeddingService
    private let modelContext: ModelContext
    
    var isProcessing: Bool = false
    var searchResults: [SemanticNote] = []
    
    init(embeddingService: EmbeddingService, modelContext: ModelContext) {
        self.embeddingService = embeddingService
        self.modelContext = modelContext
    }
    
    /// Adds a new note to the system, automatically generating its embedding.
    /// - Parameter content: The text content of the note.
    func ingestNote(content: String) async throws {
        isProcessing = true
        defer { isProcessing = false }
        
        // 1. Generate the vector via the Actor
        let vector = try await embeddingService.generateEmbedding(for: content)
        
        // 2. Create the SwiftData model on the main actor/context
        let newNote = SemanticNote(content: content, embedding: vector)
        
        // 3. Persist
        modelContext.insert(newNote)
        try modelContext.save()
    }
    
    /// Performs a semantic search across all stored notes.
    /// - Parameter query: The user's natural language query.
    /// - Returns: A list of notes ranked by semantic similarity.
    func search(query: String) async throws -> [SemanticNote] {
        isProcessing = true
        defer { isProcessing = false }
        
        // 1. Embed the query
        let queryVector = try await embeddingService.generateEmbedding(for: query)
        
        // 2. Fetch all notes (In a massive DB, you'd use a Vector Database like Milvus or Pinecone)
        let descriptor = FetchDescriptor<SemanticNote>()
        let allNotes = try modelContext.fetch(descriptor)
        
        // 3. Perform similarity calculation using Accelerate
        // We use a TaskGroup to parallelize the math if the dataset is large
        let scoredNotes = try await withThrowingTaskGroup(of: (SemanticNote, Float).self) { group in
            for note in allNotes {
                group.addTask {
                    let similarity = self.cosineSimilarity(queryVector, note.embedding)
                    return (note, similarity)
                }
            }
            
            var results: [(SemanticNote, Float)] = []
            for try await result in group {
                results.append(result)
            }
            return results
        }
        
        // 4. Sort by highest similarity and return
        let sorted = scoredNotes
            .sorted { $0.1 > $1.1 }
            .map { $0.0 }
        
        self.searchResults = sorted
        return sorted
    }
    
    /// High-performance Cosine Similarity using Apple's Accelerate framework.
    /// This replaces a manual loop with SIMD-optimized vector instructions.
    private func cosineSimilarity(_ v1: [Float], _ v2: [Float]) -> Float {
        guard v1.count == v2.count else { return 0.0 }
        
        let n = v1.count
        var dotProduct: Float = 0.0
        var v1SumSq: Float = 0.0
        var v2SumSq: Float = 0.0
        
        // vDSP_dotpr: Computes the dot product of two vectors
        vDSP_dotpr(v1, 1, v2, 1, &dotProduct, vDSP_Length(n))
        
        // vDSP_svesq: Computes the sum of squares of a vector (needed for magnitude)
        vDSP_svesq(v1, 1, &v1SumSq, vDSP_Length(n))
        vDSP_svesq(v2, 1, &v2SumSq, vDSP_Length(n))
        
        let magnitude = sqrt(v1SumSq) * sqrt(v2SumSq)
        
        return magnitude > 0 ? (dotProduct / magnitude) : 0.0
    }
}
