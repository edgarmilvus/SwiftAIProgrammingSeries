
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import ARKit
import RealityKit
import Combine

/// Represents an error encountered during spatial anchoring or persistence.
enum SpatialError: Error, LocalizedError {
    case anchorCreationFailed
    case relocalizationFailed
    case persistenceFailure(Error)
    case objectNotFound
    
    var errorDescription: String? {
        switch self {
        case .anchorCreationFailed: return "Failed to create a world anchor at the detected location."
        case .relocalizationFailed: return "Unable to relocalize to the existing spatial map."
        case .persistenceFailure(let error): return "Data persistence failed: \(error.localizedDescription)"
        case .objectNotFound: return "The recognized object could not be found in the current spatial context."
        }
    }
}

/// Metadata associated with a recognized physical object.
struct AssetMetadata: Codable, Identifiable, Equatable {
    let id: UUID
    let name: String
    let modelIdentifier: String
    let lastMaintenanceDate: Date
}

/// A container that binds a physical World Anchor to its digital metadata.
struct PersistedSpatialAsset: Codable, Identifiable {
    let id: UUID
    let anchorIdentifier: UUID // The UUID of the ARAnchor
    let metadata: AssetMetadata
}

/// An Actor responsible for managing the state of spatial assets.
/// Using an Actor ensures that updates from the ARSession and requests from the UI
/// are synchronized, preventing data races in a multi-threaded spatial environment.
@available(visionOS 1.0, *)
actor SpatialAssetStore {
    private var assets: [UUID: PersistedSpatialAsset] = [:]
    private let fileURL: URL
    
    init() {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        self.fileURL = paths[0].appendingPathComponent("spatial_assets.json")
    }
    
    /// Saves the current collection of assets to disk.
    func saveToDisk() throws {
        do {
            let data = try JSONEncoder().encode(Array(assets.values))
            try data.write(to: fileURL, options: .atomic)
        } catch {
            throw SpatialError.persistenceFailure(error)
        }
    }
    
    /// Loads assets from disk.
    func loadFromDisk() throws {
        guard FileManager.default.fileExists(atPath: fileURL.path) else { return }
        let data = try Data(contentsOf: fileURL)
        let decodedAssets = try JSONDecoder().decode([PersistedSpatialAsset].self, from: data)
        self.assets = Dictionary(uniqueKeysWithValues: decodedAssets.map { ($0.id, $0) })
    }
    
    /// Registers a new asset.
    func registerAsset(_ asset: PersistedSpatialAsset) throws {
        assets[asset.id] = asset
        try saveToDisk()
    }
    
    /// Retrieves all assets.
    func getAllAssets() -> [PersistedSpatialAsset] {
        return Array(assets.values)
    }
    
    /// Finds an asset by its ARAnchor identifier.
    func findAsset(for anchorID: UUID) -> PersistedSpatialAsset? {
        return assets.values.first(where: { $0.anchorIdentifier == anchorID })
    }
}

/// The primary coordinator for the Spatial AI experience.
/// It manages the ARKit session, object recognition, and the lifecycle of World Anchors.
@available(visionOS 1.0, *)
class SpatialSessionCoordinator: NSObject, ObservableObject {
    
    // MARK: - Published State
    @Published private(set) var isRelocalizing: Bool = false
    @Published private(set) var recognizedAssets: [PersistedSpatialAsset] = []
    @Published var errorMessage: String?
    
    // MARK: - Private Properties
    private var arSession: ARSession?
    private var assetStore = SpatialAssetStore()
    private var cancellables = Set<AnyCancellable>()
    
    // The RealityKit view would use this to render entities
    private var anchorEntities: [UUID: Entity] = [:]
    
    override init() {
        super.init()
        Task {
            await setupStore()
        }
    }
    
    private func setupStore() async {
        do {
            try await assetStore.loadFromDisk()
            let loaded = await assetStore.getAllAssets()
            await MainActor.run {
                self.recognizedAssets = loaded
            }
        } catch {
            await handleError(.persistenceFailure(error))
        }
    }
    
    /// Initializes the ARSession with configuration for object detection and persistence.
    func startSession(session: ARSession) {
        self.arSession = session
        session.delegate = self
        
        let configuration = ARWorldTrackingConfiguration()
        // Enable scene reconstruction for better depth understanding
        configuration.sceneReconstruction = .meshWithClassification
        // Enable object detection if using ARObjectScanning/Detection
        // configuration.detectionObjects = [...] 
        
        session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
    }
    
    /// The core logic for persisting a newly recognized object.
    /// - Parameters:
    ///   - metadata: The information about the physical object.
    ///   - transform: The 4x4 matrix representing the object's position in the world.
    func persistRecognizedObject(metadata: AssetMetadata, transform: simd_float4x4) async {
        guard let session = arSession else { return }
        
        // 1. Create an ARAnchor at the object's transform.
        // This anchor is the "hook" into the physical world.
        let anchor = ARAnchor(name: metadata.name, transform: transform)
        
        // 2. Add the anchor to the session.
        // ARKit will now attempt to map this anchor to the physical feature points.
        session.add(anchor: anchor)
        
        // 3. Create the persistence record.
        let spatialAsset = PersistedSpatialAsset(
            id: UUID(),
            anchorIdentifier: anchor.identifier,
            metadata: metadata
        )
        
        // 4. Save to the actor-based store.
        do {
            try await assetStore.registerAsset(spatialAsset)
            await MainActor.run {
                self.recognizedAssets.append(spatialAsset)
            }
        } catch {
            await handleError(.persistenceFailure(error))
        }
    }
    
    @MainActor
    private func handleError(_ error: SpatialError) {
        self.errorMessage = error.localizedDescription
        print("Spatial Error: \(error.localizedDescription)")
    }
}

// MARK: - ARSessionDelegate

extension SpatialSessionCoordinator: ARSessionDelegate {
    
    /// Called when ARKit adds a new anchor to the session.
    /// This is where we perform "Relocalization" logic.
    func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
        Task {
            for anchor in anchors {
                // Check if this anchor is one of our persisted assets
                if let asset = await assetStore.findAsset(for: anchor.identifier) {
                    await handleRelocalizedAsset(asset, anchor: anchor)
                }
            }
        }
    }
    
    /// Called when the session's tracking state changes (e.g., from Limited to Normal).
    func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
        let state = camera.trackingState
        Task { @MainActor in
            switch state {
            case .limited(.relocalizing):
                self.isRelocalizing = true
            case .normal:
                self.isRelocalizing = false
            default:
                break
            }
        }
    }
    
    /// Handles the visual reconstruction of a persisted asset once its anchor is found.
    @MainActor
    private func handleRelocalizedAsset(_ asset: PersistedSpatialAsset, anchor: ARAnchor) async {
        // In a real app, you would use RealityKit to attach an Entity to this anchor.
        // Example:
        // let entity = try await Entity.load(named: asset.metadata.modelIdentifier)
        // let anchorEntity = AnchorEntity(anchor: anchor)
        // anchorEntity.addChild(entity)
        // arView.scene.addAnchor(anchorEntity)
        
        print("Successfully relocalized asset: \(asset.metadata.name) at \(anchor.transform)")
    }
}
