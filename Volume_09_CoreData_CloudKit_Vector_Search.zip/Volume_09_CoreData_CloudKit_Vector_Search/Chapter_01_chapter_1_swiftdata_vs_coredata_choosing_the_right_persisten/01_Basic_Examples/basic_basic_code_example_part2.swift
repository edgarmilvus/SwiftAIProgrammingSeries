
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CoreData

/// A Core Data version of the same model.
/// Note that this requires inheriting from NSManagedObject.
@available(iOS 18.0, macOS 15.0, *)
@objc(MemorySnippetCoreData)
final class MemorySnippetCoreData: NSManagedObject {
    @NSManaged var content: String?
    @NSManaged var timestamp: Date?
    @NSManaged var category: String?
    @NSManaged var confidenceScore: Double
}

/// A Core Data Manager demonstrating the imperative setup.
@available(iOS 18.0, macOS 15.0, *)
final class CoreDataMemoryManager {
    
    private let persistentContainer: NSPersistentContainer

    init() {
        // 1. Manually define the Entity and Attributes (The "Hard" Way)
        let entity = NSEntityDescription()
        entity.name = "MemorySnippetCoreData"
        entity.managedObjectClassName = NSStringFromClass(MemorySnippetCoreData.self)
        
        let contentAttr = NSAttributeDescription()
        contentAttr.name = "content"
        contentAttr.attributeType = .stringAttributeType
        
        let dateAttr = NSAttributeDescription()
        dateAttr.name = "timestamp"
        dateAttr.attributeType = .dateAttributeType
        
        let categoryAttr = NSAttributeDescription()
        categoryAttr.name = "category"
        categoryAttr.attributeType = .stringAttributeType
        
        let scoreAttr = NSAttributeDescription()
        scoreAttr.name = "confidenceScore"
        scoreAttr.attributeType = .doubleAttributeType
        
        entity.properties = [contentAttr, dateAttr, categoryAttr, scoreAttr]
        
        // 2. Create the Model and Container
        let model = NSManagedObjectModel()
        model.entities = [entity]
        
        persistentContainer = NSPersistentContainer(name: "AuraCoreData", managedObjectModel: model)
        
        // 3. Load the Stores
        persistentContainer.loadPersistentStores { (description, error) in
            if let error = error {
                fatalError("Unresolved error \(error)")
            }
        }
    }

    /// Adds a memory using the imperative NSManagedObjectContext pattern.
    func recordMemory(content: String, category: String, score: Double) {
        let context = persistentContainer.viewContext
        
        // We must manually instantiate the object within the context.
        let newSnippet = MemorySnippetCoreData(context: context)
        newSnippet.content = content
        newSnippet.category = category
        newSnippet.confidenceScore = score
        newSnippet.timestamp = Date()
        
        do {
            try context.save()
            print("Core Data: Saved successfully.")
        } catch {
            print("Core Data: Failed to save: \(error)")
        }
    }
}
