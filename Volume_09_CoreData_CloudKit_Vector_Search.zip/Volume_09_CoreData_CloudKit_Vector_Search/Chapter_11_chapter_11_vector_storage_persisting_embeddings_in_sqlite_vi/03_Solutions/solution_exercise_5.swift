
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import GRDB

actor VectorIngestionActor {
    private let dbPool: DatabasePool
    private let chunkSize = 500
    
    init(dbPool: DatabasePool) {
        self.dbPool = dbPool
    }
    
    /// Ingests a stream of notes with progress reporting.
    func ingest(stream: AsyncStream<Note>) async throws {
        var currentChunk: [Note] = []
        var totalProcessed = 0
        
        for await note in stream {
            currentChunk.append(note)
            totalProcessed += 1
            
            if currentChunk.count >= chunkSize {
                try await commitChunk(currentChunk)
                currentChunk.removeAll()
                print("Progress: \(totalProcessed) notes ingested.")
            }
        }
        
        // Final remaining chunk
        if !currentChunk.isEmpty {
            try await commitChunk(currentChunk)
        }
    }
    
    private func commitChunk(_ notes: [Note]) async throws {
        // Using dbPool.write ensures we are using a transaction.
        // In WAL mode, this allows readers to continue searching.
        try await dbPool.write { db in
            for note in notes {
                try note.insert(db)
            }
        }
    }
}

// MARK: - Usage Example
struct IngestionService {
    func startMassiveIngestion(pool: DatabasePool) async {
        let actor = VectorIngestionActor(dbPool: pool)
        
        // Simulate a producer (e.g., an AI model generating embeddings)
        let noteStream = AsyncStream<Note> { continuation in
            Task {
                for i in 1...10000 {
                    let note = Note(id: nil, title: "Note \(i)", content: "...", createdAt: Date(), vectorEmbedding: [Float](repeating: 0.1, count: 1536))
                    continuation.yield(note)
                }
                continuation.finish()
            }
        }
        
        do {
            try await actor.ingest(stream: noteStream)
            print("Ingestion Complete.")
        } catch {
            print("Ingestion Failed: \(error)")
        }
    }
}
