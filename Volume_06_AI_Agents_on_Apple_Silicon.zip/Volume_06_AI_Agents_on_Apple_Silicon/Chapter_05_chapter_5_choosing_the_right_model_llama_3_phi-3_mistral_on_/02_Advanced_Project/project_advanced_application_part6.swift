
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part6.swift
// Description: Advanced Application
// ==========================================

// MockLlamaCppWrapper.swift
/// A mock implementation of `LlamaCppWrapperProtocol` for testing and demonstration.
/// It simulates model loading and text generation with artificial delays and streaming.
actor MockLlamaCppWrapper: LlamaCppWrapperProtocol {
    private var isModelLoaded: Bool = false
    private var loadedModelPath: String?

    /// Simulates loading a model with a delay.
    /// - Parameter modelPath: The path to the model file.
    /// - Throws: `LLMInferenceError.modelNotFound` if the path implies an error.
    func loadModel(from modelPath: String) async throws {
        print("Mock: Attempting to load model from \(modelPath)...")
        // Simulate network/disk I/O delay for loading a large model
        try await Task.sleep(for: .seconds(2))

        // Simulate a failure case for a specific path
        if modelPath.contains("non_existent") {
            print("Mock: Model not found at \(modelPath).")
            throw LLMInferenceError.modelNotFound(path: modelPath)
        }

        isModelLoaded = true
        loadedModelPath = modelPath
        print("Mock: Model loaded successfully from \(modelPath).")
    }

    /// Simulates unloading a model.
    func unloadModel() async {
        guard isModelLoaded else { return }
        print("Mock: Unloading model from \(loadedModelPath ?? "unknown path")...")
        // Simulate resource release delay
        try? await Task.sleep(for: .seconds(0.5))
        isModelLoaded = false
        loadedModelPath = nil
        print("Mock: Model unloaded.")
    }

    /// Simulates generating a response, streaming tokens with delays.
    /// - Parameters:
    ///   - prompt: The input prompt.
    ///   - temperature: Not used in mock, but kept for protocol conformity.
    ///   - maxTokens: Maximum tokens to generate.
    /// - Returns: An `AsyncThrowingStream` of simulated tokens.
    /// - Throws: `LLMInferenceError.noModelLoaded` if no model is loaded.
    func generate(prompt: String, temperature: Float, maxTokens: Int) async throws -> AsyncThrowingStream<String, Error> {
        guard isModelLoaded else {
            throw LLMInferenceError.noModelLoaded
        }

        print("Mock: Generating response for prompt: \"\(prompt)\" (maxTokens: \(maxTokens))...")

        // Simulate different responses based on prompt keywords
        let mockResponse: String
        if prompt.lowercased().contains("llama 3") {
            mockResponse = "Llama 3 is a powerful, state-of-the-art open-source large language model developed by Meta AI. It comes in various sizes, including 8B and 70B parameter versions, and excels at complex reasoning and creative tasks."
        } else if prompt.lowercased().contains("phi-3") {
            mockResponse = "Phi-3 is a family of small, yet highly capable, open large language models developed by Microsoft. Phi-3 Mini, for example, is a 3.8 billion parameter model optimized for mobile and edge devices, offering strong performance for its size."
        } else if prompt.lowercased().contains("mistral") {
            mockResponse = "Mistral AI has developed several highly efficient and powerful open-source models, such as Mistral 7B and Mixtral 8x7B. These models are known for their strong performance, especially in coding and reasoning, while maintaining a relatively small footprint."
        } else if prompt.lowercased().contains("error") {
            throw LLMInferenceError.inferenceFailed(reason: "Simulated inference error due to prompt content.")
        } else {
            mockResponse = "This is a simulated response from the currently loaded model (\(loadedModelPath ?? "unknown")). Your prompt was: \"\(prompt)\". I can discuss many topics, from technology to philosophy."
        }

        // Split the response into tokens (words) for streaming
        let tokens = mockResponse.components(separatedBy: " ")
        var generatedCount = 0

        return AsyncThrowingStream { continuation in
            Task {
                for token in tokens {
                    guard generatedCount < maxTokens else { break }
                    guard !Task.isCancelled else {
                        continuation.finish(throwing: LLMInferenceError.cancellationError)
                        return
                    }
                    // Simulate token generation delay
                    try await Task.sleep(for: .milliseconds(50))
                    continuation.yield(token + " ") // Add space back for readability
                    generatedCount += 1
                }
                continuation.finish()
                print("Mock: Response generation finished.")
            }
        }
    }
}
