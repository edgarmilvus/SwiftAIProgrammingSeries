
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

// MARK: - Data Strategy Outline
/*
This section outlines the conceptual strategy for data collection/generation.
It is not executable code but crucial for the overall solution.

1.  **Element Types:**
    *   Define 5-7 distinct categories: "Button", "Slider", "Checkbox", "Icon-Arrow", "Icon-Gear", "Text Field", "Toggle Switch".
    *   Ensure clear visual distinctions where possible.

2.  **Visual Styles:**
    *   **Synthetic Generation (Primary):** Use design tools (Sketch, Figma, Adobe XD) or programmatic rendering (e.g., SwiftUI/AppKit views rendered to images) to create elements across various styles:
        *   Flat Design (varied colors, outlines, fills)
        *   Skeuomorphic (gradients, shadows, textures)
        *   Minimalist (simple lines, monochrome)
        *   Material Design, iOS/macOS Human Interface Guidelines styles.
    *   **Real-world Scrapes (Secondary):** Scrape design asset websites (e.g., Dribbble, Behance, icon libraries) for diverse examples. Manually clean and label.

3.  **Backgrounds:**
    *   **Transparent Backgrounds (Initial):** Generate elements with transparent backgrounds. This allows maximum flexibility for augmentation.
    *   **Augmentation Compositing:** During augmentation (or a pre-processing step), composite these transparent elements onto:
        *   Random solid colors (wide range of hues, saturations, brightness).
        *   Random gradient backgrounds.
        *   Simple texture images (e.g., wood, metal, fabric patterns).
        *   Blurred screenshots of complex UIs (to simulate real app contexts).

4.  **Sizes:**
    *   Generate elements at various resolutions (e.g., 24x24, 48x48, 64x64, 128x128, 256x256 pixels for icons; varying widths/heights for buttons/text fields).
    *   During augmentation, use aggressive scaling (`.scale`) and cropping (`.crop`) to make the model invariant to absolute pixel dimensions. All images will be resized to a fixed input size for the model, so variation in original size is key.

5.  **Diversity Considerations:**
    *   **Color:** Generate elements in a full spectrum of colors, including monochrome, grayscale, and vibrant hues.
    *   **State:** For interactive elements (buttons, checkboxes), include images of different states (normal, hovered, pressed, disabled, selected).
    *   **Text:** For text fields/buttons, use placeholder text, short labels, and varying font styles/sizes.
    *   **Occlusion:** Consider synthetically adding partial occlusions (e.g., another UI element overlapping slightly) to improve robustness.
*/

// MARK: - Create ML Training (macOS Command Line Tool or Playground)
// This code runs on macOS for training the model.

import CreateML
import Foundation

// IMPORTANT: Replace these URLs with actual paths to your dataset.
let uiElementTrainingDataURL = URL(fileURLWithPath: "/path/to/your/uiElementTrainingDataDirectory")
let uiElementValidationDataURL = URL(fileURLWithPath: "/path/to/your/uiElementValidationDataDirectory")
let uiElementOutputModelURL = URL(fileURLWithPath: "/path/to/save/UIElementClassifier.mlmodel")

@available(macOS 14.0, *)
func trainUIElementClassifier() async {
    print("Starting UI element classifier training...")
    do {
        let trainingData = try MLImageClassifier.DataSource.labeledDirectories(at: uiElementTrainingDataURL)
        let validationData = try MLImageClassifier.DataSource.labeledDirectories(at: uiElementValidationDataURL)

        // Advanced Augmentation for UI Elements
        let builder = MLImageClassifier.Builder(trainingData: trainingData)
            .validationData(validationData)
            // Hyperparameter Exploration (initial values)
            .maxEpochs(80) // More epochs for complex data
            .batchSize(64) // Larger batch size can sometimes speed up training on powerful GPUs
            .learningRate(0.0001) // Lower learning rate for fine-tuning a base model
            .augmentationOptions([
                // Aggressive Geometric Augmentation
                .rotation(minimumAngle: -30, maximumAngle: 30), // Wide range for perspective changes
                .horizontalFlip,
                .verticalFlip, // Essential for icons that can be mirrored or inverted
                .crop(minimumScale: 0.6, maximumScale: 1.0), // Simulate zoom, partial views
                .scale(minimum: 0.7, maximum: 1.3), // Significant scaling variation
                .translation(minimum: -0.2, maximum: 0.2), // Shift elements around
                // Note: Shear is not directly available in MLImageClassifier.Builder,
                // would require pre-processing or custom augmentation.

                // Advanced Color Augmentation
                // Apply significant color jitter. Create ML applies these randomly.
                // For conditional color augmentation (e.g., monochrome), you'd need
                // to pre-process or create separate training pipelines.
                .color(hue: 0.15, saturation: 0.4, brightness: 0.3, contrast: 0.3),

                // Noise and Blur
                .gaussianNoise(standardDeviation: 0.05), // Simulate export artifacts, sensor noise
                .blur(radius: 1.5), // Simulate varying resolutions or slight out-of-focus

                // Background Variation (Conceptual - requires pre-processing or custom augmentation)
                // MLImageClassifier.Builder does not directly composite backgrounds.
                // This would be achieved by pre-generating your training images
                // with diverse backgrounds as described in the Data Strategy.
            ])
            // Pre-trained base model for transfer learning
            .baseModel(.visionFeaturePrint) // Good starting point
            // .baseModel(.resnet50) // Explore more powerful models if needed and data allows
            // .baseModel(.efficientNetB0) // Another option for modern architectures

        print("Training UI element classifier...")
        let model = try builder.train()
        print("Model training complete.")

        // Model Performance Metrics (Create ML provides these during training)
        // Look for:
        // - Training Accuracy, Validation Accuracy
        // - Training Loss, Validation Loss
        // - Precision, Recall, F1-score for each class (available in detailed reports)
        // These metrics would be analyzed to assess overfitting and per-class performance.

        let metadata = MLModelMetadata(
            author: "Your Name",
            shortDescription: "Classifies custom UI elements (Button, Slider, Checkbox, Icon-Arrow, Icon-Gear, Text Field)",
            version: "1.0",
            license: "MIT",
            additional: nil
        )
        try model.write(to: uiElementOutputModelURL, metadata: metadata)
        print("UI Element model saved to: \(uiElementOutputModelURL.path)")

    } catch {
        print("Error during UI element classifier training: \(error.localizedDescription)")
    }
}

// MARK: - macOS App Integration (AppKit)
// This code would be part of a macOS AppKit application.

import Cocoa
import CoreML
import Vision

// Main Application Delegate
@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    var window: NSWindow!

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 600, height: 400),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.center()
        window.title = "UI Element Categorizer"
        window.contentViewController = UIElementClassifierViewController()
        window.makeKeyAndOrderFront(nil)
    }
}

// UI Element Classifier View Controller
class UIElementClassifierViewController: NSViewController, NSDraggingDestination {

    private let imageView = NSImageView()
    private let resultLabel = NSTextField(labelWithString: "Drag & Drop a UI Element Image Here")
    private var uiElementClassifier: UIElementClassifier?

    override func loadView() {
        self.view = NSView()
        self.view.wantsLayer = true // Enable layer for background color
        self.view.layer?.backgroundColor = NSColor.windowBackgroundColor.cgColor
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadClassifier()
    }

    private func setupUI() {
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.imageScaling = .scaleProportionallyUpOrDown
        imageView.imageFrameStyle = .grayBezel
        view.addSubview(imageView)

        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        resultLabel.font = .systemFont(ofSize: 24, weight: .bold)
        resultLabel.alignment = .center
        resultLabel.isEditable = false
        resultLabel.isSelectable = false
        resultLabel.backgroundColor = .clear
        view.addSubview(resultLabel)

        NSLayoutConstraint.activate([
            imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            imageView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -50),
            imageView.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.8),
            imageView.heightAnchor.constraint(lessThanOrEqualTo: view.heightAnchor, multiplier: 0.6),
            imageView.widthAnchor.constraint(equalToConstant: 250).priority(.defaultLow), // Min width
            imageView.heightAnchor.constraint(equalToConstant: 250).priority(.defaultLow), // Min height

            resultLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            resultLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])

        // Register for drag and drop operations
        view.registerForDraggedTypes([.fileURL])
    }

    private func loadClassifier() {
        Task { @MainActor in
            do {
                self.uiElementClassifier = try await UIElementClassifier()
                print("UI Element Classifier loaded successfully.")
            } catch {
                self.resultLabel.stringValue = "Error loading model: \(error.localizedDescription)"
                print("Error loading UI Element Classifier: \(error.localizedDescription)")
            }
        }
    }

    private func classify(imageURL: URL) {
        guard let classifier = uiElementClassifier else {
            resultLabel.stringValue = "Model not loaded."
            return
        }

        Task { @MainActor in
            resultLabel.stringValue = "Classifying..."
            imageView.image = NSImage(contentsOf: imageURL)

            do {
                if let (type, confidence) = try await classifier.classifyImage(at: imageURL) {
                    resultLabel.stringValue = "\(type) (\(String(format: "%.2f", confidence * 100))%)"
                } else {
                    resultLabel.stringValue = "Could not classify."
                }
            } catch {
                resultLabel.stringValue = "Error: \(error.localizedDescription)"
            }
        }
    }

    // MARK: - NSDraggingDestination

    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation {
        return .copy
    }

    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        guard let pasteboard = sender.draggingPasteboard.propertyList(forType: .fileURL) as? [String],
              let path = pasteboard.first,
              let url = URL(string: path) else {
            return false
        }

        classify(imageURL: url)
        return true
    }
}

// UIElementClassifier (similar to DocumentClassifier but for UI elements)
struct UIElementClassifier {
    private let model: VNCoreMLModel

    init() async throws {
        guard let modelURL = Bundle.main.url(forResource: "UIElementClassifier", withExtension: "mlmodelc") else {
            throw UIElementClassifierError.modelNotFound
        }
        let coreMLModel = try MLModel(contentsOf: modelURL)
        self.model = try VNCoreMLModel(for: coreMLModel)
    }

    func classifyImage(at imageURL: URL) async throws -> (String, Float)? {
        guard let image = NSImage(contentsOf: imageURL),
              let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
            throw UIElementClassifierError.invalidImage
        }

        return try await withCheckedThrowingContinuation { continuation in
            let request = VNCoreMLRequest(model: self.model) { request, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }
                guard let results = request.results as? [VNClassificationObservation],
                      let topResult = results.first else {
                    continuation.resume(returning: nil)
                    return
                }
                continuation.resume(returning: (topResult.identifier, topResult.confidence))
            }
            // Set image crop and scale option, crucial for matching training data
            request.imageCropAndScaleOption = .scaleFill // Or .centerCrop etc.

            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    try handler.perform([request])
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    enum UIElementClassifierError: Error, LocalizedError {
        case modelNotFound
        case invalidImage
        var errorDescription: String? {
            switch self {
            case .modelNotFound: return "UI Element Classifier model not found."
            case .invalidImage: return "Could not load or convert image for classification."
            }
        }
    }
}
