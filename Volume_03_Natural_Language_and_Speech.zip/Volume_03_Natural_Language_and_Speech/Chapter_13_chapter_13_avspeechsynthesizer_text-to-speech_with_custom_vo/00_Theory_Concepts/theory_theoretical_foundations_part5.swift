
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part5.swift
// Description: Theoretical Foundations
// ==========================================

import AVFoundation

// @available(iOS 18.0, *) - For demonstration of modern concurrency features
@available(iOS 18.0, *)
actor SpeechActor: NSObject, AVSpeechSynthesizerDelegate { // Now an actor!
    private let synthesizer = AVSpeechSynthesizer()
    // Internal state, safely managed by the actor
    private var _isSpeaking: Bool = false
    private var _currentUtterance: AVSpeechUtterance?
    private var _spokenWords: String = ""

    // A continuation to bridge the delegate-based API to async/await
    private var currentContinuation: CheckedContinuation<Void, Error>?

    // Public properties to read state (accessed via 'await')
    var isSpeaking: Bool { _isSpeaking }
    var currentUtterance: AVSpeechUtterance? { _currentUtterance }
    var spokenWords: String { _spokenWords }

    override init() {
        super.init()
        synthesizer.delegate = self
    }

    // MARK: - Public API (Actor-isolated)

    /// Synthesizes speech for a given request asynchronously.
    func speak(request: SpeechRequest) async throws {
        // All access to synthesizer and internal state is serialized here
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
            currentContinuation?.resume(throwing: CancellationError())
            currentContinuation = nil
        }

        let utterance = AVSpeechUtterance(request: request)
        _currentUtterance = utterance
        _spokenWords = ""

        try await withCheckedThrowingContinuation { continuation in
            currentContinuation = continuation
            synthesizer.speak(utterance)
        }
    }

    /// Pauses the current speech.
    func pause() {
        if synthesizer.isSpeaking {
            synthesizer.pauseSpeaking(at: .word)
        }
    }

    /// Continues paused speech.
    func `continue`() {
        if synthesizer.isPaused {
            synthesizer.continueSpeaking()
        }
    }

    /// Stops current speech immediately.
    func stop() {
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
            currentContinuation?.resume(throwing: CancellationError())
            currentContinuation = nil
        }
        _currentUtterance = nil
        _spokenWords = ""
    }

    // MARK: - AVSpeechSynthesizerDelegate (Called on an arbitrary thread by AVFoundation)

    // Delegate methods MUST be marked nonisolated if they access actor state
    // and need to be called on an arbitrary thread.
    // However, since `AVSpeechSynthesizer` often calls its delegate methods
    // on the main thread (or a specific internal queue), we need to be careful.
    // For simplicity, we'll assume these delegate methods implicitly hop to
    // the actor's executor if they modify actor state, or explicitly hop to @MainActor
    // for UI updates if needed.
    // A more robust solution might involve sending messages back to the actor.
    // For now, let's keep the `Task { @MainActor in ... }` pattern for UI updates
    // and implicitly rely on the actor's isolation for state updates.

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        // Accessing actor state from non-isolated context requires `await`
        Task { await self.updateState { $0._isSpeaking = true } } // Helper to update actor state
        print("Speech started for: \(utterance.speechString)")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        Task { await self.updateState {
            $0._isSpeaking = false
            $0._currentUtterance = nil
            $0._spokenWords = ""
            $0.currentContinuation?.resume()
            $0.currentContinuation = nil
        }}
        print("Speech finished for: \(utterance.speechString)")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didPause utterance: AVSpeechUtterance) {
        Task { await self.updateState { $0._isSpeaking = false } }
        print("Speech paused for: \(utterance.speechString)")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didContinue utterance: AVSpeechUtterance) {
        Task { await self.updateState { $0._isSpeaking = true } }
        print("Speech continued for: \(utterance.speechString)")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        Task { await self.updateState {
            $0._isSpeaking = false
            $0._currentUtterance = nil
            $0._spokenWords = ""
            $0.currentContinuation?.resume(throwing: CancellationError())
            $0.currentContinuation = nil
        }}
        print("Speech cancelled for: \(utterance.speechString)")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        let word = (utterance.speechString as NSString).substring(with: characterRange)
        Task { await self.updateState { $0._spokenWords = word } }
    }

    // Helper to safely update actor state from a non-isolated context (like delegate methods)
    private func updateState(_ block: @escaping (SpeechActor) -> Void) {
        block(self)
    }
}
