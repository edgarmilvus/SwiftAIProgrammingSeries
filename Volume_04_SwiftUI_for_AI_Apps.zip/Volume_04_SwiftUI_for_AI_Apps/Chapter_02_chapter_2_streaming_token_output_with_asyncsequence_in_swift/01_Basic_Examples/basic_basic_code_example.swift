
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Foundation // For TimeInterval and Task.sleep

// MARK: - 1. The AsyncSequence for AI Token Streaming

/// `TokenStreamer` simulates an AI model generating a response token by token.
/// It conforms to `AsyncSequence`, allowing consumers to `await` each token asynchronously.
///
/// This structure is designed to be lightweight and efficient, providing a clear
/// example of how to create a custom asynchronous sequence.
@available(iOS 15.0, macOS 12.0, *) // AsyncSequence is available from iOS 15 / macOS 12
struct TokenStreamer: AsyncSequence {
    /// The type of element that this sequence produces.
    /// In this case, each element is a `String` representing a single token.
    typealias Element = String

    private let fullResponse: String
    private let tokenDelay: TimeInterval

    /// Initializes the streamer with the full response text and an artificial delay.
    /// - Parameters:
    ///   - fullResponse: The complete text that the AI model would generate.
    ///   - tokenDelay: The time interval (in seconds) to wait before emitting each token.
    ///                 A small delay simulates real-world latency from an AI service.
    init(fullResponse: String, tokenDelay: TimeInterval = 0.05) {
        self.fullResponse = fullResponse
        self.tokenDelay = tokenDelay
    }

    /// Creates and returns an `AsyncIterator` that produces tokens.
    /// This is the primary entry point for consumers to begin iterating over the sequence.
    func makeAsyncIterator() -> TokenIterator {
        return TokenIterator(fullResponse: fullResponse, tokenDelay: tokenDelay)
    }

    /// `TokenIterator` is the actual mechanism that steps through the tokens.
    /// It conforms to `AsyncIteratorProtocol`, providing the `next()` method
    /// that drives the asynchronous token generation.
    struct TokenIterator: AsyncIteratorProtocol {
        /// The type of element that this iterator produces, matching `TokenStreamer.Element`.
        typealias Element = String

        private var words: [String] // Stores the response split into "tokens" (words)
        private var currentIndex: Int = 0 // Tracks the current token being emitted
        private let tokenDelay: TimeInterval // Delay between token emissions

        /// Initializes the iterator with the full response and token delay.
        /// - Parameters:
        ///   - fullResponse: The complete text to be streamed.
        ///   - tokenDelay: The delay between emitting each token.
        init(fullResponse: String, tokenDelay: TimeInterval) {
            // For simplicity, we split the response by whitespace to get "word" tokens.
            // In a real AI system, tokens are often sub-word units or characters.
            self.words = fullResponse.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }
            self.tokenDelay = tokenDelay
        }

        /// Advances to the next token in the sequence.
        /// This method is `async` because token generation is asynchronous, simulating
        /// network latency or AI model computation time.
        /// It's `mutating` because it updates the `currentIndex` to track progress.
        /// - Returns: The next token as a `String`, or `nil` if the sequence has ended.
        /// - Throws: An error if the underlying asynchronous operation fails (e.g., `Task.sleep` can throw `CancellationError`).
        mutating func next() async throws -> String? {
            // Simulate network delay or compute time for generating the next token.
            // In a real application, this might be an actual network request or ML inference.
            try await Task.sleep(for: .milliseconds(Int(tokenDelay * 1000)))

            // Check if the task consuming this iterator has been cancelled.
            // This is crucial for responsive cancellation.
            guard !Task.isCancelled else {
                print("TokenIterator: Task was cancelled, stopping token generation.")
                return nil
            }

            // Check if there are more tokens to emit.
            guard currentIndex < words.count else {
                print("TokenIterator: End of sequence.")
                return nil // No more tokens, sequence has ended
            }

            let token = words[currentIndex]
            currentIndex += 1
            return token
        }
    }
}

// MARK: - 2. SwiftUI ViewModel for Consuming the Stream

/// `ChatViewModel` manages the state for our chat interface,
/// consuming tokens from the `TokenStreamer` and updating the UI.
///
/// By being marked with `@MainActor`, all operations within this class
/// (especially updates to `@Published` properties) are guaranteed to run
/// on the main thread, which is essential for SwiftUI UI updates.
@MainActor
class ChatViewModel: ObservableObject {
    /// The accumulated text from the AI stream, displayed in the UI.
    @Published var streamedOutput: String = ""
    /// A boolean indicating whether a streaming operation is currently active.
    @Published var isStreaming: Bool = false
    /// Stores any error message encountered during streaming.
    @Published var errorMessage: String?

    /// Holds the `Task` responsible for consuming the `AsyncSequence`.
    /// This allows us to cancel the task if needed.
    private var streamTask: Task<Void, Never>?

    /// Starts the token streaming process based on a user prompt.
    /// - Parameter prompt: The user's input prompt. This is used to determine
    ///                     the simulated AI response in this example.
    func startStreaming(for prompt: String) {
        // In a real AI app, 'prompt' would be sent to a backend AI model
        // (e.g., via an API call) or an on-device ML model.
        // Here, we simulate a response based on simple keyword matching.
        let simulatedResponse: String
        if prompt.lowercased().contains("hello") {
            simulatedResponse = "Hello there! I am an AI assistant. How can I help you today?"
        } else if prompt.lowercased().contains("swiftui") {
            simulatedResponse = "SwiftUI is Apple's modern declarative UI framework. It allows you to build user interfaces across all Apple platforms with a single codebase, leveraging Swift's powerful concurrency features."
        } else if prompt.lowercased().contains("ai") || prompt.lowercased().contains("artificial intelligence") {
            simulatedResponse = "Artificial Intelligence is a broad field of computer science focused on creating machines that can perform tasks requiring human intelligence, such as learning, problem-solving, and understanding language."
        }
        else {
            simulatedResponse = "I'm not sure how to respond to that specific prompt, but here's a generic message to demonstrate token streaming. This text will appear word by word."
        }

        // Reset state for a new streaming session.
        streamedOutput = ""
        isStreaming = true
        errorMessage = nil

        // Cancel any previously running streaming task to ensure only one is active.
        streamTask?.cancel()

        // Create a new `Task` to asynchronously consume the `TokenStreamer`.
        // This task will run on a background thread pool, but due to `@MainActor`
        // on the `ChatViewModel`, all `@Published` property updates will be
        // marshaled back to the main thread automatically.
        streamTask = Task {
            do {
                // Initialize our simulated AI token streamer.
                let streamer = TokenStreamer(fullResponse: simulatedResponse, tokenDelay: 0.07) // A slightly faster stream for demonstration

                // Iterate over the asynchronous sequence of tokens.
                // The `for try await` loop will pause execution until `streamer.next()`
                // produces a token, then resume to process it.
                for try await token in streamer {
                    // Crucial check for task cancellation. If the user stopped streaming,
                    // we should exit the loop immediately.
                    guard !Task.isCancelled else {
                        print("Streaming task was cancelled while iterating.")
                        break
                    }
                    streamedOutput += token + " " // Append the new token to our display string.
                }
                isStreaming = false // Streaming finished successfully.
                print("Streaming completed.")
            } catch is CancellationError {
                // Handle explicit task cancellation gracefully.
                print("Streaming task was cancelled.")
                isStreaming = false
            } catch {
                // Catch any other errors that might occur during streaming.
                errorMessage = "Streaming error: \(error.localizedDescription)"
                isStreaming = false
                print("Streaming error: \(error.localizedDescription)")
            }
        }
    }

    /// Stops the current streaming process immediately.
    /// This is achieved by cancelling the underlying `streamTask`.
    func stopStreaming() {
        streamTask?.cancel()
        streamTask = nil // Clear the task reference
        isStreaming = false
        print("Streaming stopped by user.")
    }

    /// `deinit` is called when the `ChatViewModel` is deallocated.
    /// It's crucial to cancel any running tasks here to prevent memory leaks
    /// or unexpected behavior if the ViewModel is destroyed while a task is active.
    deinit {
        streamTask?.cancel()
        print("ChatViewModel deinitialized, streaming task cancelled.")
    }
}

// MARK: - 3. SwiftUI View for Displaying the Streamed Output

/// `AIChatView` is a simple SwiftUI view that provides a user interface
/// for interacting with our simulated AI chat assistant and displaying
/// its streaming responses.
@available(iOS 17.0, macOS 14.0, *) // Targeting a recent iOS version for modern SwiftUI features
struct AIChatView: View {
    /// `@StateObject` creates and manages the lifecycle of our `ChatViewModel`.
    /// SwiftUI ensures the ViewModel persists as long as the View is active
    /// and automatically observes its `@Published` properties for UI updates.
    @StateObject private var viewModel = ChatViewModel()
    /// `@State` for the user's input prompt in the `TextField`.
    @State private var chatPrompt: String = ""

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 15) {
                Text("AI Chat Assistant")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.bottom, 10)

                // User input field for the chat prompt.
                TextField("Ask me something (e.g., 'hello', 'swiftui', 'AI')", text: $chatPrompt)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                // Action buttons to start and stop streaming.
                HStack {
                    Button("Start Streaming") {
                        // If the prompt is empty, use a generic message to start streaming.
                        viewModel.startStreaming(for: chatPrompt.isEmpty ? "generic message" : chatPrompt)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(viewModel.isStreaming) // Disable if already streaming

                    Button("Stop Streaming") {
                        viewModel.stopStreaming()
                    }
                    .buttonStyle(.bordered)
                    .tint(.red)
                    .disabled(!viewModel.isStreaming) // Disable if not streaming
                }
                .padding(.horizontal)

                Divider() // Visual separator

                // Display area for the streamed AI output.
                ScrollView {
                    Text(viewModel.streamedOutput.isEmpty && !viewModel.isStreaming ?
                         "Enter a prompt and tap 'Start Streaming' to see AI responses appear token by token." :
                         viewModel.streamedOutput)
                        .font(.body)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                        // This animation makes the text appear smoothly as it's appended.
                        // It applies a linear animation to changes in `streamedOutput`.
                        .animation(.linear(duration: 0.1), value: viewModel.streamedOutput)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity) // Make the scroll view fill available space

                // Display any error messages.
                if let errorMessage = viewModel.errorMessage {
                    Text("Error: \(errorMessage)")
                        .foregroundColor(.red)
                        .padding(.horizontal)
                }
            }
            .padding()
            .navigationTitle("") // Hide default navigation title for a cleaner look
            .navigationBarHidden(true) // Hide navigation bar
        }
    }
}

// MARK: - 4. App Entry Point (for Xcode Preview and App)

/// The main entry point for the SwiftUI application.
/// This structure defines the root view for the app.
@main
@available(iOS 17.0, macOS 14.0, *)
struct StreamingAIApp: App {
    var body: some Scene {
        WindowGroup {
            AIChatView()
        }
    }
}
