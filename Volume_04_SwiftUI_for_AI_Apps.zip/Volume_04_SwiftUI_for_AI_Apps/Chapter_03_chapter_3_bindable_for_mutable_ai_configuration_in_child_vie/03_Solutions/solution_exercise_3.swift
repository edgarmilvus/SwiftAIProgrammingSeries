
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
import SwiftUI

// 1. Define a Protocol for Pipeline Stages
protocol PipelineStageConfiguration: Observable, Identifiable {
    var id: UUID { get }
    var name: String { get set }
    // Add a computed property for summary description (optional, but useful for UI)
    var description: String { get }
}

// 2. Create Concrete Observable Stage Classes
@Observable
class PreprocessingConfig: PipelineStageConfiguration {
    let id = UUID()
    var name: String = "Data Preprocessing"
    var normalizationEnabled: Bool = true
    var scalingFactor: Double = 1.0

    var description: String {
        "Normalization: \(normalizationEnabled ? "Enabled" : "Disabled"), Scale: \(scalingFactor, specifier: "%.1f")"
    }
}

@Observable
class FeatureExtractionConfig: PipelineStageConfiguration {
    let id = UUID()
    var name: String = "Feature Extraction"
    var embeddingModel: String = "BERT-base-uncased"
    var outputDimension: Int = 768

    var description: String {
        "Model: \(embeddingModel), Dim: \(outputDimension)"
    }
}

@Observable
class InferenceConfig: PipelineStageConfiguration {
    let id = UUID()
    var name: String = "Model Inference"
    var modelPath: String = "/models/my_llm.bin"
    var batchSize: Int = 32
    var enableGPU: Bool = true

    var description: String {
        "Batch: \(batchSize), GPU: \(enableGPU ? "Yes" : "No")"
    }
}

// 3. Define the AIPipeline Object
@Observable
class AIPipeline {
    // Use 'any' keyword for type erasure when storing protocol types
    var stages: [any PipelineStageConfiguration]

    init() {
        self.stages = [
            PreprocessingConfig(),
            FeatureExtractionConfig(),
            InferenceConfig()
        ]
    }
}

// 4. Main PipelineEditorView
@available(iOS 18.0, macOS 15.0, *)
struct PipelineEditorView: View {
    @StateObject private var pipeline = AIPipeline()
    // Use 'any' for the selected stage as its concrete type is unknown at compile time
    @State private var selectedStage: (any PipelineStageConfiguration)? = nil
    @State private var showSettingsSheet = false

    var body: some View {
        // NavigationStack is the modern approach for navigation
        NavigationStack {
            List {
                ForEach(pipeline.stages) { stage in
                    Button {
                        selectedStage = stage
                        showSettingsSheet = true
                    } label: {
                        VStack(alignment: .leading) {
                            Text(stage.name)
                                .font(.headline)
                            // Display specific details based on the concrete type
                            Text(stage.description) // Leverage the description computed property
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("AI Pipeline Editor")
            .sheet(isPresented: $showSettingsSheet) {
                if let selectedStage {
                    // 5. Pass the specific stage to StageSettingsView using @Bindable
                    // The @Bindable wrapper handles the 'any' type erasure correctly.
                    StageSettingsView(stage: selectedStage)
                }
            }
        }
    }
}

// 5. StageSettingsView for Dynamic Editing
@available(iOS 18.0, macOS 15.0, *)
struct StageSettingsView: View {
    @Bindable var stage: any PipelineStageConfiguration // Receive the 'any' type
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationStack { // Use NavigationStack inside sheet for toolbar
            Form {
                Section("General Settings") {
                    TextField("Stage Name", text: $stage.name)
                }

                Section("Specific Parameters") {
                    // Dynamically display controls based on the concrete type using 'if let as?'
                    if let preproc = stage as? PreprocessingConfig {
                        Toggle("Normalization Enabled", isOn: $preproc.normalizationEnabled)
                        HStack {
                            Text("Scaling Factor:")
                            Slider(value: $preproc.scalingFactor, in: 0.1...5.0, step: 0.1) {
                                Text("Scaling Factor")
                            } minimumValueLabel: {
                                Text("0.1")
                            } maximumValueLabel: {
                                Text("5.0")
                            }
                            Text("\(preproc.scalingFactor, specifier: "%.1f")")
                        }
                    } else if let feature = stage as? FeatureExtractionConfig {
                        TextField("Embedding Model", text: $feature.embeddingModel)
                        HStack {
                            Text("Output Dimension:")
                            Stepper(value: $feature.outputDimension, in: 64...2048, step: 64) {
                                Text("\(feature.outputDimension)")
                            }
                        }
                    } else if let inference = stage as? InferenceConfig {
                        TextField("Model Path", text: $inference.modelPath)
                        HStack {
                            Text("Batch Size:")
                            Stepper(value: $inference.batchSize, in: 1...256, step: 1) {
                                Text("\(inference.batchSize)")
                            }
                        }
                        Toggle("Enable GPU", isOn: $inference.enableGPU)
                    } else {
                        Text("Unknown stage configuration type.")
                    }
                }
            }
            .navigationTitle(stage.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}
