
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI
    import Observation // For @Observable

    @available(iOS 17.0, *) // @Observable requires iOS 17+
    @Observable
    class NoteManager {
        var notes: [Note] = []

        func addNote(title: String, content: String, summary: String? = nil) {
            let newNote = Note(id: UUID(), title: title, content: content, summary: summary, date: Date())
            notes.append(newNote)
            print("Note added: \(newNote.title)")
        }

        func updateNoteSummary(id: UUID, newSummary: String) {
            if let index = notes.firstIndex(where: { $0.id == id }) {
                notes[index].summary = newSummary
                print("Note \(id) summary updated.")
            }
        }
    }

    struct Note: Identifiable {
        let id: UUID
        var title: String
        var content: String
        var summary: String?
        let date: Date
    }

    // An AppIntent could update this NoteManager
    @available(iOS 18.0, *)
    struct UpdateNoteWithAISummaryIntent: AppIntent {
        static var title: LocalizedStringResource = "Update Note with AI Summary"

        @Parameter(title: "Note ID")
        var noteID: UUID

        @Parameter(title: "Summary Text")
        var summaryText: String

        // Assume NoteManager is accessible, e.g., via environment or shared instance
        // For simplicity, let's use a placeholder. In a real app, inject this.
        private var noteManager: NoteManager {
            // This is a simplification. Use proper dependency injection.
            if let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as? UIWindowSceneDelegate,
               let window = sceneDelegate.window,
               let rootVC = window?.rootViewController as? UIHostingController<ContentView> {
                // Access the NoteManager from the environment of ContentView
                // This is highly coupled and not ideal for production.
                // A better approach would be a shared singleton or actor, or passing it.
                return rootVC.rootView.noteManager // Assuming ContentView has a noteManager
            }
            // Fallback for demonstration
            return NoteManager()
        }

        func perform() async throws -> some IntentResult {
            noteManager.updateNoteSummary(id: noteID, newSummary: summaryText)
            return .result()
        }
    }
    