
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation
import BackgroundTasks
import UIKit // For AppDelegate context

// MARK: - Helper Logger (for all exercises)
struct Logger {
    static func log(_ message: String, category: String = "BackgroundTasks", isError: Bool = false) {
        let timestamp = DateFormatter.localizedString(from: Date(), dateStyle: .medium, timeStyle: .medium)
        let level = isError ? "ERROR" : "INFO"
        print("[\(timestamp)] [\(category)] [\(level)] \(message)")
    }
}

// MARK: - Document and Embedding Management (for Exercise 4)
struct Document: Codable, Hashable, Identifiable {
    let id: String
    let url: URL
    var isProcessed: Bool
    var embeddingsCount: Int? // To store how many embeddings were generated
}

struct DocumentChunk: Codable {
    let documentId: String
    let chunkIndex: Int
    let text: String
    var embeddings: [Float]? // Optional, as it might not be generated yet
}

// MARK: - Local LLM Simulation (for Exercise 4)
struct LocalLLM {
    static let shared = LocalLLM()

    enum LLMError: Error {
        case cancellation
        case processingFailed(String)
    }

    func extractAndChunkText(from url: URL) async throws -> [String] {
        try Task.checkCancellation()
        Logger.log("Extracting and chunking text from \(url.lastPathComponent)...", category: "LocalLLM")
        try await Task.sleep(nanoseconds: 500_000_000) // Simulate text extraction time

        guard let content = try? String(contentsOf: url) else {
            throw LLMError.processingFailed("Failed to read content from \(url.lastPathComponent)")
        }

        // Simple chunking: split by sentence or fixed length
        let sentences = content.components(separatedBy: ". ").filter { !$0.isEmpty }
        var chunks: [String] = []
        var currentChunk = ""
        let maxChunkLength = 100 // characters

        for sentence in sentences {
            if currentChunk.count + sentence.count + 2 > maxChunkLength && !currentChunk.isEmpty {
                chunks.append(currentChunk.trimmingCharacters(in: .whitespacesAndNewlines))
                currentChunk = ""
            }
            currentChunk += sentence + ". "
        }
        if !currentChunk.isEmpty {
            chunks.append(currentChunk.trimmingCharacters(in: .whitespacesAndNewlines))
        }

        Logger.log("Extracted \(chunks.count) chunks from \(url.lastPathComponent).", category: "LocalLLM")
        return chunks
    }

    func generateEmbeddings(for textChunk: String) async throws -> [Float] {
        try Task.checkCancellation()
        Logger.log("Generating embeddings for a chunk (length: \(textChunk.count))...", category: "LocalLLM")
        try await Task.sleep(nanoseconds: 1_000_000_000) // Simulate CPU-intensive embedding generation

        // Simulate generating a fixed-size embedding vector
        let embeddingSize = 128
        let embeddings = (0..<embeddingSize).map { _ in Float.random(in: -1.0...1.0) }

        Logger.log("Generated \(embeddings.count) embeddings.", category: "LocalLLM")
        return embeddings
    }
}

// MARK: - AppDelegate / SceneDelegate context
class AppDelegate: UIResponder, UIApplicationDelegate {

    // MARK: - Background Task Identifiers
    static let embeddingsGenerationTaskIdentifier = "com.example.app.generateEmbeddings"
    // Other task identifiers for subsequent exercises would go here
    // ...

    // Cancellation token for the embeddings generation task
    private var embeddingsGenerationTaskCancellationToken: Task<Void, Never>?

    // For Exercise 4
    private var documentsToProcess: [Document] = []
    private let documentDirectory: URL = {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("RAGDocuments")
    }()
    private let embeddingsStorageURL: URL = {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("EmbeddingsStore")
    }()

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        Logger.log("App finished launching.", category: "AppDelegate")

        // Initialize document directory for Exercise 4
        try? FileManager.default.createDirectory(at: documentDirectory, withIntermediateDirectories: true, attributes: nil)
        try? FileManager.default.createDirectory(at: embeddingsStorageURL, withIntermediateDirectories: true, attributes: nil)
        Logger.log("RAG Documents directory initialized at: \(documentDirectory.path)", category: "Exercise 4 Setup")
        Logger.log("Embeddings storage directory initialized at: \(embeddingsStorageURL.path)", category: "Exercise 4 Setup")

        // Load or simulate initial documents for Exercise 4
        loadDocumentsToProcess()
        if documentsToProcess.isEmpty {
            for i in 1...3 {
                let docURL = documentDirectory.appendingPathComponent("document_\(i).txt")
                let content = "This is the content for document \(i). It contains some sample text that needs to be processed into embeddings for the RAG system. The more text, the more chunks and embeddings. This document is quite long and will be chunked into multiple pieces for embedding generation. Each piece will then have its own vector representation."
                try? content.write(to: docURL, atomically: true, encoding: .utf8)
                documentsToProcess.append(Document(id: "doc_\(i)", url: docURL, isProcessed: false))
            }
            saveDocumentsToProcess()
            Logger.log("Simulated initial documents for embedding generation.", category: "Exercise 4 Setup")
        }

        registerBackgroundTasks() // Register all background tasks
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        Logger.log("App entered background. Scheduling tasks...", category: "AppDelegate")
        scheduleEmbeddingsGeneration() // Schedule the embeddings generation task
        // Other task scheduling for subsequent exercises would go here
        // ...
    }

    // MARK: - Task Registration
    private func registerBackgroundTasks() {
        Logger.log("Registering background tasks...", category: "BGTaskScheduler")

        // Exercise 4: Processing Task (Embeddings Generation)
        BGTaskScheduler.shared.register(forIdentifier: AppDelegate.embeddingsGenerationTaskIdentifier, using: nil) { task in
            Logger.log("Received BGProcessingTask: \(task.identifier)", category: "BGTaskScheduler")
            self.handleEmbeddingGeneration(task: task as! BGProcessingTask)
        }
    }

    // MARK: - Task Scheduling
    private func scheduleEmbeddingsGeneration() {
        let request = BGProcessingTaskRequest(identifier: AppDelegate.embeddingsGenerationTaskIdentifier)
        request.requiresNetworkAccess = false // Local model
        request.requiresExternalPower = true // CPU/memory intensive
        request.earliestBeginDate = Date(timeIntervalSinceNow: 60 * 60 * 1) // Try every hour, or when conditions are optimal

        do {
            try BGTaskScheduler.shared.submit(request)
            Logger.log("Scheduled BGProcessingTask for \(AppDelegate.embeddingsGenerationTaskIdentifier)", category: "BGTaskScheduler")
        } catch {
            Logger.log("Could not schedule embeddings generation task: \(error.localizedDescription)", category: "BGTaskScheduler", isError: true)
        }
    }

    // MARK: - Document Persistence for Exercise 4
    private func saveDocumentsToProcess() {
        do {
            let data = try JSONEncoder().encode(documentsToProcess)
            let fileURL = documentDirectory.appendingPathComponent("documents_state.json")
            try data.write(to: fileURL)
            Logger.log("Documents state saved.", category: "Exercise 4 Persistence")
        } catch {
            Logger.log("Failed to save documents state: \(error.localizedDescription)", category: "Exercise 4 Persistence", isError: true)
        }
    }

    private func loadDocumentsToProcess() {
        let fileURL = documentDirectory.appendingPathComponent("documents_state.json")
        if FileManager.default.fileExists(atPath: fileURL.path) {
            do {
                let data = try Data(contentsOf: fileURL)
                documentsToProcess = try JSONDecoder().decode([Document].self, from: data)
                Logger.log("Documents state loaded. \(documentsToProcess.count) documents.", category: "Exercise 4 Persistence")
            } catch {
                Logger.log("Failed to load documents state: \(error.localizedDescription)", category: "Exercise 4 Persistence", isError: true)
            }
        }
    }

    // MARK: - Task Handlers

    // Exercise 4: Local LLM Embeddings Generation Handler
    private func handleEmbeddingGeneration(task: BGProcessingTask) {
        Logger.log("Starting embeddings generation task...", category: "EmbeddingsGeneration")

        embeddingsGenerationTaskCancellationToken = Task {
            var success = true
            var processedDocumentCount = 0

            do {
                // Set the expiration handler immediately.
                task.expirationHandler = {
                    Logger.log("Embeddings generation task expired. Cancelling...", category: "EmbeddingsGeneration", isError: true)
                    self.embeddingsGenerationTaskCancellationToken?.cancel() // Cancel the async Task
                    task.setTaskCompleted(success: false)
                }

                // Identify new/unprocessed documents
                let unprocessedDocuments = documentsToProcess.filter { !$0.isProcessed }
                Logger.log("Found \(unprocessedDocuments.count) unprocessed documents.", category: "EmbeddingsGeneration")

                guard !unprocessedDocuments.isEmpty else {
                    Logger.log("No new documents to process for embeddings.", category: "EmbeddingsGeneration")
                    task.setTaskCompleted(success: true)
                    self.embeddingsGenerationTaskCancellationToken = nil
                    return
                }

                // Process each document
                for index in documentsToProcess.indices {
                    let document = documentsToProcess[index]
                    guard !document.isProcessed else { continue } // Skip already processed

                    Logger.log("Processing document: \(document.id) at \(document.url.lastPathComponent)", category: "EmbeddingsGeneration")

                    do {
                        // 1. Text Extraction & Chunking
                        let chunks = try await LocalLLM.shared.extractAndChunkText(from: document.url)
                        try Task.checkCancellation()

                        var generatedEmbeddingsCount = 0
                        var documentChunksWithEmbeddings: [DocumentChunk] = []

                        // 2. Embeddings Generation for each chunk
                        for (chunkIndex, chunk) in chunks.enumerated() {
                            try Task.checkCancellation() // Check cancellation before each intensive operation
                            let embeddings = try await LocalLLM.shared.generateEmbeddings(for: chunk)

                            documentChunksWithEmbeddings.append(DocumentChunk(documentId: document.id, chunkIndex: chunkIndex, text: chunk, embeddings: embeddings))
                            generatedEmbeddingsCount += 1
                        }

                        // 3. Local Storage (Simulated)
                        // In a real app, this would be storing in a vector database.
                        // For this exercise, we'll save it to a file per document.
                        let encoder = JSONEncoder()
                        encoder.outputFormatting = .prettyPrinted
                        let embeddingsData = try encoder.encode(documentChunksWithEmbeddings)
                        let fileURL = embeddingsStorageURL.appendingPathComponent("\(document.id)_embeddings.json")
                        try embeddingsData.write(to: fileURL)
                        Logger.log("Stored \(generatedEmbeddingsCount) embeddings for document \(document.id) to \(fileURL.lastPathComponent)", category: "EmbeddingsGeneration")

                        // 4. Mark as Processed
                        documentsToProcess[index].isProcessed = true
                        documentsToProcess[index].embeddingsCount = generatedEmbeddingsCount
                        processedDocumentCount += 1
                        Logger.log("Document \(document.id) processed successfully.", category: "EmbeddingsGeneration")

                        // Save state after each document to persist progress
                        saveDocumentsToProcess()

                    } catch {
                        if let llmError = error as? LocalLLM.LLMError, llmError == .cancellation || Task.isCancelled {
                            Logger.log("Processing for document \(document.id) cancelled.", category: "EmbeddingsGeneration", isError: true)
                            success = false // Mark overall task as failed if any document was interrupted
                            break // Stop processing further documents
                        } else {
                            Logger.log("Failed to process document \(document.id): \(error.localizedDescription)", category: "EmbeddingsGeneration", isError: true)
                            // Decide if a single document failure should fail the whole task or just skip this document.
                            // For this exercise, we'll let it continue to other documents but mark overall success as false.
                            success = false
                            // Optionally, mark this specific document as failed for later retry
                        }
                    }
                }

                if processedDocumentCount == unprocessedDocuments.count && success {
                    Logger.log("All new documents processed for embeddings successfully.", category: "EmbeddingsGeneration")
                    success = true
                } else {
                    Logger.log("Embeddings generation completed with some failures or cancellations.", category: "EmbeddingsGeneration", isError: true)
                    success = false
                }

            } catch { // Catch any errors from initial setup or unexpected issues
                Logger.log("Embeddings generation task encountered a critical error: \(error.localizedDescription)", category: "EmbeddingsGeneration", isError: true)
                success = false
            }

            task.setTaskCompleted(success: success)
            self.embeddingsGenerationTaskCancellationToken = nil // Clear the reference
        }
    }
}

/*
// --- Info.plist Configuration ---
// Add the following key-value pair to your app's Info.plist file:
//
// <key>BGTaskSchedulerPermittedIdentifiers</key>
// <array>
//     <string>com.example.app.generateEmbeddings</string>
//     <!-- Add other identifiers here -->
// </array>
*/
