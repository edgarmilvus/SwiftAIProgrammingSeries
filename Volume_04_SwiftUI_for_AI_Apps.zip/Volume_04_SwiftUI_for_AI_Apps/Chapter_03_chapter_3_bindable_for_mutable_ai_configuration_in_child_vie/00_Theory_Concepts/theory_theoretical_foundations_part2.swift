
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

    // MARK: - AI Model Actor
    @available(iOS 18.0, *)
    actor ModelInferenceActor {
        private var currentConfig: AIModelConfiguration

        init(initialConfig: AIModelConfiguration) {
            self.currentConfig = initialConfig
        }

        func updateConfiguration(newConfig: AIModelConfiguration) {
            self.currentConfig = newConfig // Safely update internal config
            print("ModelInferenceActor updated config to: \(newConfig.modelIdentifier), temp: \(newConfig.temperature)")
        }

        func performInference() async throws -> String {
            // Simulate a heavy AI inference task
            print("Performing inference with config: \(currentConfig.modelIdentifier), temp: \(currentConfig.temperature)")
            try await Task.sleep(for: .seconds(2))
            return "Generated response based on config: \(currentConfig.modelIdentifier)"
        }
    }

    // Example of how the parent view might interact with an actor
    @available(iOS 18.0, *)
    struct ContentViewActorIntegration: View {
        @State private var config = AIModelConfiguration()
        @State private var inferenceActor: ModelInferenceActor?
        @State private var inferenceResult: String?

        var body: some View {
            NavigationStack {
                VStack {
                    Text("Current Temperature: \(config.temperature, specifier: "%.2f")")
                    AIConfigurationEditor(configuration: config)

                    Button("Initialize Model Actor") {
                        inferenceActor = ModelInferenceActor(initialConfig: config)
                    }
                    .disabled(inferenceActor != nil)

                    Button("Update Actor Config & Perform Inference") {
                        Task {
                            if let actor = inferenceActor {
                                await actor.updateConfiguration(newConfig: config) // Pass current config
                                inferenceResult = try await actor.performInference()
                            }
                        }
                    }
                    .disabled(inferenceActor == nil)

                    if let result = inferenceResult {
                        Text("Inference Result: \(result)")
                            .font(.headline)
                            .padding()
                    }
                }
                .navigationTitle("AI App Settings (Actor)")
            }
        }
    }
    