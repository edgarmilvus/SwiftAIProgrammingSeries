
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN

@available(iOS 18.0, macOS 15.0, *)
final class SimpleLinearModel: MLXNN.Module {
    let weight: MLXArray
    let bias: MLXArray

    init(inputFeatures: Int, outputFeatures: Int) {
        self.weight = MLXArray.random(
            shape: [outputFeatures, inputFeatures],
            initializer: .uniform(low: -0.01, high: 0.01)
        )
        self.bias = MLXArray.zeros(shape: [outputFeatures])
        super.init() // Call super.init() after all properties are initialized
    }

    func callAsFunction(_ input: MLXArray) -> MLXArray {
        // Operations on MLXArrays, leveraging Unified Memory
        return MLX.linear(input, weight: weight, bias: bias)
    }
}

// Example usage:
@available(iOS 18.0, macOS 15.0, *)
func demonstrateModel() {
    let model = SimpleLinearModel(inputFeatures: 768, outputFeatures: 128)
    let input = MLXArray.random(shape: [1, 768])
    let output = model(input) // Lazy evaluation: graph built here
    print("Output shape: \(output.shape)") // .eval() implicitly called here to get shape
}
