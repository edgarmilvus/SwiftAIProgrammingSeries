
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import MLX
import MLXNN

@available(iOS 18.0, *)
class TextEmbeddingModel: MLXNN.Module {
    let embeddingLayer: MLXNN.Embedding
    let projectionLayer: MLXNN.Linear

    init(vocabularySize: Int, embeddingDimension: Int, outputDimension: Int) {
        self.embeddingLayer = MLXNN.Embedding(
            outputFeatures: embeddingDimension,
            inputFeatures: vocabularySize
        )
        self.projectionLayer = MLXNN.Linear(
            inputFeatures: embeddingDimension,
            outputFeatures: outputDimension
        )
        super.init() // Call super.init() after all properties are initialized
    }

    // The forward pass: takes token IDs, outputs an embedding vector
    override func callAsFunction(_ inputs: MLXArray) -> MLXArray {
        // inputs: [batch_size, sequence_length] of token IDs
        let embedded = embeddingLayer(inputs) // [batch_size, sequence_length, embedding_dimension]

        // Simple mean pooling across the sequence dimension
        let pooled = MLX.mean(embedded, axis: 1) // [batch_size, embedding_dimension]

        // Project to the final output dimension
        return projectionLayer(pooled) // [batch_size, output_dimension]
    }
}

// Example usage:
@available(iOS 18.0, *)
func createAndUseEmbeddingModel() {
    let vocabSize = 10000
    let embedDim = 256
    let outputDim = 128
    let model = TextEmbeddingModel(vocabularySize: vocabSize, embeddingDimension: embedDim, outputDimension: outputDim)

    // Simulate a batch of tokenized input (e.g., from a tokenizer)
    // Here, just random integers representing token IDs
    let inputTokens = MLXArray.randomUniform(low: 0, high: Float(vocabSize), [2, 10], type: .int32)

    // Perform inference to get embeddings
    let embeddings = model(inputTokens)
    print("Generated embeddings shape: \(embeddings.shape)") // e.g., [2, 128]
    // The 'embeddings' MLXArray now holds the semantic representations
    // in unified memory, ready for further processing (e.g., similarity search).
}
