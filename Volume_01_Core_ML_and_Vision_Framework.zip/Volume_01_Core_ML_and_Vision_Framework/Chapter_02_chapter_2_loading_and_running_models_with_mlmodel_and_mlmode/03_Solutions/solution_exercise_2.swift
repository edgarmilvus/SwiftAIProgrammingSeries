
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import CoreML
import Foundation // For CFAbsoluteTimeGetCurrent()
import UIKit // For UIImage and CVPixelBuffer conversion

// Reusing the UIImage extension from Exercise 1
extension UIImage {
    func toCVPixelBuffer(targetSize: CGSize, pixelFormat: OSType = kCVPixelFormatType_32BGRA) -> CVPixelBuffer? {
        let width = Int(targetSize.width)
        let height = Int(targetSize.height)

        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(nil, width, height, pixelFormat, nil, &pixelBuffer)

        guard status == kCVReturnSuccess, let buffer = pixelBuffer else {
            print("Error creating CVPixelBuffer: \(status)")
            return nil
        }

        CVPixelBufferLockBaseAddress(buffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(buffer, .readOnly) }

        let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue
        )

        guard let cgImage = self.cgImage else {
            print("Failed to get CGImage from UIImage.")
            return nil
        }

        context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        return buffer
    }
}

// Extension to make MLComputeUnits printable for clearer output
extension MLComputeUnits: CustomStringConvertible {
    public var description: String {
        switch self {
        case .cpuOnly: return "CPU Only"
        case .cpuAndGPU: return "CPU and GPU"
        case .all: return "All Available (CPU, GPU, Neural Engine)"
        case .cpuAndNeuralEngine: return "CPU and Neural Engine"
        @unknown default: return "Unknown Compute Unit"
        }
    }
}

// MARK: - ModelBenchmark Class

@available(iOS 17.0, *)
class ModelBenchmark {
    private let modelURL: URL
    private let imageInput: MLFeatureProvider // Pre-prepared input for consistent benchmarking
    private let modelInputName: String
    private let modelImageSize: CGSize

    /// Initializes the benchmark with model details and a single image input.
    /// - Parameters:
    ///   - modelURL: URL to the compiled Core ML model.
    ///   - sampleImage: A UIImage to be used as a consistent input for all benchmarks.
    ///   - modelInputName: The name of the image input feature in the model (e.g., "image").
    ///   - modelImageSize: The expected input image size for the model (e.g., 224x224).
    init?(modelURL: URL, sampleImage: UIImage, modelInputName: String, modelImageSize: CGSize) {
        self.modelURL = modelURL
        self.modelInputName = modelInputName
        self.modelImageSize = modelImageSize

        guard let pixelBuffer = sampleImage.toCVPixelBuffer(targetSize: modelImageSize) else {
            print("Failed to convert sample image to CVPixelBuffer. Benchmark cannot proceed.")
            return nil
        }
        do {
            self.imageInput = try MLDictionaryFeatureProvider(dictionary: [modelInputName: MLFeatureValue(pixelBuffer: pixelBuffer)])
        } catch {
            print("Failed to create MLFeatureProvider from sample image: \(error.localizedDescription). Benchmark cannot proceed.")
            return nil
        }
    }

    /// Runs benchmarks for different compute unit configurations.
    /// - Parameter numberOfInferences: The number of times to run prediction for each configuration.
    func runBenchmarks(numberOfInferences: Int = 20) {
        // Define compute unit options to test.
        // .cpuAndNeuralEngine is available on devices with an Apple Neural Engine (A11 Bionic and newer).
        // .all will automatically use Neural Engine if available, otherwise GPU.
        var computeUnitsOptions: [MLComputeUnits] = [
            .cpuOnly,
            .cpuAndGPU,
            .all
        ]

        // Conditionally add .cpuAndNeuralEngine if targeting devices that explicitly support it
        // This check is more conceptual, in real apps you'd typically rely on .all or specific device checks.
        // For demonstration, we'll assume it's relevant to test explicitly.
        if #available(iOS 13.0, *), ProcessInfo.processInfo.isOperatingSystemAtLeast(OperatingSystemVersion(majorVersion: 13, minorVersion: 0, patchVersion: 0)) {
            // Note: There's no direct API to check for Neural Engine presence,
            // but A11 Bionic (iPhone 8/X) and newer chips have it.
            // Using .all is generally sufficient, but for explicit testing, one might add this.
            computeUnitsOptions.append(.cpuAndNeuralEngine)
        }

        print("\n--- Core ML Compute Unit Benchmarks ---")
        print("Model: \(modelURL.lastPathComponent), Inferences per unit: \(numberOfInferences)")
        print("Input Image Size: \(Int(modelImageSize.width))x\(Int(modelImageSize.height))\n")

        for units in computeUnitsOptions {
            var configuration = MLModelConfiguration()
            configuration.computeUnits = units

            do {
                let model = try MLModel(contentsOf: modelURL, configuration: configuration)
                var totalTime: TimeInterval = 0

                // Warm-up run: The first few predictions can be slower due to JIT compilation,
                // caching, or device initialization. A warm-up helps get more stable measurements.
                _ = try model.prediction(input: imageInput)

                for i in 0..<numberOfInferences {
                    let startTime = CFAbsoluteTimeGetCurrent()
                    _ = try model.prediction(input: imageInput)
                    let endTime = CFAbsoluteTimeGetCurrent()
                    totalTime += (endTime - startTime)
                    // print("  \(units) run \(i+1): \((endTime - startTime) * 1000) ms") // Uncomment for verbose logging
                }

                let averageTime = totalTime / Double(numberOfInferences)
                print("Compute Units: \(units) | Average Inference Time: \(String(format: "%.4f", averageTime * 1000)) ms")

            } catch {
                print("Error benchmarking with \(units) compute units: \(error.localizedDescription)")
            }
        }
        print("\n--- Benchmarks Complete ---")
    }
}

// MARK: - Example Usage in a ViewController

@available(iOS 17.0, *)
class BenchmarkViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        runModelBenchmarks()
    }

    private func runModelBenchmarks() {
        // IMPORTANT: Replace "MobileNetV3" with your actual model name
        // and adjust input details.
        guard let modelURL = Bundle.main.url(forResource: "MobileNetV3", withExtension: "mlmodelc") else {
            print("Error: MobileNetV3.mlmodelc not found in bundle.")
            return
        }

        guard let sampleImage = UIImage(named: "sampleImage") else {
            print("Error: 'sampleImage' asset not found.")
            return
        }

        // Initialize the benchmark with the model and a consistent input image
        if let benchmark = ModelBenchmark(
            modelURL: modelURL,
            sampleImage: sampleImage,
            modelInputName: "image", // Adjust according to your model's input feature name
            modelImageSize: CGSize(width: 224, height: 224) // Adjust according to your model's input image size
        ) {
            benchmark.runBenchmarks(numberOfInferences: 50) // More inferences for better average
        } else {
            print("Failed to initialize ModelBenchmark.")
        }
    }
}

// To run this example:
// 1. Create a new iOS project or add to an existing one.
// 2. Drag a compiled Core ML model (e.g., MobileNetV3.mlmodelc) into your project.
// 3. Add an image named "sampleImage" to your Assets.xcassets.
// 4. Call `runModelBenchmarks()` from your `ViewController` (e.g., in `viewDidLoad`).
