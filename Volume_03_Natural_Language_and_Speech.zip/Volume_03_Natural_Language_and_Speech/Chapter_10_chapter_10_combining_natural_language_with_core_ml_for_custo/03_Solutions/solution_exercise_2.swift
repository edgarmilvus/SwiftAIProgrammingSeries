
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit // Or AppKit for macOS
import CoreML
import NaturalLanguage // Not strictly required for this basic model, but good to include.

// Assume InappropriateContentClassifier.mlmodel has been added to the project
// and Xcode has automatically generated the InappropriateContentClassifier class.

class ContentModerationViewController: UIViewController { // Use NSViewController for macOS
    // UI Elements
    private let commentTextView: UITextView = { // NSTextView for macOS
        let textView = UITextView()
        textView.font = .systemFont(ofSize: 17)
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 5.0
        textView.translatesAutoresizingMaskIntoConstraints = false
        return textView
    }()

    private let classifyButton: UIButton = { // NSButton for macOS
        let button = UIButton(type: .system)
        button.setTitle("Classify Comment", for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let resultLabel: UILabel = { // NSTextField for macOS
        let label = UILabel()
        label.text = "Prediction: "
        label.font = .boldSystemFont(ofSize: 18)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // Core ML Model instance
    private var classifier: InappropriateContentClassifier?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadModel()
    }

    private func setupUI() {
        view.backgroundColor = .white // For iOS, NSColor.white for macOS

        view.addSubview(commentTextView)
        view.addSubview(classifyButton)
        view.addSubview(resultLabel)

        // Layout constraints (simplified for brevity, use Auto Layout fully in real app)
        NSLayoutConstraint.activate([
            commentTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            commentTextView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            commentTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            commentTextView.heightAnchor.constraint(equalToConstant: 150),

            classifyButton.topAnchor.constraint(equalTo: commentTextView.bottomAnchor, constant: 20),
            classifyButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            classifyButton.widthAnchor.constraint(equalToConstant: 200),
            classifyButton.heightAnchor.constraint(equalToConstant: 50),

            resultLabel.topAnchor.constraint(equalTo: classifyButton.bottomAnchor, constant: 20),
            resultLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            resultLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])

        classifyButton.addTarget(self, action: #selector(classifyComment), for: .touchUpInside) // For macOS: target: self, action: #selector(classifyComment)
    }

    private func loadModel() {
        // Use Task for async loading if model is large, otherwise sync is fine.
        // For this simple example, we'll keep it synchronous as it's a small model.
        do {
            let config = MLModelConfiguration()
            self.classifier = try InappropriateContentClassifier(configuration: config)
            print("Core ML model 'InappropriateContentClassifier' loaded successfully.")
        } catch {
            print("Error loading Core ML model: \(error.localizedDescription)")
            resultLabel.text = "Error: Model failed to load."
        }
    }

    @objc private func classifyComment() {
        guard let text = commentTextView.text, !text.isEmpty else {
            resultLabel.text = "Prediction: Please enter some text."
            return
        }

        guard let classifier = classifier else {
            resultLabel.text = "Prediction: Model not loaded, cannot classify."
            return
        }

        // Use a Task to perform prediction asynchronously, keeping the UI responsive.
        Task {
            do {
                let prediction = try await classifier.prediction(text: text)
                // Update UI on the main actor
                await MainActor.run {
                    resultLabel.text = "Prediction: \(prediction.label)"
                    if prediction.label == "Flagged" {
                        resultLabel.textColor = .red // For macOS: NSColor.red
                    } else {
                        resultLabel.textColor = .systemGreen // For macOS: NSColor.systemGreen
                    }
                }
            } catch {
                await MainActor.run {
                    resultLabel.text = "Prediction Error: \(error.localizedDescription)"
                    resultLabel.textColor = .red // For macOS: NSColor.red
                }
                print("Error making prediction: \(error.localizedDescription)")
            }
        }
    }
}
