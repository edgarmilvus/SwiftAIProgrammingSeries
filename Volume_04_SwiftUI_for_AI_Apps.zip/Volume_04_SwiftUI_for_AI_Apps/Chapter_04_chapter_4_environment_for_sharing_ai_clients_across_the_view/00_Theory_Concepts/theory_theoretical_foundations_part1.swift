
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// MARK: - 1. Define the AI Client (an Actor for concurrency safety)
// This is an example, assuming previous chapters covered Actor basics.
// @available(iOS 18.0, *) is used here because @Observable is iOS 17+,
// and combining it with Actors for SwiftUI observation is a modern pattern.
@available(iOS 18.0, *)
actor OpenAIChatClient: Observable { // An actor for isolated state, Observable for SwiftUI updates
    // Assume ChatRequest and ChatResponse are Sendable structs.
    struct ChatRequest: Sendable {
        let messages: [String]
        let model: String
    }

    struct ChatResponse: Sendable {
        let id: String
        let content: String
        let isStreaming: Bool
    }

    // Isolated mutable state within the actor
    @ObservationIgnored private var apiKey: String
    @ObservationIgnored private var session: URLSession

    // Observable properties for SwiftUI views
    @Published var currentResponse: String = "" // @Published is used here for simplicity as a bridge to Observable
                                               // In a true @Observable, you'd just have 'var currentResponse'
                                               // and rely on the macro for observation.
    var isLoading: Bool = false
    var error: Error?

    init(apiKey: String, session: URLSession = .shared) {
        self.apiKey = apiKey
        self.session = session
    }

    // Actor-isolated function for performing chat requests
    func sendRequest(_ request: ChatRequest) async throws -> AsyncStream<ChatResponse> {
        self.isLoading = true // Update observable state
        self.currentResponse = ""
        self.error = nil

        // Simulate network request and streaming
        return AsyncStream { continuation in
            Task {
                // In a real client, this would be a network call
                // For demonstration, we'll simulate token streaming
                let simulatedTokens = ["Hello", ", ", "how", " can", " I", " assist", " you", " today", "?"]
                for token in simulatedTokens {
                    try await Task.sleep(for: .milliseconds(100))
                    continuation.yield(ChatResponse(id: UUID().uuidString, content: token, isStreaming: true))
                    await MainActor.run {
                        self.currentResponse += token // Update observable state on MainActor
                    }
                }
                await MainActor.run {
                    self.isLoading = false
                }
                continuation.finish()
            }
        }
    }

    // Example of a non-streaming request
    func getCompletion(_ request: ChatRequest) async throws -> ChatResponse {
        self.isLoading = true
        self.currentResponse = ""
        self.error = nil

        try await Task.sleep(for: .seconds(1)) // Simulate network delay
        let response = ChatResponse(id: UUID().uuidString, content: "This is a non-streaming response.", isStreaming: false)
        await MainActor.run {
            self.currentResponse = response.content
            self.isLoading = false
        }
        return response
    }

    // Example of how to access isolated state (only within the actor)
    func getAPIKey() -> String {
        return apiKey
    }
}

// MARK: - 2. Define the EnvironmentKey
private struct OpenAIChatClientKey: EnvironmentKey {
    // Provide a default client, perhaps a mock or a client that will error
    // if not explicitly set. This is crucial for testability and safety.
    @available(iOS 18.0, *)
    static let defaultValue: OpenAIChatClient = {
        let client = OpenAIChatClient(apiKey: "DEFAULT_API_KEY")
        // Potentially log a warning if default is used in production
        return client
    }()
}

// MARK: - 3. Extend EnvironmentValues for convenient access
extension EnvironmentValues {
    @available(iOS 18.0, *)
    var openAIChatClient: OpenAIChatClient {
        get { self[OpenAIChatClientKey.self] }
        set { self[OpenAIChatClientKey.self] = newValue }
    }
}

// MARK: - How to provide and consume the client

// 4. Provide the client at the app's root or a specific subtree
@available(iOS 18.0, *)
struct MyApp: App {
    // Create the client instance once
    @State private var chatClient = OpenAIChatClient(apiKey: "YOUR_OPENAI_API_KEY")

    var body: some Scene {
        WindowGroup {
            ContentView()
                // Inject the client into the environment for its entire subtree
                .environment(\.openAIChatClient, chatClient)
        }
    }
}

// 5. Consume the client in any descendant view
@available(iOS 18.0, *)
struct ContentView: View {
    var body: some View {
        VStack {
            Text("Welcome to the AI App!")
            ChatView() // ChatView and its children can now access the client
        }
    }
}

@available(iOS 18.0, *)
struct ChatView: View {
    // No need to pass the client down from ContentView
    var body: some View {
        VStack {
            MessageInputView()
            ChatHistoryView()
        }
    }
}

@available(iOS 18.0, *)
struct MessageInputView: View {
    // Directly access the client from the environment
    @Environment(\.openAIChatClient) private var chatClient
    @State private var message: String = ""

    var body: some View {
        VStack {
            TextField("Enter your message", text: $message)
            Button("Send") {
                Task {
                    // Interact with the actor-isolated client
                    let request = OpenAIChatClient.ChatRequest(messages: [message], model: "gpt-4o")
                    // Example of streaming
                    for await response in try await chatClient.sendRequest(request) {
                        print("Streamed token: \(response.content)")
                    }
                    // Example of non-streaming
                    // let response = try await chatClient.getCompletion(request)
                    // print("Completion: \(response.content)")
                }
            }
            Text("Current AI Response: \(chatClient.currentResponse)") // Observe changes
                .font(.caption)
            if chatClient.isLoading {
                ProgressView()
            }
        }
    }
}
