
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import CreateML
import Foundation

@available(iOS 18.0, macOS 15.0, *)
func robustMotionClassifierPipeline() async throws { // Made async for parallelization
    // 1. Prepare a Motion Dataset
    // Placeholder for your actual data loading.
    // Assume each row in the data table represents a segment of motion,
    // and there's a 'activity' column for the label.
    let dataArray: [[String: MLDataValueConvertible]] = [
        // Push-ups (fewer samples to demonstrate imbalance/stratification)
        ["accelX": 0.1, "accelY": 0.2, "accelZ": 0.3, "gyroX": 0.01, "gyroY": 0.02, "gyroZ": 0.03, "activity": "Push-up"],
        ["accelX": 0.11, "accelY": 0.21, "accelZ": 0.31, "gyroX": 0.011, "gyroY": 0.021, "gyroZ": 0.031, "activity": "Push-up"],
        ["accelX": 0.12, "accelY": 0.22, "accelZ": 0.32, "gyroX": 0.012, "gyroY": 0.022, "gyroZ": 0.032, "activity": "Push-up"],

        // Squats (more samples)
        ["accelX": 0.5, "accelY": 0.6, "accelZ": 0.7, "gyroX": 0.05, "gyroY": 0.06, "gyroZ": 0.07, "activity": "Squat"],
        ["accelX": 0.51, "accelY": 0.61, "accelZ": 0.71, "gyroX": 0.051, "gyroY": 0.061, "gyroZ": 0.071, "activity": "Squat"],
        ["accelX": 0.52, "accelY": 0.62, "accelZ": 0.72, "gyroX": 0.052, "gyroY": 0.062, "gyroZ": 0.072, "activity": "Squat"],
        ["accelX": 0.53, "accelY": 0.63, "accelZ": 0.73, "gyroX": 0.053, "gyroY": 0.063, "gyroZ": 0.073, "activity": "Squat"],
        ["accelX": 0.54, "accelY": 0.64, "accelZ": 0.74, "gyroX": 0.054, "gyroY": 0.064, "gyroZ": 0.074, "activity": "Squat"],
        ["accelX": 0.55, "accelY": 0.65, "accelZ": 0.75, "gyroX": 0.055, "gyroY": 0.065, "gyroZ": 0.075, "activity": "Squat"],

        // Jumping Jacks (more samples)
        ["accelX": 0.8, "accelY": 0.9, "accelZ": 1.0, "gyroX": 0.08, "gyroY": 0.09, "gyroZ": 0.10, "activity": "Jumping Jack"],
        ["accelX": 0.81, "accelY": 0.91, "accelZ": 1.01, "gyroX": 0.081, "gyroY": 0.091, "gyroZ": 0.101, "activity": "Jumping Jack"],
        ["accelX": 0.82, "accelY": 0.92, "accelZ": 1.02, "gyroX": 0.082, "gyroY": 0.092, "gyroZ": 0.102, "activity": "Jumping Jack"],
        ["accelX": 0.83, "accelY": 0.93, "accelZ": 1.03, "gyroX": 0.083, "gyroY": 0.093, "gyroZ": 0.103, "activity": "Jumping Jack"],
        ["accelX": 0.84, "accelY": 0.94, "accelZ": 1.04, "gyroX": 0.084, "gyroY": 0.094, "gyroZ": 0.104, "activity": "Jumping Jack"],
    ]
    let allData = try MLDataTable(array: dataArray)
    let targetColumn = "activity"

    // 2. Define Hyperparameter Search Space
    let maxIterationsOptions = [50, 150]
    let windowSizeOptions: [MLMotionClassifier.ModelParameters.WindowSize] = [.short, .medium]

    let numFolds = 3 // For k-fold cross-validation

    var bestAvgAccuracy: Double = 0.0
    var bestHyperparameters: (maxIterations: Int, windowSize: MLMotionClassifier.ModelParameters.WindowSize)? = nil

    print("Starting robust motion classifier pipeline with stratified k-fold CV and hyperparameter tuning...")

    // --- Helper function for stratified splitting ---
    // This function takes an MLDataTable and splits it into 'numFolds' training/validation pairs
    // ensuring that the proportion of each class is maintained in each fold.
    func createStratifiedFolds(data: MLDataTable, targetColumn: String, numFolds: Int) throws -> [(training: MLDataTable, validation: MLDataTable)] {
        var foldRowCollections: [[MLDataTableRow]] = Array(repeating: [], count: numFolds)

        // 1. Group data by targetColumn
        let uniqueClasses = try data[targetColumn].uniqueElements()
        var classDataRows: [MLDataValue: [MLDataTableRow]] = [:]
        for className in uniqueClasses {
            classDataRows[className] = try data.filter(targetColumn, .equalTo, className).rows.map { $0 }
        }

        // 2. Distribute rows from each class into folds in a round-robin fashion
        for (_, rows) in classDataRows {
            for (index, row) in rows.enumerated() {
                let foldIndex = index % numFolds
                foldRowCollections[foldIndex].append(row)
            }
        }

        // 3. Convert row collections into actual MLDataTable folds
        let actualFolds = try foldRowCollections.map { try MLDataTable(rows: $0) }

        // 4. Create training/validation pairs for each fold
        var trainingValidationPairs: [(training: MLDataTable, validation: MLDataTable)] = []
        for i in 0..<numFolds {
            let validationData = actualFolds[i]
            var trainingTables: [MLDataTable] = []
            for j in 0..<numFolds {
                if i != j {
                    trainingTables.append(actualFolds[j])
                }
            }
            let trainingData = try MLDataTable(tables: trainingTables)
            trainingValidationPairs.append((training: trainingData, validation: validationData))
        }
        return trainingValidationPairs
    }

    // Generate stratified folds once for the entire pipeline
    let stratifiedFolds = try createStratifiedFolds(data: allData, targetColumn: targetColumn, numFolds: numFolds)

    // Outer Loop: Hyperparameter Search, using TaskGroup for parallel execution
    await withTaskGroup(of: (Double, Int, MLMotionClassifier.ModelParameters.WindowSize).self) { group in
        for iterations in maxIterationsOptions {
            for windowSize in windowSizeOptions {
                group.addTask {
                    print("\n--- Testing Iterations: \(iterations), Window Size: \(windowSize) ---")
                    var foldAccuracies: [Double] = []

                    // Inner Loop: K-Fold Cross-Validation (sequential for simplicity within a single Task)
                    // Could be parallelized further if each fold's training is a separate Task,
                    // but that adds complexity to managing results for a single HP combination.
                    for i in 0..<numFolds {
                        print("  Fold \(i + 1)/\(numFolds) for (Iterations: \(iterations), Window: \(windowSize))")
                        let (trainingData, validationData) = stratifiedFolds[i]

                        let trainingDataSource = try MLMotionClassifier.DataSource(data: trainingData, activityColumn: targetColumn)
                        let validationDataSource = try MLMotionClassifier.DataSource(data: validationData, activityColumn: targetColumn)

                        let parameters = MLMotionClassifier.ModelParameters(
                            maxIterations: iterations,
                            augmentationOptions: .init(windowSize: windowSize)
                        )

                        do {
                            let model = try MLMotionClassifier(trainingData: trainingDataSource, parameters: parameters)
                            let evaluation = model.evaluation(on: validationDataSource)
                            if let accuracy = evaluation.accuracy {
                                print("    Fold \(i + 1) Validation Accuracy: \(String(format: "%.4f", accuracy))")
                                foldAccuracies.append(accuracy)
                            } else {
                                print("    Fold \(i + 1) Evaluation Accuracy not available.")
                            }
                        } catch {
                            print("    Error training model for fold \(i + 1) with (Iterations: \(iterations), Window: \(windowSize)): \(error)")
                        }
                    }

                    if !foldAccuracies.isEmpty {
                        let avgAccuracyForCombination = foldAccuracies.reduce(0.0, +) / Double(foldAccuracies.count)
                        print("  Average CV Accuracy for (Iterations: \(iterations), Window: \(windowSize)): \(String(format: "%.4f", avgAccuracyForCombination))")
                        return (avgAccuracyForCombination, iterations, windowSize)
                    } else {
                        print("  No accuracies recorded for (Iterations: \(iterations), Window: \(windowSize)).")
                    }
                    return (0.0, iterations, windowSize) // Return 0.0 if no accuracies recorded
                }
            }
        }

        // Collect results from all hyperparameter combination tasks
        for await (avgAccuracy, iterations, windowSize) in group {
            if avgAccuracy > bestAvgAccuracy {
                bestAvgAccuracy = avgAccuracy
                bestHyperparameters = (maxIterations: iterations, windowSize: windowSize)
                print("  -> New best average accuracy found: \(String(format: "%.4f", avgAccuracy))")
            }
        }
    }

    // 4. Report Best Configuration
    print("\n--- Robust Motion Classifier Pipeline Complete ---")
    if let bestParams = bestHyperparameters {
        print("Optimal Hyperparameters Found:")
        print("  Max Iterations: \(bestParams.maxIterations)")
        print("  Window Size: \(bestParams.windowSize)")
        print("Best Average Cross-Validation Accuracy: \(String(format: "%.4f", bestAvgAccuracy))")
    } else {
        print("No optimal hyperparameters found.")
    }

    print("\nImportance of Stratification:")
    print("Stratification ensures that each fold in the cross-validation process has a similar proportion of each activity class as the original dataset. This is crucial when dealing with imbalanced datasets (e.g., if 'Push-ups' are much rarer than 'Squats'). Without stratification, some folds might end up with very few or no samples of a minority class, leading to biased training or evaluation results. By stratifying, we get a more reliable and less optimistic estimate of the model's generalization performance, especially for all activity types, ensuring the model performs well across all defined exercises.")
}

// To run this exercise, uncomment the lines below:
// Task {
//    try await robustMotionClassifierPipeline()
// }
