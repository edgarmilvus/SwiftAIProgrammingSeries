
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

// This exercise requires setup in Xcode, not executable Swift code.
// The following describes the necessary steps and file content.

// --- Step 1: Create Localizable.strings files ---
// In Xcode, create a new "Strings File" named 'Localizable.strings'.
// Select the file, then in the File Inspector (right sidebar), click "Localize...".
// Choose "English" as the base language.
// Then, in the Project Navigator, select your project, go to 'Info' tab.
// Under 'Localizations', add "Spanish (es)" and "French (fr)".
// When prompted, ensure 'Localizable.strings' is checked for these new languages.
// This will create 'Localizable.strings (English)', 'Localizable.strings (Spanish)',
// and 'Localizable.strings (French)' files.

// --- Step 2: Populate Localizable.strings files ---

// Localizable.strings (English)
/*
"welcome_greeting" = "Welcome to ConnectSphere!";
"welcome_description" = "Connect with friends and family.";
"go_to_feed_button" = "Go to Feed";
"app_logo_accessibility_label" = "ConnectSphere App Logo"; // For image accessibility
*/

// Localizable.strings (Spanish)
/*
"welcome_greeting" = "¡Bienvenido a ConnectSphere!";
"welcome_description" = "Conéctate con amigos y familiares.";
"go_to_feed_button" = "Ir al Feed";
"app_logo_accessibility_label" = "Logo de la aplicación ConnectSphere";
*/

// Localizable.strings (French)
/*
"welcome_greeting" = "Bienvenue sur ConnectSphere !";
"welcome_description" = "Connectez-vous avec vos amis et votre famille.";
"go_to_feed_button" = "Aller au Fil d'actualité";
"app_logo_accessibility_label" = "Logo de l'application ConnectSphere";
*/

// --- Step 3: Localize an Image Asset ---
// 1. Add your image (e.g., 'globe_icon.png' or 'app_logo.png') to your Asset Catalog (Assets.xcassets).
// 2. Select the image asset in the Asset Catalog.
// 3. In the Attributes Inspector (right sidebar), click the "Localize..." button.
// 4. Choose "English" as the base localization.
// 5. Check the boxes for "Spanish" and "French" in the Localization section of the Attributes Inspector.
// 6. Xcode will create localized versions of the image slot. You can then drag and drop
//    different image files for each language (e.g., a version of the globe icon with
//    Spanish text embedded, or simply a different icon if culturally appropriate).
//    If no specific localized image is provided, the base image will be used.

// --- Step 4: Using Localized Strings and Images in Swift UI (Example using SwiftUI) ---
/*
import SwiftUI

struct WelcomeView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image("app_logo") // This will automatically pick the localized image
                .resizable()
                .scaledToFit()
                .frame(width: 150, height: 150)
                .accessibilityLabel(Text(NSLocalizedString("app_logo_accessibility_label", comment: "Accessibility label for the app logo")))

            Text(NSLocalizedString("welcome_greeting", comment: "Main welcome message"))
                .font(.largeTitle)
                .multilineTextAlignment(.center)

            Text(NSLocalizedString("welcome_description", comment: "Secondary descriptive text"))
                .font(.body)
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            Button(action: {
                // Action to navigate to feed
            }) {
                Text(NSLocalizedString("go_to_feed_button", comment: "Button to proceed to feed"))
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.horizontal)
        }
        .padding()
    }
}

// To verify, change your device's preferred language in Settings -> General -> Language & Region.
// Run the app again to see the localized text and potentially localized images.
*/
