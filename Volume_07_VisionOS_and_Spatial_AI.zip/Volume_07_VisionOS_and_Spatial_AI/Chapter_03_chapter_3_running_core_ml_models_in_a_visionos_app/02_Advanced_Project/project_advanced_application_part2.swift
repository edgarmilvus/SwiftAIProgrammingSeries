
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Vision
import CoreML
import AVFoundation
import Spatial

/// Represents a detected object with its spatial and semantic metadata.
/// Conforms to `Sendable` to safely pass across actor boundaries in Swift 6.
public struct SpatialDetection: Sendable, Identifiable {
    public let id: UUID
    public let label: String
    public let confidence: Float
    /// The 2D bounding box in normalized coordinates (0.0 to 1.0).
    public let boundingBox: CGRect
    /// The estimated 3D position in the world coordinate system.
    public let worldPosition: SIMD3<Float>?
    
    public init(id: UUID = UUID(), label: String, confidence: Float, boundingBox: CGRect, worldPosition: SIMD3<Float>? = nil) {
        self.id = id
        self.label = label
        self.confidence = confidence
        self.boundingBox = boundingBox
        self.worldPosition = worldPosition
    }
}

/// An actor responsible for isolating Core ML inference logic.
/// This prevents UI hangs and ensures thread-safe access to the Vision request pipeline.
@available(visionOS 1.0, *)
public actor SpatialInferenceActor {
    
    private var detectionRequest: VNCoreMLRequest?
    private let model: VNCoreMLModel
    
    /// Errors specific to the Spatial Inference process.
    public enum InferenceError: Error {
        case modelInitializationFailed
        case processingError(Error)
        case invalidBuffer
    }

    /// Initializes the actor with a specific Core ML model.
    /// - Parameter modelURL: The URL to the compiled .mlmodelc file.
    public init(modelURL: URL) throws {
        do {
            // Load the model configuration to optimize for the Neural Engine (ANE)
            let config = MLModelConfiguration()
            config.computeUnits = .all // Prioritize ANE, then GPU, then CPU
            
            let coreMLModel = try MLModel(contentsOf: modelURL, configuration: config)
            self.model = try VNCoreMLModel(for: coreMLModel)
            
            // Prepare the Vision request
            self.detectionRequest = VNCoreMLRequest(model: self.model)
            self.detectionRequest?.imageCropAndScaleOption = .scaleFill
        } catch {
            throw InferenceError.modelInitializationFailed
        }
    }

    /// Performs inference on a provided pixel buffer.
    /// - Parameter pixelBuffer: The raw video frame from the camera.
    /// - Returns: An array of `SpatialDetection` objects.
    public func performInference(on pixelBuffer: CVPixelBuffer) async throws -> [SpatialDetection] {
        guard let request = detectionRequest else {
            throw InferenceError.processingError(NSError(domain: "NoRequest", code: -1))
        }

        return try await withCheckedThrowingContinuation { continuation in
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
            
            do {
                try handler.perform([request])
                
                // Extract results from the Vision request
                let observations = request.results as? [VNRecognizedObjectObservation] ?? []
                
                let detections = observations.map { observation in
                    // Convert Vision's normalized coordinates (bottom-left origin) 
                    // to standard CGRect (top-left origin)
                    let rect = VNImageRectForNormalizedRect(
                        observation.boundingBox,
                        Int(pixelBuffer.width),
                        Int(pixelBuffer.height)
                    )
                    
                    let topLabel = observation.labels.first
                    
                    return SpatialDetection(
                        label: topLabel?.identifier ?? "Unknown",
                        confidence: topLabel?.confidence ?? 0.0,
                        boundingBox: rect
                    )
                }
                
                continuation.resume(returning: detections)
            } catch {
                continuation.resume(throwing: InferenceError.processingError(error))
            }
        }
    }
}
