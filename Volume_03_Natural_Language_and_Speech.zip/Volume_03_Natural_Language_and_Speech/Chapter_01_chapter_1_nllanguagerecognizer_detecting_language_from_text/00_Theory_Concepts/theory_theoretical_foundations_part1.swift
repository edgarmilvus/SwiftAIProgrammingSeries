
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 18.0, *) // NLLanguageRecognizer itself is older, but this example uses modern Swift 6 features.
class LanguageDetector {
    private let recognizer = NLLanguageRecognizer()

    /// Asynchronously detects the dominant language of a given text.
    /// - Parameter text: The text to analyze.
    /// - Returns: An `NLLanguage` representing the dominant language, or nil if no language could be determined.
    func detectDominantLanguage(for text: String) async -> NLLanguage? {
        // Performing the recognition on a background thread using a Task.
        // NLLanguageRecognizer is thread-safe for calls to its recognition methods.
        await Task.detached {
            self.recognizer.processString(text)
            return self.recognizer.dominantLanguage
        }.value
    }

    /// Asynchronously detects all languages present in the text with their confidence scores.
    /// - Parameter text: The text to analyze.
    /// - Returns: An array of tuples, each containing an `NLLanguage` and its confidence score.
    func detectAllLanguages(for text: String) async -> [(NLLanguage, Double)] {
        await Task.detached {
            self.recognizer.processString(text)
            // The topN parameter allows fetching multiple potential languages.
            // We'll fetch up to 5 languages with confidence scores above 0.1.
            return self.recognizer.languageHypotheses(withMaximum: 5)
                .map { (language: $0.key, confidence: $0.value) }
                .filter { $0.confidence > 0.1 }
        }.value
    }
}

// Example Usage in a SwiftUI View Model (conceptual)
@available(iOS 18.0, *)
@Observable
class ContentViewModel {
    private let detector = LanguageDetector()
    var inputText: String = "" {
        didSet {
            // Trigger recognition whenever input text changes
            Task { await recognizeLanguage() }
        }
    }
    var detectedLanguage: NLLanguage?
    var languageHypotheses: [(NLLanguage, Double)] = []
    var isLoading: Bool = false

    @MainActor
    func recognizeLanguage() async {
        guard !inputText.isEmpty else {
            detectedLanguage = nil
            languageHypotheses = []
            return
        }
        isLoading = true
        // Await the asynchronous detection
        let dominant = await detector.detectDominantLanguage(for: inputText)
        let hypotheses = await detector.detectAllLanguages(for: inputText)

        // Update @Observable properties on the MainActor
        detectedLanguage = dominant
        languageHypotheses = hypotheses
        isLoading = false
    }
}
