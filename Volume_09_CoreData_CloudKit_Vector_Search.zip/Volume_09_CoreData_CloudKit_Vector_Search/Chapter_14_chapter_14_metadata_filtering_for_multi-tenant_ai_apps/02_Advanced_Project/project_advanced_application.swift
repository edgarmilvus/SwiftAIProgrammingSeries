
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import Accelerate

// MARK: - Package Dependencies
/*
 Package.swift equivalent:
 dependencies: [
    .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0"),
    .package(url: "https://github.com/apple/swift-collections", from: "1.1.0")
 ]
*/

/// Represents the security scope of a specific user within the multi-tenant system.
/// Using `Sendable` to ensure safe transfer across actor boundaries in Swift 6.
public struct SecurityContext: Sendable, Hashable {
    public let tenantID: UUID
    public let departmentID: String
    public let clearanceLevel: Int // 0: Public, 1: Internal, 2: Confidential
    
    public init(tenantID: UUID, departmentID: String, clearanceLevel: Int) {
        self.tenantID = tenantID
        self.departmentID = departmentID
        self.clearanceLevel = clearanceLevel
    }
}

/// Error types specific to the Vector Search Engine.
public enum VectorEngineError: Error {
    case tenantMismatch(String)
    case insufficientClearance
    case vectorDimensionMismatch
    case searchTimeout
}

/// A single unit of knowledge in the AI system.
/// Contains the semantic vector and the metadata required for filtering.
public struct VectorEntry: Sendable {
    public let id: UUID
    public let tenantID: UUID
    public let departmentID: String
    public let clearanceLevel: Int
    public let embedding: [Float] // The high-dimensional vector
    public let contentSnippet: String
    
    public init(id: UUID = UUID(), 
                tenantID: UUID, 
                departmentID: String, 
                clearanceLevel: Int, 
                embedding: [Float], 
                contentSnippet: String) {
        self.id = id
        self.tenantID = tenantID
        self.departmentID = departmentID
        self.clearanceLevel = clearanceLevel
        self.embedding = embedding
        self.contentSnippet = contentSnippet
    }
}

/// The result of a semantic search, including the similarity score.
public struct SearchResult: Sendable {
    public let entry: VectorEntry
    public let similarityScore: Float
}

/// An Actor that manages the high-dimensional vector index.
/// Actors are critical here to prevent data races when multiple 
/// background tasks attempt to update or search the index simultaneously.
@available(iOS 18.0, *)
public actor MultiTenantVectorEngine {
    
    // The underlying storage: In a real app, this might be a 
    // specialized database or a memory-mapped file.
    private var index: [VectorEntry] = []
    private let vectorDimension: Int
    
    public init(vectorDimension: Int) {
        self.vectorDimension = vectorDimension
    }
    
    /// Adds a new vector to the index.
    /// - Parameter entry: The vector entry to be stored.
    /// - Throws: `VectorEngineError.vectorDimensionMismatch`
    public func ingest(entry: VectorEntry) throws {
        guard entry.embedding.count == vectorDimension else {
            throw VectorEngineError.vectorDimensionMismatch
        }
        index.append(entry)
    }
    
    /// Performs a metadata-filtered semantic search.
    /// This implements the "Pre-Filtering" strategy.
    /// 
    /// - Parameters:
    ///   - queryEmbedding: The vector representing the user's query.
    ///   - context: The security context of the requesting user.
    ///   - limit: The maximum number of results to return.
    /// - Returns: An array of `SearchResult` sorted by similarity.
    public func search(
        queryEmbedding: [Float],
        context: SecurityContext,
        limit: Int = 5
    ) async throws -> [SearchResult] {
        
        guard queryEmbedding.count == vectorDimension else {
            throw VectorEngineError.vectorDimensionMismatch
        }
        
        // 1. PRE-FILTERING STEP:
        // We filter the entire index by the tenant and clearance level 
        // BEFORE performing any mathematical similarity calculations.
        // This is the core of the Multi-Tenant isolation pattern.
        let allowedEntries = index.filter { entry in
            entry.tenantID == context.tenantID &&
            entry.clearanceLevel <= context.clearanceLevel &&
            (context.clearanceLevel > 1 ? true : entry.departmentID == context.departmentID)
        }
        
        // 2. SEMANTIC SEARCH STEP:
        // Only perform expensive math on the filtered subset.
        return allowedEntries
            .compactMap { entry -> SearchResult? in
                let score = cosineSimilarity(queryEmbedding, entry.embedding)
                return SearchResult(entry: entry, similarityScore: score)
            }
            .sorted { $0.similarityScore > $1.similarityScore }
            .prefix(limit)
            .map { $0 }
    }
    
    /// Calculates the cosine similarity between two vectors using Accelerate.
    /// Cosine Similarity = (A · B) / (||A|| * ||B||)
    private func cosineSimilarity(_ a: [Float], _ b: [Float]) -> Float {
        // Use Accelerate framework for high-performance BLAS operations.
        // This is essential for real-time AI responsiveness.
        var dotProduct: Float = 0
        vDSP_dotpr(a, 1, b, 1, &dotProduct, vDSP_Length(a.count))
        
        var normA: Float = 0
        vDSP_svesq(a, 1, &normA, vDSP_Length(a.count))
        normA = sqrt(normA)
        
        var normB: Float = 0
        vDSP_svesq(b, 1, &normB, vDSP_Length(b.count))
        normB = sqrt(normB)
        
        guard normA > 0 && normB > 0 else { return 0 }
        return dotProduct / (normA * normB)
    }
}

// MARK: - Application Integration Example

/// A ViewModel demonstrating how a UI component would interact with the engine.
@available(iOS 18.0, *)
@MainActor
public class AISearchViewModel: ObservableObject {
    @Published public var results: [SearchResult] = []
    @Published public var isSearching = false
    @Published public var errorMessage: String?
    
    private let engine: MultiTenantVectorEngine
    private let userContext: SecurityContext
    
    public init(engine: MultiTenantVectorEngine, context: SecurityContext) {
        self.engine = engine
        self.userContext = context
    }
    
    /// Simulates a user typing a query and hitting search.
    public func performSearch(queryVector: [Float]) async {
        isSearching = true
        errorMessage = nil
        
        do {
            // The search is awaited because the engine is an Actor.
            // This prevents the UI thread from blocking during heavy math.
            let foundResults = try await engine.search(
                queryEmbedding: queryVector,
                context: userContext
            )
            self.results = foundResults
        } catch VectorEngineError.tenantMismatch(let msg) {
            self.errorMessage = "Security Violation: \(msg)"
        } catch {
            self.errorMessage = "An unexpected error occurred: \(error.localizedDescription)"
        }
        
        isSearching = false
    }
}
