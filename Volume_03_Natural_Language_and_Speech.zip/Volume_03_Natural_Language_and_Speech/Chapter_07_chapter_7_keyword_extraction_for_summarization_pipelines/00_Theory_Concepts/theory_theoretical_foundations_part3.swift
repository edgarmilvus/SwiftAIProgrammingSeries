
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

    @available(iOS 18.0, *)
    @Observable
    class KeywordExtractionViewModel {
        var inputText: String = ""
        var extractedKeywords: [String] = []
        var isLoading: Bool = false
        var progress: Double = 0.0 // For showing extraction progress
        var errorMessage: String?

        private let extractor = KeywordExtractor()

        func performExtraction() async {
            guard !inputText.isEmpty else { return }
            isLoading = true
            errorMessage = nil
            progress = 0.0
            extractedKeywords = []

            do {
                // Simulate progress updates during a long task
                Task {
                    for i in 1...100 {
                        try await Task.sleep(for: .milliseconds(10))
                        await MainActor.run { self.progress = Double(i) / 100.0 }
                    }
                }
                let keywords = try await extractor.extractKeywords(from: inputText)
                await MainActor.run {
                    self.extractedKeywords = keywords
                    self.progress = 1.0
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "Failed to extract keywords: \(error.localizedDescription)"
                }
            }
            await MainActor.run { self.isLoading = false }
        }
    }
    