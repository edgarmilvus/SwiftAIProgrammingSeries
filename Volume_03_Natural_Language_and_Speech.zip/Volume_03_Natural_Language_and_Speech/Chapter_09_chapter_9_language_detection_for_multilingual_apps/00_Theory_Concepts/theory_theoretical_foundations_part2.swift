
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import NaturalLanguage

@available(iOS 18.0, *)
actor NLLanguageDetectorActor {
    private let recognizer = NLLanguageRecognizer()

    /// Detects the dominant language of a given string.
    /// This method is implicitly isolated to the actor's execution context.
    func detectDominantLanguage(for text: String) -> NLLanguage? {
        recognizer.reset() // Ensure a fresh start for each detection
        recognizer.processString(text)
        return recognizer.dominantLanguage
    }

    /// Detects multiple language hypotheses and their confidence scores.
    func detectHypotheses(for text: String, maxHypotheses: Int = 3) -> [NLLanguage: Double] {
        recognizer.reset()
        recognizer.processString(text)
        return recognizer.hypotheses(withMaximum: maxHypotheses)
    }

    /// Incrementally processes a string, building context over time.
    func processIncrementalString(_ text: String) {
        recognizer.processString(text)
    }

    /// Resets the recognizer's internal state.
    func resetRecognizer() {
        recognizer.reset()
    }

    /// Returns the current dominant language based on accumulated context.
    func currentDominantLanguage() -> NLLanguage? {
        return recognizer.dominantLanguage
    }
}

// Example Usage
@available(iOS 18.0, *)
func demonstrateActorDetection() async {
    let detectorActor = NLLanguageDetectorActor()

    // Concurrent access is safe, as the actor serializes calls
    async let lang1 = detectorActor.detectDominantLanguage(for: "Hello from Swift!")
    async let lang2 = detectorActor.detectDominantLanguage(for: "¡Hola desde Swift!")
    async let lang3 = detectorActor.detectHypotheses(for: "Guten Tag!", maxHypotheses: 2)

    print("Lang 1: \(await lang1?.rawValue ?? "Unknown")")
    print("Lang 2: \(await lang2?.rawValue ?? "Unknown")")
    print("Lang 3: \(await lang3.map { (key, value) in "\(key.rawValue): \(String(format: "%.2f", value * 100))%" }.joined(separator: ", "))")

    // Demonstrate incremental processing
    await detectorActor.resetRecognizer()
    await detectorActor.processIncrementalString("This is a test. ")
    print("Incremental dominant after first part: \(await detectorActor.currentDominantLanguage()?.rawValue ?? "Unknown")")
    await detectorActor.processIncrementalString("Ceci est un test. ")
    print("Incremental dominant after second part: \(await detectorActor.currentDominantLanguage()?.rawValue ?? "Unknown")")
    await detectorActor.processIncrementalString("Es ist ein Test.")
    print("Incremental dominant after third part: \(await detectorActor.currentDominantLanguage()?.rawValue ?? "Unknown")")
}
