
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.swift
// Description: Theoretical Foundations
// ==========================================

@available(iOS 18.0, macOS 15.0, *)
struct InferenceView: View {
    @State private var prompt: String = "Tell me a short story."
    @State private var response: String = ""
    @State private var isLoading: Bool = false
    @State private var streamedResponse: String = ""

    // An instance of our actor
    private let inferenceEngine = InferenceEngine()

    var body: some View {
        VStack {
            TextField("Enter prompt", text: $prompt)
                .textFieldStyle(.roundedBorder)
                .padding()

            Button("Generate (Non-Streaming)") {
                isLoading = true
                Task {
                    do {
                        response = try await inferenceEngine.generate(prompt: prompt, maxTokens: 100)
                    } catch {
                        response = "Error: \(error.localizedDescription)"
                    }
                    isLoading = false
                }
            }
            .disabled(isLoading)
            .padding()

            Button("Generate (Streaming)") {
                isLoading = true
                streamedResponse = ""
                Task {
                    do {
                        for await token in try await inferenceEngine.streamGenerate(prompt: prompt, maxTokens: 100) {
                            streamedResponse += token
                        }
                    } catch {
                        streamedResponse = "Error: \(error.localizedDescription)"
                    }
                    isLoading = false
                }
            }
            .disabled(isLoading)
            .padding()

            if isLoading {
                ProgressView()
            }

            Text("Response (Non-Streaming):\n\(response)")
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)

            Text("Response (Streaming):\n\(streamedResponse)")
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}
