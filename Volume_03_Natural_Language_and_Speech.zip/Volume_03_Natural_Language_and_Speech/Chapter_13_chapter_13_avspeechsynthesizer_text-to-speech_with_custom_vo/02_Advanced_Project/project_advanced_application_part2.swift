
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import AVFoundation
import Foundation

// MARK: - Error Definitions

/// Custom errors for the IntelligentDocumentReader.
enum DocumentReaderError: Error, LocalizedError {
    case voiceNotFound(identifier: AVSpeechSynthesisVoiceIdentifier)
    case audioSessionActivationFailed(Error)
    case speechCancelled
    case unknownSpeechError

    var errorDescription: String? {
        switch self {
        case .voiceNotFound(let identifier):
            return "Speech voice with identifier '\(identifier.rawValue)' not found."
        case .audioSessionActivationFailed(let error):
            return "Failed to activate audio session: \(error.localizedDescription)"
        case .speechCancelled:
            return "Speech synthesis was cancelled."
        case .unknownSpeechError:
            return "An unknown error occurred during speech synthesis."
        }
    }
}

// MARK: - Document Structure and Voice Preferences

/// Represents different types of sections within a document.
enum DocumentSection: String, CaseIterable, Identifiable {
    var id: String { rawValue }

    case heading = "Heading"
    case body = "Body Text"
    case codeBlock = "Code Snippet"
    case disclaimer = "Disclaimer"
    case quote = "Quote"
    case custom = "Custom Section" // For demonstrating dynamic voice assignment

    /// Example text for each section type.
    var exampleText: String {
        switch self {
        case .heading: return "Chapter 1: The Dawn of AI"
        case .body: return "In the bustling digital metropolis, where algorithms hummed like a million tiny engines, a new era was dawning. This era promised to reshape human interaction with technology, making interfaces more intuitive, and experiences more personal."
        case .codeBlock: return "