
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import MLX
import MLXNN

@available(iOS 18.0, macOS 15.0, *)
class LoRALinear: MLXNN.Module {
    let baseLinear: MLXNN.Linear
    let adapterA: MLXNN.Linear
    let adapterB: MLXNN.Linear
    let scale: Float

    init(baseLinear: MLXNN.Linear, rank: Int, scale: Float = 1.0) {
        self.baseLinear = baseLinear
        // Adapter A: input_dim -> rank
        self.adapterA = MLXNN.Linear(inputDimensions: baseLinear.inputDimensions, outputDimensions: rank, bias: false)
        // Adapter B: rank -> output_dim
        self.adapterB = MLXNN.Linear(inputDimensions: rank, outputDimensions: baseLinear.outputDimensions, bias: false)
        self.scale = scale
        super.init()

        // Initialize adapter weights. Common practice: A random, B zero.
        // For simplicity, we use small random for both here, as MLXNN.Linear initializes with Xavier uniform.
        // We will scale down the initial weights significantly.
        self.adapterA.weight = MLXArray.rand(baseLinear.inputDimensions, rank) * 0.001
        self.adapterB.weight = MLXArray.rand(rank, baseLinear.outputDimensions) * 0.001
    }

    override func callAsFunction(_ input: MLXArray) -> MLXArray {
        let original_output = baseLinear(input)
        let lora_output = adapterB(adapterA(input)) * scale
        return original_output + lora_output
    }
}

@available(iOS 18.0, macOS 15.0, *)
class SimplifiedLoRALLMBlock: MLXNN.Module {
    let selfAttention: MLXNN.MultiHeadAttention
    let norm1: MLXNN.LayerNorm
    let feedForward: MLXNN.Linear // Simplified FFN for demonstration
    let norm2: MLXNN.LayerNorm

    init(dimensions: Int, numHeads: Int, ffnDimensions: Int, loraRank: Int) {
        // Base attention layers (these would typically be loaded pre-trained and frozen)
        let query = MLXNN.Linear(inputDimensions: dimensions, outputDimensions: dimensions, bias: true)
        let key = MLXNN.Linear(inputDimensions: dimensions, outputDimensions: dimensions, bias: true)
        let value = MLXNN.Linear(inputDimensions: dimensions, outputDimensions: dimensions, bias: true)
        let output = MLXNN.Linear(inputDimensions: dimensions, outputDimensions: dimensions, bias: true)

        // Wrap base attention layers with LoRA
        let loraQuery = LoRALinear(baseLinear: query, rank: loraRank)
        let loraKey = LoRALinear(baseLinear: key, rank: loraRank)
        let loraValue = LoRALinear(baseLinear: value, rank: loraRank)
        let loraOutput = LoRALinear(baseLinear: output, rank: loraRank) // LoRA can be applied to output projection too

        self.selfAttention = MLXNN.MultiHeadAttention(
            dimensions: dimensions,
            numHeads: numHeads,
            query: loraQuery,
            key: loraKey,
            value: loraValue,
            output: loraOutput
        )
        self.norm1 = MLXNN.LayerNorm(dimensions: dimensions)
        self.feedForward = MLXNN.Linear(inputDimensions: dimensions, outputDimensions: ffnDimensions) // Simplified FFN
        self.norm2 = MLXNN.LayerNorm(dimensions: dimensions)
        super.init()
    }

    override func callAsFunction(_ input: MLXArray, mask: MLXArray? = nil) -> MLXArray {
        var x = norm1(input)
        x = selfAttention(x, key: x, value: x, mask: mask) + input // Residual connection
        
        var y = norm2(x)
        y = MLX.relu(feedForward(y)) + x // Simplified FFN with residual
        return y
    }

    // Function to get only LoRA parameters for fine-tuning
    func loraParameters() -> [String: MLXArray] {
        var loraParams: [String: MLXArray] = [:]
        for (name, param) in parameters() {
            // Check for parameters belonging to adapterA or adapterB
            if name.contains("adapterA") || name.contains("adapterB") {
                loraParams[name] = param
            }
        }
        return loraParams
    }
}

// MARK: - Fine-tuning Loop and Inference Logic

@available(iOS 18.0, macOS 15.0, *)
func runLoRAFineTuningExercise() {
    print("\n--- Exercise 3: LoRA Fine-tuning for a Domain-Specific Chatbot ---")

    // Model Hyperparameters
    let dimensions = 256
    let numHeads = 4
    let ffnDimensions = 512
    let loraRank = 8 // Low rank for LoRA adapters
    let vocabSize = 1000 // Small vocab for dummy data
    let sequenceLength = 20
    let batchSize = 2

    // 1. Instantiate SimplifiedLoRALLMBlock
    let model = SimplifiedLoRALLMBlock(
        dimensions: dimensions,
        numHeads: numHeads,
        ffnDimensions: ffnDimensions,
        loraRank: loraRank
    )
    print("SimplifiedLoRALLMBlock instantiated with LoRA rank \(loraRank).")

    // 2. Load dummy base LLM weights (simulate pre-trained model)
    // For this exercise, MLXNN.Linear initializes weights automatically.
    // We'll just ensure the baseLinear weights are *not* part of the LoRA parameters.
    // In a real scenario, you'd load these from a safetensors file and then freeze them.
    // MLX's optimizer will only update the parameters you pass to it, effectively freezing others.
    print("Dummy base LLM weights are implicitly initialized by MLXNN.Linear.")
    print("LoRA adapters are initialized with small random values.")

    // 3. Create a dummy dataset (input sequences, target sequences)
    // Simulate language modeling: predict the next token
    let dummyInput = MLXArray.rand([batchSize, sequenceLength], .int32) * MLXArray(vocabSize)
    let dummyTarget = MLXArray.rand([batchSize, sequenceLength], .int32) * MLXArray(vocabSize)
    MLX.eval(dummyInput, dummyTarget)

    print("\nDummy dataset created:")
    print("Input shape: \(dummyInput.shape), Target shape: \(dummyTarget.shape)")

    // 4. Implement a simple training loop using `MLX.valueAndGradient`
    let learningRate: Float = 1e-3
    let optimizer = MLX.Adam(learningRate: learningRate)

    let loraParams = model.loraParameters()
    print("Number of LoRA parameters for fine-tuning: \(loraParams.count)")
    print("Example LoRA parameter name: \(loraParams.keys.first ?? "N/A")")

    // Define the loss function closure
    let lossFn = { (model: SimplifiedLoRALLMBlock, input: MLXArray, target: MLXArray) -> MLXArray in
        let output = model(input) // [batch_size, sequence_length, dimensions]
        
        // For language modeling, we typically compare the last dimension (logits for next token)
        // Reshape output and target for cross-entropy loss: [batch_size * sequence_length, vocab_size]
        let outputFlat = MLX.reshape(output, [output.dim[0] * output.dim[1], output.dim[2]])
        // Dummy target needs to be reshaped to match the batch of tokens
        let targetFlat = MLX.reshape(target, [target.dim[0] * target.dim[1]])

        // For simplicity, we'll project the `dimensions` output to `vocabSize` for loss calculation
        // In a real LLM, there would be a final linear layer: `MLXNN.Linear(dimensions, vocabSize)`
        // Let's simulate a projection here for the loss calculation
        let dummyProjection = MLXNN.Linear(inputDimensions: dimensions, outputDimensions: vocabSize)
        let logits = dummyProjection(outputFlat)

        return MLX.crossEntropy(logits: logits, targets: targetFlat, reduction: .mean)
    }

    let numTrainingSteps = 5
    print("\nStarting \(numTrainingSteps) simulated training steps...")
    for step in 0..<numTrainingSteps {
        // Compute loss and gradients *only* for LoRA parameters
        let (loss, gradients) = MLX.valueAndGradient(lossFn, model, loraParams)(model, dummyInput, dummyTarget)
        
        // Update only the LoRA parameters
        optimizer.update(model: model, gradients: gradients)
        
        MLX.eval(loss, model.parameters()) // Force evaluation of loss and model parameters
        print("Step \(step + 1): Loss = \(loss.item(Float.self))")
    }
    print("Simulated fine-tuning complete.")

    // 5. Demonstrate saving and loading only the LoRA weights
    let loraWeightsToSave = model.loraParameters()
    let loraWeightsFilePath = "lora_adapters.safetensors"
    do {
        try MLX.save(parameters: loraWeightsToSave, path: loraWeightsFilePath)
        print("\nLoRA weights saved to: \(loraWeightsFilePath)")

        // Simulate loading LoRA weights into a new model instance
        let loadedLoRAWeights = try MLX.load(path: loraWeightsFilePath)
        print("LoRA weights loaded from: \(loraWeightsFilePath). Count: \(loadedLoRAWeights.count)")
        
        // You would then apply these loaded weights to a new model instance
        // For demonstration, let's just show they were loaded
        if let firstLoadedWeight = loadedLoRAWeights.first {
            print("Example loaded LoRA weight: \(firstLoadedWeight.key) shape: \(firstLoadedWeight.value.shape)")
        }

    } catch {
        print("Error saving/loading LoRA weights: \(error)")
    }

    // 6. Demonstrate Inference with LoRA
    print("\nPerforming inference with 'fine-tuned' LoRA weights...")
    let inferenceInput = MLXArray.rand([1, sequenceLength], .int32) * MLXArray(vocabSize)
    MLX.eval(inferenceInput)

    let inferenceOutput = model(inferenceInput)
    MLX.eval(inferenceOutput)

    print("Inference input shape: \(inferenceInput.shape)")
    print("Inference output shape: \(inferenceOutput.shape)") // [1, sequence_length, dimensions]
    print("Inference output (first token, first dimension): \(inferenceOutput[0, 0, 0])")
    
    print("--- End Exercise 3 ---")
}

// Call the function to run the exercise
// runLoRAFineTuningExercise() // Uncomment to run in a playground or main.swift
