
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import UIKit
import WritingTools // Assume WritingTools framework is available

// MARK: - Custom UITextView for Context Menu Integration

@available(iOS 18.0, *)
class RewritingTextView: UITextView {
    
    // Custom action selector for rewriting
    @objc func rewriteSelectedTextAction(_ sender: Any?) {
        guard let selectedText = text(in: selectedTextRange ?? textRange(from: beginningOfDocument, to: beginningOfDocument)!) else {
            print("No text selected for rewriting.")
            return
        }
        
        let originalRange = selectedRange
        
        Task {
            await rewriteSelectedText(text: selectedText, range: originalRange)
        }
    }
    
    // Override to enable custom context menu action
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        if action == #selector(rewriteSelectedTextAction(_:)) {
            // Only enable if there's selected text
            return !selectedTextRange!.isEmpty
        }
        return super.canPerformAction(action, withSender: sender)
    }
    
    // Asynchronous function to interact with WritingToolsService
    private func rewriteSelectedText(text: String, range: NSRange) async {
        let request = WritingToolsRequest.RewriteRequest(text: text)
        
        DispatchQueue.main.async {
            // Optionally, show a loading indicator here
            print("Rewriting '\(text)'...")
        }
        
        do {
            let result = try await WritingToolsService.shared.rewriteRequest(for: request)
            
            if let rewrittenText = result.rewrite.suggestions.first?.text {
                DispatchQueue.main.async {
                    // Update UI on the main thread
                    self.textStorage.replaceCharacters(in: range, with: rewrittenText)
                    // Optionally, update the selection to the newly inserted text
                    self.selectedRange = NSRange(location: range.location, length: rewrittenText.count)
                    print("Text rewritten successfully: \(rewrittenText)")
                }
            } else {
                DispatchQueue.main.async {
                    print("No rewrite suggestions available.")
                    // Optionally, hide loading indicator and show a message
                }
            }
        } catch {
            DispatchQueue.main.async {
                print("Error rewriting text: \(error.localizedDescription)")
                // Optionally, hide loading indicator and show an error alert
            }
        }
    }
}

// MARK: - Example Usage in a UIViewController

@available(iOS 18.0, *)
class RewriteViewController: UIViewController {
    
    private let textView: RewritingTextView = {
        let tv = RewritingTextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = UIFont.preferredFont(forTextStyle: .body)
        tv.isEditable = true
        tv.isSelectable = true
        tv.backgroundColor = .systemBackground
        tv.layer.borderColor = UIColor.systemGray3.cgColor
        tv.layer.borderWidth = 1
        tv.layer.cornerRadius = 8
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return tv
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGroupedBackground
        title = "Rewrite Example (iOS 18+)"
        
        view.addSubview(textView)
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.heightAnchor.constraint(equalToConstant: 300) // Example height
        ])
        
        textView.text = "The quick brown fox jumps over the lazy dog. This is a sentence that could be improved. Please select some text and try rewriting it using the context menu."
        
        // Add custom menu item to UIMenuController
        // UIMenuController is often implicitly managed by UITextView,
        // but for custom actions, you might explicitly add it.
        // For iOS 18+, the system automatically integrates custom actions
        // if `canPerformAction` is properly overridden.
    }
    
    // Ensure the view controller is available for iOS 18+
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        guard #available(iOS 18.0, *) else { return nil }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        guard #available(iOS 18.0, *) else { return }
    }
}
