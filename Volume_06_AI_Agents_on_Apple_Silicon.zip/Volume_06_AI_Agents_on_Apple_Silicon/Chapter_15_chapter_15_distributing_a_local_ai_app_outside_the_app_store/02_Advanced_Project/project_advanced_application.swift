
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

import Foundation
import CryptoKit // For SHA256 hashing

// MARK: - 1. Model Configuration
/// Describes a specific LLM model available for download and use.
/// This struct holds all necessary metadata for a model, including its remote location,
/// expected integrity hash, and local identifiers.
struct LLMModelDescriptor: Identifiable, Hashable {
    let id: String // Unique identifier, e.g., "llama3-8b-q4"
    let name: String // User-friendly name, e.g., "Llama 3 8B (Quantized)"
    let version: String // Model version, e.g., "1.0.1"
    let downloadURL: URL // URL to fetch the model file from a custom server/CDN
    let expectedSHA256: String // Expected SHA256 hash for integrity verification after download
    let fileSizeGB: Double // Approximate file size in GB for display purposes

    /// Example model descriptors for demonstration. In a real app, these might
    /// be loaded from a remote configuration file or a database.
    static let exampleModels: [LLMModelDescriptor] = [
        LLMModelDescriptor(
            id: "llama3-8b-q4",
            name: "Llama 3 8B (Quantized)",
            version: "1.0.1",
            // Placeholder URL - in a real app, this would point to your CDN or server
            downloadURL: URL(string: "https://example.com/models/llama3-8b-q4-v1.0.1.gguf")!,
            expectedSHA256: "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2", // Replace with actual hash
            fileSizeGB: 4.7
        ),
        LLMModelDescriptor(
            id: "mistral-7b-q4",
            name: "Mistral 7B (Quantized)",
            version: "1.2.0",
            downloadURL: URL(string: "https://example.com/models/mistral-7b-q4-v1.2.0.gguf")!,
            expectedSHA256: "b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3", // Replace with actual hash
            fileSizeGB: 3.8
        )
    ]
}

// MARK: - 2. Error Handling
/// Custom errors for model management operations, providing localized descriptions
/// for better user feedback.
enum ModelManagerError: Error, LocalizedError {
    case invalidURL
    case downloadFailed(Error)
    case integrityCheckFailed(expected: String, actual: String)
    case fileSystemError(String, Error?)
    case modelNotFound(String)
    case cancellationRequested
    case unknown

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "The provided URL is invalid for download."
        case .downloadFailed(let error): return "Model download failed: \(error.localizedDescription)"
        case .integrityCheckFailed(let expected, let actual): return "Model integrity check failed. Expected SHA256: \(expected), Actual: \(actual)."
        case .fileSystemError(let message, let error): return "File system operation failed: \(message) - \(error?.localizedDescription ?? "No underlying error")."
        case .modelNotFound(let id): return "Model with ID '\(id)' not found locally."
        case .cancellationRequested: return "Model download was cancelled."
        case .unknown: return "An unknown error occurred during model management."
        }
    }
}

// MARK: - 3. Model Storage Utility
/// Manages the local storage paths for LLM models. This ensures models are stored
/// in a consistent and appropriate location, typically within the app's Application Support directory.
enum ModelStorage {
    /// Returns the URL for the application's dedicated model storage directory.
    /// This directory is suitable for large, user-specific data not meant for iCloud backup.
    /// - Throws: `ModelManagerError.fileSystemError` if the directory cannot be found or created.
    /// - Returns: The URL to the model storage directory.
    static func modelDirectory() throws -> URL {
        guard let appSupportDirectory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            throw ModelManagerError.fileSystemError("Could not find Application Support directory.", nil)
        }
        let modelsDirectory = appSupportDirectory.appendingPathComponent("LocalAIChatModels", isDirectory: true)

        if !FileManager.default.fileExists(atPath: modelsDirectory.path) {
            do {
                try FileManager.default.createDirectory(at: modelsDirectory, withIntermediateDirectories: true, attributes: nil)
            } catch {
                throw ModelManagerError.fileSystemError("Failed to create model directory at \(modelsDirectory.path)", error)
            }
        }
        return modelsDirectory
    }

    /// Returns the full local file URL for a specific model given its ID and version.
    /// - Parameters:
    ///   - id: The unique identifier of the model.
    ///   - version: The version string of the model.
    /// - Throws: `ModelManagerError.fileSystemError` if the model directory cannot be determined.
    /// - Returns: The expected local URL for the model file.
    static func localURL(forModelID id: String, version: String) throws -> URL {
        // Models are stored as ID-VERSION.gguf (e.g., llama3-8b-q4-1.0.1.gguf)
        return try modelDirectory().appendingPathComponent("\(id)-\(version).gguf")
    }

    /// Checks if a model file exists at its expected local path.
    /// - Parameters:
    ///   - id: The unique identifier of the model.
    ///   - version: The version string of the model.
    /// - Throws: `ModelManagerError.fileSystemError` if the model directory cannot be determined.
    /// - Returns: `true` if the file exists, `false` otherwise.
    static func modelExists(id: String, version: String) throws -> Bool {
        let url = try localURL(forModelID: id, version: version)
        return FileManager.default.fileExists(atPath: url.path)
    }

    /// Deletes a model file from local storage.
    /// - Parameters:
    ///   - id: The unique identifier of the model to delete.
    ///   - version: The version string of the model.
    /// - Throws: `ModelManagerError.modelNotFound` if the model file doesn't exist,
    ///           or `ModelManagerError.fileSystemError` if deletion fails.
    static func deleteModel(id: String, version: String) throws {
        let url = try localURL(forModelID: id, version: version)
        guard FileManager.default.fileExists(atPath: url.path) else {
            throw ModelManagerError.modelNotFound(id)
        }
        do {
            try FileManager.default.removeItem(at: url)
        } catch {
            throw ModelManagerError.fileSystemError("Failed to delete model file at \(url.path)", error)
        }
    }
}

// MARK: - 4. SHA256 Hashing Utility
/// Provides utility for computing SHA256 hashes of local files. This is crucial
/// for verifying the integrity of downloaded large model files.
enum SHA256Calculator {
    /// Computes the SHA256 hash of a file at the given URL.
    /// This method reads the file in chunks (1 MB buffer) to efficiently handle large files
    /// without loading the entire file into memory, preventing excessive memory usage.
    /// - Parameter url: The file URL to hash.
    /// - Throws: `ModelManagerError.fileSystemError` if the file cannot be opened or read.
    /// - Returns: A hexadecimal string representation of the SHA256 hash.
    static func computeSHA256(forFileAt url: URL) throws -> String {
        let bufferSize = 1024 * 1024 // 1 MB buffer
        var hasher = Insecure.SHA256() // Insecure is used here for demonstration; for critical security, prefer SHA512 or similar.

        guard let fileHandle = try? FileHandle(forReadingFrom: url) else {
            throw ModelManagerError.fileSystemError("Could not open file for hashing at \(url.path)", nil)
        }

        defer {
            try? fileHandle.close() // Ensure file handle is closed even if errors occur
        }

        // Read data in chunks until end of file
        while autoreleasepool(invoking: {
            let data = fileHandle.readData(ofLength: bufferSize)
            if data.isEmpty {
                return false // End of file
            }
            hasher.update(data: data)
            return true
        }) {}

        let digest = hasher.finalize()
        return digest.map { String(format: "%02hhx", $0) }.joined()
    }
}

// MARK: - 5. Model Download & Verification Service
/// Manages the secure download and integrity verification of LLM models.
/// It uses `URLSessionDownloadDelegate` for detailed progress reporting and
/// `CheckedContinuation` to integrate with Swift's modern concurrency model.
@available(macOS 14.0, iOS 18.0, *) // Requires modern concurrency features like CheckedContinuation
class LLMModelDownloader: NSObject, URLSessionDownloadDelegate, ObservableObject {
    private var urlSession: URLSession
    /// Tracks active downloads, mapping a `URLSessionDownloadTask` to its descriptor,
    /// the `CheckedContinuation` to resume upon completion/error, and a progress handler.
    private var activeDownloads: [URLSessionDownloadTask: (descriptor: LLMModelDescriptor, continuation: CheckedContinuation<URL, Error>, progressHandler: (Double) -> Void)] = [:]

    /// Initializes the downloader with a default URLSession configuration.
    /// The delegate is set to `self` to receive download events.
    override init() {
        let configuration = URLSessionConfiguration.default
        // For very large models, consider `URLSessionConfiguration.background(withIdentifier:)`
        // for downloads that can continue when the app is in the background.
        self.urlSession = URLSession(configuration: configuration, delegate: nil, delegateQueue: nil) // Initialized temporarily
        super.init()
        // Re-initialize the session with self as delegate after super.init() to ensure proper delegate setup.
        self.urlSession = URLSession(configuration: configuration, delegate: self, delegateQueue: OperationQueue.main) // Use main queue for delegate callbacks for simplicity
    }

    /// Asynchronously downloads and verifies an LLM model.
    /// This method leverages `URLSessionDownloadDelegate` for robust progress reporting
    /// and `CheckedContinuation` to bridge the delegate-based API with Swift concurrency (`async/await`).
    ///
    /// - Parameters:
    ///   - descriptor: The `LLMModelDescriptor` of the model to download.
    ///   - progressHandler: A closure called periodically with download progress (0.0 to 1.0).
    /// - Returns: The local URL of the successfully downloaded and verified model file.
    /// - Throws: `ModelManagerError` if download or verification fails.
    func downloadAndVerifyModel(descriptor: LLMModelDescriptor, progressHandler: @escaping (Double) -> Void) async throws -> URL {
        // Pre-check: Ensure the download URL is not a local file URL
        guard !descriptor.downloadURL.isFileURL else {
            throw ModelManagerError.invalidURL
        }

        // Check if the model already exists locally and its hash matches the descriptor.
        // This avoids re-downloading already valid models.
        if try ModelStorage.modelExists(id: descriptor.id, version: descriptor.version) {
            let localURL = try ModelStorage.localURL(forModelID: descriptor.id, version: descriptor.version)
            let actualHash = try SHA256Calculator.computeSHA256(forFileAt: localURL)
            if actualHash == descriptor.expectedSHA256 {
                print("Model \(descriptor.name) v\(descriptor.version) already exists and is verified.")
                return localURL // Return early if model is already valid
            } else {
                print("Model \(descriptor.name) v\(descriptor.version) exists but hash mismatch. Attempting re-download.")
                // Optionally delete the corrupted file to ensure a clean re-download
                try? ModelStorage.deleteModel(id: descriptor.id, version: descriptor.version)
            }
        }

        // Use `withTaskCancellationHandler` to ensure that if the calling `Task` is cancelled,
        // the underlying `URLSessionDownloadTask` is also cancelled.
        return try await withTaskCancellationHandler {
            // `withCheckedThrowingContinuation` bridges the asynchronous, delegate-based
            // `URLSession` API with Swift's structured concurrency (`async/await`).
            try await withCheckedThrowingContinuation { continuation in
                let downloadTask = urlSession.downloadTask(with: descriptor.downloadURL)
                // Store the descriptor, continuation, and progress handler for this task.
                activeDownloads[downloadTask] = (descriptor, continuation, progressHandler)
                downloadTask.resume() // Start the download
                print("Starting download for \(descriptor.name) from \(descriptor.downloadURL)")
            }
        } onCancel: {
            // This closure is called if the `Task` that called `downloadAndVerifyModel` is cancelled.
            for (task, value) in activeDownloads where value.descriptor.id == descriptor.id {
                task.cancel() // Cancel the underlying URLSession task
                print("Download for \(descriptor.name) cancelled by Task cancellation.")
                // The `urlSession(_:task:didCompleteWithError:)` delegate method will be called
                // with an `NSURLErrorCancelled` error, which will then resume the continuation.
            }
        }
    }

    /// Cancels an active download for a given model ID.
    /// This allows explicit cancellation from the UI or other parts of the app.
    /// - Parameter id: The unique identifier of the model whose download should be cancelled.
    func cancelDownload(forModelID id: String) {
        for (task, value) in activeDownloads where value.descriptor.id == id {
            task.cancel()
            print("Explicitly cancelled download for \(id).")
            // The delegate method `urlSession(_:task:didCompleteWithError:)` will handle
            // resuming the continuation with a cancellation error.
        }
    }

    // MARK: - URLSessionDownloadDelegate methods

    /// Reports download progress. This method is called periodically as data is received.
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let (descriptor, _, progressHandler) = activeDownloads[downloadTask] else { return }
        if totalBytesExpectedToWrite > 0 {
            let progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
            // Report progress on the main thread to ensure UI updates are safe.
            DispatchQueue.main.async {
                progressHandler(progress)
            }
            // print("Progress for \(descriptor.name): \(Int(progress * 100))%") // Uncomment for verbose logging
        }
    }

    /// Called when a download task completes successfully and the file has been downloaded
    /// to a temporary location.
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        // Retrieve the stored descriptor and continuation for this task.
        guard let (descriptor, continuation, _) = activeDownloads.removeValue(forKey: downloadTask) else { return }

        // Perform post-download processing (hash verification, file move) in a new Task
        // to avoid blocking the URLSession delegate queue.
        Task {
            do {
                // 1. Verify SHA256 hash of the downloaded temporary file.
                let actualHash = try SHA256Calculator.computeSHA256(forFileAt: location)
                guard actualHash == descriptor.expectedSHA256 else {
                    let error = ModelManagerError.integrityCheckFailed(expected: descriptor.expectedSHA256, actual: actualHash)
                    print("Integrity check failed for \(descriptor.name): \(error.localizedDescription)")
                    continuation.resume(throwing: error) // Resume continuation with integrity error
                    return
                }
                print("Integrity check passed for \(descriptor.name).")

                // 2. Move the verified file from the temporary location to its permanent storage.
                // This is an atomic operation, ensuring the file is only available if fully verified.
                let destinationURL = try ModelStorage.localURL(forModelID: descriptor.id, version: descriptor.version)
                try FileManager.default.moveItem(at: location, to: destinationURL)
                print("Model \(descriptor.name) saved to \(destinationURL.path)")

                // 3. Resume the continuation with the final local URL of the model.
                continuation.resume(returning: destinationURL)

            } catch {
                // Catch any errors during hashing or file system operations.
                print("Error during post-download processing for \(descriptor.name): \(error.localizedDescription)")
                continuation.resume(throwing: error) // Resume continuation with the encountered error
            }
        }
    }

    /// Called when a task completes, whether successfully or with an error.
    /// This is where download errors (e.g., network issues, server errors, cancellation) are handled.
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let downloadTask = task as? URLSessionDownloadTask,
              let (descriptor, continuation, _) = activeDownloads.removeValue(forKey: downloadTask) else { return }

        if let error = error {
            // Check for cancellation error specifically.
            if (error as NSError).code == NSURLErrorCancelled {
                print("Download for \(descriptor.name) was cancelled.")
                continuation.resume(throwing: ModelManagerError.cancellationRequested)
            } else {
                print("Download for \(descriptor.name) failed with error: \(error.localizedDescription)")
                continuation.resume(throwing: ModelManagerError.downloadFailed(error))
            }
        }
        // If error is nil, `didFinishDownloadingTo` should have already handled the successful completion
        // and resumed the continuation. This block primarily handles errors that prevent
        // `didFinishDownloadingTo` from being called.
    }
}

// MARK: - 6. Main Application Model Manager
/// Orchestrates the management of local LLM models within the application.
/// This class acts as the primary interface for UI components to interact with model downloads
/// and local storage, providing published properties for real-time updates.
@available(macOS 14.0, iOS 18.0, *)
class LocalAIChatAppModelManager: ObservableObject {
    /// Published property mapping model ID to its local file URL, for UI observation.
    @Published var downloadedModelURLs: [String: URL] = [:]
    /// Published property mapping model ID to its current download progress (0.0 - 1.0).
    @Published var downloadProgress: [String: Double] = [:]
    /// Published set of model IDs currently undergoing download.
    @Published var activeDownloads: Set<String> = []
    /// Published dictionary mapping model ID to the last encountered error during download/management.
    @Published var downloadErrors: [String: ModelManagerError] = [:]

    private let modelDownloader = LLMModelDownloader()
    private let availableModelDescriptors: [LLMModelDescriptor]

    /// Initializes the manager with a list of available model descriptors.
    /// It immediately attempts to load information about models already present on the file system.
    /// - Parameter availableModels: An array of `LLMModelDescriptor` representing all models the app can handle.
    init(availableModels: [LLMModelDescriptor] = LLMModelDescriptor.exampleModels) {
        self.availableModelDescriptors = availableModels
        // Asynchronously load existing models on initialization.
        Task { await loadExistingModels() }
    }

    /// Scans the local model directory to identify and verify models that have already been downloaded.
    /// Updates `downloadedModelURLs` accordingly. Runs on the main actor to ensure UI consistency.
    @MainActor
    private func loadExistingModels() async {
        for descriptor in availableModelDescriptors {
            do {
                if try ModelStorage.modelExists(id: descriptor.id, version: descriptor.version) {
                    let localURL = try ModelStorage.localURL(forModelID: descriptor.id, version: descriptor.version)
                    let actualHash = try SHA256Calculator.computeSHA256(forFileAt: localURL)
                    if actualHash == descriptor.expectedSHA256 {
                        downloadedModelURLs[descriptor.id] = localURL
                        print("Found existing and verified model: \(descriptor.name)")
                    } else {
                        print("Found existing model \(descriptor.name) but hash mismatch. It will be re-downloaded if requested.")
                        // Optionally, delete the corrupted file here: try? ModelStorage.deleteModel(...)
                    }
                }
            } catch {
                print("Error checking existing model \(descriptor.name): \(error.localizedDescription)")
            }
        }
    }

    /// Initiates the download and verification process for a given model ID.
    /// This method handles updating UI-bound published properties for progress and status.
    /// - Parameter modelID: The unique identifier of the model to download.
    @MainActor
    func downloadModel(modelID: String) async {
        guard let descriptor = availableModelDescriptors.first(where: { $0.id == modelID }) else {
            downloadErrors[modelID] = .modelNotFound(modelID)
            return
        }

        guard !activeDownloads.contains(modelID) else {
            print("Download for \(modelID) is already active.")
            return
        }

        activeDownloads.insert(modelID)
        downloadProgress[modelID] = 0.0 // Initialize progress
        downloadErrors.removeValue(forKey: modelID) // Clear any previous errors for this model

        do {
            let localURL = try await modelDownloader.downloadAndVerifyModel(descriptor: descriptor) { [weak self] progress in
                // Update progress on the main thread for UI.
                DispatchQueue.main.async {
                    self?.downloadProgress[modelID] = progress
                }
            }
            downloadedModelURLs[modelID] = localURL // Store the final URL
            print("Successfully downloaded and verified \(descriptor.name) to \(localURL.path)")
        } catch let error as ModelManagerError {
            print("Failed to download or verify \(descriptor.name): \(error.localizedDescription)")
            downloadErrors[modelID] = error // Report specific errors
        } catch {
            print("An unexpected error occurred for \(descriptor.name): \(error.localizedDescription)")
            downloadErrors[modelID] = .unknown // Catch any other unexpected errors
        }
        activeDownloads.remove(modelID) // Mark download as complete (or failed)
        downloadProgress.removeValue(forKey: modelID) // Clear progress after completion or error
    }

    /// Provides the local file URL for a downloaded and verified model.
    /// - Parameter modelID: The unique identifier of the model.
    /// - Returns: The local URL if the model is downloaded and verified, otherwise `nil`.
    func getLocalModelURL(forModelID modelID: String) -> URL? {
        return downloadedModelURLs[modelID]
    }

    /// Deletes a specified model from local storage.
    /// - Parameter modelID: The unique identifier of the model to delete.
    @MainActor
    func deleteModel(modelID: String) async {
        guard let descriptor = availableModelDescriptors.first(where: { $0.id == modelID }) else {
            print("Attempted to delete unknown model ID: \(modelID)")
            return
        }

        do {
            try ModelStorage.deleteModel(id: descriptor.id, version: descriptor.version)
            downloadedModelURLs.removeValue(forKey: modelID) // Remove from tracking
            print("Successfully deleted model \(descriptor.name).")
        } catch {
            print("Failed to delete model \(descriptor.name): \(error.localizedDescription)")
            downloadErrors[modelID] = .fileSystemError("Failed to delete model", error)
        }
    }

    /// Cancels an ongoing download for a specific model.
    /// - Parameter modelID: The unique identifier of the model whose download should be cancelled.
    @MainActor
    func cancelDownload(modelID: String) {
        modelDownloader.cancelDownload(forModelID: modelID)
        activeDownloads.remove(modelID)
        downloadProgress.removeValue(forKey: modelID)
        downloadErrors[modelID] = .cancellationRequested // Indicate cancellation
    }
}

// MARK: - Example Usage (simulated UI context)
/// This `ContentView` class simulates a SwiftUI View or ViewModel to demonstrate
/// how `LocalAIChatAppModelManager` would be integrated and used in an application.
@available(macOS 14.0, iOS 18.0, *)
class ContentView: ObservableObject {
    @Published var modelManager: LocalAIChatAppModelManager

    init() {
        self.modelManager = LocalAIChatAppModelManager()
    }

    /// Sets up and runs a demonstration of model downloading, progress tracking,
    /// cancellation, and deletion.
    func setupAndRunExample() async {
        print("\n--- Starting Local AI Chat Assistant Demo ---")

        let llama3ID = "llama3-8b-q4"
        let mistralID = "mistral-7b-q4"

        // --- Scenario 1: Download Llama 3 model ---
        print("\nAttempting to download \(llama3ID)...")
        await modelManager.downloadModel(modelID: llama3ID)

        if let llama3URL = modelManager.getLocalModelURL(forModelID: llama3ID) {
            print("Llama 3 model is ready at: \(llama3URL.path)")
            // In a real app, you would now pass `llama3URL` to your llama.cpp Swift bindings
            // or Ollama client to load the model for inference.
        } else if let error = modelManager.downloadErrors[llama3ID] {
            print("Failed to get Llama 3 model: \(error.localizedDescription)")
        }

        // --- Scenario 2: Attempt to download the same model again (should be skipped if successful) ---
        print("\nAttempting to download \(llama3ID) again (should be skipped if already valid)...")
        await modelManager.downloadModel(modelID: llama3ID)

        // --- Scenario 3: Download another model (Mistral) with simulated progress monitoring ---
        print("\nAttempting to download \(mistralID)...")
        // Start the download in a separate task to allow concurrent monitoring.
        Task {
            await modelManager.downloadModel(modelID: mistralID)
        }

        // Simulate monitoring progress for Mistral (in a real UI, this would be bound to a progress bar).
        var counter = 0
        while modelManager.activeDownloads.contains(mistralID) && counter < 5 { // Monitor for a few seconds
            if let progress = modelManager.downloadProgress[mistralID] {
                print("Mistral download progress: \(Int(progress * 100))%")
            }
            try? await Task.sleep(for: .seconds(1)) // Simulate UI refresh interval
            counter += 1
        }

        // --- Scenario 4: Simulate cancellation if Mistral is still downloading ---
        if modelManager.activeDownloads.contains(mistralID) {
            print("\nCancelling Mistral download...")
            modelManager.cancelDownload(modelID: mistralID)
            try? await Task.sleep(for: .seconds(1)) // Give time for cancellation to propagate
        }

        // Check final status for Mistral after potential cancellation.
        if let mistralURL = modelManager.getLocalModelURL(forModelID: mistralID) {
            print("Mistral model is ready at: \(mistralURL.path)")
        } else if let error = modelManager.downloadErrors[mistralID] {
            print("Failed to get Mistral model: \(error.localizedDescription)")
        }

        // --- Scenario 5: Simulate deleting a model ---
        print("\nDeleting Llama 3 model...")
        await modelManager.deleteModel(modelID: llama3ID)
        if modelManager.getLocalModelURL(forModelID: llama3ID) == nil {
            print("Llama 3 model successfully deleted.")
        } else {
            print("Llama 3 model still present (error during deletion?).")
        }

        print("\n--- Local AI Chat Assistant Demo Finished ---")
    }
}

// To run this example in a Swift Package Executable or a SwiftUI App:
/*
// For a SwiftUI App (e.g., in your App.swift file):
@main
struct LocalAIApp: App {
    @StateObject private var contentViewModel = ContentView()

    var body: some Scene {
        WindowGroup {
            Text("Local AI App Demo")
                .task {
                    // Start the demo when the app launches
                    await contentViewModel.setupAndRunExample()
                }
        }
    }
}

// For a simple command-line execution (e.g., in a Swift Package Executable target's main.swift):
@available(macOS 14.0, iOS 18.0, *)
@main
struct LocalAIDemoExecutable {
    static func main() async {
        let contentViewModel = ContentView()
        await contentViewModel.setupAndRunExample()
    }
}
*/
