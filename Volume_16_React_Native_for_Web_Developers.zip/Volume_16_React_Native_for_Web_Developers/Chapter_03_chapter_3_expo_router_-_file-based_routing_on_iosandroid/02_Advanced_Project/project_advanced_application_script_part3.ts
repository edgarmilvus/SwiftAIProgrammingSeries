/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ==============================================================================
 * FILE: app/projects/[id]/dashboard/page.tsx
 * PURPOSE: Dynamic Route Segment.
 *          Handles the URL pattern /projects/:id/dashboard.
 *          Fetches data specific to the ID.
 * ==============================================================================
 */
import { notFound } from 'next/navigation';
import { UpdateProjectForm } from './update-form';

interface PageProps {
  params: {
    id: string;
  };
}

export default async function ProjectDashboard({ params }: PageProps) {
  // 1. Data Fetching based on Dynamic Param
  // This runs on the server. The 'id' is available immediately.
  const project = await fetchProject(params.id);

  if (!project) {
    notFound(); // Triggers 404 boundary
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold">Dashboard: {project.name}</h1>
        <p className="text-gray-600">ID: {params.id}</p>
      </header>

      <section className="grid grid-cols-3 gap-4">
        <div className="col-span-2 bg-white p-4 border rounded shadow-sm">
          <h2 className="text-xl font-semibold mb-2">Analytics</h2>
          <p>Total Views: {project.views}</p>
          <p>Active Users: {project.users}</p>
        </div>

        <div className="col-span-1 bg-white p-4 border rounded shadow-sm">
          <h2 className="text-xl font-semibold mb-2">Settings</h2>
          {/* 
            Client Component hydration: 
            The form interactivity happens here. We pass initial data as props.
          */}
          <UpdateProjectForm projectId={params.id} initialName={project.name} />
        </div>
      </section>
    </div>
  );
}

// Helper function (Server-side only)
async function fetchProject(id: string) {
  // Simulate DB lookup
  if (id === 'proj-1') {
    return { name: 'Project Alpha', views: 1200, users: 45 };
  }
  if (id === 'proj-2') {
    return { name: 'Project Beta', views: 300, users: 12 };
  }
  return null;
}
