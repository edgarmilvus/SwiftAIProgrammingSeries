
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import AppIntents
import Foundation // For UUID

// MARK: - NoteCategory AppEntity
// Define your NoteCategory struct here, conforming to AppEntity, Codable, and Identifiable.
// It should have properties like 'id' (e.g., String) and 'name'.
// Implement 'displayRepresentation' for AppEntity conformance.
@available(iOS 18.0, *)
struct NoteCategory: AppEntity, Codable, Identifiable, Hashable { // Added Hashable for contains(where:) in provider
    var id: String
    var name: String

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Note Category"

    var displayRepresentation: DisplayRepresentation {
        DisplayRepresentation(stringLiteral: name)
    }
}

// MARK: - NoteCategoryProvider
@available(iOS 18.0, *)
struct NoteCategoryProvider: DynamicOptionsProvider {
    typealias Result = NoteCategory

    // Simulated AI function for contextual category suggestions
    private func simulateAICategorySuggestions(for text: String) async -> [NoteCategory] {
        try? await Task.sleep(for: .milliseconds(400)) // Simulate AI processing time

        var suggestions: [NoteCategory] = []
        let lowercasedText = text.lowercased()

        // Keyword-based AI simulation
        if lowercasedText.contains("finance") || lowercasedText.contains("money") || lowercasedText.contains("budget") {
            suggestions.append(NoteCategory(id: "finance", name: "Finance"))
        }
        if lowercasedText.contains("travel") || lowercasedText.contains("trip") || lowercasedText.contains("vacation") {
            suggestions.append(NoteCategory(id: "travel", name: "Travel"))
        }
        if lowercasedText.contains("meeting") || lowercasedText.contains("project") || lowercasedText.contains("work") {
            suggestions.append(NoteCategory(id: "work", name: "Work"))
        }
        if lowercasedText.contains("personal") || lowercasedText.contains("diary") || lowercasedText.contains("thoughts") {
            suggestions.append(NoteCategory(id: "personal", name: "Personal"))
        }
        if lowercasedText.contains("recipe") || lowercasedText.contains("cooking") || lowercasedText.contains("food") {
            suggestions.append(NoteCategory(id: "recipes", name: "Recipes"))
        }

        // Add some common categories as default if not already present or if text is empty
        let defaultCommonCategories: [NoteCategory] = [
            NoteCategory(id: "general", name: "General"),
            NoteCategory(id: "ideas", name: "Ideas"),
            NoteCategory(id: "todos", name: "To-Dos"),
            NoteCategory(id: "reminders", name: "Reminders")
        ]
        
        for category in defaultCommonCategories {
            if !suggestions.contains(where: { $0.id == category.id }) {
                suggestions.append(category)
            }
        }

        // Ensure uniqueness and limit for display
        return Array(Set(suggestions)).sorted { $0.name < $1.name }.prefix(10) // Limit to top 10 for display
    }

    func suggestedOptions() async throws -> [NoteCategory] {
        // When no search term is provided, simulate suggestions based on general context
        // In a real AI scenario, this might use recent activity or user preferences.
        return await simulateAICategorySuggestions(for: "")
    }

    func suggestedOptions(for searchTerm: String?) async throws -> [NoteCategory] {
        // Here, the 'searchTerm' is used to influence the AI suggestions.
        // If the user types a search term, we first get AI suggestions based on that term
        // (simulating AI analysis of the typed text), then filter those suggestions further.
        let textForAI = searchTerm ?? ""
        var aiSuggestions = await simulateAICategorySuggestions(for: textForAI)
        
        if let searchTerm = searchTerm, !searchTerm.isEmpty {
            let lowercasedSearchTerm = searchTerm.lowercased()
            // Further filter AI suggestions if the user is actively typing a category name
            aiSuggestions = aiSuggestions.filter { $0.name.lowercased().contains(lowercasedSearchTerm) }
        }
        return aiSuggestions
    }

    func defaultOptions() async throws -> [NoteCategory] {
        return await simulateAICategorySuggestions(for: "")
    }

    func options(for identifiers: [NoteCategory.ID]) async throws -> [NoteCategory] {
        // In a real app, fetch categories by ID from your data store.
        // For this exercise, we combine a baseline of simulated and default categories
        // to ensure we can find any ID that might have been suggested.
        let baselineCategories = await simulateAICategorySuggestions(for: "")
        let allPossibleCategories = Set(baselineCategories).sorted { $0.name < $1.name } // Ensure uniqueness
        
        return allPossibleCategories.filter { identifiers.contains($0.id) }
    }
}

// MARK: - SummarizeAndCategorizeNoteIntent
@available(iOS 18.0, *)
struct SummarizeAndCategorizeNoteIntent: AppIntent {
    static var title: LocalizedStringResource = "Summarize and Categorize Note"
    static var description: IntentDescription = "Summarizes selected text and saves it under a chosen category."

    @Parameter(title: "Text to Summarize", description: "The text content to be summarized.", inputConnection: .text)
    var textToSummarize: String

    @Parameter(title: "Category", description: "The category for the summarized note.", optionsProvider: NoteCategoryProvider.self)
    var category: NoteCategory

    func perform() async throws -> some IntentResult {
        // Simulate summarization
        var simulatedSummary = textToSummarize
        if textToSummarize.count > 100 { // Simple truncation for long texts
            let endIndex = textToSummarize.index(textToSummarize.startIndex, offsetBy: 100)
            simulatedSummary = String(textToSummarize[..<endIndex]) + "..."
        }
        
        print("Original Text: \"\(textToSummarize)\"")
        print("Simulated Summary: \"\(simulatedSummary)\"")
        print("Categorized as: \(category.name) (ID: \(category.id))")
        
        // In a real app, you would save this summary and category to your app's data store.
        // e.g., NoteManager.shared.saveNote(summary: simulatedSummary, category: category)
        
        return .result(
            value: simulatedSummary, // Return the summary as a result
            view: IntentResultView {
                VStack(alignment: .leading) {
                    Text("Note Summarized & Categorized!")
                        .font(.headline)
                    Text("Category: \(category.name)")
                    Text("Summary: \(simulatedSummary)")
                }
            }
        )
    }
}
