
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import AVFoundation
import Vision
import UIKit // For UIImage, although CVPixelBuffer is primary

/// Protocol for communicating scan results and errors back to the UI.
@available(iOS 17.0, *) // Targeting modern iOS for async/await and Vision features
protocol SmartDocumentScannerProcessorDelegate: AnyObject {
    /// Called when document rectangles are detected in a frame.
    /// - Parameters:
    ///   - processor: The `SmartDocumentScannerProcessor` instance.
    ///   - rectangles: An array of `VNRectangleObservation` representing detected documents.
    ///   - frameSize: The size of the processed video frame.
    func processor(_ processor: SmartDocumentScannerProcessor, didDetectDocumentRectangles rectangles: [VNRectangleObservation], in frameSize: CGSize)

    /// Called when text is recognized in a frame.
    /// - Parameters:
    ///   - processor: The `SmartDocumentScannerProcessor` instance.
    ///   - recognizedText: The combined string of recognized text.
    ///   - boundingBoxes: An array of `CGRect` for each recognized text line.
    ///   - frameSize: The size of the processed video frame.
    func processor(_ processor: SmartDocumentScannerProcessor, didRecognizeText recognizedText: String, boundingBoxes: [CGRect], in frameSize: CGSize)

    /// Called when an error occurs during camera or Vision processing.
    /// - Parameters:
    ///   - processor: The `SmartDocumentScannerProcessor` instance.
    ///   - error: The error that occurred.
    func processor(_ processor: SmartDocumentScannerProcessor, didEncounterError error: Error)
}

/// Manages live camera feed, performs document rectangle detection and text recognition using Vision.
@available(iOS 17.0, *)
class SmartDocumentScannerProcessor: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {

    // MARK: - Properties

    private let captureSession = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    // Use a dedicated serial queue for video data output delegate to prevent blocking the main thread.
    private let videoDataOutputQueue = DispatchQueue(label: "com.example.SmartScanner.VideoDataOutput", qos: .userInitiated)

    // Vision requests
    private var rectangleDetectionRequest: VNDetectRectanglesRequest!
    private var textRecognitionRequest: VNRecognizeTextRequest!

    // Flag to prevent concurrent Vision processing of frames, ensuring performance.
    private var isProcessingFrame = false

    weak var delegate: SmartDocumentScannerProcessorDelegate?

    /// The `AVCaptureVideoPreviewLayer` to display the camera feed.
    /// This should be added to a `UIView`'s layer hierarchy.
    lazy var previewLayer: AVCaptureVideoPreviewLayer = {
        let layer = AVCaptureVideoPreviewLayer(session: captureSession)
        layer.videoGravity = .resizeAspectFill
        return layer
    }()

    // MARK: - Initialization

    override init() {
        super.init()
        setupVisionRequests()
    }

    /// Configures the Vision requests for document rectangle detection and text recognition.
    private func setupVisionRequests() {
        // Configure rectangle detection request
        rectangleDetectionRequest = VNDetectRectanglesRequest { [weak self] request, error in
            guard let self = self else { return }
            if let error = error {
                self.delegate?.processor(self, didEncounterError: error)
                return
            }
            self.handleRectangleDetection(request: request)
        }
        // Optimize for document detection: look for rectangles with aspect ratios close to typical documents.
        rectangleDetectionRequest.minimumAspectRatio = 0.5 // e.g., A4 portrait
        rectangleDetectionRequest.maximumAspectRatio = 2.0  // e.g., A4 landscape
        rectangleDetectionRequest.quadratureTolerance = 15.0 // Allow some skew
        rectangleDetectionRequest.minimumSize = 0.1 // Minimum size relative to image dimensions
        rectangleDetectionRequest.maximumObservations = 1 // Focus on the most prominent document

        // Configure text recognition request
        textRecognitionRequest = VNRecognizeTextRequest { [weak self] request, error in
            guard let self = self else { return }
            if let error = error {
                self.delegate?.processor(self, didEncounterError: error)
                return
            }
            self.handleTextRecognition(request: request)
        }
        textRecognitionRequest.recognitionLevel = .accurate // More accurate but slower
        textRecognitionRequest.usesLanguageCorrection = true
        textRecognitionRequest.recognitionLanguages = ["en-US", "fr-FR", "es-ES"] // Specify languages for better accuracy
    }

    // MARK: - Camera Setup

    /// Requests camera authorization and sets up the AVCaptureSession.
    /// - Throws: `CameraError` if camera access is denied or setup fails.
    func setupCamera() async throws {
        // Request camera authorization first.
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        switch status {
        case .notDetermined:
            // Prompt user for permission.
            let granted = await AVCaptureDevice.requestAccess(for: .video)
            guard granted else {
                throw CameraError.permissionDenied
            }
        case .denied, .restricted:
            throw CameraError.permissionDenied
        case .authorized:
            break // Permission already granted.
        @unknown default:
            throw CameraError.unknown
        }

        // Configure the capture session on a background queue to avoid blocking the UI.
        await Task.detached { [weak self] in
            guard let self = self else { return }
            self.captureSession.beginConfiguration()
            defer { self.captureSession.commitConfiguration() } // Ensure configuration is committed

            // Remove existing inputs/outputs to ensure a clean setup
            self.captureSession.inputs.forEach { self.captureSession.removeInput($0) }
            self.captureSession.outputs.forEach { self.captureSession.removeOutput($0) }

            // Add video input
            guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
                throw CameraError.noCameraAvailable
            }
            let videoInput = try AVCaptureDeviceInput(device: videoDevice)
            guard self.captureSession.canAddInput(videoInput) else {
                throw CameraError.cannotAddInput
            }
            self.captureSession.addInput(videoInput)

            // Add video data output
            guard self.captureSession.canAddOutput(self.videoOutput) else {
                throw CameraError.cannotAddOutput
            }
            self.captureSession.addOutput(self.videoOutput)

            // Set video output settings: pixel format and delegate
            self.videoOutput.alwaysDiscardsLateVideoFrames = true
            // Use BGRA for direct display or YpCbCr for performance if Vision handles it.
            // Vision works well with both, BGRA is often simpler for direct pixel access if needed.
            self.videoOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
            self.videoOutput.setSampleBufferDelegate(self, queue: self.videoDataOutputQueue)

            // Ensure video orientation matches device orientation for correct Vision processing
            if let connection = self.videoOutput.connection, connection.isVideoOrientationSupported {
                connection.videoOrientation = .portrait // Or dynamically adjust based on device orientation
            }

            self.captureSession.sessionPreset = .high // Or .photo for highest quality
        }.value // Await the detached task to ensure setup completes before returning
    }

    /// Starts the capture session.
    func startSession() {
        // Start running the session on a background thread.
        Task.detached { [weak self] in
            guard let self = self else { return }
            if !self.captureSession.isRunning {
                self.captureSession.startRunning()
                print("AVCaptureSession started.")
            }
        }
    }

    /// Stops the capture session.
    func stopSession() {
        // Stop running the session on a background thread.
        Task.detached { [weak self] in
            guard let self = self else { return }
            if self.captureSession.isRunning {
                self.captureSession.stopRunning()
                print("AVCaptureSession stopped.")
            }
        }
    }

    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

    /// Called whenever the video output captures a new video frame.
    /// This is where the Vision requests are performed.
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard !isProcessingFrame else { return } // Skip frame if previous one is still processing

        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            delegate?.processor(self, didEncounterError: CameraError.failedToGetPixelBuffer)
            return
        }

        // Set flag to prevent concurrent processing.
        isProcessingFrame = true
        defer { isProcessingFrame = false } // Ensure flag is reset after processing

        // Create a Vision image request handler for the current frame.
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up) // Orientation needs to be correct for Vision

        do {
            // Perform both rectangle detection and text recognition concurrently.
            try handler.perform([rectangleDetectionRequest, textRecognitionRequest])
        } catch {
            delegate?.processor(self, didEncounterError: error)
        }
    }

    // MARK: - Vision Request Handlers

    /// Handles the results of the `VNDetectRectanglesRequest`.
    /// - Parameter request: The completed Vision request.
    private func handleRectangleDetection(request: VNRequest) {
        guard let observations = request.results as? [VNRectangleObservation], !observations.isEmpty else {
            // No rectangles detected, clear any previous overlays.
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                self.delegate?.processor(self, didDetectDocumentRectangles: [], in: .zero) // Clear rectangles
            }
            return
        }

        // The input image's dimensions are available via the request's originalImageDimensions
        let imageWidth = request.originalImageDimensions.width
        let imageHeight = request.originalImageDimensions.height
        let frameSize = CGSize(width: imageWidth, height: imageHeight)

        // Pass observations to the delegate on the main thread for UI updates.
        Task { @MainActor [weak self] in
            guard let self = self else { return }
            self.delegate?.processor(self, didDetectDocumentRectangles: observations, in: frameSize)
        }
    }

    /// Handles the results of the `VNRecognizeTextRequest`.
    /// - Parameter request: The completed Vision request.
    private func handleTextRecognition(request: VNRequest) {
        guard let observations = request.results as? [VNRecognizeTextObservation], !observations.isEmpty else {
            // No text recognized, clear any previous text.
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                self.delegate?.processor(self, didRecognizeText: "", boundingBoxes: [], in: .zero) // Clear text
            }
            return
        }

        let imageWidth = request.originalImageDimensions.width
        let imageHeight = request.originalImageDimensions.height
        let frameSize = CGSize(width: imageWidth, height: imageHeight)

        var recognizedText = ""
        var boundingBoxes: [CGRect] = []

        for observation in observations {
            // Get the top candidate for each text observation.
            guard let topCandidate = observation.topCandidates(1).first else { continue }
            recognizedText += topCandidate.string + "\n"

            // Convert Vision normalized bounding box to UIKit coordinates.
            // Vision's origin is bottom-left, UIKit's is top-left.
            // Y-coordinate needs to be flipped, and scaled by image dimensions.
            let boundingBox = VNImageRectForNormalizedRect(observation.boundingBox, Int(imageWidth), Int(imageHeight))
            boundingBoxes.append(boundingBox)
        }

        // Pass recognized text and bounding boxes to the delegate on the main thread.
        Task { @MainActor [weak self] in
            guard let self = self else { return }
            self.delegate?.processor(self, didRecognizeText: recognizedText, boundingBoxes: boundingBoxes, in: frameSize)
        }
    }

    // MARK: - Error Handling

    /// Custom errors for camera operations.
    enum CameraError: Error, LocalizedError {
        case permissionDenied
        case noCameraAvailable
        case cannotAddInput
        case cannotAddOutput
        case failedToGetPixelBuffer
        case unknown

        var errorDescription: String? {
            switch self {
            case .permissionDenied:
                return "Camera access denied. Please enable camera access in Settings."
            case .noCameraAvailable:
                return "No camera device is available."
            case .cannotAddInput:
                return "Could not add camera input to the session."
            case .cannotAddOutput:
                return "Could not add video data output to the session."
            case .failedToGetPixelBuffer:
                return "Failed to get CVPixelBuffer from sample buffer."
            case .unknown:
                return "An unknown camera error occurred."
            }
        }
    }
}
