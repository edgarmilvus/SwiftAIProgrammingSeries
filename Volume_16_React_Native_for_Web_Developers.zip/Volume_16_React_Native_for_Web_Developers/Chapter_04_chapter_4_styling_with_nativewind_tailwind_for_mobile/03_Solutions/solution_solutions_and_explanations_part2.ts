/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { View, Text, Image } from 'react-native';

interface ProfileCardProps {
  name: string;
  bio: string;
  avatarUrl: string;
}

export const ProfileCard: React.FC<ProfileCardProps> = ({ name, bio, avatarUrl }) => {
  return (
    // Container View
    // Default (Mobile): Flex column, centered, gap-4
    // MD breakpoint: Flex row, items start (aligned to top), gap-6
    <View className="flex-col items-center justify-center gap-4 md:flex-row md:items-start md:gap-6 bg-white p-4 rounded-lg shadow-md">
      
      {/* Avatar Image */}
      // Mobile: w-16 h-16
      // MD breakpoint: md:w-20 md:h-20
      <Image
        source={{ uri: avatarUrl }}
        className="w-16 h-16 rounded-full md:w-20 md:h-20"
        resizeMode="cover"
      />

      {/* Text Details Container */}
      <View className="flex-1 items-center md:items-start">
        <Text className="text-lg font-bold text-gray-900">{name}</Text>
        <Text className="text-sm text-gray-600 mt-1 text-center md:text-left">{bio}</Text>
      </View>
    </View>
  );
};
