
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

import Foundation
import Observation
import CoreML

// MARK: - Models

/// Represents the sensitivity level of the input data.
/// This dictates our decision-making logic in the framework.
enum DataSensitivity: Sendable {
    case low      // Public info, safe for cloud
    case medium   // User preferences, prefer local
    case high     // Biometrics, PII, strictly local
}

/// A thread-safe container for AI results.
struct AIResponse: Sendable, Identifiable {
    let id: UUID
    let text: String
    let source: InferenceSource
}

enum InferenceSource: Sendable {
    case onDevice
    case cloud
}

/// The input payload, strictly enforcing Sendable to ensure 
/// we know exactly what is being passed across boundaries.
struct AIInput: Sendable {
    let prompt: String
    let sensitivity: DataSensitivity
    let context: [String: String]
}

// MARK: - Engine Protocols

/// Defines the capability of an inference provider.
protocol InferenceProvider: Sendable {
    func generateResponse(for input: AIInput) async throws -> String
}

// MARK: - Implementations

/// On-Device Engine: High privacy, low latency, limited intelligence.
/// Uses @available(iOS 18.0, *) to leverage the latest ML capabilities.
final class LocalInferenceProvider: InferenceProvider {
    @available(iOS 18.0, *)
    func generateResponse(for input: AIInput) async throws -> String {
        // Simulate Core ML inference on the Neural Engine
        // In a real app, this would involve:
        // let model = try await MLModel.load(contentsOf: modelURL)
        try await Task.sleep(for: .milliseconds(500)) 
        return "Local Response to: \(input.prompt)"
    }
}

/// Cloud Engine: High intelligence, high latency, privacy risk.
final class CloudInferenceProvider: InferenceProvider {
    func generateResponse(for input: AIInput) async throws -> String {
        // Simulate a network request to a remote LLM
        try await Task.sleep(for: .seconds(2))
        return "Cloud Response to: \(input.prompt)"
    }
}

// MARK: - The Decision Framework Engine

/// The core actor that manages the inference logic.
/// Using an actor ensures that the 'state' of the engine (e.g., current model)
/// is isolated from data races.
actor HybridInferenceEngine {
    private let localProvider: LocalInferenceProvider
    private let cloudProvider: CloudInferenceProvider
    
    init(local: LocalInferenceProvider, cloud: CloudInferenceProvider) {
        self.localProvider = local
        self.cloudProvider = cloud
    }
    
    /// The Decision Framework Logic:
    /// This is where the theoretical 'Privacy-Utility' trade-off is codified.
    func process(_ input: AIInput) async throws -> AIResponse {
        switch input.sensitivity {
        case .high:
            // Strict enforcement of privacy: High sensitivity ALWAYS stays local.
            let text = try await localProvider.generateResponse(for: input)
            return AIResponse(id: UUID(), text: text, source: .onDevice)
            
        case .medium:
            // Heuristic-based decision: If the prompt is too complex for local, 
            // we might prompt the user for permission or use a smaller local model.
            // For this framework, we default to local for medium.
            let text = try await localProvider.generateResponse(for: input)
            return AIResponse(id: UUID(), text: text, source: .onDevice)
            
        case .low:
            // Maximum utility: Low sensitivity goes to the cloud.
            let text = try await cloudProvider.generateResponse(for: input)
            return AIResponse(id: UUID(), text: text, source: .cloud)
        }
    }
}

// MARK: - UI State Management

/// Using @Observable to bridge the Gap between the Actor and the SwiftUI View.
@Observable
@MainActor
final class AIViewModel {
    var currentResponse: AIResponse?
    var isProcessing: Bool = false
    var errorMessage: String?
    
    private let engine: HybridInferenceEngine
    
    init(engine: HybridInferenceEngine) {
        self.engine = engine
    }
    
    func askQuestion(prompt: String, sensitivity: DataSensitivity) {
        isProcessing = true
        errorMessage = nil
        
        let input = AIInput(prompt: prompt, sensitivity: sensitivity, context: [:])
        
        // We create a Task to bridge the synchronous UI call to the asynchronous Actor.
        Task {
            do {
                // The 'await' here handles the non-deterministic latency 
                // of the underlying provider.
                let response = try await engine.process(input)
                self.currentResponse = response
            } catch {
                self.errorMessage = error.localizedDescription
            }
            self.isProcessing = false
        }
    }
}
