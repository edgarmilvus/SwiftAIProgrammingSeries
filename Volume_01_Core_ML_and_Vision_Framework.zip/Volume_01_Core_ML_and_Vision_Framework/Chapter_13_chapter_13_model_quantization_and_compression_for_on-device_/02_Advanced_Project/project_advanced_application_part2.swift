
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import CoreML
import Vision
import UIKit // For UIImage and CIImage

// Ensure compatibility with the latest iOS version for Core ML and Vision advancements
@available(iOS 18.0, *)
enum QuantizationStrategy: String, CaseIterable, Identifiable {
    case fullPrecision = "FullPrecision" // Represents FP32 model
    case quantized = "Quantized"       // Represents INT8 model

    var id: String { self.rawValue }

    /// Returns the filename prefix for the corresponding model.
    var modelFileName: String {
        switch self {
        case .fullPrecision: return "DocumentClassifier_FP32"
        case .quantized: return "DocumentClassifier_INT8"
        }
    }

    /// Provides a user-friendly description for the strategy.
    var description: String {
        switch self {
        case .fullPrecision: return "High Accuracy (Full Precision)"
        case .quantized: return "Fast Scan (Quantized)"
        }
    }
}

@available(iOS 18.0, *)
enum ModelInferenceError: Error, LocalizedError {
    case modelNotFound(strategy: QuantizationStrategy)
    case modelLoadingFailed(strategy: QuantizationStrategy, underlyingError: Error)
    case imageProcessingFailed
    case classificationFailed(underlyingError: Error?)
    case invalidInputImage

    var errorDescription: String? {
        switch self {
        case .modelNotFound(let strategy):
            return "Could not find model for strategy: \(strategy.description)."
        case .modelLoadingFailed(let strategy, let error):
            return "Failed to load model for strategy \(strategy.description): \(error.localizedDescription)."
        case .imageProcessingFailed:
            return "Failed to process the input image for classification."
        case .classificationFailed(let error):
            return "Document classification failed: \(error?.localizedDescription ?? "Unknown error")."
        case .invalidInputImage:
            return "The provided image is invalid for classification."
        }
    }
}
