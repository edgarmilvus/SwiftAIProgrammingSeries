
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import UIKit
import WritingTools // Assume WritingTools framework is available

// MARK: - Proofreading Popover ViewController

@available(iOS 18.0, *)
class ProofreadingSuggestionViewController: UIViewController {
    let suggestions: [String]
    var onSelectReplacement: ((String) -> Void)?
    
    private lazy var stackView: UIStackView = {
        let sv = UIStackView()
        sv.axis = .vertical
        sv.spacing = 8
        sv.translatesAutoresizingMaskIntoConstraints = false
        return sv
    }()
    
    init(suggestions: [String], onSelectReplacement: ((String) -> Void)?) {
        self.suggestions = suggestions
        self.onSelectReplacement = onSelectReplacement
        super.init(nibName: nil, bundle: nil)
        
        // Set preferred content size for popover
        self.preferredContentSize = CGSize(width: 250, height: (40 * suggestions.count) + 20)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        view.layer.cornerRadius = 10
        view.clipsToBounds = true
        
        view.addSubview(stackView)
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            stackView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            stackView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            stackView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -10)
        ])
        
        for (index, suggestion) in suggestions.enumerated() {
            let button = UIButton(type: .system)
            button.setTitle(suggestion, for: .normal)
            button.contentHorizontalAlignment = .left
            button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
            button.tag = index
            button.addTarget(self, action: #selector(suggestionTapped(_:)), for: .touchUpInside)
            stackView.addArrangedSubview(button)
        }
    }
    
    @objc private func suggestionTapped(_ sender: UIButton) {
        let selectedSuggestion = suggestions[sender.tag]
        onSelectReplacement?(selectedSuggestion)
        dismiss(animated: true, completion: nil)
    }
}

// MARK: - UIViewController for Proofreading Example

@available(iOS 18.0, *)
class ProofreadViewController: UIViewController, UITextViewDelegate, UIPopoverPresentationControllerDelegate {
    
    private let textView: UITextView = {
        let tv = UITextView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.font = UIFont.preferredFont(forTextStyle: .body)
        tv.isEditable = true
        tv.isSelectable = true
        tv.backgroundColor = .systemBackground
        tv.layer.borderColor = UIColor.systemGray3.cgColor
        tv.layer.borderWidth = 1
        tv.layer.cornerRadius = 8
        tv.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return tv
    }()
    
    private lazy var proofreadButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Proofread Document", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        button.addTarget(self, action: #selector(proofreadDocument), for: .touchUpInside)
        return button
    }()
    
    // Custom attribute key to store proofreading suggestion data
    private static let proofreadingSuggestionAttributeName = NSAttributedString.Key("ProofreadingSuggestion")
    
    // Store all proofreading results to retrieve suggestions on tap
    private var currentProofreadingSuggestions: [NSRange: [String]] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGroupedBackground
        title = "Proofread Example (iOS 18+)"
        
        view.addSubview(proofreadButton)
        view.addSubview(textView)
        
        NSLayoutConstraint.activate([
            proofreadButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            proofreadButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            textView.topAnchor.constraint(equalTo: proofreadButton.bottomAnchor, constant: 20),
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
        
        textView.delegate = self
        textView.text = "This is a sentence with a grammer error. And a spelling mistake. It also has some stylistic issues, like using 'thing' instead of a more precise word. Lets see how good the proofreader is."
    }
    
    @objc private func proofreadDocument() {
        guard !textView.text.isEmpty else {
            print("Document is empty, nothing to proofread.")
            return
        }
        
        // Clear previous highlights and suggestions
        clearProofreadingHighlights()
        
        Task {
            await performProofreading(documentText: textView.text)
        }
    }
    
    private func clearProofreadingHighlights() {
        let fullRange = NSRange(location: 0, length: textView.text.count)
        let mutableAttributedString = NSMutableAttributedString(attributedString: textView.attributedText)
        mutableAttributedString.removeAttribute(.underlineStyle, range: fullRange)
        mutableAttributedString.removeAttribute(.backgroundColor, range: fullRange)
        mutableAttributedString.removeAttribute(Self.proofreadingSuggestionAttributeName, range: fullRange)
        textView.attributedText = mutableAttributedString
        currentProofreadingSuggestions.removeAll()
    }
    
    private func performProofreading(documentText: String) async {
        DispatchQueue.main.async {
            self.proofreadButton.isEnabled = false
            self.proofreadButton.setTitle("Proofreading...", for: .normal)
            // Optionally, show activity indicator
        }
        
        let request = WritingToolsRequest.ProofreadRequest(text: documentText)
        
        do {
            let result = try await WritingToolsService.shared.proofreadRequest(for: request)
            
            DispatchQueue.main.async {
                self.applyProofreadingHighlights(result.proofread.suggestions)
                self.proofreadButton.isEnabled = true
                self.proofreadButton.setTitle("Proofread Document", for: .normal)
                // Optionally, hide activity indicator
            }
        } catch {
            DispatchQueue.main.async {
                print("Error proofreading document: \(error.localizedDescription)")
                self.proofreadButton.isEnabled = true
                self.proofreadButton.setTitle("Proofread Document", for: .normal)
                // Optionally, show error alert
            }
        }
    }
    
    private func applyProofreadingHighlights(_ suggestions: [WritingToolsResult.ProofreadResult.Suggestion]) {
        let mutableAttributedString = NSMutableAttributedString(attributedString: textView.attributedText)
        
        for suggestion in suggestions {
            if let firstReplacement = suggestion.replacements.first {
                print("Issue: '\(mutableAttributedString.attributedSubstring(from: suggestion.range).string)' -> Suggestion: '\(firstReplacement)'")
            }
            
            // Apply highlighting attributes
            mutableAttributedString.addAttributes([
                .underlineStyle: NSUnderlineStyle.single.rawValue,
                .underlineColor: UIColor.systemRed,
                .backgroundColor: UIColor.systemRed.withAlphaComponent(0.1),
                Self.proofreadingSuggestionAttributeName: suggestion.replacements // Store replacements
            ], range: suggestion.range)
            
            // Store mapping for easy lookup on tap
            currentProofreadingSuggestions[suggestion.range] = suggestion.replacements
        }
        
        textView.attributedText = mutableAttributedString
    }
    
    // MARK: - UITextViewDelegate for Tap Detection
    
    // Using `shouldInteractWith` to detect taps on attributed text
    func textView(_ textView: UITextView, shouldInteractWith textAttachment: NSTextAttachment, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        return true // Allow default interaction for attachments
    }
    
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        return true // Allow default interaction for URLs
    }
    
    // This is the key method for detecting taps on custom attributed ranges
    func textView(_ textView: UITextView, shouldInteractWith text: String, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        if interaction == .invokeDefaultAction {
            // Check if the tapped range has our custom attribute
            let attributes = textView.attributedText.attributes(at: characterRange.location, effectiveRange: nil)
            if let replacements = attributes[Self.proofreadingSuggestionAttributeName] as? [String], !replacements.isEmpty {
                presentProofreadingPopover(for: characterRange, with: replacements)
                return false // We've handled the interaction
            }
        }
        return true // Allow default interaction for other text
    }
    
    private func presentProofreadingPopover(for range: NSRange, with replacements: [String]) {
        let suggestionVC = ProofreadingSuggestionViewController(suggestions: replacements) { [weak self] selectedReplacement in
            guard let self = self else { return }
            self.applyProofreadingCorrection(at: range, with: selectedReplacement)
        }
        
        suggestionVC.modalPresentationStyle = .popover
        suggestionVC.popoverPresentationController?.delegate = self
        
        // Calculate the rect in the text view for the popover anchor
        let startPosition = textView.beginningOfDocument
        let start = textView.position(from: startPosition, offset: range.location)!
        let end = textView.position(from: startPosition, offset: range.location + range.length)!
        let textRange = textView.textRange(from: start, to: end)!
        let rect = textView.firstRect(for: textRange)
        
        suggestionVC.popoverPresentationController?.sourceView = textView
        suggestionVC.popoverPresentationController?.sourceRect = rect
        suggestionVC.popoverPresentationController?.permittedArrowDirections = [.up, .down]
        
        present(suggestionVC, animated: true, completion: nil)
    }
    
    private func applyProofreadingCorrection(at originalRange: NSRange, with replacement: String) {
        let mutableAttributedString = NSMutableAttributedString(attributedString: textView.attributedText)
        mutableAttributedString.replaceCharacters(in: originalRange, with: replacement)
        
        // Remove highlighting attributes from the corrected range
        mutableAttributedString.removeAttribute(.underlineStyle, range: NSRange(location: originalRange.location, length: replacement.count))
        mutableAttributedString.removeAttribute(.underlineColor, range: NSRange(location: originalRange.location, length: replacement.count))
        mutableAttributedString.removeAttribute(.backgroundColor, range: NSRange(location: originalRange.location, length: replacement.count))
        mutableAttributedString.removeAttribute(Self.proofreadingSuggestionAttributeName, range: NSRange(location: originalRange.location, length: replacement.count))
        
        textView.attributedText = mutableAttributedString
        
        // After modification, it's often best to re-run proofreading if the document structure
        // or other issues might have shifted, or to update the `currentProofreadingSuggestions` map.
        // For simplicity in this example, we're not re-running, but in a real app,
        // you'd likely adjust other ranges or re-evaluate.
        currentProofreadingSuggestions.removeValue(forKey: originalRange) // Remove the specific suggestion
    }
    
    // MARK: - UIPopoverPresentationControllerDelegate
    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return .none // Ensures popover on iPhone too
    }
    
    // Ensure the view controller is available for iOS 18+
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        guard #available(iOS 18.0, *) else { return nil }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        guard #available(iOS 18.0, *) else { return }
    }
}
