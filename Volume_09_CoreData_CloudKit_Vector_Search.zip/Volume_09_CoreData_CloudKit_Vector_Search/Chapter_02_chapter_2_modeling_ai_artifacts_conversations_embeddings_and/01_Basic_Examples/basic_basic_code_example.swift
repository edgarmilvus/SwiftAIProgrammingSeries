
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation
import CoreData
import Accelerate // Used for high-performance vector math

// MARK: - Models

/// Represents the role of a participant in a conversation.
/// Conforming to `Codable` and `Sendable` for safe transfer across actor boundaries.
enum ChatRole: String, Codable, Sendable {
    case user
    case assistant
    case system
}

/// A high-level representation of an AI-generated embedding.
/// In a real-world app, this would be stored in Core Data as a 'Binary Data' attribute.
struct SemanticEmbedding: Sendable {
    /// The raw vector data. We use `Data` to store the float array efficiently.
    let vector: Data
    /// The dimensionality of the vector (e.g., 1536 for OpenAI's text-embedding-3-small).
    let dimensions: Int
    /// Tracks which model produced this vector to ensure compatibility during search.
    let modelIdentifier: String
    
    /// Converts the raw Data back into an array of Floats for mathematical operations.
    func toFloatArray() -> [Float] {
        return vector.withUnsafeBytes { buffer in
            Array(buffer.bindMemory(to: Float.self))
        }
    }
}

/// The primary domain model for a chat message.
/// This serves as the bridge between the UI and the Persistence layer.
struct ChatMessage: Identifiable, Sendable {
    let id: UUID
    let text: String
    let role: ChatRole
    let timestamp: Date
    let embedding: SemanticEmbedding?
}

// MARK: - AI Engine

/// An Actor responsible for the computationally expensive task of generating embeddings.
/// Using an `actor` ensures that multiple requests to the AI model are serialized 
/// and do not overwhelm the system's neural engine or GPU.
@available(iOS 18.0, *)
actor EmbeddingEngine {
    
    /// A unique identifier for the current embedding model.
    private let modelID = "com.apple.semantic-engine.v1"
    
    /// Generates a semantic embedding for a given string.
    /// - Parameter text: The raw text to be vectorized.
    /// - Returns: A `SemanticEmbedding` containing the high-dimensional vector.
    /// - Note: In a real implementation, this would call `NaturalLanguage` framework 
    ///   or a remote LLM API.
    func generateEmbedding(for text: String) async throws -> SemanticEmbedding {
        // Simulate network or local ML model latency
        try await Task.sleep(for: .seconds(0.5))
        
        // MOCK LOGIC: Creating a deterministic "fake" vector for demonstration.
        // In production, this is where the heavy math happens.
        let mockDimensions = 384
        var mockVector = [Float](repeating: 0.0, count: mockDimensions)
        
        // Fill with dummy data based on text hash to simulate "meaning"
        let hash = text.hashValue
        for i in 0..<mockDimensions {
            mockVector[i] = Float(abs(hash + i) % 100) / 100.0
        }
        
        // Convert [Float] to Data for storage
        let data = mockVector.withUnsafeBytes { Data($0) }
        
        return SemanticEmbedding(
            vector: data,
            dimensions: mockDimensions,
            modelIdentifier: modelID
        )
    }
}

// MARK: - Persistence Layer

/// A thread-safe manager for Core Data operations.
/// We use a `ModelActor` pattern (introduced in recent Swift versions) 
/// to isolate Core Data's `NSManagedObjectContext` to a specific background actor.
@available(iOS 18.0, *)
@globalActor
actor DataPersistenceActor {
    static let shared = DataPersistenceActor()
    
    let container: NSPersistentCloudKitContainer
    
    private init() {
        // In a real app, this would load your .xcdatamodeld file.
        container = NSPersistentCloudKitContainer(name: "AIChatModel")
        
        // Configure the container for CloudKit sync
        guard let description = container.persistentStoreDescriptions.first else {
            fatalError("Failed to retrieve persistent store description.")
        }
        description.setOption(true as NSNumber, forKey: NSPersistentHistoryTrackingKey)
        description.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)
        
        container.loadPersistentStores { _, error in
            if let error = error {
                print("Core Data failed to load: \(error.localizedDescription)")
            }
        }
        
        container.viewContext.automaticallyMergesChangesFromParent = true
    }
    
    /// Saves a new message and its embedding to the persistent store.
    /// - Parameters:
    ///   - message: The domain model message.
    ///   - context: The background context to perform the write.
    func saveMessage(_ message: ChatMessage) async throws {
        let context = container.newBackgroundContext()
        
        // Perform the write on the background context
        try await context.perform {
            // Here, you would map the `ChatMessage` struct to your `NSManagedObject`
            // For this example, we simulate the logic of creating a managed object.
            print("💾 Persisting message: '\(message.text)' with embedding size: \(message.embedding?.vector.count ?? 0) bytes")
            
            // In a real app:
            // let entity = MessageEntity(context: context)
            // entity.text = message.text
            // entity.embeddingData = message.embedding?.vector
            
            try context.save()
        }
    }
}

// MARK: - Orchestration (The ViewModel)

/// The ViewModel that coordinates the UI, the AI Engine, and the Persistence layer.
/// Marked with `@MainActor` to ensure all updates to the UI-bound properties 
/// happen on the main thread.
@available(iOS 18.0, *)
@MainActor
class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var isProcessing: Bool = false
    
    private let engine = EmbeddingEngine()
    private let persistence = DataPersistenceActor.shared
    
    /// Sends a new user message, generates its embedding, and saves it.
    /// - Parameter text: The user's input string.
    func sendMessage(_ text: String) async {
        isProcessing = true
        
        // 1. Create the initial message object (Symbolic)
        let newMessage = ChatMessage(
            id: UUID(),
            text: text,
            role: .user,
            timestamp: Date(),
            embedding: nil
        )
        
        // Update UI immediately for responsiveness
        messages.append(newMessage)
        
        do {
            // 2. Generate the Semantic Artifact (The Embedding)
            // This happens on the EmbeddingEngine actor, off the main thread.
            let embedding = try await engine.generateEmbedding(for: text)
            
            // 3. Create the enriched message
            let enrichedMessage = ChatMessage(
                id: newMessage.id,
                text: text,
                role: .user,
                timestamp: newMessage.timestamp,
                embedding: embedding
            )
            
            // 4. Update the local UI state
            if let index = messages.firstIndex(where: { $0.id == newMessage.id }) {
                messages[index] = enrichedMessage
            }
            
            // 5. Persist to Core Data
            // This happens on the DataPersistenceActor, off the main thread.
            try await persistence.saveMessage(enrichedMessage)
            
        } catch {
            print("❌ Error in AI pipeline: \(error)")
        }
        
        isProcessing = false
    }
}
