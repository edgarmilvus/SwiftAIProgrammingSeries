
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI
import AVFoundation
import CoreML
import Combine

// Assume SecurityEventClassifier.mlmodel is added to the project.
// This model should have "GlassBreak", "AlarmSiren", and "BackgroundNoise" classes.
// Input format: MLMultiArray of shape [1, 16000] (1 second @ 16kHz, mono, Float32).

// MARK: - Core ML Model Wrapper

struct SecurityEventClassifierInput {
    let input: MLMultiArray
}

struct SecurityEventClassifierOutput {
    let label: String
    let labelProbability: [String : Double]
}

final class SecurityEventClassifierModel {
    private let model: SecurityEventClassifier
    let modelInputLength: Int = 16000 // e.g., 1 second * 16000 samples/sec
    let expectedSampleRate: Double = 16000.0

    init() throws {
        let configuration = MLModelConfiguration()
        self.model = try SecurityEventClassifier(configuration: configuration)
    }

    func predict(input: SecurityEventClassifierInput) throws -> SecurityEventClassifierOutput {
        let prediction = try model.prediction(input: input.input)
        return SecurityEventClassifierOutput(label: prediction.label, labelProbability: prediction.labelProbability)
    }
    
    var audioFormat: AVAudioFormat {
        return AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: expectedSampleRate, channels: 1, interleaved: false)!
    }
}

// MARK: - Event Tracking & State Management

enum SecurityAlertState {
    case monitoring
    case glassBreakDetected(timestamp: Date)
    case highPriorityAlert(glassBreakTime: Date, sirenTime: Date)
}

struct SecurityEventLog: Identifiable {
    let id = UUID()
    let timestamp: Date
    let event: String
    let confidence: Double
    let isHighPriority: Bool
}

class SmartHomeSecurityMonitor: ObservableObject {
    @Published var alertState: SecurityAlertState = .monitoring
    @Published var eventLog: [SecurityEventLog] = []
    @Published var permissionGranted: Bool = false
    @Published var isMonitoring: Bool = false
    @Published var errorMessage: String?

    private let audioEngine = AVAudioEngine()
    private var classifier: SecurityEventClassifierModel?
    private let audioProcessingQueue = DispatchQueue(label: "com.example.securityAudioProcessing", qos: .userInitiated)
    
    private let glassBreakWindow: TimeInterval = 15.0 // 15 seconds for alarm siren
    private var glassBreakTimer: Timer? // Timer to clear glassBreakDetected state
    private var lastGlassBreakTimestamp: Date? // Tracks the last confirmed glass break
    
    private let detectionConfidenceThreshold: Double = 0.7 // Minimum confidence to log/trigger
    
    // Buffer to accumulate audio for classification (1 second chunks)
    private var audioBuffer: AVAudioPCMBuffer?
    private let bufferCapacity: AVAudioFrameCount

    init() {
        do {
            classifier = try SecurityEventClassifierModel()
            bufferCapacity = AVAudioFrameCount(classifier!.modelInputLength)
            audioBuffer = AVAudioPCMBuffer(pcmFormat: classifier!.audioFormat, frameCapacity: bufferCapacity)
            audioBuffer?.frameLength = 0
        } catch {
            errorMessage = "Failed to load ML model: \(error.localizedDescription)"
            print("Error loading model: \(error)")
        }
    }
    
    deinit {
        stopMonitoring()
        glassBreakTimer?.invalidate()
    }

    func requestMicrophonePermission() async {
        let status = AVCaptureDevice.authorizationStatus(for: .audio)
        switch status {
        case .authorized:
            permissionGranted = true
        case .notDetermined:
            await AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                DispatchQueue.main.async {
                    self?.permissionGranted = granted
                    if !granted {
                        self?.errorMessage = "Microphone permission denied. Please enable it in Settings."
                    }
                }
            }
        case .denied, .restricted:
            permissionGranted = false
            errorMessage = "Microphone permission denied. Please enable it in Settings."
        @unknown default:
            permissionGranted = false
            errorMessage = "Unknown microphone permission status."
        }
    }

    func startMonitoring() {
        guard permissionGranted, classifier != nil else {
            errorMessage = "Microphone permission not granted or model not loaded."
            return
        }

        let inputNode = audioEngine.inputNode
        let bus = 0
        let inputFormat = inputNode.inputFormat(forBus: bus)
        let outputFormat = classifier!.audioFormat

        if inputFormat.sampleRate != outputFormat.sampleRate || inputFormat.channelCount != outputFormat.channelCount {
            audioEngine.attach(AVAudioMixerNode())
            let mixer = audioEngine.mainMixerNode
            audioEngine.connect(inputNode, to: mixer, format: inputFormat)
            audioEngine.connect(mixer, to: audioEngine.outputNode, format: outputFormat)
            
            inputNode.installTap(onBus: bus, bufferSize: AVAudioFrameCount(outputFormat.sampleRate), format: outputFormat) { [weak self] buffer, time in
                self?.processAudioBuffer(buffer: buffer)
            }
        } else {
            inputNode.installTap(onBus: bus, bufferSize: AVAudioFrameCount(inputFormat.sampleRate), format: inputFormat) { [weak self] buffer, time in
                self?.processAudioBuffer(buffer: buffer)
            }
        }

        audioEngine.prepare()
        do {
            try audioEngine.start()
            isMonitoring = true
            errorMessage = nil
            resetState() // Clear previous state and logs
        } catch {
            errorMessage = "Error starting audio engine: \(error.localizedDescription)"
            print("Error starting audio engine: \(error)")
        }
    }

    func stopMonitoring() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        isMonitoring = false
        resetState()
    }
    
    private func resetState() {
        DispatchQueue.main.async {
            self.alertState = .monitoring
            self.eventLog = []
            self.lastGlassBreakTimestamp = nil
            self.glassBreakTimer?.invalidate()
            self.glassBreakTimer = nil
        }
    }

    private func processAudioBuffer(buffer: AVAudioPCMBuffer) {
        audioProcessingQueue.async { [weak self] in
            guard let self = self, let classifier = self.classifier else { return }

            self.audioBuffer?.append(buffer, startingFrame: 0, frameCount: buffer.frameLength)

            if let currentBuffer = self.audioBuffer, currentBuffer.frameLength >= self.bufferCapacity {
                guard let multiArray = currentBuffer.toMLMultiArray(
                    modelInputLength: classifier.modelInputLength,
                    targetSampleRate: classifier.expectedSampleRate
                ) else {
                    print("Failed to convert buffer to MLMultiArray.")
                    currentBuffer.frameLength = 0
                    return
                }

                do {
                    let prediction = try classifier.predict(input: SecurityEventClassifierInput(input: multiArray))
                    
                    // Only process predictions above a certain confidence and not background noise
                    guard prediction.label != "BackgroundNoise",
                          let confidence = prediction.labelProbability[prediction.label],
                          confidence >= self.detectionConfidenceThreshold else {
                        currentBuffer.frameLength = 0
                        return
                    }
                    
                    let detectedEvent = prediction.label
                    let currentDetectionTime = Date()

                    DispatchQueue.main.async {
                        // Log individual event (low priority)
                        self.eventLog.insert(SecurityEventLog(timestamp: currentDetectionTime, event: detectedEvent, confidence: confidence, isHighPriority: false), at: 0)
                        if self.eventLog.count > 50 { self.eventLog.removeLast() } // Keep log manageable

                        switch detectedEvent {
                        case "GlassBreak":
                            self.lastGlassBreakTimestamp = currentDetectionTime
                            self.alertState = .glassBreakDetected(timestamp: currentDetectionTime)
                            self.startGlassBreakTimer()
                            print("GlassBreak detected at \(currentDetectionTime)")
                            
                        case "AlarmSiren":
                            if let gbTime = self.lastGlassBreakTimestamp,
                               currentDetectionTime.timeIntervalSince(gbTime) <= self.glassBreakWindow {
                                // High-priority alert: Glass Break followed by Alarm Siren within window
                                self.alertState = .highPriorityAlert(glassBreakTime: gbTime, sirenTime: currentDetectionTime)
                                self.glassBreakTimer?.invalidate() // Stop the timer, high alert is active
                                self.glassBreakTimer = nil
                                self.lastGlassBreakTimestamp = nil // Clear state for next sequence
                                print("HIGH PRIORITY ALERT: Glass Break followed by Alarm Siren!")
                                
                                // Update log entry to high priority
                                if let index = self.eventLog.firstIndex(where: { $0.event == "AlarmSiren" && !$0.isHighPriority }) {
                                    self.eventLog[index] = SecurityEventLog(timestamp: currentDetectionTime, event: detectedEvent, confidence: confidence, isHighPriority: true)
                                }
                            } else {
                                // Alarm Siren detected, but no recent glass break or outside window
                                print("AlarmSiren detected (standalone) at \(currentDetectionTime)")
                            }
                        default:
                            break // Other detected sounds, if any
                        }
                    }
                } catch {
                    print("Error during prediction: \(error)")
                }
                
                currentBuffer.frameLength = 0
            }
        }
    }
    
    private func startGlassBreakTimer() {
        glassBreakTimer?.invalidate() // Invalidate any existing timer
        glassBreakTimer = Timer.scheduledTimer(withTimeInterval: glassBreakWindow, repeats: false) { [weak self] _ in
            DispatchQueue.main.async {
                guard let self = self else { return }
                if case .glassBreakDetected = self.alertState {
                    // If no siren detected within the window, revert to monitoring
                    self.alertState = .monitoring
                    self.lastGlassBreakTimestamp = nil
                    print("Glass break window expired, reverting to monitoring.")
                }
                self.glassBreakTimer = nil
            }
        }
        RunLoop.main.add(glassBreakTimer!, forMode: .common)
    }
}

// MARK: - Helper Extension for AVAudioPCMBuffer to MLMultiArray Conversion (Same as previous exercises)
extension AVAudioPCMBuffer {
    func toMLMultiArray(modelInputLength: Int, targetSampleRate: Double) -> MLMultiArray? {
        guard let floatChannelData = floatChannelData else { return nil }
        guard format.channelCount == 1 else { return nil }
        guard format.sampleRate == targetSampleRate else { return nil }

        let frameCount = Int(frameLength)
        guard frameCount >= modelInputLength else { return nil }

        do {
            let multiArray = try MLMultiArray(shape: [1, NSNumber(value: modelInputLength)], dataType: .float32)
            let bufferPointer = UnsafeMutableBufferPointer(start: floatChannelData[0], count: frameCount)

            for i in 0..<modelInputLength {
                multiArray[i] = NSNumber(value: bufferPointer[i])
            }
            return multiArray
        } catch {
            print("Failed to create MLMultiArray: \(error)")
            return nil
        }
    }
}


// MARK: - SwiftUI View

struct SmartHomeSecurityView: View {
    @StateObject private var monitor = SmartHomeSecurityMonitor()

    var body: some View {
        VStack {
            Text("Smart Home Security")
                .font(.largeTitle)
                .padding()

            if let errorMessage = monitor.errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }

            if monitor.permissionGranted {
                Text(monitor.isMonitoring ? "Monitoring Security Events..." : "Ready to Monitor")
                    .font(.headline)
                    .padding()

                Button(action: {
                    if monitor.isMonitoring {
                        monitor.stopMonitoring()
                    } else {
                        monitor.startMonitoring()
                    }
                }) {
                    Text(monitor.isMonitoring ? "Stop Monitoring" : "Start Monitoring")
                        .font(.title2)
                        .padding()
                        .background(monitor.isMonitoring ? Color.red : Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()

                Divider()

                VStack {
                    switch monitor.alertState {
                    case .monitoring:
                        Text("System Monitoring")
                            .font(.title)
                            .foregroundColor(.gray)
                    case .glassBreakDetected(let timestamp):
                        Text("Glass Break Detected!")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(.orange)
                        Text(timestamp, formatter: itemFormatter)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    case .highPriorityAlert(let gbTime, let sirenTime):
                        VStack {
                            Text("CRITICAL ALERT: INTRUSION!")
                                .font(.system(size: 40, weight: .heavy, design: .rounded))
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.red.opacity(0.8))
                                .cornerRadius(15)
                                .shadow(radius: 10)
                                .animation(.easeOut(duration: 0.2).repeatForever(autoreverses: true), value: monitor.alertState)
                            Text("Glass Break at \(gbTime, formatter: itemFormatter)")
                                .font(.headline)
                                .foregroundColor(.red)
                            Text("Alarm Siren at \(sirenTime, formatter: itemFormatter)")
                                .font(.headline)
                                .foregroundColor(.red)
                        }
                    }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(
                    Group {
                        if case .highPriorityAlert = monitor.alertState {
                            Color.red.opacity(0.2)
                        } else {
                            Color.clear
                        }
                    }
                )
                .cornerRadius(10)
                .animation(.easeInOut, value: monitor.alertState)

                Divider()

                Text("Event Log:")
                    .font(.title2)
                    .padding(.top)

                ScrollView {
                    LazyVStack(alignment: .leading) {
                        ForEach(monitor.eventLog) { logEntry in
                            HStack {
                                Text(logEntry.timestamp, formatter: itemFormatter)
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                Text(logEntry.event)
                                    .font(.body)
                                    .fontWeight(logEntry.isHighPriority ? .bold : .medium)
                                    .foregroundColor(logEntry.isHighPriority ? .red : .primary)
                                Text(String(format: "(%.1f%%)", logEntry.confidence * 100))
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                Spacer()
                            }
                            .padding(.vertical, 2)
                            .background(logEntry.isHighPriority ? Color.red.opacity(0.1) : Color.clear)
                            .cornerRadius(5)
                        }
                    }
                    .padding(.horizontal)
                }
            } else {
                Text("Microphone access is required for smart home security monitoring.")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding()
                Button("Request Microphone Access") {
                    Task {
                        await monitor.requestMicrophonePermission()
                    }
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
        }
        .onAppear {
            Task {
                await monitor.requestMicrophonePermission()
            }
        }
        .padding()
    }

    private let itemFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.timeStyle = .medium
        return formatter
    }()
}

// MARK: - App Entry Point (for iOS)
/*
@main
struct SmartHomeSecurityApp: App {
    var body: some Scene {
        WindowGroup {
            SmartHomeSecurityView()
        }
    }
}
*/
