
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import NaturalLanguage
import UIKit

// Ensure iOS 18.0 availability for NLWritingTool
@available(iOS 18.0, *)
class SwiftNotesEditorViewController: UIViewController, UITextViewDelegate {

    let editorTextView = UITextView()
    private let writingTool = NLWritingTool()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupEditor()
        editorTextView.delegate = self
        editorTextView.text = "This is a sample note for testing. We need to make it more formal for a report. It's also quite informal, so we might want to change that. Let's summarize this point for a colleague quickly. And finally, we should elaborate on the main idea here."
    }

    private func setupEditor() {
        editorTextView.translatesAutoresizingMaskIntoConstraints = false
        editorTextView.font = UIFont.preferredFont(forTextStyle: .body)
        editorTextView.layer.borderColor = UIColor.lightGray.cgColor
        editorTextView.layer.borderWidth = 0.5
        editorTextView.layer.cornerRadius = 5
        editorTextView.textContainerInset = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        view.addSubview(editorTextView)

        NSLayoutConstraint.activate([
            editorTextView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            editorTextView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            editorTextView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            editorTextView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }

    // MARK: - UITextViewDelegate

    func textViewDidChangeSelection(_ textView: UITextView) {
        // Invalidate the menu to rebuild it with relevant options based on selection
        UIMenuController.shared.hideMenu() // Hide existing menu
        textView.resignFirstResponder() // Resign to ensure menu is rebuilt
        textView.becomeFirstResponder() // Become first responder again
    }

    // MARK: - Custom Menu Integration (iOS 13+ way)

    override func buildMenu(with builder: UIMenuBuilder) {
        super.buildMenu(with: builder)

        // Only add custom menus to the editing menu
        guard builder.menu.identifier == UIMenu.Identifier.init("com.apple.UIKit.EditMenu") else { return }

        guard let selectedTextRange = editorTextView.selectedTextRange,
              !selectedTextRange.isEmpty,
              let selectedText = editorTextView.text(in: selectedTextRange) else {
            return // No selection, no custom menu
        }

        // Basic paragraph detection: Check if selection includes at least one full line break
        let nsSelectedRange = NSRange(selectedTextRange, in: editorTextView.textStorage.string)
        let textString = editorTextView.textStorage.string
        let containsNewline = textString[nsSelectedRange.location..<nsSelectedRange.upperBound].contains("\n")

        // For simplicity, we'll consider any non-empty selection eligible for tone adjustment.
        // A more robust solution might check for paragraph boundaries using NLTokenizer.
        guard !selectedText.isEmpty else { return }

        let formalAction = UIAction(title: "Make More Formal") { [weak self] _ in
            self?.performToneAdjustment(for: selectedText, adjustmentType: .makeMoreFormal, range: selectedTextRange)
        }
        let casualAction = UIAction(title: "Make More Casual") { [weak self] _ in
            self?.performToneAdjustment(for: selectedText, adjustmentType: .makeMoreCasual, range: selectedTextRange)
        }
        let summarizeAction = UIAction(title: "Summarize for Colleague") { [weak self] _ in
            self?.performToneAdjustment(for: selectedText, adjustmentType: .summarizeForColleague, range: selectedTextRange)
        }
        let elaborateAction = UIAction(title: "Elaborate on this Point") { [weak self] _ in
            self?.performToneAdjustment(for: selectedText, adjustmentType: .elaborateOnPoint, range: selectedTextRange)
        }

        let toneAdjustmentMenu = UIMenu(title: "Adjust Tone", children: [formalAction, casualAction, summarizeAction, elaborateAction])

        // Insert the custom menu after the 'Cut'/'Copy' options
        builder.insertSibling(toneAdjustmentMenu, afterMenu: .cut)
    }

    // MARK: - Tone Adjustment Logic

    enum AdjustmentType {
        case makeMoreFormal
        case makeMoreCasual
        case summarizeForColleague
        case elaborateOnPoint
    }

    private func performToneAdjustment(for selectedText: String, adjustmentType: AdjustmentType, range: UITextRange) {
        // Show a loading indicator
        let activityIndicator = UIActivityIndicatorView(style: .medium)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(activityIndicator)
        NSLayoutConstraint.activate([
            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
        activityIndicator.startAnimating()
        editorTextView.isUserInteractionEnabled = false // Disable interaction during processing

        Task { @MainActor in
            do {
                var options = NLWritingTool.Options()
                let prompt: String
                let revisedText: String

                switch adjustmentType {
                case .makeMoreFormal:
                    prompt = "Rewrite the following text to have a more formal and professional tone, suitable for a formal document or presentation. Maintain the original meaning."
                    revisedText = try await writingTool.rewrite(selectedText, options: options, prompt: prompt)
                case .makeMoreCasual:
                    prompt = "Rewrite the following text to have a more casual and friendly tone, as if speaking to a friend or close colleague. Maintain the original meaning."
                    revisedText = try await writingTool.rewrite(selectedText, options: options, prompt: prompt)
                case .summarizeForColleague:
                    prompt = "Summarize the following paragraph concisely, highlighting only the key points relevant for a colleague who needs a quick overview. Keep it brief."
                    revisedText = try await writingTool.summarize(selectedText, options: options, prompt: prompt)
                case .elaborateOnPoint:
                    prompt = "Elaborate on the following text, providing more detail, examples, and context to expand on the main idea presented. Aim for clarity and thoroughness."
                    revisedText = try await writingTool.rewrite(selectedText, options: options, prompt: prompt)
                }

                // Hide loading indicator
                activityIndicator.stopAnimating()
                activityIndicator.removeFromSuperview()
                editorTextView.isUserInteractionEnabled = true // Re-enable interaction

                // Present 'revisedText' to the user for review and replacement.
                presentReviewAndApplySheet(original: selectedText, revised: revisedText, range: range)

            } catch {
                // Hide loading indicator
                activityIndicator.stopAnimating()
                activityIndicator.removeFromSuperview()
                editorTextView.isUserInteractionEnabled = true // Re-enable interaction

                print("Error adjusting tone: \(error.localizedDescription)")
                let alert = UIAlertController(title: "Tone Adjustment Error", message: error.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                present(alert, animated: true)
            }
        }
    }

    private func presentReviewAndApplySheet(original: String, revised: String, range: UITextRange) {
        let alert = UIAlertController(title: "Review Tone Adjustment", message: nil, preferredStyle: .actionSheet)

        // Custom view to display original and revised text side-by-side (or stacked)
        let customView = UIStackView()
        customView.axis = .vertical
        customView.spacing = 10
        customView.alignment = .leading
        customView.translatesAutoresizingMaskIntoConstraints = false

        let originalLabel = UILabel()
        originalLabel.numberOfLines = 0
        originalLabel.font = UIFont.systemFont(ofSize: 14)
        originalLabel.text = "Original:\n\(original)"
        originalLabel.textColor = .secondaryLabel

        let revisedLabel = UILabel()
        revisedLabel.numberOfLines = 0
        revisedLabel.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        revisedLabel.text = "Revised:\n\(revised)"

        customView.addArrangedSubview(originalLabel)
        customView.addArrangedSubview(revisedLabel)

        // Add custom view to alert controller
        alert.view.addSubview(customView)
        NSLayoutConstraint.activate([
            customView.topAnchor.constraint(equalTo: alert.view.topAnchor, constant: 60), // Adjust constant as needed
            customView.leadingAnchor.constraint(equalTo: alert.view.leadingAnchor, constant: 20),
            customView.trailingAnchor.constraint(equalTo: alert.view.trailingAnchor, constant: -20),
            customView.bottomAnchor.constraint(lessThanOrEqualTo: alert.view.bottomAnchor, constant: -120) // Give space for buttons
        ])
        
        // Adjust the height of the alert controller to fit the custom view
        let height: CGFloat = min(UIScreen.main.bounds.height * 0.7, customView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize).height + 150)
        alert.preferredContentSize = CGSize(width: alert.preferredContentSize.width, height: height)


        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Accept Changes", style: .default) { [weak self] _ in
            self?.editorTextView.replace(range, withText: revised)
            // Optionally, move cursor
            if let newStart = self?.editorTextView.position(from: range.start, offset: revised.utf16.count) {
                self?.editorTextView.selectedTextRange = self?.editorTextView.textRange(from: newStart, to: newStart)
            }
        })
        present(alert, animated: true)
    }
}
