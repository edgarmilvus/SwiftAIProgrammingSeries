
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import SwiftUI
import Vision
import ARKit
import RealityKit
import Combine

// MARK: - Models

/// Represents a single detected joint in 3D space.
/// This model bridges the gap between the Vision framework and RealityKit.
struct SpatialJoint {
    let name: String
    let position: SIMD3<Float> // Position in meters (World Space)
    let confidence: Float
}

/// A collection of joints forming a skeletal structure.
struct BodyPose3D {
    let joints: [String: SpatialJoint]
}

// MARK: - Pose Estimation Engine

/// `PoseEstimationEngine` is an actor responsible for the heavy lifting of 
/// running machine learning inference without blocking the Main thread.
/// By using an `actor`, we ensure thread-safety for our internal state.
@available(iOS 18.0, visionOS 2.0, *)
actor PoseEstimationEngine {
    
    /// The Vision request object used to detect human body poses.
    private let poseRequest = VNDetectHumanBodyPoseRequest()
    
    /// Performs pose estimation on a provided pixel buffer.
    /// - Parameter pixelBuffer: The raw image data from the ARKit camera.
    /// - Returns: A collection of 3D joints or nil if no human is detected.
    func estimatePose(from pixelBuffer: CVPixelBuffer, cameraTransform: simd_float4x4, intrinsics: simd_float3x3) async -> BodyPose3D? {
        
        // 1. Create a request handler for the current frame.
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
        
        do {
            // 2. Perform the Vision request synchronously within this actor's context.
            // This is safe because the actor is off the Main thread.
            try handler.perform([poseRequest])
            
            guard let observation = poseRequest.results?.first else {
                return nil
            }
            
            // 3. Extract landmarks and project them to 3D.
            return try await processObservations(observation, cameraTransform: cameraTransform, intrinsics: intrinsics)
            
        } catch {
            print("Vision Error: \(error.localizedDescription)")
            return nil
        }
    }
    
    /// Maps 2D Vision points to 3D World coordinates.
    private func processObservations(_ observation: VNHumanBodyPoseObservation, 
                                     cameraTransform: simd_float4x4, 
                                     intrinsics: simd_float3x3) async throws -> BodyPose3D {
        
        var detectedJoints: [String: SpatialJoint] = [:]
        
        // We iterate through all recognized landmarks (elbow, knee, etc.)
        let allPoints = try observation.recognizedPoints(.all)
        
        for (key, point) in allPoints {
            // Only process points with high confidence to avoid "jittery" 3D models.
            guard point.confidence > 0.5 else { continue }
            
            // 4. Convert Normalized 2D Point -> 3D Ray in Camera Space.
            // Vision uses normalized coordinates (0 to 1) where (0,0) is bottom-left.
            let cameraSpacePoint = projectToCameraSpace(point: point, intrinsics: intrinsics)
            
            // 5. Convert Camera Space Point -> World Space Point.
            // We multiply the camera-space vector by the inverse of the camera's transform.
            let worldSpacePoint = transformToWorldSpace(cameraPoint: cameraSpacePoint, cameraTransform: cameraTransform)
            
            detectedJoints[key.rawValue] = SpatialJoint(
                name: key.rawValue,
                position: worldSpacePoint,
                confidence: point.confidence
            )
        }
        
        return BodyPose3D(joints: detectedJoints)
    }
    
    /// Uses camera intrinsics to project a 2D point into a 3D ray.
    /// This is the "Unprojection" step.
    private func projectToCameraSpace(point: VNRecognizedPoint, intrinsics: simd_float3x3) -> SIMD3<Float> {
        // Convert normalized Vision coordinates (0-1, bottom-left) 
        // to Image Plane coordinates (centered at 0,0).
        let x = Float(point.location.x) * 2.0 - 1.0
        let y = Float(point.location.y) * 2.0 - 1.0
        
        // In a real-world implementation, we would use the focal length (fx, fy)
        // from the intrinsic matrix to determine the depth.
        // For this basic example, we assume a depth 'z' of 1.0 meter to demonstrate the math.
        let z: Float = 1.0 
        
        // Simplified unprojection:
        // x_cam = (x_img - cx) / fx
        // y_cam = (y_img - cy) / fy
        // Here we use the intrinsics to scale the ray.
        let fx = intrinsics[0, 0]
        let fy = intrinsics[1, 1]
        
        return SIMD3<Float>(x * z * (1.0/fx), y * z * (1.0/fy), z)
    }
    
    /// Applies the camera's extrinsic matrix to move a point from the camera's local view to the world.
    private func transformToWorldSpace(cameraPoint: SIMD3<Float>, cameraTransform: simd_float4x4) -> SIMD3<Float> {
        // Convert SIMD3 to SIMD4 (homogeneous coordinates) for matrix multiplication.
        let point4 = SIMD4<Float>(cameraPoint.x, cameraPoint.y, cameraPoint.z, 1.0)
        
        // Multiply by the camera's world transform.
        let worldPoint4 = cameraTransform * point4
        
        // Convert back to SIMD3.
        return SIMD3<Float>(worldPoint4.x, worldPoint4.y, worldPoint4.z)
    }
}

// MARK: - RealityKit Coordinator

/// `PoseVisualizer` manages the 3D entities in the RealityKit scene.
/// It is marked with `@MainActor` because it directly manipulates the UI/Scene graph.
@MainActor
class PoseVisualizer: ObservableObject {
    
    /// The anchor that holds our 3D skeleton in the real world.
    var skeletonAnchor = AnchorEntity(world: .zero)
    
    /// A dictionary to keep track of existing joint entities to avoid redundant allocations.
    private var jointEntities: [String: ModelEntity] = [:]
    
    /// Updates the 3D scene with new joint positions.
    /// - Parameter pose: The latest 3D pose data.
    func updateScene(with pose: BodyPose3D) {
        for (name, joint) in pose.joints {
            if let entity = jointEntities[name] {
                // Smoothly move the existing joint to the new position.
                entity.position = joint.position
            } else {
                // Create a new sphere for a new joint.
                let mesh = MeshResource.generateSphere(radius: 0.02)
                let material = SimpleMaterial(color: .green, isMetallic: true)
                let newEntity = ModelEntity(mesh: mesh, materials: [material])
                
                newEntity.position = joint.position
                skeletonAnchor.addChild(newEntity)
                jointEntities[name] = newEntity
            }
        }
    }
    
    /// Clears the scene when the user stops the session.
    func clear() {
        skeletonAnchor.children.removeAll()
        jointEntities.removeAll()
    }
}

// MARK: - Main View

@available(iOS 18.0, visionOS 2.0, *)
struct SpatialPoseView: View {
    
    @StateObject private var visualizer = PoseVisualizer()
    private let engine = PoseEstimationEngine()
    
    // In a real app, these would be provided by an ARKit session delegate.
    @State private var lastCameraTransform = matrix_identity_float4x4
    @State private var lastIntrinsics = matrix_identity_float3x3
    
    var body: some View {
        ZStack {
            // The 3D RealityKit View
            RealityView { content in
                content.add(visualizer.skeletonAnchor)
            }
            .ignoresSafeArea()
            
            // UI Overlay
            VStack {
                Text("Spatial Pose Tracker")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Spacer()
                
                Text("Align your body in the frame")
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(10)
            }
            .padding()
        }
        .task {
            // Start the simulation loop.
            await runPoseDetectionLoop()
        }
    }
    
    /// The core simulation loop. In a real app, this would be triggered 
    /// by `session(_:didUpdate:)` from ARKit.
    private func runPoseDetectionLoop() async {
        // Mocking a continuous loop of camera frames.
        while true {
            // 1. Simulate receiving a pixel buffer and camera data.
            // In production, replace with actual ARFrame data.
            guard let mockBuffer = createMockPixelBuffer() else {
                try? await Task.sleep(for: .milliseconds(16))
                continue
            }
            
            // 2. Run the heavy ML inference on the Actor.
            if let pose3D = await engine.estimatePose(
                from: mockBuffer,
                cameraTransform: lastCameraTransform,
                intrinsics: lastIntrinsics
            ) {
                // 3. Update the 3D scene on the Main Actor.
                await MainActor.run {
                    visualizer.updateScene(with: pose3D)
                }
            }
            
            // 4. Maintain ~60 FPS.
            try? await Task.sleep(for: .milliseconds(16))
        }
    }
    
    /// Helper to simulate camera data for compilation purposes.
    private func createMockPixelBuffer() -> CVPixelBuffer? {
        var pixelBuffer: CVPixelBuffer?
        let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
                     kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
        CVPixelBufferCreate(kCFAllocatorDefault, 640, 480, kCVPixelFormatType_32BGRA, attrs, &pixelBuffer)
        return pixelBuffer
    }
}
