
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application.swift
// Description: Advanced Application
// ==========================================

// Package.swift snippet for demonstrating Swift Package Manager dependencies
// In a real-world scenario, you would include dependencies for interacting with local LLMs.

// swift-tools-version:6.0
import PackageDescription

let package = Package(
    name: "MeetingAssistantApp",
    platforms: [
        .iOS(.v18), // Targeting iOS 18+ for latest concurrency features and APIs
        .macOS(.v15) // Targeting macOS 15+
    ],
    products: [
        .library(
            name: "MeetingAssistantCore",
            targets: ["MeetingAssistantCore"]),
    ],
    dependencies: [
        // Hypothetical dependency for interacting with Ollama or llama.cpp Swift bindings
        // In a real project, this would be crucial for sending prompts and receiving raw LLM output.
        // .package(url: "https://github.com/ollama-kit/OllamaKit.git", from: "1.0.0"),
        // .package(url: "https://github.com/ggerganov/llama.cpp.swift", from: "0.1.0"),
    ],
    targets: [
        .target(
            name: "MeetingAssistantCore",
            dependencies: [
                // If OllamaKit or llama.cpp.swift were used, they would be listed here:
                // .product(name: "OllamaKit", package: "OllamaKit"),
                // .product(name: "LlamaCpp", package: "llama.cpp.swift"),
            ]),
        .testTarget(
            name: "MeetingAssistantCoreTests",
            dependencies: ["MeetingAssistantCore"]),
    ]
)
