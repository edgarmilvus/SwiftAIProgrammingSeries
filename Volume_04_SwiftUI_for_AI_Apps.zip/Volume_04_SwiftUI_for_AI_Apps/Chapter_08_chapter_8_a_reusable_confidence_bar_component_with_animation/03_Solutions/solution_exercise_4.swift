
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import SwiftUI

// MARK: - Prediction Data Structure

struct Prediction: Identifiable {
    let id = UUID() // Unique ID for Identifiable conformance
    let label: String
    let confidence: Double // Value between 0.0 and 1.0
}

// MARK: - Reusable ConfidenceBar (adapted for this exercise)

struct ConfidenceBar: View {
    let confidence: Double
    let baseColor: Color // Default color for the bar
    let warningColor: Color // Color when prediction is below threshold
    let isWarning: Bool
    let isHighest: Bool
    let height: CGFloat = 20
    let cornerRadius: CGFloat = 8

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                // Background of the bar
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: height)

                // Filled portion of the bar
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(isWarning ? warningColor : baseColor) // Conditional color
                    .frame(width: geometry.size.width * CGFloat(confidence), height: height)
                    .animation(.easeInOut(duration: 0.5), value: confidence)
            }
            .overlay(
                // Optional border for highlighting the highest confidence
                RoundedRectangle(cornerRadius: cornerRadius)
                    .stroke(isHighest ? .blue : .clear, lineWidth: isHighest ? 3 : 0)
                    .animation(.easeInOut(duration: 0.3), value: isHighest)
            )
        }
        .frame(height: height)
    }
}

// MARK: - MultiConfidenceView Component

struct MultiConfidenceView: View {
    let predictions: [Prediction]
    @State private var minimumConfidenceThreshold: Double = 0.6

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Image Classification Results")
                .font(.headline)
                .padding(.bottom, 5)

            // Threshold Slider
            HStack {
                Text("Threshold: \(String(format: "%.0f%%", minimumConfidenceThreshold * 100))")
                    .font(.caption)
                    .frame(width: 100, alignment: .leading)
                Slider(value: $minimumConfidenceThreshold, in: 0.0...1.0, step: 0.05)
            }
            .padding(.horizontal)

            // Find the highest confidence prediction for highlighting
            let highestConfidencePrediction = predictions.max(by: { $0.confidence < $1.confidence })
            let sortedPredictions = predictions.sorted(by: { $0.confidence > $1.confidence }) // Optional: Sort by confidence

            ForEach(sortedPredictions) { prediction in
                HStack {
                    Text(prediction.label)
                        .font(.subheadline)
                        .frame(width: 80, alignment: .leading) // Fixed width for labels

                    // Determine if this prediction is the highest or below threshold
                    let isHighest = prediction.id == highestConfidencePrediction?.id
                    let isWarning = prediction.confidence < minimumConfidenceThreshold

                    ConfidenceBar(
                        confidence: prediction.confidence,
                        baseColor: .green, // Default success color
                        warningColor: .orange, // Warning color
                        isWarning: isWarning,
                        isHighest: isHighest
                    )
                    // Add a small warning icon if below threshold
                    if isWarning {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundColor(.orange)
                            .font(.caption)
                    }
                    Text(String(format: "%.0f%%", prediction.confidence * 100))
                        .font(.caption)
                        .frame(width: 40, alignment: .trailing)
                }
            }
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 15).fill(Color.white).shadow(radius: 5))
    }
}

// MARK: - ContentView Integration (Simulating Multi-Class Predictions)

struct ContentView: View {
    @State private var predictions: [Prediction] = []

    var body: some View {
        VStack(spacing: 30) {
            Text("Image Classifier Dashboard")
                .font(.title)
                .fontWeight(.bold)

            if predictions.isEmpty {
                Text("Tap 'Generate Predictions' to start.")
                    .foregroundColor(.secondary)
            } else {
                MultiConfidenceView(predictions: predictions)
                    .frame(maxWidth: .infinity) // Allow MultiConfidenceView to expand
            }

            Button("Generate New Predictions") {
                generateRandomPredictions()
            }
            .buttonStyle(.borderedProminent)
            .tint(.teal)
        }
        .padding()
        .onAppear(perform: generateRandomPredictions) // Generate initial predictions on appear
    }

    private func generateRandomPredictions() {
        let classes = ["Cat", "Dog", "Bird", "Fox", "Fish", "Rabbit"]
        var newPredictions: [Prediction] = []
        let numberOfPredictions = Int.random(in: 3...5) // Random number of classes

        for _ in 0..<numberOfPredictions {
            let label = classes.randomElement() ?? "Unknown"
            let confidence = Double.random(in: 0.05...0.99)
            newPredictions.append(Prediction(label: label, confidence: confidence))
        }
        // Ensure unique labels if desired, or just allow duplicates for simplicity
        predictions = newPredictions.reduce(into: []) { (result, prediction) in
            if !result.contains(where: { $0.label == prediction.label }) {
                result.append(prediction)
            }
        }
    }
}

// MARK: - Preview Provider

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
