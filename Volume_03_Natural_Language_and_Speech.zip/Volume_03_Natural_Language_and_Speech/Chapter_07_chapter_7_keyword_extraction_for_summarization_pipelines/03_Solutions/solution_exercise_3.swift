
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import NaturalLanguage
import Foundation // For log function

@available(iOS 18.0, macOS 15.0, *)
class CorpusAnalyzer {
    private let stopWords: Set<String> = [
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
        "and", "or", "but", "for", "nor", "so", "yet",
        "in", "on", "at", "by", "with", "from", "of", "to", "into", "onto",
        "this", "that", "these", "those", "it", "its", "he", "him", "his", "she", "her", "hers",
        "we", "us", "our", "ours", "you", "your", "yours", "they", "them", "their", "theirs",
        "i", "me", "my", "mine", "what", "which", "who", "whom", "whose", "where", "when", "why", "how",
        "am", "can", "will", "would", "should", "could", "may", "might", "must",
        "do", "does", "did", "don't", "doesn't", "didn't",
        "have", "has", "had", "not", "no", "yes", "all", "any", "both", "each", "few", "more", "most", "other", "some", "such",
        "only", "own", "same", "so", "than", "too", "very", "s", "t", "can't", "will", "just", "don't", "shouldn't", "now", "d", "ll", "m", "o", "re", "ve", "y", "ain", "aren", "couldn", "didn", "doesn", "hadn", "hasn", "haven", "isn", "ma", "mightn", "mustn", "needn", "shan", "shouldn", "wasn", "weren", "won", "wouldn"
    ]

    private var corpusDocuments: [String] = []
    private var documentFrequencies: [String: Int] = [:] // Global DF
    private var totalDocuments: Int { corpusDocuments.count }

    init(documents: [String]) {
        self.corpusDocuments = documents
        precomputeDocumentFrequencies()
    }

    // Helper to check if a word is a stop word (case-insensitive)
    private func isStopWord(_ word: String) -> Bool {
        return stopWords.contains(word.lowercased())
    }

    // Helper function to tokenize, lemmatize, filter stop words, and select POS
    private func preprocess(text: String) -> [String] {
        let tagger = NLTagger(tagSchemes: [.lexicalClass, .lemma])
        tagger.string = text
        var processedWords: [String] = []

        tagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .lexicalClass, options: [.omitWhitespace, .omitPunctuation, .omitOther]) { lexicalClassTag, tokenRange in
            guard let lexicalClassTag = lexicalClassTag else { return true }

            // Consider nouns, proper nouns, verbs, and adjectives for TF-IDF keywords
            guard lexicalClassTag == .noun || lexicalClassTag == .properNoun || lexicalClassTag == .verb || lexicalClassTag == .adjective else {
                return true
            }

            let word = String(text[tokenRange])
            let lemmaTag = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .lemma).0
            let lemmatizedWord = (lemmaTag?.rawValue ?? word).lowercased()

            if !isStopWord(lemmatizedWord) {
                processedWords.append(lemmatizedWord)
            }
            return true
        }
        return processedWords
    }

    private func precomputeDocumentFrequencies() {
        guard !corpusDocuments.isEmpty else { return }

        // Iterate through all corpusDocuments to build global DF
        for document in corpusDocuments {
            let processedWords = preprocess(text: document)
            // Use a Set to count each unique word in the current document only once for DF
            let uniqueWordsInDocument = Set(processedWords)
            for word in uniqueWordsInDocument {
                documentFrequencies[word, default: 0] += 1
            }
        }
    }

    func extractTFIDFKeywords(from targetDocument: String, count: Int = 10) -> [String] {
        guard totalDocuments > 0 else {
            print("Corpus is empty. Cannot compute TF-IDF.")
            return []
        }

        // 1. Preprocess the target document
        let targetProcessedWords = preprocess(text: targetDocument)
        
        // 2. Calculate Term Frequencies (TF) for the target document
        var termFrequencies: [String: Int] = [:]
        for word in targetProcessedWords {
            termFrequencies[word, default: 0] += 1
        }

        // 3. Calculate TF-IDF scores
        var tfidfScores: [String: Double] = [:]
        for (word, tf) in termFrequencies {
            let df = Double(documentFrequencies[word] ?? 0) // Document frequency from corpus
            
            // Add 1 to numerator and denominator for Laplace smoothing, preventing division by zero
            // and handling words not seen in the corpus gracefully.
            let idf = log((Double(totalDocuments) + 1.0) / (df + 1.0))
            
            let tfidf = Double(tf) * idf
            tfidfScores[word] = tfidf
        }

        // 4. Sort and return the top 'count' keywords
        let sortedKeywords = tfidfScores.sorted { (entry1, entry2) -> Bool in
            if entry1.value != entry2.value {
                return entry1.value > entry2.value // Higher score first
            } else {
                return entry1.key < entry2.key // Alphabetical for ties
            }
        }

        let topKeywords = sortedKeywords.prefix(count).map { $0.key }
        return topKeywords
    }
}

// Example Usage:
@available(iOS 18.0, macOS 15.0, *)
func runExercise3() {
    let corpus = [
        "Machine learning algorithms are powerful. Deep learning is a subset of machine learning. Data science uses machine learning.",
        "Natural language processing focuses on text analysis. Keyword extraction is a key task in NLP. NLP models understand human language.",
        "Computer vision deals with images. Object detection is a common computer vision task. Image recognition is part of computer vision.",
        "A new algorithm for deep learning was presented. The algorithm improves image recognition."
    ]

    let analyzer = CorpusAnalyzer(documents: corpus)

    let targetDocument = "Natural language processing focuses on text analysis. Keyword extraction is a key task in NLP. Understanding human language is crucial."
    let keywords = analyzer.extractTFIDFKeywords(from: targetDocument, count: 5)
    print("Exercise 3 TF-IDF Keywords: \(keywords)")
    // Expected Output (order might vary slightly, but should prioritize terms unique to the target document):
    // E.g., ["natural language", "text analysis", "keyword extraction", "nlp", "human language"]
    // My output: ["natural language", "text analysis", "keyword extraction", "human language", "nlp"]
}

// Uncomment to run the example in a playground or app
// runExercise3()
