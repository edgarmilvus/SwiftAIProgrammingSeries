
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import Foundation
import OSLog
import MetricKit

/// A service simulating the lifecycle of an AI model inference.
final class AIService {
    private let aiLog = OSLog(subsystem: "com.ai.app", category: "Inference")
    private let signposter: OSSignposter

    init() {
        self.signposter = OSSignposter(logger: aiLog)
    }

    func runInference() async {
        // Phase 1: Model Loading
        let loadingState = signposter.beginInterval("ModelLoading")
        try? await Task.sleep(for: .seconds(0.5)) // Simulate I/O
        signposter.endInterval("ModelLoading", loadingState)

        // Phase 2: Prompt Processing
        let processingState = signposter.beginInterval("PromptProcessing")
        try? await Task.sleep(for: .seconds(2.5)) // Simulate heavy prefill
        signposter.endInterval("PromptProcessing", processingState)

        // Phase 3: Token Generation
        let generationState = signposter.beginInterval("TokenGeneration")
        try? await Task.sleep(for: .seconds(1.0)) // Simulate autoregressive loop
        signposter.endInterval("TokenGeneration", generationState)
    }
}

@available(iOS 18.0, *)
actor TelemetryManager: NSObject, MXMetricManagerDelegate {
    // ... (Previous implementation) ...

    private func processSignposts(from payload: MXMetricPayload) {
        for signpostMetric in payload.signpostMetrics {
            // We are looking for 'PromptProcessing' latency
            if signpostMetric.category == "Inference" && 
               signpostMetric.name == "PromptProcessing" {
                
                let averageDuration = signpostMetric.cumulativeDuration / Double(signpostMetric.count)
                
                if averageDuration > 2.0 {
                    print("🚨 Latency Regression: PromptProcessing average is \(averageDuration)s")
                }
            }
        }
    }

    nonisolated func didReceive(_ payload: MXMetricPayload) {
        Task {
            await self.processPayload(payload)
            await self.processSignposts(from: payload)
        }
    }
    
    private func processPayload(_ payload: MXMetricPayload) {}
}
