
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: basic_basic_code_example.swift
// Description: Basic Code Example
// ==========================================

import Foundation

// MARK: - 1. Define Data Structures

/// Represents the possible categories of fruits our model can classify.
/// Conforms to `String` for easy printing and `CaseIterable` to iterate over all categories.
enum FruitCategory: String, CaseIterable, Hashable {
    case apple = "Apple"
    case banana = "Banana"
    case orange = "Orange"
    case unknown = "Unknown" // A potential fallback or error category
}

/// A simple struct to hold a single prediction result.
/// It stores both the actual (ground truth) label and the model's predicted label.
struct Prediction {
    let groundTruth: FruitCategory
    let predictedLabel: FruitCategory
}

// MARK: - 2. Simulate Model Predictions

/// Simulates a set of test data with ground truth labels and corresponding model predictions.
/// In a real app, these predictions would come from running an actual Create ML model
/// on a separate, unseen test dataset.
func generateSimulatedPredictions() -> [Prediction] {
    return [
        // Actual Apples
        Prediction(groundTruth: .apple, predictedLabel: .apple),    // Correct
        Prediction(groundTruth: .apple, predictedLabel: .apple),    // Correct
        Prediction(groundTruth: .apple, predictedLabel: .banana),   // Misclassified (FN for Apple, FP for Banana)
        Prediction(groundTruth: .apple, predictedLabel: .orange),   // Misclassified (FN for Apple, FP for Orange)
        Prediction(groundTruth: .apple, predictedLabel: .apple),    // Correct

        // Actual Bananas
        Prediction(groundTruth: .banana, predictedLabel: .banana),  // Correct
        Prediction(groundTruth: .banana, predictedLabel: .banana),  // Correct
        Prediction(groundTruth: .banana, predictedLabel: .apple),   // Misclassified (FN for Banana, FP for Apple)
        Prediction(groundTruth: .banana, predictedLabel: .banana),  // Correct
        Prediction(groundTruth: .banana, predictedLabel: .banana),  // Correct

        // Actual Oranges
        Prediction(groundTruth: .orange, predictedLabel: .orange),  // Correct
        Prediction(groundTruth: .orange, predictedLabel: .orange),  // Correct
        Prediction(groundTruth: .orange, predictedLabel: .apple),   // Misclassified (FN for Orange, FP for Apple)
        Prediction(groundTruth: .orange, predictedLabel: .orange),  // Correct
        Prediction(groundTruth: .orange, predictedLabel: .banana)   // Misclassified (FN for Orange, FP for Banana)
    ]
}

// MARK: - 3. Calculate Confusion Matrix

/// Calculates the confusion matrix from a list of predictions.
/// The confusion matrix is a nested dictionary:
/// `[GroundTruthCategory: [PredictedCategory: Count]]`
/// For example, `matrix[.apple]![.banana]` would be the count of actual Apples
/// that were predicted as Bananas.
///
/// - Parameters:
///   - predictions: An array of `Prediction` objects.
///   - categories: All possible categories the model can predict.
/// - Returns: A nested dictionary representing the confusion matrix.
func calculateConfusionMatrix(
    predictions: [Prediction],
    categories: [FruitCategory]
) -> [FruitCategory: [FruitCategory: Int]] {
    var confusionMatrix: [FruitCategory: [FruitCategory: Int]] = [:]

    // Initialize the matrix with zeros for all category pairs
    for groundTruthCat in categories {
        confusionMatrix[groundTruthCat] = [:]
        for predictedCat in categories {
            confusionMatrix[groundTruthCat]?[predictedCat] = 0
        }
    }

    // Populate the matrix with prediction counts
    for prediction in predictions {
        let groundTruth = prediction.groundTruth
        let predicted = prediction.predictedLabel
        confusionMatrix[groundTruth]?[predicted]? += 1
    }

    return confusionMatrix
}

/// Prints the confusion matrix in a readable, tabular format.
///
/// - Parameters:
///   - matrix: The confusion matrix to print.
///   - categories: All possible categories for row/column headers.
func printConfusionMatrix(
    _ matrix: [FruitCategory: [FruitCategory: Int]],
    categories: [FruitCategory]
) {
    print("\n--- Confusion Matrix ---")
    // Print header row
    print(String(format: "%-10s", "Actual\\Pred"), terminator: "")
    for category in categories {
        print(String(format: "%10s", category.rawValue), terminator: "")
    }
    print()

    // Print matrix rows
    for groundTruthCat in categories {
        print(String(format: "%-10s", groundTruthCat.rawValue), terminator: "")
        for predictedCat in categories {
            let count = matrix[groundTruthCat]?[predictedCat] ?? 0
            print(String(format: "%10d", count), terminator: "")
        }
        print()
    }
    print("------------------------")
}

// MARK: - 4. Calculate TP, FP, FN for a Specific Category

/// Calculates True Positives (TP) for a given target category.
/// TP: Instances where the actual label was the target category, and the model predicted it correctly.
///
/// - Parameters:
///   - targetCategory: The category for which to calculate TP.
///   - confusionMatrix: The pre-calculated confusion matrix.
/// - Returns: The count of True Positives.
func calculateTruePositives(
    for targetCategory: FruitCategory,
    in confusionMatrix: [FruitCategory: [FruitCategory: Int]]
) -> Int {
    // TP for a category is the count where ground truth is target and predicted is target
    return confusionMatrix[targetCategory]?[targetCategory] ?? 0
}

/// Calculates False Positives (FP) for a given target category.
/// FP: Instances where the actual label was NOT the target category, but the model incorrectly predicted it AS the target category.
///
/// - Parameters:
///   - targetCategory: The category for which to calculate FP.
///   - confusionMatrix: The pre-calculated confusion matrix.
///   - allCategories: All possible categories to sum across.
/// - Returns: The count of False Positives.
func calculateFalsePositives(
    for targetCategory: FruitCategory,
    in confusionMatrix: [FruitCategory: [FruitCategory: Int]],
    allCategories: [FruitCategory]
) -> Int {
    var fp = 0
    // FP for a category is the sum of predictions for that category
    // where the ground truth was *not* that category.
    for groundTruthCat in allCategories where groundTruthCat != targetCategory {
        fp += confusionMatrix[groundTruthCat]?[targetCategory] ?? 0
    }
    return fp
}

/// Calculates False Negatives (FN) for a given target category.
/// FN: Instances where the actual label WAS the target category, but the model incorrectly predicted it AS something else.
///
/// - Parameters:
///   - targetCategory: The category for which to calculate FN.
///   - confusionMatrix: The pre-calculated confusion matrix.
///   - allCategories: All possible categories to sum across.
/// - Returns: The count of False Negatives.
func calculateFalseNegatives(
    for targetCategory: FruitCategory,
    in confusionMatrix: [FruitCategory: [FruitCategory: Int]],
    allCategories: [FruitCategory]
) -> Int {
    var fn = 0
    // FN for a category is the sum of predictions where ground truth was target
    // but the model predicted something *else*.
    if let row = confusionMatrix[targetCategory] {
        for predictedCat in allCategories where predictedCat != targetCategory {
            fn += row[predictedCat] ?? 0
        }
    }
    return fn
}

// MARK: - 5. Calculate Precision, Recall, and F1-Score

/// Calculates Precision for a given category.
/// Precision = TP / (TP + FP)
/// Handles division by zero by returning 0.0 if (TP + FP) is zero.
///
/// - Parameters:
///   - tp: True Positives for the category.
///   - fp: False Positives for the category.
/// - Returns: The precision score as a Double.
func calculatePrecision(tp: Int, fp: Int) -> Double {
    let denominator = Double(tp + fp)
    return denominator == 0 ? 0.0 : Double(tp) / denominator
}

/// Calculates Recall for a given category.
/// Recall = TP / (TP + FN)
/// Handles division by zero by returning 0.0 if (TP + FN) is zero.
///
/// - Parameters:
///   - tp: True Positives for the category.
///   - fn: False Negatives for the category.
/// - Returns: The recall score as a Double.
func calculateRecall(tp: Int, fn: Int) -> Double {
    let denominator = Double(tp + fn)
    return denominator == 0 ? 0.0 : Double(tp) / denominator
}

/// Calculates the F1-Score, which is the harmonic mean of Precision and Recall.
/// F1-Score = 2 * (Precision * Recall) / (Precision + Recall)
/// Handles division by zero by returning 0.0 if (Precision + Recall) is zero.
///
/// - Parameters:
///   - precision: The precision score.
///   - recall: The recall score.
/// - Returns: The F1-Score as a Double.
func calculateF1Score(precision: Double, recall: Double) -> Double {
    let denominator = precision + recall
    return denominator == 0 ? 0.0 : 2 * (precision * recall) / denominator
}

// MARK: - Main Execution Block

// This ensures the code runs when the playground or app starts.
@main
struct FruitSorterAppEvaluator {
    static func main() {
        print("Starting Fruit Sorter Model Evaluation...")

        // 1. Get all possible categories for our fruit model.
        let allCategories = FruitCategory.allCases.filter { $0 != .unknown } // Exclude 'unknown' for evaluation metrics

        // 2. Simulate model predictions on a test dataset.
        let simulatedPredictions = generateSimulatedPredictions()
        print("Total simulated predictions: \(simulatedPredictions.count)")

        // 3. Calculate the confusion matrix.
        let confusionMatrix = calculateConfusionMatrix(predictions: simulatedPredictions, categories: allCategories)
        printConfusionMatrix(confusionMatrix, categories: allCategories)

        // 4. Calculate and print Precision, Recall, and F1-Score for each category.
        print("\n--- Per-Category Metrics ---")
        for category in allCategories {
            let tp = calculateTruePositives(for: category, in: confusionMatrix)
            let fp = calculateFalsePositives(for: category, in: confusionMatrix, allCategories: allCategories)
            let fn = calculateFalseNegatives(for: category, in: confusionMatrix, allCategories: allCategories)

            let precision = calculatePrecision(tp: tp, fp: fp)
            let recall = calculateRecall(tp: tp, fn: fn)
            let f1Score = calculateF1Score(precision: precision, recall: recall)

            print("\nCategory: \(category.rawValue)")
            print(String(format: "  True Positives (TP):  %d", tp))
            print(String(format: "  False Positives (FP): %d", fp))
            print(String(format: "  False Negatives (FN): %d", fn))
            print(String(format: "  Precision:            %.2f", precision))
            print(String(format: "  Recall:               %.2f", recall))
            print(String(format: "  F1-Score:             %.2f", f1Score))
        }

        print("\nFruit Sorter Model Evaluation Complete.")
    }
}
