
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

@available(iOS 18.0, *)
final class ModelCache {
    /// A shared instance of the ModelCache for convenient access.
    static let shared = ModelCache()

    /// NSCache to store MLModel instances, keyed by their QuantizationStrategy.
    private let cache = NSCache<NSString, MLModel>()

    private init() {} // Private initializer to enforce singleton pattern

    /// Retrieves a cached MLModel or loads it if not present.
    /// - Parameter strategy: The quantization strategy for the desired model.
    /// - Returns: An MLModel instance.
    /// - Throws: ModelInferenceError if the model cannot be found or loaded.
    func getModel(for strategy: QuantizationStrategy) async throws -> MLModel {
        let cacheKey = strategy.modelFileName as NSString

        // 1. Check if the model is already in the cache.
        if let cachedModel = cache.object(forKey: cacheKey) {
            print("🟢 Using cached model: \(strategy.description)")
            return cachedModel
        }

        // 2. If not cached, attempt to load the model asynchronously.
        print("🟡 Loading model from bundle: \(strategy.description)")
        guard let modelURL = Bundle.main.url(forResource: strategy.modelFileName, withExtension: "mlmodelc") else {
            throw ModelInferenceError.modelNotFound(strategy: strategy)
        }

        do {
            // MLModelAsset allows loading models from arbitrary URLs.
            // This is key for dynamic model selection or even downloading models.
            let modelAsset = try await MLModelAsset(url: modelURL).model
            cache.setObject(modelAsset, forKey: cacheKey)
            print("✅ Model loaded and cached: \(strategy.description)")
            return modelAsset
        } catch {
            throw ModelInferenceError.modelLoadingFailed(strategy: strategy, underlyingError: error)
        }
    }

    /// Clears all models from the cache.
    func clearCache() {
        cache.removeAllObjects()
        print("🗑️ Model cache cleared.")
    }
}
