
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part6.swift
// Description: Theoretical Foundations
// ==========================================

// Example of a SwiftUI View using the @Observable SpeechManager
import SwiftUI
import AVFoundation

@available(iOS 18.0, *)
struct SpeechView: View {
    @State private var speechManager = SpeechManager() // Or inject via environment

    var body: some View {
        VStack {
            Text("Current Word: \(speechManager.spokenWords)")
                .font(.largeTitle)
                .padding()

            Button(speechManager.isSpeaking ? "Stop Speaking" : "Start Speaking") {
                if speechManager.isSpeaking {
                    speechManager.stop()
                } else {
                    Task {
                        await speakContent()
                    }
                }
            }
            .padding()
            .buttonStyle(.borderedProminent)
            .disabled(speechManager.isSpeaking && speechManager.currentUtterance == nil) // Disable if stopping and no utterance

            if speechManager.isSpeaking {
                ProgressView()
            }
        }
    }

    @available(iOS 18.0, *)
    func speakContent() async {
        let request = SpeechRequest(text: "This is a demonstration of text-to-speech with modern Swift concurrency and SwiftUI.", rate: 0.5)
        do {
            try await speechManager.speak(request: request)
        } catch {
            print("Speech error: \(error)")
        }
    }
}
