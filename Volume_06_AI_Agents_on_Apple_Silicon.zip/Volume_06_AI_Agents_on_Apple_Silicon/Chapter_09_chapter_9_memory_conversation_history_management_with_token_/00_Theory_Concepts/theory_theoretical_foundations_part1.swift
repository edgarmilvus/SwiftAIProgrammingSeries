
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

// Package.swift snippet (example dependency for tokenization)
// .package(url: "https://github.com/ggerganov/llama.cpp", from: "0.0.1"),
// .product(name: "LlamaCpp", package: "llama.cpp"),

import Foundation
import LlamaCpp // Assuming LlamaCpp provides a tokenizer or similar utility

/// Represents a single turn in the conversation.
struct ConversationEntry: Sendable, Identifiable {
    let id = UUID()
    let role: String // e.g., "user", "assistant", "system"
    let content: String
    let timestamp: Date
    var tokenCount: Int? // Will be populated asynchronously

    // Conform to Sendable for safe concurrent access
    // All properties are value types or Sendable, so this is implicit or trivial
}

@available(iOS 18.0, *)
actor AgentMemory {
    private var conversationHistory: [ConversationEntry] = []
    private let tokenizer: TokenizerService // A service to count tokens

    init(tokenizer: TokenizerService) {
        self.tokenizer = tokenizer
    }

    /// Adds a new entry to the conversation history and tokenizes it.
    func addEntry(_ entry: ConversationEntry) async {
        var mutableEntry = entry
        // Asynchronously count tokens for the entry
        mutableEntry.tokenCount = await tokenizer.countTokens(for: entry.content)
        conversationHistory.append(mutableEntry)
        // In a real scenario, we might immediately prune here
        // await pruneHistory(toBudget: someBudget)
    }

    /// Retrieves the conversation history, pruned to fit the given token budget.
    /// This is where the core memory management logic resides.
    func getHistory(forTokenBudget budget: Int) async -> [ConversationEntry] {
        var currentTokens = 0
        var prunedHistory: [ConversationEntry] = []

        // Iterate from most recent to oldest
        for entry in conversationHistory.reversed() {
            guard let entryTokens = entry.tokenCount else {
                // Should not happen if addEntry correctly tokenizes, but handle defensively
                continue
            }

            if currentTokens + entryTokens <= budget {
                prunedHistory.insert(entry, at: 0) // Insert at beginning to maintain chronological order
                currentTokens += entryTokens
            } else {
                // This entry would exceed the budget, stop adding older entries
                break
            }
        }
        return prunedHistory
    }

    /// Clears the entire conversation history.
    func clearHistory() {
        conversationHistory.removeAll()
    }

    /// Returns the full, unpruned history (for debugging/inspection).
    func fullHistory() -> [ConversationEntry] {
        return conversationHistory
    }
}
