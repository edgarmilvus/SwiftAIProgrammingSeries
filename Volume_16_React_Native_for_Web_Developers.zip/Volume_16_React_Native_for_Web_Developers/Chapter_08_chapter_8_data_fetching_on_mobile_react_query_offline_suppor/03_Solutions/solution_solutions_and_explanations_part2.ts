/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet, Alert } from 'react-native';
import { useQuery, useMutation, useQueryClient, onlineManager } from '@tanstack/react-query';

type Todo = { id: string; text: string; status: 'pending' | 'done' };

// Mock API
const addTodoApi = async (text: string): Promise<Todo> => {
  await new Promise((resolve, reject) => setTimeout(() => {
    // Simulate random failure for testing rollback
    if (Math.random() > 0.9) reject(new Error("Server Error"));
    else resolve({ id: Date.now().toString(), text, status: 'done' });
  }, 1000));
};

// Mock initial data
const fetchTodos = async (): Promise<Todo[]> => [
  { id: '1', text: 'Learn React Query', status: 'done' }
];

export const TodoList = () => {
  const queryClient = useQueryClient();
  const [input, setInput] = useState('');

  // 1. Fetch Todos
  const { data: todos = [] } = useQuery({
    queryKey: ['todos'],
    queryFn: fetchTodos,
  });

  // 2. Mutation Logic
  const mutation = useMutation({
    mutationFn: (text: string) => addTodoApi(text),
    
    // 3. Optimistic Update (OnMutate)
    onMutate: async (newTodoText) => {
      // Cancel outgoing refetches to avoid overwriting our optimistic update
      await queryClient.cancelQueries({ queryKey: ['todos'] });

      // Snapshot previous value
      const previousTodos = queryClient.getQueryData(['todos']);

      // Optimistically update local cache
      queryClient.setQueryData(['todos'], (old: Todo[] | undefined) => [
        ...(old || []),
        { id: 'temp-id', text: newTodoText, status: 'pending' },
      ]);

      // Return context for rollback
      return { previousTodos };
    },

    // 4. Error Rollback (OnError)
    onError: (err, newTodoText, context) => {
      if (context?.previousTodos) {
        queryClient.setQueryData(['todos'], context.previousTodos);
      }
      Alert.alert("Error", "Failed to add todo. Reverted changes.");
    },

    // 5. OnSettled (Refetch/Invalidate)
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['todos'] });
    },
  });

  const handleAdd = () => {
    if (!input.trim()) return;

    // 6. Offline Check
    if (!onlineManager.isOnline()) {
      Alert.alert("Offline", "You are offline. Changes will sync when connection is restored.");
      // In a real app, we would add this to a persistent queue here
      // For this exercise, we won't trigger the mutation to simulate blocking
      return;
    }

    mutation.mutate(input);
    setInput('');
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={todos}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text style={item.status === 'pending' ? styles.pending : styles.done}>
              {item.text} {item.status === 'pending' ? '(Syncing...)' : ''}
            </Text>
          </View>
        )}
      />
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="Add a todo"
        />
        <Button title="Add" onPress={handleAdd} disabled={mutation.isPending} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  item: { padding: 10, borderBottomWidth: 1, borderColor: '#eee' },
  inputRow: { flexDirection: 'row', marginTop: 10 },
  input: { flex: 1, borderWidth: 1, borderColor: '#ccc', padding: 8, marginRight: 10 },
  pending: { color: 'orange', fontStyle: 'italic' },
  done: { color: 'black' },
});
