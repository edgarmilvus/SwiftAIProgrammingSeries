
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part7.swift
// Description: Advanced Application
// ==========================================

import Foundation
import MLX
import MLXNN
import MLXNN_Optimizers

@available(iOS 18.0, macOS 14.0, visionOS 1.0, *)
class DocumentAssistantAppManager: ObservableObject {
    @Published var statusMessage: String = "Ready to fine-tune."
    @Published var lastPrediction: String = "No prediction yet."

    private var fineTuner: DocumentFineTuner?
    private let loraWeightsFileName = "lora_document_classifier_weights.safetensors"

    let embeddingDimension = 128
    let hiddenDimension = 64
    let numClasses = 10
    let loraRank = 8
    let loraAlpha = 16.0 // Typically 2 * rank

    func setupFineTuner() async {
        do {
            self.fineTuner = try DocumentFineTuner(
                embeddingDimension: embeddingDimension,
                hiddenDimension: hiddenDimension,
                numClasses: numClasses,
                loraRank: loraRank,
                loraAlpha: loraAlpha,
                learningRate: 1e-3,
                batchSize: 32,
                numEpochs: 5,
                seed: 42
            )
            await MainActor.run { statusMessage = "Fine-tuner initialized successfully." }
        } catch {
            await MainActor.run { statusMessage = "Error initializing fine-tuner: \(error.localizedDescription)" }
            print("Error initializing fine-tuner: \(error)")
        }
    }

    func startFineTuning() async {
        guard let fineTuner = self.fineTuner else {
            await MainActor.run { statusMessage = "Fine-tuner not initialized." }
            return
        }

        await MainActor.run { statusMessage = "Starting fine-tuning process..." }
        do {
            try await fineTuner.fineTune()
            await MainActor.run { statusMessage = "Fine-tuning completed!" }

            // Save the LoRA weights after fine-tuning
            let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            let fileURL = documentsDirectory.appendingPathComponent(loraWeightsFileName)
            try await fineTuner.saveLoRAAdapterParameters(to: fileURL)
            await MainActor.run { statusMessage += "\nLoRA weights saved to \(fileURL.lastPathComponent)" }

        } catch {
            await MainActor.run { statusMessage = "Fine-tuning failed: \(error.localizedDescription)" }
            print("Fine-tuning failed: \(error)")
        }
    }

    func loadAndPredict() async {
        guard let fineTuner = self.fineTuner else {
            await MainActor.run { statusMessage = "Fine-tuner not initialized." }
            return
        }

        await MainActor.run { statusMessage = "Attempting to load LoRA weights..." }
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileURL = documentsDirectory.appendingPathComponent(loraWeightsFileName)

        do {
            try await fineTuner.loadLoRAAdapterParameters(from: fileURL)
            await MainActor.run { statusMessage += "\nLoRA weights loaded successfully." }

            // --- 8. Inference with Fine-Tuned LoRA ---
            // Generate a *new* synthetic input for prediction,
            // also with the fine-tune bias to test the adapted model.
            var currentKey = MLXRandom.Key(seed: 123) // A different seed for inference data
            let (testEmbeddings, _) = generateSyntheticData(
                numSamples: 1, // Just one sample for prediction
                embeddingDimension: embeddingDimension,
                numClasses: numClasses,
                fineTuneBias: 0.5, // Match the fine-tuning domain
                key: currentKey.split()
            )

            let logits = await fineTuner.predict(input: testEmbeddings)
            let predictedClass = MLXArray.argmax(logits, axis: -1).item(Int.self)

            await MainActor.run {
                lastPrediction = "Predicted class for new document: \(predictedClass)"
                statusMessage += "\n\(lastPrediction)"
            }

        } catch {
            await MainActor.run { statusMessage = "Error loading weights or predicting: \(error.localizedDescription)" }
            print("Error loading weights or predicting: \(error)")
        }
    }
}

// Example usage in an async context (e.g., a SwiftUI App or a command-line tool)
@available(iOS 18.0, macOS 14.0, visionOS 1.0, *)
@main
struct SmartDocumentAssistantApp {
    static func main() async {
        let manager = DocumentAssistantAppManager()

        // Setup the fine-tuner
        await manager.setupFineTuner()

        // Start the fine-tuning process
        await manager.startFineTuning()

        // After fine-tuning (and saving), we can load the weights and predict
        // This simulates restarting the app or loading a pre-trained adapter.
        await manager.loadAndPredict()

        // Print final status
        await MainActor.run {
            print("\n--- Final App Status ---")
            print(manager.statusMessage)
            print(manager.lastPrediction)
        }
    }
}
