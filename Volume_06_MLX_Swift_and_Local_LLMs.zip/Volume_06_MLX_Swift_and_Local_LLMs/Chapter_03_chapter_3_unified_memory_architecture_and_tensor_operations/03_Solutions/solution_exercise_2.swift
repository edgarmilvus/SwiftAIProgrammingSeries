
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_2.swift
// Description: Solution for Exercise 2
// ==========================================

import MLX

@available(iOS 18.0, macOS 15.0, *)
func calculateRMSEnergy(audioSamples: [Float]) -> Float {
    precondition(!audioSamples.isEmpty, "Audio samples array cannot be empty.")

    // 1. MLXArray Conversion: Convert the input [Float] array into an MLXArray.
    // The shape is 1D, representing a sequence of audio samples.
    let samplesArray = MLXArray(audioSamples, shape: [audioSamples.count], dtype: .float32)

    // 2. RMS Calculation:
    // a. Square each sample: x^2
    let squaredSamples = samplesArray * samplesArray // Element-wise multiplication

    // b. Calculate the mean of the squared samples: sum(x^2) / N
    let meanSquared = MLX.mean(squaredSamples)

    // c. Take the square root of the mean: sqrt(sum(x^2) / N)
    let rmsValueArray = MLX.sqrt(meanSquared)

    // 3. Output: The function should return a single Float value.
    // .item() evaluates the MLXArray and extracts its scalar value.
    return rmsValueArray.item()
}

// Example usage:
// let samples = [0.1, -0.2, 0.3, -0.4, 0.5, 0.0, 0.6, -0.7]
// let rms = calculateRMSEnergy(audioSamples: samples)
// print("Audio Samples: \(samples)")
// print("RMS Energy: \(rms)")
//
// let silentSamples = Array(repeating: Float(0.0), count: 100)
// let rmsSilent = calculateRMSEnergy(audioSamples: silentSamples)
// print("RMS Energy (silent samples): \(rmsSilent)")
//
// let loudSamples = Array(repeating: Float(1.0), count: 100)
// let rmsLoud = calculateRMSEnergy(audioSamples: loudSamples)
// print("RMS Energy (loud samples): \(rmsLoud)")
