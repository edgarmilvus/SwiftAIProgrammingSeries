
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import Foundation
import MLX
import AppKit // For macOS UI elements, conceptual for this example
// import UIKit // For iOS UI elements, conceptual for this example

// MARK: - Mocks for MLX and Tokenizer (since actual models/tokenizers are external)

// A protocol to represent a generic tokenizer
protocol TokenizerProtocol: Sendable {
    func tokenize(text: String) -> [Int]
    func detokenize(ids: [Int]) -> String
    var eosTokenID: Int { get }
}

// A simple mock tokenizer for demonstration
class MockTokenizer: TokenizerProtocol {
    let vocab: [String: Int]
    let reverseVocab: [Int: String]
    let eosTokenID: Int

    init(vocab: [String: Int], eosTokenID: Int) {
        self.vocab = vocab
        self.reverseVocab = vocab.reduce(into: [:]) { $0[$1.value] = $1.key }
        self.eosTokenID = eosTokenID
    }

    func tokenize(text: String) -> [Int] {
        return text.split(separator: " ").compactMap { vocab[String($0)] }
    }

    func detokenize(ids: [Int]) -> String {
        return ids.compactMap { reverseVocab[$0] }.joined(separator: " ")
    }
}

// A protocol for a generic MLX model that can stream tokens
protocol MLXModelProtocol: Sendable {
    func generate(
        promptTokens: MLXArray,
        maxTokens: Int,
        temperature: Float,
        tokenizer: TokenizerProtocol
    ) async throws -> AsyncThrowingStream<MLXArray, Error>
    var name: String { get }
}

// A mock MLX model for demonstration
class MockMLXModel: MLXModelProtocol {
    let name: String = "Mock-Llama-7B"
    let eosTokenID: Int

    init(eosTokenID: Int) {
        self.eosTokenID = eosTokenID
    }

    func generate(
        promptTokens: MLXArray,
        maxTokens: Int,
        temperature: Float, // Not used in mock but part of API
        tokenizer: TokenizerProtocol
    ) async throws -> AsyncThrowingStream<MLXArray, Error> {
        return AsyncThrowingStream { continuation in
            Task {
                let mockResponses: [String: [String]] = [
                    "hello": ["Hello", "there", "!", "How", "can", "I", "assist", "you", "?"],
                    "tell me a joke": ["Why", "don't", "scientists", "trust", "atoms", "?", "Because", "they", "make", "up", "everything", "!"],
                    "what is mlx": ["MLX", "is", "an", "array", "framework", "for", "Apple", "silicon", "."],
                ]

                guard let promptString = tokenizer.detokenize(ids: promptTokens.data.map { $0.item(Int.self)! }).lowercased() else {
                    continuation.finish(throwing: ChatError.tokenizerFailed)
                    return
                }
                
                let responseWords = mockResponses.first { promptString.contains($0.key) }?.value ?? ["I'm", "not", "sure", "how", "to", "respond", "to", "that", "."]
                
                for word in responseWords {
                    // Simulate token generation delay
                    try await Task.sleep(for: .milliseconds(50))
                    let tokenID = tokenizer.tokenize(text: word).first ?? 0 // Get first token ID for the word
                    continuation.yield(MLXArray(scalar: tokenID))
                }
                
                // Simulate EOS token
                try await Task.sleep(for: .milliseconds(50))
                continuation.yield(MLXArray(scalar: self.eosTokenID))
                
                continuation.finish()
            }
        }
    }
}

// MARK: - Chat Application Logic

enum ChatError: Error, LocalizedError {
    case modelLoadingFailed(String)
    case tokenizerLoadingFailed(String)
    case inferenceFailed(String)
    case invalidTokenID
    
    var errorDescription: String? {
        switch self {
        case .modelLoadingFailed(let msg): return "Model loading failed: \(msg)"
        case .tokenizerLoadingFailed(let msg): return "Tokenizer loading failed: \(msg)"
        case .inferenceFailed(let msg): return "Inference failed: \(msg)"
        case .invalidTokenID: return "Received an invalid token ID from the model."
        }
    }
}

@Observable // Available in Swift 5.9+ / iOS 17+ / macOS 14+
class ChatViewModel {
    private var model: (any MLXModelProtocol)?
    private var tokenizer: (any TokenizerProtocol)?
    
    var chatHistory: String = ""
    var currentInput: String = ""
    var isLoading: Bool = false
    var errorMessage: String?
    
    // In a real app, these would be paths to model/tokenizer files
    private let modelPath = "path/to/your/model.safetensors"
    private let tokenizerPath = "path/to/your/tokenizer.json"
    
    init() {
        // Initialize with default mock tokenizer/model
        let mockVocab: [String: Int] = [
            "hello": 1, "there": 2, "!": 3, "How": 4, "can": 5, "I": 6, "assist": 7, "you": 8, "?": 9,
            "Why": 10, "don't": 11, "scientists": 12, "trust": 13, "atoms": 14, "Because": 15, "they": 16, "make": 17, "up": 18, "everything": 19,
            "MLX": 20, "is": 21, "an": 22, "array": 23, "framework": 24, "for": 25, "Apple": 26, "silicon": 27, ".": 28,
            "I'm": 29, "not": 30, "sure": 31, "how": 32, "to": 33, "respond": 34, "that": 35,
            "<|eos|>": 1000 // End-of-sequence token
        ]
        let eosTokenID = mockVocab["<|eos|>"]!
        self.tokenizer = MockTokenizer(vocab: mockVocab, eosTokenID: eosTokenID)
        self.model = MockMLXModel(eosTokenID: eosTokenID)
    }

    func loadModelAndTokenizer() async {
        isLoading = true
        errorMessage = nil
        do {
            // In a real scenario, this would involve loading MLX model weights
            // and a tokenizer (e.g., from Hugging Face format)
            // For this example, we're using the mock objects initialized in init().
            // Example real loading (conceptual):
            // self.tokenizer = try await TokenizerLoader.load(from: tokenizerPath)
            // self.model = try await MLXModelLoader.load(from: modelPath)
            
            // Simulate loading delay
            try await Task.sleep(for: .seconds(1))
            
            guard self.model != nil else {
                throw ChatError.modelLoadingFailed("Failed to initialize mock model.")
            }
            guard self.tokenizer != nil else {
                throw ChatError.tokenizerLoadingFailed("Failed to initialize mock tokenizer.")
            }
            
            print("Model and tokenizer loaded successfully.")
        } catch {
            errorMessage = error.localizedDescription
            print("Error loading model/tokenizer: \(error.localizedDescription)")
        }
        isLoading = false
    }
    
    @MainActor
    func sendMessage() async {
        guard !currentInput.isEmpty else { return }
        guard let model = self.model, let tokenizer = self.tokenizer else {
            errorMessage = "Model or tokenizer not loaded."
            return
        }

        let userPrompt = currentInput
        chatHistory += "You: \(userPrompt)\n"
        currentInput = "" // Clear input field
        
        chatHistory += "AI: " // Start AI response line
        
        do {
            let promptTokens = tokenizer.tokenize(text: userPrompt)
            let mlxPrompt = MLXArray(promptTokens)
            
            let tokenStream = try await model.generate(
                promptTokens: mlxPrompt,
                maxTokens: 200, // Max tokens to generate
                temperature: 0.7,
                tokenizer: tokenizer
            )
            
            for try await tokenIDArray in tokenStream {
                guard let tokenID = tokenIDArray.item(Int.self) else {
                    throw ChatError.invalidTokenID
                }
                
                if tokenID == tokenizer.eosTokenID {
                    break // Stop on EOS token
                }
                
                let detokenized = tokenizer.detokenize(ids: [tokenID])
                chatHistory += detokenized + (detokenized.hasSuffix(" ") ? "" : " ") // Append with space if not already present
                // In a real UI, you'd update an NSTextView/UITextView here.
                // For this example, we're appending to a string and printing.
                print("Streamed: \(detokenized)")
            }
            chatHistory += "\n" // New line after AI response
            print("AI response finished.")

        } catch {
            errorMessage = "Inference error: \(error.localizedDescription)"
            chatHistory += "Error: \(error.localizedDescription)\n"
            print("Error during inference: \(error.localizedDescription)")
        }
    }
}

// MARK: - Conceptual UI Usage (macOS example)

@MainActor
func setupConceptualUI() {
    let viewModel = ChatViewModel()
    
    // Simulate initial model loading
    Task {
        await viewModel.loadModelAndTokenizer()
    }

    // --- Conceptual UI Elements ---
    // In a real app, these would be connected to actual views.
    let scrollView = NSScrollView()
    let chatTextView = NSTextView()
    chatTextView.isEditable = false
    chatTextView.isSelectable = true
    scrollView.documentView = chatTextView
    
    let inputField = NSTextField()
    inputField.placeholderString = "Type your message..."
    
    let sendButton = NSButton(title: "Send", target: nil, action: nil)
    sendButton.action = #selector(sendButtonTapped) // Needs an actual target/selector
    
    // Bindings (conceptual)
    // chatTextView.textStorage?.setAttributedString(NSAttributedString(string: viewModel.chatHistory))
    // inputField.stringValue = viewModel.currentInput
    // sendButton.isEnabled = !viewModel.isLoading && !viewModel.currentInput.isEmpty

    // Simulate user interaction
    Task {
        try await Task.sleep(for: .seconds(2)) // Wait for model to load
        print("\n--- Simulating User Input ---")
        
        viewModel.currentInput = "Hello there"
        await viewModel.sendMessage()
        
        try await Task.sleep(for: .seconds(5)) // Wait for response
        
        viewModel.currentInput = "Tell me a joke"
        await viewModel.sendMessage()
        
        try await Task.sleep(for: .seconds(8)) // Wait for response

        viewModel.currentInput = "What is MLX"
        await viewModel.sendMessage()

        try await Task.sleep(for: .seconds(8)) // Wait for response
        
        print("\n--- Final Chat History ---")
        print(viewModel.chatHistory)
        if let error = viewModel.errorMessage {
            print("Error: \(error)")
        }
    }
}

// Call this to run the conceptual example
// setupConceptualUI()
