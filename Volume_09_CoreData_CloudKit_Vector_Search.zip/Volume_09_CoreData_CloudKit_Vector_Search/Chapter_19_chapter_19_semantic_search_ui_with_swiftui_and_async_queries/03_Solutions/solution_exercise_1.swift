
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Observation

@available(iOS 18.0, *)
@Observable
@MainActor // Ensure all UI updates happen on the main thread
class SemanticSearchViewModel {
    var searchText: String = ""
    var results: [SearchResult] = []
    var isSearching: Bool = false
    
    // Reference to the current running task to allow cancellation
    private var searchTask: Task<Void, Never>?

    /// This function is called whenever searchText changes.
    func handleSearchChange() async {
        // 1. Cancel the previous task immediately if the user is still typing
        searchTask?.cancel()
        
        // 2. Create a new task for the current input
        searchTask = Task {
            do {
                // 3. Implement the debounce window (300ms)
                // Task.sleep is cancellation-aware; it throws if the task is cancelled during sleep
                try await Task.sleep(for: .milliseconds(300))
                
                // 4. Check for cancellation before starting heavy work
                if Task.isCancelled { return }
                
                isSearching = true
                
                // 5. Perform the heavy lifting
                let fetchedResults = try await performSemanticSearch(for: searchText)
                
                // 6. Check for cancellation again before updating the UI
                if Task.isCancelled { return }
                
                self.results = fetchedResults
                self.isSearching = false
                
            } catch is CancellationError {
                // Task was cancelled during sleep or execution; do nothing
            } catch {
                // Handle actual search errors
                print("Search error: \(error)")
                isSearching = false
            }
        }
    }

    /// Simulates the heavy lifting of vector search.
    private func performSemanticSearch(for query: String) async throws -> [SearchResult] {
        guard !query.isEmpty else { return [] }
        
        // Simulate Embedding Generation (e.g., NPU/GPU intensive)
        // We check isCancelled to stop math mid-way if a new character was typed
        try await Task.sleep(for: .milliseconds(500))
        if Task.isCancelled { throw CancellationError() }
        
        // Simulate Vector Similarity Lookup
        try await Task.sleep(for: .milliseconds(300))
        if Task.isCancelled { throw CancellationError() }
        
        // Return mock data
        return [
            SearchResult(id: UUID(), title: "Result for '\(query)'", similarityScore: 0.95),
            SearchResult(id: UUID(), title: "Related to \(query)", similarityScore: 0.72)
        ]
    }
}

struct SearchResult: Identifiable, Sendable {
    let id: UUID
    let title: String
    let similarityScore: Double
}

@available(iOS 18.0, *)
struct DebouncedSearchView: View {
    @State private var viewModel = SemanticSearchViewModel()

    var body: some View {
        NavigationStack {
            List(viewModel.results) { result in
                Text(result.title)
            }
            .navigationTitle("Semantic Search")
            .searchable(text: $viewModel.searchText)
            .onChange(of: viewModel.searchText) { oldValue, newValue in
                // Trigger the async search handler via a new Task
                Task {
                    await viewModel.handleSearchChange()
                }
            }
            .overlay {
                if viewModel.isSearching {
                    ProgressView("Generating Embeddings...")
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(10)
                }
            }
        }
    }
}
