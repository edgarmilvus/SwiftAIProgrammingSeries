
/*
#
# These sources are part of the "Swift Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_5.swift
// Description: Solution for Exercise 5
// ==========================================

import Foundation
import SwiftData

@available(iOS 18.0, *)
@Model
final class Interaction {
    var timestamp: Date
    var content: String
    var summary: String?
    var embedding: [Float]?
    var tier: Int // 1: Hot, 2: Warm, 3: Cold
    
    init(content: String, embedding: [Float]? = nil) {
        self.timestamp = Date()
        self.content = content
        self.embedding = embedding
        self.tier = 1
    }
}

@available(iOS 18.0, *)
@ModelActor
actor PruningActor {
    /// Executes the tiered storage lifecycle management.
    func runPruningCycle() async throws {
        let now = Date()
        let oneMonthAgo = Calendar.current.date(byAdding: .month, value: -1, to: now)!
        let sixMonthsAgo = Calendar.current.date(byAdding: .month, value: -6, to: now)!
        
        // --- TIER 1 -> TIER 2 (Purge Embeddings) ---
        // Criteria: Tier 1 and older than 1 month
        let t1ToT2Predicate = #Predicate<Interaction> { interaction in
            interaction.tier == 1 && interaction.timestamp < oneMonthAgo
        }
        let t1ToT2Descriptor = FetchDescriptor<Interaction>(predicate: t1ToT2Predicate)
        let t1Interactions = try modelContext.fetch(t1ToT2Descriptor)
        
        for interaction in t1Interactions {
            interaction.tier = 2
            interaction.embedding = nil // Purge heavy vector
            // We keep 'content' for keyword search
        }
        try modelContext.save()
        
        // --- TIER 2 -> TIER 3 (Purge Content, Keep Summary) ---
        // Criteria: Tier 2 and older than 6 months
        let t2ToT3Predicate = #Predicate<Interaction> { interaction in
            interaction.tier == 2 && interaction.timestamp < sixMonthsAgo
        }
        let t2ToT3Descriptor = FetchDescriptor<Interaction>(predicate: t2ToT3Predicate)
        let t2Interactions = try modelContext.fetch(t2ToT3Descriptor)
        
        for interaction in t2Interactions {
            // In a real app, we would call an LLM here to generate a summary 
            // before stripping the content.
            interaction.summary = "Archived interaction from \(interaction.timestamp.formatted(date: .abbreviated, time: .omitted))"
            interaction.content = "" // Purge heavy text
            interaction.tier = 3
        }
        try modelContext.save()
        
        print("Pruning cycle complete. Processed \(t1Interactions.count) T1->T2 and \(t2Interactions.count) T2->T3 transitions.")
    }
}
