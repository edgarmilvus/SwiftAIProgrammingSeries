
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part2.swift
// Description: Advanced Application
// ==========================================

import Foundation
import AppIntents // Requires iOS 18.0 or later for AppIntents with Apple Intelligence features

// MARK: - 1. Data Structures for Receipt Information

/// Represents the structured data extracted from a receipt.
/// This data is the outcome of the on-device LLM's "on-screen awareness."
struct ReceiptData: Identifiable, Hashable, Sendable {
    let id = UUID()
    let merchantName: String
    let totalAmount: Decimal
    let transactionDate: Date
    let items: [String: Decimal] // Item description to amount mapping
    let rawText: String // Original text for context or debugging

    /// Initializes a new ReceiptData instance.
    /// - Parameters:
    ///   - merchantName: The name of the merchant.
    ///   - totalAmount: The total amount of the transaction.
    ///   - transactionDate: The date of the transaction.
    ///   - items: A dictionary of items and their respective amounts.
    ///   - rawText: The raw text from which the data was extracted.
    init(merchantName: String, totalAmount: Decimal, transactionDate: Date, items: [String: Decimal], rawText: String) {
        self.merchantName = merchantName
        self.totalAmount = totalAmount
        self.transactionDate = transactionDate
        self.items = items
        self.rawText = rawText
    }
}

// MARK: - 2. On-Device LLM Simulation for Content Analysis

/// Error types specific to receipt analysis.
enum ReceiptAnalysisError: Error, LocalizedError {
    case invalidInput
    case llmProcessingFailed(String)
    case dataExtractionFailed(String)
    case unauthorizedAccess // Example for future entitlement errors

    var errorDescription: String? {
        switch self {
        case .invalidInput:
            return "The provided input for analysis was invalid or empty."
        case .llmProcessingFailed(let message):
            return "LLM processing failed: \(message)"
        case .dataExtractionFailed(let message):
            return "Failed to extract structured data: \(message)"
        case .unauthorizedAccess:
            return "Access to perform this analysis is not authorized. Check entitlements."
        }
    }
}

/// A service that simulates interaction with an on-device LLM (Apple Intelligence Foundation Model)
/// to parse raw receipt text and extract structured `ReceiptData`.
/// This component embodies the "on-screen awareness" by understanding the semantic content.
@available(iOS 18.0, *)
class FoundationModelService {
    /// Simulates the processing of raw text by an on-device LLM.
    /// In a real scenario, this would interface with `PredictionService` or a dedicated
    /// `FoundationModels` API, requiring specific entitlements like
    /// `com.apple.developer.on-device-ml-inference`.
    ///
    /// - Parameter text: The raw text content of the receipt.
    /// - Returns: A `ReceiptData` object containing the extracted structured information.
    /// - Throws: `ReceiptAnalysisError` if processing fails or data cannot be extracted.
    func analyzeReceipt(text: String) async throws -> ReceiptData {
        guard !text.isEmpty else {
            throw ReceiptAnalysisError.invalidInput
        }

        // --- PRODUCTION PATTERN: LLM Interaction Placeholder ---
        // In a real application, this would involve:
        // 1. Constructing a prompt for the on-device LLM.
        //    Example: "Extract merchant name, total amount, date, and itemized list from this receipt text: '\(text)'"
        // 2. Calling the LLM API (e.g., `PredictionService.shared.predict(prompt: model:)`).
        // 3. Parsing the LLM's structured output (e.g., JSON or specific format).
        // 4. Robust error handling for LLM inference failures, timeouts, etc.

        // Simulate LLM processing delay and potential errors
        try await Task.sleep(for: .milliseconds(500)) // Simulate network/processing delay

        // A very basic, hardcoded simulation for demonstration purposes.
        // A real LLM would extract this intelligently.
        if text.lowercased().contains("error") {
            throw ReceiptAnalysisError.llmProcessingFailed("Simulated LLM failure due to 'error' keyword.")
        }

        // Simulate successful data extraction
        let merchantName = text.contains("Starbucks") ? "Starbucks" : "Local Cafe"
        let totalAmount: Decimal = text.contains("Starbucks") ? 12.50 : 8.75
        let transactionDate = Calendar.current.date(byAdding: .day, value: -Int.random(in: 1...30), to: Date()) ?? Date()
        let items: [String: Decimal] = text.contains("Starbucks") ?
            ["Latte": 5.25, "Croissant": 3.50, "Muffin": 3.75] :
            ["Coffee": 3.00, "Sandwich": 5.75]

        // Validate extracted data (production pattern)
        guard totalAmount > 0 else {
            throw ReceiptAnalysisError.dataExtractionFailed("Extracted total amount was invalid.")
        }

        return ReceiptData(
            merchantName: merchantName,
            totalAmount: totalAmount,
            transactionDate: transactionDate,
            items: items,
            rawText: text
        )
    }
}

// MARK: - 3. AppIntents for Contextual Actions

/// An `AppIntent` to add the extracted receipt details as an expense.
/// This demonstrates "in-app action entitlements" for system integration.
/// Requires `com.apple.developer.siri.app-intents` entitlement.
@available(iOS 18.0, *)
struct AddExpenseIntent: AppIntent {
    static var title: LocalizedStringResource = "Add to Expenses"
    static var description = IntentDescription("Adds this receipt's details to your expense tracker.")
    static var openAppWhenRun: Bool = true // Opens the app to confirm/complete the action

    /// Parameters for the intent, dynamically populated from `ReceiptData`.
    @Parameter(title: "Merchant Name")
    var merchant: String

    @Parameter(title: "Total Amount")
    var amount: Double

    @Parameter(title: "Transaction Date")
    var date: Date

    @Parameter(title: "Category", default: "Uncategorized")
    var category: String

    init() {} // Default initializer for AppIntent
    init(merchant: String, amount: Double, date: Date, category: String = "Uncategorized") {
        self.merchant = merchant
        self.amount = amount
        self.date = date
        self.category = category
    }

    /// Performs the action associated with this intent.
    /// In a real app, this would integrate with a budgeting framework, Core Data, or a backend.
    func perform() async throws -> some IntentResult {
        print("ACTION: Adding expense for \(merchant) of $\(amount) on \(date) to category '\(category)'")
        // Simulate saving to a database or calling another app via URL scheme/AppIntent
        try await Task.sleep(for: .seconds(1))
        return .result(dialog: "Expense for \(merchant) of $\(amount) added successfully!")
    }
}

/// An `AppIntent` to search for the merchant online.
/// This shows another type of contextual action, leveraging system capabilities.
@available(iOS 18.0, *)
struct SearchMerchantIntent: AppIntent {
    static var title: LocalizedStringResource = "Search Merchant Online"
    static var description = IntentDescription("Searches for the merchant on the web.")
    static var openAppWhenRun: Bool = false // Can run in background without opening app

    @Parameter(title: "Merchant Name")
    var merchant: String

    init() {}
    init(merchant: String) {
        self.merchant = merchant
    }

    func perform() async throws -> some IntentResult {
        guard let url = URL(string: "https://www.google.com/search?q=\(merchant.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")") else {
            throw AppIntentError.badRequest("Could not form search URL.")
        }
        // Open the URL in Safari, a common action for AppIntents
        await MainActor.run {
            UIApplication.shared.open(url)
        }
        return .result(dialog: "Searching for \(merchant) online.")
    }
}

// MARK: - 4. App Integration and Action Presentation

/// A conceptual `ReceiptProcessorAppView` that orchestrates the analysis and action presentation.
/// This would be part of a SwiftUI `View` in a real application.
@available(iOS 18.0, *)
struct ReceiptProcessorAppView {
    let foundationModelService = FoundationModelService()
    
    /// Simulates raw text input from an OCR process or manual entry.
    /// This is the "on-screen content" that the app becomes aware of.
    var currentReceiptText: String = """
    STARBUCKS COFFEE
    123 Main St, Anytown, USA
    Date: 2024-07-23
    Time: 09:30 AM
    --------------------
    Latte             $5.25
    Croissant         $3.50
    Muffin            $3.75
    --------------------
    Subtotal         $12.50
    Tax                $0.00
    Total            $12.50
    """

    /// Stores the analyzed receipt data and available actions.
    @State private var analyzedReceipt: ReceiptData?
    @State private var availableActions: [AppIntent] = []
    @State private var errorMessage: String?

    /// Orchestrates the receipt analysis and dynamic action generation.
    /// This method ties together the awareness (LLM analysis) and the action (AppIntents).
    func processReceipt() async {
        errorMessage = nil
        analyzedReceipt = nil
        availableActions = []

        do {
            // Step 1: Analyze the raw text using the on-device LLM.
            // This is where "on-screen awareness" of the document's content happens.
            let data = try await foundationModelService.analyzeReceipt(text: currentReceiptText)
            analyzedReceipt = data
            print("Successfully analyzed receipt for: \(data.merchantName), Total: \(data.totalAmount)")

            // Step 2: Dynamically generate AppIntents based on the extracted data.
            // These are the "in-app actions" driven by awareness.
            let addExpenseIntent = AddExpenseIntent(
                merchant: data.merchantName,
                amount: Double(truncating: data.totalAmount as NSNumber),
                date: data.transactionDate
            )
            let searchMerchantIntent = SearchMerchantIntent(merchant: data.merchantName)

            availableActions.append(addExpenseIntent)
            availableActions.append(searchMerchantIntent)

        } catch {
            errorMessage = error.localizedDescription
            print("Error processing receipt: \(error.localizedDescription)")
        }
    }

    /// Placeholder for a UI rendering function to display the results and actions.
    /// In a real SwiftUI app, this would be the `body` property.
    func renderUI() {
        print("\n--- Receipt Processor UI ---")
        if let errorMessage = errorMessage {
            print("ERROR: \(errorMessage)")
        } else if let receipt = analyzedReceipt {
            print("Analyzed Receipt:")
            print("  Merchant: \(receipt.merchantName)")
            print("  Total: $\(receipt.totalAmount)")
            print("  Date: \(receipt.transactionDate.formatted(date: .numeric, time: .shortened))")
            print("  Items: \(receipt.items.map { "\($0.key): $\($0.value)" }.joined(separator: ", "))")

            print("\nAvailable Actions:")
            for action in availableActions {
                // In SwiftUI, you'd use `Button(intent: action)` to present these.
                if let addExpense = action as? AddExpenseIntent {
                    print("- Action: \(AddExpenseIntent.title) (Merchant: \(addExpense.merchant), Amount: \(addExpense.amount))")
                    // Example of how to 'perform' an intent programmatically
                    Task {
                        do {
                            _ = try await addExpense.perform()
                        } catch {
                            print("Failed to perform AddExpenseIntent: \(error.localizedDescription)")
                        }
                    }
                } else if let searchMerchant = action as? SearchMerchantIntent {
                    print("- Action: \(SearchMerchantIntent.title) (Merchant: \(searchMerchant.merchant))")
                    Task {
                        do {
                            _ = try await searchMerchant.perform()
                        } catch {
                            print("Failed to perform SearchMerchantIntent: \(error.localizedDescription)")
                        }
                    }
                }
            }
        } else {
            print("No receipt processed yet. Tap 'Process Receipt' to begin.")
        }
        print("--------------------------")
    }
    
    // Example of how to run this in a main context (e.g., from an AppDelegate or main entry point)
    static func runExample() async {
        let view = ReceiptProcessorAppView()
        print("Starting receipt processing example...")
        await view.processReceipt()
        view.renderUI()

        // Simulate another receipt with an error
        print("\n--- Simulating an error case ---")
        view.currentReceiptText = "This receipt contains an error keyword which will simulate an LLM failure."
        await view.processReceipt()
        view.renderUI()
    }
}

// To run this example in a playground or an app's entry point:
/*
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView() // Your main app view
                .task {
                    // Example of running the logic on app launch
                    await ReceiptProcessorAppView.runExample()
                }
        }
    }
}
*/

// For a simple script execution:
@available(iOS 18.0, *)
@main
struct ReceiptProcessorScript {
    static func main() async {
        await ReceiptProcessorAppView.runExample()
    }
}
