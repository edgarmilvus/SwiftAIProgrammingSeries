
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part8.swift
// Description: Theoretical Foundations
// ==========================================

    import SwiftUI // For Color
    import Observation // For @Observable

    @available(iOS 17.0, *)
    @MainActor
    @Observable
    class ObjectDetectionViewModel {
        var detectedObjects: [DetectedObject] = []
        var currentImage: UIImage? // The image being displayed

        // Function to process observations and update state
        func processObservations(
            _ observations: [VNRecognizedObjectObservation],
            originalImageSize: CGSize,
            viewSize: CGSize
        ) {
            self.detectedObjects = observations.compactMap { observation in
                guard let bestLabel = observation.labels.first else { return nil }

                // Transform the bounding box
                let transformedRect = transformVisionRect(
                    observation.boundingBox,
                    imageSize: originalImageSize,
                    viewSize: viewSize
                )

                return DetectedObject(
                    boundingBox: transformedRect,
                    label: bestLabel.identifier,
                    confidence: bestLabel.confidence,
                    color: .red // Example color
                )
            }
        }
    }
    