
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_4.swift
// Description: Solution for Exercise 4
// ==========================================

import Foundation

// MARK: - 1. CalendarEvent Structure

/// Represents a calendar event.
struct CalendarEvent: Codable, Identifiable, Equatable {
    let id: UUID
    var title: String
    var date: Date // Start date/time
    var duration: TimeInterval // in seconds
    var participants: [String] // e.g., email addresses or names

    init(id: UUID = UUID(), title: String, date: Date, duration: TimeInterval, participants: [String] = []) {
        self.id = id
        self.title = title
        self.date = date
        self.duration = duration
        self.participants = participants
    }
    
    var endDate: Date {
        date.addingTimeInterval(duration)
    }
}

// MARK: - 2. Mock Calendar Service

/// Simulates calendar operations.
class MockCalendarService {
    private var events: [UUID: CalendarEvent] = [:]
    private let queue = DispatchQueue(label: "com.agent.calendar.service", qos: .userInitiated)

    func createEvent(event: CalendarEvent) async throws -> CalendarEvent {
        return await queue.sync {
            let newEvent = event
            events[newEvent.id] = newEvent
            print("MockCalendarService: Created event '\(newEvent.title)' (ID: \(newEvent.id))")
            return newEvent
        }
    }

    func findEvents(query: String, fromDate: Date?, toDate: Date?) async throws -> [CalendarEvent] {
        return await queue.sync {
            let now = Date()
            let filteredEvents = events.values.filter { event in
                let matchesQuery = query.isEmpty || event.title.localizedCaseInsensitiveContains(query) ||
                                   event.participants.contains(where: { $0.localizedCaseInsensitiveContains(query) })
                let isAfterFromDate = fromDate.map { event.endDate > $0 } ?? true
                let isBeforeToDate = toDate.map { event.date < $0 } ?? true
                let isFutureOrPresent = event.endDate >= now // Only show future/present events by default

                return matchesQuery && isAfterFromDate && isBeforeToDate && isFutureOrPresent
            }.sorted(by: { $0.date < $1.date })
            print("MockCalendarService: Found \(filteredEvents.count) events for query '\(query)'")
            return filteredEvents
        }
    }

    func updateEvent(id: UUID, newEvent: CalendarEvent) async throws -> CalendarEvent? {
        return await queue.sync {
            guard var existingEvent = events[id] else { return nil }
            
            existingEvent.title = newEvent.title
            existingEvent.date = newEvent.date
            existingEvent.duration = newEvent.duration
            existingEvent.participants = newEvent.participants
            
            events[id] = existingEvent
            print("MockCalendarService: Updated event '\(existingEvent.title)' (ID: \(existingEvent.id))")
            return existingEvent
        }
    }
    
    func getEvent(id: UUID) async throws -> CalendarEvent? {
        return await queue.sync {
            events[id]
        }
    }

    func deleteEvent(id: UUID) async throws -> Bool {
        return await queue.sync {
            if events.removeValue(forKey: id) != nil {
                print("MockCalendarService: Deleted event (ID: \(id))")
                return true
            }
            return false
        }
    }
}

// MARK: - LLM Abstraction and Tool Definitions

/// Protocol for LLM inference (reused from previous exercises).
protocol LLMInference {
    @available(iOS 18.0, macOS 15.0, *)
    func infer(prompt: String) async throws -> String
}

/// A mock LLM for the calendar agent.
class MockCalendarLLM: LLMInference {
    private let dateFormatter = ISO8601DateFormatter()

    @available(iOS 18.0, macOS 15.0, *)
    func infer(prompt: String) async throws -> String {
        try await Task.sleep(for: .milliseconds(300)) // Simulate LLM thinking

        // Simplified logic based on conversational flow
        if prompt.contains("Schedule a meeting with Alice next Tuesday at 10 AM for an hour") {
            let nextTuesday = Calendar.current.date(byAdding: .day, value: 3, to: Date())! // Example
            let date = Calendar.current.date(bySettingHour: 10, minute: 0, second: 0, of: nextTuesday)!
            return """
            {
                "toolName": "createCalendarEvent",
                "arguments": {
                    "title": "Meeting with Alice",
                    "date": "\(dateFormatter.string(from: date))",
                    "duration": 3600,
                    "participants": ["Alice"]
                }
            }
            """
        } else if prompt.contains("What should be the title") && prompt.contains("Project X Sync") {
            return """
            {
                "toolName": "modifyCalendarEvent",
                "arguments": {
                    "newTitle": "Project X Sync"
                },
                "response": "Okay, I've scheduled a meeting with Alice next Tuesday at 10 AM for one hour. What should be the title?"
            }
            """
        } else if prompt.contains("Let's call it 'Project X Sync'") && prompt.contains("pendingEventDetails") {
            return """
            {
                "toolName": "modifyCalendarEvent",
                "arguments": {
                    "newTitle": "Project X Sync"
                },
                "response": "Got it. The meeting 'Project X Sync' with Alice is set for next Tuesday at 10 AM."
            }
            """
        } else if prompt.contains("Actually, can we make it 11 AM instead?") && prompt.contains("Project X Sync") {
            let nextTuesday = Calendar.current.date(byAdding: .day, value: 3, to: Date())! // Example, should be from pending event
            let date = Calendar.current.date(bySettingHour: 11, minute: 0, second: 0, of: nextTuesday)!
            return """
            {
                "toolName": "modifyCalendarEvent",
                "arguments": {
                    "newDate": "\(dateFormatter.string(from: date))"
                },
                "response": "Sure, I've updated 'Project X Sync' to 11 AM next Tuesday."
            }
            """
        } else if prompt.contains("What are my events tomorrow?") {
             return """
            {
                "toolName": "searchCalendarEvents",
                "arguments": {
                    "query": "",
                    "startDate": "\(dateFormatter.string(from: Calendar.current.startOfDay(for: Date().addingTimeInterval(24*60*60))))",
                    "endDate": "\(dateFormatter.current.date(byAdding: .day, value: 2, to: Calendar.current.startOfDay(for: Date()))!)"
                }
            }
            """
        } else if prompt.contains("Please specify the event ID.") { // Clarification
            return """
            {
                "clarificationQuestion": "Please specify the event ID or a more specific title for the event you want to modify."
            }
            """
        } else if prompt.contains("delete 'Project X Sync'") {
            return """
            {
                "toolName": "deleteCalendarEvent",
                "arguments": {
                    "query": "Project X Sync"
                }
            }
            """
        }
        
        // Default response if no specific match
        return """
        {
            "response": "I'm not sure how to handle that. Can you rephrase or provide more details?"
        }
        """
    }
}


/// Represents a tool the agent can invoke (reused from Exercise 1, adapted for calendar).
struct AgentTool {
    let name: String
    let description: String
    let action: ([String: Any]) async throws -> String // Closure to execute the tool

    // Helper for creating tools with specific argument types
    static func make<A: Decodable>(name: String, description: String, _ handler: @escaping (A) async throws -> String) -> AgentTool {
        AgentTool(name: name, description: description) { argsDict in
            let data = try JSONSerialization.data(withJSONObject: argsDict, options: [])
            let typedArgs = try JSONDecoder().decode(A.self, from: data)
            return try await handler(typedArgs)
        }
    }
}

// Argument definitions for calendar tools
struct CreateCalendarEventArgs: Codable {
    let title: String
    let date: Date
    let duration: TimeInterval
    let participants: [String]?
}

struct SearchCalendarEventArgs: Codable {
    let query: String?
    let startDate: Date?
    let endDate: Date?
}

struct ModifyCalendarEventArgs: Codable {
    let id: UUID? // If directly provided
    let query: String? // If searching by title
    let newTitle: String?
    let newDate: Date?
    let newDuration: TimeInterval?
    let newParticipants: [String]?
}

struct DeleteCalendarEventArgs: Codable {
    let id: UUID?
    let query: String?
}


// MARK: - 4. CalendarAgentState

/// Holds the persistent state for the conversational calendar agent.
class CalendarAgentState {
    var conversationalHistory: [String] = []
    var pendingEventDetails: CalendarEvent? // For multi-turn event creation/modification
    var lastToolResult: String? // Output from the previous tool call
    var lastInteractedEventID: UUID? // ID of the last event the user interacted with

    func addMessageToHistory(_ message: String) {
        conversationalHistory.append(message)
        // Keep history manageable, e.g., last 10 turns
        if conversationalHistory.count > 10 {
            conversationalHistory.removeFirst(conversationalHistory.count - 10)
        }
    }
}

// MARK: - 5. CalendarAgent

/// Decodable structure for LLM's multi-turn output.
struct LLMCalendarResponse: Decodable {
    let toolName: String?
    let arguments: [String: JSONValue]? // Reusing JSONValue from Exercise 1
    let clarificationQuestion: String?
    let response: String? // Final natural language response
}

@available(iOS 18.0, macOS 15.0, *)
class CalendarAgent {
    private let llm: LLMInference
    private let calendarService: MockCalendarService
    private let state: CalendarAgentState
    private let tools: [String: AgentTool]
    private let jsonDecoder: JSONDecoder

    init(llm: LLMInference, calendarService: MockCalendarService, initialState: CalendarAgentState = CalendarAgentState()) {
        self.llm = llm
        self.calendarService = calendarService
        self.state = initialState
        
        let dateFormatter = ISO8601DateFormatter()
        self.jsonDecoder = JSONDecoder()
        self.jsonDecoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let dateString = try container.decode(String.self)
            if let date = dateFormatter.date(from: dateString) {
                return date
            }
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Cannot decode date string \(dateString)")
        }

        // Define calendar tools
        let createEventTool = AgentTool.make(
            name: "createCalendarEvent",
            description: "Creates a new calendar event. Requires title, date (ISO 8601), duration (seconds). Optional participants (array of strings)."
        ) { (args: CreateCalendarEventArgs) in
            let event = CalendarEvent(title: args.title, date: args.date, duration: args.duration, participants: args.participants ?? [])
            let createdEvent = try await self.calendarService.createEvent(event: event)
            self.state.lastInteractedEventID = createdEvent.id
            self.state.pendingEventDetails = createdEvent // Store for multi-turn updates
            return "Event '\(createdEvent.title)' created for \(createdEvent.date.formatted()). ID: \(createdEvent.id)"
        }

        let searchEventsTool = AgentTool.make(
            name: "searchCalendarEvents",
            description: "Searches for calendar events. Optional query (string), startDate (ISO 8601), endDate (ISO 8601)."
        ) { (args: SearchCalendarEventArgs) in
            let events = try await self.calendarService.findEvents(query: args.query ?? "", fromDate: args.startDate, toDate: args.endDate)
            if events.isEmpty {
                return "No events found."
            }
            let eventDescriptions = events.map { event in
                self.state.lastInteractedEventID = event.id // Update last interacted event
                return "- '\(event.title)' on \(event.date.formatted()) for \(Int(event.duration / 60)) minutes."
            }.joined(separator: "\n")
            return "Found \(events.count) events:\n\(eventDescriptions)"
        }

        let modifyEventTool = AgentTool.make(
            name: "modifyCalendarEvent",
            description: "Modifies an existing calendar event. Requires event 'id' or 'query' to find. Can update newTitle, newDate (ISO 8601), newDuration (seconds), newParticipants (array of strings)."
        ) { (args: ModifyCalendarEventArgs) in
            guard let eventID = args.id ?? self.state.lastInteractedEventID else {
                return "Error: Cannot modify event without an ID or a previously discussed event."
            }
            
            guard var existingEvent = try await self.calendarService.getEvent(id: eventID) else {
                return "Error: Event with ID \(eventID) not found."
            }
            
            // Apply updates
            if let newTitle = args.newTitle { existingEvent.title = newTitle }
            if let newDate = args.newDate { existingEvent.date = newDate }
            if let newDuration = args.newDuration { existingEvent.duration = newDuration }
            if let newParticipants = args.newParticipants { existingEvent.participants = newParticipants }

            if let updatedEvent = try await self.calendarService.updateEvent(id: eventID, newEvent: existingEvent) {
                self.state.pendingEventDetails = updatedEvent // Update pending event
                return "Event '\(updatedEvent.title)' (ID: \(updatedEvent.id)) updated successfully."
            } else {
                return "Failed to update event with ID \(eventID)."
            }
        }
        
        let deleteEventTool = AgentTool.make(
            name: "deleteCalendarEvent",
            description: "Deletes a calendar event. Requires event 'id' or 'query' to find."
        ) { (args: DeleteCalendarEventArgs) in
            guard let eventID = args.id ?? self.state.lastInteractedEventID else {
                 let events = try await self.calendarService.findEvents(query: args.query ?? "", fromDate: nil, toDate: nil)
                 if events.count == 1, let eventToDelete = events.first {
                     if try await self.calendarService.deleteEvent(id: eventToDelete.id) {
                         self.state.pendingEventDetails = nil // Clear pending event if deleted
                         self.state.lastInteractedEventID = nil
                         return "Event '\(eventToDelete.title)' deleted successfully."
                     }
                 }
                return "Error: Cannot delete event without an ID or a specific query that identifies a single event."
            }
            
            if try await self.calendarService.deleteEvent(id: eventID) {
                self.state.pendingEventDetails = nil // Clear pending event if deleted
                self.state.lastInteractedEventID = nil
                return "Event (ID: \(eventID)) deleted successfully."
            } else {
                return "Failed to delete event with ID \(eventID)."
            }
        }

        self.tools = [
            createEventTool.name: createEventTool,
            searchEventsTool.name: searchEventsTool,
            modifyEventTool.name: modifyEventTool,
            deleteEventTool.name: deleteEventTool
        ]
    }

    private func generatePrompt(for input: String) -> String {
        let toolDescriptions = tools.values.map { tool in
            "Tool Name: \(tool.name)\nDescription: \(tool.description)"
        }.joined(separator: "\n---\n")

        let history = state.conversationalHistory.isEmpty ? "No prior conversation." : state.conversationalHistory.joined(separator: "\n")
        let pendingEvent = state.pendingEventDetails.map { event in
            "Pending Event Details:\nID: \(event.id)\nTitle: \(event.title)\nDate: \(event.date.formatted())\nDuration: \(event.duration) seconds\nParticipants: \(event.participants.joined(separator: ", "))"
        } ?? "No pending event."
        let lastResult = state.lastToolResult.map { "Last Tool Result: \($0)" } ?? "No previous tool result."

        return """
        You are a conversational AI assistant for managing a calendar.
        You can schedule, find, modify, and delete events.
        Maintain context from previous turns and pending event details.

        Here are the tools you have available:
        \(toolDescriptions)

        Current Conversational History:
        \(history)

        \(pendingEvent)
        \(lastResult)

        Based on the user's current input, decide on the next action:
        1. Call a tool: Respond with a JSON object:
           {
               "toolName": "name_of_the_tool",
               "arguments": { "arg1": "value1", ... },
               "response": "Optional natural language response to user after tool execution."
           }
           Ensure date arguments are in ISO 8601 format. If modifying an event, use the 'id' from 'pendingEventDetails' if available, or extract 'query'.

        2. Ask for clarification: Respond with a JSON object:
           {
               "clarificationQuestion": "A natural language question to get more information."
           }

        3. Provide a final response (task complete or general chat): Respond with a JSON object:
           {
               "response": "A natural language response to the user."
           }

        User Input: "\(input)"
        JSON Response:
        """
    }

    func process(input: String) async throws -> String {
        print("\n--- Agent processing input: \"\(input)\" ---")
        state.addMessageToHistory("User: \(input)")

        // Reasoning
        let prompt = generatePrompt(for: input)
        let llmResponse = try await llm.infer(prompt: prompt)
        print("LLM Raw Response:\n\(llmResponse)")

        // Acting
        guard let data = llmResponse.data(using: .utf8) else {
            throw AgentError.invalidLLMResponse("Could not encode LLM response to data.")
        }

        let agentAction: LLMCalendarResponse
        do {
            agentAction = try jsonDecoder.decode(LLMCalendarResponse.self, from: data)
        } catch {
            print("Failed to decode LLM calendar response JSON: \(error.localizedDescription)")
            throw AgentError.invalidLLMResponse("Malformed JSON from LLM: \(error.localizedDescription)")
        }

        var agentOutput: String
        if let clarification = agentAction.clarificationQuestion {
            agentOutput = clarification
        } else if let toolName = agentAction.toolName, let arguments = agentAction.arguments {
            guard let tool = tools[toolName] else {
                throw AgentError.toolNotFound("Tool '\(toolName)' not found.")
            }
            let argumentsAsAny = arguments.mapValues { $0.toAny } as! [String: Any]

            do {
                let toolResult = try await tool.action(argumentsAsAny)
                state.lastToolResult = toolResult // Observing: Store tool result
                agentOutput = agentAction.response ?? toolResult // Prioritize LLM's suggested response
            } catch {
                state.lastToolResult = "Error: \(error.localizedDescription)" // Observing: Store error
                agentOutput = "I encountered an error while trying to perform that action: \(error.localizedDescription)"
            }
        } else if let response = agentAction.response {
            agentOutput = response
        } else {
            agentOutput = "I'm sorry, I couldn't understand your request."
        }

        // Observing: Update history with agent's response
        state.addMessageToHistory("Agent: \(agentOutput)")
        print("Agent's Response: \(agentOutput)")
        return agentOutput
    }
}

// MARK: - Example Conversation Flow

@available(iOS 18.0, macOS 15.0, *)
func runCalendarAgentExample() async {
    let llm = MockCalendarLLM()
    let calendarService = MockCalendarService()
    let agent = CalendarAgent(llm: llm, calendarService: calendarService)

    let conversation: [(String, String?)] = [
        ("Schedule a meeting with Alice next Tuesday at 10 AM for an hour.", "Okay, I've scheduled a meeting with Alice next Tuesday at 10 AM for one hour. What should be the title?"),
        ("Let's call it 'Project X Sync'.", "Got it. The meeting 'Project X Sync' with Alice is set for next Tuesday at 10 AM."),
        ("Actually, can we make it 11 AM instead?", "Sure, I've updated 'Project X Sync' to 11 AM next Tuesday."),
        ("What are my events tomorrow?", "Found 1 events:\n- 'Project X Sync' on ..."), // Mock LLM will return a general search
        ("Delete 'Project X Sync'.", "Event 'Project X Sync' deleted successfully."),
        ("What are my events tomorrow?", "No events found."), // After deletion
        ("Find me information about Swift concurrency.", "I'm not sure how to handle that. Can you rephrase or provide more details?") // Unrelated query
    ]

    for (userInput, expectedPartialResponse) in conversation {
        do {
            let agentResponse = try await agent.process(input: userInput)
            // Basic check for expected response (mock specific)
            if let expected = expectedPartialResponse, !agentResponse.contains(expected.prefix(20)) {
                print("WARNING: Agent response did not match expected partial string for input: '\(userInput)'")
                print("Expected partial: '\(expected.prefix(20))'")
                print("Actual: '\(agentResponse.prefix(20))'")
            }
            print("--- End of Turn ---")
        } catch {
            print("Agent encountered an error: \(error.localizedDescription)")
        }
    }
}

// To run the example in a playground or an app:
// if #available(iOS 18.0, macOS 15.0, *) {
//     Task {
//         await runCalendarAgentExample()
//     }
// } else {
//     print("Requires iOS 18.0 / macOS 15.0 or later for async/await functionality.")
// }
