
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.swift
// Description: Theoretical Foundations
// ==========================================

// Example of a Sendable data structure for AI results
struct AISuggestion: Identifiable, Hashable, Sendable { // Conforms to Sendable
    let id: UUID
    let text: String
    let type: SuggestionType
    
    enum SuggestionType: String, Sendable { // Enum cases are implicitly Sendable
        case rewrite
        case proofread
        case summarize
        case custom
    }
}

@available(iOS 18.0, *)
actor CustomSuggestionManager {
    private var suggestionsCache: [UUID: AISuggestion] = [:]
    
    func addSuggestion(_ suggestion: AISuggestion) { // AISuggestion is Sendable, safe to pass
        suggestionsCache[suggestion.id] = suggestion
    }
    
    func getSuggestion(id: UUID) -> AISuggestion? {
        return suggestionsCache[id]
    }
    
    func processSuggestionsInBackground(suggestions: [AISuggestion]) async { // [AISuggestion] is Sendable if AISuggestion is
        for suggestion in suggestions {
            print("Processing suggestion \(suggestion.id) of type \(suggestion.type.rawValue)")
            // Simulate heavy processing
            try? await Task.sleep(for: .milliseconds(100))
        }
    }
}

// Using Sendable types
@available(iOS 18.0, *)
func demonstrateSendable() async {
    let manager = CustomSuggestionManager()
    let newSuggestion = AISuggestion(id: UUID(), text: "Hello there!", type: .rewrite)
    
    // Pass Sendable object to an actor
    await manager.addSuggestion(newSuggestion)
    
    // Pass an array of Sendable objects to an async function
    await manager.processSuggestionsInBackground(suggestions: [newSuggestion])
}
