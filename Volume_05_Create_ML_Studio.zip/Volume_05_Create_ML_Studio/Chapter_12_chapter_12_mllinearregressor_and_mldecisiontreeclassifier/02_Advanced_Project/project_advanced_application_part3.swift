
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: project_advanced_application_part3.swift
// Description: Advanced Application
// ==========================================

/// Prepares an `MLDataTable` from an array of `UtilityBillData`.
/// This is the crucial step of transforming raw data into a format Create ML can consume.
/// - Parameter data: An array of `UtilityBillData`.
/// - Returns: An `MLDataTable` ready for model training or prediction.
/// - Throws: `UtilityBillPredictorError.dataTableCreationFailed` if the table cannot be created.
func prepareDataTable(from data: [UtilityBillData]) throws -> MLDataTable {
    var columns: [String: MLDataValueConvertible] = [
        "month": data.map { $0.month },
        "avgTemperatureC": data.map { $0.avgTemperatureC },
        "householdOccupants": data.map { $0.householdOccupants },
        "previousBillAmount": data.map { $0.previousBillAmount },
        "actualBillAmount": data.map { $0.actualBillAmount }
    ]

    do {
        return try MLDataTable(dictionary: columns)
    } catch {
        throw UtilityBillPredictorError.dataTableCreationFailed(error.localizedDescription)
    }
}
