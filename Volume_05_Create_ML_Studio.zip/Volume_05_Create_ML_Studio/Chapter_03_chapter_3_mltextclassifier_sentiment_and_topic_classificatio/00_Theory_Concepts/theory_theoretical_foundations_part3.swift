
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.swift
// Description: Theoretical Foundations
// ==========================================

import SwiftUI
import CoreML

// Assuming MyTextClassifier is the generated class from your .mlmodel
@available(iOS 18.0, macOS 15.0, *)
@Observable
class TextClassifierViewModel {
    private let predictor: ModelPredictor // Our actor for model interaction
    var inputText: String = ""
    var classifiedLabel: String?
    var confidence: Double?
    var isLoading: Bool = false
    var errorMessage: String?

    init(predictor: ModelPredictor) {
        self.predictor = predictor
    }

    func classifyText() async {
        guard !inputText.isEmpty else {
            classifiedLabel = nil
            confidence = nil
            errorMessage = "Please enter text to classify."
            return
        }

        isLoading = true
        errorMessage = nil
        do {
            let (label, conf) = try await predictor.predictSentiment(for: inputText)
            classifiedLabel = label
            confidence = conf
        } catch {
            errorMessage = "Classification failed: \(error.localizedDescription)"
            classifiedLabel = nil
            confidence = nil
        }
        isLoading = false
    }
}

@available(iOS 18.0, macOS 15.0, *)
struct TextClassifierView: View {
    @State private var predictor: ModelPredictor?
    @State private var viewModel: TextClassifierViewModel?
    @State private var loadingModel: Bool = true

    var body: some View {
        Group {
            if loadingModel {
                ProgressView("Loading ML Model...")
            } else if let viewModel = viewModel {
                VStack {
                    TextField("Enter text here...", text: $viewModel.inputText)
                        .textFieldStyle(.roundedBorder)
                        .padding()

                    Button("Classify") {
                        Task {
                            await viewModel.classifyText()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(viewModel.isLoading)

                    if viewModel.isLoading {
                        ProgressView()
                    } else if let label = viewModel.classifiedLabel, let conf = viewModel.confidence {
                        Text("Result: \(label) (Confidence: \(String(format: "%.2f", conf * 100))%)")
                            .font(.headline)
                            .padding()
                    } else if let error = viewModel.errorMessage {
                        Text("Error: \(error)")
                            .foregroundStyle(.red)
                            .padding()
                    }
                }
            } else {
                Text("Error: Model predictor not initialized.")
            }
        }
        .task {
            // Initialize the predictor and view model when the view appears
            do {
                self.predictor = try await ModelPredictor()
                self.viewModel = TextClassifierViewModel(predictor: self.predictor!)
                self.loadingModel = false
            } catch {
                print("Failed to load model predictor: \(error)")
                self.loadingModel = false
            }
        }
    }
}
