
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_3.swift
// Description: Solution for Exercise 3
// ==========================================

import SwiftUI
import Foundation
// import MLX

// Reusing LLMService protocol and LLMServiceError from Exercise 1
// protocol LLMService { ... }
// enum LLMServiceError: Error, LocalizedError { ... }

/// A simulated MLX LLM service that streams a predefined Markdown response.
final class MarkdownStreamingService: LLMService {
    private let simulatedMarkdownResponse = """
    # Introduction to MLX Swift
    This is a **simulated** streaming response demonstrating real-time Markdown rendering.

    MLX Swift allows developers to leverage Apple's powerful Neural Engine and GPU for machine learning tasks directly within Swift applications.

    ## Key Concepts
    *   **Unified Memory:** MLX takes full advantage of Apple Silicon's unified memory architecture, minimizing data transfers between CPU and GPU.
    *   **Lazy Evaluation:** Operations on `MLXArray` build a computation graph that is only evaluated when results are needed, optimizing performance.
    *   **Swift-Native:** Provides a native Swift API, making it easy to integrate into existing Swift projects.

    ### Example Code (Simulated)
    