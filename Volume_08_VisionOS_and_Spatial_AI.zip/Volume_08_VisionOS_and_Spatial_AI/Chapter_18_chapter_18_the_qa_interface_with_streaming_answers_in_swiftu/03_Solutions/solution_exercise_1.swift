
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: solution_exercise_1.swift
// Description: Solution for Exercise 1
// ==========================================

import SwiftUI
import Observation

@available(iOS 18.0, *)
@Observable
@MainActor
class TerminalViewModel {
    var currentResponse: String = ""
    var isStreaming: Bool = false

    /// Simulates an LLM streaming tokens one by one
    func startStreaming() -> AsyncStream<String> {
        AsyncStream { continuation in
            let tokens = ["Hello", " ", "this", " ", "is", " ", "a", " ", "simulated", " ", "AI", " ", "stream."]
            
            Task {
                for token in tokens {
                    // Simulate network latency/generation time
                    try? await Task.sleep(for: .milliseconds(300))
                    
                    // Check for cancellation to prevent "ghost" updates
                    if Task.isCancelled {
                        continuation.finish()
                        return
                    }
                    
                    continuation.yield(token + " ")
                }
                continuation.finish()
            }
        }
    }

    func runStream() async {
        isStreaming = true
        currentResponse = ""
        
        let stream = startStreaming()
        
        for await chunk in stream {
            // Because the ViewModel is @MainActor, this update is thread-safe
            currentResponse += chunk
        }
        
        isStreaming = false
    }
}

struct TerminalView: View {
    @State private var viewModel = TerminalViewModel()

    var body: some View {
        VStack(spacing: 20) {
            ScrollView {
                Text(viewModel.currentResponse)
                    .font(.system(.body, design: .monospaced))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
            }
            .background(Color.black.opacity(0.05))
            .cornerRadius(12)

            Button {
                Task {
                    await viewModel.runStream()
                }
            } label: {
                if viewModel.isStreaming {
                    ProgressView()
                } else {
                    Text("Start Generation")
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(viewModel.isStreaming)
        }
        .padding()
        .padding(.top, 50)
        // .task handles automatic cancellation when the view disappears
        .task {
            // This is where we would trigger logic if it needed to start immediately
        }
    }
}
