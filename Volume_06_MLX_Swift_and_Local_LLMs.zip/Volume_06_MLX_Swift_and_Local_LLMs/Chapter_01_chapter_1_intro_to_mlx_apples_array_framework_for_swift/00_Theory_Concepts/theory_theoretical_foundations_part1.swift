
/*
#
# These sources are part of the "C# Programming Series" by Edgar Milvus, 
# for additional info, new volumes, link to stores:
# https://github.com/edgarmilvus/SwiftAIProgrammingSeries
#
# MIT License
# Copyright (c) 2026 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part1.swift
// Description: Theoretical Foundations
// ==========================================

    // Package.swift snippet for MLX dependencies
    // .package(url: "https://github.com/mlx-swift/mlx-swift.git", from: "0.1.0"),
    // .product(name: "MLX", package: "mlx-swift"),

    import MLX

    // Define a simple function to compute
    // f(x) = x^2 + 2x + 1
    @available(iOS 18.0, *)
    func myLossFunction(x: MLXArray) -> MLXArray {
        return x * x + 2 * x + 1
    }

    @available(iOS 18.0, *)
    func demonstrateGradient() {
        let x = MLXArray(1.0) // Our input, an MLXArray
        
        // Use valueAndGradient to get a function that computes both the value and its gradient
        let valueAndGradFn = valueAndGradient(myLossFunction)
        
        // Call the new function with x to get the result
        let (value, gradient) = valueAndGradFn(x: x)
        
        // Force evaluation to compute the actual values
        value.eval()
        gradient.eval()
        
        print("x: \(x)") // x: 1.0
        print("Value (f(x)): \(value)") // Value (f(x)): 4.0 (1^2 + 2*1 + 1)
        print("Gradient (df/dx): \(gradient)") // Gradient (df/dx): 4.0 (2x + 2, at x=1 -> 2*1 + 2 = 4)
    }

    // demonstrateGradient() // Call this in an appropriate context
    